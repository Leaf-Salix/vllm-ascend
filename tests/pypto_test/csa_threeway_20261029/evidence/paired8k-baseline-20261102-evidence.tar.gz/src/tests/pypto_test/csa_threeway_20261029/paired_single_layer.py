# SPDX-License-Identifier: Apache-2.0
"""冻结两份完整CSA，同一Native fixture，图恢复在计时外；不测整模型。"""

import argparse
import importlib
import importlib.util
import json
import math
import os
import shutil
import statistics
import sys
from pathlib import Path


def mount_package(source, name):
    """与既有单层runner相同的隔离导入，避免依赖未同步的历史脚本。"""
    assert name not in sys.modules
    spec = importlib.util.spec_from_file_location(
        name, source / "__init__.py", submodule_search_locations=[str(source)]
    )
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return name


def main():
    import pypto.torch
    import torch
    import torch_npu
    from dsv4_csa_native_case import native_session
    from dsv4_csa_single_layer import guard_checks, make_layer, restore
    from nal_native_alignment_20261027.ragged_fixture import make_ragged_fixture
    from pypto.runtime.kernel.abi import KernelConfig
    from vllm.engine.arg_utils import EngineArgs
    from vllm.platforms import current_platform

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cpu", choices=("ours", "nalinaly"))
    args = parser.parse_args()
    args.output.mkdir(exist_ok=False)
    package = "vllm_ascend/ops/pypto/deepseek_v4_flash_csa_spmd_tnd"
    sources = {
        "ours": args.root / "cohorts/eightcard-source-v5/ours/source",
        "nalinaly": args.root / "cohorts/eightcard-nal-pre-aclnn-1574-v1/nalinaly/source",
    }
    modules = {}
    report = {"scope": "single real layer4, synthetic common hidden/history, B8/S6/8K", "sources": {}}
    for arm, source in sources.items():
        report["sources"][arm] = json.loads((source.parent / "manifest.json").read_text())["csa_source"]
        name = mount_package(source / package, "vllm_ascend.ops.pypto._paired_" + arm)
        modules[arm] = {
            n: importlib.import_module(name + "." + n) for n in ("entry", "policy", "binding", "native_adapter")
        }
    if args.cpu:
        arm = args.cpu
        policy = modules[arm]["policy"].select_policy(tokens=48, requests=8, max_query_tokens=6, max_seq_len=8198)
        artifact, _, _ = modules[arm]["entry"].decode_csa_spmd._resolve_compiled(
            (),
            policy.constexprs(),
            allow_signature_mode=True,
            _kernel=True,
            _kernel_config=KernelConfig("a2a3", "tensormap_and_ringbuffer", 0, ring_task_window=2048),
        )
        artifact.load()
        assert not torch_npu.npu.is_initialized()
        report.update(cpu_only=True, artifact=artifact.identity().hex())
    else:
        assert os.environ["TASK_DEVICE"] in ("8", "9", "10", "11", "12", "13", "15")
        assert os.environ["ASCEND_RT_VISIBLE_DEVICES"] == os.environ["TASK_DEVICE"]
        torch.npu.set_device(0)
        torch.npu.config.allow_internal_format = True
        torch.use_deterministic_algorithms(True)
        torch_npu.npu.set_deterministic_level(1)
        torch.set_num_threads(4)
        current_platform.pre_register_and_update()
        from vllm_ascend.utils import enable_custom_op

        assert enable_custom_op(), "Native custom operators must be registered before metadata construction"
        checkpoint = "/data/model/DeepSeek-V4-Flash-0731-w8a8"
        config = EngineArgs(
            model=checkpoint,
            tokenizer_mode="deepseek_v4",
            trust_remote_code=True,
            dtype="bfloat16",
            quantization="ascend",
            tensor_parallel_size=1,
            hf_overrides={"sliding_window": 128},
            max_model_len=16384,
            max_num_seqs=40,
            max_num_batched_tokens=256,
            block_size=32,
            enable_prefix_caching=False,
            enforce_eager=True,
            speculative_config={"method": "dspark", "num_speculative_tokens": 5, "enforce_eager": True},
            additional_config={"weight_nz_mode": 2, "enable_kv_nz": False, "enable_dsa_cp": False},
        ).create_engine_config()
        with native_session(config, 0), torch.inference_mode():
            layer, _ = make_layer(config, Path(checkpoint), torch.device("npu:0"), 4)
            fixture = make_ragged_fixture(config, layer.self_attn, 8, 8192, 1024, torch.device("npu:0"), [6] * 8)
            groups = {n: (fixture["metadata"][g["prefix"]], g["views"]) for n, g in fixture["groups"].items()}
            from vllm_ascend.ops.pypto.deepseek_v4_flash_csa.native_adapter import prepare_weights

            pypto.torch.init(
                ring_heap=(256 << 20, 512 << 20, 256 << 20, 256 << 20),
                ring_task_window=2048,
                enable_chip_swimlane=1,
                enable_dep_gen=False,
                output_dir=str(args.output / "dfx"),
            )
            fixture["readonly"]["hidden"] = (fixture["hidden"], fixture["hidden"].cpu().clone())
            graphs, outputs, controls, owners = {}, {}, {}, {}

            def snapshot(output):
                return {
                    "output": output.cpu().clone(),
                    **{n: g["allocation"].cpu().clone() for n, g in fixture["groups"].items()},
                }

            def check_readonly():
                for value, initial in fixture["readonly"].values():
                    assert torch.equal(
                        value.cpu().contiguous().view(torch.uint8), initial.contiguous().view(torch.uint8)
                    )

            def check_guards():
                check_readonly()
                assert all(row["status"] == "PASS" for row in guard_checks(fixture).values()), "invalid write domain"

            for arm, module in modules.items():
                output = torch.empty_like(fixture["hidden"])
                outputs[arm] = output
                weights = prepare_weights(
                    layer.self_attn, groups["indexer"][0].hadamard, layer, root_function=module["entry"].decode_csa_spmd
                )
                native = module["native_adapter"].bind_native_inputs(
                    weights,
                    fixture["hidden"],
                    fixture["positions"],
                    groups,
                    layer_name=layer.self_attn.dsa_attn.dsa_attn.layer_name,
                    compact_metadata=fixture["compact"],
                    output=output,
                )
                entry = module["binding"].PreparedDynamicCSA(native, max_query_tokens=6, max_seq_len=8198)
                owners[arm] = (entry, native, weights)  # 保活所有图外权重/scale/绑定，直到末次replay。
                restore(fixture)
                entry()
                torch.npu.synchronize()
                check_guards()
                controls[arm] = snapshot(output)
                graph = torch.npu.NPUGraph()
                with torch.npu.graph(graph):
                    entry()
                graphs[arm] = graph
            samples = {arm: [] for arm in modules}
            for window in range(35):
                for arm in list(modules) if window % 2 == 0 else list(reversed(modules)):
                    restore(fixture)
                    torch.npu.synchronize()
                    begin, end = torch.npu.Event(enable_timing=True), torch.npu.Event(enable_timing=True)
                    begin.record()
                    graphs[arm].replay()
                    end.record()
                    torch.npu.synchronize()
                    check_readonly()
                    if window >= 5:
                        samples[arm].append(begin.elapsed_time(end) * 1000)
            report["self_replay_equal"] = {}
            for arm, graph in graphs.items():
                restore(fixture)
                graph.replay()
                torch.npu.synchronize()
                check_guards()
                state = snapshot(outputs[arm])
                report["self_replay_equal"][arm] = all(
                    torch.equal(state[n].contiguous().view(torch.uint8), v.contiguous().view(torch.uint8))
                    for n, v in controls[arm].items()
                )
            assert all(report["self_replay_equal"].values()), "graph/eager self control failed"
            assert all(len(v) == 30 and all(math.isfinite(x) and x > 0 for x in v) for v in samples.values())
            report["timing_us"] = {
                a: dict(samples=v, median=statistics.median(v), mean=statistics.mean(v)) for a, v in samples.items()
            }
            (args.output / "result.json").write_text(json.dumps(report, indent=2) + "\n")
            report["dfx"] = {}
            for index, (arm, graph) in enumerate(graphs.items()):
                restore(fixture)
                torch.npu.synchronize()
                pypto.torch.begin_dfx()
                try:
                    graph.replay()
                finally:
                    pypto.torch.end_dfx()
                torch.npu.synchronize()
                source = args.output / "dfx"
                if index:
                    source /= f"window_{index}"
                destination = args.output / f"dfx_{arm}.json"
                shutil.copyfile(source / "chip_swimlane_records.json", destination)
                report["dfx"][arm] = str(destination)
                check_guards()
    (args.output / "result.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        destination = Path(sys.argv[2])
        if destination.is_dir():
            (destination / "failure.json").write_text(json.dumps({"passed": False, "error": repr(error)}) + "\n")
        raise
