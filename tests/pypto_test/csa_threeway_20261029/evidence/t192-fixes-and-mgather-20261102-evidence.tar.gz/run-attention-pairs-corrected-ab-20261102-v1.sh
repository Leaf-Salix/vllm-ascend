#!/usr/bin/env bash
set -euo pipefail
case "${TASK_DEVICE:?}" in 8|9|10|11|12|13|15) ;; *) exit 2;; esac
r=/data/pyptouser/yejia/vllm-nal-tnd-native-align-20261027-codex
source "$r/src/tests/pypto_test/nal_native_alignment_20261027/env.sh"
s="$r/cohorts/eightcard-source-v5/native/source"
export SOURCE_ROOT="$s" ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
export PYTHONPATH="$r/src/tests/pypto_test:${PYTHONPATH:-}"
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$s/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$r/results/attention-pairs-corrected-ab-20261102-v1-opp")
cp "$r/src/tests/pypto_test/csa_threeway_20261029/paired_single_layer.py" "$r/results/attention-pairs-corrected-ab-20261102-v1.runner.py"
timeout --signal=TERM --kill-after=10s 720s python "$s/tests/pypto_test/csa_toolchain_repro_20261019/bootstrap.py" --shared-toolchain --native-plugin-root "$s" "$r/results/attention-pairs-corrected-ab-20261102-v1.runner.py" "$r" "$r/results/attention-pairs-corrected-ab-20261102-v1" --baseline "$r/candidates/qa-wkv-woa192-precision-20261102-v1/source" --candidate "$r/candidates/attention-pair-qa-wkv-woa192-20261102-v1/source" --batch 32 --native-check > "$r/results/attention-pairs-corrected-ab-20261102-v1.log" 2>&1
