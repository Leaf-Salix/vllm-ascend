#!/usr/bin/env bash
set -euo pipefail
r=/data/pyptouser/yejia/vllm-nal-tnd-native-align-20261027-codex
source "$r/src/tests/pypto_test/nal_native_alignment_20261027/env.sh"
export PTO_CSA_RING_TASK_WINDOW=2048
exec timeout --signal=TERM --kill-after=10s 720s bash "$r/src/tests/pypto_test/csa_threeway_20261029/run_eight_card.sh" "$r/cohorts/eightcard-attention-pair-precision-20261102-v3" ours attention-pairs-real8k-20261102-v1 "$r/results/last8-native-8k-waves8-v5" --inspect-token-sequence --measure-waves
