#!/usr/bin/env bash
set -euo pipefail
r=/data/pyptouser/yejia/vllm-nal-tnd-native-align-20261027-codex
source "$r/src/tests/pypto_test/nal_native_alignment_20261027/env.sh"
s="$r/cohorts/eightcard-attention-pair-precision-20261102-v3/ours/source"
export SOURCE_ROOT="$s"
bank=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/low-acceptance-20261010/banks/fixed8192
timeout --signal=TERM --kill-after=10s 720s python "$s/tests/pypto_test/csa_toolchain_repro_20261019/bootstrap.py" --shared-toolchain --native-plugin-root "$s" "$r/src/tests/pypto_test/csa_threeway_20261029/preflight.py" "$s" "$bank" "$r/results/attention-pairs-eightcard-preflight-20261102-v3.json" --check-capacity-guard > "$r/results/attention-pairs-eightcard-preflight-20261102-v3.log" 2>&1
