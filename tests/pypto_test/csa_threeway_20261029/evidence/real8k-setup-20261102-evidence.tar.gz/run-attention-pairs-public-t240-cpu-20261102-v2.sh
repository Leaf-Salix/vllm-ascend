#!/usr/bin/env bash
set -euo pipefail
r=/data/pyptouser/yejia/vllm-nal-tnd-native-align-20261027-codex
source "$r/src/tests/pypto_test/nal_native_alignment_20261027/env.sh"
s="$r/cohorts/eightcard-attention-pair-precision-20261102-v3/ours/source"
export SOURCE_ROOT="$s"
ccache -s
timeout --signal=TERM --kill-after=10s 720s python "$s/tests/pypto_test/csa_toolchain_repro_20261019/bootstrap.py" --shared-toolchain --native-plugin-root "$s" "$r/src/tests/pypto_test/csa_threeway_20261029/precompile.py" "$s" "$r/results/attention-pairs-public-t240-cpu-20261102-v2.json" --tokens 240 --max-seq-len 9000 --table-columns 2048 --task-window 2048 > "$r/results/attention-pairs-public-t240-cpu-20261102-v2.log" 2>&1
