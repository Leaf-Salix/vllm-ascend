#!/usr/bin/env bash
set -euo pipefail
r=/data/pyptouser/yejia/vllm-nal-tnd-native-align-20261027-codex
source "$r/src/tests/pypto_test/nal_native_alignment_20261027/env.sh"
s="$r/cohorts/eightcard-source-v5/native/source"
export PYTHONPATH="$r/src/tests/pypto_test:${PYTHONPATH:-}"
python "$r/src/tests/pypto_test/csa_threeway_20261029/hc_rms_batch_gather_candidate.py" "$r"
ccache -s
timeout --signal=TERM --kill-after=10s 720s python "$s/tests/pypto_test/csa_toolchain_repro_20261019/bootstrap.py" --shared-toolchain --native-plugin-root "$s" "$r/src/tests/pypto_test/csa_threeway_20261029/paired_single_layer.py" "$r" "$r/results/hc-rms-batch-gather-cpu-20261102-v3" --cpu candidate --batch 40 --candidate "$r/candidates/hc-rms-batch-gather-20261102-v3/source" > "$r/results/hc-rms-batch-gather-cpu-20261102-v3.log" 2>&1
