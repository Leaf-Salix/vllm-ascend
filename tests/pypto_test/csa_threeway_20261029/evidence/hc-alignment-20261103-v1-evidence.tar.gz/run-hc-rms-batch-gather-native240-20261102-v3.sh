#!/usr/bin/env bash
set -euo pipefail
case "${TASK_DEVICE:?}" in 8|9|10|11|12|13|15) ;; *) exit 2;; esac
r=/data/pyptouser/yejia/vllm-nal-tnd-native-align-20261027-codex
source "$r/src/tests/pypto_test/nal_native_alignment_20261027/env.sh"
s="$r/cohorts/eightcard-source-v5/native/source"
export SOURCE_ROOT="$s" ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
export PYTHONPATH="$r/src/tests/pypto_test:${PYTHONPATH:-}"
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$s/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$r/results/hc-rms-batch-gather-native240-20261102-v3-opp")
cp "$r/src/tests/pypto_test/csa_threeway_20261029/paired_single_layer.py" "$r/results/hc-rms-batch-gather-native240-20261102-v3.runner.py"
timeout --signal=TERM --kill-after=10s 240s python "$s/tests/pypto_test/csa_toolchain_repro_20261019/bootstrap.py" --shared-toolchain --native-plugin-root "$s" "$r/results/hc-rms-batch-gather-native240-20261102-v3.runner.py" "$r" "$r/results/hc-rms-batch-gather-native240-20261102-v3" --batch 40 --native-check --qualification-reference /data/pyptouser/yejia/vllm-nal-tnd-native-align-20261027-codex/results/hc-rms-batch-gather-padded-20261102-v3/result.json --candidate /data/pyptouser/yejia/vllm-nal-tnd-native-align-20261027-codex/candidates/hc-rms-batch-gather-20261102-v3/source > "$r/results/hc-rms-batch-gather-native240-20261102-v3.log" 2>&1
