import json,os,runpy,sys
from pathlib import Path
import torch_npu,pypto,simpler,vllm_ascend,pytest
from pypto.runtime.kernel.context import get_process_kernel_state
a=Path("/data/pyptouser/yejia/vllm-nal-tnd-native-align-20261027-codex")
assert not torch_npu.npu.is_initialized() and get_process_kernel_state().config is None
sys.path.insert(0,str(a/"src/tests/pypto_test/nal_native_alignment_20261027"))
sys.argv=[str(a/"src/tests/pypto_test/nal_native_alignment_20261027/probe_padding.py"),"--help"]
try:
    runpy.run_path(sys.argv[0],run_name="bucket240_help_check")
except SystemExit as error:
    assert error.code == 0
assert not torch_npu.npu.is_initialized() and get_process_kernel_state().config is None
code=pytest.main(["-q",str(a/"src/tests/pypto_test/csa_threeway_20261029/test_policy_padding.py")])
assert not torch_npu.npu.is_initialized() and get_process_kernel_state().config is None
receipt={"passed":code==0,"npu_initialized":False,"pypto":pypto.__file__,"simpler":simpler.__file__,"vllm_ascend":vllm_ascend.__file__,"PTOAS_ROOT":os.environ["PTOAS_ROOT"],"ASCEND_HOME_PATH":os.environ["ASCEND_HOME_PATH"],"qualification":"Native contract first; dummy Q6 retained, guards never relaxed"}
(a/"results/bucket240-active8-cpu-v2.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt))
raise SystemExit(code)
