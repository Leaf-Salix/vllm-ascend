import ast,importlib,importlib.util,json,os,runpy,sys
from pathlib import Path
import torch_npu
from pypto.runtime.kernel.context import get_process_kernel_state
a=Path("/data/pyptouser/yejia/vllm-nal-tnd-native-align-20261027-codex")
source=Path(os.environ["SOURCE_ROOT"])
assert not torch_npu.npu.is_initialized() and get_process_kernel_state().config is None
sys.path.insert(0,str(a/"src/tests/pypto_test/csa_threeway_20261029"))
spec=importlib.util.spec_from_file_location("token_prepare_actual",a/"src/tests/pypto_test/csa_threeway_20261029/launch.py")
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
runner,receipt=module.prepare_token_runner(source)
ast.parse(runner.read_text())
importlib.import_module("csa_threeway_20261029.token_diagnostic_"+receipt["token_scheduler_sha256"][:12])
runpy.run_path(str(runner),run_name="token_diagnostic_import_check")
assert not torch_npu.npu.is_initialized() and get_process_kernel_state().config is None
receipt.update(passed=True,npu_initialized=False,runner=str(runner))
(a/"results/token-diagnostic-prepare-v1.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt))
