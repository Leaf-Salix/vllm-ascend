import ast
import importlib
import importlib.util
import json
import os
import runpy
import sys
from pathlib import Path
import torch_npu
from pypto.runtime.kernel.context import get_process_kernel_state
root = Path("/data/pyptouser/yejia/vllm-nal-tnd-native-align-20261027-codex")
source = Path(os.environ["SOURCE_ROOT"])
assert not torch_npu.npu.is_initialized() and get_process_kernel_state().config is None
sys.path.insert(0, str(root / "src/tests/pypto_test/csa_threeway_20261029"))
spec = importlib.util.spec_from_file_location("prepare_first_step_actual", root / "src/tests/pypto_test/csa_threeway_20261029/launch.py")
launch = importlib.util.module_from_spec(spec)
spec.loader.exec_module(launch)
runner, receipt = launch.prepare_first_step_runner(source)
ast.parse(runner.read_text())
module = "csa_threeway_20261029.first_step_" + receipt["first_step_observer_sha256"][:12]
observer = importlib.import_module(module)
assert observer.FirstStepObserver.__name__ == "FirstStepObserver"
runpy.run_path(str(runner), run_name="first_step_import_check")
assert not torch_npu.npu.is_initialized() and get_process_kernel_state().config is None
receipt.update(passed=True, npu_initialized=False, runner=str(runner), observer=observer.__file__)
(root / "results/first-step-prepare-v1.json").write_text(json.dumps(receipt, indent=2)+"\n")
print(json.dumps(receipt), flush=True)
