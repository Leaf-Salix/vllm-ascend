import importlib
import json
import os
import sys
from pathlib import Path

import torch_npu

source = Path(sys.argv[1]).resolve()
native = Path(sys.argv[2]).resolve()
assert not torch_npu.npu.is_initialized()
policy = importlib.import_module("vllm_ascend.ops.pypto.deepseek_v4_flash_csa_spmd_tnd.policy")
assert source in Path(policy.__file__).resolve().parents
receipts = {}
for path in native.parent.glob("eightcard-ours-t*-cache-v5.json"):
    value = json.loads(path.read_text())
    assert value["pass"] and value["root_tensors"] == 55
    assert source in Path(value["entry"]).resolve().parents
    assert value["sdk_release"] == os.environ["CSA_SHARED_TOOLCHAIN_RELEASE"]
    receipts[json.dumps(value["bindings"], sort_keys=True)] = str(path)
assert receipts, "v5 cache receipts missing"
groups = {}
dummy_steps = 0
for rank in range(8):
    data = json.loads((native / f"rank{rank}.mixed.json").read_text())
    for row in data["observation"][0]["policy_descriptors"]:
        if row.get("is_dummy_batch", False):
            dummy_steps += row["steps"]
            continue
        if row["actual_tokens"] <= 0:
            continue
        args = {key: row[key] for key in ("tokens", "requests", "max_seq_len", "compressed_table_columns")}
        bindings = policy.select_policy(max_query_tokens=6, **args).constexprs()
        key = json.dumps(bindings, sort_keys=True)
        group = groups.setdefault(key, {"representative": args, "bindings": bindings, "cache_receipt": receipts.get(key), "steps": 0, "modes": set()})
        group["steps"] += row["steps"]
        group["modes"].add(row["requested_mode"])
for group in groups.values():
    group["modes"] = sorted(group["modes"])
missing = [value for value in groups.values() if value["cache_receipt"] is None]
result = {"source": str(source), "native": str(native), "receipt_files": len(list(native.parent.glob("eightcard-ours-t*-cache-v5.json"))), "unique_policies": list(groups.values()), "missing": missing, "excluded_dummy_steps": dummy_steps, "npu_initialized": False}
assert not torch_npu.npu.is_initialized()
out = native.parent / "last8-policy-cache-plan-v5.json"
out.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"output": str(out), "policies": [{"representative": v["representative"], "cache_receipt": v["cache_receipt"], "steps": v["steps"], "modes": v["modes"]} for v in groups.values()], "missing_count": len(missing), "excluded_dummy_steps": dummy_steps}))

