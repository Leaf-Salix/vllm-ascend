#!/usr/bin/env bash
set -euo pipefail
r=/data/pyptouser/yejia/vllm-nal-tnd-native-align-20261027-codex
source "$r/src/tests/pypto_test/nal_native_alignment_20261027/env.sh"
s="$r/cohorts/eightcard-source-v5/native/source"
export SOURCE_ROOT="$s"
export CMAKE_BUILD_PARALLEL_LEVEL=4
ccache -s
timeout --signal=TERM --kill-after=10s 720s python "$s/tests/pypto_test/csa_toolchain_repro_20261019/bootstrap.py" --shared-toolchain --native-plugin-root "$s" "$r/src/tests/pypto_test/nal_native_alignment_20261027/precompile_eager.py" "$r/results/t192-spmd-debug-cpu-20261102-v1.json" spmd-debug --lengths 6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6 > "$r/results/t192-spmd-debug-cpu-20261102-v1.log" 2>&1
