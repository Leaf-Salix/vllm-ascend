#!/usr/bin/env bash
set -euo pipefail
case "${TASK_DEVICE:?}" in 8|9|10|11|12|13|15) ;; *) exit 2;; esac
r=/data/pyptouser/yejia/vllm-nal-tnd-native-align-20261027-codex
source "$r/src/tests/pypto_test/nal_native_alignment_20261027/env.sh"
s="$r/cohorts/eightcard-source-v5/native/source"
export SOURCE_ROOT="$s" ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
export PYTHONPATH="$r/src/tests/pypto_test:${PYTHONPATH:-}"
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$s/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$r/results/qa192fix-stages-full-20261102-v1-opp")
export SPMD_PRODUCTION_REFERENCE="$r/results/qa192fix-production-full-20261102-v1/production.pt"
mkdir "$r/results/qa192fix-stages-full-20261102-v1"
cp "$r/candidates/qa192-precision-20261102-v1/source/tests/pypto_test/nal_native_alignment_20261027/probe_spmd.py" "$r/results/qa192fix-stages-full-20261102-v1/actual-runner.py"
timeout --signal=TERM --kill-after=10s 720s python "$s/tests/pypto_test/csa_toolchain_repro_20261019/bootstrap.py" --shared-toolchain --native-plugin-root "$s" "$r/candidates/qa192-precision-20261102-v1/source/tests/pypto_test/nal_native_alignment_20261027/probe_spmd.py" "$r/results/qa192fix-stages-full-20261102-v1" --lengths 6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6 > "$r/results/qa192fix-stages-full-20261102-v1.log" 2>&1
