#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void packed_prefix_indexer_cube(__gm__ float* v1, __gm__ float* v2, __gm__ bfloat16_t* v3, __gm__ bfloat16_t* v4, __gm__ float* v5, __gm__ bfloat16_t* v6, __gm__ bfloat16_t* v7, __gm__ int32_t* v8, __gm__ float* v9, __gm__ int64_t* v10, __gm__ bfloat16_t* v11, __gm__ int32_t* v12, __gm__ float* v13, __gm__ bfloat16_t* v14, __gm__ float* v15, __gm__ float* v16, __gm__ float* v17, __gm__ float* v18, __gm__ float* v19, __gm__ float* v20, __gm__ float* v21, __gm__ float* v22, __gm__ bfloat16_t* v23, __gm__ bfloat16_t* v24, __gm__ bfloat16_t* v25, __gm__ float* v26, __gm__ bfloat16_t* v27, __gm__ float* v28, __gm__ bfloat16_t* v29, __gm__ bfloat16_t* v30, __gm__ half* v31, int64_t v32, int64_t v33, int64_t v34, int64_t v35, int64_t v36, int32_t v37, int32_t v38) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v39 = 0;
  // pto: %c32768_i64
  const int64_t v40 = 32768;
  // pto: %c2048_i64
  const int64_t v41 = 2048;
  // pto: %c16384_index
  const int64_t v42 = 16384;
  // pto: %c1_index
  const int64_t v43 = 1;
  // pto: %c16_index
  const int64_t v44 = 16;
  // pto: %c32768_index
  const int64_t v45 = 32768;
  const int64_t v46 = 32;
  // pto: %c4096_index
  const int64_t v47 = 4096;
  // pto: %c512_index
  const int64_t v48 = 512;
  const int64_t v49 = 64;
  // pto: %c4_index
  const int64_t v50 = 4;
  // pto: %c24_index
  const int64_t v51 = 24;
  // pto: %c22_index
  const int64_t v52 = 22;
  // pto: %c21_index
  const int64_t v53 = 21;
  // pto: %c0_index
  const int64_t v54 = 0;
  // pto: %c768_index
  const int64_t v55 = 768;
  // pto: %c2_index
  const int64_t v56 = 2;
  // pto: %cn1_index
  const int64_t v57 = -1;
  // pto: %c63_index
  const int64_t v58 = 63;
  // pto: %c1536_index
  const int64_t v59 = 1536;
  // pto: %c128_index
  const int64_t v60 = 128;
  // pto: %c15_index
  const int64_t v61 = 15;
  // pto: %c256_index
  const int64_t v62 = 256;
  // pto: %wide__ssa_v0_view
  const int64_t v63 = 1;
  // pto: %wide__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %wide__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %wide__ssa_v0_view
  int64_t v66 = (int64_t) v32;
  // pto: %wide__ssa_v0_view
  int64_t v67 = v66 * v42;
  // pto: %wide__ssa_v0_view
  int64_t v68 = v65 * v67;
  // pto: %wide__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v69 = pto::Shape<1, 1, 1, -1, -1>(v63, v64, v65, v66, v42);
  // pto: %wide__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v70 = pto::Stride<-1, -1, -1, -1, -1>(v64 * v68, v68, v67, v42, v43);
  // pto: %wide__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v71 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v69, v70);
  // pto: %spmd_square__ssa_v0_view
  const int64_t v72 = 1;
  // pto: %spmd_square__ssa_v0_view
  const int64_t v73 = 1;
  // pto: %spmd_square__ssa_v0_view
  const int64_t v74 = 1;
  // pto: %spmd_square__ssa_v0_view
  int64_t v75 = (int64_t) v33;
  // pto: %spmd_square__ssa_v0_view
  int64_t v76 = v75 * v44;
  // pto: %spmd_square__ssa_v0_view
  int64_t v77 = v74 * v76;
  // pto: %spmd_square__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v78 = pto::Shape<1, 1, 1, -1, -1>(v72, v73, v74, v75, v44);
  // pto: %spmd_square__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v79 = pto::Stride<-1, -1, -1, -1, -1>(v73 * v77, v77, v76, v44, v43);
  // pto: %spmd_square__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v80 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v78, v79);
  // pto: %hc_packed_weight__ssa_v0_view
  const int64_t v81 = 1;
  // pto: %hc_packed_weight__ssa_v0_view
  const int64_t v82 = 1;
  // pto: %hc_packed_weight__ssa_v0_view
  const int64_t v83 = 1;
  // pto: %hc_packed_weight__ssa_v0_view
  int64_t v84 = v45 * v46;
  // pto: %hc_packed_weight__ssa_v0_view
  int64_t v85 = v83 * v84;
  // pto: %hc_packed_weight__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v86 = pto::Shape<1, 1, 1, -1, -1>(v81, v82, v83, v45, v46);
  // pto: %hc_packed_weight__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v87 = pto::Stride<-1, -1, -1, -1, -1>(v82 * v85, v85, v84, v46, v43);
  // pto: %hc_packed_weight__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v88 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v86, v87);
  // pto: %packed_flat__ssa_v0_view
  const int64_t v89 = 1;
  // pto: %packed_flat__ssa_v0_view
  const int64_t v90 = 1;
  // pto: %packed_flat__ssa_v0_view
  const int64_t v91 = 1;
  // pto: %packed_flat__ssa_v0_view
  int64_t v92 = (int64_t) v34;
  // pto: %packed_flat__ssa_v0_view
  int64_t v93 = v92 * v45;
  // pto: %packed_flat__ssa_v0_view
  int64_t v94 = v91 * v93;
  // pto: %packed_flat__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v95 = pto::Shape<1, 1, 1, -1, -1>(v89, v90, v91, v92, v45);
  // pto: %packed_flat__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v96 = pto::Stride<-1, -1, -1, -1, -1>(v90 * v94, v94, v93, v45, v43);
  // pto: %packed_flat__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v97 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v95, v96);
  // pto: %spmd_linear__ssa_v0_view
  const int64_t v98 = 1;
  // pto: %spmd_linear__ssa_v0_view
  const int64_t v99 = 1;
  // pto: %spmd_linear__ssa_v0_view
  const int64_t v100 = 1;
  // pto: %spmd_linear__ssa_v0_view
  int64_t v101 = (int64_t) v33;
  // pto: %spmd_linear__ssa_v0_view
  int64_t v102 = v101 * v46;
  // pto: %spmd_linear__ssa_v0_view
  int64_t v103 = v100 * v102;
  // pto: %spmd_linear__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v104 = pto::Shape<1, 1, 1, -1, -1>(v98, v99, v100, v101, v46);
  // pto: %spmd_linear__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v105 = pto::Stride<-1, -1, -1, -1, -1>(v99 * v103, v103, v102, v46, v43);
  // pto: %spmd_linear__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v106 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v104, v105);
  // pto: %normed__ssa_v0_view
  const int64_t v107 = 1;
  // pto: %normed__ssa_v0_view
  const int64_t v108 = 1;
  // pto: %normed__ssa_v0_view
  const int64_t v109 = 1;
  // pto: %normed__ssa_v0_view
  int64_t v110 = (int64_t) v32;
  // pto: %normed__ssa_v0_view
  int64_t v111 = v110 * v47;
  // pto: %normed__ssa_v0_view
  int64_t v112 = v109 * v111;
  // pto: %normed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v113 = pto::Shape<1, 1, 1, -1, -1>(v107, v108, v109, v110, v47);
  // pto: %normed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v114 = pto::Stride<-1, -1, -1, -1, -1>(v108 * v112, v112, v111, v47, v43);
  // pto: %normed__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v115 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v113, v114);
  // pto: %wkv__ssa_v0_view
  const int64_t v116 = 1;
  // pto: %wkv__ssa_v0_view
  const int64_t v117 = 1;
  // pto: %wkv__ssa_v0_view
  const int64_t v118 = 1;
  // pto: %wkv__ssa_v0_view
  int64_t v119 = v48 * v47;
  // pto: %wkv__ssa_v0_view
  int64_t v120 = v118 * v119;
  // pto: %wkv__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v121 = pto::Shape<1, 1, 1, -1, -1>(v116, v117, v118, v48, v47);
  // pto: %wkv__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v122 = pto::Stride<-1, -1, -1, -1, -1>(v117 * v120, v120, v119, v47, v43);
  // pto: %wkv__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v123 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v121, v122);
  // pto: %spmd_accum__ssa_v0_view
  const int64_t v124 = 1;
  // pto: %spmd_accum__ssa_v0_view
  const int64_t v125 = 1;
  // pto: %spmd_accum__ssa_v0_view
  const int64_t v126 = 1;
  // pto: %spmd_accum__ssa_v0_view
  int64_t v127 = (int64_t) v35;
  // pto: %spmd_accum__ssa_v0_view
  int64_t v128 = v127 * v48;
  // pto: %spmd_accum__ssa_v0_view
  int64_t v129 = v126 * v128;
  // pto: %spmd_accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v130 = pto::Shape<1, 1, 1, -1, -1>(v124, v125, v126, v127, v48);
  // pto: %spmd_accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v131 = pto::Stride<-1, -1, -1, -1, -1>(v125 * v129, v129, v128, v48, v43);
  // pto: %spmd_accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v132 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v130, v131);
  // pto: %weights_proj__ssa_v0_view
  const int64_t v133 = 1;
  // pto: %weights_proj__ssa_v0_view
  const int64_t v134 = 1;
  // pto: %weights_proj__ssa_v0_view
  const int64_t v135 = 1;
  // pto: %weights_proj__ssa_v0_view
  int64_t v136 = v49 * v47;
  // pto: %weights_proj__ssa_v0_view
  int64_t v137 = v135 * v136;
  // pto: %weights_proj__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v138 = pto::Shape<1, 1, 1, -1, -1>(v133, v134, v135, v49, v47);
  // pto: %weights_proj__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v139 = pto::Stride<-1, -1, -1, -1, -1>(v134 * v137, v137, v136, v47, v43);
  // pto: %weights_proj__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v140 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v11, v138, v139);
  // pto: %spmd_idx_accum__ssa_v0_view
  const int64_t v141 = 1;
  // pto: %spmd_idx_accum__ssa_v0_view
  const int64_t v142 = 1;
  // pto: %spmd_idx_accum__ssa_v0_view
  const int64_t v143 = 1;
  // pto: %spmd_idx_accum__ssa_v0_view
  int64_t v144 = (int64_t) v34;
  // pto: %spmd_idx_accum__ssa_v0_view
  int64_t v145 = v144 * v49;
  // pto: %spmd_idx_accum__ssa_v0_view
  int64_t v146 = v143 * v145;
  // pto: %spmd_idx_accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v147 = pto::Shape<1, 1, 1, -1, -1>(v141, v142, v143, v144, v49);
  // pto: %spmd_idx_accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v148 = pto::Stride<-1, -1, -1, -1, -1>(v142 * v146, v146, v145, v49, v43);
  // pto: %spmd_idx_accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v149 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v147, v148);
  // pto: %native_sq_acc_inline10309__rv_v2
  Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v150 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v44);
  // pto: %native_sq_acc_inline10309__rv_v2
  uint64_t v151 = (uint64_t) v39;
  TASSIGN(v150, v151);
  uint64_t v152 = reinterpret_cast<uint64_t>(v10);
  set_ffts_base_addr(v152);
  // pto: %worker__ssa_v0
  int64_t v153 = (int64_t) v37;
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %17
  int64_t v154 = v33 / v52;
  // pto: %18
  bool v155 = v32 >= v49;
  // pto: %sq_group_inline10297__phi_v2
  int64_t v156 = v155 ? v50 : v43;
  // pto: %19, %20
  int64_t v157 = (int64_t) ((uint64_t) v156 + (uint64_t) v53) / v156;
  // pto: %21, %22
  for (int64_t v158 = v153; v158 < ((int64_t) ((uint64_t) (v154 / v44) * (uint64_t) v157)); v158 += v51) {
    // pto: %23, %24
    ;
    int64_t v159 = (int64_t) ((uint64_t) (v158 / v157) * (uint64_t) v44);
    // pto: %25, %26
    ;
    int64_t v160 = (int64_t) ((uint64_t) (v158 % v157) * (uint64_t) v156);
    // pto: %27
    ;
    int64_t v161 = (int64_t) ((uint64_t) v32 - (uint64_t) v159);
    // pto: %28
    ;
    int64_t v162 = v161 < v44 ? v161 : v44;
    // pto: %29
    ;
    int64_t v163 = (int64_t) ((uint64_t) v52 - (uint64_t) v160);
    // pto: %30
    ;
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    for (int64_t v164 = v54; v164 < (v156 < v163 ? v156 : v163); v164 += v43) {
      // pto: %31
      ;
      int64_t v165 = (int64_t) ((uint64_t) v160 + (uint64_t) v164);
      // pto: %32
      ;
      int64_t v166 = (int64_t) ((uint64_t) v165 * (uint64_t) v55);
      // pto: %33
      ;
      int64_t v167 = (int64_t) ((uint64_t) v42 - (uint64_t) v166);
      // pto: %34
      ;
      int64_t v168 = v167 < v55 ? v167 : v55;
      // pto: %35
      ;
      int64_t v169 = v168 / v46;
      // pto: %native_sq_acc_inline10309__tile
      ;
      Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v170 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v44);
      // pto: %native_sq_acc_inline10309__tile
      ;
      uint64_t v171 = (uint64_t) v39;
      TASSIGN(v170, v171);
      // pto: %36
      ;
      int64_t v172 = v169 / v56;
      // pto: %37
      ;
      int64_t v173 = (int64_t) ((uint64_t) v172 * (uint64_t) v56);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      for (int64_t v174 = v54; v174 < v173; v174 += v56) {
        // pto: %39
        ;
        int64_t v175 = (int64_t) ((uint64_t) v174 * (uint64_t) v46);
        // pto: %40
        ;
        int64_t v176 = (int64_t) ((uint64_t) v166 + (uint64_t) v175);
        // pto: %44, %43
        ;
        int64_t v177 = (int64_t) ((uint64_t) v166 + (uint64_t) ((int64_t) (uint64_t) v175 + (uint64_t) v46));
        // pto: %sq_lhs_inline10304__tile
        ;
        Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v178 = Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v162, v46);
        // pto: %sq_lhs_inline10304__tile
        ;
        uint64_t v179 = (uint64_t) v39;
        TASSIGN(v178, v179);
        // pto: %45
        ;
        int64_t v180 = v159 < v54 ? v54 : v159;
        // pto: %46
        ;
        int64_t v181 = v176 < v54 ? v54 : v176;
        // pto: %wide__ssa_v0_pview
        ;
        const int64_t v182 = 0;
        // pto: %wide__ssa_v0_pview
        ;
        __gm__ float* v183 = PTOAS__GLOBAL_TENSOR_DATA(v71);
        // pto: %wide__ssa_v0_pview
        ;
        const int64_t v184 = 1;
        // pto: %wide__ssa_v0_pview
        ;
        const int64_t v185 = 1;
        // pto: %wide__ssa_v0_pview
        ;
        const int64_t v186 = 1;
        // pto: %wide__ssa_v0_pview
        ;
        int64_t v187 = v162 * v42;
        // pto: %wide__ssa_v0_pview
        ;
        int64_t v188 = v186 * v187;
        // pto: %wide__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 32> v189 = pto::Shape<1, 1, 1, -1, 32>(v184, v185, v186, v162, v46);
        // pto: %wide__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v190 = pto::Stride<-1, -1, -1, -1, -1>(v185 * v188, v188, v187, v42, v43);
        // pto: %wide__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v191 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v183 + (v182 + v180 * v42 + v181 * v43), v189, v190);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v178, v191);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %0
        ;
        Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v192 = Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v162, v46);
        // pto: %0
        ;
        uint64_t v193 = (uint64_t) v40;
        TASSIGN(v192, v193);
        // pto: %48
        ;
        int64_t v194 = v177 < v54 ? v54 : v177;
        // pto: %49
        ;
        const int64_t v195 = 0;
        // pto: %49
        ;
        __gm__ float* v196 = PTOAS__GLOBAL_TENSOR_DATA(v71);
        // pto: %49
        ;
        const int64_t v197 = 1;
        // pto: %49
        ;
        const int64_t v198 = 1;
        // pto: %49
        ;
        const int64_t v199 = 1;
        // pto: %49
        ;
        int64_t v200 = v162 * v42;
        // pto: %49
        ;
        int64_t v201 = v199 * v200;
        // pto: %49
        ;
        pto::Shape<1, 1, 1, -1, 32> v202 = pto::Shape<1, 1, 1, -1, 32>(v197, v198, v199, v162, v46);
        // pto: %49
        ;
        pto::Stride<-1, -1, -1, -1, -1> v203 = pto::Stride<-1, -1, -1, -1, -1>(v198 * v201, v201, v200, v42, v43);
        // pto: %49
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v204 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v196 + (v195 + v180 * v42 + v194 * v43), v202, v203);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        TLOAD(v192, v204);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %sq_lhs_inline10304__tile_t
        ;
        Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v205 = Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v162);
        // pto: %sq_lhs_inline10304__tile_t
        ;
        uint64_t v206 = (uint64_t) v39;
        TASSIGN(v205, v206);
        // pto: %sq_lhs_inline10304__tile_Left
        ;
        Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v162, v46);
        // pto: %sq_lhs_inline10304__tile_Left
        ;
        uint64_t v208 = (uint64_t) v41;
        TASSIGN(v207, v208);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        TMOV(v207, v178);
        // pto: %sq_lhs_inline10304__tile_t_Right
        ;
        Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v209 = Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v162);
        // pto: %sq_lhs_inline10304__tile_t_Right
        ;
        uint64_t v210 = (uint64_t) v41;
        TASSIGN(v209, v210);
        TMOV(v209, v205);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %50
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        if (v174 == v54) {
          pipe_barrier(PIPE_M);
          TMATMUL(v170, v207, v209);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v170, v170, v207, v209);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        // pto: %2
        ;
        Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v162);
        // pto: %2
        ;
        uint64_t v212 = (uint64_t) v40;
        TASSIGN(v211, v212);
        // pto: %3
        ;
        Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v213 = Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v162, v46);
        // pto: %3
        ;
        uint64_t v214 = (uint64_t) v39;
        TASSIGN(v213, v214);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        TMOV(v213, v192);
        // pto: %4
        ;
        Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v162);
        // pto: %4
        ;
        uint64_t v216 = (uint64_t) v39;
        TASSIGN(v215, v216);
        TMOV(v215, v211);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %51
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        if (v174 == v57) {
          pipe_barrier(PIPE_M);
          TMATMUL(v170, v213, v215);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v170, v170, v213, v215);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      // pto: %52, %53
      ;
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      if ((int64_t) ((uint64_t) v169 - (uint64_t) v173) == v43) {
        // pto: %56
        ;
        int64_t v217 = (int64_t) ((uint64_t) v166 + (uint64_t) ((int64_t) (uint64_t) v172 * (uint64_t) v49));
        // pto: %6
        ;
        Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v162, v46);
        // pto: %6
        ;
        uint64_t v219 = (uint64_t) v39;
        TASSIGN(v218, v219);
        // pto: %57
        ;
        int64_t v220 = v159 < v54 ? v54 : v159;
        // pto: %58
        ;
        int64_t v221 = v217 < v54 ? v54 : v217;
        // pto: %59
        ;
        const int64_t v222 = 0;
        // pto: %59
        ;
        __gm__ float* v223 = PTOAS__GLOBAL_TENSOR_DATA(v71);
        // pto: %59
        ;
        const int64_t v224 = 1;
        // pto: %59
        ;
        const int64_t v225 = 1;
        // pto: %59
        ;
        const int64_t v226 = 1;
        // pto: %59
        ;
        int64_t v227 = v162 * v42;
        // pto: %59
        ;
        int64_t v228 = v226 * v227;
        // pto: %59
        ;
        pto::Shape<1, 1, 1, -1, 32> v229 = pto::Shape<1, 1, 1, -1, 32>(v224, v225, v226, v162, v46);
        // pto: %59
        ;
        pto::Stride<-1, -1, -1, -1, -1> v230 = pto::Stride<-1, -1, -1, -1, -1>(v225 * v228, v228, v227, v42, v43);
        // pto: %59
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v231 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v223 + (v222 + v220 * v42 + v221 * v43), v229, v230);
        TLOAD(v218, v231);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        // pto: %7
        ;
        Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v232 = Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v162);
        // pto: %7
        ;
        uint64_t v233 = (uint64_t) v39;
        TASSIGN(v232, v233);
        // pto: %8
        ;
        Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v234 = Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v162, v46);
        // pto: %8
        ;
        uint64_t v235 = (uint64_t) v41;
        TASSIGN(v234, v235);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        TMOV(v234, v218);
        // pto: %9
        ;
        Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v236 = Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v162);
        // pto: %9
        ;
        uint64_t v237 = (uint64_t) v41;
        TASSIGN(v236, v237);
        TMOV(v236, v232);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %60
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        if (v173 == v54) {
          pipe_barrier(PIPE_M);
          TMATMUL(v170, v234, v236);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v170, v170, v234, v236);
        };
      };
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %61, %62
      ;
      int64_t v238 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v165 * (uint64_t) v154) + (uint64_t) v159);
      // pto: %63
      ;
      int64_t v239 = v238 < v54 ? v54 : v238;
      // pto: %square__iter_v3_pview
      ;
      __gm__ float* v240 = PTOAS__GLOBAL_TENSOR_DATA(v80);
      // pto: %square__iter_v3_pview
      ;
      const int64_t v241 = 0;
      // pto: %square__iter_v3_pview
      ;
      const int64_t v242 = 16;
      // pto: %square__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, 16, 16> v243 = pto::Shape<1, 1, 1, 16, 16>();
      // pto: %square__iter_v3_pview
      ;
      pto::Stride<256, 256, 256, 16, 1> v244 = pto::Stride<256, 256, 256, 16, 1>();
      // pto: %square__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<256, 256, 256, 16, 1>, pto::Layout::ND> v245 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<256, 256, 256, 16, 1>, pto::Layout::ND>(v240 + (v241 + v239 * v242), v243, v244);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      pipe_barrier(PIPE_FIX);
      TSTORE(v245, v150);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    };
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  if (v155) {
    // pto: %65, %66
    ;
    int64_t v246 = (int64_t) ((uint64_t) v34 + (uint64_t) v58) / v49;
    // pto: %67
    ;
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    for (int64_t v247 = v153; v247 < ((int64_t) ((uint64_t) v246 * (uint64_t) v52)); v247 += v51) {
      // pto: %70
      ;
      int64_t v248 = v247 / v246;
      // pto: %73, %74
      ;
      int64_t v249 = (int64_t) ((uint64_t) (v247 % v246) * (uint64_t) v49);
      // pto: %75
      ;
      int64_t v250 = (int64_t) ((uint64_t) v34 - (uint64_t) v249);
      // pto: %76
      ;
      int64_t v251 = v250 < v49 ? v250 : v49;
      // pto: %78, %77
      ;
      int64_t v252 = (int64_t) ((uint64_t) v42 - (uint64_t) ((int64_t) (uint64_t) v248 * (uint64_t) v55));
      // pto: %79
      ;
      int64_t v253 = v252 < v55 ? v252 : v55;
      // pto: %80
      ;
      // pto: %81
      ;
      int64_t v254 = (int64_t) ((uint64_t) v248 * (uint64_t) v59);
      // pto: %panel64_wide_first_x_inline10322__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v255 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v251, v60);
      // pto: %panel64_wide_first_x_inline10322__tile
      ;
      uint64_t v256 = (uint64_t) v39;
      TASSIGN(v255, v256);
      // pto: %82
      ;
      int64_t v257 = v249 < v54 ? v54 : v249;
      // pto: %83
      ;
      int64_t v258 = v254 < v54 ? v54 : v254;
      // pto: %packed_flat__ssa_v0_pview
      ;
      const int64_t v259 = 0;
      // pto: %packed_flat__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v260 = PTOAS__GLOBAL_TENSOR_DATA(v97);
      // pto: %packed_flat__ssa_v0_pview
      ;
      const int64_t v261 = 1;
      // pto: %packed_flat__ssa_v0_pview
      ;
      const int64_t v262 = 1;
      // pto: %packed_flat__ssa_v0_pview
      ;
      const int64_t v263 = 1;
      // pto: %packed_flat__ssa_v0_pview
      ;
      int64_t v264 = v251 * v45;
      // pto: %packed_flat__ssa_v0_pview
      ;
      int64_t v265 = v263 * v264;
      // pto: %packed_flat__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 128> v266 = pto::Shape<1, 1, 1, -1, 128>(v261, v262, v263, v251, v60);
      // pto: %packed_flat__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v267 = pto::Stride<-1, -1, -1, -1, -1>(v262 * v265, v265, v264, v45, v43);
      // pto: %packed_flat__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v268 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v260 + (v259 + v257 * v45 + v258 * v43), v266, v267);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      TLOAD(v255, v268);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %panel64_wide_first_w_inline10333__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v269 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
      // pto: %panel64_wide_first_w_inline10333__tile
      ;
      uint64_t v270 = (uint64_t) v40;
      TASSIGN(v269, v270);
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v271 = PTOAS__GLOBAL_TENSOR_DATA(v88);
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      const int64_t v272 = 0;
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      const int64_t v273 = 32;
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 128, 32> v274 = pto::Shape<1, 1, 1, 128, 32>();
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      pto::Stride<4096, 4096, 4096, 32, 1> v275 = pto::Stride<4096, 4096, 4096, 32, 1>();
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND> v276 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND>(v271 + (v272 + v258 * v273), v274, v275);
      TLOAD(v269, v276);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      // pto: %panel64_wide_first_x_inline10322__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v277 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v251, v60);
      // pto: %panel64_wide_first_x_inline10322__tile_Left
      ;
      uint64_t v278 = (uint64_t) v41;
      TASSIGN(v277, v278);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      TMOV(v277, v255);
      // pto: %panel64_wide_first_w_inline10333__tile_Right
      ;
      Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v279 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
      // pto: %panel64_wide_first_w_inline10333__tile_Right
      ;
      uint64_t v280 = (uint64_t) v41;
      TASSIGN(v279, v280);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      TMOV(v279, v269);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      // pto: %panel64_wide_accumulator_inline10332__tile
      ;
      Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v281 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v251, v46);
      // pto: %panel64_wide_accumulator_inline10332__tile
      ;
      uint64_t v282 = (uint64_t) v39;
      TASSIGN(v281, v282);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
      TMATMUL(v281, v277, v279);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      for (int64_t v283 = v43; v283 < (v253 / v49); v283 += v43) {
        // pto: %87, %86
        ;
        int64_t v284 = (int64_t) ((uint64_t) v254 + (uint64_t) ((int64_t) (uint64_t) v283 * (uint64_t) v60));
        // pto: %panel64_wide_x_inline10317__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v285 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v251, v60);
        // pto: %panel64_wide_x_inline10317__tile
        ;
        uint64_t v286 = (uint64_t) v39;
        TASSIGN(v285, v286);
        // pto: %89
        ;
        int64_t v287 = v284 < v54 ? v54 : v284;
        // pto: %90
        ;
        const int64_t v288 = 0;
        // pto: %90
        ;
        __gm__ bfloat16_t* v289 = PTOAS__GLOBAL_TENSOR_DATA(v97);
        // pto: %90
        ;
        const int64_t v290 = 1;
        // pto: %90
        ;
        const int64_t v291 = 1;
        // pto: %90
        ;
        const int64_t v292 = 1;
        // pto: %90
        ;
        int64_t v293 = v251 * v45;
        // pto: %90
        ;
        int64_t v294 = v292 * v293;
        // pto: %90
        ;
        pto::Shape<1, 1, 1, -1, 128> v295 = pto::Shape<1, 1, 1, -1, 128>(v290, v291, v292, v251, v60);
        // pto: %90
        ;
        pto::Stride<-1, -1, -1, -1, -1> v296 = pto::Stride<-1, -1, -1, -1, -1>(v291 * v294, v294, v293, v45, v43);
        // pto: %90
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v297 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v289 + (v288 + v257 * v45 + v287 * v43), v295, v296);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
        TLOAD(v285, v297);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        // pto: %panel64_wide_w_inline10321__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
        // pto: %panel64_wide_w_inline10321__tile
        ;
        uint64_t v299 = (uint64_t) v40;
        TASSIGN(v298, v299);
        // pto: %92
        ;
        __gm__ bfloat16_t* v300 = PTOAS__GLOBAL_TENSOR_DATA(v88);
        // pto: %92
        ;
        const int64_t v301 = 0;
        // pto: %92
        ;
        const int64_t v302 = 32;
        // pto: %92
        ;
        pto::Shape<1, 1, 1, 128, 32> v303 = pto::Shape<1, 1, 1, 128, 32>();
        // pto: %92
        ;
        pto::Stride<4096, 4096, 4096, 32, 1> v304 = pto::Stride<4096, 4096, 4096, 32, 1>();
        // pto: %92
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND> v305 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND>(v300 + (v301 + v287 * v302), v303, v304);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        TLOAD(v298, v305);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
        // pto: %panel64_wide_x_inline10317__tile_Left
        ;
        Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v306 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v251, v60);
        // pto: %panel64_wide_x_inline10317__tile_Left
        ;
        uint64_t v307 = (uint64_t) v41;
        TASSIGN(v306, v307);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        TMOV(v306, v285);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
        // pto: %panel64_wide_w_inline10321__tile_Right
        ;
        Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v308 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
        // pto: %panel64_wide_w_inline10321__tile_Right
        ;
        uint64_t v309 = (uint64_t) v41;
        TASSIGN(v308, v309);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
        TMOV(v308, v298);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        TMATMUL_ACC(v281, v281, v306, v308);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      };
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      v281.SetValidShape(v251, v46);
      // pto: %93, %94
      ;
      int64_t v310 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v248 * (uint64_t) v34) + (uint64_t) v249);
      // pto: %95
      ;
      int64_t v311 = v310 < v54 ? v54 : v310;
      // pto: %linear__iter_v1_pview
      ;
      const int64_t v312 = 0;
      // pto: %linear__iter_v1_pview
      ;
      __gm__ float* v313 = PTOAS__GLOBAL_TENSOR_DATA(v106);
      // pto: %linear__iter_v1_pview
      ;
      const int64_t v314 = 1;
      // pto: %linear__iter_v1_pview
      ;
      const int64_t v315 = 1;
      // pto: %linear__iter_v1_pview
      ;
      const int64_t v316 = 1;
      // pto: %linear__iter_v1_pview
      ;
      int64_t v317 = v251 * v46;
      // pto: %linear__iter_v1_pview
      ;
      int64_t v318 = v316 * v317;
      // pto: %linear__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, -1, 32> v319 = pto::Shape<1, 1, 1, -1, 32>(v314, v315, v316, v251, v46);
      // pto: %linear__iter_v1_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v320 = pto::Stride<-1, -1, -1, -1, -1>(v315 * v318, v318, v317, v46, v43);
      // pto: %linear__iter_v1_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v321 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v313 + (v312 + v311 * v46 + v54 * v43), v319, v320);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      TSTORE(v321, v281);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
    };
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  } else {
    // pto: %96
    ;
    int64_t v322 = v34 / v44;
    // pto: %97
    ;
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
    for (int64_t v323 = v153; v323 < ((int64_t) ((uint64_t) v322 * (uint64_t) v52)); v323 += v51) {
      // pto: %99
      ;
      int64_t v324 = v323 / v322;
      // pto: %101, %102
      ;
      int64_t v325 = (int64_t) ((uint64_t) (v323 % v322) * (uint64_t) v44);
      // pto: %104, %103
      ;
      int64_t v326 = (int64_t) ((uint64_t) v42 - (uint64_t) ((int64_t) (uint64_t) v324 * (uint64_t) v55));
      // pto: %105
      ;
      int64_t v327 = v326 < v55 ? v326 : v55;
      // pto: %106
      ;
      // pto: %panel64_accumulator_inline10310__tile
      ;
      Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v328 = Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v46);
      // pto: %panel64_accumulator_inline10310__tile
      ;
      uint64_t v329 = (uint64_t) v39;
      TASSIGN(v328, v329);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v330 = v54; v330 < (v327 / v49); v330 += v43) {
        // pto: %107, %109, %108
        ;
        int64_t v331 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v324 * (uint64_t) v59) + (uint64_t) ((int64_t) (uint64_t) v330 * (uint64_t) v60));
        // pto: %panel64_x16_inline10312__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v332 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v60);
        // pto: %panel64_x16_inline10312__tile
        ;
        uint64_t v333 = (uint64_t) v40;
        TASSIGN(v332, v333);
        // pto: %110
        ;
        int64_t v334 = v325 < v54 ? v54 : v325;
        // pto: %111
        ;
        int64_t v335 = v331 < v54 ? v54 : v331;
        // pto: %112
        ;
        __gm__ bfloat16_t* v336 = PTOAS__GLOBAL_TENSOR_DATA(v97);
        // pto: %112
        ;
        const int64_t v337 = 0;
        // pto: %112
        ;
        const int64_t v338 = 32768;
        // pto: %112
        ;
        pto::Shape<1, 1, 1, 16, 128> v339 = pto::Shape<1, 1, 1, 16, 128>();
        // pto: %112
        ;
        pto::Stride<524288, 524288, 524288, 32768, 1> v340 = pto::Stride<524288, 524288, 524288, 32768, 1>();
        // pto: %112
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND> v341 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND>(v336 + (v337 + v334 * v338 + v335), v339, v340);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        TLOAD(v332, v341);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
        // pto: %panel64_w16_inline10314__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v342 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
        // pto: %panel64_w16_inline10314__tile
        ;
        uint64_t v343 = (uint64_t) v39;
        TASSIGN(v342, v343);
        // pto: %114
        ;
        __gm__ bfloat16_t* v344 = PTOAS__GLOBAL_TENSOR_DATA(v88);
        // pto: %114
        ;
        const int64_t v345 = 0;
        // pto: %114
        ;
        const int64_t v346 = 32;
        // pto: %114
        ;
        pto::Shape<1, 1, 1, 128, 32> v347 = pto::Shape<1, 1, 1, 128, 32>();
        // pto: %114
        ;
        pto::Stride<4096, 4096, 4096, 32, 1> v348 = pto::Stride<4096, 4096, 4096, 32, 1>();
        // pto: %114
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND> v349 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND>(v344 + (v345 + v335 * v346), v347, v348);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v342, v349);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %panel64_x16_inline10312__tile_Left
        ;
        Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v350 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v60);
        // pto: %panel64_x16_inline10312__tile_Left
        ;
        uint64_t v351 = (uint64_t) v41;
        TASSIGN(v350, v351);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
        pipe_barrier(PIPE_MTE1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        TMOV(v350, v332);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        // pto: %panel64_w16_inline10314__tile_Right
        ;
        Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v352 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
        // pto: %panel64_w16_inline10314__tile_Right
        ;
        uint64_t v353 = (uint64_t) v41;
        TASSIGN(v352, v353);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        TMOV(v352, v342);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        // pto: %115
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        if (v330 == v54) {
          TMATMUL(v328, v350, v352);
        } else {
          TMATMUL_ACC(v328, v328, v350, v352);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
      // pto: %117, %118
      ;
      int64_t v354 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v324 * (uint64_t) v34) + (uint64_t) v325);
      // pto: %119
      ;
      int64_t v355 = v354 < v54 ? v54 : v354;
      // pto: %linear__iter_v4_pview
      ;
      __gm__ float* v356 = PTOAS__GLOBAL_TENSOR_DATA(v106);
      // pto: %linear__iter_v4_pview
      ;
      const int64_t v357 = 0;
      // pto: %linear__iter_v4_pview
      ;
      const int64_t v358 = 32;
      // pto: %linear__iter_v4_pview
      ;
      pto::Shape<1, 1, 1, 16, 32> v359 = pto::Shape<1, 1, 1, 16, 32>();
      // pto: %linear__iter_v4_pview
      ;
      pto::Stride<512, 512, 512, 32, 1> v360 = pto::Stride<512, 512, 512, 32, 1>();
      // pto: %linear__iter_v4_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND> v361 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND>(v356 + (v357 + v355 * v358), v359, v360);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
      pipe_barrier(PIPE_FIX);
      TSTORE(v361, v328);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
    };
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %120, %121
  int64_t v362 = (int64_t) ((uint64_t) v32 + (uint64_t) v61) / v44;
  // pto: %124
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
  if (v32 <= v44) {
    // pto: %125
    ;
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
    for (int64_t v363 = v153; v363 < ((int64_t) ((uint64_t) v362 * (uint64_t) v46)); v363 += v51) {
      // pto: %126, %127
      ;
      int64_t v364 = (int64_t) ((uint64_t) (v363 / v46) * (uint64_t) v44);
      // pto: %128, %129
      ;
      int64_t v365 = (int64_t) ((uint64_t) (v363 % v46) * (uint64_t) v44);
      // pto: %130
      ;
      int64_t v366 = (int64_t) ((uint64_t) v32 - (uint64_t) v364);
      // pto: %131
      ;
      int64_t v367 = v366 < v44 ? v366 : v44;
      // pto: %m16_tile_inline10375__tile
      ;
      Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v368 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v44);
      // pto: %m16_tile_inline10375__tile
      ;
      uint64_t v369 = (uint64_t) v39;
      TASSIGN(v368, v369);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v370 = v54; v370 < v44; v370 += v43) {
        // pto: %flat_offset, %m16_k_block_inline10372__tile
        ;
        int32_t v371 = (v8)[(int64_t) ((uint64_t) v365 + (uint64_t) v370)];
        // pto: %132
        ;
        int64_t v372 = (int64_t) v371;
        // pto: %133
        ;
        int64_t v373 = v372 < v54 ? v54 : v372;
        // pto: %134
        ;
        int64_t v374 = (int64_t) ((uint64_t) v373 * (uint64_t) v62);
        // pto: %m16_a_inline10352__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v375 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v367, v62);
        // pto: %m16_a_inline10352__tile
        ;
        uint64_t v376 = (uint64_t) v39;
        TASSIGN(v375, v376);
        // pto: %135
        ;
        int64_t v377 = v364 < v54 ? v54 : v364;
        // pto: %136
        ;
        int64_t v378 = v374 < v54 ? v54 : v374;
        // pto: %normed__ssa_v0_pview
        ;
        const int64_t v379 = 0;
        // pto: %normed__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v380 = PTOAS__GLOBAL_TENSOR_DATA(v115);
        // pto: %normed__ssa_v0_pview
        ;
        const int64_t v381 = 1;
        // pto: %normed__ssa_v0_pview
        ;
        const int64_t v382 = 1;
        // pto: %normed__ssa_v0_pview
        ;
        const int64_t v383 = 1;
        // pto: %normed__ssa_v0_pview
        ;
        int64_t v384 = v367 * v47;
        // pto: %normed__ssa_v0_pview
        ;
        int64_t v385 = v383 * v384;
        // pto: %normed__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v386 = pto::Shape<1, 1, 1, -1, 256>(v381, v382, v383, v367, v62);
        // pto: %normed__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v387 = pto::Stride<-1, -1, -1, -1, -1>(v382 * v385, v385, v384, v47, v43);
        // pto: %normed__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v388 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v380 + (v379 + v377 * v47 + v378 * v43), v386, v387);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        TLOAD(v375, v388);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %m16_b_inline10350__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v389 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v62);
        // pto: %m16_b_inline10350__tile
        ;
        uint64_t v390 = (uint64_t) v40;
        TASSIGN(v389, v390);
        // pto: %137
        ;
        int64_t v391 = v365 < v54 ? v54 : v365;
        // pto: %wkv__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v392 = PTOAS__GLOBAL_TENSOR_DATA(v123);
        // pto: %wkv__ssa_v0_pview
        ;
        const int64_t v393 = 0;
        // pto: %wkv__ssa_v0_pview
        ;
        const int64_t v394 = 4096;
        // pto: %wkv__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 16, 256> v395 = pto::Shape<1, 1, 1, 16, 256>();
        // pto: %wkv__ssa_v0_pview
        ;
        pto::Stride<65536, 65536, 65536, 4096, 1> v396 = pto::Stride<65536, 65536, 65536, 4096, 1>();
        // pto: %wkv__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v397 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v392 + (v393 + v391 * v394 + v378), v395, v396);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v389, v397);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %m16_b_inline10350__tile_t
        ;
        Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v398 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
        // pto: %m16_b_inline10350__tile_t
        ;
        uint64_t v399 = (uint64_t) v40;
        TASSIGN(v398, v399);
        // pto: %m16_a_inline10352__tile_Left
        ;
        Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v400 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v367, v62);
        // pto: %m16_a_inline10352__tile_Left
        ;
        uint64_t v401 = (uint64_t) v41;
        TASSIGN(v400, v401);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        TMOV(v400, v375);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        // pto: %m16_b_inline10350__tile_t_Right
        ;
        Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v402 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
        // pto: %m16_b_inline10350__tile_t_Right
        ;
        uint64_t v403 = (uint64_t) v41;
        TASSIGN(v402, v403);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        TMOV(v402, v398);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
        // pto: %139
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
        if (v370 == v54) {
          TMATMUL(v368, v400, v402);
        } else {
          TMATMUL_ACC(v368, v368, v400, v402);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
      // pto: %140
      ;
      int64_t v404 = v364 < v54 ? v54 : v364;
      // pto: %141
      ;
      int64_t v405 = v365 < v54 ? v54 : v365;
      // pto: %accum__iter_v1_pview
      ;
      __gm__ float* v406 = PTOAS__GLOBAL_TENSOR_DATA(v132);
      // pto: %accum__iter_v1_pview
      ;
      const int64_t v407 = 0;
      // pto: %accum__iter_v1_pview
      ;
      const int64_t v408 = 512;
      // pto: %accum__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, 16, 16> v409 = pto::Shape<1, 1, 1, 16, 16>();
      // pto: %accum__iter_v1_pview
      ;
      pto::Stride<8192, 8192, 8192, 512, 1> v410 = pto::Stride<8192, 8192, 8192, 512, 1>();
      // pto: %accum__iter_v1_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v411 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v406 + (v407 + v404 * v408 + v405), v409, v410);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
      pipe_barrier(PIPE_FIX);
      TSTORE(v411, v368);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
    };
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
  } else {
    // pto: %122, %123, %142
    ;
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
    for (int64_t v412 = v153; v412 < ((int64_t) ((uint64_t) ((int64_t) ((uint64_t) v32 + (uint64_t) v58) / v49) * (uint64_t) v44)); v412 += v51) {
      // pto: %143, %144
      ;
      int64_t v413 = (int64_t) ((uint64_t) (v412 / v44) * (uint64_t) v49);
      // pto: %145
      ;
      int64_t v414 = v412 % v44;
      // pto: %146
      ;
      int64_t v415 = (int64_t) ((uint64_t) v414 * (uint64_t) v56);
      int64_t v416 = (int64_t) ((uint64_t) v414 * (uint64_t) v46);
      // pto: %148
      ;
      int64_t v417 = (int64_t) ((uint64_t) v32 - (uint64_t) v413);
      // pto: %149
      ;
      int64_t v418 = v417 < v49 ? v417 : v49;
      // pto: %same_order_inline10363__rv_v2
      ;
      int64_t v419;
      v419 = v43;
      for (int64_t v420 = v54; v420 < v44; v420 += v43) {
        // pto: %151, %t__tile
        ;
        int32_t v421 = (v8)[(int64_t) ((uint64_t) v416 + (uint64_t) v420)];
        // pto: %153, %154, %155, %152
        ;
        int32_t v422 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v415 + (uint64_t) v43) * (uint64_t) v44) + (uint64_t) v420)];
        // pto: %156, %same_order_inline10363__phi_v4
        ;
        int64_t v423 = v421 != v422 ? v54 : v419;
        v419 = v423;
      };
      // pto: %157
      ;
      bool v424 = v419 == v43;
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
      if (v424) {
        // pto: %first_block_inline10366__tile
        ;
        int32_t v425 = (v8)[v416];
        // pto: %160
        ;
        int64_t v426 = (int64_t) v425;
        // pto: %161
        ;
        int64_t v427 = v426 < v54 ? v54 : v426;
        // pto: %162
        ;
        int64_t v428 = (int64_t) ((uint64_t) v427 * (uint64_t) v62);
        // pto: %first_a_inline10374__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v429 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v418, v62);
        // pto: %first_a_inline10374__tile
        ;
        uint64_t v430 = (uint64_t) v39;
        TASSIGN(v429, v430);
        // pto: %163
        ;
        int64_t v431 = v413 < v54 ? v54 : v413;
        // pto: %164
        ;
        int64_t v432 = v428 < v54 ? v54 : v428;
        // pto: %165
        ;
        const int64_t v433 = 0;
        // pto: %165
        ;
        __gm__ bfloat16_t* v434 = PTOAS__GLOBAL_TENSOR_DATA(v115);
        // pto: %165
        ;
        const int64_t v435 = 1;
        // pto: %165
        ;
        const int64_t v436 = 1;
        // pto: %165
        ;
        const int64_t v437 = 1;
        // pto: %165
        ;
        int64_t v438 = v418 * v47;
        // pto: %165
        ;
        int64_t v439 = v437 * v438;
        // pto: %165
        ;
        pto::Shape<1, 1, 1, -1, 256> v440 = pto::Shape<1, 1, 1, -1, 256>(v435, v436, v437, v418, v62);
        // pto: %165
        ;
        pto::Stride<-1, -1, -1, -1, -1> v441 = pto::Stride<-1, -1, -1, -1, -1>(v436 * v439, v439, v438, v47, v43);
        // pto: %165
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v442 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v434 + (v433 + v431 * v47 + v432 * v43), v440, v441);
        TLOAD(v429, v442);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %first_b_inline10370__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v443 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %first_b_inline10370__tile
        ;
        uint64_t v444 = (uint64_t) v40;
        TASSIGN(v443, v444);
        // pto: %166
        ;
        int64_t v445 = v416 < v54 ? v54 : v416;
        // pto: %168
        ;
        __gm__ bfloat16_t* v446 = PTOAS__GLOBAL_TENSOR_DATA(v123);
        // pto: %168
        ;
        const int64_t v447 = 0;
        // pto: %168
        ;
        const int64_t v448 = 4096;
        // pto: %168
        ;
        pto::Shape<1, 1, 1, 32, 256> v449 = pto::Shape<1, 1, 1, 32, 256>();
        // pto: %168
        ;
        pto::Stride<131072, 131072, 131072, 4096, 1> v450 = pto::Stride<131072, 131072, 131072, 4096, 1>();
        // pto: %168
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND> v451 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND>(v446 + (v447 + v445 * v448 + v432), v449, v450);
        TLOAD(v443, v451);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %first_b_inline10370__tile_t
        ;
        Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v452 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v46);
        // pto: %first_b_inline10370__tile_t
        ;
        uint64_t v453 = (uint64_t) v40;
        TASSIGN(v452, v453);
        // pto: %first_a_inline10374__tile_Left
        ;
        Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v454 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v418, v62);
        // pto: %first_a_inline10374__tile_Left
        ;
        uint64_t v455 = (uint64_t) v41;
        TASSIGN(v454, v455);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        TMOV(v454, v429);
        // pto: %first_b_inline10370__tile_t_Right
        ;
        Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v456 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v46);
        // pto: %first_b_inline10370__tile_t_Right
        ;
        uint64_t v457 = (uint64_t) v41;
        TASSIGN(v456, v457);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        TMOV(v456, v452);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        // pto: %wide_tile_inline10376__tile
        ;
        Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v458 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v418, v46);
        // pto: %wide_tile_inline10376__tile
        ;
        uint64_t v459 = (uint64_t) v39;
        TASSIGN(v458, v459);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        TMATMUL(v458, v454, v456);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        for (int64_t v460 = v43; v460 < v44; v460 += v43) {
          // pto: %170, %k_block_inline10378__tile
          ;
          int32_t v461 = (v8)[(int64_t) ((uint64_t) v416 + (uint64_t) v460)];
          // pto: %171
          ;
          int64_t v462 = (int64_t) v461;
          // pto: %172
          ;
          int64_t v463 = v462 < v54 ? v54 : v462;
          // pto: %173
          ;
          int64_t v464 = (int64_t) ((uint64_t) v463 * (uint64_t) v62);
          // pto: %a_inline10343__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v465 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v418, v62);
          // pto: %a_inline10343__tile
          ;
          uint64_t v466 = (uint64_t) v39;
          TASSIGN(v465, v466);
          // pto: %175
          ;
          int64_t v467 = v464 < v54 ? v54 : v464;
          // pto: %176
          ;
          const int64_t v468 = 0;
          // pto: %176
          ;
          __gm__ bfloat16_t* v469 = PTOAS__GLOBAL_TENSOR_DATA(v115);
          // pto: %176
          ;
          const int64_t v470 = 1;
          // pto: %176
          ;
          const int64_t v471 = 1;
          // pto: %176
          ;
          const int64_t v472 = 1;
          // pto: %176
          ;
          int64_t v473 = v418 * v47;
          // pto: %176
          ;
          int64_t v474 = v472 * v473;
          // pto: %176
          ;
          pto::Shape<1, 1, 1, -1, 256> v475 = pto::Shape<1, 1, 1, -1, 256>(v470, v471, v472, v418, v62);
          // pto: %176
          ;
          pto::Stride<-1, -1, -1, -1, -1> v476 = pto::Stride<-1, -1, -1, -1, -1>(v471 * v474, v474, v473, v47, v43);
          // pto: %176
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v477 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v469 + (v468 + v431 * v47 + v467 * v43), v475, v476);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          TLOAD(v465, v477);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %b_inline10377__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v478 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v46, v62);
          // pto: %b_inline10377__tile
          ;
          uint64_t v479 = (uint64_t) v40;
          TASSIGN(v478, v479);
          // pto: %179
          ;
          __gm__ bfloat16_t* v480 = PTOAS__GLOBAL_TENSOR_DATA(v123);
          // pto: %179
          ;
          const int64_t v481 = 0;
          // pto: %179
          ;
          const int64_t v482 = 4096;
          // pto: %179
          ;
          pto::Shape<1, 1, 1, 32, 256> v483 = pto::Shape<1, 1, 1, 32, 256>();
          // pto: %179
          ;
          pto::Stride<131072, 131072, 131072, 4096, 1> v484 = pto::Stride<131072, 131072, 131072, 4096, 1>();
          // pto: %179
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND> v485 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND>(v480 + (v481 + v445 * v482 + v467), v483, v484);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          TLOAD(v478, v485);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %b_inline10377__tile_t
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v486 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v46);
          // pto: %b_inline10377__tile_t
          ;
          uint64_t v487 = (uint64_t) v40;
          TASSIGN(v486, v487);
          // pto: %a_inline10343__tile_Left
          ;
          Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v488 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v418, v62);
          // pto: %a_inline10343__tile_Left
          ;
          uint64_t v489 = (uint64_t) v41;
          TASSIGN(v488, v489);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          TMOV(v488, v465);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %b_inline10377__tile_t_Right
          ;
          Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v490 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v46);
          // pto: %b_inline10377__tile_t_Right
          ;
          uint64_t v491 = (uint64_t) v41;
          TASSIGN(v490, v491);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          TMOV(v490, v486);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          TMATMUL_ACC(v458, v458, v488, v490);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        };
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
        // pto: %accum__iter_v4_pview
        ;
        const int64_t v492 = 0;
        // pto: %accum__iter_v4_pview
        ;
        __gm__ float* v493 = PTOAS__GLOBAL_TENSOR_DATA(v132);
        // pto: %accum__iter_v4_pview
        ;
        const int64_t v494 = 1;
        // pto: %accum__iter_v4_pview
        ;
        const int64_t v495 = 1;
        // pto: %accum__iter_v4_pview
        ;
        const int64_t v496 = 1;
        // pto: %accum__iter_v4_pview
        ;
        int64_t v497 = v418 * v48;
        // pto: %accum__iter_v4_pview
        ;
        int64_t v498 = v496 * v497;
        // pto: %accum__iter_v4_pview
        ;
        pto::Shape<1, 1, 1, -1, 32> v499 = pto::Shape<1, 1, 1, -1, 32>(v494, v495, v496, v418, v46);
        // pto: %accum__iter_v4_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v500 = pto::Stride<-1, -1, -1, -1, -1>(v495 * v498, v498, v497, v48, v43);
        // pto: %accum__iter_v4_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v501 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v493 + (v492 + v431 * v48 + v445 * v43), v499, v500);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
        TSTORE(v501, v458);
      } else {
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
        for (int64_t v502 = v54; v502 < v56; v502 += v43) {
          // pto: %183, %184
          ;
          int64_t v503 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v415 + (uint64_t) v502) * (uint64_t) v44);
          // pto: %narrow_first_block_inline10339__tile
          ;
          int32_t v504 = (v8)[v503];
          // pto: %187
          ;
          int64_t v505 = (int64_t) v504;
          // pto: %188
          ;
          int64_t v506 = v505 < v54 ? v54 : v505;
          // pto: %189
          ;
          int64_t v507 = (int64_t) ((uint64_t) v506 * (uint64_t) v62);
          // pto: %narrow_first_a_inline10359__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v508 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v418, v62);
          // pto: %narrow_first_a_inline10359__tile
          ;
          uint64_t v509 = (uint64_t) v39;
          TASSIGN(v508, v509);
          // pto: %190
          ;
          int64_t v510 = v413 < v54 ? v54 : v413;
          // pto: %191
          ;
          int64_t v511 = v507 < v54 ? v54 : v507;
          // pto: %192
          ;
          const int64_t v512 = 0;
          // pto: %192
          ;
          __gm__ bfloat16_t* v513 = PTOAS__GLOBAL_TENSOR_DATA(v115);
          // pto: %192
          ;
          const int64_t v514 = 1;
          // pto: %192
          ;
          const int64_t v515 = 1;
          // pto: %192
          ;
          const int64_t v516 = 1;
          // pto: %192
          ;
          int64_t v517 = v418 * v47;
          // pto: %192
          ;
          int64_t v518 = v516 * v517;
          // pto: %192
          ;
          pto::Shape<1, 1, 1, -1, 256> v519 = pto::Shape<1, 1, 1, -1, 256>(v514, v515, v516, v418, v62);
          // pto: %192
          ;
          pto::Stride<-1, -1, -1, -1, -1> v520 = pto::Stride<-1, -1, -1, -1, -1>(v515 * v518, v518, v517, v47, v43);
          // pto: %192
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v521 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v513 + (v512 + v510 * v47 + v511 * v43), v519, v520);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          TLOAD(v508, v521);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %narrow_first_b_inline10357__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v522 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v62);
          // pto: %narrow_first_b_inline10357__tile
          ;
          uint64_t v523 = (uint64_t) v40;
          TASSIGN(v522, v523);
          // pto: %193
          ;
          int64_t v524 = v503 < v54 ? v54 : v503;
          // pto: %195
          ;
          __gm__ bfloat16_t* v525 = PTOAS__GLOBAL_TENSOR_DATA(v123);
          // pto: %195
          ;
          const int64_t v526 = 0;
          // pto: %195
          ;
          const int64_t v527 = 4096;
          // pto: %195
          ;
          pto::Shape<1, 1, 1, 16, 256> v528 = pto::Shape<1, 1, 1, 16, 256>();
          // pto: %195
          ;
          pto::Stride<65536, 65536, 65536, 4096, 1> v529 = pto::Stride<65536, 65536, 65536, 4096, 1>();
          // pto: %195
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v530 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v525 + (v526 + v524 * v527 + v511), v528, v529);
          TLOAD(v522, v530);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %narrow_first_b_inline10357__tile_t
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v531 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
          // pto: %narrow_first_b_inline10357__tile_t
          ;
          uint64_t v532 = (uint64_t) v40;
          TASSIGN(v531, v532);
          // pto: %narrow_first_a_inline10359__tile_Left
          ;
          Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v533 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v418, v62);
          // pto: %narrow_first_a_inline10359__tile_Left
          ;
          uint64_t v534 = (uint64_t) v41;
          TASSIGN(v533, v534);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          TMOV(v533, v508);
          // pto: %narrow_first_b_inline10357__tile_t_Right
          ;
          Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v535 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
          // pto: %narrow_first_b_inline10357__tile_t_Right
          ;
          uint64_t v536 = (uint64_t) v41;
          TASSIGN(v535, v536);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          TMOV(v535, v531);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          // pto: %narrow_tile_inline10367__tile
          ;
          Tile<TileType::Acc, float, 64, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v537 = Tile<TileType::Acc, float, 64, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v418, v44);
          // pto: %narrow_tile_inline10367__tile
          ;
          uint64_t v538 = (uint64_t) v39;
          TASSIGN(v537, v538);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          wait_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
          TMATMUL(v537, v533, v535);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          for (int64_t v539 = v43; v539 < v44; v539 += v43) {
            // pto: %197, %narrow_block_inline10340__tile
            ;
            int32_t v540 = (v8)[(int64_t) ((uint64_t) v503 + (uint64_t) v539)];
            // pto: %198
            ;
            int64_t v541 = (int64_t) v540;
            // pto: %199
            ;
            int64_t v542 = v541 < v54 ? v54 : v541;
            // pto: %200
            ;
            int64_t v543 = (int64_t) ((uint64_t) v542 * (uint64_t) v62);
            // pto: %narrow_a_inline10336__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v544 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v418, v62);
            // pto: %narrow_a_inline10336__tile
            ;
            uint64_t v545 = (uint64_t) v39;
            TASSIGN(v544, v545);
            // pto: %202
            ;
            int64_t v546 = v543 < v54 ? v54 : v543;
            // pto: %203
            ;
            const int64_t v547 = 0;
            // pto: %203
            ;
            __gm__ bfloat16_t* v548 = PTOAS__GLOBAL_TENSOR_DATA(v115);
            // pto: %203
            ;
            const int64_t v549 = 1;
            // pto: %203
            ;
            const int64_t v550 = 1;
            // pto: %203
            ;
            const int64_t v551 = 1;
            // pto: %203
            ;
            int64_t v552 = v418 * v47;
            // pto: %203
            ;
            int64_t v553 = v551 * v552;
            // pto: %203
            ;
            pto::Shape<1, 1, 1, -1, 256> v554 = pto::Shape<1, 1, 1, -1, 256>(v549, v550, v551, v418, v62);
            // pto: %203
            ;
            pto::Stride<-1, -1, -1, -1, -1> v555 = pto::Stride<-1, -1, -1, -1, -1>(v550 * v553, v553, v552, v47, v43);
            // pto: %203
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v556 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v548 + (v547 + v510 * v47 + v546 * v43), v554, v555);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            TLOAD(v544, v556);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %narrow_b_inline10335__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v557 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v62);
            // pto: %narrow_b_inline10335__tile
            ;
            uint64_t v558 = (uint64_t) v40;
            TASSIGN(v557, v558);
            // pto: %206
            ;
            __gm__ bfloat16_t* v559 = PTOAS__GLOBAL_TENSOR_DATA(v123);
            // pto: %206
            ;
            const int64_t v560 = 0;
            // pto: %206
            ;
            const int64_t v561 = 4096;
            // pto: %206
            ;
            pto::Shape<1, 1, 1, 16, 256> v562 = pto::Shape<1, 1, 1, 16, 256>();
            // pto: %206
            ;
            pto::Stride<65536, 65536, 65536, 4096, 1> v563 = pto::Stride<65536, 65536, 65536, 4096, 1>();
            // pto: %206
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v564 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v559 + (v560 + v524 * v561 + v546), v562, v563);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            TLOAD(v557, v564);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %narrow_b_inline10335__tile_t
            ;
            Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v565 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
            // pto: %narrow_b_inline10335__tile_t
            ;
            uint64_t v566 = (uint64_t) v40;
            TASSIGN(v565, v566);
            // pto: %narrow_a_inline10336__tile_Left
            ;
            Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v567 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v418, v62);
            // pto: %narrow_a_inline10336__tile_Left
            ;
            uint64_t v568 = (uint64_t) v41;
            TASSIGN(v567, v568);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
            TMOV(v567, v544);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            // pto: %narrow_b_inline10335__tile_t_Right
            ;
            Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v569 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
            // pto: %narrow_b_inline10335__tile_t_Right
            ;
            uint64_t v570 = (uint64_t) v41;
            TASSIGN(v569, v570);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            TMOV(v569, v565);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            TMATMUL_ACC(v537, v537, v567, v569);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %accum__iter_v7_pview
          ;
          const int64_t v571 = 0;
          // pto: %accum__iter_v7_pview
          ;
          __gm__ float* v572 = PTOAS__GLOBAL_TENSOR_DATA(v132);
          // pto: %accum__iter_v7_pview
          ;
          const int64_t v573 = 1;
          // pto: %accum__iter_v7_pview
          ;
          const int64_t v574 = 1;
          // pto: %accum__iter_v7_pview
          ;
          const int64_t v575 = 1;
          // pto: %accum__iter_v7_pview
          ;
          int64_t v576 = v418 * v48;
          // pto: %accum__iter_v7_pview
          ;
          int64_t v577 = v575 * v576;
          // pto: %accum__iter_v7_pview
          ;
          pto::Shape<1, 1, 1, -1, 16> v578 = pto::Shape<1, 1, 1, -1, 16>(v573, v574, v575, v418, v44);
          // pto: %accum__iter_v7_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v579 = pto::Stride<-1, -1, -1, -1, -1>(v574 * v577, v577, v576, v48, v43);
          // pto: %accum__iter_v7_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v580 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v572 + (v571 + v510 * v48 + v524 * v43), v578, v579);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
          TSTORE(v580, v537);
          set_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
        };
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
    };
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  // pto: %212
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  for (int64_t v581 = v153; v581 < ((int64_t) ((uint64_t) v362 * (uint64_t) v50)); v581 += v51) {
    // pto: %213
    ;
    int64_t v582 = v581 / v50;
    // pto: %214
    ;
    int64_t v583 = v581 % v50;
    // pto: %215
    ;
    int64_t v584 = (int64_t) ((uint64_t) v582 * (uint64_t) v44);
    // pto: %216
    ;
    int64_t v585 = (int64_t) ((uint64_t) v583 * (uint64_t) v44);
    // pto: %217
    ;
    int64_t v586 = (int64_t) ((uint64_t) v32 - (uint64_t) v584);
    // pto: %218
    ;
    int64_t v587 = v586 < v44 ? v586 : v44;
    // pto: %tile_inline10386__tile
    ;
    Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v588 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v44);
    // pto: %tile_inline10386__tile
    ;
    uint64_t v589 = (uint64_t) v39;
    TASSIGN(v588, v589);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    for (int64_t v590 = v54; v590 < v44; v590 += v43) {
      // pto: %219, %220, %221, %222, %k_block_inline10390__tile
      ;
      int32_t v591 = (v12)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v582 * (uint64_t) v50) + (uint64_t) v583) * (uint64_t) v44) + (uint64_t) v590)];
      // pto: %223
      ;
      int64_t v592 = (int64_t) v591;
      // pto: %224
      ;
      int64_t v593 = v592 < v54 ? v54 : v592;
      // pto: %225
      ;
      int64_t v594 = (int64_t) ((uint64_t) v593 * (uint64_t) v62);
      // pto: %a_inline10392__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v595 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v587, v62);
      // pto: %a_inline10392__tile
      ;
      uint64_t v596 = (uint64_t) v39;
      TASSIGN(v595, v596);
      // pto: %226
      ;
      int64_t v597 = v584 < v54 ? v54 : v584;
      // pto: %227
      ;
      int64_t v598 = v594 < v54 ? v54 : v594;
      // pto: %228
      ;
      const int64_t v599 = 0;
      // pto: %228
      ;
      __gm__ bfloat16_t* v600 = PTOAS__GLOBAL_TENSOR_DATA(v115);
      // pto: %228
      ;
      const int64_t v601 = 1;
      // pto: %228
      ;
      const int64_t v602 = 1;
      // pto: %228
      ;
      const int64_t v603 = 1;
      // pto: %228
      ;
      int64_t v604 = v587 * v47;
      // pto: %228
      ;
      int64_t v605 = v603 * v604;
      // pto: %228
      ;
      pto::Shape<1, 1, 1, -1, 256> v606 = pto::Shape<1, 1, 1, -1, 256>(v601, v602, v603, v587, v62);
      // pto: %228
      ;
      pto::Stride<-1, -1, -1, -1, -1> v607 = pto::Stride<-1, -1, -1, -1, -1>(v602 * v605, v605, v604, v47, v43);
      // pto: %228
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v608 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v600 + (v599 + v597 * v47 + v598 * v43), v606, v607);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v595, v608);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %b_inline10379__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v609 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v62);
      // pto: %b_inline10379__tile
      ;
      uint64_t v610 = (uint64_t) v40;
      TASSIGN(v609, v610);
      // pto: %229
      ;
      int64_t v611 = v585 < v54 ? v54 : v585;
      // pto: %weights_proj__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v612 = PTOAS__GLOBAL_TENSOR_DATA(v140);
      // pto: %weights_proj__ssa_v0_pview
      ;
      const int64_t v613 = 0;
      // pto: %weights_proj__ssa_v0_pview
      ;
      const int64_t v614 = 4096;
      // pto: %weights_proj__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 256> v615 = pto::Shape<1, 1, 1, 16, 256>();
      // pto: %weights_proj__ssa_v0_pview
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v616 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %weights_proj__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v617 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v612 + (v613 + v611 * v614 + v598), v615, v616);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v609, v617);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %b_inline10379__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v618 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
      // pto: %b_inline10379__tile_t
      ;
      uint64_t v619 = (uint64_t) v40;
      TASSIGN(v618, v619);
      // pto: %a_inline10392__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v620 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v587, v62);
      // pto: %a_inline10392__tile_Left
      ;
      uint64_t v621 = (uint64_t) v41;
      TASSIGN(v620, v621);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      TMOV(v620, v595);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %b_inline10379__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v622 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
      // pto: %b_inline10379__tile_t_Right
      ;
      uint64_t v623 = (uint64_t) v41;
      TASSIGN(v622, v623);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      TMOV(v622, v618);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %231
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (v590 == v54) {
        TMATMUL(v588, v620, v622);
      } else {
        TMATMUL_ACC(v588, v588, v620, v622);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    };
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID6);
    // pto: %232
    ;
    int64_t v624 = v584 < v54 ? v54 : v584;
    // pto: %233
    ;
    int64_t v625 = v585 < v54 ? v54 : v585;
    // pto: %idx_accum__iter_v1_pview
    ;
    __gm__ float* v626 = PTOAS__GLOBAL_TENSOR_DATA(v149);
    // pto: %idx_accum__iter_v1_pview
    ;
    const int64_t v627 = 0;
    // pto: %idx_accum__iter_v1_pview
    ;
    const int64_t v628 = 64;
    // pto: %idx_accum__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 16> v629 = pto::Shape<1, 1, 1, 16, 16>();
    // pto: %idx_accum__iter_v1_pview
    ;
    pto::Stride<1024, 1024, 1024, 64, 1> v630 = pto::Stride<1024, 1024, 1024, 64, 1>();
    // pto: %idx_accum__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<1024, 1024, 1024, 64, 1>, pto::Layout::ND> v631 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<1024, 1024, 1024, 64, 1>, pto::Layout::ND>(v626 + (v627 + v624 * v628 + v625), v629, v630);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID6);
    pipe_barrier(PIPE_FIX);
    TSTORE(v631, v588);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void prepacked_prefix_indexer_vector(__gm__ float* v1, __gm__ float* v2, __gm__ bfloat16_t* v3, __gm__ bfloat16_t* v4, __gm__ float* v5, __gm__ bfloat16_t* v6, __gm__ bfloat16_t* v7, __gm__ int32_t* v8, __gm__ float* v9, __gm__ int64_t* v10, __gm__ bfloat16_t* v11, __gm__ int32_t* v12, __gm__ float* v13, __gm__ bfloat16_t* v14, __gm__ float* v15, __gm__ float* v16, __gm__ float* v17, __gm__ float* v18, __gm__ float* v19, __gm__ float* v20, __gm__ float* v21, __gm__ float* v22, __gm__ bfloat16_t* v23, __gm__ bfloat16_t* v24, __gm__ bfloat16_t* v25, __gm__ float* v26, __gm__ bfloat16_t* v27, __gm__ float* v28, __gm__ bfloat16_t* v29, __gm__ bfloat16_t* v30, __gm__ half* v31, int64_t v32, int64_t v33, int64_t v34, int64_t v35, int64_t v36, int32_t v37, int32_t v38, int32_t v39) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v40 = 12544;
  const int64_t v41 = 8448;
  const int64_t v42 = 4352;
  const int64_t v43 = 8388608;
  const int64_t v44 = 20;
  // pto: %c108288_i64
  const int64_t v45 = 108288;
  // pto: %c1792_i64
  const int64_t v46 = 1792;
  // pto: %c42752_i64
  const int64_t v47 = 42752;
  // pto: %c75520_i64
  const int64_t v48 = 75520;
  // pto: %c18176_i64
  const int64_t v49 = 18176;
  // pto: %c26368_i64
  const int64_t v50 = 26368;
  // pto: %c34560_i64
  const int64_t v51 = 34560;
  // pto: %c0_i64
  const int64_t v52 = 0;
  // pto: %c256_i64
  const int64_t v53 = 256;
  // pto: %c9984_i64
  const int64_t v54 = 9984;
  // pto: %c512_i64
  const int64_t v55 = 512;
  // pto: %c768_i64
  const int64_t v56 = 768;
  // pto: %c1024_i64
  const int64_t v57 = 1024;
  // pto: %c1280_i64
  const int64_t v58 = 1280;
  // pto: %c1536_i64
  const int64_t v59 = 1536;
  const int64_t v60 = 32;
  const int64_t v61 = 64;
  // pto: %c96_i64
  const int64_t v62 = 96;
  const int64_t v63 = 83712;
  const int64_t v64 = 79616;
  const int64_t v65 = 77568;
  const int64_t v66 = 76544;
  const int64_t v67 = 76032;
  const int64_t v68 = 75776;
  // pto: %c16384_index
  const int64_t v69 = 16384;
  // pto: %c1_index
  const int64_t v70 = 1;
  const int64_t v71 = 16;
  // pto: %c32768_index
  const int64_t v72 = 32768;
  // pto: %c32_index
  const int64_t v73 = 32;
  // pto: %c4096_index
  const int64_t v74 = 4096;
  const int64_t v75 = 512;
  // pto: %c64_index
  const int64_t v76 = 64;
  // pto: %c4_index
  const int64_t v77 = 4;
  // pto: %c24_index
  const int64_t v78 = 24;
  const int64_t v79 = 8;
  // pto: %c2_index
  const int64_t v80 = 2;
  // pto: %c48_index
  const int64_t v81 = 48;
  // pto: %c0_index
  const int64_t v82 = 0;
  // pto: %c7_index
  const int64_t v83 = 7;
  // pto: %c192_index
  const int64_t v84 = 192;
  // pto: %c0_i32
  const int32_t v85 = 0;
  // pto: %c16_i32
  const int32_t v86 = 16;
  // pto: %c22_index
  const int64_t v87 = 22;
  // pto: %cst_44
  const float v88 = 6.10351563E-5f;
  // pto: %cst_45
  const float v89 = 9.99999997E-7f;
  // pto: %cst_46
  const float v90 = 1.0f;
  // pto: %c256_index
  const int64_t v91 = 256;
  // pto: %cst_49
  const float v92 = 0.0f;
  // pto: %cst_50
  const bfloat16_t v93 = 0.0f;
  // pto: %cst_51
  const float v94 = 2.0f;
  const int64_t v95 = 12;
  // pto: %c18_index
  const int64_t v96 = 18;
  // pto: %c8192_index
  const int64_t v97 = 8192;
  // pto: %c12288_index
  const int64_t v98 = 12288;
  // pto: %c2048_index
  const int64_t v99 = 2048;
  // pto: %c1024_index
  const int64_t v100 = 1024;
  // pto: %c128_index
  const int64_t v101 = 128;
  // pto: %cst_59
  const float v102 = 2.44140625E-4f;
  // pto: %c8388608_index
  const int64_t v103 = 8388608;
  // pto: %c2139095040_i64
  const int64_t v104 = 2139095040;
  // pto: %c2_i64
  const int64_t v105 = 2;
  // pto: %c152_i64
  const int64_t v106 = 152;
  // pto: %c1_i64
  const int64_t v107 = 1;
  // pto: %c15_index
  const int64_t v108 = 15;
  // pto: %cst_66
  const float v109 = 0.0110485433f;
  // pto: %wide__ssa_v0_view
  const int64_t v110 = 1;
  // pto: %wide__ssa_v0_view
  const int64_t v111 = 1;
  // pto: %wide__ssa_v0_view
  const int64_t v112 = 1;
  // pto: %wide__ssa_v0_view
  int64_t v113 = (int64_t) v32;
  // pto: %wide__ssa_v0_view
  int64_t v114 = v113 * v69;
  // pto: %wide__ssa_v0_view
  int64_t v115 = v112 * v114;
  // pto: %wide__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v116 = pto::Shape<1, 1, 1, -1, -1>(v110, v111, v112, v113, v69);
  // pto: %wide__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v117 = pto::Stride<-1, -1, -1, -1, -1>(v111 * v115, v115, v114, v69, v70);
  // pto: %wide__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v118 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v116, v117);
  // pto: %packed_flat__ssa_v0_view
  const int64_t v119 = 1;
  // pto: %packed_flat__ssa_v0_view
  const int64_t v120 = 1;
  // pto: %packed_flat__ssa_v0_view
  const int64_t v121 = 1;
  // pto: %packed_flat__ssa_v0_view
  int64_t v122 = (int64_t) v34;
  // pto: %packed_flat__ssa_v0_view
  int64_t v123 = v122 * v72;
  // pto: %packed_flat__ssa_v0_view
  int64_t v124 = v121 * v123;
  // pto: %packed_flat__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v125 = pto::Shape<1, 1, 1, -1, -1>(v119, v120, v121, v122, v72);
  // pto: %packed_flat__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v126 = pto::Stride<-1, -1, -1, -1, -1>(v120 * v124, v124, v123, v72, v70);
  // pto: %packed_flat__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v127 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v125, v126);
  // pto: %normed__ssa_v0_view
  const int64_t v128 = 1;
  // pto: %normed__ssa_v0_view
  const int64_t v129 = 1;
  // pto: %normed__ssa_v0_view
  const int64_t v130 = 1;
  // pto: %normed__ssa_v0_view
  int64_t v131 = (int64_t) v32;
  // pto: %normed__ssa_v0_view
  int64_t v132 = v131 * v74;
  // pto: %normed__ssa_v0_view
  int64_t v133 = v130 * v132;
  // pto: %normed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v134 = pto::Shape<1, 1, 1, -1, -1>(v128, v129, v130, v131, v74);
  // pto: %normed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v135 = pto::Stride<-1, -1, -1, -1, -1>(v129 * v133, v133, v132, v74, v70);
  // pto: %normed__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v136 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v134, v135);
  // pto: %flat_hc__ssa_v0_view
  const int64_t v137 = 1;
  // pto: %flat_hc__ssa_v0_view
  const int64_t v138 = 1;
  // pto: %flat_hc__ssa_v0_view
  const int64_t v139 = 1;
  // pto: %flat_hc__ssa_v0_view
  int64_t v140 = (int64_t) v32;
  // pto: %flat_hc__ssa_v0_view
  int64_t v141 = v140 * v69;
  // pto: %flat_hc__ssa_v0_view
  int64_t v142 = v139 * v141;
  // pto: %flat_hc__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v143 = pto::Shape<1, 1, 1, -1, -1>(v137, v138, v139, v140, v69);
  // pto: %flat_hc__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v144 = pto::Stride<-1, -1, -1, -1, -1>(v138 * v142, v142, v141, v69, v70);
  // pto: %flat_hc__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v145 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v143, v144);
  // pto: %spmd_square_read__ssa_v0_view
  const int64_t v146 = 1;
  // pto: %spmd_square_read__ssa_v0_view
  const int64_t v147 = 1;
  // pto: %spmd_square_read__ssa_v0_view
  const int64_t v148 = 1;
  // pto: %spmd_square_read__ssa_v0_view
  int64_t v149 = (int64_t) v33;
  // pto: %spmd_square_read__ssa_v0_view
  int64_t v150 = v149 * v71;
  // pto: %spmd_square_read__ssa_v0_view
  int64_t v151 = v148 * v150;
  // pto: %spmd_square_read__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v152 = pto::Shape<1, 1, 1, -1, -1>(v146, v147, v148, v149, v71);
  // pto: %spmd_square_read__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v153 = pto::Stride<-1, -1, -1, -1, -1>(v147 * v151, v151, v150, v71, v70);
  // pto: %spmd_square_read__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v154 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v152, v153);
  // pto: %vec_ws__ssa_v0_view
  const int64_t v155 = 1;
  // pto: %vec_ws__ssa_v0_view
  const int64_t v156 = 1;
  // pto: %vec_ws__ssa_v0_view
  const int64_t v157 = 1;
  // pto: %vec_ws__ssa_v0_view
  int64_t v158 = (int64_t) v36;
  // pto: %vec_ws__ssa_v0_view
  int64_t v159 = v158 * v76;
  // pto: %vec_ws__ssa_v0_view
  int64_t v160 = v157 * v159;
  // pto: %vec_ws__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v161 = pto::Shape<1, 1, 1, -1, -1>(v155, v156, v157, v158, v76);
  // pto: %vec_ws__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v162 = pto::Stride<-1, -1, -1, -1, -1>(v156 * v160, v160, v159, v76, v70);
  // pto: %vec_ws__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v163 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v161, v162);
  // pto: %spmd_linear_read__ssa_v0_view
  const int64_t v164 = 1;
  // pto: %spmd_linear_read__ssa_v0_view
  const int64_t v165 = 1;
  // pto: %spmd_linear_read__ssa_v0_view
  const int64_t v166 = 1;
  // pto: %spmd_linear_read__ssa_v0_view
  int64_t v167 = (int64_t) v33;
  // pto: %spmd_linear_read__ssa_v0_view
  int64_t v168 = v167 * v73;
  // pto: %spmd_linear_read__ssa_v0_view
  int64_t v169 = v166 * v168;
  // pto: %spmd_linear_read__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v170 = pto::Shape<1, 1, 1, -1, -1>(v164, v165, v166, v167, v73);
  // pto: %spmd_linear_read__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v171 = pto::Stride<-1, -1, -1, -1, -1>(v165 * v169, v169, v168, v73, v70);
  // pto: %spmd_linear_read__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v172 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v17, v170, v171);
  // pto: %hc_attn_base__ssa_v0_view
  const int64_t v173 = 1;
  // pto: %hc_attn_base__ssa_v0_view
  const int64_t v174 = 1;
  // pto: %hc_attn_base__ssa_v0_view
  const int64_t v175 = 1;
  // pto: %hc_attn_base__ssa_v0_view
  const int64_t v176 = 1;
  // pto: %hc_attn_base__ssa_v0_view
  int64_t v177 = v78 * v70;
  // pto: %hc_attn_base__ssa_v0_view
  int64_t v178 = v176 * v177;
  // pto: %hc_attn_base__ssa_v0_view
  int64_t v179 = v175 * v178;
  // pto: %hc_attn_base__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v180 = pto::Shape<1, 1, 1, 1, -1>(v173, v174, v175, v176, v78);
  // pto: %hc_attn_base__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v181 = pto::Stride<-1, -1, -1, -1, -1>(v174 * v179, v179, v178, v177, v70);
  // pto: %hc_attn_base__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v182 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v19, v180, v181);
  // pto: %hc_base_2d__ssa_v0_view
  const int64_t v183 = 1;
  // pto: %hc_base_2d__ssa_v0_view
  const int64_t v184 = 1;
  // pto: %hc_base_2d__ssa_v0_view
  const int64_t v185 = 1;
  // pto: %hc_base_2d__ssa_v0_view
  int64_t v186 = v70 * v78;
  // pto: %hc_base_2d__ssa_v0_view
  int64_t v187 = v185 * v186;
  // pto: %hc_base_2d__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v188 = pto::Shape<1, 1, 1, -1, -1>(v183, v184, v185, v70, v78);
  // pto: %hc_base_2d__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v189 = pto::Stride<-1, -1, -1, -1, -1>(v184 * v187, v187, v186, v78, v70);
  // pto: %hc_base_2d__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v190 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v20, v188, v189);
  // pto: %post__ssa_v0_view
  const int64_t v191 = 1;
  // pto: %post__ssa_v0_view
  const int64_t v192 = 1;
  // pto: %post__ssa_v0_view
  const int64_t v193 = 1;
  // pto: %post__ssa_v0_view
  int64_t v194 = (int64_t) v32;
  // pto: %post__ssa_v0_view
  int64_t v195 = v194 * v77;
  // pto: %post__ssa_v0_view
  int64_t v196 = v193 * v195;
  // pto: %post__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v197 = pto::Shape<1, 1, 1, -1, -1>(v191, v192, v193, v194, v77);
  // pto: %post__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v198 = pto::Stride<-1, -1, -1, -1, -1>(v192 * v196, v196, v195, v77, v70);
  // pto: %post__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v199 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v21, v197, v198);
  // pto: %comb__ssa_v0_view
  const int64_t v200 = 1;
  // pto: %comb__ssa_v0_view
  const int64_t v201 = 1;
  // pto: %comb__ssa_v0_view
  const int64_t v202 = 1;
  // pto: %comb__ssa_v0_view
  int64_t v203 = (int64_t) v32;
  // pto: %comb__ssa_v0_view
  int64_t v204 = v203 * v71;
  // pto: %comb__ssa_v0_view
  int64_t v205 = v202 * v204;
  // pto: %comb__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v206 = pto::Shape<1, 1, 1, -1, -1>(v200, v201, v202, v203, v71);
  // pto: %comb__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v207 = pto::Stride<-1, -1, -1, -1, -1>(v201 * v205, v205, v204, v71, v70);
  // pto: %comb__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v208 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v22, v206, v207);
  // pto: %mixed__ssa_v0_view
  const int64_t v209 = 1;
  // pto: %mixed__ssa_v0_view
  const int64_t v210 = 1;
  // pto: %mixed__ssa_v0_view
  const int64_t v211 = 1;
  // pto: %mixed__ssa_v0_view
  int64_t v212 = (int64_t) v32;
  // pto: %mixed__ssa_v0_view
  int64_t v213 = v212 * v74;
  // pto: %mixed__ssa_v0_view
  int64_t v214 = v211 * v213;
  // pto: %mixed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v215 = pto::Shape<1, 1, 1, -1, -1>(v209, v210, v211, v212, v74);
  // pto: %mixed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v216 = pto::Stride<-1, -1, -1, -1, -1>(v210 * v214, v214, v213, v74, v70);
  // pto: %mixed__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v217 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v23, v215, v216);
  // pto: %mixed_tail__ssa_v0_view
  const int64_t v218 = 1;
  // pto: %mixed_tail__ssa_v0_view
  const int64_t v219 = 1;
  // pto: %mixed_tail__ssa_v0_view
  const int64_t v220 = 1;
  // pto: %mixed_tail__ssa_v0_view
  int64_t v221 = v79 * v74;
  // pto: %mixed_tail__ssa_v0_view
  int64_t v222 = v220 * v221;
  // pto: %mixed_tail__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v223 = pto::Shape<1, 1, 1, -1, -1>(v218, v219, v220, v79, v74);
  // pto: %mixed_tail__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v224 = pto::Stride<-1, -1, -1, -1, -1>(v219 * v222, v222, v221, v74, v70);
  // pto: %mixed_tail__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v225 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v24, v223, v224);
  // pto: %attn_norm_w__ssa_v0_view
  const int64_t v226 = 1;
  // pto: %attn_norm_w__ssa_v0_view
  const int64_t v227 = 1;
  // pto: %attn_norm_w__ssa_v0_view
  const int64_t v228 = 1;
  // pto: %attn_norm_w__ssa_v0_view
  const int64_t v229 = 1;
  // pto: %attn_norm_w__ssa_v0_view
  int64_t v230 = v74 * v70;
  // pto: %attn_norm_w__ssa_v0_view
  int64_t v231 = v229 * v230;
  // pto: %attn_norm_w__ssa_v0_view
  int64_t v232 = v228 * v231;
  // pto: %attn_norm_w__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v233 = pto::Shape<1, 1, 1, 1, -1>(v226, v227, v228, v229, v74);
  // pto: %attn_norm_w__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v234 = pto::Stride<-1, -1, -1, -1, -1>(v227 * v232, v232, v231, v230, v70);
  // pto: %attn_norm_w__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v235 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v25, v233, v234);
  // pto: %spmd_accum_read__ssa_v0_view
  const int64_t v236 = 1;
  // pto: %spmd_accum_read__ssa_v0_view
  const int64_t v237 = 1;
  // pto: %spmd_accum_read__ssa_v0_view
  const int64_t v238 = 1;
  // pto: %spmd_accum_read__ssa_v0_view
  int64_t v239 = (int64_t) v35;
  // pto: %spmd_accum_read__ssa_v0_view
  int64_t v240 = v239 * v75;
  // pto: %spmd_accum_read__ssa_v0_view
  int64_t v241 = v238 * v240;
  // pto: %spmd_accum_read__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v242 = pto::Shape<1, 1, 1, -1, -1>(v236, v237, v238, v239, v75);
  // pto: %spmd_accum_read__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v243 = pto::Stride<-1, -1, -1, -1, -1>(v237 * v241, v241, v240, v75, v70);
  // pto: %spmd_accum_read__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v244 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v26, v242, v243);
  // pto: %projected_kv__ssa_v0_view
  const int64_t v245 = 1;
  // pto: %projected_kv__ssa_v0_view
  const int64_t v246 = 1;
  // pto: %projected_kv__ssa_v0_view
  const int64_t v247 = 1;
  // pto: %projected_kv__ssa_v0_view
  int64_t v248 = (int64_t) v32;
  // pto: %projected_kv__ssa_v0_view
  int64_t v249 = v248 * v75;
  // pto: %projected_kv__ssa_v0_view
  int64_t v250 = v247 * v249;
  // pto: %projected_kv__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v251 = pto::Shape<1, 1, 1, -1, -1>(v245, v246, v247, v248, v75);
  // pto: %projected_kv__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v252 = pto::Stride<-1, -1, -1, -1, -1>(v246 * v250, v250, v249, v75, v70);
  // pto: %projected_kv__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v253 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v27, v251, v252);
  // pto: %spmd_idx_accum_read__ssa_v0_view
  const int64_t v254 = 1;
  // pto: %spmd_idx_accum_read__ssa_v0_view
  const int64_t v255 = 1;
  // pto: %spmd_idx_accum_read__ssa_v0_view
  const int64_t v256 = 1;
  // pto: %spmd_idx_accum_read__ssa_v0_view
  int64_t v257 = (int64_t) v34;
  // pto: %spmd_idx_accum_read__ssa_v0_view
  int64_t v258 = v257 * v76;
  // pto: %spmd_idx_accum_read__ssa_v0_view
  int64_t v259 = v256 * v258;
  // pto: %spmd_idx_accum_read__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v260 = pto::Shape<1, 1, 1, -1, -1>(v254, v255, v256, v257, v76);
  // pto: %spmd_idx_accum_read__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v261 = pto::Stride<-1, -1, -1, -1, -1>(v255 * v259, v259, v258, v76, v70);
  // pto: %spmd_idx_accum_read__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v262 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v28, v260, v261);
  // pto: %indexer_raw__ssa_v0_view
  const int64_t v263 = 1;
  // pto: %indexer_raw__ssa_v0_view
  const int64_t v264 = 1;
  // pto: %indexer_raw__ssa_v0_view
  const int64_t v265 = 1;
  // pto: %indexer_raw__ssa_v0_view
  int64_t v266 = (int64_t) v32;
  // pto: %indexer_raw__ssa_v0_view
  int64_t v267 = v266 * v76;
  // pto: %indexer_raw__ssa_v0_view
  int64_t v268 = v265 * v267;
  // pto: %indexer_raw__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v269 = pto::Shape<1, 1, 1, -1, -1>(v263, v264, v265, v266, v76);
  // pto: %indexer_raw__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v270 = pto::Stride<-1, -1, -1, -1, -1>(v264 * v268, v268, v267, v76, v70);
  // pto: %indexer_raw__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v271 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v29, v269, v270);
  // pto: %indexer_scaled__ssa_v0_view
  const int64_t v272 = 1;
  // pto: %indexer_scaled__ssa_v0_view
  const int64_t v273 = 1;
  // pto: %indexer_scaled__ssa_v0_view
  const int64_t v274 = 1;
  // pto: %indexer_scaled__ssa_v0_view
  int64_t v275 = (int64_t) v32;
  // pto: %indexer_scaled__ssa_v0_view
  int64_t v276 = v275 * v76;
  // pto: %indexer_scaled__ssa_v0_view
  int64_t v277 = v274 * v276;
  // pto: %indexer_scaled__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v278 = pto::Shape<1, 1, 1, -1, -1>(v272, v273, v274, v275, v76);
  // pto: %indexer_scaled__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v279 = pto::Stride<-1, -1, -1, -1, -1>(v273 * v277, v277, v276, v76, v70);
  // pto: %indexer_scaled__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v280 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v30, v278, v279);
  // pto: %indexer_weights__ssa_v0_view
  const int64_t v281 = 1;
  // pto: %indexer_weights__ssa_v0_view
  const int64_t v282 = 1;
  // pto: %indexer_weights__ssa_v0_view
  const int64_t v283 = 1;
  // pto: %indexer_weights__ssa_v0_view
  int64_t v284 = (int64_t) v32;
  // pto: %indexer_weights__ssa_v0_view
  int64_t v285 = v284 * v76;
  // pto: %indexer_weights__ssa_v0_view
  int64_t v286 = v283 * v285;
  // pto: %indexer_weights__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v287 = pto::Shape<1, 1, 1, -1, -1>(v281, v282, v283, v284, v76);
  // pto: %indexer_weights__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v288 = pto::Stride<-1, -1, -1, -1, -1>(v282 * v286, v286, v285, v76, v70);
  // pto: %indexer_weights__ssa_v0_view
  GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v289 = GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v31, v287, v288);
  uint64_t v290 = reinterpret_cast<uint64_t>(v10);
  set_ffts_base_addr(v290);
  // pto: %t__tmp_v0, %90, %91, %t__tmp_v1
  int64_t v291 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v37) * (uint64_t) v80) + (uint64_t) ((int64_t) v39));
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  set_flag(PIPE_S, PIPE_V, EVENT_ID5);
  for (int64_t v292 = v291; v292 < v32; v292 += v81) {
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    for (int64_t v293 = v82; v293 < v73; v293 += v80) {
      // pto: %92
      ;
      int64_t v294 = (int64_t) ((uint64_t) v293 * (uint64_t) v75);
      // pto: %94
      ;
      int64_t v295 = (int64_t) ((uint64_t) v294 + (uint64_t) v75);
      // pto: %t__tile
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v296 = Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
      // pto: %t__tile
      ;
      uint64_t v297 = (uint64_t) v45;
      TASSIGN(v296, v297);
      // pto: %95
      ;
      int64_t v298 = v292 < v82 ? v82 : v292;
      // pto: %96
      ;
      int64_t v299 = v294 < v82 ? v82 : v294;
      // pto: %flat_hc__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v300 = PTOAS__GLOBAL_TENSOR_DATA(v145);
      // pto: %flat_hc__ssa_v0_pview
      ;
      const int64_t v301 = 0;
      // pto: %flat_hc__ssa_v0_pview
      ;
      const int64_t v302 = 16384;
      // pto: %flat_hc__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v303 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %flat_hc__ssa_v0_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v304 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %flat_hc__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v305 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v300 + (v301 + v298 * v302 + v299), v303, v304);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      TLOAD(v296, v305);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %0
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v306 = Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
      // pto: %0
      ;
      uint64_t v307 = (uint64_t) v46;
      TASSIGN(v306, v307);
      // pto: %98
      ;
      int64_t v308 = v295 < v82 ? v82 : v295;
      // pto: %99
      ;
      __gm__ bfloat16_t* v309 = PTOAS__GLOBAL_TENSOR_DATA(v145);
      // pto: %99
      ;
      const int64_t v310 = 0;
      // pto: %99
      ;
      const int64_t v311 = 16384;
      // pto: %99
      ;
      pto::Shape<1, 1, 1, 1, 512> v312 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %99
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v313 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %99
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v314 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v309 + (v310 + v298 * v311 + v308), v312, v313);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      TLOAD(v306, v314);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %value_inline9726__tile
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
      // pto: %value_inline9726__tile
      ;
      uint64_t v316 = (uint64_t) v47;
      TASSIGN(v315, v316);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      RoundMode v317 = RoundMode::CAST_ROUND;
      SaturationMode v318 = SaturationMode::ON;
      TCVT(v315, v296, v317, v318);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      // pto: %wide__iter_v3_pview
      ;
      __gm__ float* v319 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %wide__iter_v3_pview
      ;
      const int64_t v320 = 0;
      // pto: %wide__iter_v3_pview
      ;
      const int64_t v321 = 16384;
      // pto: %wide__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v322 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %wide__iter_v3_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v323 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %wide__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v324 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v319 + (v320 + v298 * v321 + v299), v322, v323);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v324, v315);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      // pto: %1
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v325 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
      // pto: %1
      ;
      uint64_t v326 = (uint64_t) v48;
      TASSIGN(v325, v326);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      RoundMode v327 = RoundMode::CAST_ROUND;
      SaturationMode v328 = SaturationMode::ON;
      TCVT(v325, v306, v327, v328);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      // pto: %wide__tile_pview
      ;
      __gm__ float* v329 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %wide__tile_pview
      ;
      const int64_t v330 = 0;
      // pto: %wide__tile_pview
      ;
      const int64_t v331 = 16384;
      // pto: %wide__tile_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v332 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %wide__tile_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v333 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %wide__tile_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v334 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v329 + (v330 + v298 * v331 + v308), v332, v333);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v334, v325);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    };
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %105
  int64_t v335 = (int64_t) ((uint64_t) v36 - (uint64_t) v79);
  // pto: %106, %107
  int64_t v336 = (int64_t) ((uint64_t) v32 + (uint64_t) v83) / v79;
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  for (int64_t v337 = v291; v337 < v336; v337 += v81) {
    // pto: %108
    ;
    int64_t v338 = (int64_t) ((uint64_t) v337 * (uint64_t) v79);
    // pto: %rms_lanes_inline9737__ci_tmp_v0
    ;
    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v339 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v84);
    // pto: %rms_lanes_inline9737__ci_tmp_v0
    ;
    uint64_t v340 = (uint64_t) v47;
    TASSIGN(v339, v340);
    // pto: %rms_lanes_inline9737__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v341 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_lanes_inline9737__tile
    ;
    uint64_t v342 = (uint64_t) v48;
    TASSIGN(v341, v342);
    // pto: %ci_tmp_view
    ;
    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v343;
    TRESHAPE(v343, v339);
    // pto: %ci_dst_view
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v344;
    TRESHAPE(v344, v341);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    TCI<Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v344, v85, v343);
    // pto: %rms_rows_inline9741__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v345 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_rows_inline9741__tile
    ;
    uint64_t v346 = (uint64_t) v47;
    TASSIGN(v345, v346);
    // pto: %109
    ;
    int32_t v347 = (int32_t) v338;
    pipe_barrier(PIPE_V);
    TADDS(v345, v341, v347);
    // pto: %rms_local_inline9742__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v348 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_local_inline9742__tile
    ;
    uint64_t v349 = (uint64_t) v48;
    TASSIGN(v348, v349);
    // pto: %110, %111
    ;
    int32_t v350 = (int32_t) (v338 % v71);
    pipe_barrier(PIPE_V);
    TADDS(v348, v341, v350);
    // pto: %2
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v351 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %2
    ;
    uint64_t v352 = (uint64_t) v47;
    TASSIGN(v351, v352);
    TMULS(v351, v345, v86);
    // pto: %rms_index_inline9740__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v353 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_index_inline9740__tile
    ;
    uint64_t v354 = (uint64_t) v47;
    TASSIGN(v353, v354);
    pipe_barrier(PIPE_V);
    TADD(v353, v351, v348);
    set_flag(PIPE_V, PIPE_S, EVENT_ID1);
    // pto: %rms_total_inline9743__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v355 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_total_inline9743__tile
    ;
    uint64_t v356 = (uint64_t) v48;
    TASSIGN(v355, v356);
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    const int64_t v357 = 0;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    __gm__ float* v358 = PTOAS__GLOBAL_TENSOR_DATA(v154);
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    const int64_t v359 = 1;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    const int64_t v360 = 1;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    const int64_t v361 = 1;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    int64_t v362 = (int64_t) v33;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    int64_t v363 = v362 * v71;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    int64_t v364 = v361 * v363;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 16> v365 = pto::Shape<1, 1, 1, -1, 16>(v359, v360, v361, v362, v71);
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v366 = pto::Stride<-1, -1, -1, -1, -1>(v360 * v364, v364, v363, v71, v70);
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v367 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v358 + (v357 + v82 * v71 + v82 * v70), v365, v366);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID1);
    MGATHER<pto::Coalesce::Elem>(v355, v367, v353);
    set_flag(PIPE_S, PIPE_V, EVENT_ID2);
    for (int64_t v368 = v70; v368 < v87; v368 += v70) {
      // pto: %rms_part_index_inline9746__tile
      ;
      Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v369 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %rms_part_index_inline9746__tile
      ;
      uint64_t v370 = (uint64_t) v45;
      TASSIGN(v369, v370);
      // pto: %112, %113, %114
      ;
      int32_t v371 = (int32_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v368 * (uint64_t) v335) * (uint64_t) v71);
      pipe_barrier(PIPE_V);
      TADDS(v369, v353, v371);
      set_flag(PIPE_V, PIPE_S, EVENT_ID2);
      // pto: %rms_value_inline9735__tile
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v372 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %rms_value_inline9735__tile
      ;
      uint64_t v373 = (uint64_t) v46;
      TASSIGN(v372, v373);
      wait_flag(PIPE_V, PIPE_S, EVENT_ID2);
      MGATHER<pto::Coalesce::Elem>(v372, v367, v369);
      set_flag(PIPE_S, PIPE_V, EVENT_ID1);
      // pto: %3
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v374 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %3
      ;
      uint64_t v375 = (uint64_t) v48;
      TASSIGN(v374, v375);
      wait_flag(PIPE_S, PIPE_V, EVENT_ID1);
      TADD(v374, v355, v372);
    };
    // pto: %4
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v376 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %4
    ;
    uint64_t v377 = (uint64_t) v47;
    TASSIGN(v376, v377);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID2);
    TMULS(v376, v355, v88);
    // pto: %rms_variance_inline9733__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v378 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_variance_inline9733__tile
    ;
    uint64_t v379 = (uint64_t) v47;
    TASSIGN(v378, v379);
    pipe_barrier(PIPE_V);
    TADDS(v378, v376, v89);
    // pto: %rms_root_inline9732__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v380 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_root_inline9732__tile
    ;
    uint64_t v381 = (uint64_t) v47;
    TASSIGN(v380, v381);
    pipe_barrier(PIPE_V);
    TSQRT(v380, v378);
    // pto: %5
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v382 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %5
    ;
    uint64_t v383 = (uint64_t) v48;
    TASSIGN(v382, v383);
    TEXPANDS(v382, v90);
    // pto: %native_inverse_inline9731__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v384 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %native_inverse_inline9731__tile
    ;
    uint64_t v385 = (uint64_t) v47;
    TASSIGN(v384, v385);
    pipe_barrier(PIPE_V);
    TDIV(v384, v382, v380);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
    // pto: %116
    ;
    int64_t v386 = v338 < v82 ? v82 : v338;
    // pto: %vec_ws__iter_v1_pview
    ;
    __gm__ float* v387 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %vec_ws__iter_v1_pview
    ;
    const int64_t v388 = 40;
    // pto: %vec_ws__iter_v1_pview
    ;
    const int64_t v389 = 64;
    // pto: %vec_ws__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v390 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %vec_ws__iter_v1_pview
    ;
    pto::Stride<64, 64, 64, 64, 1> v391 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %vec_ws__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v392 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v387 + (v388 + v386 * v389), v390, v391);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
    TSTORE(v392, v384);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  // pto: %117
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  if (v32 >= v76) {
    // pto: %119, %120, %121
    ;
    for (int64_t v393 = v291; v393 < ((int64_t) ((uint64_t) (v34 / v71) * (uint64_t) v76) / v77); v393 += v81) {
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      for (int64_t v394 = v82; v394 < v77; v394 += v70) {
        // pto: %122, %123
        ;
        int64_t v395 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v393 * (uint64_t) v77) + (uint64_t) v394);
        // pto: %124, %125
        ;
        int64_t v396 = (int64_t) ((uint64_t) (v395 / v76) * (uint64_t) v71);
        // pto: %126
        ;
        int64_t v397 = v395 % v76;
        // pto: %127
        ;
        int64_t v398 = (int64_t) ((uint64_t) v397 * (uint64_t) v91);
        // pto: %128
        ;
        int64_t v399 = (int64_t) ((uint64_t) v32 - (uint64_t) v396);
        // pto: %129
        ;
        int64_t v400 = v399 < v71 ? v399 : v71;
        // pto: %panel64_values_inline9762__ssa_v0
        ;
        Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v401 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v400, v91);
        // pto: %panel64_values_inline9762__ssa_v0
        ;
        uint64_t v402 = (uint64_t) v47;
        TASSIGN(v401, v402);
        // pto: %130
        ;
        int64_t v403 = v396 < v82 ? v82 : v396;
        // pto: %131
        ;
        int64_t v404 = v398 < v82 ? v82 : v398;
        // pto: %wide_v1__ssa_v0_pview
        ;
        const int64_t v405 = 0;
        // pto: %wide_v1__ssa_v0_pview
        ;
        __gm__ float* v406 = PTOAS__GLOBAL_TENSOR_DATA(v118);
        // pto: %wide_v1__ssa_v0_pview
        ;
        const int64_t v407 = 1;
        // pto: %wide_v1__ssa_v0_pview
        ;
        const int64_t v408 = 1;
        // pto: %wide_v1__ssa_v0_pview
        ;
        const int64_t v409 = 1;
        // pto: %wide_v1__ssa_v0_pview
        ;
        int64_t v410 = v400 * v69;
        // pto: %wide_v1__ssa_v0_pview
        ;
        int64_t v411 = v409 * v410;
        // pto: %wide_v1__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v412 = pto::Shape<1, 1, 1, -1, 256>(v407, v408, v409, v400, v91);
        // pto: %wide_v1__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v413 = pto::Stride<-1, -1, -1, -1, -1>(v408 * v411, v411, v410, v69, v70);
        // pto: %wide_v1__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v414 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v406 + (v405 + v403 * v69 + v404 * v70), v412, v413);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        TLOAD(v401, v414);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        set_flag(PIPE_MTE2, PIPE_S, EVENT_ID1);
        wait_flag(PIPE_MTE2, PIPE_S, EVENT_ID1);
        for (int64_t v415 = v400; v415 < v71; v415 += v70) {
          for (int64_t v416 = v82; v416 < v91; v416 += v70) {
            // pto: %flat_offset_mul, %flat_offset
            ;
            int64_t v417 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v415 * (uint64_t) v91) + (uint64_t) v416);
            v401.SetValue(v417, v92);
          };
        };
        set_flag(PIPE_S, PIPE_V, EVENT_ID3);
        v401.SetValidShape(v71, v91);
        // pto: %panel64_values_v2_inline9764__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v418 = Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v91);
        // pto: %panel64_values_v2_inline9764__ssa_v0
        ;
        uint64_t v419 = (uint64_t) v47;
        TASSIGN(v418, v419);
        wait_flag(PIPE_S, PIPE_V, EVENT_ID3);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v420 = RoundMode::CAST_ROUND;
        SaturationMode v421 = SaturationMode::ON;
        TCVT(v418, v401, v420, v421);
        // pto: %transpose_tmp
        ;
        Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v422 = Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v91);
        // pto: %transpose_tmp
        ;
        uint64_t v423 = (uint64_t) v48;
        TASSIGN(v422, v423);
        // pto: %panel64_transposed_values_inline9749__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v424 = Tile<TileType::Vec, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v91, v71);
        // pto: %panel64_transposed_values_inline9749__ssa_v0
        ;
        uint64_t v425 = (uint64_t) v45;
        TASSIGN(v424, v425);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
        TTRANS(v424, v418, v422);
        // pto: %panel64_packed_transposed_inline9747__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v426 = Tile<TileType::Vec, bfloat16_t, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v75, v71);
        // pto: %panel64_packed_transposed_inline9747__ssa_v0
        ;
        uint64_t v427 = (uint64_t) v47;
        TASSIGN(v426, v427);
        pipe_barrier(PIPE_V);
        TEXPANDS(v426, v93);
        for (int64_t v428 = v82; v428 < v73; v428 += v70) {
          // pto: %panel64_input8_inline9748__ssa_v0
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v429 = Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v71);
          // pto: %panel64_input8_inline9748__ssa_v0
          ;
          uint64_t v430 = (uint64_t) v45;
          TASSIGN(v429, v430);
          // pto: %slice_view
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v431;
          // pto: %136, %slice_view
          ;
          uint64_t v432 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v428 * (uint64_t) v79) * (uint64_t) v60) + (uint64_t) v45);
          TASSIGN(v431, v432);
          // pto: %137
          ;
          int64_t v433 = (int64_t) ((uint64_t) v428 * (uint64_t) v71);
          // pto: %assemble_view
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v434;
          // pto: %assemble_view
          ;
          uint64_t v435 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v433 * (uint64_t) v60) + (uint64_t) v47);
          TASSIGN(v434, v435);
          pipe_barrier(PIPE_V);
          TMOV(v434, v431);
          // pto: %140
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v436;
          // pto: %139, %140
          ;
          uint64_t v437 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v433 + (uint64_t) v79) * (uint64_t) v60) + (uint64_t) v47);
          TASSIGN(v436, v437);
          pipe_barrier(PIPE_V);
          TMOV(v436, v431);
        };
        // pto: %6
        ;
        Tile<TileType::Vec, bfloat16_t, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v438 = Tile<TileType::Vec, bfloat16_t, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v75, v71);
        // pto: %6
        ;
        uint64_t v439 = (uint64_t) v48;
        TASSIGN(v438, v439);
        // pto: %panel64_packed_values_inline9759__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v440 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v75);
        // pto: %panel64_packed_values_inline9759__ssa_v0
        ;
        uint64_t v441 = (uint64_t) v45;
        TASSIGN(v440, v441);
        pipe_barrier(PIPE_V);
        TTRANS(v440, v426, v438);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        int64_t v442 = (int64_t) ((uint64_t) v397 * (uint64_t) v75);
        // pto: %143
        ;
        int64_t v443 = v442 < v82 ? v82 : v442;
        // pto: %packed_flat__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v444 = PTOAS__GLOBAL_TENSOR_DATA(v127);
        // pto: %packed_flat__ssa_v0_pview
        ;
        const int64_t v445 = 0;
        // pto: %packed_flat__ssa_v0_pview
        ;
        const int64_t v446 = 32768;
        // pto: %packed_flat__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 16, 512> v447 = pto::Shape<1, 1, 1, 16, 512>();
        // pto: %packed_flat__ssa_v0_pview
        ;
        pto::Stride<524288, 524288, 524288, 32768, 1> v448 = pto::Stride<524288, 524288, 524288, 32768, 1>();
        // pto: %packed_flat__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND> v449 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND>(v444 + (v445 + v403 * v446 + v443), v447, v448);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        TSTORE(v449, v440);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      };
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    };
  } else {
    // pto: %145, %146
    ;
    for (int64_t v450 = v291; v450 < ((int64_t) ((uint64_t) (v34 / v71) * (uint64_t) v76)); v450 += v81) {
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      // pto: %150, %151
      ;
      int64_t v451 = (int64_t) ((uint64_t) (v450 / v76) * (uint64_t) v71);
      // pto: %152
      ;
      int64_t v452 = v450 % v76;
      // pto: %153
      ;
      int64_t v453 = (int64_t) ((uint64_t) v452 * (uint64_t) v91);
      // pto: %154
      ;
      int64_t v454 = (int64_t) ((uint64_t) v32 - (uint64_t) v451);
      // pto: %155
      ;
      int64_t v455 = v454 < v71 ? v454 : v71;
      // pto: %panel64_values_inline9781__ssa_v0
      ;
      Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v456 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v455, v91);
      // pto: %panel64_values_inline9781__ssa_v0
      ;
      uint64_t v457 = (uint64_t) v47;
      TASSIGN(v456, v457);
      // pto: %156
      ;
      int64_t v458 = v451 < v82 ? v82 : v451;
      // pto: %157
      ;
      int64_t v459 = v453 < v82 ? v82 : v453;
      // pto: %160
      ;
      const int64_t v460 = 0;
      // pto: %160
      ;
      __gm__ float* v461 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %160
      ;
      const int64_t v462 = 1;
      // pto: %160
      ;
      const int64_t v463 = 1;
      // pto: %160
      ;
      const int64_t v464 = 1;
      // pto: %160
      ;
      int64_t v465 = v455 * v69;
      // pto: %160
      ;
      int64_t v466 = v464 * v465;
      // pto: %160
      ;
      pto::Shape<1, 1, 1, -1, 256> v467 = pto::Shape<1, 1, 1, -1, 256>(v462, v463, v464, v455, v91);
      // pto: %160
      ;
      pto::Stride<-1, -1, -1, -1, -1> v468 = pto::Stride<-1, -1, -1, -1, -1>(v463 * v466, v466, v465, v69, v70);
      // pto: %160
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v469 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v461 + (v460 + v458 * v69 + v459 * v70), v467, v468);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      TLOAD(v456, v469);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      set_flag(PIPE_MTE2, PIPE_S, EVENT_ID2);
      wait_flag(PIPE_MTE2, PIPE_S, EVENT_ID2);
      for (int64_t v470 = v455; v470 < v71; v470 += v70) {
        for (int64_t v471 = v82; v471 < v91; v471 += v70) {
          // pto: %163, %164
          ;
          int64_t v472 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v470 * (uint64_t) v91) + (uint64_t) v471);
          v456.SetValue(v472, v92);
        };
      };
      set_flag(PIPE_S, PIPE_V, EVENT_ID4);
      v456.SetValidShape(v71, v91);
      // pto: %7
      ;
      Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v473 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v91);
      // pto: %7
      ;
      uint64_t v474 = (uint64_t) v48;
      TASSIGN(v473, v474);
      // pto: %panel64_transposed_values_inline9776__ssa_v0
      ;
      Tile<TileType::Vec, float, 256, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v475 = Tile<TileType::Vec, float, 256, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v91, v71);
      // pto: %panel64_transposed_values_inline9776__ssa_v0
      ;
      uint64_t v476 = (uint64_t) v45;
      TASSIGN(v475, v476);
      wait_flag(PIPE_S, PIPE_V, EVENT_ID4);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      TTRANS(v475, v456, v473);
      // pto: %panel64_packed_transposed_inline9779__ssa_v0
      ;
      Tile<TileType::Vec, float, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v477 = Tile<TileType::Vec, float, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v75, v71);
      // pto: %panel64_packed_transposed_inline9779__ssa_v0
      ;
      uint64_t v478 = (uint64_t) v47;
      TASSIGN(v477, v478);
      pipe_barrier(PIPE_V);
      TEXPANDS(v477, v92);
      for (int64_t v479 = v82; v479 < v73; v479 += v70) {
        // pto: %panel64_input8_inline9772__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v480 = Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v71);
        // pto: %panel64_input8_inline9772__ssa_v0
        ;
        uint64_t v481 = (uint64_t) v45;
        TASSIGN(v480, v481);
        // pto: %166
        ;
        Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v482;
        // pto: %165, %166
        ;
        uint64_t v483 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v479 * (uint64_t) v79) * (uint64_t) v61) + (uint64_t) v45);
        TASSIGN(v482, v483);
        // pto: %167
        ;
        int64_t v484 = (int64_t) ((uint64_t) v479 * (uint64_t) v71);
        // pto: %168
        ;
        Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v485;
        // pto: %168
        ;
        uint64_t v486 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v484 * (uint64_t) v61) + (uint64_t) v47);
        TASSIGN(v485, v486);
        pipe_barrier(PIPE_V);
        TMOV(v485, v482);
        // pto: %171
        ;
        Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v487;
        // pto: %170, %171
        ;
        uint64_t v488 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v484 + (uint64_t) v79) * (uint64_t) v61) + (uint64_t) v47);
        TASSIGN(v487, v488);
        pipe_barrier(PIPE_V);
        TMOV(v487, v482);
      };
      // pto: %8
      ;
      Tile<TileType::Vec, float, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v489 = Tile<TileType::Vec, float, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v75, v71);
      // pto: %8
      ;
      uint64_t v490 = (uint64_t) v48;
      TASSIGN(v489, v490);
      // pto: %panel64_packed_values_inline9767__ssa_v0
      ;
      Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v491 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v75);
      // pto: %panel64_packed_values_inline9767__ssa_v0
      ;
      uint64_t v492 = (uint64_t) v45;
      TASSIGN(v491, v492);
      pipe_barrier(PIPE_V);
      TTRANS(v491, v477, v489);
      // pto: %t__tmp_v8
      ;
      Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v493 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v75);
      // pto: %t__tmp_v8
      ;
      uint64_t v494 = (uint64_t) v47;
      TASSIGN(v493, v494);
      pipe_barrier(PIPE_V);
      RoundMode v495 = RoundMode::CAST_ROUND;
      SaturationMode v496 = SaturationMode::ON;
      TCVT(v493, v491, v495, v496);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
      int64_t v497 = (int64_t) ((uint64_t) v452 * (uint64_t) v75);
      // pto: %174
      ;
      int64_t v498 = v497 < v82 ? v82 : v497;
      // pto: %175
      ;
      __gm__ bfloat16_t* v499 = PTOAS__GLOBAL_TENSOR_DATA(v127);
      // pto: %175
      ;
      const int64_t v500 = 0;
      // pto: %175
      ;
      const int64_t v501 = 32768;
      // pto: %175
      ;
      pto::Shape<1, 1, 1, 16, 512> v502 = pto::Shape<1, 1, 1, 16, 512>();
      // pto: %175
      ;
      pto::Stride<524288, 524288, 524288, 32768, 1> v503 = pto::Stride<524288, 524288, 524288, 32768, 1>();
      // pto: %175
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND> v504 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND>(v499 + (v500 + v458 * v501 + v498), v502, v503);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
      TSTORE(v504, v493);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    };
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %177
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  pipe_barrier(PIPE_ALL);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v505 = v291; v505 < (v335 / v71); v505 += v81) {
    // pto: %178
    ;
    int64_t v506 = (int64_t) ((uint64_t) v505 * (uint64_t) v71);
    // pto: %mixes_total_inline9785__tile
    ;
    Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v507 = Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v73);
    // pto: %mixes_total_inline9785__tile
    ;
    uint64_t v508 = (uint64_t) v47;
    TASSIGN(v507, v508);
    // pto: %179
    ;
    int64_t v509 = v506 < v82 ? v82 : v506;
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    __gm__ float* v510 = PTOAS__GLOBAL_TENSOR_DATA(v172);
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    const int64_t v511 = 0;
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    const int64_t v512 = 32;
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 16, 32> v513 = pto::Shape<1, 1, 1, 16, 32>();
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    pto::Stride<512, 512, 512, 32, 1> v514 = pto::Stride<512, 512, 512, 32, 1>();
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND> v515 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND>(v510 + (v511 + v509 * v512), v513, v514);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v507, v515);
    set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    for (int64_t v516 = v70; v516 < v87; v516 += v70) {
      // pto: %180, %181
      ;
      int64_t v517 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v516 * (uint64_t) v335) + (uint64_t) v506);
      // pto: %partial_tile_inline9782__tile
      ;
      Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v518 = Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v73);
      // pto: %partial_tile_inline9782__tile
      ;
      uint64_t v519 = (uint64_t) v48;
      TASSIGN(v518, v519);
      // pto: %182
      ;
      int64_t v520 = v517 < v82 ? v82 : v517;
      // pto: %183
      ;
      __gm__ float* v521 = PTOAS__GLOBAL_TENSOR_DATA(v172);
      // pto: %183
      ;
      const int64_t v522 = 0;
      // pto: %183
      ;
      const int64_t v523 = 32;
      // pto: %183
      ;
      pto::Shape<1, 1, 1, 16, 32> v524 = pto::Shape<1, 1, 1, 16, 32>();
      // pto: %183
      ;
      pto::Stride<512, 512, 512, 32, 1> v525 = pto::Stride<512, 512, 512, 32, 1>();
      // pto: %183
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND> v526 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND>(v521 + (v522 + v520 * v523), v524, v525);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      TLOAD(v518, v526);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      // pto: %9
      ;
      Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v527 = Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v73);
      // pto: %9
      ;
      uint64_t v528 = (uint64_t) v47;
      TASSIGN(v527, v528);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      TADD(v527, v507, v518);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    };
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    __gm__ float* v529 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    const int64_t v530 = 0;
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    const int64_t v531 = 64;
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 32> v532 = pto::Shape<1, 1, 1, 16, 32>();
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    pto::Stride<1024, 1024, 1024, 64, 1> v533 = pto::Stride<1024, 1024, 1024, 64, 1>();
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<1024, 1024, 1024, 64, 1>, pto::Layout::ND> v534 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<1024, 1024, 1024, 64, 1>, pto::Layout::ND>(v529 + (v530 + v509 * v531), v532, v533);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
    wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    TSTORE(v534, v507);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %scale0_inline9800__tile
  float v535 = (v18)[v82];
  // pto: %scale1_inline9801__tile
  float v536 = (v18)[v70];
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  for (int64_t v537 = v291; v537 < v336; v537 += v81) {
    // pto: %187
    ;
    int64_t v538 = (int64_t) ((uint64_t) v537 * (uint64_t) v79);
    // pto: %188
    ;
    int64_t v539 = (int64_t) ((uint64_t) v32 - (uint64_t) v538);
    // pto: %189
    ;
    int64_t v540 = v539 < v79 ? v539 : v79;
    // pto: %t__tmp_v10
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v541 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %t__tmp_v10
    ;
    uint64_t v542 = (uint64_t) v45;
    TASSIGN(v541, v542);
    // pto: %190
    ;
    int64_t v543 = v538 < v82 ? v82 : v538;
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    __gm__ float* v544 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    const int64_t v545 = 40;
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    const int64_t v546 = 64;
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v547 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    pto::Stride<64, 64, 64, 64, 1> v548 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v549 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v544 + (v545 + v543 * v546), v547, v548);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    TLOAD(v541, v549);
    // pto: %inv_col_inline9805__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v550 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %inv_col_inline9805__ssa_v0
    ;
    uint64_t v551 = (uint64_t) v45;
    TASSIGN(v550, v551);
    // pto: %t__tmp_v11
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v552 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %t__tmp_v11
    ;
    uint64_t v553 = (uint64_t) v46;
    TASSIGN(v552, v553);
    // pto: %hc_attn_base__ssa_v0_pview
    ;
    __gm__ float* v554 = PTOAS__GLOBAL_TENSOR_DATA(v182);
    // pto: %hc_attn_base__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v555 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %hc_attn_base__ssa_v0_pview
    ;
    pto::Stride<8, 8, 8, 8, 1> v556 = pto::Stride<8, 8, 8, 8, 1>();
    // pto: %hc_attn_base__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND> v557 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND>(v554, v555, v556);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    TLOAD(v552, v557);
    // pto: %pre_base_inline9797__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v558 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %pre_base_inline9797__ssa_v0
    ;
    uint64_t v559 = (uint64_t) v46;
    TASSIGN(v558, v559);
    // pto: %t__tmp_v12
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v560 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v12
    ;
    uint64_t v561 = (uint64_t) v47;
    TASSIGN(v560, v561);
    // pto: %192
    ;
    __gm__ float* v562 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %192
    ;
    const int64_t v563 = 0;
    // pto: %192
    ;
    const int64_t v564 = 64;
    // pto: %192
    ;
    pto::Shape<1, 1, 1, 8, 8> v565 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %192
    ;
    pto::Stride<512, 512, 512, 64, 1> v566 = pto::Stride<512, 512, 512, 64, 1>();
    // pto: %192
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v567 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v562 + (v563 + v543 * v564), v565, v566);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    TLOAD(v560, v567);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    // pto: %t__tmp_v13
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v568 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v13
    ;
    uint64_t v569 = (uint64_t) v47;
    TASSIGN(v568, v569);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    TROWEXPANDMUL(v568, v560, v550);
    // pto: %pre_scaled_inline9799__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v570 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %pre_scaled_inline9799__ssa_v0
    ;
    uint64_t v571 = (uint64_t) v47;
    TASSIGN(v570, v571);
    pipe_barrier(PIPE_V);
    TMULS(v570, v568, v535);
    // pto: %t__tmp_v14
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v572 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v14
    ;
    uint64_t v573 = (uint64_t) v48;
    TASSIGN(v572, v573);
    TCOLEXPAND(v572, v558);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %pre_logits_inline9804__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v574 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %pre_logits_inline9804__ssa_v0
    ;
    uint64_t v575 = (uint64_t) v47;
    TASSIGN(v574, v575);
    pipe_barrier(PIPE_V);
    TADD(v574, v570, v572);
    // pto: %t__tmp_v15
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v576 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v15
    ;
    uint64_t v577 = (uint64_t) v48;
    TASSIGN(v576, v577);
    pipe_barrier(PIPE_V);
    TEXPANDS(v576, v90);
    // pto: %t__tmp_v16
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v578 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v16
    ;
    uint64_t v579 = (uint64_t) v47;
    TASSIGN(v578, v579);
    TNEG(v578, v574);
    // pto: %t__tmp_v17
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v580 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v17
    ;
    uint64_t v581 = (uint64_t) v47;
    TASSIGN(v580, v581);
    pipe_barrier(PIPE_V);
    TEXP(v580, v578);
    // pto: %t__tmp_v18
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v582 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v18
    ;
    uint64_t v583 = (uint64_t) v47;
    TASSIGN(v582, v583);
    pipe_barrier(PIPE_V);
    TADDS(v582, v580, v90);
    // pto: %pre_sig_inline9806__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v584 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %pre_sig_inline9806__ssa_v0
    ;
    uint64_t v585 = (uint64_t) v47;
    TASSIGN(v584, v585);
    pipe_barrier(PIPE_V);
    TDIV(v584, v576, v582);
    // pto: %pre_val_inline9807__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v586 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %pre_val_inline9807__ssa_v0
    ;
    uint64_t v587 = (uint64_t) v47;
    TASSIGN(v586, v587);
    pipe_barrier(PIPE_V);
    TADDS(v586, v584, v89);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
    // pto: %194
    ;
    __gm__ float* v588 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %194
    ;
    const int64_t v589 = 32;
    // pto: %194
    ;
    const int64_t v590 = 64;
    // pto: %194
    ;
    pto::Shape<1, 1, 1, 8, 8> v591 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %194
    ;
    pto::Stride<512, 512, 512, 64, 1> v592 = pto::Stride<512, 512, 512, 64, 1>();
    // pto: %194
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v593 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v588 + (v589 + v543 * v590), v591, v592);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
    TSTORE(v593, v586);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    // pto: %t__tmp_v19
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v594 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %t__tmp_v19
    ;
    uint64_t v595 = (uint64_t) v46;
    TASSIGN(v594, v595);
    // pto: %195
    ;
    __gm__ float* v596 = PTOAS__GLOBAL_TENSOR_DATA(v182);
    // pto: %195
    ;
    unsigned v597 = 4;
    // pto: %195
    ;
    pto::Shape<1, 1, 1, 1, 8> v598 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %195
    ;
    pto::Stride<8, 8, 8, 8, 1> v599 = pto::Stride<8, 8, 8, 8, 1>();
    // pto: %195
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND> v600 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND>(v596 + v597, v598, v599);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v594, v600);
    // pto: %post_base_inline9793__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v601 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %post_base_inline9793__ssa_v0
    ;
    uint64_t v602 = (uint64_t) v46;
    TASSIGN(v601, v602);
    // pto: %t__tmp_v20
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v603 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v20
    ;
    uint64_t v604 = (uint64_t) v47;
    TASSIGN(v603, v604);
    // pto: %197
    ;
    __gm__ float* v605 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %197
    ;
    const int64_t v606 = 4;
    // pto: %197
    ;
    const int64_t v607 = 64;
    // pto: %197
    ;
    pto::Shape<1, 1, 1, 8, 8> v608 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %197
    ;
    pto::Stride<512, 512, 512, 64, 1> v609 = pto::Stride<512, 512, 512, 64, 1>();
    // pto: %197
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v610 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v605 + (v606 + v543 * v607), v608, v609);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    TLOAD(v603, v610);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
    // pto: %t__tmp_v21
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v611 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v21
    ;
    uint64_t v612 = (uint64_t) v47;
    TASSIGN(v611, v612);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
    TROWEXPANDMUL(v611, v603, v550);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    // pto: %post_scaled_inline9798__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v613 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %post_scaled_inline9798__ssa_v0
    ;
    uint64_t v614 = (uint64_t) v47;
    TASSIGN(v613, v614);
    pipe_barrier(PIPE_V);
    TMULS(v613, v611, v536);
    // pto: %t__tmp_v22
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v615 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v22
    ;
    uint64_t v616 = (uint64_t) v48;
    TASSIGN(v615, v616);
    TCOLEXPAND(v615, v601);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    // pto: %post_logits_inline9792__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v617 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %post_logits_inline9792__ssa_v0
    ;
    uint64_t v618 = (uint64_t) v47;
    TASSIGN(v617, v618);
    pipe_barrier(PIPE_V);
    TADD(v617, v613, v615);
    // pto: %t__tmp_v23
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v619 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v23
    ;
    uint64_t v620 = (uint64_t) v48;
    TASSIGN(v619, v620);
    pipe_barrier(PIPE_V);
    TEXPANDS(v619, v90);
    // pto: %t__tmp_v24
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v621 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v24
    ;
    uint64_t v622 = (uint64_t) v47;
    TASSIGN(v621, v622);
    TNEG(v621, v617);
    // pto: %t__tmp_v25
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v623 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v25
    ;
    uint64_t v624 = (uint64_t) v47;
    TASSIGN(v623, v624);
    pipe_barrier(PIPE_V);
    TEXP(v623, v621);
    // pto: %t__tmp_v26
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v625 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v26
    ;
    uint64_t v626 = (uint64_t) v47;
    TASSIGN(v625, v626);
    pipe_barrier(PIPE_V);
    TADDS(v625, v623, v90);
    // pto: %post_sig_inline9791__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v627 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %post_sig_inline9791__ssa_v0
    ;
    uint64_t v628 = (uint64_t) v47;
    TASSIGN(v627, v628);
    pipe_barrier(PIPE_V);
    TDIV(v627, v619, v625);
    // pto: %post_pad_inline9790__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v629 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %post_pad_inline9790__ssa_v0
    ;
    uint64_t v630 = (uint64_t) v47;
    TASSIGN(v629, v630);
    pipe_barrier(PIPE_V);
    TMULS(v629, v627, v94);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
    // pto: %198
    ;
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    if (v540 == v79) {
      // pto: %t__tmp_v27
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v631 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v77);
      // pto: %t__tmp_v27
      ;
      uint64_t v632 = (uint64_t) v47;
      TASSIGN(v631, v632);
      // pto: %199
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, 8, 4, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v633;
      // pto: %199
      ;
      uint64_t v634 = (uint64_t) v47;
      TASSIGN(v633, v634);
      // pto: %post__ssa_v0_pview
      ;
      __gm__ float* v635 = PTOAS__GLOBAL_TENSOR_DATA(v199);
      // pto: %post__ssa_v0_pview
      ;
      const int64_t v636 = 0;
      // pto: %post__ssa_v0_pview
      ;
      const int64_t v637 = 4;
      // pto: %post__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 4> v638 = pto::Shape<1, 1, 1, 8, 4>();
      // pto: %post__ssa_v0_pview
      ;
      pto::Stride<32, 32, 32, 4, 1> v639 = pto::Stride<32, 32, 32, 4, 1>();
      // pto: %post__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<32, 32, 32, 4, 1>, pto::Layout::ND> v640 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<32, 32, 32, 4, 1>, pto::Layout::ND>(v635 + (v636 + v543 * v637), v638, v639);
      TSTORE(v640, v633);
    } else {
      // pto: %202
      ;
      int64_t v641 = v335 < v82 ? v82 : v335;
      // pto: %203
      ;
      __gm__ float* v642 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %203
      ;
      const int64_t v643 = 0;
      // pto: %203
      ;
      const int64_t v644 = 64;
      // pto: %203
      ;
      pto::Shape<1, 1, 1, 8, 8> v645 = pto::Shape<1, 1, 1, 8, 8>();
      // pto: %203
      ;
      pto::Stride<512, 512, 512, 64, 1> v646 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %203
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v647 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v642 + (v643 + v641 * v644), v645, v646);
      TSTORE(v647, v629);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      // pto: %post_tile_inline9789__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v648 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v77);
      // pto: %post_tile_inline9789__ssa_v0
      ;
      uint64_t v649 = (uint64_t) v47;
      TASSIGN(v648, v649);
      // pto: %206
      ;
      const int64_t v650 = 0;
      // pto: %206
      ;
      __gm__ float* v651 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %206
      ;
      const int64_t v652 = 1;
      // pto: %206
      ;
      const int64_t v653 = 1;
      // pto: %206
      ;
      const int64_t v654 = 1;
      // pto: %206
      ;
      int64_t v655 = v540 * v76;
      // pto: %206
      ;
      int64_t v656 = v654 * v655;
      // pto: %206
      ;
      pto::Shape<1, 1, 1, -1, 4> v657 = pto::Shape<1, 1, 1, -1, 4>(v652, v653, v654, v540, v77);
      // pto: %206
      ;
      pto::Stride<-1, -1, -1, -1, -1> v658 = pto::Stride<-1, -1, -1, -1, -1>(v653 * v656, v656, v655, v76, v70);
      // pto: %206
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v659 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v651 + (v650 + v641 * v76 + v82 * v70), v657, v658);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      TLOAD(v648, v659);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
      // pto: %208
      ;
      const int64_t v660 = 0;
      // pto: %208
      ;
      __gm__ float* v661 = PTOAS__GLOBAL_TENSOR_DATA(v199);
      // pto: %208
      ;
      const int64_t v662 = 1;
      // pto: %208
      ;
      const int64_t v663 = 1;
      // pto: %208
      ;
      const int64_t v664 = 1;
      // pto: %208
      ;
      int64_t v665 = v540 * v77;
      // pto: %208
      ;
      int64_t v666 = v664 * v665;
      // pto: %208
      ;
      pto::Shape<1, 1, 1, -1, 4> v667 = pto::Shape<1, 1, 1, -1, 4>(v662, v663, v664, v540, v77);
      // pto: %208
      ;
      pto::Stride<-1, -1, -1, -1, -1> v668 = pto::Stride<-1, -1, -1, -1, -1>(v663 * v666, v666, v665, v77, v70);
      // pto: %208
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v669 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v661 + (v660 + v543 * v77 + v82 * v70), v667, v668);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
      TSTORE(v669, v648);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  for (int64_t v670 = v291; v670 < v336; v670 += v81) {
    // pto: %scale2_inline9843__tile
    ;
    float v671 = (v18)[v80];
    // pto: %211
    ;
    int64_t v672 = (int64_t) ((uint64_t) v670 * (uint64_t) v79);
    // pto: %212
    ;
    int64_t v673 = (int64_t) ((uint64_t) v32 - (uint64_t) v672);
    // pto: %213
    ;
    int64_t v674 = v673 < v79 ? v673 : v79;
    // pto: %t__tmp_v30
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v675 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %t__tmp_v30
    ;
    uint64_t v676 = (uint64_t) v49;
    TASSIGN(v675, v676);
    // pto: %214
    ;
    int64_t v677 = v672 < v82 ? v82 : v672;
    // pto: %215
    ;
    __gm__ float* v678 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %215
    ;
    const int64_t v679 = 40;
    // pto: %215
    ;
    const int64_t v680 = 64;
    // pto: %215
    ;
    pto::Shape<1, 1, 1, 1, 8> v681 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %215
    ;
    pto::Stride<64, 64, 64, 64, 1> v682 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %215
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v683 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v678 + (v679 + v677 * v680), v681, v682);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v675, v683);
    // pto: %t__tmp_v31
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v684 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %t__tmp_v31
    ;
    uint64_t v685 = (uint64_t) v49;
    TASSIGN(v684, v685);
    v684.SetValidShape(v674, v70);
    // pto: %mix_g0_inline9827__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v686 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
    // pto: %mix_g0_inline9827__ssa_v0
    ;
    uint64_t v687 = (uint64_t) v47;
    TASSIGN(v686, v687);
    // pto: %218
    ;
    const int64_t v688 = 0;
    // pto: %218
    ;
    __gm__ float* v689 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %218
    ;
    const int64_t v690 = 1;
    // pto: %218
    ;
    const int64_t v691 = 1;
    // pto: %218
    ;
    const int64_t v692 = 1;
    // pto: %218
    ;
    int64_t v693 = v674 * v76;
    // pto: %218
    ;
    int64_t v694 = v692 * v693;
    // pto: %218
    ;
    pto::Shape<1, 1, 1, -1, 4> v695 = pto::Shape<1, 1, 1, -1, 4>(v690, v691, v692, v674, v77);
    // pto: %218
    ;
    pto::Stride<-1, -1, -1, -1, -1> v696 = pto::Stride<-1, -1, -1, -1, -1>(v691 * v694, v694, v693, v76, v70);
    // pto: %218
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v697 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v689 + (v688 + v677 * v76 + v79 * v70), v695, v696);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    TLOAD(v686, v697);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
    // pto: %mix_g1_inline9847__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v698 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
    // pto: %mix_g1_inline9847__ssa_v0
    ;
    uint64_t v699 = (uint64_t) v48;
    TASSIGN(v698, v699);
    // pto: %222
    ;
    const int64_t v700 = 0;
    // pto: %222
    ;
    __gm__ float* v701 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %222
    ;
    const int64_t v702 = 1;
    // pto: %222
    ;
    const int64_t v703 = 1;
    // pto: %222
    ;
    const int64_t v704 = 1;
    // pto: %222
    ;
    int64_t v705 = v674 * v76;
    // pto: %222
    ;
    int64_t v706 = v704 * v705;
    // pto: %222
    ;
    pto::Shape<1, 1, 1, -1, 4> v707 = pto::Shape<1, 1, 1, -1, 4>(v702, v703, v704, v674, v77);
    // pto: %222
    ;
    pto::Stride<-1, -1, -1, -1, -1> v708 = pto::Stride<-1, -1, -1, -1, -1>(v703 * v706, v706, v705, v76, v70);
    // pto: %222
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v709 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v701 + (v700 + v677 * v76 + v95 * v70), v707, v708);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    TLOAD(v698, v709);
    // pto: %mix_g2_inline9828__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v710 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
    // pto: %mix_g2_inline9828__ssa_v0
    ;
    uint64_t v711 = (uint64_t) v45;
    TASSIGN(v710, v711);
    // pto: %226
    ;
    const int64_t v712 = 0;
    // pto: %226
    ;
    __gm__ float* v713 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %226
    ;
    const int64_t v714 = 1;
    // pto: %226
    ;
    const int64_t v715 = 1;
    // pto: %226
    ;
    const int64_t v716 = 1;
    // pto: %226
    ;
    int64_t v717 = v674 * v76;
    // pto: %226
    ;
    int64_t v718 = v716 * v717;
    // pto: %226
    ;
    pto::Shape<1, 1, 1, -1, 4> v719 = pto::Shape<1, 1, 1, -1, 4>(v714, v715, v716, v674, v77);
    // pto: %226
    ;
    pto::Stride<-1, -1, -1, -1, -1> v720 = pto::Stride<-1, -1, -1, -1, -1>(v715 * v718, v718, v717, v76, v70);
    // pto: %226
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v721 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v713 + (v712 + v677 * v76 + v71 * v70), v719, v720);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    TLOAD(v710, v721);
    // pto: %mix_g3_inline9844__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v722 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
    // pto: %mix_g3_inline9844__ssa_v0
    ;
    uint64_t v723 = (uint64_t) v46;
    TASSIGN(v722, v723);
    // pto: %230
    ;
    const int64_t v724 = 0;
    // pto: %230
    ;
    __gm__ float* v725 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %230
    ;
    const int64_t v726 = 1;
    // pto: %230
    ;
    const int64_t v727 = 1;
    // pto: %230
    ;
    const int64_t v728 = 1;
    // pto: %230
    ;
    int64_t v729 = v674 * v76;
    // pto: %230
    ;
    int64_t v730 = v728 * v729;
    // pto: %230
    ;
    pto::Shape<1, 1, 1, -1, 4> v731 = pto::Shape<1, 1, 1, -1, 4>(v726, v727, v728, v674, v77);
    // pto: %230
    ;
    pto::Stride<-1, -1, -1, -1, -1> v732 = pto::Stride<-1, -1, -1, -1, -1>(v727 * v730, v730, v729, v76, v70);
    // pto: %230
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v733 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v725 + (v724 + v677 * v76 + v44 * v70), v731, v732);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    TLOAD(v722, v733);
    // pto: %cb0_inline9845__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v734 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v77);
    // pto: %cb0_inline9845__ssa_v0
    ;
    uint64_t v735 = (uint64_t) v50;
    TASSIGN(v734, v735);
    // pto: %hc_base_2d__ssa_v0_pview
    ;
    __gm__ float* v736 = PTOAS__GLOBAL_TENSOR_DATA(v190);
    // pto: %hc_base_2d__ssa_v0_pview
    ;
    unsigned v737 = 8;
    // pto: %hc_base_2d__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 4> v738 = pto::Shape<1, 1, 1, 1, 4>();
    // pto: %hc_base_2d__ssa_v0_pview
    ;
    pto::Stride<24, 24, 24, 24, 1> v739 = pto::Stride<24, 24, 24, 24, 1>();
    // pto: %hc_base_2d__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND> v740 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND>(v736 + v737, v738, v739);
    TLOAD(v734, v740);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %cb1_inline9833__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v741 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v77);
    // pto: %cb1_inline9833__ssa_v0
    ;
    uint64_t v742 = (uint64_t) v51;
    TASSIGN(v741, v742);
    // pto: %234
    ;
    __gm__ float* v743 = PTOAS__GLOBAL_TENSOR_DATA(v190);
    // pto: %234
    ;
    unsigned v744 = 12;
    // pto: %234
    ;
    pto::Shape<1, 1, 1, 1, 4> v745 = pto::Shape<1, 1, 1, 1, 4>();
    // pto: %234
    ;
    pto::Stride<24, 24, 24, 24, 1> v746 = pto::Stride<24, 24, 24, 24, 1>();
    // pto: %234
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND> v747 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND>(v743 + v744, v745, v746);
    TLOAD(v741, v747);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %cb2_inline9834__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v748 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v77);
    // pto: %cb2_inline9834__ssa_v0
    ;
    uint64_t v749 = (uint64_t) v52;
    TASSIGN(v748, v749);
    // pto: %237
    ;
    __gm__ float* v750 = PTOAS__GLOBAL_TENSOR_DATA(v190);
    // pto: %237
    ;
    unsigned v751 = 16;
    // pto: %237
    ;
    pto::Shape<1, 1, 1, 1, 4> v752 = pto::Shape<1, 1, 1, 1, 4>();
    // pto: %237
    ;
    pto::Stride<24, 24, 24, 24, 1> v753 = pto::Stride<24, 24, 24, 24, 1>();
    // pto: %237
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND> v754 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND>(v750 + v751, v752, v753);
    TLOAD(v748, v754);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    // pto: %cb3_inline9851__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v755 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v77);
    // pto: %cb3_inline9851__ssa_v0
    ;
    uint64_t v756 = (uint64_t) v53;
    TASSIGN(v755, v756);
    // pto: %240
    ;
    __gm__ float* v757 = PTOAS__GLOBAL_TENSOR_DATA(v190);
    // pto: %240
    ;
    unsigned v758 = 20;
    // pto: %240
    ;
    pto::Shape<1, 1, 1, 1, 4> v759 = pto::Shape<1, 1, 1, 1, 4>();
    // pto: %240
    ;
    pto::Stride<24, 24, 24, 24, 1> v760 = pto::Stride<24, 24, 24, 24, 1>();
    // pto: %240
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND> v761 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND>(v757 + v758, v759, v760);
    TLOAD(v755, v761);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    // pto: %t__tmp_v32
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v762 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
    // pto: %t__tmp_v32
    ;
    uint64_t v763 = (uint64_t) v54;
    TASSIGN(v762, v763);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v762, v686, v684);
    // pto: %t__tmp_v33
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v764 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
    // pto: %t__tmp_v33
    ;
    uint64_t v765 = (uint64_t) v54;
    TASSIGN(v764, v765);
    pipe_barrier(PIPE_V);
    TMULS(v764, v762, v671);
    // pto: %t__tmp_v34
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v766 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
    // pto: %t__tmp_v34
    ;
    uint64_t v767 = (uint64_t) v47;
    TASSIGN(v766, v767);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TCOLEXPAND(v766, v734);
    // pto: %row0_inline9836__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v768 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
    // pto: %row0_inline9836__ssa_v0
    ;
    uint64_t v769 = (uint64_t) v47;
    TASSIGN(v768, v769);
    pipe_barrier(PIPE_V);
    TADD(v768, v764, v766);
    // pto: %t__tmp_v35
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v770 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
    // pto: %t__tmp_v35
    ;
    uint64_t v771 = (uint64_t) v54;
    TASSIGN(v770, v771);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v770, v698, v684);
    // pto: %t__tmp_v36
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v772 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
    // pto: %t__tmp_v36
    ;
    uint64_t v773 = (uint64_t) v54;
    TASSIGN(v772, v773);
    pipe_barrier(PIPE_V);
    TMULS(v772, v770, v671);
    // pto: %t__tmp_v37
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v774 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
    // pto: %t__tmp_v37
    ;
    uint64_t v775 = (uint64_t) v48;
    TASSIGN(v774, v775);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    TCOLEXPAND(v774, v741);
    // pto: %row1_inline9835__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v776 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
    // pto: %row1_inline9835__ssa_v0
    ;
    uint64_t v777 = (uint64_t) v48;
    TASSIGN(v776, v777);
    pipe_barrier(PIPE_V);
    TADD(v776, v772, v774);
    // pto: %t__tmp_v38
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v778 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
    // pto: %t__tmp_v38
    ;
    uint64_t v779 = (uint64_t) v54;
    TASSIGN(v778, v779);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v778, v710, v684);
    // pto: %t__tmp_v39
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v780 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
    // pto: %t__tmp_v39
    ;
    uint64_t v781 = (uint64_t) v54;
    TASSIGN(v780, v781);
    pipe_barrier(PIPE_V);
    TMULS(v780, v778, v671);
    // pto: %t__tmp_v40
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v782 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
    // pto: %t__tmp_v40
    ;
    uint64_t v783 = (uint64_t) v45;
    TASSIGN(v782, v783);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    TCOLEXPAND(v782, v748);
    // pto: %row2_inline9888__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v784 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
    // pto: %row2_inline9888__ssa_v0
    ;
    uint64_t v785 = (uint64_t) v45;
    TASSIGN(v784, v785);
    pipe_barrier(PIPE_V);
    TADD(v784, v780, v782);
    // pto: %t__tmp_v41
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v786 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
    // pto: %t__tmp_v41
    ;
    uint64_t v787 = (uint64_t) v54;
    TASSIGN(v786, v787);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v786, v722, v684);
    // pto: %t__tmp_v42
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v788 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
    // pto: %t__tmp_v42
    ;
    uint64_t v789 = (uint64_t) v54;
    TASSIGN(v788, v789);
    pipe_barrier(PIPE_V);
    TMULS(v788, v786, v671);
    // pto: %t__tmp_v43
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v790 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
    // pto: %t__tmp_v43
    ;
    uint64_t v791 = (uint64_t) v46;
    TASSIGN(v790, v791);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    TCOLEXPAND(v790, v755);
    // pto: %row3_inline9826__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v792 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
    // pto: %row3_inline9826__ssa_v0
    ;
    uint64_t v793 = (uint64_t) v46;
    TASSIGN(v792, v793);
    pipe_barrier(PIPE_V);
    TADD(v792, v788, v790);
    // pto: %row0_p_inline9832__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v794 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row0_p_inline9832__ssa_v0
    ;
    uint64_t v795 = (uint64_t) v47;
    TASSIGN(v794, v795);
    TFILLPAD<pto::TFillPadMode::InPlace>(v794, v768);
    // pto: %row1_p_inline9838__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v796 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row1_p_inline9838__ssa_v0
    ;
    uint64_t v797 = (uint64_t) v48;
    TASSIGN(v796, v797);
    TFILLPAD<pto::TFillPadMode::InPlace>(v796, v776);
    // pto: %row2_p_inline9841__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v798 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row2_p_inline9841__ssa_v0
    ;
    uint64_t v799 = (uint64_t) v45;
    TASSIGN(v798, v799);
    TFILLPAD<pto::TFillPadMode::InPlace>(v798, v784);
    // pto: %row3_p_inline9830__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v800 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row3_p_inline9830__ssa_v0
    ;
    uint64_t v801 = (uint64_t) v46;
    TASSIGN(v800, v801);
    pipe_barrier(PIPE_V);
    TFILLPAD<pto::TFillPadMode::InPlace>(v800, v792);
    // pto: %row_max_tmp_inline9825__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v802 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %row_max_tmp_inline9825__ssa_v0
    ;
    uint64_t v803 = (uint64_t) v54;
    TASSIGN(v802, v803);
    // pto: %row_sum_tmp_inline9850__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v804 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %row_sum_tmp_inline9850__ssa_v0
    ;
    uint64_t v805 = (uint64_t) v49;
    TASSIGN(v804, v805);
    // pto: %row0_max_inline9840__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v806 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row0_max_inline9840__ssa_v0
    ;
    uint64_t v807 = (uint64_t) v50;
    TASSIGN(v806, v807);
    TROWMAX(v806, v794, v802);
    // pto: %row1_max_inline9857__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v808 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row1_max_inline9857__ssa_v0
    ;
    uint64_t v809 = (uint64_t) v51;
    TASSIGN(v808, v809);
    pipe_barrier(PIPE_V);
    TROWMAX(v808, v796, v802);
    // pto: %row2_max_inline9863__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v810 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row2_max_inline9863__ssa_v0
    ;
    uint64_t v811 = (uint64_t) v52;
    TASSIGN(v810, v811);
    pipe_barrier(PIPE_V);
    TROWMAX(v810, v798, v802);
    // pto: %row3_max_inline9864__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v812 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row3_max_inline9864__ssa_v0
    ;
    uint64_t v813 = (uint64_t) v53;
    TASSIGN(v812, v813);
    pipe_barrier(PIPE_V);
    TROWMAX(v812, v800, v802);
    // pto: %t__tmp_v44
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v814 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v44
    ;
    uint64_t v815 = (uint64_t) v47;
    TASSIGN(v814, v815);
    TROWEXPANDSUB(v814, v794, v806);
    // pto: %row0_exp_inline9868__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v816 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row0_exp_inline9868__ssa_v0
    ;
    uint64_t v817 = (uint64_t) v47;
    TASSIGN(v816, v817);
    pipe_barrier(PIPE_V);
    TEXP(v816, v814);
    // pto: %t__tmp_v45
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v818 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v45
    ;
    uint64_t v819 = (uint64_t) v48;
    TASSIGN(v818, v819);
    TROWEXPANDSUB(v818, v796, v808);
    // pto: %row1_exp_inline9829__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v820 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row1_exp_inline9829__ssa_v0
    ;
    uint64_t v821 = (uint64_t) v48;
    TASSIGN(v820, v821);
    pipe_barrier(PIPE_V);
    TEXP(v820, v818);
    // pto: %t__tmp_v46
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v822 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v46
    ;
    uint64_t v823 = (uint64_t) v45;
    TASSIGN(v822, v823);
    TROWEXPANDSUB(v822, v798, v810);
    // pto: %row2_exp_inline9855__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v824 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row2_exp_inline9855__ssa_v0
    ;
    uint64_t v825 = (uint64_t) v45;
    TASSIGN(v824, v825);
    pipe_barrier(PIPE_V);
    TEXP(v824, v822);
    // pto: %t__tmp_v47
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v826 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v47
    ;
    uint64_t v827 = (uint64_t) v46;
    TASSIGN(v826, v827);
    TROWEXPANDSUB(v826, v800, v812);
    // pto: %row3_exp_inline9831__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v828 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row3_exp_inline9831__ssa_v0
    ;
    uint64_t v829 = (uint64_t) v46;
    TASSIGN(v828, v829);
    pipe_barrier(PIPE_V);
    TEXP(v828, v826);
    // pto: %row0_sum_inline9871__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v830 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row0_sum_inline9871__ssa_v0
    ;
    uint64_t v831 = (uint64_t) v54;
    TASSIGN(v830, v831);
    TROWSUM(v830, v816, v804);
    // pto: %row1_sum_inline9872__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v832 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row1_sum_inline9872__ssa_v0
    ;
    uint64_t v833 = (uint64_t) v50;
    TASSIGN(v832, v833);
    pipe_barrier(PIPE_V);
    TROWSUM(v832, v820, v804);
    // pto: %row2_sum_inline9869__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v834 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row2_sum_inline9869__ssa_v0
    ;
    uint64_t v835 = (uint64_t) v51;
    TASSIGN(v834, v835);
    pipe_barrier(PIPE_V);
    TROWSUM(v834, v824, v804);
    // pto: %row3_sum_inline9870__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v836 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row3_sum_inline9870__ssa_v0
    ;
    uint64_t v837 = (uint64_t) v52;
    TASSIGN(v836, v837);
    pipe_barrier(PIPE_V);
    TROWSUM(v836, v828, v804);
    // pto: %t__tmp_v48
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v838 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v48
    ;
    uint64_t v839 = (uint64_t) v47;
    TASSIGN(v838, v839);
    TROWEXPANDDIV(v838, v816, v830);
    // pto: %row0_soft_inline9846__ssa_v1
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v840 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row0_soft_inline9846__ssa_v1
    ;
    uint64_t v841 = (uint64_t) v47;
    TASSIGN(v840, v841);
    pipe_barrier(PIPE_V);
    TADDS(v840, v838, v89);
    // pto: %t__tmp_v49
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v842 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v49
    ;
    uint64_t v843 = (uint64_t) v48;
    TASSIGN(v842, v843);
    TROWEXPANDDIV(v842, v820, v832);
    // pto: %row1_soft_inline9877__ssa_v1
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v844 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row1_soft_inline9877__ssa_v1
    ;
    uint64_t v845 = (uint64_t) v48;
    TASSIGN(v844, v845);
    pipe_barrier(PIPE_V);
    TADDS(v844, v842, v89);
    // pto: %t__tmp_v50
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v846 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v50
    ;
    uint64_t v847 = (uint64_t) v45;
    TASSIGN(v846, v847);
    TROWEXPANDDIV(v846, v824, v834);
    // pto: %row2_soft_inline9849__ssa_v1
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v848 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row2_soft_inline9849__ssa_v1
    ;
    uint64_t v849 = (uint64_t) v45;
    TASSIGN(v848, v849);
    pipe_barrier(PIPE_V);
    TADDS(v848, v846, v89);
    // pto: %t__tmp_v51
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v850 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v51
    ;
    uint64_t v851 = (uint64_t) v46;
    TASSIGN(v850, v851);
    TROWEXPANDDIV(v850, v828, v836);
    // pto: %row3_soft_inline9881__ssa_v1
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v852 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row3_soft_inline9881__ssa_v1
    ;
    uint64_t v853 = (uint64_t) v46;
    TASSIGN(v852, v853);
    pipe_barrier(PIPE_V);
    TADDS(v852, v850, v89);
    v840.SetValidShape(v79, v77);
    v844.SetValidShape(v79, v77);
    v848.SetValidShape(v79, v77);
    v852.SetValidShape(v79, v77);
    // pto: %row0_eff_inline9837__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v854 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row0_eff_inline9837__ssa_v0
    ;
    uint64_t v855 = (uint64_t) v47;
    TASSIGN(v854, v855);
    TFILLPAD<pto::TFillPadMode::InPlace>(v854, v840);
    // pto: %row1_eff_inline9887__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v856 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row1_eff_inline9887__ssa_v0
    ;
    uint64_t v857 = (uint64_t) v48;
    TASSIGN(v856, v857);
    TFILLPAD<pto::TFillPadMode::InPlace>(v856, v844);
    // pto: %row2_eff_inline9885__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v858 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row2_eff_inline9885__ssa_v0
    ;
    uint64_t v859 = (uint64_t) v45;
    TASSIGN(v858, v859);
    TFILLPAD<pto::TFillPadMode::InPlace>(v858, v848);
    // pto: %row3_eff_inline9889__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v860 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row3_eff_inline9889__ssa_v0
    ;
    uint64_t v861 = (uint64_t) v46;
    TASSIGN(v860, v861);
    pipe_barrier(PIPE_V);
    TFILLPAD<pto::TFillPadMode::InPlace>(v860, v852);
    // pto: %row_sum_tmp_iter_inline9883__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v862 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %row_sum_tmp_iter_inline9883__ssa_v0
    ;
    uint64_t v863 = (uint64_t) v54;
    TASSIGN(v862, v863);
    // pto: %t__tmp_v52
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v864 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v52
    ;
    uint64_t v865 = (uint64_t) v49;
    TASSIGN(v864, v865);
    TADD(v864, v854, v856);
    // pto: %t__tmp_v53
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v866 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v53
    ;
    uint64_t v867 = (uint64_t) v49;
    TASSIGN(v866, v867);
    pipe_barrier(PIPE_V);
    TADD(v866, v864, v858);
    // pto: %col_sum_inline9824__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v868 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %col_sum_inline9824__ssa_v0
    ;
    uint64_t v869 = (uint64_t) v49;
    TASSIGN(v868, v869);
    pipe_barrier(PIPE_V);
    TADD(v868, v866, v860);
    // pto: %col_sum_v1_inline9823__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v870 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %col_sum_v1_inline9823__ssa_v0
    ;
    uint64_t v871 = (uint64_t) v49;
    TASSIGN(v870, v871);
    pipe_barrier(PIPE_V);
    TADDS(v870, v868, v89);
    // pto: %row0_cur_inline9852__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v872 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row0_cur_inline9852__ssa_v0
    ;
    uint64_t v873 = (uint64_t) v47;
    TASSIGN(v872, v873);
    pipe_barrier(PIPE_V);
    TDIV(v872, v854, v870);
    // pto: %row1_cur_inline9822__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v874 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row1_cur_inline9822__ssa_v0
    ;
    uint64_t v875 = (uint64_t) v48;
    TASSIGN(v874, v875);
    TDIV(v874, v856, v870);
    // pto: %row2_cur_inline9821__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v876 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row2_cur_inline9821__ssa_v0
    ;
    uint64_t v877 = (uint64_t) v45;
    TASSIGN(v876, v877);
    TDIV(v876, v858, v870);
    // pto: %row3_cur_inline9820__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v878 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row3_cur_inline9820__ssa_v0
    ;
    uint64_t v879 = (uint64_t) v46;
    TASSIGN(v878, v879);
    TDIV(v878, v860, v870);
    for (int64_t v880 = v82; v880 < v96; v880 += v80) {
      // pto: %t__tmp_v54
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v881 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %t__tmp_v54
      ;
      uint64_t v882 = (uint64_t) v49;
      TASSIGN(v881, v882);
      pipe_barrier(PIPE_V);
      TROWSUM(v881, v872, v862);
      // pto: %row0_rowsum_inline9817__rm_a0_tmp_v0
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v883 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row0_rowsum_inline9817__rm_a0_tmp_v0
      ;
      uint64_t v884 = (uint64_t) v49;
      TASSIGN(v883, v884);
      // pto: %row0_rowsum_inline9817__row_major_tmp_v1
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v885 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row0_rowsum_inline9817__row_major_tmp_v1
      ;
      uint64_t v886 = (uint64_t) v50;
      TASSIGN(v885, v886);
      pipe_barrier(PIPE_V);
      TADDS(v885, v883, v89);
      // pto: %row0_rowsum_inline9817__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v887 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %row0_rowsum_inline9817__ssa_v0
      ;
      uint64_t v888 = (uint64_t) v50;
      TASSIGN(v887, v888);
      // pto: %t__tmp_v55
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v889 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %t__tmp_v55
      ;
      uint64_t v890 = (uint64_t) v49;
      TASSIGN(v889, v890);
      pipe_barrier(PIPE_V);
      TROWSUM(v889, v874, v862);
      // pto: %row1_rowsum_inline9865__rm_a0_tmp_v2
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v891 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row1_rowsum_inline9865__rm_a0_tmp_v2
      ;
      uint64_t v892 = (uint64_t) v49;
      TASSIGN(v891, v892);
      // pto: %row1_rowsum_inline9865__row_major_tmp_v3
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v893 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row1_rowsum_inline9865__row_major_tmp_v3
      ;
      uint64_t v894 = (uint64_t) v51;
      TASSIGN(v893, v894);
      pipe_barrier(PIPE_V);
      TADDS(v893, v891, v89);
      // pto: %row1_rowsum_inline9865__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v895 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %row1_rowsum_inline9865__ssa_v0
      ;
      uint64_t v896 = (uint64_t) v51;
      TASSIGN(v895, v896);
      // pto: %t__tmp_v56
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v897 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %t__tmp_v56
      ;
      uint64_t v898 = (uint64_t) v49;
      TASSIGN(v897, v898);
      pipe_barrier(PIPE_V);
      TROWSUM(v897, v876, v862);
      // pto: %row2_rowsum_inline9816__rm_a0_tmp_v4
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v899 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row2_rowsum_inline9816__rm_a0_tmp_v4
      ;
      uint64_t v900 = (uint64_t) v49;
      TASSIGN(v899, v900);
      // pto: %row2_rowsum_inline9816__row_major_tmp_v5
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v901 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row2_rowsum_inline9816__row_major_tmp_v5
      ;
      uint64_t v902 = (uint64_t) v52;
      TASSIGN(v901, v902);
      pipe_barrier(PIPE_V);
      TADDS(v901, v899, v89);
      // pto: %row2_rowsum_inline9816__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v903 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %row2_rowsum_inline9816__ssa_v0
      ;
      uint64_t v904 = (uint64_t) v52;
      TASSIGN(v903, v904);
      // pto: %t__tmp_v57
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v905 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %t__tmp_v57
      ;
      uint64_t v906 = (uint64_t) v49;
      TASSIGN(v905, v906);
      pipe_barrier(PIPE_V);
      TROWSUM(v905, v878, v862);
      // pto: %row3_rowsum_inline9815__rm_a0_tmp_v6
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v907 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row3_rowsum_inline9815__rm_a0_tmp_v6
      ;
      uint64_t v908 = (uint64_t) v49;
      TASSIGN(v907, v908);
      // pto: %row3_rowsum_inline9815__row_major_tmp_v7
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v909 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row3_rowsum_inline9815__row_major_tmp_v7
      ;
      uint64_t v910 = (uint64_t) v53;
      TASSIGN(v909, v910);
      pipe_barrier(PIPE_V);
      TADDS(v909, v907, v89);
      // pto: %row3_rowsum_inline9815__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v911 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %row3_rowsum_inline9815__ssa_v0
      ;
      uint64_t v912 = (uint64_t) v53;
      TASSIGN(v911, v912);
      // pto: %row0_norm_inline9882__ssa_v1
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v913 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row0_norm_inline9882__ssa_v1
      ;
      uint64_t v914 = (uint64_t) v49;
      TASSIGN(v913, v914);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v913, v872, v887);
      // pto: %row1_norm_inline9814__ssa_v1
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v915 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row1_norm_inline9814__ssa_v1
      ;
      uint64_t v916 = (uint64_t) v50;
      TASSIGN(v915, v916);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v915, v874, v895);
      // pto: %row2_norm_inline9818__ssa_v1
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v917 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row2_norm_inline9818__ssa_v1
      ;
      uint64_t v918 = (uint64_t) v51;
      TASSIGN(v917, v918);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v917, v876, v903);
      // pto: %row3_norm_inline9873__ssa_v1
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v919 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row3_norm_inline9873__ssa_v1
      ;
      uint64_t v920 = (uint64_t) v52;
      TASSIGN(v919, v920);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v919, v878, v911);
      // pto: %t__tmp_v58
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v921 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %t__tmp_v58
      ;
      uint64_t v922 = (uint64_t) v53;
      TASSIGN(v921, v922);
      pipe_barrier(PIPE_V);
      TADD(v921, v913, v915);
      // pto: %t__tmp_v59
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v923 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %t__tmp_v59
      ;
      uint64_t v924 = (uint64_t) v53;
      TASSIGN(v923, v924);
      pipe_barrier(PIPE_V);
      TADD(v923, v921, v917);
      // pto: %col_sum_v1_inline9823__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v925 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %col_sum_v1_inline9823__ssa_v3
      ;
      uint64_t v926 = (uint64_t) v53;
      TASSIGN(v925, v926);
      pipe_barrier(PIPE_V);
      TADD(v925, v923, v919);
      // pto: %col_sum_v1_inline9823__ssa_v4
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v927 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %col_sum_v1_inline9823__ssa_v4
      ;
      uint64_t v928 = (uint64_t) v53;
      TASSIGN(v927, v928);
      pipe_barrier(PIPE_V);
      TADDS(v927, v925, v89);
      // pto: %row0_cur_inline9852__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v929 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row0_cur_inline9852__ssa_v3
      ;
      uint64_t v930 = (uint64_t) v49;
      TASSIGN(v929, v930);
      pipe_barrier(PIPE_V);
      TDIV(v929, v913, v927);
      // pto: %row1_cur_inline9822__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v931 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row1_cur_inline9822__ssa_v3
      ;
      uint64_t v932 = (uint64_t) v50;
      TASSIGN(v931, v932);
      TDIV(v931, v915, v927);
      // pto: %row2_cur_inline9821__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v933 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row2_cur_inline9821__ssa_v3
      ;
      uint64_t v934 = (uint64_t) v51;
      TASSIGN(v933, v934);
      TDIV(v933, v917, v927);
      // pto: %row3_cur_inline9820__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v935 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row3_cur_inline9820__ssa_v3
      ;
      uint64_t v936 = (uint64_t) v52;
      TASSIGN(v935, v936);
      TDIV(v935, v919, v927);
      // pto: %10
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v937 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %10
      ;
      uint64_t v938 = (uint64_t) v55;
      TASSIGN(v937, v938);
      pipe_barrier(PIPE_V);
      TROWSUM(v937, v929, v862);
      // pto: %11
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v939 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %11
      ;
      uint64_t v940 = (uint64_t) v55;
      TASSIGN(v939, v940);
      // pto: %12
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v941 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %12
      ;
      uint64_t v942 = (uint64_t) v56;
      TASSIGN(v941, v942);
      pipe_barrier(PIPE_V);
      TADDS(v941, v939, v89);
      // pto: %13
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v943 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %13
      ;
      uint64_t v944 = (uint64_t) v56;
      TASSIGN(v943, v944);
      // pto: %14
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v945 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %14
      ;
      uint64_t v946 = (uint64_t) v55;
      TASSIGN(v945, v946);
      pipe_barrier(PIPE_V);
      TROWSUM(v945, v931, v862);
      // pto: %15
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v947 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %15
      ;
      uint64_t v948 = (uint64_t) v55;
      TASSIGN(v947, v948);
      // pto: %16
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v949 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %16
      ;
      uint64_t v950 = (uint64_t) v57;
      TASSIGN(v949, v950);
      pipe_barrier(PIPE_V);
      TADDS(v949, v947, v89);
      // pto: %17
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v951 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %17
      ;
      uint64_t v952 = (uint64_t) v57;
      TASSIGN(v951, v952);
      // pto: %18
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v953 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %18
      ;
      uint64_t v954 = (uint64_t) v55;
      TASSIGN(v953, v954);
      pipe_barrier(PIPE_V);
      TROWSUM(v953, v933, v862);
      // pto: %19
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v955 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %19
      ;
      uint64_t v956 = (uint64_t) v55;
      TASSIGN(v955, v956);
      // pto: %20
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v957 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %20
      ;
      uint64_t v958 = (uint64_t) v58;
      TASSIGN(v957, v958);
      pipe_barrier(PIPE_V);
      TADDS(v957, v955, v89);
      // pto: %21
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v959 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %21
      ;
      uint64_t v960 = (uint64_t) v58;
      TASSIGN(v959, v960);
      // pto: %22
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v961 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %22
      ;
      uint64_t v962 = (uint64_t) v55;
      TASSIGN(v961, v962);
      pipe_barrier(PIPE_V);
      TROWSUM(v961, v935, v862);
      // pto: %23
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v963 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %23
      ;
      uint64_t v964 = (uint64_t) v55;
      TASSIGN(v963, v964);
      // pto: %24
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v965 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %24
      ;
      uint64_t v966 = (uint64_t) v59;
      TASSIGN(v965, v966);
      pipe_barrier(PIPE_V);
      TADDS(v965, v963, v89);
      // pto: %25
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v967 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %25
      ;
      uint64_t v968 = (uint64_t) v59;
      TASSIGN(v967, v968);
      // pto: %26
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v969 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %26
      ;
      uint64_t v970 = (uint64_t) v55;
      TASSIGN(v969, v970);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v969, v929, v943);
      // pto: %27
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v971 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %27
      ;
      uint64_t v972 = (uint64_t) v56;
      TASSIGN(v971, v972);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v971, v931, v951);
      // pto: %28
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v973 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %28
      ;
      uint64_t v974 = (uint64_t) v57;
      TASSIGN(v973, v974);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v973, v933, v959);
      // pto: %29
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v975 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %29
      ;
      uint64_t v976 = (uint64_t) v58;
      TASSIGN(v975, v976);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v975, v935, v967);
      // pto: %30
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v977 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %30
      ;
      uint64_t v978 = (uint64_t) v59;
      TASSIGN(v977, v978);
      pipe_barrier(PIPE_V);
      TADD(v977, v969, v971);
      // pto: %31
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v979 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %31
      ;
      uint64_t v980 = (uint64_t) v59;
      TASSIGN(v979, v980);
      pipe_barrier(PIPE_V);
      TADD(v979, v977, v973);
      // pto: %32
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v981 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %32
      ;
      uint64_t v982 = (uint64_t) v59;
      TASSIGN(v981, v982);
      pipe_barrier(PIPE_V);
      TADD(v981, v979, v975);
      // pto: %33
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v983 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %33
      ;
      uint64_t v984 = (uint64_t) v59;
      TASSIGN(v983, v984);
      pipe_barrier(PIPE_V);
      TADDS(v983, v981, v89);
      // pto: %34
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v985 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %34
      ;
      uint64_t v986 = (uint64_t) v47;
      TASSIGN(v985, v986);
      pipe_barrier(PIPE_V);
      TDIV(v985, v969, v983);
      // pto: %35
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v987 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %35
      ;
      uint64_t v988 = (uint64_t) v48;
      TASSIGN(v987, v988);
      TDIV(v987, v971, v983);
      // pto: %36
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v989 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %36
      ;
      uint64_t v990 = (uint64_t) v45;
      TASSIGN(v989, v990);
      TDIV(v989, v973, v983);
      // pto: %37
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v991 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %37
      ;
      uint64_t v992 = (uint64_t) v46;
      TASSIGN(v991, v992);
      TDIV(v991, v975, v983);
    };
    // pto: %38
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v993 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %38
    ;
    uint64_t v994 = (uint64_t) v49;
    TASSIGN(v993, v994);
    pipe_barrier(PIPE_V);
    TROWSUM(v993, v872, v862);
    // pto: %39
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v995 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %39
    ;
    uint64_t v996 = (uint64_t) v49;
    TASSIGN(v995, v996);
    // pto: %40
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v997 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %40
    ;
    uint64_t v998 = (uint64_t) v49;
    TASSIGN(v997, v998);
    pipe_barrier(PIPE_V);
    TADDS(v997, v995, v89);
    // pto: %41
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v999 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %41
    ;
    uint64_t v1000 = (uint64_t) v49;
    TASSIGN(v999, v1000);
    // pto: %42
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1001 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %42
    ;
    uint64_t v1002 = (uint64_t) v50;
    TASSIGN(v1001, v1002);
    TROWSUM(v1001, v874, v862);
    // pto: %43
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1003 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %43
    ;
    uint64_t v1004 = (uint64_t) v50;
    TASSIGN(v1003, v1004);
    // pto: %44
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1005 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %44
    ;
    uint64_t v1006 = (uint64_t) v50;
    TASSIGN(v1005, v1006);
    pipe_barrier(PIPE_V);
    TADDS(v1005, v1003, v89);
    // pto: %45
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1007 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %45
    ;
    uint64_t v1008 = (uint64_t) v50;
    TASSIGN(v1007, v1008);
    // pto: %46
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1009 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %46
    ;
    uint64_t v1010 = (uint64_t) v51;
    TASSIGN(v1009, v1010);
    TROWSUM(v1009, v876, v862);
    // pto: %47
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1011 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %47
    ;
    uint64_t v1012 = (uint64_t) v51;
    TASSIGN(v1011, v1012);
    // pto: %48
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1013 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %48
    ;
    uint64_t v1014 = (uint64_t) v51;
    TASSIGN(v1013, v1014);
    pipe_barrier(PIPE_V);
    TADDS(v1013, v1011, v89);
    // pto: %49
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1015 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %49
    ;
    uint64_t v1016 = (uint64_t) v51;
    TASSIGN(v1015, v1016);
    // pto: %50
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1017 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %50
    ;
    uint64_t v1018 = (uint64_t) v52;
    TASSIGN(v1017, v1018);
    TROWSUM(v1017, v878, v862);
    // pto: %51
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1019 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %51
    ;
    uint64_t v1020 = (uint64_t) v52;
    TASSIGN(v1019, v1020);
    // pto: %52
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1021 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %52
    ;
    uint64_t v1022 = (uint64_t) v54;
    TASSIGN(v1021, v1022);
    pipe_barrier(PIPE_V);
    TADDS(v1021, v1019, v89);
    // pto: %53
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1023 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %53
    ;
    uint64_t v1024 = (uint64_t) v54;
    TASSIGN(v1023, v1024);
    // pto: %54
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1025 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %54
    ;
    uint64_t v1026 = (uint64_t) v47;
    TASSIGN(v1025, v1026);
    TROWEXPANDDIV(v1025, v872, v999);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %55
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1027 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %55
    ;
    uint64_t v1028 = (uint64_t) v48;
    TASSIGN(v1027, v1028);
    TROWEXPANDDIV(v1027, v874, v1007);
    // pto: %56
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1029 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %56
    ;
    uint64_t v1030 = (uint64_t) v45;
    TASSIGN(v1029, v1030);
    TROWEXPANDDIV(v1029, v876, v1015);
    // pto: %57
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1031 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %57
    ;
    uint64_t v1032 = (uint64_t) v46;
    TASSIGN(v1031, v1032);
    pipe_barrier(PIPE_V);
    TROWEXPANDDIV(v1031, v878, v1023);
    // pto: %58
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1033 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %58
    ;
    uint64_t v1034 = (uint64_t) v54;
    TASSIGN(v1033, v1034);
    pipe_barrier(PIPE_V);
    TADD(v1033, v1025, v1027);
    // pto: %59
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1035 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %59
    ;
    uint64_t v1036 = (uint64_t) v54;
    TASSIGN(v1035, v1036);
    pipe_barrier(PIPE_V);
    TADD(v1035, v1033, v1029);
    // pto: %60
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1037 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %60
    ;
    uint64_t v1038 = (uint64_t) v54;
    TASSIGN(v1037, v1038);
    pipe_barrier(PIPE_V);
    TADD(v1037, v1035, v1031);
    // pto: %61
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1039 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %61
    ;
    uint64_t v1040 = (uint64_t) v54;
    TASSIGN(v1039, v1040);
    pipe_barrier(PIPE_V);
    TADDS(v1039, v1037, v89);
    // pto: %62
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1041 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %62
    ;
    uint64_t v1042 = (uint64_t) v47;
    TASSIGN(v1041, v1042);
    pipe_barrier(PIPE_V);
    TDIV(v1041, v1025, v1039);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %63
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1043 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %63
    ;
    uint64_t v1044 = (uint64_t) v48;
    TASSIGN(v1043, v1044);
    TDIV(v1043, v1027, v1039);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %64
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1045 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %64
    ;
    uint64_t v1046 = (uint64_t) v45;
    TASSIGN(v1045, v1046);
    TDIV(v1045, v1029, v1039);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
    // pto: %65
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1047 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %65
    ;
    uint64_t v1048 = (uint64_t) v46;
    TASSIGN(v1047, v1048);
    TDIV(v1047, v1031, v1039);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    // pto: %row0_cur_inline9852__rv_v2
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1049 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row0_cur_inline9852__rv_v2
    ;
    uint64_t v1050 = (uint64_t) v47;
    TASSIGN(v1049, v1050);
    // pto: %row1_cur_inline9822__rv_v2
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1051 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row1_cur_inline9822__rv_v2
    ;
    uint64_t v1052 = (uint64_t) v48;
    TASSIGN(v1051, v1052);
    // pto: %row2_cur_inline9821__rv_v2
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1053 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row2_cur_inline9821__rv_v2
    ;
    uint64_t v1054 = (uint64_t) v45;
    TASSIGN(v1053, v1054);
    // pto: %row3_cur_inline9820__rv_v2
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1055 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row3_cur_inline9820__rv_v2
    ;
    uint64_t v1056 = (uint64_t) v46;
    TASSIGN(v1055, v1056);
    // pto: %241
    ;
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
    if (v674 == v79) {
      v1049.SetValidShape(v79, v77);
      v1051.SetValidShape(v79, v77);
      v1053.SetValidShape(v79, v77);
      v1055.SetValidShape(v79, v77);
      // pto: %comb__ssa_v0_pview
      ;
      __gm__ float* v1057 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %comb__ssa_v0_pview
      ;
      const int64_t v1058 = 0;
      // pto: %comb__ssa_v0_pview
      ;
      const int64_t v1059 = 16;
      // pto: %comb__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 4> v1060 = pto::Shape<1, 1, 1, 8, 4>();
      // pto: %comb__ssa_v0_pview
      ;
      pto::Stride<128, 128, 128, 16, 1> v1061 = pto::Stride<128, 128, 128, 16, 1>();
      // pto: %comb__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND> v1062 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND>(v1057 + (v1058 + v677 * v1059), v1060, v1061);
      TSTORE(v1062, v1049);
      // pto: %244
      ;
      __gm__ float* v1063 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %244
      ;
      const int64_t v1064 = 4;
      // pto: %244
      ;
      const int64_t v1065 = 16;
      // pto: %244
      ;
      pto::Shape<1, 1, 1, 8, 4> v1066 = pto::Shape<1, 1, 1, 8, 4>();
      // pto: %244
      ;
      pto::Stride<128, 128, 128, 16, 1> v1067 = pto::Stride<128, 128, 128, 16, 1>();
      // pto: %244
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND> v1068 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND>(v1063 + (v1064 + v677 * v1065), v1066, v1067);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1068, v1051);
      // pto: %246
      ;
      __gm__ float* v1069 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %246
      ;
      const int64_t v1070 = 8;
      // pto: %246
      ;
      const int64_t v1071 = 16;
      // pto: %246
      ;
      pto::Shape<1, 1, 1, 8, 4> v1072 = pto::Shape<1, 1, 1, 8, 4>();
      // pto: %246
      ;
      pto::Stride<128, 128, 128, 16, 1> v1073 = pto::Stride<128, 128, 128, 16, 1>();
      // pto: %246
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND> v1074 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND>(v1069 + (v1070 + v677 * v1071), v1072, v1073);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1074, v1053);
      // pto: %248
      ;
      __gm__ float* v1075 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %248
      ;
      const int64_t v1076 = 12;
      // pto: %248
      ;
      const int64_t v1077 = 16;
      // pto: %248
      ;
      pto::Shape<1, 1, 1, 8, 4> v1078 = pto::Shape<1, 1, 1, 8, 4>();
      // pto: %248
      ;
      pto::Stride<128, 128, 128, 16, 1> v1079 = pto::Stride<128, 128, 128, 16, 1>();
      // pto: %248
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND> v1080 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND>(v1075 + (v1076 + v677 * v1077), v1078, v1079);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1080, v1055);
    } else {
      // pto: %250
      ;
      int64_t v1081 = v335 < v82 ? v82 : v335;
      // pto: %251
      ;
      __gm__ float* v1082 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %251
      ;
      const int64_t v1083 = 8;
      // pto: %251
      ;
      const int64_t v1084 = 64;
      // pto: %251
      ;
      pto::Shape<1, 1, 1, 8, 8> v1085 = pto::Shape<1, 1, 1, 8, 8>();
      // pto: %251
      ;
      pto::Stride<512, 512, 512, 64, 1> v1086 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %251
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v1087 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v1082 + (v1083 + v1081 * v1084), v1085, v1086);
      TSTORE(v1087, v1049);
      // pto: %254
      ;
      __gm__ float* v1088 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %254
      ;
      const int64_t v1089 = 16;
      // pto: %254
      ;
      const int64_t v1090 = 64;
      // pto: %254
      ;
      pto::Shape<1, 1, 1, 8, 8> v1091 = pto::Shape<1, 1, 1, 8, 8>();
      // pto: %254
      ;
      pto::Stride<512, 512, 512, 64, 1> v1092 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %254
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v1093 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v1088 + (v1089 + v1081 * v1090), v1091, v1092);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1093, v1051);
      // pto: %257
      ;
      __gm__ float* v1094 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %257
      ;
      const int64_t v1095 = 24;
      // pto: %257
      ;
      const int64_t v1096 = 64;
      // pto: %257
      ;
      pto::Shape<1, 1, 1, 8, 8> v1097 = pto::Shape<1, 1, 1, 8, 8>();
      // pto: %257
      ;
      pto::Stride<512, 512, 512, 64, 1> v1098 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %257
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v1099 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v1094 + (v1095 + v1081 * v1096), v1097, v1098);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1099, v1053);
      // pto: %260
      ;
      __gm__ float* v1100 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %260
      ;
      const int64_t v1101 = 32;
      // pto: %260
      ;
      const int64_t v1102 = 64;
      // pto: %260
      ;
      pto::Shape<1, 1, 1, 8, 8> v1103 = pto::Shape<1, 1, 1, 8, 8>();
      // pto: %260
      ;
      pto::Stride<512, 512, 512, 64, 1> v1104 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %260
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v1105 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v1100 + (v1101 + v1081 * v1102), v1103, v1104);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1105, v1055);
      // pto: %row0_tail_inline9867__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1106 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
      // pto: %row0_tail_inline9867__ssa_v0
      ;
      uint64_t v1107 = (uint64_t) v47;
      TASSIGN(v1106, v1107);
      // pto: %263
      ;
      const int64_t v1108 = 0;
      // pto: %263
      ;
      __gm__ float* v1109 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %263
      ;
      const int64_t v1110 = 1;
      // pto: %263
      ;
      const int64_t v1111 = 1;
      // pto: %263
      ;
      const int64_t v1112 = 1;
      // pto: %263
      ;
      int64_t v1113 = v674 * v76;
      // pto: %263
      ;
      int64_t v1114 = v1112 * v1113;
      // pto: %263
      ;
      pto::Shape<1, 1, 1, -1, 4> v1115 = pto::Shape<1, 1, 1, -1, 4>(v1110, v1111, v1112, v674, v77);
      // pto: %263
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1116 = pto::Stride<-1, -1, -1, -1, -1>(v1111 * v1114, v1114, v1113, v76, v70);
      // pto: %263
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1117 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1109 + (v1108 + v1081 * v76 + v79 * v70), v1115, v1116);
      pipe_barrier(PIPE_ALL);
      TLOAD(v1106, v1117);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
      // pto: %row1_tail_inline9810__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1118 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
      // pto: %row1_tail_inline9810__ssa_v0
      ;
      uint64_t v1119 = (uint64_t) v48;
      TASSIGN(v1118, v1119);
      // pto: %266
      ;
      const int64_t v1120 = 0;
      // pto: %266
      ;
      __gm__ float* v1121 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %266
      ;
      const int64_t v1122 = 1;
      // pto: %266
      ;
      const int64_t v1123 = 1;
      // pto: %266
      ;
      const int64_t v1124 = 1;
      // pto: %266
      ;
      int64_t v1125 = v674 * v76;
      // pto: %266
      ;
      int64_t v1126 = v1124 * v1125;
      // pto: %266
      ;
      pto::Shape<1, 1, 1, -1, 4> v1127 = pto::Shape<1, 1, 1, -1, 4>(v1122, v1123, v1124, v674, v77);
      // pto: %266
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1128 = pto::Stride<-1, -1, -1, -1, -1>(v1123 * v1126, v1126, v1125, v76, v70);
      // pto: %266
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1129 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1121 + (v1120 + v1081 * v76 + v71 * v70), v1127, v1128);
      TLOAD(v1118, v1129);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID3);
      // pto: %row2_tail_inline9809__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1130 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
      // pto: %row2_tail_inline9809__ssa_v0
      ;
      uint64_t v1131 = (uint64_t) v45;
      TASSIGN(v1130, v1131);
      // pto: %269
      ;
      const int64_t v1132 = 0;
      // pto: %269
      ;
      __gm__ float* v1133 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %269
      ;
      const int64_t v1134 = 1;
      // pto: %269
      ;
      const int64_t v1135 = 1;
      // pto: %269
      ;
      const int64_t v1136 = 1;
      // pto: %269
      ;
      int64_t v1137 = v674 * v76;
      // pto: %269
      ;
      int64_t v1138 = v1136 * v1137;
      // pto: %269
      ;
      pto::Shape<1, 1, 1, -1, 4> v1139 = pto::Shape<1, 1, 1, -1, 4>(v1134, v1135, v1136, v674, v77);
      // pto: %269
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1140 = pto::Stride<-1, -1, -1, -1, -1>(v1135 * v1138, v1138, v1137, v76, v70);
      // pto: %269
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1141 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1133 + (v1132 + v1081 * v76 + v78 * v70), v1139, v1140);
      TLOAD(v1130, v1141);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID4);
      // pto: %row3_tail_inline9808__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1142 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v674, v77);
      // pto: %row3_tail_inline9808__ssa_v0
      ;
      uint64_t v1143 = (uint64_t) v46;
      TASSIGN(v1142, v1143);
      // pto: %272
      ;
      const int64_t v1144 = 0;
      // pto: %272
      ;
      __gm__ float* v1145 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %272
      ;
      const int64_t v1146 = 1;
      // pto: %272
      ;
      const int64_t v1147 = 1;
      // pto: %272
      ;
      const int64_t v1148 = 1;
      // pto: %272
      ;
      int64_t v1149 = v674 * v76;
      // pto: %272
      ;
      int64_t v1150 = v1148 * v1149;
      // pto: %272
      ;
      pto::Shape<1, 1, 1, -1, 4> v1151 = pto::Shape<1, 1, 1, -1, 4>(v1146, v1147, v1148, v674, v77);
      // pto: %272
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1152 = pto::Stride<-1, -1, -1, -1, -1>(v1147 * v1150, v1150, v1149, v76, v70);
      // pto: %272
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1153 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1145 + (v1144 + v1081 * v76 + v73 * v70), v1151, v1152);
      TLOAD(v1142, v1153);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID5);
      // pto: %274
      ;
      const int64_t v1154 = 0;
      // pto: %274
      ;
      __gm__ float* v1155 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %274
      ;
      const int64_t v1156 = 1;
      // pto: %274
      ;
      const int64_t v1157 = 1;
      // pto: %274
      ;
      const int64_t v1158 = 1;
      // pto: %274
      ;
      int64_t v1159 = v674 * v71;
      // pto: %274
      ;
      int64_t v1160 = v1158 * v1159;
      // pto: %274
      ;
      pto::Shape<1, 1, 1, -1, 4> v1161 = pto::Shape<1, 1, 1, -1, 4>(v1156, v1157, v1158, v674, v77);
      // pto: %274
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1162 = pto::Stride<-1, -1, -1, -1, -1>(v1157 * v1160, v1160, v1159, v71, v70);
      // pto: %274
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1163 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1155 + (v1154 + v677 * v71 + v82 * v70), v1161, v1162);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
      TSTORE(v1163, v1106);
      // pto: %276
      ;
      const int64_t v1164 = 0;
      // pto: %276
      ;
      __gm__ float* v1165 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %276
      ;
      const int64_t v1166 = 1;
      // pto: %276
      ;
      const int64_t v1167 = 1;
      // pto: %276
      ;
      const int64_t v1168 = 1;
      // pto: %276
      ;
      int64_t v1169 = v674 * v71;
      // pto: %276
      ;
      int64_t v1170 = v1168 * v1169;
      // pto: %276
      ;
      pto::Shape<1, 1, 1, -1, 4> v1171 = pto::Shape<1, 1, 1, -1, 4>(v1166, v1167, v1168, v674, v77);
      // pto: %276
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1172 = pto::Stride<-1, -1, -1, -1, -1>(v1167 * v1170, v1170, v1169, v71, v70);
      // pto: %276
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1173 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1165 + (v1164 + v677 * v71 + v77 * v70), v1171, v1172);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID3);
      TSTORE(v1173, v1118);
      // pto: %278
      ;
      const int64_t v1174 = 0;
      // pto: %278
      ;
      __gm__ float* v1175 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %278
      ;
      const int64_t v1176 = 1;
      // pto: %278
      ;
      const int64_t v1177 = 1;
      // pto: %278
      ;
      const int64_t v1178 = 1;
      // pto: %278
      ;
      int64_t v1179 = v674 * v71;
      // pto: %278
      ;
      int64_t v1180 = v1178 * v1179;
      // pto: %278
      ;
      pto::Shape<1, 1, 1, -1, 4> v1181 = pto::Shape<1, 1, 1, -1, 4>(v1176, v1177, v1178, v674, v77);
      // pto: %278
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1182 = pto::Stride<-1, -1, -1, -1, -1>(v1177 * v1180, v1180, v1179, v71, v70);
      // pto: %278
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1183 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1175 + (v1174 + v677 * v71 + v79 * v70), v1181, v1182);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID4);
      TSTORE(v1183, v1130);
      // pto: %280
      ;
      const int64_t v1184 = 0;
      // pto: %280
      ;
      __gm__ float* v1185 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %280
      ;
      const int64_t v1186 = 1;
      // pto: %280
      ;
      const int64_t v1187 = 1;
      // pto: %280
      ;
      const int64_t v1188 = 1;
      // pto: %280
      ;
      int64_t v1189 = v674 * v71;
      // pto: %280
      ;
      int64_t v1190 = v1188 * v1189;
      // pto: %280
      ;
      pto::Shape<1, 1, 1, -1, 4> v1191 = pto::Shape<1, 1, 1, -1, 4>(v1186, v1187, v1188, v674, v77);
      // pto: %280
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1192 = pto::Stride<-1, -1, -1, -1, -1>(v1187 * v1190, v1190, v1189, v71, v70);
      // pto: %280
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1193 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1185 + (v1184 + v677 * v71 + v95 * v70), v1191, v1192);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID5);
      TSTORE(v1193, v1142);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v1194 = v291; v1194 < v336; v1194 += v81) {
    // pto: %283
    ;
    int64_t v1195 = (int64_t) ((uint64_t) v1194 * (uint64_t) v79);
    // pto: %284
    ;
    int64_t v1196 = (int64_t) ((uint64_t) v32 - (uint64_t) v1195);
    // pto: %285
    ;
    int64_t v1197 = v1196 < v79 ? v1196 : v79;
    // pto: %66
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1198 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %66
    ;
    uint64_t v1199 = (uint64_t) v47;
    TASSIGN(v1198, v1199);
    // pto: %286
    ;
    int64_t v1200 = v1195 < v82 ? v82 : v1195;
    // pto: %287
    ;
    __gm__ float* v1201 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %287
    ;
    const int64_t v1202 = 32;
    // pto: %287
    ;
    const int64_t v1203 = 64;
    // pto: %287
    ;
    pto::Shape<1, 1, 1, 8, 8> v1204 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %287
    ;
    pto::Stride<512, 512, 512, 64, 1> v1205 = pto::Stride<512, 512, 512, 64, 1>();
    // pto: %287
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v1206 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v1201 + (v1202 + v1200 * v1203), v1204, v1205);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v1198, v1206);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %67
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1207 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %67
    ;
    uint64_t v1208 = (uint64_t) v48;
    TASSIGN(v1207, v1208);
    // pto: %pre_tile_t_inline9908__tile
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1209 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %pre_tile_t_inline9908__tile
    ;
    uint64_t v1210 = (uint64_t) v52;
    TASSIGN(v1209, v1210);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TTRANS(v1209, v1198, v1207);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    // pto: %68
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1211 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %68
    ;
    uint64_t v1212 = (uint64_t) v52;
    TASSIGN(v1211, v1212);
    // pto: %pre0_inline9901__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1213 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %pre0_inline9901__tile
    ;
    uint64_t v1214 = (uint64_t) v52;
    TASSIGN(v1213, v1214);
    // pto: %69
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1215 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %69
    ;
    uint64_t v1216 = (uint64_t) v60;
    TASSIGN(v1215, v1216);
    // pto: %pre1_inline9909__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1217 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %pre1_inline9909__tile
    ;
    uint64_t v1218 = (uint64_t) v60;
    TASSIGN(v1217, v1218);
    // pto: %70
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1219 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %70
    ;
    uint64_t v1220 = (uint64_t) v61;
    TASSIGN(v1219, v1220);
    // pto: %pre2_inline9910__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1221 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %pre2_inline9910__tile
    ;
    uint64_t v1222 = (uint64_t) v61;
    TASSIGN(v1221, v1222);
    // pto: %71
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1223 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %71
    ;
    uint64_t v1224 = (uint64_t) v62;
    TASSIGN(v1223, v1224);
    // pto: %pre3_inline9911__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1225 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %pre3_inline9911__tile
    ;
    uint64_t v1226 = (uint64_t) v62;
    TASSIGN(v1225, v1226);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    for (int64_t v1227 = v82; v1227 < v71; v1227 += v80) {
      // pto: %292
      ;
      int64_t v1228 = (int64_t) ((uint64_t) v1227 * (uint64_t) v91);
      // pto: %295
      ;
      int64_t v1229 = (int64_t) ((uint64_t) v1228 + (uint64_t) v91);
      // pto: %x0_inline9898__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1230 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %x0_inline9898__tile
      ;
      uint64_t v1231 = (uint64_t) v47;
      TASSIGN(v1230, v1231);
      // pto: %298
      ;
      int64_t v1232 = v1228 < v82 ? v82 : v1228;
      // pto: %299
      ;
      const int64_t v1233 = 0;
      // pto: %299
      ;
      __gm__ float* v1234 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %299
      ;
      const int64_t v1235 = 1;
      // pto: %299
      ;
      const int64_t v1236 = 1;
      // pto: %299
      ;
      const int64_t v1237 = 1;
      // pto: %299
      ;
      int64_t v1238 = v1197 * v69;
      // pto: %299
      ;
      int64_t v1239 = v1237 * v1238;
      // pto: %299
      ;
      pto::Shape<1, 1, 1, -1, 256> v1240 = pto::Shape<1, 1, 1, -1, 256>(v1235, v1236, v1237, v1197, v91);
      // pto: %299
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1241 = pto::Stride<-1, -1, -1, -1, -1>(v1236 * v1239, v1239, v1238, v69, v70);
      // pto: %299
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1242 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1234 + (v1233 + v1200 * v69 + v1232 * v70), v1240, v1241);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      TLOAD(v1230, v1242);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %x1_inline9894__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1243 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %x1_inline9894__tile
      ;
      uint64_t v1244 = (uint64_t) v48;
      TASSIGN(v1243, v1244);
      // pto: %301
      ;
      int64_t v1245 = (int64_t) ((uint64_t) v1228 + (uint64_t) v74);
      // pto: %302
      ;
      int64_t v1246 = v1245 < v82 ? v82 : v1245;
      // pto: %303
      ;
      const int64_t v1247 = 0;
      // pto: %303
      ;
      __gm__ float* v1248 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %303
      ;
      const int64_t v1249 = 1;
      // pto: %303
      ;
      const int64_t v1250 = 1;
      // pto: %303
      ;
      const int64_t v1251 = 1;
      // pto: %303
      ;
      int64_t v1252 = v1197 * v69;
      // pto: %303
      ;
      int64_t v1253 = v1251 * v1252;
      // pto: %303
      ;
      pto::Shape<1, 1, 1, -1, 256> v1254 = pto::Shape<1, 1, 1, -1, 256>(v1249, v1250, v1251, v1197, v91);
      // pto: %303
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1255 = pto::Stride<-1, -1, -1, -1, -1>(v1250 * v1253, v1253, v1252, v69, v70);
      // pto: %303
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1256 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1248 + (v1247 + v1200 * v69 + v1246 * v70), v1254, v1255);
      TLOAD(v1243, v1256);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %x2_inline9912__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1257 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %x2_inline9912__tile
      ;
      uint64_t v1258 = (uint64_t) v45;
      TASSIGN(v1257, v1258);
      // pto: %305
      ;
      int64_t v1259 = (int64_t) ((uint64_t) v1228 + (uint64_t) v97);
      // pto: %306
      ;
      int64_t v1260 = v1259 < v82 ? v82 : v1259;
      // pto: %307
      ;
      const int64_t v1261 = 0;
      // pto: %307
      ;
      __gm__ float* v1262 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %307
      ;
      const int64_t v1263 = 1;
      // pto: %307
      ;
      const int64_t v1264 = 1;
      // pto: %307
      ;
      const int64_t v1265 = 1;
      // pto: %307
      ;
      int64_t v1266 = v1197 * v69;
      // pto: %307
      ;
      int64_t v1267 = v1265 * v1266;
      // pto: %307
      ;
      pto::Shape<1, 1, 1, -1, 256> v1268 = pto::Shape<1, 1, 1, -1, 256>(v1263, v1264, v1265, v1197, v91);
      // pto: %307
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1269 = pto::Stride<-1, -1, -1, -1, -1>(v1264 * v1267, v1267, v1266, v69, v70);
      // pto: %307
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1270 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1262 + (v1261 + v1200 * v69 + v1260 * v70), v1268, v1269);
      TLOAD(v1257, v1270);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %x3_inline9893__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1271 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %x3_inline9893__tile
      ;
      uint64_t v1272 = (uint64_t) v46;
      TASSIGN(v1271, v1272);
      // pto: %309
      ;
      int64_t v1273 = (int64_t) ((uint64_t) v1228 + (uint64_t) v98);
      // pto: %310
      ;
      int64_t v1274 = v1273 < v82 ? v82 : v1273;
      // pto: %311
      ;
      const int64_t v1275 = 0;
      // pto: %311
      ;
      __gm__ float* v1276 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %311
      ;
      const int64_t v1277 = 1;
      // pto: %311
      ;
      const int64_t v1278 = 1;
      // pto: %311
      ;
      const int64_t v1279 = 1;
      // pto: %311
      ;
      int64_t v1280 = v1197 * v69;
      // pto: %311
      ;
      int64_t v1281 = v1279 * v1280;
      // pto: %311
      ;
      pto::Shape<1, 1, 1, -1, 256> v1282 = pto::Shape<1, 1, 1, -1, 256>(v1277, v1278, v1279, v1197, v91);
      // pto: %311
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1283 = pto::Stride<-1, -1, -1, -1, -1>(v1278 * v1281, v1281, v1280, v69, v70);
      // pto: %311
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1284 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1276 + (v1275 + v1200 * v69 + v1274 * v70), v1282, v1283);
      TLOAD(v1271, v1284);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %72
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1285 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %72
      ;
      uint64_t v1286 = (uint64_t) v54;
      TASSIGN(v1285, v1286);
      // pto: %313
      ;
      int64_t v1287 = v1229 < v82 ? v82 : v1229;
      // pto: %314
      ;
      const int64_t v1288 = 0;
      // pto: %314
      ;
      __gm__ float* v1289 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %314
      ;
      const int64_t v1290 = 1;
      // pto: %314
      ;
      const int64_t v1291 = 1;
      // pto: %314
      ;
      const int64_t v1292 = 1;
      // pto: %314
      ;
      int64_t v1293 = v1197 * v69;
      // pto: %314
      ;
      int64_t v1294 = v1292 * v1293;
      // pto: %314
      ;
      pto::Shape<1, 1, 1, -1, 256> v1295 = pto::Shape<1, 1, 1, -1, 256>(v1290, v1291, v1292, v1197, v91);
      // pto: %314
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1296 = pto::Stride<-1, -1, -1, -1, -1>(v1291 * v1294, v1294, v1293, v69, v70);
      // pto: %314
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1297 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1289 + (v1288 + v1200 * v69 + v1287 * v70), v1295, v1296);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      TLOAD(v1285, v1297);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      // pto: %73
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1298 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %73
      ;
      uint64_t v1299 = (uint64_t) v49;
      TASSIGN(v1298, v1299);
      int64_t v1300 = (int64_t) ((uint64_t) v1228 + (uint64_t) v42);
      // pto: %317
      ;
      int64_t v1301 = v1300 < v82 ? v82 : v1300;
      // pto: %318
      ;
      const int64_t v1302 = 0;
      // pto: %318
      ;
      __gm__ float* v1303 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %318
      ;
      const int64_t v1304 = 1;
      // pto: %318
      ;
      const int64_t v1305 = 1;
      // pto: %318
      ;
      const int64_t v1306 = 1;
      // pto: %318
      ;
      int64_t v1307 = v1197 * v69;
      // pto: %318
      ;
      int64_t v1308 = v1306 * v1307;
      // pto: %318
      ;
      pto::Shape<1, 1, 1, -1, 256> v1309 = pto::Shape<1, 1, 1, -1, 256>(v1304, v1305, v1306, v1197, v91);
      // pto: %318
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1310 = pto::Stride<-1, -1, -1, -1, -1>(v1305 * v1308, v1308, v1307, v69, v70);
      // pto: %318
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1311 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1303 + (v1302 + v1200 * v69 + v1301 * v70), v1309, v1310);
      TLOAD(v1298, v1311);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      // pto: %74
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1312 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %74
      ;
      uint64_t v1313 = (uint64_t) v50;
      TASSIGN(v1312, v1313);
      int64_t v1314 = (int64_t) ((uint64_t) v1228 + (uint64_t) v41);
      // pto: %321
      ;
      int64_t v1315 = v1314 < v82 ? v82 : v1314;
      // pto: %322
      ;
      const int64_t v1316 = 0;
      // pto: %322
      ;
      __gm__ float* v1317 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %322
      ;
      const int64_t v1318 = 1;
      // pto: %322
      ;
      const int64_t v1319 = 1;
      // pto: %322
      ;
      const int64_t v1320 = 1;
      // pto: %322
      ;
      int64_t v1321 = v1197 * v69;
      // pto: %322
      ;
      int64_t v1322 = v1320 * v1321;
      // pto: %322
      ;
      pto::Shape<1, 1, 1, -1, 256> v1323 = pto::Shape<1, 1, 1, -1, 256>(v1318, v1319, v1320, v1197, v91);
      // pto: %322
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1324 = pto::Stride<-1, -1, -1, -1, -1>(v1319 * v1322, v1322, v1321, v69, v70);
      // pto: %322
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1325 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1317 + (v1316 + v1200 * v69 + v1315 * v70), v1323, v1324);
      TLOAD(v1312, v1325);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
      // pto: %75
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1326 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %75
      ;
      uint64_t v1327 = (uint64_t) v51;
      TASSIGN(v1326, v1327);
      int64_t v1328 = (int64_t) ((uint64_t) v1228 + (uint64_t) v40);
      // pto: %325
      ;
      int64_t v1329 = v1328 < v82 ? v82 : v1328;
      // pto: %326
      ;
      const int64_t v1330 = 0;
      // pto: %326
      ;
      __gm__ float* v1331 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %326
      ;
      const int64_t v1332 = 1;
      // pto: %326
      ;
      const int64_t v1333 = 1;
      // pto: %326
      ;
      const int64_t v1334 = 1;
      // pto: %326
      ;
      int64_t v1335 = v1197 * v69;
      // pto: %326
      ;
      int64_t v1336 = v1334 * v1335;
      // pto: %326
      ;
      pto::Shape<1, 1, 1, -1, 256> v1337 = pto::Shape<1, 1, 1, -1, 256>(v1332, v1333, v1334, v1197, v91);
      // pto: %326
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1338 = pto::Stride<-1, -1, -1, -1, -1>(v1333 * v1336, v1336, v1335, v69, v70);
      // pto: %326
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1339 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1331 + (v1330 + v1200 * v69 + v1329 * v70), v1337, v1338);
      TLOAD(v1326, v1339);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
      // pto: %y0_inline9903__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1340 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %y0_inline9903__tile
      ;
      uint64_t v1341 = (uint64_t) v47;
      TASSIGN(v1340, v1341);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      TROWEXPANDMUL(v1340, v1230, v1213);
      // pto: %y1_inline9892__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1342 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %y1_inline9892__tile
      ;
      uint64_t v1343 = (uint64_t) v48;
      TASSIGN(v1342, v1343);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      TROWEXPANDMUL(v1342, v1243, v1217);
      // pto: %y2_inline9895__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1344 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %y2_inline9895__tile
      ;
      uint64_t v1345 = (uint64_t) v45;
      TASSIGN(v1344, v1345);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      TROWEXPANDMUL(v1344, v1257, v1221);
      // pto: %y3_inline9907__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1346 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %y3_inline9907__tile
      ;
      uint64_t v1347 = (uint64_t) v46;
      TASSIGN(v1346, v1347);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      TROWEXPANDMUL(v1346, v1271, v1225);
      // pto: %76
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1348 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %76
      ;
      uint64_t v1349 = (uint64_t) v47;
      TASSIGN(v1348, v1349);
      pipe_barrier(PIPE_V);
      TADD(v1348, v1340, v1342);
      // pto: %77
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1350 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %77
      ;
      uint64_t v1351 = (uint64_t) v47;
      TASSIGN(v1350, v1351);
      pipe_barrier(PIPE_V);
      TADD(v1350, v1348, v1344);
      // pto: %y_tile_inline9891__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1352 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %y_tile_inline9891__tile
      ;
      uint64_t v1353 = (uint64_t) v47;
      TASSIGN(v1352, v1353);
      pipe_barrier(PIPE_V);
      TADD(v1352, v1350, v1346);
      // pto: %y_bf16_inline9890__tile
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1354 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %y_bf16_inline9890__tile
      ;
      uint64_t v1355 = (uint64_t) v47;
      TASSIGN(v1354, v1355);
      pipe_barrier(PIPE_V);
      RoundMode v1356 = RoundMode::CAST_RINT;
      SaturationMode v1357 = SaturationMode::ON;
      TCVT(v1354, v1352, v1356, v1357);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      // pto: %327
      ;
      bool v1358 = v1197 == v79;
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      if (v1358) {
        // pto: %mixed__iter_v3_pview
        ;
        const int64_t v1359 = 0;
        // pto: %mixed__iter_v3_pview
        ;
        __gm__ bfloat16_t* v1360 = PTOAS__GLOBAL_TENSOR_DATA(v217);
        // pto: %mixed__iter_v3_pview
        ;
        const int64_t v1361 = 1;
        // pto: %mixed__iter_v3_pview
        ;
        const int64_t v1362 = 1;
        // pto: %mixed__iter_v3_pview
        ;
        const int64_t v1363 = 1;
        // pto: %mixed__iter_v3_pview
        ;
        int64_t v1364 = v1197 * v74;
        // pto: %mixed__iter_v3_pview
        ;
        int64_t v1365 = v1363 * v1364;
        // pto: %mixed__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v1366 = pto::Shape<1, 1, 1, -1, 256>(v1361, v1362, v1363, v1197, v91);
        // pto: %mixed__iter_v3_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1367 = pto::Stride<-1, -1, -1, -1, -1>(v1362 * v1365, v1365, v1364, v74, v70);
        // pto: %mixed__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1368 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1360 + (v1359 + v1200 * v74 + v1232 * v70), v1366, v1367);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v1368, v1354);
      } else {
        // pto: %mixed_tail__iter_v3_pview
        ;
        const int64_t v1369 = 0;
        // pto: %mixed_tail__iter_v3_pview
        ;
        __gm__ bfloat16_t* v1370 = PTOAS__GLOBAL_TENSOR_DATA(v225);
        // pto: %mixed_tail__iter_v3_pview
        ;
        const int64_t v1371 = 1;
        // pto: %mixed_tail__iter_v3_pview
        ;
        const int64_t v1372 = 1;
        // pto: %mixed_tail__iter_v3_pview
        ;
        const int64_t v1373 = 1;
        // pto: %mixed_tail__iter_v3_pview
        ;
        int64_t v1374 = v1197 * v74;
        // pto: %mixed_tail__iter_v3_pview
        ;
        int64_t v1375 = v1373 * v1374;
        // pto: %mixed_tail__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v1376 = pto::Shape<1, 1, 1, -1, 256>(v1371, v1372, v1373, v1197, v91);
        // pto: %mixed_tail__iter_v3_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1377 = pto::Stride<-1, -1, -1, -1, -1>(v1372 * v1375, v1375, v1374, v74, v70);
        // pto: %mixed_tail__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1378 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1370 + (v1369 + v82 * v74 + v1232 * v70), v1376, v1377);
        TSTORE(v1378, v1354);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        // pto: %y_out_inline9897__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1379 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
        // pto: %y_out_inline9897__ssa_v0
        ;
        uint64_t v1380 = (uint64_t) v47;
        TASSIGN(v1379, v1380);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        TLOAD(v1379, v1378);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID6);
        // pto: %334
        ;
        const int64_t v1381 = 0;
        // pto: %334
        ;
        __gm__ bfloat16_t* v1382 = PTOAS__GLOBAL_TENSOR_DATA(v217);
        // pto: %334
        ;
        const int64_t v1383 = 1;
        // pto: %334
        ;
        const int64_t v1384 = 1;
        // pto: %334
        ;
        const int64_t v1385 = 1;
        // pto: %334
        ;
        int64_t v1386 = v1197 * v74;
        // pto: %334
        ;
        int64_t v1387 = v1385 * v1386;
        // pto: %334
        ;
        pto::Shape<1, 1, 1, -1, 256> v1388 = pto::Shape<1, 1, 1, -1, 256>(v1383, v1384, v1385, v1197, v91);
        // pto: %334
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1389 = pto::Stride<-1, -1, -1, -1, -1>(v1384 * v1387, v1387, v1386, v74, v70);
        // pto: %334
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1390 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1382 + (v1381 + v1200 * v74 + v1232 * v70), v1388, v1389);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID6);
        TSTORE(v1390, v1379);
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      // pto: %78
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1391 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %78
      ;
      uint64_t v1392 = (uint64_t) v54;
      TASSIGN(v1391, v1392);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      TROWEXPANDMUL(v1391, v1285, v1213);
      // pto: %79
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1393 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %79
      ;
      uint64_t v1394 = (uint64_t) v49;
      TASSIGN(v1393, v1394);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      TROWEXPANDMUL(v1393, v1298, v1217);
      // pto: %80
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1395 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %80
      ;
      uint64_t v1396 = (uint64_t) v50;
      TASSIGN(v1395, v1396);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
      TROWEXPANDMUL(v1395, v1312, v1221);
      // pto: %81
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1397 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %81
      ;
      uint64_t v1398 = (uint64_t) v51;
      TASSIGN(v1397, v1398);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
      TROWEXPANDMUL(v1397, v1326, v1225);
      // pto: %82
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1399 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %82
      ;
      uint64_t v1400 = (uint64_t) v54;
      TASSIGN(v1399, v1400);
      pipe_barrier(PIPE_V);
      TADD(v1399, v1391, v1393);
      // pto: %83
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1401 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %83
      ;
      uint64_t v1402 = (uint64_t) v54;
      TASSIGN(v1401, v1402);
      pipe_barrier(PIPE_V);
      TADD(v1401, v1399, v1395);
      // pto: %84
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1403 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %84
      ;
      uint64_t v1404 = (uint64_t) v54;
      TASSIGN(v1403, v1404);
      pipe_barrier(PIPE_V);
      TADD(v1403, v1401, v1397);
      // pto: %85
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1405 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
      // pto: %85
      ;
      uint64_t v1406 = (uint64_t) v54;
      TASSIGN(v1405, v1406);
      pipe_barrier(PIPE_V);
      RoundMode v1407 = RoundMode::CAST_RINT;
      SaturationMode v1408 = SaturationMode::ON;
      TCVT(v1405, v1403, v1407, v1408);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      if (v1358) {
        // pto: %mixed__phi_v6_pview
        ;
        const int64_t v1409 = 0;
        // pto: %mixed__phi_v6_pview
        ;
        __gm__ bfloat16_t* v1410 = PTOAS__GLOBAL_TENSOR_DATA(v217);
        // pto: %mixed__phi_v6_pview
        ;
        const int64_t v1411 = 1;
        // pto: %mixed__phi_v6_pview
        ;
        const int64_t v1412 = 1;
        // pto: %mixed__phi_v6_pview
        ;
        const int64_t v1413 = 1;
        // pto: %mixed__phi_v6_pview
        ;
        int64_t v1414 = v1197 * v74;
        // pto: %mixed__phi_v6_pview
        ;
        int64_t v1415 = v1413 * v1414;
        // pto: %mixed__phi_v6_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v1416 = pto::Shape<1, 1, 1, -1, 256>(v1411, v1412, v1413, v1197, v91);
        // pto: %mixed__phi_v6_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1417 = pto::Stride<-1, -1, -1, -1, -1>(v1412 * v1415, v1415, v1414, v74, v70);
        // pto: %mixed__phi_v6_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1418 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1410 + (v1409 + v1200 * v74 + v1287 * v70), v1416, v1417);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v1418, v1405);
      } else {
        // pto: %mixed_tail__phi_v6_pview
        ;
        const int64_t v1419 = 0;
        // pto: %mixed_tail__phi_v6_pview
        ;
        __gm__ bfloat16_t* v1420 = PTOAS__GLOBAL_TENSOR_DATA(v225);
        // pto: %mixed_tail__phi_v6_pview
        ;
        const int64_t v1421 = 1;
        // pto: %mixed_tail__phi_v6_pview
        ;
        const int64_t v1422 = 1;
        // pto: %mixed_tail__phi_v6_pview
        ;
        const int64_t v1423 = 1;
        // pto: %mixed_tail__phi_v6_pview
        ;
        int64_t v1424 = v1197 * v74;
        // pto: %mixed_tail__phi_v6_pview
        ;
        int64_t v1425 = v1423 * v1424;
        // pto: %mixed_tail__phi_v6_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v1426 = pto::Shape<1, 1, 1, -1, 256>(v1421, v1422, v1423, v1197, v91);
        // pto: %mixed_tail__phi_v6_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1427 = pto::Stride<-1, -1, -1, -1, -1>(v1422 * v1425, v1425, v1424, v74, v70);
        // pto: %mixed_tail__phi_v6_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1428 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1420 + (v1419 + v82 * v74 + v1287 * v70), v1426, v1427);
        TSTORE(v1428, v1405);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        // pto: %86
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1429 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1197, v91);
        // pto: %86
        ;
        uint64_t v1430 = (uint64_t) v54;
        TASSIGN(v1429, v1430);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        TLOAD(v1429, v1428);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID7);
        // pto: %345
        ;
        const int64_t v1431 = 0;
        // pto: %345
        ;
        __gm__ bfloat16_t* v1432 = PTOAS__GLOBAL_TENSOR_DATA(v217);
        // pto: %345
        ;
        const int64_t v1433 = 1;
        // pto: %345
        ;
        const int64_t v1434 = 1;
        // pto: %345
        ;
        const int64_t v1435 = 1;
        // pto: %345
        ;
        int64_t v1436 = v1197 * v74;
        // pto: %345
        ;
        int64_t v1437 = v1435 * v1436;
        // pto: %345
        ;
        pto::Shape<1, 1, 1, -1, 256> v1438 = pto::Shape<1, 1, 1, -1, 256>(v1433, v1434, v1435, v1197, v91);
        // pto: %345
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1439 = pto::Stride<-1, -1, -1, -1, -1>(v1434 * v1437, v1437, v1436, v74, v70);
        // pto: %345
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1440 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1432 + (v1431 + v1200 * v74 + v1287 * v70), v1438, v1439);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID7);
        TSTORE(v1440, v1429);
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    };
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v1441 = v291; v1441 < v32; v1441 += v81) {
    // pto: %raw_inline9936__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1442 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %raw_inline9936__ssa_v0
    ;
    uint64_t v1443 = (uint64_t) v48;
    TASSIGN(v1442, v1443);
    // pto: %346
    ;
    int64_t v1444 = v1441 < v82 ? v82 : v1441;
    // pto: %mixed__ssa_v7_pview
    ;
    __gm__ bfloat16_t* v1445 = PTOAS__GLOBAL_TENSOR_DATA(v217);
    // pto: %mixed__ssa_v7_pview
    ;
    const int64_t v1446 = 0;
    // pto: %mixed__ssa_v7_pview
    ;
    const int64_t v1447 = 4096;
    // pto: %mixed__ssa_v7_pview
    ;
    pto::Shape<1, 1, 1, 1, 4096> v1448 = pto::Shape<1, 1, 1, 1, 4096>();
    // pto: %mixed__ssa_v7_pview
    ;
    pto::Stride<4096, 4096, 4096, 4096, 1> v1449 = pto::Stride<4096, 4096, 4096, 4096, 1>();
    // pto: %mixed__ssa_v7_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v1450 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v1445 + (v1446 + v1444 * v1447), v1448, v1449);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v1442, v1450);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %wide_inline9958__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1451 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %wide_inline9958__ssa_v0
    ;
    uint64_t v1452 = (uint64_t) v47;
    TASSIGN(v1451, v1452);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
    RoundMode v1453 = RoundMode::CAST_ROUND;
    SaturationMode v1454 = SaturationMode::ON;
    TCVT(v1451, v1442, v1453, v1454);
    // pto: %square_inline9934__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1455 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %square_inline9934__ssa_v0
    ;
    uint64_t v1456 = (uint64_t) v48;
    TASSIGN(v1455, v1456);
    pipe_barrier(PIPE_V);
    TMUL(v1455, v1451, v1451);
    // pto: %t__tmp_v75
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1457 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v99);
    // pto: %t__tmp_v75
    ;
    uint64_t v1458 = (uint64_t) v48;
    TASSIGN(v1457, v1458);
    // pto: %347
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1459;
    // pto: %347
    ;
    uint64_t v1460 = (uint64_t) v48;
    TASSIGN(v1459, v1460);
    // pto: %t__tmp_v76
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1461 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v99);
    // pto: %t__tmp_v76
    ;
    uint64_t v1462 = (uint64_t) v63;
    TASSIGN(v1461, v1462);
    // pto: %348
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1463;
    // pto: %348
    ;
    uint64_t v1464 = (uint64_t) v63;
    TASSIGN(v1463, v1464);
    // pto: %fold2048_inline9932__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1465 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v99);
    // pto: %fold2048_inline9932__ssa_v0
    ;
    uint64_t v1466 = (uint64_t) v48;
    TASSIGN(v1465, v1466);
    pipe_barrier(PIPE_V);
    TADD(v1465, v1459, v1463);
    // pto: %t__tmp_v77
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1467 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v100);
    // pto: %t__tmp_v77
    ;
    uint64_t v1468 = (uint64_t) v48;
    TASSIGN(v1467, v1468);
    // pto: %349
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1469;
    // pto: %349
    ;
    uint64_t v1470 = (uint64_t) v48;
    TASSIGN(v1469, v1470);
    // pto: %t__tmp_v78
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1471 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v100);
    // pto: %t__tmp_v78
    ;
    uint64_t v1472 = (uint64_t) v64;
    TASSIGN(v1471, v1472);
    // pto: %350
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1473;
    // pto: %350
    ;
    uint64_t v1474 = (uint64_t) v64;
    TASSIGN(v1473, v1474);
    // pto: %fold1024_inline9929__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1475 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v100);
    // pto: %fold1024_inline9929__ssa_v0
    ;
    uint64_t v1476 = (uint64_t) v48;
    TASSIGN(v1475, v1476);
    pipe_barrier(PIPE_V);
    TADD(v1475, v1469, v1473);
    // pto: %t__tmp_v79
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1477 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
    // pto: %t__tmp_v79
    ;
    uint64_t v1478 = (uint64_t) v48;
    TASSIGN(v1477, v1478);
    // pto: %351
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1479;
    // pto: %351
    ;
    uint64_t v1480 = (uint64_t) v48;
    TASSIGN(v1479, v1480);
    // pto: %t__tmp_v80
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1481 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
    // pto: %t__tmp_v80
    ;
    uint64_t v1482 = (uint64_t) v65;
    TASSIGN(v1481, v1482);
    // pto: %352
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1483;
    // pto: %352
    ;
    uint64_t v1484 = (uint64_t) v65;
    TASSIGN(v1483, v1484);
    // pto: %fold512_inline9931__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1485 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
    // pto: %fold512_inline9931__ssa_v0
    ;
    uint64_t v1486 = (uint64_t) v48;
    TASSIGN(v1485, v1486);
    pipe_barrier(PIPE_V);
    TADD(v1485, v1479, v1483);
    // pto: %t__tmp_v81
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1487 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v91);
    // pto: %t__tmp_v81
    ;
    uint64_t v1488 = (uint64_t) v48;
    TASSIGN(v1487, v1488);
    // pto: %353
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1489;
    // pto: %353
    ;
    uint64_t v1490 = (uint64_t) v48;
    TASSIGN(v1489, v1490);
    // pto: %t__tmp_v82
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1491 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v91);
    // pto: %t__tmp_v82
    ;
    uint64_t v1492 = (uint64_t) v66;
    TASSIGN(v1491, v1492);
    // pto: %354
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1493;
    // pto: %354
    ;
    uint64_t v1494 = (uint64_t) v66;
    TASSIGN(v1493, v1494);
    // pto: %fold256_inline9928__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1495 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v91);
    // pto: %fold256_inline9928__ssa_v0
    ;
    uint64_t v1496 = (uint64_t) v48;
    TASSIGN(v1495, v1496);
    pipe_barrier(PIPE_V);
    TADD(v1495, v1489, v1493);
    // pto: %t__tmp_v83
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1497 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v101);
    // pto: %t__tmp_v83
    ;
    uint64_t v1498 = (uint64_t) v48;
    TASSIGN(v1497, v1498);
    // pto: %355
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1499;
    // pto: %355
    ;
    uint64_t v1500 = (uint64_t) v48;
    TASSIGN(v1499, v1500);
    // pto: %t__tmp_v84
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1501 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v101);
    // pto: %t__tmp_v84
    ;
    uint64_t v1502 = (uint64_t) v67;
    TASSIGN(v1501, v1502);
    // pto: %356
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1503;
    // pto: %356
    ;
    uint64_t v1504 = (uint64_t) v67;
    TASSIGN(v1503, v1504);
    // pto: %fold128_inline9941__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1505 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v101);
    // pto: %fold128_inline9941__ssa_v0
    ;
    uint64_t v1506 = (uint64_t) v48;
    TASSIGN(v1505, v1506);
    pipe_barrier(PIPE_V);
    TADD(v1505, v1499, v1503);
    // pto: %t__tmp_v85
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1507 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v76);
    // pto: %t__tmp_v85
    ;
    uint64_t v1508 = (uint64_t) v48;
    TASSIGN(v1507, v1508);
    // pto: %357
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1509;
    // pto: %357
    ;
    uint64_t v1510 = (uint64_t) v48;
    TASSIGN(v1509, v1510);
    // pto: %t__tmp_v86
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1511 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v76);
    // pto: %t__tmp_v86
    ;
    uint64_t v1512 = (uint64_t) v68;
    TASSIGN(v1511, v1512);
    // pto: %358
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1513;
    // pto: %358
    ;
    uint64_t v1514 = (uint64_t) v68;
    TASSIGN(v1513, v1514);
    // pto: %fold64_inline9945__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1515 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v76);
    // pto: %fold64_inline9945__ssa_v0
    ;
    uint64_t v1516 = (uint64_t) v45;
    TASSIGN(v1515, v1516);
    pipe_barrier(PIPE_V);
    TADD(v1515, v1509, v1513);
    // pto: %t__tmp_v87
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1517 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v76);
    // pto: %t__tmp_v87
    ;
    uint64_t v1518 = (uint64_t) v48;
    TASSIGN(v1517, v1518);
    // pto: %repeated_inline9926__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1519 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v76);
    // pto: %repeated_inline9926__ssa_v0
    ;
    uint64_t v1520 = (uint64_t) v48;
    TASSIGN(v1519, v1520);
    pipe_barrier(PIPE_V);
    TCOLEXPAND(v1519, v1515);
    // pto: %t__tmp_v88
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1521 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v76);
    // pto: %t__tmp_v88
    ;
    uint64_t v1522 = (uint64_t) v45;
    TASSIGN(v1521, v1522);
    // pto: %total_inline9927__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1523 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %total_inline9927__ssa_v0
    ;
    uint64_t v1524 = (uint64_t) v46;
    TASSIGN(v1523, v1524);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID5);
    TROWSUM(v1523, v1519, v1521);
    set_flag(PIPE_V, PIPE_S, EVENT_ID3);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID3);
    // pto: %total_scalar_inline9948__ssa_v0
    ;
    float v1525 = v1523.GetValue(v82);
    // pto: %87
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1526 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %87
    ;
    uint64_t v1527 = (uint64_t) v48;
    TASSIGN(v1526, v1527);
    pipe_barrier(PIPE_V);
    TEXPANDS(v1526, v90);
    // pto: %total_vector_inline9949__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1528 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %total_vector_inline9949__tile
    ;
    uint64_t v1529 = (uint64_t) v48;
    TASSIGN(v1528, v1529);
    pipe_barrier(PIPE_V);
    TMULS(v1528, v1526, v1525);
    // pto: %88
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1530 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %88
    ;
    uint64_t v1531 = (uint64_t) v48;
    TASSIGN(v1530, v1531);
    pipe_barrier(PIPE_V);
    TMULS(v1530, v1528, v102);
    // pto: %variance_inline9950__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1532 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %variance_inline9950__tile
    ;
    uint64_t v1533 = (uint64_t) v48;
    TASSIGN(v1532, v1533);
    pipe_barrier(PIPE_V);
    TADDS(v1532, v1530, v89);
    set_flag(PIPE_V, PIPE_S, EVENT_ID4);
    // pto: %root_value_inline9953__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1534 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %root_value_inline9953__tile
    ;
    uint64_t v1535 = (uint64_t) v45;
    TASSIGN(v1534, v1535);
    pipe_barrier(PIPE_V);
    TSQRT(v1534, v1532);
    set_flag(PIPE_V, PIPE_S, EVENT_ID5);
    // pto: %variance_bits_inline9954__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1536 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %variance_bits_inline9954__tile
    ;
    uint64_t v1537 = (uint64_t) v48;
    TASSIGN(v1536, v1537);
    // pto: %approx_bits_inline9935__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1538 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %approx_bits_inline9935__tile
    ;
    uint64_t v1539 = (uint64_t) v45;
    TASSIGN(v1538, v1539);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID4);
    // pto: %359
    ;
    int32_t v1540 = v1536.GetValue(v82);
    set_flag(PIPE_S, PIPE_V, EVENT_ID6);
    // pto: %360
    ;
    int64_t v1541 = (int64_t) v1540;
    wait_flag(PIPE_V, PIPE_S, EVENT_ID5);
    // pto: %361
    ;
    int32_t v1542 = v1538.GetValue(v82);
    set_flag(PIPE_S, PIPE_MTE2, EVENT_ID1);
    // pto: %362
    ;
    int64_t v1543 = (int64_t) v1542;
    // pto: %364, %365, %366
    ;
    // pto: %y_bits_inline9943__phi_v7
    ;
    int64_t v1544;
    if ((int64_t) v1540 >= v103 & v1541 < v104) {
      // pto: %368
      ;
      int64_t v1545 = v1541 / v43;
      // pto: %370, %372
      ;
      int64_t v1546 = (int64_t) ((uint64_t) (v1541 % v43) + (uint64_t) v43);
      // pto: %y_bits_inline9943__rv_v2
      ;
      int64_t v1547;
      v1547 = v1543;
      for (int64_t v1548 = v82; v1548 < v80; v1548 += v70) {
        // pto: %374
        ;
        int64_t v1549 = v1547 / v43;
        // pto: %376
        ;
        int64_t v1550 = v1547 % v43;
        // pto: %378, %379, %381
        ;
        int64_t v1551 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v1550 + (uint64_t) v43) * (uint64_t) v105) + (uint64_t) v70);
        // pto: %382
        ;
        int64_t v1552 = (int64_t) ((uint64_t) v1551 * (uint64_t) v1551);
        // pto: %386, %384, %383, %385
        ;
        int64_t v1553 = (int64_t) ((uint64_t) v1546 << (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v1545 - (uint64_t) ((int64_t) (uint64_t) v1549 * (uint64_t) v105)) + (uint64_t) v106));
        // pto: %387
        ;
        uint64_t v1554 = (uint64_t) v1547;
        // pto: %387
        ;
        int64_t v1555 = (int64_t) (v1554 - (uint64_t) v107);
        // pto: %391, %393, %394, %396
        ;
        int64_t v1556 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) (v1555 % v43) + (uint64_t) v43) * (uint64_t) v105) + (uint64_t) v70);
        // pto: %397
        ;
        int64_t v1557 = (int64_t) ((uint64_t) v1556 * (uint64_t) v1556);
        // pto: %401, %399, %389, %398, %400
        ;
        int64_t v1558 = (int64_t) ((uint64_t) v1546 << (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v1545 - (uint64_t) ((int64_t) (uint64_t) (v1555 / v43) * (uint64_t) v105)) + (uint64_t) v106));
        // pto: %406
        ;
        int64_t v1559 = v1547 % v105;
        // pto: %407
        ;
        bool v1560 = v1559 == v107;
        // pto: %403, %405, %408, %409
        ;
        // pto: %y_bits_inline9943__phi_v6
        ;
        int64_t v1561;
        if (v1552 < v1553 | v1553 == v1552 & v1560) {
          // pto: %410
          ;
          uint64_t v1562 = (uint64_t) v1547;
          // pto: %410
          ;
          v1561 = (int64_t) (v1562 + (uint64_t) v107);
        } else {
          // pto: %412, %414, %417, %418, %y_bits_inline9943__phi_v5
          ;
          int64_t v1563 = v1558 < v1557 | v1558 == v1557 & v1560 ? v1555 : v1547;
          v1561 = v1563;
        };
        v1547 = v1561;
      };
      v1544 = v1547;
    } else {
      v1544 = v1543;
    };
    // pto: %rounded_bits_inline9956__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1564 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rounded_bits_inline9956__tile
    ;
    uint64_t v1565 = (uint64_t) v48;
    TASSIGN(v1564, v1565);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID6);
    pipe_barrier(PIPE_V);
    TEXPANDS(v1564, v85);
    set_flag(PIPE_V, PIPE_S, EVENT_ID6);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID6);
    for (int64_t v1566 = v82; v1566 < v79; v1566 += v70) {
      // pto: %420
      ;
      int32_t v1567 = (int32_t) v1544;
      v1564.SetValue(v1566, v1567);
    };
    // pto: %rounded_root_inline9940__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1568 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rounded_root_inline9940__tile
    ;
    uint64_t v1569 = (uint64_t) v48;
    TASSIGN(v1568, v1569);
    // pto: %scalar_root_value_inline9919__tile
    ;
    float v1570 = v1568.GetValue(v82);
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
    // pto: %423
    ;
    float v1571 = v90 / v1570;
    // pto: %89
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1572 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %89
    ;
    uint64_t v1573 = (uint64_t) v48;
    TASSIGN(v1572, v1573);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    TEXPANDS(v1572, v90);
    // pto: %inverse_inline9917__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1574 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %inverse_inline9917__tile
    ;
    uint64_t v1575 = (uint64_t) v46;
    TASSIGN(v1574, v1575);
    pipe_barrier(PIPE_V);
    TMULS(v1574, v1572, v1571);
    set_flag(PIPE_V, PIPE_S, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    __gm__ float* v1576 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    const int64_t v1577 = 48;
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    const int64_t v1578 = 64;
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v1579 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    pto::Stride<64, 64, 64, 64, 1> v1580 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v1581 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v1576 + (v1577 + v1444 * v1578), v1579, v1580);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1581, v1574);
    // pto: %apply_value_inline9921__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1582 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %apply_value_inline9921__ssa_v0
    ;
    uint64_t v1583 = (uint64_t) v47;
    TASSIGN(v1582, v1583);
    // pto: %t__tmp_v94
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1584 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %t__tmp_v94
    ;
    uint64_t v1585 = (uint64_t) v45;
    TASSIGN(v1584, v1585);
    // pto: %attn_norm_w__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v1586 = PTOAS__GLOBAL_TENSOR_DATA(v235);
    // pto: %attn_norm_w__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 4096> v1587 = pto::Shape<1, 1, 1, 1, 4096>();
    // pto: %attn_norm_w__ssa_v0_pview
    ;
    pto::Stride<4096, 4096, 4096, 4096, 1> v1588 = pto::Stride<4096, 4096, 4096, 4096, 1>();
    // pto: %attn_norm_w__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v1589 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v1586, v1587, v1588);
    wait_flag(PIPE_S, PIPE_MTE2, EVENT_ID1);
    TLOAD(v1584, v1589);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %w_raw_inline9916__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1590 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %w_raw_inline9916__ssa_v0
    ;
    uint64_t v1591 = (uint64_t) v45;
    TASSIGN(v1590, v1591);
    // pto: %w_inline9914__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1592 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %w_inline9914__ssa_v0
    ;
    uint64_t v1593 = (uint64_t) v48;
    TASSIGN(v1592, v1593);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    pipe_barrier(PIPE_V);
    RoundMode v1594 = RoundMode::CAST_ROUND;
    SaturationMode v1595 = SaturationMode::ON;
    TCVT(v1592, v1590, v1594, v1595);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
    // pto: %inv_inline9915__tile
    ;
    float v1596 = v1574.GetValue(v82);
    set_flag(PIPE_S, PIPE_V, EVENT_ID5);
    // pto: %scaled_inline9952__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1597 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %scaled_inline9952__ssa_v0
    ;
    uint64_t v1598 = (uint64_t) v47;
    TASSIGN(v1597, v1598);
    TMULS(v1597, v1582, v1596);
    // pto: %result_inline9939__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1599 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %result_inline9939__ssa_v0
    ;
    uint64_t v1600 = (uint64_t) v47;
    TASSIGN(v1599, v1600);
    pipe_barrier(PIPE_V);
    TCOLEXPANDMUL(v1599, v1597, v1592);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %t__tmp_v95
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1601 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %t__tmp_v95
    ;
    uint64_t v1602 = (uint64_t) v47;
    TASSIGN(v1601, v1602);
    pipe_barrier(PIPE_V);
    RoundMode v1603 = RoundMode::CAST_RINT;
    SaturationMode v1604 = SaturationMode::ON;
    TCVT(v1601, v1599, v1603, v1604);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %normed__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v1605 = PTOAS__GLOBAL_TENSOR_DATA(v136);
    // pto: %normed__ssa_v0_pview
    ;
    const int64_t v1606 = 0;
    // pto: %normed__ssa_v0_pview
    ;
    const int64_t v1607 = 4096;
    // pto: %normed__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 4096> v1608 = pto::Shape<1, 1, 1, 1, 4096>();
    // pto: %normed__ssa_v0_pview
    ;
    pto::Stride<4096, 4096, 4096, 4096, 1> v1609 = pto::Stride<4096, 4096, 4096, 4096, 1>();
    // pto: %normed__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v1610 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v1605 + (v1606 + v1444 * v1607), v1608, v1609);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1610, v1601);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %426, %427
  int64_t v1611 = (int64_t) ((uint64_t) v32 + (uint64_t) v108) / v71;
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v1612 = v291; v1612 < v1611; v1612 += v81) {
    // pto: %428
    ;
    int64_t v1613 = (int64_t) ((uint64_t) v1612 * (uint64_t) v71);
    // pto: %429
    ;
    int64_t v1614 = (int64_t) ((uint64_t) v32 - (uint64_t) v1613);
    // pto: %430
    ;
    int64_t v1615 = v1614 < v71 ? v1614 : v71;
    // pto: %projected_inline9964__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1616 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1615, v75);
    // pto: %projected_inline9964__ssa_v0
    ;
    uint64_t v1617 = (uint64_t) v47;
    TASSIGN(v1616, v1617);
    // pto: %431
    ;
    int64_t v1618 = v1613 < v82 ? v82 : v1613;
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    const int64_t v1619 = 0;
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    __gm__ float* v1620 = PTOAS__GLOBAL_TENSOR_DATA(v244);
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    const int64_t v1621 = 1;
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    const int64_t v1622 = 1;
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    const int64_t v1623 = 1;
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    int64_t v1624 = v1615 * v75;
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    int64_t v1625 = v1623 * v1624;
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v1626 = pto::Shape<1, 1, 1, -1, 512>(v1621, v1622, v1623, v1615, v75);
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1627 = pto::Stride<-1, -1, -1, -1, -1>(v1622 * v1625, v1625, v1624, v75, v70);
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1628 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1620 + (v1619 + v1618 * v75 + v82 * v70), v1626, v1627);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v1616, v1628);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %rounded_inline9962__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1629 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1615, v75);
    // pto: %rounded_inline9962__ssa_v0
    ;
    uint64_t v1630 = (uint64_t) v47;
    TASSIGN(v1629, v1630);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v1631 = RoundMode::CAST_RINT;
    SaturationMode v1632 = SaturationMode::ON;
    TCVT(v1629, v1616, v1631, v1632);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %projected_kv__ssa_v0_pview
    ;
    const int64_t v1633 = 0;
    // pto: %projected_kv__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v1634 = PTOAS__GLOBAL_TENSOR_DATA(v253);
    // pto: %projected_kv__ssa_v0_pview
    ;
    const int64_t v1635 = 1;
    // pto: %projected_kv__ssa_v0_pview
    ;
    const int64_t v1636 = 1;
    // pto: %projected_kv__ssa_v0_pview
    ;
    const int64_t v1637 = 1;
    // pto: %projected_kv__ssa_v0_pview
    ;
    int64_t v1638 = v1615 * v75;
    // pto: %projected_kv__ssa_v0_pview
    ;
    int64_t v1639 = v1637 * v1638;
    // pto: %projected_kv__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v1640 = pto::Shape<1, 1, 1, -1, 512>(v1635, v1636, v1637, v1615, v75);
    // pto: %projected_kv__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1641 = pto::Stride<-1, -1, -1, -1, -1>(v1636 * v1639, v1639, v1638, v75, v70);
    // pto: %projected_kv__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1642 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1634 + (v1633 + v1618 * v75 + v82 * v70), v1640, v1641);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1642, v1629);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v1643 = v291; v1643 < v1611; v1643 += v81) {
    // pto: %435
    ;
    int64_t v1644 = (int64_t) ((uint64_t) v1643 * (uint64_t) v71);
    // pto: %436
    ;
    int64_t v1645 = (int64_t) ((uint64_t) v32 - (uint64_t) v1644);
    // pto: %437
    ;
    int64_t v1646 = v1645 < v71 ? v1645 : v71;
    // pto: %value_inline9973__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1647 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1646, v76);
    // pto: %value_inline9973__ssa_v0
    ;
    uint64_t v1648 = (uint64_t) v47;
    TASSIGN(v1647, v1648);
    // pto: %438
    ;
    int64_t v1649 = v1644 < v82 ? v82 : v1644;
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    const int64_t v1650 = 0;
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    __gm__ float* v1651 = PTOAS__GLOBAL_TENSOR_DATA(v262);
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    const int64_t v1652 = 1;
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    const int64_t v1653 = 1;
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    const int64_t v1654 = 1;
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    int64_t v1655 = v1646 * v76;
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    int64_t v1656 = v1654 * v1655;
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 64> v1657 = pto::Shape<1, 1, 1, -1, 64>(v1652, v1653, v1654, v1646, v76);
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1658 = pto::Stride<-1, -1, -1, -1, -1>(v1653 * v1656, v1656, v1655, v76, v70);
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1659 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1651 + (v1650 + v1649 * v76 + v82 * v70), v1657, v1658);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v1647, v1659);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %projected_inline9976__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1660 = Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1646, v76);
    // pto: %projected_inline9976__ssa_v0
    ;
    uint64_t v1661 = (uint64_t) v48;
    TASSIGN(v1660, v1661);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v1662 = RoundMode::CAST_RINT;
    SaturationMode v1663 = SaturationMode::ON;
    TCVT(v1660, v1647, v1662, v1663);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %indexer_raw__ssa_v0_pview
    ;
    const int64_t v1664 = 0;
    // pto: %indexer_raw__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v1665 = PTOAS__GLOBAL_TENSOR_DATA(v271);
    // pto: %indexer_raw__ssa_v0_pview
    ;
    const int64_t v1666 = 1;
    // pto: %indexer_raw__ssa_v0_pview
    ;
    const int64_t v1667 = 1;
    // pto: %indexer_raw__ssa_v0_pview
    ;
    const int64_t v1668 = 1;
    // pto: %indexer_raw__ssa_v0_pview
    ;
    int64_t v1669 = v1646 * v76;
    // pto: %indexer_raw__ssa_v0_pview
    ;
    int64_t v1670 = v1668 * v1669;
    // pto: %indexer_raw__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 64> v1671 = pto::Shape<1, 1, 1, -1, 64>(v1666, v1667, v1668, v1646, v76);
    // pto: %indexer_raw__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1672 = pto::Stride<-1, -1, -1, -1, -1>(v1667 * v1670, v1670, v1669, v76, v70);
    // pto: %indexer_raw__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1673 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1665 + (v1664 + v1649 * v76 + v82 * v70), v1671, v1672);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1673, v1660);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    // pto: %value_v1_inline9972__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1674 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1646, v76);
    // pto: %value_v1_inline9972__ssa_v0
    ;
    uint64_t v1675 = (uint64_t) v47;
    TASSIGN(v1674, v1675);
    pipe_barrier(PIPE_V);
    RoundMode v1676 = RoundMode::CAST_ROUND;
    SaturationMode v1677 = SaturationMode::ON;
    TCVT(v1674, v1660, v1676, v1677);
    // pto: %value_v2_inline9971__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1678 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1646, v76);
    // pto: %value_v2_inline9971__ssa_v0
    ;
    uint64_t v1679 = (uint64_t) v47;
    TASSIGN(v1678, v1679);
    pipe_barrier(PIPE_V);
    TMULS(v1678, v1674, v109);
    // pto: %weighted_inline9970__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1680 = Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1646, v76);
    // pto: %weighted_inline9970__ssa_v0
    ;
    uint64_t v1681 = (uint64_t) v48;
    TASSIGN(v1680, v1681);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    RoundMode v1682 = RoundMode::CAST_RINT;
    SaturationMode v1683 = SaturationMode::ON;
    TCVT(v1680, v1678, v1682, v1683);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    const int64_t v1684 = 0;
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v1685 = PTOAS__GLOBAL_TENSOR_DATA(v280);
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    const int64_t v1686 = 1;
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    const int64_t v1687 = 1;
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    const int64_t v1688 = 1;
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    int64_t v1689 = v1646 * v76;
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    int64_t v1690 = v1688 * v1689;
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 64> v1691 = pto::Shape<1, 1, 1, -1, 64>(v1686, v1687, v1688, v1646, v76);
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1692 = pto::Stride<-1, -1, -1, -1, -1>(v1687 * v1690, v1690, v1689, v76, v70);
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1693 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1685 + (v1684 + v1649 * v76 + v82 * v70), v1691, v1692);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1693, v1680);
    // pto: %result_inline9969__cast_fp32_tmp_v0
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1694 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1646, v76);
    // pto: %result_inline9969__cast_fp32_tmp_v0
    ;
    uint64_t v1695 = (uint64_t) v47;
    TASSIGN(v1694, v1695);
    pipe_barrier(PIPE_V);
    RoundMode v1696 = RoundMode::CAST_RINT;
    SaturationMode v1697 = SaturationMode::ON;
    TCVT(v1694, v1680, v1696, v1697);
    // pto: %result_inline9969__ssa_v0
    ;
    Tile<TileType::Vec, half, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1698 = Tile<TileType::Vec, half, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1646, v76);
    // pto: %result_inline9969__ssa_v0
    ;
    uint64_t v1699 = (uint64_t) v47;
    TASSIGN(v1698, v1699);
    pipe_barrier(PIPE_V);
    RoundMode v1700 = RoundMode::CAST_RINT;
    SaturationMode v1701 = SaturationMode::ON;
    TCVT(v1698, v1694, v1700, v1701);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %indexer_weights__ssa_v0_pview
    ;
    const int64_t v1702 = 0;
    // pto: %indexer_weights__ssa_v0_pview
    ;
    __gm__ half* v1703 = PTOAS__GLOBAL_TENSOR_DATA(v289);
    // pto: %indexer_weights__ssa_v0_pview
    ;
    const int64_t v1704 = 1;
    // pto: %indexer_weights__ssa_v0_pview
    ;
    const int64_t v1705 = 1;
    // pto: %indexer_weights__ssa_v0_pview
    ;
    const int64_t v1706 = 1;
    // pto: %indexer_weights__ssa_v0_pview
    ;
    int64_t v1707 = v1646 * v76;
    // pto: %indexer_weights__ssa_v0_pview
    ;
    int64_t v1708 = v1706 * v1707;
    // pto: %indexer_weights__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 64> v1709 = pto::Shape<1, 1, 1, -1, 64>(v1704, v1705, v1706, v1646, v76);
    // pto: %indexer_weights__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1710 = pto::Stride<-1, -1, -1, -1, -1>(v1705 * v1708, v1708, v1707, v76, v70);
    // pto: %indexer_weights__ssa_v0_pview
    ;
    GlobalTensor<half, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1711 = GlobalTensor<half, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1703 + (v1702 + v1649 * v76 + v82 * v70), v1709, v1710);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1711, v1698);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID5);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}