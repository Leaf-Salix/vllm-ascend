"""Read only the two experiment-owned CPU snapshots; no NPU operations."""
import hashlib
import json
from pathlib import Path
import numpy as np
import torch

r=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-spmd-20261019/results')
a=torch.load(r/'bf16layout-full-t126-v1/first-difference.pt',map_location='cpu',weights_only=False)
b=torch.load(r/'bf16layout-control-t126-v1/first-difference.pt',map_location='cpu',weights_only=False)
def equal(x,y):
 return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
out={
 'states':{arm:{name:equal(value,b['states'][arm][name]) for name,value in values.items()} for arm,values in a['states'].items()},
 'inputs':{arm:{name:equal(values[name],b['inputs'][arm][name]) for name in ('hidden','positions')} for arm,values in a['inputs'].items()},
 'initial_allocations':{arm:{name:equal(value,b['inputs'][arm]['initial'][name]) for name,value in values['initial'].items()} for arm,values in a['inputs'].items()},
}
out['tensor_sha256']={}
small={}
for label,run in (('bf16',a),('control',b)):
 out['tensor_sha256'][label]={}
 for arm,values in run['states'].items():
  out['tensor_sha256'][label][arm]={name:hashlib.sha256(value.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest() for name,value in values.items()}
  small[label+'_'+arm+'_topk']=values['idx_topk'].numpy()
 mask=run['states']['candidate']['x_out']!=run['states']['native']['x_out']
 out[label+'_output_difference']={'rows':mask.reshape(mask.shape[0],-1).any(dim=1).nonzero().reshape(-1).tolist(),'different_elements':int(mask.sum()),'max_abs':float((run['states']['candidate']['x_out'].float()-run['states']['native']['x_out'].float()).abs().max())}
 changed_rows=mask.reshape(mask.shape[0],-1).any(dim=1).nonzero().reshape(-1)
 small[label+'_output_rows']=changed_rows.numpy()
 for arm,values in run['states'].items():
  small[label+'_'+arm+'_output_changed_rows_bits']=values['x_out'][changed_rows].contiguous().view(torch.int16).numpy()
np.savez_compressed(r/'bf16layout-t126-minimal-difference.npz',**small)
(r/'bf16layout-t126-control-exact-comparison.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
