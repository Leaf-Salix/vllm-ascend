"""抽象检查三槽协议：任意角色交错下不覆盖仍在使用的 KV/Score/Prob/PV。"""
import itertools
import json
import random
from collections import defaultdict
from pathlib import Path


def actors(valid):
    count = len(valid)
    cube = []
    for tick in range(count + 2):
        if tick < count and valid[tick]:
            cube.append(('wait', 'kv', tick))
            cube.extend(('read', 'kv', tick, lane) for lane in range(2))
            cube.extend(('write', 'score', tick, lane) for lane in range(2))
            cube.append(('set', 'score', tick, 0))
        work = tick - 2
        if 0 <= work < count and valid[work]:
            cube.append(('wait', 'prob', work))
            cube.extend(('read', resource, work, lane) for resource in ('kv', 'prob') for lane in range(2))
            cube.extend(('write', 'pv', work, lane) for lane in range(2))
            cube.append(('set', 'pv', work, 0))
    vectors = []
    for lane in range(2):
        seq = []
        for tick in range(count + 3):
            work = tick - 3
            if 0 <= work < count and valid[work]:
                seq.append(('wait', 'pv', work))
                seq.extend(('read', r, work, lane) for r in ('pv', 'stats'))
            if tick < count and valid[tick]:
                seq.extend([('write', 'kv', tick, lane), ('set', 'kv', tick, lane)])
            work = tick - 1
            if 0 <= work < count and valid[work]:
                seq.append(('wait', 'score', work))
                seq.append(('read', 'score', work, lane))
                seq.extend(('write', r, work, lane) for r in ('prob', 'stats'))
                seq.append(('set', 'prob', work, lane))
        vectors.append(seq)
    return [cube, *vectors]


def run(valid, seed):
    programs = actors(valid)
    pos = [0, 0, 0]
    event = defaultdict(set)
    storage = {}
    steps = 0
    rng = random.Random(seed)
    while any(pos[a] < len(programs[a]) for a in range(3)):
        available = []
        for a in range(3):
            if pos[a] == len(programs[a]):
                continue
            op, kind, work, *lane = programs[a][pos[a]]
            expected = {0, 1} if kind in ('kv', 'prob') else {a - 1}
            if op != 'wait' or expected.issubset(event[kind, work % 3]):
                available.append(a)
        assert available, ('deadlock', valid, seed, pos)
        a = rng.choice(available)
        op, kind, work, *lane = programs[a][pos[a]]
        if op == 'set':
            posted = {lane[0]} if kind in ('kv', 'prob') else {0, 1}
            assert not (event[kind, work % 3] & posted), ('binary flag repost before wait',kind,work,lane)
            event[kind, work % 3].update(posted)
        elif op == 'wait':
            consumed = {0, 1} if kind in ('kv', 'prob') else {a - 1}
            event[kind, work % 3].difference_update(consumed)
        elif op == 'write':
            storage[kind, work % 3, lane[0]] = work
        elif op == 'read':
            assert storage.get((kind, work % 3, lane[0])) == work, (
                'ring overwrite/stale read', kind, work, lane, storage, seed)
        pos[a] += 1
        steps += 1
    return steps


def main():
    runs = steps = masks = 0
    for queries in range(5):
        for mask in itertools.product((False, True), repeat=queries * 2):
            masks += 1
            for seed in range(32):
                steps += run(mask, seed)
                runs += 1
    rng = random.Random(20261026)
    for case in range(256):
        queries = rng.randint(1, 64)
        mask = [rng.choice((False, True)) for _ in range(queries * 2)]
        masks += 1
        for seed in range(8):
            steps += run(mask, case * 8 + seed)
            runs += 1
    report = {'pass': True, 'masks': masks, 'interleavings': runs, 'steps': steps,
              'slots': 3, 'event_model': '12 binary flags, per-slot/per-lane set and consuming wait with no counters', 'actors': ['AIC', 'AIV0', 'AIV1'],
              'covers': ['all validity masks for0..4queries', '256 random masks up to64queries',
                         'KV preserved for QK and PV', 'all score/prob/stats/PV consumers see their generation',
                         'empty work and pipeline tail drain', 'both lane readiness'],
              'limitation': 'abstract source protocol only; compiler fences, DMA lifetimes and NPU execution require independent verification'}
    p = Path(__file__).with_name('PIPELINE_PROTOCOL.json')
    p.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
