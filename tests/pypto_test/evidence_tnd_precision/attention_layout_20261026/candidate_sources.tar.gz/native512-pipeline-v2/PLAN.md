# Native K512跨query流水验证方案

控制为已推送11b380e3f，当前候选不进入正式目录。

## 机制

参考nalinaly三槽tick编排，保留我们的NativeK512在线softmax、actualK归约、probability CAST_ROUND、PV K32递增累加、BF16归一化和inverseRoPE。不得改成nalinaly每128候选独立softmax。Cube做QK(tick)、PV(tick-2)；两AIV先归并PV(tick-3)，确认旧槽消费完成后gather(tick)，再做Native softmax(tick-1)。同一query的m/l在softmax阶段有顺序依赖；output左右累加在延后merge阶段有自己的顺序依赖，独立储存，避免下一query覆盖前一query状态。

## 代价及风险

增加三槽GM scratch；Cube为PV重载全部四个K128 panel，放弃旧实现保留两panel的L1复用。流水收益可能被额外MTE2抵消，性能必须实测。invalid两块、dummy请求、首尾排空、双lane异步速度都需验证。纯DSL，不改SDK/codegen。v1初审发现copy64单core scratch错误使用三槽索引，及原模型按work分配虚拟事件而未模拟binary复用。v1未提交设备。v2将copy64恢复单core地址；四种事件每槽独立，event=kind+4*slot，共12个编号0..11，保留14/15给编译器。新模型按每槽每lane二进制位set、wait消费clear，拒绝未消费重复set。通过模型仍不能替代生成物或设备验证。

## 门禁

1. 两臂现有SDK CPU64参编译/load/NPUfalse；生成资源、out别名、事件和buffer生命周期独立审查。
2. 单卡8K/B32 FULL graph先性能：12×100交替event窗口、9独立L1；至少0.5%收益、10/12配对领先、L1下降。未过则停止并保留结果。
3. 胜出后Native A/B八边界、ABA、guard和readonly检查，首差立即停止定位；反向capture复测，再128K/B16与mixedT126。
4. 稳定收益且Native逐位后才整模型8K/B40→128K/B24，复用gold、warm192+measured192，每任务内750/外780秒，不跑Native2。
