"""Compile entire roots and actual native ABI without initializing NPU."""
import hashlib, importlib, json, os, runpy, sys, traceback, types
from pathlib import Path
root=Path(__file__).resolve().parent
arm=sys.argv[1]
assert arm in ('baseline','candidate')
runpy.run_path(str(root/'sdk_bind.py'),run_name='__sdk_preflight__')
import torch_npu
assert not torch_npu.npu.is_initialized()
from source_identity import source_identity
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program
from pypto.runtime._kernel_artifact import KernelArtifact
out=root/('cpu-'+arm)
out.mkdir(exist_ok=False)
record={'pass':False,'device_execution':False,'arm':arm,'source':source_identity(),
        'sdk':json.loads(Path(os.environ['PREFLIGHT_RECEIPT']).read_text()),
        'helper_manifest_sha256':hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest(),
        'candidate_source_sha256':hashlib.sha256((root/'SOURCE.json').read_bytes()).hexdigest()}
try:
 from load_candidate import entry_for
 program=entry_for(arm).specialize()
 abi=kernel_abi_for_program(program,platform='a2a3',runtime='tensormap_and_ringbuffer')
 record['root_tensors']=len(abi.parameters)
 assert record['root_tensors']==64
 _compile_impl(program,output_dir=str(out/'kernel'),platform='a2a3',skip_ptoas=False,_kernel_abi=abi)
 if arm=='candidate':
  assert (out/'kernel/ptoas/oproj_bf16_quant.cpp').is_file(),'candidate fused leaf missing'
  assert not (out/'kernel/ptoas/oproj_a_bf16.cpp').exists(),'old materialization leaf still present'
  assert not (out/'kernel/ptoas/oproj_quant.cpp').exists(),'old quant leaf still present'
 artifact=KernelArtifact(out/'kernel',abi);artifact.load()
 record['artifact_identity']=artifact.identity().hex()
 record['npu_initialized']=torch_npu.npu.is_initialized()
 assert record['npu_initialized'] is False
 record['pass']=True
except BaseException:
 record['error']=traceback.format_exc()
finally:
 (out/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record,indent=2),flush=True)
if not record['pass']:raise SystemExit(1)
