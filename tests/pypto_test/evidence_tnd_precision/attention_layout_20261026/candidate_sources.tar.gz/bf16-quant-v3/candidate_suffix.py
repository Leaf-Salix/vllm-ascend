# SPDX-License-Identifier: Apache-2.0
"""借鉴nalinaly输出融合编排，保留我方Native数值体；独立诊断候选。"""

import pypto.language as pl

from ..deepseek_v4_flash_csa_tnd_precision.nz_mode import QUANT_WEIGHT_LAYOUT, WO_A_WEIGHT_LAYOUT

T = pl.dynamic("FULL_PRECISION_OPROJ_T")


def _o_proj_hcpost(
    heads: pl.Tensor[[T, 32768], pl.BF16],
    wo_a: pl.Tensor[[8, 4096, 1024], pl.BF16, WO_A_WEIGHT_LAYOUT],
    wo_b: pl.Tensor[[8192, 4096], pl.INT8, QUANT_WEIGHT_LAYOUT],
    wo_b_scale: pl.Tensor[[4096], pl.FP32],
    start: pl.Tensor[[16, 8, 8], pl.INT32],
    projected: pl.Out[pl.Tensor[[T, 8192], pl.BF16]],
    quantized: pl.Out[pl.Tensor[[T, 8192], pl.INT8]],
    token_scale: pl.Out[pl.Tensor[[T, 1], pl.FP32]],
    residual: pl.Tensor[[T, 4, 4096], pl.BF16],
    post: pl.Tensor[[T, 4], pl.FP32],
    comb: pl.Tensor[[T, 16], pl.FP32],
    output: pl.Out[pl.Tensor[[T, 4, 4096], pl.BF16]],
):
    heads.bind_dynamic(0, T)
    projected.bind_dynamic(0, T)
    quantized.bind_dynamic(0, T)
    token_scale.bind_dynamic(0, T)
    residual.bind_dynamic(0, T)
    post.bind_dynamic(0, T)
    comb.bind_dynamic(0, T)
    output.bind_dynamic(0, T)
    rows = pl.tensor.dim(heads, 0)
    row_tiles = (rows + 15) // 16
    accum = pl.create_tensor([rows + 127, 8192], dtype=pl.FP32)
    if rows >= 192:
        for seed_group in pl.parallel(8):
            for seed_block in pl.spmd(8, name_hint="oproj_a"):
                seed_col = seed_block * 128
                for seed_panel in pl.range((row_tiles + 7) // 8):
                    seed_first_rb = seed_panel * 8
                    seed_first_start = pl.max(pl.read(start, [seed_first_rb, seed_group, seed_block]), 0)
                    seed_same_start = 1
                    if seed_first_rb + 1 < row_tiles:
                        if pl.max(pl.read(start, [seed_first_rb + 1, seed_group, seed_block]), 0) != seed_first_start:
                            seed_same_start = 0
                    if seed_first_rb + 2 < row_tiles:
                        if pl.max(pl.read(start, [seed_first_rb + 2, seed_group, seed_block]), 0) != seed_first_start:
                            seed_same_start = 0
                    if seed_first_rb + 3 < row_tiles:
                        if pl.max(pl.read(start, [seed_first_rb + 3, seed_group, seed_block]), 0) != seed_first_start:
                            seed_same_start = 0
                    if seed_first_rb + 4 < row_tiles:
                        if pl.max(pl.read(start, [seed_first_rb + 4, seed_group, seed_block]), 0) != seed_first_start:
                            seed_same_start = 0
                    if seed_first_rb + 5 < row_tiles:
                        if pl.max(pl.read(start, [seed_first_rb + 5, seed_group, seed_block]), 0) != seed_first_start:
                            seed_same_start = 0
                    if seed_first_rb + 6 < row_tiles:
                        if pl.max(pl.read(start, [seed_first_rb + 6, seed_group, seed_block]), 0) != seed_first_start:
                            seed_same_start = 0
                    if seed_first_rb + 7 < row_tiles:
                        if pl.max(pl.read(start, [seed_first_rb + 7, seed_group, seed_block]), 0) != seed_first_start:
                            seed_same_start = 0
                    if rows <= 16:
                        seed_same_start = 0
                    if seed_first_start > 240:
                        seed_same_start = 0
                    if seed_same_start == 1:
                        seed_fast_row = seed_first_rb * 16
                        seed_fast_valid = pl.min(128, rows - seed_fast_row)
                        seed_fast_seed_k = seed_first_start * 16
                        seed_fast_seed_x = pl.slice(
                            heads,
                            [128, 256],
                            [seed_fast_row, seed_group * 4096 + seed_fast_seed_k],
                            valid_shape=[seed_fast_valid, 256],
                        )
                        seed_fast_seed_w = wo_a[
                            seed_group : seed_group + 1,
                            seed_fast_seed_k : seed_fast_seed_k + 256,
                            seed_col : seed_col + 128,
                        ]
                        seed_fast_acc = pl.matmul(seed_fast_seed_x, seed_fast_seed_w, out_dtype=pl.FP32)
                        for seed_fast_packet in pl.pipeline(1, 16, stage=2):
                            seed_fast_packet_kb = (seed_first_start + seed_fast_packet * 16) % 256
                            if seed_fast_packet_kb <= 240:
                                seed_fast_packet_k = seed_fast_packet_kb * 16
                                seed_fast_packet_x = pl.slice(
                                    heads,
                                    [128, 256],
                                    [seed_fast_row, seed_group * 4096 + seed_fast_packet_k],
                                    valid_shape=[seed_fast_valid, 256],
                                )
                                seed_fast_packet_w = wo_a[
                                    seed_group : seed_group + 1,
                                    seed_fast_packet_k : seed_fast_packet_k + 256,
                                    seed_col : seed_col + 128,
                                ]
                                seed_fast_acc = pl.matmul_acc(
                                    seed_fast_acc, seed_fast_packet_x, seed_fast_packet_w, init_cond=False
                                )
                            else:
                                for seed_fast_inner in pl.range(16):
                                    seed_fast_wrap_k = (seed_fast_packet_kb + seed_fast_inner) % 256 * 16
                                    seed_fast_wrap_x = pl.slice(
                                        heads,
                                        [128, 16],
                                        [seed_fast_row, seed_group * 4096 + seed_fast_wrap_k],
                                        valid_shape=[seed_fast_valid, 16],
                                    )
                                    seed_fast_wrap_w = wo_a[
                                        seed_group : seed_group + 1,
                                        seed_fast_wrap_k : seed_fast_wrap_k + 16,
                                        seed_col : seed_col + 128,
                                    ]
                                    seed_fast_acc = pl.matmul_acc(
                                        seed_fast_acc, seed_fast_wrap_x, seed_fast_wrap_w, init_cond=False
                                    )
                        accum = pl.assemble(accum, seed_fast_acc, [seed_fast_row, seed_group * 1024 + seed_col])
                    else:
                        for seed_local_rb in pl.range(8):
                            seed_narrow_rb = seed_first_rb + seed_local_rb
                            if seed_narrow_rb < row_tiles:
                                seed_narrow_row = seed_narrow_rb * 16
                                seed_narrow_valid = pl.min(16, rows - seed_narrow_row)
                                seed_narrow_first_block = pl.max(
                                    pl.read(start, [seed_narrow_rb, seed_group, seed_block]), 0
                                )
                                seed_narrow_acc = pl.create_tensor([1, 16, 128], dtype=pl.FP32)
                                for seed_narrow_packet in pl.range(16):
                                    seed_narrow_packet_kb = (seed_narrow_first_block + seed_narrow_packet * 16) % 256
                                    if seed_narrow_packet_kb <= 240:
                                        seed_narrow_packet_k = seed_narrow_packet_kb * 16
                                        seed_narrow_packet_x = pl.slice(
                                            heads,
                                            [16, 256],
                                            [seed_narrow_row, seed_group * 4096 + seed_narrow_packet_k],
                                            valid_shape=[seed_narrow_valid, 256],
                                        )
                                        seed_narrow_packet_w = wo_a[
                                            seed_group : seed_group + 1,
                                            seed_narrow_packet_k : seed_narrow_packet_k + 256,
                                            seed_col : seed_col + 128,
                                        ]
                                        seed_narrow_acc = pl.matmul_acc(
                                            seed_narrow_acc,
                                            seed_narrow_packet_x,
                                            seed_narrow_packet_w,
                                            init_cond=seed_narrow_packet == 0,
                                        )
                                    else:
                                        for seed_narrow_inner in pl.range(16):
                                            seed_narrow_wrap_k = (seed_narrow_packet_kb + seed_narrow_inner) % 256 * 16
                                            seed_narrow_wrap_x = pl.slice(
                                                heads,
                                                [16, 16],
                                                [seed_narrow_row, seed_group * 4096 + seed_narrow_wrap_k],
                                                valid_shape=[seed_narrow_valid, 16],
                                            )
                                            seed_narrow_wrap_w = wo_a[
                                                seed_group : seed_group + 1,
                                                seed_narrow_wrap_k : seed_narrow_wrap_k + 16,
                                                seed_col : seed_col + 128,
                                            ]
                                            seed_narrow_acc = pl.matmul_acc(
                                                seed_narrow_acc,
                                                seed_narrow_wrap_x,
                                                seed_narrow_wrap_w,
                                                init_cond=seed_narrow_packet * 16 + seed_narrow_inner == 0,
                                            )
                                accum = pl.assemble(
                                    accum, seed_narrow_acc, [seed_narrow_row, seed_group * 1024 + seed_col]
                                )
    else:
        for v4_group in pl.parallel(8):
            for v4_block in pl.spmd(8, name_hint="oproj_a"):
                v4_col = v4_block * 128
                for v4_panel in pl.range((row_tiles + 7) // 8):
                    v4_first_rb = v4_panel * 8
                    v4_first_start = pl.max(pl.read(start, [v4_first_rb, v4_group, v4_block]), 0)
                    v4_same_start = 1
                    if v4_first_rb + 1 < row_tiles:
                        if pl.max(pl.read(start, [v4_first_rb + 1, v4_group, v4_block]), 0) != v4_first_start:
                            v4_same_start = 0
                    if v4_first_rb + 2 < row_tiles:
                        if pl.max(pl.read(start, [v4_first_rb + 2, v4_group, v4_block]), 0) != v4_first_start:
                            v4_same_start = 0
                    if v4_first_rb + 3 < row_tiles:
                        if pl.max(pl.read(start, [v4_first_rb + 3, v4_group, v4_block]), 0) != v4_first_start:
                            v4_same_start = 0
                    if v4_first_rb + 4 < row_tiles:
                        if pl.max(pl.read(start, [v4_first_rb + 4, v4_group, v4_block]), 0) != v4_first_start:
                            v4_same_start = 0
                    if v4_first_rb + 5 < row_tiles:
                        if pl.max(pl.read(start, [v4_first_rb + 5, v4_group, v4_block]), 0) != v4_first_start:
                            v4_same_start = 0
                    if v4_first_rb + 6 < row_tiles:
                        if pl.max(pl.read(start, [v4_first_rb + 6, v4_group, v4_block]), 0) != v4_first_start:
                            v4_same_start = 0
                    if v4_first_rb + 7 < row_tiles:
                        if pl.max(pl.read(start, [v4_first_rb + 7, v4_group, v4_block]), 0) != v4_first_start:
                            v4_same_start = 0
                    if rows <= 16:
                        v4_same_start = 0
                    if v4_same_start == 1:
                        v4_wide_row = v4_first_rb * 16
                        v4_wide_valid = pl.min(128, rows - v4_wide_row)
                        v4_wide_first_block = v4_first_start
                        v4_wide_seed_k = v4_wide_first_block % 256 * 16
                        v4_wide_seed_x = pl.slice(
                            heads,
                            [128, 16],
                            [v4_wide_row, v4_group * 4096 + v4_wide_seed_k],
                            valid_shape=[v4_wide_valid, 16],
                        )
                        v4_wide_seed_w = wo_a[
                            v4_group : v4_group + 1, v4_wide_seed_k : v4_wide_seed_k + 16, v4_col : v4_col + 128
                        ]
                        v4_wide_acc = pl.matmul(v4_wide_seed_x, v4_wide_seed_w, out_dtype=pl.FP32)
                        for v4_wide_packet in pl.pipeline(15, stage=2):
                            v4_wide_packet_kb = (v4_wide_first_block + 1 + v4_wide_packet * 16) % 256
                            if v4_wide_packet_kb <= 240:
                                v4_wide_packet_k = v4_wide_packet_kb * 16
                                v4_wide_packet_x = pl.slice(
                                    heads,
                                    [128, 256],
                                    [v4_wide_row, v4_group * 4096 + v4_wide_packet_k],
                                    valid_shape=[v4_wide_valid, 256],
                                )
                                v4_wide_packet_w = wo_a[
                                    v4_group : v4_group + 1,
                                    v4_wide_packet_k : v4_wide_packet_k + 256,
                                    v4_col : v4_col + 128,
                                ]
                                v4_wide_acc = pl.matmul_acc(
                                    v4_wide_acc, v4_wide_packet_x, v4_wide_packet_w, init_cond=False
                                )
                            else:
                                for v4_wide_inner in pl.range(16):
                                    v4_wide_wrap_k = (v4_wide_packet_kb + v4_wide_inner) % 256 * 16
                                    v4_wide_wrap_x = pl.slice(
                                        heads,
                                        [128, 16],
                                        [v4_wide_row, v4_group * 4096 + v4_wide_wrap_k],
                                        valid_shape=[v4_wide_valid, 16],
                                    )
                                    v4_wide_wrap_w = wo_a[
                                        v4_group : v4_group + 1,
                                        v4_wide_wrap_k : v4_wide_wrap_k + 16,
                                        v4_col : v4_col + 128,
                                    ]
                                    v4_wide_acc = pl.matmul_acc(
                                        v4_wide_acc, v4_wide_wrap_x, v4_wide_wrap_w, init_cond=False
                                    )
                        for v4_wide_tail in pl.range(241, 256):
                            v4_wide_tail_k = (v4_wide_first_block + v4_wide_tail) % 256 * 16
                            v4_wide_tail_x = pl.slice(
                                heads,
                                [128, 16],
                                [v4_wide_row, v4_group * 4096 + v4_wide_tail_k],
                                valid_shape=[v4_wide_valid, 16],
                            )
                            v4_wide_tail_w = wo_a[
                                v4_group : v4_group + 1, v4_wide_tail_k : v4_wide_tail_k + 16, v4_col : v4_col + 128
                            ]
                            v4_wide_acc = pl.matmul_acc(v4_wide_acc, v4_wide_tail_x, v4_wide_tail_w, init_cond=False)
                        accum = pl.assemble(accum, v4_wide_acc, [v4_wide_row, v4_group * 1024 + v4_col])
                    else:
                        for v4_local_rb in pl.range(8):
                            v4_narrow_rb = v4_first_rb + v4_local_rb
                            if v4_narrow_rb < row_tiles:
                                v4_narrow_row = v4_narrow_rb * 16
                                v4_narrow_valid = pl.min(16, rows - v4_narrow_row)
                                v4_narrow_first_block = pl.max(pl.read(start, [v4_narrow_rb, v4_group, v4_block]), 0)
                                v4_narrow_acc = pl.create_tensor([1, 16, 128], dtype=pl.FP32)
                                for v4_narrow_packet in pl.range(16):
                                    v4_narrow_packet_kb = (v4_narrow_first_block + v4_narrow_packet * 16) % 256
                                    if v4_narrow_packet_kb <= 240:
                                        v4_narrow_packet_k = v4_narrow_packet_kb * 16
                                        v4_narrow_packet_x = pl.slice(
                                            heads,
                                            [16, 256],
                                            [v4_narrow_row, v4_group * 4096 + v4_narrow_packet_k],
                                            valid_shape=[v4_narrow_valid, 256],
                                        )
                                        v4_narrow_packet_w = wo_a[
                                            v4_group : v4_group + 1,
                                            v4_narrow_packet_k : v4_narrow_packet_k + 256,
                                            v4_col : v4_col + 128,
                                        ]
                                        v4_narrow_acc = pl.matmul_acc(
                                            v4_narrow_acc,
                                            v4_narrow_packet_x,
                                            v4_narrow_packet_w,
                                            init_cond=v4_narrow_packet == 0,
                                        )
                                    else:
                                        for v4_narrow_inner in pl.range(16):
                                            v4_narrow_wrap_k = (v4_narrow_packet_kb + v4_narrow_inner) % 256 * 16
                                            v4_narrow_wrap_x = pl.slice(
                                                heads,
                                                [16, 16],
                                                [v4_narrow_row, v4_group * 4096 + v4_narrow_wrap_k],
                                                valid_shape=[v4_narrow_valid, 16],
                                            )
                                            v4_narrow_wrap_w = wo_a[
                                                v4_group : v4_group + 1,
                                                v4_narrow_wrap_k : v4_narrow_wrap_k + 16,
                                                v4_col : v4_col + 128,
                                            ]
                                            v4_narrow_acc = pl.matmul_acc(
                                                v4_narrow_acc,
                                                v4_narrow_wrap_x,
                                                v4_narrow_wrap_w,
                                                init_cond=v4_narrow_packet * 16 + v4_narrow_inner == 0,
                                            )
                                accum = pl.assemble(accum, v4_narrow_acc, [v4_narrow_row, v4_group * 1024 + v4_col])
    quant_rows = (rows + 7) // 8
    for block in pl.spmd(quant_rows, name_hint="oproj_bf16_quant"):
        row = block * 8
        valid = pl.min(8, rows - row)
        # Retain BF16 segments in UB until the Native global8192 scale is known.
        # 8 rows keep each ColMajor reduction output naturally 32-byte aligned.
        oa0 = pl.load(accum, [row, 0], [8, 512], valid_shape=[valid, 512])
        rounded0 = pl.cast(oa0, pl.BF16, mode="rint")
        pl.store(pl.set_validshape(rounded0, valid, 512), [row, 0], projected)
        magnitude0 = pl.row_max(pl.abs(pl.cast(rounded0, pl.FP32)), pl.create_tile([8, 512], dtype=pl.FP32))
        amax = magnitude0
        oa1 = pl.load(accum, [row, 512], [8, 512], valid_shape=[valid, 512])
        rounded1 = pl.cast(oa1, pl.BF16, mode="rint")
        pl.store(pl.set_validshape(rounded1, valid, 512), [row, 512], projected)
        magnitude1 = pl.row_max(pl.abs(pl.cast(rounded1, pl.FP32)), pl.create_tile([8, 512], dtype=pl.FP32))
        amax = pl.maximum(amax, magnitude1)
        oa2 = pl.load(accum, [row, 1024], [8, 512], valid_shape=[valid, 512])
        rounded2 = pl.cast(oa2, pl.BF16, mode="rint")
        pl.store(pl.set_validshape(rounded2, valid, 512), [row, 1024], projected)
        magnitude2 = pl.row_max(pl.abs(pl.cast(rounded2, pl.FP32)), pl.create_tile([8, 512], dtype=pl.FP32))
        amax = pl.maximum(amax, magnitude2)
        oa3 = pl.load(accum, [row, 1536], [8, 512], valid_shape=[valid, 512])
        rounded3 = pl.cast(oa3, pl.BF16, mode="rint")
        pl.store(pl.set_validshape(rounded3, valid, 512), [row, 1536], projected)
        magnitude3 = pl.row_max(pl.abs(pl.cast(rounded3, pl.FP32)), pl.create_tile([8, 512], dtype=pl.FP32))
        amax = pl.maximum(amax, magnitude3)
        oa4 = pl.load(accum, [row, 2048], [8, 512], valid_shape=[valid, 512])
        rounded4 = pl.cast(oa4, pl.BF16, mode="rint")
        pl.store(pl.set_validshape(rounded4, valid, 512), [row, 2048], projected)
        magnitude4 = pl.row_max(pl.abs(pl.cast(rounded4, pl.FP32)), pl.create_tile([8, 512], dtype=pl.FP32))
        amax = pl.maximum(amax, magnitude4)
        oa5 = pl.load(accum, [row, 2560], [8, 512], valid_shape=[valid, 512])
        rounded5 = pl.cast(oa5, pl.BF16, mode="rint")
        pl.store(pl.set_validshape(rounded5, valid, 512), [row, 2560], projected)
        magnitude5 = pl.row_max(pl.abs(pl.cast(rounded5, pl.FP32)), pl.create_tile([8, 512], dtype=pl.FP32))
        amax = pl.maximum(amax, magnitude5)
        oa6 = pl.load(accum, [row, 3072], [8, 512], valid_shape=[valid, 512])
        rounded6 = pl.cast(oa6, pl.BF16, mode="rint")
        pl.store(pl.set_validshape(rounded6, valid, 512), [row, 3072], projected)
        magnitude6 = pl.row_max(pl.abs(pl.cast(rounded6, pl.FP32)), pl.create_tile([8, 512], dtype=pl.FP32))
        amax = pl.maximum(amax, magnitude6)
        oa7 = pl.load(accum, [row, 3584], [8, 512], valid_shape=[valid, 512])
        rounded7 = pl.cast(oa7, pl.BF16, mode="rint")
        pl.store(pl.set_validshape(rounded7, valid, 512), [row, 3584], projected)
        magnitude7 = pl.row_max(pl.abs(pl.cast(rounded7, pl.FP32)), pl.create_tile([8, 512], dtype=pl.FP32))
        amax = pl.maximum(amax, magnitude7)
        oa8 = pl.load(accum, [row, 4096], [8, 512], valid_shape=[valid, 512])
        rounded8 = pl.cast(oa8, pl.BF16, mode="rint")
        pl.store(pl.set_validshape(rounded8, valid, 512), [row, 4096], projected)
        magnitude8 = pl.row_max(pl.abs(pl.cast(rounded8, pl.FP32)), pl.create_tile([8, 512], dtype=pl.FP32))
        amax = pl.maximum(amax, magnitude8)
        oa9 = pl.load(accum, [row, 4608], [8, 512], valid_shape=[valid, 512])
        rounded9 = pl.cast(oa9, pl.BF16, mode="rint")
        pl.store(pl.set_validshape(rounded9, valid, 512), [row, 4608], projected)
        magnitude9 = pl.row_max(pl.abs(pl.cast(rounded9, pl.FP32)), pl.create_tile([8, 512], dtype=pl.FP32))
        amax = pl.maximum(amax, magnitude9)
        oa10 = pl.load(accum, [row, 5120], [8, 512], valid_shape=[valid, 512])
        rounded10 = pl.cast(oa10, pl.BF16, mode="rint")
        pl.store(pl.set_validshape(rounded10, valid, 512), [row, 5120], projected)
        magnitude10 = pl.row_max(pl.abs(pl.cast(rounded10, pl.FP32)), pl.create_tile([8, 512], dtype=pl.FP32))
        amax = pl.maximum(amax, magnitude10)
        oa11 = pl.load(accum, [row, 5632], [8, 512], valid_shape=[valid, 512])
        rounded11 = pl.cast(oa11, pl.BF16, mode="rint")
        pl.store(pl.set_validshape(rounded11, valid, 512), [row, 5632], projected)
        magnitude11 = pl.row_max(pl.abs(pl.cast(rounded11, pl.FP32)), pl.create_tile([8, 512], dtype=pl.FP32))
        amax = pl.maximum(amax, magnitude11)
        oa12 = pl.load(accum, [row, 6144], [8, 512], valid_shape=[valid, 512])
        rounded12 = pl.cast(oa12, pl.BF16, mode="rint")
        pl.store(pl.set_validshape(rounded12, valid, 512), [row, 6144], projected)
        magnitude12 = pl.row_max(pl.abs(pl.cast(rounded12, pl.FP32)), pl.create_tile([8, 512], dtype=pl.FP32))
        amax = pl.maximum(amax, magnitude12)
        oa13 = pl.load(accum, [row, 6656], [8, 512], valid_shape=[valid, 512])
        rounded13 = pl.cast(oa13, pl.BF16, mode="rint")
        pl.store(pl.set_validshape(rounded13, valid, 512), [row, 6656], projected)
        magnitude13 = pl.row_max(pl.abs(pl.cast(rounded13, pl.FP32)), pl.create_tile([8, 512], dtype=pl.FP32))
        amax = pl.maximum(amax, magnitude13)
        oa14 = pl.load(accum, [row, 7168], [8, 512], valid_shape=[valid, 512])
        rounded14 = pl.cast(oa14, pl.BF16, mode="rint")
        pl.store(pl.set_validshape(rounded14, valid, 512), [row, 7168], projected)
        magnitude14 = pl.row_max(pl.abs(pl.cast(rounded14, pl.FP32)), pl.create_tile([8, 512], dtype=pl.FP32))
        amax = pl.maximum(amax, magnitude14)
        oa15 = pl.load(accum, [row, 7680], [8, 512], valid_shape=[valid, 512])
        rounded15 = pl.cast(oa15, pl.BF16, mode="rint")
        pl.store(pl.set_validshape(rounded15, valid, 512), [row, 7680], projected)
        magnitude15 = pl.row_max(pl.abs(pl.cast(rounded15, pl.FP32)), pl.create_tile([8, 512], dtype=pl.FP32))
        amax = pl.maximum(amax, magnitude15)
        dequant = pl.mul(amax, 1.0 / 127.0)
        denominator = pl.add(amax, 0.0)
        for lane in pl.range(valid):
            magnitude = pl.read(denominator, [lane, 0])
            if magnitude == 0.0:
                pl.write(denominator, [lane, 0], 1.0)
        multiplier = pl.div(pl.add(pl.mul(amax, 0.0), 127.0), denominator)
        pl.store(pl.set_validshape(dequant, valid, 1), [row, 0], token_scale)
        scaled0 = pl.row_expand_mul(pl.cast(rounded0, pl.FP32), multiplier)
        integer0 = pl.cast(scaled0, pl.INT32, mode="rint")
        half0 = pl.cast(integer0, pl.FP16, mode="round")
        result0 = pl.cast(half0, pl.INT8, mode="trunc")
        pl.store(pl.set_validshape(result0, valid, 512), [row, 0], quantized)
        scaled1 = pl.row_expand_mul(pl.cast(rounded1, pl.FP32), multiplier)
        integer1 = pl.cast(scaled1, pl.INT32, mode="rint")
        half1 = pl.cast(integer1, pl.FP16, mode="round")
        result1 = pl.cast(half1, pl.INT8, mode="trunc")
        pl.store(pl.set_validshape(result1, valid, 512), [row, 512], quantized)
        scaled2 = pl.row_expand_mul(pl.cast(rounded2, pl.FP32), multiplier)
        integer2 = pl.cast(scaled2, pl.INT32, mode="rint")
        half2 = pl.cast(integer2, pl.FP16, mode="round")
        result2 = pl.cast(half2, pl.INT8, mode="trunc")
        pl.store(pl.set_validshape(result2, valid, 512), [row, 1024], quantized)
        scaled3 = pl.row_expand_mul(pl.cast(rounded3, pl.FP32), multiplier)
        integer3 = pl.cast(scaled3, pl.INT32, mode="rint")
        half3 = pl.cast(integer3, pl.FP16, mode="round")
        result3 = pl.cast(half3, pl.INT8, mode="trunc")
        pl.store(pl.set_validshape(result3, valid, 512), [row, 1536], quantized)
        scaled4 = pl.row_expand_mul(pl.cast(rounded4, pl.FP32), multiplier)
        integer4 = pl.cast(scaled4, pl.INT32, mode="rint")
        half4 = pl.cast(integer4, pl.FP16, mode="round")
        result4 = pl.cast(half4, pl.INT8, mode="trunc")
        pl.store(pl.set_validshape(result4, valid, 512), [row, 2048], quantized)
        scaled5 = pl.row_expand_mul(pl.cast(rounded5, pl.FP32), multiplier)
        integer5 = pl.cast(scaled5, pl.INT32, mode="rint")
        half5 = pl.cast(integer5, pl.FP16, mode="round")
        result5 = pl.cast(half5, pl.INT8, mode="trunc")
        pl.store(pl.set_validshape(result5, valid, 512), [row, 2560], quantized)
        scaled6 = pl.row_expand_mul(pl.cast(rounded6, pl.FP32), multiplier)
        integer6 = pl.cast(scaled6, pl.INT32, mode="rint")
        half6 = pl.cast(integer6, pl.FP16, mode="round")
        result6 = pl.cast(half6, pl.INT8, mode="trunc")
        pl.store(pl.set_validshape(result6, valid, 512), [row, 3072], quantized)
        scaled7 = pl.row_expand_mul(pl.cast(rounded7, pl.FP32), multiplier)
        integer7 = pl.cast(scaled7, pl.INT32, mode="rint")
        half7 = pl.cast(integer7, pl.FP16, mode="round")
        result7 = pl.cast(half7, pl.INT8, mode="trunc")
        pl.store(pl.set_validshape(result7, valid, 512), [row, 3584], quantized)
        scaled8 = pl.row_expand_mul(pl.cast(rounded8, pl.FP32), multiplier)
        integer8 = pl.cast(scaled8, pl.INT32, mode="rint")
        half8 = pl.cast(integer8, pl.FP16, mode="round")
        result8 = pl.cast(half8, pl.INT8, mode="trunc")
        pl.store(pl.set_validshape(result8, valid, 512), [row, 4096], quantized)
        scaled9 = pl.row_expand_mul(pl.cast(rounded9, pl.FP32), multiplier)
        integer9 = pl.cast(scaled9, pl.INT32, mode="rint")
        half9 = pl.cast(integer9, pl.FP16, mode="round")
        result9 = pl.cast(half9, pl.INT8, mode="trunc")
        pl.store(pl.set_validshape(result9, valid, 512), [row, 4608], quantized)
        scaled10 = pl.row_expand_mul(pl.cast(rounded10, pl.FP32), multiplier)
        integer10 = pl.cast(scaled10, pl.INT32, mode="rint")
        half10 = pl.cast(integer10, pl.FP16, mode="round")
        result10 = pl.cast(half10, pl.INT8, mode="trunc")
        pl.store(pl.set_validshape(result10, valid, 512), [row, 5120], quantized)
        scaled11 = pl.row_expand_mul(pl.cast(rounded11, pl.FP32), multiplier)
        integer11 = pl.cast(scaled11, pl.INT32, mode="rint")
        half11 = pl.cast(integer11, pl.FP16, mode="round")
        result11 = pl.cast(half11, pl.INT8, mode="trunc")
        pl.store(pl.set_validshape(result11, valid, 512), [row, 5632], quantized)
        scaled12 = pl.row_expand_mul(pl.cast(rounded12, pl.FP32), multiplier)
        integer12 = pl.cast(scaled12, pl.INT32, mode="rint")
        half12 = pl.cast(integer12, pl.FP16, mode="round")
        result12 = pl.cast(half12, pl.INT8, mode="trunc")
        pl.store(pl.set_validshape(result12, valid, 512), [row, 6144], quantized)
        scaled13 = pl.row_expand_mul(pl.cast(rounded13, pl.FP32), multiplier)
        integer13 = pl.cast(scaled13, pl.INT32, mode="rint")
        half13 = pl.cast(integer13, pl.FP16, mode="round")
        result13 = pl.cast(half13, pl.INT8, mode="trunc")
        pl.store(pl.set_validshape(result13, valid, 512), [row, 6656], quantized)
        scaled14 = pl.row_expand_mul(pl.cast(rounded14, pl.FP32), multiplier)
        integer14 = pl.cast(scaled14, pl.INT32, mode="rint")
        half14 = pl.cast(integer14, pl.FP16, mode="round")
        result14 = pl.cast(half14, pl.INT8, mode="trunc")
        pl.store(pl.set_validshape(result14, valid, 512), [row, 7168], quantized)
        scaled15 = pl.row_expand_mul(pl.cast(rounded15, pl.FP32), multiplier)
        integer15 = pl.cast(scaled15, pl.INT32, mode="rint")
        half15 = pl.cast(integer15, pl.FP16, mode="round")
        result15 = pl.cast(half15, pl.INT8, mode="trunc")
        pl.store(pl.set_validshape(result15, valid, 512), [row, 7680], quantized)
    integer_accum = pl.create_tensor([rows + 63, 4096], dtype=pl.INT32)
    if rows <= 16:
        for block in pl.spmd(row_tiles * 32, name_hint="oproj_b"):
            row = block // 32 * 16
            col = pl.max(block % 32, 0) * 128
            valid = pl.min(16, rows - row)
            b_acc = pl.create_tensor([16, 128], dtype=pl.INT32)
            for step in pl.range(16):
                k = step * 512
                b_input = pl.slice(quantized, [16, 512], [row, k], valid_shape=[valid, 512])
                b_weight = wo_b[k : k + 512, col : col + 128]
                b_acc = pl.matmul_acc(b_acc, b_input, b_weight, init_cond=step == 0)
            integer_accum[row : row + 16, col : col + 128] = b_acc
    else:
        for wide_block in pl.spmd((rows + 63) // 64 * 32, name_hint="oproj_b64"):
            wide_row = wide_block // 32 * 64
            wide_col = pl.max(wide_block % 32, 0) * 128
            wide_valid = pl.min(64, rows - wide_row)
            wide_first_input = pl.slice(quantized, [64, 512], [wide_row, 0], valid_shape=[wide_valid, 512])
            wide_first_weight = wo_b[0:512, wide_col : wide_col + 128]
            wide_b_acc = pl.matmul(wide_first_input, wide_first_weight, out_dtype=pl.INT32)
            for wide_step in pl.range(1, 16):
                wide_k = wide_step * 512
                wide_b_input = pl.slice(quantized, [64, 512], [wide_row, wide_k], valid_shape=[wide_valid, 512])
                wide_b_weight = wo_b[wide_k : wide_k + 512, wide_col : wide_col + 128]
                wide_b_acc = pl.matmul_acc(wide_b_acc, wide_b_input, wide_b_weight, init_cond=False)
            integer_accum = pl.assemble(integer_accum, wide_b_acc, [wide_row, wide_col])
    residual_flat = pl.reshape(residual, [rows, 16384])
    output_flat = pl.reshape(output, [rows, 16384])
    # Match Native channel*token scale and the attended BF16 publication.
    # Fusion only removes the attended GM store/reload and task handoff.
    for token_block in pl.spmd((rows + 3) // 4, name_hint="oproj_dequant_hcpost"):
        first = token_block * 4
        for row in pl.pipeline(first, first + 4, stage=2):
            if row < rows:
                ob_integer = pl.load(integer_accum, [row, 0], [1, 4096])
                channel = pl.reshape(pl.load(wo_b_scale, [0], [4096]), [1, 4096])
                scale = pl.read(token_scale, [row, 0])
                coefficient_one = pl.tile.full([1, 4096], dtype=pl.FP32, value=1.0)
                coefficient_channel = pl.col_expand_mul(coefficient_one, channel)
                coefficient = pl.mul(coefficient_channel, scale)
                ob_scaled = pl.mul(pl.cast(ob_integer, pl.FP32), coefficient)
                attended_bf16 = pl.cast(ob_scaled, pl.BF16, mode="rint")
                x_f32 = pl.cast(attended_bf16, pl.FP32)
                res_0 = pl.cast(pl.load(residual_flat, [row, 0], [1, 4096], valid_shape=[1, 4096]), pl.FP32)
                res_1 = pl.cast(pl.load(residual_flat, [row, 4096 + 0], [1, 4096], valid_shape=[1, 4096]), pl.FP32)
                res_2 = pl.cast(pl.load(residual_flat, [row, 2 * 4096 + 0], [1, 4096], valid_shape=[1, 4096]), pl.FP32)
                res_3 = pl.cast(pl.load(residual_flat, [row, 3 * 4096 + 0], [1, 4096], valid_shape=[1, 4096]), pl.FP32)
                for out_h in pl.unroll(4):
                    post_scalar = pl.read(post, [row, out_h])
                    single_y = pl.mul(x_f32, post_scalar)
                    comb_scalar_0 = pl.read(comb, [row, out_h])
                    single_weighted_0 = pl.mul(res_0, comb_scalar_0)
                    single_y = pl.add(single_y, single_weighted_0)
                    comb_scalar_1 = pl.read(comb, [row, 4 + out_h])
                    single_weighted_1 = pl.mul(res_1, comb_scalar_1)
                    single_y = pl.add(single_y, single_weighted_1)
                    comb_scalar_2 = pl.read(comb, [row, 2 * 4 + out_h])
                    single_weighted_2 = pl.mul(res_2, comb_scalar_2)
                    single_y = pl.add(single_y, single_weighted_2)
                    comb_scalar_3 = pl.read(comb, [row, 3 * 4 + out_h])
                    single_weighted_3 = pl.mul(res_3, comb_scalar_3)
                    single_y = pl.add(single_y, single_weighted_3)
                    single_result = pl.cast(single_y, pl.BF16, mode="rint")
                    pl.store(pl.set_validshape(single_result, 1, 4096), [row, out_h * 4096], output_flat)
    return output


o_proj_hcpost_entry = pl.jit.inline(auto_scope=False)(_o_proj_hcpost)
o_proj_hcpost_test = pl.jit(_o_proj_hcpost)
