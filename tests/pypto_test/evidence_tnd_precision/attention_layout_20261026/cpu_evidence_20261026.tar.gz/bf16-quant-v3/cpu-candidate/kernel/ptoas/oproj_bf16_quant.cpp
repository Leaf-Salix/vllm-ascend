#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_bf16_quant(__gm__ float* v1, __gm__ bfloat16_t* v2, __gm__ float* v3, __gm__ int8_t* v4, int64_t v5, int64_t v6, int64_t v7, int32_t v8, int32_t v9) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c57408_i64
  const int64_t v10 = 57408;
  // pto: %c81984_i64
  const int64_t v11 = 81984;
  // pto: %c122944_i64
  const int64_t v12 = 122944;
  // pto: %c24640_i64
  const int64_t v13 = 24640;
  // pto: %c16416_i64
  const int64_t v14 = 16416;
  // pto: %c32832_i64
  const int64_t v15 = 32832;
  // pto: %c41024_i64
  const int64_t v16 = 41024;
  // pto: %c49216_i64
  const int64_t v17 = 49216;
  // pto: %c73792_i64
  const int64_t v18 = 73792;
  // pto: %c90176_i64
  const int64_t v19 = 90176;
  // pto: %c98368_i64
  const int64_t v20 = 98368;
  // pto: %c106560_i64
  const int64_t v21 = 106560;
  // pto: %c114752_i64
  const int64_t v22 = 114752;
  // pto: %c139328_i64
  const int64_t v23 = 139328;
  // pto: %c147520_i64
  const int64_t v24 = 147520;
  // pto: %c155712_i64
  const int64_t v25 = 155712;
  // pto: %c0_i64
  const int64_t v26 = 0;
  // pto: %c8224_i64
  const int64_t v27 = 8224;
  // pto: %c8192_i64
  const int64_t v28 = 8192;
  // pto: %c24608_i64
  const int64_t v29 = 24608;
  // pto: %c8192_index
  const int64_t v30 = 8192;
  // pto: %c1_index
  const int64_t v31 = 1;
  // pto: %c8_index
  const int64_t v32 = 8;
  // pto: %c512_index
  const int64_t v33 = 512;
  // pto: %c0_index
  const int64_t v34 = 0;
  // pto: %c1024_index
  const int64_t v35 = 1024;
  // pto: %c1536_index
  const int64_t v36 = 1536;
  // pto: %c2048_index
  const int64_t v37 = 2048;
  // pto: %c2560_index
  const int64_t v38 = 2560;
  // pto: %c3072_index
  const int64_t v39 = 3072;
  // pto: %c3584_index
  const int64_t v40 = 3584;
  // pto: %c4096_index
  const int64_t v41 = 4096;
  // pto: %c4608_index
  const int64_t v42 = 4608;
  // pto: %c5120_index
  const int64_t v43 = 5120;
  // pto: %c5632_index
  const int64_t v44 = 5632;
  // pto: %c6144_index
  const int64_t v45 = 6144;
  // pto: %c6656_index
  const int64_t v46 = 6656;
  // pto: %c7168_index
  const int64_t v47 = 7168;
  // pto: %c7680_index
  const int64_t v48 = 7680;
  // pto: %cst_39
  const float v49 = 0.00787401571f;
  // pto: %cst_40
  const float v50 = 0.0f;
  // pto: %cst_41
  const float v51 = 1.0f;
  // pto: %cst_42
  const float v52 = 127.0f;
  // pto: %c127_index
  const int64_t v53 = 127;
  // pto: %100
  int64_t v54 = (int64_t) ((uint64_t) v6 + (uint64_t) v53);
  // pto: %accum_inline1065__phi_v21_view
  const int64_t v55 = 1;
  // pto: %accum_inline1065__phi_v21_view
  const int64_t v56 = 1;
  // pto: %accum_inline1065__phi_v21_view
  const int64_t v57 = 1;
  // pto: %accum_inline1065__phi_v21_view
  int64_t v58 = v54 * v30;
  // pto: %accum_inline1065__phi_v21_view
  int64_t v59 = v57 * v58;
  // pto: %accum_inline1065__phi_v21_view
  pto::Shape<1, 1, 1, -1, -1> v60 = pto::Shape<1, 1, 1, -1, -1>(v55, v56, v57, v54, v30);
  // pto: %accum_inline1065__phi_v21_view
  pto::Stride<-1, -1, -1, -1, -1> v61 = pto::Stride<-1, -1, -1, -1, -1>(v56 * v59, v59, v58, v30, v31);
  // pto: %accum_inline1065__phi_v21_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v62 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v60, v61);
  // pto: %projected_o__ssa_v0_view
  const int64_t v63 = 1;
  // pto: %projected_o__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %projected_o__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %projected_o__ssa_v0_view
  int64_t v66 = (int64_t) v7;
  // pto: %projected_o__ssa_v0_view
  int64_t v67 = v66 * v30;
  // pto: %projected_o__ssa_v0_view
  int64_t v68 = v65 * v67;
  // pto: %projected_o__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v69 = pto::Shape<1, 1, 1, -1, -1>(v63, v64, v65, v66, v30);
  // pto: %projected_o__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v70 = pto::Stride<-1, -1, -1, -1, -1>(v64 * v68, v68, v67, v30, v31);
  // pto: %projected_o__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v71 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v69, v70);
  // pto: %scale_o__ssa_v0_view
  const int64_t v72 = 1;
  // pto: %scale_o__ssa_v0_view
  const int64_t v73 = 1;
  // pto: %scale_o__ssa_v0_view
  const int64_t v74 = 1;
  // pto: %scale_o__ssa_v0_view
  int64_t v75 = (int64_t) v7;
  // pto: %scale_o__ssa_v0_view
  int64_t v76 = v75 * v31;
  // pto: %scale_o__ssa_v0_view
  int64_t v77 = v74 * v76;
  // pto: %scale_o__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v78 = pto::Shape<1, 1, 1, -1, -1>(v72, v73, v74, v75, v31);
  // pto: %scale_o__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v79 = pto::Stride<-1, -1, -1, -1, -1>(v73 * v77, v77, v76, v31, (int64_t) v7);
  // pto: %scale_o__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v80 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v3, v78, v79);
  // pto: %quantized_o__ssa_v0_view
  const int64_t v81 = 1;
  // pto: %quantized_o__ssa_v0_view
  const int64_t v82 = 1;
  // pto: %quantized_o__ssa_v0_view
  const int64_t v83 = 1;
  // pto: %quantized_o__ssa_v0_view
  int64_t v84 = (int64_t) v7;
  // pto: %quantized_o__ssa_v0_view
  int64_t v85 = v84 * v30;
  // pto: %quantized_o__ssa_v0_view
  int64_t v86 = v83 * v85;
  // pto: %quantized_o__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v87 = pto::Shape<1, 1, 1, -1, -1>(v81, v82, v83, v84, v30);
  // pto: %quantized_o__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v88 = pto::Stride<-1, -1, -1, -1, -1>(v82 * v86, v86, v85, v30, v31);
  // pto: %quantized_o__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v89 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v87, v88);
  // pto: %block_inline1104__ssa_v0, %0
  int64_t v90 = (int64_t) ((uint64_t) ((int64_t) v8) * (uint64_t) v32);
  // pto: %1
  int64_t v91 = (int64_t) ((uint64_t) v6 - (uint64_t) v90);
  // pto: %2
  int64_t v92 = v91 < v32 ? v91 : v32;
  // pto: %oa0_inline1096__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %oa0_inline1096__ssa_v0
  uint64_t v94 = (uint64_t) v10;
  TASSIGN(v93, v94);
  // pto: %3
  int64_t v95 = v90 < v34 ? v34 : v90;
  // pto: %accum_inline1065__phi_v21_pview
  const int64_t v96 = 0;
  // pto: %accum_inline1065__phi_v21_pview
  __gm__ float* v97 = PTOAS__GLOBAL_TENSOR_DATA(v62);
  // pto: %accum_inline1065__phi_v21_pview
  const int64_t v98 = 1;
  // pto: %accum_inline1065__phi_v21_pview
  const int64_t v99 = 1;
  // pto: %accum_inline1065__phi_v21_pview
  const int64_t v100 = 1;
  // pto: %accum_inline1065__phi_v21_pview
  int64_t v101 = v92 * v30;
  // pto: %accum_inline1065__phi_v21_pview
  int64_t v102 = v100 * v101;
  // pto: %accum_inline1065__phi_v21_pview
  pto::Shape<1, 1, 1, -1, 512> v103 = pto::Shape<1, 1, 1, -1, 512>(v98, v99, v100, v92, v33);
  // pto: %accum_inline1065__phi_v21_pview
  pto::Stride<-1, -1, -1, -1, -1> v104 = pto::Stride<-1, -1, -1, -1, -1>(v99 * v102, v102, v101, v30, v31);
  // pto: %accum_inline1065__phi_v21_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v105 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v97 + (v96 + v95 * v30 + v34 * v31), v103, v104);
  TLOAD(v93, v105);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %rounded0_inline1115__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %rounded0_inline1115__ssa_v0
  uint64_t v107 = (uint64_t) v11;
  TASSIGN(v106, v107);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  RoundMode v108 = RoundMode::CAST_RINT;
  SaturationMode v109 = SaturationMode::ON;
  TCVT(v106, v93, v108, v109);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v106.SetValidShape(v92, v33);
  // pto: %projected_o__ssa_v0_pview
  const int64_t v110 = 0;
  // pto: %projected_o__ssa_v0_pview
  __gm__ bfloat16_t* v111 = PTOAS__GLOBAL_TENSOR_DATA(v71);
  // pto: %projected_o__ssa_v0_pview
  const int64_t v112 = 1;
  // pto: %projected_o__ssa_v0_pview
  const int64_t v113 = 1;
  // pto: %projected_o__ssa_v0_pview
  const int64_t v114 = 1;
  // pto: %projected_o__ssa_v0_pview
  int64_t v115 = v92 * v30;
  // pto: %projected_o__ssa_v0_pview
  int64_t v116 = v114 * v115;
  // pto: %projected_o__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 512> v117 = pto::Shape<1, 1, 1, -1, 512>(v112, v113, v114, v92, v33);
  // pto: %projected_o__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v118 = pto::Stride<-1, -1, -1, -1, -1>(v113 * v116, v116, v115, v30, v31);
  // pto: %projected_o__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v119 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v111 + (v110 + v95 * v30 + v34 * v31), v117, v118);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v119, v106);
  // pto: %t__tmp_v1014
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1014
  uint64_t v121 = (uint64_t) v10;
  TASSIGN(v120, v121);
  pipe_barrier(PIPE_V);
  RoundMode v122 = RoundMode::CAST_ROUND;
  SaturationMode v123 = SaturationMode::ON;
  TCVT(v120, v106, v122, v123);
  // pto: %t__tmp_v1015
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1015
  uint64_t v125 = (uint64_t) v10;
  TASSIGN(v124, v125);
  pipe_barrier(PIPE_V);
  TABS(v124, v120);
  // pto: %t__tmp_v1016
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v126 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
  // pto: %t__tmp_v1016
  uint64_t v127 = (uint64_t) v12;
  TASSIGN(v126, v127);
  // pto: %magnitude0_inline1034__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v128 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %magnitude0_inline1034__ssa_v0
  uint64_t v129 = (uint64_t) v13;
  TASSIGN(v128, v129);
  pipe_barrier(PIPE_V);
  TROWMAX(v128, v124, v126);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  // pto: %amax_inline1091__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %amax_inline1091__ssa_v0
  uint64_t v131 = (uint64_t) v13;
  TASSIGN(v130, v131);
  // pto: %oa1_inline1018__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v132 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %oa1_inline1018__ssa_v0
  uint64_t v133 = (uint64_t) v10;
  TASSIGN(v132, v133);
  // pto: %6
  const int64_t v134 = 0;
  // pto: %6
  __gm__ float* v135 = PTOAS__GLOBAL_TENSOR_DATA(v62);
  // pto: %6
  const int64_t v136 = 1;
  // pto: %6
  const int64_t v137 = 1;
  // pto: %6
  const int64_t v138 = 1;
  // pto: %6
  int64_t v139 = v92 * v30;
  // pto: %6
  int64_t v140 = v138 * v139;
  // pto: %6
  pto::Shape<1, 1, 1, -1, 512> v141 = pto::Shape<1, 1, 1, -1, 512>(v136, v137, v138, v92, v33);
  // pto: %6
  pto::Stride<-1, -1, -1, -1, -1> v142 = pto::Stride<-1, -1, -1, -1, -1>(v137 * v140, v140, v139, v30, v31);
  // pto: %6
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v143 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v135 + (v134 + v95 * v30 + v33 * v31), v141, v142);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  TLOAD(v132, v143);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  // pto: %rounded1_inline1143__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v144 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %rounded1_inline1143__ssa_v0
  uint64_t v145 = (uint64_t) v14;
  TASSIGN(v144, v145);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  RoundMode v146 = RoundMode::CAST_RINT;
  SaturationMode v147 = SaturationMode::ON;
  TCVT(v144, v132, v146, v147);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
  v144.SetValidShape(v92, v33);
  // pto: %8
  const int64_t v148 = 0;
  // pto: %8
  __gm__ bfloat16_t* v149 = PTOAS__GLOBAL_TENSOR_DATA(v71);
  // pto: %8
  const int64_t v150 = 1;
  // pto: %8
  const int64_t v151 = 1;
  // pto: %8
  const int64_t v152 = 1;
  // pto: %8
  int64_t v153 = v92 * v30;
  // pto: %8
  int64_t v154 = v152 * v153;
  // pto: %8
  pto::Shape<1, 1, 1, -1, 512> v155 = pto::Shape<1, 1, 1, -1, 512>(v150, v151, v152, v92, v33);
  // pto: %8
  pto::Stride<-1, -1, -1, -1, -1> v156 = pto::Stride<-1, -1, -1, -1, -1>(v151 * v154, v154, v153, v30, v31);
  // pto: %8
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v157 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v149 + (v148 + v95 * v30 + v33 * v31), v155, v156);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
  pipe_barrier(PIPE_MTE3);
  TSTORE(v157, v144);
  // pto: %t__tmp_v1018
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v158 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1018
  uint64_t v159 = (uint64_t) v10;
  TASSIGN(v158, v159);
  pipe_barrier(PIPE_V);
  RoundMode v160 = RoundMode::CAST_ROUND;
  SaturationMode v161 = SaturationMode::ON;
  TCVT(v158, v144, v160, v161);
  // pto: %t__tmp_v1019
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v162 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1019
  uint64_t v163 = (uint64_t) v10;
  TASSIGN(v162, v163);
  pipe_barrier(PIPE_V);
  TABS(v162, v158);
  // pto: %t__tmp_v1020
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v164 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
  // pto: %t__tmp_v1020
  uint64_t v165 = (uint64_t) v12;
  TASSIGN(v164, v165);
  // pto: %magnitude1_inline1141__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v166 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %magnitude1_inline1141__ssa_v0
  uint64_t v167 = (uint64_t) v15;
  TASSIGN(v166, v167);
  pipe_barrier(PIPE_V);
  TROWMAX(v166, v162, v164);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  // pto: %amax_v1_inline1218__rm_a0_tmp_v0
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v168 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v1_inline1218__rm_a0_tmp_v0
  uint64_t v169 = (uint64_t) v13;
  TASSIGN(v168, v169);
  // pto: %amax_v1_inline1218__rm_a1_tmp_v1
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v170 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v1_inline1218__rm_a1_tmp_v1
  uint64_t v171 = (uint64_t) v15;
  TASSIGN(v170, v171);
  // pto: %amax_v1_inline1218__row_major_tmp_v2
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v172 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v1_inline1218__row_major_tmp_v2
  uint64_t v173 = (uint64_t) v15;
  TASSIGN(v172, v173);
  pipe_barrier(PIPE_V);
  TMAX(v172, v168, v170);
  // pto: %amax_v1_inline1218__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v174 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %amax_v1_inline1218__ssa_v0
  uint64_t v175 = (uint64_t) v15;
  TASSIGN(v174, v175);
  // pto: %oa2_inline1014__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v176 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %oa2_inline1014__ssa_v0
  uint64_t v177 = (uint64_t) v10;
  TASSIGN(v176, v177);
  // pto: %10
  const int64_t v178 = 0;
  // pto: %10
  __gm__ float* v179 = PTOAS__GLOBAL_TENSOR_DATA(v62);
  // pto: %10
  const int64_t v180 = 1;
  // pto: %10
  const int64_t v181 = 1;
  // pto: %10
  const int64_t v182 = 1;
  // pto: %10
  int64_t v183 = v92 * v30;
  // pto: %10
  int64_t v184 = v182 * v183;
  // pto: %10
  pto::Shape<1, 1, 1, -1, 512> v185 = pto::Shape<1, 1, 1, -1, 512>(v180, v181, v182, v92, v33);
  // pto: %10
  pto::Stride<-1, -1, -1, -1, -1> v186 = pto::Stride<-1, -1, -1, -1, -1>(v181 * v184, v184, v183, v30, v31);
  // pto: %10
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v187 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v179 + (v178 + v95 * v30 + v35 * v31), v185, v186);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  TLOAD(v176, v187);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
  // pto: %rounded2_inline1123__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v188 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %rounded2_inline1123__ssa_v0
  uint64_t v189 = (uint64_t) v13;
  TASSIGN(v188, v189);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
  pipe_barrier(PIPE_V);
  RoundMode v190 = RoundMode::CAST_RINT;
  SaturationMode v191 = SaturationMode::ON;
  TCVT(v188, v176, v190, v191);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
  v188.SetValidShape(v92, v33);
  // pto: %12
  const int64_t v192 = 0;
  // pto: %12
  __gm__ bfloat16_t* v193 = PTOAS__GLOBAL_TENSOR_DATA(v71);
  // pto: %12
  const int64_t v194 = 1;
  // pto: %12
  const int64_t v195 = 1;
  // pto: %12
  const int64_t v196 = 1;
  // pto: %12
  int64_t v197 = v92 * v30;
  // pto: %12
  int64_t v198 = v196 * v197;
  // pto: %12
  pto::Shape<1, 1, 1, -1, 512> v199 = pto::Shape<1, 1, 1, -1, 512>(v194, v195, v196, v92, v33);
  // pto: %12
  pto::Stride<-1, -1, -1, -1, -1> v200 = pto::Stride<-1, -1, -1, -1, -1>(v195 * v198, v198, v197, v30, v31);
  // pto: %12
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v201 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v193 + (v192 + v95 * v30 + v35 * v31), v199, v200);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
  pipe_barrier(PIPE_MTE3);
  TSTORE(v201, v188);
  // pto: %t__tmp_v1022
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v202 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1022
  uint64_t v203 = (uint64_t) v10;
  TASSIGN(v202, v203);
  pipe_barrier(PIPE_V);
  RoundMode v204 = RoundMode::CAST_ROUND;
  SaturationMode v205 = SaturationMode::ON;
  TCVT(v202, v188, v204, v205);
  // pto: %t__tmp_v1023
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v206 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1023
  uint64_t v207 = (uint64_t) v10;
  TASSIGN(v206, v207);
  pipe_barrier(PIPE_V);
  TABS(v206, v202);
  // pto: %t__tmp_v1024
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v208 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
  // pto: %t__tmp_v1024
  uint64_t v209 = (uint64_t) v12;
  TASSIGN(v208, v209);
  // pto: %magnitude2_inline1012__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v210 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %magnitude2_inline1012__ssa_v0
  uint64_t v211 = (uint64_t) v16;
  TASSIGN(v210, v211);
  pipe_barrier(PIPE_V);
  TROWMAX(v210, v206, v208);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  // pto: %amax_v2_inline1026__rm_a0_tmp_v3
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v212 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v2_inline1026__rm_a0_tmp_v3
  uint64_t v213 = (uint64_t) v15;
  TASSIGN(v212, v213);
  // pto: %amax_v2_inline1026__rm_a1_tmp_v4
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v214 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v2_inline1026__rm_a1_tmp_v4
  uint64_t v215 = (uint64_t) v16;
  TASSIGN(v214, v215);
  // pto: %amax_v2_inline1026__row_major_tmp_v5
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v216 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v2_inline1026__row_major_tmp_v5
  uint64_t v217 = (uint64_t) v16;
  TASSIGN(v216, v217);
  pipe_barrier(PIPE_V);
  TMAX(v216, v212, v214);
  // pto: %amax_v2_inline1026__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %amax_v2_inline1026__ssa_v0
  uint64_t v219 = (uint64_t) v16;
  TASSIGN(v218, v219);
  // pto: %oa3_inline1103__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %oa3_inline1103__ssa_v0
  uint64_t v221 = (uint64_t) v10;
  TASSIGN(v220, v221);
  // pto: %14
  const int64_t v222 = 0;
  // pto: %14
  __gm__ float* v223 = PTOAS__GLOBAL_TENSOR_DATA(v62);
  // pto: %14
  const int64_t v224 = 1;
  // pto: %14
  const int64_t v225 = 1;
  // pto: %14
  const int64_t v226 = 1;
  // pto: %14
  int64_t v227 = v92 * v30;
  // pto: %14
  int64_t v228 = v226 * v227;
  // pto: %14
  pto::Shape<1, 1, 1, -1, 512> v229 = pto::Shape<1, 1, 1, -1, 512>(v224, v225, v226, v92, v33);
  // pto: %14
  pto::Stride<-1, -1, -1, -1, -1> v230 = pto::Stride<-1, -1, -1, -1, -1>(v225 * v228, v228, v227, v30, v31);
  // pto: %14
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v231 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v223 + (v222 + v95 * v30 + v36 * v31), v229, v230);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  TLOAD(v220, v231);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
  // pto: %rounded3_inline1114__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v232 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %rounded3_inline1114__ssa_v0
  uint64_t v233 = (uint64_t) v15;
  TASSIGN(v232, v233);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
  pipe_barrier(PIPE_V);
  RoundMode v234 = RoundMode::CAST_RINT;
  SaturationMode v235 = SaturationMode::ON;
  TCVT(v232, v220, v234, v235);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
  v232.SetValidShape(v92, v33);
  // pto: %16
  const int64_t v236 = 0;
  // pto: %16
  __gm__ bfloat16_t* v237 = PTOAS__GLOBAL_TENSOR_DATA(v71);
  // pto: %16
  const int64_t v238 = 1;
  // pto: %16
  const int64_t v239 = 1;
  // pto: %16
  const int64_t v240 = 1;
  // pto: %16
  int64_t v241 = v92 * v30;
  // pto: %16
  int64_t v242 = v240 * v241;
  // pto: %16
  pto::Shape<1, 1, 1, -1, 512> v243 = pto::Shape<1, 1, 1, -1, 512>(v238, v239, v240, v92, v33);
  // pto: %16
  pto::Stride<-1, -1, -1, -1, -1> v244 = pto::Stride<-1, -1, -1, -1, -1>(v239 * v242, v242, v241, v30, v31);
  // pto: %16
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v245 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v237 + (v236 + v95 * v30 + v36 * v31), v243, v244);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
  pipe_barrier(PIPE_MTE3);
  TSTORE(v245, v232);
  // pto: %t__tmp_v1026
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v246 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1026
  uint64_t v247 = (uint64_t) v10;
  TASSIGN(v246, v247);
  pipe_barrier(PIPE_V);
  RoundMode v248 = RoundMode::CAST_ROUND;
  SaturationMode v249 = SaturationMode::ON;
  TCVT(v246, v232, v248, v249);
  // pto: %t__tmp_v1027
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v250 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1027
  uint64_t v251 = (uint64_t) v10;
  TASSIGN(v250, v251);
  pipe_barrier(PIPE_V);
  TABS(v250, v246);
  // pto: %t__tmp_v1028
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v252 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
  // pto: %t__tmp_v1028
  uint64_t v253 = (uint64_t) v12;
  TASSIGN(v252, v253);
  // pto: %magnitude3_inline1023__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v254 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %magnitude3_inline1023__ssa_v0
  uint64_t v255 = (uint64_t) v17;
  TASSIGN(v254, v255);
  pipe_barrier(PIPE_V);
  TROWMAX(v254, v250, v252);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  // pto: %amax_v3_inline1129__rm_a0_tmp_v6
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v256 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v3_inline1129__rm_a0_tmp_v6
  uint64_t v257 = (uint64_t) v16;
  TASSIGN(v256, v257);
  // pto: %amax_v3_inline1129__rm_a1_tmp_v7
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v258 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v3_inline1129__rm_a1_tmp_v7
  uint64_t v259 = (uint64_t) v17;
  TASSIGN(v258, v259);
  // pto: %amax_v3_inline1129__row_major_tmp_v8
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v260 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v3_inline1129__row_major_tmp_v8
  uint64_t v261 = (uint64_t) v17;
  TASSIGN(v260, v261);
  pipe_barrier(PIPE_V);
  TMAX(v260, v256, v258);
  // pto: %amax_v3_inline1129__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v262 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %amax_v3_inline1129__ssa_v0
  uint64_t v263 = (uint64_t) v17;
  TASSIGN(v262, v263);
  // pto: %oa4_inline1009__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v264 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %oa4_inline1009__ssa_v0
  uint64_t v265 = (uint64_t) v10;
  TASSIGN(v264, v265);
  // pto: %18
  const int64_t v266 = 0;
  // pto: %18
  __gm__ float* v267 = PTOAS__GLOBAL_TENSOR_DATA(v62);
  // pto: %18
  const int64_t v268 = 1;
  // pto: %18
  const int64_t v269 = 1;
  // pto: %18
  const int64_t v270 = 1;
  // pto: %18
  int64_t v271 = v92 * v30;
  // pto: %18
  int64_t v272 = v270 * v271;
  // pto: %18
  pto::Shape<1, 1, 1, -1, 512> v273 = pto::Shape<1, 1, 1, -1, 512>(v268, v269, v270, v92, v33);
  // pto: %18
  pto::Stride<-1, -1, -1, -1, -1> v274 = pto::Stride<-1, -1, -1, -1, -1>(v269 * v272, v272, v271, v30, v31);
  // pto: %18
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v275 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v267 + (v266 + v95 * v30 + v37 * v31), v273, v274);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  TLOAD(v264, v275);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
  // pto: %rounded4_inline1046__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v276 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %rounded4_inline1046__ssa_v0
  uint64_t v277 = (uint64_t) v16;
  TASSIGN(v276, v277);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
  pipe_barrier(PIPE_V);
  RoundMode v278 = RoundMode::CAST_RINT;
  SaturationMode v279 = SaturationMode::ON;
  TCVT(v276, v264, v278, v279);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
  v276.SetValidShape(v92, v33);
  // pto: %20
  const int64_t v280 = 0;
  // pto: %20
  __gm__ bfloat16_t* v281 = PTOAS__GLOBAL_TENSOR_DATA(v71);
  // pto: %20
  const int64_t v282 = 1;
  // pto: %20
  const int64_t v283 = 1;
  // pto: %20
  const int64_t v284 = 1;
  // pto: %20
  int64_t v285 = v92 * v30;
  // pto: %20
  int64_t v286 = v284 * v285;
  // pto: %20
  pto::Shape<1, 1, 1, -1, 512> v287 = pto::Shape<1, 1, 1, -1, 512>(v282, v283, v284, v92, v33);
  // pto: %20
  pto::Stride<-1, -1, -1, -1, -1> v288 = pto::Stride<-1, -1, -1, -1, -1>(v283 * v286, v286, v285, v30, v31);
  // pto: %20
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v289 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v281 + (v280 + v95 * v30 + v37 * v31), v287, v288);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
  pipe_barrier(PIPE_MTE3);
  TSTORE(v289, v276);
  // pto: %t__tmp_v1030
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v290 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1030
  uint64_t v291 = (uint64_t) v10;
  TASSIGN(v290, v291);
  pipe_barrier(PIPE_V);
  RoundMode v292 = RoundMode::CAST_ROUND;
  SaturationMode v293 = SaturationMode::ON;
  TCVT(v290, v276, v292, v293);
  // pto: %t__tmp_v1031
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v294 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1031
  uint64_t v295 = (uint64_t) v10;
  TASSIGN(v294, v295);
  pipe_barrier(PIPE_V);
  TABS(v294, v290);
  // pto: %t__tmp_v1032
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v296 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
  // pto: %t__tmp_v1032
  uint64_t v297 = (uint64_t) v12;
  TASSIGN(v296, v297);
  // pto: %magnitude4_inline1146__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %magnitude4_inline1146__ssa_v0
  uint64_t v299 = (uint64_t) v18;
  TASSIGN(v298, v299);
  pipe_barrier(PIPE_V);
  TROWMAX(v298, v294, v296);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  // pto: %amax_v4_inline1166__rm_a0_tmp_v9
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v300 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v4_inline1166__rm_a0_tmp_v9
  uint64_t v301 = (uint64_t) v17;
  TASSIGN(v300, v301);
  // pto: %amax_v4_inline1166__rm_a1_tmp_v10
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v302 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v4_inline1166__rm_a1_tmp_v10
  uint64_t v303 = (uint64_t) v18;
  TASSIGN(v302, v303);
  // pto: %amax_v4_inline1166__row_major_tmp_v11
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v304 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v4_inline1166__row_major_tmp_v11
  uint64_t v305 = (uint64_t) v18;
  TASSIGN(v304, v305);
  pipe_barrier(PIPE_V);
  TMAX(v304, v300, v302);
  // pto: %amax_v4_inline1166__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v306 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %amax_v4_inline1166__ssa_v0
  uint64_t v307 = (uint64_t) v18;
  TASSIGN(v306, v307);
  // pto: %oa5_inline1094__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v308 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %oa5_inline1094__ssa_v0
  uint64_t v309 = (uint64_t) v10;
  TASSIGN(v308, v309);
  // pto: %22
  const int64_t v310 = 0;
  // pto: %22
  __gm__ float* v311 = PTOAS__GLOBAL_TENSOR_DATA(v62);
  // pto: %22
  const int64_t v312 = 1;
  // pto: %22
  const int64_t v313 = 1;
  // pto: %22
  const int64_t v314 = 1;
  // pto: %22
  int64_t v315 = v92 * v30;
  // pto: %22
  int64_t v316 = v314 * v315;
  // pto: %22
  pto::Shape<1, 1, 1, -1, 512> v317 = pto::Shape<1, 1, 1, -1, 512>(v312, v313, v314, v92, v33);
  // pto: %22
  pto::Stride<-1, -1, -1, -1, -1> v318 = pto::Stride<-1, -1, -1, -1, -1>(v313 * v316, v316, v315, v30, v31);
  // pto: %22
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v319 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v311 + (v310 + v95 * v30 + v38 * v31), v317, v318);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  TLOAD(v308, v319);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
  // pto: %rounded5_inline1004__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v320 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %rounded5_inline1004__ssa_v0
  uint64_t v321 = (uint64_t) v17;
  TASSIGN(v320, v321);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
  pipe_barrier(PIPE_V);
  RoundMode v322 = RoundMode::CAST_RINT;
  SaturationMode v323 = SaturationMode::ON;
  TCVT(v320, v308, v322, v323);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
  v320.SetValidShape(v92, v33);
  // pto: %24
  const int64_t v324 = 0;
  // pto: %24
  __gm__ bfloat16_t* v325 = PTOAS__GLOBAL_TENSOR_DATA(v71);
  // pto: %24
  const int64_t v326 = 1;
  // pto: %24
  const int64_t v327 = 1;
  // pto: %24
  const int64_t v328 = 1;
  // pto: %24
  int64_t v329 = v92 * v30;
  // pto: %24
  int64_t v330 = v328 * v329;
  // pto: %24
  pto::Shape<1, 1, 1, -1, 512> v331 = pto::Shape<1, 1, 1, -1, 512>(v326, v327, v328, v92, v33);
  // pto: %24
  pto::Stride<-1, -1, -1, -1, -1> v332 = pto::Stride<-1, -1, -1, -1, -1>(v327 * v330, v330, v329, v30, v31);
  // pto: %24
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v333 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v325 + (v324 + v95 * v30 + v38 * v31), v331, v332);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
  pipe_barrier(PIPE_MTE3);
  TSTORE(v333, v320);
  // pto: %t__tmp_v1034
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v334 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1034
  uint64_t v335 = (uint64_t) v10;
  TASSIGN(v334, v335);
  pipe_barrier(PIPE_V);
  RoundMode v336 = RoundMode::CAST_ROUND;
  SaturationMode v337 = SaturationMode::ON;
  TCVT(v334, v320, v336, v337);
  // pto: %t__tmp_v1035
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v338 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1035
  uint64_t v339 = (uint64_t) v10;
  TASSIGN(v338, v339);
  pipe_barrier(PIPE_V);
  TABS(v338, v334);
  // pto: %t__tmp_v1036
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v340 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
  // pto: %t__tmp_v1036
  uint64_t v341 = (uint64_t) v12;
  TASSIGN(v340, v341);
  // pto: %magnitude5_inline1015__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v342 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %magnitude5_inline1015__ssa_v0
  uint64_t v343 = (uint64_t) v19;
  TASSIGN(v342, v343);
  pipe_barrier(PIPE_V);
  TROWMAX(v342, v338, v340);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  // pto: %amax_v5_inline1008__rm_a0_tmp_v12
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v344 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v5_inline1008__rm_a0_tmp_v12
  uint64_t v345 = (uint64_t) v18;
  TASSIGN(v344, v345);
  // pto: %amax_v5_inline1008__rm_a1_tmp_v13
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v346 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v5_inline1008__rm_a1_tmp_v13
  uint64_t v347 = (uint64_t) v19;
  TASSIGN(v346, v347);
  // pto: %amax_v5_inline1008__row_major_tmp_v14
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v348 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v5_inline1008__row_major_tmp_v14
  uint64_t v349 = (uint64_t) v19;
  TASSIGN(v348, v349);
  pipe_barrier(PIPE_V);
  TMAX(v348, v344, v346);
  // pto: %amax_v5_inline1008__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v350 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %amax_v5_inline1008__ssa_v0
  uint64_t v351 = (uint64_t) v19;
  TASSIGN(v350, v351);
  // pto: %oa6_inline1024__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v352 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %oa6_inline1024__ssa_v0
  uint64_t v353 = (uint64_t) v10;
  TASSIGN(v352, v353);
  // pto: %26
  const int64_t v354 = 0;
  // pto: %26
  __gm__ float* v355 = PTOAS__GLOBAL_TENSOR_DATA(v62);
  // pto: %26
  const int64_t v356 = 1;
  // pto: %26
  const int64_t v357 = 1;
  // pto: %26
  const int64_t v358 = 1;
  // pto: %26
  int64_t v359 = v92 * v30;
  // pto: %26
  int64_t v360 = v358 * v359;
  // pto: %26
  pto::Shape<1, 1, 1, -1, 512> v361 = pto::Shape<1, 1, 1, -1, 512>(v356, v357, v358, v92, v33);
  // pto: %26
  pto::Stride<-1, -1, -1, -1, -1> v362 = pto::Stride<-1, -1, -1, -1, -1>(v357 * v360, v360, v359, v30, v31);
  // pto: %26
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v363 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v355 + (v354 + v95 * v30 + v39 * v31), v361, v362);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  TLOAD(v352, v363);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
  // pto: %rounded6_inline1003__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v364 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %rounded6_inline1003__ssa_v0
  uint64_t v365 = (uint64_t) v18;
  TASSIGN(v364, v365);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
  pipe_barrier(PIPE_V);
  RoundMode v366 = RoundMode::CAST_RINT;
  SaturationMode v367 = SaturationMode::ON;
  TCVT(v364, v352, v366, v367);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
  v364.SetValidShape(v92, v33);
  // pto: %28
  const int64_t v368 = 0;
  // pto: %28
  __gm__ bfloat16_t* v369 = PTOAS__GLOBAL_TENSOR_DATA(v71);
  // pto: %28
  const int64_t v370 = 1;
  // pto: %28
  const int64_t v371 = 1;
  // pto: %28
  const int64_t v372 = 1;
  // pto: %28
  int64_t v373 = v92 * v30;
  // pto: %28
  int64_t v374 = v372 * v373;
  // pto: %28
  pto::Shape<1, 1, 1, -1, 512> v375 = pto::Shape<1, 1, 1, -1, 512>(v370, v371, v372, v92, v33);
  // pto: %28
  pto::Stride<-1, -1, -1, -1, -1> v376 = pto::Stride<-1, -1, -1, -1, -1>(v371 * v374, v374, v373, v30, v31);
  // pto: %28
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v377 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v369 + (v368 + v95 * v30 + v39 * v31), v375, v376);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
  pipe_barrier(PIPE_MTE3);
  TSTORE(v377, v364);
  // pto: %t__tmp_v1038
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v378 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1038
  uint64_t v379 = (uint64_t) v10;
  TASSIGN(v378, v379);
  pipe_barrier(PIPE_V);
  RoundMode v380 = RoundMode::CAST_ROUND;
  SaturationMode v381 = SaturationMode::ON;
  TCVT(v378, v364, v380, v381);
  // pto: %t__tmp_v1039
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v382 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1039
  uint64_t v383 = (uint64_t) v10;
  TASSIGN(v382, v383);
  pipe_barrier(PIPE_V);
  TABS(v382, v378);
  // pto: %t__tmp_v1040
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v384 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
  // pto: %t__tmp_v1040
  uint64_t v385 = (uint64_t) v12;
  TASSIGN(v384, v385);
  // pto: %magnitude6_inline1226__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v386 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %magnitude6_inline1226__ssa_v0
  uint64_t v387 = (uint64_t) v20;
  TASSIGN(v386, v387);
  pipe_barrier(PIPE_V);
  TROWMAX(v386, v382, v384);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  // pto: %amax_v6_inline1093__rm_a0_tmp_v15
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v388 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v6_inline1093__rm_a0_tmp_v15
  uint64_t v389 = (uint64_t) v19;
  TASSIGN(v388, v389);
  // pto: %amax_v6_inline1093__rm_a1_tmp_v16
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v390 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v6_inline1093__rm_a1_tmp_v16
  uint64_t v391 = (uint64_t) v20;
  TASSIGN(v390, v391);
  // pto: %amax_v6_inline1093__row_major_tmp_v17
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v392 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v6_inline1093__row_major_tmp_v17
  uint64_t v393 = (uint64_t) v20;
  TASSIGN(v392, v393);
  pipe_barrier(PIPE_V);
  TMAX(v392, v388, v390);
  // pto: %amax_v6_inline1093__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v394 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %amax_v6_inline1093__ssa_v0
  uint64_t v395 = (uint64_t) v20;
  TASSIGN(v394, v395);
  // pto: %oa7_inline1247__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v396 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %oa7_inline1247__ssa_v0
  uint64_t v397 = (uint64_t) v10;
  TASSIGN(v396, v397);
  // pto: %30
  const int64_t v398 = 0;
  // pto: %30
  __gm__ float* v399 = PTOAS__GLOBAL_TENSOR_DATA(v62);
  // pto: %30
  const int64_t v400 = 1;
  // pto: %30
  const int64_t v401 = 1;
  // pto: %30
  const int64_t v402 = 1;
  // pto: %30
  int64_t v403 = v92 * v30;
  // pto: %30
  int64_t v404 = v402 * v403;
  // pto: %30
  pto::Shape<1, 1, 1, -1, 512> v405 = pto::Shape<1, 1, 1, -1, 512>(v400, v401, v402, v92, v33);
  // pto: %30
  pto::Stride<-1, -1, -1, -1, -1> v406 = pto::Stride<-1, -1, -1, -1, -1>(v401 * v404, v404, v403, v30, v31);
  // pto: %30
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v407 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v399 + (v398 + v95 * v30 + v40 * v31), v405, v406);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  TLOAD(v396, v407);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
  // pto: %rounded7_inline998__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v408 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %rounded7_inline998__ssa_v0
  uint64_t v409 = (uint64_t) v19;
  TASSIGN(v408, v409);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
  pipe_barrier(PIPE_V);
  RoundMode v410 = RoundMode::CAST_RINT;
  SaturationMode v411 = SaturationMode::ON;
  TCVT(v408, v396, v410, v411);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
  v408.SetValidShape(v92, v33);
  // pto: %32
  const int64_t v412 = 0;
  // pto: %32
  __gm__ bfloat16_t* v413 = PTOAS__GLOBAL_TENSOR_DATA(v71);
  // pto: %32
  const int64_t v414 = 1;
  // pto: %32
  const int64_t v415 = 1;
  // pto: %32
  const int64_t v416 = 1;
  // pto: %32
  int64_t v417 = v92 * v30;
  // pto: %32
  int64_t v418 = v416 * v417;
  // pto: %32
  pto::Shape<1, 1, 1, -1, 512> v419 = pto::Shape<1, 1, 1, -1, 512>(v414, v415, v416, v92, v33);
  // pto: %32
  pto::Stride<-1, -1, -1, -1, -1> v420 = pto::Stride<-1, -1, -1, -1, -1>(v415 * v418, v418, v417, v30, v31);
  // pto: %32
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v421 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v413 + (v412 + v95 * v30 + v40 * v31), v419, v420);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
  pipe_barrier(PIPE_MTE3);
  TSTORE(v421, v408);
  // pto: %t__tmp_v1042
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v422 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1042
  uint64_t v423 = (uint64_t) v10;
  TASSIGN(v422, v423);
  pipe_barrier(PIPE_V);
  RoundMode v424 = RoundMode::CAST_ROUND;
  SaturationMode v425 = SaturationMode::ON;
  TCVT(v422, v408, v424, v425);
  // pto: %t__tmp_v1043
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v426 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1043
  uint64_t v427 = (uint64_t) v10;
  TASSIGN(v426, v427);
  pipe_barrier(PIPE_V);
  TABS(v426, v422);
  // pto: %t__tmp_v1044
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v428 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
  // pto: %t__tmp_v1044
  uint64_t v429 = (uint64_t) v12;
  TASSIGN(v428, v429);
  // pto: %magnitude7_inline1063__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v430 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %magnitude7_inline1063__ssa_v0
  uint64_t v431 = (uint64_t) v21;
  TASSIGN(v430, v431);
  pipe_barrier(PIPE_V);
  TROWMAX(v430, v426, v428);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  // pto: %amax_v7_inline1001__rm_a0_tmp_v18
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v432 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v7_inline1001__rm_a0_tmp_v18
  uint64_t v433 = (uint64_t) v20;
  TASSIGN(v432, v433);
  // pto: %amax_v7_inline1001__rm_a1_tmp_v19
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v434 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v7_inline1001__rm_a1_tmp_v19
  uint64_t v435 = (uint64_t) v21;
  TASSIGN(v434, v435);
  // pto: %amax_v7_inline1001__row_major_tmp_v20
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v436 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v7_inline1001__row_major_tmp_v20
  uint64_t v437 = (uint64_t) v21;
  TASSIGN(v436, v437);
  pipe_barrier(PIPE_V);
  TMAX(v436, v432, v434);
  // pto: %amax_v7_inline1001__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v438 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %amax_v7_inline1001__ssa_v0
  uint64_t v439 = (uint64_t) v21;
  TASSIGN(v438, v439);
  // pto: %oa8_inline1057__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v440 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %oa8_inline1057__ssa_v0
  uint64_t v441 = (uint64_t) v10;
  TASSIGN(v440, v441);
  // pto: %34
  const int64_t v442 = 0;
  // pto: %34
  __gm__ float* v443 = PTOAS__GLOBAL_TENSOR_DATA(v62);
  // pto: %34
  const int64_t v444 = 1;
  // pto: %34
  const int64_t v445 = 1;
  // pto: %34
  const int64_t v446 = 1;
  // pto: %34
  int64_t v447 = v92 * v30;
  // pto: %34
  int64_t v448 = v446 * v447;
  // pto: %34
  pto::Shape<1, 1, 1, -1, 512> v449 = pto::Shape<1, 1, 1, -1, 512>(v444, v445, v446, v92, v33);
  // pto: %34
  pto::Stride<-1, -1, -1, -1, -1> v450 = pto::Stride<-1, -1, -1, -1, -1>(v445 * v448, v448, v447, v30, v31);
  // pto: %34
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v451 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v443 + (v442 + v95 * v30 + v41 * v31), v449, v450);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  TLOAD(v440, v451);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %rounded8_inline1043__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v452 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %rounded8_inline1043__ssa_v0
  uint64_t v453 = (uint64_t) v20;
  TASSIGN(v452, v453);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  pipe_barrier(PIPE_V);
  RoundMode v454 = RoundMode::CAST_RINT;
  SaturationMode v455 = SaturationMode::ON;
  TCVT(v452, v440, v454, v455);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v452.SetValidShape(v92, v33);
  // pto: %36
  const int64_t v456 = 0;
  // pto: %36
  __gm__ bfloat16_t* v457 = PTOAS__GLOBAL_TENSOR_DATA(v71);
  // pto: %36
  const int64_t v458 = 1;
  // pto: %36
  const int64_t v459 = 1;
  // pto: %36
  const int64_t v460 = 1;
  // pto: %36
  int64_t v461 = v92 * v30;
  // pto: %36
  int64_t v462 = v460 * v461;
  // pto: %36
  pto::Shape<1, 1, 1, -1, 512> v463 = pto::Shape<1, 1, 1, -1, 512>(v458, v459, v460, v92, v33);
  // pto: %36
  pto::Stride<-1, -1, -1, -1, -1> v464 = pto::Stride<-1, -1, -1, -1, -1>(v459 * v462, v462, v461, v30, v31);
  // pto: %36
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v465 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v457 + (v456 + v95 * v30 + v41 * v31), v463, v464);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  pipe_barrier(PIPE_MTE3);
  TSTORE(v465, v452);
  // pto: %t__tmp_v1046
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v466 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1046
  uint64_t v467 = (uint64_t) v10;
  TASSIGN(v466, v467);
  pipe_barrier(PIPE_V);
  RoundMode v468 = RoundMode::CAST_ROUND;
  SaturationMode v469 = SaturationMode::ON;
  TCVT(v466, v452, v468, v469);
  // pto: %t__tmp_v1047
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v470 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1047
  uint64_t v471 = (uint64_t) v10;
  TASSIGN(v470, v471);
  pipe_barrier(PIPE_V);
  TABS(v470, v466);
  // pto: %t__tmp_v1048
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v472 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
  // pto: %t__tmp_v1048
  uint64_t v473 = (uint64_t) v12;
  TASSIGN(v472, v473);
  // pto: %magnitude8_inline1071__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v474 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %magnitude8_inline1071__ssa_v0
  uint64_t v475 = (uint64_t) v22;
  TASSIGN(v474, v475);
  pipe_barrier(PIPE_V);
  TROWMAX(v474, v470, v472);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  // pto: %amax_v8_inline1062__rm_a0_tmp_v21
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v476 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v8_inline1062__rm_a0_tmp_v21
  uint64_t v477 = (uint64_t) v21;
  TASSIGN(v476, v477);
  // pto: %amax_v8_inline1062__rm_a1_tmp_v22
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v478 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v8_inline1062__rm_a1_tmp_v22
  uint64_t v479 = (uint64_t) v22;
  TASSIGN(v478, v479);
  // pto: %amax_v8_inline1062__row_major_tmp_v23
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v480 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v8_inline1062__row_major_tmp_v23
  uint64_t v481 = (uint64_t) v22;
  TASSIGN(v480, v481);
  pipe_barrier(PIPE_V);
  TMAX(v480, v476, v478);
  // pto: %amax_v8_inline1062__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v482 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %amax_v8_inline1062__ssa_v0
  uint64_t v483 = (uint64_t) v22;
  TASSIGN(v482, v483);
  // pto: %oa9_inline1175__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v484 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %oa9_inline1175__ssa_v0
  uint64_t v485 = (uint64_t) v10;
  TASSIGN(v484, v485);
  // pto: %38
  const int64_t v486 = 0;
  // pto: %38
  __gm__ float* v487 = PTOAS__GLOBAL_TENSOR_DATA(v62);
  // pto: %38
  const int64_t v488 = 1;
  // pto: %38
  const int64_t v489 = 1;
  // pto: %38
  const int64_t v490 = 1;
  // pto: %38
  int64_t v491 = v92 * v30;
  // pto: %38
  int64_t v492 = v490 * v491;
  // pto: %38
  pto::Shape<1, 1, 1, -1, 512> v493 = pto::Shape<1, 1, 1, -1, 512>(v488, v489, v490, v92, v33);
  // pto: %38
  pto::Stride<-1, -1, -1, -1, -1> v494 = pto::Stride<-1, -1, -1, -1, -1>(v489 * v492, v492, v491, v30, v31);
  // pto: %38
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v495 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v487 + (v486 + v95 * v30 + v42 * v31), v493, v494);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  TLOAD(v484, v495);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %rounded9_inline997__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v496 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %rounded9_inline997__ssa_v0
  uint64_t v497 = (uint64_t) v21;
  TASSIGN(v496, v497);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  pipe_barrier(PIPE_V);
  RoundMode v498 = RoundMode::CAST_RINT;
  SaturationMode v499 = SaturationMode::ON;
  TCVT(v496, v484, v498, v499);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v496.SetValidShape(v92, v33);
  // pto: %40
  const int64_t v500 = 0;
  // pto: %40
  __gm__ bfloat16_t* v501 = PTOAS__GLOBAL_TENSOR_DATA(v71);
  // pto: %40
  const int64_t v502 = 1;
  // pto: %40
  const int64_t v503 = 1;
  // pto: %40
  const int64_t v504 = 1;
  // pto: %40
  int64_t v505 = v92 * v30;
  // pto: %40
  int64_t v506 = v504 * v505;
  // pto: %40
  pto::Shape<1, 1, 1, -1, 512> v507 = pto::Shape<1, 1, 1, -1, 512>(v502, v503, v504, v92, v33);
  // pto: %40
  pto::Stride<-1, -1, -1, -1, -1> v508 = pto::Stride<-1, -1, -1, -1, -1>(v503 * v506, v506, v505, v30, v31);
  // pto: %40
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v509 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v501 + (v500 + v95 * v30 + v42 * v31), v507, v508);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  pipe_barrier(PIPE_MTE3);
  TSTORE(v509, v496);
  // pto: %t__tmp_v1050
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v510 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1050
  uint64_t v511 = (uint64_t) v10;
  TASSIGN(v510, v511);
  pipe_barrier(PIPE_V);
  RoundMode v512 = RoundMode::CAST_ROUND;
  SaturationMode v513 = SaturationMode::ON;
  TCVT(v510, v496, v512, v513);
  // pto: %t__tmp_v1051
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v514 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1051
  uint64_t v515 = (uint64_t) v10;
  TASSIGN(v514, v515);
  pipe_barrier(PIPE_V);
  TABS(v514, v510);
  // pto: %t__tmp_v1052
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v516 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
  // pto: %t__tmp_v1052
  uint64_t v517 = (uint64_t) v12;
  TASSIGN(v516, v517);
  // pto: %magnitude9_inline1242__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v518 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %magnitude9_inline1242__ssa_v0
  uint64_t v519 = (uint64_t) v23;
  TASSIGN(v518, v519);
  pipe_barrier(PIPE_V);
  TROWMAX(v518, v514, v516);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  // pto: %amax_v9_inline1150__rm_a0_tmp_v24
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v520 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v9_inline1150__rm_a0_tmp_v24
  uint64_t v521 = (uint64_t) v22;
  TASSIGN(v520, v521);
  // pto: %amax_v9_inline1150__rm_a1_tmp_v25
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v522 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v9_inline1150__rm_a1_tmp_v25
  uint64_t v523 = (uint64_t) v23;
  TASSIGN(v522, v523);
  // pto: %amax_v9_inline1150__row_major_tmp_v26
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v524 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v9_inline1150__row_major_tmp_v26
  uint64_t v525 = (uint64_t) v23;
  TASSIGN(v524, v525);
  pipe_barrier(PIPE_V);
  TMAX(v524, v520, v522);
  // pto: %amax_v9_inline1150__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v526 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %amax_v9_inline1150__ssa_v0
  uint64_t v527 = (uint64_t) v23;
  TASSIGN(v526, v527);
  // pto: %oa10_inline995__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v528 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %oa10_inline995__ssa_v0
  uint64_t v529 = (uint64_t) v10;
  TASSIGN(v528, v529);
  // pto: %42
  const int64_t v530 = 0;
  // pto: %42
  __gm__ float* v531 = PTOAS__GLOBAL_TENSOR_DATA(v62);
  // pto: %42
  const int64_t v532 = 1;
  // pto: %42
  const int64_t v533 = 1;
  // pto: %42
  const int64_t v534 = 1;
  // pto: %42
  int64_t v535 = v92 * v30;
  // pto: %42
  int64_t v536 = v534 * v535;
  // pto: %42
  pto::Shape<1, 1, 1, -1, 512> v537 = pto::Shape<1, 1, 1, -1, 512>(v532, v533, v534, v92, v33);
  // pto: %42
  pto::Stride<-1, -1, -1, -1, -1> v538 = pto::Stride<-1, -1, -1, -1, -1>(v533 * v536, v536, v535, v30, v31);
  // pto: %42
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v539 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v531 + (v530 + v95 * v30 + v43 * v31), v537, v538);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  TLOAD(v528, v539);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %rounded10_inline1069__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v540 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %rounded10_inline1069__ssa_v0
  uint64_t v541 = (uint64_t) v22;
  TASSIGN(v540, v541);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  pipe_barrier(PIPE_V);
  RoundMode v542 = RoundMode::CAST_RINT;
  SaturationMode v543 = SaturationMode::ON;
  TCVT(v540, v528, v542, v543);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v540.SetValidShape(v92, v33);
  // pto: %44
  const int64_t v544 = 0;
  // pto: %44
  __gm__ bfloat16_t* v545 = PTOAS__GLOBAL_TENSOR_DATA(v71);
  // pto: %44
  const int64_t v546 = 1;
  // pto: %44
  const int64_t v547 = 1;
  // pto: %44
  const int64_t v548 = 1;
  // pto: %44
  int64_t v549 = v92 * v30;
  // pto: %44
  int64_t v550 = v548 * v549;
  // pto: %44
  pto::Shape<1, 1, 1, -1, 512> v551 = pto::Shape<1, 1, 1, -1, 512>(v546, v547, v548, v92, v33);
  // pto: %44
  pto::Stride<-1, -1, -1, -1, -1> v552 = pto::Stride<-1, -1, -1, -1, -1>(v547 * v550, v550, v549, v30, v31);
  // pto: %44
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v553 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v545 + (v544 + v95 * v30 + v43 * v31), v551, v552);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  pipe_barrier(PIPE_MTE3);
  TSTORE(v553, v540);
  // pto: %t__tmp_v1054
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v554 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1054
  uint64_t v555 = (uint64_t) v10;
  TASSIGN(v554, v555);
  pipe_barrier(PIPE_V);
  RoundMode v556 = RoundMode::CAST_ROUND;
  SaturationMode v557 = SaturationMode::ON;
  TCVT(v554, v540, v556, v557);
  // pto: %t__tmp_v1055
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v558 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1055
  uint64_t v559 = (uint64_t) v10;
  TASSIGN(v558, v559);
  pipe_barrier(PIPE_V);
  TABS(v558, v554);
  // pto: %t__tmp_v1056
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v560 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
  // pto: %t__tmp_v1056
  uint64_t v561 = (uint64_t) v12;
  TASSIGN(v560, v561);
  // pto: %magnitude10_inline1159__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v562 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %magnitude10_inline1159__ssa_v0
  uint64_t v563 = (uint64_t) v24;
  TASSIGN(v562, v563);
  pipe_barrier(PIPE_V);
  TROWMAX(v562, v558, v560);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  // pto: %amax_v10_inline1160__rm_a0_tmp_v27
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v564 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v10_inline1160__rm_a0_tmp_v27
  uint64_t v565 = (uint64_t) v23;
  TASSIGN(v564, v565);
  // pto: %amax_v10_inline1160__rm_a1_tmp_v28
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v566 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v10_inline1160__rm_a1_tmp_v28
  uint64_t v567 = (uint64_t) v24;
  TASSIGN(v566, v567);
  // pto: %amax_v10_inline1160__row_major_tmp_v29
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v568 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v10_inline1160__row_major_tmp_v29
  uint64_t v569 = (uint64_t) v24;
  TASSIGN(v568, v569);
  pipe_barrier(PIPE_V);
  TMAX(v568, v564, v566);
  // pto: %amax_v10_inline1160__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v570 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %amax_v10_inline1160__ssa_v0
  uint64_t v571 = (uint64_t) v24;
  TASSIGN(v570, v571);
  // pto: %oa11_inline1051__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v572 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %oa11_inline1051__ssa_v0
  uint64_t v573 = (uint64_t) v10;
  TASSIGN(v572, v573);
  // pto: %46
  const int64_t v574 = 0;
  // pto: %46
  __gm__ float* v575 = PTOAS__GLOBAL_TENSOR_DATA(v62);
  // pto: %46
  const int64_t v576 = 1;
  // pto: %46
  const int64_t v577 = 1;
  // pto: %46
  const int64_t v578 = 1;
  // pto: %46
  int64_t v579 = v92 * v30;
  // pto: %46
  int64_t v580 = v578 * v579;
  // pto: %46
  pto::Shape<1, 1, 1, -1, 512> v581 = pto::Shape<1, 1, 1, -1, 512>(v576, v577, v578, v92, v33);
  // pto: %46
  pto::Stride<-1, -1, -1, -1, -1> v582 = pto::Stride<-1, -1, -1, -1, -1>(v577 * v580, v580, v579, v30, v31);
  // pto: %46
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v583 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v575 + (v574 + v95 * v30 + v44 * v31), v581, v582);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  TLOAD(v572, v583);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %rounded11_inline1161__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v584 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %rounded11_inline1161__ssa_v0
  uint64_t v585 = (uint64_t) v23;
  TASSIGN(v584, v585);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  pipe_barrier(PIPE_V);
  RoundMode v586 = RoundMode::CAST_RINT;
  SaturationMode v587 = SaturationMode::ON;
  TCVT(v584, v572, v586, v587);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v584.SetValidShape(v92, v33);
  // pto: %48
  const int64_t v588 = 0;
  // pto: %48
  __gm__ bfloat16_t* v589 = PTOAS__GLOBAL_TENSOR_DATA(v71);
  // pto: %48
  const int64_t v590 = 1;
  // pto: %48
  const int64_t v591 = 1;
  // pto: %48
  const int64_t v592 = 1;
  // pto: %48
  int64_t v593 = v92 * v30;
  // pto: %48
  int64_t v594 = v592 * v593;
  // pto: %48
  pto::Shape<1, 1, 1, -1, 512> v595 = pto::Shape<1, 1, 1, -1, 512>(v590, v591, v592, v92, v33);
  // pto: %48
  pto::Stride<-1, -1, -1, -1, -1> v596 = pto::Stride<-1, -1, -1, -1, -1>(v591 * v594, v594, v593, v30, v31);
  // pto: %48
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v597 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v589 + (v588 + v95 * v30 + v44 * v31), v595, v596);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  pipe_barrier(PIPE_MTE3);
  TSTORE(v597, v584);
  // pto: %t__tmp_v1058
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v598 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1058
  uint64_t v599 = (uint64_t) v10;
  TASSIGN(v598, v599);
  pipe_barrier(PIPE_V);
  RoundMode v600 = RoundMode::CAST_ROUND;
  SaturationMode v601 = SaturationMode::ON;
  TCVT(v598, v584, v600, v601);
  // pto: %t__tmp_v1059
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v602 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1059
  uint64_t v603 = (uint64_t) v10;
  TASSIGN(v602, v603);
  pipe_barrier(PIPE_V);
  TABS(v602, v598);
  // pto: %t__tmp_v1060
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v604 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
  // pto: %t__tmp_v1060
  uint64_t v605 = (uint64_t) v12;
  TASSIGN(v604, v605);
  // pto: %magnitude11_inline1035__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v606 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %magnitude11_inline1035__ssa_v0
  uint64_t v607 = (uint64_t) v25;
  TASSIGN(v606, v607);
  pipe_barrier(PIPE_V);
  TROWMAX(v606, v602, v604);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  // pto: %amax_v11_inline1132__rm_a0_tmp_v30
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v608 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v11_inline1132__rm_a0_tmp_v30
  uint64_t v609 = (uint64_t) v24;
  TASSIGN(v608, v609);
  // pto: %amax_v11_inline1132__rm_a1_tmp_v31
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v610 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v11_inline1132__rm_a1_tmp_v31
  uint64_t v611 = (uint64_t) v25;
  TASSIGN(v610, v611);
  // pto: %amax_v11_inline1132__row_major_tmp_v32
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v612 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v11_inline1132__row_major_tmp_v32
  uint64_t v613 = (uint64_t) v25;
  TASSIGN(v612, v613);
  pipe_barrier(PIPE_V);
  TMAX(v612, v608, v610);
  // pto: %amax_v11_inline1132__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v614 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %amax_v11_inline1132__ssa_v0
  uint64_t v615 = (uint64_t) v25;
  TASSIGN(v614, v615);
  // pto: %oa12_inline1181__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v616 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %oa12_inline1181__ssa_v0
  uint64_t v617 = (uint64_t) v10;
  TASSIGN(v616, v617);
  // pto: %50
  const int64_t v618 = 0;
  // pto: %50
  __gm__ float* v619 = PTOAS__GLOBAL_TENSOR_DATA(v62);
  // pto: %50
  const int64_t v620 = 1;
  // pto: %50
  const int64_t v621 = 1;
  // pto: %50
  const int64_t v622 = 1;
  // pto: %50
  int64_t v623 = v92 * v30;
  // pto: %50
  int64_t v624 = v622 * v623;
  // pto: %50
  pto::Shape<1, 1, 1, -1, 512> v625 = pto::Shape<1, 1, 1, -1, 512>(v620, v621, v622, v92, v33);
  // pto: %50
  pto::Stride<-1, -1, -1, -1, -1> v626 = pto::Stride<-1, -1, -1, -1, -1>(v621 * v624, v624, v623, v30, v31);
  // pto: %50
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v627 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v619 + (v618 + v95 * v30 + v45 * v31), v625, v626);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  TLOAD(v616, v627);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %rounded12_inline1142__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v628 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %rounded12_inline1142__ssa_v0
  uint64_t v629 = (uint64_t) v24;
  TASSIGN(v628, v629);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  pipe_barrier(PIPE_V);
  RoundMode v630 = RoundMode::CAST_RINT;
  SaturationMode v631 = SaturationMode::ON;
  TCVT(v628, v616, v630, v631);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v628.SetValidShape(v92, v33);
  // pto: %52
  const int64_t v632 = 0;
  // pto: %52
  __gm__ bfloat16_t* v633 = PTOAS__GLOBAL_TENSOR_DATA(v71);
  // pto: %52
  const int64_t v634 = 1;
  // pto: %52
  const int64_t v635 = 1;
  // pto: %52
  const int64_t v636 = 1;
  // pto: %52
  int64_t v637 = v92 * v30;
  // pto: %52
  int64_t v638 = v636 * v637;
  // pto: %52
  pto::Shape<1, 1, 1, -1, 512> v639 = pto::Shape<1, 1, 1, -1, 512>(v634, v635, v636, v92, v33);
  // pto: %52
  pto::Stride<-1, -1, -1, -1, -1> v640 = pto::Stride<-1, -1, -1, -1, -1>(v635 * v638, v638, v637, v30, v31);
  // pto: %52
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v641 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v633 + (v632 + v95 * v30 + v45 * v31), v639, v640);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  pipe_barrier(PIPE_MTE3);
  TSTORE(v641, v628);
  // pto: %t__tmp_v1062
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v642 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1062
  uint64_t v643 = (uint64_t) v10;
  TASSIGN(v642, v643);
  pipe_barrier(PIPE_V);
  RoundMode v644 = RoundMode::CAST_ROUND;
  SaturationMode v645 = SaturationMode::ON;
  TCVT(v642, v628, v644, v645);
  // pto: %t__tmp_v1063
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v646 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1063
  uint64_t v647 = (uint64_t) v10;
  TASSIGN(v646, v647);
  pipe_barrier(PIPE_V);
  TABS(v646, v642);
  // pto: %t__tmp_v1064
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v648 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
  // pto: %t__tmp_v1064
  uint64_t v649 = (uint64_t) v12;
  TASSIGN(v648, v649);
  // pto: %magnitude12_inline1240__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v650 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %magnitude12_inline1240__ssa_v0
  uint64_t v651 = (uint64_t) v26;
  TASSIGN(v650, v651);
  pipe_barrier(PIPE_V);
  TROWMAX(v650, v646, v648);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  // pto: %amax_v12_inline1250__rm_a0_tmp_v33
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v652 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v12_inline1250__rm_a0_tmp_v33
  uint64_t v653 = (uint64_t) v25;
  TASSIGN(v652, v653);
  // pto: %amax_v12_inline1250__rm_a1_tmp_v34
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v654 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v12_inline1250__rm_a1_tmp_v34
  uint64_t v655 = (uint64_t) v26;
  TASSIGN(v654, v655);
  // pto: %amax_v12_inline1250__row_major_tmp_v35
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v656 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v12_inline1250__row_major_tmp_v35
  uint64_t v657 = (uint64_t) v26;
  TASSIGN(v656, v657);
  pipe_barrier(PIPE_V);
  TMAX(v656, v652, v654);
  // pto: %amax_v12_inline1250__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v658 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %amax_v12_inline1250__ssa_v0
  uint64_t v659 = (uint64_t) v26;
  TASSIGN(v658, v659);
  // pto: %oa13_inline1078__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v660 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %oa13_inline1078__ssa_v0
  uint64_t v661 = (uint64_t) v10;
  TASSIGN(v660, v661);
  // pto: %54
  const int64_t v662 = 0;
  // pto: %54
  __gm__ float* v663 = PTOAS__GLOBAL_TENSOR_DATA(v62);
  // pto: %54
  const int64_t v664 = 1;
  // pto: %54
  const int64_t v665 = 1;
  // pto: %54
  const int64_t v666 = 1;
  // pto: %54
  int64_t v667 = v92 * v30;
  // pto: %54
  int64_t v668 = v666 * v667;
  // pto: %54
  pto::Shape<1, 1, 1, -1, 512> v669 = pto::Shape<1, 1, 1, -1, 512>(v664, v665, v666, v92, v33);
  // pto: %54
  pto::Stride<-1, -1, -1, -1, -1> v670 = pto::Stride<-1, -1, -1, -1, -1>(v665 * v668, v668, v667, v30, v31);
  // pto: %54
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v671 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v663 + (v662 + v95 * v30 + v46 * v31), v669, v670);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  TLOAD(v660, v671);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %rounded13_inline1167__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v672 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %rounded13_inline1167__ssa_v0
  uint64_t v673 = (uint64_t) v25;
  TASSIGN(v672, v673);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  pipe_barrier(PIPE_V);
  RoundMode v674 = RoundMode::CAST_RINT;
  SaturationMode v675 = SaturationMode::ON;
  TCVT(v672, v660, v674, v675);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v672.SetValidShape(v92, v33);
  // pto: %56
  const int64_t v676 = 0;
  // pto: %56
  __gm__ bfloat16_t* v677 = PTOAS__GLOBAL_TENSOR_DATA(v71);
  // pto: %56
  const int64_t v678 = 1;
  // pto: %56
  const int64_t v679 = 1;
  // pto: %56
  const int64_t v680 = 1;
  // pto: %56
  int64_t v681 = v92 * v30;
  // pto: %56
  int64_t v682 = v680 * v681;
  // pto: %56
  pto::Shape<1, 1, 1, -1, 512> v683 = pto::Shape<1, 1, 1, -1, 512>(v678, v679, v680, v92, v33);
  // pto: %56
  pto::Stride<-1, -1, -1, -1, -1> v684 = pto::Stride<-1, -1, -1, -1, -1>(v679 * v682, v682, v681, v30, v31);
  // pto: %56
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v685 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v677 + (v676 + v95 * v30 + v46 * v31), v683, v684);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  pipe_barrier(PIPE_MTE3);
  TSTORE(v685, v672);
  // pto: %t__tmp_v1066
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v686 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1066
  uint64_t v687 = (uint64_t) v10;
  TASSIGN(v686, v687);
  pipe_barrier(PIPE_V);
  RoundMode v688 = RoundMode::CAST_ROUND;
  SaturationMode v689 = SaturationMode::ON;
  TCVT(v686, v672, v688, v689);
  // pto: %t__tmp_v1067
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v690 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1067
  uint64_t v691 = (uint64_t) v10;
  TASSIGN(v690, v691);
  pipe_barrier(PIPE_V);
  TABS(v690, v686);
  // pto: %t__tmp_v1068
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v692 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
  // pto: %t__tmp_v1068
  uint64_t v693 = (uint64_t) v12;
  TASSIGN(v692, v693);
  // pto: %magnitude13_inline1168__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v694 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %magnitude13_inline1168__ssa_v0
  uint64_t v695 = (uint64_t) v27;
  TASSIGN(v694, v695);
  pipe_barrier(PIPE_V);
  TROWMAX(v694, v690, v692);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  // pto: %amax_v13_inline1171__rm_a0_tmp_v36
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v696 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v13_inline1171__rm_a0_tmp_v36
  uint64_t v697 = (uint64_t) v26;
  TASSIGN(v696, v697);
  // pto: %amax_v13_inline1171__rm_a1_tmp_v37
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v698 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v13_inline1171__rm_a1_tmp_v37
  uint64_t v699 = (uint64_t) v27;
  TASSIGN(v698, v699);
  // pto: %amax_v13_inline1171__row_major_tmp_v38
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v700 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v13_inline1171__row_major_tmp_v38
  uint64_t v701 = (uint64_t) v27;
  TASSIGN(v700, v701);
  pipe_barrier(PIPE_V);
  TMAX(v700, v696, v698);
  // pto: %amax_v13_inline1171__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v702 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %amax_v13_inline1171__ssa_v0
  uint64_t v703 = (uint64_t) v27;
  TASSIGN(v702, v703);
  // pto: %oa14_inline1173__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v704 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %oa14_inline1173__ssa_v0
  uint64_t v705 = (uint64_t) v10;
  TASSIGN(v704, v705);
  // pto: %58
  const int64_t v706 = 0;
  // pto: %58
  __gm__ float* v707 = PTOAS__GLOBAL_TENSOR_DATA(v62);
  // pto: %58
  const int64_t v708 = 1;
  // pto: %58
  const int64_t v709 = 1;
  // pto: %58
  const int64_t v710 = 1;
  // pto: %58
  int64_t v711 = v92 * v30;
  // pto: %58
  int64_t v712 = v710 * v711;
  // pto: %58
  pto::Shape<1, 1, 1, -1, 512> v713 = pto::Shape<1, 1, 1, -1, 512>(v708, v709, v710, v92, v33);
  // pto: %58
  pto::Stride<-1, -1, -1, -1, -1> v714 = pto::Stride<-1, -1, -1, -1, -1>(v709 * v712, v712, v711, v30, v31);
  // pto: %58
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v715 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v707 + (v706 + v95 * v30 + v47 * v31), v713, v714);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  TLOAD(v704, v715);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %rounded14_inline1010__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v716 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %rounded14_inline1010__ssa_v0
  uint64_t v717 = (uint64_t) v26;
  TASSIGN(v716, v717);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  pipe_barrier(PIPE_V);
  RoundMode v718 = RoundMode::CAST_RINT;
  SaturationMode v719 = SaturationMode::ON;
  TCVT(v716, v704, v718, v719);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v716.SetValidShape(v92, v33);
  // pto: %60
  const int64_t v720 = 0;
  // pto: %60
  __gm__ bfloat16_t* v721 = PTOAS__GLOBAL_TENSOR_DATA(v71);
  // pto: %60
  const int64_t v722 = 1;
  // pto: %60
  const int64_t v723 = 1;
  // pto: %60
  const int64_t v724 = 1;
  // pto: %60
  int64_t v725 = v92 * v30;
  // pto: %60
  int64_t v726 = v724 * v725;
  // pto: %60
  pto::Shape<1, 1, 1, -1, 512> v727 = pto::Shape<1, 1, 1, -1, 512>(v722, v723, v724, v92, v33);
  // pto: %60
  pto::Stride<-1, -1, -1, -1, -1> v728 = pto::Stride<-1, -1, -1, -1, -1>(v723 * v726, v726, v725, v30, v31);
  // pto: %60
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v729 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v721 + (v720 + v95 * v30 + v47 * v31), v727, v728);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  pipe_barrier(PIPE_MTE3);
  TSTORE(v729, v716);
  // pto: %t__tmp_v1070
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v730 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1070
  uint64_t v731 = (uint64_t) v10;
  TASSIGN(v730, v731);
  pipe_barrier(PIPE_V);
  RoundMode v732 = RoundMode::CAST_ROUND;
  SaturationMode v733 = SaturationMode::ON;
  TCVT(v730, v716, v732, v733);
  // pto: %t__tmp_v1071
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v734 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1071
  uint64_t v735 = (uint64_t) v10;
  TASSIGN(v734, v735);
  pipe_barrier(PIPE_V);
  TABS(v734, v730);
  // pto: %t__tmp_v1072
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v736 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
  // pto: %t__tmp_v1072
  uint64_t v737 = (uint64_t) v12;
  TASSIGN(v736, v737);
  // pto: %magnitude14_inline1058__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v738 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %magnitude14_inline1058__ssa_v0
  uint64_t v739 = (uint64_t) v28;
  TASSIGN(v738, v739);
  pipe_barrier(PIPE_V);
  TROWMAX(v738, v734, v736);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  // pto: %amax_v14_inline1041__rm_a0_tmp_v39
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v740 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v14_inline1041__rm_a0_tmp_v39
  uint64_t v741 = (uint64_t) v27;
  TASSIGN(v740, v741);
  // pto: %amax_v14_inline1041__rm_a1_tmp_v40
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v742 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v14_inline1041__rm_a1_tmp_v40
  uint64_t v743 = (uint64_t) v28;
  TASSIGN(v742, v743);
  // pto: %amax_v14_inline1041__row_major_tmp_v41
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v744 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v14_inline1041__row_major_tmp_v41
  uint64_t v745 = (uint64_t) v28;
  TASSIGN(v744, v745);
  pipe_barrier(PIPE_V);
  TMAX(v744, v740, v742);
  // pto: %amax_v14_inline1041__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v746 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %amax_v14_inline1041__ssa_v0
  uint64_t v747 = (uint64_t) v28;
  TASSIGN(v746, v747);
  // pto: %oa15_inline1089__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v748 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %oa15_inline1089__ssa_v0
  uint64_t v749 = (uint64_t) v10;
  TASSIGN(v748, v749);
  // pto: %62
  const int64_t v750 = 0;
  // pto: %62
  __gm__ float* v751 = PTOAS__GLOBAL_TENSOR_DATA(v62);
  // pto: %62
  const int64_t v752 = 1;
  // pto: %62
  const int64_t v753 = 1;
  // pto: %62
  const int64_t v754 = 1;
  // pto: %62
  int64_t v755 = v92 * v30;
  // pto: %62
  int64_t v756 = v754 * v755;
  // pto: %62
  pto::Shape<1, 1, 1, -1, 512> v757 = pto::Shape<1, 1, 1, -1, 512>(v752, v753, v754, v92, v33);
  // pto: %62
  pto::Stride<-1, -1, -1, -1, -1> v758 = pto::Stride<-1, -1, -1, -1, -1>(v753 * v756, v756, v755, v30, v31);
  // pto: %62
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v759 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v751 + (v750 + v95 * v30 + v48 * v31), v757, v758);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  TLOAD(v748, v759);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %rounded15_inline1021__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v760 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %rounded15_inline1021__ssa_v0
  uint64_t v761 = (uint64_t) v27;
  TASSIGN(v760, v761);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  pipe_barrier(PIPE_V);
  RoundMode v762 = RoundMode::CAST_RINT;
  SaturationMode v763 = SaturationMode::ON;
  TCVT(v760, v748, v762, v763);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v760.SetValidShape(v92, v33);
  // pto: %64
  const int64_t v764 = 0;
  // pto: %64
  __gm__ bfloat16_t* v765 = PTOAS__GLOBAL_TENSOR_DATA(v71);
  // pto: %64
  const int64_t v766 = 1;
  // pto: %64
  const int64_t v767 = 1;
  // pto: %64
  const int64_t v768 = 1;
  // pto: %64
  int64_t v769 = v92 * v30;
  // pto: %64
  int64_t v770 = v768 * v769;
  // pto: %64
  pto::Shape<1, 1, 1, -1, 512> v771 = pto::Shape<1, 1, 1, -1, 512>(v766, v767, v768, v92, v33);
  // pto: %64
  pto::Stride<-1, -1, -1, -1, -1> v772 = pto::Stride<-1, -1, -1, -1, -1>(v767 * v770, v770, v769, v30, v31);
  // pto: %64
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v773 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v765 + (v764 + v95 * v30 + v48 * v31), v771, v772);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  pipe_barrier(PIPE_MTE3);
  TSTORE(v773, v760);
  // pto: %t__tmp_v1074
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v774 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1074
  uint64_t v775 = (uint64_t) v10;
  TASSIGN(v774, v775);
  pipe_barrier(PIPE_V);
  RoundMode v776 = RoundMode::CAST_ROUND;
  SaturationMode v777 = SaturationMode::ON;
  TCVT(v774, v760, v776, v777);
  // pto: %t__tmp_v1075
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v778 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1075
  uint64_t v779 = (uint64_t) v10;
  TASSIGN(v778, v779);
  pipe_barrier(PIPE_V);
  TABS(v778, v774);
  // pto: %t__tmp_v1076
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v780 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
  // pto: %t__tmp_v1076
  uint64_t v781 = (uint64_t) v12;
  TASSIGN(v780, v781);
  // pto: %magnitude15_inline1176__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v782 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %magnitude15_inline1176__ssa_v0
  uint64_t v783 = (uint64_t) v29;
  TASSIGN(v782, v783);
  pipe_barrier(PIPE_V);
  TROWMAX(v782, v778, v780);
  // pto: %amax_v15_inline1234__rm_a0_tmp_v42
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v784 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v15_inline1234__rm_a0_tmp_v42
  uint64_t v785 = (uint64_t) v28;
  TASSIGN(v784, v785);
  // pto: %amax_v15_inline1234__rm_a1_tmp_v43
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v786 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v15_inline1234__rm_a1_tmp_v43
  uint64_t v787 = (uint64_t) v29;
  TASSIGN(v786, v787);
  // pto: %amax_v15_inline1234__row_major_tmp_v44
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v788 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %amax_v15_inline1234__row_major_tmp_v44
  uint64_t v789 = (uint64_t) v10;
  TASSIGN(v788, v789);
  pipe_barrier(PIPE_V);
  TMAX(v788, v784, v786);
  // pto: %amax_v15_inline1234__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v790 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %amax_v15_inline1234__ssa_v0
  uint64_t v791 = (uint64_t) v10;
  TASSIGN(v790, v791);
  // pto: %dequant_inline1179__rm_a0_tmp_v45
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v792 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %dequant_inline1179__rm_a0_tmp_v45
  uint64_t v793 = (uint64_t) v10;
  TASSIGN(v792, v793);
  // pto: %dequant_inline1179__row_major_tmp_v46
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v794 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %dequant_inline1179__row_major_tmp_v46
  uint64_t v795 = (uint64_t) v12;
  TASSIGN(v794, v795);
  pipe_barrier(PIPE_V);
  TMULS(v794, v792, v49);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %dequant_inline1179__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v796 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %dequant_inline1179__ssa_v0
  uint64_t v797 = (uint64_t) v12;
  TASSIGN(v796, v797);
  // pto: %denominator_inline1000__rm_a0_tmp_v47
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v798 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %denominator_inline1000__rm_a0_tmp_v47
  uint64_t v799 = (uint64_t) v10;
  TASSIGN(v798, v799);
  // pto: %denominator_inline1000__row_major_tmp_v48
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v800 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %denominator_inline1000__row_major_tmp_v48
  uint64_t v801 = (uint64_t) v28;
  TASSIGN(v800, v801);
  TADDS(v800, v798, v50);
  set_flag(PIPE_V, PIPE_S, EVENT_ID0);
  // pto: %denominator_inline1000__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v802 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %denominator_inline1000__ssa_v0
  uint64_t v803 = (uint64_t) v28;
  TASSIGN(v802, v803);
  wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
  for (int64_t v804 = v34; v804 < v92; v804 += v31) {
    // pto: %magnitude_inline1075__ssa_v0
    ;
    float v805 = v802.GetValue(v804);
    // pto: %65
    ;
    bool v806 = v805 != v805 || v50 != v50;
    // pto: %65
    ;
    if ((v805 == v805 && v50 == v50) && v805 == v50) {
      v802.SetValue(v804, v51);
    };
  }
  set_flag(PIPE_S, PIPE_V, EVENT_ID0);
  // pto: %t__rm_a0_tmp_v49
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v807 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %t__rm_a0_tmp_v49
  uint64_t v808 = (uint64_t) v10;
  TASSIGN(v807, v808);
  // pto: %t__row_major_tmp_v50
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v809 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %t__row_major_tmp_v50
  uint64_t v810 = (uint64_t) v10;
  TASSIGN(v809, v810);
  pipe_barrier(PIPE_V);
  TMULS(v809, v807, v50);
  // pto: %t__tmp_v1077
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v811 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %t__tmp_v1077
  uint64_t v812 = (uint64_t) v10;
  TASSIGN(v811, v812);
  // pto: %t__rm_a0_tmp_v51
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v813 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %t__rm_a0_tmp_v51
  uint64_t v814 = (uint64_t) v10;
  TASSIGN(v813, v814);
  // pto: %t__row_major_tmp_v52
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v815 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %t__row_major_tmp_v52
  uint64_t v816 = (uint64_t) v10;
  TASSIGN(v815, v816);
  pipe_barrier(PIPE_V);
  TADDS(v815, v813, v52);
  // pto: %t__tmp_v1078
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v817 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %t__tmp_v1078
  uint64_t v818 = (uint64_t) v10;
  TASSIGN(v817, v818);
  // pto: %multiplier_inline1189__rm_a0_tmp_v53
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v819 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %multiplier_inline1189__rm_a0_tmp_v53
  uint64_t v820 = (uint64_t) v10;
  TASSIGN(v819, v820);
  // pto: %multiplier_inline1189__rm_a1_tmp_v54
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v821 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %multiplier_inline1189__rm_a1_tmp_v54
  uint64_t v822 = (uint64_t) v28;
  TASSIGN(v821, v822);
  // pto: %multiplier_inline1189__row_major_tmp_v55
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v823 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v92);
  // pto: %multiplier_inline1189__row_major_tmp_v55
  uint64_t v824 = (uint64_t) v28;
  TASSIGN(v823, v824);
  pipe_barrier(PIPE_V);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
  TDIV(v823, v819, v821);
  // pto: %multiplier_inline1189__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v825 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v31);
  // pto: %multiplier_inline1189__ssa_v0
  uint64_t v826 = (uint64_t) v28;
  TASSIGN(v825, v826);
  v796.SetValidShape(v92, v31);
  // pto: %scale_o__ssa_v0_pview
  int64_t v827 = (int64_t) v7;
  // pto: %scale_o__ssa_v0_pview
  const int64_t v828 = 0;
  // pto: %scale_o__ssa_v0_pview
  __gm__ float* v829 = PTOAS__GLOBAL_TENSOR_DATA(v80);
  // pto: %scale_o__ssa_v0_pview
  const int64_t v830 = 1;
  // pto: %scale_o__ssa_v0_pview
  const int64_t v831 = 1;
  // pto: %scale_o__ssa_v0_pview
  const int64_t v832 = 1;
  // pto: %scale_o__ssa_v0_pview
  int64_t v833 = v92 * v31;
  // pto: %scale_o__ssa_v0_pview
  int64_t v834 = v832 * v833;
  // pto: %scale_o__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 1> v835 = pto::Shape<1, 1, 1, -1, 1>(v830, v831, v832, v92, v31);
  // pto: %scale_o__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v836 = pto::Stride<-1, -1, -1, -1, -1>(v831 * v834, v834, v833, v31, v827);
  // pto: %scale_o__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v837 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v829 + (v828 + v95 * v31 + v34 * v827), v835, v836);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v837, v796);
  // pto: %t__tmp_v1080
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v838 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1080
  uint64_t v839 = (uint64_t) v10;
  TASSIGN(v838, v839);
  pipe_barrier(PIPE_V);
  RoundMode v840 = RoundMode::CAST_ROUND;
  SaturationMode v841 = SaturationMode::ON;
  TCVT(v838, v106, v840, v841);
  // pto: %scaled0_inline1182__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v842 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %scaled0_inline1182__ssa_v0
  uint64_t v843 = (uint64_t) v10;
  TASSIGN(v842, v843);
  pipe_barrier(PIPE_V);
  TROWEXPANDMUL(v842, v838, v825);
  // pto: %integer0_inline1163__ssa_v0
  Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v844 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %integer0_inline1163__ssa_v0
  uint64_t v845 = (uint64_t) v10;
  TASSIGN(v844, v845);
  pipe_barrier(PIPE_V);
  RoundMode v846 = RoundMode::CAST_RINT;
  SaturationMode v847 = SaturationMode::ON;
  TCVT(v844, v842, v846, v847);
  // pto: %half0_inline1037__ssa_v0
  Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v848 = Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %half0_inline1037__ssa_v0
  uint64_t v849 = (uint64_t) v10;
  TASSIGN(v848, v849);
  pipe_barrier(PIPE_V);
  RoundMode v850 = RoundMode::CAST_ROUND;
  SaturationMode v851 = SaturationMode::ON;
  TCVT(v848, v844, v850, v851);
  // pto: %result0_inline1090__ssa_v0
  Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v852 = Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %result0_inline1090__ssa_v0
  uint64_t v853 = (uint64_t) v10;
  TASSIGN(v852, v853);
  pipe_barrier(PIPE_V);
  RoundMode v854 = RoundMode::CAST_TRUNC;
  SaturationMode v855 = SaturationMode::ON;
  TCVT(v852, v848, v854, v855);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v852.SetValidShape(v92, v33);
  // pto: %quantized_o__ssa_v0_pview
  const int64_t v856 = 0;
  // pto: %quantized_o__ssa_v0_pview
  __gm__ int8_t* v857 = PTOAS__GLOBAL_TENSOR_DATA(v89);
  // pto: %quantized_o__ssa_v0_pview
  const int64_t v858 = 1;
  // pto: %quantized_o__ssa_v0_pview
  const int64_t v859 = 1;
  // pto: %quantized_o__ssa_v0_pview
  const int64_t v860 = 1;
  // pto: %quantized_o__ssa_v0_pview
  int64_t v861 = v92 * v30;
  // pto: %quantized_o__ssa_v0_pview
  int64_t v862 = v860 * v861;
  // pto: %quantized_o__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 512> v863 = pto::Shape<1, 1, 1, -1, 512>(v858, v859, v860, v92, v33);
  // pto: %quantized_o__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v864 = pto::Stride<-1, -1, -1, -1, -1>(v859 * v862, v862, v861, v30, v31);
  // pto: %quantized_o__ssa_v0_pview
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v865 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v857 + (v856 + v95 * v30 + v34 * v31), v863, v864);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v865, v852);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  // pto: %t__tmp_v1082
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v866 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1082
  uint64_t v867 = (uint64_t) v10;
  TASSIGN(v866, v867);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  RoundMode v868 = RoundMode::CAST_ROUND;
  SaturationMode v869 = SaturationMode::ON;
  TCVT(v866, v144, v868, v869);
  // pto: %scaled1_inline1184__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v870 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %scaled1_inline1184__ssa_v0
  uint64_t v871 = (uint64_t) v10;
  TASSIGN(v870, v871);
  pipe_barrier(PIPE_V);
  TROWEXPANDMUL(v870, v866, v825);
  // pto: %integer1_inline1029__ssa_v0
  Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v872 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %integer1_inline1029__ssa_v0
  uint64_t v873 = (uint64_t) v10;
  TASSIGN(v872, v873);
  pipe_barrier(PIPE_V);
  RoundMode v874 = RoundMode::CAST_RINT;
  SaturationMode v875 = SaturationMode::ON;
  TCVT(v872, v870, v874, v875);
  // pto: %half1_inline1164__ssa_v0
  Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v876 = Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %half1_inline1164__ssa_v0
  uint64_t v877 = (uint64_t) v10;
  TASSIGN(v876, v877);
  pipe_barrier(PIPE_V);
  RoundMode v878 = RoundMode::CAST_ROUND;
  SaturationMode v879 = SaturationMode::ON;
  TCVT(v876, v872, v878, v879);
  // pto: %result1_inline1188__ssa_v0
  Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v880 = Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %result1_inline1188__ssa_v0
  uint64_t v881 = (uint64_t) v10;
  TASSIGN(v880, v881);
  pipe_barrier(PIPE_V);
  RoundMode v882 = RoundMode::CAST_TRUNC;
  SaturationMode v883 = SaturationMode::ON;
  TCVT(v880, v876, v882, v883);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v880.SetValidShape(v92, v33);
  // pto: %71
  const int64_t v884 = 0;
  // pto: %71
  __gm__ int8_t* v885 = PTOAS__GLOBAL_TENSOR_DATA(v89);
  // pto: %71
  const int64_t v886 = 1;
  // pto: %71
  const int64_t v887 = 1;
  // pto: %71
  const int64_t v888 = 1;
  // pto: %71
  int64_t v889 = v92 * v30;
  // pto: %71
  int64_t v890 = v888 * v889;
  // pto: %71
  pto::Shape<1, 1, 1, -1, 512> v891 = pto::Shape<1, 1, 1, -1, 512>(v886, v887, v888, v92, v33);
  // pto: %71
  pto::Stride<-1, -1, -1, -1, -1> v892 = pto::Stride<-1, -1, -1, -1, -1>(v887 * v890, v890, v889, v30, v31);
  // pto: %71
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v893 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v885 + (v884 + v95 * v30 + v33 * v31), v891, v892);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v893, v880);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  // pto: %t__tmp_v1084
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v894 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1084
  uint64_t v895 = (uint64_t) v10;
  TASSIGN(v894, v895);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  RoundMode v896 = RoundMode::CAST_ROUND;
  SaturationMode v897 = SaturationMode::ON;
  TCVT(v894, v188, v896, v897);
  // pto: %scaled2_inline1190__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v898 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %scaled2_inline1190__ssa_v0
  uint64_t v899 = (uint64_t) v10;
  TASSIGN(v898, v899);
  pipe_barrier(PIPE_V);
  TROWEXPANDMUL(v898, v894, v825);
  // pto: %integer2_inline1192__ssa_v0
  Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v900 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %integer2_inline1192__ssa_v0
  uint64_t v901 = (uint64_t) v10;
  TASSIGN(v900, v901);
  pipe_barrier(PIPE_V);
  RoundMode v902 = RoundMode::CAST_RINT;
  SaturationMode v903 = SaturationMode::ON;
  TCVT(v900, v898, v902, v903);
  // pto: %half2_inline1083__ssa_v0
  Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v904 = Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %half2_inline1083__ssa_v0
  uint64_t v905 = (uint64_t) v10;
  TASSIGN(v904, v905);
  pipe_barrier(PIPE_V);
  RoundMode v906 = RoundMode::CAST_ROUND;
  SaturationMode v907 = SaturationMode::ON;
  TCVT(v904, v900, v906, v907);
  // pto: %result2_inline1006__ssa_v0
  Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v908 = Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %result2_inline1006__ssa_v0
  uint64_t v909 = (uint64_t) v10;
  TASSIGN(v908, v909);
  pipe_barrier(PIPE_V);
  RoundMode v910 = RoundMode::CAST_TRUNC;
  SaturationMode v911 = SaturationMode::ON;
  TCVT(v908, v904, v910, v911);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v908.SetValidShape(v92, v33);
  // pto: %73
  const int64_t v912 = 0;
  // pto: %73
  __gm__ int8_t* v913 = PTOAS__GLOBAL_TENSOR_DATA(v89);
  // pto: %73
  const int64_t v914 = 1;
  // pto: %73
  const int64_t v915 = 1;
  // pto: %73
  const int64_t v916 = 1;
  // pto: %73
  int64_t v917 = v92 * v30;
  // pto: %73
  int64_t v918 = v916 * v917;
  // pto: %73
  pto::Shape<1, 1, 1, -1, 512> v919 = pto::Shape<1, 1, 1, -1, 512>(v914, v915, v916, v92, v33);
  // pto: %73
  pto::Stride<-1, -1, -1, -1, -1> v920 = pto::Stride<-1, -1, -1, -1, -1>(v915 * v918, v918, v917, v30, v31);
  // pto: %73
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v921 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v913 + (v912 + v95 * v30 + v35 * v31), v919, v920);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v921, v908);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  // pto: %t__tmp_v1086
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v922 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1086
  uint64_t v923 = (uint64_t) v10;
  TASSIGN(v922, v923);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  RoundMode v924 = RoundMode::CAST_ROUND;
  SaturationMode v925 = SaturationMode::ON;
  TCVT(v922, v232, v924, v925);
  // pto: %scaled3_inline1144__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v926 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %scaled3_inline1144__ssa_v0
  uint64_t v927 = (uint64_t) v10;
  TASSIGN(v926, v927);
  pipe_barrier(PIPE_V);
  TROWEXPANDMUL(v926, v922, v825);
  // pto: %integer3_inline1194__ssa_v0
  Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v928 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %integer3_inline1194__ssa_v0
  uint64_t v929 = (uint64_t) v10;
  TASSIGN(v928, v929);
  pipe_barrier(PIPE_V);
  RoundMode v930 = RoundMode::CAST_RINT;
  SaturationMode v931 = SaturationMode::ON;
  TCVT(v928, v926, v930, v931);
  // pto: %half3_inline1196__ssa_v0
  Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v932 = Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %half3_inline1196__ssa_v0
  uint64_t v933 = (uint64_t) v10;
  TASSIGN(v932, v933);
  pipe_barrier(PIPE_V);
  RoundMode v934 = RoundMode::CAST_ROUND;
  SaturationMode v935 = SaturationMode::ON;
  TCVT(v932, v928, v934, v935);
  // pto: %result3_inline1197__ssa_v0
  Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v936 = Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %result3_inline1197__ssa_v0
  uint64_t v937 = (uint64_t) v10;
  TASSIGN(v936, v937);
  pipe_barrier(PIPE_V);
  RoundMode v938 = RoundMode::CAST_TRUNC;
  SaturationMode v939 = SaturationMode::ON;
  TCVT(v936, v932, v938, v939);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v936.SetValidShape(v92, v33);
  // pto: %75
  const int64_t v940 = 0;
  // pto: %75
  __gm__ int8_t* v941 = PTOAS__GLOBAL_TENSOR_DATA(v89);
  // pto: %75
  const int64_t v942 = 1;
  // pto: %75
  const int64_t v943 = 1;
  // pto: %75
  const int64_t v944 = 1;
  // pto: %75
  int64_t v945 = v92 * v30;
  // pto: %75
  int64_t v946 = v944 * v945;
  // pto: %75
  pto::Shape<1, 1, 1, -1, 512> v947 = pto::Shape<1, 1, 1, -1, 512>(v942, v943, v944, v92, v33);
  // pto: %75
  pto::Stride<-1, -1, -1, -1, -1> v948 = pto::Stride<-1, -1, -1, -1, -1>(v943 * v946, v946, v945, v30, v31);
  // pto: %75
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v949 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v941 + (v940 + v95 * v30 + v36 * v31), v947, v948);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v949, v936);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  // pto: %t__tmp_v1088
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v950 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1088
  uint64_t v951 = (uint64_t) v10;
  TASSIGN(v950, v951);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  RoundMode v952 = RoundMode::CAST_ROUND;
  SaturationMode v953 = SaturationMode::ON;
  TCVT(v950, v276, v952, v953);
  // pto: %scaled4_inline1220__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v954 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %scaled4_inline1220__ssa_v0
  uint64_t v955 = (uint64_t) v10;
  TASSIGN(v954, v955);
  pipe_barrier(PIPE_V);
  TROWEXPANDMUL(v954, v950, v825);
  // pto: %integer4_inline1199__ssa_v0
  Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v956 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %integer4_inline1199__ssa_v0
  uint64_t v957 = (uint64_t) v10;
  TASSIGN(v956, v957);
  pipe_barrier(PIPE_V);
  RoundMode v958 = RoundMode::CAST_RINT;
  SaturationMode v959 = SaturationMode::ON;
  TCVT(v956, v954, v958, v959);
  // pto: %half4_inline1169__ssa_v0
  Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v960 = Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %half4_inline1169__ssa_v0
  uint64_t v961 = (uint64_t) v10;
  TASSIGN(v960, v961);
  pipe_barrier(PIPE_V);
  RoundMode v962 = RoundMode::CAST_ROUND;
  SaturationMode v963 = SaturationMode::ON;
  TCVT(v960, v956, v962, v963);
  // pto: %result4_inline1200__ssa_v0
  Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v964 = Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %result4_inline1200__ssa_v0
  uint64_t v965 = (uint64_t) v10;
  TASSIGN(v964, v965);
  pipe_barrier(PIPE_V);
  RoundMode v966 = RoundMode::CAST_TRUNC;
  SaturationMode v967 = SaturationMode::ON;
  TCVT(v964, v960, v966, v967);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v964.SetValidShape(v92, v33);
  // pto: %77
  const int64_t v968 = 0;
  // pto: %77
  __gm__ int8_t* v969 = PTOAS__GLOBAL_TENSOR_DATA(v89);
  // pto: %77
  const int64_t v970 = 1;
  // pto: %77
  const int64_t v971 = 1;
  // pto: %77
  const int64_t v972 = 1;
  // pto: %77
  int64_t v973 = v92 * v30;
  // pto: %77
  int64_t v974 = v972 * v973;
  // pto: %77
  pto::Shape<1, 1, 1, -1, 512> v975 = pto::Shape<1, 1, 1, -1, 512>(v970, v971, v972, v92, v33);
  // pto: %77
  pto::Stride<-1, -1, -1, -1, -1> v976 = pto::Stride<-1, -1, -1, -1, -1>(v971 * v974, v974, v973, v30, v31);
  // pto: %77
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v977 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v969 + (v968 + v95 * v30 + v37 * v31), v975, v976);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v977, v964);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  // pto: %t__tmp_v1090
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v978 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1090
  uint64_t v979 = (uint64_t) v10;
  TASSIGN(v978, v979);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  RoundMode v980 = RoundMode::CAST_ROUND;
  SaturationMode v981 = SaturationMode::ON;
  TCVT(v978, v320, v980, v981);
  // pto: %scaled5_inline1201__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v982 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %scaled5_inline1201__ssa_v0
  uint64_t v983 = (uint64_t) v10;
  TASSIGN(v982, v983);
  pipe_barrier(PIPE_V);
  TROWEXPANDMUL(v982, v978, v825);
  // pto: %integer5_inline1202__ssa_v0
  Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v984 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %integer5_inline1202__ssa_v0
  uint64_t v985 = (uint64_t) v10;
  TASSIGN(v984, v985);
  pipe_barrier(PIPE_V);
  RoundMode v986 = RoundMode::CAST_RINT;
  SaturationMode v987 = SaturationMode::ON;
  TCVT(v984, v982, v986, v987);
  // pto: %half5_inline1204__ssa_v0
  Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v988 = Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %half5_inline1204__ssa_v0
  uint64_t v989 = (uint64_t) v10;
  TASSIGN(v988, v989);
  pipe_barrier(PIPE_V);
  RoundMode v990 = RoundMode::CAST_ROUND;
  SaturationMode v991 = SaturationMode::ON;
  TCVT(v988, v984, v990, v991);
  // pto: %result5_inline1205__ssa_v0
  Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v992 = Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %result5_inline1205__ssa_v0
  uint64_t v993 = (uint64_t) v10;
  TASSIGN(v992, v993);
  pipe_barrier(PIPE_V);
  RoundMode v994 = RoundMode::CAST_TRUNC;
  SaturationMode v995 = SaturationMode::ON;
  TCVT(v992, v988, v994, v995);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v992.SetValidShape(v92, v33);
  // pto: %79
  const int64_t v996 = 0;
  // pto: %79
  __gm__ int8_t* v997 = PTOAS__GLOBAL_TENSOR_DATA(v89);
  // pto: %79
  const int64_t v998 = 1;
  // pto: %79
  const int64_t v999 = 1;
  // pto: %79
  const int64_t v1000 = 1;
  // pto: %79
  int64_t v1001 = v92 * v30;
  // pto: %79
  int64_t v1002 = v1000 * v1001;
  // pto: %79
  pto::Shape<1, 1, 1, -1, 512> v1003 = pto::Shape<1, 1, 1, -1, 512>(v998, v999, v1000, v92, v33);
  // pto: %79
  pto::Stride<-1, -1, -1, -1, -1> v1004 = pto::Stride<-1, -1, -1, -1, -1>(v999 * v1002, v1002, v1001, v30, v31);
  // pto: %79
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1005 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v997 + (v996 + v95 * v30 + v38 * v31), v1003, v1004);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v1005, v992);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  // pto: %t__tmp_v1092
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1006 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1092
  uint64_t v1007 = (uint64_t) v10;
  TASSIGN(v1006, v1007);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  RoundMode v1008 = RoundMode::CAST_ROUND;
  SaturationMode v1009 = SaturationMode::ON;
  TCVT(v1006, v364, v1008, v1009);
  // pto: %scaled6_inline1038__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1010 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %scaled6_inline1038__ssa_v0
  uint64_t v1011 = (uint64_t) v10;
  TASSIGN(v1010, v1011);
  pipe_barrier(PIPE_V);
  TROWEXPANDMUL(v1010, v1006, v825);
  // pto: %integer6_inline1206__ssa_v0
  Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1012 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %integer6_inline1206__ssa_v0
  uint64_t v1013 = (uint64_t) v10;
  TASSIGN(v1012, v1013);
  pipe_barrier(PIPE_V);
  RoundMode v1014 = RoundMode::CAST_RINT;
  SaturationMode v1015 = SaturationMode::ON;
  TCVT(v1012, v1010, v1014, v1015);
  // pto: %half6_inline1208__ssa_v0
  Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1016 = Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %half6_inline1208__ssa_v0
  uint64_t v1017 = (uint64_t) v10;
  TASSIGN(v1016, v1017);
  pipe_barrier(PIPE_V);
  RoundMode v1018 = RoundMode::CAST_ROUND;
  SaturationMode v1019 = SaturationMode::ON;
  TCVT(v1016, v1012, v1018, v1019);
  // pto: %result6_inline1211__ssa_v0
  Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1020 = Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %result6_inline1211__ssa_v0
  uint64_t v1021 = (uint64_t) v10;
  TASSIGN(v1020, v1021);
  pipe_barrier(PIPE_V);
  RoundMode v1022 = RoundMode::CAST_TRUNC;
  SaturationMode v1023 = SaturationMode::ON;
  TCVT(v1020, v1016, v1022, v1023);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v1020.SetValidShape(v92, v33);
  // pto: %81
  const int64_t v1024 = 0;
  // pto: %81
  __gm__ int8_t* v1025 = PTOAS__GLOBAL_TENSOR_DATA(v89);
  // pto: %81
  const int64_t v1026 = 1;
  // pto: %81
  const int64_t v1027 = 1;
  // pto: %81
  const int64_t v1028 = 1;
  // pto: %81
  int64_t v1029 = v92 * v30;
  // pto: %81
  int64_t v1030 = v1028 * v1029;
  // pto: %81
  pto::Shape<1, 1, 1, -1, 512> v1031 = pto::Shape<1, 1, 1, -1, 512>(v1026, v1027, v1028, v92, v33);
  // pto: %81
  pto::Stride<-1, -1, -1, -1, -1> v1032 = pto::Stride<-1, -1, -1, -1, -1>(v1027 * v1030, v1030, v1029, v30, v31);
  // pto: %81
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1033 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1025 + (v1024 + v95 * v30 + v39 * v31), v1031, v1032);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v1033, v1020);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  // pto: %t__tmp_v1094
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1034 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1094
  uint64_t v1035 = (uint64_t) v10;
  TASSIGN(v1034, v1035);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  RoundMode v1036 = RoundMode::CAST_ROUND;
  SaturationMode v1037 = SaturationMode::ON;
  TCVT(v1034, v408, v1036, v1037);
  // pto: %scaled7_inline1213__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1038 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %scaled7_inline1213__ssa_v0
  uint64_t v1039 = (uint64_t) v10;
  TASSIGN(v1038, v1039);
  pipe_barrier(PIPE_V);
  TROWEXPANDMUL(v1038, v1034, v825);
  // pto: %integer7_inline1214__ssa_v0
  Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1040 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %integer7_inline1214__ssa_v0
  uint64_t v1041 = (uint64_t) v10;
  TASSIGN(v1040, v1041);
  pipe_barrier(PIPE_V);
  RoundMode v1042 = RoundMode::CAST_RINT;
  SaturationMode v1043 = SaturationMode::ON;
  TCVT(v1040, v1038, v1042, v1043);
  // pto: %half7_inline1101__ssa_v0
  Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1044 = Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %half7_inline1101__ssa_v0
  uint64_t v1045 = (uint64_t) v10;
  TASSIGN(v1044, v1045);
  pipe_barrier(PIPE_V);
  RoundMode v1046 = RoundMode::CAST_ROUND;
  SaturationMode v1047 = SaturationMode::ON;
  TCVT(v1044, v1040, v1046, v1047);
  // pto: %result7_inline1215__ssa_v0
  Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1048 = Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %result7_inline1215__ssa_v0
  uint64_t v1049 = (uint64_t) v10;
  TASSIGN(v1048, v1049);
  pipe_barrier(PIPE_V);
  RoundMode v1050 = RoundMode::CAST_TRUNC;
  SaturationMode v1051 = SaturationMode::ON;
  TCVT(v1048, v1044, v1050, v1051);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v1048.SetValidShape(v92, v33);
  // pto: %83
  const int64_t v1052 = 0;
  // pto: %83
  __gm__ int8_t* v1053 = PTOAS__GLOBAL_TENSOR_DATA(v89);
  // pto: %83
  const int64_t v1054 = 1;
  // pto: %83
  const int64_t v1055 = 1;
  // pto: %83
  const int64_t v1056 = 1;
  // pto: %83
  int64_t v1057 = v92 * v30;
  // pto: %83
  int64_t v1058 = v1056 * v1057;
  // pto: %83
  pto::Shape<1, 1, 1, -1, 512> v1059 = pto::Shape<1, 1, 1, -1, 512>(v1054, v1055, v1056, v92, v33);
  // pto: %83
  pto::Stride<-1, -1, -1, -1, -1> v1060 = pto::Stride<-1, -1, -1, -1, -1>(v1055 * v1058, v1058, v1057, v30, v31);
  // pto: %83
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1061 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1053 + (v1052 + v95 * v30 + v40 * v31), v1059, v1060);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v1061, v1048);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  // pto: %t__tmp_v1096
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1062 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1096
  uint64_t v1063 = (uint64_t) v10;
  TASSIGN(v1062, v1063);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  RoundMode v1064 = RoundMode::CAST_ROUND;
  SaturationMode v1065 = SaturationMode::ON;
  TCVT(v1062, v452, v1064, v1065);
  // pto: %scaled8_inline1216__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1066 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %scaled8_inline1216__ssa_v0
  uint64_t v1067 = (uint64_t) v10;
  TASSIGN(v1066, v1067);
  pipe_barrier(PIPE_V);
  TROWEXPANDMUL(v1066, v1062, v825);
  // pto: %integer8_inline1157__ssa_v0
  Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1068 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %integer8_inline1157__ssa_v0
  uint64_t v1069 = (uint64_t) v10;
  TASSIGN(v1068, v1069);
  pipe_barrier(PIPE_V);
  RoundMode v1070 = RoundMode::CAST_RINT;
  SaturationMode v1071 = SaturationMode::ON;
  TCVT(v1068, v1066, v1070, v1071);
  // pto: %half8_inline1134__ssa_v0
  Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1072 = Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %half8_inline1134__ssa_v0
  uint64_t v1073 = (uint64_t) v10;
  TASSIGN(v1072, v1073);
  pipe_barrier(PIPE_V);
  RoundMode v1074 = RoundMode::CAST_ROUND;
  SaturationMode v1075 = SaturationMode::ON;
  TCVT(v1072, v1068, v1074, v1075);
  // pto: %result8_inline1099__ssa_v0
  Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1076 = Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %result8_inline1099__ssa_v0
  uint64_t v1077 = (uint64_t) v10;
  TASSIGN(v1076, v1077);
  pipe_barrier(PIPE_V);
  RoundMode v1078 = RoundMode::CAST_TRUNC;
  SaturationMode v1079 = SaturationMode::ON;
  TCVT(v1076, v1072, v1078, v1079);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v1076.SetValidShape(v92, v33);
  // pto: %85
  const int64_t v1080 = 0;
  // pto: %85
  __gm__ int8_t* v1081 = PTOAS__GLOBAL_TENSOR_DATA(v89);
  // pto: %85
  const int64_t v1082 = 1;
  // pto: %85
  const int64_t v1083 = 1;
  // pto: %85
  const int64_t v1084 = 1;
  // pto: %85
  int64_t v1085 = v92 * v30;
  // pto: %85
  int64_t v1086 = v1084 * v1085;
  // pto: %85
  pto::Shape<1, 1, 1, -1, 512> v1087 = pto::Shape<1, 1, 1, -1, 512>(v1082, v1083, v1084, v92, v33);
  // pto: %85
  pto::Stride<-1, -1, -1, -1, -1> v1088 = pto::Stride<-1, -1, -1, -1, -1>(v1083 * v1086, v1086, v1085, v30, v31);
  // pto: %85
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1089 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1081 + (v1080 + v95 * v30 + v41 * v31), v1087, v1088);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v1089, v1076);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  // pto: %t__tmp_v1098
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1090 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1098
  uint64_t v1091 = (uint64_t) v10;
  TASSIGN(v1090, v1091);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  RoundMode v1092 = RoundMode::CAST_ROUND;
  SaturationMode v1093 = SaturationMode::ON;
  TCVT(v1090, v496, v1092, v1093);
  // pto: %scaled9_inline1033__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1094 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %scaled9_inline1033__ssa_v0
  uint64_t v1095 = (uint64_t) v10;
  TASSIGN(v1094, v1095);
  pipe_barrier(PIPE_V);
  TROWEXPANDMUL(v1094, v1090, v825);
  // pto: %integer9_inline1135__ssa_v0
  Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1096 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %integer9_inline1135__ssa_v0
  uint64_t v1097 = (uint64_t) v10;
  TASSIGN(v1096, v1097);
  pipe_barrier(PIPE_V);
  RoundMode v1098 = RoundMode::CAST_RINT;
  SaturationMode v1099 = SaturationMode::ON;
  TCVT(v1096, v1094, v1098, v1099);
  // pto: %half9_inline1217__ssa_v0
  Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1100 = Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %half9_inline1217__ssa_v0
  uint64_t v1101 = (uint64_t) v10;
  TASSIGN(v1100, v1101);
  pipe_barrier(PIPE_V);
  RoundMode v1102 = RoundMode::CAST_ROUND;
  SaturationMode v1103 = SaturationMode::ON;
  TCVT(v1100, v1096, v1102, v1103);
  // pto: %result9_inline1061__ssa_v0
  Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1104 = Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %result9_inline1061__ssa_v0
  uint64_t v1105 = (uint64_t) v10;
  TASSIGN(v1104, v1105);
  pipe_barrier(PIPE_V);
  RoundMode v1106 = RoundMode::CAST_TRUNC;
  SaturationMode v1107 = SaturationMode::ON;
  TCVT(v1104, v1100, v1106, v1107);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v1104.SetValidShape(v92, v33);
  // pto: %87
  const int64_t v1108 = 0;
  // pto: %87
  __gm__ int8_t* v1109 = PTOAS__GLOBAL_TENSOR_DATA(v89);
  // pto: %87
  const int64_t v1110 = 1;
  // pto: %87
  const int64_t v1111 = 1;
  // pto: %87
  const int64_t v1112 = 1;
  // pto: %87
  int64_t v1113 = v92 * v30;
  // pto: %87
  int64_t v1114 = v1112 * v1113;
  // pto: %87
  pto::Shape<1, 1, 1, -1, 512> v1115 = pto::Shape<1, 1, 1, -1, 512>(v1110, v1111, v1112, v92, v33);
  // pto: %87
  pto::Stride<-1, -1, -1, -1, -1> v1116 = pto::Stride<-1, -1, -1, -1, -1>(v1111 * v1114, v1114, v1113, v30, v31);
  // pto: %87
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1117 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1109 + (v1108 + v95 * v30 + v42 * v31), v1115, v1116);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v1117, v1104);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  // pto: %t__tmp_v1100
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1118 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1100
  uint64_t v1119 = (uint64_t) v10;
  TASSIGN(v1118, v1119);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  RoundMode v1120 = RoundMode::CAST_ROUND;
  SaturationMode v1121 = SaturationMode::ON;
  TCVT(v1118, v540, v1120, v1121);
  // pto: %scaled10_inline1219__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1122 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %scaled10_inline1219__ssa_v0
  uint64_t v1123 = (uint64_t) v10;
  TASSIGN(v1122, v1123);
  pipe_barrier(PIPE_V);
  TROWEXPANDMUL(v1122, v1118, v825);
  // pto: %integer10_inline1025__ssa_v0
  Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1124 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %integer10_inline1025__ssa_v0
  uint64_t v1125 = (uint64_t) v10;
  TASSIGN(v1124, v1125);
  pipe_barrier(PIPE_V);
  RoundMode v1126 = RoundMode::CAST_RINT;
  SaturationMode v1127 = SaturationMode::ON;
  TCVT(v1124, v1122, v1126, v1127);
  // pto: %half10_inline1221__ssa_v0
  Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1128 = Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %half10_inline1221__ssa_v0
  uint64_t v1129 = (uint64_t) v10;
  TASSIGN(v1128, v1129);
  pipe_barrier(PIPE_V);
  RoundMode v1130 = RoundMode::CAST_ROUND;
  SaturationMode v1131 = SaturationMode::ON;
  TCVT(v1128, v1124, v1130, v1131);
  // pto: %result10_inline1248__ssa_v0
  Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1132 = Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %result10_inline1248__ssa_v0
  uint64_t v1133 = (uint64_t) v10;
  TASSIGN(v1132, v1133);
  pipe_barrier(PIPE_V);
  RoundMode v1134 = RoundMode::CAST_TRUNC;
  SaturationMode v1135 = SaturationMode::ON;
  TCVT(v1132, v1128, v1134, v1135);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v1132.SetValidShape(v92, v33);
  // pto: %89
  const int64_t v1136 = 0;
  // pto: %89
  __gm__ int8_t* v1137 = PTOAS__GLOBAL_TENSOR_DATA(v89);
  // pto: %89
  const int64_t v1138 = 1;
  // pto: %89
  const int64_t v1139 = 1;
  // pto: %89
  const int64_t v1140 = 1;
  // pto: %89
  int64_t v1141 = v92 * v30;
  // pto: %89
  int64_t v1142 = v1140 * v1141;
  // pto: %89
  pto::Shape<1, 1, 1, -1, 512> v1143 = pto::Shape<1, 1, 1, -1, 512>(v1138, v1139, v1140, v92, v33);
  // pto: %89
  pto::Stride<-1, -1, -1, -1, -1> v1144 = pto::Stride<-1, -1, -1, -1, -1>(v1139 * v1142, v1142, v1141, v30, v31);
  // pto: %89
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1145 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1137 + (v1136 + v95 * v30 + v43 * v31), v1143, v1144);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v1145, v1132);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  // pto: %t__tmp_v1102
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1146 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1102
  uint64_t v1147 = (uint64_t) v10;
  TASSIGN(v1146, v1147);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  RoundMode v1148 = RoundMode::CAST_ROUND;
  SaturationMode v1149 = SaturationMode::ON;
  TCVT(v1146, v584, v1148, v1149);
  // pto: %scaled11_inline1222__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1150 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %scaled11_inline1222__ssa_v0
  uint64_t v1151 = (uint64_t) v10;
  TASSIGN(v1150, v1151);
  pipe_barrier(PIPE_V);
  TROWEXPANDMUL(v1150, v1146, v825);
  // pto: %integer11_inline1084__ssa_v0
  Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1152 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %integer11_inline1084__ssa_v0
  uint64_t v1153 = (uint64_t) v10;
  TASSIGN(v1152, v1153);
  pipe_barrier(PIPE_V);
  RoundMode v1154 = RoundMode::CAST_RINT;
  SaturationMode v1155 = SaturationMode::ON;
  TCVT(v1152, v1150, v1154, v1155);
  // pto: %half11_inline1031__ssa_v0
  Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1156 = Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %half11_inline1031__ssa_v0
  uint64_t v1157 = (uint64_t) v10;
  TASSIGN(v1156, v1157);
  pipe_barrier(PIPE_V);
  RoundMode v1158 = RoundMode::CAST_ROUND;
  SaturationMode v1159 = SaturationMode::ON;
  TCVT(v1156, v1152, v1158, v1159);
  // pto: %result11_inline1224__ssa_v0
  Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1160 = Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %result11_inline1224__ssa_v0
  uint64_t v1161 = (uint64_t) v10;
  TASSIGN(v1160, v1161);
  pipe_barrier(PIPE_V);
  RoundMode v1162 = RoundMode::CAST_TRUNC;
  SaturationMode v1163 = SaturationMode::ON;
  TCVT(v1160, v1156, v1162, v1163);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v1160.SetValidShape(v92, v33);
  // pto: %91
  const int64_t v1164 = 0;
  // pto: %91
  __gm__ int8_t* v1165 = PTOAS__GLOBAL_TENSOR_DATA(v89);
  // pto: %91
  const int64_t v1166 = 1;
  // pto: %91
  const int64_t v1167 = 1;
  // pto: %91
  const int64_t v1168 = 1;
  // pto: %91
  int64_t v1169 = v92 * v30;
  // pto: %91
  int64_t v1170 = v1168 * v1169;
  // pto: %91
  pto::Shape<1, 1, 1, -1, 512> v1171 = pto::Shape<1, 1, 1, -1, 512>(v1166, v1167, v1168, v92, v33);
  // pto: %91
  pto::Stride<-1, -1, -1, -1, -1> v1172 = pto::Stride<-1, -1, -1, -1, -1>(v1167 * v1170, v1170, v1169, v30, v31);
  // pto: %91
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1173 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1165 + (v1164 + v95 * v30 + v44 * v31), v1171, v1172);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v1173, v1160);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  // pto: %t__tmp_v1104
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1174 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1104
  uint64_t v1175 = (uint64_t) v10;
  TASSIGN(v1174, v1175);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  RoundMode v1176 = RoundMode::CAST_ROUND;
  SaturationMode v1177 = SaturationMode::ON;
  TCVT(v1174, v628, v1176, v1177);
  // pto: %scaled12_inline1225__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1178 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %scaled12_inline1225__ssa_v0
  uint64_t v1179 = (uint64_t) v10;
  TASSIGN(v1178, v1179);
  pipe_barrier(PIPE_V);
  TROWEXPANDMUL(v1178, v1174, v825);
  // pto: %integer12_inline1228__ssa_v0
  Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1180 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %integer12_inline1228__ssa_v0
  uint64_t v1181 = (uint64_t) v10;
  TASSIGN(v1180, v1181);
  pipe_barrier(PIPE_V);
  RoundMode v1182 = RoundMode::CAST_RINT;
  SaturationMode v1183 = SaturationMode::ON;
  TCVT(v1180, v1178, v1182, v1183);
  // pto: %half12_inline1193__ssa_v0
  Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1184 = Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %half12_inline1193__ssa_v0
  uint64_t v1185 = (uint64_t) v10;
  TASSIGN(v1184, v1185);
  pipe_barrier(PIPE_V);
  RoundMode v1186 = RoundMode::CAST_ROUND;
  SaturationMode v1187 = SaturationMode::ON;
  TCVT(v1184, v1180, v1186, v1187);
  // pto: %result12_inline1229__ssa_v0
  Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1188 = Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %result12_inline1229__ssa_v0
  uint64_t v1189 = (uint64_t) v10;
  TASSIGN(v1188, v1189);
  pipe_barrier(PIPE_V);
  RoundMode v1190 = RoundMode::CAST_TRUNC;
  SaturationMode v1191 = SaturationMode::ON;
  TCVT(v1188, v1184, v1190, v1191);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v1188.SetValidShape(v92, v33);
  // pto: %93
  const int64_t v1192 = 0;
  // pto: %93
  __gm__ int8_t* v1193 = PTOAS__GLOBAL_TENSOR_DATA(v89);
  // pto: %93
  const int64_t v1194 = 1;
  // pto: %93
  const int64_t v1195 = 1;
  // pto: %93
  const int64_t v1196 = 1;
  // pto: %93
  int64_t v1197 = v92 * v30;
  // pto: %93
  int64_t v1198 = v1196 * v1197;
  // pto: %93
  pto::Shape<1, 1, 1, -1, 512> v1199 = pto::Shape<1, 1, 1, -1, 512>(v1194, v1195, v1196, v92, v33);
  // pto: %93
  pto::Stride<-1, -1, -1, -1, -1> v1200 = pto::Stride<-1, -1, -1, -1, -1>(v1195 * v1198, v1198, v1197, v30, v31);
  // pto: %93
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1201 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1193 + (v1192 + v95 * v30 + v45 * v31), v1199, v1200);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v1201, v1188);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  // pto: %t__tmp_v1106
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1202 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1106
  uint64_t v1203 = (uint64_t) v10;
  TASSIGN(v1202, v1203);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  RoundMode v1204 = RoundMode::CAST_ROUND;
  SaturationMode v1205 = SaturationMode::ON;
  TCVT(v1202, v672, v1204, v1205);
  // pto: %scaled13_inline1119__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1206 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %scaled13_inline1119__ssa_v0
  uint64_t v1207 = (uint64_t) v10;
  TASSIGN(v1206, v1207);
  pipe_barrier(PIPE_V);
  TROWEXPANDMUL(v1206, v1202, v825);
  // pto: %integer13_inline1054__ssa_v0
  Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1208 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %integer13_inline1054__ssa_v0
  uint64_t v1209 = (uint64_t) v10;
  TASSIGN(v1208, v1209);
  pipe_barrier(PIPE_V);
  RoundMode v1210 = RoundMode::CAST_RINT;
  SaturationMode v1211 = SaturationMode::ON;
  TCVT(v1208, v1206, v1210, v1211);
  // pto: %half13_inline1195__ssa_v0
  Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1212 = Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %half13_inline1195__ssa_v0
  uint64_t v1213 = (uint64_t) v10;
  TASSIGN(v1212, v1213);
  pipe_barrier(PIPE_V);
  RoundMode v1214 = RoundMode::CAST_ROUND;
  SaturationMode v1215 = SaturationMode::ON;
  TCVT(v1212, v1208, v1214, v1215);
  // pto: %result13_inline1230__ssa_v0
  Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1216 = Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %result13_inline1230__ssa_v0
  uint64_t v1217 = (uint64_t) v10;
  TASSIGN(v1216, v1217);
  pipe_barrier(PIPE_V);
  RoundMode v1218 = RoundMode::CAST_TRUNC;
  SaturationMode v1219 = SaturationMode::ON;
  TCVT(v1216, v1212, v1218, v1219);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v1216.SetValidShape(v92, v33);
  // pto: %95
  const int64_t v1220 = 0;
  // pto: %95
  __gm__ int8_t* v1221 = PTOAS__GLOBAL_TENSOR_DATA(v89);
  // pto: %95
  const int64_t v1222 = 1;
  // pto: %95
  const int64_t v1223 = 1;
  // pto: %95
  const int64_t v1224 = 1;
  // pto: %95
  int64_t v1225 = v92 * v30;
  // pto: %95
  int64_t v1226 = v1224 * v1225;
  // pto: %95
  pto::Shape<1, 1, 1, -1, 512> v1227 = pto::Shape<1, 1, 1, -1, 512>(v1222, v1223, v1224, v92, v33);
  // pto: %95
  pto::Stride<-1, -1, -1, -1, -1> v1228 = pto::Stride<-1, -1, -1, -1, -1>(v1223 * v1226, v1226, v1225, v30, v31);
  // pto: %95
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1229 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1221 + (v1220 + v95 * v30 + v46 * v31), v1227, v1228);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v1229, v1216);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  // pto: %t__tmp_v1108
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1230 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1108
  uint64_t v1231 = (uint64_t) v10;
  TASSIGN(v1230, v1231);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  RoundMode v1232 = RoundMode::CAST_ROUND;
  SaturationMode v1233 = SaturationMode::ON;
  TCVT(v1230, v716, v1232, v1233);
  // pto: %scaled14_inline1231__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1234 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %scaled14_inline1231__ssa_v0
  uint64_t v1235 = (uint64_t) v10;
  TASSIGN(v1234, v1235);
  pipe_barrier(PIPE_V);
  TROWEXPANDMUL(v1234, v1230, v825);
  // pto: %integer14_inline1232__ssa_v0
  Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1236 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %integer14_inline1232__ssa_v0
  uint64_t v1237 = (uint64_t) v10;
  TASSIGN(v1236, v1237);
  pipe_barrier(PIPE_V);
  RoundMode v1238 = RoundMode::CAST_RINT;
  SaturationMode v1239 = SaturationMode::ON;
  TCVT(v1236, v1234, v1238, v1239);
  // pto: %half14_inline1017__ssa_v0
  Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1240 = Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %half14_inline1017__ssa_v0
  uint64_t v1241 = (uint64_t) v10;
  TASSIGN(v1240, v1241);
  pipe_barrier(PIPE_V);
  RoundMode v1242 = RoundMode::CAST_ROUND;
  SaturationMode v1243 = SaturationMode::ON;
  TCVT(v1240, v1236, v1242, v1243);
  // pto: %result14_inline1149__ssa_v0
  Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1244 = Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %result14_inline1149__ssa_v0
  uint64_t v1245 = (uint64_t) v10;
  TASSIGN(v1244, v1245);
  pipe_barrier(PIPE_V);
  RoundMode v1246 = RoundMode::CAST_TRUNC;
  SaturationMode v1247 = SaturationMode::ON;
  TCVT(v1244, v1240, v1246, v1247);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v1244.SetValidShape(v92, v33);
  // pto: %97
  const int64_t v1248 = 0;
  // pto: %97
  __gm__ int8_t* v1249 = PTOAS__GLOBAL_TENSOR_DATA(v89);
  // pto: %97
  const int64_t v1250 = 1;
  // pto: %97
  const int64_t v1251 = 1;
  // pto: %97
  const int64_t v1252 = 1;
  // pto: %97
  int64_t v1253 = v92 * v30;
  // pto: %97
  int64_t v1254 = v1252 * v1253;
  // pto: %97
  pto::Shape<1, 1, 1, -1, 512> v1255 = pto::Shape<1, 1, 1, -1, 512>(v1250, v1251, v1252, v92, v33);
  // pto: %97
  pto::Stride<-1, -1, -1, -1, -1> v1256 = pto::Stride<-1, -1, -1, -1, -1>(v1251 * v1254, v1254, v1253, v30, v31);
  // pto: %97
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1257 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1249 + (v1248 + v95 * v30 + v47 * v31), v1255, v1256);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v1257, v1244);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  // pto: %t__tmp_v1110
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1258 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %t__tmp_v1110
  uint64_t v1259 = (uint64_t) v10;
  TASSIGN(v1258, v1259);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  RoundMode v1260 = RoundMode::CAST_ROUND;
  SaturationMode v1261 = SaturationMode::ON;
  TCVT(v1258, v760, v1260, v1261);
  // pto: %scaled15_inline1233__ssa_v0
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1262 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %scaled15_inline1233__ssa_v0
  uint64_t v1263 = (uint64_t) v10;
  TASSIGN(v1262, v1263);
  pipe_barrier(PIPE_V);
  TROWEXPANDMUL(v1262, v1258, v825);
  // pto: %integer15_inline1158__ssa_v0
  Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1264 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %integer15_inline1158__ssa_v0
  uint64_t v1265 = (uint64_t) v10;
  TASSIGN(v1264, v1265);
  pipe_barrier(PIPE_V);
  RoundMode v1266 = RoundMode::CAST_RINT;
  SaturationMode v1267 = SaturationMode::ON;
  TCVT(v1264, v1262, v1266, v1267);
  // pto: %half15_inline1198__ssa_v0
  Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1268 = Tile<TileType::Vec, half, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %half15_inline1198__ssa_v0
  uint64_t v1269 = (uint64_t) v10;
  TASSIGN(v1268, v1269);
  pipe_barrier(PIPE_V);
  RoundMode v1270 = RoundMode::CAST_ROUND;
  SaturationMode v1271 = SaturationMode::ON;
  TCVT(v1268, v1264, v1270, v1271);
  // pto: %result15_inline1235__ssa_v0
  Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1272 = Tile<TileType::Vec, int8_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v92, v33);
  // pto: %result15_inline1235__ssa_v0
  uint64_t v1273 = (uint64_t) v10;
  TASSIGN(v1272, v1273);
  pipe_barrier(PIPE_V);
  RoundMode v1274 = RoundMode::CAST_TRUNC;
  SaturationMode v1275 = SaturationMode::ON;
  TCVT(v1272, v1268, v1274, v1275);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  v1272.SetValidShape(v92, v33);
  // pto: %99
  const int64_t v1276 = 0;
  // pto: %99
  __gm__ int8_t* v1277 = PTOAS__GLOBAL_TENSOR_DATA(v89);
  // pto: %99
  const int64_t v1278 = 1;
  // pto: %99
  const int64_t v1279 = 1;
  // pto: %99
  const int64_t v1280 = 1;
  // pto: %99
  int64_t v1281 = v92 * v30;
  // pto: %99
  int64_t v1282 = v1280 * v1281;
  // pto: %99
  pto::Shape<1, 1, 1, -1, 512> v1283 = pto::Shape<1, 1, 1, -1, 512>(v1278, v1279, v1280, v92, v33);
  // pto: %99
  pto::Stride<-1, -1, -1, -1, -1> v1284 = pto::Stride<-1, -1, -1, -1, -1>(v1279 * v1282, v1282, v1281, v30, v31);
  // pto: %99
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1285 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1277 + (v1276 + v95 * v30 + v48 * v31), v1283, v1284);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v1285, v1272);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}