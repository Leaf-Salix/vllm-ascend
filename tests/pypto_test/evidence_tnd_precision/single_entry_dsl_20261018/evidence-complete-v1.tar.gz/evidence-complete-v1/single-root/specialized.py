# pypto.program: _jit__full_csa_tnd
import pypto.language as pl

B_DYN = pl.dynamic("B_DYN")
CMP_BLOCK_NUM_DYN = pl.dynamic("CMP_BLOCK_NUM_DYN")
COMPRESSED_ROWS_DYN = pl.dynamic("COMPRESSED_ROWS_DYN")
COMPRESSED_TABLE_COLUMNS_DYN = pl.dynamic("COMPRESSED_TABLE_COLUMNS_DYN")
CSA_COMPACT_REQUESTS = pl.dynamic("CSA_COMPACT_REQUESTS")
DECODE_CSA_C4_B_DYN = pl.dynamic("DECODE_CSA_C4_B_DYN")
DECODE_IDX_C4_B_DYN = pl.dynamic("DECODE_IDX_C4_B_DYN")
HC_PAD_ROWS_DYN = pl.dynamic("HC_PAD_ROWS_DYN")
IDX_NATIVE_CACHE_BLOCK_NUM_DYN = pl.dynamic("IDX_NATIVE_CACHE_BLOCK_NUM_DYN")
INDEXER_PAGE_BYTES_DYN = pl.dynamic("INDEXER_PAGE_BYTES_DYN")
INDEXER_ROWS_DYN = pl.dynamic("INDEXER_ROWS_DYN")
INDEXER_TABLE_COLUMNS_DYN = pl.dynamic("INDEXER_TABLE_COLUMNS_DYN")
INNER_STATE_BLOCK_NUM_DYN = pl.dynamic("INNER_STATE_BLOCK_NUM_DYN")
INNER_STATE_PAGE_ELEMENTS_DYN = pl.dynamic("INNER_STATE_PAGE_ELEMENTS_DYN")
INNER_STATE_TABLE_COLUMNS_DYN = pl.dynamic("INNER_STATE_TABLE_COLUMNS_DYN")
LINEAR_ROWS_DYN = pl.dynamic("LINEAR_ROWS_DYN")
MAIN_STATE_BLOCK_NUM_DYN = pl.dynamic("MAIN_STATE_BLOCK_NUM_DYN")
ORIGINAL_TABLE_COLUMNS_DYN = pl.dynamic("ORIGINAL_TABLE_COLUMNS_DYN")
ORI_BLOCK_NUM_DYN = pl.dynamic("ORI_BLOCK_NUM_DYN")
QKV_QPROJ_MM_T_DYN = pl.dynamic("QKV_QPROJ_MM_T_DYN")
QUERY_BOUNDS_DYN = pl.dynamic("QUERY_BOUNDS_DYN")
STATE_PAGE_ELEMENTS_DYN = pl.dynamic("STATE_PAGE_ELEMENTS_DYN")
STATE_TABLE_COLUMNS_DYN = pl.dynamic("STATE_TABLE_COLUMNS_DYN")
T_DYN = pl.dynamic("T_DYN")

@pl.program
class _jit__full_csa_tnd:
    @pl.function(type=pl.FunctionType.Inline)
    def hc_post_block(self, x_block: pl.Tensor[[1, 4096], pl.BF16], residual_flat: pl.Tensor[[T_DYN, 16384], pl.BF16], post: pl.Tensor[[T_DYN, 4], pl.FP32], comb: pl.Tensor[[T_DYN, 16], pl.FP32], y_flat: pl.Tensor[[T_DYN, 16384], pl.BF16], t0: pl.Scalar[pl.INDEX], n0: pl.Scalar[pl.INDEX], valid_rows: pl.Scalar[pl.INDEX]) -> pl.Tensor[[T_DYN, 16384], pl.BF16]:
        x_f32: pl.Tensor[[1, 4096], pl.FP32] = pl.tensor.cast(x_block, target_type=pl.FP32, mode='round')
        res_0: pl.Tensor[[1, 4096], pl.FP32, pl.TensorView(valid_shape=[valid_rows, pl.min(pl.max(pl.const(16384, pl.INDEX) - n0, pl.const(0, pl.INDEX)), pl.const(4096, pl.INDEX))], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.cast(pl.tensor.slice(residual_flat, [1, 4096], [t0, n0], [valid_rows, 4096], clamp=True), target_type=pl.FP32, mode='round')
        res_1: pl.Tensor[[1, 4096], pl.FP32, pl.TensorView(valid_shape=[valid_rows, pl.min(pl.max(pl.const(12288, pl.INDEX) - n0, pl.const(0, pl.INDEX)), pl.const(4096, pl.INDEX))], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.cast(pl.tensor.slice(residual_flat, [1, 4096], [t0, 4096 + n0], [valid_rows, 4096], clamp=True), target_type=pl.FP32, mode='round')
        res_2: pl.Tensor[[1, 4096], pl.FP32, pl.TensorView(valid_shape=[valid_rows, pl.min(pl.max(pl.const(8192, pl.INDEX) - n0, pl.const(0, pl.INDEX)), pl.const(4096, pl.INDEX))], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.cast(pl.tensor.slice(residual_flat, [1, 4096], [t0, 8192 + n0], [valid_rows, 4096], clamp=True), target_type=pl.FP32, mode='round')
        res_3: pl.Tensor[[1, 4096], pl.FP32, pl.TensorView(valid_shape=[valid_rows, pl.min(pl.max(pl.const(4096, pl.INDEX) - n0, pl.const(0, pl.INDEX)), pl.const(4096, pl.INDEX))], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.cast(pl.tensor.slice(residual_flat, [1, 4096], [t0, 12288 + n0], [valid_rows, 4096], clamp=True), target_type=pl.FP32, mode='round')
        for out_h in pl.unroll(4):
            post_scalar: pl.Scalar[pl.FP32] = pl.tensor.read(post, [t0, out_h])
            single_y: pl.Tensor[[1, 4096], pl.FP32] = pl.tensor.muls(x_f32, post_scalar)
            comb_scalar_0: pl.Scalar[pl.FP32] = pl.tensor.read(comb, [t0, out_h])
            single_weighted_0: pl.Tensor[[1, 4096], pl.FP32, pl.TensorView(valid_shape=[valid_rows, pl.min(pl.max(pl.const(16384, pl.INDEX) - n0, pl.const(0, pl.INDEX)), pl.const(4096, pl.INDEX))], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.muls(res_0, comb_scalar_0)
            single_y_v1: pl.Tensor[[1, 4096], pl.FP32] = pl.tensor.add(single_y, single_weighted_0)
            comb_scalar_1: pl.Scalar[pl.FP32] = pl.tensor.read(comb, [t0, 4 + out_h])
            single_weighted_1: pl.Tensor[[1, 4096], pl.FP32, pl.TensorView(valid_shape=[valid_rows, pl.min(pl.max(pl.const(12288, pl.INDEX) - n0, pl.const(0, pl.INDEX)), pl.const(4096, pl.INDEX))], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.muls(res_1, comb_scalar_1)
            single_y_v2: pl.Tensor[[1, 4096], pl.FP32] = pl.tensor.add(single_y_v1, single_weighted_1)
            comb_scalar_2: pl.Scalar[pl.FP32] = pl.tensor.read(comb, [t0, 8 + out_h])
            single_weighted_2: pl.Tensor[[1, 4096], pl.FP32, pl.TensorView(valid_shape=[valid_rows, pl.min(pl.max(pl.const(8192, pl.INDEX) - n0, pl.const(0, pl.INDEX)), pl.const(4096, pl.INDEX))], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.muls(res_2, comb_scalar_2)
            single_y_v3: pl.Tensor[[1, 4096], pl.FP32] = pl.tensor.add(single_y_v2, single_weighted_2)
            comb_scalar_3: pl.Scalar[pl.FP32] = pl.tensor.read(comb, [t0, 12 + out_h])
            single_weighted_3: pl.Tensor[[1, 4096], pl.FP32, pl.TensorView(valid_shape=[valid_rows, pl.min(pl.max(pl.const(4096, pl.INDEX) - n0, pl.const(0, pl.INDEX)), pl.const(4096, pl.INDEX))], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.muls(res_3, comb_scalar_3)
            single_y_v4: pl.Tensor[[1, 4096], pl.FP32] = pl.tensor.add(single_y_v3, single_weighted_3)
            single_result: pl.Tensor[[1, 4096], pl.BF16] = pl.tensor.cast(single_y_v4, target_type=pl.BF16, mode='rint')
            y_flat: pl.Tensor[[T_DYN, 16384], pl.BF16] = pl.tensor.assemble(y_flat, pl.tensor.set_validshape(single_result, valid_rows, 4096), [t0, out_h * 4096 + n0])
        return y_flat
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def _hc_post(self, x: pl.Tensor[[T_DYN, 4096], pl.BF16], residual: pl.Tensor[[T_DYN, 4, 4096], pl.BF16], post: pl.Tensor[[T_DYN, 4], pl.FP32], comb: pl.Tensor[[T_DYN, 16], pl.FP32], y: pl.Tensor[[T_DYN, 4, 4096], pl.BF16]) -> pl.Tensor[[T_DYN, 4, 4096], pl.BF16]:
        t_dim: pl.Scalar[pl.INDEX] = pl.tensor.dim(x, 0)
        residual_flat: pl.Tensor[[t_dim, 16384], pl.BF16] = pl.tensor.reshape(residual, [t_dim, 16384])
        y_flat: pl.Tensor[[t_dim, 16384], pl.BF16] = pl.tensor.reshape(y, [t_dim, 16384])
        token_tiles: pl.Scalar[pl.INDEX] = (t_dim + 4 - 1) // 4
        for token_block in pl.spmd(token_tiles, name_hint="hc_post_spmd"):
            t0: pl.Scalar[pl.INDEX] = token_block * 4
            for t in pl.pipeline(t0, t0 + 4, stage=2):
                if t < t_dim:
                    x_block: pl.Tensor[[1, 4096], pl.BF16] = pl.tensor.slice(x, [1, 4096], [t, 0])
                    y_flat: pl.Tensor[[t_dim, 16384], pl.BF16] = self.hc_post_block(x_block, residual_flat, post, comb, y_flat, t, 0, 1)
        return y
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def _hcpre_linear_dsl(self, flat: pl.Tensor[[T_DYN, 16384], pl.FP32], weight: pl.Tensor[[24, 16384], pl.FP32], partials: pl.Tensor[[LINEAR_ROWS_DYN, 32], pl.FP32]) -> pl.Tensor[[LINEAR_ROWS_DYN, 32], pl.FP32]:
        tokens: pl.Scalar[pl.INDEX] = pl.tensor.dim(flat, 0)
        padded_tokens: pl.Scalar[pl.INDEX] = pl.tensor.dim(partials, 0) // 22
        rounded_weight: pl.Tensor[[16384, 32], pl.FP32] = pl.tensor.create([16384, 32], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        for block in pl.spmd(512, name_hint="hcpre_hf32_weight_spmd", allow_early_resolve=True):
            raw: pl.Tile[[32, 32], pl.FP32, pl.TileView(valid_shape=[24, 32])] = pl.tile.load(weight, [0, block * 32], [32, 32], [24, 32])
            transposed: pl.Tile[[32, 32], pl.FP32] = pl.tile.transpose(raw, 0, 1)
            bits: pl.Tile[[32, 32], pl.INT32] = pl.tile.reinterpret_view(transposed, dtype=pl.INT32)
            converted: pl.Tile[[32, 32], pl.FP32, pl.Mem.Vec] = pl.tile.reinterpret_view(pl.tile.and_(pl.tile.adds(bits, pl.const(2048, pl.INT32)), pl.tile.full([32, 32], dtype=pl.INT32, value=-4096)), dtype=pl.FP32)
            for pad_column in pl.range(24, 32):
                for pad_k in pl.range(32):
                    pl.tile.write(converted, [pad_k, pad_column], 0.0)
            pl.tile.store(pl.tile.set_validshape(converted, 32, 32), [block * 32, 0], rounded_weight)
        for unit in pl.spmd(22 * padded_tokens, name_hint="hcpre_hf32_exact8_spmd", allow_early_resolve=True):
            split: pl.Scalar[pl.INDEX] = unit // padded_tokens
            row: pl.Scalar[pl.INDEX] = unit % padded_tokens
            zero: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.full([1, 32], dtype=pl.FP32, value=0.0)
            one: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.full([1, 32], dtype=pl.FP32, value=1.0)
            sel_tmp: pl.Tile[[1, 16], pl.UINT32] = pl.tile.create([1, 16], dtype=pl.UINT32)
            accumulator: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.full([1, 32], dtype=pl.FP32, value=0.0)
            if row < tokens:
                count: pl.Scalar[pl.INDEX] = pl.min(768, 16384 - split * 768) // 8
                for kb in pl.range(count):
                    k: pl.Scalar[pl.INDEX] = split * 768 + kb * 8
                    weight0: pl.Tile[[1, 32], pl.FP32] = pl.tile.load(rounded_weight, [k + 0, 0], [1, 32], [1, 32])
                    input0: pl.Scalar[pl.FP32] = pl.tensor.read(flat, [row, k + 0])
                    product0: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.muls(weight0, input0)
                    weight1: pl.Tile[[1, 32], pl.FP32] = pl.tile.load(rounded_weight, [k + 1, 0], [1, 32], [1, 32])
                    input1: pl.Scalar[pl.FP32] = pl.tensor.read(flat, [row, k + 1])
                    product1: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.muls(weight1, input1)
                    weight2: pl.Tile[[1, 32], pl.FP32] = pl.tile.load(rounded_weight, [k + 2, 0], [1, 32], [1, 32])
                    input2: pl.Scalar[pl.FP32] = pl.tensor.read(flat, [row, k + 2])
                    product2: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.muls(weight2, input2)
                    weight3: pl.Tile[[1, 32], pl.FP32] = pl.tile.load(rounded_weight, [k + 3, 0], [1, 32], [1, 32])
                    input3: pl.Scalar[pl.FP32] = pl.tensor.read(flat, [row, k + 3])
                    product3: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.muls(weight3, input3)
                    weight4: pl.Tile[[1, 32], pl.FP32] = pl.tile.load(rounded_weight, [k + 4, 0], [1, 32], [1, 32])
                    input4: pl.Scalar[pl.FP32] = pl.tensor.read(flat, [row, k + 4])
                    product4: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.muls(weight4, input4)
                    weight5: pl.Tile[[1, 32], pl.FP32] = pl.tile.load(rounded_weight, [k + 5, 0], [1, 32], [1, 32])
                    input5: pl.Scalar[pl.FP32] = pl.tensor.read(flat, [row, k + 5])
                    product5: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.muls(weight5, input5)
                    weight6: pl.Tile[[1, 32], pl.FP32] = pl.tile.load(rounded_weight, [k + 6, 0], [1, 32], [1, 32])
                    input6: pl.Scalar[pl.FP32] = pl.tensor.read(flat, [row, k + 6])
                    product6: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.muls(weight6, input6)
                    weight7: pl.Tile[[1, 32], pl.FP32] = pl.tile.load(rounded_weight, [k + 7, 0], [1, 32], [1, 32])
                    input7: pl.Scalar[pl.FP32] = pl.tensor.read(flat, [row, k + 7])
                    product7: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.muls(weight7, input7)
                    e0_0_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(product0, accumulator)
                    e0_0_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e0_0_hi, product0)
                    e0_0_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(product0, pl.tile.sub(e0_0_hi, e0_0_v)), pl.tile.sub(accumulator, e0_0_v))
                    e1_0_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(product1, e0_0_lo)
                    e1_0_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e1_0_hi, product1)
                    e1_0_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(product1, pl.tile.sub(e1_0_hi, e1_0_v)), pl.tile.sub(e0_0_lo, e1_0_v))
                    e1_1_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e1_0_hi, e0_0_hi)
                    e1_1_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e1_1_hi, e1_0_hi)
                    e1_1_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e1_0_hi, pl.tile.sub(e1_1_hi, e1_1_v)), pl.tile.sub(e0_0_hi, e1_1_v))
                    e2_0_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(product2, e1_0_lo)
                    e2_0_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e2_0_hi, product2)
                    e2_0_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(product2, pl.tile.sub(e2_0_hi, e2_0_v)), pl.tile.sub(e1_0_lo, e2_0_v))
                    e2_1_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e2_0_hi, e1_1_lo)
                    e2_1_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e2_1_hi, e2_0_hi)
                    e2_1_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e2_0_hi, pl.tile.sub(e2_1_hi, e2_1_v)), pl.tile.sub(e1_1_lo, e2_1_v))
                    e2_2_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e2_1_hi, e1_1_hi)
                    e2_2_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e2_2_hi, e2_1_hi)
                    e2_2_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e2_1_hi, pl.tile.sub(e2_2_hi, e2_2_v)), pl.tile.sub(e1_1_hi, e2_2_v))
                    e3_0_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(product3, e2_0_lo)
                    e3_0_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e3_0_hi, product3)
                    e3_0_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(product3, pl.tile.sub(e3_0_hi, e3_0_v)), pl.tile.sub(e2_0_lo, e3_0_v))
                    e3_1_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e3_0_hi, e2_1_lo)
                    e3_1_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e3_1_hi, e3_0_hi)
                    e3_1_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e3_0_hi, pl.tile.sub(e3_1_hi, e3_1_v)), pl.tile.sub(e2_1_lo, e3_1_v))
                    e3_2_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e3_1_hi, e2_2_lo)
                    e3_2_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e3_2_hi, e3_1_hi)
                    e3_2_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e3_1_hi, pl.tile.sub(e3_2_hi, e3_2_v)), pl.tile.sub(e2_2_lo, e3_2_v))
                    e3_3_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e3_2_hi, e2_2_hi)
                    e3_3_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e3_3_hi, e3_2_hi)
                    e3_3_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e3_2_hi, pl.tile.sub(e3_3_hi, e3_3_v)), pl.tile.sub(e2_2_hi, e3_3_v))
                    e4_0_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(product4, e3_0_lo)
                    e4_0_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e4_0_hi, product4)
                    e4_0_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(product4, pl.tile.sub(e4_0_hi, e4_0_v)), pl.tile.sub(e3_0_lo, e4_0_v))
                    e4_1_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e4_0_hi, e3_1_lo)
                    e4_1_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e4_1_hi, e4_0_hi)
                    e4_1_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e4_0_hi, pl.tile.sub(e4_1_hi, e4_1_v)), pl.tile.sub(e3_1_lo, e4_1_v))
                    e4_2_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e4_1_hi, e3_2_lo)
                    e4_2_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e4_2_hi, e4_1_hi)
                    e4_2_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e4_1_hi, pl.tile.sub(e4_2_hi, e4_2_v)), pl.tile.sub(e3_2_lo, e4_2_v))
                    e4_3_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e4_2_hi, e3_3_lo)
                    e4_3_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e4_3_hi, e4_2_hi)
                    e4_3_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e4_2_hi, pl.tile.sub(e4_3_hi, e4_3_v)), pl.tile.sub(e3_3_lo, e4_3_v))
                    e4_4_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e4_3_hi, e3_3_hi)
                    e4_4_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e4_4_hi, e4_3_hi)
                    e4_4_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e4_3_hi, pl.tile.sub(e4_4_hi, e4_4_v)), pl.tile.sub(e3_3_hi, e4_4_v))
                    e5_0_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(product5, e4_0_lo)
                    e5_0_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e5_0_hi, product5)
                    e5_0_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(product5, pl.tile.sub(e5_0_hi, e5_0_v)), pl.tile.sub(e4_0_lo, e5_0_v))
                    e5_1_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e5_0_hi, e4_1_lo)
                    e5_1_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e5_1_hi, e5_0_hi)
                    e5_1_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e5_0_hi, pl.tile.sub(e5_1_hi, e5_1_v)), pl.tile.sub(e4_1_lo, e5_1_v))
                    e5_2_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e5_1_hi, e4_2_lo)
                    e5_2_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e5_2_hi, e5_1_hi)
                    e5_2_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e5_1_hi, pl.tile.sub(e5_2_hi, e5_2_v)), pl.tile.sub(e4_2_lo, e5_2_v))
                    e5_3_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e5_2_hi, e4_3_lo)
                    e5_3_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e5_3_hi, e5_2_hi)
                    e5_3_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e5_2_hi, pl.tile.sub(e5_3_hi, e5_3_v)), pl.tile.sub(e4_3_lo, e5_3_v))
                    e5_4_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e5_3_hi, e4_4_lo)
                    e5_4_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e5_4_hi, e5_3_hi)
                    e5_4_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e5_3_hi, pl.tile.sub(e5_4_hi, e5_4_v)), pl.tile.sub(e4_4_lo, e5_4_v))
                    e5_5_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e5_4_hi, e4_4_hi)
                    e5_5_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e5_5_hi, e5_4_hi)
                    e5_5_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e5_4_hi, pl.tile.sub(e5_5_hi, e5_5_v)), pl.tile.sub(e4_4_hi, e5_5_v))
                    e6_0_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(product6, e5_0_lo)
                    e6_0_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e6_0_hi, product6)
                    e6_0_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(product6, pl.tile.sub(e6_0_hi, e6_0_v)), pl.tile.sub(e5_0_lo, e6_0_v))
                    e6_1_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e6_0_hi, e5_1_lo)
                    e6_1_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e6_1_hi, e6_0_hi)
                    e6_1_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e6_0_hi, pl.tile.sub(e6_1_hi, e6_1_v)), pl.tile.sub(e5_1_lo, e6_1_v))
                    e6_2_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e6_1_hi, e5_2_lo)
                    e6_2_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e6_2_hi, e6_1_hi)
                    e6_2_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e6_1_hi, pl.tile.sub(e6_2_hi, e6_2_v)), pl.tile.sub(e5_2_lo, e6_2_v))
                    e6_3_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e6_2_hi, e5_3_lo)
                    e6_3_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e6_3_hi, e6_2_hi)
                    e6_3_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e6_2_hi, pl.tile.sub(e6_3_hi, e6_3_v)), pl.tile.sub(e5_3_lo, e6_3_v))
                    e6_4_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e6_3_hi, e5_4_lo)
                    e6_4_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e6_4_hi, e6_3_hi)
                    e6_4_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e6_3_hi, pl.tile.sub(e6_4_hi, e6_4_v)), pl.tile.sub(e5_4_lo, e6_4_v))
                    e6_5_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e6_4_hi, e5_5_lo)
                    e6_5_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e6_5_hi, e6_4_hi)
                    e6_5_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e6_4_hi, pl.tile.sub(e6_5_hi, e6_5_v)), pl.tile.sub(e5_5_lo, e6_5_v))
                    e6_6_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e6_5_hi, e5_5_hi)
                    e6_6_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e6_6_hi, e6_5_hi)
                    e6_6_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e6_5_hi, pl.tile.sub(e6_6_hi, e6_6_v)), pl.tile.sub(e5_5_hi, e6_6_v))
                    e7_0_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(product7, e6_0_lo)
                    e7_0_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e7_0_hi, product7)
                    e7_0_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(product7, pl.tile.sub(e7_0_hi, e7_0_v)), pl.tile.sub(e6_0_lo, e7_0_v))
                    e7_1_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e7_0_hi, e6_1_lo)
                    e7_1_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e7_1_hi, e7_0_hi)
                    e7_1_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e7_0_hi, pl.tile.sub(e7_1_hi, e7_1_v)), pl.tile.sub(e6_1_lo, e7_1_v))
                    e7_2_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e7_1_hi, e6_2_lo)
                    e7_2_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e7_2_hi, e7_1_hi)
                    e7_2_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e7_1_hi, pl.tile.sub(e7_2_hi, e7_2_v)), pl.tile.sub(e6_2_lo, e7_2_v))
                    e7_3_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e7_2_hi, e6_3_lo)
                    e7_3_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e7_3_hi, e7_2_hi)
                    e7_3_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e7_2_hi, pl.tile.sub(e7_3_hi, e7_3_v)), pl.tile.sub(e6_3_lo, e7_3_v))
                    e7_4_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e7_3_hi, e6_4_lo)
                    e7_4_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e7_4_hi, e7_3_hi)
                    e7_4_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e7_3_hi, pl.tile.sub(e7_4_hi, e7_4_v)), pl.tile.sub(e6_4_lo, e7_4_v))
                    e7_5_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e7_4_hi, e6_5_lo)
                    e7_5_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e7_5_hi, e7_4_hi)
                    e7_5_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e7_4_hi, pl.tile.sub(e7_5_hi, e7_5_v)), pl.tile.sub(e6_5_lo, e7_5_v))
                    e7_6_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e7_5_hi, e6_6_lo)
                    e7_6_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e7_6_hi, e7_5_hi)
                    e7_6_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e7_5_hi, pl.tile.sub(e7_6_hi, e7_6_v)), pl.tile.sub(e6_6_lo, e7_6_v))
                    e7_7_hi: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(e7_6_hi, e6_6_hi)
                    e7_7_v: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e7_7_hi, e7_6_hi)
                    e7_7_lo: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.sub(e7_6_hi, pl.tile.sub(e7_7_hi, e7_7_v)), pl.tile.sub(e6_6_hi, e7_7_v))
                    tail_prefix_1: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(pl.tile.cmp(e7_1_lo, zero, cmp_type=1), e7_1_lo, e7_0_lo, sel_tmp)
                    tail_prefix_2: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(pl.tile.cmp(e7_2_lo, zero, cmp_type=1), e7_2_lo, tail_prefix_1, sel_tmp)
                    tail_prefix_3: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(pl.tile.cmp(e7_3_lo, zero, cmp_type=1), e7_3_lo, tail_prefix_2, sel_tmp)
                    tail_prefix_4: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(pl.tile.cmp(e7_4_lo, zero, cmp_type=1), e7_4_lo, tail_prefix_3, sel_tmp)
                    tail_prefix_5: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(pl.tile.cmp(e7_5_lo, zero, cmp_type=1), e7_5_lo, tail_prefix_4, sel_tmp)
                    tail_prefix_6: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(pl.tile.cmp(e7_6_lo, zero, cmp_type=1), e7_6_lo, tail_prefix_5, sel_tmp)
                    rounded: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = e7_7_hi
                    residual: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = zero
                    remaining: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = zero
                    active: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = one
                    round7_sum: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(rounded, e7_7_lo)
                    round7_error: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e7_7_lo, pl.tile.sub(round7_sum, rounded))
                    round7_active: pl.Tile[[1, 32], pl.UINT8, pl.Mem.Vec, pl.TileView(valid_shape=[1, 4])] = pl.tile.cmp(active, zero, cmp_type=1)
                    rounded_v1: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round7_active, round7_sum, rounded, sel_tmp)
                    residual_v1: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round7_active, round7_error, residual, sel_tmp)
                    remaining_v1: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round7_active, tail_prefix_6, remaining, sel_tmp)
                    active_v1: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(pl.tile.cmp(round7_error, zero, cmp_type=0), active, zero, sel_tmp)
                    round6_sum: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(rounded_v1, e7_6_lo)
                    round6_error: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e7_6_lo, pl.tile.sub(round6_sum, rounded_v1))
                    round6_active: pl.Tile[[1, 32], pl.UINT8, pl.Mem.Vec, pl.TileView(valid_shape=[1, 4])] = pl.tile.cmp(active_v1, zero, cmp_type=1)
                    rounded_v2: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round6_active, round6_sum, rounded_v1, sel_tmp)
                    residual_v2: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round6_active, round6_error, residual_v1, sel_tmp)
                    remaining_v2: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round6_active, tail_prefix_5, remaining_v1, sel_tmp)
                    active_v2: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(pl.tile.cmp(round6_error, zero, cmp_type=0), active_v1, zero, sel_tmp)
                    round5_sum: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(rounded_v2, e7_5_lo)
                    round5_error: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e7_5_lo, pl.tile.sub(round5_sum, rounded_v2))
                    round5_active: pl.Tile[[1, 32], pl.UINT8, pl.Mem.Vec, pl.TileView(valid_shape=[1, 4])] = pl.tile.cmp(active_v2, zero, cmp_type=1)
                    rounded_v3: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round5_active, round5_sum, rounded_v2, sel_tmp)
                    residual_v3: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round5_active, round5_error, residual_v2, sel_tmp)
                    remaining_v3: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round5_active, tail_prefix_4, remaining_v2, sel_tmp)
                    active_v3: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(pl.tile.cmp(round5_error, zero, cmp_type=0), active_v2, zero, sel_tmp)
                    round4_sum: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(rounded_v3, e7_4_lo)
                    round4_error: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e7_4_lo, pl.tile.sub(round4_sum, rounded_v3))
                    round4_active: pl.Tile[[1, 32], pl.UINT8, pl.Mem.Vec, pl.TileView(valid_shape=[1, 4])] = pl.tile.cmp(active_v3, zero, cmp_type=1)
                    rounded_v4: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round4_active, round4_sum, rounded_v3, sel_tmp)
                    residual_v4: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round4_active, round4_error, residual_v3, sel_tmp)
                    remaining_v4: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round4_active, tail_prefix_3, remaining_v3, sel_tmp)
                    active_v4: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(pl.tile.cmp(round4_error, zero, cmp_type=0), active_v3, zero, sel_tmp)
                    round3_sum: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(rounded_v4, e7_3_lo)
                    round3_error: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e7_3_lo, pl.tile.sub(round3_sum, rounded_v4))
                    round3_active: pl.Tile[[1, 32], pl.UINT8, pl.Mem.Vec, pl.TileView(valid_shape=[1, 4])] = pl.tile.cmp(active_v4, zero, cmp_type=1)
                    rounded_v5: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round3_active, round3_sum, rounded_v4, sel_tmp)
                    residual_v5: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round3_active, round3_error, residual_v4, sel_tmp)
                    remaining_v5: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round3_active, tail_prefix_2, remaining_v4, sel_tmp)
                    active_v5: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(pl.tile.cmp(round3_error, zero, cmp_type=0), active_v4, zero, sel_tmp)
                    round2_sum: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(rounded_v5, e7_2_lo)
                    round2_error: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e7_2_lo, pl.tile.sub(round2_sum, rounded_v5))
                    round2_active: pl.Tile[[1, 32], pl.UINT8, pl.Mem.Vec, pl.TileView(valid_shape=[1, 4])] = pl.tile.cmp(active_v5, zero, cmp_type=1)
                    rounded_v6: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round2_active, round2_sum, rounded_v5, sel_tmp)
                    residual_v6: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round2_active, round2_error, residual_v5, sel_tmp)
                    remaining_v6: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round2_active, tail_prefix_1, remaining_v5, sel_tmp)
                    active_v6: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(pl.tile.cmp(round2_error, zero, cmp_type=0), active_v5, zero, sel_tmp)
                    round1_sum: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(rounded_v6, e7_1_lo)
                    round1_error: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e7_1_lo, pl.tile.sub(round1_sum, rounded_v6))
                    round1_active: pl.Tile[[1, 32], pl.UINT8, pl.Mem.Vec, pl.TileView(valid_shape=[1, 4])] = pl.tile.cmp(active_v6, zero, cmp_type=1)
                    rounded_v7: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round1_active, round1_sum, rounded_v6, sel_tmp)
                    residual_v7: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round1_active, round1_error, residual_v6, sel_tmp)
                    remaining_v7: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round1_active, e7_0_lo, remaining_v6, sel_tmp)
                    active_v7: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(pl.tile.cmp(round1_error, zero, cmp_type=0), active_v6, zero, sel_tmp)
                    round0_sum: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(rounded_v7, e7_0_lo)
                    round0_error: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sub(e7_0_lo, pl.tile.sub(round0_sum, rounded_v7))
                    round0_active: pl.Tile[[1, 32], pl.UINT8, pl.Mem.Vec, pl.TileView(valid_shape=[1, 4])] = pl.tile.cmp(active_v7, zero, cmp_type=1)
                    rounded_v8: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round0_active, round0_sum, rounded_v7, sel_tmp)
                    residual_v8: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round0_active, round0_error, residual_v7, sel_tmp)
                    remaining_v8: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(round0_active, zero, remaining_v7, sel_tmp)
                    active_v8: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(pl.tile.cmp(round0_error, zero, cmp_type=0), active_v7, zero, sel_tmp)
                    positive_tail: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(pl.tile.cmp(remaining_v8, zero, cmp_type=4), one, zero, sel_tmp)
                    negative_tail: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(pl.tile.cmp(remaining_v8, zero, cmp_type=2), one, zero, sel_tmp)
                    positive: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(pl.tile.cmp(residual_v8, zero, cmp_type=4), positive_tail, zero, sel_tmp)
                    negative: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(pl.tile.cmp(residual_v8, zero, cmp_type=2), negative_tail, zero, sel_tmp)
                    same_sign: pl.Tile[[1, 32], pl.UINT8, pl.Mem.Vec, pl.TileView(valid_shape=[1, 4])] = pl.tile.cmp(pl.tile.add(positive, negative), zero, cmp_type=4)
                    twice: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.muls(residual_v8, 2.0)
                    adjusted: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.add(rounded_v8, twice)
                    exact_half: pl.Tile[[1, 32], pl.UINT8, pl.Mem.Vec, pl.TileView(valid_shape=[1, 4])] = pl.tile.cmp(pl.tile.sub(adjusted, rounded_v8), twice, cmp_type=0)
                    tie_adjusted: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(exact_half, adjusted, rounded_v8, sel_tmp)
                    rounded_v9: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sel(same_sign, tie_adjusted, rounded_v8, sel_tmp)
                    accumulator: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = rounded_v9
            pl.tile.store(accumulator, [unit, 0], partials)
        return partials
    @pl.function(type=pl.FunctionType.Inline)
    def hc_pre_gates_from_rms(self, x: pl.Tensor[[T_DYN, 4, 4096], pl.FP32], hc_fn: pl.Tensor[[24, 16384], pl.FP32], hc_scale: pl.Tensor[[3], pl.FP32], hc_base: pl.Tensor[[24], pl.FP32], pre_val_store: pl.Tensor[[T_DYN, 8], pl.FP32], post: pl.Tensor[[T_DYN, 4], pl.FP32], comb: pl.Tensor[[T_DYN, 16], pl.FP32], row_recip: pl.Scalar[pl.BOOL], inv_rms: pl.Tensor[[HC_PAD_ROWS_DYN, 1], pl.FP32]) -> pl.Tensor[[T_DYN, 8], pl.FP32]:
        # 共享门控与Sinkhorn算术，复用调用方按原规则生成的RMS统计。
        t_dim: pl.Scalar[pl.INDEX] = pl.tensor.dim(x, 0)
        token_tiles: pl.Scalar[pl.INDEX] = (t_dim + 8 - 1) // 8
        t_linear: pl.Scalar[pl.INDEX] = (t_dim + 16 - 1) // 16 * 16
        x_flat: pl.Tensor[[t_dim, 16384], pl.FP32] = pl.tensor.reshape(x, [t_dim, 16384])
        hc_base_2d: pl.Tensor[[1, 24], pl.FP32] = pl.tensor.reshape(hc_base, [1, 24])
        mixes_partials: pl.Tensor[[pl.const(22, pl.INDEX) * t_linear, 32], pl.FP32] = pl.tensor.create([22 * t_linear, 32], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        mixes_partials_v1: pl.Tensor[[pl.const(22, pl.INDEX) * t_linear, 32], pl.FP32] = self._hcpre_linear_dsl(x_flat, hc_fn, mixes_partials)
        mixes_raw: pl.Tensor[[t_linear, 32], pl.FP32] = pl.tensor.create([t_linear, 32], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        for linear_block in pl.spmd(t_linear // 16, name_hint="hc_pre_linear_reduce_spmd", allow_early_resolve=True):
            linear_t0: pl.Scalar[pl.INDEX] = linear_block * 16
            mixes_total: pl.Tensor[[16, 32], pl.FP32] = pl.tensor.slice(mixes_partials_v1, [16, 32], [linear_t0, 0])
            for linear_split in pl.range(1, 22):
                partial_t0: pl.Scalar[pl.INDEX] = linear_split * t_linear + linear_t0
                partial_tile: pl.Tensor[[16, 32], pl.FP32] = pl.tensor.slice(mixes_partials_v1, [16, 32], [partial_t0, 0])
                mixes_total: pl.Tensor[[16, 32], pl.FP32] = pl.tensor.add(mixes_total, partial_tile)
            mixes_raw: pl.Tensor[[t_linear, 32], pl.FP32] = pl.tensor.assemble(mixes_raw, mixes_total, [linear_t0, 0])
        post_tail_store: pl.Tensor[[8, 8], pl.FP32] = pl.tensor.create([8, 8], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        for ob_worker in pl.spmd(pl.min(token_tiles, 16), name_hint="split_pre_post_spmd", allow_early_resolve=True):
            scale0: pl.Scalar[pl.FP32] = pl.tensor.read(hc_scale, [0])
            scale1: pl.Scalar[pl.FP32] = pl.tensor.read(hc_scale, [1])
            for ob in pl.range(ob_worker, token_tiles, pl.min(token_tiles, 16)):
                t0: pl.Scalar[pl.INDEX] = ob * 8
                valid_rows: pl.Scalar[pl.INDEX] = pl.min(8, t_dim - t0)
                inv_col: pl.Tensor[[8, 1], pl.FP32] = pl.tensor.slice(inv_rms, [8, 1], [t0, 0])
                pre_base: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.reshape(pl.tensor.slice(hc_base, [8], [0]), [1, 8])
                pre_scaled: pl.Tensor[[8, 8], pl.FP32] = pl.tensor.muls(pl.tensor.row_expand_mul(pl.tensor.slice(mixes_raw, [8, 8], [t0, 0]), inv_col), scale0)
                pre_logits: pl.Tensor[[8, 8], pl.FP32] = pl.tensor.add(pre_scaled, pl.tensor.col_expand(pre_scaled, pre_base))
                pre_sig: pl.Tensor[[8, 8], pl.FP32] = pl.tensor.div(pl.tensor.full([8, 8], dtype=pl.FP32, value=1.0), pl.tensor.adds(pl.tensor.exp(pl.tensor.neg(pre_logits)), 1.0))
                pre_val: pl.Tensor[[8, 8], pl.FP32] = pl.tensor.adds(pre_sig, 9.9999999999999995e-07)
                pre_val_store: pl.Tensor[[T_DYN, 8], pl.FP32] = pl.tensor.assemble(pre_val_store, pre_val, [t0, 0])
                post_base: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.reshape(pl.tensor.slice(hc_base, [8], [4]), [1, 8])
                post_scaled: pl.Tensor[[8, 8], pl.FP32] = pl.tensor.muls(pl.tensor.row_expand_mul(pl.tensor.slice(mixes_raw, [8, 8], [t0, 4]), inv_col), scale1)
                post_logits: pl.Tensor[[8, 8], pl.FP32] = pl.tensor.add(post_scaled, pl.tensor.col_expand(post_scaled, post_base))
                post_sig: pl.Tensor[[8, 8], pl.FP32] = pl.tensor.div(pl.tensor.full([8, 8], dtype=pl.FP32, value=1.0), pl.tensor.adds(pl.tensor.exp(pl.tensor.neg(post_logits)), 1.0))
                post_pad: pl.Tensor[[8, 8], pl.FP32] = pl.tensor.muls(post_sig, 2.0)
                if valid_rows == 8:
                    post: pl.Tensor[[T_DYN, 4], pl.FP32] = pl.tensor.assemble(post, pl.tensor.slice(post_pad, [8, 8], [0, 0], [8, 4]), [t0, 0])
                else:
                    post_tail_store: pl.Tensor[[8, 8], pl.FP32] = pl.tensor.assemble(post_tail_store, post_pad, [0, 0])
                    post_tile: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 4])] = pl.tile.load(post_tail_store, [0, 0], [8, 8], [valid_rows, 4], target_memory=pl.Mem.Vec)
                    pl.tile.store(post_tile, [t0, 0], post)
        comb_tail_store: pl.Tensor[[8, 32], pl.FP32] = pl.tensor.create([8, 32], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        for ob_1 in pl.spmd(token_tiles, name_hint="comb_sinkhorn_spmd", allow_early_resolve=True):
            scale2: pl.Scalar[pl.FP32] = pl.tensor.read(hc_scale, [2])
            t0: pl.Scalar[pl.INDEX] = ob_1 * 8
            valid_rows: pl.Scalar[pl.INDEX] = pl.min(8, t_dim - t0)
            inv_col_t: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 1])] = pl.tile.load(inv_rms, [t0, 0], [8, 1], [valid_rows, 1], target_memory=pl.Mem.Vec)
            comb_off: pl.Scalar[pl.INDEX] = 8
            mix_g0: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 4])] = pl.tile.load(mixes_raw, [t0, comb_off + 0], [8, 8], [valid_rows, 4], target_memory=pl.Mem.Vec)
            mix_g1: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 4])] = pl.tile.load(mixes_raw, [t0, comb_off + 4], [8, 8], [valid_rows, 4], target_memory=pl.Mem.Vec)
            mix_g2: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 4])] = pl.tile.load(mixes_raw, [t0, comb_off + 8], [8, 8], [valid_rows, 4], target_memory=pl.Mem.Vec)
            mix_g3: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 4])] = pl.tile.load(mixes_raw, [t0, comb_off + 12], [8, 8], [valid_rows, 4], target_memory=pl.Mem.Vec)
            cb0: pl.Tile[[1, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[1, 4])] = pl.tile.load(hc_base_2d, [0, comb_off + 0], [1, 8], [1, 4], target_memory=pl.Mem.Vec)
            cb1: pl.Tile[[1, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[1, 4])] = pl.tile.load(hc_base_2d, [0, comb_off + 4], [1, 8], [1, 4], target_memory=pl.Mem.Vec)
            cb2: pl.Tile[[1, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[1, 4])] = pl.tile.load(hc_base_2d, [0, comb_off + 8], [1, 8], [1, 4], target_memory=pl.Mem.Vec)
            cb3: pl.Tile[[1, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[1, 4])] = pl.tile.load(hc_base_2d, [0, comb_off + 12], [1, 8], [1, 4], target_memory=pl.Mem.Vec)
            row0: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 4])] = pl.tile.add(pl.tile.muls(pl.tile.row_expand_mul(mix_g0, inv_col_t), scale2), pl.tile.col_expand(mix_g0, cb0))
            row1: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 4])] = pl.tile.add(pl.tile.muls(pl.tile.row_expand_mul(mix_g1, inv_col_t), scale2), pl.tile.col_expand(mix_g1, cb1))
            row2: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 4])] = pl.tile.add(pl.tile.muls(pl.tile.row_expand_mul(mix_g2, inv_col_t), scale2), pl.tile.col_expand(mix_g2, cb2))
            row3: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 4])] = pl.tile.add(pl.tile.muls(pl.tile.row_expand_mul(mix_g3, inv_col_t), scale2), pl.tile.col_expand(mix_g3, cb3))
            row0_p: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.fillpad(row0, pad_value=pl.PadValue.min)
            row1_p: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.fillpad(row1, pad_value=pl.PadValue.min)
            row2_p: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.fillpad(row2, pad_value=pl.PadValue.min)
            row3_p: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.fillpad(row3, pad_value=pl.PadValue.min)
            row_max_tmp: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec] = pl.tile.create([8, 8], dtype=pl.FP32, target_memory=pl.Mem.Vec)
            row_sum_tmp: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec] = pl.tile.create([8, 8], dtype=pl.FP32, target_memory=pl.Mem.Vec)
            row0_max: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.row_max(row0_p, row_max_tmp)
            row1_max: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.row_max(row1_p, row_max_tmp)
            row2_max: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.row_max(row2_p, row_max_tmp)
            row3_max: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.row_max(row3_p, row_max_tmp)
            row0_exp: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.exp(pl.tile.row_expand_sub(row0_p, row0_max))
            row1_exp: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.exp(pl.tile.row_expand_sub(row1_p, row1_max))
            row2_exp: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.exp(pl.tile.row_expand_sub(row2_p, row2_max))
            row3_exp: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.exp(pl.tile.row_expand_sub(row3_p, row3_max))
            row0_sum: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.row_sum(row0_exp, row_sum_tmp)
            row1_sum: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.row_sum(row1_exp, row_sum_tmp)
            row2_sum: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.row_sum(row2_exp, row_sum_tmp)
            row3_sum: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.row_sum(row3_exp, row_sum_tmp)
            if row_recip:
                row0_inv: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.recip(row0_sum)
                row0_prob: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.row_expand_mul(row0_exp, row0_inv)
                row0_soft: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.adds(row0_prob, 9.9999999999999995e-07)
                row1_inv: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.recip(row1_sum)
                row1_prob: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.row_expand_mul(row1_exp, row1_inv)
                row1_soft: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.adds(row1_prob, 9.9999999999999995e-07)
                row2_inv: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.recip(row2_sum)
                row2_prob: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.row_expand_mul(row2_exp, row2_inv)
                row2_soft: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.adds(row2_prob, 9.9999999999999995e-07)
                row3_inv: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.recip(row3_sum)
                row3_prob: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.row_expand_mul(row3_exp, row3_inv)
                row3_soft: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.adds(row3_prob, 9.9999999999999995e-07)
            else:
                row0_soft: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.adds(pl.tile.row_expand_div(row0_exp, row0_sum), 9.9999999999999995e-07)
                row1_soft: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.adds(pl.tile.row_expand_div(row1_exp, row1_sum), 9.9999999999999995e-07)
                row2_soft: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.adds(pl.tile.row_expand_div(row2_exp, row2_sum), 9.9999999999999995e-07)
                row3_soft: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.adds(pl.tile.row_expand_div(row3_exp, row3_sum), 9.9999999999999995e-07)
            row0_valid: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[8, 4], pad=pl.PadValue.min)] = pl.tile.set_validshape(row0_soft, 8, 4)
            row1_valid: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[8, 4], pad=pl.PadValue.min)] = pl.tile.set_validshape(row1_soft, 8, 4)
            row2_valid: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[8, 4], pad=pl.PadValue.min)] = pl.tile.set_validshape(row2_soft, 8, 4)
            row3_valid: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[8, 4], pad=pl.PadValue.min)] = pl.tile.set_validshape(row3_soft, 8, 4)
            row0_eff: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.fillpad(row0_valid, pad_value=pl.PadValue.zero)
            row1_eff: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.fillpad(row1_valid, pad_value=pl.PadValue.zero)
            row2_eff: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.fillpad(row2_valid, pad_value=pl.PadValue.zero)
            row3_eff: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.fillpad(row3_valid, pad_value=pl.PadValue.zero)
            row_sum_tmp_iter: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec] = pl.tile.create([8, 8], dtype=pl.FP32, target_memory=pl.Mem.Vec)
            col_sum: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.add(pl.tile.add(pl.tile.add(row0_eff, row1_eff), row2_eff), row3_eff)
            col_sum_v1: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.adds(col_sum, 9.9999999999999995e-07)
            row0_cur: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.div(row0_eff, col_sum_v1)
            row1_cur: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.div(row1_eff, col_sum_v1)
            row2_cur: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.div(row2_eff, col_sum_v1)
            row3_cur: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.div(row3_eff, col_sum_v1)
            for _sk_it in pl.pipeline(19, stage=2):
                row0_rowsum: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.adds(pl.tile.row_sum(row0_cur, row_sum_tmp_iter), 9.9999999999999995e-07)
                row1_rowsum: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.adds(pl.tile.row_sum(row1_cur, row_sum_tmp_iter), 9.9999999999999995e-07)
                row2_rowsum: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.adds(pl.tile.row_sum(row2_cur, row_sum_tmp_iter), 9.9999999999999995e-07)
                row3_rowsum: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.adds(pl.tile.row_sum(row3_cur, row_sum_tmp_iter), 9.9999999999999995e-07)
                if row_recip:
                    row0_inv: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.recip(row0_rowsum)
                    row0_norm: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.row_expand_mul(row0_cur, row0_inv)
                    row1_inv: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.recip(row1_rowsum)
                    row1_norm: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.row_expand_mul(row1_cur, row1_inv)
                    row2_inv: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.recip(row2_rowsum)
                    row2_norm: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.row_expand_mul(row2_cur, row2_inv)
                    row3_inv: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.recip(row3_rowsum)
                    row3_norm: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.row_expand_mul(row3_cur, row3_inv)
                else:
                    row0_norm: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.row_expand_div(row0_cur, row0_rowsum)
                    row1_norm: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.row_expand_div(row1_cur, row1_rowsum)
                    row2_norm: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.row_expand_div(row2_cur, row2_rowsum)
                    row3_norm: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.row_expand_div(row3_cur, row3_rowsum)
                col_sum_v1: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.add(pl.tile.add(pl.tile.add(row0_norm, row1_norm), row2_norm), row3_norm)
                col_sum_v1: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.adds(col_sum_v1, 9.9999999999999995e-07)
                row0_cur: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.div(row0_norm, col_sum_v1)
                row1_cur: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.div(row1_norm, col_sum_v1)
                row2_cur: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.div(row2_norm, col_sum_v1)
                row3_cur: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.zero)] = pl.tile.div(row3_norm, col_sum_v1)
            if valid_rows == 8:
                row0_out: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[8, 4], pad=pl.PadValue.zero)] = pl.tile.set_validshape(row0_cur, 8, 4)
                row1_out: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[8, 4], pad=pl.PadValue.zero)] = pl.tile.set_validshape(row1_cur, 8, 4)
                row2_out: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[8, 4], pad=pl.PadValue.zero)] = pl.tile.set_validshape(row2_cur, 8, 4)
                row3_out: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[8, 4], pad=pl.PadValue.zero)] = pl.tile.set_validshape(row3_cur, 8, 4)
                pl.tile.store(row0_out, [t0, 0], comb)
                pl.tile.store(row1_out, [t0, 4], comb)
                pl.tile.store(row2_out, [t0, 8], comb)
                pl.tile.store(row3_out, [t0, 12], comb)
            else:
                pl.tile.store(row0_cur, [0, 0], comb_tail_store)
                pl.tile.store(row1_cur, [0, 8], comb_tail_store)
                pl.tile.store(row2_cur, [0, 16], comb_tail_store)
                pl.tile.store(row3_cur, [0, 24], comb_tail_store)
                row0_tail: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 4])] = pl.tile.load(comb_tail_store, [0, 0], [8, 8], [valid_rows, 4], target_memory=pl.Mem.Vec)
                row1_tail: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 4])] = pl.tile.load(comb_tail_store, [0, 8], [8, 8], [valid_rows, 4], target_memory=pl.Mem.Vec)
                row2_tail: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 4])] = pl.tile.load(comb_tail_store, [0, 16], [8, 8], [valid_rows, 4], target_memory=pl.Mem.Vec)
                row3_tail: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 4])] = pl.tile.load(comb_tail_store, [0, 24], [8, 8], [valid_rows, 4], target_memory=pl.Mem.Vec)
                pl.tile.store(row0_tail, [t0, 0], comb)
                pl.tile.store(row1_tail, [t0, 4], comb)
                pl.tile.store(row2_tail, [t0, 8], comb)
                pl.tile.store(row3_tail, [t0, 12], comb)
        return pre_val_store
    @pl.function(type=pl.FunctionType.Inline)
    def hc_pre_gates(self, x: pl.Tensor[[T_DYN, 4, 4096], pl.FP32], hc_fn: pl.Tensor[[24, 16384], pl.FP32], hc_scale: pl.Tensor[[3], pl.FP32], hc_base: pl.Tensor[[24], pl.FP32], pre_val_store: pl.Tensor[[T_DYN, 8], pl.FP32], post: pl.Tensor[[T_DYN, 4], pl.FP32], comb: pl.Tensor[[T_DYN, 16], pl.FP32], row_recip: pl.Scalar[pl.BOOL]):
        # 保留原独立RMS任务及其归约次序。
        t_dim: pl.Scalar[pl.INDEX] = pl.tensor.dim(x, 0)
        token_tiles: pl.Scalar[pl.INDEX] = (t_dim + 8 - 1) // 8
        t_linear: pl.Scalar[pl.INDEX] = (t_dim + 16 - 1) // 16 * 16
        x_flat: pl.Tensor[[t_dim, 16384], pl.FP32] = pl.tensor.reshape(x, [t_dim, 16384])
        inv_rms: pl.Tensor[[t_linear, 1], pl.FP32] = pl.tensor.create([t_linear, 1], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        sq_partials: pl.Tensor[[pl.const(22, pl.INDEX) * t_linear, 16], pl.FP32] = pl.tensor.create([22 * t_linear, 16], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        sq_units: pl.Scalar[pl.INDEX] = t_linear // 16 * 22
        for sq_unit in pl.spmd(sq_units, name_hint="hc_pre_square_partial_spmd", allow_early_resolve=True):
            sq_t0: pl.Scalar[pl.INDEX] = sq_unit // 22 * 16
            sq_part: pl.Scalar[pl.INDEX] = sq_unit % 22
            sq_rows: pl.Scalar[pl.INDEX] = pl.min(16, t_dim - sq_t0)
            sq_count: pl.Scalar[pl.INDEX] = pl.min(768, 16384 - sq_part * 768) // 32
            native_sq_acc: pl.Tensor[[16, 16], pl.FP32] = pl.tensor.create([16, 16], dtype=pl.FP32, layout=pl.TensorLayout.ND)
            for sq_kb in pl.pipeline(sq_count, stage=2):
                sq_k: pl.Scalar[pl.INDEX] = sq_part * 768 + sq_kb * 32
                sq_lhs: pl.Tensor[[16, 32], pl.FP32, pl.TensorView(valid_shape=[sq_rows, 32], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.slice(x_flat, [16, 32], [sq_t0, sq_k], [sq_rows, 32])
                native_sq_acc: pl.Tensor[[16, 16], pl.FP32] = pl.tensor.matmul_acc(native_sq_acc, sq_lhs, sq_lhs, init_cond=sq_kb == 0, a_trans=False, b_trans=True)
            sq_out_row: pl.Scalar[pl.INDEX] = sq_part * t_linear + sq_t0
            sq_partials: pl.Tensor[[pl.const(22, pl.INDEX) * t_linear, 16], pl.FP32] = pl.tensor.assemble(sq_partials, native_sq_acc, [sq_out_row, 0])
        for rms_block in pl.spmd(token_tiles, name_hint="hc_pre_native_rms_spmd", allow_early_resolve=True):
            rms_t0: pl.Scalar[pl.INDEX] = rms_block * 8
            rms_lanes: pl.Tensor[[1, 8], pl.INT32] = pl.tensor.ci(pl.const(0, pl.INT32), [1, 8], dtype=pl.INT32, descending=False)
            rms_rows: pl.Tensor[[1, 8], pl.INT32] = pl.tensor.adds(rms_lanes, pl.cast(rms_t0, pl.INT32))
            rms_local: pl.Tensor[[1, 8], pl.INT32] = pl.tensor.adds(rms_lanes, pl.cast(rms_t0 % 16, pl.INT32))
            rms_index: pl.Tensor[[1, 8], pl.INT32] = pl.tensor.add(pl.tensor.muls(rms_rows, pl.const(16, pl.INT32)), rms_local)
            rms_total: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.gather(sq_partials, rms_index)
            for rms_part in pl.range(1, 22):
                rms_part_index: pl.Tensor[[1, 8], pl.INT32] = pl.tensor.adds(rms_index, pl.cast(rms_part * t_linear * 16, pl.INT32))
                rms_value: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.gather(sq_partials, rms_part_index)
                rms_total: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.add(rms_total, rms_value)
            rms_variance: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.adds(pl.tensor.muls(rms_total, 6.103515625e-05), 9.9999999999999995e-07)
            rms_root: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.sqrt(rms_variance)
            native_inverse: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.div(pl.tensor.full([1, 8], dtype=pl.FP32, value=1.0), rms_root)
            inv_rms: pl.Tensor[[t_linear, 1], pl.FP32] = pl.tensor.assemble(inv_rms, pl.tensor.reshape(native_inverse, [8, 1]), [rms_t0, 0])
        return self.hc_pre_gates_from_rms(x, hc_fn, hc_scale, hc_base, pre_val_store, post, comb, row_recip, inv_rms)
    @pl.function(type=pl.FunctionType.Inline)
    def _hc_pre(self, x: pl.Tensor[[T_DYN, 4, 4096], pl.FP32], hc_fn: pl.Tensor[[24, 16384], pl.FP32], hc_scale: pl.Tensor[[3], pl.FP32], hc_base: pl.Tensor[[24], pl.FP32], x_mixed: pl.Tensor[[T_DYN, 4096], pl.BF16], post: pl.Tensor[[T_DYN, 4], pl.FP32], comb: pl.Tensor[[T_DYN, 16], pl.FP32]) -> pl.Tensor[[T_DYN, 4096], pl.BF16]:
        # Compute HC gates and BF16 pre-mixed activations.
        t_dim: pl.Scalar[pl.INDEX] = pl.tensor.dim(x, 0)
        token_tiles: pl.Scalar[pl.INDEX] = (t_dim + 8 - 1) // 8
        t_linear: pl.Scalar[pl.INDEX] = (t_dim + 16 - 1) // 16 * 16
        pre_val_store: pl.Tensor[[t_linear, 8], pl.FP32] = pl.tensor.create([t_linear, 8], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        self.hc_pre_gates(x, hc_fn, hc_scale, hc_base, pre_val_store, post, comb, False)
        x_flat: pl.Tensor[[t_dim, 16384], pl.FP32] = pl.tensor.reshape(x, [t_dim, 16384])
        x_mixed_tail_store: pl.Tensor[[8, 4096], pl.BF16] = pl.tensor.create([8, 4096], dtype=pl.BF16, layout=pl.TensorLayout.ND)
        for blk in pl.spmd(token_tiles * 1, name_hint="mix_x_spmd", allow_early_resolve=True):
            t0: pl.Scalar[pl.INDEX] = blk // 1 * 8
            d_base: pl.Scalar[pl.INDEX] = blk % 1 * 4096
            valid_rows: pl.Scalar[pl.INDEX] = pl.min(8, t_dim - t0)
            pre_tile_t: pl.Tensor[[8, 8], pl.FP32, pl.TensorView(stride=[1, 8], layout=pl.TensorLayout.DN)] = pl.tensor.transpose(pl.tensor.slice(pre_val_store, [8, 8], [t0, 0]), 0, 1)
            pre0: pl.Tensor[[8, 1], pl.FP32] = pl.tensor.reshape(pl.tensor.slice(pre_tile_t, [1, 8], [0, 0]), [8, 1])
            pre1: pl.Tensor[[8, 1], pl.FP32] = pl.tensor.reshape(pl.tensor.slice(pre_tile_t, [1, 8], [1, 0]), [8, 1])
            pre2: pl.Tensor[[8, 1], pl.FP32] = pl.tensor.reshape(pl.tensor.slice(pre_tile_t, [1, 8], [2, 0]), [8, 1])
            pre3: pl.Tensor[[8, 1], pl.FP32] = pl.tensor.reshape(pl.tensor.slice(pre_tile_t, [1, 8], [3, 0]), [8, 1])
            for db in pl.pipeline(16, stage=2):
                d0: pl.Scalar[pl.INDEX] = d_base + db * 256
                x0: pl.Tensor[[8, 256], pl.FP32, pl.TensorView(valid_shape=[valid_rows, 256], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.slice(x_flat, [8, 256], [t0, 0 + d0], [valid_rows, 256])
                x1: pl.Tensor[[8, 256], pl.FP32, pl.TensorView(valid_shape=[valid_rows, 256], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.slice(x_flat, [8, 256], [t0, 4096 + d0], [valid_rows, 256])
                x2: pl.Tensor[[8, 256], pl.FP32, pl.TensorView(valid_shape=[valid_rows, 256], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.slice(x_flat, [8, 256], [t0, 8192 + d0], [valid_rows, 256])
                x3: pl.Tensor[[8, 256], pl.FP32, pl.TensorView(valid_shape=[valid_rows, 256], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.slice(x_flat, [8, 256], [t0, 12288 + d0], [valid_rows, 256])
                y0: pl.Tensor[[8, 256], pl.FP32] = pl.tensor.row_expand_mul(x0, pre0)
                y1: pl.Tensor[[8, 256], pl.FP32] = pl.tensor.row_expand_mul(x1, pre1)
                y2: pl.Tensor[[8, 256], pl.FP32] = pl.tensor.row_expand_mul(x2, pre2)
                y3: pl.Tensor[[8, 256], pl.FP32] = pl.tensor.row_expand_mul(x3, pre3)
                y_tile: pl.Tensor[[8, 256], pl.FP32] = pl.tensor.add(pl.tensor.add(pl.tensor.add(y0, y1), y2), y3)
                y_bf16: pl.Tensor[[8, 256], pl.BF16] = pl.tensor.cast(y_tile, target_type=pl.BF16, mode='rint')
                if valid_rows == 8:
                    x_mixed: pl.Tensor[[T_DYN, 4096], pl.BF16] = pl.tensor.assemble(x_mixed, y_bf16, [t0, d0])
                else:
                    x_mixed_tail_store: pl.Tensor[[8, 4096], pl.BF16] = pl.tensor.assemble(x_mixed_tail_store, y_bf16, [0, d0])
                    y_out: pl.Tile[[8, 256], pl.BF16, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 256])] = pl.tile.load(x_mixed_tail_store, [0, d0], [8, 256], [valid_rows, 256], target_memory=pl.Mem.Vec)
                    pl.tile.store(y_out, [t0, d0], x_mixed)
        return x_mixed
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def _hc_pre_test(self, x: pl.Tensor[[T_DYN, 4, 4096], pl.BF16], hc_fn: pl.Tensor[[24, 16384], pl.FP32], hc_scale: pl.Tensor[[3], pl.FP32], hc_base: pl.Tensor[[24], pl.FP32], x_mixed: pl.Tensor[[T_DYN, 4096], pl.BF16], post: pl.Tensor[[T_DYN, 4], pl.FP32], comb: pl.Tensor[[T_DYN, 16], pl.FP32]) -> tuple[pl.Tensor[[T_DYN, 4096], pl.BF16], pl.Tensor[[T_DYN, 4], pl.FP32], pl.Tensor[[T_DYN, 16], pl.FP32]]:
        tokens: pl.Scalar[pl.INDEX] = pl.tensor.dim(x, 0)
        wide: pl.Tensor[[tokens, 4, 4096], pl.FP32] = pl.tensor.create([tokens, 4, 4096], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        flat: pl.Tensor[[tokens, 16384], pl.BF16] = pl.tensor.reshape(x, [tokens, 16384])
        wide_flat: pl.Tensor[[tokens, 16384], pl.FP32] = pl.tensor.reshape(wide, [tokens, 16384])
        for row in pl.spmd(tokens, name_hint="hc_pre_widen_spmd", allow_early_resolve=True):
            for column in pl.pipeline(32, stage=2):
                start: pl.Scalar[pl.INDEX] = column * 512
                value: pl.Tensor[[1, 512], pl.FP32] = pl.tensor.cast(pl.tensor.slice(flat, [1, 512], [row, start]), target_type=pl.FP32, mode='round')
                wide_flat: pl.Tensor[[tokens, 16384], pl.FP32] = pl.tensor.assemble(wide_flat, value, [row, start])
        self._hc_pre(wide, hc_fn, hc_scale, hc_base, x_mixed, post, comb)
        return x_mixed, post, comb
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def _indexer_projection(self, x: pl.Tensor[[T_DYN, 4096], pl.BF16], weight: pl.Tensor[[64, 4096], pl.BF16], order: pl.Tensor[[16, 4, 16], pl.INT32], raw: pl.Tensor[[T_DYN, 64], pl.BF16], scaled: pl.Tensor[[T_DYN, 64], pl.BF16], output: pl.Tensor[[T_DYN, 64], pl.FP16]) -> tuple[pl.Tensor[[T_DYN, 64], pl.BF16], pl.Tensor[[T_DYN, 64], pl.BF16], pl.Tensor[[T_DYN, 64], pl.FP16]]:
        rows: pl.Scalar[pl.INDEX] = pl.tensor.dim(x, 0)
        row_tiles: pl.Scalar[pl.INDEX] = (rows + 15) // 16
        accum: pl.Tensor[[row_tiles * pl.const(16, pl.INDEX), 64], pl.FP32] = pl.tensor.create([row_tiles * 16, 64], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        for worker in pl.spmd(row_tiles * 4, name_hint="indexer_projection_matmul_spmd"):
            rb: pl.Scalar[pl.INDEX] = worker // 4
            group: pl.Scalar[pl.INDEX] = worker % 4
            row: pl.Scalar[pl.INDEX] = rb * 16
            col: pl.Scalar[pl.INDEX] = group * 16
            valid: pl.Scalar[pl.INDEX] = pl.min(16, rows - row)
            tile: pl.Tensor[[16, 16], pl.FP32] = pl.tensor.create([16, 16], dtype=pl.FP32, layout=pl.TensorLayout.ND)
            for step in pl.range(16):
                k_block: pl.Scalar[pl.INT32] = pl.tensor.read(order, [rb, group, step])
                offset: pl.Scalar[pl.INDEX] = pl.max(pl.cast(k_block, pl.INDEX), 0) * 256
                a: pl.Tensor[[16, 256], pl.BF16, pl.TensorView(valid_shape=[valid, 256], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.slice(x, [16, 256], [row, offset], [valid, 256])
                b: pl.Tensor[[16, 256], pl.BF16] = pl.tensor.slice(weight, [16, 256], [col, offset])
                tile: pl.Tensor[[16, 16], pl.FP32] = pl.tensor.matmul_acc(tile, a, b, init_cond=step == 0, a_trans=False, b_trans=True)
            accum: pl.Tensor[[row_tiles * pl.const(16, pl.INDEX), 64], pl.FP32] = pl.tensor.assemble(accum, tile, [row, col])
        for block in pl.spmd(row_tiles, name_hint="indexer_projection_round_spmd"):
            row: pl.Scalar[pl.INDEX] = block * 16
            valid: pl.Scalar[pl.INDEX] = pl.min(16, rows - row)
            value: pl.Tile[[16, 64], pl.FP32, pl.TileView(valid_shape=[valid, 64])] = pl.tile.load(accum, [row, 0], [16, 64], [valid, 64])
            projected: pl.Tile[[16, 64], pl.BF16, pl.Mem.Vec, pl.TileView(valid_shape=[valid, 64])] = pl.tile.cast(value, target_type=pl.BF16, mode='rint')
            pl.tile.store(projected, [row, 0], raw)
            value_v1: pl.Tile[[16, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid, 64])] = pl.tile.cast(projected, target_type=pl.FP32, mode='round')
            value_v2: pl.Tile[[16, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid, 64])] = pl.tile.muls(value_v1, 0.011048543456039806)
            weighted: pl.Tile[[16, 64], pl.BF16, pl.Mem.Vec, pl.TileView(valid_shape=[valid, 64])] = pl.tile.cast(value_v2, target_type=pl.BF16, mode='rint')
            pl.tile.store(weighted, [row, 0], scaled)
            result: pl.Tile[[16, 64], pl.FP16, pl.Mem.Vec, pl.TileView(valid_shape=[valid, 64])] = pl.tile.cast(weighted, target_type=pl.FP16, mode='rint')
            pl.tile.store(result, [row, 0], output)
        return raw, scaled, output
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def _square_sum(self, x: pl.Tensor[[T_DYN, 4096], pl.BF16], sums: pl.Tensor[[T_DYN, 8], pl.FP32]) -> pl.Tensor[[T_DYN, 8], pl.FP32]:
        rows: pl.Scalar[pl.INDEX] = pl.tensor.dim(x, 0)
        for row in pl.spmd(rows, name_hint="input_rms_sum_dsl_spmd", allow_early_resolve=True):
            raw: pl.Tile[[1, 4096], pl.BF16, pl.Mem.Vec] = pl.tile.load(x, [row, 0], [1, 4096], [1, 4096], target_memory=pl.Mem.Vec)
            wide: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec] = pl.tile.cast(raw, target_type=pl.FP32, mode='round')
            square: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec] = pl.tile.mul(wide, wide)
            fold2048: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.slice(square, [1, 2048], [0, 0]), pl.tile.slice(square, [1, 2048], [0, 2048]))
            fold1024: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.slice(fold2048, [1, 1024], [0, 0]), pl.tile.slice(fold2048, [1, 1024], [0, 1024]))
            fold512: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.slice(fold1024, [1, 512], [0, 0]), pl.tile.slice(fold1024, [1, 512], [0, 512]))
            fold256: pl.Tile[[1, 256], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.slice(fold512, [1, 256], [0, 0]), pl.tile.slice(fold512, [1, 256], [0, 256]))
            fold128: pl.Tile[[1, 128], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.slice(fold256, [1, 128], [0, 0]), pl.tile.slice(fold256, [1, 128], [0, 128]))
            fold64: pl.Tile[[1, 64], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.slice(fold128, [1, 64], [0, 0]), pl.tile.slice(fold128, [1, 64], [0, 64]))
            repeated: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.col_expand(pl.tile.create([8, 64], dtype=pl.FP32), fold64)
            total: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.row_sum(repeated, pl.tile.create([8, 64], dtype=pl.FP32))
            pl.tile.store(pl.tile.reshape(total, [1, 8]), [row, 0], sums)
        return sums
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def _input_norm_test(self, x: pl.Tensor[[T_DYN, 4096], pl.BF16], weight: pl.Tensor[[4096], pl.BF16], output: pl.Tensor[[T_DYN, 4096], pl.BF16], rstd: pl.Tensor[[T_DYN, 8], pl.FP32]) -> tuple[pl.Tensor[[T_DYN, 4096], pl.BF16], pl.Tensor[[T_DYN, 8], pl.FP32]]:
        rows: pl.Scalar[pl.INDEX] = pl.tensor.dim(x, 0)
        sums: pl.Tensor[[rows, 8], pl.FP32] = pl.tensor.create([rows, 8], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        sums_v1: pl.Tensor[[rows, 8], pl.FP32] = self._square_sum(x, sums)
        for row in pl.spmd(rows, name_hint="input_rms_inverse_spmd", allow_early_resolve=True):
            total: pl.Scalar[pl.FP32] = pl.tensor.read(sums_v1, [row, 0])
            total_vector: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.muls(pl.tensor.full([1, 8], dtype=pl.FP32, value=1.0), total)
            variance: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.adds(pl.tensor.muls(total_vector, 0.000244140625), 9.9999999999999995e-07)
            root_value: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.sqrt(variance)
            variance_bits: pl.Tensor[[1, 8], pl.INT32] = pl.tensor.reinterpret_view(variance, dtype=pl.INT32)
            approx_bits: pl.Tensor[[1, 8], pl.INT32] = pl.tensor.reinterpret_view(root_value, dtype=pl.INT32)
            x_bits: pl.Scalar[pl.INT64] = pl.cast(pl.tensor.read(variance_bits, [0, 0]), pl.INT64)
            y_bits: pl.Scalar[pl.INT64] = pl.cast(pl.tensor.read(approx_bits, [0, 0]), pl.INT64)
            fraction_unit: pl.Scalar[pl.INDEX] = 8388608
            if x_bits >= fraction_unit and x_bits < 2139095040:
                x_exp: pl.Scalar[pl.INT64] = x_bits // fraction_unit
                x_sig: pl.Scalar[pl.INT64] = x_bits % fraction_unit + fraction_unit
                for correction_step in pl.range(2):
                    y_exp: pl.Scalar[pl.INT64] = y_bits // fraction_unit
                    y_sig: pl.Scalar[pl.INT64] = y_bits % fraction_unit + fraction_unit
                    upper_mid: pl.Scalar[pl.INDEX] = 2 * y_sig + 1
                    upper_square: pl.Scalar[pl.INDEX] = upper_mid * upper_mid
                    x_upper: pl.Scalar[pl.INT64] = x_sig << x_exp - 2 * y_exp + 152
                    previous_bits: pl.Scalar[pl.INT64] = y_bits - 1
                    previous_exp: pl.Scalar[pl.INT64] = previous_bits // fraction_unit
                    previous_sig: pl.Scalar[pl.INT64] = previous_bits % fraction_unit + fraction_unit
                    lower_mid: pl.Scalar[pl.INDEX] = 2 * previous_sig + 1
                    lower_square: pl.Scalar[pl.INDEX] = lower_mid * lower_mid
                    x_lower: pl.Scalar[pl.INT64] = x_sig << x_exp - 2 * previous_exp + 152
                    if x_upper > upper_square or x_upper == upper_square and y_bits % 2 == 1:
                        y_bits: pl.Scalar[pl.INT64] = y_bits + 1
                    else:
                        if x_lower < lower_square or x_lower == lower_square and y_bits % 2 == 1:
                            y_bits: pl.Scalar[pl.INT64] = y_bits - 1
            rounded_bits: pl.Tensor[[1, 8], pl.INT32] = pl.tensor.full([1, 8], dtype=pl.INT32, value=0)
            for root_lane in pl.range(8):
                pl.tensor.write(rounded_bits, [0, root_lane], pl.cast(y_bits, pl.INT32))
            rounded_root: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.reinterpret_view(rounded_bits, dtype=pl.FP32)
            scalar_root_value: pl.Scalar[pl.FP32] = pl.tensor.read(rounded_root, [0, 0])
            scalar_inv: pl.Scalar[pl.FP32] = 1.0 / scalar_root_value
            inverse: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.muls(pl.tensor.full([1, 8], dtype=pl.FP32, value=1.0), scalar_inv)
            rstd: pl.Tensor[[T_DYN, 8], pl.FP32] = pl.tensor.assemble(rstd, inverse, [row, 0])
        for row_1 in pl.spmd(rows, name_hint="input_rms_apply_spmd", allow_early_resolve=True):
            apply_value: pl.Tensor[[1, 4096], pl.FP32] = pl.tensor.cast(pl.tensor.slice(x, [1, 4096], [row_1, 0]), target_type=pl.FP32, mode='round')
            w: pl.Tensor[[1, 4096], pl.FP32] = pl.tensor.cast(pl.tensor.reshape(weight, [1, 4096]), target_type=pl.FP32, mode='round')
            inv: pl.Scalar[pl.FP32] = pl.tensor.read(rstd, [row_1, 0])
            scaled: pl.Tensor[[1, 4096], pl.FP32] = pl.tensor.muls(apply_value, inv)
            result: pl.Tensor[[1, 4096], pl.FP32] = pl.tensor.col_expand_mul(scaled, w)
            output: pl.Tensor[[T_DYN, 4096], pl.BF16] = pl.tensor.assemble(output, pl.tensor.cast(result, target_type=pl.BF16, mode='rint'), [row_1, 0])
        return output, rstd
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def _o_proj_test(self, heads: pl.Tensor[[T_DYN, 32768], pl.BF16], wo_a: pl.Tensor[[8, 4096, 1024], pl.BF16, pl.TensorView(stride=[], layout=pl.TensorLayout.NZ)], wo_b: pl.Tensor[[8192, 4096], pl.INT8, pl.TensorView(stride=[], layout=pl.TensorLayout.NZ)], wo_b_scale: pl.Tensor[[4096], pl.FP32], start: pl.Tensor[[16, 8, 8], pl.INT32], projected: pl.Tensor[[T_DYN, 8192], pl.BF16], quantized: pl.Tensor[[T_DYN, 8192], pl.INT8], token_scale: pl.Tensor[[T_DYN, 1], pl.FP32], output: pl.Tensor[[T_DYN, 4096], pl.BF16]) -> pl.Tensor[[T_DYN, 4096], pl.BF16]:
        rows: pl.Scalar[pl.INDEX] = pl.tensor.dim(heads, 0)
        row_tiles: pl.Scalar[pl.INDEX] = (rows + 15) // 16
        accum: pl.Tensor[[row_tiles * pl.const(16, pl.INDEX), 8192], pl.FP32] = pl.tensor.create([row_tiles * 16, 8192], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        for group in pl.parallel(8):
            for block in pl.spmd(8, name_hint="oproj_a_spmd"):
                col: pl.Scalar[pl.INDEX] = block * 128
                for rb in pl.range(row_tiles):
                    row: pl.Scalar[pl.INDEX] = rb * 16
                    valid: pl.Scalar[pl.INDEX] = pl.min(16, rows - row)
                    first_block: pl.Scalar[pl.INDEX] = pl.max(pl.cast(pl.tensor.read(start, [rb, group, block]), pl.INDEX), 0)
                    first_k: pl.Scalar[pl.INDEX] = first_block * 16
                    x: pl.Tensor[[16, 16], pl.BF16, pl.TensorView(valid_shape=[valid, 16], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.slice(heads, [16, 16], [row, group * 4096 + first_k], [valid, 16])
                    w: pl.Tensor[[1, 16, 128], pl.BF16, pl.TensorView(stride=[], layout=pl.TensorLayout.NZ)] = pl.tensor.slice(wo_a, [1, 16, 128], [group, first_k, col])
                    acc: pl.Tensor[[1, 16, 128], pl.FP32] = pl.tensor.matmul(x, w, a_trans=False, b_trans=False, c_matrix_nz=False, out_dtype=pl.FP32)
                    for step in pl.range(1, 256):
                        k: pl.Scalar[pl.INDEX] = (first_block + step) % 256 * 16
                        x: pl.Tensor[[16, 16], pl.BF16, pl.TensorView(valid_shape=[valid, 16], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.slice(heads, [16, 16], [row, group * 4096 + k], [valid, 16])
                        w: pl.Tensor[[1, 16, 128], pl.BF16, pl.TensorView(stride=[], layout=pl.TensorLayout.NZ)] = pl.tensor.slice(wo_a, [1, 16, 128], [group, k, col])
                        acc: pl.Tensor[[1, 16, 128], pl.FP32] = pl.tensor.matmul_acc(acc, x, w, a_trans=False, b_trans=False)
                    accum: pl.Tensor[[row_tiles * pl.const(16, pl.INDEX), 8192], pl.FP32] = pl.tensor.assemble(accum, acc, [row, group * 1024 + col])
        for block_1 in pl.spmd(row_tiles * 8, name_hint="oproj_a_bf16_spmd"):
            row: pl.Scalar[pl.INDEX] = block_1 // 8 * 16
            col: pl.Scalar[pl.INDEX] = block_1 % 8 * 1024
            valid: pl.Scalar[pl.INDEX] = pl.min(16, rows - row)
            oa_value: pl.Tile[[16, 1024], pl.FP32, pl.TileView(valid_shape=[valid, 1024])] = pl.tile.load(accum, [row, col], [16, 1024], [valid, 1024])
            pl.tile.store(pl.tile.cast(oa_value, target_type=pl.BF16, mode='rint'), [row, col], projected)
        quant_rows: pl.Scalar[pl.INDEX] = (rows + 7) // 8
        for block_2 in pl.spmd(quant_rows, name_hint="oproj_quant_spmd"):
            row: pl.Scalar[pl.INDEX] = block_2 * 8
            valid: pl.Scalar[pl.INDEX] = pl.min(8, rows - row)
            first_quant: pl.Tile[[8, 1024], pl.BF16, pl.TileView(valid_shape=[valid, 1024])] = pl.tile.load(projected, [row, 0], [8, 1024], [valid, 1024])
            first_abs: pl.Tile[[8, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid, 1024])] = pl.tile.abs(pl.tile.cast(first_quant, target_type=pl.FP32, mode='round'))
            amax: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid, 1])] = pl.tile.row_max(first_abs, pl.tile.create([8, 1024], dtype=pl.FP32))
            for group_1 in pl.range(1, 8):
                q_bf16: pl.Tile[[8, 1024], pl.BF16, pl.TileView(valid_shape=[valid, 1024])] = pl.tile.load(projected, [row, group_1 * 1024], [8, 1024], [valid, 1024])
                q_fp32: pl.Tile[[8, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid, 1024])] = pl.tile.cast(q_bf16, target_type=pl.FP32, mode='round')
                amax: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid, 1])] = pl.tile.maximum(amax, pl.tile.row_max(pl.tile.abs(q_fp32), pl.tile.create([8, 1024], dtype=pl.FP32)))
            dequant: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid, 1])] = pl.tile.muls(amax, 0.007874015748031496)
            denominator: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid, 1])] = pl.tile.adds(amax, 0.0)
            for lane in pl.range(valid):
                magnitude: pl.Scalar[pl.FP32] = pl.tile.read(denominator, [lane, 0])
                if magnitude == 0.0:
                    pl.tile.write(denominator, [lane, 0], 1.0)
            multiplier: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid, 1])] = pl.tile.div(pl.tile.adds(pl.tile.muls(amax, 0.0), 127.0), denominator)
            pl.tile.store(pl.tile.set_validshape(dequant, valid, 1), [row, 0], token_scale)
            for group_2 in pl.range(8):
                col: pl.Scalar[pl.INDEX] = group_2 * 1024
                quant_bf16: pl.Tile[[8, 1024], pl.BF16, pl.TileView(valid_shape=[valid, 1024])] = pl.tile.load(projected, [row, col], [8, 1024], [valid, 1024])
                quant_scaled: pl.Tile[[8, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid, 1024])] = pl.tile.row_expand_mul(pl.tile.cast(quant_bf16, target_type=pl.FP32, mode='round'), multiplier)
                integer: pl.Tile[[8, 1024], pl.INT32, pl.Mem.Vec, pl.TileView(valid_shape=[valid, 1024])] = pl.tile.cast(quant_scaled, target_type=pl.INT32, mode='rint')
                half: pl.Tile[[8, 1024], pl.FP16, pl.Mem.Vec, pl.TileView(valid_shape=[valid, 1024])] = pl.tile.cast(integer, target_type=pl.FP16, mode='round')
                result: pl.Tile[[8, 1024], pl.INT8, pl.Mem.Vec, pl.TileView(valid_shape=[valid, 1024])] = pl.tile.cast(half, target_type=pl.INT8, mode='trunc')
                pl.tile.store(pl.tile.set_validshape(result, valid, 1024), [row, col], quantized)
        integer_accum: pl.Tensor[[row_tiles * pl.const(16, pl.INDEX), 4096], pl.INT32] = pl.tensor.create([row_tiles * 16, 4096], dtype=pl.INT32, layout=pl.TensorLayout.ND)
        for block_3 in pl.spmd(row_tiles * 32, name_hint="oproj_b_spmd"):
            row: pl.Scalar[pl.INDEX] = block_3 // 32 * 16
            col: pl.Scalar[pl.INDEX] = pl.max(block_3 % 32, 0) * 128
            valid: pl.Scalar[pl.INDEX] = pl.min(16, rows - row)
            b_acc: pl.Tensor[[16, 128], pl.INT32] = pl.tensor.create([16, 128], dtype=pl.INT32, layout=pl.TensorLayout.ND)
            for step_1 in pl.range(16):
                k: pl.Scalar[pl.INDEX] = step_1 * 512
                b_input: pl.Tensor[[16, 512], pl.INT8, pl.TensorView(valid_shape=[valid, 512], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.slice(quantized, [16, 512], [row, k], [valid, 512])
                b_weight: pl.Tensor[[512, 128], pl.INT8, pl.TensorView(stride=[], layout=pl.TensorLayout.NZ)] = pl.tensor.slice(wo_b, [512, 128], [k, col])
                b_acc: pl.Tensor[[16, 128], pl.INT32] = pl.tensor.matmul_acc(b_acc, b_input, b_weight, init_cond=step_1 == 0, a_trans=False, b_trans=False)
            integer_accum: pl.Tensor[[row_tiles * pl.const(16, pl.INDEX), 4096], pl.INT32] = pl.tensor.assemble(integer_accum, b_acc, [row, col])
        for block_4 in pl.spmd(row_tiles * 8, name_hint="oproj_b_dequant_spmd"):
            row: pl.Scalar[pl.INDEX] = block_4 // 8 * 16
            col: pl.Scalar[pl.INDEX] = block_4 % 8 * 512
            valid: pl.Scalar[pl.INDEX] = pl.min(16, rows - row)
            ob_integer: pl.Tile[[16, 512], pl.INT32, pl.TileView(valid_shape=[valid, 512])] = pl.tile.load(integer_accum, [row, col], [16, 512], [valid, 512])
            channel: pl.Tile[[1, 512], pl.FP32] = pl.tile.reshape(pl.tile.load(wo_b_scale, [col], [512], [512]), [1, 512])
            scale: pl.Tile[[16, 1], pl.FP32, pl.TileView(valid_shape=[valid, 1])] = pl.tile.load(token_scale, [row, 0], [16, 1], [valid, 1])
            coefficient_one: pl.Tile[[16, 512], pl.FP32, pl.Mem.Vec] = pl.tile.full([16, 512], dtype=pl.FP32, value=1.0)
            coefficient_channel: pl.Tile[[16, 512], pl.FP32, pl.Mem.Vec] = pl.tile.col_expand_mul(coefficient_one, channel)
            coefficient: pl.Tile[[16, 512], pl.FP32, pl.Mem.Vec] = pl.tile.row_expand_mul(coefficient_channel, scale)
            ob_scaled: pl.Tile[[16, 512], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid, 512])] = pl.tile.mul(pl.tile.cast(ob_integer, target_type=pl.FP32, mode='round'), coefficient)
            pl.tile.store(pl.tile.cast(ob_scaled, target_type=pl.BF16, mode='rint'), [row, col], output)
        return output
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def _read_device_max_seq_len(self, lengths: pl.Tensor[[B_DYN], pl.INT32], unused_host_value: pl.Scalar[pl.INT32]):
        maximum: pl.Scalar[pl.INDEX] = 0
        for batch in pl.range(pl.tensor.dim(lengths, 0)):
            maximum: pl.Scalar[pl.INDEX] = pl.max(maximum, pl.cast(pl.tensor.read(lengths, [batch]), pl.INDEX))
        return maximum
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def _wkv_test(self, x: pl.Tensor[[T_DYN, 4096], pl.BF16], weight: pl.Tensor[[512, 4096], pl.BF16], order: pl.Tensor[[32, 16], pl.INT32], output: pl.Tensor[[T_DYN, 512], pl.BF16]) -> pl.Tensor[[T_DYN, 512], pl.BF16]:
        rows: pl.Scalar[pl.INDEX] = pl.tensor.dim(x, 0)
        row_tiles: pl.Scalar[pl.INDEX] = (rows + 15) // 16
        accum: pl.Tensor[[row_tiles * pl.const(16, pl.INDEX), 512], pl.FP32] = pl.tensor.create([row_tiles * 16, 512], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        for worker in pl.spmd(row_tiles * 32, name_hint="wkv_matmul_spmd"):
            row: pl.Scalar[pl.INDEX] = worker // 32 * 16
            group: pl.Scalar[pl.INDEX] = worker % 32
            col: pl.Scalar[pl.INDEX] = group * 16
            valid: pl.Scalar[pl.INDEX] = pl.min(16, rows - row)
            tile: pl.Tensor[[16, 16], pl.FP32] = pl.tensor.create([16, 16], dtype=pl.FP32, layout=pl.TensorLayout.ND)
            for step in pl.range(16):
                k_block: pl.Scalar[pl.INT32] = pl.tensor.read(order, [group, step])
                offset: pl.Scalar[pl.INDEX] = pl.max(pl.cast(k_block, pl.INDEX), 0) * 256
                a: pl.Tensor[[16, 256], pl.BF16, pl.TensorView(valid_shape=[valid, 256], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.slice(x, [16, 256], [row, offset], [valid, 256])
                b: pl.Tensor[[16, 256], pl.BF16] = pl.tensor.slice(weight, [16, 256], [col, offset])
                tile: pl.Tensor[[16, 16], pl.FP32] = pl.tensor.matmul_acc(tile, a, b, init_cond=step == 0, a_trans=False, b_trans=True)
            accum: pl.Tensor[[row_tiles * pl.const(16, pl.INDEX), 512], pl.FP32] = pl.tensor.assemble(accum, tile, [row, col])
        for block in pl.spmd(row_tiles, name_hint="wkv_round_spmd"):
            out_row: pl.Scalar[pl.INDEX] = block * 16
            out_rows: pl.Scalar[pl.INDEX] = pl.min(16, rows - out_row)
            projected: pl.Tile[[16, 512], pl.FP32, pl.TileView(valid_shape=[out_rows, 512])] = pl.tile.load(accum, [out_row, 0], [16, 512], [out_rows, 512])
            rounded: pl.Tile[[16, 512], pl.BF16, pl.Mem.Vec, pl.TileView(valid_shape=[out_rows, 512])] = pl.tile.cast(projected, target_type=pl.BF16, mode='rint')
            pl.tile.store(rounded, [out_row, 0], output)
        return output
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def build_compact_row_offsets(self, bounds: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], lengths: pl.Tensor[[B_DYN], pl.INT32], offsets: pl.Tensor[[CSA_COMPACT_REQUESTS], pl.INT32]) -> pl.Tensor[[CSA_COMPACT_REQUESTS], pl.INT32]:
        # Run in an existing single-owner task; one offset per Native request.
        prefix: pl.Scalar[pl.INDEX] = pl.cast(0, pl.INDEX)
        for request in pl.range(pl.tensor.dim(lengths, 0)):
            begin: pl.Scalar[pl.INT32] = pl.tensor.read(bounds, [request])
            end: pl.Scalar[pl.INT32] = pl.tensor.read(bounds, [request + 1])
            length: pl.Scalar[pl.INT32] = pl.tensor.read(lengths, [request])
            start: pl.Scalar[pl.INT32] = length - (end - begin)
            pl.tensor.write(offsets, [request], pl.cast(prefix - pl.cast(start, pl.INDEX) // 4 - 1, pl.INT32))
            prefix: pl.Scalar[pl.INDEX] = prefix + pl.cast(length, pl.INDEX) // 4 - pl.cast(start, pl.INDEX) // 4
        return offsets
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def build_token_request(self, bounds: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], seq_lens: pl.Tensor[[B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32]) -> pl.Tensor[[T_DYN], pl.INT32]:
        # 把 query_start_loc 展开成逐 token 的请求号表。
        # 
        #         TND（变长请求）下 token // DECODE_SEQ 不再等于请求号：每个请求的 token 数
        #         各不相同。宿主侧已经有 query_start_loc（每请求的 token 起止，长度
        #         requests + 1），这里一次性展开成逐 token 的表，后面所有 kernel 直接查，
        #         不必各自重算。和 build_compact_row_offsets 一样跑在已有的单属主任务里。
        #         
        for token in pl.range(pl.tensor.dim(token_request, 0)):
            pl.tensor.write(token_request, [token], pl.cast(-1, pl.INT32))
        for request in pl.range(pl.tensor.dim(seq_lens, 0)):
            begin: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(bounds, [request]), pl.INDEX)
            end: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(bounds, [request + 1]), pl.INDEX)
            if pl.cast(pl.tensor.read(seq_lens, [request]), pl.INDEX) > 0:
                for token_1 in pl.range(begin, end):
                    pl.tensor.write(token_request, [token_1], pl.cast(request, pl.INT32))
        return token_request
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def load_compact_rope_rows(self, cos: pl.Tensor[[COMPRESSED_ROWS_DYN, 64], pl.FP32], sin: pl.Tensor[[COMPRESSED_ROWS_DYN, 64], pl.FP32], token_request: pl.Tensor[[T_DYN], pl.INT32], positions: pl.Tensor[[T_DYN], pl.INT64], offsets: pl.Tensor[[DECODE_CSA_C4_B_DYN], pl.INT32], begin: pl.Scalar[pl.INDEX], rows: pl.Scalar[pl.INDEX]):
        # Gather only closing rows into the consumer's existing 16-row UB tile.
        cosine: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.full([16, 64], dtype=pl.FP32, value=1.0)
        sine: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.full([16, 64], dtype=pl.FP32, value=0.0)
        for row in pl.range(rows):
            token: pl.Scalar[pl.INDEX] = begin + row
            position: pl.Scalar[pl.INT64] = pl.tensor.read(positions, [token])
            token_req: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(token_request, [token]), pl.INDEX)
            if token_req >= 0 and (position + 1) % 4 == 0:
                compact_row: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(offsets, [token_req]), pl.INDEX) + pl.cast((position + 1) // 4, pl.INDEX)
                if compact_row >= 0 and compact_row < pl.tensor.dim(cos, 0):
                    cosine: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.gather_row(cosine, cos, [row, 0], [compact_row, 0], [1, 64], transpose=False)
                    sine: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.gather_row(sine, sin, [row, 0], [compact_row, 0], [1, 64], transpose=False)
        return cosine, sine
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def compressor_ratio4_cache_write(self, kv: pl.Tensor[[T_DYN, 512], pl.FP32], pooled_kv: pl.Tensor[[384, 512], pl.FP32], norm_w: pl.Tensor[[512], pl.BF16], cos: pl.Tensor[[COMPRESSED_ROWS_DYN, 64], pl.FP32], sin: pl.Tensor[[COMPRESSED_ROWS_DYN, 64], pl.FP32], compact_offsets: pl.Tensor[[DECODE_CSA_C4_B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], cmp_kv_cache: pl.Tensor[[CMP_BLOCK_NUM_DYN, 32, 1, 512], pl.BF16], cmp_slot_mapping: pl.Tensor[[COMPRESSED_ROWS_DYN, 2], pl.INT32], compress_state: pl.Tensor[[MAIN_STATE_BLOCK_NUM_DYN, STATE_PAGE_ELEMENTS_DYN], pl.FP32], state_table: pl.Tensor[[B_DYN, STATE_TABLE_COLUMNS_DYN], pl.INT32], ape: pl.Tensor[[4, 1024], pl.FP32], kv_proj_pad: pl.Tensor[[384, 1024], pl.FP32], score_proj_pad: pl.Tensor[[384, 1024], pl.FP32], position_ids: pl.Tensor[[T_DYN], pl.INT64], seq_lens: pl.Tensor[[B_DYN], pl.INT32], query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], state_slot_mapping: pl.Tensor[[T_DYN, 2], pl.INT32], pool_tid: pl.Scalar[pl.TASK_ID], late_write_dep: pl.Scalar[pl.TASK_ID]):
        # State commit, RMSNorm + RoPE over the pooled rows, and the compressed KV cache write.
        b_dim: pl.Scalar[pl.INDEX] = pl.tensor.dim(state_table, 0)
        bs: pl.Scalar[pl.INDEX] = pl.tensor.dim(position_ids, 0)
        rms_blocks: pl.Scalar[pl.INDEX] = (bs + 16 - 1) // 16
        cmp_block_num: pl.Scalar[pl.INDEX] = pl.tensor.dim(cmp_kv_cache, 0)
        kv_flat: pl.Tensor[[T_DYN, 512], pl.FP32] = kv
        cmp_kv_cache_flat: pl.Tensor[[cmp_block_num * pl.const(32, pl.INDEX), 512], pl.BF16] = pl.tensor.reshape(cmp_kv_cache, [cmp_block_num * 32, 512])
        cmp4_kv_proj_pad: pl.Tensor[[384, 1024], pl.FP32] = kv_proj_pad
        cmp4_score_proj_pad: pl.Tensor[[384, 1024], pl.FP32] = score_proj_pad
        commit_workers: pl.Scalar[pl.INDEX] = pl.min(b_dim, 48)
        for commit_worker in pl.spmd(commit_workers, name_hint="compress_state_commit_spmd", deps=[pool_tid, late_write_dep]):
            for c_idx in pl.range(commit_worker, b_dim, commit_workers):
                commit_begin: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [c_idx]), pl.INDEX)
                commit_end: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [c_idx + 1]), pl.INDEX)
                for token in pl.range(commit_begin, commit_end):
                    state_page: pl.Scalar[pl.INT32] = pl.tensor.read(state_slot_mapping, [token, 0])
                    state_offset: pl.Scalar[pl.INT32] = pl.tensor.read(state_slot_mapping, [token, 1])
                    if pl.cast(state_page, pl.INDEX) >= 0 and pl.cast(state_offset, pl.INDEX) >= 0:
                        token_pos: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [token])
                        native_page: pl.Scalar[pl.INDEX] = pl.cast(state_page, pl.INDEX)
                        native_column: pl.Scalar[pl.INDEX] = pl.cast(state_offset, pl.INDEX) * 2048
                        ape_row: pl.Scalar[pl.INDEX] = pl.cast(token_pos % 4, pl.INDEX)
                        compress_state: pl.Tensor[[MAIN_STATE_BLOCK_NUM_DYN, STATE_PAGE_ELEMENTS_DYN], pl.FP32] = pl.tensor.assemble(compress_state, pl.tensor.slice(cmp4_kv_proj_pad, [1, 1024], [token, 0]), [native_page, native_column])
                        compress_state: pl.Tensor[[MAIN_STATE_BLOCK_NUM_DYN, STATE_PAGE_ELEMENTS_DYN], pl.FP32] = pl.tensor.assemble(compress_state, pl.tensor.add(pl.tensor.slice(cmp4_score_proj_pad, [1, 1024], [token, 0]), pl.tensor.slice(ape, [1, 1024], [ape_row, 0])), [native_page, native_column + 1024])
        normed_kv: pl.Tensor[[384, 512], pl.FP32] = pl.tensor.create([384, 512], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        norm_w_2d: pl.Tensor[[1, 512], pl.BF16] = pl.tensor.reshape(norm_w, [1, 512])
        with pl.spmd(rms_blocks, name_hint="rmsnorm_rope_cache_write_spmd", deps=[pool_tid, late_write_dep], allow_early_resolve=True) as cache_write_tid:
            rms_blk: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
            b0: pl.Scalar[pl.INDEX] = rms_blk * 16
            rms_blk_rows: pl.Scalar[pl.INDEX] = pl.min(16, bs - b0)
            _tuple_tmp: pl.Tuple[pl.Tensor[[16, 64], pl.FP32], pl.Tensor[[16, 64], pl.FP32]] = self.load_compact_rope_rows(cos, sin, token_request, position_ids, compact_offsets, b0, rms_blk_rows)
            cos_b: pl.Tensor[[16, 64], pl.FP32] = _tuple_tmp[0]
            sin_b: pl.Tensor[[16, 64], pl.FP32] = _tuple_tmp[1]
            rms_low: pl.Tensor[[16, 256], pl.FP32] = pl.tensor.slice(pooled_kv, [16, 256], [b0, 0])
            rms_high: pl.Tensor[[16, 256], pl.FP32] = pl.tensor.slice(pooled_kv, [16, 256], [b0, 256])
            folded4: pl.Tensor[[16, 256], pl.FP32] = pl.tensor.add(pl.tensor.mul(rms_low, rms_low), pl.tensor.mul(rms_high, rms_high))
            folded2: pl.Tensor[[16, 128], pl.FP32] = pl.tensor.add(pl.tensor.slice(folded4, [16, 128], [0, 0]), pl.tensor.slice(folded4, [16, 128], [0, 128]))
            folded1: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.add(pl.tensor.slice(folded2, [16, 64], [0, 0]), pl.tensor.slice(folded2, [16, 64], [0, 64]))
            square_sum: pl.Tensor[[16, 1], pl.FP32] = pl.tensor.row_sum(folded1)
            variance: pl.Tensor[[16, 1], pl.FP32] = pl.tensor.adds(pl.tensor.muls(square_sum, 0.001953125), 9.9999999999999995e-07)
            rms: pl.Tensor[[16, 1], pl.FP32] = pl.tensor.sqrt(variance)
            for k0 in pl.range(0, 448, 64):
                kv_norm_chunk: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.slice(pooled_kv, [16, 64], [b0, k0])
                gamma: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.cast(pl.tensor.slice(norm_w_2d, [1, 64], [0, k0]), target_type=pl.FP32, mode='round')
                normed_chunk: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.col_expand_mul(pl.tensor.row_expand_div(kv_norm_chunk, rms), gamma)
                normed_kv: pl.Tensor[[384, 512], pl.FP32] = pl.tensor.assemble(normed_kv, normed_chunk, [b0, k0])
            kv_rope_norm: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.slice(pooled_kv, [16, 64], [b0, 448])
            gamma_rope: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.cast(pl.tensor.slice(norm_w_2d, [1, 64], [0, 448]), target_type=pl.FP32, mode='round')
            rope_normed: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.col_expand_mul(pl.tensor.row_expand_div(kv_rope_norm, rms), gamma_rope)
            rope_ones: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.full([16, 64], dtype=pl.FP32, value=1.0)
            rope_index: pl.Tensor[[1, 64], pl.INT32] = pl.tensor.ci(pl.const(0, pl.INT32), [1, 64], dtype=pl.INT32, descending=False)
            rope_index_f: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.cast(rope_index, target_type=pl.FP32, mode='round')
            rope_col: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.col_expand_mul(rope_ones, rope_index_f)
            rope_dup_f: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.cast(pl.tensor.cast(pl.tensor.muls(rope_col, 0.5), target_type=pl.INT32, mode='trunc'), target_type=pl.FP32, mode='round')
            rope_lane: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.sub(rope_col, pl.tensor.muls(rope_dup_f, 2.0))
            rope_swap_idx: pl.Tensor[[16, 64], pl.INT32] = pl.tensor.cast(pl.tensor.sub(pl.tensor.adds(rope_col, 1.0), pl.tensor.muls(rope_lane, 2.0)), target_type=pl.INT32, mode='round')
            swapped: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.gather(rope_normed, rope_swap_idx, dim=-1)
            sin_signed: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.mul(sin_b, pl.tensor.subs(pl.tensor.muls(rope_lane, 2.0), 1.0))
            rope_rot: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.add(pl.tensor.mul(rope_normed, cos_b), pl.tensor.mul(swapped, sin_signed))
            normed_kv: pl.Tensor[[384, 512], pl.FP32] = pl.tensor.assemble(normed_kv, rope_rot, [b0, 448])
            for inner in pl.range(rms_blk_rows):
                token: pl.Scalar[pl.INDEX] = b0 + inner
                token_pos: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [token])
                token_req: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(token_request, [token]), pl.INDEX)
                if token_req >= 0 and (token_pos + 1) % 4 == 0:
                    metadata_row: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(compact_offsets, [token_req]), pl.INDEX) + pl.cast((token_pos + 1) // 4, pl.INDEX)
                    compact_rows: pl.Scalar[pl.INDEX] = pl.tensor.dim(cmp_slot_mapping, 0)
                    if metadata_row >= 0 and metadata_row < compact_rows:
                        cache_page: pl.Scalar[pl.INT32] = pl.tensor.read(cmp_slot_mapping, [metadata_row, 0])
                        cache_offset: pl.Scalar[pl.INT32] = pl.tensor.read(cmp_slot_mapping, [metadata_row, 1])
                        if pl.cast(cache_page, pl.INDEX) >= 0 and pl.cast(cache_offset, pl.INDEX) >= 0:
                            cache_row: pl.Scalar[pl.INDEX] = pl.cast(cache_page, pl.INDEX) * 32 + pl.cast(cache_offset, pl.INDEX)
                            kv_row_fp32: pl.Tensor[[1, 512], pl.FP32] = pl.tensor.slice(normed_kv, [1, 512], [token, 0])
                            kv_flat: pl.Tensor[[T_DYN, 512], pl.FP32] = pl.tensor.assemble(kv_flat, kv_row_fp32, [token, 0])
                            cmp_kv_cache_flat: pl.Tensor[[cmp_block_num * pl.const(32, pl.INDEX), 512], pl.BF16] = pl.tensor.assemble(cmp_kv_cache_flat, pl.tensor.cast(kv_row_fp32, target_type=pl.BF16, mode='rint'), [cache_row, 0])
        return cache_write_tid
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def compressor_ratio4_pool_projected(self, compress_state: pl.Tensor[[MAIN_STATE_BLOCK_NUM_DYN, STATE_PAGE_ELEMENTS_DYN], pl.FP32], state_table: pl.Tensor[[B_DYN, STATE_TABLE_COLUMNS_DYN], pl.INT32], ape: pl.Tensor[[4, 1024], pl.FP32], position_ids: pl.Tensor[[T_DYN], pl.INT64], seq_lens: pl.Tensor[[B_DYN], pl.INT32], query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], pooled_kv: pl.Tensor[[384, 512], pl.FP32], kv_proj_pad: pl.Tensor[[384, 1024], pl.FP32], score_proj_pad: pl.Tensor[[384, 1024], pl.FP32], late_dep: pl.Scalar[pl.TASK_ID]):
        # Pool full-stream projected values and scores against Native paged state.
        b_dim: pl.Scalar[pl.INDEX] = pl.tensor.dim(state_table, 0)
        cmp4_kv_proj_pad: pl.Tensor[[384, 1024], pl.FP32] = kv_proj_pad
        cmp4_score_proj_pad: pl.Tensor[[384, 1024], pl.FP32] = score_proj_pad
        _kv_score_tid: pl.Scalar[pl.TASK_ID] = late_dep
        pool_workers: pl.Scalar[pl.INDEX] = pl.min(b_dim, 48)
        with pl.spmd(pool_workers, name_hint="scatter_softmax_pool_spmd", deps=[_kv_score_tid], allow_early_resolve=True) as pool_tid:
            pool_worker: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
            for c_idx in pl.range(pool_worker, b_dim, pool_workers):
                request_begin: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [c_idx]), pl.INDEX)
                request_end: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [c_idx + 1]), pl.INDEX)
                first_pos_b: pl.Scalar[pl.INDEX] = pl.cast(0, pl.INDEX)
                if request_begin < request_end:
                    first_pos_b: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(position_ids, [request_begin]), pl.INDEX)
                c_len: pl.Scalar[pl.INT32] = pl.tensor.read(seq_lens, [c_idx])
                request_begin_v1: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [c_idx]), pl.INDEX)
                request_end_v1: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [c_idx + 1]), pl.INDEX)
                for token in pl.range(request_begin_v1, request_end_v1):
                    token_pos: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [token])
                    pooled_kv: pl.Tensor[[384, 512], pl.FP32] = pl.tensor.assemble(pooled_kv, pl.tensor.full([1, 512], dtype=pl.FP32, value=0.0), [token, 0])
                    if pl.cast(c_len, pl.INDEX) > 0 and (token_pos + 1) % 4 == 0:
                        window_start: pl.Scalar[pl.INT64] = token_pos - 8 + 1
                        for h0 in pl.range(0, 512, 512):
                            window_values: pl.Tile[[8, 512], pl.FP32, pl.Mem.Vec] = pl.tile.full([8, 512], dtype=pl.FP32, value=0.0)
                            window_scores: pl.Tile[[8, 512], pl.FP32, pl.Mem.Vec] = pl.tile.full([8, 512], dtype=pl.FP32, value=-3.4028234663852886e+38)
                            for state_idx in pl.range(8):
                                logical_pos: pl.Scalar[pl.INT64] = window_start + state_idx
                                value: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec] = pl.tile.full([1, 512], dtype=pl.FP32, value=0.0)
                                score: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec] = pl.tile.full([1, 512], dtype=pl.FP32, value=-3.4028234663852886e+38)
                                state_half: pl.Scalar[pl.INDEX] = 0
                                if state_idx >= 4:
                                    state_half: pl.Scalar[pl.INDEX] = 512
                                if logical_pos >= 0 and logical_pos < first_pos_b:
                                    score: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec] = pl.tile.full([1, 512], dtype=pl.FP32, value=0.0)
                                    history_page: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(state_table, [c_idx, logical_pos // 2]), pl.INDEX)
                                    if history_page >= 0:
                                        history_column: pl.Scalar[pl.INDEX] = pl.cast(logical_pos % 2, pl.INDEX) * 2048 + state_half + h0
                                        value: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec] = pl.tile.load(compress_state, [history_page, history_column], [1, 512], [1, 512])
                                        score: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec] = pl.tile.load(compress_state, [history_page, history_column + 1024], [1, 512], [1, 512])
                                if logical_pos >= first_pos_b:
                                    if logical_pos <= token_pos:
                                        overlay_token: pl.Scalar[pl.INDEX] = request_begin_v1 + logical_pos - first_pos_b
                                        ape_row: pl.Scalar[pl.INDEX] = pl.cast(logical_pos % 4, pl.INDEX)
                                        value: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec] = pl.tile.load(cmp4_kv_proj_pad, [overlay_token, state_half + h0], [1, 512], [1, 512])
                                        score: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.load(cmp4_score_proj_pad, [overlay_token, state_half + h0], [1, 512], [1, 512]), pl.tile.load(ape, [ape_row, state_half + h0], [1, 512], [1, 512]))
                                native_row: pl.Scalar[pl.INDEX] = state_idx % 4 * 2 + state_idx // 4
                                window_values: pl.Tile[[8, 512], pl.FP32, pl.Mem.Vec] = pl.tile.assemble(window_values, value, [native_row, 0])
                                window_scores: pl.Tile[[8, 512], pl.FP32, pl.Mem.Vec] = pl.tile.assemble(window_scores, score, [native_row, 0])
                            max4: pl.Tile[[4, 512], pl.FP32, pl.Mem.Vec] = pl.tile.maximum(pl.tile.slice(window_scores, [4, 512], [0, 0]), pl.tile.slice(window_scores, [4, 512], [4, 0]))
                            max2: pl.Tile[[2, 512], pl.FP32, pl.Mem.Vec] = pl.tile.maximum(pl.tile.slice(max4, [2, 512], [0, 0]), pl.tile.slice(max4, [2, 512], [2, 0]))
                            maximum: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec] = pl.tile.maximum(pl.tile.slice(max2, [1, 512], [0, 0]), pl.tile.slice(max2, [1, 512], [1, 0]))
                            probability: pl.Tile[[8, 512], pl.FP32, pl.Mem.Vec] = pl.tile.exp(pl.tile.col_expand_sub(window_scores, maximum))
                            sum4: pl.Tile[[4, 512], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.slice(probability, [4, 512], [0, 0]), pl.tile.slice(probability, [4, 512], [4, 0]))
                            sum2: pl.Tile[[2, 512], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.slice(sum4, [2, 512], [0, 0]), pl.tile.slice(sum4, [2, 512], [2, 0]))
                            total: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.slice(sum2, [1, 512], [0, 0]), pl.tile.slice(sum2, [1, 512], [1, 0]))
                            probability_v1: pl.Tile[[8, 512], pl.FP32, pl.Mem.Vec] = pl.tile.col_expand_div(probability, total)
                            weighted: pl.Tile[[8, 512], pl.FP32, pl.Mem.Vec] = pl.tile.mul(window_values, probability_v1)
                            weighted4: pl.Tile[[4, 512], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.slice(weighted, [4, 512], [0, 0]), pl.tile.slice(weighted, [4, 512], [4, 0]))
                            weighted2: pl.Tile[[2, 512], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.slice(weighted4, [2, 512], [0, 0]), pl.tile.slice(weighted4, [2, 512], [2, 0]))
                            pooled_row: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.slice(weighted2, [1, 512], [0, 0]), pl.tile.slice(weighted2, [1, 512], [1, 0]))
                            pl.tile.store(pooled_row, [token, h0], pooled_kv)
        return pool_tid, _kv_score_tid
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def native_compressor_column_group(self, bounds: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], tokens: pl.Scalar[pl.INDEX], head_dim: pl.Scalar[pl.INDEX]):
        first: pl.Scalar[pl.INT32] = pl.tensor.read(bounds, [1]) - pl.tensor.read(bounds, [0])
        deviation: pl.Scalar[pl.INT32] = pl.cast(0, pl.INT32)
        for request in pl.range(1, pl.tensor.dim(bounds, 0) - 1):
            length: pl.Scalar[pl.INT32] = pl.tensor.read(bounds, [request + 1]) - pl.tensor.read(bounds, [request])
            delta: pl.Scalar[pl.INT32] = length - first
            deviation: pl.Scalar[pl.INT32] = deviation + delta * delta
        group: pl.Scalar[pl.INDEX] = pl.cast(64, pl.INDEX)
        capacity: pl.Scalar[pl.INDEX] = 128 * (24 // (head_dim // 64))
        if pl.cast(deviation, pl.INDEX) == 0 and tokens <= capacity:
            if head_dim == 512:
                group: pl.Scalar[pl.INDEX] = pl.cast(32, pl.INDEX)
            else:
                group: pl.Scalar[pl.INDEX] = pl.cast(16, pl.INDEX)
        return group
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def compressor_ratio4_project(self, x: pl.Tensor[[T_DYN, 4096], pl.BF16], wkv: pl.Tensor[[1024, 4096], pl.BF16], wgate: pl.Tensor[[1024, 4096], pl.BF16], kv_proj_pad: pl.Tensor[[384, 1024], pl.FP32], score_proj_pad: pl.Tensor[[384, 1024], pl.FP32], query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], late_dep: pl.Scalar[pl.TASK_ID]):
        # Project token-local compressor values and scores in FP32.
        bs: pl.Scalar[pl.INDEX] = pl.tensor.dim(x, 0)
        t_matmul: pl.Scalar[pl.INDEX] = (bs + 64 - 1) // 64 * 64
        x_flat: pl.Tensor[[T_DYN, 4096], pl.BF16] = x
        cmp4_kv_proj_pad: pl.Tensor[[384, 1024], pl.FP32] = kv_proj_pad
        cmp4_score_proj_pad: pl.Tensor[[384, 1024], pl.FP32] = score_proj_pad
        with pl.spmd(24, name_hint="kv_score_proj_spmd", deps=[late_dep]) as _kv_score_tid:
            kv_worker: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
            native_column_group: pl.Scalar[pl.INDEX] = self.native_compressor_column_group(query_start_loc, bs, 512)
            for idx in pl.range(kv_worker, t_matmul * 1024 // 2048, 24):
                global_row0: pl.Scalar[pl.INDEX] = idx // 32 * 64
                o0: pl.Scalar[pl.INDEX] = idx % 32 * 32
                x_rows: pl.Scalar[pl.INDEX] = pl.min(64, bs - global_row0)
                kv_acc: pl.Tensor[[64, 32], pl.FP32] = pl.tensor.create([64, 32], dtype=pl.FP32, layout=pl.TensorLayout.ND)
                score_acc: pl.Tensor[[64, 32], pl.FP32] = pl.tensor.create([64, 32], dtype=pl.FP32, layout=pl.TensorLayout.ND)
                for kb in pl.pipeline(32, stage=2):
                    k0: pl.Scalar[pl.INDEX] = (kb * 128 + o0 % 512 // native_column_group * 256) % 4096
                    x_tile: pl.Tensor[[64, 128], pl.BF16, pl.TensorView(valid_shape=[x_rows, 128], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.slice(x_flat, [64, 128], [global_row0, k0], [x_rows, 128])
                    wkv_tile: pl.Tensor[[32, 128], pl.BF16] = pl.tensor.slice(wkv, [32, 128], [o0, k0])
                    wgate_tile: pl.Tensor[[32, 128], pl.BF16] = pl.tensor.slice(wgate, [32, 128], [o0, k0])
                    if kb == 0:
                        kv_acc: pl.Tensor[[64, 32], pl.FP32] = pl.tensor.matmul(x_tile, wkv_tile, a_trans=False, b_trans=True, c_matrix_nz=False, out_dtype=pl.FP32)
                        score_acc: pl.Tensor[[64, 32], pl.FP32] = pl.tensor.matmul(x_tile, wgate_tile, a_trans=False, b_trans=True, c_matrix_nz=False, out_dtype=pl.FP32)
                    else:
                        kv_acc: pl.Tensor[[64, 32], pl.FP32] = pl.tensor.matmul_acc(kv_acc, x_tile, wkv_tile, a_trans=False, b_trans=True)
                        score_acc: pl.Tensor[[64, 32], pl.FP32] = pl.tensor.matmul_acc(score_acc, x_tile, wgate_tile, a_trans=False, b_trans=True)
                cmp4_kv_proj_pad: pl.Tensor[[384, 1024], pl.FP32] = pl.tensor.assemble(cmp4_kv_proj_pad, kv_acc, [global_row0, o0])
                cmp4_score_proj_pad: pl.Tensor[[384, 1024], pl.FP32] = pl.tensor.assemble(cmp4_score_proj_pad, score_acc, [global_row0, o0])
        return _kv_score_tid
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def compressor_ratio4_pool(self, x: pl.Tensor[[T_DYN, 4096], pl.BF16], compress_state: pl.Tensor[[MAIN_STATE_BLOCK_NUM_DYN, STATE_PAGE_ELEMENTS_DYN], pl.FP32], state_table: pl.Tensor[[B_DYN, STATE_TABLE_COLUMNS_DYN], pl.INT32], wkv: pl.Tensor[[1024, 4096], pl.BF16], wgate: pl.Tensor[[1024, 4096], pl.BF16], ape: pl.Tensor[[4, 1024], pl.FP32], position_ids: pl.Tensor[[T_DYN], pl.INT64], seq_lens: pl.Tensor[[B_DYN], pl.INT32], query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], pooled_kv: pl.Tensor[[384, 512], pl.FP32], kv_proj_pad: pl.Tensor[[384, 1024], pl.FP32], score_proj_pad: pl.Tensor[[384, 1024], pl.FP32], late_dep: pl.Scalar[pl.TASK_ID]):
        # Project, then pool and commit the token stream.
        projection_tid: pl.Scalar[pl.TASK_ID] = self.compressor_ratio4_project(x, wkv, wgate, kv_proj_pad, score_proj_pad, query_start_loc, late_dep)
        _tuple_tmp: pl.Tuple[pl.Scalar[pl.TASK_ID], pl.Scalar[pl.TASK_ID]] = self.compressor_ratio4_pool_projected(compress_state, state_table, ape, position_ids, seq_lens, query_start_loc, pooled_kv, kv_proj_pad, score_proj_pad, projection_tid)
        pool_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp[0]
        projection_ready_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp[1]
        return pool_tid, projection_ready_tid
    @pl.function(type=pl.FunctionType.Inline)
    def compressor_ratio4(self, x: pl.Tensor[[T_DYN, 4096], pl.BF16], kv: pl.Tensor[[T_DYN, 512], pl.FP32], compress_state: pl.Tensor[[MAIN_STATE_BLOCK_NUM_DYN, STATE_PAGE_ELEMENTS_DYN], pl.FP32], state_table: pl.Tensor[[B_DYN, STATE_TABLE_COLUMNS_DYN], pl.INT32], wkv: pl.Tensor[[1024, 4096], pl.BF16], wgate: pl.Tensor[[1024, 4096], pl.BF16], ape: pl.Tensor[[4, 1024], pl.FP32], norm_w: pl.Tensor[[512], pl.BF16], cos: pl.Tensor[[COMPRESSED_ROWS_DYN, 64], pl.FP32], sin: pl.Tensor[[COMPRESSED_ROWS_DYN, 64], pl.FP32], compact_offsets: pl.Tensor[[DECODE_CSA_C4_B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], cmp_kv_cache: pl.Tensor[[CMP_BLOCK_NUM_DYN, 32, 1, 512], pl.BF16], position_ids: pl.Tensor[[T_DYN], pl.INT64], seq_lens: pl.Tensor[[B_DYN], pl.INT32], query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], cmp_slot_mapping: pl.Tensor[[COMPRESSED_ROWS_DYN, 2], pl.INT32], state_slot_mapping: pl.Tensor[[T_DYN, 2], pl.INT32], late_dep: pl.Scalar[pl.TASK_ID]) -> tuple[pl.Tensor[[T_DYN, 512], pl.FP32], pl.Scalar[pl.TASK_ID], pl.Scalar[pl.TASK_ID]]:
        pooled_kv: pl.Tensor[[384, 512], pl.FP32] = pl.tensor.create([384, 512], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        kv_proj_pad: pl.Tensor[[384, 1024], pl.FP32] = pl.tensor.create([384, 1024], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        score_proj_pad: pl.Tensor[[384, 1024], pl.FP32] = pl.tensor.create([384, 1024], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        _tuple_tmp: pl.Tuple[pl.Scalar[pl.TASK_ID], pl.Scalar[pl.TASK_ID]] = self.compressor_ratio4_pool(x, compress_state, state_table, wkv, wgate, ape, position_ids, seq_lens, query_start_loc, pooled_kv, kv_proj_pad, score_proj_pad, late_dep)
        pool_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp[0]
        kv_score_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp[1]
        cache_write_tid: pl.Scalar[pl.TASK_ID] = self.compressor_ratio4_cache_write(kv, pooled_kv, norm_w, cos, sin, compact_offsets, token_request, cmp_kv_cache, cmp_slot_mapping, compress_state, state_table, ape, kv_proj_pad, score_proj_pad, position_ids, seq_lens, query_start_loc, state_slot_mapping, pool_tid, pool_tid)
        return kv, cache_write_tid, kv_score_tid
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def indexer_qr_hadamard_mm(self, x: pl.Tensor[[T_DYN, 4096], pl.BF16], qr_bf16: pl.Tensor[[27648, 128], pl.BF16], hadamard: pl.Tensor[[128, 128], pl.BF16], qr_hadamard_i8: pl.Tensor[[27648, 128], pl.INT8], qr_hadamard_scale_dq: pl.Tensor[[27648, 1], pl.FP32], qh_mm_dep: pl.Scalar[pl.TASK_ID]) -> tuple[pl.Scalar[pl.TASK_ID], pl.Scalar[pl.TASK_ID]]:
        # q @ hadamard and its INT8 quant, fenced behind the caller's cube ordering.
        bs: pl.Scalar[pl.INDEX] = pl.tensor.dim(x, 0)
        bs_heads: pl.Scalar[pl.INDEX] = bs * 64
        qh_acc_gm: pl.Tensor[[bs_heads, 128], pl.FP32] = pl.tensor.create([bs_heads, 128], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        with pl.spmd(24, name_hint="qr_hadamard_matmul_spmd", deps=[qh_mm_dep], allow_early_resolve=True) as qh_mm_tid:
            qh_worker: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
            qh_hadamard: pl.Tensor[[128, 128], pl.BF16] = pl.tensor.slice(hadamard, [128, 128], [0, 0])
            for idx in pl.range(qh_worker, bs_heads // 64, 24):
                o0: pl.Scalar[pl.INDEX] = idx * 64
                qh_acc: pl.Tensor[[64, 128], pl.FP32] = pl.tensor.matmul(pl.tensor.slice(qr_bf16, [64, 128], [o0, 0]), qh_hadamard, a_trans=False, b_trans=False, c_matrix_nz=False, out_dtype=pl.FP32)
                qh_acc_gm: pl.Tensor[[bs_heads, 128], pl.FP32] = pl.tensor.assemble(qh_acc_gm, qh_acc, [o0, 0])
        with pl.spmd(48, name_hint="qr_hadamard_quant_spmd", allow_early_resolve=True) as qh_quant_tid:
            qh_quant_worker: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
            for idx_1 in pl.range(qh_quant_worker, bs_heads // 64, 48):
                o0: pl.Scalar[pl.INDEX] = idx_1 * 64
                qh_full_f32: pl.Tensor[[64, 128], pl.FP32] = pl.tensor.slice(qh_acc_gm, [64, 128], [o0, 0])
                qh_full_f32_v1: pl.Tensor[[64, 128], pl.FP32] = pl.tensor.cast(pl.tensor.cast(qh_full_f32, target_type=pl.BF16, mode='rint'), target_type=pl.FP32, mode='round')
                qh_full_f32_v2: pl.Tensor[[64, 128], pl.FP32] = pl.tensor.cast(pl.tensor.cast(pl.tensor.muls(qh_full_f32_v1, 0.088388347648318447), target_type=pl.BF16, mode='rint'), target_type=pl.FP32, mode='round')
                qh_amax: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.full([1, 64], dtype=pl.FP32, value=0.0001)
                for h0 in pl.range(0, 128, 64):
                    qh_a_f32: pl.Tensor[[64, 64], pl.FP32] = pl.tensor.slice(qh_full_f32_v2, [64, 64], [0, h0])
                    qh_a_neg: pl.Tensor[[64, 64], pl.FP32] = pl.tensor.neg(qh_a_f32)
                    qh_a_abs: pl.Tensor[[64, 64], pl.FP32] = pl.tensor.maximum(qh_a_f32, qh_a_neg)
                    qh_a_max_col: pl.Tensor[[64, 1], pl.FP32] = pl.tensor.row_max(qh_a_abs)
                    qh_a_max: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.reshape(qh_a_max_col, [1, 64])
                    qh_amax: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.maximum(qh_amax, qh_a_max)
                qh_scale_numerator: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.full([1, 64], dtype=pl.FP32, value=127.0)
                qh_scale_quant_row: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.div(qh_scale_numerator, qh_amax)
                qh_scale_recip: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.recip(qh_scale_quant_row)
                qh_scale_dq: pl.Tensor[[64, 1], pl.FP32] = pl.tensor.reshape(qh_scale_recip, [64, 1])
                qr_hadamard_scale_dq: pl.Tensor[[27648, 1], pl.FP32] = pl.tensor.assemble(qr_hadamard_scale_dq, pl.tensor.cast(pl.tensor.cast(qh_scale_dq, target_type=pl.FP16, mode='rint'), target_type=pl.FP32, mode='round'), [o0, 0])
                qh_scale_quant: pl.Tensor[[64, 1], pl.FP32] = pl.tensor.reshape(qh_scale_quant_row, [64, 1])
                qh_q_scaled: pl.Tensor[[64, 128], pl.FP32] = pl.tensor.row_expand_mul(qh_full_f32_v2, qh_scale_quant)
                qh_q_i32: pl.Tensor[[64, 128], pl.INT32] = pl.tensor.cast(qh_q_scaled, target_type=pl.INT32, mode='rint')
                qh_q_half: pl.Tensor[[64, 128], pl.FP16] = pl.tensor.cast(qh_q_i32, target_type=pl.FP16, mode='round')
                qh_i8: pl.Tensor[[64, 128], pl.INT8] = pl.tensor.cast(qh_q_half, target_type=pl.INT8, mode='trunc')
                qr_hadamard_i8: pl.Tensor[[27648, 128], pl.INT8] = pl.tensor.assemble(qr_hadamard_i8, qh_i8, [o0, 0])
        return qh_mm_tid, qh_quant_tid
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def indexer_qr_rope(self, x: pl.Tensor[[T_DYN, 4096], pl.BF16], qr: pl.Tensor[[T_DYN, 1024], pl.INT8], qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32], wq_b: pl.Tensor[[1024, 8192], pl.INT8], wq_b_scale: pl.Tensor[[8192], pl.FP32], cos: pl.Tensor[[T_DYN, 64], pl.FP32], sin: pl.Tensor[[T_DYN, 64], pl.FP32], qr_bf16: pl.Tensor[[27648, 128], pl.BF16]) -> pl.Scalar[pl.TASK_ID]:
        # Indexer query projection, dequant and RoPE -- everything before the hadamard.
        bs: pl.Scalar[pl.INDEX] = pl.tensor.dim(x, 0)
        row_blocks: pl.Scalar[pl.INDEX] = (bs + 64 - 1) // 64
        qr_acc_pad: pl.Tensor[[448, 8192], pl.INT32] = pl.tensor.create([448, 8192], dtype=pl.INT32, layout=pl.TensorLayout.ND)
        with pl.spmd(24, name_hint="idx_qr_proj_matmul_spmd", allow_early_resolve=True) as idx_qr_mm_tid:
            qr_proj_worker: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
            for qr_col in pl.range(qr_proj_worker, 32, 24):
                o_base: pl.Scalar[pl.INDEX] = qr_col * 256
                wq_tile: pl.Tensor[[1024, 256], pl.INT8] = pl.tensor.slice(wq_b, [1024, 256], [0, o_base])
                for qr_rb in pl.range(row_blocks):
                    qr_r0: pl.Scalar[pl.INDEX] = qr_rb * 64
                    qr_rows: pl.Scalar[pl.INDEX] = pl.min(64, bs - qr_r0)
                    qr_tile: pl.Tensor[[64, 1024], pl.INT8, pl.TensorView(valid_shape=[qr_rows, 1024], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.slice(qr, [64, 1024], [qr_r0, 0], [qr_rows, 1024])
                    qr_acc: pl.Tensor[[64, 256], pl.INT32] = pl.tensor.matmul(qr_tile, wq_tile, a_trans=False, b_trans=False, c_matrix_nz=False, out_dtype=pl.INT32)
                    qr_acc_pad: pl.Tensor[[448, 8192], pl.INT32] = pl.tensor.assemble(qr_acc_pad, qr_acc, [qr_r0, o_base])
        qr_bf16_2d: pl.Tensor[[432, 8192], pl.BF16] = pl.tensor.reshape(qr_bf16, [432, 8192])
        dq_rope_units: pl.Scalar[pl.INDEX] = (bs + 8 - 1) // 8 * 16
        dq_rope_workers: pl.Scalar[pl.INDEX] = pl.min(dq_rope_units, 48)
        for dq_rope_worker in pl.spmd(dq_rope_workers, name_hint="idx_qr_dequant_rope_spmd", allow_early_resolve=True):
            sw_ones: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.full([8, 64], dtype=pl.FP32, value=1.0)
            sw_index: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.cast(pl.tensor.ci(pl.const(0, pl.INT32), [1, 64], dtype=pl.INT32, descending=False), target_type=pl.FP32, mode='round')
            sw_col: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.col_expand_mul(sw_ones, sw_index)
            sw_dup_f: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.cast(pl.tensor.cast(pl.tensor.muls(sw_col, 0.5), target_type=pl.INT32, mode='trunc'), target_type=pl.FP32, mode='round')
            sw_lane: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.sub(sw_col, pl.tensor.muls(sw_dup_f, 2.0))
            rope_swap_idx: pl.Tensor[[8, 64], pl.INT32] = pl.tensor.cast(pl.tensor.sub(pl.tensor.adds(sw_col, 1.0), pl.tensor.muls(sw_lane, 2.0)), target_type=pl.INT32, mode='round')
            for dq_unit in pl.range(dq_rope_worker, dq_rope_units, dq_rope_workers):
                hg: pl.Scalar[pl.INDEX] = dq_unit % 16 * 4
                dq_t0: pl.Scalar[pl.INDEX] = dq_unit // 16 * 8
                if dq_t0 + 8 <= bs:
                    qr_scale_tile: pl.Tensor[[8, 1], pl.FP32] = pl.tensor.slice(qr_scale, [8, 1], [dq_t0, 0])
                    cos_tile: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.slice(cos, [8, 64], [dq_t0, 0])
                    sin_tile: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.slice(sin, [8, 64], [dq_t0, 0])
                    for h_inner in pl.pipeline(4, stage=2):
                        h0: pl.Scalar[pl.INDEX] = (hg + h_inner) * 128
                        wq_scale: pl.Tensor[[1, 128], pl.FP32] = pl.tensor.reshape(pl.tensor.slice(wq_b_scale, [128], [h0]), [1, 128])
                        acc_fp32: pl.Tensor[[8, 128], pl.FP32] = pl.tensor.cast(pl.tensor.slice(qr_acc_pad, [8, 128], [dq_t0, h0]), target_type=pl.FP32, mode='none')
                        qr_dequant_scale: pl.Tensor[[8, 128], pl.FP32] = pl.tensor.col_expand_mul(pl.tensor.row_expand_mul(pl.tensor.full([8, 128], dtype=pl.FP32, value=1.0), qr_scale_tile), wq_scale)
                        qr_dequant: pl.Tensor[[8, 128], pl.FP32] = pl.tensor.mul(acc_fp32, qr_dequant_scale)
                        qr_dequant_v1: pl.Tensor[[8, 128], pl.FP32] = pl.tensor.cast(pl.tensor.cast(qr_dequant, target_type=pl.BF16, mode='rint'), target_type=pl.FP32, mode='round')
                        qr_nope_bf16: pl.Tensor[[8, 64], pl.BF16] = pl.tensor.cast(pl.tensor.slice(qr_dequant_v1, [8, 64], [0, 0]), target_type=pl.BF16, mode='rint')
                        qr_rope_slice: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.slice(qr_dequant_v1, [8, 64], [0, 64])
                        qr_swapped: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.gather(qr_rope_slice, rope_swap_idx, dim=-1)
                        rope_rot: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.add(pl.tensor.mul(qr_rope_slice, cos_tile), pl.tensor.mul(qr_swapped, sin_tile))
                        rope_bf16: pl.Tensor[[8, 64], pl.BF16] = pl.tensor.cast(rope_rot, target_type=pl.BF16, mode='rint')
                        qr_bf16_2d: pl.Tensor[[432, 8192], pl.BF16] = pl.tensor.assemble(qr_bf16_2d, qr_nope_bf16, [dq_t0, h0])
                        qr_bf16_2d: pl.Tensor[[432, 8192], pl.BF16] = pl.tensor.assemble(qr_bf16_2d, rope_bf16, [dq_t0, h0 + 64])
                else:
                    tail_swap_idx: pl.Tensor[[1, 64], pl.INT32] = pl.tensor.slice(rope_swap_idx, [1, 64], [0, 0])
                    for tail_t0 in pl.range(dq_t0, bs):
                        tail_qr_scale_value: pl.Scalar[pl.FP32] = pl.tensor.read(qr_scale, [tail_t0, 0])
                        tail_cos_tile: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.slice(cos, [1, 64], [tail_t0, 0])
                        tail_sin_tile: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.slice(sin, [1, 64], [tail_t0, 0])
                        for tail_h_inner in pl.pipeline(4, stage=2):
                            tail_h0: pl.Scalar[pl.INDEX] = (hg + tail_h_inner) * 128
                            tail_wq_scale: pl.Tensor[[1, 128], pl.FP32] = pl.tensor.reshape(pl.tensor.slice(wq_b_scale, [128], [tail_h0]), [1, 128])
                            tail_acc_fp32: pl.Tensor[[1, 128], pl.FP32] = pl.tensor.cast(pl.tensor.slice(qr_acc_pad, [1, 128], [tail_t0, tail_h0]), target_type=pl.FP32, mode='none')
                            tail_qr_dequant_scale: pl.Tensor[[1, 128], pl.FP32] = pl.tensor.muls(tail_wq_scale, tail_qr_scale_value)
                            tail_qr_dequant: pl.Tensor[[1, 128], pl.FP32] = pl.tensor.mul(tail_acc_fp32, tail_qr_dequant_scale)
                            tail_qr_dequant_v1: pl.Tensor[[1, 128], pl.FP32] = pl.tensor.cast(pl.tensor.cast(tail_qr_dequant, target_type=pl.BF16, mode='rint'), target_type=pl.FP32, mode='round')
                            tail_qr_nope_bf16: pl.Tensor[[1, 64], pl.BF16] = pl.tensor.cast(pl.tensor.slice(tail_qr_dequant_v1, [1, 64], [0, 0]), target_type=pl.BF16, mode='rint')
                            tail_qr_rope_slice: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.slice(tail_qr_dequant_v1, [1, 64], [0, 64])
                            tail_qr_swapped: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.gather(tail_qr_rope_slice, tail_swap_idx, dim=-1)
                            tail_rope_rot: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.add(pl.tensor.mul(tail_qr_rope_slice, tail_cos_tile), pl.tensor.mul(tail_qr_swapped, tail_sin_tile))
                            tail_rope_bf16: pl.Tensor[[1, 64], pl.BF16] = pl.tensor.cast(tail_rope_rot, target_type=pl.BF16, mode='rint')
                            qr_bf16_2d: pl.Tensor[[432, 8192], pl.BF16] = pl.tensor.assemble(qr_bf16_2d, tail_qr_nope_bf16, [tail_t0, tail_h0])
                            qr_bf16_2d: pl.Tensor[[432, 8192], pl.BF16] = pl.tensor.assemble(qr_bf16_2d, tail_rope_bf16, [tail_t0, tail_h0 + 64])
        return idx_qr_mm_tid
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def indexer_qr_hadamard(self, x: pl.Tensor[[T_DYN, 4096], pl.BF16], qr: pl.Tensor[[T_DYN, 1024], pl.INT8], qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32], wq_b: pl.Tensor[[1024, 8192], pl.INT8], wq_b_scale: pl.Tensor[[8192], pl.FP32], cos: pl.Tensor[[T_DYN, 64], pl.FP32], sin: pl.Tensor[[T_DYN, 64], pl.FP32], hadamard: pl.Tensor[[128, 128], pl.BF16], qr_hadamard_i8: pl.Tensor[[27648, 128], pl.INT8], qr_hadamard_scale_dq: pl.Tensor[[27648, 1], pl.FP32]):
        # Query half of the indexer: qr projection, rope, hadamard, and INT8 quant.
        qr_bf16: pl.Tensor[[27648, 128], pl.BF16] = pl.tensor.create([27648, 128], dtype=pl.BF16, layout=pl.TensorLayout.ND)
        idx_qr_mm_tid: pl.Scalar[pl.TASK_ID] = self.indexer_qr_rope(x, qr, qr_scale, wq_b, wq_b_scale, cos, sin, qr_bf16)
        _tuple_tmp: pl.Tuple[pl.Scalar[pl.TASK_ID], pl.Scalar[pl.TASK_ID]] = self.indexer_qr_hadamard_mm(x, qr_bf16, hadamard, qr_hadamard_i8, qr_hadamard_scale_dq, idx_qr_mm_tid)
        qh_mm_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp[0]
        qh_quant_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp[1]
        return qh_mm_tid, qh_quant_tid, idx_qr_mm_tid
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def indexer_native_weights(self, native_indexer_weights: pl.Tensor[[T_DYN, 64], pl.FP16], gate_dep: pl.Scalar[pl.TASK_ID]) -> tuple[pl.Tensor[[432, 64], pl.FP32], pl.Scalar[pl.TASK_ID]]:
        # Consume Native's published FP16 values without changing coefficient arithmetic.
        tokens: pl.Scalar[pl.INDEX] = pl.tensor.dim(native_indexer_weights, 0)
        row_blocks: pl.Scalar[pl.INDEX] = (tokens + 16 - 1) // 16
        weights: pl.Tensor[[432, 64], pl.FP32] = pl.tensor.create([432, 64], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        with pl.spmd(row_blocks, name_hint="native_indexer_weights_spmd", deps=[gate_dep]) as weights_tid:
            row: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx() * 16
            rows: pl.Scalar[pl.INDEX] = pl.min(16, tokens - row)
            values: pl.Tile[[16, 64], pl.FP16, pl.TileView(valid_shape=[rows, 64])] = pl.tile.load(native_indexer_weights, [row, 0], [16, 64], [rows, 64], clamp=True)
            pl.tile.store(pl.tile.cast(values, target_type=pl.FP32, mode='round'), [row, 0], weights)
        return weights, weights_tid
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def indexer_build_query_groups(self, query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], seq_lens: pl.Tensor[[B_DYN], pl.INT32], group_row: pl.Tensor[[432], pl.INT32], group_rows: pl.Tensor[[432], pl.INT32], group_count: pl.Tensor[[1], pl.INT32]) -> pl.Tensor[[1], pl.INT32]:
        # 把 query 切成不跨请求的组：每请求 ceil(len / group_size) 组，末组按实际行数收尾。
        # 
        #         定长下每请求恰好 S 行，组边界与原来的 `g * group_size` 完全重合，
        #         所以这张表在定长输入上退化成原式，不改变任何编排。
        #         变长下全局对齐的组会跨请求，而组内共用一份 Key、共用组内最后一行的可见范围，
        #         跨请求时两者分属不同请求 —— 是错误不是次优，所以必须按请求切。
        #         
        count: pl.Scalar[pl.INDEX] = pl.cast(0, pl.INDEX)
        for request in pl.range(pl.tensor.dim(seq_lens, 0)):
            begin: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [request]), pl.INDEX)
            end: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [request + 1]), pl.INDEX)
            groups_here: pl.Scalar[pl.INDEX] = 0
            if pl.cast(pl.tensor.read(seq_lens, [request]), pl.INDEX) > 0:
                groups_here: pl.Scalar[pl.INDEX] = (end - begin + 6 - 1) // 6
            for local in pl.range(groups_here):
                row: pl.Scalar[pl.INDEX] = begin + local * 6
                pl.tensor.write(group_row, [count + local], pl.cast(row, pl.INT32))
                pl.tensor.write(group_rows, [count + local], pl.cast(pl.min(6, end - row), pl.INT32))
            count: pl.Scalar[pl.INDEX] = count + groups_here
        pl.tensor.write(group_count, [0], pl.cast(count, pl.INT32))
        return group_count
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def indexer_build_query_groups__2(self, query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], seq_lens: pl.Tensor[[B_DYN], pl.INT32], group_row: pl.Tensor[[432], pl.INT32], group_rows: pl.Tensor[[432], pl.INT32], group_count: pl.Tensor[[1], pl.INT32]) -> pl.Tensor[[1], pl.INT32]:
        # 把 query 切成不跨请求的组：每请求 ceil(len / group_size) 组，末组按实际行数收尾。
        # 
        #         定长下每请求恰好 S 行，组边界与原来的 `g * group_size` 完全重合，
        #         所以这张表在定长输入上退化成原式，不改变任何编排。
        #         变长下全局对齐的组会跨请求，而组内共用一份 Key、共用组内最后一行的可见范围，
        #         跨请求时两者分属不同请求 —— 是错误不是次优，所以必须按请求切。
        #         
        count: pl.Scalar[pl.INDEX] = pl.cast(0, pl.INDEX)
        for request in pl.range(pl.tensor.dim(seq_lens, 0)):
            begin: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [request]), pl.INDEX)
            end: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [request + 1]), pl.INDEX)
            groups_here: pl.Scalar[pl.INDEX] = 0
            if pl.cast(pl.tensor.read(seq_lens, [request]), pl.INDEX) > 0:
                groups_here: pl.Scalar[pl.INDEX] = (end - begin + 2 - 1) // 2
            for local in pl.range(groups_here):
                row: pl.Scalar[pl.INDEX] = begin + local * 2
                pl.tensor.write(group_row, [count + local], pl.cast(row, pl.INT32))
                pl.tensor.write(group_rows, [count + local], pl.cast(pl.min(2, end - row), pl.INT32))
            count: pl.Scalar[pl.INDEX] = count + groups_here
        pl.tensor.write(group_count, [0], pl.cast(count, pl.INT32))
        return group_count
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def indexer_query_group_count(self, query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], seq_lens: pl.Tensor[[B_DYN], pl.INT32]):
        # 与 indexer_build_query_groups 同一套切法，只要组数、不建表。
        # 
        #         分派门和 merge 侧只需要组数；单独算一遍 O(B) 标量，省掉把表传过去。
        #         
        count: pl.Scalar[pl.INDEX] = pl.cast(0, pl.INDEX)
        for request in pl.range(pl.tensor.dim(seq_lens, 0)):
            begin: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [request]), pl.INDEX)
            end: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [request + 1]), pl.INDEX)
            if pl.cast(pl.tensor.read(seq_lens, [request]), pl.INDEX) > 0:
                count: pl.Scalar[pl.INDEX] = count + (end - begin + 6 - 1) // 6
        return count
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def indexer_query_group_count__2(self, query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], seq_lens: pl.Tensor[[B_DYN], pl.INT32]):
        # 与 indexer_build_query_groups 同一套切法，只要组数、不建表。
        # 
        #         分派门和 merge 侧只需要组数；单独算一遍 O(B) 标量，省掉把表传过去。
        #         
        count: pl.Scalar[pl.INDEX] = pl.cast(0, pl.INDEX)
        for request in pl.range(pl.tensor.dim(seq_lens, 0)):
            begin: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [request]), pl.INDEX)
            end: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [request + 1]), pl.INDEX)
            if pl.cast(pl.tensor.read(seq_lens, [request]), pl.INDEX) > 0:
                count: pl.Scalar[pl.INDEX] = count + (end - begin + 2 - 1) // 2
        return count
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def indexer_head_coefficients(self, qr_hadamard_scale_dq: pl.Tensor[[27648, 1], pl.FP32], weights: pl.Tensor[[432, 64], pl.FP32], kv_seq_lens: pl.Tensor[[B_DYN], pl.INT32], group_row: pl.Tensor[[432], pl.INT32], group_rows: pl.Tensor[[432], pl.INT32], group_count_t: pl.Tensor[[1], pl.INT32], groups_tid: pl.Scalar[pl.TASK_ID], qh_quant_tid: pl.Scalar[pl.TASK_ID], weights_tid: pl.Scalar[pl.TASK_ID]):
        # 把同组query的FP16系数放在对角块，一次Cube完成各自的head规约。
        coefficients: pl.Tensor[[1152, 384], pl.FP16] = pl.tensor.create([1152, 384], dtype=pl.FP16, layout=pl.TensorLayout.ND)
        coefficient_scales: pl.Tensor[[432, 64], pl.FP32] = pl.tensor.reshape(qr_hadamard_scale_dq, [432, 64])
        coefficient_workers: pl.Scalar[pl.INDEX] = pl.min(48, pl.tensor.dim(kv_seq_lens, 0) * 1)
        with pl.spmd(coefficient_workers, name_hint="indexer_head_coefficients_spmd", deps=[groups_tid, qh_quant_tid, weights_tid], allow_early_resolve=True) as coefficients_tid:
            coefficient_worker: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
            coefficient_count: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_count_t, [0]), pl.INDEX)
            for coefficient_pair in pl.range(coefficient_worker, coefficient_count, 48):
                coefficient_rows: pl.Tile[[96, 64], pl.FP16, pl.Mem.Vec] = pl.tile.full([96, 64], dtype=pl.FP16, value=0.0)
                coefficient_begin: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_row, [coefficient_pair]), pl.INDEX)
                query_scales: pl.Tile[[6, 64], pl.FP32] = pl.tile.load(coefficient_scales, [coefficient_begin, 0], [6, 64], [6, 64])
                query_weights: pl.Tile[[6, 64], pl.FP32] = pl.tile.load(weights, [coefficient_begin, 0], [6, 64], [6, 64])
                query_scale_half: pl.Tile[[6, 64], pl.FP16, pl.Mem.Vec] = pl.tile.cast(query_scales, target_type=pl.FP16, mode='rint')
                query_weight_half: pl.Tile[[6, 64], pl.FP16, pl.Mem.Vec] = pl.tile.cast(query_weights, target_type=pl.FP16, mode='rint')
                head_coefficients: pl.Tile[[6, 64], pl.FP16, pl.Mem.Vec] = pl.tile.mul(query_scale_half, query_weight_half)
                for coefficient_lane in pl.unroll(6):
                    if coefficient_lane < pl.cast(pl.tensor.read(group_rows, [coefficient_pair]), pl.INDEX):
                        head_coefficient: pl.Tile[[1, 64], pl.FP16, pl.Mem.Vec] = pl.tile.extract(head_coefficients, coefficient_lane, 0, [1, 64], target_memory=pl.Mem.Vec)
                        coefficient_rows: pl.Tile[[96, 64], pl.FP16, pl.Mem.Vec] = pl.tile.assemble(coefficient_rows, head_coefficient, [coefficient_lane * 7, 0])
                coefficient_matrix: pl.Tile[[16, 384], pl.FP16, pl.Mem.Vec] = pl.tile.reshape(coefficient_rows, [16, 384])
                pl.tile.store(coefficient_matrix, [coefficient_pair * 16, 0], coefficients)
        return coefficients, coefficients_tid
    @pl.function(type=pl.FunctionType.Inline)
    def indexer_long_leaf_plan(self, max_cache_count: pl.Scalar[pl.INDEX], query_groups: pl.Scalar[pl.INDEX]):
        # Balance four/eight/sixteen request groups over the 24 Score workers.
        # 
        #         S6 reuses each Key panel for all six queries. Round four groups to six
        #         leaves, eight/sixteen groups to three-leaf multiples, within the existing
        #         pair arena. Other request counts preserve the original leaf partition.
        #         
        tile_count: pl.Scalar[pl.INDEX] = (max_cache_count + 1024 - 1) // 1024
        leaf_count: pl.Scalar[pl.INDEX] = pl.max((max_cache_count + 8192 - 1) // 8192, 1)
        leaf_tiles: pl.Scalar[pl.INDEX] = 8
        extra_leaves: pl.Scalar[pl.INDEX] = 0
        leaf_multiple: pl.Scalar[pl.INDEX] = 1
        if 3 * query_groups == 48:
            leaf_multiple: pl.Scalar[pl.INDEX] = 3
        else:
            if 3 * query_groups == 24:
                leaf_multiple: pl.Scalar[pl.INDEX] = 3
            else:
                if 6 * query_groups == 24:
                    leaf_multiple: pl.Scalar[pl.INDEX] = 6
        if leaf_multiple > 1:
            balanced_count: pl.Scalar[pl.INDEX] = (leaf_count + leaf_multiple - 1) // leaf_multiple * leaf_multiple
            if balanced_count <= 32:
                leaf_count: pl.Scalar[pl.INDEX] = balanced_count
                leaf_tiles: pl.Scalar[pl.INDEX] = pl.max(tile_count // balanced_count, 1)
                extra_leaves: pl.Scalar[pl.INDEX] = tile_count % balanced_count
        return leaf_count, leaf_tiles, extra_leaves
    @pl.function(type=pl.FunctionType.Inline)
    def indexer_topk_half_leaf(self, score_arena: pl.Tensor[[432, 8192], pl.FP32], pair_arena: pl.Tensor[[27648, 1024], pl.FP32], score_row: pl.Scalar[pl.INDEX], logical_begin: pl.Scalar[pl.INDEX], valid_count: pl.Scalar[pl.INDEX], output_slot: pl.Scalar[pl.INDEX]):
        # Sort a contiguous half-leaf and store its Top-512 pairs.
        logical_begin_i32: pl.Scalar[pl.INT32] = pl.cast(logical_begin, pl.INT32)
        if valid_count <= 512:
            short_indices: pl.Tile[[1, 512], pl.INT32, pl.Mem.Vec] = pl.tile.adds(pl.tile.ci(pl.const(0, pl.INT32), [1, 512], dtype=pl.INT32, descending=False), logical_begin_i32)
            short_raw: pl.Tile[[1, 512], pl.FP32, pl.TileView(valid_shape=[1, valid_count])] = pl.tile.load(score_arena, [score_row, 0], [1, 512], [1, valid_count])
            short_scores: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.fillpad(short_raw, pad_value=pl.PadValue.min)
            short_scores_v1: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximums(short_scores, -3.4028234663852886e+38)
            short_pairs: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(short_scores_v1, pl.tile.reinterpret_view(short_indices, dtype=pl.UINT32))
            short_pairs_v1: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(short_pairs, pl.const(64, pl.INT32))
            short_pairs_v2: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(short_pairs_v1, pl.const(256, pl.INT32))
            pl.tile.store(short_pairs_v2, [output_slot, 0], pair_arena)
        else:
            if valid_count <= 1024:
                small_indices: pl.Tile[[1, 1024], pl.INT32, pl.Mem.Vec] = pl.tile.adds(pl.tile.ci(pl.const(0, pl.INT32), [1, 1024], dtype=pl.INT32, descending=False), logical_begin_i32)
                small_raw: pl.Tile[[1, 1024], pl.FP32, pl.TileView(valid_shape=[1, valid_count])] = pl.tile.load(score_arena, [score_row, 0], [1, 1024], [1, valid_count])
                small_scores: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.fillpad(small_raw, pad_value=pl.PadValue.min)
                small_scores_v1: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximums(small_scores, -3.4028234663852886e+38)
                small_pairs: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(small_scores_v1, pl.tile.reinterpret_view(small_indices, dtype=pl.UINT32))
                small_pairs_v1: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(small_pairs, pl.const(64, pl.INT32))
                small_pairs_v2: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(small_pairs_v1, pl.const(256, pl.INT32))
                small_left: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(small_pairs_v2, [1, 1024], [0, 0])
                small_right: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(small_pairs_v2, [1, 1024], [0, 1024])
                small_tmp: pl.Tile[[1, 2048], pl.FP32] = pl.tile.create([1, 2048], dtype=pl.FP32)
                small_merged: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format2(small_left, small_right, small_tmp, exhausted=False)
                small_top: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(small_merged, [1, 1024], [0, 0])
                pl.tile.store(small_top, [output_slot, 0], pair_arena)
            else:
                if valid_count <= 2048:
                    leaf_indices: pl.Tile[[1, 2048], pl.INT32, pl.Mem.Vec] = pl.tile.adds(pl.tile.ci(pl.const(0, pl.INT32), [1, 2048], dtype=pl.INT32, descending=False), logical_begin_i32)
                    leaf_scores_raw: pl.Tile[[1, 2048], pl.FP32, pl.TileView(valid_shape=[1, valid_count])] = pl.tile.load(score_arena, [score_row, 0], [1, 2048], [1, valid_count])
                    leaf_scores: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.fillpad(leaf_scores_raw, pad_value=pl.PadValue.min)
                    leaf_scores_v1: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximums(leaf_scores, -3.4028234663852886e+38)
                    pairs: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(leaf_scores_v1, pl.tile.reinterpret_view(leaf_indices, dtype=pl.UINT32))
                    pairs_v1: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(pairs, pl.const(64, pl.INT32))
                    pairs_v2: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(pairs_v1, pl.const(256, pl.INT32))
                    pairs_v3: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(pairs_v2, pl.const(1024, pl.INT32))
                    pl.tile.store(pl.tile.slice(pairs_v3, [1, 1024], [0, 0]), [output_slot, 0], pair_arena)
                else:
                    if valid_count <= 2560:
                        partial_indices: pl.Tile[[1, 2560], pl.INT32, pl.Mem.Vec] = pl.tile.adds(pl.tile.ci(pl.const(0, pl.INT32), [1, 2560], dtype=pl.INT32, descending=False), logical_begin_i32)
                        partial_raw: pl.Tile[[1, 2560], pl.FP32, pl.TileView(valid_shape=[1, valid_count])] = pl.tile.load(score_arena, [score_row, 0], [1, 2560], [1, valid_count])
                        partial_scores: pl.Tile[[1, 2560], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.fillpad(partial_raw, pad_value=pl.PadValue.min)
                        partial_scores_v1: pl.Tile[[1, 2560], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximums(partial_scores, -3.4028234663852886e+38)
                        partial_pairs: pl.Tile[[1, 5120], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(partial_scores_v1, pl.tile.reinterpret_view(partial_indices, dtype=pl.UINT32))
                        partial_pairs_v1: pl.Tile[[1, 5120], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(partial_pairs, pl.const(64, pl.INT32))
                        partial_pairs_v2: pl.Tile[[1, 5120], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(partial_pairs_v1, pl.const(256, pl.INT32))
                        partial_prefix: pl.Tile[[1, 5120], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[1, 4096], pad=pl.PadValue.min)] = pl.tile.set_validshape(partial_pairs_v2, 1, 4096)
                        partial_prefix_v1: pl.Tile[[1, 5120], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(partial_prefix, pl.const(1024, pl.INT32))
                        partial_left: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(partial_prefix_v1, [1, 1024], [0, 0])
                        partial_right: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(partial_pairs_v2, [1, 1024], [0, 4096])
                        partial_tmp: pl.Tile[[1, 2048], pl.FP32] = pl.tile.create([1, 2048], dtype=pl.FP32)
                        partial_merged: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format2(partial_right, partial_left, partial_tmp, exhausted=False)
                        pl.tile.store(pl.tile.slice(partial_merged, [1, 1024], [0, 0]), [output_slot, 0], pair_arena)
                    else:
                        if valid_count <= 3072:
                            triple_indices: pl.Tile[[1, 3072], pl.INT32, pl.Mem.Vec] = pl.tile.adds(pl.tile.ci(pl.const(0, pl.INT32), [1, 3072], dtype=pl.INT32, descending=False), logical_begin_i32)
                            triple_raw: pl.Tile[[1, 3072], pl.FP32, pl.TileView(valid_shape=[1, valid_count])] = pl.tile.load(score_arena, [score_row, 0], [1, 3072], [1, valid_count])
                            triple_scores: pl.Tile[[1, 3072], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.fillpad(triple_raw, pad_value=pl.PadValue.min)
                            triple_scores_v1: pl.Tile[[1, 3072], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximums(triple_scores, -3.4028234663852886e+38)
                            triple_pairs: pl.Tile[[1, 6144], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(triple_scores_v1, pl.tile.reinterpret_view(triple_indices, dtype=pl.UINT32))
                            triple_pairs_v1: pl.Tile[[1, 6144], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(triple_pairs, pl.const(64, pl.INT32))
                            triple_pairs_v2: pl.Tile[[1, 6144], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(triple_pairs_v1, pl.const(256, pl.INT32))
                            triple_prefix: pl.Tile[[1, 6144], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[1, 4096], pad=pl.PadValue.min)] = pl.tile.set_validshape(triple_pairs_v2, 1, 4096)
                            triple_prefix_v1: pl.Tile[[1, 6144], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(triple_prefix, pl.const(1024, pl.INT32))
                            triple_left: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(triple_prefix_v1, [1, 1024], [0, 0])
                            triple_right0: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(triple_pairs_v2, [1, 1024], [0, 4096])
                            triple_right1: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(triple_pairs_v2, [1, 1024], [0, 5120])
                            triple_tmp: pl.Tile[[1, 3072], pl.FP32] = pl.tile.create([1, 3072], dtype=pl.FP32)
                            triple_merged: pl.Tile[[1, 3072], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format2(triple_right0, triple_right1, triple_left, triple_tmp, exhausted=False)
                            pl.tile.store(pl.tile.slice(triple_merged, [1, 1024], [0, 0]), [output_slot, 0], pair_arena)
                        else:
                            if valid_count <= 4096:
                                medium_indices: pl.Tile[[1, 4096], pl.INT32, pl.Mem.Vec] = pl.tile.adds(pl.tile.ci(pl.const(0, pl.INT32), [1, 4096], dtype=pl.INT32, descending=False), logical_begin_i32)
                                medium_scores_raw: pl.Tile[[1, 4096], pl.FP32, pl.TileView(valid_shape=[1, valid_count])] = pl.tile.load(score_arena, [score_row, 0], [1, 4096], [1, valid_count])
                                medium_scores: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.fillpad(medium_scores_raw, pad_value=pl.PadValue.min)
                                medium_scores_v1: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximums(medium_scores, -3.4028234663852886e+38)
                                medium_pairs: pl.Tile[[1, 8192], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(medium_scores_v1, pl.tile.reinterpret_view(medium_indices, dtype=pl.UINT32))
                                medium_pairs_v1: pl.Tile[[1, 8192], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(medium_pairs, pl.const(64, pl.INT32))
                                medium_pairs_v2: pl.Tile[[1, 8192], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(medium_pairs_v1, pl.const(256, pl.INT32))
                                medium_pairs_v3: pl.Tile[[1, 8192], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(medium_pairs_v2, pl.const(1024, pl.INT32))
                                medium_left: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(medium_pairs_v3, [1, 1024], [0, 0])
                                medium_right: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(medium_pairs_v3, [1, 1024], [0, 4096])
                                medium_tmp: pl.Tile[[1, 2048], pl.FP32] = pl.tile.create([1, 2048], dtype=pl.FP32)
                                medium_merged: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format2(medium_right, medium_left, medium_tmp, exhausted=False)
                                pl.tile.store(pl.tile.slice(medium_merged, [1, 1024], [0, 0]), [output_slot, 0], pair_arena)
    @pl.function(type=pl.FunctionType.Inline)
    def indexer_topk_segment_pairs(self, score_arena: pl.Tensor[[432, 8192], pl.FP32], score_row: pl.Scalar[pl.INDEX], logical_begin: pl.Scalar[pl.INDEX], valid_count: pl.Scalar[pl.INDEX]):
        # Sort the at-most-2048 candidates with the original tie rule.
        logical_i32: pl.Scalar[pl.INT32] = pl.cast(logical_begin, pl.INT32)
        if valid_count <= 512:
            tiny_indices: pl.Tile[[1, 512], pl.INT32, pl.Mem.Vec] = pl.tile.adds(pl.tile.ci(pl.const(0, pl.INT32), [1, 512], dtype=pl.INT32, descending=False), logical_i32)
            tiny_raw: pl.Tile[[1, 512], pl.FP32, pl.TileView(valid_shape=[1, valid_count])] = pl.tile.load(score_arena, [score_row, 0], [1, 512], [1, valid_count])
            tiny_scores: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximums(pl.tile.fillpad(tiny_raw, pad_value=pl.PadValue.min), -3.4028234663852886e+38)
            tiny_pairs: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(tiny_scores, pl.tile.reinterpret_view(tiny_indices, dtype=pl.UINT32))
            tiny_pairs_v1: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(tiny_pairs, pl.const(64, pl.INT32))
            tiny_pairs_v2: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(tiny_pairs_v1, pl.const(256, pl.INT32))
            root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(tiny_pairs_v2, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
        else:
            if valid_count <= 1024:
                small_indices: pl.Tile[[1, 1024], pl.INT32, pl.Mem.Vec] = pl.tile.adds(pl.tile.ci(pl.const(0, pl.INT32), [1, 1024], dtype=pl.INT32, descending=False), logical_i32)
                small_raw: pl.Tile[[1, 1024], pl.FP32, pl.TileView(valid_shape=[1, valid_count])] = pl.tile.load(score_arena, [score_row, 0], [1, 1024], [1, valid_count])
                small_scores: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximums(pl.tile.fillpad(small_raw, pad_value=pl.PadValue.min), -3.4028234663852886e+38)
                small_pairs: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(small_scores, pl.tile.reinterpret_view(small_indices, dtype=pl.UINT32))
                small_pairs_v1: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(small_pairs, pl.const(64, pl.INT32))
                small_pairs_v2: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(small_pairs_v1, pl.const(256, pl.INT32))
                small_left: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(small_pairs_v2, [1, 1024], [0, 0])
                small_right: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(small_pairs_v2, [1, 1024], [0, 1024])
                small_tmp: pl.Tile[[1, 2048], pl.FP32] = pl.tile.create([1, 2048], dtype=pl.FP32)
                small_merged: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format2(small_left, small_right, small_tmp, exhausted=False)
                root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(small_merged, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
            else:
                large_indices: pl.Tile[[1, 2048], pl.INT32, pl.Mem.Vec] = pl.tile.adds(pl.tile.ci(pl.const(0, pl.INT32), [1, 2048], dtype=pl.INT32, descending=False), logical_i32)
                large_raw: pl.Tile[[1, 2048], pl.FP32, pl.TileView(valid_shape=[1, valid_count])] = pl.tile.load(score_arena, [score_row, 0], [1, 2048], [1, valid_count])
                large_scores: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximums(pl.tile.fillpad(large_raw, pad_value=pl.PadValue.min), -3.4028234663852886e+38)
                large_pairs: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(large_scores, pl.tile.reinterpret_view(large_indices, dtype=pl.UINT32))
                large_pairs_v1: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(large_pairs, pl.const(64, pl.INT32))
                large_pairs_v2: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(large_pairs_v1, pl.const(256, pl.INT32))
                large_pairs_v3: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(large_pairs_v2, pl.const(1024, pl.INT32))
                root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(large_pairs_v3, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
        return root
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def indexer_score_topk_native_cube(self, qr_hadamard_i8: pl.Tensor[[27648, 128], pl.INT8], qr_hadamard_scale_dq: pl.Tensor[[27648, 1], pl.FP32], weights: pl.Tensor[[432, 64], pl.FP32], idx_native_kv_cache: pl.Tensor[[IDX_NATIVE_CACHE_BLOCK_NUM_DYN, INDEXER_PAGE_BYTES_DYN], pl.INT8], idx_block_table: pl.Tensor[[B_DYN, INDEXER_TABLE_COLUMNS_DYN], pl.INT32], position_ids: pl.Tensor[[T_DYN], pl.INT64], kv_seq_lens: pl.Tensor[[B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], group_row: pl.Tensor[[432], pl.INT32], group_rows: pl.Tensor[[432], pl.INT32], group_count_t: pl.Tensor[[1], pl.INT32], groups_tid: pl.Scalar[pl.TASK_ID], score_arena: pl.Tensor[[432, 8192], pl.FP32], pair_arena: pl.Tensor[[27648, 1024], pl.FP32], qh_quant_tid: pl.Scalar[pl.TASK_ID], weights_tid: pl.Scalar[pl.TASK_ID], cache_write_tid: pl.Scalar[pl.TASK_ID]):
        # 同组query共用Key：双query/M128/N128或S6/M384/N64，保持FP16/Cube策略。
        native_page_bytes: pl.Scalar[pl.INDEX] = pl.tensor.dim(idx_native_kv_cache, 1)
        cache_bytes: pl.Scalar[pl.INDEX] = pl.tensor.dim(idx_native_kv_cache, 0) * native_page_bytes
        cache_flat: pl.Tensor[[cache_bytes], pl.INT8] = pl.tensor.reshape(idx_native_kv_cache, [cache_bytes])
        key_rows: pl.Scalar[pl.INDEX] = cache_bytes // 128
        shifted_rows: pl.Scalar[pl.INDEX] = (cache_bytes - 64) // 128
        idx_kv_cache: pl.Tensor[[key_rows, 128], pl.INT8] = pl.tensor.reshape(pl.tensor.slice(cache_flat, [key_rows * 128], [0]), [key_rows, 128])
        idx_kv_cache_shift64: pl.Tensor[[shifted_rows, 128], pl.INT8] = pl.tensor.reshape(pl.tensor.slice(cache_flat, [shifted_rows * 128], [64]), [shifted_rows, 128])
        _tuple_tmp: pl.Tuple[pl.Tensor[[1152, 384], pl.FP16], pl.Scalar[pl.TASK_ID]] = self.indexer_head_coefficients(qr_hadamard_scale_dq, weights, kv_seq_lens, group_row, group_rows, group_count_t, groups_tid, qh_quant_tid, weights_tid)
        coefficients: pl.Tensor[[1152, 384], pl.FP16] = _tuple_tmp[0]
        coefficients_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp[1]
        buf_score_transfer: pl.Tensor[[288, 1024], pl.FP32] = pl.tensor.create([288, 1024], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        buf_score_ffts: pl.Tensor[[256], pl.INT64] = pl.tensor.create([256], dtype=pl.INT64, layout=pl.TensorLayout.ND)
        with pl.spmd(24, sync_start=True, name_hint="indexer_score_topk_native_pair_spmd", deps=[groups_tid, coefficients_tid, cache_write_tid]) as buffered_leaf_tid:
            buf_worker: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
            buf_max_cache_len: pl.Scalar[pl.INDEX] = 0
            for buf_batch in pl.range(pl.tensor.dim(kv_seq_lens, 0)):
                buf_max_cache_len: pl.Scalar[pl.INDEX] = pl.max(buf_max_cache_len, pl.cast(pl.tensor.read(kv_seq_lens, [buf_batch]), pl.INDEX) // 4)
            buf_capped_history: pl.Scalar[pl.INDEX] = pl.min(buf_max_cache_len, 262144)
            buf_max_leaves: pl.Scalar[pl.INDEX] = pl.max((buf_capped_history + 8192 - 1) // 8192, 1)
            buf_leaf_tiles: pl.Scalar[pl.INDEX] = 8
            buf_extra_leaves: pl.Scalar[pl.INDEX] = 0
            buf_group_count: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_count_t, [0]), pl.INDEX)
            if True:
                _tuple_tmp_1: pl.Tuple[pl.Scalar[pl.INDEX], pl.Scalar[pl.INDEX], pl.Scalar[pl.INDEX]] = self.indexer_long_leaf_plan(buf_capped_history, buf_group_count)
                buf_max_leaves: pl.Scalar[pl.INDEX] = _tuple_tmp_1[0]
                buf_leaf_tiles: pl.Scalar[pl.INDEX] = _tuple_tmp_1[1]
                buf_extra_leaves: pl.Scalar[pl.INDEX] = _tuple_tmp_1[2]
            pl.system.set_ffts(buf_score_ffts)
            for buf_item in pl.range(buf_worker, buf_group_count * buf_max_leaves, 24):
                if buf_group_count < 24:
                    buf_group: pl.Scalar[pl.INDEX] = buf_item % buf_group_count
                    buf_leaf: pl.Scalar[pl.INDEX] = buf_item // buf_group_count
                else:
                    buf_group: pl.Scalar[pl.INDEX] = buf_item // buf_max_leaves
                    buf_leaf: pl.Scalar[pl.INDEX] = buf_item % buf_max_leaves
                buf_query: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_row, [buf_group]), pl.INDEX)
                buf_group_rows: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_rows, [buf_group]), pl.INDEX)
                buf_batch_idx: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(token_request, [buf_query]), pl.INDEX)
                buf_last_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [buf_query + buf_group_rows - 1])
                buf_cache_len: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(kv_seq_lens, [buf_batch_idx]), pl.INDEX) // 4
                buf_visible_count: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(buf_cache_len, (buf_last_position + 1) // 4), 262144), 0)
                buf_logical_begin: pl.Scalar[pl.INDEX] = buf_leaf * 8192
                buf_leaf_capacity: pl.Scalar[pl.INDEX] = 8192
                if True:
                    buf_logical_begin: pl.Scalar[pl.INDEX] = (buf_leaf * buf_leaf_tiles + pl.min(buf_leaf, buf_extra_leaves)) * 1024
                    buf_leaf_capacity: pl.Scalar[pl.INDEX] = (buf_leaf_tiles + pl.cast(buf_leaf < buf_extra_leaves, pl.INDEX)) * 1024
                if buf_logical_begin < buf_visible_count:
                    buf_valid_count: pl.Scalar[pl.INDEX] = pl.min(buf_leaf_capacity, buf_visible_count - buf_logical_begin)
                    buf_tile_count: pl.Scalar[pl.INDEX] = (buf_valid_count + 1024 - 1) // 1024
                    buf_lane_span: pl.Scalar[pl.INDEX] = pl.min(buf_tile_count * 512, 4096)
                    buf_score_iters: pl.Scalar[pl.INDEX] = (buf_lane_span + 512 - 1) // 512
                    buf_query_vector: pl.Tile[[384, 128], pl.INT8, pl.Mem.Mat] = pl.tile.load(qr_hadamard_i8, [buf_query * 64, 0], [384, 128], [384, 128], target_memory=pl.Mem.Mat)
                    buf_coefficients_l1: pl.Tile[[16, 384], pl.FP16, pl.Mem.Mat] = pl.tile.load(coefficients, [buf_group * 16, 0], [16, 384], [16, 384], target_memory=pl.Mem.Mat)
                    buf_query_left: pl.Tile[[384, 128], pl.INT8, pl.Mem.Left] = pl.tile.move(buf_query_vector, target_memory=pl.Mem.Left)
                    buf_coefficient_pair: pl.Tile[[16, 384], pl.FP16, pl.Mem.Left] = pl.tile.move(buf_coefficients_l1, target_memory=pl.Mem.Left)
                    for buf_score_step in pl.range(buf_score_iters):
                        if buf_score_step >= 2:
                            pl.system.sync_wait(1, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIC)
                        buf_score_begin: pl.Scalar[pl.INDEX] = buf_score_step * 512
                        if True:
                            buf_score_begin: pl.Scalar[pl.INDEX] = buf_score_step * 1024
                        buf_transfer_row: pl.Scalar[pl.INDEX] = buf_worker * 2 * 6 + buf_score_step % 2 * 6
                        buf_previous_l1: pl.Tile[[384, 64], pl.FP16, pl.Mem.Mat] = pl.tile.create([384, 64], dtype=pl.FP16, target_memory=pl.Mem.Mat)
                        buf_current_key: pl.Tile[[128, 64], pl.INT8, pl.Mem.Right] = pl.tile.create([128, 64], dtype=pl.INT8, target_memory=pl.Mem.Right)
                        buf_prefetched_key: pl.Tile[[128, 64], pl.INT8, pl.Mem.Right] = pl.tile.create([128, 64], dtype=pl.INT8, target_memory=pl.Mem.Right)
                        buf_key_l1_pool: pl.Tile[[128, 128], pl.INT8, pl.Mem.Mat] = pl.tile.create([128, 128], dtype=pl.INT8, target_memory=pl.Mem.Mat)
                        if pl.const(1, pl.INDEX) > pl.const(0, pl.INDEX):
                            buf_prime_col: pl.Scalar[pl.INDEX] = 0
                            for buf_prime_key_page in pl.unroll(2):
                                buf_prime_key_row: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_score_begin + buf_prime_col // 512 * buf_lane_span + buf_prime_col % 512 + buf_prime_key_page * 32
                                if True:
                                    buf_prime_key_row: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_score_begin + buf_prime_col + buf_prime_key_page * 32
                                buf_prime_safe_page: pl.Scalar[pl.INDEX] = pl.min(buf_prime_key_row // 32, pl.max((buf_cache_len - 1) // 32, 0))
                                buf_prime_physical_page: pl.Scalar[pl.INDEX] = pl.max(pl.cast(pl.tensor.read(idx_block_table, [buf_batch_idx, buf_prime_safe_page]), pl.INDEX), 0)
                                buf_prime_native_byte: pl.Scalar[pl.INDEX] = buf_prime_physical_page * native_page_bytes
                                if buf_prime_native_byte % 128 == 0:
                                    buf_key_l1_pool: pl.Tile[[128, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_key_l1_pool, idx_kv_cache, [buf_prime_key_page * 32, 0], [buf_prime_native_byte // 128, 0], [32, 128], transpose=False)
                                else:
                                    buf_key_l1_pool: pl.Tile[[128, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_key_l1_pool, idx_kv_cache_shift64, [buf_prime_key_page * 32, 0], [buf_prime_native_byte // 128, 0], [32, 128], transpose=False)
                            if True:
                                buf_current_key: pl.Tile[[128, 64], pl.INT8, pl.Mem.Right] = pl.tile.extract(pl.tile.transpose_view(buf_key_l1_pool), 0, 0, [128, 64], target_memory=pl.Mem.Right)
                        for buf_qk_panel in pl.unroll(16):
                            buf_panel_col: pl.Scalar[pl.INDEX] = buf_qk_panel * 64
                            buf_load_col: pl.Scalar[pl.INDEX] = (buf_qk_panel + 1) * 64
                            buf_load_slot: pl.Scalar[pl.INDEX] = (buf_qk_panel + 1) % 2 * 64
                            if pl.const(1, pl.INDEX) > pl.const(0, pl.INDEX):
                                if not True:
                                    buf_current_key: pl.Tile[[128, 64], pl.INT8, pl.Mem.Right] = pl.tile.extract(pl.tile.transpose_view(buf_key_l1_pool), 0, buf_qk_panel % 2 * 64, [128, 64], target_memory=pl.Mem.Right)
                            if buf_qk_panel + 1 < 16:
                                buf_panel_keys: pl.Tile[[64, 128], pl.INT8, pl.Mem.Mat] = pl.tile.create([64, 128], dtype=pl.INT8, target_memory=pl.Mem.Mat)
                                for buf_key_page in pl.unroll(2):
                                    buf_key_row: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_score_begin + buf_load_col // 512 * buf_lane_span + buf_load_col % 512 + buf_key_page * 32
                                    if True:
                                        buf_key_row: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_score_begin + buf_load_col + buf_key_page * 32
                                    buf_safe_page: pl.Scalar[pl.INDEX] = pl.min(buf_key_row // 32, pl.max((buf_cache_len - 1) // 32, 0))
                                    buf_physical_page: pl.Scalar[pl.INDEX] = pl.max(pl.cast(pl.tensor.read(idx_block_table, [buf_batch_idx, buf_safe_page]), pl.INDEX), 0)
                                    buf_native_byte: pl.Scalar[pl.INDEX] = buf_physical_page * native_page_bytes
                                    if buf_native_byte % 128 == 0:
                                        if pl.const(1, pl.INDEX) > pl.const(0, pl.INDEX):
                                            buf_key_l1_pool: pl.Tile[[128, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_key_l1_pool, idx_kv_cache, [buf_load_slot + buf_key_page * 32, 0], [buf_native_byte // 128, 0], [32, 128], transpose=False)
                                        else:
                                            buf_panel_keys: pl.Tile[[64, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_panel_keys, idx_kv_cache, [buf_key_page * 32, 0], [buf_native_byte // 128, 0], [32, 128], transpose=False)
                                    else:
                                        if pl.const(1, pl.INDEX) > pl.const(0, pl.INDEX):
                                            buf_key_l1_pool: pl.Tile[[128, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_key_l1_pool, idx_kv_cache_shift64, [buf_load_slot + buf_key_page * 32, 0], [buf_native_byte // 128, 0], [32, 128], transpose=False)
                                        else:
                                            buf_panel_keys: pl.Tile[[64, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_panel_keys, idx_kv_cache_shift64, [buf_key_page * 32, 0], [buf_native_byte // 128, 0], [32, 128], transpose=False)
                                if pl.const(1, pl.INDEX) > pl.const(0, pl.INDEX):
                                    if True:
                                        buf_prefetched_key: pl.Tile[[128, 64], pl.INT8, pl.Mem.Right] = pl.tile.extract(pl.tile.transpose_view(buf_key_l1_pool), 0, buf_load_slot, [128, 64], target_memory=pl.Mem.Right)
                                else:
                                    buf_prefetched_key: pl.Tile[[128, 64], pl.INT8, pl.Mem.Right] = pl.tile.move(pl.tile.transpose_view(buf_panel_keys), target_memory=pl.Mem.Right)
                            if pl.const(1, pl.INDEX) > pl.const(0, pl.INDEX):
                                buf_key_panel: pl.Tile[[128, 64], pl.INT8, pl.Mem.Right] = buf_current_key
                            else:
                                buf_key_panel: pl.Tile[[128, 64], pl.INT8, pl.Mem.Right] = buf_prefetched_key
                            buf_scores_l1: pl.Tile[[384, 64], pl.FP16, pl.Mem.Mat] = pl.tile.create([384, 64], dtype=pl.FP16, target_memory=pl.Mem.Mat)
                            if buf_qk_panel > 0:
                                buf_previous_pair: pl.Tile[[384, 64], pl.FP16, pl.Mem.Right] = pl.tile.extract(buf_previous_l1, 0, 0, [384, 64], target_memory=pl.Mem.Right)
                                buf_scores: pl.Tile[[384, 64], pl.INT32, pl.Mem.Acc] = pl.tile.matmul(buf_query_left, buf_key_panel)
                                buf_reduced_pair: pl.Tile[[16, 64], pl.FP32, pl.Mem.Acc] = pl.tile.matmul(buf_coefficient_pair, buf_previous_pair)
                                buf_scores_l1: pl.Tile[[384, 64], pl.FP16, pl.Mem.Mat] = pl.tile.assemble(buf_scores_l1, buf_scores, [0, 0], pre_quant=0.0009765625, pre_relu=True)
                                pl.tile.store(pl.tile.set_validshape(buf_reduced_pair, 6, 64), [buf_transfer_row, buf_panel_col - 64], buf_score_transfer)
                            else:
                                buf_scores: pl.Tile[[384, 64], pl.INT32, pl.Mem.Acc] = pl.tile.matmul(buf_query_left, buf_key_panel)
                                buf_scores_l1: pl.Tile[[384, 64], pl.FP16, pl.Mem.Mat] = pl.tile.assemble(buf_scores_l1, buf_scores, [0, 0], pre_quant=0.0009765625, pre_relu=True)
                            buf_previous_l1: pl.Tile[[384, 64], pl.FP16, pl.Mem.Mat] = buf_scores_l1
                            if pl.const(1, pl.INDEX) > pl.const(0, pl.INDEX):
                                if True:
                                    if buf_qk_panel + 1 < 16:
                                        buf_current_key: pl.Tile[[128, 64], pl.INT8, pl.Mem.Right] = buf_prefetched_key
                        buf_last_pair: pl.Tile[[384, 64], pl.FP16, pl.Mem.Right] = pl.tile.extract(buf_previous_l1, 0, 0, [384, 64], target_memory=pl.Mem.Right)
                        buf_last_scores: pl.Tile[[16, 64], pl.FP32, pl.Mem.Acc] = pl.tile.matmul(buf_coefficient_pair, buf_last_pair)
                        pl.tile.store(pl.tile.set_validshape(buf_last_scores, 6, 64), [buf_transfer_row, 960], buf_score_transfer)
                        pl.system.sync_set(0, pipe=pl.PipeType.FIX, ffts_mode=2, core_type=pl.KernelType.AIC)
                    for buf_score_drain in pl.range(pl.min(buf_score_iters, 2)):
                        pl.system.sync_wait(1, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIC)
            for buf_score_lane in pl.split_aiv(2, mode=pl.SplitMode.NONE):
                if True:
                    for single_item in pl.range(buf_worker, buf_group_count * buf_max_leaves, 24):
                        if buf_group_count < 24:
                            single_group: pl.Scalar[pl.INDEX] = single_item % buf_group_count
                            single_leaf: pl.Scalar[pl.INDEX] = single_item // buf_group_count
                        else:
                            single_group: pl.Scalar[pl.INDEX] = single_item // buf_max_leaves
                            single_leaf: pl.Scalar[pl.INDEX] = single_item % buf_max_leaves
                        single_query: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_row, [single_group]), pl.INDEX)
                        single_group_rows: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_rows, [single_group]), pl.INDEX)
                        single_batch: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(token_request, [single_query]), pl.INDEX)
                        single_cache_len: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(kv_seq_lens, [single_batch]), pl.INDEX) // 4
                        single_last_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [single_query + single_group_rows - 1])
                        single_visible: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(single_cache_len, (single_last_position + 1) // 4), 262144), 0)
                        single_begin: pl.Scalar[pl.INDEX] = (single_leaf * buf_leaf_tiles + pl.min(single_leaf, buf_extra_leaves)) * 1024
                        single_capacity: pl.Scalar[pl.INDEX] = (buf_leaf_tiles + pl.cast(single_leaf < buf_extra_leaves, pl.INDEX)) * 1024
                        if single_begin < single_visible:
                            single_valid: pl.Scalar[pl.INDEX] = pl.min(single_capacity, single_visible - single_begin)
                            single_steps: pl.Scalar[pl.INDEX] = (single_valid + 1024 - 1) // 1024
                            single_roots: pl.Tile[[3, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.full([3, 1024], dtype=pl.FP32, value=-3.4028234663852886e+38)
                            single_segments: pl.Tile[[6, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.full([6, 1024], dtype=pl.FP32, value=-3.4028234663852886e+38)
                            for single_step in pl.range(single_steps):
                                single_score_begin: pl.Scalar[pl.INDEX] = single_begin + single_step * 1024
                                single_transfer_row: pl.Scalar[pl.INDEX] = buf_worker * 2 * 6 + single_step % 2 * 6 + buf_score_lane * 3
                                single_scale_bytes: pl.Tile[[1, 2048], pl.INT8] = pl.tile.create([1, 2048], dtype=pl.INT8)
                                for single_scale_page in pl.range(32):
                                    single_scale_logical: pl.Scalar[pl.INDEX] = pl.min(single_score_begin // 32 + single_scale_page, pl.max((single_cache_len - 1) // 32, 0))
                                    single_scale_physical: pl.Scalar[pl.INDEX] = pl.max(pl.cast(pl.tensor.read(idx_block_table, [single_batch, single_scale_logical]), pl.INDEX), 0)
                                    single_scale_bytes: pl.Tile[[1, 2048], pl.INT8] = pl.tile.gather_row(single_scale_bytes, idx_native_kv_cache, [0, single_scale_page * 32 * 2], [single_scale_physical, 4096], [1, 64], transpose=False)
                                single_scale_half: pl.Tile[[1, 1024], pl.FP16] = pl.tile.reinterpret_view(single_scale_bytes, dtype=pl.FP16)
                                single_kv_scale: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.cast(single_scale_half, target_type=pl.FP32, mode='round')
                                pl.system.sync_wait(0, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIV)
                                single_scores: pl.Tile[[3, 1024], pl.FP32] = pl.tile.load(buf_score_transfer, [single_transfer_row, 0], [3, 1024], [3, 1024])
                                pl.system.sync_set(1, pipe=pl.PipeType.MTE2, ffts_mode=2, core_type=pl.KernelType.AIV)
                                for single_local in pl.unroll(3):
                                    single_score_row: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_scores, single_local, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                    single_scaled: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.mul(single_score_row, single_kv_scale)
                                    single_segments: pl.Tile[[6, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.assemble(single_segments, single_scaled, [single_local * 2 + single_step % 2, 0])
                                if single_step % 2 == 1 or single_step + 1 == single_steps:
                                    single_segment_begin: pl.Scalar[pl.INDEX] = single_begin + single_step // 2 * 2048
                                    single_segment_span: pl.Scalar[pl.INDEX] = (single_step % 2 + 1) * 1024
                                    single_segment_rows: pl.Tile[[3, 2048], pl.FP32, pl.Mem.Vec] = pl.tile.reshape(single_segments, [3, 2048])
                                    for single_local_1 in pl.unroll(3):
                                        single_query_lane: pl.Scalar[pl.INDEX] = buf_score_lane * 3 + single_local_1
                                        single_lane_live: pl.Scalar[pl.BOOL] = single_query_lane < single_group_rows
                                        single_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [single_query + pl.min(single_query_lane, single_group_rows - 1)])
                                        single_query_visible: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(single_cache_len, (single_position + 1) // 4), 262144), 0)
                                        single_segment_valid: pl.Scalar[pl.INDEX] = pl.max(pl.min(single_query_visible - single_segment_begin, single_segment_span), 0)
                                        if single_segment_valid > 0 and single_lane_live:
                                            single_segment_data: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_segment_rows, single_local_1, 0, [1, 2048], target_memory=pl.Mem.Vec)
                                            logical_i32: pl.Scalar[pl.INT32] = pl.cast(single_segment_begin, pl.INT32)
                                            if single_segment_valid <= 512:
                                                tiny_indices: pl.Tile[[1, 512], pl.INT32, pl.Mem.Vec] = pl.tile.adds(pl.tile.ci(pl.const(0, pl.INT32), [1, 512], dtype=pl.INT32, descending=False), logical_i32)
                                                tiny_tile: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_segment_data, 0, 0, [1, 512], target_memory=pl.Mem.Vec)
                                                tiny_raw: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[1, single_segment_valid])] = pl.tile.set_validshape(tiny_tile, 1, single_segment_valid)
                                                tiny_scores: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximums(pl.tile.fillpad(tiny_raw, pad_value=pl.PadValue.min), -3.4028234663852886e+38)
                                                tiny_pairs: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(tiny_scores, pl.tile.reinterpret_view(tiny_indices, dtype=pl.UINT32))
                                                tiny_pairs_v1: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(tiny_pairs, pl.const(64, pl.INT32))
                                                tiny_pairs_v2: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(tiny_pairs_v1, pl.const(256, pl.INT32))
                                                single_new_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(tiny_pairs_v2, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                            else:
                                                if single_segment_valid <= 1024:
                                                    small_indices: pl.Tile[[1, 1024], pl.INT32, pl.Mem.Vec] = pl.tile.adds(pl.tile.ci(pl.const(0, pl.INT32), [1, 1024], dtype=pl.INT32, descending=False), logical_i32)
                                                    small_tile: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_segment_data, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                                    small_raw: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[1, single_segment_valid])] = pl.tile.set_validshape(small_tile, 1, single_segment_valid)
                                                    small_scores: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximums(pl.tile.fillpad(small_raw, pad_value=pl.PadValue.min), -3.4028234663852886e+38)
                                                    small_pairs: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(small_scores, pl.tile.reinterpret_view(small_indices, dtype=pl.UINT32))
                                                    small_pairs_v1: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(small_pairs, pl.const(64, pl.INT32))
                                                    small_pairs_v2: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(small_pairs_v1, pl.const(256, pl.INT32))
                                                    small_left: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(small_pairs_v2, [1, 1024], [0, 0])
                                                    small_right: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(small_pairs_v2, [1, 1024], [0, 1024])
                                                    small_tmp: pl.Tile[[1, 2048], pl.FP32] = pl.tile.create([1, 2048], dtype=pl.FP32)
                                                    small_merged: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format2(small_left, small_right, small_tmp, exhausted=False)
                                                    single_new_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(small_merged, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                                else:
                                                    large_indices: pl.Tile[[1, 2048], pl.INT32, pl.Mem.Vec] = pl.tile.adds(pl.tile.ci(pl.const(0, pl.INT32), [1, 2048], dtype=pl.INT32, descending=False), logical_i32)
                                                    large_tile: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_segment_data, 0, 0, [1, 2048], target_memory=pl.Mem.Vec)
                                                    large_raw: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[1, single_segment_valid])] = pl.tile.set_validshape(large_tile, 1, single_segment_valid)
                                                    large_scores: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximums(pl.tile.fillpad(large_raw, pad_value=pl.PadValue.min), -3.4028234663852886e+38)
                                                    large_pairs: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(large_scores, pl.tile.reinterpret_view(large_indices, dtype=pl.UINT32))
                                                    large_pairs_v1: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(large_pairs, pl.const(64, pl.INT32))
                                                    large_pairs_v2: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(large_pairs_v1, pl.const(256, pl.INT32))
                                                    large_pairs_v3: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(large_pairs_v2, pl.const(1024, pl.INT32))
                                                    single_new_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(large_pairs_v3, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                            if single_step < 2:
                                                single_roots: pl.Tile[[3, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.assemble(single_roots, single_new_root, [single_local_1, 0])
                                            else:
                                                single_old_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_roots, single_local_1, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                                single_merge_tmp: pl.Tile[[1, 2048], pl.FP32] = pl.tile.create([1, 2048], dtype=pl.FP32)
                                                single_merged: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec] = pl.tile.mrgsort_format2(single_new_root, single_old_root, single_merge_tmp, exhausted=False)
                                                single_next_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_merged, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                                single_roots: pl.Tile[[3, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.assemble(single_roots, single_next_root, [single_local_1, 0])
                            for single_local_2 in pl.unroll(3):
                                single_query_lane: pl.Scalar[pl.INDEX] = buf_score_lane * 3 + single_local_2
                                if single_query_lane < single_group_rows:
                                    single_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_roots, single_local_2, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                    pl.tile.store(single_root, [(single_query + single_query_lane) * 64 + single_leaf, 0], pair_arena)
                else:
                    for buf_item_1 in pl.range(buf_worker, buf_group_count * buf_max_leaves, 24):
                        if buf_group_count < 24:
                            buf_group: pl.Scalar[pl.INDEX] = buf_item_1 % buf_group_count
                            buf_leaf: pl.Scalar[pl.INDEX] = buf_item_1 // buf_group_count
                        else:
                            buf_group: pl.Scalar[pl.INDEX] = buf_item_1 // buf_max_leaves
                            buf_leaf: pl.Scalar[pl.INDEX] = buf_item_1 % buf_max_leaves
                        buf_query: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_row, [buf_group]), pl.INDEX)
                        buf_group_rows: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_rows, [buf_group]), pl.INDEX)
                        buf_batch_idx: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(token_request, [buf_query]), pl.INDEX)
                        buf_last_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [buf_query + buf_group_rows - 1])
                        buf_cache_len: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(kv_seq_lens, [buf_batch_idx]), pl.INDEX) // 4
                        buf_visible_count: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(buf_cache_len, (buf_last_position + 1) // 4), 262144), 0)
                        buf_logical_begin: pl.Scalar[pl.INDEX] = buf_leaf * 8192
                        buf_leaf_capacity: pl.Scalar[pl.INDEX] = 8192
                        if True:
                            buf_logical_begin: pl.Scalar[pl.INDEX] = (buf_leaf * buf_leaf_tiles + pl.min(buf_leaf, buf_extra_leaves)) * 1024
                            buf_leaf_capacity: pl.Scalar[pl.INDEX] = (buf_leaf_tiles + pl.cast(buf_leaf < buf_extra_leaves, pl.INDEX)) * 1024
                        if buf_logical_begin < buf_visible_count:
                            buf_valid_count: pl.Scalar[pl.INDEX] = pl.min(buf_leaf_capacity, buf_visible_count - buf_logical_begin)
                            buf_tile_count: pl.Scalar[pl.INDEX] = (buf_valid_count + 1024 - 1) // 1024
                            buf_lane_span: pl.Scalar[pl.INDEX] = pl.min(buf_tile_count * 512, 4096)
                            buf_score_iters: pl.Scalar[pl.INDEX] = (buf_lane_span + 512 - 1) // 512
                            buf_lane_begin: pl.Scalar[pl.INDEX] = buf_score_lane * buf_lane_span
                            prefix_roots: pl.Tile[[6, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.full([6, 1024], dtype=pl.FP32, value=-3.4028234663852886e+38)
                            for buf_score_step_1 in pl.range(buf_score_iters):
                                buf_score_begin: pl.Scalar[pl.INDEX] = buf_score_step_1 * 512
                                buf_transfer_row: pl.Scalar[pl.INDEX] = buf_worker * 2 * 6 + buf_score_step_1 % 2 * 6
                                buf_scale_bytes: pl.Tile[[1, 1024], pl.INT8] = pl.tile.create([1, 1024], dtype=pl.INT8)
                                for buf_scale_page in pl.range(16):
                                    buf_scale_row: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_score_begin + buf_lane_begin + buf_scale_page * 32
                                    buf_scale_safe_page: pl.Scalar[pl.INDEX] = pl.min(buf_scale_row // 32, pl.max((buf_cache_len - 1) // 32, 0))
                                    buf_scale_physical_page: pl.Scalar[pl.INDEX] = pl.max(pl.cast(pl.tensor.read(idx_block_table, [buf_batch_idx, buf_scale_safe_page]), pl.INDEX), 0)
                                    buf_scale_bytes: pl.Tile[[1, 1024], pl.INT8] = pl.tile.gather_row(buf_scale_bytes, idx_native_kv_cache, [0, buf_scale_page * 32 * 2], [buf_scale_physical_page, 4096], [1, 64], transpose=False)
                                buf_scale_half: pl.Tile[[1, 512], pl.FP16] = pl.tile.reinterpret_view(buf_scale_bytes, dtype=pl.FP16)
                                buf_kv_scale: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec] = pl.tile.cast(buf_scale_half, target_type=pl.FP32, mode='round')
                                pl.system.sync_wait(0, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIV)
                                buf_score_sums: pl.Tile[[6, 512], pl.FP32] = pl.tile.load(buf_score_transfer, [buf_transfer_row, buf_score_lane * 512], [6, 512], [6, 512])
                                pl.system.sync_set(1, pipe=pl.PipeType.MTE2, ffts_mode=2, core_type=pl.KernelType.AIV)
                                for buf_query_lane in pl.unroll(6):
                                    buf_lane_live: pl.Scalar[pl.BOOL] = buf_query_lane < buf_group_rows
                                    buf_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [buf_query + pl.min(buf_query_lane, buf_group_rows - 1)])
                                    buf_query_visible: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(buf_cache_len, (buf_position + 1) // 4), 262144), 0)
                                    buf_lane_valid_rows: pl.Scalar[pl.INDEX] = pl.max(pl.min(buf_query_visible - buf_logical_begin - buf_score_begin - buf_lane_begin, 512), 0)
                                    buf_lane_valid_rows_v1: pl.Scalar[pl.INDEX] = pl.min(buf_lane_valid_rows, pl.max(buf_lane_span - buf_score_begin, 0))
                                    buf_score_sum: pl.Tile[[1, 512], pl.FP32] = pl.tile.slice(buf_score_sums, [1, 512], [buf_query_lane, 0])
                                    buf_score_row: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec] = pl.tile.mul(buf_score_sum, buf_kv_scale)
                                    buf_store_row: pl.Scalar[pl.INDEX] = buf_query + buf_query_lane
                                    buf_store_column: pl.Scalar[pl.INDEX] = buf_score_begin + buf_lane_begin
                                    if buf_max_leaves > 1:
                                        buf_store_row: pl.Scalar[pl.INDEX] = buf_worker * 2 * 6 + buf_query_lane * 2 + buf_score_lane
                                        buf_store_column: pl.Scalar[pl.INDEX] = buf_score_begin
                                    if buf_lane_valid_rows_v1 > 0 and buf_lane_live:
                                        pl.tile.store(pl.tile.set_validshape(buf_score_row, 1, buf_lane_valid_rows_v1), [buf_store_row, buf_store_column], score_arena)
                                if True:
                                    if buf_score_step_1 == 3 and buf_score_iters > 4:
                                        for stream_lane in pl.unroll(6):
                                            stream_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [buf_query + pl.min(stream_lane, buf_group_rows - 1)])
                                            stream_visible: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(buf_cache_len, (stream_position + 1) // 4), 262144), 0)
                                            stream_begin: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_lane_begin
                                            stream_valid: pl.Scalar[pl.INDEX] = pl.max(pl.min(stream_visible - stream_begin, 2048), 0)
                                            if stream_valid > 0 and stream_lane < buf_group_rows:
                                                stream_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = self.indexer_topk_segment_pairs(score_arena, buf_worker * 2 * 6 + stream_lane * 2 + buf_score_lane, stream_begin, stream_valid)
                                                prefix_roots: pl.Tile[[6, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.assemble(prefix_roots, stream_root, [stream_lane, 0])
                            if buf_max_leaves > 1:
                                for buf_query_lane_1 in pl.unroll(6):
                                    if buf_query_lane_1 < buf_group_rows:
                                        buf_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [buf_query + buf_query_lane_1])
                                        buf_query_visible: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(buf_cache_len, (buf_position + 1) // 4), 262144), 0)
                                        buf_half_begin: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_lane_begin
                                        buf_half_valid: pl.Scalar[pl.INDEX] = pl.max(pl.min(buf_query_visible - buf_half_begin, buf_lane_span), 0)
                                        buf_half_slot: pl.Scalar[pl.INDEX] = (buf_query + buf_query_lane_1) * 64 + buf_leaf * 2 + buf_score_lane
                                        if buf_half_valid > 0:
                                            self.indexer_topk_half_leaf(score_arena, pair_arena, buf_worker * 2 * 6 + buf_query_lane_1 * 2 + buf_score_lane, buf_half_begin, buf_half_valid, buf_half_slot)
                                        else:
                                            pl.tile.store(pl.tile.full([1, 1024], dtype=pl.FP32, value=-3.4028234663852886e+38), [buf_half_slot, 0], pair_arena)
        return buffered_leaf_tid
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def indexer_head_coefficients__2(self, qr_hadamard_scale_dq: pl.Tensor[[27648, 1], pl.FP32], weights: pl.Tensor[[432, 64], pl.FP32], kv_seq_lens: pl.Tensor[[B_DYN], pl.INT32], group_row: pl.Tensor[[432], pl.INT32], group_rows: pl.Tensor[[432], pl.INT32], group_count_t: pl.Tensor[[1], pl.INT32], groups_tid: pl.Scalar[pl.TASK_ID], qh_quant_tid: pl.Scalar[pl.TASK_ID], weights_tid: pl.Scalar[pl.TASK_ID]):
        # 把同组query的FP16系数放在对角块，一次Cube完成各自的head规约。
        coefficients: pl.Tensor[[3456, 128], pl.FP16] = pl.tensor.create([3456, 128], dtype=pl.FP16, layout=pl.TensorLayout.ND)
        coefficient_scales: pl.Tensor[[432, 64], pl.FP32] = pl.tensor.reshape(qr_hadamard_scale_dq, [432, 64])
        coefficient_workers: pl.Scalar[pl.INDEX] = pl.min(48, pl.tensor.dim(kv_seq_lens, 0) * 3)
        with pl.spmd(coefficient_workers, name_hint="indexer_head_coefficients_spmd", deps=[groups_tid, qh_quant_tid, weights_tid], allow_early_resolve=True) as coefficients_tid:
            coefficient_worker: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
            coefficient_count: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_count_t, [0]), pl.INDEX)
            for coefficient_pair in pl.range(coefficient_worker, coefficient_count, 48):
                coefficient_rows: pl.Tile[[32, 64], pl.FP16, pl.Mem.Vec] = pl.tile.full([32, 64], dtype=pl.FP16, value=0.0)
                coefficient_begin: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_row, [coefficient_pair]), pl.INDEX)
                query_scales: pl.Tile[[2, 64], pl.FP32] = pl.tile.load(coefficient_scales, [coefficient_begin, 0], [2, 64], [2, 64])
                query_weights: pl.Tile[[2, 64], pl.FP32] = pl.tile.load(weights, [coefficient_begin, 0], [2, 64], [2, 64])
                query_scale_half: pl.Tile[[2, 64], pl.FP16, pl.Mem.Vec] = pl.tile.cast(query_scales, target_type=pl.FP16, mode='rint')
                query_weight_half: pl.Tile[[2, 64], pl.FP16, pl.Mem.Vec] = pl.tile.cast(query_weights, target_type=pl.FP16, mode='rint')
                head_coefficients: pl.Tile[[2, 64], pl.FP16, pl.Mem.Vec] = pl.tile.mul(query_scale_half, query_weight_half)
                for coefficient_lane in pl.unroll(2):
                    if coefficient_lane < pl.cast(pl.tensor.read(group_rows, [coefficient_pair]), pl.INDEX):
                        head_coefficient: pl.Tile[[1, 64], pl.FP16, pl.Mem.Vec] = pl.tile.extract(head_coefficients, coefficient_lane, 0, [1, 64], target_memory=pl.Mem.Vec)
                        coefficient_rows: pl.Tile[[32, 64], pl.FP16, pl.Mem.Vec] = pl.tile.assemble(coefficient_rows, head_coefficient, [coefficient_lane * 3, 0])
                coefficient_matrix: pl.Tile[[16, 128], pl.FP16, pl.Mem.Vec] = pl.tile.reshape(coefficient_rows, [16, 128])
                pl.tile.store(coefficient_matrix, [coefficient_pair * 16, 0], coefficients)
        return coefficients, coefficients_tid
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def indexer_score_topk_native_cube__2(self, qr_hadamard_i8: pl.Tensor[[27648, 128], pl.INT8], qr_hadamard_scale_dq: pl.Tensor[[27648, 1], pl.FP32], weights: pl.Tensor[[432, 64], pl.FP32], idx_native_kv_cache: pl.Tensor[[IDX_NATIVE_CACHE_BLOCK_NUM_DYN, INDEXER_PAGE_BYTES_DYN], pl.INT8], idx_block_table: pl.Tensor[[B_DYN, INDEXER_TABLE_COLUMNS_DYN], pl.INT32], position_ids: pl.Tensor[[T_DYN], pl.INT64], kv_seq_lens: pl.Tensor[[B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], group_row: pl.Tensor[[432], pl.INT32], group_rows: pl.Tensor[[432], pl.INT32], group_count_t: pl.Tensor[[1], pl.INT32], groups_tid: pl.Scalar[pl.TASK_ID], score_arena: pl.Tensor[[432, 8192], pl.FP32], pair_arena: pl.Tensor[[27648, 1024], pl.FP32], qh_quant_tid: pl.Scalar[pl.TASK_ID], weights_tid: pl.Scalar[pl.TASK_ID], cache_write_tid: pl.Scalar[pl.TASK_ID]):
        # 同组query共用Key：双query/M128/N128或S6/M384/N64，保持FP16/Cube策略。
        native_page_bytes: pl.Scalar[pl.INDEX] = pl.tensor.dim(idx_native_kv_cache, 1)
        cache_bytes: pl.Scalar[pl.INDEX] = pl.tensor.dim(idx_native_kv_cache, 0) * native_page_bytes
        cache_flat: pl.Tensor[[cache_bytes], pl.INT8] = pl.tensor.reshape(idx_native_kv_cache, [cache_bytes])
        key_rows: pl.Scalar[pl.INDEX] = cache_bytes // 128
        shifted_rows: pl.Scalar[pl.INDEX] = (cache_bytes - 64) // 128
        idx_kv_cache: pl.Tensor[[key_rows, 128], pl.INT8] = pl.tensor.reshape(pl.tensor.slice(cache_flat, [key_rows * 128], [0]), [key_rows, 128])
        idx_kv_cache_shift64: pl.Tensor[[shifted_rows, 128], pl.INT8] = pl.tensor.reshape(pl.tensor.slice(cache_flat, [shifted_rows * 128], [64]), [shifted_rows, 128])
        _tuple_tmp: pl.Tuple[pl.Tensor[[3456, 128], pl.FP16], pl.Scalar[pl.TASK_ID]] = self.indexer_head_coefficients__2(qr_hadamard_scale_dq, weights, kv_seq_lens, group_row, group_rows, group_count_t, groups_tid, qh_quant_tid, weights_tid)
        coefficients: pl.Tensor[[3456, 128], pl.FP16] = _tuple_tmp[0]
        coefficients_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp[1]
        buf_score_transfer: pl.Tensor[[96, 1024], pl.FP32] = pl.tensor.create([96, 1024], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        buf_score_ffts: pl.Tensor[[256], pl.INT64] = pl.tensor.create([256], dtype=pl.INT64, layout=pl.TensorLayout.ND)
        with pl.spmd(24, sync_start=True, name_hint="indexer_score_topk_native_pair_spmd", deps=[groups_tid, coefficients_tid, cache_write_tid]) as buffered_leaf_tid:
            buf_worker: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
            buf_max_cache_len: pl.Scalar[pl.INDEX] = 0
            for buf_batch in pl.range(pl.tensor.dim(kv_seq_lens, 0)):
                buf_max_cache_len: pl.Scalar[pl.INDEX] = pl.max(buf_max_cache_len, pl.cast(pl.tensor.read(kv_seq_lens, [buf_batch]), pl.INDEX) // 4)
            buf_capped_history: pl.Scalar[pl.INDEX] = pl.min(buf_max_cache_len, 262144)
            buf_max_leaves: pl.Scalar[pl.INDEX] = pl.max((buf_capped_history + 8192 - 1) // 8192, 1)
            buf_leaf_tiles: pl.Scalar[pl.INDEX] = 8
            buf_extra_leaves: pl.Scalar[pl.INDEX] = 0
            buf_group_count: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_count_t, [0]), pl.INDEX)
            if False:
                _tuple_tmp_1: pl.Tuple[pl.Scalar[pl.INDEX], pl.Scalar[pl.INDEX], pl.Scalar[pl.INDEX]] = self.indexer_long_leaf_plan(buf_capped_history, buf_group_count)
                buf_max_leaves: pl.Scalar[pl.INDEX] = _tuple_tmp_1[0]
                buf_leaf_tiles: pl.Scalar[pl.INDEX] = _tuple_tmp_1[1]
                buf_extra_leaves: pl.Scalar[pl.INDEX] = _tuple_tmp_1[2]
            pl.system.set_ffts(buf_score_ffts)
            for buf_item in pl.range(buf_worker, buf_group_count * buf_max_leaves, 24):
                if buf_group_count < 24:
                    buf_group: pl.Scalar[pl.INDEX] = buf_item % buf_group_count
                    buf_leaf: pl.Scalar[pl.INDEX] = buf_item // buf_group_count
                else:
                    buf_group: pl.Scalar[pl.INDEX] = buf_item // buf_max_leaves
                    buf_leaf: pl.Scalar[pl.INDEX] = buf_item % buf_max_leaves
                buf_query: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_row, [buf_group]), pl.INDEX)
                buf_group_rows: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_rows, [buf_group]), pl.INDEX)
                buf_batch_idx: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(token_request, [buf_query]), pl.INDEX)
                buf_last_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [buf_query + buf_group_rows - 1])
                buf_cache_len: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(kv_seq_lens, [buf_batch_idx]), pl.INDEX) // 4
                buf_visible_count: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(buf_cache_len, (buf_last_position + 1) // 4), 262144), 0)
                buf_logical_begin: pl.Scalar[pl.INDEX] = buf_leaf * 8192
                buf_leaf_capacity: pl.Scalar[pl.INDEX] = 8192
                if False:
                    buf_logical_begin: pl.Scalar[pl.INDEX] = (buf_leaf * buf_leaf_tiles + pl.min(buf_leaf, buf_extra_leaves)) * 1024
                    buf_leaf_capacity: pl.Scalar[pl.INDEX] = (buf_leaf_tiles + pl.cast(buf_leaf < buf_extra_leaves, pl.INDEX)) * 1024
                if buf_logical_begin < buf_visible_count:
                    buf_valid_count: pl.Scalar[pl.INDEX] = pl.min(buf_leaf_capacity, buf_visible_count - buf_logical_begin)
                    buf_tile_count: pl.Scalar[pl.INDEX] = (buf_valid_count + 1024 - 1) // 1024
                    buf_lane_span: pl.Scalar[pl.INDEX] = pl.min(buf_tile_count * 512, 4096)
                    buf_score_iters: pl.Scalar[pl.INDEX] = (buf_lane_span + 512 - 1) // 512
                    buf_query_vector: pl.Tile[[128, 128], pl.INT8, pl.Mem.Mat] = pl.tile.load(qr_hadamard_i8, [buf_query * 64, 0], [128, 128], [128, 128], target_memory=pl.Mem.Mat)
                    buf_coefficients_l1: pl.Tile[[16, 128], pl.FP16, pl.Mem.Mat] = pl.tile.load(coefficients, [buf_group * 16, 0], [16, 128], [16, 128], target_memory=pl.Mem.Mat)
                    buf_query_left: pl.Tile[[128, 128], pl.INT8, pl.Mem.Left] = pl.tile.move(buf_query_vector, target_memory=pl.Mem.Left)
                    buf_coefficient_pair: pl.Tile[[16, 128], pl.FP16, pl.Mem.Left] = pl.tile.move(buf_coefficients_l1, target_memory=pl.Mem.Left)
                    for buf_score_step in pl.range(buf_score_iters):
                        if buf_score_step >= 2:
                            pl.system.sync_wait(1, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIC)
                        buf_score_begin: pl.Scalar[pl.INDEX] = buf_score_step * 512
                        if False:
                            buf_score_begin: pl.Scalar[pl.INDEX] = buf_score_step * 1024
                        buf_transfer_row: pl.Scalar[pl.INDEX] = buf_worker * 2 * 2 + buf_score_step % 2 * 2
                        buf_previous_l1: pl.Tile[[128, 128], pl.FP16, pl.Mem.Mat] = pl.tile.create([128, 128], dtype=pl.FP16, target_memory=pl.Mem.Mat)
                        buf_current_key: pl.Tile[[128, 128], pl.INT8, pl.Mem.Right] = pl.tile.create([128, 128], dtype=pl.INT8, target_memory=pl.Mem.Right)
                        buf_prefetched_key: pl.Tile[[128, 128], pl.INT8, pl.Mem.Right] = pl.tile.create([128, 128], dtype=pl.INT8, target_memory=pl.Mem.Right)
                        buf_key_l1_pool: pl.Tile[[256, 128], pl.INT8, pl.Mem.Mat] = pl.tile.create([256, 128], dtype=pl.INT8, target_memory=pl.Mem.Mat)
                        if pl.const(1, pl.INDEX) > pl.const(0, pl.INDEX):
                            buf_prime_col: pl.Scalar[pl.INDEX] = 0
                            for buf_prime_key_page in pl.unroll(4):
                                buf_prime_key_row: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_score_begin + buf_prime_col // 512 * buf_lane_span + buf_prime_col % 512 + buf_prime_key_page * 32
                                if False:
                                    buf_prime_key_row: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_score_begin + buf_prime_col + buf_prime_key_page * 32
                                buf_prime_safe_page: pl.Scalar[pl.INDEX] = pl.min(buf_prime_key_row // 32, pl.max((buf_cache_len - 1) // 32, 0))
                                buf_prime_physical_page: pl.Scalar[pl.INDEX] = pl.max(pl.cast(pl.tensor.read(idx_block_table, [buf_batch_idx, buf_prime_safe_page]), pl.INDEX), 0)
                                buf_prime_native_byte: pl.Scalar[pl.INDEX] = buf_prime_physical_page * native_page_bytes
                                if buf_prime_native_byte % 128 == 0:
                                    buf_key_l1_pool: pl.Tile[[256, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_key_l1_pool, idx_kv_cache, [buf_prime_key_page * 32, 0], [buf_prime_native_byte // 128, 0], [32, 128], transpose=False)
                                else:
                                    buf_key_l1_pool: pl.Tile[[256, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_key_l1_pool, idx_kv_cache_shift64, [buf_prime_key_page * 32, 0], [buf_prime_native_byte // 128, 0], [32, 128], transpose=False)
                            if True:
                                buf_current_key: pl.Tile[[128, 128], pl.INT8, pl.Mem.Right] = pl.tile.extract(pl.tile.transpose_view(buf_key_l1_pool), 0, 0, [128, 128], target_memory=pl.Mem.Right)
                        for buf_qk_panel in pl.unroll(8):
                            buf_panel_col: pl.Scalar[pl.INDEX] = buf_qk_panel * 128
                            buf_load_col: pl.Scalar[pl.INDEX] = (buf_qk_panel + 1) * 128
                            buf_load_slot: pl.Scalar[pl.INDEX] = (buf_qk_panel + 1) % 2 * 128
                            if pl.const(1, pl.INDEX) > pl.const(0, pl.INDEX):
                                if not True:
                                    buf_current_key: pl.Tile[[128, 128], pl.INT8, pl.Mem.Right] = pl.tile.extract(pl.tile.transpose_view(buf_key_l1_pool), 0, buf_qk_panel % 2 * 128, [128, 128], target_memory=pl.Mem.Right)
                            if buf_qk_panel + 1 < 8:
                                buf_panel_keys: pl.Tile[[128, 128], pl.INT8, pl.Mem.Mat] = pl.tile.create([128, 128], dtype=pl.INT8, target_memory=pl.Mem.Mat)
                                for buf_key_page in pl.unroll(4):
                                    buf_key_row: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_score_begin + buf_load_col // 512 * buf_lane_span + buf_load_col % 512 + buf_key_page * 32
                                    if False:
                                        buf_key_row: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_score_begin + buf_load_col + buf_key_page * 32
                                    buf_safe_page: pl.Scalar[pl.INDEX] = pl.min(buf_key_row // 32, pl.max((buf_cache_len - 1) // 32, 0))
                                    buf_physical_page: pl.Scalar[pl.INDEX] = pl.max(pl.cast(pl.tensor.read(idx_block_table, [buf_batch_idx, buf_safe_page]), pl.INDEX), 0)
                                    buf_native_byte: pl.Scalar[pl.INDEX] = buf_physical_page * native_page_bytes
                                    if buf_native_byte % 128 == 0:
                                        if pl.const(1, pl.INDEX) > pl.const(0, pl.INDEX):
                                            buf_key_l1_pool: pl.Tile[[256, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_key_l1_pool, idx_kv_cache, [buf_load_slot + buf_key_page * 32, 0], [buf_native_byte // 128, 0], [32, 128], transpose=False)
                                        else:
                                            buf_panel_keys: pl.Tile[[128, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_panel_keys, idx_kv_cache, [buf_key_page * 32, 0], [buf_native_byte // 128, 0], [32, 128], transpose=False)
                                    else:
                                        if pl.const(1, pl.INDEX) > pl.const(0, pl.INDEX):
                                            buf_key_l1_pool: pl.Tile[[256, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_key_l1_pool, idx_kv_cache_shift64, [buf_load_slot + buf_key_page * 32, 0], [buf_native_byte // 128, 0], [32, 128], transpose=False)
                                        else:
                                            buf_panel_keys: pl.Tile[[128, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_panel_keys, idx_kv_cache_shift64, [buf_key_page * 32, 0], [buf_native_byte // 128, 0], [32, 128], transpose=False)
                                if pl.const(1, pl.INDEX) > pl.const(0, pl.INDEX):
                                    if True:
                                        buf_prefetched_key: pl.Tile[[128, 128], pl.INT8, pl.Mem.Right] = pl.tile.extract(pl.tile.transpose_view(buf_key_l1_pool), 0, buf_load_slot, [128, 128], target_memory=pl.Mem.Right)
                                else:
                                    buf_prefetched_key: pl.Tile[[128, 128], pl.INT8, pl.Mem.Right] = pl.tile.move(pl.tile.transpose_view(buf_panel_keys), target_memory=pl.Mem.Right)
                            if pl.const(1, pl.INDEX) > pl.const(0, pl.INDEX):
                                buf_key_panel: pl.Tile[[128, 128], pl.INT8, pl.Mem.Right] = buf_current_key
                            else:
                                buf_key_panel: pl.Tile[[128, 128], pl.INT8, pl.Mem.Right] = buf_prefetched_key
                            buf_scores_l1: pl.Tile[[128, 128], pl.FP16, pl.Mem.Mat] = pl.tile.create([128, 128], dtype=pl.FP16, target_memory=pl.Mem.Mat)
                            if buf_qk_panel > 0:
                                buf_previous_pair: pl.Tile[[128, 128], pl.FP16, pl.Mem.Right] = pl.tile.extract(buf_previous_l1, 0, 0, [128, 128], target_memory=pl.Mem.Right)
                                buf_scores: pl.Tile[[128, 128], pl.INT32, pl.Mem.Acc] = pl.tile.matmul(buf_query_left, buf_key_panel)
                                buf_reduced_pair: pl.Tile[[16, 128], pl.FP32, pl.Mem.Acc] = pl.tile.matmul(buf_coefficient_pair, buf_previous_pair)
                                buf_scores_l1: pl.Tile[[128, 128], pl.FP16, pl.Mem.Mat] = pl.tile.assemble(buf_scores_l1, buf_scores, [0, 0], pre_quant=0.0009765625, pre_relu=True)
                                pl.tile.store(pl.tile.set_validshape(buf_reduced_pair, 2, 128), [buf_transfer_row, buf_panel_col - 128], buf_score_transfer)
                            else:
                                buf_scores: pl.Tile[[128, 128], pl.INT32, pl.Mem.Acc] = pl.tile.matmul(buf_query_left, buf_key_panel)
                                buf_scores_l1: pl.Tile[[128, 128], pl.FP16, pl.Mem.Mat] = pl.tile.assemble(buf_scores_l1, buf_scores, [0, 0], pre_quant=0.0009765625, pre_relu=True)
                            buf_previous_l1: pl.Tile[[128, 128], pl.FP16, pl.Mem.Mat] = buf_scores_l1
                            if pl.const(1, pl.INDEX) > pl.const(0, pl.INDEX):
                                if True:
                                    if buf_qk_panel + 1 < 8:
                                        buf_current_key: pl.Tile[[128, 128], pl.INT8, pl.Mem.Right] = buf_prefetched_key
                        buf_last_pair: pl.Tile[[128, 128], pl.FP16, pl.Mem.Right] = pl.tile.extract(buf_previous_l1, 0, 0, [128, 128], target_memory=pl.Mem.Right)
                        buf_last_scores: pl.Tile[[16, 128], pl.FP32, pl.Mem.Acc] = pl.tile.matmul(buf_coefficient_pair, buf_last_pair)
                        pl.tile.store(pl.tile.set_validshape(buf_last_scores, 2, 128), [buf_transfer_row, 896], buf_score_transfer)
                        pl.system.sync_set(0, pipe=pl.PipeType.FIX, ffts_mode=2, core_type=pl.KernelType.AIC)
                    for buf_score_drain in pl.range(pl.min(buf_score_iters, 2)):
                        pl.system.sync_wait(1, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIC)
            for buf_score_lane in pl.split_aiv(2, mode=pl.SplitMode.NONE):
                if False:
                    for single_item in pl.range(buf_worker, buf_group_count * buf_max_leaves, 24):
                        if buf_group_count < 24:
                            single_group: pl.Scalar[pl.INDEX] = single_item % buf_group_count
                            single_leaf: pl.Scalar[pl.INDEX] = single_item // buf_group_count
                        else:
                            single_group: pl.Scalar[pl.INDEX] = single_item // buf_max_leaves
                            single_leaf: pl.Scalar[pl.INDEX] = single_item % buf_max_leaves
                        single_query: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_row, [single_group]), pl.INDEX)
                        single_group_rows: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_rows, [single_group]), pl.INDEX)
                        single_batch: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(token_request, [single_query]), pl.INDEX)
                        single_cache_len: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(kv_seq_lens, [single_batch]), pl.INDEX) // 4
                        single_last_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [single_query + single_group_rows - 1])
                        single_visible: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(single_cache_len, (single_last_position + 1) // 4), 262144), 0)
                        single_begin: pl.Scalar[pl.INDEX] = (single_leaf * buf_leaf_tiles + pl.min(single_leaf, buf_extra_leaves)) * 1024
                        single_capacity: pl.Scalar[pl.INDEX] = (buf_leaf_tiles + pl.cast(single_leaf < buf_extra_leaves, pl.INDEX)) * 1024
                        if single_begin < single_visible:
                            single_valid: pl.Scalar[pl.INDEX] = pl.min(single_capacity, single_visible - single_begin)
                            single_steps: pl.Scalar[pl.INDEX] = (single_valid + 1024 - 1) // 1024
                            single_roots: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.full([1, 1024], dtype=pl.FP32, value=-3.4028234663852886e+38)
                            single_segments: pl.Tile[[2, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.full([2, 1024], dtype=pl.FP32, value=-3.4028234663852886e+38)
                            for single_step in pl.range(single_steps):
                                single_score_begin: pl.Scalar[pl.INDEX] = single_begin + single_step * 1024
                                single_transfer_row: pl.Scalar[pl.INDEX] = buf_worker * 2 * 2 + single_step % 2 * 2 + buf_score_lane * 1
                                single_scale_bytes: pl.Tile[[1, 2048], pl.INT8] = pl.tile.create([1, 2048], dtype=pl.INT8)
                                for single_scale_page in pl.range(32):
                                    single_scale_logical: pl.Scalar[pl.INDEX] = pl.min(single_score_begin // 32 + single_scale_page, pl.max((single_cache_len - 1) // 32, 0))
                                    single_scale_physical: pl.Scalar[pl.INDEX] = pl.max(pl.cast(pl.tensor.read(idx_block_table, [single_batch, single_scale_logical]), pl.INDEX), 0)
                                    single_scale_bytes: pl.Tile[[1, 2048], pl.INT8] = pl.tile.gather_row(single_scale_bytes, idx_native_kv_cache, [0, single_scale_page * 32 * 2], [single_scale_physical, 4096], [1, 64], transpose=False)
                                single_scale_half: pl.Tile[[1, 1024], pl.FP16] = pl.tile.reinterpret_view(single_scale_bytes, dtype=pl.FP16)
                                single_kv_scale: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.cast(single_scale_half, target_type=pl.FP32, mode='round')
                                pl.system.sync_wait(0, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIV)
                                single_scores: pl.Tile[[1, 1024], pl.FP32] = pl.tile.load(buf_score_transfer, [single_transfer_row, 0], [1, 1024], [1, 1024])
                                pl.system.sync_set(1, pipe=pl.PipeType.MTE2, ffts_mode=2, core_type=pl.KernelType.AIV)
                                for single_local in pl.unroll(1):
                                    single_score_row: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_scores, single_local, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                    single_scaled: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.mul(single_score_row, single_kv_scale)
                                    single_segments: pl.Tile[[2, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.assemble(single_segments, single_scaled, [single_local * 2 + single_step % 2, 0])
                                if single_step % 2 == 1 or single_step + 1 == single_steps:
                                    single_segment_begin: pl.Scalar[pl.INDEX] = single_begin + single_step // 2 * 2048
                                    single_segment_span: pl.Scalar[pl.INDEX] = (single_step % 2 + 1) * 1024
                                    single_segment_rows: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec] = pl.tile.reshape(single_segments, [1, 2048])
                                    for single_local_1 in pl.unroll(1):
                                        single_query_lane: pl.Scalar[pl.INDEX] = buf_score_lane * 1 + single_local_1
                                        single_lane_live: pl.Scalar[pl.BOOL] = single_query_lane < single_group_rows
                                        single_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [single_query + pl.min(single_query_lane, single_group_rows - 1)])
                                        single_query_visible: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(single_cache_len, (single_position + 1) // 4), 262144), 0)
                                        single_segment_valid: pl.Scalar[pl.INDEX] = pl.max(pl.min(single_query_visible - single_segment_begin, single_segment_span), 0)
                                        if single_segment_valid > 0 and single_lane_live:
                                            single_segment_data: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_segment_rows, single_local_1, 0, [1, 2048], target_memory=pl.Mem.Vec)
                                            logical_i32: pl.Scalar[pl.INT32] = pl.cast(single_segment_begin, pl.INT32)
                                            if single_segment_valid <= 512:
                                                tiny_indices: pl.Tile[[1, 512], pl.INT32, pl.Mem.Vec] = pl.tile.adds(pl.tile.ci(pl.const(0, pl.INT32), [1, 512], dtype=pl.INT32, descending=False), logical_i32)
                                                tiny_tile: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_segment_data, 0, 0, [1, 512], target_memory=pl.Mem.Vec)
                                                tiny_raw: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[1, single_segment_valid])] = pl.tile.set_validshape(tiny_tile, 1, single_segment_valid)
                                                tiny_scores: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximums(pl.tile.fillpad(tiny_raw, pad_value=pl.PadValue.min), -3.4028234663852886e+38)
                                                tiny_pairs: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(tiny_scores, pl.tile.reinterpret_view(tiny_indices, dtype=pl.UINT32))
                                                tiny_pairs_v1: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(tiny_pairs, pl.const(64, pl.INT32))
                                                tiny_pairs_v2: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(tiny_pairs_v1, pl.const(256, pl.INT32))
                                                single_new_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(tiny_pairs_v2, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                            else:
                                                if single_segment_valid <= 1024:
                                                    small_indices: pl.Tile[[1, 1024], pl.INT32, pl.Mem.Vec] = pl.tile.adds(pl.tile.ci(pl.const(0, pl.INT32), [1, 1024], dtype=pl.INT32, descending=False), logical_i32)
                                                    small_tile: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_segment_data, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                                    small_raw: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[1, single_segment_valid])] = pl.tile.set_validshape(small_tile, 1, single_segment_valid)
                                                    small_scores: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximums(pl.tile.fillpad(small_raw, pad_value=pl.PadValue.min), -3.4028234663852886e+38)
                                                    small_pairs: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(small_scores, pl.tile.reinterpret_view(small_indices, dtype=pl.UINT32))
                                                    small_pairs_v1: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(small_pairs, pl.const(64, pl.INT32))
                                                    small_pairs_v2: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(small_pairs_v1, pl.const(256, pl.INT32))
                                                    small_left: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(small_pairs_v2, [1, 1024], [0, 0])
                                                    small_right: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(small_pairs_v2, [1, 1024], [0, 1024])
                                                    small_tmp: pl.Tile[[1, 2048], pl.FP32] = pl.tile.create([1, 2048], dtype=pl.FP32)
                                                    small_merged: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format2(small_left, small_right, small_tmp, exhausted=False)
                                                    single_new_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(small_merged, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                                else:
                                                    large_indices: pl.Tile[[1, 2048], pl.INT32, pl.Mem.Vec] = pl.tile.adds(pl.tile.ci(pl.const(0, pl.INT32), [1, 2048], dtype=pl.INT32, descending=False), logical_i32)
                                                    large_tile: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_segment_data, 0, 0, [1, 2048], target_memory=pl.Mem.Vec)
                                                    large_raw: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[1, single_segment_valid])] = pl.tile.set_validshape(large_tile, 1, single_segment_valid)
                                                    large_scores: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximums(pl.tile.fillpad(large_raw, pad_value=pl.PadValue.min), -3.4028234663852886e+38)
                                                    large_pairs: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(large_scores, pl.tile.reinterpret_view(large_indices, dtype=pl.UINT32))
                                                    large_pairs_v1: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(large_pairs, pl.const(64, pl.INT32))
                                                    large_pairs_v2: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(large_pairs_v1, pl.const(256, pl.INT32))
                                                    large_pairs_v3: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(large_pairs_v2, pl.const(1024, pl.INT32))
                                                    single_new_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(large_pairs_v3, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                            if single_step < 2:
                                                single_roots: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.assemble(single_roots, single_new_root, [single_local_1, 0])
                                            else:
                                                single_old_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_roots, single_local_1, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                                single_merge_tmp: pl.Tile[[1, 2048], pl.FP32] = pl.tile.create([1, 2048], dtype=pl.FP32)
                                                single_merged: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec] = pl.tile.mrgsort_format2(single_new_root, single_old_root, single_merge_tmp, exhausted=False)
                                                single_next_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_merged, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                                single_roots: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.assemble(single_roots, single_next_root, [single_local_1, 0])
                            for single_local_2 in pl.unroll(1):
                                single_query_lane: pl.Scalar[pl.INDEX] = buf_score_lane * 1 + single_local_2
                                if single_query_lane < single_group_rows:
                                    single_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_roots, single_local_2, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                    pl.tile.store(single_root, [(single_query + single_query_lane) * 64 + single_leaf, 0], pair_arena)
                else:
                    for buf_item_1 in pl.range(buf_worker, buf_group_count * buf_max_leaves, 24):
                        if buf_group_count < 24:
                            buf_group: pl.Scalar[pl.INDEX] = buf_item_1 % buf_group_count
                            buf_leaf: pl.Scalar[pl.INDEX] = buf_item_1 // buf_group_count
                        else:
                            buf_group: pl.Scalar[pl.INDEX] = buf_item_1 // buf_max_leaves
                            buf_leaf: pl.Scalar[pl.INDEX] = buf_item_1 % buf_max_leaves
                        buf_query: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_row, [buf_group]), pl.INDEX)
                        buf_group_rows: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_rows, [buf_group]), pl.INDEX)
                        buf_batch_idx: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(token_request, [buf_query]), pl.INDEX)
                        buf_last_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [buf_query + buf_group_rows - 1])
                        buf_cache_len: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(kv_seq_lens, [buf_batch_idx]), pl.INDEX) // 4
                        buf_visible_count: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(buf_cache_len, (buf_last_position + 1) // 4), 262144), 0)
                        buf_logical_begin: pl.Scalar[pl.INDEX] = buf_leaf * 8192
                        buf_leaf_capacity: pl.Scalar[pl.INDEX] = 8192
                        if False:
                            buf_logical_begin: pl.Scalar[pl.INDEX] = (buf_leaf * buf_leaf_tiles + pl.min(buf_leaf, buf_extra_leaves)) * 1024
                            buf_leaf_capacity: pl.Scalar[pl.INDEX] = (buf_leaf_tiles + pl.cast(buf_leaf < buf_extra_leaves, pl.INDEX)) * 1024
                        if buf_logical_begin < buf_visible_count:
                            buf_valid_count: pl.Scalar[pl.INDEX] = pl.min(buf_leaf_capacity, buf_visible_count - buf_logical_begin)
                            buf_tile_count: pl.Scalar[pl.INDEX] = (buf_valid_count + 1024 - 1) // 1024
                            buf_lane_span: pl.Scalar[pl.INDEX] = pl.min(buf_tile_count * 512, 4096)
                            buf_score_iters: pl.Scalar[pl.INDEX] = (buf_lane_span + 512 - 1) // 512
                            buf_lane_begin: pl.Scalar[pl.INDEX] = buf_score_lane * buf_lane_span
                            prefix_roots: pl.Tile[[2, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.full([2, 1024], dtype=pl.FP32, value=-3.4028234663852886e+38)
                            for buf_score_step_1 in pl.range(buf_score_iters):
                                buf_score_begin: pl.Scalar[pl.INDEX] = buf_score_step_1 * 512
                                buf_transfer_row: pl.Scalar[pl.INDEX] = buf_worker * 2 * 2 + buf_score_step_1 % 2 * 2
                                buf_scale_bytes: pl.Tile[[1, 1024], pl.INT8] = pl.tile.create([1, 1024], dtype=pl.INT8)
                                for buf_scale_page in pl.range(16):
                                    buf_scale_row: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_score_begin + buf_lane_begin + buf_scale_page * 32
                                    buf_scale_safe_page: pl.Scalar[pl.INDEX] = pl.min(buf_scale_row // 32, pl.max((buf_cache_len - 1) // 32, 0))
                                    buf_scale_physical_page: pl.Scalar[pl.INDEX] = pl.max(pl.cast(pl.tensor.read(idx_block_table, [buf_batch_idx, buf_scale_safe_page]), pl.INDEX), 0)
                                    buf_scale_bytes: pl.Tile[[1, 1024], pl.INT8] = pl.tile.gather_row(buf_scale_bytes, idx_native_kv_cache, [0, buf_scale_page * 32 * 2], [buf_scale_physical_page, 4096], [1, 64], transpose=False)
                                buf_scale_half: pl.Tile[[1, 512], pl.FP16] = pl.tile.reinterpret_view(buf_scale_bytes, dtype=pl.FP16)
                                buf_kv_scale: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec] = pl.tile.cast(buf_scale_half, target_type=pl.FP32, mode='round')
                                pl.system.sync_wait(0, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIV)
                                buf_score_sums: pl.Tile[[2, 512], pl.FP32] = pl.tile.load(buf_score_transfer, [buf_transfer_row, buf_score_lane * 512], [2, 512], [2, 512])
                                pl.system.sync_set(1, pipe=pl.PipeType.MTE2, ffts_mode=2, core_type=pl.KernelType.AIV)
                                for buf_query_lane in pl.unroll(2):
                                    buf_lane_live: pl.Scalar[pl.BOOL] = buf_query_lane < buf_group_rows
                                    buf_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [buf_query + pl.min(buf_query_lane, buf_group_rows - 1)])
                                    buf_query_visible: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(buf_cache_len, (buf_position + 1) // 4), 262144), 0)
                                    buf_lane_valid_rows: pl.Scalar[pl.INDEX] = pl.max(pl.min(buf_query_visible - buf_logical_begin - buf_score_begin - buf_lane_begin, 512), 0)
                                    buf_lane_valid_rows_v1: pl.Scalar[pl.INDEX] = pl.min(buf_lane_valid_rows, pl.max(buf_lane_span - buf_score_begin, 0))
                                    buf_score_sum: pl.Tile[[1, 512], pl.FP32] = pl.tile.slice(buf_score_sums, [1, 512], [buf_query_lane, 0])
                                    buf_score_row: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec] = pl.tile.mul(buf_score_sum, buf_kv_scale)
                                    buf_store_row: pl.Scalar[pl.INDEX] = buf_query + buf_query_lane
                                    buf_store_column: pl.Scalar[pl.INDEX] = buf_score_begin + buf_lane_begin
                                    if buf_max_leaves > 1:
                                        buf_store_row: pl.Scalar[pl.INDEX] = buf_worker * 2 * 2 + buf_query_lane * 2 + buf_score_lane
                                        buf_store_column: pl.Scalar[pl.INDEX] = buf_score_begin
                                    if buf_lane_valid_rows_v1 > 0 and buf_lane_live:
                                        pl.tile.store(pl.tile.set_validshape(buf_score_row, 1, buf_lane_valid_rows_v1), [buf_store_row, buf_store_column], score_arena)
                                if False:
                                    if buf_score_step_1 == 3 and buf_score_iters > 4:
                                        for stream_lane in pl.unroll(2):
                                            stream_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [buf_query + pl.min(stream_lane, buf_group_rows - 1)])
                                            stream_visible: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(buf_cache_len, (stream_position + 1) // 4), 262144), 0)
                                            stream_begin: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_lane_begin
                                            stream_valid: pl.Scalar[pl.INDEX] = pl.max(pl.min(stream_visible - stream_begin, 2048), 0)
                                            if stream_valid > 0 and stream_lane < buf_group_rows:
                                                stream_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = self.indexer_topk_segment_pairs(score_arena, buf_worker * 2 * 2 + stream_lane * 2 + buf_score_lane, stream_begin, stream_valid)
                                                prefix_roots: pl.Tile[[2, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.assemble(prefix_roots, stream_root, [stream_lane, 0])
                            if buf_max_leaves > 1:
                                for buf_query_lane_1 in pl.unroll(2):
                                    if buf_query_lane_1 < buf_group_rows:
                                        buf_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [buf_query + buf_query_lane_1])
                                        buf_query_visible: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(buf_cache_len, (buf_position + 1) // 4), 262144), 0)
                                        buf_half_begin: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_lane_begin
                                        buf_half_valid: pl.Scalar[pl.INDEX] = pl.max(pl.min(buf_query_visible - buf_half_begin, buf_lane_span), 0)
                                        buf_half_slot: pl.Scalar[pl.INDEX] = (buf_query + buf_query_lane_1) * 64 + buf_leaf * 2 + buf_score_lane
                                        if buf_half_valid > 0:
                                            self.indexer_topk_half_leaf(score_arena, pair_arena, buf_worker * 2 * 2 + buf_query_lane_1 * 2 + buf_score_lane, buf_half_begin, buf_half_valid, buf_half_slot)
                                        else:
                                            pl.tile.store(pl.tile.full([1, 1024], dtype=pl.FP32, value=-3.4028234663852886e+38), [buf_half_slot, 0], pair_arena)
        return buffered_leaf_tid
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def indexer_score_topk_native_cube__3(self, qr_hadamard_i8: pl.Tensor[[27648, 128], pl.INT8], qr_hadamard_scale_dq: pl.Tensor[[27648, 1], pl.FP32], weights: pl.Tensor[[432, 64], pl.FP32], idx_native_kv_cache: pl.Tensor[[IDX_NATIVE_CACHE_BLOCK_NUM_DYN, INDEXER_PAGE_BYTES_DYN], pl.INT8], idx_block_table: pl.Tensor[[B_DYN, INDEXER_TABLE_COLUMNS_DYN], pl.INT32], position_ids: pl.Tensor[[T_DYN], pl.INT64], kv_seq_lens: pl.Tensor[[B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], group_row: pl.Tensor[[432], pl.INT32], group_rows: pl.Tensor[[432], pl.INT32], group_count_t: pl.Tensor[[1], pl.INT32], groups_tid: pl.Scalar[pl.TASK_ID], score_arena: pl.Tensor[[432, 8192], pl.FP32], pair_arena: pl.Tensor[[27648, 1024], pl.FP32], qh_quant_tid: pl.Scalar[pl.TASK_ID], weights_tid: pl.Scalar[pl.TASK_ID], cache_write_tid: pl.Scalar[pl.TASK_ID]):
        # 同组query共用Key：双query/M128/N128或S6/M384/N64，保持FP16/Cube策略。
        native_page_bytes: pl.Scalar[pl.INDEX] = pl.tensor.dim(idx_native_kv_cache, 1)
        cache_bytes: pl.Scalar[pl.INDEX] = pl.tensor.dim(idx_native_kv_cache, 0) * native_page_bytes
        cache_flat: pl.Tensor[[cache_bytes], pl.INT8] = pl.tensor.reshape(idx_native_kv_cache, [cache_bytes])
        key_rows: pl.Scalar[pl.INDEX] = cache_bytes // 128
        shifted_rows: pl.Scalar[pl.INDEX] = (cache_bytes - 64) // 128
        idx_kv_cache: pl.Tensor[[key_rows, 128], pl.INT8] = pl.tensor.reshape(pl.tensor.slice(cache_flat, [key_rows * 128], [0]), [key_rows, 128])
        idx_kv_cache_shift64: pl.Tensor[[shifted_rows, 128], pl.INT8] = pl.tensor.reshape(pl.tensor.slice(cache_flat, [shifted_rows * 128], [64]), [shifted_rows, 128])
        _tuple_tmp: pl.Tuple[pl.Tensor[[1152, 384], pl.FP16], pl.Scalar[pl.TASK_ID]] = self.indexer_head_coefficients(qr_hadamard_scale_dq, weights, kv_seq_lens, group_row, group_rows, group_count_t, groups_tid, qh_quant_tid, weights_tid)
        coefficients: pl.Tensor[[1152, 384], pl.FP16] = _tuple_tmp[0]
        coefficients_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp[1]
        buf_score_transfer: pl.Tensor[[288, 768], pl.FP32] = pl.tensor.create([288, 768], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        buf_score_ffts: pl.Tensor[[256], pl.INT64] = pl.tensor.create([256], dtype=pl.INT64, layout=pl.TensorLayout.ND)
        with pl.spmd(24, name_hint="indexer_score_topk_native_pair_spmd", deps=[groups_tid, coefficients_tid, cache_write_tid], allow_early_resolve=True) as buffered_leaf_tid:
            buf_worker: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
            buf_max_cache_len: pl.Scalar[pl.INDEX] = 0
            for buf_batch in pl.range(pl.tensor.dim(kv_seq_lens, 0)):
                buf_max_cache_len: pl.Scalar[pl.INDEX] = pl.max(buf_max_cache_len, pl.cast(pl.tensor.read(kv_seq_lens, [buf_batch]), pl.INDEX) // 4)
            buf_capped_history: pl.Scalar[pl.INDEX] = pl.min(buf_max_cache_len, 262144)
            buf_max_leaves: pl.Scalar[pl.INDEX] = pl.max((buf_capped_history + 8192 - 1) // 8192, 1)
            buf_leaf_tiles: pl.Scalar[pl.INDEX] = 8
            buf_extra_leaves: pl.Scalar[pl.INDEX] = 0
            buf_group_count: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_count_t, [0]), pl.INDEX)
            if False:
                _tuple_tmp_1: pl.Tuple[pl.Scalar[pl.INDEX], pl.Scalar[pl.INDEX], pl.Scalar[pl.INDEX]] = self.indexer_long_leaf_plan(buf_capped_history, buf_group_count)
                buf_max_leaves: pl.Scalar[pl.INDEX] = _tuple_tmp_1[0]
                buf_leaf_tiles: pl.Scalar[pl.INDEX] = _tuple_tmp_1[1]
                buf_extra_leaves: pl.Scalar[pl.INDEX] = _tuple_tmp_1[2]
            pl.system.set_ffts(buf_score_ffts)
            for buf_item in pl.range(buf_worker, buf_group_count * buf_max_leaves, 24):
                if buf_group_count < 24:
                    buf_group: pl.Scalar[pl.INDEX] = buf_item % buf_group_count
                    buf_leaf: pl.Scalar[pl.INDEX] = buf_item // buf_group_count
                else:
                    buf_group: pl.Scalar[pl.INDEX] = buf_item // buf_max_leaves
                    buf_leaf: pl.Scalar[pl.INDEX] = buf_item % buf_max_leaves
                buf_query: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_row, [buf_group]), pl.INDEX)
                buf_group_rows: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_rows, [buf_group]), pl.INDEX)
                buf_batch_idx: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(token_request, [buf_query]), pl.INDEX)
                buf_last_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [buf_query + buf_group_rows - 1])
                buf_cache_len: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(kv_seq_lens, [buf_batch_idx]), pl.INDEX) // 4
                buf_visible_count: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(buf_cache_len, (buf_last_position + 1) // 4), 262144), 0)
                buf_logical_begin: pl.Scalar[pl.INDEX] = buf_leaf * 8192
                buf_leaf_capacity: pl.Scalar[pl.INDEX] = 8192
                if False:
                    buf_logical_begin: pl.Scalar[pl.INDEX] = (buf_leaf * buf_leaf_tiles + pl.min(buf_leaf, buf_extra_leaves)) * 1024
                    buf_leaf_capacity: pl.Scalar[pl.INDEX] = (buf_leaf_tiles + pl.cast(buf_leaf < buf_extra_leaves, pl.INDEX)) * 1024
                if buf_logical_begin < buf_visible_count:
                    buf_valid_count: pl.Scalar[pl.INDEX] = pl.min(buf_leaf_capacity, buf_visible_count - buf_logical_begin)
                    buf_tile_count: pl.Scalar[pl.INDEX] = (buf_valid_count + 768 - 1) // 768
                    buf_lane_span: pl.Scalar[pl.INDEX] = pl.min(buf_tile_count * 384, 4096)
                    buf_score_iters: pl.Scalar[pl.INDEX] = (buf_lane_span + 384 - 1) // 384
                    buf_query_vector: pl.Tile[[384, 128], pl.INT8, pl.Mem.Mat] = pl.tile.load(qr_hadamard_i8, [buf_query * 64, 0], [384, 128], [384, 128], target_memory=pl.Mem.Mat)
                    buf_coefficients_l1: pl.Tile[[16, 384], pl.FP16, pl.Mem.Mat] = pl.tile.load(coefficients, [buf_group * 16, 0], [16, 384], [16, 384], target_memory=pl.Mem.Mat)
                    buf_query_left: pl.Tile[[384, 128], pl.INT8, pl.Mem.Left] = pl.tile.move(buf_query_vector, target_memory=pl.Mem.Left)
                    buf_coefficient_pair: pl.Tile[[16, 384], pl.FP16, pl.Mem.Left] = pl.tile.move(buf_coefficients_l1, target_memory=pl.Mem.Left)
                    for buf_score_step in pl.range(buf_score_iters):
                        if buf_score_step >= 2:
                            pl.system.sync_wait(1, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIC)
                        buf_score_begin: pl.Scalar[pl.INDEX] = buf_score_step * 384
                        if False:
                            buf_score_begin: pl.Scalar[pl.INDEX] = buf_score_step * 768
                        buf_transfer_row: pl.Scalar[pl.INDEX] = buf_worker * 2 * 6 + buf_score_step % 2 * 6
                        buf_previous_l1: pl.Tile[[384, 64], pl.FP16, pl.Mem.Mat] = pl.tile.create([384, 64], dtype=pl.FP16, target_memory=pl.Mem.Mat)
                        buf_current_key: pl.Tile[[128, 64], pl.INT8, pl.Mem.Right] = pl.tile.create([128, 64], dtype=pl.INT8, target_memory=pl.Mem.Right)
                        buf_prefetched_key: pl.Tile[[128, 64], pl.INT8, pl.Mem.Right] = pl.tile.create([128, 64], dtype=pl.INT8, target_memory=pl.Mem.Right)
                        buf_key_l1_pool: pl.Tile[[128, 128], pl.INT8, pl.Mem.Mat] = pl.tile.create([128, 128], dtype=pl.INT8, target_memory=pl.Mem.Mat)
                        if pl.const(0, pl.INDEX) > pl.const(0, pl.INDEX):
                            buf_prime_col: pl.Scalar[pl.INDEX] = 0
                            for buf_prime_key_page in pl.unroll(2):
                                buf_prime_key_row: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_score_begin + buf_prime_col // 384 * buf_lane_span + buf_prime_col % 384 + buf_prime_key_page * 32
                                if False:
                                    buf_prime_key_row: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_score_begin + buf_prime_col + buf_prime_key_page * 32
                                buf_prime_safe_page: pl.Scalar[pl.INDEX] = pl.min(buf_prime_key_row // 32, pl.max((buf_cache_len - 1) // 32, 0))
                                buf_prime_physical_page: pl.Scalar[pl.INDEX] = pl.max(pl.cast(pl.tensor.read(idx_block_table, [buf_batch_idx, buf_prime_safe_page]), pl.INDEX), 0)
                                buf_prime_native_byte: pl.Scalar[pl.INDEX] = buf_prime_physical_page * native_page_bytes
                                if buf_prime_native_byte % 128 == 0:
                                    buf_key_l1_pool: pl.Tile[[128, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_key_l1_pool, idx_kv_cache, [buf_prime_key_page * 32, 0], [buf_prime_native_byte // 128, 0], [32, 128], transpose=False)
                                else:
                                    buf_key_l1_pool: pl.Tile[[128, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_key_l1_pool, idx_kv_cache_shift64, [buf_prime_key_page * 32, 0], [buf_prime_native_byte // 128, 0], [32, 128], transpose=False)
                            if True:
                                buf_current_key: pl.Tile[[128, 64], pl.INT8, pl.Mem.Right] = pl.tile.extract(pl.tile.transpose_view(buf_key_l1_pool), 0, 0, [128, 64], target_memory=pl.Mem.Right)
                        for buf_qk_panel in pl.unroll(12):
                            buf_panel_col: pl.Scalar[pl.INDEX] = buf_qk_panel * 64
                            buf_load_col: pl.Scalar[pl.INDEX] = (buf_qk_panel + 0) * 64
                            buf_load_slot: pl.Scalar[pl.INDEX] = (buf_qk_panel + 0) % 2 * 64
                            if pl.const(0, pl.INDEX) > pl.const(0, pl.INDEX):
                                if not True:
                                    buf_current_key: pl.Tile[[128, 64], pl.INT8, pl.Mem.Right] = pl.tile.extract(pl.tile.transpose_view(buf_key_l1_pool), 0, buf_qk_panel % 2 * 64, [128, 64], target_memory=pl.Mem.Right)
                            if buf_qk_panel + 0 < 12:
                                buf_panel_keys: pl.Tile[[64, 128], pl.INT8, pl.Mem.Mat] = pl.tile.create([64, 128], dtype=pl.INT8, target_memory=pl.Mem.Mat)
                                for buf_key_page in pl.unroll(2):
                                    buf_key_row: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_score_begin + buf_load_col // 384 * buf_lane_span + buf_load_col % 384 + buf_key_page * 32
                                    if False:
                                        buf_key_row: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_score_begin + buf_load_col + buf_key_page * 32
                                    buf_safe_page: pl.Scalar[pl.INDEX] = pl.min(buf_key_row // 32, pl.max((buf_cache_len - 1) // 32, 0))
                                    buf_physical_page: pl.Scalar[pl.INDEX] = pl.max(pl.cast(pl.tensor.read(idx_block_table, [buf_batch_idx, buf_safe_page]), pl.INDEX), 0)
                                    buf_native_byte: pl.Scalar[pl.INDEX] = buf_physical_page * native_page_bytes
                                    if buf_native_byte % 128 == 0:
                                        if pl.const(0, pl.INDEX) > pl.const(0, pl.INDEX):
                                            buf_key_l1_pool: pl.Tile[[128, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_key_l1_pool, idx_kv_cache, [buf_load_slot + buf_key_page * 32, 0], [buf_native_byte // 128, 0], [32, 128], transpose=False)
                                        else:
                                            buf_panel_keys: pl.Tile[[64, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_panel_keys, idx_kv_cache, [buf_key_page * 32, 0], [buf_native_byte // 128, 0], [32, 128], transpose=False)
                                    else:
                                        if pl.const(0, pl.INDEX) > pl.const(0, pl.INDEX):
                                            buf_key_l1_pool: pl.Tile[[128, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_key_l1_pool, idx_kv_cache_shift64, [buf_load_slot + buf_key_page * 32, 0], [buf_native_byte // 128, 0], [32, 128], transpose=False)
                                        else:
                                            buf_panel_keys: pl.Tile[[64, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_panel_keys, idx_kv_cache_shift64, [buf_key_page * 32, 0], [buf_native_byte // 128, 0], [32, 128], transpose=False)
                                if pl.const(0, pl.INDEX) > pl.const(0, pl.INDEX):
                                    if True:
                                        buf_prefetched_key: pl.Tile[[128, 64], pl.INT8, pl.Mem.Right] = pl.tile.extract(pl.tile.transpose_view(buf_key_l1_pool), 0, buf_load_slot, [128, 64], target_memory=pl.Mem.Right)
                                else:
                                    buf_prefetched_key: pl.Tile[[128, 64], pl.INT8, pl.Mem.Right] = pl.tile.move(pl.tile.transpose_view(buf_panel_keys), target_memory=pl.Mem.Right)
                            if pl.const(0, pl.INDEX) > pl.const(0, pl.INDEX):
                                buf_key_panel: pl.Tile[[128, 64], pl.INT8, pl.Mem.Right] = buf_current_key
                            else:
                                buf_key_panel: pl.Tile[[128, 64], pl.INT8, pl.Mem.Right] = buf_prefetched_key
                            buf_scores_l1: pl.Tile[[384, 64], pl.FP16, pl.Mem.Mat] = pl.tile.create([384, 64], dtype=pl.FP16, target_memory=pl.Mem.Mat)
                            if buf_qk_panel > 0:
                                buf_previous_pair: pl.Tile[[384, 64], pl.FP16, pl.Mem.Right] = pl.tile.extract(buf_previous_l1, 0, 0, [384, 64], target_memory=pl.Mem.Right)
                                buf_scores: pl.Tile[[384, 64], pl.INT32, pl.Mem.Acc] = pl.tile.matmul(buf_query_left, buf_key_panel)
                                buf_reduced_pair: pl.Tile[[16, 64], pl.FP32, pl.Mem.Acc] = pl.tile.matmul(buf_coefficient_pair, buf_previous_pair)
                                buf_scores_l1: pl.Tile[[384, 64], pl.FP16, pl.Mem.Mat] = pl.tile.assemble(buf_scores_l1, buf_scores, [0, 0], pre_quant=0.0009765625, pre_relu=True)
                                pl.tile.store(pl.tile.set_validshape(buf_reduced_pair, 6, 64), [buf_transfer_row, buf_panel_col - 64], buf_score_transfer)
                            else:
                                buf_scores: pl.Tile[[384, 64], pl.INT32, pl.Mem.Acc] = pl.tile.matmul(buf_query_left, buf_key_panel)
                                buf_scores_l1: pl.Tile[[384, 64], pl.FP16, pl.Mem.Mat] = pl.tile.assemble(buf_scores_l1, buf_scores, [0, 0], pre_quant=0.0009765625, pre_relu=True)
                            buf_previous_l1: pl.Tile[[384, 64], pl.FP16, pl.Mem.Mat] = buf_scores_l1
                            if pl.const(0, pl.INDEX) > pl.const(0, pl.INDEX):
                                if True:
                                    if buf_qk_panel + 1 < 12:
                                        buf_current_key: pl.Tile[[128, 64], pl.INT8, pl.Mem.Right] = buf_prefetched_key
                        buf_last_pair: pl.Tile[[384, 64], pl.FP16, pl.Mem.Right] = pl.tile.extract(buf_previous_l1, 0, 0, [384, 64], target_memory=pl.Mem.Right)
                        buf_last_scores: pl.Tile[[16, 64], pl.FP32, pl.Mem.Acc] = pl.tile.matmul(buf_coefficient_pair, buf_last_pair)
                        pl.tile.store(pl.tile.set_validshape(buf_last_scores, 6, 64), [buf_transfer_row, 704], buf_score_transfer)
                        pl.system.sync_set(0, pipe=pl.PipeType.FIX, ffts_mode=2, core_type=pl.KernelType.AIC)
                    for buf_score_drain in pl.range(pl.min(buf_score_iters, 2)):
                        pl.system.sync_wait(1, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIC)
            for buf_score_lane in pl.split_aiv(2, mode=pl.SplitMode.NONE):
                if False:
                    for single_item in pl.range(buf_worker, buf_group_count * buf_max_leaves, 24):
                        if buf_group_count < 24:
                            single_group: pl.Scalar[pl.INDEX] = single_item % buf_group_count
                            single_leaf: pl.Scalar[pl.INDEX] = single_item // buf_group_count
                        else:
                            single_group: pl.Scalar[pl.INDEX] = single_item // buf_max_leaves
                            single_leaf: pl.Scalar[pl.INDEX] = single_item % buf_max_leaves
                        single_query: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_row, [single_group]), pl.INDEX)
                        single_group_rows: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_rows, [single_group]), pl.INDEX)
                        single_batch: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(token_request, [single_query]), pl.INDEX)
                        single_cache_len: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(kv_seq_lens, [single_batch]), pl.INDEX) // 4
                        single_last_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [single_query + single_group_rows - 1])
                        single_visible: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(single_cache_len, (single_last_position + 1) // 4), 262144), 0)
                        single_begin: pl.Scalar[pl.INDEX] = (single_leaf * buf_leaf_tiles + pl.min(single_leaf, buf_extra_leaves)) * 768
                        single_capacity: pl.Scalar[pl.INDEX] = (buf_leaf_tiles + pl.cast(single_leaf < buf_extra_leaves, pl.INDEX)) * 768
                        if single_begin < single_visible:
                            single_valid: pl.Scalar[pl.INDEX] = pl.min(single_capacity, single_visible - single_begin)
                            single_steps: pl.Scalar[pl.INDEX] = (single_valid + 768 - 1) // 768
                            single_roots: pl.Tile[[3, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.full([3, 1024], dtype=pl.FP32, value=-3.4028234663852886e+38)
                            single_segments: pl.Tile[[6, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.full([6, 1024], dtype=pl.FP32, value=-3.4028234663852886e+38)
                            for single_step in pl.range(single_steps):
                                single_score_begin: pl.Scalar[pl.INDEX] = single_begin + single_step * 768
                                single_transfer_row: pl.Scalar[pl.INDEX] = buf_worker * 2 * 6 + single_step % 2 * 6 + buf_score_lane * 3
                                single_scale_bytes: pl.Tile[[1, 1536], pl.INT8] = pl.tile.create([1, 1536], dtype=pl.INT8)
                                for single_scale_page in pl.range(24):
                                    single_scale_logical: pl.Scalar[pl.INDEX] = pl.min(single_score_begin // 32 + single_scale_page, pl.max((single_cache_len - 1) // 32, 0))
                                    single_scale_physical: pl.Scalar[pl.INDEX] = pl.max(pl.cast(pl.tensor.read(idx_block_table, [single_batch, single_scale_logical]), pl.INDEX), 0)
                                    single_scale_bytes: pl.Tile[[1, 1536], pl.INT8] = pl.tile.gather_row(single_scale_bytes, idx_native_kv_cache, [0, single_scale_page * 32 * 2], [single_scale_physical, 4096], [1, 64], transpose=False)
                                single_scale_half: pl.Tile[[1, 768], pl.FP16] = pl.tile.reinterpret_view(single_scale_bytes, dtype=pl.FP16)
                                single_kv_scale: pl.Tile[[1, 768], pl.FP32, pl.Mem.Vec] = pl.tile.cast(single_scale_half, target_type=pl.FP32, mode='round')
                                pl.system.sync_wait(0, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIV)
                                single_scores: pl.Tile[[3, 768], pl.FP32] = pl.tile.load(buf_score_transfer, [single_transfer_row, 0], [3, 768], [3, 768])
                                pl.system.sync_set(1, pipe=pl.PipeType.MTE2, ffts_mode=2, core_type=pl.KernelType.AIV)
                                for single_local in pl.unroll(3):
                                    single_score_row: pl.Tile[[1, 768], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_scores, single_local, 0, [1, 768], target_memory=pl.Mem.Vec)
                                    single_scaled: pl.Tile[[1, 768], pl.FP32, pl.Mem.Vec] = pl.tile.mul(single_score_row, single_kv_scale)
                                    single_segments: pl.Tile[[6, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.assemble(single_segments, single_scaled, [single_local * 2 + single_step % 2, 0])
                                if single_step % 2 == 1 or single_step + 1 == single_steps:
                                    single_segment_begin: pl.Scalar[pl.INDEX] = single_begin + single_step // 2 * 1536
                                    single_segment_span: pl.Scalar[pl.INDEX] = (single_step % 2 + 1) * 768
                                    single_segment_rows: pl.Tile[[3, 2048], pl.FP32, pl.Mem.Vec] = pl.tile.reshape(single_segments, [3, 2048])
                                    for single_local_1 in pl.unroll(3):
                                        single_query_lane: pl.Scalar[pl.INDEX] = buf_score_lane * 3 + single_local_1
                                        single_lane_live: pl.Scalar[pl.BOOL] = single_query_lane < single_group_rows
                                        single_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [single_query + pl.min(single_query_lane, single_group_rows - 1)])
                                        single_query_visible: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(single_cache_len, (single_position + 1) // 4), 262144), 0)
                                        single_segment_valid: pl.Scalar[pl.INDEX] = pl.max(pl.min(single_query_visible - single_segment_begin, single_segment_span), 0)
                                        if single_segment_valid > 0 and single_lane_live:
                                            single_segment_data: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_segment_rows, single_local_1, 0, [1, 2048], target_memory=pl.Mem.Vec)
                                            logical_i32: pl.Scalar[pl.INT32] = pl.cast(single_segment_begin, pl.INT32)
                                            if single_segment_valid <= 512:
                                                tiny_indices: pl.Tile[[1, 512], pl.INT32, pl.Mem.Vec] = pl.tile.adds(pl.tile.ci(pl.const(0, pl.INT32), [1, 512], dtype=pl.INT32, descending=False), logical_i32)
                                                tiny_tile: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_segment_data, 0, 0, [1, 512], target_memory=pl.Mem.Vec)
                                                tiny_raw: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[1, single_segment_valid])] = pl.tile.set_validshape(tiny_tile, 1, single_segment_valid)
                                                tiny_scores: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximums(pl.tile.fillpad(tiny_raw, pad_value=pl.PadValue.min), -3.4028234663852886e+38)
                                                tiny_pairs: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(tiny_scores, pl.tile.reinterpret_view(tiny_indices, dtype=pl.UINT32))
                                                tiny_pairs_v1: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(tiny_pairs, pl.const(64, pl.INT32))
                                                tiny_pairs_v2: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(tiny_pairs_v1, pl.const(256, pl.INT32))
                                                single_new_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(tiny_pairs_v2, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                            else:
                                                if single_segment_valid <= 1024:
                                                    small_indices: pl.Tile[[1, 1024], pl.INT32, pl.Mem.Vec] = pl.tile.adds(pl.tile.ci(pl.const(0, pl.INT32), [1, 1024], dtype=pl.INT32, descending=False), logical_i32)
                                                    small_tile: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_segment_data, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                                    small_raw: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[1, single_segment_valid])] = pl.tile.set_validshape(small_tile, 1, single_segment_valid)
                                                    small_scores: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximums(pl.tile.fillpad(small_raw, pad_value=pl.PadValue.min), -3.4028234663852886e+38)
                                                    small_pairs: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(small_scores, pl.tile.reinterpret_view(small_indices, dtype=pl.UINT32))
                                                    small_pairs_v1: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(small_pairs, pl.const(64, pl.INT32))
                                                    small_pairs_v2: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(small_pairs_v1, pl.const(256, pl.INT32))
                                                    small_left: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(small_pairs_v2, [1, 1024], [0, 0])
                                                    small_right: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(small_pairs_v2, [1, 1024], [0, 1024])
                                                    small_tmp: pl.Tile[[1, 2048], pl.FP32] = pl.tile.create([1, 2048], dtype=pl.FP32)
                                                    small_merged: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format2(small_left, small_right, small_tmp, exhausted=False)
                                                    single_new_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(small_merged, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                                else:
                                                    large_indices: pl.Tile[[1, 2048], pl.INT32, pl.Mem.Vec] = pl.tile.adds(pl.tile.ci(pl.const(0, pl.INT32), [1, 2048], dtype=pl.INT32, descending=False), logical_i32)
                                                    large_tile: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_segment_data, 0, 0, [1, 2048], target_memory=pl.Mem.Vec)
                                                    large_raw: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[1, single_segment_valid])] = pl.tile.set_validshape(large_tile, 1, single_segment_valid)
                                                    large_scores: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximums(pl.tile.fillpad(large_raw, pad_value=pl.PadValue.min), -3.4028234663852886e+38)
                                                    large_pairs: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(large_scores, pl.tile.reinterpret_view(large_indices, dtype=pl.UINT32))
                                                    large_pairs_v1: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(large_pairs, pl.const(64, pl.INT32))
                                                    large_pairs_v2: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(large_pairs_v1, pl.const(256, pl.INT32))
                                                    large_pairs_v3: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(large_pairs_v2, pl.const(1024, pl.INT32))
                                                    single_new_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(large_pairs_v3, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                            if single_step < 2:
                                                single_roots: pl.Tile[[3, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.assemble(single_roots, single_new_root, [single_local_1, 0])
                                            else:
                                                single_old_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_roots, single_local_1, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                                single_merge_tmp: pl.Tile[[1, 2048], pl.FP32] = pl.tile.create([1, 2048], dtype=pl.FP32)
                                                single_merged: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec] = pl.tile.mrgsort_format2(single_new_root, single_old_root, single_merge_tmp, exhausted=False)
                                                single_next_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_merged, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                                single_roots: pl.Tile[[3, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.assemble(single_roots, single_next_root, [single_local_1, 0])
                            for single_local_2 in pl.unroll(3):
                                single_query_lane: pl.Scalar[pl.INDEX] = buf_score_lane * 3 + single_local_2
                                if single_query_lane < single_group_rows:
                                    single_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_roots, single_local_2, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                    pl.tile.store(single_root, [(single_query + single_query_lane) * 64 + single_leaf, 0], pair_arena)
                else:
                    for buf_item_1 in pl.range(buf_worker, buf_group_count * buf_max_leaves, 24):
                        if buf_group_count < 24:
                            buf_group: pl.Scalar[pl.INDEX] = buf_item_1 % buf_group_count
                            buf_leaf: pl.Scalar[pl.INDEX] = buf_item_1 // buf_group_count
                        else:
                            buf_group: pl.Scalar[pl.INDEX] = buf_item_1 // buf_max_leaves
                            buf_leaf: pl.Scalar[pl.INDEX] = buf_item_1 % buf_max_leaves
                        buf_query: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_row, [buf_group]), pl.INDEX)
                        buf_group_rows: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_rows, [buf_group]), pl.INDEX)
                        buf_batch_idx: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(token_request, [buf_query]), pl.INDEX)
                        buf_last_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [buf_query + buf_group_rows - 1])
                        buf_cache_len: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(kv_seq_lens, [buf_batch_idx]), pl.INDEX) // 4
                        buf_visible_count: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(buf_cache_len, (buf_last_position + 1) // 4), 262144), 0)
                        buf_logical_begin: pl.Scalar[pl.INDEX] = buf_leaf * 8192
                        buf_leaf_capacity: pl.Scalar[pl.INDEX] = 8192
                        if False:
                            buf_logical_begin: pl.Scalar[pl.INDEX] = (buf_leaf * buf_leaf_tiles + pl.min(buf_leaf, buf_extra_leaves)) * 1024
                            buf_leaf_capacity: pl.Scalar[pl.INDEX] = (buf_leaf_tiles + pl.cast(buf_leaf < buf_extra_leaves, pl.INDEX)) * 1024
                        if buf_logical_begin < buf_visible_count:
                            buf_valid_count: pl.Scalar[pl.INDEX] = pl.min(buf_leaf_capacity, buf_visible_count - buf_logical_begin)
                            buf_tile_count: pl.Scalar[pl.INDEX] = (buf_valid_count + 768 - 1) // 768
                            buf_lane_span: pl.Scalar[pl.INDEX] = pl.min(buf_tile_count * 384, 4096)
                            buf_score_iters: pl.Scalar[pl.INDEX] = (buf_lane_span + 384 - 1) // 384
                            buf_lane_begin: pl.Scalar[pl.INDEX] = buf_score_lane * buf_lane_span
                            prefix_roots: pl.Tile[[6, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.full([6, 1024], dtype=pl.FP32, value=-3.4028234663852886e+38)
                            for buf_score_step_1 in pl.range(buf_score_iters):
                                buf_score_begin: pl.Scalar[pl.INDEX] = buf_score_step_1 * 384
                                buf_transfer_row: pl.Scalar[pl.INDEX] = buf_worker * 2 * 6 + buf_score_step_1 % 2 * 6
                                buf_scale_bytes: pl.Tile[[1, 768], pl.INT8] = pl.tile.create([1, 768], dtype=pl.INT8)
                                for buf_scale_page in pl.range(12):
                                    buf_scale_row: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_score_begin + buf_lane_begin + buf_scale_page * 32
                                    buf_scale_safe_page: pl.Scalar[pl.INDEX] = pl.min(buf_scale_row // 32, pl.max((buf_cache_len - 1) // 32, 0))
                                    buf_scale_physical_page: pl.Scalar[pl.INDEX] = pl.max(pl.cast(pl.tensor.read(idx_block_table, [buf_batch_idx, buf_scale_safe_page]), pl.INDEX), 0)
                                    buf_scale_bytes: pl.Tile[[1, 768], pl.INT8] = pl.tile.gather_row(buf_scale_bytes, idx_native_kv_cache, [0, buf_scale_page * 32 * 2], [buf_scale_physical_page, 4096], [1, 64], transpose=False)
                                buf_scale_half: pl.Tile[[1, 384], pl.FP16] = pl.tile.reinterpret_view(buf_scale_bytes, dtype=pl.FP16)
                                buf_kv_scale: pl.Tile[[1, 384], pl.FP32, pl.Mem.Vec] = pl.tile.cast(buf_scale_half, target_type=pl.FP32, mode='round')
                                pl.system.sync_wait(0, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIV)
                                buf_score_sums: pl.Tile[[6, 384], pl.FP32] = pl.tile.load(buf_score_transfer, [buf_transfer_row, buf_score_lane * 384], [6, 384], [6, 384])
                                pl.system.sync_set(1, pipe=pl.PipeType.MTE2, ffts_mode=2, core_type=pl.KernelType.AIV)
                                for buf_query_lane in pl.unroll(6):
                                    buf_lane_live: pl.Scalar[pl.BOOL] = buf_query_lane < buf_group_rows
                                    buf_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [buf_query + pl.min(buf_query_lane, buf_group_rows - 1)])
                                    buf_query_visible: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(buf_cache_len, (buf_position + 1) // 4), 262144), 0)
                                    buf_lane_valid_rows: pl.Scalar[pl.INDEX] = pl.max(pl.min(buf_query_visible - buf_logical_begin - buf_score_begin - buf_lane_begin, 384), 0)
                                    buf_lane_valid_rows_v1: pl.Scalar[pl.INDEX] = pl.min(buf_lane_valid_rows, pl.max(buf_lane_span - buf_score_begin, 0))
                                    buf_score_sum: pl.Tile[[1, 384], pl.FP32] = pl.tile.slice(buf_score_sums, [1, 384], [buf_query_lane, 0])
                                    buf_score_row: pl.Tile[[1, 384], pl.FP32, pl.Mem.Vec] = pl.tile.mul(buf_score_sum, buf_kv_scale)
                                    buf_store_row: pl.Scalar[pl.INDEX] = buf_query + buf_query_lane
                                    buf_store_column: pl.Scalar[pl.INDEX] = buf_score_begin + buf_lane_begin
                                    if buf_max_leaves > 1:
                                        buf_store_row: pl.Scalar[pl.INDEX] = buf_worker * 2 * 6 + buf_query_lane * 2 + buf_score_lane
                                        buf_store_column: pl.Scalar[pl.INDEX] = buf_score_begin
                                    if buf_lane_valid_rows_v1 > 0 and buf_lane_live:
                                        pl.tile.store(pl.tile.set_validshape(buf_score_row, 1, buf_lane_valid_rows_v1), [buf_store_row, buf_store_column], score_arena)
                                if False:
                                    if buf_score_step_1 == 3 and buf_score_iters > 4:
                                        for stream_lane in pl.unroll(6):
                                            stream_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [buf_query + pl.min(stream_lane, buf_group_rows - 1)])
                                            stream_visible: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(buf_cache_len, (stream_position + 1) // 4), 262144), 0)
                                            stream_begin: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_lane_begin
                                            stream_valid: pl.Scalar[pl.INDEX] = pl.max(pl.min(stream_visible - stream_begin, 2048), 0)
                                            if stream_valid > 0 and stream_lane < buf_group_rows:
                                                stream_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = self.indexer_topk_segment_pairs(score_arena, buf_worker * 2 * 6 + stream_lane * 2 + buf_score_lane, stream_begin, stream_valid)
                                                prefix_roots: pl.Tile[[6, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.assemble(prefix_roots, stream_root, [stream_lane, 0])
                            if buf_max_leaves > 1:
                                for buf_query_lane_1 in pl.unroll(6):
                                    if buf_query_lane_1 < buf_group_rows:
                                        buf_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [buf_query + buf_query_lane_1])
                                        buf_query_visible: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(buf_cache_len, (buf_position + 1) // 4), 262144), 0)
                                        buf_half_begin: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_lane_begin
                                        buf_half_valid: pl.Scalar[pl.INDEX] = pl.max(pl.min(buf_query_visible - buf_half_begin, buf_lane_span), 0)
                                        buf_half_slot: pl.Scalar[pl.INDEX] = (buf_query + buf_query_lane_1) * 64 + buf_leaf * 2 + buf_score_lane
                                        if buf_half_valid > 0:
                                            self.indexer_topk_half_leaf(score_arena, pair_arena, buf_worker * 2 * 6 + buf_query_lane_1 * 2 + buf_score_lane, buf_half_begin, buf_half_valid, buf_half_slot)
                                        else:
                                            pl.tile.store(pl.tile.full([1, 1024], dtype=pl.FP32, value=-3.4028234663852886e+38), [buf_half_slot, 0], pair_arena)
        return buffered_leaf_tid
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def indexer_score_topk_native_cube__4(self, qr_hadamard_i8: pl.Tensor[[27648, 128], pl.INT8], qr_hadamard_scale_dq: pl.Tensor[[27648, 1], pl.FP32], weights: pl.Tensor[[432, 64], pl.FP32], idx_native_kv_cache: pl.Tensor[[IDX_NATIVE_CACHE_BLOCK_NUM_DYN, INDEXER_PAGE_BYTES_DYN], pl.INT8], idx_block_table: pl.Tensor[[B_DYN, INDEXER_TABLE_COLUMNS_DYN], pl.INT32], position_ids: pl.Tensor[[T_DYN], pl.INT64], kv_seq_lens: pl.Tensor[[B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], group_row: pl.Tensor[[432], pl.INT32], group_rows: pl.Tensor[[432], pl.INT32], group_count_t: pl.Tensor[[1], pl.INT32], groups_tid: pl.Scalar[pl.TASK_ID], score_arena: pl.Tensor[[432, 8192], pl.FP32], pair_arena: pl.Tensor[[27648, 1024], pl.FP32], qh_quant_tid: pl.Scalar[pl.TASK_ID], weights_tid: pl.Scalar[pl.TASK_ID], cache_write_tid: pl.Scalar[pl.TASK_ID]):
        # 同组query共用Key：双query/M128/N128或S6/M384/N64，保持FP16/Cube策略。
        native_page_bytes: pl.Scalar[pl.INDEX] = pl.tensor.dim(idx_native_kv_cache, 1)
        cache_bytes: pl.Scalar[pl.INDEX] = pl.tensor.dim(idx_native_kv_cache, 0) * native_page_bytes
        cache_flat: pl.Tensor[[cache_bytes], pl.INT8] = pl.tensor.reshape(idx_native_kv_cache, [cache_bytes])
        key_rows: pl.Scalar[pl.INDEX] = cache_bytes // 128
        shifted_rows: pl.Scalar[pl.INDEX] = (cache_bytes - 64) // 128
        idx_kv_cache: pl.Tensor[[key_rows, 128], pl.INT8] = pl.tensor.reshape(pl.tensor.slice(cache_flat, [key_rows * 128], [0]), [key_rows, 128])
        idx_kv_cache_shift64: pl.Tensor[[shifted_rows, 128], pl.INT8] = pl.tensor.reshape(pl.tensor.slice(cache_flat, [shifted_rows * 128], [64]), [shifted_rows, 128])
        _tuple_tmp: pl.Tuple[pl.Tensor[[3456, 128], pl.FP16], pl.Scalar[pl.TASK_ID]] = self.indexer_head_coefficients__2(qr_hadamard_scale_dq, weights, kv_seq_lens, group_row, group_rows, group_count_t, groups_tid, qh_quant_tid, weights_tid)
        coefficients: pl.Tensor[[3456, 128], pl.FP16] = _tuple_tmp[0]
        coefficients_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp[1]
        buf_score_transfer: pl.Tensor[[96, 768], pl.FP32] = pl.tensor.create([96, 768], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        buf_score_ffts: pl.Tensor[[256], pl.INT64] = pl.tensor.create([256], dtype=pl.INT64, layout=pl.TensorLayout.ND)
        with pl.spmd(24, name_hint="indexer_score_topk_native_pair_spmd", deps=[groups_tid, coefficients_tid, cache_write_tid], allow_early_resolve=True) as buffered_leaf_tid:
            buf_worker: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
            buf_max_cache_len: pl.Scalar[pl.INDEX] = 0
            for buf_batch in pl.range(pl.tensor.dim(kv_seq_lens, 0)):
                buf_max_cache_len: pl.Scalar[pl.INDEX] = pl.max(buf_max_cache_len, pl.cast(pl.tensor.read(kv_seq_lens, [buf_batch]), pl.INDEX) // 4)
            buf_capped_history: pl.Scalar[pl.INDEX] = pl.min(buf_max_cache_len, 262144)
            buf_max_leaves: pl.Scalar[pl.INDEX] = pl.max((buf_capped_history + 8192 - 1) // 8192, 1)
            buf_leaf_tiles: pl.Scalar[pl.INDEX] = 8
            buf_extra_leaves: pl.Scalar[pl.INDEX] = 0
            buf_group_count: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_count_t, [0]), pl.INDEX)
            if False:
                _tuple_tmp_1: pl.Tuple[pl.Scalar[pl.INDEX], pl.Scalar[pl.INDEX], pl.Scalar[pl.INDEX]] = self.indexer_long_leaf_plan(buf_capped_history, buf_group_count)
                buf_max_leaves: pl.Scalar[pl.INDEX] = _tuple_tmp_1[0]
                buf_leaf_tiles: pl.Scalar[pl.INDEX] = _tuple_tmp_1[1]
                buf_extra_leaves: pl.Scalar[pl.INDEX] = _tuple_tmp_1[2]
            pl.system.set_ffts(buf_score_ffts)
            for buf_item in pl.range(buf_worker, buf_group_count * buf_max_leaves, 24):
                if buf_group_count < 24:
                    buf_group: pl.Scalar[pl.INDEX] = buf_item % buf_group_count
                    buf_leaf: pl.Scalar[pl.INDEX] = buf_item // buf_group_count
                else:
                    buf_group: pl.Scalar[pl.INDEX] = buf_item // buf_max_leaves
                    buf_leaf: pl.Scalar[pl.INDEX] = buf_item % buf_max_leaves
                buf_query: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_row, [buf_group]), pl.INDEX)
                buf_group_rows: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_rows, [buf_group]), pl.INDEX)
                buf_batch_idx: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(token_request, [buf_query]), pl.INDEX)
                buf_last_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [buf_query + buf_group_rows - 1])
                buf_cache_len: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(kv_seq_lens, [buf_batch_idx]), pl.INDEX) // 4
                buf_visible_count: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(buf_cache_len, (buf_last_position + 1) // 4), 262144), 0)
                buf_logical_begin: pl.Scalar[pl.INDEX] = buf_leaf * 8192
                buf_leaf_capacity: pl.Scalar[pl.INDEX] = 8192
                if False:
                    buf_logical_begin: pl.Scalar[pl.INDEX] = (buf_leaf * buf_leaf_tiles + pl.min(buf_leaf, buf_extra_leaves)) * 1024
                    buf_leaf_capacity: pl.Scalar[pl.INDEX] = (buf_leaf_tiles + pl.cast(buf_leaf < buf_extra_leaves, pl.INDEX)) * 1024
                if buf_logical_begin < buf_visible_count:
                    buf_valid_count: pl.Scalar[pl.INDEX] = pl.min(buf_leaf_capacity, buf_visible_count - buf_logical_begin)
                    buf_tile_count: pl.Scalar[pl.INDEX] = (buf_valid_count + 768 - 1) // 768
                    buf_lane_span: pl.Scalar[pl.INDEX] = pl.min(buf_tile_count * 384, 4096)
                    buf_score_iters: pl.Scalar[pl.INDEX] = (buf_lane_span + 384 - 1) // 384
                    buf_query_vector: pl.Tile[[128, 128], pl.INT8, pl.Mem.Mat] = pl.tile.load(qr_hadamard_i8, [buf_query * 64, 0], [128, 128], [128, 128], target_memory=pl.Mem.Mat)
                    buf_coefficients_l1: pl.Tile[[16, 128], pl.FP16, pl.Mem.Mat] = pl.tile.load(coefficients, [buf_group * 16, 0], [16, 128], [16, 128], target_memory=pl.Mem.Mat)
                    buf_query_left: pl.Tile[[128, 128], pl.INT8, pl.Mem.Left] = pl.tile.move(buf_query_vector, target_memory=pl.Mem.Left)
                    buf_coefficient_pair: pl.Tile[[16, 128], pl.FP16, pl.Mem.Left] = pl.tile.move(buf_coefficients_l1, target_memory=pl.Mem.Left)
                    for buf_score_step in pl.range(buf_score_iters):
                        if buf_score_step >= 2:
                            pl.system.sync_wait(1, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIC)
                        buf_score_begin: pl.Scalar[pl.INDEX] = buf_score_step * 384
                        if False:
                            buf_score_begin: pl.Scalar[pl.INDEX] = buf_score_step * 768
                        buf_transfer_row: pl.Scalar[pl.INDEX] = buf_worker * 2 * 2 + buf_score_step % 2 * 2
                        buf_previous_l1: pl.Tile[[128, 128], pl.FP16, pl.Mem.Mat] = pl.tile.create([128, 128], dtype=pl.FP16, target_memory=pl.Mem.Mat)
                        buf_current_key: pl.Tile[[128, 128], pl.INT8, pl.Mem.Right] = pl.tile.create([128, 128], dtype=pl.INT8, target_memory=pl.Mem.Right)
                        buf_prefetched_key: pl.Tile[[128, 128], pl.INT8, pl.Mem.Right] = pl.tile.create([128, 128], dtype=pl.INT8, target_memory=pl.Mem.Right)
                        buf_key_l1_pool: pl.Tile[[256, 128], pl.INT8, pl.Mem.Mat] = pl.tile.create([256, 128], dtype=pl.INT8, target_memory=pl.Mem.Mat)
                        if pl.const(0, pl.INDEX) > pl.const(0, pl.INDEX):
                            buf_prime_col: pl.Scalar[pl.INDEX] = 0
                            for buf_prime_key_page in pl.unroll(4):
                                buf_prime_key_row: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_score_begin + buf_prime_col // 384 * buf_lane_span + buf_prime_col % 384 + buf_prime_key_page * 32
                                if False:
                                    buf_prime_key_row: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_score_begin + buf_prime_col + buf_prime_key_page * 32
                                buf_prime_safe_page: pl.Scalar[pl.INDEX] = pl.min(buf_prime_key_row // 32, pl.max((buf_cache_len - 1) // 32, 0))
                                buf_prime_physical_page: pl.Scalar[pl.INDEX] = pl.max(pl.cast(pl.tensor.read(idx_block_table, [buf_batch_idx, buf_prime_safe_page]), pl.INDEX), 0)
                                buf_prime_native_byte: pl.Scalar[pl.INDEX] = buf_prime_physical_page * native_page_bytes
                                if buf_prime_native_byte % 128 == 0:
                                    buf_key_l1_pool: pl.Tile[[256, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_key_l1_pool, idx_kv_cache, [buf_prime_key_page * 32, 0], [buf_prime_native_byte // 128, 0], [32, 128], transpose=False)
                                else:
                                    buf_key_l1_pool: pl.Tile[[256, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_key_l1_pool, idx_kv_cache_shift64, [buf_prime_key_page * 32, 0], [buf_prime_native_byte // 128, 0], [32, 128], transpose=False)
                            if True:
                                buf_current_key: pl.Tile[[128, 128], pl.INT8, pl.Mem.Right] = pl.tile.extract(pl.tile.transpose_view(buf_key_l1_pool), 0, 0, [128, 128], target_memory=pl.Mem.Right)
                        for buf_qk_panel in pl.unroll(6):
                            buf_panel_col: pl.Scalar[pl.INDEX] = buf_qk_panel * 128
                            buf_load_col: pl.Scalar[pl.INDEX] = (buf_qk_panel + 0) * 128
                            buf_load_slot: pl.Scalar[pl.INDEX] = (buf_qk_panel + 0) % 2 * 128
                            if pl.const(0, pl.INDEX) > pl.const(0, pl.INDEX):
                                if not True:
                                    buf_current_key: pl.Tile[[128, 128], pl.INT8, pl.Mem.Right] = pl.tile.extract(pl.tile.transpose_view(buf_key_l1_pool), 0, buf_qk_panel % 2 * 128, [128, 128], target_memory=pl.Mem.Right)
                            if buf_qk_panel + 0 < 6:
                                buf_panel_keys: pl.Tile[[128, 128], pl.INT8, pl.Mem.Mat] = pl.tile.create([128, 128], dtype=pl.INT8, target_memory=pl.Mem.Mat)
                                for buf_key_page in pl.unroll(4):
                                    buf_key_row: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_score_begin + buf_load_col // 384 * buf_lane_span + buf_load_col % 384 + buf_key_page * 32
                                    if False:
                                        buf_key_row: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_score_begin + buf_load_col + buf_key_page * 32
                                    buf_safe_page: pl.Scalar[pl.INDEX] = pl.min(buf_key_row // 32, pl.max((buf_cache_len - 1) // 32, 0))
                                    buf_physical_page: pl.Scalar[pl.INDEX] = pl.max(pl.cast(pl.tensor.read(idx_block_table, [buf_batch_idx, buf_safe_page]), pl.INDEX), 0)
                                    buf_native_byte: pl.Scalar[pl.INDEX] = buf_physical_page * native_page_bytes
                                    if buf_native_byte % 128 == 0:
                                        if pl.const(0, pl.INDEX) > pl.const(0, pl.INDEX):
                                            buf_key_l1_pool: pl.Tile[[256, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_key_l1_pool, idx_kv_cache, [buf_load_slot + buf_key_page * 32, 0], [buf_native_byte // 128, 0], [32, 128], transpose=False)
                                        else:
                                            buf_panel_keys: pl.Tile[[128, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_panel_keys, idx_kv_cache, [buf_key_page * 32, 0], [buf_native_byte // 128, 0], [32, 128], transpose=False)
                                    else:
                                        if pl.const(0, pl.INDEX) > pl.const(0, pl.INDEX):
                                            buf_key_l1_pool: pl.Tile[[256, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_key_l1_pool, idx_kv_cache_shift64, [buf_load_slot + buf_key_page * 32, 0], [buf_native_byte // 128, 0], [32, 128], transpose=False)
                                        else:
                                            buf_panel_keys: pl.Tile[[128, 128], pl.INT8, pl.Mem.Mat] = pl.tile.gather_row(buf_panel_keys, idx_kv_cache_shift64, [buf_key_page * 32, 0], [buf_native_byte // 128, 0], [32, 128], transpose=False)
                                if pl.const(0, pl.INDEX) > pl.const(0, pl.INDEX):
                                    if True:
                                        buf_prefetched_key: pl.Tile[[128, 128], pl.INT8, pl.Mem.Right] = pl.tile.extract(pl.tile.transpose_view(buf_key_l1_pool), 0, buf_load_slot, [128, 128], target_memory=pl.Mem.Right)
                                else:
                                    buf_prefetched_key: pl.Tile[[128, 128], pl.INT8, pl.Mem.Right] = pl.tile.move(pl.tile.transpose_view(buf_panel_keys), target_memory=pl.Mem.Right)
                            if pl.const(0, pl.INDEX) > pl.const(0, pl.INDEX):
                                buf_key_panel: pl.Tile[[128, 128], pl.INT8, pl.Mem.Right] = buf_current_key
                            else:
                                buf_key_panel: pl.Tile[[128, 128], pl.INT8, pl.Mem.Right] = buf_prefetched_key
                            buf_scores_l1: pl.Tile[[128, 128], pl.FP16, pl.Mem.Mat] = pl.tile.create([128, 128], dtype=pl.FP16, target_memory=pl.Mem.Mat)
                            if buf_qk_panel > 0:
                                buf_previous_pair: pl.Tile[[128, 128], pl.FP16, pl.Mem.Right] = pl.tile.extract(buf_previous_l1, 0, 0, [128, 128], target_memory=pl.Mem.Right)
                                buf_scores: pl.Tile[[128, 128], pl.INT32, pl.Mem.Acc] = pl.tile.matmul(buf_query_left, buf_key_panel)
                                buf_reduced_pair: pl.Tile[[16, 128], pl.FP32, pl.Mem.Acc] = pl.tile.matmul(buf_coefficient_pair, buf_previous_pair)
                                buf_scores_l1: pl.Tile[[128, 128], pl.FP16, pl.Mem.Mat] = pl.tile.assemble(buf_scores_l1, buf_scores, [0, 0], pre_quant=0.0009765625, pre_relu=True)
                                pl.tile.store(pl.tile.set_validshape(buf_reduced_pair, 2, 128), [buf_transfer_row, buf_panel_col - 128], buf_score_transfer)
                            else:
                                buf_scores: pl.Tile[[128, 128], pl.INT32, pl.Mem.Acc] = pl.tile.matmul(buf_query_left, buf_key_panel)
                                buf_scores_l1: pl.Tile[[128, 128], pl.FP16, pl.Mem.Mat] = pl.tile.assemble(buf_scores_l1, buf_scores, [0, 0], pre_quant=0.0009765625, pre_relu=True)
                            buf_previous_l1: pl.Tile[[128, 128], pl.FP16, pl.Mem.Mat] = buf_scores_l1
                            if pl.const(0, pl.INDEX) > pl.const(0, pl.INDEX):
                                if True:
                                    if buf_qk_panel + 1 < 6:
                                        buf_current_key: pl.Tile[[128, 128], pl.INT8, pl.Mem.Right] = buf_prefetched_key
                        buf_last_pair: pl.Tile[[128, 128], pl.FP16, pl.Mem.Right] = pl.tile.extract(buf_previous_l1, 0, 0, [128, 128], target_memory=pl.Mem.Right)
                        buf_last_scores: pl.Tile[[16, 128], pl.FP32, pl.Mem.Acc] = pl.tile.matmul(buf_coefficient_pair, buf_last_pair)
                        pl.tile.store(pl.tile.set_validshape(buf_last_scores, 2, 128), [buf_transfer_row, 640], buf_score_transfer)
                        pl.system.sync_set(0, pipe=pl.PipeType.FIX, ffts_mode=2, core_type=pl.KernelType.AIC)
                    for buf_score_drain in pl.range(pl.min(buf_score_iters, 2)):
                        pl.system.sync_wait(1, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIC)
            for buf_score_lane in pl.split_aiv(2, mode=pl.SplitMode.NONE):
                if False:
                    for single_item in pl.range(buf_worker, buf_group_count * buf_max_leaves, 24):
                        if buf_group_count < 24:
                            single_group: pl.Scalar[pl.INDEX] = single_item % buf_group_count
                            single_leaf: pl.Scalar[pl.INDEX] = single_item // buf_group_count
                        else:
                            single_group: pl.Scalar[pl.INDEX] = single_item // buf_max_leaves
                            single_leaf: pl.Scalar[pl.INDEX] = single_item % buf_max_leaves
                        single_query: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_row, [single_group]), pl.INDEX)
                        single_group_rows: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_rows, [single_group]), pl.INDEX)
                        single_batch: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(token_request, [single_query]), pl.INDEX)
                        single_cache_len: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(kv_seq_lens, [single_batch]), pl.INDEX) // 4
                        single_last_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [single_query + single_group_rows - 1])
                        single_visible: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(single_cache_len, (single_last_position + 1) // 4), 262144), 0)
                        single_begin: pl.Scalar[pl.INDEX] = (single_leaf * buf_leaf_tiles + pl.min(single_leaf, buf_extra_leaves)) * 768
                        single_capacity: pl.Scalar[pl.INDEX] = (buf_leaf_tiles + pl.cast(single_leaf < buf_extra_leaves, pl.INDEX)) * 768
                        if single_begin < single_visible:
                            single_valid: pl.Scalar[pl.INDEX] = pl.min(single_capacity, single_visible - single_begin)
                            single_steps: pl.Scalar[pl.INDEX] = (single_valid + 768 - 1) // 768
                            single_roots: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.full([1, 1024], dtype=pl.FP32, value=-3.4028234663852886e+38)
                            single_segments: pl.Tile[[2, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.full([2, 1024], dtype=pl.FP32, value=-3.4028234663852886e+38)
                            for single_step in pl.range(single_steps):
                                single_score_begin: pl.Scalar[pl.INDEX] = single_begin + single_step * 768
                                single_transfer_row: pl.Scalar[pl.INDEX] = buf_worker * 2 * 2 + single_step % 2 * 2 + buf_score_lane * 1
                                single_scale_bytes: pl.Tile[[1, 1536], pl.INT8] = pl.tile.create([1, 1536], dtype=pl.INT8)
                                for single_scale_page in pl.range(24):
                                    single_scale_logical: pl.Scalar[pl.INDEX] = pl.min(single_score_begin // 32 + single_scale_page, pl.max((single_cache_len - 1) // 32, 0))
                                    single_scale_physical: pl.Scalar[pl.INDEX] = pl.max(pl.cast(pl.tensor.read(idx_block_table, [single_batch, single_scale_logical]), pl.INDEX), 0)
                                    single_scale_bytes: pl.Tile[[1, 1536], pl.INT8] = pl.tile.gather_row(single_scale_bytes, idx_native_kv_cache, [0, single_scale_page * 32 * 2], [single_scale_physical, 4096], [1, 64], transpose=False)
                                single_scale_half: pl.Tile[[1, 768], pl.FP16] = pl.tile.reinterpret_view(single_scale_bytes, dtype=pl.FP16)
                                single_kv_scale: pl.Tile[[1, 768], pl.FP32, pl.Mem.Vec] = pl.tile.cast(single_scale_half, target_type=pl.FP32, mode='round')
                                pl.system.sync_wait(0, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIV)
                                single_scores: pl.Tile[[1, 768], pl.FP32] = pl.tile.load(buf_score_transfer, [single_transfer_row, 0], [1, 768], [1, 768])
                                pl.system.sync_set(1, pipe=pl.PipeType.MTE2, ffts_mode=2, core_type=pl.KernelType.AIV)
                                for single_local in pl.unroll(1):
                                    single_score_row: pl.Tile[[1, 768], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_scores, single_local, 0, [1, 768], target_memory=pl.Mem.Vec)
                                    single_scaled: pl.Tile[[1, 768], pl.FP32, pl.Mem.Vec] = pl.tile.mul(single_score_row, single_kv_scale)
                                    single_segments: pl.Tile[[2, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.assemble(single_segments, single_scaled, [single_local * 2 + single_step % 2, 0])
                                if single_step % 2 == 1 or single_step + 1 == single_steps:
                                    single_segment_begin: pl.Scalar[pl.INDEX] = single_begin + single_step // 2 * 1536
                                    single_segment_span: pl.Scalar[pl.INDEX] = (single_step % 2 + 1) * 768
                                    single_segment_rows: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec] = pl.tile.reshape(single_segments, [1, 2048])
                                    for single_local_1 in pl.unroll(1):
                                        single_query_lane: pl.Scalar[pl.INDEX] = buf_score_lane * 1 + single_local_1
                                        single_lane_live: pl.Scalar[pl.BOOL] = single_query_lane < single_group_rows
                                        single_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [single_query + pl.min(single_query_lane, single_group_rows - 1)])
                                        single_query_visible: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(single_cache_len, (single_position + 1) // 4), 262144), 0)
                                        single_segment_valid: pl.Scalar[pl.INDEX] = pl.max(pl.min(single_query_visible - single_segment_begin, single_segment_span), 0)
                                        if single_segment_valid > 0 and single_lane_live:
                                            single_segment_data: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_segment_rows, single_local_1, 0, [1, 2048], target_memory=pl.Mem.Vec)
                                            logical_i32: pl.Scalar[pl.INT32] = pl.cast(single_segment_begin, pl.INT32)
                                            if single_segment_valid <= 512:
                                                tiny_indices: pl.Tile[[1, 512], pl.INT32, pl.Mem.Vec] = pl.tile.adds(pl.tile.ci(pl.const(0, pl.INT32), [1, 512], dtype=pl.INT32, descending=False), logical_i32)
                                                tiny_tile: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_segment_data, 0, 0, [1, 512], target_memory=pl.Mem.Vec)
                                                tiny_raw: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[1, single_segment_valid])] = pl.tile.set_validshape(tiny_tile, 1, single_segment_valid)
                                                tiny_scores: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximums(pl.tile.fillpad(tiny_raw, pad_value=pl.PadValue.min), -3.4028234663852886e+38)
                                                tiny_pairs: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(tiny_scores, pl.tile.reinterpret_view(tiny_indices, dtype=pl.UINT32))
                                                tiny_pairs_v1: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(tiny_pairs, pl.const(64, pl.INT32))
                                                tiny_pairs_v2: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(tiny_pairs_v1, pl.const(256, pl.INT32))
                                                single_new_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(tiny_pairs_v2, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                            else:
                                                if single_segment_valid <= 1024:
                                                    small_indices: pl.Tile[[1, 1024], pl.INT32, pl.Mem.Vec] = pl.tile.adds(pl.tile.ci(pl.const(0, pl.INT32), [1, 1024], dtype=pl.INT32, descending=False), logical_i32)
                                                    small_tile: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_segment_data, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                                    small_raw: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[1, single_segment_valid])] = pl.tile.set_validshape(small_tile, 1, single_segment_valid)
                                                    small_scores: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximums(pl.tile.fillpad(small_raw, pad_value=pl.PadValue.min), -3.4028234663852886e+38)
                                                    small_pairs: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(small_scores, pl.tile.reinterpret_view(small_indices, dtype=pl.UINT32))
                                                    small_pairs_v1: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(small_pairs, pl.const(64, pl.INT32))
                                                    small_pairs_v2: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(small_pairs_v1, pl.const(256, pl.INT32))
                                                    small_left: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(small_pairs_v2, [1, 1024], [0, 0])
                                                    small_right: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(small_pairs_v2, [1, 1024], [0, 1024])
                                                    small_tmp: pl.Tile[[1, 2048], pl.FP32] = pl.tile.create([1, 2048], dtype=pl.FP32)
                                                    small_merged: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format2(small_left, small_right, small_tmp, exhausted=False)
                                                    single_new_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(small_merged, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                                else:
                                                    large_indices: pl.Tile[[1, 2048], pl.INT32, pl.Mem.Vec] = pl.tile.adds(pl.tile.ci(pl.const(0, pl.INT32), [1, 2048], dtype=pl.INT32, descending=False), logical_i32)
                                                    large_tile: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_segment_data, 0, 0, [1, 2048], target_memory=pl.Mem.Vec)
                                                    large_raw: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[1, single_segment_valid])] = pl.tile.set_validshape(large_tile, 1, single_segment_valid)
                                                    large_scores: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximums(pl.tile.fillpad(large_raw, pad_value=pl.PadValue.min), -3.4028234663852886e+38)
                                                    large_pairs: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(large_scores, pl.tile.reinterpret_view(large_indices, dtype=pl.UINT32))
                                                    large_pairs_v1: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(large_pairs, pl.const(64, pl.INT32))
                                                    large_pairs_v2: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(large_pairs_v1, pl.const(256, pl.INT32))
                                                    large_pairs_v3: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(large_pairs_v2, pl.const(1024, pl.INT32))
                                                    single_new_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(large_pairs_v3, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                            if single_step < 2:
                                                single_roots: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.assemble(single_roots, single_new_root, [single_local_1, 0])
                                            else:
                                                single_old_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_roots, single_local_1, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                                single_merge_tmp: pl.Tile[[1, 2048], pl.FP32] = pl.tile.create([1, 2048], dtype=pl.FP32)
                                                single_merged: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec] = pl.tile.mrgsort_format2(single_new_root, single_old_root, single_merge_tmp, exhausted=False)
                                                single_next_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_merged, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                                single_roots: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.assemble(single_roots, single_next_root, [single_local_1, 0])
                            for single_local_2 in pl.unroll(1):
                                single_query_lane: pl.Scalar[pl.INDEX] = buf_score_lane * 1 + single_local_2
                                if single_query_lane < single_group_rows:
                                    single_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.extract(single_roots, single_local_2, 0, [1, 1024], target_memory=pl.Mem.Vec)
                                    pl.tile.store(single_root, [(single_query + single_query_lane) * 64 + single_leaf, 0], pair_arena)
                else:
                    for buf_item_1 in pl.range(buf_worker, buf_group_count * buf_max_leaves, 24):
                        if buf_group_count < 24:
                            buf_group: pl.Scalar[pl.INDEX] = buf_item_1 % buf_group_count
                            buf_leaf: pl.Scalar[pl.INDEX] = buf_item_1 // buf_group_count
                        else:
                            buf_group: pl.Scalar[pl.INDEX] = buf_item_1 // buf_max_leaves
                            buf_leaf: pl.Scalar[pl.INDEX] = buf_item_1 % buf_max_leaves
                        buf_query: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_row, [buf_group]), pl.INDEX)
                        buf_group_rows: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(group_rows, [buf_group]), pl.INDEX)
                        buf_batch_idx: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(token_request, [buf_query]), pl.INDEX)
                        buf_last_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [buf_query + buf_group_rows - 1])
                        buf_cache_len: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(kv_seq_lens, [buf_batch_idx]), pl.INDEX) // 4
                        buf_visible_count: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(buf_cache_len, (buf_last_position + 1) // 4), 262144), 0)
                        buf_logical_begin: pl.Scalar[pl.INDEX] = buf_leaf * 8192
                        buf_leaf_capacity: pl.Scalar[pl.INDEX] = 8192
                        if False:
                            buf_logical_begin: pl.Scalar[pl.INDEX] = (buf_leaf * buf_leaf_tiles + pl.min(buf_leaf, buf_extra_leaves)) * 1024
                            buf_leaf_capacity: pl.Scalar[pl.INDEX] = (buf_leaf_tiles + pl.cast(buf_leaf < buf_extra_leaves, pl.INDEX)) * 1024
                        if buf_logical_begin < buf_visible_count:
                            buf_valid_count: pl.Scalar[pl.INDEX] = pl.min(buf_leaf_capacity, buf_visible_count - buf_logical_begin)
                            buf_tile_count: pl.Scalar[pl.INDEX] = (buf_valid_count + 768 - 1) // 768
                            buf_lane_span: pl.Scalar[pl.INDEX] = pl.min(buf_tile_count * 384, 4096)
                            buf_score_iters: pl.Scalar[pl.INDEX] = (buf_lane_span + 384 - 1) // 384
                            buf_lane_begin: pl.Scalar[pl.INDEX] = buf_score_lane * buf_lane_span
                            prefix_roots: pl.Tile[[2, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.full([2, 1024], dtype=pl.FP32, value=-3.4028234663852886e+38)
                            for buf_score_step_1 in pl.range(buf_score_iters):
                                buf_score_begin: pl.Scalar[pl.INDEX] = buf_score_step_1 * 384
                                buf_transfer_row: pl.Scalar[pl.INDEX] = buf_worker * 2 * 2 + buf_score_step_1 % 2 * 2
                                buf_scale_bytes: pl.Tile[[1, 768], pl.INT8] = pl.tile.create([1, 768], dtype=pl.INT8)
                                for buf_scale_page in pl.range(12):
                                    buf_scale_row: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_score_begin + buf_lane_begin + buf_scale_page * 32
                                    buf_scale_safe_page: pl.Scalar[pl.INDEX] = pl.min(buf_scale_row // 32, pl.max((buf_cache_len - 1) // 32, 0))
                                    buf_scale_physical_page: pl.Scalar[pl.INDEX] = pl.max(pl.cast(pl.tensor.read(idx_block_table, [buf_batch_idx, buf_scale_safe_page]), pl.INDEX), 0)
                                    buf_scale_bytes: pl.Tile[[1, 768], pl.INT8] = pl.tile.gather_row(buf_scale_bytes, idx_native_kv_cache, [0, buf_scale_page * 32 * 2], [buf_scale_physical_page, 4096], [1, 64], transpose=False)
                                buf_scale_half: pl.Tile[[1, 384], pl.FP16] = pl.tile.reinterpret_view(buf_scale_bytes, dtype=pl.FP16)
                                buf_kv_scale: pl.Tile[[1, 384], pl.FP32, pl.Mem.Vec] = pl.tile.cast(buf_scale_half, target_type=pl.FP32, mode='round')
                                pl.system.sync_wait(0, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIV)
                                buf_score_sums: pl.Tile[[2, 384], pl.FP32] = pl.tile.load(buf_score_transfer, [buf_transfer_row, buf_score_lane * 384], [2, 384], [2, 384])
                                pl.system.sync_set(1, pipe=pl.PipeType.MTE2, ffts_mode=2, core_type=pl.KernelType.AIV)
                                for buf_query_lane in pl.unroll(2):
                                    buf_lane_live: pl.Scalar[pl.BOOL] = buf_query_lane < buf_group_rows
                                    buf_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [buf_query + pl.min(buf_query_lane, buf_group_rows - 1)])
                                    buf_query_visible: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(buf_cache_len, (buf_position + 1) // 4), 262144), 0)
                                    buf_lane_valid_rows: pl.Scalar[pl.INDEX] = pl.max(pl.min(buf_query_visible - buf_logical_begin - buf_score_begin - buf_lane_begin, 384), 0)
                                    buf_lane_valid_rows_v1: pl.Scalar[pl.INDEX] = pl.min(buf_lane_valid_rows, pl.max(buf_lane_span - buf_score_begin, 0))
                                    buf_score_sum: pl.Tile[[1, 384], pl.FP32] = pl.tile.slice(buf_score_sums, [1, 384], [buf_query_lane, 0])
                                    buf_score_row: pl.Tile[[1, 384], pl.FP32, pl.Mem.Vec] = pl.tile.mul(buf_score_sum, buf_kv_scale)
                                    buf_store_row: pl.Scalar[pl.INDEX] = buf_query + buf_query_lane
                                    buf_store_column: pl.Scalar[pl.INDEX] = buf_score_begin + buf_lane_begin
                                    if buf_max_leaves > 1:
                                        buf_store_row: pl.Scalar[pl.INDEX] = buf_worker * 2 * 2 + buf_query_lane * 2 + buf_score_lane
                                        buf_store_column: pl.Scalar[pl.INDEX] = buf_score_begin
                                    if buf_lane_valid_rows_v1 > 0 and buf_lane_live:
                                        pl.tile.store(pl.tile.set_validshape(buf_score_row, 1, buf_lane_valid_rows_v1), [buf_store_row, buf_store_column], score_arena)
                                if False:
                                    if buf_score_step_1 == 3 and buf_score_iters > 4:
                                        for stream_lane in pl.unroll(2):
                                            stream_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [buf_query + pl.min(stream_lane, buf_group_rows - 1)])
                                            stream_visible: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(buf_cache_len, (stream_position + 1) // 4), 262144), 0)
                                            stream_begin: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_lane_begin
                                            stream_valid: pl.Scalar[pl.INDEX] = pl.max(pl.min(stream_visible - stream_begin, 2048), 0)
                                            if stream_valid > 0 and stream_lane < buf_group_rows:
                                                stream_root: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = self.indexer_topk_segment_pairs(score_arena, buf_worker * 2 * 2 + stream_lane * 2 + buf_score_lane, stream_begin, stream_valid)
                                                prefix_roots: pl.Tile[[2, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.assemble(prefix_roots, stream_root, [stream_lane, 0])
                            if buf_max_leaves > 1:
                                for buf_query_lane_1 in pl.unroll(2):
                                    if buf_query_lane_1 < buf_group_rows:
                                        buf_position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [buf_query + buf_query_lane_1])
                                        buf_query_visible: pl.Scalar[pl.INDEX] = pl.max(pl.min(pl.min(buf_cache_len, (buf_position + 1) // 4), 262144), 0)
                                        buf_half_begin: pl.Scalar[pl.INDEX] = buf_logical_begin + buf_lane_begin
                                        buf_half_valid: pl.Scalar[pl.INDEX] = pl.max(pl.min(buf_query_visible - buf_half_begin, buf_lane_span), 0)
                                        buf_half_slot: pl.Scalar[pl.INDEX] = (buf_query + buf_query_lane_1) * 64 + buf_leaf * 2 + buf_score_lane
                                        if buf_half_valid > 0:
                                            self.indexer_topk_half_leaf(score_arena, pair_arena, buf_worker * 2 * 2 + buf_query_lane_1 * 2 + buf_score_lane, buf_half_begin, buf_half_valid, buf_half_slot)
                                        else:
                                            pl.tile.store(pl.tile.full([1, 1024], dtype=pl.FP32, value=-3.4028234663852886e+38), [buf_half_slot, 0], pair_arena)
        return buffered_leaf_tid
    @pl.function(type=pl.FunctionType.Inline)
    def merge2_top512_pairs(self, pair_arena: pl.Tensor[[27648, 1024], pl.FP32], left_slot: pl.Scalar[pl.INDEX], right_slot: pl.Scalar[pl.INDEX], output_slot: pl.Scalar[pl.INDEX]):
        # Merge two arena rows and store their exact Top-512 pair row.
        left: pl.Tile[[1, 1024], pl.FP32] = pl.tile.load(pair_arena, [left_slot, 0], [1, 1024], [1, 1024])
        right: pl.Tile[[1, 1024], pl.FP32] = pl.tile.load(pair_arena, [right_slot, 0], [1, 1024], [1, 1024])
        merge_tmp: pl.Tile[[1, 2048], pl.FP32] = pl.tile.create([1, 2048], dtype=pl.FP32)
        merged_all: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec] = pl.tile.mrgsort_format2(right, left, merge_tmp, exhausted=False)
        merged: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.slice(merged_all, [1, 1024], [0, 0])
        pl.tile.store(merged, [output_slot, 0], pair_arena)
    @pl.function(type=pl.FunctionType.Inline)
    def merge_top512_roots(self, pair_arena: pl.Tensor[[27648, 1024], pl.FP32], arena_base: pl.Scalar[pl.INDEX], half_count: pl.Scalar[pl.INDEX]):
        # Keep the exact Top-512 prefix in UB between four-way merge rounds.
        # 
        #         QLI V2's ProcessLD retains the accumulated root until final publication.
        #         Explicit extract gives the loop-carried value a 1024-float allocation;
        #         carrying a slice of the full merge output would also carry its storage.
        #         
        root: pl.Tile[[1, 1024], pl.FP32] = pl.tile.load(pair_arena, [arena_base, 0], [1, 1024], [1, 1024])
        for child in pl.range(1, half_count, 3):
            incoming1: pl.Tile[[1, 1024], pl.FP32] = pl.tile.load(pair_arena, [arena_base + child, 0], [1, 1024], [1, 1024])
            if child + 2 < half_count:
                incoming2: pl.Tile[[1, 1024], pl.FP32] = pl.tile.load(pair_arena, [arena_base + child + 1, 0], [1, 1024], [1, 1024])
                incoming3: pl.Tile[[1, 1024], pl.FP32] = pl.tile.load(pair_arena, [arena_base + child + 2, 0], [1, 1024], [1, 1024])
                merge_tmp4: pl.Tile[[1, 4096], pl.FP32] = pl.tile.create([1, 4096], dtype=pl.FP32)
                merged4: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec] = pl.tile.mrgsort_format2(incoming3, incoming2, incoming1, root, merge_tmp4, exhausted=True)
                root: pl.Tile[[1, 1024], pl.FP32] = pl.tile.extract(merged4, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
            else:
                if child + 1 < half_count:
                    incoming2: pl.Tile[[1, 1024], pl.FP32] = pl.tile.load(pair_arena, [arena_base + child + 1, 0], [1, 1024], [1, 1024])
                    merge_tmp3: pl.Tile[[1, 3072], pl.FP32] = pl.tile.create([1, 3072], dtype=pl.FP32)
                    merged3: pl.Tile[[1, 3072], pl.FP32, pl.Mem.Vec] = pl.tile.mrgsort_format2(incoming2, incoming1, root, merge_tmp3, exhausted=True)
                    root: pl.Tile[[1, 1024], pl.FP32] = pl.tile.extract(merged3, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
                else:
                    merge_tmp2: pl.Tile[[1, 2048], pl.FP32] = pl.tile.create([1, 2048], dtype=pl.FP32)
                    merged2: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec] = pl.tile.mrgsort_format2(incoming1, root, merge_tmp2, exhausted=False)
                    root: pl.Tile[[1, 1024], pl.FP32] = pl.tile.extract(merged2, 0, 0, [1, 1024], target_memory=pl.Mem.Vec)
        return root
    @pl.function(type=pl.FunctionType.Inline)
    def indexer_topk_query_merge_one(self, query: pl.Scalar[pl.INDEX], position_ids: pl.Tensor[[T_DYN], pl.INT64], kv_seq_lens: pl.Tensor[[B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], pair_arena: pl.Tensor[[27648, 1024], pl.FP32], topk_scores: pl.Tensor[[T_DYN, 512], pl.FP32], topk_indices: pl.Tensor[[T_DYN, 512], pl.INT32], leaf_tiles: pl.Scalar[pl.INDEX], extra_leaves: pl.Scalar[pl.INDEX], use_request_groups: pl.Scalar[pl.INDEX]):
        # Merge the selected leaf roots and publish one query's Top-512.
        batch_idx: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(token_request, [query]), pl.INDEX)
        position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [query])
        cache_len: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(kv_seq_lens, [pl.max(batch_idx, 0)]), pl.INDEX) // 4
        if batch_idx < 0:
            cache_len: pl.Scalar[pl.INDEX] = 0
        cache_bound: pl.Scalar[pl.INDEX] = pl.min(cache_len, (position + 1) // 4)
        visible_count: pl.Scalar[pl.INDEX] = pl.min(cache_bound, 262144)
        if visible_count > 0:
            leaf_count: pl.Scalar[pl.INDEX] = (visible_count + 8192 - 1) // 8192
            if True:
                visible_tiles: pl.Scalar[pl.INDEX] = (visible_count + 1024 - 1) // 1024
                larger_leaf_tiles: pl.Scalar[pl.INDEX] = extra_leaves * (leaf_tiles + 1)
                larger_leaf_count: pl.Scalar[pl.INDEX] = pl.min(extra_leaves, (visible_tiles + leaf_tiles) // (leaf_tiles + 1))
                remaining_tiles: pl.Scalar[pl.INDEX] = pl.max(visible_tiles - larger_leaf_tiles, 0)
                leaf_count: pl.Scalar[pl.INDEX] = larger_leaf_count + (remaining_tiles + leaf_tiles - 1) // leaf_tiles
            half_count: pl.Scalar[pl.INDEX] = leaf_count * 2
            if True:
                if use_request_groups == 1:
                    half_count: pl.Scalar[pl.INDEX] = leaf_count
            arena_base: pl.Scalar[pl.INDEX] = query * 64
            if True:
                root_pairs: pl.Tile[[1, 1024], pl.FP32] = self.merge_top512_roots(pair_arena, arena_base, half_count)
            else:
                for child in pl.range(1, half_count):
                    self.merge2_top512_pairs(pair_arena, arena_base, arena_base + child, arena_base)
                root_slot: pl.Scalar[pl.INDEX] = arena_base
                root_pairs: pl.Tile[[1, 1024], pl.FP32] = pl.tile.load(pair_arena, [root_slot, 0], [1, 1024], [1, 1024])
            root_scores: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec] = pl.tile.gather_mask(root_pairs, mask_pattern=1, output_dtype=pl.FP32)
            pl.tile.store(root_scores, [query, 0], topk_scores)
            root_indices: pl.Tile[[1, 512], pl.INT32, pl.Mem.Vec] = pl.tile.gather_mask(root_pairs, mask_pattern=2, output_dtype=pl.INT32)
            if visible_count >= 512:
                pl.tile.store(root_indices, [query, 0], topk_indices)
            else:
                output_indices: pl.Tile[[1, 512], pl.INT32, pl.Mem.Vec] = pl.tile.full([1, 512], dtype=pl.INT32, value=-1)
                for lane in pl.range(visible_count):
                    pl.tile.write(output_indices, [0, lane], pl.tile.read(root_indices, [0, lane]))
                pl.tile.store(output_indices, [query, 0], topk_indices)
        else:
            pl.tile.store(pl.tile.full([1, 512], dtype=pl.FP32, value=-3.4028234663852886e+38), [query, 0], topk_scores)
            pl.tile.store(pl.tile.full([1, 512], dtype=pl.INT32, value=-1), [query, 0], topk_indices)
    @pl.function(type=pl.FunctionType.InCore, level=pl.Level.CHIP_DIE, role=pl.Role.SubWorker)
    def indexer_topk_query_merge(position_ids: pl.Tensor[[T_DYN], pl.INT64], kv_seq_lens: pl.Tensor[[B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], pair_arena: pl.Tensor[[27648, 1024], pl.FP32], topk_scores: pl.Tensor[[T_DYN, 512], pl.FP32], topk_indices: pl.Tensor[[T_DYN, 512], pl.INT32]):
        # Merge query roots on one persistent worker per physical AIV.
        worker: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
        query_count: pl.Scalar[pl.INDEX] = pl.tensor.dim(position_ids, 0)
        merge_request_groups: pl.Scalar[pl.INDEX] = self.indexer_query_group_count(query_start_loc, kv_seq_lens)
        merge_use_request: pl.Scalar[pl.INDEX] = pl.cast(merge_request_groups >= 4, pl.INDEX)
        merge_leaf_tiles: pl.Scalar[pl.INDEX] = 8
        merge_extra_leaves: pl.Scalar[pl.INDEX] = 0
        if True:
            max_cache_count: pl.Scalar[pl.INDEX] = 0
            for batch in pl.range(pl.tensor.dim(kv_seq_lens, 0)):
                max_cache_count: pl.Scalar[pl.INDEX] = pl.max(max_cache_count, pl.cast(pl.tensor.read(kv_seq_lens, [batch]), pl.INDEX) // 4)
            query_groups: pl.Scalar[pl.INDEX] = self.indexer_query_group_count__2(query_start_loc, kv_seq_lens)
            if merge_use_request == 1:
                query_groups: pl.Scalar[pl.INDEX] = merge_request_groups
            _tuple_tmp: pl.Tuple[pl.Scalar[pl.INDEX], pl.Scalar[pl.INDEX], pl.Scalar[pl.INDEX]] = self.indexer_long_leaf_plan(pl.min(max_cache_count, 262144), query_groups)
            _merge_leaf_count: pl.Scalar[pl.INDEX] = _tuple_tmp[0]
            merge_leaf_tiles: pl.Scalar[pl.INDEX] = _tuple_tmp[1]
            merge_extra_leaves: pl.Scalar[pl.INDEX] = _tuple_tmp[2]
        for query in pl.range(worker, query_count, 48):
            self.indexer_topk_query_merge_one(query, position_ids, kv_seq_lens, token_request, pair_arena, topk_scores, topk_indices, merge_leaf_tiles, merge_extra_leaves, merge_use_request)
    @pl.function(type=pl.FunctionType.Inline)
    def indexer_topk_leaf_publish(self, score_arena: pl.Tensor[[432, 8192], pl.FP32], query: pl.Scalar[pl.INDEX], valid_count: pl.Scalar[pl.INDEX], topk_scores: pl.Tensor[[T_DYN, 512], pl.FP32], topk_indices: pl.Tensor[[T_DYN, 512], pl.INT32]):
        # Sort one populated leaf and directly publish its Top-512 pairs.
        if valid_count <= 2048:
            short_indices: pl.Tile[[1, 2048], pl.INT32, pl.Mem.Vec] = pl.tile.ci(pl.const(0, pl.INT32), [1, 2048], dtype=pl.INT32, descending=False)
            short_raw: pl.Tile[[1, 2048], pl.FP32, pl.TileView(valid_shape=[1, valid_count])] = pl.tile.load(score_arena, [query, 0], [1, 2048], [1, valid_count])
            short_scores: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.fillpad(short_raw, pad_value=pl.PadValue.min)
            short_scores_v1: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximums(short_scores, -3.4028234663852886e+38)
            short_pairs: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(short_scores_v1, pl.tile.reinterpret_view(short_indices, dtype=pl.UINT32))
            short_pairs_v1: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(short_pairs, pl.const(64, pl.INT32))
            short_pairs_v2: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(short_pairs_v1, pl.const(256, pl.INT32))
            short_pairs_v3: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(short_pairs_v2, pl.const(1024, pl.INT32))
            short_top: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(short_pairs_v3, [1, 1024], [0, 0])
            short_values: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.gather_mask(short_top, mask_pattern=1, output_dtype=pl.FP32)
            short_selected: pl.Tile[[1, 512], pl.INT32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.gather_mask(short_top, mask_pattern=2, output_dtype=pl.INT32)
            pl.tile.store(short_values, [query, 0], topk_scores)
            if valid_count >= 512:
                pl.tile.store(short_selected, [query, 0], topk_indices)
            else:
                short_output: pl.Tile[[1, 512], pl.INT32, pl.Mem.Vec] = pl.tile.full([1, 512], dtype=pl.INT32, value=-1)
                for lane in pl.range(valid_count):
                    pl.tile.write(short_output, [0, lane], pl.tile.read(short_selected, [0, lane]))
                pl.tile.store(short_output, [query, 0], topk_indices)
        else:
            if valid_count <= 4096:
                medium_indices: pl.Tile[[1, 4096], pl.INT32, pl.Mem.Vec] = pl.tile.ci(pl.const(0, pl.INT32), [1, 4096], dtype=pl.INT32, descending=False)
                medium_raw: pl.Tile[[1, 4096], pl.FP32, pl.TileView(valid_shape=[1, valid_count])] = pl.tile.load(score_arena, [query, 0], [1, 4096], [1, valid_count])
                medium_scores: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.fillpad(medium_raw, pad_value=pl.PadValue.min)
                medium_scores_v1: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximums(medium_scores, -3.4028234663852886e+38)
                medium_pairs: pl.Tile[[1, 8192], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(medium_scores_v1, pl.tile.reinterpret_view(medium_indices, dtype=pl.UINT32))
                medium_pairs_v1: pl.Tile[[1, 8192], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(medium_pairs, pl.const(64, pl.INT32))
                medium_pairs_v2: pl.Tile[[1, 8192], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(medium_pairs_v1, pl.const(256, pl.INT32))
                medium_pairs_v3: pl.Tile[[1, 8192], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(medium_pairs_v2, pl.const(1024, pl.INT32))
                medium_left: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(medium_pairs_v3, [1, 1024], [0, 0])
                medium_right: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(medium_pairs_v3, [1, 1024], [0, 4096])
                medium_tmp: pl.Tile[[1, 2048], pl.FP32] = pl.tile.create([1, 2048], dtype=pl.FP32)
                medium_merged: pl.Tile[[1, 2048], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format2(medium_right, medium_left, medium_tmp, exhausted=False)
                medium_top: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(medium_merged, [1, 1024], [0, 0])
                medium_values: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.gather_mask(medium_top, mask_pattern=1, output_dtype=pl.FP32)
                medium_selected: pl.Tile[[1, 512], pl.INT32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.gather_mask(medium_top, mask_pattern=2, output_dtype=pl.INT32)
                pl.tile.store(medium_values, [query, 0], topk_scores)
                pl.tile.store(medium_selected, [query, 0], topk_indices)
            else:
                full_indices: pl.Tile[[1, 8192], pl.INT32, pl.Mem.Vec] = pl.tile.ci(pl.const(0, pl.INT32), [1, 8192], dtype=pl.INT32, descending=False)
                full_raw: pl.Tile[[1, 8192], pl.FP32, pl.TileView(valid_shape=[1, valid_count])] = pl.tile.load(score_arena, [query, 0], [1, 8192], [1, valid_count])
                full_scores: pl.Tile[[1, 8192], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.fillpad(full_raw, pad_value=pl.PadValue.min)
                full_min: pl.Tile[[1, 8192], pl.FP32, pl.Mem.Vec] = pl.tile.full([1, 8192], dtype=pl.FP32, value=-3.4028234663852886e+38)
                full_scores_v1: pl.Tile[[1, 8192], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.maximum(full_scores, full_min)
                full_pairs: pl.Tile[[1, 16384], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.sort32(full_scores_v1, pl.tile.reinterpret_view(full_indices, dtype=pl.UINT32))
                full_pairs_v1: pl.Tile[[1, 16384], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(full_pairs, pl.const(64, pl.INT32))
                full_pairs_v2: pl.Tile[[1, 16384], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(full_pairs_v1, pl.const(256, pl.INT32))
                full_pairs_v3: pl.Tile[[1, 16384], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format1(full_pairs_v2, pl.const(1024, pl.INT32))
                full_first: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(full_pairs_v3, [1, 1024], [0, 0])
                full_second: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(full_pairs_v3, [1, 1024], [0, 4096])
                full_third: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(full_pairs_v3, [1, 1024], [0, 8192])
                full_fourth: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(full_pairs_v3, [1, 1024], [0, 12288])
                full_tmp: pl.Tile[[1, 4096], pl.FP32] = pl.tile.create([1, 4096], dtype=pl.FP32)
                full_merged: pl.Tile[[1, 4096], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.mrgsort_format2(full_fourth, full_third, full_second, full_first, full_tmp, exhausted=False)
                full_top: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.slice(full_merged, [1, 1024], [0, 0])
                full_values: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.gather_mask(full_top, mask_pattern=1, output_dtype=pl.FP32)
                full_selected: pl.Tile[[1, 512], pl.INT32, pl.Mem.Vec, pl.TileView(pad=pl.PadValue.min)] = pl.tile.gather_mask(full_top, mask_pattern=2, output_dtype=pl.INT32)
                pl.tile.store(full_values, [query, 0], topk_scores)
                pl.tile.store(full_selected, [query, 0], topk_indices)
    @pl.function(type=pl.FunctionType.InCore, level=pl.Level.CHIP_DIE, role=pl.Role.SubWorker)
    def indexer_topk_single_leaf_publish(position_ids: pl.Tensor[[T_DYN], pl.INT64], kv_seq_lens: pl.Tensor[[B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], score_arena: pl.Tensor[[432, 8192], pl.FP32], topk_scores: pl.Tensor[[T_DYN, 512], pl.FP32], topk_indices: pl.Tensor[[T_DYN, 512], pl.INT32]):
        # Sort a single leaf and publish each query's Top-512 directly.
        worker: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
        query_count: pl.Scalar[pl.INDEX] = pl.tensor.dim(position_ids, 0)
        for query in pl.range(worker, query_count, 48):
            position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [query])
            query_request: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(token_request, [query]), pl.INDEX)
            cache_len: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(kv_seq_lens, [pl.max(query_request, 0)]), pl.INDEX) // 4
            if query_request < 0:
                cache_len: pl.Scalar[pl.INDEX] = 0
            visible_count: pl.Scalar[pl.INDEX] = pl.max(pl.min(cache_len, (position + 1) // 4), 0)
            if visible_count > 0:
                self.indexer_topk_leaf_publish(score_arena, query, visible_count, topk_scores, topk_indices)
            else:
                pl.tile.store(pl.tile.full([1, 512], dtype=pl.FP32, value=-3.4028234663852886e+38), [query, 0], topk_scores)
                pl.tile.store(pl.tile.full([1, 512], dtype=pl.INT32, value=-1), [query, 0], topk_indices)
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def indexer_score_topk_forest(self, qr_hadamard_i8: pl.Tensor[[27648, 128], pl.INT8], qr_hadamard_scale_dq: pl.Tensor[[27648, 1], pl.FP32], weights: pl.Tensor[[432, 64], pl.FP32], idx_native_kv_cache: pl.Tensor[[IDX_NATIVE_CACHE_BLOCK_NUM_DYN, INDEXER_PAGE_BYTES_DYN], pl.INT8], idx_block_table: pl.Tensor[[B_DYN, INDEXER_TABLE_COLUMNS_DYN], pl.INT32], position_ids: pl.Tensor[[T_DYN], pl.INT64], kv_seq_lens: pl.Tensor[[B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], topk_scores: pl.Tensor[[T_DYN, 512], pl.FP32], topk_idxs: pl.Tensor[[T_DYN, 512], pl.INT32], qh_quant_tid: pl.Scalar[pl.TASK_ID], weights_tid: pl.Scalar[pl.TASK_ID], cache_write_tid: pl.Scalar[pl.TASK_ID], host_max_seq_len: pl.Scalar[pl.INT32]):
        # Score leaves and merge Top-K roots; long S6 publishes one root per leaf.
        rgroup_row: pl.Tensor[[432], pl.INT32] = pl.tensor.create([432], dtype=pl.INT32, layout=pl.TensorLayout.ND)
        rgroup_rows: pl.Tensor[[432], pl.INT32] = pl.tensor.create([432], dtype=pl.INT32, layout=pl.TensorLayout.ND)
        rgroup_count: pl.Tensor[[1], pl.INT32] = pl.tensor.create([1], dtype=pl.INT32, layout=pl.TensorLayout.ND)
        pgroup_row: pl.Tensor[[432], pl.INT32] = pl.tensor.create([432], dtype=pl.INT32, layout=pl.TensorLayout.ND)
        pgroup_rows: pl.Tensor[[432], pl.INT32] = pl.tensor.create([432], dtype=pl.INT32, layout=pl.TensorLayout.ND)
        pgroup_count: pl.Tensor[[1], pl.INT32] = pl.tensor.create([1], dtype=pl.INT32, layout=pl.TensorLayout.ND)
        with pl.at(level=pl.Level.CORE_GROUP, name_hint="indexer_query_groups") as groups_tid:
            for token in pl.range(pl.tensor.dim(position_ids, 0)):
                if pl.cast(pl.tensor.read(token_request, [token]), pl.INDEX) < 0:
                    pl.tile.store(pl.tile.full([1, 512], dtype=pl.FP32, value=-3.4028234663852886e+38), [token, 0], topk_scores)
                    pl.tile.store(pl.tile.full([1, 512], dtype=pl.INT32, value=-1), [token, 0], topk_idxs)
            self.indexer_build_query_groups(query_start_loc, kv_seq_lens, rgroup_row, rgroup_rows, rgroup_count)
            self.indexer_build_query_groups__2(query_start_loc, kv_seq_lens, pgroup_row, pgroup_rows, pgroup_count)
        native_page_bytes: pl.Scalar[pl.INDEX] = pl.tensor.dim(idx_native_kv_cache, 1)
        cache_bytes: pl.Scalar[pl.INDEX] = pl.tensor.dim(idx_native_kv_cache, 0) * native_page_bytes
        cache_flat: pl.Tensor[[cache_bytes], pl.INT8] = pl.tensor.reshape(idx_native_kv_cache, [cache_bytes])
        key_rows: pl.Scalar[pl.INDEX] = cache_bytes // 128
        shifted_rows: pl.Scalar[pl.INDEX] = (cache_bytes - 64) // 128
        idx_kv_cache: pl.Tensor[[key_rows, 128], pl.INT8] = pl.tensor.reshape(pl.tensor.slice(cache_flat, [key_rows * 128], [0]), [key_rows, 128])
        idx_kv_cache_shift64: pl.Tensor[[shifted_rows, 128], pl.INT8] = pl.tensor.reshape(pl.tensor.slice(cache_flat, [shifted_rows * 128], [64]), [shifted_rows, 128])
        pair_arena: pl.Tensor[[27648, 1024], pl.FP32] = pl.tensor.create([27648, 1024], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        score_arena: pl.Tensor[[432, 8192], pl.FP32] = pl.tensor.create([432, 8192], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        max_topk_cache_len: pl.Scalar[pl.INDEX] = pl.cast(host_max_seq_len, pl.INDEX) // 4
        if max_topk_cache_len >= 0:
            if max_topk_cache_len > 8192:
                long_request_groups: pl.Scalar[pl.INDEX] = self.indexer_query_group_count(query_start_loc, kv_seq_lens)
                if long_request_groups >= 4:
                    score_tid: pl.Scalar[pl.TASK_ID] = self.indexer_score_topk_native_cube(qr_hadamard_i8, qr_hadamard_scale_dq, weights, idx_native_kv_cache, idx_block_table, position_ids, kv_seq_lens, token_request, rgroup_row, rgroup_rows, rgroup_count, groups_tid, score_arena, pair_arena, qh_quant_tid, weights_tid, cache_write_tid)
                else:
                    score_tid: pl.Scalar[pl.TASK_ID] = self.indexer_score_topk_native_cube__2(qr_hadamard_i8, qr_hadamard_scale_dq, weights, idx_native_kv_cache, idx_block_table, position_ids, kv_seq_lens, token_request, pgroup_row, pgroup_rows, pgroup_count, groups_tid, score_arena, pair_arena, qh_quant_tid, weights_tid, cache_write_tid)
            else:
                short_pair_groups: pl.Scalar[pl.INDEX] = self.indexer_query_group_count__2(query_start_loc, kv_seq_lens)
                short_request_groups: pl.Scalar[pl.INDEX] = self.indexer_query_group_count(query_start_loc, kv_seq_lens)
                short_pair_waves: pl.Scalar[pl.INDEX] = (short_pair_groups + 24 - 1) // 24
                short_request_waves: pl.Scalar[pl.INDEX] = (short_request_groups + 24 - 1) // 24
                short_use_request: pl.Scalar[pl.INT32] = pl.cast(0, pl.INT32)
                if short_request_groups >= 24:
                    if 24 * short_request_waves <= 10 * short_pair_waves:
                        short_use_request: pl.Scalar[pl.INT32] = pl.cast(1, pl.INT32)
                if pl.cast(short_use_request, pl.INDEX) == 1:
                    score_tid: pl.Scalar[pl.TASK_ID] = self.indexer_score_topk_native_cube__3(qr_hadamard_i8, qr_hadamard_scale_dq, weights, idx_native_kv_cache, idx_block_table, position_ids, kv_seq_lens, token_request, rgroup_row, rgroup_rows, rgroup_count, groups_tid, score_arena, pair_arena, qh_quant_tid, weights_tid, cache_write_tid)
                else:
                    score_tid: pl.Scalar[pl.TASK_ID] = self.indexer_score_topk_native_cube__4(qr_hadamard_i8, qr_hadamard_scale_dq, weights, idx_native_kv_cache, idx_block_table, position_ids, kv_seq_lens, token_request, pgroup_row, pgroup_rows, pgroup_count, groups_tid, score_arena, pair_arena, qh_quant_tid, weights_tid, cache_write_tid)
        else:
            with pl.spmd(24, name_hint="indexer_score_topk_leaf_spmd", optimizations=[pl.cross_core_slot(slot_num=1)], deps=[qh_quant_tid, weights_tid, cache_write_tid], allow_early_resolve=True) as direct_leaf_tid:
                worker: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
                query_count: pl.Scalar[pl.INDEX] = pl.tensor.dim(position_ids, 0)
                max_cache_len: pl.Scalar[pl.INDEX] = 0
                for batch in pl.range(pl.tensor.dim(kv_seq_lens, 0)):
                    batch_cache_len: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(kv_seq_lens, [batch]), pl.INDEX) // 4
                    max_cache_len: pl.Scalar[pl.INDEX] = pl.max(max_cache_len, batch_cache_len)
                max_leaves: pl.Scalar[pl.INDEX] = pl.max((pl.min(max_cache_len, 262144) + 8192 - 1) // 8192, 1)
                single_leaf: pl.Scalar[pl.INDEX] = pl.cast(max_leaves == 1, pl.INDEX)
                for item in pl.range(worker, query_count * max_leaves, 24):
                    query: pl.Scalar[pl.INDEX] = item // max_leaves
                    leaf: pl.Scalar[pl.INDEX] = item % max_leaves
                    batch_idx: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(token_request, [query]), pl.INDEX)
                    position: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [query])
                    cache_len: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(kv_seq_lens, [pl.max(batch_idx, 0)]), pl.INDEX) // 4
                    if batch_idx < 0:
                        cache_len: pl.Scalar[pl.INDEX] = 0
                    cache_bound: pl.Scalar[pl.INDEX] = pl.min(cache_len, (position + 1) // 4)
                    visible_count: pl.Scalar[pl.INDEX] = pl.max(pl.min(cache_bound, 262144), 0)
                    logical_begin: pl.Scalar[pl.INDEX] = leaf * 8192
                    if logical_begin < visible_count:
                        valid_count: pl.Scalar[pl.INDEX] = pl.min(8192, visible_count - logical_begin)
                        lane_span: pl.Scalar[pl.INDEX] = pl.min((valid_count + 384 - 1) // 384 * 192, 4096)
                        lane_stride: pl.Scalar[pl.INDEX] = single_leaf * 192 + (1 - single_leaf) * lane_span
                        query_head_begin: pl.Scalar[pl.INDEX] = query * 64
                        query_vector: pl.Tensor[[64, 128], pl.INT8] = pl.tensor.slice(qr_hadamard_i8, [64, 128], [query_head_begin, 0])
                        for _aiv_coeff in pl.split_aiv(2, mode=pl.SplitMode.NONE):
                            query_scale: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.reshape(pl.tensor.slice(qr_hadamard_scale_dq, [64, 1], [query_head_begin, 0]), [1, 64])
                            query_weight: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.slice(weights, [1, 64], [query, 0])
                            head_coefficient: pl.Tensor[[64, 1], pl.FP32] = pl.tensor.reshape(pl.tensor.mul(query_scale, query_weight), [64, 1])
                        for score_begin in pl.pipeline(0, lane_span, 192, stage=2):
                            read_begin: pl.Scalar[pl.INDEX] = score_begin * (1 + single_leaf)
                            kv_i8: pl.Tensor[[384, 128], pl.INT8] = pl.tensor.create_l1([384, 128], dtype=pl.INT8, transpose=False)
                            for key_lane in pl.unroll(2):
                                for key_page in pl.range(6):
                                    key_row: pl.Scalar[pl.INDEX] = logical_begin + read_begin + key_lane * lane_stride + key_page * 32
                                    safe_page: pl.Scalar[pl.INDEX] = pl.min(key_row // 32, pl.max((cache_len - 1) // 32, 0))
                                    physical_page: pl.Scalar[pl.INDEX] = pl.max(pl.cast(pl.tensor.read(idx_block_table, [batch_idx, safe_page]), pl.INDEX), 0)
                                    native_byte: pl.Scalar[pl.INDEX] = physical_page * native_page_bytes
                                    if native_byte % 128 == 0:
                                        kv_i8: pl.Tensor[[384, 128], pl.INT8] = pl.tensor.gather_row(kv_i8, idx_kv_cache, [key_lane * 192 + key_page * 32, 0], [native_byte // 128, 0], [32, 128], transpose=False)
                                    else:
                                        kv_i8: pl.Tensor[[384, 128], pl.INT8] = pl.tensor.gather_row(kv_i8, idx_kv_cache_shift64, [key_lane * 192 + key_page * 32, 0], [native_byte // 128, 0], [32, 128], transpose=False)
                            score_i32: pl.Tensor[[64, 384], pl.INT32] = pl.tensor.matmul(query_vector, kv_i8, a_trans=False, b_trans=True, c_matrix_nz=False, out_dtype=pl.INT32)
                            for aiv_id in pl.split_aiv(2, mode=pl.SplitMode.LEFT_RIGHT):
                                lane_begin: pl.Scalar[pl.INDEX] = aiv_id * lane_stride
                                lane_valid_rows: pl.Scalar[pl.INDEX] = pl.max(pl.min(valid_count - read_begin - lane_begin, 192), 0)
                                scale_begin: pl.Scalar[pl.INDEX] = logical_begin + read_begin + lane_begin
                                scale_bytes: pl.Tensor[[1, 384], pl.INT8] = pl.tensor.create([1, 384], dtype=pl.INT8, layout=pl.TensorLayout.ND)
                                for scale_page in pl.range(6):
                                    scale_logical_page: pl.Scalar[pl.INDEX] = pl.min((scale_begin + scale_page * 32) // 32, pl.max((cache_len - 1) // 32, 0))
                                    scale_physical_page: pl.Scalar[pl.INDEX] = pl.max(pl.cast(pl.tensor.read(idx_block_table, [batch_idx, scale_logical_page]), pl.INDEX), 0)
                                    scale_bytes: pl.Tensor[[1, 384], pl.INT8] = pl.tensor.gather_row(scale_bytes, idx_native_kv_cache, [0, scale_page * 32 * 2], [scale_physical_page, 4096], [1, 64], transpose=False)
                                kv_scale: pl.Tensor[[1, 192], pl.FP16] = pl.tensor.reinterpret_view(scale_bytes, dtype=pl.FP16)
                                score_shard: pl.Tensor[[64, 192], pl.INT32] = pl.tensor.aiv_shard(score_i32)
                                score_fp32: pl.Tensor[[64, 192], pl.FP32] = pl.tensor.cast(score_shard, target_type=pl.FP32, mode='none')
                                score_fp32_v1: pl.Tensor[[64, 192], pl.FP32] = pl.tensor.maximum(score_fp32, 0.0)
                                score_fp32_v2: pl.Tensor[[64, 192], pl.FP32] = pl.tensor.row_expand_mul(score_fp32_v1, head_coefficient)
                                score_row: pl.Tensor[[1, 192], pl.FP32] = pl.tensor.reshape(pl.tensor.col_sum(score_fp32_v2), [1, 192])
                                score_row_v1: pl.Tensor[[1, 192], pl.FP32] = pl.tensor.mul(score_row, pl.tensor.cast(kv_scale, target_type=pl.FP32, mode='round'))
                                score_row_id: pl.Scalar[pl.INDEX] = single_leaf * query + (1 - single_leaf) * (worker * 2 + aiv_id)
                                score_col: pl.Scalar[pl.INDEX] = single_leaf * (read_begin + lane_begin) + (1 - single_leaf) * score_begin
                                if lane_valid_rows > 0:
                                    score_valid: pl.Tensor[[1, 192], pl.FP32, pl.TensorView(valid_shape=[1, lane_valid_rows], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.set_validshape(score_row_v1, 1, lane_valid_rows)
                                    score_arena: pl.Tensor[[432, 8192], pl.FP32] = pl.tensor.assemble(score_arena, score_valid, [score_row_id, score_col])
                        if single_leaf == 0:
                            for sort_lane in pl.split_aiv(2, mode=pl.SplitMode.NONE):
                                half_begin: pl.Scalar[pl.INDEX] = logical_begin + sort_lane * lane_span
                                half_valid: pl.Scalar[pl.INDEX] = pl.max(pl.min(valid_count - sort_lane * lane_span, lane_span), 0)
                                half_slot: pl.Scalar[pl.INDEX] = query * 64 + leaf * 2 + sort_lane
                                if half_valid > 0:
                                    self.indexer_topk_half_leaf(score_arena, pair_arena, worker * 2 + sort_lane, half_begin, half_valid, half_slot)
                                else:
                                    empty_pairs: pl.Tile[[1, 1024], pl.FP32, pl.Mem.Vec] = pl.tile.full([1, 1024], dtype=pl.FP32, value=-3.4028234663852886e+38)
                                    pl.tile.store(empty_pairs, [half_slot, 0], pair_arena)
            score_tid: pl.Scalar[pl.TASK_ID] = direct_leaf_tid
        with pl.scope():
            if max_topk_cache_len <= 8192:
                with pl.spmd(48, name_hint="indexer_topk_single_leaf_publish", deps=[score_tid], allow_early_resolve=True):
                    self.indexer_topk_single_leaf_publish(position_ids, kv_seq_lens, token_request, score_arena, topk_scores, topk_idxs)
            else:
                with pl.spmd(48, name_hint="indexer_topk_query_merge", deps=[score_tid], allow_early_resolve=True):
                    self.indexer_topk_query_merge(position_ids, kv_seq_lens, token_request, query_start_loc, pair_arena, topk_scores, topk_idxs)
        return topk_scores, topk_idxs, score_tid
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def indexer_weights_score(self, x: pl.Tensor[[T_DYN, 4096], pl.BF16], weights_proj: pl.Tensor[[4096, 64], pl.BF16], native_indexer_weights: pl.Tensor[[T_DYN, 64], pl.FP16], qr_hadamard_i8: pl.Tensor[[27648, 128], pl.INT8], qr_hadamard_scale_dq: pl.Tensor[[27648, 1], pl.FP32], idx_native_kv_cache: pl.Tensor[[IDX_NATIVE_CACHE_BLOCK_NUM_DYN, INDEXER_PAGE_BYTES_DYN], pl.INT8], idx_block_table: pl.Tensor[[B_DYN, INDEXER_TABLE_COLUMNS_DYN], pl.INT32], topk_scores: pl.Tensor[[T_DYN, 512], pl.FP32], topk_idxs: pl.Tensor[[T_DYN, 512], pl.INT32], position_ids: pl.Tensor[[T_DYN], pl.INT64], kv_seq_lens: pl.Tensor[[B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], cache_write_dep: pl.Scalar[pl.TASK_ID], weights_gate_dep: pl.Scalar[pl.TASK_ID], qh_quant_tid: pl.Scalar[pl.TASK_ID], weights_workers: pl.Scalar[pl.INDEX], host_max_seq_len: pl.Scalar[pl.INT32]) -> tuple[pl.Tensor[[T_DYN, 512], pl.FP32], pl.Tensor[[T_DYN, 512], pl.INT32], pl.Scalar[pl.TASK_ID]]:
        # Native weight publication and the score/top-k forest over an already-quantized query.
        _tuple_tmp: pl.Tuple[pl.Tensor[[432, 64], pl.FP32], pl.Scalar[pl.TASK_ID]] = self.indexer_native_weights(native_indexer_weights, weights_gate_dep)
        weights: pl.Tensor[[432, 64], pl.FP32] = _tuple_tmp[0]
        weights_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp[1]
        _tuple_tmp_1: pl.Tuple[pl.Tensor[[T_DYN, 512], pl.FP32], pl.Tensor[[T_DYN, 512], pl.INT32], pl.Scalar[pl.TASK_ID]] = self.indexer_score_topk_forest(qr_hadamard_i8, qr_hadamard_scale_dq, weights, idx_native_kv_cache, idx_block_table, position_ids, kv_seq_lens, token_request, query_start_loc, topk_scores, topk_idxs, qh_quant_tid, weights_tid, cache_write_dep, host_max_seq_len)
        topk_scores: pl.Tensor[[T_DYN, 512], pl.FP32] = _tuple_tmp_1[0]
        topk_idxs: pl.Tensor[[T_DYN, 512], pl.INT32] = _tuple_tmp_1[1]
        leaf_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp_1[2]
        return topk_scores, topk_idxs, leaf_tid
    @pl.function(type=pl.FunctionType.Inline)
    def indexer(self, x: pl.Tensor[[T_DYN, 4096], pl.BF16], qr: pl.Tensor[[T_DYN, 1024], pl.INT8], qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32], wq_b: pl.Tensor[[1024, 8192], pl.INT8], wq_b_scale: pl.Tensor[[8192], pl.FP32], weights_proj: pl.Tensor[[4096, 64], pl.BF16], native_indexer_weights: pl.Tensor[[T_DYN, 64], pl.FP16], cos: pl.Tensor[[T_DYN, 64], pl.FP32], sin: pl.Tensor[[T_DYN, 64], pl.FP32], hadamard: pl.Tensor[[128, 128], pl.BF16], idx_native_kv_cache: pl.Tensor[[IDX_NATIVE_CACHE_BLOCK_NUM_DYN, INDEXER_PAGE_BYTES_DYN], pl.INT8], idx_block_table: pl.Tensor[[B_DYN, INDEXER_TABLE_COLUMNS_DYN], pl.INT32], topk_scores: pl.Tensor[[T_DYN, 512], pl.FP32], topk_idxs: pl.Tensor[[T_DYN, 512], pl.INT32], position_ids: pl.Tensor[[T_DYN], pl.INT64], kv_seq_lens: pl.Tensor[[B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], late_dep: pl.Scalar[pl.TASK_ID], cache_write_dep: pl.Scalar[pl.TASK_ID], host_max_seq_len: pl.Scalar[pl.INT32]) -> tuple[pl.Tensor[[T_DYN, 512], pl.FP32], pl.Tensor[[T_DYN, 512], pl.INT32]]:
        qr_hadamard_i8: pl.Tensor[[27648, 128], pl.INT8] = pl.tensor.create([27648, 128], dtype=pl.INT8, layout=pl.TensorLayout.ND)
        qr_hadamard_scale_dq: pl.Tensor[[27648, 1], pl.FP32] = pl.tensor.create([27648, 1], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        _tuple_tmp: pl.Tuple[pl.Scalar[pl.TASK_ID], pl.Scalar[pl.TASK_ID], pl.Scalar[pl.TASK_ID]] = self.indexer_qr_hadamard(x, qr, qr_scale, wq_b, wq_b_scale, cos, sin, hadamard, qr_hadamard_i8, qr_hadamard_scale_dq)
        _qh_mm_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp[0]
        qh_quant_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp[1]
        _idx_qr_mm_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp[2]
        weights_gate_dep: pl.Scalar[pl.TASK_ID] = pl.system.task_dummy(deps=[])
        _tuple_tmp_1: pl.Tuple[pl.Tensor[[T_DYN, 512], pl.FP32], pl.Tensor[[T_DYN, 512], pl.INT32], pl.Scalar[pl.TASK_ID]] = self.indexer_weights_score(x, weights_proj, native_indexer_weights, qr_hadamard_i8, qr_hadamard_scale_dq, idx_native_kv_cache, idx_block_table, topk_scores, topk_idxs, position_ids, kv_seq_lens, token_request, query_start_loc, cache_write_dep, weights_gate_dep, qh_quant_tid, 8, host_max_seq_len)
        topk_scores: pl.Tensor[[T_DYN, 512], pl.FP32] = _tuple_tmp_1[0]
        topk_idxs: pl.Tensor[[T_DYN, 512], pl.INT32] = _tuple_tmp_1[1]
        _leaf_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp_1[2]
        return topk_scores, topk_idxs
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def indexer_compressor_pool_projected(self, kv_proj_pad: pl.Tensor[[384, 256], pl.FP32], score_proj_pad: pl.Tensor[[384, 256], pl.FP32], compress_state: pl.Tensor[[INNER_STATE_BLOCK_NUM_DYN, INNER_STATE_PAGE_ELEMENTS_DYN], pl.FP32], state_table: pl.Tensor[[B_DYN, INNER_STATE_TABLE_COLUMNS_DYN], pl.INT32], ape: pl.Tensor[[4, 256], pl.FP32], norm_w: pl.Tensor[[128], pl.BF16], cos: pl.Tensor[[INDEXER_ROWS_DYN, 64], pl.FP32], sin: pl.Tensor[[INDEXER_ROWS_DYN, 64], pl.FP32], compact_offsets: pl.Tensor[[DECODE_IDX_C4_B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], position_ids: pl.Tensor[[T_DYN], pl.INT64], query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], inner_state_slot_mapping: pl.Tensor[[T_DYN, 2], pl.INT32], pooled_kv: pl.Tensor[[384, 128], pl.FP32], normed_kv: pl.Tensor[[384, 128], pl.BF16], late_dep: pl.Scalar[pl.TASK_ID], chain_dep: pl.Scalar[pl.TASK_ID]):
        # Pool projected rows, commit state, and normalize boundary KV rows.
        b_dim: pl.Scalar[pl.INDEX] = pl.tensor.dim(state_table, 0)
        bs: pl.Scalar[pl.INDEX] = pl.tensor.dim(position_ids, 0)
        rms_blocks: pl.Scalar[pl.INDEX] = (bs + 16 - 1) // 16
        _kv_score_tid: pl.Scalar[pl.TASK_ID] = late_dep
        window_values: pl.Tensor[[384, 128], pl.FP32] = pl.tensor.create([384, 128], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        window_scores: pl.Tensor[[384, 128], pl.FP32] = pl.tensor.create([384, 128], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        pool_workers: pl.Scalar[pl.INDEX] = pl.min(b_dim, 48)
        with pl.spmd(pool_workers, name_hint="scatter_softmax_pool_spmd", deps=[_kv_score_tid]) as pool_tid:
            pool_worker: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
            for c_idx in pl.range(pool_worker, b_dim, pool_workers):
                request_begin: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [c_idx]), pl.INDEX)
                request_end: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [c_idx + 1]), pl.INDEX)
                first_pos_b: pl.Scalar[pl.INDEX] = pl.cast(0, pl.INDEX)
                if request_begin < request_end:
                    first_pos_b: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(position_ids, [request_begin]), pl.INDEX)
                request_begin_v1: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [c_idx]), pl.INDEX)
                request_end_v1: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [c_idx + 1]), pl.INDEX)
                for token in pl.range(request_begin_v1, request_end_v1):
                    token_pos: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [token])
                    pooled_kv: pl.Tensor[[384, 128], pl.FP32] = pl.tensor.assemble(pooled_kv, pl.tensor.full([1, 128], dtype=pl.FP32, value=0.0), [token, 0])
                    if pl.cast(pl.tensor.read(token_request, [token]), pl.INDEX) >= 0 and (token_pos + 1) % 4 == 0:
                        window_start: pl.Scalar[pl.INT64] = token_pos - 8 + 1
                        for h0 in pl.range(0, 128, 64):
                            window_row: pl.Scalar[pl.INDEX] = pool_worker * 8
                            for state_idx in pl.range(8):
                                logical_pos: pl.Scalar[pl.INT64] = window_start + state_idx
                                value: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.full([1, 64], dtype=pl.FP32, value=0.0)
                                score: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.full([1, 64], dtype=pl.FP32, value=-3.4028234663852886e+38)
                                state_half: pl.Scalar[pl.INDEX] = 0
                                if state_idx >= 4:
                                    state_half: pl.Scalar[pl.INDEX] = 128
                                if logical_pos >= 0 and logical_pos < first_pos_b:
                                    score: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.full([1, 64], dtype=pl.FP32, value=0.0)
                                    history_page: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(state_table, [c_idx, logical_pos // 2]), pl.INDEX)
                                    if history_page >= 0:
                                        history_column: pl.Scalar[pl.INDEX] = pl.cast(logical_pos % 2, pl.INDEX) * 512 + state_half + h0
                                        value: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.slice(compress_state, [1, 64], [history_page, history_column])
                                        score: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.slice(compress_state, [1, 64], [history_page, history_column + 256])
                                if logical_pos >= first_pos_b:
                                    if logical_pos <= token_pos:
                                        overlay_token: pl.Scalar[pl.INDEX] = request_begin_v1 + logical_pos - first_pos_b
                                        ape_row: pl.Scalar[pl.INDEX] = pl.cast(logical_pos % 4, pl.INDEX)
                                        value: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.slice(kv_proj_pad, [1, 64], [overlay_token, state_half + h0])
                                        score: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.add(pl.tensor.slice(score_proj_pad, [1, 64], [overlay_token, state_half + h0]), pl.tensor.slice(ape, [1, 64], [ape_row, state_half + h0]))
                                native_row: pl.Scalar[pl.INDEX] = state_idx % 4 * 2 + state_idx // 4
                                dst_row: pl.Scalar[pl.INDEX] = window_row + native_row
                                window_values: pl.Tensor[[384, 128], pl.FP32] = pl.tensor.assemble(window_values, value, [dst_row, h0])
                                window_scores: pl.Tensor[[384, 128], pl.FP32] = pl.tensor.assemble(window_scores, score, [dst_row, h0])
                            score_rows: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.slice(window_scores, [8, 64], [window_row, h0])
                            max4: pl.Tensor[[4, 64], pl.FP32] = pl.tensor.maximum(pl.tensor.slice(score_rows, [4, 64], [0, 0]), pl.tensor.slice(score_rows, [4, 64], [4, 0]))
                            max2: pl.Tensor[[2, 64], pl.FP32] = pl.tensor.maximum(pl.tensor.slice(max4, [2, 64], [0, 0]), pl.tensor.slice(max4, [2, 64], [2, 0]))
                            maximum: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.maximum(pl.tensor.slice(max2, [1, 64], [0, 0]), pl.tensor.slice(max2, [1, 64], [1, 0]))
                            probability: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.exp(pl.tensor.col_expand_sub(score_rows, maximum))
                            sum4: pl.Tensor[[4, 64], pl.FP32] = pl.tensor.add(pl.tensor.slice(probability, [4, 64], [0, 0]), pl.tensor.slice(probability, [4, 64], [4, 0]))
                            sum2: pl.Tensor[[2, 64], pl.FP32] = pl.tensor.add(pl.tensor.slice(sum4, [2, 64], [0, 0]), pl.tensor.slice(sum4, [2, 64], [2, 0]))
                            total: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.add(pl.tensor.slice(sum2, [1, 64], [0, 0]), pl.tensor.slice(sum2, [1, 64], [1, 0]))
                            probability_v1: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.col_expand_div(probability, total)
                            value_rows: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.slice(window_values, [8, 64], [window_row, h0])
                            weighted: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.mul(value_rows, probability_v1)
                            weighted4: pl.Tensor[[4, 64], pl.FP32] = pl.tensor.add(pl.tensor.slice(weighted, [4, 64], [0, 0]), pl.tensor.slice(weighted, [4, 64], [4, 0]))
                            weighted2: pl.Tensor[[2, 64], pl.FP32] = pl.tensor.add(pl.tensor.slice(weighted4, [2, 64], [0, 0]), pl.tensor.slice(weighted4, [2, 64], [2, 0]))
                            pooled_kv: pl.Tensor[[384, 128], pl.FP32] = pl.tensor.assemble(pooled_kv, pl.tensor.add(pl.tensor.slice(weighted2, [1, 64], [0, 0]), pl.tensor.slice(weighted2, [1, 64], [1, 0])), [token, h0])
        commit_workers: pl.Scalar[pl.INDEX] = pl.min(b_dim, 48)
        for commit_worker in pl.spmd(commit_workers, name_hint="compress_state_commit_spmd", deps=[pool_tid]):
            for c_idx_1 in pl.range(commit_worker, b_dim, commit_workers):
                request_begin: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [c_idx_1]), pl.INDEX)
                request_end: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [c_idx_1 + 1]), pl.INDEX)
                for token_1 in pl.range(request_begin, request_end):
                    state_page: pl.Scalar[pl.INT32] = pl.tensor.read(inner_state_slot_mapping, [token_1, 0])
                    state_offset: pl.Scalar[pl.INT32] = pl.tensor.read(inner_state_slot_mapping, [token_1, 1])
                    if pl.cast(state_page, pl.INDEX) >= 0 and pl.cast(state_offset, pl.INDEX) >= 0:
                        token_pos: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [token_1])
                        native_page: pl.Scalar[pl.INDEX] = pl.cast(state_page, pl.INDEX)
                        native_column: pl.Scalar[pl.INDEX] = pl.cast(state_offset, pl.INDEX) * 512
                        ape_row: pl.Scalar[pl.INDEX] = pl.cast(token_pos % 4, pl.INDEX)
                        compress_state: pl.Tensor[[INNER_STATE_BLOCK_NUM_DYN, INNER_STATE_PAGE_ELEMENTS_DYN], pl.FP32] = pl.tensor.assemble(compress_state, pl.tensor.slice(kv_proj_pad, [1, 256], [token_1, 0]), [native_page, native_column])
                        compress_state: pl.Tensor[[INNER_STATE_BLOCK_NUM_DYN, INNER_STATE_PAGE_ELEMENTS_DYN], pl.FP32] = pl.tensor.assemble(compress_state, pl.tensor.add(pl.tensor.slice(score_proj_pad, [1, 256], [token_1, 0]), pl.tensor.slice(ape, [1, 256], [ape_row, 0])), [native_page, native_column + 256])
        norm_w_2d: pl.Tensor[[1, 128], pl.BF16] = pl.tensor.reshape(norm_w, [1, 128])
        with pl.spmd(b_dim, name_hint="indexer_boundary_init_spmd", deps=[pool_tid]) as boundary_init_tid:
            init_request: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
            compact_begin: pl.Scalar[pl.INDEX] = init_request * 2
            normed_kv: pl.Tensor[[384, 128], pl.BF16] = pl.tensor.assemble(normed_kv, pl.tensor.full([2, 128], dtype=pl.BF16, value=0.0), [compact_begin, 0])
        rms_workers: pl.Scalar[pl.INDEX] = pl.min(rms_blocks, 2)
        with pl.spmd(rms_workers, name_hint="rmsnorm_rope_spmd", deps=[pool_tid, boundary_init_tid]) as rms_tid:
            rms_worker: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
            rope_ones: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.full([16, 64], dtype=pl.FP32, value=1.0)
            rope_index: pl.Tensor[[1, 64], pl.INT32] = pl.tensor.ci(pl.const(0, pl.INT32), [1, 64], dtype=pl.INT32, descending=False)
            rope_index_f: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.cast(rope_index, target_type=pl.FP32, mode='round')
            rope_col: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.col_expand_mul(rope_ones, rope_index_f)
            rope_dup_f: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.cast(pl.tensor.cast(pl.tensor.muls(rope_col, 0.5), target_type=pl.INT32, mode='trunc'), target_type=pl.FP32, mode='round')
            rope_lane: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.sub(rope_col, pl.tensor.muls(rope_dup_f, 2.0))
            rope_swap_idx: pl.Tensor[[16, 64], pl.INT32] = pl.tensor.cast(pl.tensor.sub(pl.tensor.adds(rope_col, 1.0), pl.tensor.muls(rope_lane, 2.0)), target_type=pl.INT32, mode='round')
            for rms_blk in pl.range(rms_worker, rms_blocks, rms_workers):
                b0: pl.Scalar[pl.INDEX] = rms_blk * 16
                rms_blk_rows: pl.Scalar[pl.INDEX] = pl.min(16, bs - b0)
                _tuple_tmp: pl.Tuple[pl.Tensor[[16, 64], pl.FP32], pl.Tensor[[16, 64], pl.FP32]] = self.load_compact_rope_rows(cos, sin, token_request, position_ids, compact_offsets, b0, rms_blk_rows)
                cos_b: pl.Tensor[[16, 64], pl.FP32] = _tuple_tmp[0]
                sin_b: pl.Tensor[[16, 64], pl.FP32] = _tuple_tmp[1]
                kv_rms_low: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.slice(pooled_kv, [16, 64], [b0, 0])
                kv_rms_high: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.slice(pooled_kv, [16, 64], [b0, 64])
                folded_sq: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.add(pl.tensor.mul(kv_rms_low, kv_rms_low), pl.tensor.mul(kv_rms_high, kv_rms_high))
                square_sum: pl.Tensor[[16, 1], pl.FP32] = pl.tensor.row_sum(folded_sq)
                variance: pl.Tensor[[16, 1], pl.FP32] = pl.tensor.adds(pl.tensor.muls(square_sum, 0.0078125), 9.9999999999999995e-07)
                rms: pl.Tensor[[16, 1], pl.FP32] = pl.tensor.sqrt(variance)
                kv_norm_chunk: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.slice(pooled_kv, [16, 64], [b0, 0])
                gamma: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.cast(pl.tensor.slice(norm_w_2d, [1, 64], [0, 0]), target_type=pl.FP32, mode='round')
                normed_chunk: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.col_expand_mul(pl.tensor.row_expand_div(kv_norm_chunk, rms), gamma)
                normed_nope: pl.Tensor[[16, 64], pl.BF16] = pl.tensor.cast(normed_chunk, target_type=pl.BF16, mode='rint')
                kv_rope_norm: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.slice(pooled_kv, [16, 64], [b0, 64])
                gamma_rope: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.cast(pl.tensor.slice(norm_w_2d, [1, 64], [0, 64]), target_type=pl.FP32, mode='round')
                rope_normed: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.col_expand_mul(pl.tensor.row_expand_div(kv_rope_norm, rms), gamma_rope)
                swapped: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.gather(rope_normed, rope_swap_idx, dim=-1)
                sin_signed: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.mul(sin_b, pl.tensor.subs(pl.tensor.muls(rope_lane, 2.0), 1.0))
                rope_rot: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.add(pl.tensor.mul(rope_normed, cos_b), pl.tensor.mul(swapped, sin_signed))
                normed_rope: pl.Tensor[[16, 64], pl.BF16] = pl.tensor.cast(rope_rot, target_type=pl.BF16, mode='rint')
                for inner in pl.range(rms_blk_rows):
                    token_1: pl.Scalar[pl.INDEX] = b0 + inner
                    token_pos: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [token_1])
                    if pl.cast(pl.tensor.read(token_request, [token_1]), pl.INDEX) >= 0 and (token_pos + 1) % 4 == 0:
                        request: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(token_request, [token_1]), pl.INDEX)
                        request_begin: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [request]), pl.INDEX)
                        first_pos: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [request_begin])
                        first_boundary: pl.Scalar[pl.INDEX] = 3 - first_pos % 4
                        compact_token: pl.Scalar[pl.INDEX] = request * 2 + (token_1 - request_begin - first_boundary) // 4
                        normed_kv: pl.Tensor[[384, 128], pl.BF16] = pl.tensor.assemble(normed_kv, pl.tensor.slice(normed_nope, [1, 64], [inner, 0]), [compact_token, 0])
                        normed_kv: pl.Tensor[[384, 128], pl.BF16] = pl.tensor.assemble(normed_kv, pl.tensor.slice(normed_rope, [1, 64], [inner, 0]), [compact_token, 64])
        return _kv_score_tid, rms_tid
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def indexer_compressor_project(self, x: pl.Tensor[[T_DYN, 4096], pl.BF16], wkv: pl.Tensor[[256, 4096], pl.BF16], wgate: pl.Tensor[[256, 4096], pl.BF16], kv_proj_pad: pl.Tensor[[384, 256], pl.FP32], score_proj_pad: pl.Tensor[[384, 256], pl.FP32], query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], late_dep: pl.Scalar[pl.TASK_ID], chain_dep: pl.Scalar[pl.TASK_ID]):
        # Project token-local compressor values and scores in FP32.
        bs: pl.Scalar[pl.INDEX] = pl.tensor.dim(x, 0)
        t_matmul: pl.Scalar[pl.INDEX] = (bs + 16 - 1) // 16 * 16
        x_flat: pl.Tensor[[T_DYN, 4096], pl.BF16] = x
        with pl.spmd(24, name_hint="kv_score_proj_spmd", deps=[late_dep, chain_dep]) as _kv_score_tid:
            kv_worker: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
            native_column_group: pl.Scalar[pl.INDEX] = self.native_compressor_column_group(query_start_loc, bs, 128)
            for idx in pl.range(kv_worker, t_matmul * 256 // 256, 24):
                global_row0: pl.Scalar[pl.INDEX] = idx // 16 * 16
                o0: pl.Scalar[pl.INDEX] = idx % 16 * 16
                kv_acc: pl.Tensor[[16, 16], pl.FP32] = pl.tensor.create([16, 16], dtype=pl.FP32, layout=pl.TensorLayout.ND)
                score_acc: pl.Tensor[[16, 16], pl.FP32] = pl.tensor.create([16, 16], dtype=pl.FP32, layout=pl.TensorLayout.ND)
                for kb in pl.pipeline(16, stage=2):
                    k0: pl.Scalar[pl.INDEX] = (kb + o0 % 128 // native_column_group) * 256 % 4096
                    x_rows: pl.Scalar[pl.INDEX] = pl.min(16, bs - global_row0)
                    x_tile: pl.Tensor[[16, 256], pl.BF16, pl.TensorView(valid_shape=[x_rows, 256], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.slice(x_flat, [16, 256], [global_row0, k0], [x_rows, 256])
                    wkv_tile: pl.Tensor[[16, 256], pl.BF16] = pl.tensor.slice(wkv, [16, 256], [o0, k0])
                    wgate_tile: pl.Tensor[[16, 256], pl.BF16] = pl.tensor.slice(wgate, [16, 256], [o0, k0])
                    kv_acc: pl.Tensor[[16, 16], pl.FP32] = pl.tensor.matmul_acc(kv_acc, x_tile, wkv_tile, init_cond=kb == 0, a_trans=False, b_trans=True)
                    score_acc: pl.Tensor[[16, 16], pl.FP32] = pl.tensor.matmul_acc(score_acc, x_tile, wgate_tile, init_cond=kb == 0, a_trans=False, b_trans=True)
                kv_proj_pad: pl.Tensor[[384, 256], pl.FP32] = pl.tensor.assemble(kv_proj_pad, kv_acc, [global_row0, o0])
                score_proj_pad: pl.Tensor[[384, 256], pl.FP32] = pl.tensor.assemble(score_proj_pad, score_acc, [global_row0, o0])
        return _kv_score_tid
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def indexer_compressor_pool(self, x: pl.Tensor[[T_DYN, 4096], pl.BF16], compress_state: pl.Tensor[[INNER_STATE_BLOCK_NUM_DYN, INNER_STATE_PAGE_ELEMENTS_DYN], pl.FP32], state_table: pl.Tensor[[B_DYN, INNER_STATE_TABLE_COLUMNS_DYN], pl.INT32], wkv: pl.Tensor[[256, 4096], pl.BF16], wgate: pl.Tensor[[256, 4096], pl.BF16], ape: pl.Tensor[[4, 256], pl.FP32], norm_w: pl.Tensor[[128], pl.BF16], cos: pl.Tensor[[INDEXER_ROWS_DYN, 64], pl.FP32], sin: pl.Tensor[[INDEXER_ROWS_DYN, 64], pl.FP32], compact_offsets: pl.Tensor[[DECODE_IDX_C4_B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], position_ids: pl.Tensor[[T_DYN], pl.INT64], query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], inner_state_slot_mapping: pl.Tensor[[T_DYN, 2], pl.INT32], normed_kv: pl.Tensor[[384, 128], pl.BF16], late_dep: pl.Scalar[pl.TASK_ID], chain_dep: pl.Scalar[pl.TASK_ID]):
        # Project, then pool and commit the token stream.
        kv_proj_pad: pl.Tensor[[384, 256], pl.FP32] = pl.tensor.create([384, 256], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        score_proj_pad: pl.Tensor[[384, 256], pl.FP32] = pl.tensor.create([384, 256], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        pooled_kv: pl.Tensor[[384, 128], pl.FP32] = pl.tensor.create([384, 128], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        projection_tid: pl.Scalar[pl.TASK_ID] = self.indexer_compressor_project(x, wkv, wgate, kv_proj_pad, score_proj_pad, query_start_loc, late_dep, chain_dep)
        _tuple_tmp: pl.Tuple[pl.Scalar[pl.TASK_ID], pl.Scalar[pl.TASK_ID]] = self.indexer_compressor_pool_projected(kv_proj_pad, score_proj_pad, compress_state, state_table, ape, norm_w, cos, sin, compact_offsets, token_request, position_ids, query_start_loc, inner_state_slot_mapping, pooled_kv, normed_kv, projection_tid, chain_dep)
        projection_ready_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp[0]
        rms_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp[1]
        return projection_ready_tid, rms_tid
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def indexer_compressor_write(self, kv: pl.Tensor[[T_DYN, 128], pl.FP32], normed_kv: pl.Tensor[[384, 128], pl.BF16], hadamard: pl.Tensor[[128, 128], pl.BF16], idx_native_kv_cache: pl.Tensor[[IDX_NATIVE_CACHE_BLOCK_NUM_DYN, INDEXER_PAGE_BYTES_DYN], pl.INT8], idx_slot_mapping: pl.Tensor[[INDEXER_ROWS_DYN, 2], pl.INT32], compact_offsets: pl.Tensor[[DECODE_IDX_C4_B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], position_ids: pl.Tensor[[T_DYN], pl.INT64], seq_lens: pl.Tensor[[B_DYN], pl.INT32], query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], rms_tid: pl.Scalar[pl.TASK_ID], hadamard_dep: pl.Scalar[pl.TASK_ID]):
        # Rotate compact boundary rows and write their quantized indexer KV cache.
        compact_rows: pl.Scalar[pl.INDEX] = pl.tensor.dim(seq_lens, 0) * 2
        rms_blocks: pl.Scalar[pl.INDEX] = (compact_rows + 16 - 1) // 16
        kv_flat: pl.Tensor[[T_DYN, 128], pl.FP32] = kv
        idx_kv_scale_values: pl.Tensor[[384, 1], pl.FP32] = pl.tensor.create([384, 1], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        kv_final: pl.Tensor[[384, 128], pl.FP32] = pl.tensor.create([384, 128], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        with pl.at(level=pl.Level.CORE_GROUP, name_hint="kv_hadamard", deps=[rms_tid, hadamard_dep], allow_early_resolve=True) as hadamard_tid:
            for o0 in pl.range(0, 128, 64):
                hadamard_tile: pl.Tensor[[128, 64], pl.BF16] = pl.tensor.slice(hadamard, [128, 64], [0, o0])
                for had_blk in pl.range(rms_blocks):
                    had_b0: pl.Scalar[pl.INDEX] = had_blk * 16
                    had_rows: pl.Scalar[pl.INDEX] = pl.min(16, compact_rows - had_b0)
                    kv_proj_tile: pl.Tensor[[16, 128], pl.BF16, pl.TensorView(valid_shape=[had_rows, 128], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.slice(normed_kv, [16, 128], [had_b0, 0], [had_rows, 128])
                    kv_hadamard_acc: pl.Tensor[[16, 64], pl.FP32] = pl.tensor.matmul(kv_proj_tile, hadamard_tile, a_trans=False, b_trans=False, c_matrix_nz=False, out_dtype=pl.FP32)
                    kv_final: pl.Tensor[[384, 128], pl.FP32] = pl.tensor.assemble(kv_final, kv_hadamard_acc, [had_b0, o0])
        with pl.spmd(rms_blocks, name_hint="kv_and_cache_write_spmd", deps=[hadamard_tid], allow_early_resolve=True) as _write_tid:
            wr_blk: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
            wr_b0: pl.Scalar[pl.INDEX] = wr_blk * 16
            wr_blk_rows: pl.Scalar[pl.INDEX] = pl.min(16, compact_rows - wr_b0)
            kv_blk_f32: pl.Tensor[[16, 128], pl.FP32] = pl.tensor.cast(pl.tensor.cast(pl.tensor.slice(kv_final, [16, 128], [wr_b0, 0]), target_type=pl.BF16, mode='rint'), target_type=pl.FP32, mode='round')
            kv_blk_f32_v1: pl.Tensor[[16, 128], pl.FP32] = pl.tensor.cast(pl.tensor.cast(pl.tensor.muls(kv_blk_f32, 0.088388347648318447), target_type=pl.BF16, mode='rint'), target_type=pl.FP32, mode='round')
            kv_amax: pl.Tensor[[1, 16], pl.FP32] = pl.tensor.reshape(pl.tensor.row_max(pl.tensor.abs(kv_blk_f32_v1)), [1, 16])
            kv_amax_v1: pl.Tensor[[1, 16], pl.FP32] = pl.tensor.maximum(kv_amax, pl.tensor.full([1, 16], dtype=pl.FP32, value=0.0001))
            kv_scale_q_row: pl.Tensor[[1, 16], pl.FP32] = pl.tensor.div(pl.tensor.full([1, 16], dtype=pl.FP32, value=127.0), kv_amax_v1)
            kv_scale_dq_col: pl.Tensor[[16, 1], pl.FP32] = pl.tensor.reshape(pl.tensor.recip(kv_scale_q_row), [16, 1])
            kv_scale_q_col: pl.Tensor[[16, 1], pl.FP32] = pl.tensor.reshape(kv_scale_q_row, [16, 1])
            idx_kv_scale_values: pl.Tensor[[384, 1], pl.FP32] = pl.tensor.assemble(idx_kv_scale_values, kv_scale_dq_col, [wr_b0, 0])
            kv_scaled: pl.Tensor[[16, 128], pl.FP32] = pl.tensor.row_expand_mul(kv_blk_f32_v1, kv_scale_q_col)
            kv_i32: pl.Tensor[[16, 128], pl.INT32] = pl.tensor.cast(kv_scaled, target_type=pl.INT32, mode='rint')
            kv_half: pl.Tensor[[16, 128], pl.FP16] = pl.tensor.cast(kv_i32, target_type=pl.FP16, mode='round')
            kv_i8_blk: pl.Tensor[[16, 128], pl.INT8] = pl.tensor.cast(kv_half, target_type=pl.INT8, mode='trunc')
            for inner in pl.range(wr_blk_rows):
                compact_token: pl.Scalar[pl.INDEX] = wr_b0 + inner
                request: pl.Scalar[pl.INDEX] = compact_token // 2
                request_begin: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [request]), pl.INDEX)
                request_end: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [request + 1]), pl.INDEX)
                first_pos: pl.Scalar[pl.INDEX] = pl.cast(0, pl.INDEX)
                if request_begin < request_end:
                    first_pos: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(position_ids, [request_begin]), pl.INDEX)
                local_token: pl.Scalar[pl.INDEX] = compact_token % 2 * 4 + 4 - 1 - first_pos % 4
                if pl.cast(pl.tensor.read(seq_lens, [request]), pl.INDEX) > 0 and local_token < request_end - request_begin:
                    token: pl.Scalar[pl.INDEX] = request_begin + local_token
                    token_pos: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [token])
                    metadata_row: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(compact_offsets, [request]), pl.INDEX) + pl.cast((token_pos + 1) // 4, pl.INDEX)
                    idx_rows: pl.Scalar[pl.INDEX] = pl.tensor.dim(idx_slot_mapping, 0)
                    safe_row: pl.Scalar[pl.INDEX] = pl.min(metadata_row, idx_rows - 1)
                    native_page: pl.Scalar[pl.INT32] = pl.tensor.read(idx_slot_mapping, [safe_row, 0])
                    native_offset: pl.Scalar[pl.INT32] = pl.tensor.read(idx_slot_mapping, [safe_row, 1])
                    if metadata_row < idx_rows and pl.cast(native_page, pl.INDEX) >= 0 and pl.cast(native_offset, pl.INDEX) >= 0:
                        kv_flat: pl.Tensor[[T_DYN, 128], pl.FP32] = pl.tensor.assemble(kv_flat, pl.tensor.slice(kv_blk_f32_v1, [1, 128], [inner, 0]), [token, 0])
                        native_cache_page: pl.Scalar[pl.INDEX] = pl.cast(native_page, pl.INDEX)
                        native_key_begin: pl.Scalar[pl.INDEX] = pl.cast(native_offset, pl.INDEX) * 128
                        idx_native_kv_cache: pl.Tensor[[IDX_NATIVE_CACHE_BLOCK_NUM_DYN, INDEXER_PAGE_BYTES_DYN], pl.INT8] = pl.tensor.assemble(idx_native_kv_cache, pl.tensor.slice(kv_i8_blk, [1, 128], [inner, 0]), [native_cache_page, native_key_begin])
        with pl.at(level=pl.Level.CORE_GROUP, name_hint="idx_kv_scale_commit", deps=[_write_tid], allow_early_resolve=True) as scale_commit_tid:
            for compact_token_1 in pl.range(compact_rows):
                request: pl.Scalar[pl.INDEX] = compact_token_1 // 2
                request_begin: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [request]), pl.INDEX)
                request_end: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(query_start_loc, [request + 1]), pl.INDEX)
                first_pos: pl.Scalar[pl.INDEX] = pl.cast(0, pl.INDEX)
                if request_begin < request_end:
                    first_pos: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(position_ids, [request_begin]), pl.INDEX)
                local_token: pl.Scalar[pl.INDEX] = compact_token_1 % 2 * 4 + 4 - 1 - first_pos % 4
                if pl.cast(pl.tensor.read(seq_lens, [request]), pl.INDEX) > 0 and local_token < request_end - request_begin:
                    token_v1: pl.Scalar[pl.INDEX] = request_begin + local_token
                    token_pos_v1: pl.Scalar[pl.INT64] = pl.tensor.read(position_ids, [token_v1])
                    metadata_row_v1: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(compact_offsets, [request]), pl.INDEX) + pl.cast((token_pos_v1 + 1) // 4, pl.INDEX)
                    idx_rows_v1: pl.Scalar[pl.INDEX] = pl.tensor.dim(idx_slot_mapping, 0)
                    safe_row_v1: pl.Scalar[pl.INDEX] = pl.min(metadata_row_v1, idx_rows_v1 - 1)
                    native_page_v1: pl.Scalar[pl.INT32] = pl.tensor.read(idx_slot_mapping, [safe_row_v1, 0])
                    native_offset_v1: pl.Scalar[pl.INT32] = pl.tensor.read(idx_slot_mapping, [safe_row_v1, 1])
                    if metadata_row_v1 < idx_rows_v1 and pl.cast(native_page_v1, pl.INDEX) >= 0 and pl.cast(native_offset_v1, pl.INDEX) >= 0:
                        scale_value: pl.Scalar[pl.FP16] = pl.cast(pl.tensor.read(idx_kv_scale_values, [compact_token_1, 0]), pl.FP16)
                        native_scale_page: pl.Scalar[pl.INDEX] = pl.cast(native_page_v1, pl.INDEX)
                        native_scale_bytes: pl.Tile[[1, 64], pl.INT8] = pl.tile.load(idx_native_kv_cache, [native_scale_page, 4096], [1, 64], [1, 64])
                        native_scale_half: pl.Tile[[1, 32], pl.FP16] = pl.tile.reinterpret_view(native_scale_bytes, dtype=pl.FP16)
                        pl.tile.write(native_scale_half, [0, native_offset_v1], scale_value)
                        native_updated_bytes: pl.Tile[[1, 64], pl.INT8] = pl.tile.reinterpret_view(native_scale_half, dtype=pl.INT8)
                        pl.tile.store(native_updated_bytes, [native_scale_page, 4096], idx_native_kv_cache)
        return hadamard_tid, scale_commit_tid
    @pl.function(type=pl.FunctionType.Inline)
    def indexer_compressor(self, x: pl.Tensor[[T_DYN, 4096], pl.BF16], kv: pl.Tensor[[T_DYN, 128], pl.FP32], compress_state: pl.Tensor[[INNER_STATE_BLOCK_NUM_DYN, INNER_STATE_PAGE_ELEMENTS_DYN], pl.FP32], state_table: pl.Tensor[[B_DYN, INNER_STATE_TABLE_COLUMNS_DYN], pl.INT32], wkv: pl.Tensor[[256, 4096], pl.BF16], wgate: pl.Tensor[[256, 4096], pl.BF16], ape: pl.Tensor[[4, 256], pl.FP32], norm_w: pl.Tensor[[128], pl.BF16], cos: pl.Tensor[[INDEXER_ROWS_DYN, 64], pl.FP32], sin: pl.Tensor[[INDEXER_ROWS_DYN, 64], pl.FP32], compact_offsets: pl.Tensor[[DECODE_IDX_C4_B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], hadamard: pl.Tensor[[128, 128], pl.BF16], idx_native_kv_cache: pl.Tensor[[IDX_NATIVE_CACHE_BLOCK_NUM_DYN, INDEXER_PAGE_BYTES_DYN], pl.INT8], position_ids: pl.Tensor[[T_DYN], pl.INT64], seq_lens: pl.Tensor[[B_DYN], pl.INT32], query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], idx_slot_mapping: pl.Tensor[[INDEXER_ROWS_DYN, 2], pl.INT32], inner_state_slot_mapping: pl.Tensor[[T_DYN, 2], pl.INT32], late_dep: pl.Scalar[pl.TASK_ID], hadamard_dep: pl.Scalar[pl.TASK_ID]):
        normed_kv: pl.Tensor[[384, 128], pl.BF16] = pl.tensor.create([384, 128], dtype=pl.BF16, layout=pl.TensorLayout.ND)
        _tuple_tmp: pl.Tuple[pl.Scalar[pl.TASK_ID], pl.Scalar[pl.TASK_ID]] = self.indexer_compressor_pool(x, compress_state, state_table, wkv, wgate, ape, norm_w, cos, sin, compact_offsets, token_request, position_ids, query_start_loc, inner_state_slot_mapping, normed_kv, late_dep, late_dep)
        _kv_score_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp[0]
        rms_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp[1]
        _tuple_tmp_1: pl.Tuple[pl.Scalar[pl.TASK_ID], pl.Scalar[pl.TASK_ID]] = self.indexer_compressor_write(kv, normed_kv, hadamard, idx_native_kv_cache, idx_slot_mapping, compact_offsets, token_request, position_ids, seq_lens, query_start_loc, rms_tid, hadamard_dep)
        _hadamard_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp_1[0]
        write_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp_1[1]
        return write_tid
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def publish_native_heads(self, source: pl.Tensor[[3072, 4096], pl.BF16], target: pl.Tensor[[T_DYN, 32768], pl.BF16], tokens: pl.Scalar[pl.INDEX], ready: pl.Scalar[pl.TASK_ID]) -> pl.Tensor[[T_DYN, 32768], pl.BF16]:
        with pl.spmd(48, name_hint="native_heads_spmd", deps=[ready]) as _export_tid:
            worker: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
            for row in pl.range(worker, tokens, 48):
                for group in pl.range(8):
                    for col in pl.range(0, 4096, 128):
                        value: pl.Tile[[1, 128], pl.BF16] = pl.tile.load(source, [group * 384 + row, col], [1, 128], [1, 128])
                        pl.tile.store(value, [row, group * 4096 + col], target)
        return target
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def kv_proj_rope(self, x: pl.Tensor[[T_DYN, 4096], pl.BF16], wkv: pl.Tensor[[4096, 512], pl.BF16], gamma_ckv: pl.Tensor[[512], pl.BF16], rope_cos_il: pl.Tensor[[T_DYN, 64], pl.FP32], rope_sin_signed: pl.Tensor[[T_DYN, 64], pl.FP32], rope_swap_idx: pl.Tensor[[T_DYN, 64], pl.INT32], kv: pl.Tensor[[T_DYN, 512], pl.BF16], late_dep: pl.Scalar[pl.TASK_ID], native_kv_projected: pl.Tensor[[T_DYN, 512], pl.BF16]):
        # 消费 Native BF16 投影，按原顺序执行 TND KV RMSNorm/RoPE。
        t_dim: pl.Scalar[pl.INDEX] = pl.tensor.dim(x, 0)
        for tile_base in pl.range(0, t_dim, 512):
            tile_rows: pl.Scalar[pl.INDEX] = pl.min(512, t_dim - tile_base)
            with pl.scope():
                t_matmul: pl.Scalar[pl.INDEX] = (tile_rows + 16 - 1) // 16 * 16
                kv_fp32: pl.Tensor[[t_matmul, 512], pl.FP32] = pl.tensor.create([t_matmul, 512], dtype=pl.FP32, layout=pl.TensorLayout.ND)
                copy_blocks: pl.Scalar[pl.INDEX] = (tile_rows + 16 - 1) // 16
                with pl.spmd(copy_blocks, name_hint="kv_native_projection_spmd", deps=[late_dep]):
                    with pl.at(level=pl.Level.CORE_GROUP, name_hint="kv_native_projection"):
                        copy_row: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx() * 16
                        copy_rows: pl.Scalar[pl.INDEX] = pl.min(16, tile_rows - copy_row)
                        projected: pl.Tile[[16, 512], pl.BF16, pl.TileView(valid_shape=[copy_rows, 512])] = pl.tile.load(native_kv_projected, [tile_base + copy_row, 0], [16, 512], [copy_rows, 512])
                        pl.tile.store(pl.tile.cast(projected, target_type=pl.FP32, mode='round'), [copy_row, 0], kv_fp32)
                kv_view: pl.Tensor[[t_dim, 512], pl.BF16] = pl.tensor.reshape(kv, [t_dim, 512])
                kv_token_tiles: pl.Scalar[pl.INDEX] = (tile_rows + 32 - 1) // 32
                for tg_idx in pl.spmd(kv_token_tiles, sync_start=True, name_hint="kv_rms_norm_rope_spmd"):
                    tg: pl.Scalar[pl.INDEX] = tg_idx * 32
                    valid_rows: pl.Scalar[pl.INDEX] = pl.min(32, tile_rows - tg)
                    out_tg: pl.Scalar[pl.INDEX] = tile_base + tg
                    if valid_rows == 32:
                        kv_sq_lanes: pl.Tensor[[32, 64], pl.FP32] = pl.tensor.full([32, 64], dtype=pl.FP32, value=0.0)
                        for kv_sq_col0 in pl.pipeline(0, 512, 64, stage=2):
                            kv_chunk: pl.Tensor[[32, 64], pl.FP32] = pl.tensor.slice(kv_fp32, [32, 64], [tg, kv_sq_col0])
                            kv_chunk_v1: pl.Tensor[[32, 64], pl.FP32] = pl.tensor.cast(pl.tensor.cast(kv_chunk, target_type=pl.BF16, mode='rint'), target_type=pl.FP32, mode='round')
                            kv_sq: pl.Tensor[[32, 64], pl.FP32] = pl.tensor.mul(kv_chunk_v1, kv_chunk_v1)
                            kv_sq_lanes: pl.Tensor[[32, 64], pl.FP32] = pl.tensor.add(kv_sq_lanes, kv_sq)
                        kv_sq_sum: pl.Tensor[[1, 32], pl.FP32] = pl.tensor.reshape(pl.tensor.row_sum(kv_sq_lanes), [1, 32])
                        kv_rms: pl.Tensor[[1, 32], pl.FP32] = pl.tensor.sqrt(pl.tensor.adds(pl.tensor.muls(kv_sq_sum, 0.001953125), 9.9999999999999995e-07))
                        kv_inv_rms: pl.Tensor[[1, 32], pl.FP32] = pl.tensor.div(pl.tensor.full([1, 32], dtype=pl.FP32, value=1.0), kv_rms)
                        kv_inv_rms_t: pl.Tensor[[32, 1], pl.FP32] = pl.tensor.reshape(kv_inv_rms, [32, 1])
                        for n0 in pl.pipeline(0, 448, 64, stage=2):
                            kv_chunk: pl.Tensor[[32, 64], pl.FP32] = pl.tensor.slice(kv_fp32, [32, 64], [tg, n0])
                            kv_chunk_v2: pl.Tensor[[32, 64], pl.FP32] = pl.tensor.cast(pl.tensor.cast(kv_chunk, target_type=pl.BF16, mode='rint'), target_type=pl.FP32, mode='round')
                            gamma_kv_cast: pl.Tensor[[64], pl.FP32] = pl.tensor.cast(pl.tensor.slice(gamma_ckv, [64], [n0]), target_type=pl.FP32, mode='round')
                            gamma_kv_chunk: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.reshape(gamma_kv_cast, [1, 64])
                            kv_normed: pl.Tensor[[32, 64], pl.FP32] = pl.tensor.col_expand_mul(pl.tensor.row_expand_mul(kv_chunk_v2, kv_inv_rms_t), gamma_kv_chunk)
                            kv_normed_bf16: pl.Tensor[[32, 64], pl.BF16] = pl.tensor.cast(kv_normed, target_type=pl.BF16, mode='rint')
                            kv_view: pl.Tensor[[t_dim, 512], pl.BF16] = pl.tensor.assemble(kv_view, kv_normed_bf16, [out_tg, n0])
                        gamma_rope_cast: pl.Tensor[[64], pl.FP32] = pl.tensor.cast(pl.tensor.slice(gamma_ckv, [64], [448]), target_type=pl.FP32, mode='round')
                        gamma_rope: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.reshape(gamma_rope_cast, [1, 64])
                        kv_rope_chunk: pl.Tensor[[32, 64], pl.FP32] = pl.tensor.slice(kv_fp32, [32, 64], [tg, 448])
                        kv_rope_chunk_v1: pl.Tensor[[32, 64], pl.FP32] = pl.tensor.cast(pl.tensor.cast(kv_rope_chunk, target_type=pl.BF16, mode='rint'), target_type=pl.FP32, mode='round')
                        kv_rope_norm_chunk: pl.Tensor[[32, 64], pl.FP32] = pl.tensor.col_expand_mul(pl.tensor.row_expand_mul(kv_rope_chunk_v1, kv_inv_rms_t), gamma_rope)
                        kv_rope_norm_chunk_v1: pl.Tensor[[32, 64], pl.FP32] = pl.tensor.cast(pl.tensor.cast(kv_rope_norm_chunk, target_type=pl.BF16, mode='rint'), target_type=pl.FP32, mode='round')
                        kv_cos_il_full: pl.Tensor[[32, 64], pl.FP32] = pl.tensor.slice(rope_cos_il, [32, 64], [out_tg, 0])
                        kv_sin_signed_full: pl.Tensor[[32, 64], pl.FP32] = pl.tensor.slice(rope_sin_signed, [32, 64], [out_tg, 0])
                        kv_swap_idx_full: pl.Tensor[[32, 64], pl.INT32] = pl.tensor.slice(rope_swap_idx, [32, 64], [out_tg, 0])
                        kv_swapped_full: pl.Tensor[[32, 64], pl.FP32] = pl.tensor.gather(kv_rope_norm_chunk_v1, kv_swap_idx_full, dim=-1)
                        kv_rope_rot_full: pl.Tensor[[32, 64], pl.FP32] = pl.tensor.add(pl.tensor.mul(kv_rope_norm_chunk_v1, kv_cos_il_full), pl.tensor.mul(kv_swapped_full, kv_sin_signed_full))
                        kv_rope_i16_full: pl.Tensor[[32, 64], pl.BF16] = pl.tensor.cast(kv_rope_rot_full, target_type=pl.BF16, mode='rint')
                        kv_view: pl.Tensor[[t_dim, 512], pl.BF16] = pl.tensor.assemble(kv_view, kv_rope_i16_full, [out_tg, 448])
                    else:
                        kv_reduce_tmp: pl.Tile[[32, 64], pl.FP32, pl.Mem.Vec] = pl.tile.create([32, 64], dtype=pl.FP32, target_memory=pl.Mem.Vec)
                        kv_sq_lanes_tail: pl.Tile[[32, 64], pl.FP32, pl.Mem.Vec] = pl.tile.full([32, 64], dtype=pl.FP32, value=0.0)
                        for kv_sq_col0_tail in pl.pipeline(0, 512, 64, stage=2):
                            kv_chunk_tail: pl.Tile[[32, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 64])] = pl.tile.load(kv_fp32, [tg, kv_sq_col0_tail], [32, 64], [valid_rows, 64], target_memory=pl.Mem.Vec)
                            kv_chunk_tail_v1: pl.Tile[[32, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 64])] = pl.tile.cast(pl.tile.cast(kv_chunk_tail, target_type=pl.BF16, mode='rint'), target_type=pl.FP32, mode='round')
                            kv_sq_tail: pl.Tile[[32, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 64])] = pl.tile.mul(kv_chunk_tail_v1, kv_chunk_tail_v1)
                            kv_sq_lanes_tail: pl.Tile[[32, 64], pl.FP32, pl.Mem.Vec] = pl.tile.add(kv_sq_lanes_tail, kv_sq_tail)
                        kv_sq_sum_tail: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.reshape(pl.tile.row_sum(kv_sq_lanes_tail, kv_reduce_tmp), [1, 32])
                        kv_rms_tail: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.sqrt(pl.tile.adds(pl.tile.muls(kv_sq_sum_tail, 0.001953125), 9.9999999999999995e-07))
                        kv_inv_rms_tail: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.div(pl.tile.full([1, 32], dtype=pl.FP32, value=1.0), kv_rms_tail)
                        kv_inv_rms_t_tail: pl.Tile[[32, 1], pl.FP32, pl.Mem.Vec] = pl.tile.reshape(kv_inv_rms_tail, [32, 1])
                        for n0_tail in pl.pipeline(0, 448, 64, stage=2):
                            kv_chunk_tail: pl.Tile[[32, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 64])] = pl.tile.load(kv_fp32, [tg, n0_tail], [32, 64], [valid_rows, 64], target_memory=pl.Mem.Vec)
                            kv_chunk_tail_v2: pl.Tile[[32, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 64])] = pl.tile.cast(pl.tile.cast(kv_chunk_tail, target_type=pl.BF16, mode='rint'), target_type=pl.FP32, mode='round')
                            gamma_kv_input_tail: pl.Tile[[64], pl.BF16, pl.Mem.Vec] = pl.tile.load(gamma_ckv, [n0_tail], [64], [64], target_memory=pl.Mem.Vec)
                            gamma_kv_cast_tail: pl.Tile[[64], pl.FP32, pl.Mem.Vec] = pl.tile.cast(gamma_kv_input_tail, target_type=pl.FP32, mode='round')
                            gamma_kv_chunk_tail: pl.Tile[[1, 64], pl.FP32, pl.Mem.Vec] = pl.tile.reshape(gamma_kv_cast_tail, [1, 64])
                            kv_normed_tail: pl.Tile[[32, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 64])] = pl.tile.col_expand_mul(pl.tile.row_expand_mul(kv_chunk_tail_v2, kv_inv_rms_t_tail), gamma_kv_chunk_tail)
                            kv_normed_bf16_tail: pl.Tile[[32, 64], pl.BF16, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 64])] = pl.tile.cast(kv_normed_tail, target_type=pl.BF16, mode='rint')
                            kv_normed_valid: pl.Tile[[32, 64], pl.BF16, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 64])] = pl.tile.set_validshape(kv_normed_bf16_tail, valid_rows, 64)
                            pl.tile.store(kv_normed_valid, [out_tg, n0_tail], kv_view)
                        gamma_rope_input_tail: pl.Tile[[64], pl.BF16, pl.Mem.Vec] = pl.tile.load(gamma_ckv, [448], [64], [64], target_memory=pl.Mem.Vec)
                        gamma_rope_cast_tail: pl.Tile[[64], pl.FP32, pl.Mem.Vec] = pl.tile.cast(gamma_rope_input_tail, target_type=pl.FP32, mode='round')
                        gamma_rope_tail: pl.Tile[[1, 64], pl.FP32, pl.Mem.Vec] = pl.tile.reshape(gamma_rope_cast_tail, [1, 64])
                        kv_rope_chunk_tail: pl.Tile[[32, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 64])] = pl.tile.load(kv_fp32, [tg, 448], [32, 64], [valid_rows, 64], target_memory=pl.Mem.Vec)
                        kv_rope_chunk_tail_v1: pl.Tile[[32, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 64])] = pl.tile.cast(pl.tile.cast(kv_rope_chunk_tail, target_type=pl.BF16, mode='rint'), target_type=pl.FP32, mode='round')
                        kv_rope_norm_tail: pl.Tile[[32, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 64])] = pl.tile.col_expand_mul(pl.tile.row_expand_mul(kv_rope_chunk_tail_v1, kv_inv_rms_t_tail), gamma_rope_tail)
                        kv_rope_norm_tail_v1: pl.Tile[[32, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 64])] = pl.tile.cast(pl.tile.cast(kv_rope_norm_tail, target_type=pl.BF16, mode='rint'), target_type=pl.FP32, mode='round')
                        kv_cos_il_tail: pl.Tile[[32, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 64])] = pl.tile.load(rope_cos_il, [out_tg, 0], [32, 64], [valid_rows, 64], target_memory=pl.Mem.Vec)
                        kv_sin_signed_tail: pl.Tile[[32, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 64])] = pl.tile.load(rope_sin_signed, [out_tg, 0], [32, 64], [valid_rows, 64], target_memory=pl.Mem.Vec)
                        kv_col: pl.Tile[[32, 64], pl.FP32, pl.Mem.Vec] = pl.tile.col_expand_mul(pl.tile.full([32, 64], dtype=pl.FP32, value=1.0), pl.tile.cast(pl.tile.ci(pl.const(0, pl.INT32), [1, 64], dtype=pl.INT32, descending=False), target_type=pl.FP32, mode='round'))
                        kv_dup_f: pl.Tile[[32, 64], pl.FP32, pl.Mem.Vec] = pl.tile.cast(pl.tile.cast(pl.tile.muls(kv_col, 0.5), target_type=pl.INT32, mode='trunc'), target_type=pl.FP32, mode='round')
                        kv_lane: pl.Tile[[32, 64], pl.FP32, pl.Mem.Vec] = pl.tile.sub(kv_col, pl.tile.muls(kv_dup_f, 2.0))
                        kv_swap_f: pl.Tile[[32, 64], pl.FP32, pl.Mem.Vec] = pl.tile.sub(pl.tile.adds(kv_col, 1.0), pl.tile.muls(kv_lane, 2.0))
                        kv_row_seed: pl.Tile[[1, 32], pl.FP32, pl.Mem.Vec] = pl.tile.muls(pl.tile.cast(pl.tile.ci(pl.const(0, pl.INT32), [1, 32], dtype=pl.INT32, descending=False), target_type=pl.FP32, mode='round'), 64.0)
                        kv_row_grid: pl.Tile[[64, 32], pl.FP32, pl.Mem.Vec] = pl.tile.col_expand_mul(pl.tile.full([64, 32], dtype=pl.FP32, value=1.0), kv_row_seed)
                        kv_row_offset: pl.Tile[[32, 64], pl.FP32, pl.Mem.Vec] = pl.tile.transpose(kv_row_grid, 0, 1)
                        kv_swap_idx_tail: pl.Tile[[32, 64], pl.INT32, pl.Mem.Vec] = pl.tile.cast(pl.tile.add(kv_swap_f, kv_row_offset), target_type=pl.INT32, mode='round')
                        kv_gather_tmp: pl.Tile[[32, 64], pl.INT32, pl.Mem.Vec] = pl.tile.create([32, 64], dtype=pl.INT32, target_memory=pl.Mem.Vec)
                        kv_swapped_tail: pl.Tile[[32, 64], pl.FP32, pl.Mem.Vec] = pl.tile.gather(kv_rope_norm_tail_v1, kv_swap_idx_tail, kv_gather_tmp)
                        kv_rope_rot_tail: pl.Tile[[32, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 64])] = pl.tile.add(pl.tile.mul(kv_rope_norm_tail_v1, kv_cos_il_tail), pl.tile.mul(kv_swapped_tail, kv_sin_signed_tail))
                        kv_rope_i16_tail: pl.Tile[[32, 64], pl.BF16, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 64])] = pl.tile.cast(kv_rope_rot_tail, target_type=pl.BF16, mode='rint')
                        kv_rope_valid: pl.Tile[[32, 64], pl.BF16, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 64])] = pl.tile.set_validshape(kv_rope_i16_tail, valid_rows, 64)
                        pl.tile.store(kv_rope_valid, [out_tg, 448], kv_view)
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def _q_proj_q_matmul_nz(self, wq_b: pl.Tensor[[1024, 32768], pl.INT8, pl.TensorView(stride=[], layout=pl.TensorLayout.NZ)], qr_i8_matmul: pl.Tensor[[512, 1024], pl.INT8], q_proj_i32: pl.Tensor[[QKV_QPROJ_MM_T_DYN, 32768], pl.INT32], tile_rows: pl.Scalar[pl.INDEX], qproj_dep: pl.Scalar[pl.TASK_ID]):
        # Use upstream's full-K resident weight and compact tail matmul on Native NZ.
        qproj_t_matmul: pl.Scalar[pl.INDEX] = pl.tensor.dim(q_proj_i32, 0)
        qproj_full_rows: pl.Scalar[pl.INDEX] = tile_rows // 64 * 64
        with pl.spmd(24, name_hint="qproj_matmul_spmd", deps=[qproj_dep]) as qproj_tid:
            pl.set_cache_policy(wq_b, pl.CachePolicy.BYPASS)
            qproj_worker: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
            for qproj_round in pl.range((128 - qproj_worker + 24 - 1) // 24):
                qproj_n_idx: pl.Scalar[pl.INDEX] = qproj_worker + qproj_round * 24
                w_col0: pl.Scalar[pl.INDEX] = qproj_n_idx * 256
                wq_full: pl.Tensor[[1024, 256], pl.INT8, pl.TensorView(stride=[], layout=pl.TensorLayout.NZ)] = pl.tensor.slice(wq_b, [1024, 256], [0, w_col0])
                for t0 in pl.range(0, qproj_full_rows, 64):
                    qr_full: pl.Tensor[[64, 1024], pl.INT8] = pl.tensor.slice(qr_i8_matmul, [64, 1024], [t0, 0])
                    col_acc: pl.Tensor[[64, 256], pl.INT32] = pl.tensor.matmul(qr_full, wq_full, a_trans=False, b_trans=False, c_matrix_nz=False, out_dtype=pl.INT32)
                    q_proj_i32: pl.Tensor[[QKV_QPROJ_MM_T_DYN, 32768], pl.INT32] = pl.tensor.assemble(q_proj_i32, col_acc, [t0, w_col0])
                for tail_t0 in pl.range(qproj_full_rows, qproj_t_matmul, 64):
                    tail_rows: pl.Scalar[pl.INDEX] = pl.min(64, tile_rows - tail_t0)
                    qr_tail: pl.Tensor[[64, 1024], pl.INT8, pl.TensorView(valid_shape=[tail_rows, 1024], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.slice(qr_i8_matmul, [64, 1024], [tail_t0, 0], [tail_rows, 1024])
                    tail_acc: pl.Tensor[[64, 256], pl.INT32] = pl.tensor.matmul(qr_tail, wq_full, a_trans=False, b_trans=False, c_matrix_nz=False, out_dtype=pl.INT32)
                    q_proj_i32: pl.Tensor[[QKV_QPROJ_MM_T_DYN, 32768], pl.INT32] = pl.tensor.assemble(q_proj_i32, tail_acc, [tail_t0, w_col0])
        return q_proj_i32, qproj_tid
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def q_proj_q_dequant(self, wq_b_scale: pl.Tensor[[32768], pl.FP32], rope_cos_il: pl.Tensor[[T_DYN, 64], pl.FP32], rope_sin_signed: pl.Tensor[[T_DYN, 64], pl.FP32], rope_swap_idx: pl.Tensor[[T_DYN, 64], pl.INT32], q: pl.Tensor[[T_DYN, 64, 512], pl.BF16], qr_scale_pad_store: pl.Tensor[[512, 1], pl.FP32], q_proj_i32: pl.Tensor[[QKV_QPROJ_MM_T_DYN, 32768], pl.INT32], tile_base: pl.Scalar[pl.INDEX], tile_rows: pl.Scalar[pl.INDEX]) -> pl.Tensor[[T_DYN, 64, 512], pl.BF16]:
        # Dequantize, normalize, and rotate one projected Q tile.
        t_dim: pl.Scalar[pl.INDEX] = pl.tensor.dim(q, 0)
        q_flat: pl.Tensor[[t_dim, 32768], pl.BF16] = pl.tensor.reshape(q, [t_dim, 32768])
        for dq_worker in pl.spmd(48, name_hint="qproj_dequant_rms_nope_rope_spmd", allow_early_resolve=True):
            dq_head_tile: pl.Scalar[pl.INDEX] = 4
            if tile_rows >= 384 and tile_rows % 384 == 0:
                dq_head_tile: pl.Scalar[pl.INDEX] = 64
            else:
                if tile_rows >= 96 and tile_rows % 96 == 0:
                    dq_head_tile: pl.Scalar[pl.INDEX] = 16
            for dq_work in pl.range(dq_worker, (tile_rows + 8 - 1) // 8 * (64 // dq_head_tile), 48):
                hg: pl.Scalar[pl.INDEX] = dq_work % (64 // dq_head_tile) * dq_head_tile
                tg: pl.Scalar[pl.INDEX] = dq_work // (64 // dq_head_tile) * 8
                out_tg: pl.Scalar[pl.INDEX] = tile_base + tg
                if tg + 8 <= tile_rows:
                    qr_scale_dq_t: pl.Tensor[[8, 1], pl.FP32] = pl.tensor.slice(qr_scale_pad_store, [8, 1], [tg, 0])
                    q_cos_il: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.slice(rope_cos_il, [8, 64], [out_tg, 0])
                    q_sin_signed: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.slice(rope_sin_signed, [8, 64], [out_tg, 0])
                    q_swap_idx: pl.Tensor[[8, 64], pl.INT32] = pl.tensor.slice(rope_swap_idx, [8, 64], [out_tg, 0])
                    for h_inner in pl.pipeline(dq_head_tile, stage=2):
                        h: pl.Scalar[pl.INDEX] = hg + h_inner
                        h0: pl.Scalar[pl.INDEX] = h * 512
                        q_head_acc: pl.Tensor[[8, 512], pl.INT32] = pl.tensor.slice(q_proj_i32, [8, 512], [tg, h0])
                        q_head_scale: pl.Tensor[[1, 512], pl.FP32] = pl.tensor.reshape(pl.tensor.slice(wq_b_scale, [512], [h0]), [1, 512])
                        q_head_acc_fp32: pl.Tensor[[8, 512], pl.FP32] = pl.tensor.cast(q_head_acc, target_type=pl.FP32, mode='none')
                        q_head_scale_combined: pl.Tensor[[8, 512], pl.FP32] = pl.tensor.col_expand_mul(pl.tensor.row_expand_mul(pl.tensor.full([8, 512], dtype=pl.FP32, value=1.0), qr_scale_dq_t), q_head_scale)
                        q_head_dq: pl.Tensor[[8, 512], pl.FP32] = pl.tensor.mul(q_head_acc_fp32, q_head_scale_combined)
                        q_head_dq_v1: pl.Tensor[[8, 512], pl.FP32] = pl.tensor.cast(pl.tensor.cast(q_head_dq, target_type=pl.BF16, mode='rint'), target_type=pl.FP32, mode='round')
                        q_head_sq: pl.Tensor[[8, 512], pl.FP32] = pl.tensor.mul(q_head_dq_v1, q_head_dq_v1)
                        q_sq_04: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.add(pl.tensor.slice(q_head_sq, [8, 64], [0, 0]), pl.tensor.slice(q_head_sq, [8, 64], [0, 256]))
                        q_sq_15: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.add(pl.tensor.slice(q_head_sq, [8, 64], [0, 64]), pl.tensor.slice(q_head_sq, [8, 64], [0, 320]))
                        q_sq_26: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.add(pl.tensor.slice(q_head_sq, [8, 64], [0, 128]), pl.tensor.slice(q_head_sq, [8, 64], [0, 384]))
                        q_sq_37: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.add(pl.tensor.slice(q_head_sq, [8, 64], [0, 192]), pl.tensor.slice(q_head_sq, [8, 64], [0, 448]))
                        q_sq_0246: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.add(q_sq_04, q_sq_26)
                        q_sq_1357: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.add(q_sq_15, q_sq_37)
                        q_sq_64: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.add(q_sq_0246, q_sq_1357)
                        q_head_sq_row: pl.Tensor[[8, 1], pl.FP32] = pl.tensor.row_sum(q_sq_64)
                        q_head_sq_sum: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.reshape(q_head_sq_row, [1, 8])
                        q_head_sq_mean: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.muls(q_head_sq_sum, 0.001953125)
                        q_head_var: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.adds(q_head_sq_mean, 9.9999999999999995e-07)
                        q_head_inv_rms: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.rsqrt(q_head_var, high_precision=True)
                        q_head_inv_rms_t: pl.Tensor[[8, 1], pl.FP32] = pl.tensor.reshape(q_head_inv_rms, [8, 1])
                        q_nope_normed: pl.Tensor[[8, 448], pl.FP32] = pl.tensor.row_expand_mul(pl.tensor.slice(q_head_dq_v1, [8, 448], [0, 0]), q_head_inv_rms_t)
                        q_nope_bf16: pl.Tensor[[8, 448], pl.BF16] = pl.tensor.cast(q_nope_normed, target_type=pl.BF16, mode='rint')
                        q_flat: pl.Tensor[[t_dim, 32768], pl.BF16] = pl.tensor.assemble(q_flat, q_nope_bf16, [out_tg, h0])
                        q_rope_chunk_raw: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.slice(q_head_dq_v1, [8, 64], [0, 448])
                        q_rope_chunk: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.row_expand_mul(q_rope_chunk_raw, q_head_inv_rms_t)
                        q_rope_chunk_v1: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.cast(pl.tensor.cast(q_rope_chunk, target_type=pl.BF16, mode='rint'), target_type=pl.FP32, mode='round')
                        q_rope_swapped: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.gather(q_rope_chunk_v1, q_swap_idx, dim=-1)
                        q_rope_base: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.mul(q_rope_chunk_v1, q_cos_il)
                        q_rope_delta: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.mul(q_rope_swapped, q_sin_signed)
                        q_rope_rot: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.add(q_rope_base, q_rope_delta)
                        q_rope_bf16: pl.Tensor[[8, 64], pl.BF16] = pl.tensor.cast(q_rope_rot, target_type=pl.BF16, mode='rint')
                        q_flat: pl.Tensor[[t_dim, 32768], pl.BF16] = pl.tensor.assemble(q_flat, q_rope_bf16, [out_tg, h0 + 448])
                else:
                    valid_tail_rows: pl.Scalar[pl.INDEX] = tile_rows - tg
                    qr_scale_dq_tail: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.load(qr_scale_pad_store, [tg, 0], [8, 1], [8, 1], target_memory=pl.Mem.Vec)
                    q_cos_il_tail: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_tail_rows, 64])] = pl.tile.load(rope_cos_il, [out_tg, 0], [8, 64], [valid_tail_rows, 64], target_memory=pl.Mem.Vec)
                    q_sin_signed_tail: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_tail_rows, 64])] = pl.tile.load(rope_sin_signed, [out_tg, 0], [8, 64], [valid_tail_rows, 64], target_memory=pl.Mem.Vec)
                    q_col: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.col_expand_mul(pl.tile.full([8, 64], dtype=pl.FP32, value=1.0), pl.tile.cast(pl.tile.ci(pl.const(0, pl.INT32), [1, 64], dtype=pl.INT32, descending=False), target_type=pl.FP32, mode='round'))
                    q_dup_f: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.cast(pl.tile.cast(pl.tile.muls(q_col, 0.5), target_type=pl.INT32, mode='trunc'), target_type=pl.FP32, mode='round')
                    q_lane: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.sub(q_col, pl.tile.muls(q_dup_f, 2.0))
                    q_swap_f: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.sub(pl.tile.adds(q_col, 1.0), pl.tile.muls(q_lane, 2.0))
                    q_row_seed: pl.Tile[[1, 8], pl.FP32, pl.Mem.Vec] = pl.tile.muls(pl.tile.cast(pl.tile.ci(pl.const(0, pl.INT32), [1, 8], dtype=pl.INT32, descending=False), target_type=pl.FP32, mode='round'), 64.0)
                    q_row_grid: pl.Tile[[64, 8], pl.FP32, pl.Mem.Vec] = pl.tile.col_expand_mul(pl.tile.full([64, 8], dtype=pl.FP32, value=1.0), q_row_seed)
                    q_row_offset: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.transpose(q_row_grid, 0, 1)
                    q_swap_idx_tail: pl.Tile[[8, 64], pl.INT32, pl.Mem.Vec] = pl.tile.cast(pl.tile.add(q_swap_f, q_row_offset), target_type=pl.INT32, mode='round')
                    q_head_reduce_tmp: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.create([8, 64], dtype=pl.FP32, target_memory=pl.Mem.Vec)
                    q_rsqrt_tmp: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.create([8, 1], dtype=pl.FP32, target_memory=pl.Mem.Vec)
                    q_gather_tmp: pl.Tile[[8, 64], pl.INT32, pl.Mem.Vec] = pl.tile.create([8, 64], dtype=pl.INT32, target_memory=pl.Mem.Vec)
                    for h_inner_tail in pl.range(dq_head_tile):
                        h_tail: pl.Scalar[pl.INDEX] = hg + h_inner_tail
                        h0_tail: pl.Scalar[pl.INDEX] = h_tail * 512
                        q_head_acc_tail: pl.Tile[[8, 512], pl.INT32, pl.Mem.Vec] = pl.tile.load(q_proj_i32, [tg, h0_tail], [8, 512], [8, 512], target_memory=pl.Mem.Vec)
                        q_head_scale_input_tail: pl.Tile[[512], pl.FP32, pl.Mem.Vec] = pl.tile.load(wq_b_scale, [h0_tail], [512], [512], target_memory=pl.Mem.Vec)
                        q_head_scale_tail: pl.Tile[[1, 512], pl.FP32, pl.Mem.Vec] = pl.tile.reshape(q_head_scale_input_tail, [1, 512])
                        q_head_acc_fp32_tail: pl.Tile[[8, 512], pl.FP32, pl.Mem.Vec] = pl.tile.cast(q_head_acc_tail, target_type=pl.FP32, mode='none')
                        q_head_scale_combined_tail: pl.Tile[[8, 512], pl.FP32, pl.Mem.Vec] = pl.tile.col_expand_mul(pl.tile.row_expand_mul(pl.tile.full([8, 512], dtype=pl.FP32, value=1.0), qr_scale_dq_tail), q_head_scale_tail)
                        q_head_dq_tail: pl.Tile[[8, 512], pl.FP32, pl.Mem.Vec] = pl.tile.mul(q_head_acc_fp32_tail, q_head_scale_combined_tail)
                        q_head_dq_tail_v1: pl.Tile[[8, 512], pl.FP32, pl.Mem.Vec] = pl.tile.cast(pl.tile.cast(q_head_dq_tail, target_type=pl.BF16, mode='rint'), target_type=pl.FP32, mode='round')
                        q_head_sq_tail: pl.Tile[[8, 512], pl.FP32, pl.Mem.Vec] = pl.tile.mul(q_head_dq_tail_v1, q_head_dq_tail_v1)
                        q_sq_04_tail: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.slice(q_head_sq_tail, [8, 64], [0, 0]), pl.tile.slice(q_head_sq_tail, [8, 64], [0, 256]))
                        q_sq_15_tail: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.slice(q_head_sq_tail, [8, 64], [0, 64]), pl.tile.slice(q_head_sq_tail, [8, 64], [0, 320]))
                        q_sq_26_tail: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.slice(q_head_sq_tail, [8, 64], [0, 128]), pl.tile.slice(q_head_sq_tail, [8, 64], [0, 384]))
                        q_sq_37_tail: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.slice(q_head_sq_tail, [8, 64], [0, 192]), pl.tile.slice(q_head_sq_tail, [8, 64], [0, 448]))
                        q_sq_0246_tail: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.add(q_sq_04_tail, q_sq_26_tail)
                        q_sq_1357_tail: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.add(q_sq_15_tail, q_sq_37_tail)
                        q_sq_64_tail: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.add(q_sq_0246_tail, q_sq_1357_tail)
                        q_head_sq_sum_tail: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.row_sum(q_sq_64_tail, q_head_reduce_tmp)
                        q_head_var_tail: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.adds(pl.tile.muls(q_head_sq_sum_tail, 0.001953125), 9.9999999999999995e-07)
                        q_head_inv_rms_tail: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.rsqrt(q_head_var_tail, q_rsqrt_tmp)
                        q_nope_normed_tail: pl.Tile[[8, 448], pl.FP32, pl.Mem.Vec] = pl.tile.row_expand_mul(pl.tile.slice(q_head_dq_tail_v1, [8, 448], [0, 0]), q_head_inv_rms_tail)
                        q_nope_bf16_tail: pl.Tile[[8, 448], pl.BF16, pl.Mem.Vec] = pl.tile.cast(q_nope_normed_tail, target_type=pl.BF16, mode='rint')
                        q_nope_valid: pl.Tile[[8, 448], pl.BF16, pl.Mem.Vec, pl.TileView(valid_shape=[valid_tail_rows, 448])] = pl.tile.set_validshape(q_nope_bf16_tail, valid_tail_rows, 448)
                        pl.tile.store(q_nope_valid, [out_tg, h0_tail], q_flat)
                        q_rope_chunk_raw_tail: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.slice(q_head_dq_tail_v1, [8, 64], [0, 448])
                        q_rope_chunk_tail: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.row_expand_mul(q_rope_chunk_raw_tail, q_head_inv_rms_tail)
                        q_rope_chunk_tail_v1: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.cast(pl.tile.cast(q_rope_chunk_tail, target_type=pl.BF16, mode='rint'), target_type=pl.FP32, mode='round')
                        q_rope_swapped_tail: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.gather(q_rope_chunk_tail_v1, q_swap_idx_tail, q_gather_tmp)
                        q_rope_chunk_tail_v2: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_tail_rows, 64])] = pl.tile.set_validshape(q_rope_chunk_tail_v1, valid_tail_rows, 64)
                        q_rope_swapped_tail_v1: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_tail_rows, 64])] = pl.tile.set_validshape(q_rope_swapped_tail, valid_tail_rows, 64)
                        q_rope_base_tail: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_tail_rows, 64])] = pl.tile.mul(q_rope_chunk_tail_v2, q_cos_il_tail)
                        q_rope_delta_tail: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_tail_rows, 64])] = pl.tile.mul(q_rope_swapped_tail_v1, q_sin_signed_tail)
                        q_rope_rot_tail: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_tail_rows, 64])] = pl.tile.add(q_rope_base_tail, q_rope_delta_tail)
                        q_rope_bf16_tail: pl.Tile[[8, 64], pl.BF16, pl.Mem.Vec, pl.TileView(valid_shape=[valid_tail_rows, 64])] = pl.tile.cast(q_rope_rot_tail, target_type=pl.BF16, mode='rint')
                        q_rope_valid: pl.Tile[[8, 64], pl.BF16, pl.Mem.Vec, pl.TileView(valid_shape=[valid_tail_rows, 64])] = pl.tile.set_validshape(q_rope_bf16_tail, valid_tail_rows, 64)
                        pl.tile.store(q_rope_valid, [out_tg, h0_tail + 448], q_flat)
        return q
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def q_proj_q(self, x: pl.Tensor[[T_DYN, 4096], pl.BF16], wq_b: pl.Tensor[[1024, 32768], pl.INT8, pl.TensorView(stride=[], layout=pl.TensorLayout.NZ)], wq_b_scale: pl.Tensor[[32768], pl.FP32], rope_cos_il: pl.Tensor[[T_DYN, 64], pl.FP32], rope_sin_signed: pl.Tensor[[T_DYN, 64], pl.FP32], rope_swap_idx: pl.Tensor[[T_DYN, 64], pl.INT32], q: pl.Tensor[[T_DYN, 64, 512], pl.BF16], qr_i8_matmul: pl.Tensor[[512, 1024], pl.INT8], qr_scale_pad_store: pl.Tensor[[512, 1], pl.FP32], qproj_dep: pl.Scalar[pl.TASK_ID]) -> pl.Tensor[[T_DYN, 64, 512], pl.BF16]:
        # Q projection and its dequant + RMSNorm + RoPE over bounded tiles.
        t_dim: pl.Scalar[pl.INDEX] = pl.tensor.dim(x, 0)
        for tile_base in pl.range(0, t_dim, 512):
            tile_rows: pl.Scalar[pl.INDEX] = pl.min(512, t_dim - tile_base)
            with pl.scope():
                qproj_t_matmul: pl.Scalar[pl.INDEX] = (tile_rows + 64 - 1) // 64 * 64
                q_proj_i32: pl.Tensor[[qproj_t_matmul, 32768], pl.INT32] = pl.tensor.create([qproj_t_matmul, 32768], dtype=pl.INT32, layout=pl.TensorLayout.ND)
                _tuple_tmp: pl.Tuple[pl.Tensor[[qproj_t_matmul, 32768], pl.INT32], pl.Scalar[pl.TASK_ID]] = self._q_proj_q_matmul_nz(wq_b, qr_i8_matmul, q_proj_i32, tile_rows, qproj_dep)
                q_proj_i32: pl.Tensor[[qproj_t_matmul, 32768], pl.INT32] = _tuple_tmp[0]
                _qproj_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp[1]
                self.q_proj_q_dequant(wq_b_scale, rope_cos_il, rope_sin_signed, rope_swap_idx, q, qr_scale_pad_store, q_proj_i32, tile_base, tile_rows)
        return q
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def q_proj_qa(self, x: pl.Tensor[[T_DYN, 4096], pl.BF16], wq_a: pl.Tensor[[1024, 4096], pl.BF16, pl.TensorView(stride=[], layout=pl.TensorLayout.NZ)], qr_fp32: pl.Tensor[[QKV_QPROJ_MM_T_DYN, 1024], pl.FP32], tile_base: pl.Scalar[pl.INDEX], tile_rows: pl.Scalar[pl.INDEX]) -> pl.Tensor[[QKV_QPROJ_MM_T_DYN, 1024], pl.FP32]:
        # Reference QA matmul, shared by the production QR and its diagnostic.
        qa_tokens: pl.Scalar[pl.INDEX] = pl.tensor.dim(x, 0)
        x_view: pl.Tensor[[qa_tokens, 4096], pl.BF16] = pl.tensor.reshape(x, [qa_tokens, 4096])
        qr_t_matmul: pl.Scalar[pl.INDEX] = (tile_rows + 16 - 1) // 16 * 16
        qr_full_rows: pl.Scalar[pl.INDEX] = tile_rows // 64 * 64
        with pl.at(level=pl.Level.CORE_GROUP, name_hint="qr_proj_seed"):
            for ts0 in pl.range(0, qr_t_matmul, 16):
                for nseed0 in pl.range(0, 1024, 32):
                    qr_seed: pl.Tensor[[16, 32], pl.FP32] = pl.tensor.full([16, 32], dtype=pl.FP32, value=0.0)
                    qr_fp32: pl.Tensor[[QKV_QPROJ_MM_T_DYN, 1024], pl.FP32] = pl.tensor.assemble(qr_fp32, qr_seed, [ts0, nseed0])
        for qbg_idx in pl.spmd(32, name_hint="qr_proj_matmul_spmd", allow_early_resolve=True):
            q_a_col0: pl.Scalar[pl.INDEX] = qbg_idx // 1 * 32
            qr_k_base: pl.Scalar[pl.INDEX] = qbg_idx % 1 * 4096
            qr_native_group: pl.Scalar[pl.INDEX] = q_a_col0 // 96
            for dense_t0 in pl.range(0, qr_full_rows, 64):
                dense_x0: pl.Scalar[pl.INDEX] = tile_base + dense_t0
                dense_acc: pl.Tensor[[64, 32], pl.FP32] = pl.tensor.create([64, 32], dtype=pl.FP32, layout=pl.TensorLayout.ND)
                for dense_k in pl.pipeline(16, stage=2):
                    dense_k_order: pl.Scalar[pl.INDEX] = dense_k
                    if tile_rows >= 96 and tile_rows <= 240 and tile_rows % 48 == 0 and qr_native_group < 9:
                        dense_k_direction: pl.Scalar[pl.INDEX] = dense_k
                        if qr_native_group % 2 == 1:
                            dense_k_direction: pl.Scalar[pl.INDEX] = 15 - dense_k
                        dense_k_order: pl.Scalar[pl.INDEX] = (qr_native_group // 2 * 3 + dense_k_direction) % 16
                    dense_d0: pl.Scalar[pl.INDEX] = qr_k_base + pl.max(dense_k_order, 0) * 256
                    dense_x: pl.Tensor[[64, 256], pl.BF16] = pl.tensor.slice(x_view, [64, 256], [dense_x0, dense_d0])
                    dense_w: pl.Tensor[[32, 256], pl.BF16, pl.TensorView(stride=[], layout=pl.TensorLayout.NZ)] = pl.tensor.slice(wq_a, [32, 256], [q_a_col0, dense_d0])
                    dense_acc: pl.Tensor[[64, 32], pl.FP32] = pl.tensor.matmul_acc(dense_acc, dense_x, dense_w, init_cond=dense_k == 0, a_trans=False, b_trans=True)
                qr_fp32: pl.Tensor[[QKV_QPROJ_MM_T_DYN, 1024], pl.FP32] = pl.tensor.assemble(qr_fp32, dense_acc, [dense_t0, q_a_col0])
            for t0 in pl.range(qr_full_rows, qr_t_matmul, 16):
                q_acc: pl.Tensor[[16, 32], pl.FP32] = pl.tensor.create([16, 32], dtype=pl.FP32, layout=pl.TensorLayout.ND)
                for db in pl.pipeline(16, stage=2):
                    qr_k_order: pl.Scalar[pl.INDEX] = db
                    if tile_rows >= 96 and tile_rows <= 240 and tile_rows % 48 == 0 and qr_native_group < 9:
                        qr_k_direction: pl.Scalar[pl.INDEX] = db
                        if qr_native_group % 2 == 1:
                            qr_k_direction: pl.Scalar[pl.INDEX] = 15 - db
                        qr_k_order: pl.Scalar[pl.INDEX] = (qr_native_group // 2 * 3 + qr_k_direction) % 16
                    qr_d0: pl.Scalar[pl.INDEX] = qr_k_base + pl.max(qr_k_order, 0) * 256
                    qr_rows: pl.Scalar[pl.INDEX] = pl.min(16, tile_rows - t0)
                    x_t0: pl.Scalar[pl.INDEX] = tile_base + t0
                    q_x_chunk_bf16: pl.Tensor[[16, 256], pl.BF16, pl.TensorView(valid_shape=[qr_rows, 256], stride=[], layout=pl.TensorLayout.ND)] = pl.tensor.slice(x_view, [16, 256], [x_t0, qr_d0], [qr_rows, 256])
                    w_chunk: pl.Tensor[[32, 256], pl.BF16, pl.TensorView(stride=[], layout=pl.TensorLayout.NZ)] = pl.tensor.slice(wq_a, [32, 256], [q_a_col0, qr_d0])
                    q_acc: pl.Tensor[[16, 32], pl.FP32] = pl.tensor.matmul_acc(q_acc, q_x_chunk_bf16, w_chunk, init_cond=db == 0, a_trans=False, b_trans=True)
                qr_fp32: pl.Tensor[[QKV_QPROJ_MM_T_DYN, 1024], pl.FP32] = pl.tensor.assemble(qr_fp32, q_acc, [t0, q_a_col0])
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def q_proj_qr_rms(self, qr_fp32: pl.Tensor[[QKV_QPROJ_MM_T_DYN, 1024], pl.FP32], row: pl.Scalar[pl.INDEX]):
        # Native QR reduction and device scalar reciprocal, shared by diagnostics.
        qr_rms_full: pl.Tensor[[8, 1024], pl.FP32] = pl.tensor.cast(pl.tensor.cast(pl.tensor.slice(qr_fp32, [8, 1024], [row, 0]), target_type=pl.BF16, mode='rint'), target_type=pl.FP32, mode='round')
        qr_square_full: pl.Tensor[[8, 1024], pl.FP32] = pl.tensor.mul(qr_rms_full, qr_rms_full)
        qr_square_half: pl.Tensor[[8, 512], pl.FP32] = pl.tensor.add(pl.tensor.slice(qr_square_full, [8, 512], [0, 0]), pl.tensor.slice(qr_square_full, [8, 512], [0, 512]))
        qr_square_quarter: pl.Tensor[[8, 256], pl.FP32] = pl.tensor.add(pl.tensor.slice(qr_square_half, [8, 256], [0, 0]), pl.tensor.slice(qr_square_half, [8, 256], [0, 256]))
        qr_square_eighth: pl.Tensor[[8, 128], pl.FP32] = pl.tensor.add(pl.tensor.slice(qr_square_quarter, [8, 128], [0, 0]), pl.tensor.slice(qr_square_quarter, [8, 128], [0, 128]))
        qr_square_sixteenth: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.add(pl.tensor.slice(qr_square_eighth, [8, 64], [0, 0]), pl.tensor.slice(qr_square_eighth, [8, 64], [0, 64]))
        qr_sq_sum: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.reshape(pl.tensor.row_sum(qr_square_sixteenth), [1, 8])
        qr_variance: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.adds(pl.tensor.muls(qr_sq_sum, 0.0009765625), 9.9999999999999995e-07)
        qr_rms_approx: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.sqrt(qr_variance)
        qr_variance_bits: pl.Tensor[[1, 8], pl.INT32] = pl.tensor.reinterpret_view(qr_variance, dtype=pl.INT32)
        qr_approx_bits: pl.Tensor[[1, 8], pl.INT32] = pl.tensor.reinterpret_view(qr_rms_approx, dtype=pl.INT32)
        qr_rounded_bits: pl.Tensor[[1, 8], pl.INT32] = pl.tensor.full([1, 8], dtype=pl.INT32, value=0)
        for qr_sqrt_row in pl.range(8):
            qr_x_bits: pl.Scalar[pl.INT64] = pl.cast(pl.tensor.read(qr_variance_bits, [0, qr_sqrt_row]), pl.INT64)
            qr_y_bits: pl.Scalar[pl.INT64] = pl.cast(pl.tensor.read(qr_approx_bits, [0, qr_sqrt_row]), pl.INT64)
            if qr_x_bits >= 8388608 and qr_x_bits < 2139095040:
                qr_x_exp: pl.Scalar[pl.INT64] = qr_x_bits // 8388608
                qr_x_sig: pl.Scalar[pl.INT64] = qr_x_bits % 8388608 + 8388608
                for _qr_sqrt_step in pl.range(2):
                    qr_y_exp: pl.Scalar[pl.INT64] = qr_y_bits // 8388608
                    qr_y_sig: pl.Scalar[pl.INT64] = qr_y_bits % 8388608 + 8388608
                    qr_upper_mid: pl.Scalar[pl.INDEX] = 2 * qr_y_sig + 1
                    qr_upper_square: pl.Scalar[pl.INDEX] = qr_upper_mid * qr_upper_mid
                    qr_x_upper: pl.Scalar[pl.INT64] = qr_x_sig << qr_x_exp - 2 * qr_y_exp + 152
                    qr_previous_bits: pl.Scalar[pl.INT64] = qr_y_bits - 1
                    qr_previous_exp: pl.Scalar[pl.INT64] = qr_previous_bits // 8388608
                    qr_previous_sig: pl.Scalar[pl.INT64] = qr_previous_bits % 8388608 + 8388608
                    qr_lower_mid: pl.Scalar[pl.INDEX] = 2 * qr_previous_sig + 1
                    qr_lower_square: pl.Scalar[pl.INDEX] = qr_lower_mid * qr_lower_mid
                    qr_x_lower: pl.Scalar[pl.INT64] = qr_x_sig << qr_x_exp - 2 * qr_previous_exp + 152
                    if qr_x_upper > qr_upper_square or qr_x_upper == qr_upper_square and qr_y_bits % 2 == 1:
                        qr_y_bits: pl.Scalar[pl.INT64] = qr_y_bits + 1
                    else:
                        if qr_x_lower < qr_lower_square or qr_x_lower == qr_lower_square and qr_y_bits % 2 == 1:
                            qr_y_bits: pl.Scalar[pl.INT64] = qr_y_bits - 1
                pl.tensor.write(qr_rounded_bits, [0, qr_sqrt_row], pl.cast(qr_y_bits, pl.INT32))
            else:
                pl.tensor.write(qr_rounded_bits, [0, qr_sqrt_row], pl.cast(qr_y_bits, pl.INT32))
        qr_rms: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.reinterpret_view(qr_rounded_bits, dtype=pl.FP32)
        qr_inv_rms: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.full([1, 8], dtype=pl.FP32, value=0.0)
        for qr_rms_row in pl.range(8):
            qr_rms_value: pl.Scalar[pl.FP32] = pl.tensor.read(qr_rms, [0, qr_rms_row])
            pl.tensor.write(qr_inv_rms, [0, qr_rms_row], 1.0 / qr_rms_value)
        return qr_sq_sum, qr_inv_rms, qr_rms
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def q_proj_qr_normalize(self, qr_fp32: pl.Tensor[[QKV_QPROJ_MM_T_DYN, 1024], pl.FP32], gamma_cq: pl.Tensor[[1024], pl.BF16], qr: pl.Tensor[[T_DYN, 1024], pl.INT8], qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32], qr_i8_matmul: pl.Tensor[[512, 1024], pl.INT8], qr_scale_pad_store: pl.Tensor[[512, 1], pl.FP32], tile_base: pl.Scalar[pl.INDEX], tile_rows: pl.Scalar[pl.INDEX]) -> pl.Tensor[[512, 1024], pl.INT8]:
        # Native QR normalization boundary, also reused by numerical diagnostics.
        t_dim: pl.Scalar[pl.INDEX] = pl.tensor.dim(qr, 0)
        qr_view: pl.Tensor[[t_dim, 1024], pl.INT8] = pl.tensor.reshape(qr, [t_dim, 1024])
        qr_scale_view: pl.Tensor[[t_dim, 1], pl.FP32] = pl.tensor.reshape(qr_scale, [t_dim, 1])
        qr_token_tiles: pl.Scalar[pl.INDEX] = (tile_rows + 8 - 1) // 8
        qr_norm_workers: pl.Scalar[pl.INDEX] = pl.min(qr_token_tiles, 16)
        for tg_idx_worker in pl.spmd(qr_norm_workers, name_hint="qr_rms_norm_quant_spmd", allow_early_resolve=True):
            for tg_idx in pl.range(tg_idx_worker, qr_token_tiles, qr_norm_workers):
                tg: pl.Scalar[pl.INDEX] = tg_idx * 8
                valid_rows: pl.Scalar[pl.INDEX] = pl.min(8, tile_rows - tg)
                out_tg: pl.Scalar[pl.INDEX] = tile_base + tg
                _tuple_tmp: pl.Tuple[pl.Tensor[[1, 8], pl.FP32], pl.Tensor[[1, 8], pl.FP32], pl.Tensor[[1, 8], pl.FP32]] = self.q_proj_qr_rms(qr_fp32, tg)
                _qr_sq_sum: pl.Tensor[[1, 8], pl.FP32] = _tuple_tmp[0]
                qr_inv_rms: pl.Tensor[[1, 8], pl.FP32] = _tuple_tmp[1]
                _qr_rms: pl.Tensor[[1, 8], pl.FP32] = _tuple_tmp[2]
                qr_inv_rms_t: pl.Tensor[[8, 1], pl.FP32] = pl.tensor.reshape(qr_inv_rms, [8, 1])
                qr_tile_amax: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.full([1, 8], dtype=pl.FP32, value=0.0001)
                for qr_max_col0 in pl.pipeline(0, 1024, 256, stage=2):
                    qr_max_chunk: pl.Tensor[[8, 256], pl.FP32] = pl.tensor.cast(pl.tensor.cast(pl.tensor.slice(qr_fp32, [8, 256], [tg, qr_max_col0]), target_type=pl.BF16, mode='rint'), target_type=pl.FP32, mode='round')
                    gamma_max_cast: pl.Tensor[[256], pl.FP32] = pl.tensor.cast(pl.tensor.slice(gamma_cq, [256], [qr_max_col0]), target_type=pl.FP32, mode='round')
                    gamma_max_chunk: pl.Tensor[[1, 256], pl.FP32] = pl.tensor.reshape(gamma_max_cast, [1, 256])
                    qr_normalized: pl.Tensor[[8, 256], pl.FP32] = pl.tensor.col_expand_mul(pl.tensor.row_expand_mul(qr_max_chunk, qr_inv_rms_t), gamma_max_chunk)
                    qr_normalized_max: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.reshape(pl.tensor.row_max(pl.tensor.abs(qr_normalized)), [1, 8])
                    qr_tile_amax: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.maximum(qr_tile_amax, qr_normalized_max)
                qr_scale_quant_row: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.full([1, 8], dtype=pl.FP32, value=0.0)
                qr_scale_dq_row: pl.Tensor[[1, 8], pl.FP32] = pl.tensor.full([1, 8], dtype=pl.FP32, value=0.0)
                for qr_scale_row in pl.range(8):
                    qr_amax_value: pl.Scalar[pl.FP32] = pl.tensor.read(qr_tile_amax, [0, qr_scale_row])
                    qr_quant_value: pl.Scalar[pl.FP32] = 127.0 / qr_amax_value
                    pl.tensor.write(qr_scale_quant_row, [0, qr_scale_row], qr_quant_value)
                    pl.tensor.write(qr_scale_dq_row, [0, qr_scale_row], 1.0 / qr_quant_value)
                qr_scale_quant_t: pl.Tensor[[8, 1], pl.FP32] = pl.tensor.reshape(qr_scale_quant_row, [8, 1])
                qr_tile_scale_dq: pl.Tensor[[8, 1], pl.FP32] = pl.tensor.reshape(qr_scale_dq_row, [8, 1])
                qr_scale_pad_store: pl.Tensor[[512, 1], pl.FP32] = pl.tensor.assemble(qr_scale_pad_store, qr_tile_scale_dq, [tg, 0])
                if valid_rows == 8:
                    qr_scale_view: pl.Tensor[[t_dim, 1], pl.FP32] = pl.tensor.assemble(qr_scale_view, qr_tile_scale_dq, [out_tg, 0])
                else:
                    qr_scale_tail: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 1])] = pl.tile.load(qr_scale_pad_store, [tg, 0], [8, 1], [valid_rows, 1], target_memory=pl.Mem.Vec)
                    pl.tile.store(qr_scale_tail, [out_tg, 0], qr_scale_view)
                for qa in pl.pipeline(0, 1024, 256, stage=2):
                    qr_chunk: pl.Tensor[[8, 256], pl.FP32] = pl.tensor.cast(pl.tensor.cast(pl.tensor.slice(qr_fp32, [8, 256], [tg, qa]), target_type=pl.BF16, mode='rint'), target_type=pl.FP32, mode='round')
                    gamma_q_cast: pl.Tensor[[256], pl.FP32] = pl.tensor.cast(pl.tensor.slice(gamma_cq, [256], [qa]), target_type=pl.FP32, mode='round')
                    gamma_q_chunk: pl.Tensor[[1, 256], pl.FP32] = pl.tensor.reshape(gamma_q_cast, [1, 256])
                    qr_q_normed: pl.Tensor[[8, 256], pl.FP32] = pl.tensor.col_expand_mul(pl.tensor.row_expand_mul(qr_chunk, qr_inv_rms_t), gamma_q_chunk)
                    qr_q_scaled: pl.Tensor[[8, 256], pl.FP32] = pl.tensor.row_expand_mul(qr_q_normed, qr_scale_quant_t)
                    qr_q_i32: pl.Tensor[[8, 256], pl.INT32] = pl.tensor.cast(qr_q_scaled, target_type=pl.INT32, mode='rint')
                    qr_q_half: pl.Tensor[[8, 256], pl.FP16] = pl.tensor.cast(qr_q_i32, target_type=pl.FP16, mode='round')
                    qr_q_i8: pl.Tensor[[8, 256], pl.INT8] = pl.tensor.cast(qr_q_half, target_type=pl.INT8, mode='trunc')
                    qr_i8_matmul: pl.Tensor[[512, 1024], pl.INT8] = pl.tensor.assemble(qr_i8_matmul, qr_q_i8, [tg, qa])
                    if valid_rows == 8:
                        qr_view: pl.Tensor[[t_dim, 1024], pl.INT8] = pl.tensor.assemble(qr_view, qr_q_i8, [out_tg, qa])
                    else:
                        qr_q_tail: pl.Tile[[8, 256], pl.INT8, pl.Mem.Vec, pl.TileView(valid_shape=[valid_rows, 256])] = pl.tile.load(qr_i8_matmul, [tg, qa], [8, 256], [valid_rows, 256], target_memory=pl.Mem.Vec)
                        pl.tile.store(qr_q_tail, [out_tg, qa], qr_view)
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def q_proj_qr(self, x: pl.Tensor[[T_DYN, 4096], pl.BF16], wq_a: pl.Tensor[[1024, 4096], pl.BF16, pl.TensorView(stride=[], layout=pl.TensorLayout.NZ)], gamma_cq: pl.Tensor[[1024], pl.BF16], qr: pl.Tensor[[T_DYN, 1024], pl.INT8], qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32], qr_i8_matmul: pl.Tensor[[512, 1024], pl.INT8], qr_scale_pad_store: pl.Tensor[[512, 1], pl.FP32]) -> pl.Tensor[[512, 1024], pl.INT8]:
        # Q LoRA, RMSNorm and quantization -- the half the indexer query chain needs.
        # 
        #         The two staging tensors are held by the caller so the qproj half can be issued
        #         separately; they are rewritten per dense tile, so a caller that runs more than one
        #         tile iteration must let the qproj half finish before the next one starts. Every
        #         current caller has t_dim <= PREFILL_DENSE_TILE, i.e. a single iteration.
        #         
        t_dim: pl.Scalar[pl.INDEX] = pl.tensor.dim(x, 0)
        for tile_base in pl.range(0, t_dim, 512):
            tile_rows: pl.Scalar[pl.INDEX] = pl.min(512, t_dim - tile_base)
            with pl.scope():
                qr_t_matmul: pl.Scalar[pl.INDEX] = (tile_rows + 16 - 1) // 16 * 16
                qr_fp32: pl.Tensor[[qr_t_matmul, 1024], pl.FP32] = pl.tensor.create([qr_t_matmul, 1024], dtype=pl.FP32, layout=pl.TensorLayout.ND)
                self.q_proj_qa(x, wq_a, qr_fp32, tile_base, tile_rows)
                self.q_proj_qr_normalize(qr_fp32, gamma_cq, qr, qr_scale, qr_i8_matmul, qr_scale_pad_store, tile_base, tile_rows)
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def q_proj_rope(self, x: pl.Tensor[[T_DYN, 4096], pl.BF16], wq_a: pl.Tensor[[1024, 4096], pl.BF16, pl.TensorView(stride=[], layout=pl.TensorLayout.NZ)], wq_b: pl.Tensor[[1024, 32768], pl.INT8, pl.TensorView(stride=[], layout=pl.TensorLayout.NZ)], wq_b_scale: pl.Tensor[[32768], pl.FP32], gamma_cq: pl.Tensor[[1024], pl.BF16], rope_cos_il: pl.Tensor[[T_DYN, 64], pl.FP32], rope_sin_signed: pl.Tensor[[T_DYN, 64], pl.FP32], rope_swap_idx: pl.Tensor[[T_DYN, 64], pl.INT32], q: pl.Tensor[[T_DYN, 64, 512], pl.BF16], qr: pl.Tensor[[T_DYN, 1024], pl.INT8], qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32]):
        # Q LoRA, RMSNorm, quantization, and RoPE over bounded dense tiles.
        qr_i8_matmul: pl.Tensor[[512, 1024], pl.INT8] = pl.tensor.create([512, 1024], dtype=pl.INT8, layout=pl.TensorLayout.ND)
        qr_scale_pad_store: pl.Tensor[[512, 1], pl.FP32] = pl.tensor.create([512, 1], dtype=pl.FP32, layout=pl.TensorLayout.ND, manual_dep=True)
        self.q_proj_qr(x, wq_a, gamma_cq, qr, qr_scale, qr_i8_matmul, qr_scale_pad_store)
        q_seq_dep: pl.Scalar[pl.TASK_ID] = pl.system.task_dummy(deps=[])
        self.q_proj_q(x, wq_b, wq_b_scale, rope_cos_il, rope_sin_signed, rope_swap_idx, q, qr_i8_matmul, qr_scale_pad_store, q_seq_dep)
    @pl.function(type=pl.FunctionType.Inline)
    def rope_prepare(self, rope_sin: pl.Tensor[[T_DYN, 64], pl.FP32], rope_sin_signed: pl.Tensor[[T_DYN, 64], pl.FP32], rope_swap_idx: pl.Tensor[[T_DYN, 64], pl.INT32]):
        # Fold Native interleaved sin signs and build the pair-swap indices.
        t_dim: pl.Scalar[pl.INDEX] = pl.tensor.dim(rope_sin, 0)
        rope_sin_view: pl.Tensor[[t_dim, 64], pl.FP32] = pl.tensor.reshape(rope_sin, [t_dim, 64])
        rope_sin_signed_view: pl.Tensor[[t_dim, 64], pl.FP32] = pl.tensor.reshape(rope_sin_signed, [t_dim, 64])
        rope_swap_idx_view: pl.Tensor[[t_dim, 64], pl.INT32] = pl.tensor.reshape(rope_swap_idx, [t_dim, 64])
        token_tiles: pl.Scalar[pl.INDEX] = (t_dim + 8 - 1) // 8
        for qrp_worker in pl.spmd(pl.min(48, token_tiles), name_hint="q_rope_prepare_spmd", allow_early_resolve=True):
            qrp_ones: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.full([8, 64], dtype=pl.FP32, value=1.0)
            qrp_idx_i32: pl.Tensor[[1, 64], pl.INT32] = pl.tensor.ci(pl.const(0, pl.INT32), [1, 64], dtype=pl.INT32, descending=False)
            qrp_idx_fp32: pl.Tensor[[1, 64], pl.FP32] = pl.tensor.cast(qrp_idx_i32, target_type=pl.FP32, mode='round')
            qrp_col: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.col_expand_mul(qrp_ones, qrp_idx_fp32)
            qrp_half: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.muls(qrp_col, 0.5)
            qrp_dup_i32: pl.Tensor[[8, 64], pl.INT32] = pl.tensor.cast(qrp_half, target_type=pl.INT32, mode='trunc')
            qrp_dup_f: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.cast(qrp_dup_i32, target_type=pl.FP32, mode='round')
            qrp_lane: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.sub(qrp_col, pl.tensor.muls(qrp_dup_f, 2.0))
            qrp_next_col: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.adds(qrp_col, 1.0)
            qrp_lane_offset: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.muls(qrp_lane, 2.0)
            qrp_swap_f: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.sub(qrp_next_col, qrp_lane_offset)
            qrp_swap_idx: pl.Tensor[[8, 64], pl.INT32] = pl.tensor.cast(qrp_swap_f, target_type=pl.INT32, mode='round')
            qrp_sign: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.subs(pl.tensor.muls(qrp_lane, 2.0), 1.0)
            for qrp_idx in pl.range(qrp_worker, token_tiles, pl.min(48, token_tiles)):
                qrp_t0: pl.Scalar[pl.INDEX] = qrp_idx * 8
                qrp_valid_rows: pl.Scalar[pl.INDEX] = pl.min(8, t_dim - qrp_t0)
                if qrp_valid_rows == 8:
                    qrp_sin_rows_full: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.slice(rope_sin_view, [8, 64], [qrp_t0, 0])
                    qrp_sin_signed_full: pl.Tensor[[8, 64], pl.FP32] = pl.tensor.mul(qrp_sin_rows_full, qrp_sign)
                    rope_sin_signed_view: pl.Tensor[[t_dim, 64], pl.FP32] = pl.tensor.assemble(rope_sin_signed_view, qrp_sin_signed_full, [qrp_t0, 0])
                    rope_swap_idx_view: pl.Tensor[[t_dim, 64], pl.INT32] = pl.tensor.assemble(rope_swap_idx_view, qrp_swap_idx, [qrp_t0, 0])
                else:
                    qrp_sin_rows_tail: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[qrp_valid_rows, 64])] = pl.tile.load(rope_sin_view, [qrp_t0, 0], [8, 64], [qrp_valid_rows, 64], target_memory=pl.Mem.Vec)
                    qrp_tail_col: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.col_expand_mul(pl.tile.full([8, 64], dtype=pl.FP32, value=1.0), pl.tile.cast(pl.tile.ci(pl.const(0, pl.INT32), [1, 64], dtype=pl.INT32, descending=False), target_type=pl.FP32, mode='round'))
                    qrp_tail_dup_f: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.cast(pl.tile.cast(pl.tile.muls(qrp_tail_col, 0.5), target_type=pl.INT32, mode='trunc'), target_type=pl.FP32, mode='round')
                    qrp_tail_lane: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.sub(qrp_tail_col, pl.tile.muls(qrp_tail_dup_f, 2.0))
                    qrp_tail_swap_f: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.sub(pl.tile.adds(qrp_tail_col, 1.0), pl.tile.muls(qrp_tail_lane, 2.0))
                    qrp_tail_sign: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.subs(pl.tile.muls(qrp_tail_lane, 2.0), 1.0)
                    qrp_tail_sign_v1: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[qrp_valid_rows, 64])] = pl.tile.set_validshape(qrp_tail_sign, qrp_valid_rows, 64)
                    qrp_sin_signed_tail: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[qrp_valid_rows, 64])] = pl.tile.mul(qrp_sin_rows_tail, qrp_tail_sign_v1)
                    pl.tile.store(pl.tile.set_validshape(qrp_sin_signed_tail, qrp_valid_rows, 64), [qrp_t0, 0], rope_sin_signed_view)
                    pl.tile.store(pl.tile.set_validshape(pl.tile.cast(qrp_tail_swap_f, target_type=pl.INT32, mode='round'), qrp_valid_rows, 64), [qrp_t0, 0], rope_swap_idx_view)
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def qkv_proj_rope(self, x: pl.Tensor[[T_DYN, 4096], pl.BF16], wq_a: pl.Tensor[[1024, 4096], pl.BF16, pl.TensorView(stride=[], layout=pl.TensorLayout.NZ)], wq_b: pl.Tensor[[1024, 32768], pl.INT8, pl.TensorView(stride=[], layout=pl.TensorLayout.NZ)], wq_b_scale: pl.Tensor[[32768], pl.FP32], wkv: pl.Tensor[[4096, 512], pl.BF16], rope_cos: pl.Tensor[[T_DYN, 64], pl.FP32], rope_sin: pl.Tensor[[T_DYN, 64], pl.FP32], gamma_cq: pl.Tensor[[1024], pl.BF16], gamma_ckv: pl.Tensor[[512], pl.BF16], q: pl.Tensor[[T_DYN, 64, 512], pl.BF16], kv: pl.Tensor[[T_DYN, 512], pl.BF16], qr: pl.Tensor[[T_DYN, 1024], pl.INT8], qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32], late_dep: pl.Scalar[pl.TASK_ID], native_kv_projected: pl.Tensor[[T_DYN, 512], pl.BF16]):
        # Q 投影和 Native KV 后处理共用真实 TND 行数与 RoPE 表。
        t_dim: pl.Scalar[pl.INDEX] = pl.tensor.dim(x, 0)
        q_rope_sin_signed: pl.Tensor[[t_dim, 64], pl.FP32] = pl.tensor.create([t_dim, 64], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        q_rope_swap_idx: pl.Tensor[[t_dim, 64], pl.INT32] = pl.tensor.create([t_dim, 64], dtype=pl.INT32, layout=pl.TensorLayout.ND)
        self.rope_prepare(rope_sin, q_rope_sin_signed, q_rope_swap_idx)
        self.q_proj_rope(x, wq_a, wq_b, wq_b_scale, gamma_cq, rope_cos, q_rope_sin_signed, q_rope_swap_idx, q, qr, qr_scale)
        self.kv_proj_rope(x, wkv, gamma_ckv, rope_cos, q_rope_sin_signed, q_rope_swap_idx, kv, late_dep, native_kv_projected)
        projection_marker: pl.Scalar[pl.TASK_ID] = pl.system.task_dummy(deps=[late_dep])
        return q, projection_marker
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def checked_compressed_index(self, candidate: pl.Scalar[pl.INT32], request: pl.Scalar[pl.INT32], position: pl.Scalar[pl.INDEX], seq_lens: pl.Tensor[[B_DYN], pl.INT32], table: pl.Tensor[[B_DYN, COMPRESSED_TABLE_COLUMNS_DYN], pl.INT32]):
        checked: pl.Scalar[pl.INT32] = pl.cast(-1, pl.INT32)
        if pl.cast(request, pl.INDEX) >= 0 and pl.cast(request, pl.INDEX) < pl.tensor.dim(seq_lens, 0):
            if pl.cast(pl.tensor.read(seq_lens, [request]), pl.INDEX) > 0:
                if pl.cast(candidate, pl.INDEX) >= 0 and pl.cast(candidate, pl.INDEX) < (position + 1) // 4:
                    column: pl.Scalar[pl.INDEX] = pl.cast(candidate, pl.INDEX) // 32
                    if column < pl.tensor.dim(table, 1):
                        if pl.cast(pl.tensor.read(table, [request, column]), pl.INDEX) >= 0:
                            checked: pl.Scalar[pl.INT32] = candidate
        return checked
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def native_compressed_pair_swap(self, first: pl.Scalar[pl.INT32], second: pl.Scalar[pl.INT32], request: pl.Scalar[pl.INT32], limit: pl.Scalar[pl.INDEX], table: pl.Tensor[[B_DYN, COMPRESSED_TABLE_COLUMNS_DYN], pl.INT32]):
        swap: pl.Scalar[pl.INT32] = pl.cast(0, pl.INT32)
        first_index: pl.Scalar[pl.INDEX] = pl.cast(first, pl.INDEX)
        second_index: pl.Scalar[pl.INDEX] = pl.cast(second, pl.INDEX)
        if pl.cast(first, pl.INDEX) >= 0 and pl.cast(second, pl.INDEX) >= 0:
            if first_index + 1 < limit and second_index + 1 < limit:
                first_page: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(table, [request, first_index // 32]), pl.INDEX)
                second_page: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(table, [request, second_index // 32]), pl.INDEX)
                first_row: pl.Scalar[pl.INDEX] = first_page * 32 + first_index % 32
                second_row: pl.Scalar[pl.INDEX] = second_page * 32 + second_index % 32
                if first_row > second_row:
                    stride_bytes: pl.Scalar[pl.INDEX] = (first_row - second_row - 1) * 512 * 2
                    if stride_bytes < 2147483647:
                        swap: pl.Scalar[pl.INT32] = pl.cast(1, pl.INT32)
        return swap
    @pl.function(type=pl.FunctionType.Inline, auto_scope=False)
    def sparse_attn_csa(self, q: pl.Tensor[[T_DYN, 64, 512], pl.BF16], ori_kv: pl.Tensor[[ORI_BLOCK_NUM_DYN, 32, 1, 512], pl.BF16], ori_block_table: pl.Tensor[[B_DYN, ORIGINAL_TABLE_COLUMNS_DYN], pl.INT32], cmp_kv: pl.Tensor[[CMP_BLOCK_NUM_DYN, 32, 1, 512], pl.BF16], cmp_block_table: pl.Tensor[[B_DYN, COMPRESSED_TABLE_COLUMNS_DYN], pl.INT32], idx_topk: pl.Tensor[[T_DYN, 512], pl.INT32], position_ids: pl.Tensor[[T_DYN, 1], pl.INT64], seq_lens: pl.Tensor[[B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], attn_sink: pl.Tensor[[64], pl.FP32], freqs_cos: pl.Tensor[[T_DYN, 64], pl.FP32], freqs_sin: pl.Tensor[[T_DYN, 64], pl.FP32]):
        # Plan and run CSA QK/PV over sparse blocks, and build inverse-RoPE metadata.
        ori_block_num: pl.Scalar[pl.INDEX] = pl.tensor.dim(ori_kv, 0)
        t_dim: pl.Scalar[pl.INDEX] = pl.tensor.dim(q, 0)
        t_heads: pl.Scalar[pl.INDEX] = t_dim * 64
        rope_cs_blocks: pl.Scalar[pl.INDEX] = (t_dim + 6 - 1) // 6
        ori_kv_flat: pl.Tensor[[ori_block_num * pl.const(32, pl.INDEX), 512], pl.BF16] = pl.tensor.reshape(ori_kv, [ori_block_num * 32, 512])
        with pl.at(level=pl.Level.CORE_GROUP, name_hint="kv_touch", allow_early_resolve=True):
            ori_kv_flat: pl.Tensor[[ori_block_num * pl.const(32, pl.INDEX), 512], pl.BF16] = pl.tensor.assemble(ori_kv_flat, pl.tensor.slice(ori_kv_flat, [1, 512], [0, 0]), [0, 0])
        sparse_bias: pl.Tensor[[t_dim, 1024], pl.FP32] = pl.tensor.create([t_dim, 1024], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        softmax_copy64: pl.Tensor[[1536, 64], pl.FP32] = pl.tensor.create([1536, 64], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        cmp_sparse_indices: pl.Tensor[[t_dim, 512], pl.INT32] = pl.tensor.create([t_dim, 512], dtype=pl.INT32, layout=pl.TensorLayout.ND)
        valid_block_mask: pl.Tensor[[t_dim, 16], pl.INT32] = pl.tensor.create([t_dim, 16], dtype=pl.INT32, layout=pl.TensorLayout.ND)
        with pl.spmd(16, name_hint="csa_checked_indices_spmd") as checked_tid:
            checked_worker: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
            for checked_t0 in pl.range(checked_worker * 8, t_dim, 128):
                for checked_dt in pl.range(pl.min(8, t_dim - checked_t0)):
                    checked_t: pl.Scalar[pl.INDEX] = checked_t0 + checked_dt
                    c_position: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(position_ids, [checked_t, 0]), pl.INDEX)
                    c_request: pl.Scalar[pl.INT32] = pl.tensor.read(token_request, [checked_t])
                    for c_pair in pl.range(256):
                        c_slot: pl.Scalar[pl.INDEX] = c_pair * 2
                        first: pl.Scalar[pl.INT32] = self.checked_compressed_index(pl.tensor.read(idx_topk, [checked_t, c_slot]), c_request, c_position, seq_lens, cmp_block_table)
                        second: pl.Scalar[pl.INT32] = self.checked_compressed_index(pl.tensor.read(idx_topk, [checked_t, c_slot + 1]), c_request, c_position, seq_lens, cmp_block_table)
                        swap: pl.Scalar[pl.INT32] = self.native_compressed_pair_swap(first, second, c_request, (c_position + 1) // 4, cmp_block_table)
                        if pl.cast(swap, pl.INDEX) > 0:
                            pl.tensor.write(cmp_sparse_indices, [checked_t, c_slot], second)
                            pl.tensor.write(cmp_sparse_indices, [checked_t, c_slot + 1], first)
                        else:
                            pl.tensor.write(cmp_sparse_indices, [checked_t, c_slot], first)
                            pl.tensor.write(cmp_sparse_indices, [checked_t, c_slot + 1], second)
        with pl.spmd(16, name_hint="csa_slots_build_valid_qk_plan_spmd", deps=[checked_tid]) as qk_plan_tid:
            plan_worker: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
            for bias_t0 in pl.range(plan_worker * 8, t_dim, 128):
                bias_rows: pl.Scalar[pl.INDEX] = pl.min(8, t_dim - bias_t0)
                for bias_dt in pl.range(bias_rows):
                    bias_t: pl.Scalar[pl.INDEX] = bias_t0 + bias_dt
                    bias_request: pl.Scalar[pl.INDEX] = pl.max(pl.cast(pl.tensor.read(token_request, [bias_t]), pl.INDEX), 0)
                    c_position: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(position_ids, [bias_t, 0]), pl.INDEX)
                    c_out: pl.Tensor[[1, 512], pl.FP32] = pl.tensor.cast(pl.tensor.slice(cmp_sparse_indices, [1, 512], [bias_t, 0]), target_type=pl.FP32, mode='round')
                    v_length: pl.Scalar[pl.INDEX] = pl.min(c_position + 1, 128)
                    if pl.cast(pl.tensor.read(token_request, [bias_t]), pl.INDEX) < 0 or pl.cast(pl.tensor.read(seq_lens, [bias_request]), pl.INDEX) <= 0:
                        v_length: pl.Scalar[pl.INDEX] = pl.cast(0, pl.INDEX)
                    v_start: pl.Scalar[pl.INDEX] = c_position - v_length + 1
                    v_head: pl.Scalar[pl.INDEX] = v_start % 32
                    v_columns: pl.Tensor[[1, 128], pl.FP32] = pl.tensor.cast(pl.tensor.ci(pl.const(0, pl.INT32), [1, 128], dtype=pl.INT32, descending=False), target_type=pl.FP32, mode='round')
                    v_valid: pl.Tensor[[1, 128], pl.FP32] = pl.tensor.full([1, 128], dtype=pl.FP32, value=0.0)
                    v_block_valid: pl.Scalar[pl.INT32] = pl.cast(0, pl.INT32)
                    for v_run in pl.range(5):
                        v_lo: pl.Scalar[pl.INDEX] = pl.max(v_run * 32 - v_head, 0)
                        v_hi: pl.Scalar[pl.INDEX] = pl.min((v_run + 1) * 32 - v_head, v_length)
                        if v_hi > v_lo:
                            v_page: pl.Scalar[pl.INT32] = pl.tensor.read(ori_block_table, [bias_request, (v_start + v_lo) // 32])
                            if pl.cast(v_page, pl.INDEX) >= 0:
                                v_block_valid: pl.Scalar[pl.INT32] = pl.cast(1, pl.INT32)
                                v_lo_fp32: pl.Scalar[pl.FP32] = pl.cast(pl.cast(v_lo, pl.INT32), pl.FP32)
                                v_hi_fp32: pl.Scalar[pl.FP32] = pl.cast(pl.cast(v_hi, pl.INT32), pl.FP32)
                                v_ge: pl.Tensor[[1, 128], pl.FP32] = pl.tensor.minimum(pl.tensor.maximum(pl.tensor.adds(pl.tensor.subs(v_columns, v_lo_fp32), 1.0), 0.0), 1.0)
                                v_lt: pl.Tensor[[1, 128], pl.FP32] = pl.tensor.minimum(pl.tensor.maximum(pl.tensor.adds(pl.tensor.neg(v_columns), v_hi_fp32), 0.0), 1.0)
                                v_valid: pl.Tensor[[1, 128], pl.FP32] = pl.tensor.add(v_valid, pl.tensor.mul(v_ge, v_lt))
                    pl.tensor.write(valid_block_mask, [bias_t, 0], v_block_valid)
                    sparse_bias: pl.Tensor[[t_dim, 1024], pl.FP32] = pl.tensor.assemble(sparse_bias, pl.tensor.muls(pl.tensor.subs(v_valid, 1.0), 1e+20), [bias_t, 0])
                    sparse_bias: pl.Tensor[[t_dim, 1024], pl.FP32] = pl.tensor.assemble(sparse_bias, pl.tensor.full([1, 384], dtype=pl.FP32, value=-1e+20), [bias_t, 128])
                    sparse_bias: pl.Tensor[[t_dim, 1024], pl.FP32] = pl.tensor.assemble(sparse_bias, pl.tensor.muls(pl.tensor.minimum(c_out, 0.0), 1e+20), [bias_t, 512])
                c_blk_tmp: pl.Tile[[8, 512], pl.FP32] = pl.tile.create([8, 512], dtype=pl.FP32)
                for c_sb in pl.range(1, 2):
                    c_s0: pl.Scalar[pl.INDEX] = (c_sb - 1) * 512
                    c_block_slots: pl.Tile[[8, 512], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[bias_rows, 512])] = pl.tile.cast(pl.tile.load(cmp_sparse_indices, [bias_t0, c_s0], [8, 512], [bias_rows, 512]), target_type=pl.FP32, mode='round')
                    c_blk_valid: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[bias_rows, 1])] = pl.tile.row_max(pl.tile.minimums(pl.tile.maximums(pl.tile.adds(c_block_slots, 1.0), 0.0), 1.0), c_blk_tmp)
                    for c_dt in pl.range(bias_rows):
                        c_valid: pl.Scalar[pl.INT32] = pl.cast(pl.tile.read(c_blk_valid, [c_dt, 0]), pl.INT32)
                        pl.tensor.write(valid_block_mask, [bias_t0 + c_dt, c_sb], c_valid)
        cmp_block_num: pl.Scalar[pl.INDEX] = pl.tensor.dim(cmp_kv, 0)
        cmp_kv_flat: pl.Tensor[[cmp_block_num * pl.const(32, pl.INDEX), 512], pl.BF16] = pl.tensor.reshape(cmp_kv, [cmp_block_num * 32, 512])
        q_flat: pl.Tensor[[t_heads, 512], pl.BF16] = pl.tensor.reshape(q, [t_heads, 512])
        attn_sink_col: pl.Tensor[[64, 1], pl.FP32] = pl.tensor.reshape(attn_sink, [64, 1])
        attn_mi: pl.Tensor[[t_heads, 1], pl.FP32] = pl.tensor.create([t_heads, 1], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        attn_li: pl.Tensor[[t_heads, 1], pl.FP32] = pl.tensor.create([t_heads, 1], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        attn_oi: pl.Tensor[[t_heads, 512], pl.FP32] = pl.tensor.create([t_heads, 512], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        transfer_heads: pl.Scalar[pl.INDEX] = 1536
        transfer_kv_rows: pl.Scalar[pl.INDEX] = 12288
        kv_transfer: pl.Tensor[[transfer_kv_rows, 512], pl.BF16] = pl.tensor.create([transfer_kv_rows, 512], dtype=pl.BF16, layout=pl.TensorLayout.ND)
        score_transfer: pl.Tensor[[transfer_heads, 512], pl.FP32] = pl.tensor.create([transfer_heads, 512], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        probability_transfer: pl.Tensor[[transfer_heads, 512], pl.BF16] = pl.tensor.create([transfer_heads, 512], dtype=pl.BF16, layout=pl.TensorLayout.ND)
        pv_transfer: pl.Tensor[[transfer_heads, 512], pl.FP32] = pl.tensor.create([transfer_heads, 512], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        mi_transfer: pl.Tensor[[transfer_heads, 1], pl.FP32] = pl.tensor.create([transfer_heads, 1], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        li_transfer: pl.Tensor[[transfer_heads, 1], pl.FP32] = pl.tensor.create([transfer_heads, 1], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        alpha_transfer: pl.Tensor[[transfer_heads, 1], pl.FP32] = pl.tensor.create([transfer_heads, 1], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        ffts_workspace: pl.Tensor[[256], pl.INT64] = pl.tensor.create([256], dtype=pl.INT64, layout=pl.TensorLayout.ND)
        with pl.spmd(24, name_hint="qk_pv_spmd", deps=[qk_plan_tid], allow_early_resolve=True) as qk_tid:
            qk_core: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
            qk_kv_base: pl.Scalar[pl.INDEX] = qk_core * 512
            qk_head_base: pl.Scalar[pl.INDEX] = qk_core * 64
            pl.system.set_ffts(ffts_workspace)
            for qk_t in pl.range(qk_core, t_dim, 24):
                qk_b: pl.Scalar[pl.INDEX] = pl.max(pl.cast(pl.tensor.read(token_request, [qk_t]), pl.INDEX), 0)
                qk_q: pl.Tile[[64, 512], pl.BF16, pl.Mem.Mat] = pl.tile.load(q_flat, [qk_t * 64, 0], [64, 512], [64, 512], target_memory=pl.Mem.Mat)
                for qk_sb in pl.range(2):
                    if pl.cast(pl.tensor.read(valid_block_mask, [qk_t, qk_sb]), pl.INDEX) > 0:
                        pl.system.sync_wait(0, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIC)
                        for qk_part in pl.range(4):
                            qk_col: pl.Scalar[pl.INDEX] = qk_part * 128
                            qk_kv: pl.Tile[[128, 512], pl.BF16, pl.Mem.Mat] = pl.tile.load(kv_transfer, [qk_kv_base + qk_col, 0], [128, 512], [128, 512], target_memory=pl.Mem.Mat)
                            qk_scores: pl.Tile[[64, 128], pl.FP32, pl.Mem.Acc] = pl.tile.matmul(qk_q, pl.tile.transpose_view(qk_kv))
                            pl.tile.store(qk_scores, [qk_head_base, qk_col], score_transfer)
                        pl.system.sync_set(1, pipe=pl.PipeType.FIX, ffts_mode=2, core_type=pl.KernelType.AIC)
                        pl.system.sync_wait(2, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIC)
                        pv_acc: pl.Tile[[64, 512], pl.FP32, pl.Mem.Acc] = pl.tile.create([64, 512], dtype=pl.FP32, target_memory=pl.Mem.Acc)
                        for pv_part in pl.range(4):
                            pv_col: pl.Scalar[pl.INDEX] = pv_part * 128
                            pv_probability: pl.Tile[[64, 128], pl.BF16, pl.Mem.Mat] = pl.tile.load(probability_transfer, [qk_head_base, pv_col], [64, 128], [64, 128], target_memory=pl.Mem.Mat)
                            pv_kv: pl.Tile[[128, 512], pl.BF16, pl.Mem.Mat] = pl.tile.load(kv_transfer, [qk_kv_base + pv_col, 0], [128, 512], [128, 512], target_memory=pl.Mem.Mat)
                            pv_acc: pl.Tile[[64, 512], pl.FP32, pl.Mem.Acc] = pl.tile.matmul_acc(pv_acc, pv_probability, pv_kv, pv_part == 0)
                        pl.tile.store(pv_acc, [qk_head_base, 0], pv_transfer)
                        pl.system.sync_set(3, pipe=pl.PipeType.FIX, ffts_mode=2, core_type=pl.KernelType.AIC)
                for qk_aiv in pl.split_aiv(2, mode=pl.SplitMode.NONE):
                    pl.system.set_ffts(ffts_workspace)
                    qk_lane_head: pl.Scalar[pl.INDEX] = qk_aiv * 32
                    qk_lane_kv: pl.Scalar[pl.INDEX] = qk_aiv * 64
                    qk_reduce_tmp: pl.Tile[[8, 512], pl.FP32, pl.Mem.Vec] = pl.tile.create([8, 512], dtype=pl.FP32, target_memory=pl.Mem.Vec)
                    running_m: pl.Tile[[32, 1], pl.FP32] = pl.tile.load(attn_sink_col, [qk_lane_head, 0], [32, 1], [32, 1])
                    running_l: pl.Tile[[32, 1], pl.FP32, pl.Mem.Vec] = pl.tile.adds(pl.tile.muls(running_m, 0.0), 1.0)
                    running_left: pl.Tile[[32, 256], pl.FP32, pl.Mem.Vec] = pl.tile.full([32, 256], dtype=pl.FP32, value=0.0)
                    running_right: pl.Tile[[32, 256], pl.FP32, pl.Mem.Vec] = pl.tile.full([32, 256], dtype=pl.FP32, value=0.0)
                    pl.tile.store(running_m, [qk_head_base + qk_lane_head, 0], mi_transfer)
                    pl.tile.store(running_l, [qk_head_base + qk_lane_head, 0], li_transfer)
                    for qk_sb_1, (m_iter, l_iter, left_iter, right_iter) in pl.range(2, init_values=(running_m, running_l, running_left, running_right)):
                        if pl.cast(pl.tensor.read(valid_block_mask, [qk_t, qk_sb_1]), pl.INDEX) > 0:
                            for qk_part_1 in pl.range(4):
                                qk_part_row: pl.Scalar[pl.INDEX] = qk_part_1 * 128 + qk_lane_kv
                                qk_kv_half: pl.Tile[[64, 512], pl.BF16, pl.Mem.Vec] = pl.tile.full([64, 512], dtype=pl.BF16, value=0.0)
                                if qk_sb_1 == 0:
                                    qk_pos: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(position_ids, [qk_t, 0]), pl.INDEX)
                                    qk_win_len: pl.Scalar[pl.INDEX] = pl.min(qk_pos + 1, 128)
                                    qk_win_start: pl.Scalar[pl.INDEX] = qk_pos - qk_win_len + 1
                                    qk_head: pl.Scalar[pl.INDEX] = qk_win_start % 32
                                    qk_rows: pl.Scalar[pl.INDEX] = pl.min(pl.max(qk_win_len - qk_part_row, 0), 64)
                                    for qk_run in pl.unroll(5):
                                        qk_lo: pl.Scalar[pl.INDEX] = pl.max(qk_run * 32 - qk_head - qk_part_row, 0)
                                        qk_hi: pl.Scalar[pl.INDEX] = pl.min((qk_run + 1) * 32 - qk_head - qk_part_row, qk_rows)
                                        if qk_hi > qk_lo:
                                            qk_absolute: pl.Scalar[pl.INDEX] = qk_win_start + qk_part_row + qk_lo
                                            qk_raw_page: pl.Scalar[pl.INT32] = pl.tensor.read(ori_block_table, [qk_b, qk_absolute // 32])
                                            if pl.cast(qk_raw_page, pl.INDEX) >= 0:
                                                qk_raw_row: pl.Scalar[pl.INDEX] = pl.cast(qk_raw_page, pl.INDEX) * 32 + qk_absolute % 32
                                                qk_kv_half: pl.Tile[[64, 512], pl.BF16, pl.Mem.Vec] = pl.tile.gather_row(qk_kv_half, ori_kv_flat, [qk_lo, 0], [qk_raw_row, 0], [64, 512], valid_shape=[qk_hi - qk_lo, 512], transpose=False)
                                else:
                                    for qk_row in pl.range(64):
                                        qk_cmp_k: pl.Scalar[pl.INDEX] = (qk_sb_1 - 1) * 512 + qk_part_row + qk_row
                                        if qk_cmp_k < 512:
                                            qk_ridx: pl.Scalar[pl.INT32] = pl.tensor.read(cmp_sparse_indices, [qk_t, qk_cmp_k])
                                            if pl.cast(qk_ridx, pl.INDEX) >= 0:
                                                qk_page: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(cmp_block_table, [qk_b, pl.cast(qk_ridx, pl.INDEX) // 32]), pl.INDEX)
                                                if qk_page >= 0:
                                                    qk_src: pl.Scalar[pl.INDEX] = qk_page * 32 + pl.cast(qk_ridx, pl.INDEX) % 32
                                                    qk_kv_half: pl.Tile[[64, 512], pl.BF16, pl.Mem.Vec] = pl.tile.gather_row(qk_kv_half, cmp_kv_flat, [qk_row, 0], [qk_src, 0], [1, 512], transpose=False)
                                pl.tile.store(qk_kv_half, [qk_kv_base + qk_part_row, 0], kv_transfer)
                            pl.system.sync_set(0, pipe=pl.PipeType.MTE3, ffts_mode=2, core_type=pl.KernelType.AIV)
                            pl.system.sync_wait(1, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIV)
                            for sm_part in pl.range(4):
                                sm_h: pl.Scalar[pl.INDEX] = sm_part * 8
                                sm_row: pl.Scalar[pl.INDEX] = qk_head_base + qk_lane_head + sm_h
                                sm_scores: pl.Tile[[8, 512], pl.FP32] = pl.tile.load(score_transfer, [sm_row, 0], [8, 512], [8, 512])
                                sm_bias: pl.Tile[[1, 512], pl.FP32] = pl.tile.load(sparse_bias, [qk_t, qk_sb_1 * 512], [1, 512], [1, 512])
                                sm_masked: pl.Tile[[8, 512], pl.FP32, pl.Mem.Vec] = pl.tile.col_expand_add(pl.tile.muls(sm_scores, 0.044194173824159223), sm_bias)
                                sm_block_max: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.row_max(sm_masked, qk_reduce_tmp)
                                sm_old_m: pl.Tile[[8, 1], pl.FP32] = pl.tile.load(mi_transfer, [sm_row, 0], [8, 1], [8, 1])
                                sm_old_l: pl.Tile[[8, 1], pl.FP32] = pl.tile.load(li_transfer, [sm_row, 0], [8, 1], [8, 1])
                                sm_max: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.maximum(sm_old_m, sm_block_max)
                                sm_alpha: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.exp(pl.tile.sub(sm_old_m, sm_max))
                                sm_exp: pl.Tile[[8, 512], pl.FP32, pl.Mem.Vec] = pl.tile.exp(pl.tile.row_expand_sub(sm_masked, sm_max))
                                sm_position: pl.Scalar[pl.INDEX] = pl.cast(pl.tensor.read(position_ids, [qk_t, 0]), pl.INDEX)
                                if qk_sb_1 == 0:
                                    sm_key_count: pl.Scalar[pl.INDEX] = pl.min(sm_position + 1, 128)
                                else:
                                    sm_key_count: pl.Scalar[pl.INDEX] = pl.min((sm_position + 1) // 4, 512)
                                if sm_key_count < 64:
                                    sm_short: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[8, sm_key_count])] = pl.tile.slice(sm_exp, [8, 64], [0, 0], [8, sm_key_count])
                                    sm_block_sum: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.row_sum(sm_short, pl.tile.create([8, 64], dtype=pl.FP32))
                                else:
                                    if sm_key_count < 512:
                                        sm_columns: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.col_expand_add(pl.tile.full([8, 64], dtype=pl.FP32, value=0.0), pl.tile.cast(pl.tile.ci(pl.const(0, pl.INT32), [1, 64], dtype=pl.INT32, descending=False), target_type=pl.FP32, mode='round'))
                                        pl.tile.store(pl.tile.slice(sm_exp, [8, 64], [0, 0]), [sm_row, 0], softmax_copy64)
                                        sm_fold64: pl.Tile[[8, 64], pl.FP32] = pl.tile.load(softmax_copy64, [sm_row, 0], [8, 64], [8, 64])
                                        for sm_chunk in pl.unroll(1, 8):
                                            if sm_key_count > sm_chunk * 64:
                                                sm_added: pl.Tile[[8, 64], pl.FP32, pl.Mem.Vec] = pl.tile.add(sm_fold64, pl.tile.slice(sm_exp, [8, 64], [0, sm_chunk * 64]))
                                                if sm_key_count < (sm_chunk + 1) * 64:
                                                    sm_tail: pl.Scalar[pl.FP32] = pl.cast(pl.cast(sm_key_count - sm_chunk * 64, pl.INT32), pl.FP32)
                                                    sm_tail_mask: pl.Tile[[8, 32], pl.UINT8, pl.Mem.Vec, pl.TileView(valid_shape=[8, 8])] = pl.tile.cmps(sm_columns, sm_tail, cmp_type=2)
                                                    sm_fold64: pl.Tile[[8, 64], pl.FP32] = pl.tile.sel(sm_tail_mask, sm_added, sm_fold64, pl.tile.create([1, 16], dtype=pl.UINT32))
                                                else:
                                                    sm_fold64: pl.Tile[[8, 64], pl.FP32] = sm_added
                                        sm_groups64: pl.Tile[[64, 8], pl.FP32] = pl.tile.reshape(sm_fold64, [64, 8])
                                        sm_sum8: pl.Tile[[64, 1], pl.FP32, pl.Mem.Vec] = pl.tile.row_sum(sm_groups64, pl.tile.create([64, 8], dtype=pl.FP32))
                                        sm_final8: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec] = pl.tile.reshape(sm_sum8, [8, 8])
                                        sm_block_sum: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.row_sum(sm_final8, pl.tile.create([8, 8], dtype=pl.FP32))
                                    else:
                                        sm_groups8: pl.Tile[[512, 8], pl.FP32, pl.Mem.Vec] = pl.tile.reshape(sm_exp, [512, 8])
                                        sm_sum64: pl.Tile[[512, 1], pl.FP32, pl.Mem.Vec] = pl.tile.row_sum(sm_groups8, pl.tile.create([512, 8], dtype=pl.FP32))
                                        sm_groups64: pl.Tile[[64, 8], pl.FP32] = pl.tile.reshape(sm_sum64, [64, 8])
                                        sm_sum8: pl.Tile[[64, 1], pl.FP32, pl.Mem.Vec] = pl.tile.row_sum(sm_groups64, pl.tile.create([64, 8], dtype=pl.FP32))
                                        sm_final8: pl.Tile[[8, 8], pl.FP32, pl.Mem.Vec] = pl.tile.reshape(sm_sum8, [8, 8])
                                        sm_block_sum: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.row_sum(sm_final8, pl.tile.create([8, 8], dtype=pl.FP32))
                                sm_sum: pl.Tile[[8, 1], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.mul(sm_old_l, sm_alpha), sm_block_sum)
                                sm_probability: pl.Tile[[8, 512], pl.BF16, pl.Mem.Vec] = pl.tile.cast(sm_exp, target_type=pl.BF16, mode='round')
                                pl.tile.store(sm_probability, [sm_row, 0], probability_transfer)
                                pl.tile.store(sm_max, [sm_row, 0], mi_transfer)
                                pl.tile.store(sm_sum, [sm_row, 0], li_transfer)
                                pl.tile.store(sm_alpha, [sm_row, 0], alpha_transfer)
                            pl.system.sync_set(2, pipe=pl.PipeType.MTE3, ffts_mode=2, core_type=pl.KernelType.AIV)
                            pl.system.sync_wait(3, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIV)
                            pv_row: pl.Scalar[pl.INDEX] = qk_head_base + qk_lane_head
                            next_m: pl.Tile[[32, 1], pl.FP32] = pl.tile.load(mi_transfer, [pv_row, 0], [32, 1], [32, 1])
                            next_l: pl.Tile[[32, 1], pl.FP32] = pl.tile.load(li_transfer, [pv_row, 0], [32, 1], [32, 1])
                            alpha: pl.Tile[[32, 1], pl.FP32] = pl.tile.load(alpha_transfer, [pv_row, 0], [32, 1], [32, 1])
                            pv_left: pl.Tile[[32, 256], pl.FP32] = pl.tile.load(pv_transfer, [pv_row, 0], [32, 256], [32, 256])
                            next_left: pl.Tile[[32, 256], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.row_expand_mul(left_iter, alpha), pv_left)
                            pv_right: pl.Tile[[32, 256], pl.FP32] = pl.tile.load(pv_transfer, [pv_row, 256], [32, 256], [32, 256])
                            next_right: pl.Tile[[32, 256], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.row_expand_mul(right_iter, alpha), pv_right)
                            m_after, l_after, left_after, right_after = pl.yield_(next_m, next_l, next_left, next_right)
                        else:
                            m_after, l_after, left_after, right_after = pl.yield_(m_iter, l_iter, left_iter, right_iter)
                        running_m_1, running_l_1, running_left_1, running_right_1 = pl.yield_(m_after, l_after, left_after, right_after)
                    qk_output_row: pl.Scalar[pl.INDEX] = qk_t * 64 + qk_lane_head
                    pl.tile.store(running_m_1, [qk_output_row, 0], attn_mi)
                    pl.tile.store(running_l_1, [qk_output_row, 0], attn_li)
                    pl.tile.store(running_left_1, [qk_output_row, 0], attn_oi)
                    pl.tile.store(running_right_1, [qk_output_row, 256], attn_oi)
        rope_sin_signed: pl.Tensor[[384, 64], pl.FP32] = pl.tensor.create([384, 64], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        with pl.spmd(pl.min(rope_cs_blocks, 16), name_hint="rope_cs_spmd", allow_early_resolve=True) as rope_tid:
            for cs_rb in pl.range(pl.tile.get_block_idx(), rope_cs_blocks, pl.min(rope_cs_blocks, 16)):
                cs_t0: pl.Scalar[pl.INDEX] = cs_rb * 6
                cs_rows: pl.Scalar[pl.INDEX] = pl.min(6, t_dim - cs_t0)
                cs_ones: pl.Tile[[6, 64], pl.FP32, pl.Mem.Vec] = pl.tile.full([6, 64], dtype=pl.FP32, value=1.0)
                cs_idx_f: pl.Tile[[1, 64], pl.FP32, pl.Mem.Vec] = pl.tile.cast(pl.tile.ci(pl.const(0, pl.INT32), [1, 64], dtype=pl.INT32, descending=False), target_type=pl.FP32, mode='round')
                cs_col: pl.Tile[[6, 64], pl.FP32, pl.Mem.Vec] = pl.tile.col_expand_mul(cs_ones, cs_idx_f)
                cs_dup_i32: pl.Tile[[6, 64], pl.INT32, pl.Mem.Vec] = pl.tile.cast(pl.tile.muls(cs_col, 0.5), target_type=pl.INT32, mode='trunc')
                cs_dup_f: pl.Tile[[6, 64], pl.FP32, pl.Mem.Vec] = pl.tile.cast(cs_dup_i32, target_type=pl.FP32, mode='round')
                cs_lane: pl.Tile[[6, 64], pl.FP32, pl.Mem.Vec] = pl.tile.sub(cs_col, pl.tile.muls(cs_dup_f, 2.0))
                cs_sign: pl.Tile[[6, 64], pl.FP32, pl.Mem.Vec] = pl.tile.neg(pl.tile.subs(pl.tile.muls(cs_lane, 2.0), 1.0))
                cs_sin: pl.Tile[[6, 64], pl.FP32, pl.TileView(valid_shape=[cs_rows, 64])] = pl.tile.load(freqs_sin, [cs_t0, 0], [6, 64], [cs_rows, 64])
                cs_sign_rows: pl.Tile[[6, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[cs_rows, 64])] = pl.tile.set_validshape(cs_sign, cs_rows, 64)
                pl.tile.store(pl.tile.mul(cs_sin, cs_sign_rows), [cs_t0, 0], rope_sin_signed)
        return attn_mi, attn_li, attn_oi, freqs_cos, rope_sin_signed, qk_tid, rope_tid
    @pl.function(type=pl.FunctionType.Inline)
    def sparse_attn_csa_tp1(self, q: pl.Tensor[[T_DYN, 64, 512], pl.BF16], ori_kv: pl.Tensor[[ORI_BLOCK_NUM_DYN, 32, 1, 512], pl.BF16], ori_block_table: pl.Tensor[[B_DYN, ORIGINAL_TABLE_COLUMNS_DYN], pl.INT32], cmp_kv: pl.Tensor[[CMP_BLOCK_NUM_DYN, 32, 1, 512], pl.BF16], cmp_block_table: pl.Tensor[[B_DYN, COMPRESSED_TABLE_COLUMNS_DYN], pl.INT32], idx_topk: pl.Tensor[[T_DYN, 512], pl.INT32], position_ids: pl.Tensor[[T_DYN, 1], pl.INT64], seq_lens: pl.Tensor[[B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], attn_sink: pl.Tensor[[64], pl.FP32], freqs_cos: pl.Tensor[[T_DYN, 64], pl.FP32], freqs_sin: pl.Tensor[[T_DYN, 64], pl.FP32], o_packed_heads: pl.Tensor[[3072, 4096], pl.BF16]) -> tuple[pl.Tensor[[3072, 4096], pl.BF16], pl.Scalar[pl.TASK_ID]]:
        # Write CSA heads as ``[group, T_PAD, O_GROUP_IN]`` slabs.
        # 
        #         Only the first runtime ``t_dim`` rows in each group are valid. The
        #         returned task ID covers every write to the packed output tensor.
        #         
        _tuple_tmp: pl.Tuple[pl.Tensor[[t_heads, 1], pl.FP32], pl.Tensor[[t_heads, 1], pl.FP32], pl.Tensor[[t_heads, 512], pl.FP32], pl.Tensor[[T_DYN, 64], pl.FP32], pl.Tensor[[384, 64], pl.FP32], pl.Scalar[pl.TASK_ID], pl.Scalar[pl.TASK_ID]] = self.sparse_attn_csa(q, ori_kv, ori_block_table, cmp_kv, cmp_block_table, idx_topk, position_ids, seq_lens, token_request, attn_sink, freqs_cos, freqs_sin)
        attn_mi: pl.Tensor[[t_heads, 1], pl.FP32] = _tuple_tmp[0]
        attn_li: pl.Tensor[[t_heads, 1], pl.FP32] = _tuple_tmp[1]
        attn_oi: pl.Tensor[[t_heads, 512], pl.FP32] = _tuple_tmp[2]
        rope_cos_il: pl.Tensor[[T_DYN, 64], pl.FP32] = _tuple_tmp[3]
        rope_sin_signed: pl.Tensor[[384, 64], pl.FP32] = _tuple_tmp[4]
        qk_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp[5]
        rope_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp[6]
        t_dim: pl.Scalar[pl.INDEX] = pl.tensor.dim(q, 0)
        with pl.spmd(48, name_hint="merge_norm_spmd", deps=[qk_tid, rope_tid]) as merge_tid:
            m_worker: pl.Scalar[pl.INDEX] = pl.tile.get_block_idx()
            m_idx: pl.Tile[[1, 64], pl.INT32, pl.Mem.Vec] = pl.tile.ci(pl.const(0, pl.INT32), [1, 64], dtype=pl.INT32, descending=False)
            m_rem_tmp: pl.Tile[[1, 64], pl.INT32] = pl.tile.create([1, 64], dtype=pl.INT32)
            m_lane: pl.Tile[[1, 64], pl.INT32, pl.Mem.Vec] = pl.tile.rems(m_idx, pl.const(2, pl.INT32), m_rem_tmp)
            m_swap_row: pl.Tile[[1, 64], pl.INT32, pl.Mem.Vec] = pl.tile.adds(pl.tile.sub(m_idx, pl.tile.muls(m_lane, pl.const(2, pl.INT32))), pl.const(449, pl.INT32))
            m_swap_base: pl.Tile[[16, 64], pl.INT32] = pl.tile.create([16, 64], dtype=pl.INT32)
            m_swap_source: pl.Tile[[16, 64], pl.INT32, pl.Mem.Vec] = pl.tile.col_expand(m_swap_base, m_swap_row)
            m_row_offsets: pl.Tile[[1, 16], pl.INT32, pl.Mem.Vec] = pl.tile.muls(pl.tile.ci(pl.const(0, pl.INT32), [1, 16], dtype=pl.INT32, descending=False), pl.const(512, pl.INT32))
            m_swap_idx: pl.Tile[[16, 64], pl.INT32, pl.Mem.Vec] = pl.tile.row_expand_add(m_swap_source, pl.tile.reshape(m_row_offsets, [16, 1]))
            m_gather_tmp: pl.Tile[[16, 64], pl.INT32] = pl.tile.create([16, 64], dtype=pl.INT32)
            for m_idx_1 in pl.range(m_worker, t_dim * 4, 48):
                m_t: pl.Scalar[pl.INDEX] = m_idx_1 // 4
                m_h_idx: pl.Scalar[pl.INDEX] = m_idx_1 - m_t * 4
                m_h0: pl.Scalar[pl.INDEX] = m_h_idx * 16
                m_row: pl.Scalar[pl.INDEX] = m_idx_1 * 16
                if pl.cast(pl.tensor.read(token_request, [m_t]), pl.INDEX) >= 0:
                    m_li: pl.Tile[[16, 1], pl.FP32] = pl.tile.load(attn_li, [m_row, 0], [16, 1], [16, 1])
                    m_oi: pl.Tile[[16, 512], pl.FP32] = pl.tile.load(attn_oi, [m_row, 0], [16, 512], [16, 512])
                    n_full: pl.Tile[[16, 512], pl.FP32, pl.Mem.Vec] = pl.tile.row_expand_div(m_oi, m_li)
                    n_bf16: pl.Tile[[16, 512], pl.BF16, pl.Mem.Vec] = pl.tile.cast(n_full, target_type=pl.BF16, mode='rint')
                    n_rounded: pl.Tile[[16, 512], pl.FP32, pl.Mem.Vec] = pl.tile.cast(n_bf16, target_type=pl.FP32, mode='round')
                    m_rope: pl.Tile[[16, 64], pl.FP32, pl.Mem.Vec] = pl.tile.slice(n_rounded, [16, 64], [0, 448])
                    m_cos_il: pl.Tile[[1, 64], pl.FP32] = pl.tile.load(rope_cos_il, [m_t, 0], [1, 64], [1, 64])
                    m_sin_signed: pl.Tile[[1, 64], pl.FP32] = pl.tile.load(rope_sin_signed, [m_t, 0], [1, 64], [1, 64])
                    m_swapped: pl.Tile[[16, 64], pl.FP32, pl.Mem.Vec] = pl.tile.gather(n_rounded, m_swap_idx, m_gather_tmp)
                    m_rot: pl.Tile[[16, 64], pl.FP32, pl.Mem.Vec] = pl.tile.add(pl.tile.col_expand_mul(m_rope, m_cos_il), pl.tile.col_expand_mul(m_swapped, m_sin_signed))
                    n_rope_bf16: pl.Tile[[16, 64], pl.BF16, pl.Mem.Vec] = pl.tile.cast(m_rot, target_type=pl.BF16, mode='rint')
                    n_full_bf16: pl.Tile[[16, 512], pl.BF16, pl.Mem.Vec] = pl.tile.concat(pl.tile.slice(n_bf16, [16, 448], [0, 0]), n_rope_bf16)
                else:
                    n_full_bf16: pl.Tile[[16, 512], pl.BF16, pl.Mem.Vec] = pl.tile.full([16, 512], dtype=pl.BF16, value=0.0)
                n_group_bf16: pl.Tile[[2, 4096], pl.BF16, pl.Mem.Vec] = pl.tile.reshape(n_full_bf16, [2, 4096])
                n_pack_first: pl.Tile[[1, 4096], pl.BF16, pl.Mem.Vec] = pl.tile.slice(n_group_bf16, [1, 4096], [0, 0])
                n_pack_second: pl.Tile[[1, 4096], pl.BF16, pl.Mem.Vec] = pl.tile.slice(n_group_bf16, [1, 4096], [1, 0])
                n_pack_row: pl.Scalar[pl.INDEX] = m_h0 // 8 * 384 + m_t
                n_pack_row_second: pl.Scalar[pl.INDEX] = n_pack_row + 384
                pl.tile.store(n_pack_first, [n_pack_row, 0], o_packed_heads)
                pl.tile.store(n_pack_second, [n_pack_row_second, 0], o_packed_heads)
        return o_packed_heads, merge_tid
    @pl.function(type=pl.FunctionType.Orchestration, level=pl.Level.CHIP, role=pl.Role.Orchestrator, auto_scope=False)
    def _full_csa_tnd(self, x_hc: pl.Tensor[[T_DYN, 4, 4096], pl.BF16], hc_attn_fn: pl.Tensor[[24, 16384], pl.FP32], hc_attn_scale: pl.Tensor[[3], pl.FP32], hc_attn_base: pl.Tensor[[24], pl.FP32], attn_norm_w: pl.Tensor[[4096], pl.BF16], wq_a: pl.Tensor[[1024, 4096], pl.BF16, pl.TensorView(stride=[], layout=pl.TensorLayout.NZ)], wq_b: pl.Tensor[[1024, 32768], pl.INT8, pl.TensorView(stride=[], layout=pl.TensorLayout.NZ)], wq_b_scale: pl.Tensor[[32768], pl.FP32], wkv: pl.Tensor[[512, 4096], pl.BF16], gamma_cq: pl.Tensor[[1024], pl.BF16], gamma_ckv: pl.Tensor[[512], pl.BF16], freqs_cos: pl.Tensor[[T_DYN, 64], pl.FP32], freqs_sin: pl.Tensor[[T_DYN, 64], pl.FP32], cmp_freqs_cos: pl.Tensor[[COMPRESSED_ROWS_DYN, 64], pl.FP32], cmp_freqs_sin: pl.Tensor[[COMPRESSED_ROWS_DYN, 64], pl.FP32], inner_freqs_cos: pl.Tensor[[INDEXER_ROWS_DYN, 64], pl.FP32], inner_freqs_sin: pl.Tensor[[INDEXER_ROWS_DYN, 64], pl.FP32], cmp_wkv: pl.Tensor[[1024, 4096], pl.BF16], cmp_wgate: pl.Tensor[[1024, 4096], pl.BF16], cmp_ape: pl.Tensor[[4, 1024], pl.FP32], cmp_norm_w: pl.Tensor[[512], pl.BF16], compress_state: pl.InOut[pl.Tensor[[MAIN_STATE_BLOCK_NUM_DYN, STATE_PAGE_ELEMENTS_DYN], pl.FP32]], state_block_table: pl.Tensor[[B_DYN, STATE_TABLE_COLUMNS_DYN], pl.INT32], idx_wq_b: pl.Tensor[[1024, 8192], pl.INT8], idx_wq_b_scale: pl.Tensor[[8192], pl.FP32], weights_proj: pl.Tensor[[64, 4096], pl.BF16], hadamard_idx: pl.Tensor[[128, 128], pl.BF16], inner_wkv: pl.Tensor[[256, 4096], pl.BF16], inner_wgate: pl.Tensor[[256, 4096], pl.BF16], inner_ape: pl.Tensor[[4, 256], pl.FP32], inner_norm_w: pl.Tensor[[128], pl.BF16], inner_compress_state: pl.InOut[pl.Tensor[[INNER_STATE_BLOCK_NUM_DYN, INNER_STATE_PAGE_ELEMENTS_DYN], pl.FP32]], inner_state_block_table: pl.Tensor[[B_DYN, INNER_STATE_TABLE_COLUMNS_DYN], pl.INT32], kv_cache: pl.InOut[pl.Tensor[[ORI_BLOCK_NUM_DYN, 32, 1, 512], pl.BF16]], cmp_kv: pl.InOut[pl.Tensor[[CMP_BLOCK_NUM_DYN, 32, 1, 512], pl.BF16]], cmp_block_table: pl.Tensor[[B_DYN, COMPRESSED_TABLE_COLUMNS_DYN], pl.INT32], idx_native_kv_cache: pl.InOut[pl.Tensor[[IDX_NATIVE_CACHE_BLOCK_NUM_DYN, INDEXER_PAGE_BYTES_DYN], pl.INT8]], idx_block_table: pl.Tensor[[B_DYN, INDEXER_TABLE_COLUMNS_DYN], pl.INT32], ori_slot_mapping: pl.Tensor[[T_DYN, 2], pl.INT32], ori_block_table: pl.Tensor[[B_DYN, ORIGINAL_TABLE_COLUMNS_DYN], pl.INT32], cmp_slot_mapping: pl.Tensor[[COMPRESSED_ROWS_DYN, 2], pl.INT32], idx_slot_mapping: pl.Tensor[[INDEXER_ROWS_DYN, 2], pl.INT32], state_slot_mapping: pl.Tensor[[T_DYN, 2], pl.INT32], inner_state_slot_mapping: pl.Tensor[[T_DYN, 2], pl.INT32], position_ids: pl.Tensor[[T_DYN], pl.INT64], kv_seq_lens: pl.Tensor[[B_DYN], pl.INT32], cmp_query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], cmp_seq_lens: pl.Tensor[[B_DYN], pl.INT32], idx_query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], attn_sink: pl.Tensor[[64], pl.FP32], wo_a: pl.Tensor[[8, 4096, 1024], pl.BF16, pl.TensorView(stride=[], layout=pl.TensorLayout.NZ)], wo_b: pl.Tensor[[8192, 4096], pl.INT8, pl.TensorView(stride=[], layout=pl.TensorLayout.NZ)], wo_b_scale: pl.Tensor[[4096], pl.FP32], idx_topk_scores: pl.Out[pl.Tensor[[T_DYN, 512], pl.FP32]], idx_topk: pl.Out[pl.Tensor[[T_DYN, 512], pl.INT32]], wkv_order: pl.Tensor[[32, 16], pl.INT32], indexer_order: pl.Tensor[[16, 4, 16], pl.INT32], oproj_start: pl.Tensor[[16, 8, 8], pl.INT32], legacy_wkv: pl.Tensor[[4096, 512], pl.BF16], legacy_weights_proj: pl.Tensor[[4096, 64], pl.BF16], x_out: pl.Out[pl.Tensor[[T_DYN, 4, 4096], pl.BF16]]) -> pl.Tensor[[T_DYN, 4, 4096], pl.BF16]:
        # 一个runtime入口，七阶段以真实Tensor读写依赖连接。
        mixed: pl.Tensor[[T_DYN, 4096], pl.BF16] = pl.tensor.create([T_DYN, 4096], dtype=pl.BF16, layout=pl.TensorLayout.ND)
        post: pl.Tensor[[T_DYN, 4], pl.FP32] = pl.tensor.create([T_DYN, 4], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        comb: pl.Tensor[[T_DYN, 16], pl.FP32] = pl.tensor.create([T_DYN, 16], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        normed: pl.Tensor[[T_DYN, 4096], pl.BF16] = pl.tensor.create([T_DYN, 4096], dtype=pl.BF16, layout=pl.TensorLayout.ND)
        rstd: pl.Tensor[[T_DYN, 8], pl.FP32] = pl.tensor.create([T_DYN, 8], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        projected_kv: pl.Tensor[[T_DYN, 512], pl.BF16] = pl.tensor.create([T_DYN, 512], dtype=pl.BF16, layout=pl.TensorLayout.ND)
        indexer_raw: pl.Tensor[[T_DYN, 64], pl.BF16] = pl.tensor.create([T_DYN, 64], dtype=pl.BF16, layout=pl.TensorLayout.ND)
        indexer_scaled: pl.Tensor[[T_DYN, 64], pl.BF16] = pl.tensor.create([T_DYN, 64], dtype=pl.BF16, layout=pl.TensorLayout.ND)
        indexer_weights: pl.Tensor[[T_DYN, 64], pl.FP16] = pl.tensor.create([T_DYN, 64], dtype=pl.FP16, layout=pl.TensorLayout.ND)
        heads: pl.Tensor[[T_DYN, 32768], pl.BF16] = pl.tensor.create([T_DYN, 32768], dtype=pl.BF16, layout=pl.TensorLayout.ND)
        projected_o: pl.Tensor[[T_DYN, 8192], pl.BF16] = pl.tensor.create([T_DYN, 8192], dtype=pl.BF16, layout=pl.TensorLayout.ND)
        quantized_o: pl.Tensor[[T_DYN, 8192], pl.INT8] = pl.tensor.create([T_DYN, 8192], dtype=pl.INT8, layout=pl.TensorLayout.ND)
        scale_o: pl.Tensor[[T_DYN, 1], pl.FP32] = pl.tensor.create([T_DYN, 1], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        attention_out: pl.Tensor[[T_DYN, 4096], pl.BF16] = pl.tensor.create([T_DYN, 4096], dtype=pl.BF16, layout=pl.TensorLayout.ND)
        with pl.scope():
            _hc_pre_result: pl.Tuple[pl.Tensor[[T_DYN, 4096], pl.BF16], pl.Tensor[[T_DYN, 4], pl.FP32], pl.Tensor[[T_DYN, 16], pl.FP32]] = self._hc_pre_test(x_hc, hc_attn_fn, hc_attn_scale, hc_attn_base, mixed, post, comb)
        with pl.scope():
            _norm_result: pl.Tuple[pl.Tensor[[T_DYN, 4096], pl.BF16], pl.Tensor[[T_DYN, 8], pl.FP32]] = self._input_norm_test(mixed, attn_norm_w, normed, rstd)
        with pl.scope():
            _wkv_result: pl.Tensor[[T_DYN, 512], pl.BF16] = self._wkv_test(normed, wkv, wkv_order, projected_kv)
        with pl.scope():
            _indexer_weight_result: pl.Tuple[pl.Tensor[[T_DYN, 64], pl.BF16], pl.Tensor[[T_DYN, 64], pl.BF16], pl.Tensor[[T_DYN, 64], pl.FP16]] = self._indexer_projection(normed, weights_proj, indexer_order, indexer_raw, indexer_scaled, indexer_weights)
        max_seq_len: pl.Scalar[pl.INDEX] = self._read_device_max_seq_len(kv_seq_lens, 0)
        x_normed_t: pl.Tensor[[T_DYN, 4096], pl.BF16] = normed
        wb_blocks: pl.Scalar[pl.INDEX] = (T_DYN + 8 - 1) // 8
        idx_sin_signed: pl.Tensor[[T_DYN, 64], pl.FP32] = pl.tensor.create([T_DYN, 64], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        cmp_row_offsets: pl.Tensor[[B_DYN], pl.INT32] = pl.tensor.create([B_DYN], dtype=pl.INT32, layout=pl.TensorLayout.ND)
        idx_row_offsets: pl.Tensor[[B_DYN], pl.INT32] = pl.tensor.create([B_DYN], dtype=pl.INT32, layout=pl.TensorLayout.ND)
        token_request: pl.Tensor[[T_DYN], pl.INT32] = pl.tensor.create([T_DYN], dtype=pl.INT32, layout=pl.TensorLayout.ND)
        with pl.at(level=pl.Level.CORE_GROUP, name_hint="csa_row_offsets", allow_early_resolve=True) as offsets_tid:
            cmp_row_offsets: pl.Tensor[[B_DYN], pl.INT32] = self.build_compact_row_offsets(cmp_query_start_loc, cmp_seq_lens, cmp_row_offsets)
            idx_row_offsets: pl.Tensor[[B_DYN], pl.INT32] = self.build_compact_row_offsets(idx_query_start_loc, kv_seq_lens, idx_row_offsets)
            token_request: pl.Tensor[[T_DYN], pl.INT32] = self.build_token_request(query_start_loc, kv_seq_lens, token_request)
        rope_sign_blocks: pl.Scalar[pl.INDEX] = (T_DYN + 4 - 1) // 4
        with pl.spmd(pl.min(rope_sign_blocks, 16), name_hint="csa_rope_sign_spmd", deps=[offsets_tid], allow_early_resolve=True) as rope_tid:
            for rope_rb in pl.range(pl.tile.get_block_idx(), rope_sign_blocks, pl.min(rope_sign_blocks, 16)):
                rope_t0: pl.Scalar[pl.INDEX] = rope_rb * 4
                rope_rows: pl.Scalar[pl.INDEX] = pl.min(4, T_DYN - rope_t0)
                il_ones: pl.Tile[[4, 64], pl.FP32, pl.Mem.Vec] = pl.tile.full([4, 64], dtype=pl.FP32, value=1.0)
                il_lane_ids: pl.Tile[[1, 64], pl.FP32, pl.Mem.Vec] = pl.tile.cast(pl.tile.ci(pl.const(0, pl.INT32), [1, 64], dtype=pl.INT32, descending=False), target_type=pl.FP32, mode='round')
                il_col: pl.Tile[[4, 64], pl.FP32, pl.Mem.Vec] = pl.tile.col_expand_mul(il_ones, il_lane_ids)
                il_dup_f: pl.Tile[[4, 64], pl.FP32, pl.Mem.Vec] = pl.tile.cast(pl.tile.cast(pl.tile.muls(il_col, 0.5), target_type=pl.INT32, mode='trunc'), target_type=pl.FP32, mode='round')
                il_lane: pl.Tile[[4, 64], pl.FP32, pl.Mem.Vec] = pl.tile.sub(il_col, pl.tile.muls(il_dup_f, 2.0))
                il_sign: pl.Tile[[4, 64], pl.FP32, pl.Mem.Vec] = pl.tile.subs(pl.tile.muls(il_lane, 2.0), 1.0)
                rope_sin_rows: pl.Tile[[4, 64], pl.FP32, pl.TileView(valid_shape=[rope_rows, 64])] = pl.tile.load(freqs_sin, [rope_t0, 0], [4, 64], [rope_rows, 64])
                rope_sign_rows: pl.Tile[[4, 64], pl.FP32, pl.Mem.Vec, pl.TileView(valid_shape=[rope_rows, 64])] = pl.tile.set_validshape(il_sign, rope_rows, 64)
                pl.tile.store(pl.tile.mul(rope_sin_rows, rope_sign_rows), [rope_t0, 0], idx_sin_signed)
        q: pl.Tensor[[T_DYN, 64, 512], pl.BF16] = pl.tensor.create([T_DYN, 64, 512], dtype=pl.BF16, layout=pl.TensorLayout.ND)
        kv: pl.Tensor[[T_DYN, 512], pl.BF16] = pl.tensor.create([T_DYN, 512], dtype=pl.BF16, layout=pl.TensorLayout.ND)
        qr: pl.Tensor[[T_DYN, 1024], pl.INT8] = pl.tensor.create([T_DYN, 1024], dtype=pl.INT8, layout=pl.TensorLayout.ND)
        qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32] = pl.tensor.create([T_DYN, 1], dtype=pl.FP32, layout=pl.TensorLayout.ND)
        position_ids_t1: pl.Tensor[[T_DYN, 1], pl.INT64] = pl.tensor.reshape(position_ids, [T_DYN, 1])
        with pl.scope():
            late_dep: pl.Scalar[pl.TASK_ID] = pl.system.task_dummy(deps=[rope_tid])
            _tuple_tmp: pl.Tuple[pl.Tensor[[T_DYN, 64, 512], pl.BF16], pl.Scalar[pl.TASK_ID]] = self.qkv_proj_rope(x_normed_t, wq_a, wq_b, wq_b_scale, legacy_wkv, freqs_cos, freqs_sin, gamma_cq, gamma_ckv, q, kv, qr, qr_scale, late_dep, projected_kv)
            q: pl.Tensor[[T_DYN, 64, 512], pl.BF16] = _tuple_tmp[0]
            qa_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp[1]
            kv_cache_flat: pl.Tensor[[ORI_BLOCK_NUM_DYN * pl.const(32, pl.INDEX), 512], pl.BF16] = pl.tensor.reshape(kv_cache, [ORI_BLOCK_NUM_DYN * 32, 512])
            for wb_worker in pl.spmd(8, name_hint="csa_cache_writeback_spmd", allow_early_resolve=True):
                for wb_blk in pl.range(wb_worker, wb_blocks, 8):
                    wb_t0: pl.Scalar[pl.INDEX] = wb_blk * 8
                    for write_dt in pl.range(pl.min(8, T_DYN - wb_t0)):
                        write_t: pl.Scalar[pl.INDEX] = wb_t0 + write_dt
                        write_page: pl.Scalar[pl.INT32] = pl.tensor.read(ori_slot_mapping, [write_t, 0])
                        write_offset: pl.Scalar[pl.INT32] = pl.tensor.read(ori_slot_mapping, [write_t, 1])
                        if pl.cast(write_page, pl.INDEX) >= 0 and pl.cast(write_offset, pl.INDEX) >= 0:
                            write_row: pl.Scalar[pl.INDEX] = pl.cast(write_page, pl.INDEX) * 32 + pl.cast(write_offset, pl.INDEX)
                            kv_cache_flat: pl.Tensor[[ORI_BLOCK_NUM_DYN * pl.const(32, pl.INDEX), 512], pl.BF16] = pl.tensor.assemble(kv_cache_flat, pl.tensor.slice(kv, [1, 512], [write_t, 0]), [write_row, 0])
            compressor_dep: pl.Scalar[pl.TASK_ID] = pl.system.task_dummy(deps=[late_dep, qa_tid])
            cmp_out: pl.Tensor[[T_DYN, 512], pl.FP32] = pl.tensor.create([T_DYN, 512], dtype=pl.FP32, layout=pl.TensorLayout.ND)
            _tuple_tmp_1: pl.Tuple[pl.Tensor[[T_DYN, 512], pl.FP32], pl.Scalar[pl.TASK_ID], pl.Scalar[pl.TASK_ID]] = self.compressor_ratio4(x_normed_t, cmp_out, compress_state, state_block_table, cmp_wkv, cmp_wgate, cmp_ape, cmp_norm_w, cmp_freqs_cos, cmp_freqs_sin, cmp_row_offsets, token_request, cmp_kv, position_ids, cmp_seq_lens, query_start_loc, cmp_slot_mapping, state_slot_mapping, compressor_dep)
            cmp_out: pl.Tensor[[T_DYN, 512], pl.FP32] = _tuple_tmp_1[0]
            cmp_cache_write_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp_1[1]
            cmp_kv_score_tid: pl.Scalar[pl.TASK_ID] = _tuple_tmp_1[2]
            idx_kv_unused: pl.Tensor[[T_DYN, 128], pl.FP32] = pl.tensor.create([T_DYN, 128], dtype=pl.FP32, layout=pl.TensorLayout.ND)
            idx_cache_write_tid: pl.Scalar[pl.TASK_ID] = self.indexer_compressor(x_normed_t, idx_kv_unused, inner_compress_state, inner_state_block_table, inner_wkv, inner_wgate, inner_ape, inner_norm_w, inner_freqs_cos, inner_freqs_sin, idx_row_offsets, token_request, hadamard_idx, idx_native_kv_cache, position_ids, kv_seq_lens, query_start_loc, idx_slot_mapping, inner_state_slot_mapping, late_dep, cmp_kv_score_tid)
            attention_topk: pl.Tensor[[T_DYN, 512], pl.INT32] = idx_topk
            with pl.scope():
                _tuple_tmp_2: pl.Tuple[pl.Tensor[[T_DYN, 512], pl.FP32], pl.Tensor[[T_DYN, 512], pl.INT32]] = self.indexer(x_normed_t, qr, qr_scale, idx_wq_b, idx_wq_b_scale, legacy_weights_proj, indexer_weights, freqs_cos, idx_sin_signed, hadamard_idx, idx_native_kv_cache, idx_block_table, idx_topk_scores, idx_topk, position_ids, kv_seq_lens, token_request, query_start_loc, late_dep, idx_cache_write_tid, max_seq_len)
                _index_scores: pl.Tensor[[T_DYN, 512], pl.FP32] = _tuple_tmp_2[0]
                _index_indices: pl.Tensor[[T_DYN, 512], pl.INT32] = _tuple_tmp_2[1]
            o_packed_heads: pl.Tensor[[3072, 4096], pl.BF16] = pl.tensor.create([3072, 4096], dtype=pl.BF16, layout=pl.TensorLayout.ND)
            _tuple_tmp_3: pl.Tuple[pl.Tensor[[3072, 4096], pl.BF16], pl.Scalar[pl.TASK_ID]] = self.sparse_attn_csa_tp1(q, kv_cache, ori_block_table, cmp_kv, cmp_block_table, attention_topk, position_ids_t1, kv_seq_lens, token_request, attn_sink, freqs_cos, freqs_sin, o_packed_heads)
            o_packed_heads: pl.Tensor[[3072, 4096], pl.BF16] = _tuple_tmp_3[0]
            heads_dep: pl.Scalar[pl.TASK_ID] = _tuple_tmp_3[1]
            with pl.scope():
                _published_heads: pl.Tensor[[T_DYN, 32768], pl.BF16] = self.publish_native_heads(o_packed_heads, heads, T_DYN, heads_dep)
        with pl.scope():
            _oproj_result: pl.Tensor[[T_DYN, 4096], pl.BF16] = self._o_proj_test(heads, wo_a, wo_b, wo_b_scale, oproj_start, projected_o, quantized_o, scale_o, attention_out)
        with pl.scope():
            _hc_post_result: pl.Tensor[[T_DYN, 4, 4096], pl.BF16] = self._hc_post(attention_out, x_hc, post, comb, x_out)
        return x_out