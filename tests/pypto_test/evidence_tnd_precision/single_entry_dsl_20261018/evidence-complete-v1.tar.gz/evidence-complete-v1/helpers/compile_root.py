"""227原SDK无设备解析/生成；禁止改原基准或SDK。"""
from pathlib import Path
import hashlib,importlib,json,os
root=Path(os.environ['SOURCE_ROOT'])
expected=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/low-acceptance-20261010/runtime-package/pypto')
for name in ('pypto','simpler','torch','torch_npu','vllm','vllm_ascend'):
 m=importlib.import_module(name);print('MODULE',name,m.__file__,getattr(m,'__version__',None),flush=True)
 if name=='pypto':assert Path(m.__file__).resolve().is_relative_to(expected.resolve())
 if name=='vllm_ascend':assert Path(m.__file__).resolve().is_relative_to(root.resolve())
for n in ('PTOAS_ROOT','ASCEND_HOME_PATH','ATB_HOME_PATH','CCACHE_DIR'):
 assert os.environ.get(n);print('ENV',n,os.environ[n],flush=True)
base=root.parent
manifest={'baseline_git_commit':'94feb6a2f2d5dad8fd480f90456920402644d3e0','candidate':'single entry v1, pure DSL HC-pre/Norm, working changes, no compiler/SDK edits','files':{}}
for p in sorted(root.rglob('*')):
 if p.is_file() and '__pycache__' not in p.parts:manifest['files'][str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest()
(base/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('SOURCE_MANIFEST',hashlib.sha256((base/'manifest.json').read_bytes()).hexdigest(),len(manifest['files']),flush=True)
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.decode_csa import decode_csa_tp1_layer_test
from pypto.runtime import RunConfig
f=decode_csa_tp1_layer_test
assert len(f.param_names)==62,f.param_names
print('ROOT_ABI',len(f.param_names),f.param_names,flush=True)
p=f.specialize()
(base/'specialized.py').write_text(str(p))
print('ROOT_SPECIALIZE_OK',flush=True)
p=f.compile(config=RunConfig(platform='a2a3'))
(base/'compile-result.json').write_text(json.dumps({'output_dir':str(p.output_dir),'source_manifest_sha256':hashlib.sha256((base/'manifest.json').read_bytes()).hexdigest()},indent=2)+'\n')
print('ROOT_COMPILE_OK',p.output_dir,flush=True)

from pypto.runtime.kernel_compiler import KernelCompiler
compiler=KernelCompiler('a2a3')
cpp=next(Path(p.output_dir).glob('orchestration/*.cpp'))
blob=compiler.compile_orchestration('tensormap_and_ringbuffer',str(cpp),build_dir=str(base))
(base/'orchestration.so').write_bytes(blob)
print('ROOT_ORCHESTRATION_CXX_OK',len(blob),flush=True)
