"""仅作对照的冻结基准统计；不属于纯DSL候选。"""
import pypto.language as pl
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.input_norm import square_sum as baseline_sum
R=pl.dynamic('NORM_REF_ROWS')
@pl.jit
def reference_sum(x:pl.Tensor[[R,4096],pl.BF16],out:pl.Out[pl.Tensor[[R,8],pl.FP32]]):
    x.bind_dynamic(0,R)
    out.bind_dynamic(0,R)
    with pl.spmd(pl.tensor.dim(x,0)):
        out=baseline_sum(x,out)
    return out
