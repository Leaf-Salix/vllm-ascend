"""真实Native HC-pre输出、原Norm权重，逐阶段首差停止。"""
import argparse,hashlib,json,os
from pathlib import Path
import torch,torch_npu,pypto,pypto.torch
from safetensors import safe_open
from vllm_ascend.utils import enable_custom_op
from input_norm import input_norm_test,square_sum_test
from norm_reference import reference_sum
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir()
report={'pass':False,'complete':False,'candidate':'pure DSL half-interval sum plus unchanged sqrt/div/apply','native_gold':'actual installed npu_rms_norm; frozen previously aligned extern sum is a diagnostic reference only','shapes':[1,6,11,21,40,144,240,256],'phases':['A','B','A_restored','zero'],'comparisons':[],'scope':'single module real L4 HC/norm weights; no whole-model claim','task_device':os.environ['TASK_DEVICE'],'pypto_file':pypto.__file__}
def save():(a.out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
def cpu(x):torch.npu.synchronize();return x.detach().cpu().clone()
def equal(x,y):return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def check(label,actual,gold):
 for k,v in actual.items():
  assert v.shape==gold[k].shape and v.dtype==gold[k].dtype,k+" shape/dtype"
  assert torch.isfinite(v).all() and torch.isfinite(gold[k]).all(),k+" nonfinite"
 bad={k:int((v.contiguous().view(torch.int32 if v.dtype==torch.float32 else torch.int16)!=gold[k].contiguous().view(torch.int32 if v.dtype==torch.float32 else torch.int16)).sum()) for k,v in actual.items()}
 report['comparisons'].append({'label':label,'different_elements':bad});save()
 if any(bad.values()):
  torch.save({'actual':actual,'expected':gold,'input':cpu(x),'weight':cpu(weight)},a.out/'first-difference.pt');raise RuntimeError('FIRST_BIT_DIFFERENCE '+label)

torch.npu.set_device(0);torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
assert enable_custom_op()
model=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8');config=json.loads((model/'config.json').read_text());index=json.loads((model/'quant_model_weights.safetensors.index.json').read_text())['weight_map'];values={}
for name in ('hc_attn_fn','hc_attn_scale','hc_attn_base','attn_norm.weight'):
 key='layers.4.'+name
 with safe_open(model/index[key],framework='pt',device='cpu') as f:v=f.get_tensor(key)
 report.setdefault('weights',{})[key]={'sha256':hashlib.sha256(v.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest(),'shape':list(v.shape),'stored_dtype':str(v.dtype)}
 values[name]=v.to('npu',dtype=torch.bfloat16 if name=='attn_norm.weight' else v.dtype)
weight=values['attn_norm.weight'];before_weight=cpu(weight)
pypto.torch.init(device=0,platform='a2a3',runtime='tensormap_and_ringbuffer')
op=pypto.torch.register(input_norm_test,'full_dsl_norm_20261018::forward');sumop=pypto.torch.register(square_sum_test,'full_dsl_norm_20261018::sum');refop=pypto.torch.register(reference_sum,'full_dsl_norm_ref_20261018::sum')
save()
try:
 with torch.inference_mode():
  for n in report['shapes']:
   hidden=torch.randn((n,4,4096),generator=torch.Generator().manual_seed(20261018+n),dtype=torch.bfloat16).to('npu');original=hidden.clone()
   def mixed():return torch.ops._C_ascend.npu_hc_pre_v2(hidden,values['hc_attn_fn'],values['hc_attn_scale'],values['hc_attn_base'],4,config['hc_sinkhorn_iters'],config['rms_norm_eps'],config['hc_eps'])[0]
   x=mixed();old_x=cpu(x)
   owners={'output':torch.full((n+2,4096),.0625,dtype=torch.bfloat16,device='npu'),'rstd':torch.full((n+2,8),.0625,dtype=torch.float32,device='npu'),'sum':torch.full((n+2,8),.0625,dtype=torch.float32,device='npu')}
   out={k:v[1:-1] for k,v in owners.items()};ref=torch.empty((n,8),dtype=torch.float32,device='npu')
   def run():op(x,weight,out['output'],out['rstd']);sumop(x,out['sum'])
   def observed():
    assert equal(cpu(x),old_x),'candidate input mutation'
    assert equal(cpu(weight),before_weight),'weight mutation'
    for name,v in owners.items():assert bool((cpu(v[0])==.0625).all() and (cpu(v[-1])==.0625).all()),name+' guard'
    d={k:cpu(v) for k,v in out.items()}
    assert torch.equal(d['rstd'],d['rstd'][:,0:1].expand(-1,8)), 'rstd lanes disagree'
    assert torch.equal(d['sum'],d['sum'][:,0:1].expand(-1,8)), 'sum lanes disagree'
    return {'output':d['output'],'rstd':d['rstd'][:,0:1].contiguous(),'sum':d['sum'][:,0:1].contiguous()}
   def gold():
    y,inv=torch_npu.npu_rms_norm(x,weight,1e-6);refop(x,ref)
    return {'output':cpu(y),'rstd':cpu(inv).reshape(n,1),'sum':cpu(ref)[:,0:1].contiguous()}
   expected=gold();run();check(f'T{n}/eager/A',observed(),expected)
   graph=torch.npu.NPUGraph()
   with torch.npu.graph(graph):run()
   for phase in report['phases']:
    hidden.copy_(original)
    if phase=='B':hidden.add_(.125)
    if phase=='zero':hidden.zero_()
    x.copy_(mixed());old_x=cpu(x);expected=gold()
    if phase=="A":a_input=old_x.clone();a_output=expected["output"].clone()
    if phase=="B":
     assert not equal(old_x,a_input),"B input unchanged"
     assert not equal(expected["output"],a_output),"B native output unchanged"
    for v in out.values():v.fill_(float('nan'))
    graph.replay();check(f'T{n}/graph/{phase}',observed(),expected)
   report.setdefault('shapes_passed',[]).append(n);save()
  report['pass']=report['complete']=True;save()
except Exception as error:report['error']=repr(error);save();raise
