#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
old="$base/low-acceptance-20261010"
job="$base/full-dsl-single-entry-20261018/model-128-v1"
source_job="$base/full-dsl-single-entry-20261018/single-v1"
bank="$base/low-acceptance-128k-b24-20261014/banks/fixed131072"
phase=${1:?}; label=${2:?}
[[ "$phase" == precision-witness ]] || exit 2
case "$phase" in
 native-control) export FULL_PROBE_MODE=control; unset FULL_PROBE_OUTER_REFERENCE FULL_PROBE_STAGE_REFERENCE ;;
 precision-witness) export FULL_PROBE_MODE=control FULL_PROBE_OUTER_REFERENCE=$base/retest192-20261016/native1-generation-reference/full-probe; unset FULL_PROBE_STAGE_REFERENCE ;;
 *) exit 2 ;;
esac
out="/data/pyptouser/yejia/lc128/$label"
mkdir "$out"
export LOW_ACCEPTANCE_RUNTIME_PACKAGE="$old/runtime-package"
export LOW_ACCEPTANCE_GPU_BLOCKS=24000 LOW_ACCEPTANCE_OFFICIAL_CACHE="$old/official-static-cache"
unset LOW_ACCEPTANCE_STATIC_MANIFEST
source "$job/env.sh"
export SOURCE_ROOT="$source_job/source"
export PYTHONPATH="$SOURCE_ROOT:$SOURCE_ROOT/tests/pypto_test:$PYTHONPATH"
export PYTHONPATH="$job:$PYTHONPATH"
export ADMISSION_TRACE_DIR="$out/input-trace" FULL_PROBE_DIR="$out/full-probe"
if [[ "$phase" == native-control ]]; then
 unset ADMISSION_REFERENCE
else
 export ADMISSION_REFERENCE="$base/retest192-20261016/native1-generation-reference/input-trace"
fi
python "$job/source_preflight.py"
python "$job/check_inputs.py"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/align128.XXXXXX)
trap 'rmdir "$TMPDIR" 2>/dev/null || true' EXIT
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$SOURCE_ROOT/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$out/opp_env")
export PYPTO_PROG_BUILD_DIR="$out/build" ASCEND_CACHE_PATH="$out/ascend-cache"
export ASCEND_PROCESS_LOG_PATH="$out/ascend" VLLM_CACHE_ROOT="$out/vllm-cache"
mkdir -p "$ASCEND_PROCESS_LOG_PATH" "$ASCEND_CACHE_PATH"
backend=native
if [[ "$phase" == precision-witness ]]; then backend=pto; fi
python - "$out" "$backend" "$bank" "$SOURCE_ROOT" "$old" "$job" "$source_job" <<'PYMETA'
import hashlib,json,sys,os
from pathlib import Path
out,backend,bank,source,old,job,source_job=sys.argv[1:]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
config={'backend':backend,'test_harness_patch':'complete PTO CSA with verified static selection reuse; unchanged 128K input and generation gates; outer control first-difference stop','attention':'csa','variant':'tnd_full_precision','bank':bank,'batch':24,'snapshot':source,'snapshot_manifest':str(Path(source_job)/'manifest.json'),'production_git_commit':'94feb6a2f+single-entry-DSL-candidate','single_pto_entry':True,'handwritten_cpp':False,'wkv_restored':True,'indexer_projection_restored':True,'indexer_order_map_sha256':'700c26586fe104bf92ffbb5d6eba74d307ba4c67df9eeac08363c729d2ec71fc','wkv_order_map_sha256':'ba7885227b29b521f7dcbde69ff79bc4bf6c706c1942c59985a01ee323ae7255','decode_tokens':192,'event_work_mode':1,'num_gpu_blocks_override':24000,'gpu_memory_utilization':0.97,'source_manifest_sha256':sha(Path(source_job)/'manifest.json'),'official_static_cache_sha256':sha(Path(old)/'official-static-cache/metadata.json'),'bank_plan_sha256':sha(Path(bank)/'plan.json'),'capture_sizes':[6,144],'max_num_batched_tokens':400,'runtime_package_manifest_sha256':sha(Path(os.environ['LOW_ACCEPTANCE_RUNTIME_PACKAGE'])/'manifest.json'),'runtime_package':os.environ['LOW_ACCEPTANCE_RUNTIME_PACKAGE'],'generation_window_sha256':sha(Path(job)/'generation_window.py'),'generation_reference_manifest_sha256':sha(Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/retest192-20261016/native1-generation-reference/manifest.json')) if os.environ.get('ADMISSION_REFERENCE') else None,'trace_helper_sha256':sha(Path(job)/'admission_trace.py'),'bootstrap_sha256':sha(Path(job)/'sitecustomize.py'),'trace_reference':os.environ.get('ADMISSION_REFERENCE'),'full_probe_mode':os.environ['FULL_PROBE_MODE'],'full_probe_sha256':sha(Path(job)/'full_probe.py'),'witness_sha256':sha(Path(job)/'capture_boundaries.py'),'outer_reference':os.environ.get('FULL_PROBE_OUTER_REFERENCE'),'stage_reference':os.environ.get('FULL_PROBE_STAGE_REFERENCE')}
config.update(oproj_restored=True,oproj_order_map_sha256='2c6ed88f69024a894543228a818cc5e7a4081ffacbceebb9fec5452a2b187686',qualified_helper_sha256=sha(Path(job)/'qualified_wkv.py'),helper_manifest_sha256=sha(Path(job)/'helper-manifest.json'))
(Path(out)/'configuration.json').write_text(json.dumps(config,indent=2)+'\n')
PYMETA
cd "$out"
python "$SOURCE_ROOT/tests/pypto_test/offline_pd/run.py" decode --output "$out" --backend "$backend" \
 --pto-attention csa --mixed-requests --batch 24 --decode-dp 16 --max-num-batched-tokens 400 \
 --weight-nz-mode 2 --deterministic --port 30981 --gpu-memory-utilization 0.97 --event-work-mode 1 \
 --bank "$bank" --decode-tokens 192 --graph-mode full_decode_only --capture-sizes 6 144 > "$out/launch.log" 2>&1
python "$SOURCE_ROOT/tests/pypto_test/low_acceptance_20261001/mixed.py" \
 --root "$out" --bank "$bank" --batch 24 --tokens 192 > "$out/acceptance_summary.log"
