"""复用原逐轮输入/token/event/outer门禁；源码身份允许且明确记录本次变更。"""
from pathlib import Path
import os,runpy
import argparse,hashlib,json
from audit_alignment import audit
from full_probe import load_reference
p=argparse.ArgumentParser();p.add_argument('--native',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
job=Path(__file__).resolve().parent
base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
assert a.native.resolve()==Path('/data/pyptouser/yejia/lc128/full-pto8k-native-20261016')
right=json.loads((a.candidate/'configuration.json').read_text())
assert right['snapshot']==str(base/'full-dsl-single-entry-20261018/single-v1/source')
assert right['outer_reference']==str(base/'full-pto-model-8k-b40-20261016/native1-generation-reference/full-probe')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert right['source_manifest_sha256']==json.loads((job/'candidate-binding.json').read_text())['source_manifest_sha256']
assert right['helper_manifest_sha256']==sha(job/'helper-manifest.json')
for key,name in [('bootstrap_sha256','sitecustomize.py'),('qualified_helper_sha256','qualified_wkv.py'),('trace_helper_sha256','admission_trace.py'),('full_probe_sha256','full_probe.py'),('generation_window_sha256','generation_window.py')]:assert right[key]==sha(job/name),key
os.environ['SOURCE_ROOT']=right['snapshot']
runpy.run_path(str(job/'verify_single_assets.py'),run_name='__main__')
left,lt,lo,la,lv=audit(a.native,require_ready_reuse=False);right,rt,ro,ra,rv=audit(a.candidate,require_ready_reuse=False)
assert left['backend']=='native' and right['backend']=='pto'
for k in ('bank','batch','decode_tokens','event_work_mode','num_gpu_blocks_override','gpu_memory_utilization','official_static_cache_sha256','bank_plan_sha256','bank_input_proof_sha256','capture_sizes','max_num_batched_tokens','runtime_package_manifest_sha256','runtime_package'):
 assert left[k]==right[k],k
assert right['single_pto_entry'] and right['handwritten_cpp'] is False
manifest=Path(right['snapshot_manifest']);assert hashlib.sha256(manifest.read_bytes()).hexdigest()==right['source_manifest_sha256']
for name,sha in json.loads(manifest.read_text())['files'].items():assert hashlib.sha256((Path(right['snapshot'])/name).read_bytes()).hexdigest()==sha,name
assert lt==rt,'all-rank actual admission/inputs differ'
assert lo==ro and la==ra,'tokens/events differ'
reference=load_reference(Path(right['outer_reference']),'outer.jsonl');observed=load_reference(a.candidate/'full-probe','outer.jsonl')
assert observed==reference,'actual FULL target/aux/MTP hidden differs'
for rank in range(16):
 data=json.loads((a.candidate/f'rank{rank}.mixed.json').read_text());q=data['observation'][0]['full_pto_qualification']
 assert q['ready'] and q['actual_reselections']==1 and q['validated_reuses']>0
 assert set(q['single_root_counts'])==set(q['expected_layer_names']) and len(q['single_root_counts'])==21
 assert q['root_namespace']=='dsv4_csa_tnd_full_precision::attention'
 assert q['root_abi_tensors']==62
 cache=data['observation'][0]['pypto_cache_stats']
 assert all(cache[k]==0 for k in ('bypasses','invalid_entries','storage_errors','forced_rebuilds'))
 for name,sizes in q['single_root_counts'].items():
  for t in ('6','240'):assert sizes[t]['warmup']>0 and sizes[t]['capture']>0,(rank,name,t)
report={'pass':True,'scope':'real full model fixed8K B40 192token,21CSA complete pureDSL single roots; Native HCA/FFN preserved','inputs_equal_all16ranks':True,'tokens_events_equal_all16ranks':True,'rank0_target_aux_mtp_bit_equal':True,'root_warmup_capture_all21layers_all16ranks':True,'ready_reuse_required':False,'actual_admission':rv,'acceptance':{k:v for k,v in ra.items() if k!='requests'},'source_manifest_sha256':right['source_manifest_sha256'],'baseline_source_manifest_sha256':left['source_manifest_sha256'],'configuration':right}
a.out.write_text(json.dumps(report,indent=2)+'\n');print('FULL_SINGLE_DSL_8K_PASS')
