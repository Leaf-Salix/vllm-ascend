"""Read-only binding to the original Native1, production files and unchanged oracles."""
import hashlib
import json
import os
from pathlib import Path

BASE = Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
JOB = Path(__file__).resolve().parent
OLD = BASE/'full-pto-model-8k-b40-20261016'
REF = OLD/'native1-generation-reference'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(REF/'manifest.json') == 'be6ba496d189c91f9c40fcea5d8d73c68577d646fb34ea203add5612297c2834'
r = json.loads((REF/'manifest.json').read_text())
native = Path(r['raw_source'])
assert native == Path('/data/pyptouser/yejia/lc128/full-pto8k-native-20261016')
assert r['window_records'] == 51 and r['output_requests'] == 640 and r['output_tokens'] == 122880
for name,digest in r['source_sha256'].items(): assert sha(native/name) == digest, name
for name,digest in r['derived_sha256'].items(): assert sha(REF/name) == digest, name
for name in ('admission_trace.py','generation_window.py','full_probe.py','capture_boundaries.py','audit_alignment.py'):
    assert (JOB/name).read_bytes() == (OLD/name).read_bytes(), name
source=Path(os.environ['SOURCE_ROOT']); assert sha(source.parent/'manifest.json')==json.loads((JOB/'candidate-binding.json').read_text())['source_manifest_sha256']
manifest=json.loads((source.parent/'manifest.json').read_text())
for name,digest in manifest['files'].items(): assert sha(source/name)==digest,name
for name,digest in json.loads((JOB/'helper-manifest.json').read_text())['files'].items(): assert sha(JOB/name)==digest,name
package=source/'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision'
assert not list(package.glob('*.cpp')), 'Handwritten C++ in selected variant'
assert not any('jit.extern' in p.read_text() for p in package.glob('*.py'))
meta = BASE/'low-acceptance-20261010/official-static-cache/metadata.json'
assert sha(meta) == '863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
left = json.loads((native/'configuration.json').read_text())
assert left['production_git_commit'] == '259cf9a5f'
assert left['bank'] == str(BASE/'low-acceptance-20261010/banks/fixed8192')
assert left['official_static_cache_sha256'] == sha(meta)
assert left['bank_input_proof_sha256'] == sha(JOB/'bank-input-qualified.json')
assert left['num_gpu_blocks_override'] == 22000 and left['capture_sizes'] == [6,240]
assert left['batch'] == 40 and left['decode_tokens'] == 192
print('ASSETS_BOUND Native1=1 requests=640 tokens=122880 rounds=51 single_entry_all_DSL_candidate=1')
