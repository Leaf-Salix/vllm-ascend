#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
job="$base/full-dsl-single-entry-20261018/hcpre-v2"
source "$base/root-fix-20261016/env.sh"
export SOURCE_ROOT="$base/full-pto-8k-b40-20261018/step12/source"
export PYTHONPATH="$job:$SOURCE_ROOT:$SOURCE_ROOT/tests/pypto_test:$PYTHONPATH"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE" LOCAL_WORLD_SIZE=1 PYTHONNOUSERSITE=1 HCCL_DETERMINISTIC=true OMP_NUM_THREADS=4
export CCACHE_DIR=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/pypto/.ccache CMAKE_BUILD_PARALLEL_LEVEL=4
export PYPTO_PROG_BUILD_DIR="$job/run-build" PYPTO_CACHE_DIR="$job/cache"
ccache -s
out=/data/pyptouser/yejia/fpdsl/hcpre-v2
mkdir -p /data/pyptouser/yejia/fpdsl
python "$job/probe_hcpre.py" --out "$out" > "$job/run.log" 2>&1
