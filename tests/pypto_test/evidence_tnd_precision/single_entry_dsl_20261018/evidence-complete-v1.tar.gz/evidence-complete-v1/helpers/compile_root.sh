#!/usr/bin/env bash
set -euo pipefail
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
job="$base/full-dsl-single-entry-20261018"
source "$base/root-fix-20261016/env.sh"
export SOURCE_ROOT="$job/single-v1/source"
export PYTHONPATH="$SOURCE_ROOT:$SOURCE_ROOT/tests/pypto_test:$PYTHONPATH"
export PYTHONNOUSERSITE=1 ASCEND_RT_VISIBLE_DEVICES="" TORCH_DEVICE_BACKEND_AUTOLOAD=0
export CCACHE_DIR=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/pypto/.ccache CMAKE_BUILD_PARALLEL_LEVEL=4
export PYPTO_PROG_BUILD_DIR="$job/single-v1/build" PYPTO_CACHE_DIR="$job/single-v1/cache"
export PTO_CSA_VARIANT=tnd_full_precision
ccache -s
python "$job/compile_root.py"
