"""仅诊断参考：此前通过Native workspace核验的冻结HF32 extern。"""
import pypto.language as pl
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.hc_pre import hc_pre_linear_hf32
T=pl.dynamic('HCREF_T');R=pl.dynamic('HCREF_R')
@pl.jit
def reference_linear(flat:pl.Tensor[[T,16384],pl.FP32],weight:pl.Tensor[[24,16384],pl.FP32],out:pl.Out[pl.Tensor[[R,32],pl.FP32]]):
    flat.bind_dynamic(0,T)
    out.bind_dynamic(0,R)
    tokens=pl.tensor.dim(flat,0)
    padded=pl.tensor.dim(out,0)//22
    units=(padded//16)*22
    workers=pl.min(units,24)
    with pl.spmd(workers):
        out=hc_pre_linear_hf32(out,flat,weight,units,workers,tokens,padded)
    return out
