"""真实权重HC-pre纯DSL：先分片首差，再三输出，raw graph A/B/A/zero。"""
import argparse,json,hashlib,os,time
from pathlib import Path
import torch,torch_npu,pypto,pypto.torch
from safetensors import safe_open
from vllm_ascend.utils import enable_custom_op
from hc_pre import hc_pre_test,hcpre_linear_test
from linear_reference import reference_linear
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--tokens',type=int,nargs='+',default=[1,11]);a=p.parse_args();a.out.mkdir()
report={'pass':False,'complete':False,'scope':'actual Native HC-pre three outputs, real L4 weights + synthetic BF16 hidden; frozen aligned HF32 extern only diagnostic partial reference','tokens':a.tokens,'checks':[],'task_device':os.environ['TASK_DEVICE'],'pypto':pypto.__file__}
def save():(a.out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
def cpu(x):torch.npu.synchronize();return x.detach().cpu().clone()
def exact(x,y):return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def check(label,actual,gold):
 bad={}
 for k,v in actual.items():
  assert v.shape==gold[k].shape and v.dtype==gold[k].dtype,k+' shape/dtype'
  assert torch.isfinite(v).all() and torch.isfinite(gold[k]).all(),k+' nonfinite'
  bad[k]=int((v.contiguous().view(torch.int16 if v.dtype==torch.bfloat16 else torch.int32)!=gold[k].contiguous().view(torch.int16 if v.dtype==torch.bfloat16 else torch.int32)).sum())
 report['checks'].append({'label':label,'different':bad,'elapsed_s':time.monotonic()-started});save()
 if any(bad.values()):torch.save({'actual':actual,'expected':gold,'hidden':cpu(hidden),'weights':{k:cpu(v) for k,v in weights.items()}},a.out/'first-difference.pt');raise RuntimeError('FIRST_BIT_DIFFERENCE '+label)
torch.npu.set_device(0);torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4);assert enable_custom_op()
model=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8');cfg=json.loads((model/'config.json').read_text());index=json.loads((model/'quant_model_weights.safetensors.index.json').read_text())['weight_map'];weights={}
for name in ('hc_attn_fn','hc_attn_scale','hc_attn_base'):
 key='layers.4.'+name
 with safe_open(model/index[key],framework='pt',device='cpu') as f:v=f.get_tensor(key)
 assert v.dtype==torch.float32
 report.setdefault('weights',{})[key]=hashlib.sha256(v.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest();weights[name]=v.to('npu')
before_weights={k:cpu(v) for k,v in weights.items()}
pypto.torch.init(device=0,platform='a2a3',runtime='tensormap_and_ringbuffer')
linear=pypto.torch.register(hcpre_linear_test,'full_dsl_hcpre_20261018::linear');reference=pypto.torch.register(reference_linear,'full_dsl_hcref_20261018::linear');op=pypto.torch.register(hc_pre_test,'full_dsl_hcpre_20261018::forward')
started=time.monotonic();save()
try:
 with torch.inference_mode():
  for n in a.tokens:
   hidden=torch.randn((n,4,4096),generator=torch.Generator().manual_seed(17+n),dtype=torch.bfloat16).to('npu');original=hidden.clone();flat=hidden.float().reshape(n,16384);pad=((n+15)//16)*16
   owners={'mixed':torch.full((n+2,4096),.0625,dtype=torch.bfloat16,device='npu'),'post':torch.full((n+2,4),.0625,dtype=torch.float32,device='npu'),'comb':torch.full((n+2,16),.0625,dtype=torch.float32,device='npu'),'partials':torch.full((22*pad+2,32),.0625,dtype=torch.float32,device='npu')}
   outs={k:v[1:-1] for k,v in owners.items()};ref=torch.empty_like(outs['partials'])
   def partial():linear(flat,weights['hc_attn_fn'],outs['partials'])
   def full():op(hidden,*weights.values(),outs['mixed'],outs['post'],outs['comb'])
   def observed(partial_only=False):
    assert exact(cpu(hidden),expected_hidden) and exact(cpu(flat),expected_hidden.float().reshape(n,16384)),'input mutation'
    assert all(exact(cpu(v),before_weights[k]) for k,v in weights.items()),'weight mutation'
    for k,v in owners.items():assert bool((cpu(v[[0,-1]])==.0625).all()),k+' guard'
    if partial_only:return {'partials':cpu(outs['partials']).reshape(22,pad,32)[:,:n,:24].contiguous()}
    return {k:cpu(outs[k]) for k in ('mixed','post','comb')}
   def partial_gold():reference(flat,weights['hc_attn_fn'],ref);return {'partials':cpu(ref).reshape(22,pad,32)[:,:n,:24].contiguous()}
   def gold():return {k:cpu(v) for k,v in zip(('mixed','post','comb'),torch.ops._C_ascend.npu_hc_pre_v2(hidden,*weights.values(),4,cfg['hc_sinkhorn_iters'],cfg['rms_norm_eps'],cfg['hc_eps']))}
   expected_hidden=cpu(hidden);expected=partial_gold();partial();check(f'T{n}/partial/eager/A',observed(True),expected)
   expected=gold();full();check(f'T{n}/three/eager/A',observed(),expected)
   graph=torch.npu.NPUGraph()
   with torch.npu.graph(graph):partial();full()
   for phase in ('A','B','A_restored','zero'):
    hidden.copy_(original)
    if phase=='B':hidden.add_(.125)
    if phase=='zero':hidden.zero_()
    flat.copy_(hidden.float().reshape(n,16384));expected_hidden=cpu(hidden);pg=partial_gold();g=gold()
    if phase=='A':a_hidden=expected_hidden.clone();a_mixed=g['mixed'].clone()
    if phase=='B':assert not exact(a_hidden,expected_hidden) and not exact(a_mixed,g['mixed']),'B unchanged'
    for v in outs.values():v.fill_(float('nan'))
    graph.replay();check(f'T{n}/partial/graph/{phase}',observed(True),pg);check(f'T{n}/three/graph/{phase}',observed(),g)
  report['pass']=report['complete']=True;save()
except Exception as e:report['error']=repr(e);save();raise
