#!/usr/bin/env bash
set -euo pipefail
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
job="$base/full-dsl-single-entry-20261018"
source "$base/root-fix-20261016/env.sh"
export PYTHONNOUSERSITE=1 ASCEND_RT_VISIBLE_DEVICES="" TORCH_DEVICE_BACKEND_AUTOLOAD=0
export CCACHE_DIR=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/pypto/.ccache CMAKE_BUILD_PARALLEL_LEVEL=4
export PYPTO_PROG_BUILD_DIR="$job/sum9-v1/build" PYPTO_CACHE_DIR="$job/sum9-v1/cache"
export PYTHONPATH="$job/sum9-v1:$PYTHONPATH"
ccache -s
python "$job/sum9-v1/compile_sum9.py"
