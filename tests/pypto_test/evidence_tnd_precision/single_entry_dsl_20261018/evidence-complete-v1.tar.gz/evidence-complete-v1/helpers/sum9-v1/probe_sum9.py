"""独立整数gold验证现有DSL的FP32展开；首bit差异退出。"""
from pathlib import Path
import argparse,json,os,hashlib,numpy as np,torch,torch_npu,pypto,pypto.torch
from sum9 import sum9_test
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir()
report={'pass':False,'complete':False,'scope':'FP32 nine-term primitive vs CPU exact integer oracle, no whole-model claim','checks':[],'pypto':pypto.__file__}
def save():(a.out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
def cpu(x):torch.npu.synchronize();return x.detach().cpu().clone()
fixture=Path(__file__).with_name('fixture.npz');data=np.load(fixture);report['fixture_sha256']=hashlib.sha256(fixture.read_bytes()).hexdigest()
x_a=torch.from_numpy(data['values'].view(np.float32).copy());y_a=torch.from_numpy(data['expected'].view(np.float32).copy())
torch.npu.set_device(0);torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1)
pypto.torch.init(device=0,platform='a2a3',runtime='tensormap_and_ringbuffer');op=pypto.torch.register(sum9_test,'full_dsl_sum9_20261018::forward')
save()
try:
 with torch.inference_mode():
  for n in (1,17,750):
   original=x_a[:n*9].to('npu');x=original.clone();owner=torch.full((n+2,32),.0625,dtype=torch.float32,device='npu');y=owner[1:-1]
   def check(label,gold):
    actual=cpu(y);assert actual.shape==gold.shape and actual.dtype==gold.dtype
    assert torch.isfinite(actual).all() and torch.isfinite(gold).all()
    assert torch.equal(cpu(x),expected_x),'input mutation'
    assert bool((cpu(owner[[0,-1]])==.0625).all()),'output guard'
    bad=int((actual.view(torch.int32)!=gold.view(torch.int32)).sum());report['checks'].append({'label':label,'different':bad});save()
    if bad:torch.save({'input':cpu(x),'actual':actual,'expected':gold},a.out/'first-difference.pt');raise RuntimeError('FIRST_BIT_DIFFERENCE '+label)
   expected_x=cpu(x);op(x,y);check(f'B{n}/eager/A',y_a[:n])
   graph=torch.npu.NPUGraph()
   with torch.npu.graph(graph):op(x,y)
   for phase in ('A','B','A_restored','zero'):
    x.copy_(original);gold=y_a[:n]
    if phase=='B':x.neg_();gold=-gold
    if phase=='zero':x.zero_();gold=torch.zeros_like(gold)
    expected_x=cpu(x);y.fill_(float('nan'));graph.replay();check(f'B{n}/graph/{phase}',gold)
  report['pass']=report['complete']=True;save()
except Exception as e:report['error']=repr(e);save();raise
