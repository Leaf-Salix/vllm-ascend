#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qproj_matmul(__gm__ int32_t* v1, __gm__ int8_t* v2, __gm__ int8_t* v3, int64_t v4, int64_t v5, int64_t v6, int64_t v7, int32_t v8, int32_t v9) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int64_t v10 = 151;
  // pto: %c0_i64
  const int64_t v11 = 0;
  // pto: %c262144_i64
  const int64_t v12 = 262144;
  // pto: %c8192_i64
  const int64_t v13 = 8192;
  // pto: %c32768_i64
  const int64_t v14 = 32768;
  // pto: %c32768_index
  const int64_t v15 = 32768;
  // pto: %c1_index
  const int64_t v16 = 1;
  // pto: %c1024_index
  const int64_t v17 = 1024;
  // pto: %c64_index
  const int64_t v18 = 64;
  // pto: %c16_index
  const int64_t v19 = 16;
  // pto: %c32_index
  const int64_t v20 = 32;
  // pto: %c33554432_index
  const int64_t v21 = 33554432;
  // pto: %c512_index
  const int64_t v22 = 512;
  // pto: %c0_index
  const int64_t v23 = 0;
  // pto: %c128_index
  const int64_t v24 = 128;
  // pto: %c24_index
  const int64_t v25 = 24;
  // pto: %c256_index
  const int64_t v26 = 256;
  // pto: %cn128_index
  const int64_t v27 = -128;
  // pto: %q_proj_i32_inline7_inline4582__ssa_v0_view
  const int64_t v28 = 1;
  // pto: %q_proj_i32_inline7_inline4582__ssa_v0_view
  const int64_t v29 = 1;
  // pto: %q_proj_i32_inline7_inline4582__ssa_v0_view
  const int64_t v30 = 1;
  // pto: %q_proj_i32_inline7_inline4582__ssa_v0_view
  int64_t v31 = (int64_t) v7;
  // pto: %q_proj_i32_inline7_inline4582__ssa_v0_view
  int64_t v32 = v31 * v15;
  // pto: %q_proj_i32_inline7_inline4582__ssa_v0_view
  int64_t v33 = v30 * v32;
  // pto: %q_proj_i32_inline7_inline4582__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v34 = pto::Shape<1, 1, 1, -1, -1>(v28, v29, v30, v31, v15);
  // pto: %q_proj_i32_inline7_inline4582__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v35 = pto::Stride<-1, -1, -1, -1, -1>(v29 * v33, v33, v32, v15, v16);
  // pto: %q_proj_i32_inline7_inline4582__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v36 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v34, v35);
  // pto: %wq_b__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v37 = pto::Shape<-1, -1, -1, -1, -1>(v16, v17, v18, v19, v20);
  // pto: %wq_b__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v38 = pto::Stride<-1, -1, -1, -1, -1>(v21, v15, v22, v20, v16);
  // pto: %wq_b__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v39 = GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v2, v37, v38);
  // pto: %qr_i8_matmul_inline4569__rv_v2_view
  const int64_t v40 = 1;
  // pto: %qr_i8_matmul_inline4569__rv_v2_view
  const int64_t v41 = 1;
  // pto: %qr_i8_matmul_inline4569__rv_v2_view
  const int64_t v42 = 1;
  // pto: %qr_i8_matmul_inline4569__rv_v2_view
  int64_t v43 = v22 * v17;
  // pto: %qr_i8_matmul_inline4569__rv_v2_view
  int64_t v44 = v42 * v43;
  // pto: %qr_i8_matmul_inline4569__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v45 = pto::Shape<1, 1, 1, -1, -1>(v40, v41, v42, v22, v17);
  // pto: %qr_i8_matmul_inline4569__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v46 = pto::Stride<-1, -1, -1, -1, -1>(v41 * v44, v44, v43, v17, v16);
  // pto: %qr_i8_matmul_inline4569__rv_v2_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v47 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v45, v46);
  // pto: %qproj_worker_inline8233__ssa_v0
  int64_t v48 = (int64_t) v8;
  // pto: %8
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  for (int64_t v49 = v23; v49 < ((int64_t) ((uint64_t) v10 - (uint64_t) v48) / v25); v49 += v16) {
    // pto: %10, %9, %11
    ;
    int64_t v50 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v48 + (uint64_t) ((int64_t) (uint64_t) v49 * (uint64_t) v25)) * (uint64_t) v26);
    // pto: %wq_full_inline8232__tile
    ;
    Tile<TileType::Mat, int8_t, 1024, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v51 = Tile<TileType::Mat, int8_t, 1024, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v26);
    // pto: %wq_full_inline8232__tile
    ;
    uint64_t v52 = (uint64_t) v11;
    TASSIGN(v51, v52);
    // pto: %12
    ;
    int64_t v53 = v50 / v20;
    // pto: %13
    ;
    int64_t v54 = v53 < v23 ? v23 : v53;
    // pto: %wq_b__ssa_v0_pview
    ;
    __gm__ int8_t* v55 = PTOAS__GLOBAL_TENSOR_DATA(v39);
    // pto: %wq_b__ssa_v0_pview
    ;
    const int64_t v56 = 0;
    // pto: %wq_b__ssa_v0_pview
    ;
    const int64_t v57 = 32768;
    // pto: %wq_b__ssa_v0_pview
    ;
    pto::Shape<1, 8, 64, 16, 32> v58 = pto::Shape<1, 8, 64, 16, 32>();
    // pto: %wq_b__ssa_v0_pview
    ;
    pto::Stride<33554432, 32768, 512, 32, 1> v59 = pto::Stride<33554432, 32768, 512, 32, 1>();
    // pto: %wq_b__ssa_v0_pview
    ;
    GlobalTensor<int8_t, pto::Shape<1, 8, 64, 16, 32>, pto::Stride<33554432, 32768, 512, 32, 1>, pto::Layout::NZ> v60 = GlobalTensor<int8_t, pto::Shape<1, 8, 64, 16, 32>, pto::Stride<33554432, 32768, 512, 32, 1>, pto::Layout::NZ>(v55 + (v56 + v54 * v57), v58, v59);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v51, v60);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    for (int64_t v61 = v23; v61 < v4; v61 += v18) {
      // pto: %qr_full_inline8237__tile
      ;
      Tile<TileType::Mat, int8_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v62 = Tile<TileType::Mat, int8_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v17);
      // pto: %qr_full_inline8237__tile
      ;
      uint64_t v63 = (uint64_t) v12;
      TASSIGN(v62, v63);
      // pto: %14
      ;
      int64_t v64 = v61 < v23 ? v23 : v61;
      // pto: %qr_i8_matmul_inline4569__rv_v2_pview
      ;
      __gm__ int8_t* v65 = PTOAS__GLOBAL_TENSOR_DATA(v47);
      // pto: %qr_i8_matmul_inline4569__rv_v2_pview
      ;
      const int64_t v66 = 0;
      // pto: %qr_i8_matmul_inline4569__rv_v2_pview
      ;
      const int64_t v67 = 1024;
      // pto: %qr_i8_matmul_inline4569__rv_v2_pview
      ;
      pto::Shape<1, 1, 1, 64, 1024> v68 = pto::Shape<1, 1, 1, 64, 1024>();
      // pto: %qr_i8_matmul_inline4569__rv_v2_pview
      ;
      pto::Stride<65536, 65536, 65536, 1024, 1> v69 = pto::Stride<65536, 65536, 65536, 1024, 1>();
      // pto: %qr_i8_matmul_inline4569__rv_v2_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, 64, 1024>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND> v70 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 64, 1024>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND>(v65 + (v66 + v64 * v67), v68, v69);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v62, v70);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %col_acc_inline8239__tile_l0_init
      ;
      Tile<TileType::Acc, int32_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v71 = Tile<TileType::Acc, int32_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v18, v26);
      // pto: %col_acc_inline8239__tile_l0_init
      ;
      uint64_t v72 = (uint64_t) v11;
      TASSIGN(v71, v72);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
      for (int64_t v73 = v23; v73 < v17; v73 += v26) {
        // pto: %col_acc_inline8239__tile_l0_a
        ;
        Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v74 = Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v24);
        // pto: %col_acc_inline8239__tile_l0_a
        ;
        uint64_t v75 = (uint64_t) v11;
        TASSIGN(v74, v75);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        pipe_barrier(PIPE_MTE1);
        uint16_t v76 = static_cast<uint16_t>(v23);
        uint16_t v77 = static_cast<uint16_t>(v73);
        TEXTRACT(v74, v62, v76, v77);
        // pto: %col_acc_inline8239__tile_l0_b
        ;
        Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v78 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v24, v26);
        // pto: %col_acc_inline8239__tile_l0_b
        ;
        uint64_t v79 = (uint64_t) v11;
        TASSIGN(v78, v79);
        uint16_t v80 = static_cast<uint16_t>(v73);
        uint16_t v81 = static_cast<uint16_t>(v23);
        TEXTRACT(v78, v51, v80, v81);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %0
        ;
        Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v82 = Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v24);
        // pto: %0
        ;
        uint64_t v83 = (uint64_t) v13;
        TASSIGN(v82, v83);
        // pto: %15
        ;
        int64_t v84 = (int64_t) ((uint64_t) v73 + (uint64_t) v24);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v85 = static_cast<uint16_t>(v23);
        uint16_t v86 = static_cast<uint16_t>(v84);
        TEXTRACT(v82, v62, v85, v86);
        // pto: %1
        ;
        Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v87 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v24, v26);
        // pto: %1
        ;
        uint64_t v88 = (uint64_t) v14;
        TASSIGN(v87, v88);
        uint16_t v89 = static_cast<uint16_t>(v84);
        uint16_t v90 = static_cast<uint16_t>(v23);
        TEXTRACT(v87, v51, v89, v90);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %17
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        if (v73 == v23) {
          pipe_barrier(PIPE_M);
          TMATMUL(v71, v74, v78);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v71, v71, v74, v78);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        // pto: %18
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        if (v73 == v27) {
          pipe_barrier(PIPE_M);
          TMATMUL(v71, v82, v87);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v71, v71, v82, v87);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %20
      ;
      int64_t v91 = v50 < v23 ? v23 : v50;
      // pto: %q_proj_i32_inline7_inline4582__iter_v3_pview
      ;
      __gm__ int32_t* v92 = PTOAS__GLOBAL_TENSOR_DATA(v36);
      // pto: %q_proj_i32_inline7_inline4582__iter_v3_pview
      ;
      const int64_t v93 = 0;
      // pto: %q_proj_i32_inline7_inline4582__iter_v3_pview
      ;
      const int64_t v94 = 32768;
      // pto: %q_proj_i32_inline7_inline4582__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, 64, 256> v95 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %q_proj_i32_inline7_inline4582__iter_v3_pview
      ;
      pto::Stride<2097152, 2097152, 2097152, 32768, 1> v96 = pto::Stride<2097152, 2097152, 2097152, 32768, 1>();
      // pto: %q_proj_i32_inline7_inline4582__iter_v3_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<2097152, 2097152, 2097152, 32768, 1>, pto::Layout::ND> v97 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<2097152, 2097152, 2097152, 32768, 1>, pto::Layout::ND>(v92 + (v93 + v64 * v94 + v91), v95, v96);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      pipe_barrier(PIPE_FIX);
      TSTORE(v97, v71);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
    };
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
    for (int64_t v98 = v4; v98 < v5; v98 += v18) {
      // pto: %21
      ;
      int64_t v99 = (int64_t) ((uint64_t) v6 - (uint64_t) v98);
      // pto: %22
      ;
      int64_t v100 = v99 < v18 ? v99 : v18;
      // pto: %qr_tail_inline8227__tile
      ;
      Tile<TileType::Mat, int8_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Mat, int8_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v100, v17);
      // pto: %qr_tail_inline8227__tile
      ;
      uint64_t v102 = (uint64_t) v12;
      TASSIGN(v101, v102);
      // pto: %23
      ;
      int64_t v103 = v98 < v23 ? v23 : v98;
      // pto: %24
      ;
      const int64_t v104 = 0;
      // pto: %24
      ;
      __gm__ int8_t* v105 = PTOAS__GLOBAL_TENSOR_DATA(v47);
      // pto: %24
      ;
      const int64_t v106 = 1;
      // pto: %24
      ;
      const int64_t v107 = 1;
      // pto: %24
      ;
      const int64_t v108 = 1;
      // pto: %24
      ;
      int64_t v109 = v100 * v17;
      // pto: %24
      ;
      int64_t v110 = v108 * v109;
      // pto: %24
      ;
      pto::Shape<1, 1, 1, -1, 1024> v111 = pto::Shape<1, 1, 1, -1, 1024>(v106, v107, v108, v100, v17);
      // pto: %24
      ;
      pto::Stride<-1, -1, -1, -1, -1> v112 = pto::Stride<-1, -1, -1, -1, -1>(v107 * v110, v110, v109, v17, v16);
      // pto: %24
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v113 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v105 + (v104 + v103 * v17 + v23 * v16), v111, v112);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v101, v113);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %tail_acc_inline8240__tile_l0_init_storage
      ;
      Tile<TileType::Acc, int32_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v114 = Tile<TileType::Acc, int32_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v18, v26);
      // pto: %tail_acc_inline8240__tile_l0_init_storage
      ;
      uint64_t v115 = (uint64_t) v11;
      TASSIGN(v114, v115);
      v114.SetValidShape(v100, v26);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
      for (int64_t v116 = v23; v116 < v17; v116 += v26) {
        // pto: %tail_acc_inline8240__tile_l0_a
        ;
        Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v117 = Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v100, v24);
        // pto: %tail_acc_inline8240__tile_l0_a
        ;
        uint64_t v118 = (uint64_t) v11;
        TASSIGN(v117, v118);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        uint16_t v119 = static_cast<uint16_t>(v23);
        uint16_t v120 = static_cast<uint16_t>(v116);
        TEXTRACT(v117, v101, v119, v120);
        // pto: %tail_acc_inline8240__tile_l0_b
        ;
        Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v24, v26);
        // pto: %tail_acc_inline8240__tile_l0_b
        ;
        uint64_t v122 = (uint64_t) v11;
        TASSIGN(v121, v122);
        uint16_t v123 = static_cast<uint16_t>(v116);
        uint16_t v124 = static_cast<uint16_t>(v23);
        TEXTRACT(v121, v51, v123, v124);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %3
        ;
        Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v125 = Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v100, v24);
        // pto: %3
        ;
        uint64_t v126 = (uint64_t) v13;
        TASSIGN(v125, v126);
        // pto: %25
        ;
        int64_t v127 = (int64_t) ((uint64_t) v116 + (uint64_t) v24);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        uint16_t v128 = static_cast<uint16_t>(v23);
        uint16_t v129 = static_cast<uint16_t>(v127);
        TEXTRACT(v125, v101, v128, v129);
        // pto: %4
        ;
        Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v24, v26);
        // pto: %4
        ;
        uint64_t v131 = (uint64_t) v14;
        TASSIGN(v130, v131);
        pipe_barrier(PIPE_MTE1);
        uint16_t v132 = static_cast<uint16_t>(v127);
        uint16_t v133 = static_cast<uint16_t>(v23);
        TEXTRACT(v130, v51, v132, v133);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        // pto: %27
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        if (v116 == v23) {
          pipe_barrier(PIPE_M);
          TMATMUL(v114, v117, v121);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v114, v114, v117, v121);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        // pto: %28
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        if (v116 == v27) {
          pipe_barrier(PIPE_M);
          TMATMUL(v114, v125, v130);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v114, v114, v125, v130);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      };
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      // pto: %31
      ;
      int64_t v134 = v50 < v23 ? v23 : v50;
      // pto: %q_proj_i32_inline7_inline4582__iter_v6_pview
      ;
      const int64_t v135 = 0;
      // pto: %q_proj_i32_inline7_inline4582__iter_v6_pview
      ;
      __gm__ int32_t* v136 = PTOAS__GLOBAL_TENSOR_DATA(v36);
      // pto: %q_proj_i32_inline7_inline4582__iter_v6_pview
      ;
      const int64_t v137 = 1;
      // pto: %q_proj_i32_inline7_inline4582__iter_v6_pview
      ;
      const int64_t v138 = 1;
      // pto: %q_proj_i32_inline7_inline4582__iter_v6_pview
      ;
      const int64_t v139 = 1;
      // pto: %q_proj_i32_inline7_inline4582__iter_v6_pview
      ;
      int64_t v140 = v100 * v15;
      // pto: %q_proj_i32_inline7_inline4582__iter_v6_pview
      ;
      int64_t v141 = v139 * v140;
      // pto: %q_proj_i32_inline7_inline4582__iter_v6_pview
      ;
      pto::Shape<1, 1, 1, -1, 256> v142 = pto::Shape<1, 1, 1, -1, 256>(v137, v138, v139, v100, v26);
      // pto: %q_proj_i32_inline7_inline4582__iter_v6_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v143 = pto::Stride<-1, -1, -1, -1, -1>(v138 * v141, v141, v140, v15, v16);
      // pto: %q_proj_i32_inline7_inline4582__iter_v6_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v144 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v136 + (v135 + v103 * v15 + v134 * v16), v142, v143);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      pipe_barrier(PIPE_FIX);
      TSTORE(v144, v114);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
    };
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}