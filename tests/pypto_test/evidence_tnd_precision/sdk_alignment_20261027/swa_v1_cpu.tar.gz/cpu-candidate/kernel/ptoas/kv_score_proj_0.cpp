#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void kv_score_proj_0(__gm__ int32_t* v1, __gm__ float* v2, __gm__ float* v3, __gm__ bfloat16_t* v4, __gm__ bfloat16_t* v5, __gm__ bfloat16_t* v6, int64_t v7, int64_t v8, int64_t v9, int64_t v10, int32_t v11, int32_t v12) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int32_t v13 = 0;
  // pto: %c0_i64
  const int64_t v14 = 0;
  // pto: %c1024_i64
  const int64_t v15 = 1024;
  // pto: %c32768_i64
  const int64_t v16 = 32768;
  // pto: %c40960_i64
  const int64_t v17 = 40960;
  // pto: %c8192_i64
  const int64_t v18 = 8192;
  // pto: %c16384_i64
  const int64_t v19 = 16384;
  // pto: %c24576_i64
  const int64_t v20 = 24576;
  // pto: %c1_index
  const int64_t v21 = 1;
  // pto: %c384_index
  const int64_t v22 = 384;
  // pto: %c256_index
  const int64_t v23 = 256;
  // pto: %c4096_index
  const int64_t v24 = 4096;
  // pto: %c0_index
  const int64_t v25 = 0;
  // pto: %c64_index
  const int64_t v26 = 64;
  // pto: %c1536_index
  const int64_t v27 = 1536;
  // pto: %c16_index
  const int64_t v28 = 16;
  // pto: %c24_index
  const int64_t v29 = 24;
  // pto: %c2_index
  const int64_t v30 = 2;
  // pto: %c128_index
  const int64_t v31 = 128;
  // pto: %cn1_index
  const int64_t v32 = -1;
  // pto: %kv_proj_pad_inline4853__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %kv_proj_pad_inline4853__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %kv_proj_pad_inline4853__ssa_v0_view
  const int64_t v35 = 1;
  // pto: %kv_proj_pad_inline4853__ssa_v0_view
  int64_t v36 = v22 * v23;
  // pto: %kv_proj_pad_inline4853__ssa_v0_view
  int64_t v37 = v35 * v36;
  // pto: %kv_proj_pad_inline4853__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v38 = pto::Shape<1, 1, 1, -1, -1>(v33, v34, v35, v22, v23);
  // pto: %kv_proj_pad_inline4853__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v39 = pto::Stride<-1, -1, -1, -1, -1>(v34 * v37, v37, v36, v23, v21);
  // pto: %kv_proj_pad_inline4853__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v40 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v38, v39);
  // pto: %score_proj_pad_inline4858__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %score_proj_pad_inline4858__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %score_proj_pad_inline4858__ssa_v0_view
  const int64_t v43 = 1;
  // pto: %score_proj_pad_inline4858__ssa_v0_view
  int64_t v44 = v22 * v23;
  // pto: %score_proj_pad_inline4858__ssa_v0_view
  int64_t v45 = v43 * v44;
  // pto: %score_proj_pad_inline4858__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v46 = pto::Shape<1, 1, 1, -1, -1>(v41, v42, v43, v22, v23);
  // pto: %score_proj_pad_inline4858__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v47 = pto::Stride<-1, -1, -1, -1, -1>(v42 * v45, v45, v44, v23, v21);
  // pto: %score_proj_pad_inline4858__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v48 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v46, v47);
  // pto: %x_flat_inline667_inline4883__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %x_flat_inline667_inline4883__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %x_flat_inline667_inline4883__ssa_v0_view
  const int64_t v51 = 1;
  // pto: %x_flat_inline667_inline4883__ssa_v0_view
  int64_t v52 = (int64_t) v10;
  // pto: %x_flat_inline667_inline4883__ssa_v0_view
  int64_t v53 = v52 * v24;
  // pto: %x_flat_inline667_inline4883__ssa_v0_view
  int64_t v54 = v51 * v53;
  // pto: %x_flat_inline667_inline4883__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v55 = pto::Shape<1, 1, 1, -1, -1>(v49, v50, v51, v52, v24);
  // pto: %x_flat_inline667_inline4883__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v56 = pto::Stride<-1, -1, -1, -1, -1>(v50 * v54, v54, v53, v24, v21);
  // pto: %x_flat_inline667_inline4883__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v57 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v55, v56);
  // pto: %inner_wkv__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %inner_wkv__ssa_v0_view
  const int64_t v59 = 1;
  // pto: %inner_wkv__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %inner_wkv__ssa_v0_view
  int64_t v61 = v23 * v24;
  // pto: %inner_wkv__ssa_v0_view
  int64_t v62 = v60 * v61;
  // pto: %inner_wkv__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v63 = pto::Shape<1, 1, 1, -1, -1>(v58, v59, v60, v23, v24);
  // pto: %inner_wkv__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v64 = pto::Stride<-1, -1, -1, -1, -1>(v59 * v62, v62, v61, v24, v21);
  // pto: %inner_wkv__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v65 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v63, v64);
  // pto: %inner_wgate__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %inner_wgate__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %inner_wgate__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %inner_wgate__ssa_v0_view
  int64_t v69 = v23 * v24;
  // pto: %inner_wgate__ssa_v0_view
  int64_t v70 = v68 * v69;
  // pto: %inner_wgate__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v71 = pto::Shape<1, 1, 1, -1, -1>(v66, v67, v68, v23, v24);
  // pto: %inner_wgate__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v67 * v70, v70, v69, v24, v21);
  // pto: %inner_wgate__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v73 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v71, v72);
  // pto: %kv_worker_inline665_inline4861__ssa_v0
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
  // pto: %t__tile
  int32_t v74 = (v1)[v21];
  // pto: %12
  int32_t v75 = (v1)[v25];
  // pto: %15
  // pto: %deviation_inline8349__rv_v2
  int32_t v76;
  v76 = v13;
  for (int64_t v77 = v21; v77 < ((int64_t) ((uint64_t) v9 - (uint64_t) v21)); v77 += v21) {
    // pto: %17, %16
    ;
    int32_t v78 = (v1)[(int64_t) ((uint64_t) v77 + (uint64_t) v21)];
    // pto: %18
    ;
    int32_t v79 = (v1)[v77];
    // pto: %19, %20, %13
    ;
    int32_t v80 = (int32_t) ((uint32_t) ((int32_t) (uint32_t) v78 - (uint32_t) v79) - (uint32_t) ((int32_t) (uint32_t) v74 - (uint32_t) v75));
    // pto: %22
    ;
    uint32_t v81 = (uint32_t) v76;
    // pto: %21, %22
    ;
    v76 = (int32_t) (v81 + (uint32_t) ((int32_t) (uint32_t) v80 * (uint32_t) v80));
  }
  // pto: %24
  int64_t v82 = (int64_t) v76;
  // pto: %25, %26, %27, %group_inline8345__phi_v4
  int64_t v83 = v82 == v25 & v7 <= v27 ? v28 : v26;
  for (int64_t v84 = (int64_t) v11; v84 < v8; v84 += v29) {
    // pto: %29, %30
    ;
    int64_t v85 = (int64_t) ((uint64_t) (v84 / v28) * (uint64_t) v28);
    // pto: %31
    ;
    int64_t v86 = v84 % v28;
    // pto: %32, %33, %34
    ;
    int64_t v87 = v86 < v25 ? (int64_t) ((uint64_t) v86 + (uint64_t) v28) : v86;
    // pto: %35
    ;
    int64_t v88 = (int64_t) ((uint64_t) v87 * (uint64_t) v28);
    // pto: %kv_acc_inline674_inline4869__tile
    ;
    Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v89 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v28, v28);
    // pto: %kv_acc_inline674_inline4869__tile
    ;
    uint64_t v90 = (uint64_t) v14;
    TASSIGN(v89, v90);
    // pto: %score_acc_inline677_inline4844__tile
    ;
    Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v91 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v28, v28);
    // pto: %score_acc_inline677_inline4844__tile
    ;
    uint64_t v92 = (uint64_t) v15;
    TASSIGN(v91, v92);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    for (int64_t v93 = v25; v93 < v28; v93 += v30) {
      // pto: %36
      ;
      int64_t v94 = v88 % v31;
      // pto: %37, %38, %39
      ;
      int64_t v95 = v94 < v25 ? (int64_t) ((uint64_t) v94 + (uint64_t) v31) : v94;
      // pto: %41, %40, %42
      ;
      int64_t v96 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v93 + (uint64_t) (v95 / v83)) * (uint64_t) v23);
      // pto: %43
      ;
      int64_t v97 = v96 % v24;
      // pto: %44, %45, %46
      ;
      int64_t v98 = v97 < v25 ? (int64_t) ((uint64_t) v97 + (uint64_t) v24) : v97;
      // pto: %47
      ;
      int64_t v99 = (int64_t) ((uint64_t) v7 - (uint64_t) v85);
      // pto: %48
      ;
      int64_t v100 = v99 < v28 ? v99 : v28;
      // pto: %56, %57
      ;
      int64_t v101 = (int64_t) ((uint64_t) v96 + (uint64_t) v23) % v24;
      // pto: %58, %59, %60
      ;
      int64_t v102 = v101 < v25 ? (int64_t) ((uint64_t) v101 + (uint64_t) v24) : v101;
      // pto: %x_tile_inline662_inline4868__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v100, v23);
      // pto: %x_tile_inline662_inline4868__tile
      ;
      uint64_t v104 = (uint64_t) v16;
      TASSIGN(v103, v104);
      // pto: %63
      ;
      int64_t v105 = v85 < v25 ? v25 : v85;
      // pto: %64
      ;
      int64_t v106 = v98 < v25 ? v25 : v98;
      // pto: %x_flat_inline667_inline4883__ssa_v0_pview
      ;
      const int64_t v107 = 0;
      // pto: %x_flat_inline667_inline4883__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v108 = PTOAS__GLOBAL_TENSOR_DATA(v57);
      // pto: %x_flat_inline667_inline4883__ssa_v0_pview
      ;
      const int64_t v109 = 1;
      // pto: %x_flat_inline667_inline4883__ssa_v0_pview
      ;
      const int64_t v110 = 1;
      // pto: %x_flat_inline667_inline4883__ssa_v0_pview
      ;
      const int64_t v111 = 1;
      // pto: %x_flat_inline667_inline4883__ssa_v0_pview
      ;
      int64_t v112 = v100 * v24;
      // pto: %x_flat_inline667_inline4883__ssa_v0_pview
      ;
      int64_t v113 = v111 * v112;
      // pto: %x_flat_inline667_inline4883__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 256> v114 = pto::Shape<1, 1, 1, -1, 256>(v109, v110, v111, v100, v23);
      // pto: %x_flat_inline667_inline4883__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v115 = pto::Stride<-1, -1, -1, -1, -1>(v110 * v113, v113, v112, v24, v21);
      // pto: %x_flat_inline667_inline4883__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v116 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v108 + (v107 + v105 * v24 + v106 * v21), v114, v115);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v103, v116);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %wkv_tile_inline673_inline4893__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v28, v23);
      // pto: %wkv_tile_inline673_inline4893__tile
      ;
      uint64_t v118 = (uint64_t) v17;
      TASSIGN(v117, v118);
      // pto: %65
      ;
      int64_t v119 = v88 < v25 ? v25 : v88;
      // pto: %inner_wkv__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v120 = PTOAS__GLOBAL_TENSOR_DATA(v65);
      // pto: %inner_wkv__ssa_v0_pview
      ;
      const int64_t v121 = 0;
      // pto: %inner_wkv__ssa_v0_pview
      ;
      const int64_t v122 = 4096;
      // pto: %inner_wkv__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 256> v123 = pto::Shape<1, 1, 1, 16, 256>();
      // pto: %inner_wkv__ssa_v0_pview
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v124 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %inner_wkv__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v125 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v120 + (v121 + v119 * v122 + v106), v123, v124);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v117, v125);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %wgate_tile_inline661_inline4834__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v126 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v28, v23);
      // pto: %wgate_tile_inline661_inline4834__tile
      ;
      uint64_t v127 = (uint64_t) v14;
      TASSIGN(v126, v127);
      // pto: %inner_wgate__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v128 = PTOAS__GLOBAL_TENSOR_DATA(v73);
      // pto: %inner_wgate__ssa_v0_pview
      ;
      const int64_t v129 = 0;
      // pto: %inner_wgate__ssa_v0_pview
      ;
      const int64_t v130 = 4096;
      // pto: %inner_wgate__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 256> v131 = pto::Shape<1, 1, 1, 16, 256>();
      // pto: %inner_wgate__ssa_v0_pview
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v132 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %inner_wgate__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v133 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v128 + (v129 + v119 * v130 + v106), v131, v132);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v126, v133);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      // pto: %0
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v134 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v100, v23);
      // pto: %0
      ;
      uint64_t v135 = (uint64_t) v18;
      TASSIGN(v134, v135);
      // pto: %70
      ;
      int64_t v136 = v102 < v25 ? v25 : v102;
      // pto: %71
      ;
      const int64_t v137 = 0;
      // pto: %71
      ;
      __gm__ bfloat16_t* v138 = PTOAS__GLOBAL_TENSOR_DATA(v57);
      // pto: %71
      ;
      const int64_t v139 = 1;
      // pto: %71
      ;
      const int64_t v140 = 1;
      // pto: %71
      ;
      const int64_t v141 = 1;
      // pto: %71
      ;
      int64_t v142 = v100 * v24;
      // pto: %71
      ;
      int64_t v143 = v141 * v142;
      // pto: %71
      ;
      pto::Shape<1, 1, 1, -1, 256> v144 = pto::Shape<1, 1, 1, -1, 256>(v139, v140, v141, v100, v23);
      // pto: %71
      ;
      pto::Stride<-1, -1, -1, -1, -1> v145 = pto::Stride<-1, -1, -1, -1, -1>(v140 * v143, v143, v142, v24, v21);
      // pto: %71
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v146 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v138 + (v137 + v105 * v24 + v136 * v21), v144, v145);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v134, v146);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %1
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v147 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v28, v23);
      // pto: %1
      ;
      uint64_t v148 = (uint64_t) v19;
      TASSIGN(v147, v148);
      // pto: %74
      ;
      __gm__ bfloat16_t* v149 = PTOAS__GLOBAL_TENSOR_DATA(v65);
      // pto: %74
      ;
      const int64_t v150 = 0;
      // pto: %74
      ;
      const int64_t v151 = 4096;
      // pto: %74
      ;
      pto::Shape<1, 1, 1, 16, 256> v152 = pto::Shape<1, 1, 1, 16, 256>();
      // pto: %74
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v153 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %74
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v154 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v149 + (v150 + v119 * v151 + v136), v152, v153);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
      TLOAD(v147, v154);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      // pto: %2
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v155 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v28, v23);
      // pto: %2
      ;
      uint64_t v156 = (uint64_t) v20;
      TASSIGN(v155, v156);
      // pto: %77
      ;
      __gm__ bfloat16_t* v157 = PTOAS__GLOBAL_TENSOR_DATA(v73);
      // pto: %77
      ;
      const int64_t v158 = 0;
      // pto: %77
      ;
      const int64_t v159 = 4096;
      // pto: %77
      ;
      pto::Shape<1, 1, 1, 16, 256> v160 = pto::Shape<1, 1, 1, 16, 256>();
      // pto: %77
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v161 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %77
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v162 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v157 + (v158 + v119 * v159 + v136), v160, v161);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      TLOAD(v155, v162);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      // pto: %wkv_tile_inline673_inline4893__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v163 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v28);
      // pto: %wkv_tile_inline673_inline4893__tile_t
      ;
      uint64_t v164 = (uint64_t) v17;
      TASSIGN(v163, v164);
      // pto: %x_tile_inline662_inline4868__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v165 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v100, v23);
      // pto: %x_tile_inline662_inline4868__tile_Left
      ;
      uint64_t v166 = (uint64_t) v14;
      TASSIGN(v165, v166);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      TMOV(v165, v103);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %wkv_tile_inline673_inline4893__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v167 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v28);
      // pto: %wkv_tile_inline673_inline4893__tile_t_Right
      ;
      uint64_t v168 = (uint64_t) v14;
      TASSIGN(v167, v168);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      TMOV(v167, v163);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %78
      ;
      bool v169 = v93 == v25;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (v169) {
        TMATMUL(v89, v165, v167);
      } else {
        TMATMUL_ACC(v89, v89, v165, v167);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      // pto: %wgate_tile_inline661_inline4834__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v170 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v28);
      // pto: %wgate_tile_inline661_inline4834__tile_t
      ;
      uint64_t v171 = (uint64_t) v14;
      TASSIGN(v170, v171);
      // pto: %wgate_tile_inline661_inline4834__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v172 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v28);
      // pto: %wgate_tile_inline661_inline4834__tile_t_Right
      ;
      uint64_t v173 = (uint64_t) v14;
      TASSIGN(v172, v173);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      pipe_barrier(PIPE_MTE1);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      TMOV(v172, v170);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      if (v169) {
        TMATMUL(v91, v165, v172);
      } else {
        TMATMUL_ACC(v91, v91, v165, v172);
      };
      // pto: %5
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v174 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v28);
      // pto: %5
      ;
      uint64_t v175 = (uint64_t) v19;
      TASSIGN(v174, v175);
      // pto: %6
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v176 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v100, v23);
      // pto: %6
      ;
      uint64_t v177 = (uint64_t) v18;
      TASSIGN(v176, v177);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      TMOV(v176, v134);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      // pto: %7
      ;
      Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v178 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v28);
      // pto: %7
      ;
      uint64_t v179 = (uint64_t) v18;
      TASSIGN(v178, v179);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      TMOV(v178, v174);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
      // pto: %80
      ;
      bool v180 = v93 == v32;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      if (v180) {
        TMATMUL(v89, v176, v178);
      } else {
        TMATMUL_ACC(v89, v89, v176, v178);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %9
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v28);
      // pto: %9
      ;
      uint64_t v182 = (uint64_t) v20;
      TASSIGN(v181, v182);
      // pto: %10
      ;
      Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v28);
      // pto: %10
      ;
      uint64_t v184 = (uint64_t) v18;
      TASSIGN(v183, v184);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      pipe_barrier(PIPE_MTE1);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      TMOV(v183, v181);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      if (v180) {
        TMATMUL(v91, v176, v183);
      } else {
        TMATMUL_ACC(v91, v91, v176, v183);
      };
    };
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %82
    ;
    int64_t v185 = v85 < v25 ? v25 : v85;
    // pto: %83
    ;
    int64_t v186 = v88 < v25 ? v25 : v88;
    // pto: %kv_proj_pad_inline4853__iter_v1_pview
    ;
    __gm__ float* v187 = PTOAS__GLOBAL_TENSOR_DATA(v40);
    // pto: %kv_proj_pad_inline4853__iter_v1_pview
    ;
    const int64_t v188 = 0;
    // pto: %kv_proj_pad_inline4853__iter_v1_pview
    ;
    const int64_t v189 = 256;
    // pto: %kv_proj_pad_inline4853__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 16> v190 = pto::Shape<1, 1, 1, 16, 16>();
    // pto: %kv_proj_pad_inline4853__iter_v1_pview
    ;
    pto::Stride<4096, 4096, 4096, 256, 1> v191 = pto::Stride<4096, 4096, 4096, 256, 1>();
    // pto: %kv_proj_pad_inline4853__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<4096, 4096, 4096, 256, 1>, pto::Layout::ND> v192 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<4096, 4096, 4096, 256, 1>, pto::Layout::ND>(v187 + (v188 + v185 * v189 + v186), v190, v191);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE(v192, v89);
    // pto: %score_proj_pad_inline4858__iter_v1_pview
    ;
    __gm__ float* v193 = PTOAS__GLOBAL_TENSOR_DATA(v48);
    // pto: %score_proj_pad_inline4858__iter_v1_pview
    ;
    const int64_t v194 = 0;
    // pto: %score_proj_pad_inline4858__iter_v1_pview
    ;
    const int64_t v195 = 256;
    // pto: %score_proj_pad_inline4858__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 16> v196 = pto::Shape<1, 1, 1, 16, 16>();
    // pto: %score_proj_pad_inline4858__iter_v1_pview
    ;
    pto::Stride<4096, 4096, 4096, 256, 1> v197 = pto::Stride<4096, 4096, 4096, 256, 1>();
    // pto: %score_proj_pad_inline4858__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<4096, 4096, 4096, 256, 1>, pto::Layout::ND> v198 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<4096, 4096, 4096, 256, 1>, pto::Layout::ND>(v193 + (v194 + v185 * v195 + v186), v196, v197);
    TSTORE(v198, v91);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}