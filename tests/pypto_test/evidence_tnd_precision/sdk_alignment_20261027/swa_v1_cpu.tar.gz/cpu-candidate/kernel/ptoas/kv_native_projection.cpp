#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void kv_native_projection(__gm__ bfloat16_t* v1, __gm__ float* v2, int64_t v3, int64_t v4, int64_t v5, int64_t v6, int32_t v7, int32_t v8) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v9 = 0;
  // pto: %c16384_i64
  const int64_t v10 = 16384;
  // pto: %c512_index
  const int64_t v11 = 512;
  // pto: %c1_index
  const int64_t v12 = 1;
  // pto: %c16_index
  const int64_t v13 = 16;
  // pto: %c0_index
  const int64_t v14 = 0;
  // pto: %projected_kv__ssa_v1_view
  const int64_t v15 = 1;
  // pto: %projected_kv__ssa_v1_view
  const int64_t v16 = 1;
  // pto: %projected_kv__ssa_v1_view
  const int64_t v17 = 1;
  // pto: %projected_kv__ssa_v1_view
  int64_t v18 = (int64_t) v5;
  // pto: %projected_kv__ssa_v1_view
  int64_t v19 = v18 * v11;
  // pto: %projected_kv__ssa_v1_view
  int64_t v20 = v17 * v19;
  // pto: %projected_kv__ssa_v1_view
  pto::Shape<1, 1, 1, -1, -1> v21 = pto::Shape<1, 1, 1, -1, -1>(v15, v16, v17, v18, v11);
  // pto: %projected_kv__ssa_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v22 = pto::Stride<-1, -1, -1, -1, -1>(v16 * v20, v20, v19, v11, v12);
  // pto: %projected_kv__ssa_v1_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v23 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v21, v22);
  // pto: %kv_fp32_inline4626__ssa_v0_view
  const int64_t v24 = 1;
  // pto: %kv_fp32_inline4626__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %kv_fp32_inline4626__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %kv_fp32_inline4626__ssa_v0_view
  int64_t v27 = (int64_t) v6;
  // pto: %kv_fp32_inline4626__ssa_v0_view
  int64_t v28 = v27 * v11;
  // pto: %kv_fp32_inline4626__ssa_v0_view
  int64_t v29 = v26 * v28;
  // pto: %kv_fp32_inline4626__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v30 = pto::Shape<1, 1, 1, -1, -1>(v24, v25, v26, v27, v11);
  // pto: %kv_fp32_inline4626__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v31 = pto::Stride<-1, -1, -1, -1, -1>(v25 * v29, v29, v28, v11, v12);
  // pto: %kv_fp32_inline4626__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v32 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v30, v31);
  // pto: %t__tmp_v94, %0
  int64_t v33 = (int64_t) ((uint64_t) ((int64_t) v7) * (uint64_t) v13);
  // pto: %1
  int64_t v34 = (int64_t) ((uint64_t) v3 - (uint64_t) v33);
  // pto: %2
  int64_t v35 = v34 < v13 ? v34 : v13;
  // pto: %projected_inline4635__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v36 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v11);
  // pto: %projected_inline4635__ssa_v0
  uint64_t v37 = (uint64_t) v9;
  TASSIGN(v36, v37);
  // pto: %3
  int64_t v38 = (int64_t) ((uint64_t) v4 + (uint64_t) v33);
  // pto: %4
  int64_t v39 = v38 < v14 ? v14 : v38;
  // pto: %projected_kv__ssa_v1_pview
  const int64_t v40 = 0;
  // pto: %projected_kv__ssa_v1_pview
  __gm__ bfloat16_t* v41 = PTOAS__GLOBAL_TENSOR_DATA(v23);
  // pto: %projected_kv__ssa_v1_pview
  const int64_t v42 = 1;
  // pto: %projected_kv__ssa_v1_pview
  const int64_t v43 = 1;
  // pto: %projected_kv__ssa_v1_pview
  const int64_t v44 = 1;
  // pto: %projected_kv__ssa_v1_pview
  int64_t v45 = v35 * v11;
  // pto: %projected_kv__ssa_v1_pview
  int64_t v46 = v44 * v45;
  // pto: %projected_kv__ssa_v1_pview
  pto::Shape<1, 1, 1, -1, 512> v47 = pto::Shape<1, 1, 1, -1, 512>(v42, v43, v44, v35, v11);
  // pto: %projected_kv__ssa_v1_pview
  pto::Stride<-1, -1, -1, -1, -1> v48 = pto::Stride<-1, -1, -1, -1, -1>(v43 * v46, v46, v45, v11, v12);
  // pto: %projected_kv__ssa_v1_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v49 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v41 + (v40 + v39 * v11 + v14 * v12), v47, v48);
  TLOAD(v36, v49);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %t__tmp_v95
  Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v50 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v11);
  // pto: %t__tmp_v95
  uint64_t v51 = (uint64_t) v10;
  TASSIGN(v50, v51);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  RoundMode v52 = RoundMode::CAST_ROUND;
  SaturationMode v53 = SaturationMode::ON;
  TCVT(v50, v36, v52, v53);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %5
  int64_t v54 = v33 < v14 ? v14 : v33;
  // pto: %kv_fp32_inline4626__ssa_v0_pview
  const int64_t v55 = 0;
  // pto: %kv_fp32_inline4626__ssa_v0_pview
  __gm__ float* v56 = PTOAS__GLOBAL_TENSOR_DATA(v32);
  // pto: %kv_fp32_inline4626__ssa_v0_pview
  const int64_t v57 = 1;
  // pto: %kv_fp32_inline4626__ssa_v0_pview
  const int64_t v58 = 1;
  // pto: %kv_fp32_inline4626__ssa_v0_pview
  const int64_t v59 = 1;
  // pto: %kv_fp32_inline4626__ssa_v0_pview
  int64_t v60 = v35 * v11;
  // pto: %kv_fp32_inline4626__ssa_v0_pview
  int64_t v61 = v59 * v60;
  // pto: %kv_fp32_inline4626__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 512> v62 = pto::Shape<1, 1, 1, -1, 512>(v57, v58, v59, v35, v11);
  // pto: %kv_fp32_inline4626__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v63 = pto::Stride<-1, -1, -1, -1, -1>(v58 * v61, v61, v60, v11, v12);
  // pto: %kv_fp32_inline4626__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v64 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v56 + (v55 + v54 * v11 + v14 * v12), v62, v63);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v64, v50);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}