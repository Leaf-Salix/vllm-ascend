#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void csa_slots_build_valid_qk_plan(__gm__ float* v1, __gm__ int32_t* v2, __gm__ int64_t* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, __gm__ int32_t* v7, int64_t v8, int64_t v9, int64_t v10, int64_t v11, int64_t v12, int32_t v13, int32_t v14) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int32_t v15 = 1;
  // pto: %c1536_i64
  const int64_t v16 = 1536;
  // pto: %c17920_i64
  const int64_t v17 = 17920;
  // pto: %c0_i64
  const int64_t v18 = 0;
  // pto: %c512_i64
  const int64_t v19 = 512;
  // pto: %c1024_i64
  const int64_t v20 = 1024;
  // pto: %c1024_index
  const int64_t v21 = 1024;
  // pto: %c1_index
  const int64_t v22 = 1;
  // pto: %c512_index
  const int64_t v23 = 512;
  // pto: %c16_index
  const int64_t v24 = 16;
  // pto: %c8_index
  const int64_t v25 = 8;
  // pto: %c256_index
  const int64_t v26 = 256;
  // pto: %c0_index
  const int64_t v27 = 0;
  // pto: %c128_index
  const int64_t v28 = 128;
  // pto: %c32_index
  const int64_t v29 = 32;
  // pto: %c192_index
  const int64_t v30 = 192;
  const int32_t v31 = 0;
  // pto: %cst_16
  const float v32 = 0.0f;
  // pto: %c5_index
  const int64_t v33 = 5;
  // pto: %cst_18
  const float v34 = 1.0f;
  // pto: %cst_19
  const float v35 = 1.00000002E+20f;
  // pto: %c384_index
  const int64_t v36 = 384;
  // pto: %cst_21
  const float v37 = -1.00000002E+20f;
  // pto: %sparse_bias_inline5228__ssa_v0_view
  const int64_t v38 = 1;
  // pto: %sparse_bias_inline5228__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %sparse_bias_inline5228__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %sparse_bias_inline5228__ssa_v0_view
  int64_t v41 = (int64_t) v9;
  // pto: %sparse_bias_inline5228__ssa_v0_view
  int64_t v42 = v41 * v21;
  // pto: %sparse_bias_inline5228__ssa_v0_view
  int64_t v43 = v40 * v42;
  // pto: %sparse_bias_inline5228__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v44 = pto::Shape<1, 1, 1, -1, -1>(v38, v39, v40, v41, v21);
  // pto: %sparse_bias_inline5228__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v45 = pto::Stride<-1, -1, -1, -1, -1>(v39 * v43, v43, v42, v21, v22);
  // pto: %sparse_bias_inline5228__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v46 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v44, v45);
  // pto: %cmp_sparse_indices_inline5265__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %cmp_sparse_indices_inline5265__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %cmp_sparse_indices_inline5265__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %cmp_sparse_indices_inline5265__ssa_v0_view
  int64_t v50 = (int64_t) v9;
  // pto: %cmp_sparse_indices_inline5265__ssa_v0_view
  int64_t v51 = v50 * v23;
  // pto: %cmp_sparse_indices_inline5265__ssa_v0_view
  int64_t v52 = v49 * v51;
  // pto: %cmp_sparse_indices_inline5265__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v53 = pto::Shape<1, 1, 1, -1, -1>(v47, v48, v49, v50, v23);
  // pto: %cmp_sparse_indices_inline5265__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v54 = pto::Stride<-1, -1, -1, -1, -1>(v48 * v52, v52, v51, v23, v22);
  // pto: %cmp_sparse_indices_inline5265__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v55 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v53, v54);
  // pto: %v_valid_inline5333__phi_v5
  Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v56 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
  // pto: %v_valid_inline5333__phi_v5
  uint64_t v57 = (uint64_t) v18;
  TASSIGN(v56, v57);
  // pto: %v_valid_inline5333__phi_v4
  Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v58 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
  // pto: %v_valid_inline5333__phi_v4
  uint64_t v59 = (uint64_t) v18;
  TASSIGN(v58, v59);
  // pto: %plan_worker_inline5272__ssa_v0, %14
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_S, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v60 = (int64_t) ((uint64_t) ((int64_t) v13) * (uint64_t) v25); v60 < v9; v60 += v26) {
    // pto: %15
    ;
    int64_t v61 = (int64_t) ((uint64_t) v9 - (uint64_t) v60);
    // pto: %16
    ;
    int64_t v62 = v61 < v25 ? v61 : v25;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    for (int64_t v63 = v27; v63 < v62; v63 += v22) {
      // pto: %17
      ;
      int64_t v64 = (int64_t) ((uint64_t) v60 + (uint64_t) v63);
      // pto: %18
      ;
      int32_t v65 = (v2)[v64];
      // pto: %19
      ;
      int64_t v66 = (int64_t) v65;
      // pto: %20
      ;
      int64_t v67 = v66 < v27 ? v27 : v66;
      // pto: %21
      ;
      int64_t v68 = (v3)[v64];
      // pto: %t__tile
      ;
      Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v69 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v23);
      // pto: %t__tile
      ;
      uint64_t v70 = (uint64_t) v16;
      TASSIGN(v69, v70);
      // pto: %23
      ;
      int64_t v71 = v64 < v27 ? v27 : v64;
      // pto: %cmp_sparse_indices_inline5265__ssa_v0_pview
      ;
      __gm__ int32_t* v72 = PTOAS__GLOBAL_TENSOR_DATA(v55);
      // pto: %cmp_sparse_indices_inline5265__ssa_v0_pview
      ;
      const int64_t v73 = 0;
      // pto: %cmp_sparse_indices_inline5265__ssa_v0_pview
      ;
      const int64_t v74 = 512;
      // pto: %cmp_sparse_indices_inline5265__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v75 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %cmp_sparse_indices_inline5265__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 512, 1> v76 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %cmp_sparse_indices_inline5265__ssa_v0_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v77 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v72 + (v73 + v71 * v74), v75, v76);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      TLOAD(v69, v77);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %c_out_inline5307__tile
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v78 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v23);
      // pto: %c_out_inline5307__tile
      ;
      uint64_t v79 = (uint64_t) v16;
      TASSIGN(v78, v79);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      RoundMode v80 = RoundMode::CAST_ROUND;
      SaturationMode v81 = SaturationMode::ON;
      TCVT(v78, v69, v80, v81);
      // pto: %24
      ;
      int64_t v82 = (int64_t) ((uint64_t) v68 + (uint64_t) v22);
      // pto: %25
      ;
      int64_t v83 = v82 < v28 ? v82 : v28;
      // pto: %26
      ;
      int32_t v84 = (v2)[v64];
      // pto: %27
      ;
      int32_t v85 = (v5)[v67];
      // pto: %28, %29, %30, %31, %32, %v_length_inline5306__phi_v2
      ;
      int64_t v86 = (int64_t) v84 < v27 | (int64_t) v85 <= v27 ? v27 : v83;
      // pto: %34, %35
      ;
      int64_t v87 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v68 - (uint64_t) v86) + (uint64_t) v22);
      // pto: %36
      ;
      int64_t v88 = v87 % v29;
      // pto: %37, %38, %39
      ;
      int64_t v89 = v88 < v27 ? (int64_t) ((uint64_t) v88 + (uint64_t) v29) : v88;
      // pto: %t__ci_tmp_v0
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v90 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
      // pto: %t__ci_tmp_v0
      ;
      uint64_t v91 = (uint64_t) v17;
      TASSIGN(v90, v91);
      // pto: %0
      ;
      Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v92 = Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
      // pto: %0
      ;
      uint64_t v93 = (uint64_t) v18;
      TASSIGN(v92, v93);
      // pto: %ci_tmp_view
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v94;
      TRESHAPE(v94, v90);
      // pto: %ci_dst_view
      ;
      Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v95;
      TRESHAPE(v95, v92);
      TCI<Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v95, v31, v94);
      // pto: %v_columns_inline5244__tile
      ;
      Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v96 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
      // pto: %v_columns_inline5244__tile
      ;
      uint64_t v97 = (uint64_t) v17;
      TASSIGN(v96, v97);
      pipe_barrier(PIPE_V);
      RoundMode v98 = RoundMode::CAST_ROUND;
      SaturationMode v99 = SaturationMode::ON;
      TCVT(v96, v92, v98, v99);
      // pto: %v_valid_inline5333__tile
      ;
      Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v100 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
      // pto: %v_valid_inline5333__tile
      ;
      uint64_t v101 = (uint64_t) v18;
      TASSIGN(v100, v101);
      pipe_barrier(PIPE_V);
      TEXPANDS(v100, v32);
      // pto: %v_block_valid_inline5285__rv_v2
      ;
      int32_t v102;
      v102 = v31;
      for (int64_t v103 = v27; v103 < v33; v103 += v22) {
        // pto: %41, %42
        ;
        int64_t v104 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v103 * (uint64_t) v29) - (uint64_t) v89);
        // pto: %43
        ;
        int64_t v105 = v104 < v27 ? v27 : v104;
        // pto: %46
        ;
        int64_t v106 = (int64_t) ((uint64_t) v104 + (uint64_t) v29);
        // pto: %47
        ;
        int64_t v107 = v106 < v86 ? v106 : v86;
        // pto: %48
        ;
        // pto: %v_block_valid_inline5285__phi_v5
        ;
        int32_t v108;
        if (v105 < v107) {
          // pto: %51, %52, %49, %50, %v_page_inline5212__tile
          ;
          int32_t v109 = (v6)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v67 * (uint64_t) v12) + (uint64_t) ((int64_t) ((uint64_t) v87 + (uint64_t) v105) / v29))];
          // pto: %53, %54
          ;
          bool v110 = (int64_t) v109 >= v27;
          // pto: %v_block_valid_inline5285__phi_v4
          ;
          int32_t v111 = v110 ? v15 : v102;
          if (v110) {
            // pto: %56, %57
            ;
            float v112 = (float) ((int32_t) v105);
            // pto: %58, %59
            ;
            float v113 = (float) ((int32_t) v107);
            // pto: %1
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v114 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
            // pto: %1
            ;
            uint64_t v115 = (uint64_t) v19;
            TASSIGN(v114, v115);
            pipe_barrier(PIPE_V);
            TSUBS(v114, v96, v112);
            // pto: %2
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
            // pto: %2
            ;
            uint64_t v117 = (uint64_t) v19;
            TASSIGN(v116, v117);
            pipe_barrier(PIPE_V);
            TADDS(v116, v114, v34);
            // pto: %3
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v118 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
            // pto: %3
            ;
            uint64_t v119 = (uint64_t) v19;
            TASSIGN(v118, v119);
            pipe_barrier(PIPE_V);
            TMAXS(v118, v116, v32);
            // pto: %v_ge_inline5327__tile
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
            // pto: %v_ge_inline5327__tile
            ;
            uint64_t v121 = (uint64_t) v19;
            TASSIGN(v120, v121);
            pipe_barrier(PIPE_V);
            TMINS(v120, v118, v34);
            // pto: %4
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v122 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
            // pto: %4
            ;
            uint64_t v123 = (uint64_t) v20;
            TASSIGN(v122, v123);
            TNEG(v122, v96);
            // pto: %5
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
            // pto: %5
            ;
            uint64_t v125 = (uint64_t) v20;
            TASSIGN(v124, v125);
            pipe_barrier(PIPE_V);
            TADDS(v124, v122, v113);
            // pto: %6
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v126 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
            // pto: %6
            ;
            uint64_t v127 = (uint64_t) v20;
            TASSIGN(v126, v127);
            pipe_barrier(PIPE_V);
            TMAXS(v126, v124, v32);
            // pto: %v_lt_inline5463__tile
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v128 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
            // pto: %v_lt_inline5463__tile
            ;
            uint64_t v129 = (uint64_t) v20;
            TASSIGN(v128, v129);
            pipe_barrier(PIPE_V);
            TMINS(v128, v126, v34);
            // pto: %7
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
            // pto: %7
            ;
            uint64_t v131 = (uint64_t) v19;
            TASSIGN(v130, v131);
            pipe_barrier(PIPE_V);
            TMUL(v130, v120, v128);
            // pto: %8
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v132 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
            // pto: %8
            ;
            uint64_t v133 = (uint64_t) v18;
            TASSIGN(v132, v133);
            pipe_barrier(PIPE_V);
            TADD(v132, v100, v130);
          };
          v108 = v111;
        } else {
          v108 = v102;
        };
        v102 = v108;
      };
      // pto: %60
      ;
      int64_t v134 = (int64_t) ((uint64_t) v64 * (uint64_t) v24);
      (v7)[v134] = v102;
      // pto: %9
      ;
      Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v135 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
      // pto: %9
      ;
      uint64_t v136 = (uint64_t) v17;
      TASSIGN(v135, v136);
      pipe_barrier(PIPE_V);
      TSUBS(v135, v100, v34);
      // pto: %10
      ;
      Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
      // pto: %10
      ;
      uint64_t v138 = (uint64_t) v17;
      TASSIGN(v137, v138);
      pipe_barrier(PIPE_V);
      TMULS(v137, v135, v35);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      // pto: %sparse_bias_inline5228__iter_v3_pview
      ;
      __gm__ float* v139 = PTOAS__GLOBAL_TENSOR_DATA(v46);
      // pto: %sparse_bias_inline5228__iter_v3_pview
      ;
      const int64_t v140 = 0;
      // pto: %sparse_bias_inline5228__iter_v3_pview
      ;
      const int64_t v141 = 1024;
      // pto: %sparse_bias_inline5228__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, 1, 128> v142 = pto::Shape<1, 1, 1, 1, 128>();
      // pto: %sparse_bias_inline5228__iter_v3_pview
      ;
      pto::Stride<1024, 1024, 1024, 1024, 1> v143 = pto::Stride<1024, 1024, 1024, 1024, 1>();
      // pto: %sparse_bias_inline5228__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v144 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v139 + (v140 + v71 * v141), v142, v143);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v144, v137);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      // pto: %11
      ;
      Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v145 = Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v36);
      // pto: %11
      ;
      uint64_t v146 = (uint64_t) v17;
      TASSIGN(v145, v146);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      TEXPANDS(v145, v37);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      // pto: %sparse_bias_inline5228__tile_pview
      ;
      __gm__ float* v147 = PTOAS__GLOBAL_TENSOR_DATA(v46);
      // pto: %sparse_bias_inline5228__tile_pview
      ;
      const int64_t v148 = 128;
      // pto: %sparse_bias_inline5228__tile_pview
      ;
      const int64_t v149 = 1024;
      // pto: %sparse_bias_inline5228__tile_pview
      ;
      pto::Shape<1, 1, 1, 1, 384> v150 = pto::Shape<1, 1, 1, 1, 384>();
      // pto: %sparse_bias_inline5228__tile_pview
      ;
      pto::Stride<1024, 1024, 1024, 1024, 1> v151 = pto::Stride<1024, 1024, 1024, 1024, 1>();
      // pto: %sparse_bias_inline5228__tile_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 384>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v152 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 384>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v147 + (v148 + v71 * v149), v150, v151);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      TSTORE(v152, v145);
      // pto: %12
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v153 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v23);
      // pto: %12
      ;
      uint64_t v154 = (uint64_t) v16;
      TASSIGN(v153, v154);
      TMINS(v153, v78, v32);
      // pto: %13
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v155 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v23);
      // pto: %13
      ;
      uint64_t v156 = (uint64_t) v16;
      TASSIGN(v155, v156);
      pipe_barrier(PIPE_V);
      TMULS(v155, v153, v35);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      // pto: %67
      ;
      __gm__ float* v157 = PTOAS__GLOBAL_TENSOR_DATA(v46);
      // pto: %67
      ;
      const int64_t v158 = 512;
      // pto: %67
      ;
      const int64_t v159 = 1024;
      // pto: %67
      ;
      pto::Shape<1, 1, 1, 1, 512> v160 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %67
      ;
      pto::Stride<1024, 1024, 1024, 1024, 1> v161 = pto::Stride<1024, 1024, 1024, 1024, 1>();
      // pto: %67
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v162 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v157 + (v158 + v71 * v159), v160, v161);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v162, v155);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    // pto: %c_blk_tmp_inline5452__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v163 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v23);
    // pto: %c_blk_tmp_inline5452__ssa_v0
    ;
    uint64_t v164 = (uint64_t) v16;
    TASSIGN(v163, v164);
    // pto: %t__tmp_v930
    ;
    Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v165 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v23);
    // pto: %t__tmp_v930
    ;
    uint64_t v166 = (uint64_t) v17;
    TASSIGN(v165, v166);
    // pto: %68
    ;
    int64_t v167 = v60 < v27 ? v27 : v60;
    // pto: %70
    ;
    const int64_t v168 = 0;
    // pto: %70
    ;
    __gm__ int32_t* v169 = PTOAS__GLOBAL_TENSOR_DATA(v55);
    // pto: %70
    ;
    const int64_t v170 = 1;
    // pto: %70
    ;
    const int64_t v171 = 1;
    // pto: %70
    ;
    const int64_t v172 = 1;
    // pto: %70
    ;
    int64_t v173 = v62 * v23;
    // pto: %70
    ;
    int64_t v174 = v172 * v173;
    // pto: %70
    ;
    pto::Shape<1, 1, 1, -1, 512> v175 = pto::Shape<1, 1, 1, -1, 512>(v170, v171, v172, v62, v23);
    // pto: %70
    ;
    pto::Stride<-1, -1, -1, -1, -1> v176 = pto::Stride<-1, -1, -1, -1, -1>(v171 * v174, v174, v173, v23, v22);
    // pto: %70
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v177 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v169 + (v168 + v167 * v23 + v27 * v22), v175, v176);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    TLOAD(v165, v177);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %c_block_slots_inline5362__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v178 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v23);
    // pto: %c_block_slots_inline5362__ssa_v0
    ;
    uint64_t v179 = (uint64_t) v17;
    TASSIGN(v178, v179);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    RoundMode v180 = RoundMode::CAST_ROUND;
    SaturationMode v181 = SaturationMode::ON;
    TCVT(v178, v165, v180, v181);
    // pto: %t__tmp_v931
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v182 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v23);
    // pto: %t__tmp_v931
    ;
    uint64_t v183 = (uint64_t) v17;
    TASSIGN(v182, v183);
    pipe_barrier(PIPE_V);
    TADDS(v182, v178, v34);
    // pto: %t__tmp_v932
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v184 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v23);
    // pto: %t__tmp_v932
    ;
    uint64_t v185 = (uint64_t) v17;
    TASSIGN(v184, v185);
    pipe_barrier(PIPE_V);
    TMAXS(v184, v182, v32);
    // pto: %t__tmp_v933
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v186 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v23);
    // pto: %t__tmp_v933
    ;
    uint64_t v187 = (uint64_t) v17;
    TASSIGN(v186, v187);
    pipe_barrier(PIPE_V);
    TMINS(v186, v184, v34);
    // pto: %c_blk_valid_inline5209__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v188 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v22);
    // pto: %c_blk_valid_inline5209__ssa_v0
    ;
    uint64_t v189 = (uint64_t) v18;
    TASSIGN(v188, v189);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    TROWMAX(v188, v186, v163);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_V, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
    for (int64_t v190 = v27; v190 < v62; v190 += v22) {
      // pto: %t__tmp_v934
      ;
      float v191 = v188.GetValue(v190);
      // pto: %73
      ;
      int32_t v192 = (int32_t) v191;
      // pto: %74, %75, %76
      ;
      int64_t v193 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v60 + (uint64_t) v190) * (uint64_t) v24) + (uint64_t) v22);
      (v7)[v193] = v192;
    };
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  dsb((mem_dsb_t)0);
  #endif // __DAV_VEC__

  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  dsb((mem_dsb_t)0);
  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}