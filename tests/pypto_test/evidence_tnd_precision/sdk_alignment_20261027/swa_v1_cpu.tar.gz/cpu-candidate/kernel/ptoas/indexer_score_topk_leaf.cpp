#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void indexer_score_topk_leaf_aic(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ float* v3, __gm__ int32_t* v4, __gm__ int8_t* v5, __gm__ float* v6, __gm__ float* v7, __gm__ int32_t* v8, __gm__ int8_t* v9, __gm__ int8_t* v10, __gm__ int8_t* v11, __gm__ float* v12, __gm__ float* v13, int64_t v14, int64_t v15, int64_t v16, int64_t v17, int64_t v18, int64_t v19, int64_t v20, int64_t v21, int32_t v22, int32_t v23) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int64_t v24 = 32;
  const int32_t v25 = 0;
  // pto: %c0_i64
  const int64_t v26 = 0;
  // pto: %c8192_i64
  const int64_t v27 = 8192;
  // pto: %c4096_i64
  const int64_t v28 = 4096;
  // pto: %c24576_i64
  const int64_t v29 = 24576;
  // pto: %c57344_i64
  const int64_t v30 = 57344;
  // pto: %c12288_i64
  const int64_t v31 = 12288;
  // pto: %c1_index
  const int64_t v32 = 1;
  // pto: %c8192_index
  const int64_t v33 = 8192;
  // pto: %c27648_index
  const int64_t v34 = 27648;
  // pto: %c128_index
  const int64_t v35 = 128;
  // pto: %c64_index
  const int64_t v36 = 64;
  // pto: %c0_index
  const int64_t v37 = 0;
  // pto: %c4_index
  const int64_t v38 = 4;
  // pto: %c262144_index
  const int64_t v39 = 262144;
  // pto: %c8191_index
  const int64_t v40 = 8191;
  // pto: %c24_index
  const int64_t v41 = 24;
  // pto: %c1_i64
  const int64_t v42 = 1;
  // pto: %c4_i64
  const int64_t v43 = 4;
  // pto: %c383_index
  const int64_t v44 = 383;
  // pto: %c384_index
  const int64_t v45 = 384;
  // pto: %c192_index
  const int64_t v46 = 192;
  // pto: %c4096_index
  const int64_t v47 = 4096;
  // pto: %c191_index
  const int64_t v48 = 191;
  // pto: %c6_index
  const int64_t v49 = 6;
  // pto: %c32_index
  const int64_t v50 = 32;
  // pto: %c2_index
  const int64_t v51 = 2;
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  const int64_t v52 = 1;
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  const int64_t v53 = 1;
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  const int64_t v54 = 1;
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  int64_t v55 = v34 * v35;
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  int64_t v56 = v54 * v55;
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v57 = pto::Shape<1, 1, 1, -1, -1>(v52, v53, v54, v34, v35);
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v58 = pto::Stride<-1, -1, -1, -1, -1>(v53 * v56, v56, v55, v35, v32);
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v59 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v57, v58);
  // pto: %idx_kv_cache_inline1400_inline5095__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %idx_kv_cache_inline1400_inline5095__ssa_v0_view
  const int64_t v61 = 1;
  // pto: %idx_kv_cache_inline1400_inline5095__ssa_v0_view
  const int64_t v62 = 1;
  // pto: %idx_kv_cache_inline1400_inline5095__ssa_v0_view
  int64_t v63 = (int64_t) v18;
  // pto: %idx_kv_cache_inline1400_inline5095__ssa_v0_view
  int64_t v64 = v63 * v35;
  // pto: %idx_kv_cache_inline1400_inline5095__ssa_v0_view
  int64_t v65 = v62 * v64;
  // pto: %idx_kv_cache_inline1400_inline5095__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v66 = pto::Shape<1, 1, 1, -1, -1>(v60, v61, v62, v63, v35);
  // pto: %idx_kv_cache_inline1400_inline5095__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v67 = pto::Stride<-1, -1, -1, -1, -1>(v61 * v65, v65, v64, v35, v32);
  // pto: %idx_kv_cache_inline1400_inline5095__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v68 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v66, v67);
  // pto: %idx_kv_cache_shift64_inline1427_inline5092__ssa_v0_view
  const int64_t v69 = 1;
  // pto: %idx_kv_cache_shift64_inline1427_inline5092__ssa_v0_view
  const int64_t v70 = 1;
  // pto: %idx_kv_cache_shift64_inline1427_inline5092__ssa_v0_view
  const int64_t v71 = 1;
  // pto: %idx_kv_cache_shift64_inline1427_inline5092__ssa_v0_view
  int64_t v72 = (int64_t) v19;
  // pto: %idx_kv_cache_shift64_inline1427_inline5092__ssa_v0_view
  int64_t v73 = v72 * v35;
  // pto: %idx_kv_cache_shift64_inline1427_inline5092__ssa_v0_view
  int64_t v74 = v71 * v73;
  // pto: %idx_kv_cache_shift64_inline1427_inline5092__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v75 = pto::Shape<1, 1, 1, -1, -1>(v69, v70, v71, v72, v35);
  // pto: %idx_kv_cache_shift64_inline1427_inline5092__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v76 = pto::Stride<-1, -1, -1, -1, -1>(v70 * v74, v74, v73, v35, v32);
  // pto: %idx_kv_cache_shift64_inline1427_inline5092__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v77 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v10, v75, v76);
  // pto: %kv_i8_inline1438_inline5088__phi_v5
  Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v78 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
  // pto: %kv_i8_inline1438_inline5088__phi_v5
  uint64_t v79 = (uint64_t) v27;
  TASSIGN(v78, v79);
  // pto: %kv_i8_inline1438_inline5088__phi_v10
  Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v80 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
  // pto: %kv_i8_inline1438_inline5088__phi_v10
  uint64_t v81 = (uint64_t) v27;
  TASSIGN(v80, v81);
  // pto: %163
  Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v82 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
  // pto: %163
  uint64_t v83 = (uint64_t) v30;
  TASSIGN(v82, v83);
  // pto: %195
  Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v84 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
  // pto: %195
  uint64_t v85 = (uint64_t) v30;
  TASSIGN(v84, v85);
  // pto: %237
  Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v86 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
  // pto: %237
  uint64_t v87 = (uint64_t) v27;
  TASSIGN(v86, v87);
  // pto: %269
  Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v88 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
  // pto: %269
  uint64_t v89 = (uint64_t) v27;
  TASSIGN(v88, v89);
  const int32_t v90 = 0;
  auto v91 = TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>(v13, v25, v90);
  // pto: %worker_inline1409_inline5141__ssa_v0
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  // pto: %max_cache_len_inline1392_inline5142__rv_v2
  int64_t v92;
  v92 = v37;
  for (int64_t v93 = v37; v93 < v16; v93 += v32) {
    // pto: %t__tile
    ;
    int32_t v94 = (v2)[v93];
    // pto: %33, %34
    ;
    int64_t v95 = (int64_t) v94 / v38;
    // pto: %35
    ;
    bool v96 = v92 < v95;
    // pto: %35
    ;
    int64_t v97 = v96 ? v95 : v92;
    v92 = v97;
  }
  // pto: %36
  bool v98 = v92 < v39;
  // pto: %36
  int64_t v99 = v98 ? v92 : v39;
  // pto: %37, %38
  int64_t v100 = (int64_t) ((uint64_t) v99 + (uint64_t) v40) / v33;
  // pto: %39
  int64_t v101 = v100 < v32 ? v32 : v100;
  // pto: %40, %41
  int64_t v102 = (int64_t) (v101 == v32);
  // pto: %42
  for (int64_t v103 = (int64_t) v22; v103 < ((int64_t) ((uint64_t) v15 * (uint64_t) v101)); v103 += v41) {
    // pto: %43
    ;
    int64_t v104 = v103 / v101;
    // pto: %44
    ;
    int64_t v105 = v103 % v101;
    // pto: %48, %45, %46, %47, %49, %50, %51
    ;
    int64_t v106 = v105 != v37 & (v105 < v37 ^ v101 < v37) ? (int64_t) ((uint64_t) v105 + (uint64_t) v101) : v105;
    // pto: %52
    ;
    int32_t v107 = (v4)[v104];
    // pto: %53
    ;
    int64_t v108 = (int64_t) v107;
    // pto: %position_inline1428_inline5123__tile
    ;
    int64_t v109 = (v1)[v104];
    // pto: %55
    ;
    int64_t v110 = v108 < v37 ? v37 : v108;
    // pto: %54
    ;
    int32_t v111 = (v2)[v110];
    // pto: %58, %56, %57, %cache_len_inline1383_inline5155__phi_v2
    ;
    int64_t v112 = v108 < v37 ? v37 : (int64_t) v111 / v38;
    // pto: %59, %60
    ;
    int64_t v113 = (int64_t) ((uint64_t) v109 + (uint64_t) v42) / v43;
    // pto: %62
    ;
    int64_t v114 = v112 < v113 ? v112 : v113;
    // pto: %63
    ;
    int64_t v115 = v114 < v39 ? v114 : v39;
    // pto: %64
    ;
    int64_t v116 = v115 < v37 ? v37 : v115;
    // pto: %65
    ;
    int64_t v117 = (int64_t) ((uint64_t) v106 * (uint64_t) v33);
    // pto: %66
    ;
    if (v117 < v116) {
      // pto: %67
      ;
      int64_t v118 = (int64_t) ((uint64_t) v116 - (uint64_t) v117);
      // pto: %68
      ;
      int64_t v119 = v118 < v33 ? v118 : v33;
      // pto: %69, %70, %71
      ;
      int64_t v120 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v119 + (uint64_t) v44) / v45) * (uint64_t) v46);
      // pto: %72
      ;
      int64_t v121 = v120 < v47 ? v120 : v47;
      // pto: %73, %76, %74, %75
      ;
      int64_t v122 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v102 * (uint64_t) v46) + (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v32 - (uint64_t) v102) * (uint64_t) v121));
      // pto: %77
      ;
      int64_t v123 = (int64_t) ((uint64_t) v104 * (uint64_t) v36);
      // pto: %query_vector_inline1436_inline5153__tile
      ;
      Tile<TileType::Mat, int8_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Mat, int8_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v35);
      // pto: %query_vector_inline1436_inline5153__tile
      ;
      uint64_t v125 = (uint64_t) v26;
      TASSIGN(v124, v125);
      // pto: %78
      ;
      int64_t v126 = v123 < v37 ? v37 : v123;
      // pto: %qr_hadamard_i8_inline979__rv_v2_pview
      ;
      __gm__ int8_t* v127 = PTOAS__GLOBAL_TENSOR_DATA(v59);
      // pto: %qr_hadamard_i8_inline979__rv_v2_pview
      ;
      const int64_t v128 = 0;
      // pto: %qr_hadamard_i8_inline979__rv_v2_pview
      ;
      const int64_t v129 = 128;
      // pto: %qr_hadamard_i8_inline979__rv_v2_pview
      ;
      pto::Shape<1, 1, 1, 64, 128> v130 = pto::Shape<1, 1, 1, 64, 128>();
      // pto: %qr_hadamard_i8_inline979__rv_v2_pview
      ;
      pto::Stride<8192, 8192, 8192, 128, 1> v131 = pto::Stride<8192, 8192, 8192, 128, 1>();
      // pto: %qr_hadamard_i8_inline979__rv_v2_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND> v132 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND>(v127 + (v128 + v126 * v129), v130, v131);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v124, v132);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %79
      ;
      int64_t v133 = (int64_t) ((uint64_t) v121 + (uint64_t) v48);
      // pto: %80
      ;
      int64_t v134 = v133 / v45;
      // pto: %81
      ;
      int64_t v135 = (int64_t) ((uint64_t) v134 * (uint64_t) v45);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
      for (int64_t v136 = v37; v136 < v135; v136 += v45) {
        // pto: %82
        ;
        int64_t v137 = (int64_t) ((uint64_t) v102 + (uint64_t) v32);
        // pto: %83
        ;
        int64_t v138 = (int64_t) ((uint64_t) v136 * (uint64_t) v137);
        // pto: %84, %86
        ;
        int64_t v139 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v136 + (uint64_t) v46) * (uint64_t) v137);
        // pto: %kv_i8_inline1438_inline5088__tile
        ;
        Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v140 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
        // pto: %kv_i8_inline1438_inline5088__tile
        ;
        uint64_t v141 = (uint64_t) v27;
        TASSIGN(v140, v141);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        for (int64_t v142 = v37; v142 < v49; v142 += v32) {
          // pto: %88
          ;
          int64_t v143 = (int64_t) ((uint64_t) v142 * (uint64_t) v50);
          // pto: %87, %89, %90
          ;
          int64_t v144 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v117 + (uint64_t) v138) + (uint64_t) v143) / v50;
          // pto: %91, %92
          ;
          int64_t v145 = (int64_t) ((uint64_t) v112 - (uint64_t) v32) / v50;
          // pto: %93
          ;
          int64_t v146 = v145 < v37 ? v37 : v145;
          // pto: %94
          ;
          int64_t v147 = v144 < v146 ? v144 : v146;
          // pto: %flat_offset_mul, %flat_offset, %95
          ;
          int32_t v148 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v108 * (uint64_t) v17) + (uint64_t) v147)];
          // pto: %96
          ;
          int64_t v149 = (int64_t) v148;
          // pto: %97
          ;
          int64_t v150 = v149 < v37 ? v37 : v149;
          // pto: %98
          ;
          int64_t v151 = (int64_t) ((uint64_t) v150 * (uint64_t) v14);
          // pto: %99
          ;
          int64_t v152 = v151 % v35;
          // pto: %100, %101, %102
          ;
          int64_t v153 = v152 < v37 ? (int64_t) ((uint64_t) v152 + (uint64_t) v35) : v152;
          // pto: %103
          ;
          if (v153 == v37) {
            // pto: %gather_row_view
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v154;
            // pto: %gather_row_view
            ;
            uint64_t v155 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v143 * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v154, v155);
            // pto: %105
            ;
            int64_t v156 = v151 / v35;
            // pto: %106
            ;
            int64_t v157 = v156 < v37 ? v37 : v156;
            // pto: %idx_kv_cache_inline1400_inline5095__ssa_v0_pview
            ;
            __gm__ int8_t* v158 = PTOAS__GLOBAL_TENSOR_DATA(v68);
            // pto: %idx_kv_cache_inline1400_inline5095__ssa_v0_pview
            ;
            const int64_t v159 = 0;
            // pto: %idx_kv_cache_inline1400_inline5095__ssa_v0_pview
            ;
            const int64_t v160 = 128;
            // pto: %idx_kv_cache_inline1400_inline5095__ssa_v0_pview
            ;
            pto::Shape<1, 1, 1, 32, 128> v161 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %idx_kv_cache_inline1400_inline5095__ssa_v0_pview
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v162 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %idx_kv_cache_inline1400_inline5095__ssa_v0_pview
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v163 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v158 + (v159 + v157 * v160), v161, v162);
            TLOAD(v154, v163);
          } else {
            // pto: %108
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v164;
            // pto: %108
            ;
            uint64_t v165 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v143 * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v164, v165);
            // pto: %109
            ;
            int64_t v166 = v151 / v35;
            // pto: %110
            ;
            int64_t v167 = v166 < v37 ? v37 : v166;
            // pto: %idx_kv_cache_shift64_inline1427_inline5092__ssa_v0_pview
            ;
            __gm__ int8_t* v168 = PTOAS__GLOBAL_TENSOR_DATA(v77);
            // pto: %idx_kv_cache_shift64_inline1427_inline5092__ssa_v0_pview
            ;
            const int64_t v169 = 0;
            // pto: %idx_kv_cache_shift64_inline1427_inline5092__ssa_v0_pview
            ;
            const int64_t v170 = 128;
            // pto: %idx_kv_cache_shift64_inline1427_inline5092__ssa_v0_pview
            ;
            pto::Shape<1, 1, 1, 32, 128> v171 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %idx_kv_cache_shift64_inline1427_inline5092__ssa_v0_pview
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v172 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %idx_kv_cache_shift64_inline1427_inline5092__ssa_v0_pview
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v173 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v168 + (v169 + v167 * v170), v171, v172);
            TLOAD(v164, v173);
          };
        };
        for (int64_t v174 = v37; v174 < v49; v174 += v32) {
          // pto: %113
          ;
          int64_t v175 = (int64_t) ((uint64_t) v174 * (uint64_t) v50);
          // pto: %111, %112, %114, %115
          ;
          int64_t v176 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v117 + (uint64_t) v138) + (uint64_t) v122) + (uint64_t) v175) / v50;
          // pto: %116, %117
          ;
          int64_t v177 = (int64_t) ((uint64_t) v112 - (uint64_t) v32) / v50;
          // pto: %118
          ;
          int64_t v178 = v177 < v37 ? v37 : v177;
          // pto: %119
          ;
          int64_t v179 = v176 < v178 ? v176 : v178;
          // pto: %121, %122, %120
          ;
          int32_t v180 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v108 * (uint64_t) v17) + (uint64_t) v179)];
          // pto: %123
          ;
          int64_t v181 = (int64_t) v180;
          // pto: %124
          ;
          int64_t v182 = v181 < v37 ? v37 : v181;
          // pto: %125
          ;
          int64_t v183 = (int64_t) ((uint64_t) v182 * (uint64_t) v14);
          // pto: %126
          ;
          int64_t v184 = v183 % v35;
          // pto: %127, %128, %129
          ;
          int64_t v185 = v184 < v37 ? (int64_t) ((uint64_t) v184 + (uint64_t) v35) : v184;
          // pto: %130
          ;
          if (v185 == v37) {
            // pto: %133
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v186;
            // pto: %132, %133
            ;
            uint64_t v187 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v175 + (uint64_t) v46) * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v186, v187);
            // pto: %134
            ;
            int64_t v188 = v183 / v35;
            // pto: %135
            ;
            int64_t v189 = v188 < v37 ? v37 : v188;
            // pto: %136
            ;
            __gm__ int8_t* v190 = PTOAS__GLOBAL_TENSOR_DATA(v68);
            // pto: %136
            ;
            const int64_t v191 = 0;
            // pto: %136
            ;
            const int64_t v192 = 128;
            // pto: %136
            ;
            pto::Shape<1, 1, 1, 32, 128> v193 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %136
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v194 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %136
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v195 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v190 + (v191 + v189 * v192), v193, v194);
            TLOAD(v186, v195);
          } else {
            // pto: %139
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v196;
            // pto: %138, %139
            ;
            uint64_t v197 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v175 + (uint64_t) v46) * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v196, v197);
            // pto: %140
            ;
            int64_t v198 = v183 / v35;
            // pto: %141
            ;
            int64_t v199 = v198 < v37 ? v37 : v198;
            // pto: %142
            ;
            __gm__ int8_t* v200 = PTOAS__GLOBAL_TENSOR_DATA(v77);
            // pto: %142
            ;
            const int64_t v201 = 0;
            // pto: %142
            ;
            const int64_t v202 = 128;
            // pto: %142
            ;
            pto::Shape<1, 1, 1, 32, 128> v203 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %142
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v204 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %142
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v205 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v200 + (v201 + v199 * v202), v203, v204);
            TLOAD(v196, v205);
          };
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %kv_i8_inline1438_inline5088__rv_v7_t
        ;
        Tile<TileType::Mat, int8_t, 128, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v206 = Tile<TileType::Mat, int8_t, 128, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v35, v45);
        // pto: %kv_i8_inline1438_inline5088__rv_v7_t
        ;
        uint64_t v207 = (uint64_t) v27;
        TASSIGN(v206, v207);
        // pto: %score_i32_inline1377_inline5080__tile_l0_init
        ;
        Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v208 = Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %score_i32_inline1377_inline5080__tile_l0_init
        ;
        uint64_t v209 = (uint64_t) v26;
        TASSIGN(v208, v209);
        // pto: %score_i32_inline1377_inline5080__tile_l0_a
        ;
        Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v210 = Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
        // pto: %score_i32_inline1377_inline5080__tile_l0_a
        ;
        uint64_t v211 = (uint64_t) v26;
        TASSIGN(v210, v211);
        uint16_t v212 = static_cast<uint16_t>(v37);
        uint16_t v213 = static_cast<uint16_t>(v37);
        TEXTRACT(v210, v124, v212, v213);
        // pto: %score_i32_inline1377_inline5080__tile_l0_b
        ;
        Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v214 = Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %score_i32_inline1377_inline5080__tile_l0_b
        ;
        uint64_t v215 = (uint64_t) v26;
        TASSIGN(v214, v215);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v216 = static_cast<uint16_t>(v37);
        uint16_t v217 = static_cast<uint16_t>(v37);
        TEXTRACT(v214, v206, v216, v217);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %4
        ;
        Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
        // pto: %4
        ;
        uint64_t v219 = (uint64_t) v28;
        TASSIGN(v218, v219);
        uint16_t v220 = static_cast<uint16_t>(v37);
        uint16_t v221 = static_cast<uint16_t>(v36);
        TEXTRACT(v218, v124, v220, v221);
        // pto: %5
        ;
        Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v222 = Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %5
        ;
        uint64_t v223 = (uint64_t) v29;
        TASSIGN(v222, v223);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v224 = static_cast<uint16_t>(v36);
        uint16_t v225 = static_cast<uint16_t>(v37);
        TEXTRACT(v222, v206, v224, v225);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v208, v210, v214);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v208, v208, v218, v222);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        TPUSH<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_LEFT_RIGHT>(v91, v208);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %7
        ;
        Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v226 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
        // pto: %7
        ;
        uint64_t v227 = (uint64_t) v30;
        TASSIGN(v226, v227);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        for (int64_t v228 = v37; v228 < v49; v228 += v32) {
          // pto: %145
          ;
          int64_t v229 = (int64_t) ((uint64_t) v228 * (uint64_t) v50);
          // pto: %144, %146, %147
          ;
          int64_t v230 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v117 + (uint64_t) v139) + (uint64_t) v229) / v50;
          // pto: %148, %149
          ;
          int64_t v231 = (int64_t) ((uint64_t) v112 - (uint64_t) v32) / v50;
          // pto: %150
          ;
          int64_t v232 = v231 < v37 ? v37 : v231;
          // pto: %151
          ;
          int64_t v233 = v230 < v232 ? v230 : v232;
          // pto: %153, %154, %152
          ;
          int32_t v234 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v108 * (uint64_t) v17) + (uint64_t) v233)];
          // pto: %155
          ;
          int64_t v235 = (int64_t) v234;
          // pto: %156
          ;
          int64_t v236 = v235 < v37 ? v37 : v235;
          // pto: %157
          ;
          int64_t v237 = (int64_t) ((uint64_t) v236 * (uint64_t) v14);
          // pto: %158
          ;
          int64_t v238 = v237 % v35;
          // pto: %159, %160, %161
          ;
          int64_t v239 = v238 < v37 ? (int64_t) ((uint64_t) v238 + (uint64_t) v35) : v238;
          // pto: %162
          ;
          if (v239 == v37) {
            // pto: %165
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v240;
            // pto: %165
            ;
            uint64_t v241 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v229 * (uint64_t) v24) + (uint64_t) v30);
            TASSIGN(v240, v241);
            // pto: %166
            ;
            int64_t v242 = v237 / v35;
            // pto: %167
            ;
            int64_t v243 = v242 < v37 ? v37 : v242;
            // pto: %168
            ;
            __gm__ int8_t* v244 = PTOAS__GLOBAL_TENSOR_DATA(v68);
            // pto: %168
            ;
            const int64_t v245 = 0;
            // pto: %168
            ;
            const int64_t v246 = 128;
            // pto: %168
            ;
            pto::Shape<1, 1, 1, 32, 128> v247 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %168
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v248 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %168
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v249 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v244 + (v245 + v243 * v246), v247, v248);
            TLOAD(v240, v249);
          } else {
            // pto: %170
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v250;
            // pto: %170
            ;
            uint64_t v251 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v229 * (uint64_t) v24) + (uint64_t) v30);
            TASSIGN(v250, v251);
            // pto: %171
            ;
            int64_t v252 = v237 / v35;
            // pto: %172
            ;
            int64_t v253 = v252 < v37 ? v37 : v252;
            // pto: %173
            ;
            __gm__ int8_t* v254 = PTOAS__GLOBAL_TENSOR_DATA(v77);
            // pto: %173
            ;
            const int64_t v255 = 0;
            // pto: %173
            ;
            const int64_t v256 = 128;
            // pto: %173
            ;
            pto::Shape<1, 1, 1, 32, 128> v257 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %173
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v258 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %173
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v259 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v254 + (v255 + v253 * v256), v257, v258);
            TLOAD(v250, v259);
          };
        };
        for (int64_t v260 = v37; v260 < v49; v260 += v32) {
          // pto: %177
          ;
          int64_t v261 = (int64_t) ((uint64_t) v260 * (uint64_t) v50);
          // pto: %175, %176, %178, %179
          ;
          int64_t v262 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v117 + (uint64_t) v139) + (uint64_t) v122) + (uint64_t) v261) / v50;
          // pto: %180, %181
          ;
          int64_t v263 = (int64_t) ((uint64_t) v112 - (uint64_t) v32) / v50;
          // pto: %182
          ;
          int64_t v264 = v263 < v37 ? v37 : v263;
          // pto: %183
          ;
          int64_t v265 = v262 < v264 ? v262 : v264;
          // pto: %185, %186, %184
          ;
          int32_t v266 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v108 * (uint64_t) v17) + (uint64_t) v265)];
          // pto: %187
          ;
          int64_t v267 = (int64_t) v266;
          // pto: %188
          ;
          int64_t v268 = v267 < v37 ? v37 : v267;
          // pto: %189
          ;
          int64_t v269 = (int64_t) ((uint64_t) v268 * (uint64_t) v14);
          // pto: %190
          ;
          int64_t v270 = v269 % v35;
          // pto: %191, %192, %193
          ;
          int64_t v271 = v270 < v37 ? (int64_t) ((uint64_t) v270 + (uint64_t) v35) : v270;
          // pto: %194
          ;
          if (v271 == v37) {
            // pto: %198
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v272;
            // pto: %197, %198
            ;
            uint64_t v273 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v261 + (uint64_t) v46) * (uint64_t) v24) + (uint64_t) v30);
            TASSIGN(v272, v273);
            // pto: %199
            ;
            int64_t v274 = v269 / v35;
            // pto: %200
            ;
            int64_t v275 = v274 < v37 ? v37 : v274;
            // pto: %201
            ;
            __gm__ int8_t* v276 = PTOAS__GLOBAL_TENSOR_DATA(v68);
            // pto: %201
            ;
            const int64_t v277 = 0;
            // pto: %201
            ;
            const int64_t v278 = 128;
            // pto: %201
            ;
            pto::Shape<1, 1, 1, 32, 128> v279 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %201
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v280 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %201
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v281 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v276 + (v277 + v275 * v278), v279, v280);
            TLOAD(v272, v281);
          } else {
            // pto: %204
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v282;
            // pto: %203, %204
            ;
            uint64_t v283 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v261 + (uint64_t) v46) * (uint64_t) v24) + (uint64_t) v30);
            TASSIGN(v282, v283);
            // pto: %205
            ;
            int64_t v284 = v269 / v35;
            // pto: %206
            ;
            int64_t v285 = v284 < v37 ? v37 : v284;
            // pto: %207
            ;
            __gm__ int8_t* v286 = PTOAS__GLOBAL_TENSOR_DATA(v77);
            // pto: %207
            ;
            const int64_t v287 = 0;
            // pto: %207
            ;
            const int64_t v288 = 128;
            // pto: %207
            ;
            pto::Shape<1, 1, 1, 32, 128> v289 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %207
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v290 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %207
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v291 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v286 + (v287 + v285 * v288), v289, v290);
            TLOAD(v282, v291);
          };
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        // pto: %12
        ;
        Tile<TileType::Mat, int8_t, 128, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v292 = Tile<TileType::Mat, int8_t, 128, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v35, v45);
        // pto: %12
        ;
        uint64_t v293 = (uint64_t) v30;
        TASSIGN(v292, v293);
        // pto: %13
        ;
        Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v294 = Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %13
        ;
        uint64_t v295 = (uint64_t) v26;
        TASSIGN(v294, v295);
        // pto: %14
        ;
        Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v296 = Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
        // pto: %14
        ;
        uint64_t v297 = (uint64_t) v27;
        TASSIGN(v296, v297);
        uint16_t v298 = static_cast<uint16_t>(v37);
        uint16_t v299 = static_cast<uint16_t>(v37);
        TEXTRACT(v296, v124, v298, v299);
        // pto: %15
        ;
        Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v300 = Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %15
        ;
        uint64_t v301 = (uint64_t) v26;
        TASSIGN(v300, v301);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v302 = static_cast<uint16_t>(v37);
        uint16_t v303 = static_cast<uint16_t>(v37);
        TEXTRACT(v300, v292, v302, v303);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %16
        ;
        Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v304 = Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
        // pto: %16
        ;
        uint64_t v305 = (uint64_t) v31;
        TASSIGN(v304, v305);
        uint16_t v306 = static_cast<uint16_t>(v37);
        uint16_t v307 = static_cast<uint16_t>(v36);
        TEXTRACT(v304, v124, v306, v307);
        // pto: %17
        ;
        Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v308 = Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %17
        ;
        uint64_t v309 = (uint64_t) v29;
        TASSIGN(v308, v309);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        uint16_t v310 = static_cast<uint16_t>(v36);
        uint16_t v311 = static_cast<uint16_t>(v37);
        TEXTRACT(v308, v292, v310, v311);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v294, v296, v300);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        TMATMUL_ACC(v294, v294, v304, v308);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TPUSH<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_LEFT_RIGHT>(v91, v294);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
      // pto: %209, %213, %212, %214
      ;
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
      if ((int64_t) ((uint64_t) (v133 / v46) - (uint64_t) ((int64_t) (uint64_t) v134 * (uint64_t) v51)) == v32) {
        // pto: %216, %215
        ;
        int64_t v312 = (int64_t) ((uint64_t) v135 * (uint64_t) ((int64_t) (uint64_t) v102 + (uint64_t) v32));
        // pto: %20
        ;
        Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
        // pto: %20
        ;
        uint64_t v314 = (uint64_t) v27;
        TASSIGN(v313, v314);
        for (int64_t v315 = v37; v315 < v49; v315 += v32) {
          // pto: %219
          ;
          int64_t v316 = (int64_t) ((uint64_t) v315 * (uint64_t) v50);
          // pto: %218, %220, %221
          ;
          int64_t v317 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v117 + (uint64_t) v312) + (uint64_t) v316) / v50;
          // pto: %222, %223
          ;
          int64_t v318 = (int64_t) ((uint64_t) v112 - (uint64_t) v32) / v50;
          // pto: %224
          ;
          int64_t v319 = v318 < v37 ? v37 : v318;
          // pto: %225
          ;
          int64_t v320 = v317 < v319 ? v317 : v319;
          // pto: %227, %228, %226
          ;
          int32_t v321 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v108 * (uint64_t) v17) + (uint64_t) v320)];
          // pto: %229
          ;
          int64_t v322 = (int64_t) v321;
          // pto: %230
          ;
          int64_t v323 = v322 < v37 ? v37 : v322;
          // pto: %231
          ;
          int64_t v324 = (int64_t) ((uint64_t) v323 * (uint64_t) v14);
          // pto: %232
          ;
          int64_t v325 = v324 % v35;
          // pto: %233, %234, %235
          ;
          int64_t v326 = v325 < v37 ? (int64_t) ((uint64_t) v325 + (uint64_t) v35) : v325;
          // pto: %236
          ;
          if (v326 == v37) {
            // pto: %239
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v327;
            // pto: %239
            ;
            uint64_t v328 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v316 * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v327, v328);
            // pto: %240
            ;
            int64_t v329 = v324 / v35;
            // pto: %241
            ;
            int64_t v330 = v329 < v37 ? v37 : v329;
            // pto: %242
            ;
            __gm__ int8_t* v331 = PTOAS__GLOBAL_TENSOR_DATA(v68);
            // pto: %242
            ;
            const int64_t v332 = 0;
            // pto: %242
            ;
            const int64_t v333 = 128;
            // pto: %242
            ;
            pto::Shape<1, 1, 1, 32, 128> v334 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %242
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v335 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %242
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v336 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v331 + (v332 + v330 * v333), v334, v335);
            TLOAD(v327, v336);
          } else {
            // pto: %244
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v337;
            // pto: %244
            ;
            uint64_t v338 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v316 * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v337, v338);
            // pto: %245
            ;
            int64_t v339 = v324 / v35;
            // pto: %246
            ;
            int64_t v340 = v339 < v37 ? v37 : v339;
            // pto: %247
            ;
            __gm__ int8_t* v341 = PTOAS__GLOBAL_TENSOR_DATA(v77);
            // pto: %247
            ;
            const int64_t v342 = 0;
            // pto: %247
            ;
            const int64_t v343 = 128;
            // pto: %247
            ;
            pto::Shape<1, 1, 1, 32, 128> v344 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %247
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v345 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %247
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v346 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v341 + (v342 + v340 * v343), v344, v345);
            TLOAD(v337, v346);
          };
        };
        for (int64_t v347 = v37; v347 < v49; v347 += v32) {
          // pto: %251
          ;
          int64_t v348 = (int64_t) ((uint64_t) v347 * (uint64_t) v50);
          // pto: %249, %250, %252, %253
          ;
          int64_t v349 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v117 + (uint64_t) v312) + (uint64_t) v122) + (uint64_t) v348) / v50;
          // pto: %254, %255
          ;
          int64_t v350 = (int64_t) ((uint64_t) v112 - (uint64_t) v32) / v50;
          // pto: %256
          ;
          int64_t v351 = v350 < v37 ? v37 : v350;
          // pto: %257
          ;
          int64_t v352 = v349 < v351 ? v349 : v351;
          // pto: %259, %260, %258
          ;
          int32_t v353 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v108 * (uint64_t) v17) + (uint64_t) v352)];
          // pto: %261
          ;
          int64_t v354 = (int64_t) v353;
          // pto: %262
          ;
          int64_t v355 = v354 < v37 ? v37 : v354;
          // pto: %263
          ;
          int64_t v356 = (int64_t) ((uint64_t) v355 * (uint64_t) v14);
          // pto: %264
          ;
          int64_t v357 = v356 % v35;
          // pto: %265, %266, %267
          ;
          int64_t v358 = v357 < v37 ? (int64_t) ((uint64_t) v357 + (uint64_t) v35) : v357;
          // pto: %268
          ;
          if (v358 == v37) {
            // pto: %272
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v359;
            // pto: %271, %272
            ;
            uint64_t v360 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v348 + (uint64_t) v46) * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v359, v360);
            // pto: %273
            ;
            int64_t v361 = v356 / v35;
            // pto: %274
            ;
            int64_t v362 = v361 < v37 ? v37 : v361;
            // pto: %275
            ;
            __gm__ int8_t* v363 = PTOAS__GLOBAL_TENSOR_DATA(v68);
            // pto: %275
            ;
            const int64_t v364 = 0;
            // pto: %275
            ;
            const int64_t v365 = 128;
            // pto: %275
            ;
            pto::Shape<1, 1, 1, 32, 128> v366 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %275
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v367 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %275
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v368 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v363 + (v364 + v362 * v365), v366, v367);
            TLOAD(v359, v368);
          } else {
            // pto: %278
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v369;
            // pto: %277, %278
            ;
            uint64_t v370 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v348 + (uint64_t) v46) * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v369, v370);
            // pto: %279
            ;
            int64_t v371 = v356 / v35;
            // pto: %280
            ;
            int64_t v372 = v371 < v37 ? v37 : v371;
            // pto: %281
            ;
            __gm__ int8_t* v373 = PTOAS__GLOBAL_TENSOR_DATA(v77);
            // pto: %281
            ;
            const int64_t v374 = 0;
            // pto: %281
            ;
            const int64_t v375 = 128;
            // pto: %281
            ;
            pto::Shape<1, 1, 1, 32, 128> v376 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %281
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v377 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %281
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v378 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v373 + (v374 + v372 * v375), v376, v377);
            TLOAD(v369, v378);
          };
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
        // pto: %25
        ;
        Tile<TileType::Mat, int8_t, 128, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v379 = Tile<TileType::Mat, int8_t, 128, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v35, v45);
        // pto: %25
        ;
        uint64_t v380 = (uint64_t) v27;
        TASSIGN(v379, v380);
        // pto: %26
        ;
        Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v381 = Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %26
        ;
        uint64_t v382 = (uint64_t) v26;
        TASSIGN(v381, v382);
        // pto: %27
        ;
        Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v383 = Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
        // pto: %27
        ;
        uint64_t v384 = (uint64_t) v26;
        TASSIGN(v383, v384);
        uint16_t v385 = static_cast<uint16_t>(v37);
        uint16_t v386 = static_cast<uint16_t>(v37);
        TEXTRACT(v383, v124, v385, v386);
        // pto: %28
        ;
        Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v387 = Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %28
        ;
        uint64_t v388 = (uint64_t) v26;
        TASSIGN(v387, v388);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
        uint16_t v389 = static_cast<uint16_t>(v37);
        uint16_t v390 = static_cast<uint16_t>(v37);
        TEXTRACT(v387, v379, v389, v390);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        // pto: %29
        ;
        Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v391 = Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
        // pto: %29
        ;
        uint64_t v392 = (uint64_t) v28;
        TASSIGN(v391, v392);
        uint16_t v393 = static_cast<uint16_t>(v37);
        uint16_t v394 = static_cast<uint16_t>(v36);
        TEXTRACT(v391, v124, v393, v394);
        // pto: %30
        ;
        Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v395 = Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %30
        ;
        uint64_t v396 = (uint64_t) v29;
        TASSIGN(v395, v396);
        uint16_t v397 = static_cast<uint16_t>(v36);
        uint16_t v398 = static_cast<uint16_t>(v37);
        TEXTRACT(v395, v379, v397, v398);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        TMATMUL(v381, v383, v387);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        TMATMUL_ACC(v381, v381, v391, v395);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
        TPUSH<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_LEFT_RIGHT>(v91, v381);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    };
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void indexer_score_topk_leaf_aiv(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ float* v3, __gm__ int32_t* v4, __gm__ int8_t* v5, __gm__ float* v6, __gm__ float* v7, __gm__ int32_t* v8, __gm__ int8_t* v9, __gm__ int8_t* v10, __gm__ int8_t* v11, __gm__ float* v12, __gm__ float* v13, int64_t v14, int64_t v15, int64_t v16, int64_t v17, int64_t v18, int64_t v19, int64_t v20, int64_t v21, int32_t v22, int32_t v23, int32_t v24) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  pto::MrgSortExecutedNumList v25 = pto::MrgSortExecutedNumList{0, 0, 0, 0};
  // pto: %c131072_i64
  const int64_t v26 = 131072;
  // pto: %c131328_i64
  const int64_t v27 = 131328;
  // pto: %c98688_i64
  const int64_t v28 = 98688;
  // pto: %c98304_i64
  const int64_t v29 = 98304;
  // pto: %c131840_i64
  const int64_t v30 = 131840;
  // pto: %c133120_i64
  const int64_t v31 = 133120;
  const int64_t v32 = 135168;
  // pto: %c137216_i64
  const int64_t v33 = 137216;
  // pto: %c139264_i64
  const int64_t v34 = 139264;
  // pto: %c143360_i64
  const int64_t v35 = 143360;
  const int64_t v36 = 147456;
  // pto: %c155648_i64
  const int64_t v37 = 155648;
  // pto: %c141312_i64
  const int64_t v38 = 141312;
  const int64_t v39 = 151552;
  // pto: %c161792_i64
  const int64_t v40 = 161792;
  // pto: %c172032_i64
  const int64_t v41 = 172032;
  // pto: %c167936_i64
  const int64_t v42 = 167936;
  // pto: %c110592_i64
  const int64_t v43 = 110592;
  // pto: %c163840_i64
  const int64_t v44 = 163840;
  const int64_t v45 = 114688;
  // pto: %c1_index
  const int64_t v46 = 1;
  // pto: %c432_index
  const int64_t v47 = 432;
  // pto: %c8192_index
  const int64_t v48 = 8192;
  // pto: %c27648_index
  const int64_t v49 = 27648;
  // pto: %c64_index
  const int64_t v50 = 64;
  // pto: %c1024_index
  const int64_t v51 = 1024;
  // pto: %c0_i32
  const int32_t v52 = 0;
  // pto: %c0_index
  const int64_t v53 = 0;
  // pto: %c4_index
  const int64_t v54 = 4;
  // pto: %c262144_index
  const int64_t v55 = 262144;
  // pto: %c8191_index
  const int64_t v56 = 8191;
  // pto: %c24_index
  const int64_t v57 = 24;
  // pto: %c1_i64
  const int64_t v58 = 1;
  // pto: %c4_i64
  const int64_t v59 = 4;
  // pto: %c383_index
  const int64_t v60 = 383;
  // pto: %c384_index
  const int64_t v61 = 384;
  // pto: %c192_index
  const int64_t v62 = 192;
  // pto: %c4096_index
  const int64_t v63 = 4096;
  // pto: %c191_index
  const int64_t v64 = 191;
  // pto: %c2_index
  const int64_t v65 = 2;
  // pto: %c6_index
  const int64_t v66 = 6;
  // pto: %c32_index
  const int64_t v67 = 32;
  // pto: %cst_43
  const float v68 = 0.0f;
  // pto: %c512_index
  const int64_t v69 = 512;
  // pto: %cst_45
  const float v70 = -3.40282347E+38f;
  // pto: %c64_i32
  const int32_t v71 = 64;
  // pto: %c256_i32
  const int32_t v72 = 256;
  // pto: %c2048_index
  const int64_t v73 = 2048;
  // pto: %c1024_i32
  const int32_t v74 = 1024;
  // pto: %c2560_index
  const int64_t v75 = 2560;
  // pto: %c5120_index
  const int64_t v76 = 5120;
  // pto: %c3072_index
  const int64_t v77 = 3072;
  // pto: %c6144_index
  const int64_t v78 = 6144;
  // pto: %score_arena_inline1391_inline5091__ssa_v0_view
  const int64_t v79 = 1;
  // pto: %score_arena_inline1391_inline5091__ssa_v0_view
  const int64_t v80 = 1;
  // pto: %score_arena_inline1391_inline5091__ssa_v0_view
  const int64_t v81 = 1;
  // pto: %score_arena_inline1391_inline5091__ssa_v0_view
  int64_t v82 = v47 * v48;
  // pto: %score_arena_inline1391_inline5091__ssa_v0_view
  int64_t v83 = v81 * v82;
  // pto: %score_arena_inline1391_inline5091__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v84 = pto::Shape<1, 1, 1, -1, -1>(v79, v80, v81, v47, v48);
  // pto: %score_arena_inline1391_inline5091__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v85 = pto::Stride<-1, -1, -1, -1, -1>(v80 * v83, v83, v82, v48, v46);
  // pto: %score_arena_inline1391_inline5091__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v86 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v84, v85);
  // pto: %qr_hadamard_scale_dq_inline976__rv_v2_view
  const int64_t v87 = 1;
  // pto: %qr_hadamard_scale_dq_inline976__rv_v2_view
  const int64_t v88 = 1;
  // pto: %qr_hadamard_scale_dq_inline976__rv_v2_view
  const int64_t v89 = 1;
  // pto: %qr_hadamard_scale_dq_inline976__rv_v2_view
  int64_t v90 = v49 * v46;
  // pto: %qr_hadamard_scale_dq_inline976__rv_v2_view
  int64_t v91 = v89 * v90;
  // pto: %qr_hadamard_scale_dq_inline976__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v92 = pto::Shape<1, 1, 1, -1, -1>(v87, v88, v89, v49, v46);
  // pto: %qr_hadamard_scale_dq_inline976__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v93 = pto::Stride<-1, -1, -1, -1, -1>(v88 * v91, v91, v90, v46, v49);
  // pto: %qr_hadamard_scale_dq_inline976__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v94 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v6, v92, v93);
  // pto: %weights_inline5133__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %weights_inline5133__ssa_v0_view
  const int64_t v96 = 1;
  // pto: %weights_inline5133__ssa_v0_view
  const int64_t v97 = 1;
  // pto: %weights_inline5133__ssa_v0_view
  int64_t v98 = v47 * v50;
  // pto: %weights_inline5133__ssa_v0_view
  int64_t v99 = v97 * v98;
  // pto: %weights_inline5133__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v100 = pto::Shape<1, 1, 1, -1, -1>(v95, v96, v97, v47, v50);
  // pto: %weights_inline5133__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v101 = pto::Stride<-1, -1, -1, -1, -1>(v96 * v99, v99, v98, v50, v46);
  // pto: %weights_inline5133__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v102 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v100, v101);
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v103 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v104 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v105 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v106 = (int64_t) v20;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v107 = (int64_t) v21;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v108 = v106 * v107;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v109 = v105 * v108;
  // pto: %idx_native_kv_cache__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v110 = pto::Shape<1, 1, 1, -1, -1>(v103, v104, v105, v106, (int64_t) v21);
  // pto: %idx_native_kv_cache__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v111 = pto::Stride<-1, -1, -1, -1, -1>(v104 * v109, v109, v108, v107, v46);
  // pto: %idx_native_kv_cache__rv_v2_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v112 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v11, v110, v111);
  // pto: %pair_arena_inline1406_inline5120__ssa_v0_view
  const int64_t v113 = 1;
  // pto: %pair_arena_inline1406_inline5120__ssa_v0_view
  const int64_t v114 = 1;
  // pto: %pair_arena_inline1406_inline5120__ssa_v0_view
  const int64_t v115 = 1;
  // pto: %pair_arena_inline1406_inline5120__ssa_v0_view
  int64_t v116 = v49 * v51;
  // pto: %pair_arena_inline1406_inline5120__ssa_v0_view
  int64_t v117 = v115 * v116;
  // pto: %pair_arena_inline1406_inline5120__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v118 = pto::Shape<1, 1, 1, -1, -1>(v113, v114, v115, v49, v51);
  // pto: %pair_arena_inline1406_inline5120__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v119 = pto::Stride<-1, -1, -1, -1, -1>(v114 * v117, v117, v116, v51, v46);
  // pto: %pair_arena_inline1406_inline5120__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v120 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v12, v118, v119);
  const int32_t v121 = 0;
  auto v122 = TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>(v13, v52, v121);
  // pto: %worker_inline1409_inline5141__ssa_v0
  int64_t v123 = (int64_t) v22;
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  // pto: %max_cache_len_inline1392_inline5142__rv_v2
  int64_t v124;
  v124 = v53;
  for (int64_t v125 = v53; v125 < v16; v125 += v46) {
    // pto: %26
    ;
    int32_t v126 = (v2)[v125];
    // pto: %27, %28
    ;
    int64_t v127 = (int64_t) v126 / v54;
    // pto: %29
    ;
    bool v128 = v124 < v127;
    // pto: %29
    ;
    int64_t v129 = v128 ? v127 : v124;
    v124 = v129;
  }
  // pto: %30
  bool v130 = v124 < v55;
  // pto: %30
  int64_t v131 = v130 ? v124 : v55;
  // pto: %31, %32
  int64_t v132 = (int64_t) ((uint64_t) v131 + (uint64_t) v56) / v48;
  // pto: %33
  int64_t v133 = v132 < v46 ? v46 : v132;
  // pto: %34, %35
  int64_t v134 = (int64_t) (v133 == v46);
  // pto: %36
  for (int64_t v135 = v123; v135 < ((int64_t) ((uint64_t) v15 * (uint64_t) v133)); v135 += v57) {
    // pto: %37
    ;
    int64_t v136 = v135 / v133;
    // pto: %38
    ;
    int64_t v137 = v135 % v133;
    // pto: %42, %39, %40, %41, %43, %44, %45
    ;
    int64_t v138 = v137 != v53 & (v137 < v53 ^ v133 < v53) ? (int64_t) ((uint64_t) v137 + (uint64_t) v133) : v137;
    // pto: %46
    ;
    int32_t v139 = (v4)[v136];
    // pto: %47
    ;
    int64_t v140 = (int64_t) v139;
    // pto: %position_inline1428_inline5123__tile
    ;
    int64_t v141 = (v1)[v136];
    // pto: %49
    ;
    int64_t v142 = v140 < v53 ? v53 : v140;
    // pto: %48
    ;
    int32_t v143 = (v2)[v142];
    // pto: %52, %50, %51, %cache_len_inline1383_inline5155__phi_v2
    ;
    int64_t v144 = v140 < v53 ? v53 : (int64_t) v143 / v54;
    // pto: %53, %54
    ;
    int64_t v145 = (int64_t) ((uint64_t) v141 + (uint64_t) v58) / v59;
    // pto: %56
    ;
    int64_t v146 = v144 < v145 ? v144 : v145;
    // pto: %57
    ;
    int64_t v147 = v146 < v55 ? v146 : v55;
    // pto: %58
    ;
    int64_t v148 = v147 < v53 ? v53 : v147;
    // pto: %59
    ;
    int64_t v149 = (int64_t) ((uint64_t) v138 * (uint64_t) v48);
    // pto: %60
    ;
    if (v149 < v148) {
      // pto: %61
      ;
      int64_t v150 = (int64_t) ((uint64_t) v148 - (uint64_t) v149);
      // pto: %62
      ;
      int64_t v151 = v150 < v48 ? v150 : v48;
      // pto: %63, %64, %65
      ;
      int64_t v152 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v151 + (uint64_t) v60) / v61) * (uint64_t) v62);
      // pto: %66
      ;
      int64_t v153 = v152 < v63 ? v152 : v63;
      // pto: %68
      ;
      int64_t v154 = (int64_t) ((uint64_t) v46 - (uint64_t) v134);
      // pto: %67, %70, %69
      ;
      int64_t v155 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v134 * (uint64_t) v62) + (uint64_t) ((int64_t) (uint64_t) v154 * (uint64_t) v153));
      // pto: %71
      ;
      int64_t v156 = (int64_t) ((uint64_t) v136 * (uint64_t) v50);
      // pto: %t__tile
      ;
      Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v46);
      // pto: %t__tile
      ;
      uint64_t v158 = (uint64_t) v26;
      TASSIGN(v157, v158);
      // pto: %72
      ;
      int64_t v159 = v156 < v53 ? v53 : v156;
      // pto: %qr_hadamard_scale_dq_inline976__rv_v2_pview
      ;
      __gm__ float* v160 = PTOAS__GLOBAL_TENSOR_DATA(v94);
      // pto: %qr_hadamard_scale_dq_inline976__rv_v2_pview
      ;
      const int64_t v161 = 0;
      // pto: %qr_hadamard_scale_dq_inline976__rv_v2_pview
      ;
      pto::Shape<1, 1, 1, 64, 1> v162 = pto::Shape<1, 1, 1, 64, 1>();
      // pto: %qr_hadamard_scale_dq_inline976__rv_v2_pview
      ;
      pto::Stride<64, 64, 64, 1, 27648> v163 = pto::Stride<64, 64, 64, 1, 27648>();
      // pto: %qr_hadamard_scale_dq_inline976__rv_v2_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 64, 1>, pto::Stride<64, 64, 64, 1, 27648>, pto::Layout::DN> v164 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 1>, pto::Stride<64, 64, 64, 1, 27648>, pto::Layout::DN>(v160 + (v161 + v159), v162, v163);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      TLOAD(v157, v164);
      // pto: %query_scale_inline1408_inline5158__tile
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v165 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v50);
      // pto: %query_scale_inline1408_inline5158__tile
      ;
      uint64_t v166 = (uint64_t) v26;
      TASSIGN(v165, v166);
      // pto: %query_weight_inline1411_inline5094__tile
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v167 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v50);
      // pto: %query_weight_inline1411_inline5094__tile
      ;
      uint64_t v168 = (uint64_t) v27;
      TASSIGN(v167, v168);
      // pto: %73
      ;
      int64_t v169 = v136 < v53 ? v53 : v136;
      // pto: %weights_inline5133__ssa_v0_pview
      ;
      __gm__ float* v170 = PTOAS__GLOBAL_TENSOR_DATA(v102);
      // pto: %weights_inline5133__ssa_v0_pview
      ;
      const int64_t v171 = 0;
      // pto: %weights_inline5133__ssa_v0_pview
      ;
      const int64_t v172 = 64;
      // pto: %weights_inline5133__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 64> v173 = pto::Shape<1, 1, 1, 1, 64>();
      // pto: %weights_inline5133__ssa_v0_pview
      ;
      pto::Stride<64, 64, 64, 64, 1> v174 = pto::Stride<64, 64, 64, 64, 1>();
      // pto: %weights_inline5133__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v175 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v170 + (v171 + v169 * v172), v173, v174);
      TLOAD(v167, v175);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v176 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v50);
      // pto: %0
      ;
      uint64_t v177 = (uint64_t) v28;
      TASSIGN(v176, v177);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      pipe_barrier(PIPE_V);
      TMUL(v176, v165, v167);
      // pto: %head_coefficient_inline1418_inline5097__tile
      ;
      Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v178 = Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v46);
      // pto: %head_coefficient_inline1418_inline5097__tile
      ;
      uint64_t v179 = (uint64_t) v28;
      TASSIGN(v178, v179);
      // pto: %74
      ;
      int64_t v180 = (int64_t) ((uint64_t) v153 + (uint64_t) v64);
      // pto: %75
      ;
      int64_t v181 = v180 / v61;
      // pto: %76
      ;
      int64_t v182 = (int64_t) ((uint64_t) v181 * (uint64_t) v61);
      for (int64_t v183 = v53; v183 < v182; v183 += v61) {
        // pto: %77
        ;
        int64_t v184 = (int64_t) ((uint64_t) v134 + (uint64_t) v46);
        // pto: %78
        ;
        int64_t v185 = (int64_t) ((uint64_t) v183 * (uint64_t) v184);
        // pto: %aiv_id_inline1376_inline5077__ssa_v0
        ;
        int64_t v186 = (int64_t) v24;
        // pto: %79
        ;
        int64_t v187 = (int64_t) ((uint64_t) v186 * (uint64_t) v155);
        // pto: %80, %81
        ;
        int64_t v188 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v151 - (uint64_t) v185) - (uint64_t) v187);
        // pto: %82
        ;
        int64_t v189 = v188 < v62 ? v188 : v62;
        // pto: %83
        ;
        int64_t v190 = v189 < v53 ? v53 : v189;
        // pto: %86, %91, %90, %88, %89
        ;
        int64_t v191 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v134 * (uint64_t) v136) + (uint64_t) ((int64_t) (uint64_t) v154 * (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v186)));
        // pto: %93, %92, %96, %95
        ;
        int64_t v192 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v134 * (uint64_t) ((int64_t) (uint64_t) v185 + (uint64_t) v187)) + (uint64_t) ((int64_t) (uint64_t) v154 * (uint64_t) v183));
        // pto: %97
        ;
        int64_t v193 = (int64_t) ((uint64_t) v183 + (uint64_t) v62);
        // pto: %99
        ;
        int64_t v194 = (int64_t) ((uint64_t) v193 * (uint64_t) v184);
        // pto: %102, %103
        ;
        int64_t v195 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v151 - (uint64_t) v194) - (uint64_t) v187);
        // pto: %104
        ;
        int64_t v196 = v195 < v62 ? v195 : v62;
        // pto: %105
        ;
        int64_t v197 = v196 < v53 ? v53 : v196;
        // pto: %115, %114, %119, %118
        ;
        int64_t v198 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v134 * (uint64_t) ((int64_t) (uint64_t) v194 + (uint64_t) v187)) + (uint64_t) ((int64_t) (uint64_t) v154 * (uint64_t) v193));
        // pto: %scale_bytes_inline1439_inline5069__tile
        ;
        Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v199 = Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v61);
        // pto: %scale_bytes_inline1439_inline5069__tile
        ;
        uint64_t v200 = (uint64_t) v29;
        TASSIGN(v199, v200);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        for (int64_t v201 = v53; v201 < v66; v201 += v46) {
          // pto: %84, %85, %120, %121
          ;
          int64_t v202 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) ((int64_t) (uint64_t) v149 + (uint64_t) v185) + (uint64_t) v187) / v67) + (uint64_t) v201);
          // pto: %122, %123
          ;
          int64_t v203 = (int64_t) ((uint64_t) v144 - (uint64_t) v46) / v67;
          // pto: %124
          ;
          int64_t v204 = v203 < v53 ? v53 : v203;
          // pto: %125
          ;
          int64_t v205 = v202 < v204 ? v202 : v204;
          // pto: %flat_offset_mul, %flat_offset, %126
          ;
          int32_t v206 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v17) + (uint64_t) v205)];
          // pto: %127
          ;
          int64_t v207 = (int64_t) v206;
          // pto: %128
          ;
          int64_t v208 = v207 < v53 ? v53 : v207;
          // pto: %gather_row_view
          ;
          Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v209;
          // pto: %129, %gather_row_view
          ;
          uint64_t v210 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v201 * (uint64_t) v50) + (uint64_t) v29);
          TASSIGN(v209, v210);
          // pto: %130
          ;
          int64_t v211 = v208 < v53 ? v53 : v208;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v212 = (int64_t) v21;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v213 = 0;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          __gm__ int8_t* v214 = PTOAS__GLOBAL_TENSOR_DATA(v112);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v215 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v216 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v217 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v218 = v46 * v212;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v219 = v217 * v218;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          pto::Shape<1, 1, 1, 1, 64> v220 = pto::Shape<1, 1, 1, 1, 64>(v215, v216, v217, v46, v50);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v221 = pto::Stride<-1, -1, -1, -1, -1>(v216 * v219, v219, v218, v212, v46);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v222 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v214 + (v213 + v211 * v212 + v63 * v46), v220, v221);
          TLOAD(v209, v222);
        };
        // pto: %kv_scale_inline1370_inline5103__tile
        ;
        Tile<TileType::Vec, half, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v223 = Tile<TileType::Vec, half, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %kv_scale_inline1370_inline5103__tile
        ;
        uint64_t v224 = (uint64_t) v29;
        TASSIGN(v223, v224);
        // pto: %score_shard_inline1369_inline5154__tile
        ;
        const int32_t v225 = 64;
        // pto: %score_shard_inline1369_inline5154__tile
        ;
        const int32_t v226 = 192;
        // pto: %score_shard_inline1369_inline5154__tile
        ;
        Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v227 = Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v225, v226);
        TPOP<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_LEFT_RIGHT>(v122, v227);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %score_fp32_inline1426_inline5138__tile
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v228 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %score_fp32_inline1426_inline5138__tile
        ;
        uint64_t v229 = (uint64_t) v26;
        TASSIGN(v228, v229);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        RoundMode v230 = RoundMode::CAST_NONE;
        SaturationMode v231 = SaturationMode::ON;
        TCVT(v228, v227, v230, v231);
        TFREE<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, TileSplitAxis::TILE_LEFT_RIGHT>(v122);
        // pto: %score_fp32_v1_inline1368_inline5114__tile
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v232 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %score_fp32_v1_inline1368_inline5114__tile
        ;
        uint64_t v233 = (uint64_t) v26;
        TASSIGN(v232, v233);
        pipe_barrier(PIPE_V);
        TMAXS(v232, v228, v68);
        // pto: %score_fp32_v2_inline1423_inline5068__tile
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v234 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %score_fp32_v2_inline1423_inline5068__tile
        ;
        uint64_t v235 = (uint64_t) v26;
        TASSIGN(v234, v235);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v234, v232, v178);
        // pto: %2
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v236 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %2
        ;
        uint64_t v237 = (uint64_t) v26;
        TASSIGN(v236, v237);
        pipe_barrier(PIPE_V);
        TCOLSUM(v236, v234);
        // pto: %score_row_inline1367_inline5096__tile
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v238 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %score_row_inline1367_inline5096__tile
        ;
        uint64_t v239 = (uint64_t) v26;
        TASSIGN(v238, v239);
        // pto: %3
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v240 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %3
        ;
        uint64_t v241 = (uint64_t) v30;
        TASSIGN(v240, v241);
        pipe_barrier(PIPE_V);
        RoundMode v242 = RoundMode::CAST_ROUND;
        SaturationMode v243 = SaturationMode::ON;
        TCVT(v240, v223, v242, v243);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        // pto: %score_row_v1_inline1365_inline5118__tile
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v244 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %score_row_v1_inline1365_inline5118__tile
        ;
        uint64_t v245 = (uint64_t) v26;
        TASSIGN(v244, v245);
        pipe_barrier(PIPE_V);
        TMUL(v244, v238, v240);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %131
        ;
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        if (v190 > v53) {
          v244.SetValidShape(v46, v190);
          // pto: %132
          ;
          int64_t v246 = v191 < v53 ? v53 : v191;
          // pto: %133
          ;
          int64_t v247 = v192 < v53 ? v53 : v192;
          // pto: %score_arena_inline1391_inline5091__iter_v3_pview
          ;
          const int64_t v248 = 0;
          // pto: %score_arena_inline1391_inline5091__iter_v3_pview
          ;
          __gm__ float* v249 = PTOAS__GLOBAL_TENSOR_DATA(v86);
          // pto: %score_arena_inline1391_inline5091__iter_v3_pview
          ;
          const int64_t v250 = 1;
          // pto: %score_arena_inline1391_inline5091__iter_v3_pview
          ;
          const int64_t v251 = 1;
          // pto: %score_arena_inline1391_inline5091__iter_v3_pview
          ;
          const int64_t v252 = 1;
          // pto: %score_arena_inline1391_inline5091__iter_v3_pview
          ;
          int64_t v253 = v46 * v48;
          // pto: %score_arena_inline1391_inline5091__iter_v3_pview
          ;
          int64_t v254 = v252 * v253;
          // pto: %score_arena_inline1391_inline5091__iter_v3_pview
          ;
          pto::Shape<1, 1, 1, 1, -1> v255 = pto::Shape<1, 1, 1, 1, -1>(v250, v251, v252, v46, v190);
          // pto: %score_arena_inline1391_inline5091__iter_v3_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v256 = pto::Stride<-1, -1, -1, -1, -1>(v251 * v254, v254, v253, v48, v46);
          // pto: %score_arena_inline1391_inline5091__iter_v3_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v257 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v249 + (v248 + v246 * v48 + v247 * v46), v255, v256);
          TSTORE(v257, v244);
        };
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
        // pto: %4
        ;
        Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v258 = Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v61);
        // pto: %4
        ;
        uint64_t v259 = (uint64_t) v29;
        TASSIGN(v258, v259);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        for (int64_t v260 = v53; v260 < v66; v260 += v46) {
          // pto: %106, %107, %135, %136
          ;
          int64_t v261 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) ((int64_t) (uint64_t) v149 + (uint64_t) v194) + (uint64_t) v187) / v67) + (uint64_t) v260);
          // pto: %137, %138
          ;
          int64_t v262 = (int64_t) ((uint64_t) v144 - (uint64_t) v46) / v67;
          // pto: %139
          ;
          int64_t v263 = v262 < v53 ? v53 : v262;
          // pto: %140
          ;
          int64_t v264 = v261 < v263 ? v261 : v263;
          // pto: %142, %143, %141
          ;
          int32_t v265 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v17) + (uint64_t) v264)];
          // pto: %144
          ;
          int64_t v266 = (int64_t) v265;
          // pto: %145
          ;
          int64_t v267 = v266 < v53 ? v53 : v266;
          // pto: %147
          ;
          Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v268;
          // pto: %146, %147
          ;
          uint64_t v269 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v260 * (uint64_t) v50) + (uint64_t) v29);
          TASSIGN(v268, v269);
          // pto: %148
          ;
          int64_t v270 = v267 < v53 ? v53 : v267;
          // pto: %149
          ;
          int64_t v271 = (int64_t) v21;
          // pto: %149
          ;
          const int64_t v272 = 0;
          // pto: %149
          ;
          __gm__ int8_t* v273 = PTOAS__GLOBAL_TENSOR_DATA(v112);
          // pto: %149
          ;
          const int64_t v274 = 1;
          // pto: %149
          ;
          const int64_t v275 = 1;
          // pto: %149
          ;
          const int64_t v276 = 1;
          // pto: %149
          ;
          int64_t v277 = v46 * v271;
          // pto: %149
          ;
          int64_t v278 = v276 * v277;
          // pto: %149
          ;
          pto::Shape<1, 1, 1, 1, 64> v279 = pto::Shape<1, 1, 1, 1, 64>(v274, v275, v276, v46, v50);
          // pto: %149
          ;
          pto::Stride<-1, -1, -1, -1, -1> v280 = pto::Stride<-1, -1, -1, -1, -1>(v275 * v278, v278, v277, v271, v46);
          // pto: %149
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v281 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v273 + (v272 + v270 * v271 + v63 * v46), v279, v280);
          TLOAD(v268, v281);
        };
        // pto: %6
        ;
        Tile<TileType::Vec, half, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v282 = Tile<TileType::Vec, half, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %6
        ;
        uint64_t v283 = (uint64_t) v29;
        TASSIGN(v282, v283);
        // pto: %150
        ;
        const int32_t v284 = 64;
        // pto: %150
        ;
        const int32_t v285 = 192;
        // pto: %150
        ;
        Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v286 = Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v284, v285);
        TPOP<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_LEFT_RIGHT>(v122, v286);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %7
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v287 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %7
        ;
        uint64_t v288 = (uint64_t) v26;
        TASSIGN(v287, v288);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
        pipe_barrier(PIPE_V);
        RoundMode v289 = RoundMode::CAST_NONE;
        SaturationMode v290 = SaturationMode::ON;
        TCVT(v287, v286, v289, v290);
        TFREE<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, TileSplitAxis::TILE_LEFT_RIGHT>(v122);
        // pto: %8
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v291 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %8
        ;
        uint64_t v292 = (uint64_t) v26;
        TASSIGN(v291, v292);
        pipe_barrier(PIPE_V);
        TMAXS(v291, v287, v68);
        // pto: %9
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v293 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %9
        ;
        uint64_t v294 = (uint64_t) v26;
        TASSIGN(v293, v294);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v293, v291, v178);
        // pto: %10
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v295 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %10
        ;
        uint64_t v296 = (uint64_t) v26;
        TASSIGN(v295, v296);
        pipe_barrier(PIPE_V);
        TCOLSUM(v295, v293);
        // pto: %11
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v297 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %11
        ;
        uint64_t v298 = (uint64_t) v26;
        TASSIGN(v297, v298);
        // pto: %12
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v299 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %12
        ;
        uint64_t v300 = (uint64_t) v30;
        TASSIGN(v299, v300);
        pipe_barrier(PIPE_V);
        RoundMode v301 = RoundMode::CAST_ROUND;
        SaturationMode v302 = SaturationMode::ON;
        TCVT(v299, v282, v301, v302);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        // pto: %13
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v303 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %13
        ;
        uint64_t v304 = (uint64_t) v26;
        TASSIGN(v303, v304);
        pipe_barrier(PIPE_V);
        TMUL(v303, v297, v299);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        // pto: %151
        ;
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        if (v197 > v53) {
          v303.SetValidShape(v46, v197);
          // pto: %153
          ;
          int64_t v305 = v191 < v53 ? v53 : v191;
          // pto: %154
          ;
          int64_t v306 = v198 < v53 ? v53 : v198;
          // pto: %score_arena_inline1391_inline5091__phi_v6_pview
          ;
          const int64_t v307 = 0;
          // pto: %score_arena_inline1391_inline5091__phi_v6_pview
          ;
          __gm__ float* v308 = PTOAS__GLOBAL_TENSOR_DATA(v86);
          // pto: %score_arena_inline1391_inline5091__phi_v6_pview
          ;
          const int64_t v309 = 1;
          // pto: %score_arena_inline1391_inline5091__phi_v6_pview
          ;
          const int64_t v310 = 1;
          // pto: %score_arena_inline1391_inline5091__phi_v6_pview
          ;
          const int64_t v311 = 1;
          // pto: %score_arena_inline1391_inline5091__phi_v6_pview
          ;
          int64_t v312 = v46 * v48;
          // pto: %score_arena_inline1391_inline5091__phi_v6_pview
          ;
          int64_t v313 = v311 * v312;
          // pto: %score_arena_inline1391_inline5091__phi_v6_pview
          ;
          pto::Shape<1, 1, 1, 1, -1> v314 = pto::Shape<1, 1, 1, 1, -1>(v309, v310, v311, v46, v197);
          // pto: %score_arena_inline1391_inline5091__phi_v6_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v315 = pto::Stride<-1, -1, -1, -1, -1>(v310 * v313, v313, v312, v48, v46);
          // pto: %score_arena_inline1391_inline5091__phi_v6_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v316 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v308 + (v307 + v305 * v48 + v306 * v46), v314, v315);
          TSTORE(v316, v303);
        };
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      };
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
      // pto: %156, %160, %159, %161
      ;
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
      if ((int64_t) ((uint64_t) (v180 / v62) - (uint64_t) ((int64_t) (uint64_t) v181 * (uint64_t) v65)) == v46) {
        // pto: %163, %162
        ;
        int64_t v317 = (int64_t) ((uint64_t) v182 * (uint64_t) ((int64_t) (uint64_t) v134 + (uint64_t) v46));
        // pto: %164
        ;
        int64_t v318 = (int64_t) v24;
        // pto: %165
        ;
        int64_t v319 = (int64_t) ((uint64_t) v318 * (uint64_t) v155);
        // pto: %166, %167
        ;
        int64_t v320 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v151 - (uint64_t) v317) - (uint64_t) v319);
        // pto: %168
        ;
        int64_t v321 = v320 < v62 ? v320 : v62;
        // pto: %169
        ;
        int64_t v322 = v321 < v53 ? v53 : v321;
        // pto: %15
        ;
        Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v323 = Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v61);
        // pto: %15
        ;
        uint64_t v324 = (uint64_t) v29;
        TASSIGN(v323, v324);
        for (int64_t v325 = v53; v325 < v66; v325 += v46) {
          // pto: %170, %171, %173, %174
          ;
          int64_t v326 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) ((int64_t) (uint64_t) v149 + (uint64_t) v317) + (uint64_t) v319) / v67) + (uint64_t) v325);
          // pto: %175, %176
          ;
          int64_t v327 = (int64_t) ((uint64_t) v144 - (uint64_t) v46) / v67;
          // pto: %177
          ;
          int64_t v328 = v327 < v53 ? v53 : v327;
          // pto: %178
          ;
          int64_t v329 = v326 < v328 ? v326 : v328;
          // pto: %180, %181, %179
          ;
          int32_t v330 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v17) + (uint64_t) v329)];
          // pto: %182
          ;
          int64_t v331 = (int64_t) v330;
          // pto: %183
          ;
          int64_t v332 = v331 < v53 ? v53 : v331;
          // pto: %185
          ;
          Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v333;
          // pto: %184, %185
          ;
          uint64_t v334 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v325 * (uint64_t) v50) + (uint64_t) v29);
          TASSIGN(v333, v334);
          // pto: %186
          ;
          int64_t v335 = v332 < v53 ? v53 : v332;
          // pto: %187
          ;
          int64_t v336 = (int64_t) v21;
          // pto: %187
          ;
          const int64_t v337 = 0;
          // pto: %187
          ;
          __gm__ int8_t* v338 = PTOAS__GLOBAL_TENSOR_DATA(v112);
          // pto: %187
          ;
          const int64_t v339 = 1;
          // pto: %187
          ;
          const int64_t v340 = 1;
          // pto: %187
          ;
          const int64_t v341 = 1;
          // pto: %187
          ;
          int64_t v342 = v46 * v336;
          // pto: %187
          ;
          int64_t v343 = v341 * v342;
          // pto: %187
          ;
          pto::Shape<1, 1, 1, 1, 64> v344 = pto::Shape<1, 1, 1, 1, 64>(v339, v340, v341, v46, v50);
          // pto: %187
          ;
          pto::Stride<-1, -1, -1, -1, -1> v345 = pto::Stride<-1, -1, -1, -1, -1>(v340 * v343, v343, v342, v336, v46);
          // pto: %187
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v346 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v338 + (v337 + v335 * v336 + v63 * v46), v344, v345);
          TLOAD(v333, v346);
        };
        // pto: %17
        ;
        Tile<TileType::Vec, half, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v347 = Tile<TileType::Vec, half, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %17
        ;
        uint64_t v348 = (uint64_t) v29;
        TASSIGN(v347, v348);
        // pto: %188
        ;
        const int32_t v349 = 64;
        // pto: %188
        ;
        const int32_t v350 = 192;
        // pto: %188
        ;
        Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v351 = Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v349, v350);
        TPOP<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_LEFT_RIGHT>(v122, v351);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        // pto: %18
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v352 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %18
        ;
        uint64_t v353 = (uint64_t) v26;
        TASSIGN(v352, v353);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        pipe_barrier(PIPE_V);
        RoundMode v354 = RoundMode::CAST_NONE;
        SaturationMode v355 = SaturationMode::ON;
        TCVT(v352, v351, v354, v355);
        TFREE<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, TileSplitAxis::TILE_LEFT_RIGHT>(v122);
        // pto: %19
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v356 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %19
        ;
        uint64_t v357 = (uint64_t) v26;
        TASSIGN(v356, v357);
        pipe_barrier(PIPE_V);
        TMAXS(v356, v352, v68);
        // pto: %20
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v358 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %20
        ;
        uint64_t v359 = (uint64_t) v26;
        TASSIGN(v358, v359);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v358, v356, v178);
        // pto: %21
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v360 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %21
        ;
        uint64_t v361 = (uint64_t) v26;
        TASSIGN(v360, v361);
        pipe_barrier(PIPE_V);
        TCOLSUM(v360, v358);
        // pto: %22
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v362 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %22
        ;
        uint64_t v363 = (uint64_t) v26;
        TASSIGN(v362, v363);
        // pto: %23
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v364 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %23
        ;
        uint64_t v365 = (uint64_t) v30;
        TASSIGN(v364, v365);
        pipe_barrier(PIPE_V);
        RoundMode v366 = RoundMode::CAST_ROUND;
        SaturationMode v367 = SaturationMode::ON;
        TCVT(v364, v347, v366, v367);
        // pto: %24
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v368 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %24
        ;
        uint64_t v369 = (uint64_t) v26;
        TASSIGN(v368, v369);
        pipe_barrier(PIPE_V);
        TMUL(v368, v362, v364);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        // pto: %189, %194, %193, %191, %192
        ;
        int64_t v370 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v134 * (uint64_t) v136) + (uint64_t) ((int64_t) (uint64_t) v154 * (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v318)));
        // pto: %196, %195, %199, %198
        ;
        int64_t v371 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v134 * (uint64_t) ((int64_t) (uint64_t) v317 + (uint64_t) v319)) + (uint64_t) ((int64_t) (uint64_t) v154 * (uint64_t) v182));
        // pto: %200
        ;
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        if (v322 > v53) {
          v368.SetValidShape(v46, v322);
          // pto: %202
          ;
          int64_t v372 = v370 < v53 ? v53 : v370;
          // pto: %203
          ;
          int64_t v373 = v371 < v53 ? v53 : v371;
          // pto: %score_arena_inline1391_inline5091__rv_v4_main_pview
          ;
          const int64_t v374 = 0;
          // pto: %score_arena_inline1391_inline5091__rv_v4_main_pview
          ;
          __gm__ float* v375 = PTOAS__GLOBAL_TENSOR_DATA(v86);
          // pto: %score_arena_inline1391_inline5091__rv_v4_main_pview
          ;
          const int64_t v376 = 1;
          // pto: %score_arena_inline1391_inline5091__rv_v4_main_pview
          ;
          const int64_t v377 = 1;
          // pto: %score_arena_inline1391_inline5091__rv_v4_main_pview
          ;
          const int64_t v378 = 1;
          // pto: %score_arena_inline1391_inline5091__rv_v4_main_pview
          ;
          int64_t v379 = v46 * v48;
          // pto: %score_arena_inline1391_inline5091__rv_v4_main_pview
          ;
          int64_t v380 = v378 * v379;
          // pto: %score_arena_inline1391_inline5091__rv_v4_main_pview
          ;
          pto::Shape<1, 1, 1, 1, -1> v381 = pto::Shape<1, 1, 1, 1, -1>(v376, v377, v378, v46, v322);
          // pto: %score_arena_inline1391_inline5091__rv_v4_main_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v382 = pto::Stride<-1, -1, -1, -1, -1>(v377 * v380, v380, v379, v48, v46);
          // pto: %score_arena_inline1391_inline5091__rv_v4_main_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v383 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v375 + (v374 + v372 * v48 + v373 * v46), v381, v382);
          TSTORE(v383, v368);
        };
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      // pto: %204
      ;
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      if (v134 == v53) {
        // pto: %sort_lane_inline1361_inline5073__ssa_v0
        ;
        int64_t v384 = (int64_t) v24;
        // pto: %205
        ;
        int64_t v385 = (int64_t) ((uint64_t) v384 * (uint64_t) v153);
        // pto: %208
        ;
        int64_t v386 = (int64_t) ((uint64_t) v151 - (uint64_t) v385);
        // pto: %209
        ;
        int64_t v387 = v386 < v153 ? v386 : v153;
        // pto: %210
        ;
        int64_t v388 = v387 < v53 ? v53 : v387;
        // pto: %213, %212, %214
        ;
        int64_t v389 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v156 + (uint64_t) ((int64_t) (uint64_t) v138 * (uint64_t) v65)) + (uint64_t) v384);
        // pto: %215
        ;
        if (v388 > v53) {
          // pto: %206, %216
          ;
          int32_t v390 = (int32_t) ((int64_t) (uint64_t) v149 + (uint64_t) v385);
          // pto: %217
          ;
          if (v388 <= v69) {
            // pto: %t__ci_tmp_v0
            ;
            Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v391 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
            // pto: %t__ci_tmp_v0
            ;
            uint64_t v392 = (uint64_t) v31;
            TASSIGN(v391, v392);
            // pto: %t__tmp_v849
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v393 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v69);
            // pto: %t__tmp_v849
            ;
            uint64_t v394 = (uint64_t) v26;
            TASSIGN(v393, v394);
            // pto: %ci_tmp_view
            ;
            Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v395;
            TRESHAPE(v395, v391);
            // pto: %ci_dst_view
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v396;
            TRESHAPE(v396, v393);
            pipe_barrier(PIPE_V);
            TCI<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v396, v52, v395);
            // pto: %short_indices_inline9594__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v397 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v69);
            // pto: %short_indices_inline9594__ssa_v0
            ;
            uint64_t v398 = (uint64_t) v32;
            TASSIGN(v397, v398);
            pipe_barrier(PIPE_V);
            TADDS(v397, v393, v390);
            set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
            // pto: %short_raw_inline9579__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v399 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v388);
            // pto: %short_raw_inline9579__ssa_v0
            ;
            uint64_t v400 = (uint64_t) v26;
            TASSIGN(v399, v400);
            // pto: %218, %219
            ;
            int64_t v401 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v384);
            // pto: %220
            ;
            int64_t v402 = v401 < v53 ? v53 : v401;
            // pto: %score_arena_inline1391_inline5091__rv_v4_pview
            ;
            const int64_t v403 = 0;
            // pto: %score_arena_inline1391_inline5091__rv_v4_pview
            ;
            __gm__ float* v404 = PTOAS__GLOBAL_TENSOR_DATA(v86);
            // pto: %score_arena_inline1391_inline5091__rv_v4_pview
            ;
            const int64_t v405 = 1;
            // pto: %score_arena_inline1391_inline5091__rv_v4_pview
            ;
            const int64_t v406 = 1;
            // pto: %score_arena_inline1391_inline5091__rv_v4_pview
            ;
            const int64_t v407 = 1;
            // pto: %score_arena_inline1391_inline5091__rv_v4_pview
            ;
            int64_t v408 = v46 * v48;
            // pto: %score_arena_inline1391_inline5091__rv_v4_pview
            ;
            int64_t v409 = v407 * v408;
            // pto: %score_arena_inline1391_inline5091__rv_v4_pview
            ;
            pto::Shape<1, 1, 1, 1, -1> v410 = pto::Shape<1, 1, 1, 1, -1>(v405, v406, v407, v46, v388);
            // pto: %score_arena_inline1391_inline5091__rv_v4_pview
            ;
            pto::Stride<-1, -1, -1, -1, -1> v411 = pto::Stride<-1, -1, -1, -1, -1>(v406 * v409, v409, v408, v48, v46);
            // pto: %score_arena_inline1391_inline5091__rv_v4_pview
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v412 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v404 + (v403 + v402 * v48 + v53 * v46), v410, v411);
            wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
            TLOAD(v399, v412);
            set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
            // pto: %short_scores_inline9589__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v413 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v69);
            // pto: %short_scores_inline9589__ssa_v0
            ;
            uint64_t v414 = (uint64_t) v26;
            TASSIGN(v413, v414);
            wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
            TFILLPAD<pto::TFillPadMode::InPlace>(v413, v399);
            // pto: %short_scores_v1_inline9577__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v415 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v69);
            // pto: %short_scores_v1_inline9577__ssa_v0
            ;
            uint64_t v416 = (uint64_t) v33;
            TASSIGN(v415, v416);
            pipe_barrier(PIPE_V);
            TMAXS(v415, v413, v70);
            // pto: %t__tmp_v850
            ;
            Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v417 = Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v69);
            // pto: %t__tmp_v850
            ;
            uint64_t v418 = (uint64_t) v32;
            TASSIGN(v417, v418);
            // pto: %short_pairs_inline9556__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v419 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
            // pto: %short_pairs_inline9556__ssa_v0
            ;
            uint64_t v420 = (uint64_t) v26;
            TASSIGN(v419, v420);
            // pto: %sort32_src_view
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v421;
            TRESHAPE(v421, v415);
            // pto: %sort32_idx_view
            ;
            Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v422;
            TRESHAPE(v422, v417);
            // pto: %sort32_dst_view
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v423;
            TRESHAPE(v423, v419);
            pipe_barrier(PIPE_V);
            TSORT32(v423, v421, v422);
            // pto: %short_pairs_v1_inline9559__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v424 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
            // pto: %short_pairs_v1_inline9559__ssa_v0
            ;
            uint64_t v425 = (uint64_t) v32;
            TASSIGN(v424, v425);
            pipe_barrier(PIPE_V);
            TMRGSORT(v424, v419, v71);
            // pto: %short_pairs_v2_inline9569__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v426 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
            // pto: %short_pairs_v2_inline9569__ssa_v0
            ;
            uint64_t v427 = (uint64_t) v26;
            TASSIGN(v426, v427);
            pipe_barrier(PIPE_V);
            TMRGSORT(v426, v424, v72);
            set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
            // pto: %221
            ;
            int64_t v428 = v389 < v53 ? v53 : v389;
            // pto: %pair_arena_inline1406_inline5120__ssa_v0_pview
            ;
            __gm__ float* v429 = PTOAS__GLOBAL_TENSOR_DATA(v120);
            // pto: %pair_arena_inline1406_inline5120__ssa_v0_pview
            ;
            const int64_t v430 = 0;
            // pto: %pair_arena_inline1406_inline5120__ssa_v0_pview
            ;
            const int64_t v431 = 1024;
            // pto: %pair_arena_inline1406_inline5120__ssa_v0_pview
            ;
            pto::Shape<1, 1, 1, 1, 1024> v432 = pto::Shape<1, 1, 1, 1, 1024>();
            // pto: %pair_arena_inline1406_inline5120__ssa_v0_pview
            ;
            pto::Stride<1024, 1024, 1024, 1024, 1> v433 = pto::Stride<1024, 1024, 1024, 1024, 1>();
            // pto: %pair_arena_inline1406_inline5120__ssa_v0_pview
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v434 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v429 + (v430 + v428 * v431), v432, v433);
            wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
            pipe_barrier(PIPE_MTE3);
            TSTORE(v434, v426);
          } else {
            // pto: %222
            ;
            if (v388 <= v51) {
              // pto: %t__ci_tmp_v1
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v435 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
              // pto: %t__ci_tmp_v1
              ;
              uint64_t v436 = (uint64_t) v32;
              TASSIGN(v435, v436);
              // pto: %t__tmp_v851
              ;
              Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v437 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v51);
              // pto: %t__tmp_v851
              ;
              uint64_t v438 = (uint64_t) v26;
              TASSIGN(v437, v438);
              // pto: %223
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v439;
              TRESHAPE(v439, v435);
              // pto: %224
              ;
              Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v440;
              TRESHAPE(v440, v437);
              pipe_barrier(PIPE_V);
              TCI<Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v440, v52, v439);
              // pto: %small_indices_inline9592__ssa_v0
              ;
              Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v441 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v51);
              // pto: %small_indices_inline9592__ssa_v0
              ;
              uint64_t v442 = (uint64_t) v34;
              TASSIGN(v441, v442);
              pipe_barrier(PIPE_V);
              TADDS(v441, v437, v390);
              set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
              // pto: %small_raw_inline9567__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v443 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v388);
              // pto: %small_raw_inline9567__ssa_v0
              ;
              uint64_t v444 = (uint64_t) v26;
              TASSIGN(v443, v444);
              // pto: %225, %226
              ;
              int64_t v445 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v384);
              // pto: %227
              ;
              int64_t v446 = v445 < v53 ? v53 : v445;
              // pto: %228
              ;
              const int64_t v447 = 0;
              // pto: %228
              ;
              __gm__ float* v448 = PTOAS__GLOBAL_TENSOR_DATA(v86);
              // pto: %228
              ;
              const int64_t v449 = 1;
              // pto: %228
              ;
              const int64_t v450 = 1;
              // pto: %228
              ;
              const int64_t v451 = 1;
              // pto: %228
              ;
              int64_t v452 = v46 * v48;
              // pto: %228
              ;
              int64_t v453 = v451 * v452;
              // pto: %228
              ;
              pto::Shape<1, 1, 1, 1, -1> v454 = pto::Shape<1, 1, 1, 1, -1>(v449, v450, v451, v46, v388);
              // pto: %228
              ;
              pto::Stride<-1, -1, -1, -1, -1> v455 = pto::Stride<-1, -1, -1, -1, -1>(v450 * v453, v453, v452, v48, v46);
              // pto: %228
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v456 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v448 + (v447 + v446 * v48 + v53 * v46), v454, v455);
              wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
              TLOAD(v443, v456);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
              // pto: %small_scores_inline9564__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v457 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
              // pto: %small_scores_inline9564__ssa_v0
              ;
              uint64_t v458 = (uint64_t) v26;
              TASSIGN(v457, v458);
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
              TFILLPAD<pto::TFillPadMode::InPlace>(v457, v443);
              // pto: %small_scores_v1_inline9580__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v459 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
              // pto: %small_scores_v1_inline9580__ssa_v0
              ;
              uint64_t v460 = (uint64_t) v35;
              TASSIGN(v459, v460);
              pipe_barrier(PIPE_V);
              TMAXS(v459, v457, v70);
              // pto: %t__tmp_v852
              ;
              Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v461 = Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v51);
              // pto: %t__tmp_v852
              ;
              uint64_t v462 = (uint64_t) v34;
              TASSIGN(v461, v462);
              // pto: %small_pairs_inline9575__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v463 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
              // pto: %small_pairs_inline9575__ssa_v0
              ;
              uint64_t v464 = (uint64_t) v26;
              TASSIGN(v463, v464);
              // pto: %229
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v465;
              TRESHAPE(v465, v459);
              // pto: %230
              ;
              Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v466;
              TRESHAPE(v466, v461);
              // pto: %231
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v467;
              TRESHAPE(v467, v463);
              pipe_barrier(PIPE_V);
              TSORT32(v467, v465, v466);
              // pto: %small_pairs_v1_inline9596__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v468 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
              // pto: %small_pairs_v1_inline9596__ssa_v0
              ;
              uint64_t v469 = (uint64_t) v34;
              TASSIGN(v468, v469);
              pipe_barrier(PIPE_V);
              TMRGSORT(v468, v463, v71);
              // pto: %small_pairs_v2_inline9555__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v470 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
              // pto: %small_pairs_v2_inline9555__ssa_v0
              ;
              uint64_t v471 = (uint64_t) v26;
              TASSIGN(v470, v471);
              pipe_barrier(PIPE_V);
              TMRGSORT(v470, v468, v72);
              // pto: %small_left_inline9587__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v472 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
              // pto: %small_left_inline9587__ssa_v0
              ;
              uint64_t v473 = (uint64_t) v26;
              TASSIGN(v472, v473);
              // pto: %slice_view
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v474;
              // pto: %slice_view
              ;
              uint64_t v475 = (uint64_t) v26;
              TASSIGN(v474, v475);
              // pto: %small_right_inline9553__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v476 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
              // pto: %small_right_inline9553__ssa_v0
              ;
              uint64_t v477 = (uint64_t) v32;
              TASSIGN(v476, v477);
              // pto: %232
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v478;
              // pto: %232
              ;
              uint64_t v479 = (uint64_t) v32;
              TASSIGN(v478, v479);
              // pto: %small_tmp_inline9554__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v480 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v73);
              // pto: %small_tmp_inline9554__ssa_v0
              ;
              uint64_t v481 = (uint64_t) v34;
              TASSIGN(v480, v481);
              // pto: %small_merged_inline9570__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v482 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
              // pto: %small_merged_inline9570__ssa_v0
              ;
              uint64_t v483 = (uint64_t) v36;
              TASSIGN(v482, v483);
              pipe_barrier(PIPE_V);
              TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v482, v25, v480, v474, v478);
              set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
              // pto: %small_top_inline9558__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v484 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
              // pto: %small_top_inline9558__ssa_v0
              ;
              uint64_t v485 = (uint64_t) v36;
              TASSIGN(v484, v485);
              // pto: %233
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v486;
              // pto: %233
              ;
              uint64_t v487 = (uint64_t) v36;
              TASSIGN(v486, v487);
              // pto: %234
              ;
              int64_t v488 = v389 < v53 ? v53 : v389;
              // pto: %235
              ;
              __gm__ float* v489 = PTOAS__GLOBAL_TENSOR_DATA(v120);
              // pto: %235
              ;
              const int64_t v490 = 0;
              // pto: %235
              ;
              const int64_t v491 = 1024;
              // pto: %235
              ;
              pto::Shape<1, 1, 1, 1, 1024> v492 = pto::Shape<1, 1, 1, 1, 1024>();
              // pto: %235
              ;
              pto::Stride<1024, 1024, 1024, 1024, 1> v493 = pto::Stride<1024, 1024, 1024, 1024, 1>();
              // pto: %235
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v494 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v489 + (v490 + v488 * v491), v492, v493);
              wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
              pipe_barrier(PIPE_MTE3);
              TSTORE(v494, v486);
            } else {
              // pto: %236
              ;
              if (v388 <= v73) {
                // pto: %t__ci_tmp_v2
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v495 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
                // pto: %t__ci_tmp_v2
                ;
                uint64_t v496 = (uint64_t) v34;
                TASSIGN(v495, v496);
                // pto: %t__tmp_v853
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v497 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v73);
                // pto: %t__tmp_v853
                ;
                uint64_t v498 = (uint64_t) v26;
                TASSIGN(v497, v498);
                // pto: %237
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v499;
                TRESHAPE(v499, v495);
                // pto: %238
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v500;
                TRESHAPE(v500, v497);
                pipe_barrier(PIPE_V);
                TCI<Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v500, v52, v499);
                // pto: %leaf_indices_inline9552__ssa_v0
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v501 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v73);
                // pto: %leaf_indices_inline9552__ssa_v0
                ;
                uint64_t v502 = (uint64_t) v36;
                TASSIGN(v501, v502);
                pipe_barrier(PIPE_V);
                TADDS(v501, v497, v390);
                set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
                // pto: %leaf_scores_raw_inline9586__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v503 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v388);
                // pto: %leaf_scores_raw_inline9586__ssa_v0
                ;
                uint64_t v504 = (uint64_t) v26;
                TASSIGN(v503, v504);
                // pto: %239, %240
                ;
                int64_t v505 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v384);
                // pto: %241
                ;
                int64_t v506 = v505 < v53 ? v53 : v505;
                // pto: %242
                ;
                const int64_t v507 = 0;
                // pto: %242
                ;
                __gm__ float* v508 = PTOAS__GLOBAL_TENSOR_DATA(v86);
                // pto: %242
                ;
                const int64_t v509 = 1;
                // pto: %242
                ;
                const int64_t v510 = 1;
                // pto: %242
                ;
                const int64_t v511 = 1;
                // pto: %242
                ;
                int64_t v512 = v46 * v48;
                // pto: %242
                ;
                int64_t v513 = v511 * v512;
                // pto: %242
                ;
                pto::Shape<1, 1, 1, 1, -1> v514 = pto::Shape<1, 1, 1, 1, -1>(v509, v510, v511, v46, v388);
                // pto: %242
                ;
                pto::Stride<-1, -1, -1, -1, -1> v515 = pto::Stride<-1, -1, -1, -1, -1>(v510 * v513, v513, v512, v48, v46);
                // pto: %242
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v516 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v508 + (v507 + v506 * v48 + v53 * v46), v514, v515);
                wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
                TLOAD(v503, v516);
                set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
                // pto: %leaf_scores_inline9566__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v517 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
                // pto: %leaf_scores_inline9566__ssa_v0
                ;
                uint64_t v518 = (uint64_t) v26;
                TASSIGN(v517, v518);
                wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
                TFILLPAD<pto::TFillPadMode::InPlace>(v517, v503);
                // pto: %leaf_scores_v1_inline9583__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v519 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
                // pto: %leaf_scores_v1_inline9583__ssa_v0
                ;
                uint64_t v520 = (uint64_t) v37;
                TASSIGN(v519, v520);
                pipe_barrier(PIPE_V);
                TMAXS(v519, v517, v70);
                // pto: %t__tmp_v854
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v521 = Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v73);
                // pto: %t__tmp_v854
                ;
                uint64_t v522 = (uint64_t) v36;
                TASSIGN(v521, v522);
                // pto: %pairs_inline9551__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v523 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v63);
                // pto: %pairs_inline9551__ssa_v0
                ;
                uint64_t v524 = (uint64_t) v26;
                TASSIGN(v523, v524);
                // pto: %243
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v525;
                TRESHAPE(v525, v519);
                // pto: %244
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v526;
                TRESHAPE(v526, v521);
                // pto: %245
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v527;
                TRESHAPE(v527, v523);
                pipe_barrier(PIPE_V);
                TSORT32(v527, v525, v526);
                // pto: %pairs_v1_inline9565__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v528 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v63);
                // pto: %pairs_v1_inline9565__ssa_v0
                ;
                uint64_t v529 = (uint64_t) v36;
                TASSIGN(v528, v529);
                pipe_barrier(PIPE_V);
                TMRGSORT(v528, v523, v71);
                // pto: %pairs_v2_inline9563__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v530 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v63);
                // pto: %pairs_v2_inline9563__ssa_v0
                ;
                uint64_t v531 = (uint64_t) v26;
                TASSIGN(v530, v531);
                pipe_barrier(PIPE_V);
                TMRGSORT(v530, v528, v72);
                // pto: %pairs_v3_inline9588__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v532 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v63);
                // pto: %pairs_v3_inline9588__ssa_v0
                ;
                uint64_t v533 = (uint64_t) v36;
                TASSIGN(v532, v533);
                pipe_barrier(PIPE_V);
                TMRGSORT(v532, v530, v74);
                set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
                // pto: %t__tmp_v855
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v534 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                // pto: %t__tmp_v855
                ;
                uint64_t v535 = (uint64_t) v36;
                TASSIGN(v534, v535);
                // pto: %246
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v536;
                // pto: %246
                ;
                uint64_t v537 = (uint64_t) v36;
                TASSIGN(v536, v537);
                // pto: %247
                ;
                int64_t v538 = v389 < v53 ? v53 : v389;
                // pto: %248
                ;
                __gm__ float* v539 = PTOAS__GLOBAL_TENSOR_DATA(v120);
                // pto: %248
                ;
                const int64_t v540 = 0;
                // pto: %248
                ;
                const int64_t v541 = 1024;
                // pto: %248
                ;
                pto::Shape<1, 1, 1, 1, 1024> v542 = pto::Shape<1, 1, 1, 1, 1024>();
                // pto: %248
                ;
                pto::Stride<1024, 1024, 1024, 1024, 1> v543 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                // pto: %248
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v544 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v539 + (v540 + v538 * v541), v542, v543);
                wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
                pipe_barrier(PIPE_MTE3);
                TSTORE(v544, v536);
              } else {
                // pto: %249
                ;
                if (v388 <= v75) {
                  // pto: %t__ci_tmp_v3
                  ;
                  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v545 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
                  // pto: %t__ci_tmp_v3
                  ;
                  uint64_t v546 = (uint64_t) v38;
                  TASSIGN(v545, v546);
                  // pto: %t__tmp_v856
                  ;
                  Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v547 = Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v75);
                  // pto: %t__tmp_v856
                  ;
                  uint64_t v548 = (uint64_t) v26;
                  TASSIGN(v547, v548);
                  // pto: %250
                  ;
                  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v549;
                  TRESHAPE(v549, v545);
                  // pto: %251
                  ;
                  Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v550;
                  TRESHAPE(v550, v547);
                  pipe_barrier(PIPE_V);
                  TCI<Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v550, v52, v549);
                  // pto: %partial_indices_inline9601__ssa_v0
                  ;
                  Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v551 = Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v75);
                  // pto: %partial_indices_inline9601__ssa_v0
                  ;
                  uint64_t v552 = (uint64_t) v39;
                  TASSIGN(v551, v552);
                  pipe_barrier(PIPE_V);
                  TADDS(v551, v547, v390);
                  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
                  // pto: %partial_raw_inline9590__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v553 = Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v388);
                  // pto: %partial_raw_inline9590__ssa_v0
                  ;
                  uint64_t v554 = (uint64_t) v26;
                  TASSIGN(v553, v554);
                  // pto: %252, %253
                  ;
                  int64_t v555 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v384);
                  // pto: %254
                  ;
                  int64_t v556 = v555 < v53 ? v53 : v555;
                  // pto: %255
                  ;
                  const int64_t v557 = 0;
                  // pto: %255
                  ;
                  __gm__ float* v558 = PTOAS__GLOBAL_TENSOR_DATA(v86);
                  // pto: %255
                  ;
                  const int64_t v559 = 1;
                  // pto: %255
                  ;
                  const int64_t v560 = 1;
                  // pto: %255
                  ;
                  const int64_t v561 = 1;
                  // pto: %255
                  ;
                  int64_t v562 = v46 * v48;
                  // pto: %255
                  ;
                  int64_t v563 = v561 * v562;
                  // pto: %255
                  ;
                  pto::Shape<1, 1, 1, 1, -1> v564 = pto::Shape<1, 1, 1, 1, -1>(v559, v560, v561, v46, v388);
                  // pto: %255
                  ;
                  pto::Stride<-1, -1, -1, -1, -1> v565 = pto::Stride<-1, -1, -1, -1, -1>(v560 * v563, v563, v562, v48, v46);
                  // pto: %255
                  ;
                  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v566 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v558 + (v557 + v556 * v48 + v53 * v46), v564, v565);
                  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
                  TLOAD(v553, v566);
                  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
                  // pto: %partial_scores_inline9584__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v567 = Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v75);
                  // pto: %partial_scores_inline9584__ssa_v0
                  ;
                  uint64_t v568 = (uint64_t) v26;
                  TASSIGN(v567, v568);
                  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
                  TFILLPAD<pto::TFillPadMode::InPlace>(v567, v553);
                  // pto: %partial_scores_v1_inline9593__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v569 = Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v75);
                  // pto: %partial_scores_v1_inline9593__ssa_v0
                  ;
                  uint64_t v570 = (uint64_t) v40;
                  TASSIGN(v569, v570);
                  pipe_barrier(PIPE_V);
                  TMAXS(v569, v567, v70);
                  // pto: %t__tmp_v857
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v571 = Tile<TileType::Vec, uint32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v75);
                  // pto: %t__tmp_v857
                  ;
                  uint64_t v572 = (uint64_t) v39;
                  TASSIGN(v571, v572);
                  // pto: %partial_pairs_inline9573__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v573 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v76);
                  // pto: %partial_pairs_inline9573__ssa_v0
                  ;
                  uint64_t v574 = (uint64_t) v26;
                  TASSIGN(v573, v574);
                  // pto: %256
                  ;
                  Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v575;
                  TRESHAPE(v575, v569);
                  // pto: %257
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v576;
                  TRESHAPE(v576, v571);
                  // pto: %258
                  ;
                  Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 5120, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v577;
                  TRESHAPE(v577, v573);
                  pipe_barrier(PIPE_V);
                  TSORT32(v577, v575, v576);
                  // pto: %partial_pairs_v1_inline9595__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v578 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v76);
                  // pto: %partial_pairs_v1_inline9595__ssa_v0
                  ;
                  uint64_t v579 = (uint64_t) v39;
                  TASSIGN(v578, v579);
                  pipe_barrier(PIPE_V);
                  TMRGSORT(v578, v573, v71);
                  // pto: %partial_pairs_v2_inline9598__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v580 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v76);
                  // pto: %partial_pairs_v2_inline9598__ssa_v0
                  ;
                  uint64_t v581 = (uint64_t) v26;
                  TASSIGN(v580, v581);
                  pipe_barrier(PIPE_V);
                  TMRGSORT(v580, v578, v72);
                  v580.SetValidShape(v46, v63);
                  // pto: %partial_prefix_v1_inline9599__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v582 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v76);
                  // pto: %partial_prefix_v1_inline9599__ssa_v0
                  ;
                  uint64_t v583 = (uint64_t) v39;
                  TASSIGN(v582, v583);
                  pipe_barrier(PIPE_V);
                  TMRGSORT(v582, v580, v74);
                  // pto: %partial_left_inline9600__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v584 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                  // pto: %partial_left_inline9600__ssa_v0
                  ;
                  uint64_t v585 = (uint64_t) v39;
                  TASSIGN(v584, v585);
                  // pto: %259
                  ;
                  Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v586;
                  // pto: %259
                  ;
                  uint64_t v587 = (uint64_t) v39;
                  TASSIGN(v586, v587);
                  // pto: %partial_right_inline9591__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v588 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                  // pto: %partial_right_inline9591__ssa_v0
                  ;
                  uint64_t v589 = (uint64_t) v36;
                  TASSIGN(v588, v589);
                  // pto: %260
                  ;
                  Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v590;
                  // pto: %260
                  ;
                  uint64_t v591 = (uint64_t) v36;
                  TASSIGN(v590, v591);
                  // pto: %partial_tmp_inline9550__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v592 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v73);
                  // pto: %partial_tmp_inline9550__ssa_v0
                  ;
                  uint64_t v593 = (uint64_t) v41;
                  TASSIGN(v592, v593);
                  // pto: %partial_merged_inline9609__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v594 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
                  // pto: %partial_merged_inline9609__ssa_v0
                  ;
                  uint64_t v595 = (uint64_t) v29;
                  TASSIGN(v594, v595);
                  pipe_barrier(PIPE_V);
                  TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v594, v25, v592, v590, v586);
                  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
                  // pto: %t__tmp_v858
                  ;
                  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v596 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                  // pto: %t__tmp_v858
                  ;
                  uint64_t v597 = (uint64_t) v29;
                  TASSIGN(v596, v597);
                  // pto: %262
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v598;
                  // pto: %262
                  ;
                  uint64_t v599 = (uint64_t) v29;
                  TASSIGN(v598, v599);
                  // pto: %263
                  ;
                  int64_t v600 = v389 < v53 ? v53 : v389;
                  // pto: %264
                  ;
                  __gm__ float* v601 = PTOAS__GLOBAL_TENSOR_DATA(v120);
                  // pto: %264
                  ;
                  const int64_t v602 = 0;
                  // pto: %264
                  ;
                  const int64_t v603 = 1024;
                  // pto: %264
                  ;
                  pto::Shape<1, 1, 1, 1, 1024> v604 = pto::Shape<1, 1, 1, 1, 1024>();
                  // pto: %264
                  ;
                  pto::Stride<1024, 1024, 1024, 1024, 1> v605 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                  // pto: %264
                  ;
                  GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v606 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v601 + (v602 + v600 * v603), v604, v605);
                  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
                  pipe_barrier(PIPE_MTE3);
                  TSTORE(v606, v598);
                } else {
                  // pto: %265
                  ;
                  if (v388 <= v77) {
                    // pto: %t__ci_tmp_v4
                    ;
                    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v607 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
                    // pto: %t__ci_tmp_v4
                    ;
                    uint64_t v608 = (uint64_t) v35;
                    TASSIGN(v607, v608);
                    // pto: %t__tmp_v859
                    ;
                    Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v609 = Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v77);
                    // pto: %t__tmp_v859
                    ;
                    uint64_t v610 = (uint64_t) v26;
                    TASSIGN(v609, v610);
                    // pto: %266
                    ;
                    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v611;
                    TRESHAPE(v611, v607);
                    // pto: %267
                    ;
                    Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v612;
                    TRESHAPE(v612, v609);
                    pipe_barrier(PIPE_V);
                    TCI<Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v612, v52, v611);
                    // pto: %triple_indices_inline9602__ssa_v0
                    ;
                    Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v613 = Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v77);
                    // pto: %triple_indices_inline9602__ssa_v0
                    ;
                    uint64_t v614 = (uint64_t) v37;
                    TASSIGN(v613, v614);
                    pipe_barrier(PIPE_V);
                    TADDS(v613, v609, v390);
                    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                    // pto: %triple_raw_inline9568__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v615 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v388);
                    // pto: %triple_raw_inline9568__ssa_v0
                    ;
                    uint64_t v616 = (uint64_t) v26;
                    TASSIGN(v615, v616);
                    // pto: %268, %269
                    ;
                    int64_t v617 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v384);
                    // pto: %270
                    ;
                    int64_t v618 = v617 < v53 ? v53 : v617;
                    // pto: %271
                    ;
                    const int64_t v619 = 0;
                    // pto: %271
                    ;
                    __gm__ float* v620 = PTOAS__GLOBAL_TENSOR_DATA(v86);
                    // pto: %271
                    ;
                    const int64_t v621 = 1;
                    // pto: %271
                    ;
                    const int64_t v622 = 1;
                    // pto: %271
                    ;
                    const int64_t v623 = 1;
                    // pto: %271
                    ;
                    int64_t v624 = v46 * v48;
                    // pto: %271
                    ;
                    int64_t v625 = v623 * v624;
                    // pto: %271
                    ;
                    pto::Shape<1, 1, 1, 1, -1> v626 = pto::Shape<1, 1, 1, 1, -1>(v621, v622, v623, v46, v388);
                    // pto: %271
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v627 = pto::Stride<-1, -1, -1, -1, -1>(v622 * v625, v625, v624, v48, v46);
                    // pto: %271
                    ;
                    GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v628 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v620 + (v619 + v618 * v48 + v53 * v46), v626, v627);
                    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                    TLOAD(v615, v628);
                    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                    // pto: %triple_scores_inline9605__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v629 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v77);
                    // pto: %triple_scores_inline9605__ssa_v0
                    ;
                    uint64_t v630 = (uint64_t) v26;
                    TASSIGN(v629, v630);
                    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                    TFILLPAD<pto::TFillPadMode::InPlace>(v629, v615);
                    // pto: %triple_scores_v1_inline9582__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v631 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v77);
                    // pto: %triple_scores_v1_inline9582__ssa_v0
                    ;
                    uint64_t v632 = (uint64_t) v42;
                    TASSIGN(v631, v632);
                    pipe_barrier(PIPE_V);
                    TMAXS(v631, v629, v70);
                    // pto: %t__tmp_v860
                    ;
                    Tile<TileType::Vec, uint32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v633 = Tile<TileType::Vec, uint32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v77);
                    // pto: %t__tmp_v860
                    ;
                    uint64_t v634 = (uint64_t) v37;
                    TASSIGN(v633, v634);
                    // pto: %triple_pairs_inline9576__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v635 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v78);
                    // pto: %triple_pairs_inline9576__ssa_v0
                    ;
                    uint64_t v636 = (uint64_t) v26;
                    TASSIGN(v635, v636);
                    // pto: %272
                    ;
                    Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v637;
                    TRESHAPE(v637, v631);
                    // pto: %273
                    ;
                    Tile<TileType::Vec, uint32_t, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v638;
                    TRESHAPE(v638, v633);
                    // pto: %274
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 6144, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v639;
                    TRESHAPE(v639, v635);
                    pipe_barrier(PIPE_V);
                    TSORT32(v639, v637, v638);
                    // pto: %triple_pairs_v1_inline9557__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v640 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v78);
                    // pto: %triple_pairs_v1_inline9557__ssa_v0
                    ;
                    uint64_t v641 = (uint64_t) v37;
                    TASSIGN(v640, v641);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v640, v635, v71);
                    // pto: %triple_pairs_v2_inline9604__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v642 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v78);
                    // pto: %triple_pairs_v2_inline9604__ssa_v0
                    ;
                    uint64_t v643 = (uint64_t) v26;
                    TASSIGN(v642, v643);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v642, v640, v72);
                    v642.SetValidShape(v46, v63);
                    // pto: %triple_prefix_v1_inline9581__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v644 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v78);
                    // pto: %triple_prefix_v1_inline9581__ssa_v0
                    ;
                    uint64_t v645 = (uint64_t) v37;
                    TASSIGN(v644, v645);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v644, v642, v74);
                    // pto: %triple_left_inline9603__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v646 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                    // pto: %triple_left_inline9603__ssa_v0
                    ;
                    uint64_t v647 = (uint64_t) v37;
                    TASSIGN(v646, v647);
                    // pto: %275
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v648;
                    // pto: %275
                    ;
                    uint64_t v649 = (uint64_t) v37;
                    TASSIGN(v648, v649);
                    // pto: %triple_right0_inline9585__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v650 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                    // pto: %triple_right0_inline9585__ssa_v0
                    ;
                    uint64_t v651 = (uint64_t) v36;
                    TASSIGN(v650, v651);
                    // pto: %276
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v652;
                    // pto: %276
                    ;
                    uint64_t v653 = (uint64_t) v36;
                    TASSIGN(v652, v653);
                    // pto: %triple_right1_inline9606__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v654 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                    // pto: %triple_right1_inline9606__ssa_v0
                    ;
                    uint64_t v655 = (uint64_t) v39;
                    TASSIGN(v654, v655);
                    // pto: %277
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v656;
                    // pto: %277
                    ;
                    uint64_t v657 = (uint64_t) v39;
                    TASSIGN(v656, v657);
                    // pto: %triple_tmp_inline9560__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v658 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v77);
                    // pto: %triple_tmp_inline9560__ssa_v0
                    ;
                    uint64_t v659 = (uint64_t) v29;
                    TASSIGN(v658, v659);
                    // pto: %triple_merged_inline9607__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v660 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v77);
                    // pto: %triple_merged_inline9607__ssa_v0
                    ;
                    uint64_t v661 = (uint64_t) v43;
                    TASSIGN(v660, v661);
                    pipe_barrier(PIPE_V);
                    TMRGSORT<Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v660, v25, v658, v652, v656, v648);
                    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
                    // pto: %t__tmp_v861
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v662 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                    // pto: %t__tmp_v861
                    ;
                    uint64_t v663 = (uint64_t) v43;
                    TASSIGN(v662, v663);
                    // pto: %279
                    ;
                    Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v664;
                    // pto: %279
                    ;
                    uint64_t v665 = (uint64_t) v43;
                    TASSIGN(v664, v665);
                    // pto: %280
                    ;
                    int64_t v666 = v389 < v53 ? v53 : v389;
                    // pto: %281
                    ;
                    __gm__ float* v667 = PTOAS__GLOBAL_TENSOR_DATA(v120);
                    // pto: %281
                    ;
                    const int64_t v668 = 0;
                    // pto: %281
                    ;
                    const int64_t v669 = 1024;
                    // pto: %281
                    ;
                    pto::Shape<1, 1, 1, 1, 1024> v670 = pto::Shape<1, 1, 1, 1, 1024>();
                    // pto: %281
                    ;
                    pto::Stride<1024, 1024, 1024, 1024, 1> v671 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                    // pto: %281
                    ;
                    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v672 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v667 + (v668 + v666 * v669), v670, v671);
                    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
                    TSTORE(v672, v664);
                  } else {
                    // pto: %t__ci_tmp_v5
                    ;
                    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v673 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
                    // pto: %t__ci_tmp_v5
                    ;
                    uint64_t v674 = (uint64_t) v36;
                    TASSIGN(v673, v674);
                    // pto: %t__tmp_v862
                    ;
                    Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v675 = Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v63);
                    // pto: %t__tmp_v862
                    ;
                    uint64_t v676 = (uint64_t) v26;
                    TASSIGN(v675, v676);
                    // pto: %282
                    ;
                    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v677;
                    TRESHAPE(v677, v673);
                    // pto: %283
                    ;
                    Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v678;
                    TRESHAPE(v678, v675);
                    pipe_barrier(PIPE_V);
                    TCI<Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v678, v52, v677);
                    // pto: %medium_indices_inline9608__ssa_v0
                    ;
                    Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v679 = Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v63);
                    // pto: %medium_indices_inline9608__ssa_v0
                    ;
                    uint64_t v680 = (uint64_t) v44;
                    TASSIGN(v679, v680);
                    pipe_barrier(PIPE_V);
                    TADDS(v679, v675, v390);
                    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                    // pto: %medium_scores_raw_inline9610__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v681 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v388);
                    // pto: %medium_scores_raw_inline9610__ssa_v0
                    ;
                    uint64_t v682 = (uint64_t) v26;
                    TASSIGN(v681, v682);
                    // pto: %284, %285
                    ;
                    int64_t v683 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v384);
                    // pto: %286
                    ;
                    int64_t v684 = v683 < v53 ? v53 : v683;
                    // pto: %287
                    ;
                    const int64_t v685 = 0;
                    // pto: %287
                    ;
                    __gm__ float* v686 = PTOAS__GLOBAL_TENSOR_DATA(v86);
                    // pto: %287
                    ;
                    const int64_t v687 = 1;
                    // pto: %287
                    ;
                    const int64_t v688 = 1;
                    // pto: %287
                    ;
                    const int64_t v689 = 1;
                    // pto: %287
                    ;
                    int64_t v690 = v46 * v48;
                    // pto: %287
                    ;
                    int64_t v691 = v689 * v690;
                    // pto: %287
                    ;
                    pto::Shape<1, 1, 1, 1, -1> v692 = pto::Shape<1, 1, 1, 1, -1>(v687, v688, v689, v46, v388);
                    // pto: %287
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v693 = pto::Stride<-1, -1, -1, -1, -1>(v688 * v691, v691, v690, v48, v46);
                    // pto: %287
                    ;
                    GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v694 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v686 + (v685 + v684 * v48 + v53 * v46), v692, v693);
                    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                    TLOAD(v681, v694);
                    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                    // pto: %medium_scores_inline9574__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v695 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v63);
                    // pto: %medium_scores_inline9574__ssa_v0
                    ;
                    uint64_t v696 = (uint64_t) v26;
                    TASSIGN(v695, v696);
                    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                    TFILLPAD<pto::TFillPadMode::InPlace>(v695, v681);
                    // pto: %medium_scores_v1_inline9578__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v697 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v63);
                    // pto: %medium_scores_v1_inline9578__ssa_v0
                    ;
                    uint64_t v698 = (uint64_t) v29;
                    TASSIGN(v697, v698);
                    pipe_barrier(PIPE_V);
                    TMAXS(v697, v695, v70);
                    // pto: %t__tmp_v863
                    ;
                    Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v699 = Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v63);
                    // pto: %t__tmp_v863
                    ;
                    uint64_t v700 = (uint64_t) v44;
                    TASSIGN(v699, v700);
                    // pto: %medium_pairs_inline9549__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v701 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v48);
                    // pto: %medium_pairs_inline9549__ssa_v0
                    ;
                    uint64_t v702 = (uint64_t) v26;
                    TASSIGN(v701, v702);
                    // pto: %288
                    ;
                    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v703;
                    TRESHAPE(v703, v697);
                    // pto: %289
                    ;
                    Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v704;
                    TRESHAPE(v704, v699);
                    // pto: %290
                    ;
                    Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 8192, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v705;
                    TRESHAPE(v705, v701);
                    pipe_barrier(PIPE_V);
                    TSORT32(v705, v703, v704);
                    // pto: %medium_pairs_v1_inline9572__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v706 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v48);
                    // pto: %medium_pairs_v1_inline9572__ssa_v0
                    ;
                    uint64_t v707 = (uint64_t) v29;
                    TASSIGN(v706, v707);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v706, v701, v71);
                    // pto: %medium_pairs_v2_inline9548__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v708 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v48);
                    // pto: %medium_pairs_v2_inline9548__ssa_v0
                    ;
                    uint64_t v709 = (uint64_t) v26;
                    TASSIGN(v708, v709);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v708, v706, v72);
                    // pto: %medium_pairs_v3_inline9562__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v710 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v48);
                    // pto: %medium_pairs_v3_inline9562__ssa_v0
                    ;
                    uint64_t v711 = (uint64_t) v29;
                    TASSIGN(v710, v711);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v710, v708, v74);
                    // pto: %medium_left_inline9547__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v712 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                    // pto: %medium_left_inline9547__ssa_v0
                    ;
                    uint64_t v713 = (uint64_t) v29;
                    TASSIGN(v712, v713);
                    // pto: %291
                    ;
                    Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v714;
                    // pto: %291
                    ;
                    uint64_t v715 = (uint64_t) v29;
                    TASSIGN(v714, v715);
                    // pto: %medium_right_inline9546__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v716 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                    // pto: %medium_right_inline9546__ssa_v0
                    ;
                    uint64_t v717 = (uint64_t) v45;
                    TASSIGN(v716, v717);
                    // pto: %292
                    ;
                    Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v718;
                    // pto: %292
                    ;
                    uint64_t v719 = (uint64_t) v45;
                    TASSIGN(v718, v719);
                    // pto: %medium_tmp_inline9545__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v720 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v73);
                    // pto: %medium_tmp_inline9545__ssa_v0
                    ;
                    uint64_t v721 = (uint64_t) v26;
                    TASSIGN(v720, v721);
                    // pto: %medium_merged_inline9544__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v722 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
                    // pto: %medium_merged_inline9544__ssa_v0
                    ;
                    uint64_t v723 = (uint64_t) v34;
                    TASSIGN(v722, v723);
                    pipe_barrier(PIPE_V);
                    TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v722, v25, v720, v718, v714);
                    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                    // pto: %t__tmp_v864
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v724 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                    // pto: %t__tmp_v864
                    ;
                    uint64_t v725 = (uint64_t) v34;
                    TASSIGN(v724, v725);
                    // pto: %294
                    ;
                    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v726;
                    // pto: %294
                    ;
                    uint64_t v727 = (uint64_t) v34;
                    TASSIGN(v726, v727);
                    // pto: %295
                    ;
                    int64_t v728 = v389 < v53 ? v53 : v389;
                    // pto: %296
                    ;
                    __gm__ float* v729 = PTOAS__GLOBAL_TENSOR_DATA(v120);
                    // pto: %296
                    ;
                    const int64_t v730 = 0;
                    // pto: %296
                    ;
                    const int64_t v731 = 1024;
                    // pto: %296
                    ;
                    pto::Shape<1, 1, 1, 1, 1024> v732 = pto::Shape<1, 1, 1, 1, 1024>();
                    // pto: %296
                    ;
                    pto::Stride<1024, 1024, 1024, 1024, 1> v733 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                    // pto: %296
                    ;
                    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v734 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v729 + (v730 + v728 * v731), v732, v733);
                    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                    TSTORE(v734, v726);
                  };
                };
              };
            };
          };
        } else {
          // pto: %empty_pairs_inline1398_inline5065__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v735 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v51);
          // pto: %empty_pairs_inline1398_inline5065__ssa_v0
          ;
          uint64_t v736 = (uint64_t) v26;
          TASSIGN(v735, v736);
          pipe_barrier(PIPE_V);
          TEXPANDS(v735, v70);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
          // pto: %297
          ;
          int64_t v737 = v389 < v53 ? v53 : v389;
          // pto: %298
          ;
          __gm__ float* v738 = PTOAS__GLOBAL_TENSOR_DATA(v120);
          // pto: %298
          ;
          const int64_t v739 = 0;
          // pto: %298
          ;
          const int64_t v740 = 1024;
          // pto: %298
          ;
          pto::Shape<1, 1, 1, 1, 1024> v741 = pto::Shape<1, 1, 1, 1, 1024>();
          // pto: %298
          ;
          pto::Stride<1024, 1024, 1024, 1024, 1> v742 = pto::Stride<1024, 1024, 1024, 1024, 1>();
          // pto: %298
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v743 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v738 + (v739 + v737 * v740), v741, v742);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
          pipe_barrier(PIPE_MTE3);
          TSTORE(v743, v735);
        };
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    };
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}