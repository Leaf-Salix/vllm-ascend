#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void idx_qr_dequant_rope(__gm__ bfloat16_t* v1, __gm__ float* v2, __gm__ float* v3, __gm__ float* v4, __gm__ float* v5, __gm__ int32_t* v6, int64_t v7, int64_t v8, int64_t v9, int64_t v10, int32_t v11, int32_t v12) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v13 = 256;
  const int64_t v14 = 512;
  // pto: %c6176_i64
  const int64_t v15 = 6176;
  // pto: %c10272_i64
  const int64_t v16 = 10272;
  // pto: %c14368_i64
  const int64_t v17 = 14368;
  // pto: %c0_i64
  const int64_t v18 = 0;
  // pto: %c2048_i64
  const int64_t v19 = 2048;
  // pto: %c2080_i64
  const int64_t v20 = 2080;
  // pto: %c4128_i64
  const int64_t v21 = 4128;
  // pto: %c18464_i64
  const int64_t v22 = 18464;
  // pto: %c24096_i64
  const int64_t v23 = 24096;
  const int64_t v24 = 6432;
  // pto: %c19488_i64
  const int64_t v25 = 19488;
  // pto: %c19744_i64
  const int64_t v26 = 19744;
  // pto: %c20000_i64
  const int64_t v27 = 20000;
  const int64_t v28 = 10528;
  // pto: %c25120_i64
  const int64_t v29 = 25120;
  // pto: %c25376_i64
  const int64_t v30 = 25376;
  const int64_t v31 = 14624;
  // pto: %c432_index
  const int64_t v32 = 432;
  // pto: %c8192_index
  const int64_t v33 = 8192;
  // pto: %c1_index
  const int64_t v34 = 1;
  // pto: %c64_index
  const int64_t v35 = 64;
  // pto: %c448_index
  const int64_t v36 = 448;
  // pto: %c8_index
  const int64_t v37 = 8;
  // pto: %cst_23
  const float v38 = 1.0f;
  // pto: %c192_index
  const int64_t v39 = 192;
  // pto: %c0_i32
  const int32_t v40 = 0;
  // pto: %cst_26
  const float v41 = 0.5f;
  // pto: %cst_27
  const float v42 = 2.0f;
  // pto: %c16_index
  const int64_t v43 = 16;
  // pto: %c0_index
  const int64_t v44 = 0;
  // pto: %c4_index
  const int64_t v45 = 4;
  // pto: %c2_index
  const int64_t v46 = 2;
  // pto: %c128_index
  const int64_t v47 = 128;
  // pto: %qr_bf16_2d_inline1750_inline5006__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %qr_bf16_2d_inline1750_inline5006__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %qr_bf16_2d_inline1750_inline5006__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %qr_bf16_2d_inline1750_inline5006__ssa_v0_view
  int64_t v51 = v32 * v33;
  // pto: %qr_bf16_2d_inline1750_inline5006__ssa_v0_view
  int64_t v52 = v50 * v51;
  // pto: %qr_bf16_2d_inline1750_inline5006__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v53 = pto::Shape<1, 1, 1, -1, -1>(v48, v49, v50, v32, v33);
  // pto: %qr_bf16_2d_inline1750_inline5006__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v54 = pto::Stride<-1, -1, -1, -1, -1>(v49 * v52, v52, v51, v33, v34);
  // pto: %qr_bf16_2d_inline1750_inline5006__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v55 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v53, v54);
  // pto: %qr_scale__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %qr_scale__ssa_v0_view
  const int64_t v57 = 1;
  // pto: %qr_scale__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %qr_scale__ssa_v0_view
  int64_t v59 = (int64_t) v10;
  // pto: %qr_scale__ssa_v0_view
  int64_t v60 = v59 * v34;
  // pto: %qr_scale__ssa_v0_view
  int64_t v61 = v58 * v60;
  // pto: %qr_scale__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v62 = pto::Shape<1, 1, 1, -1, -1>(v56, v57, v58, v59, v34);
  // pto: %qr_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v63 = pto::Stride<-1, -1, -1, -1, -1>(v57 * v61, v61, v60, v34, (int64_t) v10);
  // pto: %qr_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v64 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v2, v62, v63);
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v68 = (int64_t) v10;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v69 = v68 * v35;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v70 = v67 * v69;
  // pto: %freqs_cos__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v71 = pto::Shape<1, 1, 1, -1, -1>(v65, v66, v67, v68, v35);
  // pto: %freqs_cos__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v66 * v70, v70, v69, v35, v34);
  // pto: %freqs_cos__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v73 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v71, v72);
  // pto: %idx_sin_signed__ssa_v0_view
  const int64_t v74 = 1;
  // pto: %idx_sin_signed__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %idx_sin_signed__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %idx_sin_signed__ssa_v0_view
  int64_t v77 = (int64_t) v10;
  // pto: %idx_sin_signed__ssa_v0_view
  int64_t v78 = v77 * v35;
  // pto: %idx_sin_signed__ssa_v0_view
  int64_t v79 = v76 * v78;
  // pto: %idx_sin_signed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v80 = pto::Shape<1, 1, 1, -1, -1>(v74, v75, v76, v77, v35);
  // pto: %idx_sin_signed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v81 = pto::Stride<-1, -1, -1, -1, -1>(v75 * v79, v79, v78, v35, v34);
  // pto: %idx_sin_signed__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v82 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v80, v81);
  // pto: %idx_wq_b_scale__ssa_v0_view
  const int64_t v83 = 1;
  // pto: %idx_wq_b_scale__ssa_v0_view
  const int64_t v84 = 1;
  // pto: %idx_wq_b_scale__ssa_v0_view
  const int64_t v85 = 1;
  // pto: %idx_wq_b_scale__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %idx_wq_b_scale__ssa_v0_view
  int64_t v87 = v33 * v34;
  // pto: %idx_wq_b_scale__ssa_v0_view
  int64_t v88 = v86 * v87;
  // pto: %idx_wq_b_scale__ssa_v0_view
  int64_t v89 = v85 * v88;
  // pto: %idx_wq_b_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v90 = pto::Shape<1, 1, 1, 1, -1>(v83, v84, v85, v86, v33);
  // pto: %idx_wq_b_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v91 = pto::Stride<-1, -1, -1, -1, -1>(v84 * v89, v89, v88, v87, v34);
  // pto: %idx_wq_b_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v92 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v90, v91);
  // pto: %qr_acc_pad_inline1727_inline4997__rv_v2_view
  const int64_t v93 = 1;
  // pto: %qr_acc_pad_inline1727_inline4997__rv_v2_view
  const int64_t v94 = 1;
  // pto: %qr_acc_pad_inline1727_inline4997__rv_v2_view
  const int64_t v95 = 1;
  // pto: %qr_acc_pad_inline1727_inline4997__rv_v2_view
  int64_t v96 = v36 * v33;
  // pto: %qr_acc_pad_inline1727_inline4997__rv_v2_view
  int64_t v97 = v95 * v96;
  // pto: %qr_acc_pad_inline1727_inline4997__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v98 = pto::Shape<1, 1, 1, -1, -1>(v93, v94, v95, v36, v33);
  // pto: %qr_acc_pad_inline1727_inline4997__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v99 = pto::Stride<-1, -1, -1, -1, -1>(v94 * v97, v97, v96, v33, v34);
  // pto: %qr_acc_pad_inline1727_inline4997__rv_v2_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v100 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v98, v99);
  // pto: %dq_rope_worker_inline1745_inline5015__ssa_v0
  // pto: %sw_ones_inline1733_inline5012__tile
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %sw_ones_inline1733_inline5012__tile
  uint64_t v102 = (uint64_t) v15;
  TASSIGN(v101, v102);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  TEXPANDS(v101, v38);
  // pto: %t__ci_tmp_v0
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v39);
  // pto: %t__ci_tmp_v0
  uint64_t v104 = (uint64_t) v16;
  TASSIGN(v103, v104);
  // pto: %t__tile
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v105 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
  // pto: %t__tile
  uint64_t v106 = (uint64_t) v17;
  TASSIGN(v105, v106);
  // pto: %ci_tmp_view
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v107;
  TRESHAPE(v107, v103);
  // pto: %ci_dst_view
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v108;
  TRESHAPE(v108, v105);
  TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v108, v40, v107);
  // pto: %sw_index_inline1753_inline5011__tile
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v109 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
  // pto: %sw_index_inline1753_inline5011__tile
  uint64_t v110 = (uint64_t) v16;
  TASSIGN(v109, v110);
  pipe_barrier(PIPE_V);
  RoundMode v111 = RoundMode::CAST_ROUND;
  SaturationMode v112 = SaturationMode::ON;
  TCVT(v109, v105, v111, v112);
  // pto: %sw_col_inline1736_inline5010__tile
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %sw_col_inline1736_inline5010__tile
  uint64_t v114 = (uint64_t) v15;
  TASSIGN(v113, v114);
  pipe_barrier(PIPE_V);
  TCOLEXPANDMUL(v113, v101, v109);
  // pto: %0
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v115 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %0
  uint64_t v116 = (uint64_t) v16;
  TASSIGN(v115, v116);
  pipe_barrier(PIPE_V);
  TMULS(v115, v113, v41);
  // pto: %1
  Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %1
  uint64_t v118 = (uint64_t) v16;
  TASSIGN(v117, v118);
  pipe_barrier(PIPE_V);
  RoundMode v119 = RoundMode::CAST_TRUNC;
  SaturationMode v120 = SaturationMode::ON;
  TCVT(v117, v115, v119, v120);
  // pto: %sw_dup_f_inline1739_inline5003__tile
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %sw_dup_f_inline1739_inline5003__tile
  uint64_t v122 = (uint64_t) v16;
  TASSIGN(v121, v122);
  pipe_barrier(PIPE_V);
  RoundMode v123 = RoundMode::CAST_ROUND;
  SaturationMode v124 = SaturationMode::ON;
  TCVT(v121, v117, v123, v124);
  // pto: %2
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v125 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %2
  uint64_t v126 = (uint64_t) v16;
  TASSIGN(v125, v126);
  pipe_barrier(PIPE_V);
  TMULS(v125, v121, v42);
  // pto: %sw_lane_inline1757_inline5036__tile
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %sw_lane_inline1757_inline5036__tile
  uint64_t v128 = (uint64_t) v16;
  TASSIGN(v127, v128);
  pipe_barrier(PIPE_V);
  TSUB(v127, v113, v125);
  // pto: %3
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %3
  uint64_t v130 = (uint64_t) v15;
  TASSIGN(v129, v130);
  pipe_barrier(PIPE_V);
  TADDS(v129, v113, v38);
  // pto: %4
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %4
  uint64_t v132 = (uint64_t) v16;
  TASSIGN(v131, v132);
  TMULS(v131, v127, v42);
  // pto: %5
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %5
  uint64_t v134 = (uint64_t) v15;
  TASSIGN(v133, v134);
  pipe_barrier(PIPE_V);
  TSUB(v133, v129, v131);
  // pto: %rope_swap_idx_inline1728_inline5004__tile
  Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v135 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %rope_swap_idx_inline1728_inline5004__tile
  uint64_t v136 = (uint64_t) v18;
  TASSIGN(v135, v136);
  pipe_barrier(PIPE_V);
  RoundMode v137 = RoundMode::CAST_ROUND;
  SaturationMode v138 = SaturationMode::ON;
  TCVT(v135, v133, v137, v138);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  for (int64_t v139 = (int64_t) v11; v139 < v7; v139 += v8) {
    // pto: %72
    ;
    int64_t v140 = v139 % v43;
    // pto: %73, %74, %75
    ;
    int64_t v141 = v140 < v44 ? (int64_t) ((uint64_t) v140 + (uint64_t) v43) : v140;
    // pto: %76
    ;
    int64_t v142 = (int64_t) ((uint64_t) v141 * (uint64_t) v45);
    // pto: %77, %78
    ;
    int64_t v143 = (int64_t) ((uint64_t) (v139 / v43) * (uint64_t) v37);
    // pto: %79, %80
    ;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    if ((int64_t) ((uint64_t) v143 + (uint64_t) v37) <= v9) {
      // pto: %qr_scale_tile_inline1763_inline5000__tile
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v144 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v34);
      // pto: %qr_scale_tile_inline1763_inline5000__tile
      ;
      uint64_t v145 = (uint64_t) v19;
      TASSIGN(v144, v145);
      // pto: %81
      ;
      int64_t v146 = v143 < v44 ? v44 : v143;
      // pto: %qr_scale__ssa_v0_pview
      ;
      int64_t v147 = (int64_t) v10;
      // pto: %qr_scale__ssa_v0_pview
      ;
      const int64_t v148 = 0;
      // pto: %qr_scale__ssa_v0_pview
      ;
      __gm__ float* v149 = PTOAS__GLOBAL_TENSOR_DATA(v64);
      // pto: %qr_scale__ssa_v0_pview
      ;
      const int64_t v150 = 1;
      // pto: %qr_scale__ssa_v0_pview
      ;
      const int64_t v151 = 1;
      // pto: %qr_scale__ssa_v0_pview
      ;
      const int64_t v152 = 1;
      // pto: %qr_scale__ssa_v0_pview
      ;
      int64_t v153 = v37 * v34;
      // pto: %qr_scale__ssa_v0_pview
      ;
      int64_t v154 = v152 * v153;
      // pto: %qr_scale__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 1> v155 = pto::Shape<1, 1, 1, 8, 1>(v150, v151, v152, v37, v34);
      // pto: %qr_scale__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v156 = pto::Stride<-1, -1, -1, -1, -1>(v151 * v154, v154, v153, v34, v147);
      // pto: %qr_scale__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v157 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v149 + (v148 + v146 * v34 + v44 * v147), v155, v156);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
      TLOAD(v144, v157);
      // pto: %cos_tile_inline1749_inline4996__tile
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v158 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
      // pto: %cos_tile_inline1749_inline4996__tile
      ;
      uint64_t v159 = (uint64_t) v20;
      TASSIGN(v158, v159);
      // pto: %freqs_cos__ssa_v0_pview
      ;
      __gm__ float* v160 = PTOAS__GLOBAL_TENSOR_DATA(v73);
      // pto: %freqs_cos__ssa_v0_pview
      ;
      const int64_t v161 = 0;
      // pto: %freqs_cos__ssa_v0_pview
      ;
      const int64_t v162 = 64;
      // pto: %freqs_cos__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 64> v163 = pto::Shape<1, 1, 1, 8, 64>();
      // pto: %freqs_cos__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 64, 1> v164 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %freqs_cos__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v165 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v160 + (v161 + v146 * v162), v163, v164);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
      TLOAD(v158, v165);
      // pto: %sin_tile_inline1755_inline5055__tile
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v166 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
      // pto: %sin_tile_inline1755_inline5055__tile
      ;
      uint64_t v167 = (uint64_t) v21;
      TASSIGN(v166, v167);
      // pto: %idx_sin_signed__ssa_v0_pview
      ;
      __gm__ float* v168 = PTOAS__GLOBAL_TENSOR_DATA(v82);
      // pto: %idx_sin_signed__ssa_v0_pview
      ;
      const int64_t v169 = 0;
      // pto: %idx_sin_signed__ssa_v0_pview
      ;
      const int64_t v170 = 64;
      // pto: %idx_sin_signed__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 64> v171 = pto::Shape<1, 1, 1, 8, 64>();
      // pto: %idx_sin_signed__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 64, 1> v172 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %idx_sin_signed__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v173 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v168 + (v169 + v146 * v170), v171, v172);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      TLOAD(v166, v173);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      for (int64_t v174 = v44; v174 < v45; v174 += v46) {
        // pto: %84, %85
        ;
        int64_t v175 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v142 + (uint64_t) v174) * (uint64_t) v47);
        // pto: %87, %86, %88
        ;
        int64_t v176 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v142 + (uint64_t) ((int64_t) (uint64_t) v174 + (uint64_t) v34)) * (uint64_t) v47);
        // pto: %6
        ;
        Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
        // pto: %6
        ;
        uint64_t v178 = (uint64_t) v22;
        TASSIGN(v177, v178);
        // pto: %89
        ;
        int64_t v179 = v175 < v44 ? v44 : v175;
        // pto: %idx_wq_b_scale__ssa_v0_pview
        ;
        __gm__ float* v180 = PTOAS__GLOBAL_TENSOR_DATA(v92);
        // pto: %idx_wq_b_scale__ssa_v0_pview
        ;
        const int64_t v181 = 0;
        // pto: %idx_wq_b_scale__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 128> v182 = pto::Shape<1, 1, 1, 1, 128>();
        // pto: %idx_wq_b_scale__ssa_v0_pview
        ;
        pto::Stride<128, 128, 128, 128, 1> v183 = pto::Stride<128, 128, 128, 128, 1>();
        // pto: %idx_wq_b_scale__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v184 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v180 + (v181 + v179), v182, v183);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        TLOAD(v177, v184);
        // pto: %7
        ;
        Tile<TileType::Vec, int32_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v185 = Tile<TileType::Vec, int32_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %7
        ;
        uint64_t v186 = (uint64_t) v15;
        TASSIGN(v185, v186);
        // pto: %qr_acc_pad_inline1727_inline4997__rv_v2_pview
        ;
        __gm__ int32_t* v187 = PTOAS__GLOBAL_TENSOR_DATA(v100);
        // pto: %qr_acc_pad_inline1727_inline4997__rv_v2_pview
        ;
        const int64_t v188 = 0;
        // pto: %qr_acc_pad_inline1727_inline4997__rv_v2_pview
        ;
        const int64_t v189 = 8192;
        // pto: %qr_acc_pad_inline1727_inline4997__rv_v2_pview
        ;
        pto::Shape<1, 1, 1, 8, 128> v190 = pto::Shape<1, 1, 1, 8, 128>();
        // pto: %qr_acc_pad_inline1727_inline4997__rv_v2_pview
        ;
        pto::Stride<65536, 65536, 65536, 8192, 1> v191 = pto::Stride<65536, 65536, 65536, 8192, 1>();
        // pto: %qr_acc_pad_inline1727_inline4997__rv_v2_pview
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 128>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v192 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 128>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v187 + (v188 + v146 * v189 + v179), v190, v191);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        TLOAD(v185, v192);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %8
        ;
        Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v193 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
        // pto: %8
        ;
        uint64_t v194 = (uint64_t) v23;
        TASSIGN(v193, v194);
        // pto: %92
        ;
        int64_t v195 = v176 < v44 ? v44 : v176;
        // pto: %93
        ;
        __gm__ float* v196 = PTOAS__GLOBAL_TENSOR_DATA(v92);
        // pto: %93
        ;
        const int64_t v197 = 0;
        // pto: %93
        ;
        pto::Shape<1, 1, 1, 1, 128> v198 = pto::Shape<1, 1, 1, 1, 128>();
        // pto: %93
        ;
        pto::Stride<128, 128, 128, 128, 1> v199 = pto::Stride<128, 128, 128, 128, 1>();
        // pto: %93
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v200 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v196 + (v197 + v195), v198, v199);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
        TLOAD(v193, v200);
        // pto: %9
        ;
        Tile<TileType::Vec, int32_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v201 = Tile<TileType::Vec, int32_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %9
        ;
        uint64_t v202 = (uint64_t) v16;
        TASSIGN(v201, v202);
        // pto: %96
        ;
        __gm__ int32_t* v203 = PTOAS__GLOBAL_TENSOR_DATA(v100);
        // pto: %96
        ;
        const int64_t v204 = 0;
        // pto: %96
        ;
        const int64_t v205 = 8192;
        // pto: %96
        ;
        pto::Shape<1, 1, 1, 8, 128> v206 = pto::Shape<1, 1, 1, 8, 128>();
        // pto: %96
        ;
        pto::Stride<65536, 65536, 65536, 8192, 1> v207 = pto::Stride<65536, 65536, 65536, 8192, 1>();
        // pto: %96
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 128>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v208 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 128>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v203 + (v204 + v146 * v205 + v195), v206, v207);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        TLOAD(v201, v208);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %wq_scale_inline1718_inline5047__tile
        ;
        Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v209 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
        // pto: %wq_scale_inline1718_inline5047__tile
        ;
        uint64_t v210 = (uint64_t) v22;
        TASSIGN(v209, v210);
        // pto: %acc_fp32_inline1717_inline5008__tile
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %acc_fp32_inline1717_inline5008__tile
        ;
        uint64_t v212 = (uint64_t) v15;
        TASSIGN(v211, v212);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v213 = RoundMode::CAST_NONE;
        SaturationMode v214 = SaturationMode::ON;
        TCVT(v211, v185, v213, v214);
        // pto: %10
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %10
        ;
        uint64_t v216 = (uint64_t) v17;
        TASSIGN(v215, v216);
        TEXPANDS(v215, v38);
        // pto: %11
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %11
        ;
        uint64_t v218 = (uint64_t) v17;
        TASSIGN(v217, v218);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v217, v215, v144);
        // pto: %qr_dequant_scale_inline1716_inline4999__tile
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v219 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %qr_dequant_scale_inline1716_inline4999__tile
        ;
        uint64_t v220 = (uint64_t) v17;
        TASSIGN(v219, v220);
        pipe_barrier(PIPE_V);
        TCOLEXPANDMUL(v219, v217, v209);
        // pto: %qr_dequant_inline1743_inline5023__tile
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v221 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %qr_dequant_inline1743_inline5023__tile
        ;
        uint64_t v222 = (uint64_t) v15;
        TASSIGN(v221, v222);
        pipe_barrier(PIPE_V);
        TMUL(v221, v211, v219);
        // pto: %12
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v223 = Tile<TileType::Vec, bfloat16_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %12
        ;
        uint64_t v224 = (uint64_t) v17;
        TASSIGN(v223, v224);
        pipe_barrier(PIPE_V);
        RoundMode v225 = RoundMode::CAST_RINT;
        SaturationMode v226 = SaturationMode::ON;
        TCVT(v223, v221, v225, v226);
        // pto: %qr_dequant_v1_inline1715_inline5030__tile
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v227 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %qr_dequant_v1_inline1715_inline5030__tile
        ;
        uint64_t v228 = (uint64_t) v15;
        TASSIGN(v227, v228);
        pipe_barrier(PIPE_V);
        RoundMode v229 = RoundMode::CAST_ROUND;
        SaturationMode v230 = SaturationMode::ON;
        TCVT(v227, v223, v229, v230);
        // pto: %13
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v231 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %13
        ;
        uint64_t v232 = (uint64_t) v15;
        TASSIGN(v231, v232);
        // pto: %slice_view
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v233;
        // pto: %slice_view
        ;
        uint64_t v234 = (uint64_t) v15;
        TASSIGN(v233, v234);
        // pto: %qr_nope_bf16_inline1714_inline5034__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v235 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %qr_nope_bf16_inline1714_inline5034__tile
        ;
        uint64_t v236 = (uint64_t) v22;
        TASSIGN(v235, v236);
        pipe_barrier(PIPE_V);
        RoundMode v237 = RoundMode::CAST_RINT;
        SaturationMode v238 = SaturationMode::ON;
        TCVT(v235, v233, v237, v238);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %qr_rope_slice_inline1734_inline5017__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v239 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %qr_rope_slice_inline1734_inline5017__tile
        ;
        uint64_t v240 = (uint64_t) v24;
        TASSIGN(v239, v240);
        // pto: %97
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v241;
        // pto: %97
        ;
        uint64_t v242 = (uint64_t) v24;
        TASSIGN(v241, v242);
        // pto: %gather_acc_init
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v243 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %gather_acc_init
        ;
        uint64_t v244 = (uint64_t) v17;
        TASSIGN(v243, v244);
        for (int64_t v245 = v44; v245 < v37; v245 += v34) {
          // pto: %gather_inp_row
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v246 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %gather_inp_row
          ;
          uint64_t v247 = (uint64_t) v15;
          TASSIGN(v246, v247);
          // pto: %98
          ;
          Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v248;
          // pto: %98
          ;
          uint64_t v249 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v245 * (uint64_t) v14) + (uint64_t) v24);
          TASSIGN(v248, v249);
          // pto: %gather_idx_row
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v250 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %gather_idx_row
          ;
          uint64_t v251 = (uint64_t) v18;
          TASSIGN(v250, v251);
          // pto: %99
          ;
          int64_t v252 = (int64_t) ((uint64_t) v245 * (uint64_t) v13);
          // pto: %99
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v253;
          // pto: %99
          ;
          uint64_t v254 = (uint64_t) v252;
          TASSIGN(v253, v254);
          // pto: %gather_row_tmp
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v255 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %gather_row_tmp
          ;
          uint64_t v256 = (uint64_t) v25;
          TASSIGN(v255, v256);
          // pto: %gather_row
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v257 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %gather_row
          ;
          uint64_t v258 = (uint64_t) v26;
          TASSIGN(v257, v258);
          pipe_barrier(PIPE_V);
          TGATHER(v257, v248, v253, v255);
          // pto: %assemble_view
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v259;
          // pto: %assemble_view
          ;
          uint64_t v260 = (uint64_t) ((int64_t) (uint64_t) v252 + (uint64_t) v17);
          TASSIGN(v259, v260);
          pipe_barrier(PIPE_V);
          TMOV(v259, v257);
        };
        // pto: %qr_swapped_inline1754_inline5056__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v261 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %qr_swapped_inline1754_inline5056__tile
        ;
        uint64_t v262 = (uint64_t) v17;
        TASSIGN(v261, v262);
        // pto: %14
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v263 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %14
        ;
        uint64_t v264 = (uint64_t) v15;
        TASSIGN(v263, v264);
        pipe_barrier(PIPE_V);
        TMUL(v263, v241, v158);
        // pto: %15
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v265 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %15
        ;
        uint64_t v266 = (uint64_t) v17;
        TASSIGN(v265, v266);
        TMUL(v265, v261, v166);
        // pto: %rope_rot_inline1713_inline5037__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v267 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %rope_rot_inline1713_inline5037__tile
        ;
        uint64_t v268 = (uint64_t) v15;
        TASSIGN(v267, v268);
        pipe_barrier(PIPE_V);
        TADD(v267, v263, v265);
        // pto: %rope_bf16_inline1711_inline5041__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v269 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %rope_bf16_inline1711_inline5041__tile
        ;
        uint64_t v270 = (uint64_t) v15;
        TASSIGN(v269, v270);
        pipe_barrier(PIPE_V);
        RoundMode v271 = RoundMode::CAST_RINT;
        SaturationMode v272 = SaturationMode::ON;
        TCVT(v269, v267, v271, v272);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        // pto: %qr_bf16_2d_inline1750_inline5006__iter_v3_pview
        ;
        __gm__ bfloat16_t* v273 = PTOAS__GLOBAL_TENSOR_DATA(v55);
        // pto: %qr_bf16_2d_inline1750_inline5006__iter_v3_pview
        ;
        const int64_t v274 = 0;
        // pto: %qr_bf16_2d_inline1750_inline5006__iter_v3_pview
        ;
        const int64_t v275 = 8192;
        // pto: %qr_bf16_2d_inline1750_inline5006__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, 8, 64> v276 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %qr_bf16_2d_inline1750_inline5006__iter_v3_pview
        ;
        pto::Stride<65536, 65536, 65536, 8192, 1> v277 = pto::Stride<65536, 65536, 65536, 8192, 1>();
        // pto: %qr_bf16_2d_inline1750_inline5006__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v278 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v273 + (v274 + v146 * v275 + v179), v276, v277);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v278, v235);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        // pto: %104
        ;
        int64_t v279 = (int64_t) ((uint64_t) v175 + (uint64_t) v35);
        // pto: %105
        ;
        int64_t v280 = v279 < v44 ? v44 : v279;
        // pto: %qr_bf16_2d_inline1750_inline5006__tile_pview
        ;
        __gm__ bfloat16_t* v281 = PTOAS__GLOBAL_TENSOR_DATA(v55);
        // pto: %qr_bf16_2d_inline1750_inline5006__tile_pview
        ;
        const int64_t v282 = 0;
        // pto: %qr_bf16_2d_inline1750_inline5006__tile_pview
        ;
        const int64_t v283 = 8192;
        // pto: %qr_bf16_2d_inline1750_inline5006__tile_pview
        ;
        pto::Shape<1, 1, 1, 8, 64> v284 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %qr_bf16_2d_inline1750_inline5006__tile_pview
        ;
        pto::Stride<65536, 65536, 65536, 8192, 1> v285 = pto::Stride<65536, 65536, 65536, 8192, 1>();
        // pto: %qr_bf16_2d_inline1750_inline5006__tile_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v286 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v281 + (v282 + v146 * v283 + v280), v284, v285);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v286, v269);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        // pto: %16
        ;
        Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v287 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
        // pto: %16
        ;
        uint64_t v288 = (uint64_t) v23;
        TASSIGN(v287, v288);
        // pto: %17
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v289 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %17
        ;
        uint64_t v290 = (uint64_t) v16;
        TASSIGN(v289, v290);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        RoundMode v291 = RoundMode::CAST_NONE;
        SaturationMode v292 = SaturationMode::ON;
        TCVT(v289, v201, v291, v292);
        // pto: %18
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v293 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %18
        ;
        uint64_t v294 = (uint64_t) v27;
        TASSIGN(v293, v294);
        TEXPANDS(v293, v38);
        // pto: %19
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v295 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %19
        ;
        uint64_t v296 = (uint64_t) v27;
        TASSIGN(v295, v296);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v295, v293, v144);
        // pto: %20
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v297 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %20
        ;
        uint64_t v298 = (uint64_t) v27;
        TASSIGN(v297, v298);
        pipe_barrier(PIPE_V);
        TCOLEXPANDMUL(v297, v295, v287);
        // pto: %21
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v299 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %21
        ;
        uint64_t v300 = (uint64_t) v16;
        TASSIGN(v299, v300);
        pipe_barrier(PIPE_V);
        TMUL(v299, v289, v297);
        // pto: %22
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v301 = Tile<TileType::Vec, bfloat16_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %22
        ;
        uint64_t v302 = (uint64_t) v27;
        TASSIGN(v301, v302);
        pipe_barrier(PIPE_V);
        RoundMode v303 = RoundMode::CAST_RINT;
        SaturationMode v304 = SaturationMode::ON;
        TCVT(v301, v299, v303, v304);
        // pto: %23
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v305 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %23
        ;
        uint64_t v306 = (uint64_t) v16;
        TASSIGN(v305, v306);
        pipe_barrier(PIPE_V);
        RoundMode v307 = RoundMode::CAST_ROUND;
        SaturationMode v308 = SaturationMode::ON;
        TCVT(v305, v301, v307, v308);
        // pto: %24
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %24
        ;
        uint64_t v310 = (uint64_t) v16;
        TASSIGN(v309, v310);
        // pto: %106
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v311;
        // pto: %106
        ;
        uint64_t v312 = (uint64_t) v16;
        TASSIGN(v311, v312);
        // pto: %25
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %25
        ;
        uint64_t v314 = (uint64_t) v23;
        TASSIGN(v313, v314);
        pipe_barrier(PIPE_V);
        RoundMode v315 = RoundMode::CAST_RINT;
        SaturationMode v316 = SaturationMode::ON;
        TCVT(v313, v311, v315, v316);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        // pto: %26
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v317 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %26
        ;
        uint64_t v318 = (uint64_t) v28;
        TASSIGN(v317, v318);
        // pto: %107
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v319;
        // pto: %107
        ;
        uint64_t v320 = (uint64_t) v28;
        TASSIGN(v319, v320);
        // pto: %27
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v321 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %27
        ;
        uint64_t v322 = (uint64_t) v27;
        TASSIGN(v321, v322);
        for (int64_t v323 = v44; v323 < v37; v323 += v34) {
          // pto: %28
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v324 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %28
          ;
          uint64_t v325 = (uint64_t) v16;
          TASSIGN(v324, v325);
          // pto: %109
          ;
          Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v326;
          // pto: %109
          ;
          uint64_t v327 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v323 * (uint64_t) v14) + (uint64_t) v28);
          TASSIGN(v326, v327);
          // pto: %29
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v328 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %29
          ;
          uint64_t v329 = (uint64_t) v18;
          TASSIGN(v328, v329);
          // pto: %110
          ;
          int64_t v330 = (int64_t) ((uint64_t) v323 * (uint64_t) v13);
          // pto: %110
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v331;
          // pto: %110
          ;
          uint64_t v332 = (uint64_t) v330;
          TASSIGN(v331, v332);
          // pto: %30
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v333 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %30
          ;
          uint64_t v334 = (uint64_t) v29;
          TASSIGN(v333, v334);
          // pto: %31
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v335 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %31
          ;
          uint64_t v336 = (uint64_t) v30;
          TASSIGN(v335, v336);
          pipe_barrier(PIPE_V);
          TGATHER(v335, v326, v331, v333);
          // pto: %111
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v337;
          // pto: %111
          ;
          uint64_t v338 = (uint64_t) ((int64_t) (uint64_t) v330 + (uint64_t) v27);
          TASSIGN(v337, v338);
          pipe_barrier(PIPE_V);
          TMOV(v337, v335);
        };
        // pto: %33
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v339 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %33
        ;
        uint64_t v340 = (uint64_t) v27;
        TASSIGN(v339, v340);
        // pto: %34
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v341 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %34
        ;
        uint64_t v342 = (uint64_t) v16;
        TASSIGN(v341, v342);
        pipe_barrier(PIPE_V);
        TMUL(v341, v319, v158);
        // pto: %35
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v343 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %35
        ;
        uint64_t v344 = (uint64_t) v27;
        TASSIGN(v343, v344);
        TMUL(v343, v339, v166);
        // pto: %36
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v345 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %36
        ;
        uint64_t v346 = (uint64_t) v16;
        TASSIGN(v345, v346);
        pipe_barrier(PIPE_V);
        TADD(v345, v341, v343);
        // pto: %37
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v347 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %37
        ;
        uint64_t v348 = (uint64_t) v16;
        TASSIGN(v347, v348);
        pipe_barrier(PIPE_V);
        RoundMode v349 = RoundMode::CAST_RINT;
        SaturationMode v350 = SaturationMode::ON;
        TCVT(v347, v345, v349, v350);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        // pto: %115
        ;
        __gm__ bfloat16_t* v351 = PTOAS__GLOBAL_TENSOR_DATA(v55);
        // pto: %115
        ;
        const int64_t v352 = 0;
        // pto: %115
        ;
        const int64_t v353 = 8192;
        // pto: %115
        ;
        pto::Shape<1, 1, 1, 8, 64> v354 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %115
        ;
        pto::Stride<65536, 65536, 65536, 8192, 1> v355 = pto::Stride<65536, 65536, 65536, 8192, 1>();
        // pto: %115
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v356 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v351 + (v352 + v146 * v353 + v195), v354, v355);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v356, v313);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
        // pto: %118
        ;
        int64_t v357 = (int64_t) ((uint64_t) v176 + (uint64_t) v35);
        // pto: %119
        ;
        int64_t v358 = v357 < v44 ? v44 : v357;
        // pto: %120
        ;
        __gm__ bfloat16_t* v359 = PTOAS__GLOBAL_TENSOR_DATA(v55);
        // pto: %120
        ;
        const int64_t v360 = 0;
        // pto: %120
        ;
        const int64_t v361 = 8192;
        // pto: %120
        ;
        pto::Shape<1, 1, 1, 8, 64> v362 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %120
        ;
        pto::Stride<65536, 65536, 65536, 8192, 1> v363 = pto::Stride<65536, 65536, 65536, 8192, 1>();
        // pto: %120
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v364 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v359 + (v360 + v146 * v361 + v358), v362, v363);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        TSTORE(v364, v347);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      };
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    } else {
      // pto: %tail_swap_idx_inline1730_inline5042__tile
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v365 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
      // pto: %tail_swap_idx_inline1730_inline5042__tile
      ;
      uint64_t v366 = (uint64_t) v18;
      TASSIGN(v365, v366);
      // pto: %121
      ;
      uint64_t v367 = (uint64_t) v18;
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      for (int64_t v368 = v143; v368 < v9; v368 += v34) {
        // pto: %tail_qr_scale_value_inline1709_inline5009__tile
        ;
        float v369 = (v2)[v368];
        // pto: %tail_cos_tile_inline1722_inline5014__tile
        ;
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v370 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
        // pto: %tail_cos_tile_inline1722_inline5014__tile
        ;
        uint64_t v371 = (uint64_t) v20;
        TASSIGN(v370, v371);
        // pto: %122
        ;
        int64_t v372 = v368 < v44 ? v44 : v368;
        // pto: %123
        ;
        __gm__ float* v373 = PTOAS__GLOBAL_TENSOR_DATA(v73);
        // pto: %123
        ;
        const int64_t v374 = 0;
        // pto: %123
        ;
        const int64_t v375 = 64;
        // pto: %123
        ;
        pto::Shape<1, 1, 1, 1, 64> v376 = pto::Shape<1, 1, 1, 1, 64>();
        // pto: %123
        ;
        pto::Stride<64, 64, 64, 64, 1> v377 = pto::Stride<64, 64, 64, 64, 1>();
        // pto: %123
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v378 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v373 + (v374 + v372 * v375), v376, v377);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        TLOAD(v370, v378);
        // pto: %tail_sin_tile_inline1758_inline5035__tile
        ;
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v379 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
        // pto: %tail_sin_tile_inline1758_inline5035__tile
        ;
        uint64_t v380 = (uint64_t) v21;
        TASSIGN(v379, v380);
        // pto: %125
        ;
        __gm__ float* v381 = PTOAS__GLOBAL_TENSOR_DATA(v82);
        // pto: %125
        ;
        const int64_t v382 = 0;
        // pto: %125
        ;
        const int64_t v383 = 64;
        // pto: %125
        ;
        pto::Shape<1, 1, 1, 1, 64> v384 = pto::Shape<1, 1, 1, 1, 64>();
        // pto: %125
        ;
        pto::Stride<64, 64, 64, 64, 1> v385 = pto::Stride<64, 64, 64, 64, 1>();
        // pto: %125
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v386 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v381 + (v382 + v372 * v383), v384, v385);
        pipe_barrier(PIPE_ALL);
        TLOAD(v379, v386);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
        for (int64_t v387 = v44; v387 < v45; v387 += v46) {
          // pto: %126, %127
          ;
          int64_t v388 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v142 + (uint64_t) v387) * (uint64_t) v47);
          // pto: %129, %128, %130
          ;
          int64_t v389 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v142 + (uint64_t) ((int64_t) (uint64_t) v387 + (uint64_t) v34)) * (uint64_t) v47);
          // pto: %38
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v390 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %38
          ;
          uint64_t v391 = (uint64_t) v15;
          TASSIGN(v390, v391);
          // pto: %131
          ;
          int64_t v392 = v388 < v44 ? v44 : v388;
          // pto: %132
          ;
          __gm__ float* v393 = PTOAS__GLOBAL_TENSOR_DATA(v92);
          // pto: %132
          ;
          const int64_t v394 = 0;
          // pto: %132
          ;
          pto::Shape<1, 1, 1, 1, 128> v395 = pto::Shape<1, 1, 1, 1, 128>();
          // pto: %132
          ;
          pto::Stride<128, 128, 128, 128, 1> v396 = pto::Stride<128, 128, 128, 128, 1>();
          // pto: %132
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v397 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v393 + (v394 + v392), v395, v396);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
          TLOAD(v390, v397);
          // pto: %39
          ;
          Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v398 = Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %39
          ;
          uint64_t v399 = (uint64_t) v16;
          TASSIGN(v398, v399);
          // pto: %135
          ;
          __gm__ int32_t* v400 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %135
          ;
          const int64_t v401 = 0;
          // pto: %135
          ;
          const int64_t v402 = 8192;
          // pto: %135
          ;
          pto::Shape<1, 1, 1, 1, 128> v403 = pto::Shape<1, 1, 1, 1, 128>();
          // pto: %135
          ;
          pto::Stride<8192, 8192, 8192, 8192, 1> v404 = pto::Stride<8192, 8192, 8192, 8192, 1>();
          // pto: %135
          ;
          GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v405 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v400 + (v401 + v372 * v402 + v392), v403, v404);
          TLOAD(v398, v405);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          // pto: %40
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v406 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %40
          ;
          uint64_t v407 = (uint64_t) v17;
          TASSIGN(v406, v407);
          // pto: %136
          ;
          int64_t v408 = v389 < v44 ? v44 : v389;
          // pto: %137
          ;
          __gm__ float* v409 = PTOAS__GLOBAL_TENSOR_DATA(v92);
          // pto: %137
          ;
          const int64_t v410 = 0;
          // pto: %137
          ;
          pto::Shape<1, 1, 1, 1, 128> v411 = pto::Shape<1, 1, 1, 1, 128>();
          // pto: %137
          ;
          pto::Stride<128, 128, 128, 128, 1> v412 = pto::Stride<128, 128, 128, 128, 1>();
          // pto: %137
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v413 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v409 + (v410 + v408), v411, v412);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
          TLOAD(v406, v413);
          // pto: %41
          ;
          Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v414 = Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %41
          ;
          uint64_t v415 = (uint64_t) v27;
          TASSIGN(v414, v415);
          // pto: %140
          ;
          __gm__ int32_t* v416 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %140
          ;
          const int64_t v417 = 0;
          // pto: %140
          ;
          const int64_t v418 = 8192;
          // pto: %140
          ;
          pto::Shape<1, 1, 1, 1, 128> v419 = pto::Shape<1, 1, 1, 1, 128>();
          // pto: %140
          ;
          pto::Stride<8192, 8192, 8192, 8192, 1> v420 = pto::Stride<8192, 8192, 8192, 8192, 1>();
          // pto: %140
          ;
          GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v421 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v416 + (v417 + v372 * v418 + v408), v419, v420);
          TLOAD(v414, v421);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
          // pto: %tail_wq_scale_inline1707_inline5059__tile
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v422 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %tail_wq_scale_inline1707_inline5059__tile
          ;
          uint64_t v423 = (uint64_t) v15;
          TASSIGN(v422, v423);
          // pto: %tail_acc_fp32_inline1729_inline5048__tile
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v424 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %tail_acc_fp32_inline1729_inline5048__tile
          ;
          uint64_t v425 = (uint64_t) v16;
          TASSIGN(v424, v425);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          RoundMode v426 = RoundMode::CAST_NONE;
          SaturationMode v427 = SaturationMode::ON;
          TCVT(v424, v398, v426, v427);
          // pto: %tail_qr_dequant_scale_inline1761_inline5061__tile
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v428 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %tail_qr_dequant_scale_inline1761_inline5061__tile
          ;
          uint64_t v429 = (uint64_t) v15;
          TASSIGN(v428, v429);
          TMULS(v428, v422, v369);
          // pto: %tail_qr_dequant_inline1710_inline5049__tile
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v430 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %tail_qr_dequant_inline1710_inline5049__tile
          ;
          uint64_t v431 = (uint64_t) v15;
          TASSIGN(v430, v431);
          pipe_barrier(PIPE_V);
          TMUL(v430, v424, v428);
          // pto: %42
          ;
          Tile<TileType::Vec, bfloat16_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v432 = Tile<TileType::Vec, bfloat16_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %42
          ;
          uint64_t v433 = (uint64_t) v16;
          TASSIGN(v432, v433);
          pipe_barrier(PIPE_V);
          RoundMode v434 = RoundMode::CAST_RINT;
          SaturationMode v435 = SaturationMode::ON;
          TCVT(v432, v430, v434, v435);
          // pto: %tail_qr_dequant_v1_inline1737_inline5062__tile
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v436 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %tail_qr_dequant_v1_inline1737_inline5062__tile
          ;
          uint64_t v437 = (uint64_t) v15;
          TASSIGN(v436, v437);
          pipe_barrier(PIPE_V);
          RoundMode v438 = RoundMode::CAST_ROUND;
          SaturationMode v439 = SaturationMode::ON;
          TCVT(v436, v432, v438, v439);
          // pto: %43
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v440 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %43
          ;
          uint64_t v441 = (uint64_t) v15;
          TASSIGN(v440, v441);
          // pto: %141
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v442;
          // pto: %141
          ;
          uint64_t v443 = (uint64_t) v15;
          TASSIGN(v442, v443);
          // pto: %tail_qr_nope_bf16_inline1720_inline5053__tile
          ;
          Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v444 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %tail_qr_nope_bf16_inline1720_inline5053__tile
          ;
          uint64_t v445 = (uint64_t) v29;
          TASSIGN(v444, v445);
          pipe_barrier(PIPE_V);
          RoundMode v446 = RoundMode::CAST_RINT;
          SaturationMode v447 = SaturationMode::ON;
          TCVT(v444, v442, v446, v447);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
          // pto: %tail_qr_rope_slice_inline1706_inline5019__tile
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v448 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %tail_qr_rope_slice_inline1706_inline5019__tile
          ;
          uint64_t v449 = (uint64_t) v24;
          TASSIGN(v448, v449);
          // pto: %142
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v450;
          // pto: %142
          ;
          uint64_t v451 = (uint64_t) v24;
          TASSIGN(v450, v451);
          // pto: %44
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v452 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %44
          ;
          uint64_t v453 = (uint64_t) v16;
          TASSIGN(v452, v453);
          // pto: %45
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v454 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %45
          ;
          uint64_t v455 = (uint64_t) v15;
          TASSIGN(v454, v455);
          // pto: %143
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v456;
          // pto: %143
          ;
          uint64_t v457 = (uint64_t) v24;
          TASSIGN(v456, v457);
          // pto: %46
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v458 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %46
          ;
          uint64_t v459 = (uint64_t) v18;
          TASSIGN(v458, v459);
          // pto: %144
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v460;
          // pto: %144
          ;
          uint64_t v461 = (uint64_t) v18;
          TASSIGN(v460, v461);
          // pto: %47
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v462 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %47
          ;
          uint64_t v463 = (uint64_t) v22;
          TASSIGN(v462, v463);
          // pto: %48
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v464 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %48
          ;
          uint64_t v465 = (uint64_t) v23;
          TASSIGN(v464, v465);
          TGATHER(v464, v456, v460, v462);
          // pto: %145
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v466;
          // pto: %145
          ;
          uint64_t v467 = (uint64_t) v16;
          TASSIGN(v466, v467);
          pipe_barrier(PIPE_V);
          TMOV(v466, v464);
          // pto: %tail_qr_swapped_inline1742_inline5054__tile
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v468 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %tail_qr_swapped_inline1742_inline5054__tile
          ;
          uint64_t v469 = (uint64_t) v16;
          TASSIGN(v468, v469);
          // pto: %50
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v470 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %50
          ;
          uint64_t v471 = (uint64_t) v15;
          TASSIGN(v470, v471);
          TMUL(v470, v450, v370);
          // pto: %51
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v472 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %51
          ;
          uint64_t v473 = (uint64_t) v16;
          TASSIGN(v472, v473);
          pipe_barrier(PIPE_V);
          TMUL(v472, v468, v379);
          // pto: %tail_rope_rot_inline1760_inline5064__tile
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v474 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %tail_rope_rot_inline1760_inline5064__tile
          ;
          uint64_t v475 = (uint64_t) v15;
          TASSIGN(v474, v475);
          pipe_barrier(PIPE_V);
          TADD(v474, v470, v472);
          // pto: %tail_rope_bf16_inline1732_inline5024__tile
          ;
          Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v476 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %tail_rope_bf16_inline1732_inline5024__tile
          ;
          uint64_t v477 = (uint64_t) v15;
          TASSIGN(v476, v477);
          pipe_barrier(PIPE_V);
          RoundMode v478 = RoundMode::CAST_RINT;
          SaturationMode v479 = SaturationMode::ON;
          TCVT(v476, v474, v478, v479);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
          // pto: %qr_bf16_2d_inline1750_inline5006__iter_v9_pview
          ;
          __gm__ bfloat16_t* v480 = PTOAS__GLOBAL_TENSOR_DATA(v55);
          // pto: %qr_bf16_2d_inline1750_inline5006__iter_v9_pview
          ;
          const int64_t v481 = 0;
          // pto: %qr_bf16_2d_inline1750_inline5006__iter_v9_pview
          ;
          const int64_t v482 = 8192;
          // pto: %qr_bf16_2d_inline1750_inline5006__iter_v9_pview
          ;
          pto::Shape<1, 1, 1, 1, 64> v483 = pto::Shape<1, 1, 1, 1, 64>();
          // pto: %qr_bf16_2d_inline1750_inline5006__iter_v9_pview
          ;
          pto::Stride<8192, 8192, 8192, 8192, 1> v484 = pto::Stride<8192, 8192, 8192, 8192, 1>();
          // pto: %qr_bf16_2d_inline1750_inline5006__iter_v9_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v485 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v480 + (v481 + v372 * v482 + v392), v483, v484);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
          pipe_barrier(PIPE_MTE3);
          TSTORE(v485, v444);
          // pto: %151
          ;
          int64_t v486 = (int64_t) ((uint64_t) v388 + (uint64_t) v35);
          // pto: %152
          ;
          int64_t v487 = v486 < v44 ? v44 : v486;
          // pto: %153
          ;
          __gm__ bfloat16_t* v488 = PTOAS__GLOBAL_TENSOR_DATA(v55);
          // pto: %153
          ;
          const int64_t v489 = 0;
          // pto: %153
          ;
          const int64_t v490 = 8192;
          // pto: %153
          ;
          pto::Shape<1, 1, 1, 1, 64> v491 = pto::Shape<1, 1, 1, 1, 64>();
          // pto: %153
          ;
          pto::Stride<8192, 8192, 8192, 8192, 1> v492 = pto::Stride<8192, 8192, 8192, 8192, 1>();
          // pto: %153
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v493 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v488 + (v489 + v372 * v490 + v487), v491, v492);
          pipe_barrier(PIPE_MTE3);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
          TSTORE(v493, v476);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
          // pto: %52
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v494 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %52
          ;
          uint64_t v495 = (uint64_t) v17;
          TASSIGN(v494, v495);
          // pto: %53
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v496 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %53
          ;
          uint64_t v497 = (uint64_t) v27;
          TASSIGN(v496, v497);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
          RoundMode v498 = RoundMode::CAST_NONE;
          SaturationMode v499 = SaturationMode::ON;
          TCVT(v496, v414, v498, v499);
          // pto: %54
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v500 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %54
          ;
          uint64_t v501 = (uint64_t) v17;
          TASSIGN(v500, v501);
          TMULS(v500, v494, v369);
          // pto: %55
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v502 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %55
          ;
          uint64_t v503 = (uint64_t) v17;
          TASSIGN(v502, v503);
          pipe_barrier(PIPE_V);
          TMUL(v502, v496, v500);
          // pto: %56
          ;
          Tile<TileType::Vec, bfloat16_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v504 = Tile<TileType::Vec, bfloat16_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %56
          ;
          uint64_t v505 = (uint64_t) v27;
          TASSIGN(v504, v505);
          pipe_barrier(PIPE_V);
          RoundMode v506 = RoundMode::CAST_RINT;
          SaturationMode v507 = SaturationMode::ON;
          TCVT(v504, v502, v506, v507);
          // pto: %57
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v508 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %57
          ;
          uint64_t v509 = (uint64_t) v17;
          TASSIGN(v508, v509);
          pipe_barrier(PIPE_V);
          RoundMode v510 = RoundMode::CAST_ROUND;
          SaturationMode v511 = SaturationMode::ON;
          TCVT(v508, v504, v510, v511);
          // pto: %58
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v512 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %58
          ;
          uint64_t v513 = (uint64_t) v17;
          TASSIGN(v512, v513);
          // pto: %154
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v514;
          // pto: %154
          ;
          uint64_t v515 = (uint64_t) v17;
          TASSIGN(v514, v515);
          // pto: %59
          ;
          Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v516 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %59
          ;
          uint64_t v517 = (uint64_t) v30;
          TASSIGN(v516, v517);
          pipe_barrier(PIPE_V);
          RoundMode v518 = RoundMode::CAST_RINT;
          SaturationMode v519 = SaturationMode::ON;
          TCVT(v516, v514, v518, v519);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
          // pto: %60
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v520 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %60
          ;
          uint64_t v521 = (uint64_t) v31;
          TASSIGN(v520, v521);
          // pto: %155
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v522;
          // pto: %155
          ;
          uint64_t v523 = (uint64_t) v31;
          TASSIGN(v522, v523);
          // pto: %61
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v524 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %61
          ;
          uint64_t v525 = (uint64_t) v27;
          TASSIGN(v524, v525);
          // pto: %62
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v526 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %62
          ;
          uint64_t v527 = (uint64_t) v17;
          TASSIGN(v526, v527);
          // pto: %156
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v528;
          // pto: %156
          ;
          uint64_t v529 = (uint64_t) v31;
          TASSIGN(v528, v529);
          // pto: %63
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v530 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %63
          ;
          uint64_t v531 = (uint64_t) v18;
          TASSIGN(v530, v531);
          // pto: %157
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v532;
          // pto: %157
          ;
          uint64_t v533 = (uint64_t) v18;
          TASSIGN(v532, v533);
          // pto: %64
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v534 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %64
          ;
          uint64_t v535 = (uint64_t) v25;
          TASSIGN(v534, v535);
          // pto: %65
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v536 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %65
          ;
          uint64_t v537 = (uint64_t) v26;
          TASSIGN(v536, v537);
          TGATHER(v536, v528, v532, v534);
          // pto: %158
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v538;
          // pto: %158
          ;
          uint64_t v539 = (uint64_t) v27;
          TASSIGN(v538, v539);
          pipe_barrier(PIPE_V);
          TMOV(v538, v536);
          // pto: %67
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v540 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %67
          ;
          uint64_t v541 = (uint64_t) v27;
          TASSIGN(v540, v541);
          // pto: %68
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v542 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %68
          ;
          uint64_t v543 = (uint64_t) v17;
          TASSIGN(v542, v543);
          TMUL(v542, v522, v370);
          // pto: %69
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v544 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %69
          ;
          uint64_t v545 = (uint64_t) v27;
          TASSIGN(v544, v545);
          pipe_barrier(PIPE_V);
          TMUL(v544, v540, v379);
          // pto: %70
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v546 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %70
          ;
          uint64_t v547 = (uint64_t) v17;
          TASSIGN(v546, v547);
          pipe_barrier(PIPE_V);
          TADD(v546, v542, v544);
          // pto: %71
          ;
          Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v548 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %71
          ;
          uint64_t v549 = (uint64_t) v17;
          TASSIGN(v548, v549);
          pipe_barrier(PIPE_V);
          RoundMode v550 = RoundMode::CAST_RINT;
          SaturationMode v551 = SaturationMode::ON;
          TCVT(v548, v546, v550, v551);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
          // pto: %162
          ;
          __gm__ bfloat16_t* v552 = PTOAS__GLOBAL_TENSOR_DATA(v55);
          // pto: %162
          ;
          const int64_t v553 = 0;
          // pto: %162
          ;
          const int64_t v554 = 8192;
          // pto: %162
          ;
          pto::Shape<1, 1, 1, 1, 64> v555 = pto::Shape<1, 1, 1, 1, 64>();
          // pto: %162
          ;
          pto::Stride<8192, 8192, 8192, 8192, 1> v556 = pto::Stride<8192, 8192, 8192, 8192, 1>();
          // pto: %162
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v557 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v552 + (v553 + v372 * v554 + v408), v555, v556);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
          pipe_barrier(PIPE_MTE3);
          TSTORE(v557, v516);
          // pto: %165
          ;
          int64_t v558 = (int64_t) ((uint64_t) v389 + (uint64_t) v35);
          // pto: %166
          ;
          int64_t v559 = v558 < v44 ? v44 : v558;
          // pto: %167
          ;
          __gm__ bfloat16_t* v560 = PTOAS__GLOBAL_TENSOR_DATA(v55);
          // pto: %167
          ;
          const int64_t v561 = 0;
          // pto: %167
          ;
          const int64_t v562 = 8192;
          // pto: %167
          ;
          pto::Shape<1, 1, 1, 1, 64> v563 = pto::Shape<1, 1, 1, 1, 64>();
          // pto: %167
          ;
          pto::Stride<8192, 8192, 8192, 8192, 1> v564 = pto::Stride<8192, 8192, 8192, 8192, 1>();
          // pto: %167
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v565 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v560 + (v561 + v372 * v562 + v559), v563, v564);
          pipe_barrier(PIPE_MTE3);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
          TSTORE(v565, v548);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        };
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      };
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}