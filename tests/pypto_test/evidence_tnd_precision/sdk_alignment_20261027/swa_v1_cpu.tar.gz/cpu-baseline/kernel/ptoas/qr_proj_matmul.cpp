#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qr_proj_matmul(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ float* v3, int64_t v4, int64_t v5, int64_t v6, int64_t v7, int64_t v8, int64_t v9, int32_t v10, int32_t v11) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v12 = 0;
  // pto: %c32768_i64
  const int64_t v13 = 32768;
  // pto: %c49152_i64
  const int64_t v14 = 49152;
  // pto: %c81920_i64
  const int64_t v15 = 81920;
  // pto: %c16384_i64
  const int64_t v16 = 16384;
  // pto: %c4096_index
  const int64_t v17 = 4096;
  // pto: %c1_index
  const int64_t v18 = 1;
  // pto: %c256_index
  const int64_t v19 = 256;
  // pto: %c64_index
  const int64_t v20 = 64;
  // pto: %c16_index
  const int64_t v21 = 16;
  // pto: %c4194304_index
  const int64_t v22 = 4194304;
  // pto: %c16384_index
  const int64_t v23 = 16384;
  // pto: %c1024_index
  const int64_t v24 = 1024;
  // pto: %c32_index
  const int64_t v25 = 32;
  // pto: %c96_index
  const int64_t v26 = 96;
  // pto: %c0_index
  const int64_t v27 = 0;
  // pto: %c2_index
  const int64_t v28 = 2;
  // pto: %c9_index
  const int64_t v29 = 9;
  // pto: %c7_index
  const int64_t v30 = 7;
  // pto: %c8_index
  const int64_t v31 = 8;
  // pto: %cn1_index
  const int64_t v32 = -1;
  // pto: %x_view_inline8040__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %x_view_inline8040__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %x_view_inline8040__ssa_v0_view
  const int64_t v35 = 1;
  // pto: %x_view_inline8040__ssa_v0_view
  int64_t v36 = (int64_t) v8;
  // pto: %x_view_inline8040__ssa_v0_view
  int64_t v37 = v36 * v17;
  // pto: %x_view_inline8040__ssa_v0_view
  int64_t v38 = v35 * v37;
  // pto: %x_view_inline8040__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v39 = pto::Shape<1, 1, 1, -1, -1>(v33, v34, v35, v36, v17);
  // pto: %x_view_inline8040__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v40 = pto::Stride<-1, -1, -1, -1, -1>(v34 * v38, v38, v37, v17, v18);
  // pto: %x_view_inline8040__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v41 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v39, v40);
  // pto: %wq_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v42 = pto::Shape<-1, -1, -1, -1, -1>(v18, v19, v20, v21, v21);
  // pto: %wq_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v43 = pto::Stride<-1, -1, -1, -1, -1>(v22, v23, v19, v21, v18);
  // pto: %wq_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v44 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v2, v42, v43);
  // pto: %qr_fp32_inline0_inline4556__rv_v2_view
  const int64_t v45 = 1;
  // pto: %qr_fp32_inline0_inline4556__rv_v2_view
  const int64_t v46 = 1;
  // pto: %qr_fp32_inline0_inline4556__rv_v2_view
  const int64_t v47 = 1;
  // pto: %qr_fp32_inline0_inline4556__rv_v2_view
  int64_t v48 = (int64_t) v9;
  // pto: %qr_fp32_inline0_inline4556__rv_v2_view
  int64_t v49 = v48 * v24;
  // pto: %qr_fp32_inline0_inline4556__rv_v2_view
  int64_t v50 = v47 * v49;
  // pto: %qr_fp32_inline0_inline4556__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v51 = pto::Shape<1, 1, 1, -1, -1>(v45, v46, v47, v48, v24);
  // pto: %qr_fp32_inline0_inline4556__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v52 = pto::Stride<-1, -1, -1, -1, -1>(v46 * v50, v50, v49, v24, v18);
  // pto: %qr_fp32_inline0_inline4556__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v53 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v51, v52);
  // pto: %qbg_idx_inline8035__ssa_v0, %14
  int64_t v54 = (int64_t) ((uint64_t) ((int64_t) v10) * (uint64_t) v25);
  // pto: %15
  int64_t v55 = v54 / v26;
  // pto: %dense_acc_inline8045__tile
  Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v56 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v25);
  // pto: %dense_acc_inline8045__tile
  uint64_t v57 = (uint64_t) v12;
  TASSIGN(v56, v57);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  for (int64_t v58 = v27; v58 < v21; v58 += v28) {
    // pto: %16
    ;
    int64_t v59 = (int64_t) ((uint64_t) v58 + (uint64_t) v18);
    // pto: %17
    ;
    bool v60 = v55 < v29;
    // pto: %dense_k_order_inline8046__phi_v2
    ;
    int64_t v61;
    if (v60) {
      // pto: %18
      ;
      int64_t v62 = v58 / v28;
      // pto: %19
      ;
      int64_t v63 = v55 % v28;
      // pto: %20, %21, %22
      ;
      int64_t v64 = v63 < v27 ? (int64_t) ((uint64_t) v63 + (uint64_t) v28) : v63;
      // pto: %23
      ;
      // pto: %native_packet_inline8052__phi_v2
      ;
      int64_t v65;
      if (v64 == v18) {
        // pto: %24
        ;
        v65 = (int64_t) ((uint64_t) v30 - (uint64_t) v62);
      } else {
        v65 = v62;
      };
      // pto: %26
      ;
      uint64_t v66 = (uint64_t) v65;
      // pto: %25, %26, %27
      ;
      int64_t v67 = (int64_t) ((uint64_t) (v55 / v28) + v66) % v31;
      // pto: %28, %29, %30
      ;
      int64_t v68 = v67 < v27 ? (int64_t) ((uint64_t) v67 + (uint64_t) v31) : v67;
      // pto: %32
      ;
      int64_t v69 = v58 % v28;
      // pto: %33, %34, %35
      ;
      int64_t v70 = v69 < v27 ? (int64_t) ((uint64_t) v69 + (uint64_t) v28) : v69;
      // pto: %31, %36
      ;
      v61 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v68 * (uint64_t) v28) + (uint64_t) v70);
    } else {
      v61 = v58;
    };
    // pto: %37
    ;
    bool v71 = v61 < v27;
    // pto: %37
    ;
    int64_t v72 = v71 ? v27 : v61;
    // pto: %38
    ;
    int64_t v73 = (int64_t) ((uint64_t) v72 * (uint64_t) v19);
    // pto: %dense_x_inline8047__tile
    ;
    Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v74 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v19);
    // pto: %dense_x_inline8047__tile
    ;
    uint64_t v75 = (uint64_t) v12;
    TASSIGN(v74, v75);
    // pto: %39
    ;
    int64_t v76 = v4 < v27 ? v27 : v4;
    // pto: %40
    ;
    int64_t v77 = v73 < v27 ? v27 : v73;
    // pto: %x_view_inline8040__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v78 = PTOAS__GLOBAL_TENSOR_DATA(v41);
    // pto: %x_view_inline8040__ssa_v0_pview
    ;
    const int64_t v79 = 0;
    // pto: %x_view_inline8040__ssa_v0_pview
    ;
    const int64_t v80 = 4096;
    // pto: %x_view_inline8040__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 64, 256> v81 = pto::Shape<1, 1, 1, 64, 256>();
    // pto: %x_view_inline8040__ssa_v0_pview
    ;
    pto::Stride<262144, 262144, 262144, 4096, 1> v82 = pto::Stride<262144, 262144, 262144, 4096, 1>();
    // pto: %x_view_inline8040__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND> v83 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND>(v78 + (v79 + v76 * v80 + v77), v81, v82);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v74, v83);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    // pto: %dense_w_inline8050__tile
    ;
    Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v84 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v19);
    // pto: %dense_w_inline8050__tile
    ;
    uint64_t v85 = (uint64_t) v13;
    TASSIGN(v84, v85);
    // pto: %41
    ;
    int64_t v86 = v73 / v21;
    // pto: %42
    ;
    int64_t v87 = v86 < v27 ? v27 : v86;
    // pto: %43
    ;
    int64_t v88 = v54 / v21;
    // pto: %44
    ;
    int64_t v89 = v88 < v27 ? v27 : v88;
    // pto: %wq_a__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v90 = PTOAS__GLOBAL_TENSOR_DATA(v44);
    // pto: %wq_a__ssa_v0_pview
    ;
    const int64_t v91 = 0;
    // pto: %wq_a__ssa_v0_pview
    ;
    const int64_t v92 = 16384;
    // pto: %wq_a__ssa_v0_pview
    ;
    const int64_t v93 = 256;
    // pto: %wq_a__ssa_v0_pview
    ;
    pto::Shape<1, 16, 2, 16, 16> v94 = pto::Shape<1, 16, 2, 16, 16>();
    // pto: %wq_a__ssa_v0_pview
    ;
    pto::Stride<4194304, 16384, 256, 16, 1> v95 = pto::Stride<4194304, 16384, 256, 16, 1>();
    // pto: %wq_a__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v96 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v90 + (v91 + v87 * v92 + v89 * v93), v94, v95);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    TLOAD(v84, v96);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    // pto: %46
    ;
    int64_t v97;
    if (v60) {
      // pto: %48
      ;
      int64_t v98 = v59 / v28;
      // pto: %49
      ;
      int64_t v99 = v55 % v28;
      // pto: %50, %51, %52
      ;
      int64_t v100 = v99 < v27 ? (int64_t) ((uint64_t) v99 + (uint64_t) v28) : v99;
      // pto: %53
      ;
      // pto: %54
      ;
      int64_t v101;
      if (v100 == v18) {
        // pto: %55
        ;
        v101 = (int64_t) ((uint64_t) v30 - (uint64_t) v98);
      } else {
        v101 = v98;
      };
      // pto: %57
      ;
      uint64_t v102 = (uint64_t) v101;
      // pto: %56, %57, %58
      ;
      int64_t v103 = (int64_t) ((uint64_t) (v55 / v28) + v102) % v31;
      // pto: %59, %60, %61
      ;
      int64_t v104 = v103 < v27 ? (int64_t) ((uint64_t) v103 + (uint64_t) v31) : v103;
      // pto: %64
      ;
      int64_t v105 = v59 % v28;
      // pto: %65, %66, %67
      ;
      int64_t v106 = v105 < v27 ? (int64_t) ((uint64_t) v105 + (uint64_t) v28) : v105;
      // pto: %62, %68
      ;
      v97 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v104 * (uint64_t) v28) + (uint64_t) v106);
    } else {
      v97 = v59;
    };
    // pto: %69
    ;
    bool v107 = v97 < v27;
    // pto: %69
    ;
    int64_t v108 = v107 ? v27 : v97;
    // pto: %70
    ;
    int64_t v109 = (int64_t) ((uint64_t) v108 * (uint64_t) v19);
    // pto: %0
    ;
    Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v19);
    // pto: %0
    ;
    uint64_t v111 = (uint64_t) v14;
    TASSIGN(v110, v111);
    // pto: %72
    ;
    int64_t v112 = v109 < v27 ? v27 : v109;
    // pto: %73
    ;
    __gm__ bfloat16_t* v113 = PTOAS__GLOBAL_TENSOR_DATA(v41);
    // pto: %73
    ;
    const int64_t v114 = 0;
    // pto: %73
    ;
    const int64_t v115 = 4096;
    // pto: %73
    ;
    pto::Shape<1, 1, 1, 64, 256> v116 = pto::Shape<1, 1, 1, 64, 256>();
    // pto: %73
    ;
    pto::Stride<262144, 262144, 262144, 4096, 1> v117 = pto::Stride<262144, 262144, 262144, 4096, 1>();
    // pto: %73
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND> v118 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND>(v113 + (v114 + v76 * v115 + v112), v116, v117);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    TLOAD(v110, v118);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    // pto: %1
    ;
    Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v119 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v19);
    // pto: %1
    ;
    uint64_t v120 = (uint64_t) v15;
    TASSIGN(v119, v120);
    // pto: %74
    ;
    int64_t v121 = v109 / v21;
    // pto: %75
    ;
    int64_t v122 = v121 < v27 ? v27 : v121;
    // pto: %78
    ;
    __gm__ bfloat16_t* v123 = PTOAS__GLOBAL_TENSOR_DATA(v44);
    // pto: %78
    ;
    const int64_t v124 = 0;
    // pto: %78
    ;
    const int64_t v125 = 16384;
    // pto: %78
    ;
    const int64_t v126 = 256;
    // pto: %78
    ;
    pto::Shape<1, 16, 2, 16, 16> v127 = pto::Shape<1, 16, 2, 16, 16>();
    // pto: %78
    ;
    pto::Stride<4194304, 16384, 256, 16, 1> v128 = pto::Stride<4194304, 16384, 256, 16, 1>();
    // pto: %78
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v129 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v123 + (v124 + v122 * v125 + v89 * v126), v127, v128);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    TLOAD(v119, v129);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    // pto: %dense_w_inline8050__tile_t
    ;
    Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v25);
    // pto: %dense_w_inline8050__tile_t
    ;
    uint64_t v131 = (uint64_t) v13;
    TASSIGN(v130, v131);
    // pto: %dense_x_inline8047__tile_Left
    ;
    Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v132 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v19);
    // pto: %dense_x_inline8047__tile_Left
    ;
    uint64_t v133 = (uint64_t) v13;
    TASSIGN(v132, v133);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    TMOV(v132, v74);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    // pto: %dense_w_inline8050__tile_t_Right
    ;
    Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v134 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v25);
    // pto: %dense_w_inline8050__tile_t_Right
    ;
    uint64_t v135 = (uint64_t) v16;
    TASSIGN(v134, v135);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    TMOV(v134, v130);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    // pto: %79
    ;
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    if (v58 == v27) {
      pipe_barrier(PIPE_M);
      TMATMUL(v56, v132, v134);
    } else {
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v56, v56, v132, v134);
    };
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    // pto: %3
    ;
    Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v136 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v25);
    // pto: %3
    ;
    uint64_t v137 = (uint64_t) v15;
    TASSIGN(v136, v137);
    // pto: %4
    ;
    Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v138 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v19);
    // pto: %4
    ;
    uint64_t v139 = (uint64_t) v12;
    TASSIGN(v138, v139);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    TMOV(v138, v110);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    // pto: %5
    ;
    Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v140 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v25);
    // pto: %5
    ;
    uint64_t v141 = (uint64_t) v12;
    TASSIGN(v140, v141);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    TMOV(v140, v136);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
    // pto: %80
    ;
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
    if (v58 == v32) {
      pipe_barrier(PIPE_M);
      TMATMUL(v56, v138, v140);
    } else {
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v56, v56, v138, v140);
    };
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  // pto: %81
  int64_t v142 = v54 < v27 ? v27 : v54;
  // pto: %qr_fp32_inline0_inline4556__rv_v2_pview
  __gm__ float* v143 = PTOAS__GLOBAL_TENSOR_DATA(v53);
  // pto: %qr_fp32_inline0_inline4556__rv_v2_pview
  const int64_t v144 = 0;
  // pto: %qr_fp32_inline0_inline4556__rv_v2_pview
  pto::Shape<1, 1, 1, 64, 32> v145 = pto::Shape<1, 1, 1, 64, 32>();
  // pto: %qr_fp32_inline0_inline4556__rv_v2_pview
  pto::Stride<65536, 65536, 65536, 1024, 1> v146 = pto::Stride<65536, 65536, 65536, 1024, 1>();
  // pto: %qr_fp32_inline0_inline4556__rv_v2_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 64, 32>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND> v147 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 32>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND>(v143 + (v144 + v142), v145, v146);
  wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  TSTORE(v147, v56);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  for (int64_t v148 = v5; v148 < v6; v148 += v21) {
    // pto: %q_acc_inline8057__tile
    ;
    Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v149 = Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v21, v25);
    // pto: %q_acc_inline8057__tile
    ;
    uint64_t v150 = (uint64_t) v12;
    TASSIGN(v149, v150);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    for (int64_t v151 = v27; v151 < v21; v151 += v28) {
      // pto: %82
      ;
      int64_t v152 = (int64_t) ((uint64_t) v7 - (uint64_t) v148);
      // pto: %83
      ;
      int64_t v153 = v152 < v21 ? v152 : v21;
      // pto: %84
      ;
      int64_t v154 = (int64_t) ((uint64_t) v4 + (uint64_t) v148);
      // pto: %85
      ;
      int64_t v155 = (int64_t) ((uint64_t) v151 + (uint64_t) v18);
      // pto: %89
      ;
      bool v156 = v55 < v29;
      // pto: %qr_k_order_inline8054__phi_v2
      ;
      int64_t v157;
      if (v156) {
        // pto: %90
        ;
        int64_t v158 = v151 / v28;
        // pto: %91
        ;
        int64_t v159 = v55 % v28;
        // pto: %92, %93, %94
        ;
        int64_t v160 = v159 < v27 ? (int64_t) ((uint64_t) v159 + (uint64_t) v28) : v159;
        // pto: %95
        ;
        // pto: %native_packet_v1_inline8042__phi_v2
        ;
        int64_t v161;
        if (v160 == v18) {
          // pto: %96
          ;
          v161 = (int64_t) ((uint64_t) v30 - (uint64_t) v158);
        } else {
          v161 = v158;
        };
        // pto: %98
        ;
        uint64_t v162 = (uint64_t) v161;
        // pto: %97, %98, %99
        ;
        int64_t v163 = (int64_t) ((uint64_t) (v55 / v28) + v162) % v31;
        // pto: %100, %101, %102
        ;
        int64_t v164 = v163 < v27 ? (int64_t) ((uint64_t) v163 + (uint64_t) v31) : v163;
        // pto: %104
        ;
        int64_t v165 = v151 % v28;
        // pto: %105, %106, %107
        ;
        int64_t v166 = v165 < v27 ? (int64_t) ((uint64_t) v165 + (uint64_t) v28) : v165;
        // pto: %103, %108
        ;
        v157 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v164 * (uint64_t) v28) + (uint64_t) v166);
      } else {
        v157 = v151;
      };
      // pto: %109
      ;
      bool v167 = v157 < v27;
      // pto: %109
      ;
      int64_t v168 = v167 ? v27 : v157;
      // pto: %110
      ;
      int64_t v169 = (int64_t) ((uint64_t) v168 * (uint64_t) v19);
      // pto: %q_x_chunk_bf16_inline8048__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v170 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v153, v19);
      // pto: %q_x_chunk_bf16_inline8048__tile
      ;
      uint64_t v171 = (uint64_t) v13;
      TASSIGN(v170, v171);
      // pto: %111
      ;
      int64_t v172 = v154 < v27 ? v27 : v154;
      // pto: %112
      ;
      int64_t v173 = v169 < v27 ? v27 : v169;
      // pto: %113
      ;
      const int64_t v174 = 0;
      // pto: %113
      ;
      __gm__ bfloat16_t* v175 = PTOAS__GLOBAL_TENSOR_DATA(v41);
      // pto: %113
      ;
      const int64_t v176 = 1;
      // pto: %113
      ;
      const int64_t v177 = 1;
      // pto: %113
      ;
      const int64_t v178 = 1;
      // pto: %113
      ;
      int64_t v179 = v153 * v17;
      // pto: %113
      ;
      int64_t v180 = v178 * v179;
      // pto: %113
      ;
      pto::Shape<1, 1, 1, -1, 256> v181 = pto::Shape<1, 1, 1, -1, 256>(v176, v177, v178, v153, v19);
      // pto: %113
      ;
      pto::Stride<-1, -1, -1, -1, -1> v182 = pto::Stride<-1, -1, -1, -1, -1>(v177 * v180, v180, v179, v17, v18);
      // pto: %113
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v183 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v175 + (v174 + v172 * v17 + v173 * v18), v181, v182);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      TLOAD(v170, v183);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      // pto: %w_chunk_inline8029__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v184 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v19);
      // pto: %w_chunk_inline8029__tile
      ;
      uint64_t v185 = (uint64_t) v12;
      TASSIGN(v184, v185);
      // pto: %114
      ;
      int64_t v186 = v169 / v21;
      // pto: %115
      ;
      int64_t v187 = v186 < v27 ? v27 : v186;
      // pto: %116
      ;
      int64_t v188 = v54 / v21;
      // pto: %117
      ;
      int64_t v189 = v188 < v27 ? v27 : v188;
      // pto: %118
      ;
      __gm__ bfloat16_t* v190 = PTOAS__GLOBAL_TENSOR_DATA(v44);
      // pto: %118
      ;
      const int64_t v191 = 0;
      // pto: %118
      ;
      const int64_t v192 = 16384;
      // pto: %118
      ;
      const int64_t v193 = 256;
      // pto: %118
      ;
      pto::Shape<1, 16, 2, 16, 16> v194 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %118
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v195 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %118
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v196 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v190 + (v191 + v187 * v192 + v189 * v193), v194, v195);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      TLOAD(v184, v196);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      // pto: %120
      ;
      int64_t v197;
      if (v156) {
        // pto: %122
        ;
        int64_t v198 = v155 / v28;
        // pto: %123
        ;
        int64_t v199 = v55 % v28;
        // pto: %124, %125, %126
        ;
        int64_t v200 = v199 < v27 ? (int64_t) ((uint64_t) v199 + (uint64_t) v28) : v199;
        // pto: %127
        ;
        // pto: %128
        ;
        int64_t v201;
        if (v200 == v18) {
          // pto: %129
          ;
          v201 = (int64_t) ((uint64_t) v30 - (uint64_t) v198);
        } else {
          v201 = v198;
        };
        // pto: %131
        ;
        uint64_t v202 = (uint64_t) v201;
        // pto: %130, %131, %132
        ;
        int64_t v203 = (int64_t) ((uint64_t) (v55 / v28) + v202) % v31;
        // pto: %133, %134, %135
        ;
        int64_t v204 = v203 < v27 ? (int64_t) ((uint64_t) v203 + (uint64_t) v31) : v203;
        // pto: %138
        ;
        int64_t v205 = v155 % v28;
        // pto: %139, %140, %141
        ;
        int64_t v206 = v205 < v27 ? (int64_t) ((uint64_t) v205 + (uint64_t) v28) : v205;
        // pto: %136, %142
        ;
        v197 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v204 * (uint64_t) v28) + (uint64_t) v206);
      } else {
        v197 = v155;
      };
      // pto: %143
      ;
      bool v207 = v197 < v27;
      // pto: %143
      ;
      int64_t v208 = v207 ? v27 : v197;
      // pto: %144
      ;
      int64_t v209 = (int64_t) ((uint64_t) v208 * (uint64_t) v19);
      // pto: %7
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v210 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v153, v19);
      // pto: %7
      ;
      uint64_t v211 = (uint64_t) v15;
      TASSIGN(v210, v211);
      // pto: %146
      ;
      int64_t v212 = v209 < v27 ? v27 : v209;
      // pto: %147
      ;
      const int64_t v213 = 0;
      // pto: %147
      ;
      __gm__ bfloat16_t* v214 = PTOAS__GLOBAL_TENSOR_DATA(v41);
      // pto: %147
      ;
      const int64_t v215 = 1;
      // pto: %147
      ;
      const int64_t v216 = 1;
      // pto: %147
      ;
      const int64_t v217 = 1;
      // pto: %147
      ;
      int64_t v218 = v153 * v17;
      // pto: %147
      ;
      int64_t v219 = v217 * v218;
      // pto: %147
      ;
      pto::Shape<1, 1, 1, -1, 256> v220 = pto::Shape<1, 1, 1, -1, 256>(v215, v216, v217, v153, v19);
      // pto: %147
      ;
      pto::Stride<-1, -1, -1, -1, -1> v221 = pto::Stride<-1, -1, -1, -1, -1>(v216 * v219, v219, v218, v17, v18);
      // pto: %147
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v222 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v214 + (v213 + v172 * v17 + v212 * v18), v220, v221);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      TLOAD(v210, v222);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
      // pto: %8
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v223 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v19);
      // pto: %8
      ;
      uint64_t v224 = (uint64_t) v14;
      TASSIGN(v223, v224);
      // pto: %148
      ;
      int64_t v225 = v209 / v21;
      // pto: %149
      ;
      int64_t v226 = v225 < v27 ? v27 : v225;
      // pto: %152
      ;
      __gm__ bfloat16_t* v227 = PTOAS__GLOBAL_TENSOR_DATA(v44);
      // pto: %152
      ;
      const int64_t v228 = 0;
      // pto: %152
      ;
      const int64_t v229 = 16384;
      // pto: %152
      ;
      const int64_t v230 = 256;
      // pto: %152
      ;
      pto::Shape<1, 16, 2, 16, 16> v231 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %152
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v232 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %152
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v233 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v227 + (v228 + v226 * v229 + v189 * v230), v231, v232);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v223, v233);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
      // pto: %w_chunk_inline8029__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v234 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v25);
      // pto: %w_chunk_inline8029__tile_t
      ;
      uint64_t v235 = (uint64_t) v12;
      TASSIGN(v234, v235);
      // pto: %q_x_chunk_bf16_inline8048__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v236 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v153, v19);
      // pto: %q_x_chunk_bf16_inline8048__tile_Left
      ;
      uint64_t v237 = (uint64_t) v13;
      TASSIGN(v236, v237);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      TMOV(v236, v170);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      // pto: %w_chunk_inline8029__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v238 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v25);
      // pto: %w_chunk_inline8029__tile_t_Right
      ;
      uint64_t v239 = (uint64_t) v16;
      TASSIGN(v238, v239);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      TMOV(v238, v234);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      // pto: %153
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      if (v151 == v27) {
        pipe_barrier(PIPE_M);
        TMATMUL(v149, v236, v238);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v149, v149, v236, v238);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      // pto: %10
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v240 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v25);
      // pto: %10
      ;
      uint64_t v241 = (uint64_t) v14;
      TASSIGN(v240, v241);
      // pto: %11
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v242 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v153, v19);
      // pto: %11
      ;
      uint64_t v243 = (uint64_t) v12;
      TASSIGN(v242, v243);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      TMOV(v242, v210);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      // pto: %12
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v244 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v25);
      // pto: %12
      ;
      uint64_t v245 = (uint64_t) v12;
      TASSIGN(v244, v245);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
      TMOV(v244, v240);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %154
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      if (v151 == v32) {
        pipe_barrier(PIPE_M);
        TMATMUL(v149, v242, v244);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v149, v149, v242, v244);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    };
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
    // pto: %156
    ;
    int64_t v246 = v148 < v27 ? v27 : v148;
    // pto: %qr_fp32_inline0_inline4556__iter_v9_pview
    ;
    __gm__ float* v247 = PTOAS__GLOBAL_TENSOR_DATA(v53);
    // pto: %qr_fp32_inline0_inline4556__iter_v9_pview
    ;
    const int64_t v248 = 0;
    // pto: %qr_fp32_inline0_inline4556__iter_v9_pview
    ;
    const int64_t v249 = 1024;
    // pto: %qr_fp32_inline0_inline4556__iter_v9_pview
    ;
    pto::Shape<1, 1, 1, 16, 32> v250 = pto::Shape<1, 1, 1, 16, 32>();
    // pto: %qr_fp32_inline0_inline4556__iter_v9_pview
    ;
    pto::Stride<16384, 16384, 16384, 1024, 1> v251 = pto::Stride<16384, 16384, 16384, 1024, 1>();
    // pto: %qr_fp32_inline0_inline4556__iter_v9_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND> v252 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND>(v247 + (v248 + v246 * v249 + v142), v250, v251);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
    pipe_barrier(PIPE_FIX);
    TSTORE(v252, v149);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  }
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}