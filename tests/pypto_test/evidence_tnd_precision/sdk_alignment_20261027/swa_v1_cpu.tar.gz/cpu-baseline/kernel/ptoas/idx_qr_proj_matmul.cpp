#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void idx_qr_proj_matmul(__gm__ int32_t* v1, __gm__ int8_t* v2, __gm__ int8_t* v3, int64_t v4, int64_t v5, int64_t v6, int32_t v7, int32_t v8) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v9 = 0;
  // pto: %c262144_i64
  const int64_t v10 = 262144;
  // pto: %c8192_i64
  const int64_t v11 = 8192;
  // pto: %c32768_i64
  const int64_t v12 = 32768;
  // pto: %c448_index
  const int64_t v13 = 448;
  // pto: %c8192_index
  const int64_t v14 = 8192;
  // pto: %c1_index
  const int64_t v15 = 1;
  // pto: %c1024_index
  const int64_t v16 = 1024;
  // pto: %c32_index
  const int64_t v17 = 32;
  // pto: %c24_index
  const int64_t v18 = 24;
  // pto: %c256_index
  const int64_t v19 = 256;
  // pto: %c0_index
  const int64_t v20 = 0;
  // pto: %c64_index
  const int64_t v21 = 64;
  // pto: %c128_index
  const int64_t v22 = 128;
  // pto: %cn128_index
  const int64_t v23 = -128;
  // pto: %qr_acc_pad_inline1727_inline5012__ssa_v0_view
  const int64_t v24 = 1;
  // pto: %qr_acc_pad_inline1727_inline5012__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %qr_acc_pad_inline1727_inline5012__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %qr_acc_pad_inline1727_inline5012__ssa_v0_view
  int64_t v27 = v13 * v14;
  // pto: %qr_acc_pad_inline1727_inline5012__ssa_v0_view
  int64_t v28 = v26 * v27;
  // pto: %qr_acc_pad_inline1727_inline5012__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v29 = pto::Shape<1, 1, 1, -1, -1>(v24, v25, v26, v13, v14);
  // pto: %qr_acc_pad_inline1727_inline5012__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v30 = pto::Stride<-1, -1, -1, -1, -1>(v25 * v28, v28, v27, v14, v15);
  // pto: %qr_acc_pad_inline1727_inline5012__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v31 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v29, v30);
  // pto: %idx_wq_b__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %idx_wq_b__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %idx_wq_b__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %idx_wq_b__ssa_v0_view
  int64_t v35 = v16 * v14;
  // pto: %idx_wq_b__ssa_v0_view
  int64_t v36 = v34 * v35;
  // pto: %idx_wq_b__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v37 = pto::Shape<1, 1, 1, -1, -1>(v32, v33, v34, v16, v14);
  // pto: %idx_wq_b__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v38 = pto::Stride<-1, -1, -1, -1, -1>(v33 * v36, v36, v35, v14, v15);
  // pto: %idx_wq_b__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v39 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v37, v38);
  // pto: %qr__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %qr__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %qr__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %qr__ssa_v0_view
  int64_t v43 = (int64_t) v6;
  // pto: %qr__ssa_v0_view
  int64_t v44 = v43 * v16;
  // pto: %qr__ssa_v0_view
  int64_t v45 = v42 * v44;
  // pto: %qr__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v46 = pto::Shape<1, 1, 1, -1, -1>(v40, v41, v42, v43, v16);
  // pto: %qr__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v47 = pto::Stride<-1, -1, -1, -1, -1>(v41 * v45, v45, v44, v16, v15);
  // pto: %qr__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v48 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v46, v47);
  // pto: %qr_proj_worker_inline1740_inline4992__ssa_v0
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  for (int64_t v49 = (int64_t) v7; v49 < v17; v49 += v18) {
    // pto: %3
    ;
    int64_t v50 = (int64_t) ((uint64_t) v49 * (uint64_t) v19);
    // pto: %wq_tile_inline1722_inline4995__tile
    ;
    Tile<TileType::Mat, int8_t, 1024, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v51 = Tile<TileType::Mat, int8_t, 1024, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v19);
    // pto: %wq_tile_inline1722_inline4995__tile
    ;
    uint64_t v52 = (uint64_t) v9;
    TASSIGN(v51, v52);
    // pto: %4
    ;
    int64_t v53 = v50 < v20 ? v20 : v50;
    // pto: %idx_wq_b__ssa_v0_pview
    ;
    __gm__ int8_t* v54 = PTOAS__GLOBAL_TENSOR_DATA(v39);
    // pto: %idx_wq_b__ssa_v0_pview
    ;
    const int64_t v55 = 0;
    // pto: %idx_wq_b__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1024, 256> v56 = pto::Shape<1, 1, 1, 1024, 256>();
    // pto: %idx_wq_b__ssa_v0_pview
    ;
    pto::Stride<8388608, 8388608, 8388608, 8192, 1> v57 = pto::Stride<8388608, 8388608, 8388608, 8192, 1>();
    // pto: %idx_wq_b__ssa_v0_pview
    ;
    GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1024, 256>, pto::Stride<8388608, 8388608, 8388608, 8192, 1>, pto::Layout::ND> v58 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1024, 256>, pto::Stride<8388608, 8388608, 8388608, 8192, 1>, pto::Layout::ND>(v54 + (v55 + v53), v56, v57);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v51, v58);
    for (int64_t v59 = v20; v59 < v4; v59 += v15) {
      // pto: %5
      ;
      int64_t v60 = (int64_t) ((uint64_t) v59 * (uint64_t) v21);
      // pto: %6
      ;
      int64_t v61 = (int64_t) ((uint64_t) v5 - (uint64_t) v60);
      // pto: %7
      ;
      int64_t v62 = v61 < v21 ? v61 : v21;
      // pto: %qr_tile_inline1750_inline5009__tile
      ;
      Tile<TileType::Mat, int8_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v63 = Tile<TileType::Mat, int8_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v62, v16);
      // pto: %qr_tile_inline1750_inline5009__tile
      ;
      uint64_t v64 = (uint64_t) v10;
      TASSIGN(v63, v64);
      // pto: %8
      ;
      int64_t v65 = v60 < v20 ? v20 : v60;
      // pto: %qr__ssa_v0_pview
      ;
      const int64_t v66 = 0;
      // pto: %qr__ssa_v0_pview
      ;
      __gm__ int8_t* v67 = PTOAS__GLOBAL_TENSOR_DATA(v48);
      // pto: %qr__ssa_v0_pview
      ;
      const int64_t v68 = 1;
      // pto: %qr__ssa_v0_pview
      ;
      const int64_t v69 = 1;
      // pto: %qr__ssa_v0_pview
      ;
      const int64_t v70 = 1;
      // pto: %qr__ssa_v0_pview
      ;
      int64_t v71 = v62 * v16;
      // pto: %qr__ssa_v0_pview
      ;
      int64_t v72 = v70 * v71;
      // pto: %qr__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 1024> v73 = pto::Shape<1, 1, 1, -1, 1024>(v68, v69, v70, v62, v16);
      // pto: %qr__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v74 = pto::Stride<-1, -1, -1, -1, -1>(v69 * v72, v72, v71, v16, v15);
      // pto: %qr__ssa_v0_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v75 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v67 + (v66 + v65 * v16 + v20 * v15), v73, v74);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v63, v75);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %qr_acc_inline1762_inline4993__tile_l0_init_storage
      ;
      Tile<TileType::Acc, int32_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v76 = Tile<TileType::Acc, int32_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v21, v19);
      // pto: %qr_acc_inline1762_inline4993__tile_l0_init_storage
      ;
      uint64_t v77 = (uint64_t) v9;
      TASSIGN(v76, v77);
      v76.SetValidShape(v62, v19);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
      for (int64_t v78 = v20; v78 < v16; v78 += v19) {
        // pto: %qr_acc_inline1762_inline4993__tile_l0_a
        ;
        Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v79 = Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v62, v22);
        // pto: %qr_acc_inline1762_inline4993__tile_l0_a
        ;
        uint64_t v80 = (uint64_t) v9;
        TASSIGN(v79, v80);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        pipe_barrier(PIPE_MTE1);
        uint16_t v81 = static_cast<uint16_t>(v20);
        uint16_t v82 = static_cast<uint16_t>(v78);
        TEXTRACT(v79, v63, v81, v82);
        // pto: %qr_acc_inline1762_inline4993__tile_l0_b
        ;
        Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v83 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v22, v19);
        // pto: %qr_acc_inline1762_inline4993__tile_l0_b
        ;
        uint64_t v84 = (uint64_t) v9;
        TASSIGN(v83, v84);
        uint16_t v85 = static_cast<uint16_t>(v78);
        uint16_t v86 = static_cast<uint16_t>(v20);
        TEXTRACT(v83, v51, v85, v86);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %0
        ;
        Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v87 = Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v62, v22);
        // pto: %0
        ;
        uint64_t v88 = (uint64_t) v11;
        TASSIGN(v87, v88);
        // pto: %9
        ;
        int64_t v89 = (int64_t) ((uint64_t) v78 + (uint64_t) v22);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v90 = static_cast<uint16_t>(v20);
        uint16_t v91 = static_cast<uint16_t>(v89);
        TEXTRACT(v87, v63, v90, v91);
        // pto: %1
        ;
        Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v92 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v22, v19);
        // pto: %1
        ;
        uint64_t v93 = (uint64_t) v12;
        TASSIGN(v92, v93);
        uint16_t v94 = static_cast<uint16_t>(v89);
        uint16_t v95 = static_cast<uint16_t>(v20);
        TEXTRACT(v92, v51, v94, v95);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %11
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        if (v78 == v20) {
          pipe_barrier(PIPE_M);
          TMATMUL(v76, v79, v83);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v76, v76, v79, v83);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        // pto: %12
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        if (v78 == v23) {
          pipe_barrier(PIPE_M);
          TMATMUL(v76, v87, v92);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v76, v76, v87, v92);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      };
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %qr_acc_pad_inline1727_inline5012__iter_v3_pview
      ;
      const int64_t v96 = 0;
      // pto: %qr_acc_pad_inline1727_inline5012__iter_v3_pview
      ;
      __gm__ int32_t* v97 = PTOAS__GLOBAL_TENSOR_DATA(v31);
      // pto: %qr_acc_pad_inline1727_inline5012__iter_v3_pview
      ;
      const int64_t v98 = 1;
      // pto: %qr_acc_pad_inline1727_inline5012__iter_v3_pview
      ;
      const int64_t v99 = 1;
      // pto: %qr_acc_pad_inline1727_inline5012__iter_v3_pview
      ;
      const int64_t v100 = 1;
      // pto: %qr_acc_pad_inline1727_inline5012__iter_v3_pview
      ;
      int64_t v101 = v62 * v14;
      // pto: %qr_acc_pad_inline1727_inline5012__iter_v3_pview
      ;
      int64_t v102 = v100 * v101;
      // pto: %qr_acc_pad_inline1727_inline5012__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, -1, 256> v103 = pto::Shape<1, 1, 1, -1, 256>(v98, v99, v100, v62, v19);
      // pto: %qr_acc_pad_inline1727_inline5012__iter_v3_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v104 = pto::Stride<-1, -1, -1, -1, -1>(v99 * v102, v102, v101, v14, v15);
      // pto: %qr_acc_pad_inline1727_inline5012__iter_v3_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v105 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v97 + (v96 + v65 * v14 + v53 * v15), v103, v104);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      pipe_barrier(PIPE_FIX);
      TSTORE(v105, v76);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    };
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}