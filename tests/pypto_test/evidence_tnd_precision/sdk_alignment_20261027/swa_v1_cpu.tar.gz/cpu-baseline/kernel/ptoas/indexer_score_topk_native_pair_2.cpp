#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void indexer_score_topk_native_pair_2_aic(__gm__ int32_t* v1, __gm__ int32_t* v2, __gm__ int64_t* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, __gm__ int64_t* v7, __gm__ int8_t* v8, __gm__ half* v9, __gm__ int32_t* v10, __gm__ int8_t* v11, __gm__ int8_t* v12, __gm__ float* v13, __gm__ int8_t* v14, __gm__ float* v15, __gm__ float* v16, int64_t v17, int64_t v18, int64_t v19, int64_t v20, int64_t v21, int64_t v22, int64_t v23, int64_t v24, int32_t v25, int32_t v26) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int64_t v27 = 352;
  const int64_t v28 = 320;
  const int64_t v29 = 288;
  const int64_t v30 = 35840;
  const int64_t v31 = 224;
  const int64_t v32 = 34816;
  const int64_t v33 = 192;
  const int64_t v34 = 33792;
  const int64_t v35 = 160;
  const int64_t v36 = 3072;
  const int64_t v37 = 2048;
  const int64_t v38 = 1024;
  // pto: %c0_i64
  const int64_t v39 = 0;
  // pto: %c32768_i64
  const int64_t v40 = 32768;
  // pto: %c16384_i64
  const int64_t v41 = 16384;
  // pto: %c65536_i64
  const int64_t v42 = 65536;
  // pto: %c1_index
  const int64_t v43 = 1;
  // pto: %c27648_index
  const int64_t v44 = 27648;
  const int64_t v45 = 128;
  // pto: %c3456_index
  const int64_t v46 = 3456;
  // pto: %c96_index
  const int64_t v47 = 96;
  // pto: %c768_index
  const int64_t v48 = 768;
  // pto: %c8192_index
  const int64_t v49 = 8192;
  const int64_t v50 = 0;
  // pto: %c4_index
  const int64_t v51 = 4;
  // pto: %c262144_index
  const int64_t v52 = 262144;
  // pto: %c8191_index
  const int64_t v53 = 8191;
  // pto: %c24_index
  const int64_t v54 = 24;
  // pto: %c1_i64
  const int64_t v55 = 1;
  // pto: %c4_i64
  const int64_t v56 = 4;
  // pto: %c767_index
  const int64_t v57 = 767;
  const int64_t v58 = 384;
  // pto: %c4096_index
  const int64_t v59 = 4096;
  // pto: %c383_index
  const int64_t v60 = 383;
  // pto: %c64_index
  const int64_t v61 = 64;
  // pto: %c16_index
  const int64_t v62 = 16;
  // pto: %c2_index
  const int64_t v63 = 2;
  // pto: %c32_index
  const int64_t v64 = 32;
  // pto: %c981467136_i64
  const int64_t v65 = 981467136;
  const int64_t v66 = 256;
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  const int64_t v67 = 1;
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  const int64_t v68 = 1;
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  const int64_t v69 = 1;
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  int64_t v70 = v44 * v45;
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  int64_t v71 = v69 * v70;
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v72 = pto::Shape<1, 1, 1, -1, -1>(v67, v68, v69, v44, v45);
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v73 = pto::Stride<-1, -1, -1, -1, -1>(v68 * v71, v71, v70, v45, v43);
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v74 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v72, v73);
  // pto: %coefficients_inline9338__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %coefficients_inline9338__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %coefficients_inline9338__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %coefficients_inline9338__ssa_v0_view
  int64_t v78 = v46 * v45;
  // pto: %coefficients_inline9338__ssa_v0_view
  int64_t v79 = v77 * v78;
  // pto: %coefficients_inline9338__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v80 = pto::Shape<1, 1, 1, -1, -1>(v75, v76, v77, v46, v45);
  // pto: %coefficients_inline9338__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v81 = pto::Stride<-1, -1, -1, -1, -1>(v76 * v79, v79, v78, v45, v43);
  // pto: %coefficients_inline9338__ssa_v0_view
  GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v82 = GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v80, v81);
  // pto: %idx_kv_cache_inline9340__ssa_v0_view
  const int64_t v83 = 1;
  // pto: %idx_kv_cache_inline9340__ssa_v0_view
  const int64_t v84 = 1;
  // pto: %idx_kv_cache_inline9340__ssa_v0_view
  const int64_t v85 = 1;
  // pto: %idx_kv_cache_inline9340__ssa_v0_view
  int64_t v86 = (int64_t) v21;
  // pto: %idx_kv_cache_inline9340__ssa_v0_view
  int64_t v87 = v86 * v45;
  // pto: %idx_kv_cache_inline9340__ssa_v0_view
  int64_t v88 = v85 * v87;
  // pto: %idx_kv_cache_inline9340__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v89 = pto::Shape<1, 1, 1, -1, -1>(v83, v84, v85, v86, v45);
  // pto: %idx_kv_cache_inline9340__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v90 = pto::Stride<-1, -1, -1, -1, -1>(v84 * v88, v88, v87, v45, v43);
  // pto: %idx_kv_cache_inline9340__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v91 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v11, v89, v90);
  // pto: %idx_kv_cache_shift64_inline9347__ssa_v0_view
  const int64_t v92 = 1;
  // pto: %idx_kv_cache_shift64_inline9347__ssa_v0_view
  const int64_t v93 = 1;
  // pto: %idx_kv_cache_shift64_inline9347__ssa_v0_view
  const int64_t v94 = 1;
  // pto: %idx_kv_cache_shift64_inline9347__ssa_v0_view
  int64_t v95 = (int64_t) v22;
  // pto: %idx_kv_cache_shift64_inline9347__ssa_v0_view
  int64_t v96 = v95 * v45;
  // pto: %idx_kv_cache_shift64_inline9347__ssa_v0_view
  int64_t v97 = v94 * v96;
  // pto: %idx_kv_cache_shift64_inline9347__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v98 = pto::Shape<1, 1, 1, -1, -1>(v92, v93, v94, v95, v45);
  // pto: %idx_kv_cache_shift64_inline9347__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v99 = pto::Stride<-1, -1, -1, -1, -1>(v93 * v97, v97, v96, v45, v43);
  // pto: %idx_kv_cache_shift64_inline9347__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v100 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v12, v98, v99);
  // pto: %buf_score_transfer_inline9298__ssa_v0_view
  const int64_t v101 = 1;
  // pto: %buf_score_transfer_inline9298__ssa_v0_view
  const int64_t v102 = 1;
  // pto: %buf_score_transfer_inline9298__ssa_v0_view
  const int64_t v103 = 1;
  // pto: %buf_score_transfer_inline9298__ssa_v0_view
  int64_t v104 = v47 * v48;
  // pto: %buf_score_transfer_inline9298__ssa_v0_view
  int64_t v105 = v103 * v104;
  // pto: %buf_score_transfer_inline9298__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v106 = pto::Shape<1, 1, 1, -1, -1>(v101, v102, v103, v47, v48);
  // pto: %buf_score_transfer_inline9298__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v107 = pto::Stride<-1, -1, -1, -1, -1>(v102 * v105, v105, v104, v48, v43);
  // pto: %buf_score_transfer_inline9298__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v108 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v106, v107);
  // pto: %buf_panel_keys_inline9242__phi_v5
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v109 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v5
  uint64_t v110 = (uint64_t) v39;
  TASSIGN(v109, v110);
  // pto: %buf_panel_keys_inline9242__phi_v10
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v10
  uint64_t v112 = (uint64_t) v39;
  TASSIGN(v111, v112);
  // pto: %buf_panel_keys_inline9242__phi_v15
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v15
  uint64_t v114 = (uint64_t) v39;
  TASSIGN(v113, v114);
  // pto: %buf_panel_keys_inline9242__phi_v20
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v115 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v20
  uint64_t v116 = (uint64_t) v39;
  TASSIGN(v115, v116);
  // pto: %buf_panel_keys_inline9242__phi_v26
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v26
  uint64_t v118 = (uint64_t) v40;
  TASSIGN(v117, v118);
  // pto: %buf_panel_keys_inline9242__phi_v31
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v119 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v31
  uint64_t v120 = (uint64_t) v40;
  TASSIGN(v119, v120);
  // pto: %buf_panel_keys_inline9242__phi_v36
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v36
  uint64_t v122 = (uint64_t) v40;
  TASSIGN(v121, v122);
  // pto: %buf_panel_keys_inline9242__phi_v41
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v123 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v41
  uint64_t v124 = (uint64_t) v40;
  TASSIGN(v123, v124);
  // pto: %buf_panel_keys_inline9242__phi_v47
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v125 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v47
  uint64_t v126 = (uint64_t) v39;
  TASSIGN(v125, v126);
  // pto: %buf_panel_keys_inline9242__phi_v52
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v52
  uint64_t v128 = (uint64_t) v39;
  TASSIGN(v127, v128);
  // pto: %buf_panel_keys_inline9242__phi_v57
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v57
  uint64_t v130 = (uint64_t) v39;
  TASSIGN(v129, v130);
  // pto: %buf_panel_keys_inline9242__phi_v62
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v62
  uint64_t v132 = (uint64_t) v39;
  TASSIGN(v131, v132);
  // pto: %buf_panel_keys_inline9242__phi_v68
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v68
  uint64_t v134 = (uint64_t) v40;
  TASSIGN(v133, v134);
  // pto: %buf_panel_keys_inline9242__phi_v73
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v135 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v73
  uint64_t v136 = (uint64_t) v40;
  TASSIGN(v135, v136);
  // pto: %buf_panel_keys_inline9242__phi_v78
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v78
  uint64_t v138 = (uint64_t) v40;
  TASSIGN(v137, v138);
  // pto: %buf_panel_keys_inline9242__phi_v83
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v139 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v83
  uint64_t v140 = (uint64_t) v40;
  TASSIGN(v139, v140);
  // pto: %buf_panel_keys_inline9242__phi_v89
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v141 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v89
  uint64_t v142 = (uint64_t) v39;
  TASSIGN(v141, v142);
  // pto: %buf_panel_keys_inline9242__phi_v94
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v143 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v94
  uint64_t v144 = (uint64_t) v39;
  TASSIGN(v143, v144);
  // pto: %buf_panel_keys_inline9242__phi_v99
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v145 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v99
  uint64_t v146 = (uint64_t) v39;
  TASSIGN(v145, v146);
  // pto: %buf_panel_keys_inline9242__phi_v104
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v147 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v104
  uint64_t v148 = (uint64_t) v39;
  TASSIGN(v147, v148);
  // pto: %buf_panel_keys_inline9242__phi_v110
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v149 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v110
  uint64_t v150 = (uint64_t) v40;
  TASSIGN(v149, v150);
  // pto: %buf_panel_keys_inline9242__phi_v115
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v151 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v115
  uint64_t v152 = (uint64_t) v40;
  TASSIGN(v151, v152);
  // pto: %buf_panel_keys_inline9242__phi_v120
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v153 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v120
  uint64_t v154 = (uint64_t) v40;
  TASSIGN(v153, v154);
  // pto: %buf_panel_keys_inline9242__phi_v125
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v155 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline9242__phi_v125
  uint64_t v156 = (uint64_t) v40;
  TASSIGN(v155, v156);
  // pto: %buf_worker_inline9397__ssa_v0
  int64_t v157 = (int64_t) v25;
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  // pto: %buf_max_cache_len_inline9304__rv_v2
  int64_t v158;
  v158 = v50;
  for (int64_t v159 = v50; v159 < v18; v159 += v43) {
    // pto: %t__tile
    ;
    int32_t v160 = (v1)[v159];
    // pto: %0, %1
    ;
    int64_t v161 = (int64_t) v160 / v51;
    // pto: %2
    ;
    bool v162 = v158 < v161;
    // pto: %2
    ;
    int64_t v163 = v162 ? v161 : v158;
    v158 = v163;
  }
  // pto: %3
  bool v164 = v158 < v52;
  // pto: %3
  int64_t v165 = v164 ? v158 : v52;
  // pto: %4, %5
  int64_t v166 = (int64_t) ((uint64_t) v165 + (uint64_t) v53) / v49;
  // pto: %6
  int64_t v167 = v166 < v43 ? v43 : v166;
  // pto: %7
  int32_t v168 = (v2)[v50];
  // pto: %8
  int64_t v169 = (int64_t) v168;
  uint64_t v170 = reinterpret_cast<uint64_t>(v3);
  set_ffts_base_addr(v170);
  // pto: %9
  for (int64_t v171 = v157; v171 < ((int64_t) ((uint64_t) v169 * (uint64_t) v167)); v171 += v54) {
    // pto: %10
    ;
    // pto: %buf_group_inline9381__phi_v2
    ;
    int64_t v172;
    // pto: %buf_leaf_inline9296__phi_v2
    ;
    int64_t v173;
    if (v169 < v54) {
      // pto: %11
      ;
      int64_t v174 = v171 % v169;
      // pto: %15, %12, %13, %14, %16, %17, %18
      ;
      // pto: %19
      ;
      v172 = v174 != v50 & (v174 < v50 ^ v169 < v50) ? (int64_t) ((uint64_t) v174 + (uint64_t) v169) : v174;
      v173 = v171 / v169;
    } else {
      // pto: %20
      ;
      // pto: %21
      ;
      int64_t v175 = v171 % v167;
      // pto: %25, %22, %23, %24, %26, %27, %28
      ;
      v172 = v171 / v167;
      v173 = v175 != v50 & (v175 < v50 ^ v167 < v50) ? (int64_t) ((uint64_t) v175 + (uint64_t) v167) : v175;
    };
    // pto: %29
    ;
    int32_t v176 = (v4)[v172];
    // pto: %30
    ;
    int64_t v177 = (int64_t) v176;
    // pto: %31
    ;
    int32_t v178 = (v5)[v172];
    // pto: %33
    ;
    int32_t v179 = (v6)[v177];
    // pto: %34
    ;
    int64_t v180 = (int64_t) v179;
    // pto: %35, %32, %36, %buf_last_position_inline9360__tile
    ;
    int64_t v181 = (v7)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v177 + (uint64_t) ((int64_t) v178)) - (uint64_t) v43)];
    // pto: %37
    ;
    int32_t v182 = (v1)[v180];
    // pto: %38, %39
    ;
    int64_t v183 = (int64_t) v182 / v51;
    // pto: %40, %41
    ;
    int64_t v184 = (int64_t) ((uint64_t) v181 + (uint64_t) v55) / v56;
    // pto: %43
    ;
    int64_t v185 = v183 < v184 ? v183 : v184;
    // pto: %44
    ;
    int64_t v186 = v185 < v52 ? v185 : v52;
    // pto: %45
    ;
    int64_t v187 = v186 < v50 ? v50 : v186;
    // pto: %46
    ;
    uint64_t v188 = (uint64_t) v173;
    // pto: %46
    ;
    int64_t v189 = (int64_t) (v188 * (uint64_t) v49);
    // pto: %47
    ;
    if (v189 < v187) {
      // pto: %48
      ;
      int64_t v190 = (int64_t) ((uint64_t) v187 - (uint64_t) v189);
      // pto: %49
      ;
      int64_t v191 = v190 < v49 ? v190 : v49;
      // pto: %50, %51, %52
      ;
      int64_t v192 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v191 + (uint64_t) v57) / v48) * (uint64_t) v58);
      // pto: %53
      ;
      int64_t v193 = v192 < v59 ? v192 : v59;
      // pto: %54, %55
      ;
      int64_t v194 = (int64_t) ((uint64_t) v193 + (uint64_t) v60) / v58;
      // pto: %buf_query_vector_inline9400__ssa_v0
      ;
      Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v195 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
      // pto: %buf_query_vector_inline9400__ssa_v0
      ;
      uint64_t v196 = (uint64_t) v39;
      TASSIGN(v195, v196);
      // pto: %56
      ;
      int64_t v197 = (int64_t) ((uint64_t) v177 * (uint64_t) v61);
      // pto: %57
      ;
      int64_t v198 = v197 < v50 ? v50 : v197;
      // pto: %qr_hadamard_i8_inline979__rv_v2_pview
      ;
      __gm__ int8_t* v199 = PTOAS__GLOBAL_TENSOR_DATA(v74);
      // pto: %qr_hadamard_i8_inline979__rv_v2_pview
      ;
      const int64_t v200 = 0;
      // pto: %qr_hadamard_i8_inline979__rv_v2_pview
      ;
      const int64_t v201 = 128;
      // pto: %qr_hadamard_i8_inline979__rv_v2_pview
      ;
      pto::Shape<1, 1, 1, 128, 128> v202 = pto::Shape<1, 1, 1, 128, 128>();
      // pto: %qr_hadamard_i8_inline979__rv_v2_pview
      ;
      pto::Stride<16384, 16384, 16384, 128, 1> v203 = pto::Stride<16384, 16384, 16384, 128, 1>();
      // pto: %qr_hadamard_i8_inline979__rv_v2_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, 128, 128>, pto::Stride<16384, 16384, 16384, 128, 1>, pto::Layout::ND> v204 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 128, 128>, pto::Stride<16384, 16384, 16384, 128, 1>, pto::Layout::ND>(v199 + (v200 + v198 * v201), v202, v203);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v195, v204);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %buf_coefficients_l1_inline9297__ssa_v0
      ;
      Tile<TileType::Mat, half, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v205 = Tile<TileType::Mat, half, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v62, v45);
      // pto: %buf_coefficients_l1_inline9297__ssa_v0
      ;
      uint64_t v206 = (uint64_t) v40;
      TASSIGN(v205, v206);
      // pto: %58
      ;
      uint64_t v207 = (uint64_t) v172;
      // pto: %58
      ;
      int64_t v208 = (int64_t) (v207 * (uint64_t) v62);
      // pto: %59
      ;
      int64_t v209 = v208 < v50 ? v50 : v208;
      // pto: %coefficients_inline9338__ssa_v0_pview
      ;
      __gm__ half* v210 = PTOAS__GLOBAL_TENSOR_DATA(v82);
      // pto: %coefficients_inline9338__ssa_v0_pview
      ;
      const int64_t v211 = 0;
      // pto: %coefficients_inline9338__ssa_v0_pview
      ;
      const int64_t v212 = 128;
      // pto: %coefficients_inline9338__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 128> v213 = pto::Shape<1, 1, 1, 16, 128>();
      // pto: %coefficients_inline9338__ssa_v0_pview
      ;
      pto::Stride<2048, 2048, 2048, 128, 1> v214 = pto::Stride<2048, 2048, 2048, 128, 1>();
      // pto: %coefficients_inline9338__ssa_v0_pview
      ;
      GlobalTensor<half, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<2048, 2048, 2048, 128, 1>, pto::Layout::ND> v215 = GlobalTensor<half, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<2048, 2048, 2048, 128, 1>, pto::Layout::ND>(v210 + (v211 + v209 * v212), v213, v214);
      TLOAD(v205, v215);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %buf_query_left_inline9366__ssa_v0
      ;
      Tile<TileType::Left, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v216 = Tile<TileType::Left, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
      // pto: %buf_query_left_inline9366__ssa_v0
      ;
      uint64_t v217 = (uint64_t) v39;
      TASSIGN(v216, v217);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      TMOV(v216, v195);
      // pto: %buf_coefficient_pair_inline9323__ssa_v0
      ;
      Tile<TileType::Left, half, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Left, half, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v62, v45);
      // pto: %buf_coefficient_pair_inline9323__ssa_v0
      ;
      uint64_t v219 = (uint64_t) v41;
      TASSIGN(v218, v219);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      TMOV(v218, v205);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      for (int64_t v220 = v50; v220 < v194; v220 += v43) {
        // pto: %60
        ;
        if (v220 >= v63) {
          int32_t v221 = (int32_t) v43;
          wait_flag_dev(v221);
        };
        // pto: %63
        ;
        int64_t v222 = v220 % v63;
        // pto: %64, %65, %66
        ;
        int64_t v223 = v222 < v50 ? (int64_t) ((uint64_t) v222 + (uint64_t) v63) : v222;
        // pto: %62, %68, %67
        ;
        int64_t v224 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v157 * (uint64_t) v51) + (uint64_t) ((int64_t) (uint64_t) v223 * (uint64_t) v63));
        // pto: %buf_panel_keys_inline9242__ssa_v0
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v225 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_panel_keys_inline9242__ssa_v0
        ;
        uint64_t v226 = (uint64_t) v39;
        TASSIGN(v225, v226);
        // pto: %69, %61
        ;
        int64_t v227 = (int64_t) ((uint64_t) v189 + (uint64_t) ((int64_t) (uint64_t) v220 * (uint64_t) v58));
        // pto: %71
        ;
        int64_t v228 = v227 / v64;
        // pto: %72, %73
        ;
        int64_t v229 = (int64_t) ((uint64_t) v183 - (uint64_t) v43) / v64;
        // pto: %74
        ;
        int64_t v230 = v229 < v50 ? v50 : v229;
        // pto: %75
        ;
        int64_t v231 = v228 < v230 ? v228 : v230;
        // pto: %flat_offset_mul
        ;
        int64_t v232 = (int64_t) ((uint64_t) v180 * (uint64_t) v20);
        // pto: %flat_offset, %76
        ;
        int32_t v233 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v231)];
        // pto: %77
        ;
        int64_t v234 = (int64_t) v233;
        // pto: %78
        ;
        int64_t v235 = v234 < v50 ? v50 : v234;
        // pto: %79
        ;
        int64_t v236 = (int64_t) ((uint64_t) v235 * (uint64_t) v17);
        // pto: %80
        ;
        int64_t v237 = v236 % v45;
        // pto: %81, %82, %83
        ;
        int64_t v238 = v237 < v50 ? (int64_t) ((uint64_t) v237 + (uint64_t) v45) : v237;
        // pto: %84
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        if (v238 == v50) {
          // pto: %gather_row_view
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v239;
          // pto: %gather_row_view
          ;
          uint64_t v240 = (uint64_t) v39;
          TASSIGN(v239, v240);
          // pto: %85
          ;
          int64_t v241 = v236 / v45;
          // pto: %86
          ;
          int64_t v242 = v241 < v50 ? v50 : v241;
          // pto: %idx_kv_cache_inline9340__ssa_v0_pview
          ;
          __gm__ int8_t* v243 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %idx_kv_cache_inline9340__ssa_v0_pview
          ;
          const int64_t v244 = 0;
          // pto: %idx_kv_cache_inline9340__ssa_v0_pview
          ;
          const int64_t v245 = 128;
          // pto: %idx_kv_cache_inline9340__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 32, 128> v246 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %idx_kv_cache_inline9340__ssa_v0_pview
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v247 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %idx_kv_cache_inline9340__ssa_v0_pview
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v248 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v243 + (v244 + v242 * v245), v246, v247);
          TLOAD(v239, v248);
        } else {
          // pto: %87
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v249;
          // pto: %87
          ;
          uint64_t v250 = (uint64_t) v39;
          TASSIGN(v249, v250);
          // pto: %88
          ;
          int64_t v251 = v236 / v45;
          // pto: %89
          ;
          int64_t v252 = v251 < v50 ? v50 : v251;
          // pto: %idx_kv_cache_shift64_inline9347__ssa_v0_pview
          ;
          __gm__ int8_t* v253 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %idx_kv_cache_shift64_inline9347__ssa_v0_pview
          ;
          const int64_t v254 = 0;
          // pto: %idx_kv_cache_shift64_inline9347__ssa_v0_pview
          ;
          const int64_t v255 = 128;
          // pto: %idx_kv_cache_shift64_inline9347__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 32, 128> v256 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %idx_kv_cache_shift64_inline9347__ssa_v0_pview
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v257 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %idx_kv_cache_shift64_inline9347__ssa_v0_pview
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v258 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v253 + (v254 + v252 * v255), v256, v257);
          TLOAD(v249, v258);
        };
        // pto: %92, %93
        ;
        int64_t v259 = (int64_t) ((uint64_t) v227 + (uint64_t) v64) / v64;
        // pto: %97
        ;
        int64_t v260 = v259 < v230 ? v259 : v230;
        // pto: %100, %98
        ;
        int32_t v261 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v260)];
        // pto: %101
        ;
        int64_t v262 = (int64_t) v261;
        // pto: %102
        ;
        int64_t v263 = v262 < v50 ? v50 : v262;
        // pto: %103
        ;
        int64_t v264 = (int64_t) ((uint64_t) v263 * (uint64_t) v17);
        // pto: %104
        ;
        int64_t v265 = v264 % v45;
        // pto: %105, %106, %107
        ;
        int64_t v266 = v265 < v50 ? (int64_t) ((uint64_t) v265 + (uint64_t) v45) : v265;
        // pto: %108
        ;
        if (v266 == v50) {
          // pto: %109
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v267;
          // pto: %109
          ;
          uint64_t v268 = (uint64_t) v38;
          TASSIGN(v267, v268);
          // pto: %110
          ;
          int64_t v269 = v264 / v45;
          // pto: %111
          ;
          int64_t v270 = v269 < v50 ? v50 : v269;
          // pto: %112
          ;
          __gm__ int8_t* v271 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %112
          ;
          const int64_t v272 = 0;
          // pto: %112
          ;
          const int64_t v273 = 128;
          // pto: %112
          ;
          pto::Shape<1, 1, 1, 32, 128> v274 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %112
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v275 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %112
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v276 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v271 + (v272 + v270 * v273), v274, v275);
          TLOAD(v267, v276);
        } else {
          // pto: %113
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v277;
          // pto: %113
          ;
          uint64_t v278 = (uint64_t) v38;
          TASSIGN(v277, v278);
          // pto: %114
          ;
          int64_t v279 = v264 / v45;
          // pto: %115
          ;
          int64_t v280 = v279 < v50 ? v50 : v279;
          // pto: %116
          ;
          __gm__ int8_t* v281 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %116
          ;
          const int64_t v282 = 0;
          // pto: %116
          ;
          const int64_t v283 = 128;
          // pto: %116
          ;
          pto::Shape<1, 1, 1, 32, 128> v284 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %116
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v285 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %116
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v286 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v281 + (v282 + v280 * v283), v284, v285);
          TLOAD(v277, v286);
        };
        // pto: %119, %120
        ;
        int64_t v287 = (int64_t) ((uint64_t) v227 + (uint64_t) v61) / v64;
        // pto: %124
        ;
        int64_t v288 = v287 < v230 ? v287 : v230;
        // pto: %127, %125
        ;
        int32_t v289 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v288)];
        // pto: %128
        ;
        int64_t v290 = (int64_t) v289;
        // pto: %129
        ;
        int64_t v291 = v290 < v50 ? v50 : v290;
        // pto: %130
        ;
        int64_t v292 = (int64_t) ((uint64_t) v291 * (uint64_t) v17);
        // pto: %131
        ;
        int64_t v293 = v292 % v45;
        // pto: %132, %133, %134
        ;
        int64_t v294 = v293 < v50 ? (int64_t) ((uint64_t) v293 + (uint64_t) v45) : v293;
        // pto: %135
        ;
        if (v294 == v50) {
          // pto: %136
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v295;
          // pto: %136
          ;
          uint64_t v296 = (uint64_t) v37;
          TASSIGN(v295, v296);
          // pto: %137
          ;
          int64_t v297 = v292 / v45;
          // pto: %138
          ;
          int64_t v298 = v297 < v50 ? v50 : v297;
          // pto: %139
          ;
          __gm__ int8_t* v299 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %139
          ;
          const int64_t v300 = 0;
          // pto: %139
          ;
          const int64_t v301 = 128;
          // pto: %139
          ;
          pto::Shape<1, 1, 1, 32, 128> v302 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %139
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v303 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %139
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v304 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v299 + (v300 + v298 * v301), v302, v303);
          TLOAD(v295, v304);
        } else {
          // pto: %140
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v305;
          // pto: %140
          ;
          uint64_t v306 = (uint64_t) v37;
          TASSIGN(v305, v306);
          // pto: %141
          ;
          int64_t v307 = v292 / v45;
          // pto: %142
          ;
          int64_t v308 = v307 < v50 ? v50 : v307;
          // pto: %143
          ;
          __gm__ int8_t* v309 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %143
          ;
          const int64_t v310 = 0;
          // pto: %143
          ;
          const int64_t v311 = 128;
          // pto: %143
          ;
          pto::Shape<1, 1, 1, 32, 128> v312 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %143
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v313 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %143
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v314 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v309 + (v310 + v308 * v311), v312, v313);
          TLOAD(v305, v314);
        };
        // pto: %146, %147
        ;
        int64_t v315 = (int64_t) ((uint64_t) v227 + (uint64_t) v47) / v64;
        // pto: %151
        ;
        int64_t v316 = v315 < v230 ? v315 : v230;
        // pto: %154, %152
        ;
        int32_t v317 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v316)];
        // pto: %155
        ;
        int64_t v318 = (int64_t) v317;
        // pto: %156
        ;
        int64_t v319 = v318 < v50 ? v50 : v318;
        // pto: %157
        ;
        int64_t v320 = (int64_t) ((uint64_t) v319 * (uint64_t) v17);
        // pto: %158
        ;
        int64_t v321 = v320 % v45;
        // pto: %159, %160, %161
        ;
        int64_t v322 = v321 < v50 ? (int64_t) ((uint64_t) v321 + (uint64_t) v45) : v321;
        // pto: %162
        ;
        if (v322 == v50) {
          // pto: %163
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v323;
          // pto: %163
          ;
          uint64_t v324 = (uint64_t) v36;
          TASSIGN(v323, v324);
          // pto: %164
          ;
          int64_t v325 = v320 / v45;
          // pto: %165
          ;
          int64_t v326 = v325 < v50 ? v50 : v325;
          // pto: %166
          ;
          __gm__ int8_t* v327 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %166
          ;
          const int64_t v328 = 0;
          // pto: %166
          ;
          const int64_t v329 = 128;
          // pto: %166
          ;
          pto::Shape<1, 1, 1, 32, 128> v330 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %166
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v331 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %166
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v332 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v327 + (v328 + v326 * v329), v330, v331);
          TLOAD(v323, v332);
        } else {
          // pto: %167
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v333;
          // pto: %167
          ;
          uint64_t v334 = (uint64_t) v36;
          TASSIGN(v333, v334);
          // pto: %168
          ;
          int64_t v335 = v320 / v45;
          // pto: %169
          ;
          int64_t v336 = v335 < v50 ? v50 : v335;
          // pto: %170
          ;
          __gm__ int8_t* v337 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %170
          ;
          const int64_t v338 = 0;
          // pto: %170
          ;
          const int64_t v339 = 128;
          // pto: %170
          ;
          pto::Shape<1, 1, 1, 32, 128> v340 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %170
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v341 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %170
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v342 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v337 + (v338 + v336 * v339), v340, v341);
          TLOAD(v333, v342);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        // pto: %t__tmp_v765
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v343 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %t__tmp_v765
        ;
        uint64_t v344 = (uint64_t) v39;
        TASSIGN(v343, v344);
        // pto: %buf_prefetched_key_inline9260__ssa_v3
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v345 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_prefetched_key_inline9260__ssa_v3
        ;
        uint64_t v346 = (uint64_t) v41;
        TASSIGN(v345, v346);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        TMOV(v345, v343);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_key_panel_inline9272__ssa_v1
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v347 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_key_panel_inline9272__ssa_v1
        ;
        uint64_t v348 = (uint64_t) v41;
        TASSIGN(v347, v348);
        // pto: %buf_scores_l1_inline9318__ssa_v0
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v349 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_l1_inline9318__ssa_v0
        ;
        uint64_t v350 = (uint64_t) v39;
        TASSIGN(v349, v350);
        // pto: %buf_scores_inline9403__ssa_v1
        ;
        Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v351 = Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_inline9403__ssa_v1
        ;
        uint64_t v352 = (uint64_t) v39;
        TASSIGN(v351, v352);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        TMATMUL(v351, v216, v347);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v353 = static_cast<uint64_t>(v65);
        uint16_t v354 = static_cast<uint16_t>(v50);
        uint16_t v355 = static_cast<uint16_t>(v50);
        TINSERT<Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v349, v351, v353, v354, v355);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        // pto: %buf_previous_l1_inline9375__ssa_v1
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v356 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_previous_l1_inline9375__ssa_v1
        ;
        uint64_t v357 = (uint64_t) v39;
        TASSIGN(v356, v357);
        // pto: %buf_panel_keys_inline9242__ssa_v21
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v358 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_panel_keys_inline9242__ssa_v21
        ;
        uint64_t v359 = (uint64_t) v40;
        TASSIGN(v358, v359);
        // pto: %172, %173
        ;
        int64_t v360 = (int64_t) ((uint64_t) v227 + (uint64_t) v45) / v64;
        // pto: %177
        ;
        int64_t v361 = v360 < v230 ? v360 : v230;
        // pto: %180, %178
        ;
        int32_t v362 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v361)];
        // pto: %181
        ;
        int64_t v363 = (int64_t) v362;
        // pto: %182
        ;
        int64_t v364 = v363 < v50 ? v50 : v363;
        // pto: %183
        ;
        int64_t v365 = (int64_t) ((uint64_t) v364 * (uint64_t) v17);
        // pto: %184
        ;
        int64_t v366 = v365 % v45;
        // pto: %185, %186, %187
        ;
        int64_t v367 = v366 < v50 ? (int64_t) ((uint64_t) v366 + (uint64_t) v45) : v366;
        // pto: %188
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        if (v367 == v50) {
          // pto: %189
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v368;
          // pto: %189
          ;
          uint64_t v369 = (uint64_t) v40;
          TASSIGN(v368, v369);
          // pto: %190
          ;
          int64_t v370 = v365 / v45;
          // pto: %191
          ;
          int64_t v371 = v370 < v50 ? v50 : v370;
          // pto: %192
          ;
          __gm__ int8_t* v372 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %192
          ;
          const int64_t v373 = 0;
          // pto: %192
          ;
          const int64_t v374 = 128;
          // pto: %192
          ;
          pto::Shape<1, 1, 1, 32, 128> v375 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %192
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v376 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %192
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v377 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v372 + (v373 + v371 * v374), v375, v376);
          TLOAD(v368, v377);
        } else {
          // pto: %193
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v378;
          // pto: %193
          ;
          uint64_t v379 = (uint64_t) v40;
          TASSIGN(v378, v379);
          // pto: %194
          ;
          int64_t v380 = v365 / v45;
          // pto: %195
          ;
          int64_t v381 = v380 < v50 ? v50 : v380;
          // pto: %196
          ;
          __gm__ int8_t* v382 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %196
          ;
          const int64_t v383 = 0;
          // pto: %196
          ;
          const int64_t v384 = 128;
          // pto: %196
          ;
          pto::Shape<1, 1, 1, 32, 128> v385 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %196
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v386 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %196
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v387 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v382 + (v383 + v381 * v384), v385, v386);
          TLOAD(v378, v387);
        };
        // pto: %199, %200
        ;
        int64_t v388 = (int64_t) ((uint64_t) v227 + (uint64_t) v35) / v64;
        // pto: %204
        ;
        int64_t v389 = v388 < v230 ? v388 : v230;
        // pto: %207, %205
        ;
        int32_t v390 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v389)];
        // pto: %208
        ;
        int64_t v391 = (int64_t) v390;
        // pto: %209
        ;
        int64_t v392 = v391 < v50 ? v50 : v391;
        // pto: %210
        ;
        int64_t v393 = (int64_t) ((uint64_t) v392 * (uint64_t) v17);
        // pto: %211
        ;
        int64_t v394 = v393 % v45;
        // pto: %212, %213, %214
        ;
        int64_t v395 = v394 < v50 ? (int64_t) ((uint64_t) v394 + (uint64_t) v45) : v394;
        // pto: %215
        ;
        if (v395 == v50) {
          // pto: %216
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v396;
          // pto: %216
          ;
          uint64_t v397 = (uint64_t) v34;
          TASSIGN(v396, v397);
          // pto: %217
          ;
          int64_t v398 = v393 / v45;
          // pto: %218
          ;
          int64_t v399 = v398 < v50 ? v50 : v398;
          // pto: %219
          ;
          __gm__ int8_t* v400 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %219
          ;
          const int64_t v401 = 0;
          // pto: %219
          ;
          const int64_t v402 = 128;
          // pto: %219
          ;
          pto::Shape<1, 1, 1, 32, 128> v403 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %219
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v404 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %219
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v405 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v400 + (v401 + v399 * v402), v403, v404);
          TLOAD(v396, v405);
        } else {
          // pto: %220
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v406;
          // pto: %220
          ;
          uint64_t v407 = (uint64_t) v34;
          TASSIGN(v406, v407);
          // pto: %221
          ;
          int64_t v408 = v393 / v45;
          // pto: %222
          ;
          int64_t v409 = v408 < v50 ? v50 : v408;
          // pto: %223
          ;
          __gm__ int8_t* v410 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %223
          ;
          const int64_t v411 = 0;
          // pto: %223
          ;
          const int64_t v412 = 128;
          // pto: %223
          ;
          pto::Shape<1, 1, 1, 32, 128> v413 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %223
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v414 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %223
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v415 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v410 + (v411 + v409 * v412), v413, v414);
          TLOAD(v406, v415);
        };
        // pto: %226, %227
        ;
        int64_t v416 = (int64_t) ((uint64_t) v227 + (uint64_t) v33) / v64;
        // pto: %231
        ;
        int64_t v417 = v416 < v230 ? v416 : v230;
        // pto: %234, %232
        ;
        int32_t v418 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v417)];
        // pto: %235
        ;
        int64_t v419 = (int64_t) v418;
        // pto: %236
        ;
        int64_t v420 = v419 < v50 ? v50 : v419;
        // pto: %237
        ;
        int64_t v421 = (int64_t) ((uint64_t) v420 * (uint64_t) v17);
        // pto: %238
        ;
        int64_t v422 = v421 % v45;
        // pto: %239, %240, %241
        ;
        int64_t v423 = v422 < v50 ? (int64_t) ((uint64_t) v422 + (uint64_t) v45) : v422;
        // pto: %242
        ;
        if (v423 == v50) {
          // pto: %243
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v424;
          // pto: %243
          ;
          uint64_t v425 = (uint64_t) v32;
          TASSIGN(v424, v425);
          // pto: %244
          ;
          int64_t v426 = v421 / v45;
          // pto: %245
          ;
          int64_t v427 = v426 < v50 ? v50 : v426;
          // pto: %246
          ;
          __gm__ int8_t* v428 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %246
          ;
          const int64_t v429 = 0;
          // pto: %246
          ;
          const int64_t v430 = 128;
          // pto: %246
          ;
          pto::Shape<1, 1, 1, 32, 128> v431 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %246
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v432 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %246
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v433 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v428 + (v429 + v427 * v430), v431, v432);
          TLOAD(v424, v433);
        } else {
          // pto: %247
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v434;
          // pto: %247
          ;
          uint64_t v435 = (uint64_t) v32;
          TASSIGN(v434, v435);
          // pto: %248
          ;
          int64_t v436 = v421 / v45;
          // pto: %249
          ;
          int64_t v437 = v436 < v50 ? v50 : v436;
          // pto: %250
          ;
          __gm__ int8_t* v438 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %250
          ;
          const int64_t v439 = 0;
          // pto: %250
          ;
          const int64_t v440 = 128;
          // pto: %250
          ;
          pto::Shape<1, 1, 1, 32, 128> v441 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %250
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v442 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %250
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v443 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v438 + (v439 + v437 * v440), v441, v442);
          TLOAD(v434, v443);
        };
        // pto: %253, %254
        ;
        int64_t v444 = (int64_t) ((uint64_t) v227 + (uint64_t) v31) / v64;
        // pto: %258
        ;
        int64_t v445 = v444 < v230 ? v444 : v230;
        // pto: %261, %259
        ;
        int32_t v446 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v445)];
        // pto: %262
        ;
        int64_t v447 = (int64_t) v446;
        // pto: %263
        ;
        int64_t v448 = v447 < v50 ? v50 : v447;
        // pto: %264
        ;
        int64_t v449 = (int64_t) ((uint64_t) v448 * (uint64_t) v17);
        // pto: %265
        ;
        int64_t v450 = v449 % v45;
        // pto: %266, %267, %268
        ;
        int64_t v451 = v450 < v50 ? (int64_t) ((uint64_t) v450 + (uint64_t) v45) : v450;
        // pto: %269
        ;
        if (v451 == v50) {
          // pto: %270
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v452;
          // pto: %270
          ;
          uint64_t v453 = (uint64_t) v30;
          TASSIGN(v452, v453);
          // pto: %271
          ;
          int64_t v454 = v449 / v45;
          // pto: %272
          ;
          int64_t v455 = v454 < v50 ? v50 : v454;
          // pto: %273
          ;
          __gm__ int8_t* v456 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %273
          ;
          const int64_t v457 = 0;
          // pto: %273
          ;
          const int64_t v458 = 128;
          // pto: %273
          ;
          pto::Shape<1, 1, 1, 32, 128> v459 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %273
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v460 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %273
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v461 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v456 + (v457 + v455 * v458), v459, v460);
          TLOAD(v452, v461);
        } else {
          // pto: %274
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v462;
          // pto: %274
          ;
          uint64_t v463 = (uint64_t) v30;
          TASSIGN(v462, v463);
          // pto: %275
          ;
          int64_t v464 = v449 / v45;
          // pto: %276
          ;
          int64_t v465 = v464 < v50 ? v50 : v464;
          // pto: %277
          ;
          __gm__ int8_t* v466 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %277
          ;
          const int64_t v467 = 0;
          // pto: %277
          ;
          const int64_t v468 = 128;
          // pto: %277
          ;
          pto::Shape<1, 1, 1, 32, 128> v469 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %277
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v470 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %277
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v471 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v466 + (v467 + v465 * v468), v469, v470);
          TLOAD(v462, v471);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
        // pto: %t__tmp_v770
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v472 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %t__tmp_v770
        ;
        uint64_t v473 = (uint64_t) v40;
        TASSIGN(v472, v473);
        // pto: %buf_prefetched_key_inline9260__ssa_v8
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v474 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_prefetched_key_inline9260__ssa_v8
        ;
        uint64_t v475 = (uint64_t) v39;
        TASSIGN(v474, v475);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
        TMOV(v474, v472);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %buf_key_panel_inline9272__ssa_v4
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v476 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_key_panel_inline9272__ssa_v4
        ;
        uint64_t v477 = (uint64_t) v39;
        TASSIGN(v476, v477);
        // pto: %buf_scores_l1_inline9318__ssa_v4
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v478 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_l1_inline9318__ssa_v4
        ;
        uint64_t v479 = (uint64_t) v40;
        TASSIGN(v478, v479);
        // pto: %buf_previous_pair_inline9269__ssa_v1
        ;
        Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v480 = Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_previous_pair_inline9269__ssa_v1
        ;
        uint64_t v481 = (uint64_t) v41;
        TASSIGN(v480, v481);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        uint16_t v482 = static_cast<uint16_t>(v50);
        uint16_t v483 = static_cast<uint16_t>(v50);
        TEXTRACT(v480, v356, v482, v483);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %buf_scores_inline9403__ssa_v3
        ;
        Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v484 = Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_inline9403__ssa_v3
        ;
        uint64_t v485 = (uint64_t) v39;
        TASSIGN(v484, v485);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v484, v216, v476);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        // pto: %buf_reduced_pair_inline9267__ssa_v1
        ;
        Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v486 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v62, v45);
        // pto: %buf_reduced_pair_inline9267__ssa_v1
        ;
        uint64_t v487 = (uint64_t) v42;
        TASSIGN(v486, v487);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        TMATMUL(v486, v218, v480);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        uint64_t v488 = static_cast<uint64_t>(v65);
        uint16_t v489 = static_cast<uint16_t>(v50);
        uint16_t v490 = static_cast<uint16_t>(v50);
        TINSERT<Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v478, v484, v488, v489, v490);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID1);
        v486.SetValidShape(v63, v45);
        // pto: %278
        ;
        int64_t v491 = v224 < v50 ? v50 : v224;
        // pto: %buf_score_transfer_inline9298__ssa_v0_pview
        ;
        __gm__ float* v492 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %buf_score_transfer_inline9298__ssa_v0_pview
        ;
        const int64_t v493 = 0;
        // pto: %buf_score_transfer_inline9298__ssa_v0_pview
        ;
        const int64_t v494 = 768;
        // pto: %buf_score_transfer_inline9298__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 2, 128> v495 = pto::Shape<1, 1, 1, 2, 128>();
        // pto: %buf_score_transfer_inline9298__ssa_v0_pview
        ;
        pto::Stride<1536, 1536, 1536, 768, 1> v496 = pto::Stride<1536, 1536, 1536, 768, 1>();
        // pto: %buf_score_transfer_inline9298__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND> v497 = GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND>(v492 + (v493 + v491 * v494), v495, v496);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
        TSTORE(v497, v486);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
        // pto: %buf_previous_l1_inline9375__ssa_v2
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v498 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_previous_l1_inline9375__ssa_v2
        ;
        uint64_t v499 = (uint64_t) v40;
        TASSIGN(v498, v499);
        // pto: %buf_panel_keys_inline9242__ssa_v42
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v500 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_panel_keys_inline9242__ssa_v42
        ;
        uint64_t v501 = (uint64_t) v39;
        TASSIGN(v500, v501);
        // pto: %282, %283
        ;
        int64_t v502 = (int64_t) ((uint64_t) v227 + (uint64_t) v66) / v64;
        // pto: %287
        ;
        int64_t v503 = v502 < v230 ? v502 : v230;
        // pto: %290, %288
        ;
        int32_t v504 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v503)];
        // pto: %291
        ;
        int64_t v505 = (int64_t) v504;
        // pto: %292
        ;
        int64_t v506 = v505 < v50 ? v50 : v505;
        // pto: %293
        ;
        int64_t v507 = (int64_t) ((uint64_t) v506 * (uint64_t) v17);
        // pto: %294
        ;
        int64_t v508 = v507 % v45;
        // pto: %295, %296, %297
        ;
        int64_t v509 = v508 < v50 ? (int64_t) ((uint64_t) v508 + (uint64_t) v45) : v508;
        // pto: %298
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        if (v509 == v50) {
          // pto: %299
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v510;
          // pto: %299
          ;
          uint64_t v511 = (uint64_t) v39;
          TASSIGN(v510, v511);
          // pto: %300
          ;
          int64_t v512 = v507 / v45;
          // pto: %301
          ;
          int64_t v513 = v512 < v50 ? v50 : v512;
          // pto: %302
          ;
          __gm__ int8_t* v514 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %302
          ;
          const int64_t v515 = 0;
          // pto: %302
          ;
          const int64_t v516 = 128;
          // pto: %302
          ;
          pto::Shape<1, 1, 1, 32, 128> v517 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %302
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v518 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %302
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v519 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v514 + (v515 + v513 * v516), v517, v518);
          TLOAD(v510, v519);
        } else {
          // pto: %303
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v520;
          // pto: %303
          ;
          uint64_t v521 = (uint64_t) v39;
          TASSIGN(v520, v521);
          // pto: %304
          ;
          int64_t v522 = v507 / v45;
          // pto: %305
          ;
          int64_t v523 = v522 < v50 ? v50 : v522;
          // pto: %306
          ;
          __gm__ int8_t* v524 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %306
          ;
          const int64_t v525 = 0;
          // pto: %306
          ;
          const int64_t v526 = 128;
          // pto: %306
          ;
          pto::Shape<1, 1, 1, 32, 128> v527 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %306
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v528 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %306
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v529 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v524 + (v525 + v523 * v526), v527, v528);
          TLOAD(v520, v529);
        };
        // pto: %309, %310
        ;
        int64_t v530 = (int64_t) ((uint64_t) v227 + (uint64_t) v29) / v64;
        // pto: %314
        ;
        int64_t v531 = v530 < v230 ? v530 : v230;
        // pto: %317, %315
        ;
        int32_t v532 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v531)];
        // pto: %318
        ;
        int64_t v533 = (int64_t) v532;
        // pto: %319
        ;
        int64_t v534 = v533 < v50 ? v50 : v533;
        // pto: %320
        ;
        int64_t v535 = (int64_t) ((uint64_t) v534 * (uint64_t) v17);
        // pto: %321
        ;
        int64_t v536 = v535 % v45;
        // pto: %322, %323, %324
        ;
        int64_t v537 = v536 < v50 ? (int64_t) ((uint64_t) v536 + (uint64_t) v45) : v536;
        // pto: %325
        ;
        if (v537 == v50) {
          // pto: %326
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v538;
          // pto: %326
          ;
          uint64_t v539 = (uint64_t) v38;
          TASSIGN(v538, v539);
          // pto: %327
          ;
          int64_t v540 = v535 / v45;
          // pto: %328
          ;
          int64_t v541 = v540 < v50 ? v50 : v540;
          // pto: %329
          ;
          __gm__ int8_t* v542 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %329
          ;
          const int64_t v543 = 0;
          // pto: %329
          ;
          const int64_t v544 = 128;
          // pto: %329
          ;
          pto::Shape<1, 1, 1, 32, 128> v545 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %329
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v546 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %329
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v547 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v542 + (v543 + v541 * v544), v545, v546);
          TLOAD(v538, v547);
        } else {
          // pto: %330
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v548;
          // pto: %330
          ;
          uint64_t v549 = (uint64_t) v38;
          TASSIGN(v548, v549);
          // pto: %331
          ;
          int64_t v550 = v535 / v45;
          // pto: %332
          ;
          int64_t v551 = v550 < v50 ? v50 : v550;
          // pto: %333
          ;
          __gm__ int8_t* v552 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %333
          ;
          const int64_t v553 = 0;
          // pto: %333
          ;
          const int64_t v554 = 128;
          // pto: %333
          ;
          pto::Shape<1, 1, 1, 32, 128> v555 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %333
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v556 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %333
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v557 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v552 + (v553 + v551 * v554), v555, v556);
          TLOAD(v548, v557);
        };
        // pto: %336, %337
        ;
        int64_t v558 = (int64_t) ((uint64_t) v227 + (uint64_t) v28) / v64;
        // pto: %341
        ;
        int64_t v559 = v558 < v230 ? v558 : v230;
        // pto: %344, %342
        ;
        int32_t v560 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v559)];
        // pto: %345
        ;
        int64_t v561 = (int64_t) v560;
        // pto: %346
        ;
        int64_t v562 = v561 < v50 ? v50 : v561;
        // pto: %347
        ;
        int64_t v563 = (int64_t) ((uint64_t) v562 * (uint64_t) v17);
        // pto: %348
        ;
        int64_t v564 = v563 % v45;
        // pto: %349, %350, %351
        ;
        int64_t v565 = v564 < v50 ? (int64_t) ((uint64_t) v564 + (uint64_t) v45) : v564;
        // pto: %352
        ;
        if (v565 == v50) {
          // pto: %353
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v566;
          // pto: %353
          ;
          uint64_t v567 = (uint64_t) v37;
          TASSIGN(v566, v567);
          // pto: %354
          ;
          int64_t v568 = v563 / v45;
          // pto: %355
          ;
          int64_t v569 = v568 < v50 ? v50 : v568;
          // pto: %356
          ;
          __gm__ int8_t* v570 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %356
          ;
          const int64_t v571 = 0;
          // pto: %356
          ;
          const int64_t v572 = 128;
          // pto: %356
          ;
          pto::Shape<1, 1, 1, 32, 128> v573 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %356
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v574 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %356
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v575 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v570 + (v571 + v569 * v572), v573, v574);
          TLOAD(v566, v575);
        } else {
          // pto: %357
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v576;
          // pto: %357
          ;
          uint64_t v577 = (uint64_t) v37;
          TASSIGN(v576, v577);
          // pto: %358
          ;
          int64_t v578 = v563 / v45;
          // pto: %359
          ;
          int64_t v579 = v578 < v50 ? v50 : v578;
          // pto: %360
          ;
          __gm__ int8_t* v580 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %360
          ;
          const int64_t v581 = 0;
          // pto: %360
          ;
          const int64_t v582 = 128;
          // pto: %360
          ;
          pto::Shape<1, 1, 1, 32, 128> v583 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %360
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v584 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %360
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v585 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v580 + (v581 + v579 * v582), v583, v584);
          TLOAD(v576, v585);
        };
        // pto: %363, %364
        ;
        int64_t v586 = (int64_t) ((uint64_t) v227 + (uint64_t) v27) / v64;
        // pto: %368
        ;
        int64_t v587 = v586 < v230 ? v586 : v230;
        // pto: %371, %369
        ;
        int32_t v588 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v587)];
        // pto: %372
        ;
        int64_t v589 = (int64_t) v588;
        // pto: %373
        ;
        int64_t v590 = v589 < v50 ? v50 : v589;
        // pto: %374
        ;
        int64_t v591 = (int64_t) ((uint64_t) v590 * (uint64_t) v17);
        // pto: %375
        ;
        int64_t v592 = v591 % v45;
        // pto: %376, %377, %378
        ;
        int64_t v593 = v592 < v50 ? (int64_t) ((uint64_t) v592 + (uint64_t) v45) : v592;
        // pto: %379
        ;
        if (v593 == v50) {
          // pto: %380
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v594;
          // pto: %380
          ;
          uint64_t v595 = (uint64_t) v36;
          TASSIGN(v594, v595);
          // pto: %381
          ;
          int64_t v596 = v591 / v45;
          // pto: %382
          ;
          int64_t v597 = v596 < v50 ? v50 : v596;
          // pto: %383
          ;
          __gm__ int8_t* v598 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %383
          ;
          const int64_t v599 = 0;
          // pto: %383
          ;
          const int64_t v600 = 128;
          // pto: %383
          ;
          pto::Shape<1, 1, 1, 32, 128> v601 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %383
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v602 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %383
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v603 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v598 + (v599 + v597 * v600), v601, v602);
          TLOAD(v594, v603);
        } else {
          // pto: %384
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v604;
          // pto: %384
          ;
          uint64_t v605 = (uint64_t) v36;
          TASSIGN(v604, v605);
          // pto: %385
          ;
          int64_t v606 = v591 / v45;
          // pto: %386
          ;
          int64_t v607 = v606 < v50 ? v50 : v606;
          // pto: %387
          ;
          __gm__ int8_t* v608 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %387
          ;
          const int64_t v609 = 0;
          // pto: %387
          ;
          const int64_t v610 = 128;
          // pto: %387
          ;
          pto::Shape<1, 1, 1, 32, 128> v611 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %387
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v612 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %387
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v613 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v608 + (v609 + v607 * v610), v611, v612);
          TLOAD(v604, v613);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
        // pto: %t__tmp_v776
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v614 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %t__tmp_v776
        ;
        uint64_t v615 = (uint64_t) v39;
        TASSIGN(v614, v615);
        // pto: %buf_prefetched_key_inline9260__ssa_v13
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v616 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_prefetched_key_inline9260__ssa_v13
        ;
        uint64_t v617 = (uint64_t) v39;
        TASSIGN(v616, v617);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        TMOV(v616, v614);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        // pto: %buf_key_panel_inline9272__ssa_v7
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v618 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_key_panel_inline9272__ssa_v7
        ;
        uint64_t v619 = (uint64_t) v39;
        TASSIGN(v618, v619);
        // pto: %buf_scores_l1_inline9318__ssa_v8
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v620 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_l1_inline9318__ssa_v8
        ;
        uint64_t v621 = (uint64_t) v39;
        TASSIGN(v620, v621);
        // pto: %buf_previous_pair_inline9269__ssa_v2
        ;
        Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v622 = Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_previous_pair_inline9269__ssa_v2
        ;
        uint64_t v623 = (uint64_t) v41;
        TASSIGN(v622, v623);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v624 = static_cast<uint16_t>(v50);
        uint16_t v625 = static_cast<uint16_t>(v50);
        TEXTRACT(v622, v498, v624, v625);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        // pto: %buf_scores_inline9403__ssa_v6
        ;
        Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v626 = Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_inline9403__ssa_v6
        ;
        uint64_t v627 = (uint64_t) v39;
        TASSIGN(v626, v627);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v626, v216, v618);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
        // pto: %buf_reduced_pair_inline9267__ssa_v2
        ;
        Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v628 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v62, v45);
        // pto: %buf_reduced_pair_inline9267__ssa_v2
        ;
        uint64_t v629 = (uint64_t) v42;
        TASSIGN(v628, v629);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
        TMATMUL(v628, v218, v622);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
        uint64_t v630 = static_cast<uint64_t>(v65);
        uint16_t v631 = static_cast<uint16_t>(v50);
        uint16_t v632 = static_cast<uint16_t>(v50);
        TINSERT<Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v620, v626, v630, v631, v632);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID2);
        v628.SetValidShape(v63, v45);
        // pto: %391
        ;
        __gm__ float* v633 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %391
        ;
        const int64_t v634 = 128;
        // pto: %391
        ;
        const int64_t v635 = 768;
        // pto: %391
        ;
        pto::Shape<1, 1, 1, 2, 128> v636 = pto::Shape<1, 1, 1, 2, 128>();
        // pto: %391
        ;
        pto::Stride<1536, 1536, 1536, 768, 1> v637 = pto::Stride<1536, 1536, 1536, 768, 1>();
        // pto: %391
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND> v638 = GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND>(v633 + (v634 + v491 * v635), v636, v637);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
        TSTORE(v638, v628);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
        // pto: %buf_previous_l1_inline9375__ssa_v3
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v639 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_previous_l1_inline9375__ssa_v3
        ;
        uint64_t v640 = (uint64_t) v39;
        TASSIGN(v639, v640);
        // pto: %buf_panel_keys_inline9242__ssa_v63
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v641 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_panel_keys_inline9242__ssa_v63
        ;
        uint64_t v642 = (uint64_t) v40;
        TASSIGN(v641, v642);
        // pto: %395
        ;
        int64_t v643 = (int64_t) ((uint64_t) v227 + (uint64_t) v193);
        // pto: %401
        ;
        int64_t v644 = v643 / v64;
        // pto: %405
        ;
        int64_t v645 = v644 < v230 ? v644 : v230;
        // pto: %408, %406
        ;
        int32_t v646 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v645)];
        // pto: %409
        ;
        int64_t v647 = (int64_t) v646;
        // pto: %410
        ;
        int64_t v648 = v647 < v50 ? v50 : v647;
        // pto: %411
        ;
        int64_t v649 = (int64_t) ((uint64_t) v648 * (uint64_t) v17);
        // pto: %412
        ;
        int64_t v650 = v649 % v45;
        // pto: %413, %414, %415
        ;
        int64_t v651 = v650 < v50 ? (int64_t) ((uint64_t) v650 + (uint64_t) v45) : v650;
        // pto: %416
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        if (v651 == v50) {
          // pto: %417
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v652;
          // pto: %417
          ;
          uint64_t v653 = (uint64_t) v40;
          TASSIGN(v652, v653);
          // pto: %418
          ;
          int64_t v654 = v649 / v45;
          // pto: %419
          ;
          int64_t v655 = v654 < v50 ? v50 : v654;
          // pto: %420
          ;
          __gm__ int8_t* v656 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %420
          ;
          const int64_t v657 = 0;
          // pto: %420
          ;
          const int64_t v658 = 128;
          // pto: %420
          ;
          pto::Shape<1, 1, 1, 32, 128> v659 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %420
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v660 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %420
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v661 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v656 + (v657 + v655 * v658), v659, v660);
          TLOAD(v652, v661);
        } else {
          // pto: %421
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v662;
          // pto: %421
          ;
          uint64_t v663 = (uint64_t) v40;
          TASSIGN(v662, v663);
          // pto: %422
          ;
          int64_t v664 = v649 / v45;
          // pto: %423
          ;
          int64_t v665 = v664 < v50 ? v50 : v664;
          // pto: %424
          ;
          __gm__ int8_t* v666 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %424
          ;
          const int64_t v667 = 0;
          // pto: %424
          ;
          const int64_t v668 = 128;
          // pto: %424
          ;
          pto::Shape<1, 1, 1, 32, 128> v669 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %424
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v670 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %424
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v671 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v666 + (v667 + v665 * v668), v669, v670);
          TLOAD(v662, v671);
        };
        // pto: %434, %435
        ;
        int64_t v672 = (int64_t) ((uint64_t) v643 + (uint64_t) v64) / v64;
        // pto: %439
        ;
        int64_t v673 = v672 < v230 ? v672 : v230;
        // pto: %442, %440
        ;
        int32_t v674 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v673)];
        // pto: %443
        ;
        int64_t v675 = (int64_t) v674;
        // pto: %444
        ;
        int64_t v676 = v675 < v50 ? v50 : v675;
        // pto: %445
        ;
        int64_t v677 = (int64_t) ((uint64_t) v676 * (uint64_t) v17);
        // pto: %446
        ;
        int64_t v678 = v677 % v45;
        // pto: %447, %448, %449
        ;
        int64_t v679 = v678 < v50 ? (int64_t) ((uint64_t) v678 + (uint64_t) v45) : v678;
        // pto: %450
        ;
        if (v679 == v50) {
          // pto: %451
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v680;
          // pto: %451
          ;
          uint64_t v681 = (uint64_t) v34;
          TASSIGN(v680, v681);
          // pto: %452
          ;
          int64_t v682 = v677 / v45;
          // pto: %453
          ;
          int64_t v683 = v682 < v50 ? v50 : v682;
          // pto: %454
          ;
          __gm__ int8_t* v684 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %454
          ;
          const int64_t v685 = 0;
          // pto: %454
          ;
          const int64_t v686 = 128;
          // pto: %454
          ;
          pto::Shape<1, 1, 1, 32, 128> v687 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %454
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v688 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %454
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v689 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v684 + (v685 + v683 * v686), v687, v688);
          TLOAD(v680, v689);
        } else {
          // pto: %455
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v690;
          // pto: %455
          ;
          uint64_t v691 = (uint64_t) v34;
          TASSIGN(v690, v691);
          // pto: %456
          ;
          int64_t v692 = v677 / v45;
          // pto: %457
          ;
          int64_t v693 = v692 < v50 ? v50 : v692;
          // pto: %458
          ;
          __gm__ int8_t* v694 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %458
          ;
          const int64_t v695 = 0;
          // pto: %458
          ;
          const int64_t v696 = 128;
          // pto: %458
          ;
          pto::Shape<1, 1, 1, 32, 128> v697 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %458
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v698 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %458
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v699 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v694 + (v695 + v693 * v696), v697, v698);
          TLOAD(v690, v699);
        };
        // pto: %468, %469
        ;
        int64_t v700 = (int64_t) ((uint64_t) v643 + (uint64_t) v61) / v64;
        // pto: %473
        ;
        int64_t v701 = v700 < v230 ? v700 : v230;
        // pto: %476, %474
        ;
        int32_t v702 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v701)];
        // pto: %477
        ;
        int64_t v703 = (int64_t) v702;
        // pto: %478
        ;
        int64_t v704 = v703 < v50 ? v50 : v703;
        // pto: %479
        ;
        int64_t v705 = (int64_t) ((uint64_t) v704 * (uint64_t) v17);
        // pto: %480
        ;
        int64_t v706 = v705 % v45;
        // pto: %481, %482, %483
        ;
        int64_t v707 = v706 < v50 ? (int64_t) ((uint64_t) v706 + (uint64_t) v45) : v706;
        // pto: %484
        ;
        if (v707 == v50) {
          // pto: %485
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v708;
          // pto: %485
          ;
          uint64_t v709 = (uint64_t) v32;
          TASSIGN(v708, v709);
          // pto: %486
          ;
          int64_t v710 = v705 / v45;
          // pto: %487
          ;
          int64_t v711 = v710 < v50 ? v50 : v710;
          // pto: %488
          ;
          __gm__ int8_t* v712 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %488
          ;
          const int64_t v713 = 0;
          // pto: %488
          ;
          const int64_t v714 = 128;
          // pto: %488
          ;
          pto::Shape<1, 1, 1, 32, 128> v715 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %488
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v716 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %488
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v717 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v712 + (v713 + v711 * v714), v715, v716);
          TLOAD(v708, v717);
        } else {
          // pto: %489
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v718;
          // pto: %489
          ;
          uint64_t v719 = (uint64_t) v32;
          TASSIGN(v718, v719);
          // pto: %490
          ;
          int64_t v720 = v705 / v45;
          // pto: %491
          ;
          int64_t v721 = v720 < v50 ? v50 : v720;
          // pto: %492
          ;
          __gm__ int8_t* v722 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %492
          ;
          const int64_t v723 = 0;
          // pto: %492
          ;
          const int64_t v724 = 128;
          // pto: %492
          ;
          pto::Shape<1, 1, 1, 32, 128> v725 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %492
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v726 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %492
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v727 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v722 + (v723 + v721 * v724), v725, v726);
          TLOAD(v718, v727);
        };
        // pto: %502, %503
        ;
        int64_t v728 = (int64_t) ((uint64_t) v643 + (uint64_t) v47) / v64;
        // pto: %507
        ;
        int64_t v729 = v728 < v230 ? v728 : v230;
        // pto: %510, %508
        ;
        int32_t v730 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v729)];
        // pto: %511
        ;
        int64_t v731 = (int64_t) v730;
        // pto: %512
        ;
        int64_t v732 = v731 < v50 ? v50 : v731;
        // pto: %513
        ;
        int64_t v733 = (int64_t) ((uint64_t) v732 * (uint64_t) v17);
        // pto: %514
        ;
        int64_t v734 = v733 % v45;
        // pto: %515, %516, %517
        ;
        int64_t v735 = v734 < v50 ? (int64_t) ((uint64_t) v734 + (uint64_t) v45) : v734;
        // pto: %518
        ;
        if (v735 == v50) {
          // pto: %519
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v736;
          // pto: %519
          ;
          uint64_t v737 = (uint64_t) v30;
          TASSIGN(v736, v737);
          // pto: %520
          ;
          int64_t v738 = v733 / v45;
          // pto: %521
          ;
          int64_t v739 = v738 < v50 ? v50 : v738;
          // pto: %522
          ;
          __gm__ int8_t* v740 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %522
          ;
          const int64_t v741 = 0;
          // pto: %522
          ;
          const int64_t v742 = 128;
          // pto: %522
          ;
          pto::Shape<1, 1, 1, 32, 128> v743 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %522
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v744 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %522
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v745 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v740 + (v741 + v739 * v742), v743, v744);
          TLOAD(v736, v745);
        } else {
          // pto: %523
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v746;
          // pto: %523
          ;
          uint64_t v747 = (uint64_t) v30;
          TASSIGN(v746, v747);
          // pto: %524
          ;
          int64_t v748 = v733 / v45;
          // pto: %525
          ;
          int64_t v749 = v748 < v50 ? v50 : v748;
          // pto: %526
          ;
          __gm__ int8_t* v750 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %526
          ;
          const int64_t v751 = 0;
          // pto: %526
          ;
          const int64_t v752 = 128;
          // pto: %526
          ;
          pto::Shape<1, 1, 1, 32, 128> v753 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %526
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v754 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %526
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v755 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v750 + (v751 + v749 * v752), v753, v754);
          TLOAD(v746, v755);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        // pto: %t__tmp_v782
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v756 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %t__tmp_v782
        ;
        uint64_t v757 = (uint64_t) v40;
        TASSIGN(v756, v757);
        // pto: %buf_prefetched_key_inline9260__ssa_v18
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v758 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_prefetched_key_inline9260__ssa_v18
        ;
        uint64_t v759 = (uint64_t) v39;
        TASSIGN(v758, v759);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        TMOV(v758, v756);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        // pto: %buf_key_panel_inline9272__ssa_v10
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v760 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_key_panel_inline9272__ssa_v10
        ;
        uint64_t v761 = (uint64_t) v39;
        TASSIGN(v760, v761);
        // pto: %buf_scores_l1_inline9318__ssa_v12
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v762 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_l1_inline9318__ssa_v12
        ;
        uint64_t v763 = (uint64_t) v40;
        TASSIGN(v762, v763);
        // pto: %buf_previous_pair_inline9269__ssa_v3
        ;
        Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v764 = Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_previous_pair_inline9269__ssa_v3
        ;
        uint64_t v765 = (uint64_t) v41;
        TASSIGN(v764, v765);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        uint16_t v766 = static_cast<uint16_t>(v50);
        uint16_t v767 = static_cast<uint16_t>(v50);
        TEXTRACT(v764, v639, v766, v767);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
        // pto: %buf_scores_inline9403__ssa_v9
        ;
        Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v768 = Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_inline9403__ssa_v9
        ;
        uint64_t v769 = (uint64_t) v39;
        TASSIGN(v768, v769);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
        TMATMUL(v768, v216, v760);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
        // pto: %buf_reduced_pair_inline9267__ssa_v3
        ;
        Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v770 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v62, v45);
        // pto: %buf_reduced_pair_inline9267__ssa_v3
        ;
        uint64_t v771 = (uint64_t) v42;
        TASSIGN(v770, v771);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
        TMATMUL(v770, v218, v764);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID6);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
        uint64_t v772 = static_cast<uint64_t>(v65);
        uint16_t v773 = static_cast<uint16_t>(v50);
        uint16_t v774 = static_cast<uint16_t>(v50);
        TINSERT<Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v762, v768, v772, v773, v774);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID3);
        v770.SetValidShape(v63, v45);
        // pto: %530
        ;
        __gm__ float* v775 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %530
        ;
        const int64_t v776 = 256;
        // pto: %530
        ;
        const int64_t v777 = 768;
        // pto: %530
        ;
        pto::Shape<1, 1, 1, 2, 128> v778 = pto::Shape<1, 1, 1, 2, 128>();
        // pto: %530
        ;
        pto::Stride<1536, 1536, 1536, 768, 1> v779 = pto::Stride<1536, 1536, 1536, 768, 1>();
        // pto: %530
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND> v780 = GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND>(v775 + (v776 + v491 * v777), v778, v779);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID6);
        TSTORE(v780, v770);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
        // pto: %buf_previous_l1_inline9375__ssa_v4
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v781 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_previous_l1_inline9375__ssa_v4
        ;
        uint64_t v782 = (uint64_t) v40;
        TASSIGN(v781, v782);
        // pto: %buf_panel_keys_inline9242__ssa_v84
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v783 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_panel_keys_inline9242__ssa_v84
        ;
        uint64_t v784 = (uint64_t) v39;
        TASSIGN(v783, v784);
        // pto: %539, %540
        ;
        int64_t v785 = (int64_t) ((uint64_t) v643 + (uint64_t) v45) / v64;
        // pto: %544
        ;
        int64_t v786 = v785 < v230 ? v785 : v230;
        // pto: %547, %545
        ;
        int32_t v787 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v786)];
        // pto: %548
        ;
        int64_t v788 = (int64_t) v787;
        // pto: %549
        ;
        int64_t v789 = v788 < v50 ? v50 : v788;
        // pto: %550
        ;
        int64_t v790 = (int64_t) ((uint64_t) v789 * (uint64_t) v17);
        // pto: %551
        ;
        int64_t v791 = v790 % v45;
        // pto: %552, %553, %554
        ;
        int64_t v792 = v791 < v50 ? (int64_t) ((uint64_t) v791 + (uint64_t) v45) : v791;
        // pto: %555
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
        if (v792 == v50) {
          // pto: %556
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v793;
          // pto: %556
          ;
          uint64_t v794 = (uint64_t) v39;
          TASSIGN(v793, v794);
          // pto: %557
          ;
          int64_t v795 = v790 / v45;
          // pto: %558
          ;
          int64_t v796 = v795 < v50 ? v50 : v795;
          // pto: %559
          ;
          __gm__ int8_t* v797 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %559
          ;
          const int64_t v798 = 0;
          // pto: %559
          ;
          const int64_t v799 = 128;
          // pto: %559
          ;
          pto::Shape<1, 1, 1, 32, 128> v800 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %559
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v801 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %559
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v802 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v797 + (v798 + v796 * v799), v800, v801);
          TLOAD(v793, v802);
        } else {
          // pto: %560
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v803;
          // pto: %560
          ;
          uint64_t v804 = (uint64_t) v39;
          TASSIGN(v803, v804);
          // pto: %561
          ;
          int64_t v805 = v790 / v45;
          // pto: %562
          ;
          int64_t v806 = v805 < v50 ? v50 : v805;
          // pto: %563
          ;
          __gm__ int8_t* v807 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %563
          ;
          const int64_t v808 = 0;
          // pto: %563
          ;
          const int64_t v809 = 128;
          // pto: %563
          ;
          pto::Shape<1, 1, 1, 32, 128> v810 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %563
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v811 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %563
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v812 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v807 + (v808 + v806 * v809), v810, v811);
          TLOAD(v803, v812);
        };
        // pto: %573, %574
        ;
        int64_t v813 = (int64_t) ((uint64_t) v643 + (uint64_t) v35) / v64;
        // pto: %578
        ;
        int64_t v814 = v813 < v230 ? v813 : v230;
        // pto: %581, %579
        ;
        int32_t v815 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v814)];
        // pto: %582
        ;
        int64_t v816 = (int64_t) v815;
        // pto: %583
        ;
        int64_t v817 = v816 < v50 ? v50 : v816;
        // pto: %584
        ;
        int64_t v818 = (int64_t) ((uint64_t) v817 * (uint64_t) v17);
        // pto: %585
        ;
        int64_t v819 = v818 % v45;
        // pto: %586, %587, %588
        ;
        int64_t v820 = v819 < v50 ? (int64_t) ((uint64_t) v819 + (uint64_t) v45) : v819;
        // pto: %589
        ;
        if (v820 == v50) {
          // pto: %590
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v821;
          // pto: %590
          ;
          uint64_t v822 = (uint64_t) v38;
          TASSIGN(v821, v822);
          // pto: %591
          ;
          int64_t v823 = v818 / v45;
          // pto: %592
          ;
          int64_t v824 = v823 < v50 ? v50 : v823;
          // pto: %593
          ;
          __gm__ int8_t* v825 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %593
          ;
          const int64_t v826 = 0;
          // pto: %593
          ;
          const int64_t v827 = 128;
          // pto: %593
          ;
          pto::Shape<1, 1, 1, 32, 128> v828 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %593
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v829 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %593
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v830 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v825 + (v826 + v824 * v827), v828, v829);
          TLOAD(v821, v830);
        } else {
          // pto: %594
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v831;
          // pto: %594
          ;
          uint64_t v832 = (uint64_t) v38;
          TASSIGN(v831, v832);
          // pto: %595
          ;
          int64_t v833 = v818 / v45;
          // pto: %596
          ;
          int64_t v834 = v833 < v50 ? v50 : v833;
          // pto: %597
          ;
          __gm__ int8_t* v835 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %597
          ;
          const int64_t v836 = 0;
          // pto: %597
          ;
          const int64_t v837 = 128;
          // pto: %597
          ;
          pto::Shape<1, 1, 1, 32, 128> v838 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %597
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v839 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %597
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v840 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v835 + (v836 + v834 * v837), v838, v839);
          TLOAD(v831, v840);
        };
        // pto: %607, %608
        ;
        int64_t v841 = (int64_t) ((uint64_t) v643 + (uint64_t) v33) / v64;
        // pto: %612
        ;
        int64_t v842 = v841 < v230 ? v841 : v230;
        // pto: %615, %613
        ;
        int32_t v843 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v842)];
        // pto: %616
        ;
        int64_t v844 = (int64_t) v843;
        // pto: %617
        ;
        int64_t v845 = v844 < v50 ? v50 : v844;
        // pto: %618
        ;
        int64_t v846 = (int64_t) ((uint64_t) v845 * (uint64_t) v17);
        // pto: %619
        ;
        int64_t v847 = v846 % v45;
        // pto: %620, %621, %622
        ;
        int64_t v848 = v847 < v50 ? (int64_t) ((uint64_t) v847 + (uint64_t) v45) : v847;
        // pto: %623
        ;
        if (v848 == v50) {
          // pto: %624
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v849;
          // pto: %624
          ;
          uint64_t v850 = (uint64_t) v37;
          TASSIGN(v849, v850);
          // pto: %625
          ;
          int64_t v851 = v846 / v45;
          // pto: %626
          ;
          int64_t v852 = v851 < v50 ? v50 : v851;
          // pto: %627
          ;
          __gm__ int8_t* v853 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %627
          ;
          const int64_t v854 = 0;
          // pto: %627
          ;
          const int64_t v855 = 128;
          // pto: %627
          ;
          pto::Shape<1, 1, 1, 32, 128> v856 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %627
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v857 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %627
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v858 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v853 + (v854 + v852 * v855), v856, v857);
          TLOAD(v849, v858);
        } else {
          // pto: %628
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v859;
          // pto: %628
          ;
          uint64_t v860 = (uint64_t) v37;
          TASSIGN(v859, v860);
          // pto: %629
          ;
          int64_t v861 = v846 / v45;
          // pto: %630
          ;
          int64_t v862 = v861 < v50 ? v50 : v861;
          // pto: %631
          ;
          __gm__ int8_t* v863 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %631
          ;
          const int64_t v864 = 0;
          // pto: %631
          ;
          const int64_t v865 = 128;
          // pto: %631
          ;
          pto::Shape<1, 1, 1, 32, 128> v866 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %631
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v867 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %631
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v868 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v863 + (v864 + v862 * v865), v866, v867);
          TLOAD(v859, v868);
        };
        // pto: %641, %642
        ;
        int64_t v869 = (int64_t) ((uint64_t) v643 + (uint64_t) v31) / v64;
        // pto: %646
        ;
        int64_t v870 = v869 < v230 ? v869 : v230;
        // pto: %649, %647
        ;
        int32_t v871 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v870)];
        // pto: %650
        ;
        int64_t v872 = (int64_t) v871;
        // pto: %651
        ;
        int64_t v873 = v872 < v50 ? v50 : v872;
        // pto: %652
        ;
        int64_t v874 = (int64_t) ((uint64_t) v873 * (uint64_t) v17);
        // pto: %653
        ;
        int64_t v875 = v874 % v45;
        // pto: %654, %655, %656
        ;
        int64_t v876 = v875 < v50 ? (int64_t) ((uint64_t) v875 + (uint64_t) v45) : v875;
        // pto: %657
        ;
        if (v876 == v50) {
          // pto: %658
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v877;
          // pto: %658
          ;
          uint64_t v878 = (uint64_t) v36;
          TASSIGN(v877, v878);
          // pto: %659
          ;
          int64_t v879 = v874 / v45;
          // pto: %660
          ;
          int64_t v880 = v879 < v50 ? v50 : v879;
          // pto: %661
          ;
          __gm__ int8_t* v881 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %661
          ;
          const int64_t v882 = 0;
          // pto: %661
          ;
          const int64_t v883 = 128;
          // pto: %661
          ;
          pto::Shape<1, 1, 1, 32, 128> v884 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %661
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v885 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %661
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v886 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v881 + (v882 + v880 * v883), v884, v885);
          TLOAD(v877, v886);
        } else {
          // pto: %662
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v887;
          // pto: %662
          ;
          uint64_t v888 = (uint64_t) v36;
          TASSIGN(v887, v888);
          // pto: %663
          ;
          int64_t v889 = v874 / v45;
          // pto: %664
          ;
          int64_t v890 = v889 < v50 ? v50 : v889;
          // pto: %665
          ;
          __gm__ int8_t* v891 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %665
          ;
          const int64_t v892 = 0;
          // pto: %665
          ;
          const int64_t v893 = 128;
          // pto: %665
          ;
          pto::Shape<1, 1, 1, 32, 128> v894 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %665
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v895 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %665
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v896 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v891 + (v892 + v890 * v893), v894, v895);
          TLOAD(v887, v896);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
        // pto: %t__tmp_v788
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v897 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %t__tmp_v788
        ;
        uint64_t v898 = (uint64_t) v39;
        TASSIGN(v897, v898);
        // pto: %buf_prefetched_key_inline9260__ssa_v23
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v899 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_prefetched_key_inline9260__ssa_v23
        ;
        uint64_t v900 = (uint64_t) v39;
        TASSIGN(v899, v900);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
        TMOV(v899, v897);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        // pto: %buf_key_panel_inline9272__ssa_v13
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v901 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_key_panel_inline9272__ssa_v13
        ;
        uint64_t v902 = (uint64_t) v39;
        TASSIGN(v901, v902);
        // pto: %buf_scores_l1_inline9318__ssa_v16
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v903 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_l1_inline9318__ssa_v16
        ;
        uint64_t v904 = (uint64_t) v39;
        TASSIGN(v903, v904);
        // pto: %buf_previous_pair_inline9269__ssa_v4
        ;
        Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v905 = Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_previous_pair_inline9269__ssa_v4
        ;
        uint64_t v906 = (uint64_t) v41;
        TASSIGN(v905, v906);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID3);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        uint16_t v907 = static_cast<uint16_t>(v50);
        uint16_t v908 = static_cast<uint16_t>(v50);
        TEXTRACT(v905, v781, v907, v908);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline9403__ssa_v12
        ;
        Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v909 = Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_inline9403__ssa_v12
        ;
        uint64_t v910 = (uint64_t) v39;
        TASSIGN(v909, v910);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
        TMATMUL(v909, v216, v901);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID7);
        // pto: %buf_reduced_pair_inline9267__ssa_v4
        ;
        Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v911 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v62, v45);
        // pto: %buf_reduced_pair_inline9267__ssa_v4
        ;
        uint64_t v912 = (uint64_t) v42;
        TASSIGN(v911, v912);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
        TMATMUL(v911, v218, v905);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID7);
        uint64_t v913 = static_cast<uint64_t>(v65);
        uint16_t v914 = static_cast<uint16_t>(v50);
        uint16_t v915 = static_cast<uint16_t>(v50);
        TINSERT<Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v903, v909, v913, v914, v915);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID4);
        v911.SetValidShape(v63, v45);
        // pto: %669
        ;
        __gm__ float* v916 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %669
        ;
        const int64_t v917 = 384;
        // pto: %669
        ;
        const int64_t v918 = 768;
        // pto: %669
        ;
        pto::Shape<1, 1, 1, 2, 128> v919 = pto::Shape<1, 1, 1, 2, 128>();
        // pto: %669
        ;
        pto::Stride<1536, 1536, 1536, 768, 1> v920 = pto::Stride<1536, 1536, 1536, 768, 1>();
        // pto: %669
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND> v921 = GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND>(v916 + (v917 + v491 * v918), v919, v920);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        TSTORE(v921, v911);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline9375__ssa_v5
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v922 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_previous_l1_inline9375__ssa_v5
        ;
        uint64_t v923 = (uint64_t) v39;
        TASSIGN(v922, v923);
        // pto: %buf_panel_keys_inline9242__ssa_v105
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v924 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_panel_keys_inline9242__ssa_v105
        ;
        uint64_t v925 = (uint64_t) v40;
        TASSIGN(v924, v925);
        // pto: %678, %679
        ;
        int64_t v926 = (int64_t) ((uint64_t) v643 + (uint64_t) v66) / v64;
        // pto: %683
        ;
        int64_t v927 = v926 < v230 ? v926 : v230;
        // pto: %686, %684
        ;
        int32_t v928 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v927)];
        // pto: %687
        ;
        int64_t v929 = (int64_t) v928;
        // pto: %688
        ;
        int64_t v930 = v929 < v50 ? v50 : v929;
        // pto: %689
        ;
        int64_t v931 = (int64_t) ((uint64_t) v930 * (uint64_t) v17);
        // pto: %690
        ;
        int64_t v932 = v931 % v45;
        // pto: %691, %692, %693
        ;
        int64_t v933 = v932 < v50 ? (int64_t) ((uint64_t) v932 + (uint64_t) v45) : v932;
        // pto: %694
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
        if (v933 == v50) {
          // pto: %695
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v934;
          // pto: %695
          ;
          uint64_t v935 = (uint64_t) v40;
          TASSIGN(v934, v935);
          // pto: %696
          ;
          int64_t v936 = v931 / v45;
          // pto: %697
          ;
          int64_t v937 = v936 < v50 ? v50 : v936;
          // pto: %698
          ;
          __gm__ int8_t* v938 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %698
          ;
          const int64_t v939 = 0;
          // pto: %698
          ;
          const int64_t v940 = 128;
          // pto: %698
          ;
          pto::Shape<1, 1, 1, 32, 128> v941 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %698
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v942 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %698
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v943 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v938 + (v939 + v937 * v940), v941, v942);
          TLOAD(v934, v943);
        } else {
          // pto: %699
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v944;
          // pto: %699
          ;
          uint64_t v945 = (uint64_t) v40;
          TASSIGN(v944, v945);
          // pto: %700
          ;
          int64_t v946 = v931 / v45;
          // pto: %701
          ;
          int64_t v947 = v946 < v50 ? v50 : v946;
          // pto: %702
          ;
          __gm__ int8_t* v948 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %702
          ;
          const int64_t v949 = 0;
          // pto: %702
          ;
          const int64_t v950 = 128;
          // pto: %702
          ;
          pto::Shape<1, 1, 1, 32, 128> v951 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %702
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v952 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %702
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v953 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v948 + (v949 + v947 * v950), v951, v952);
          TLOAD(v944, v953);
        };
        // pto: %712, %713
        ;
        int64_t v954 = (int64_t) ((uint64_t) v643 + (uint64_t) v29) / v64;
        // pto: %717
        ;
        int64_t v955 = v954 < v230 ? v954 : v230;
        // pto: %720, %718
        ;
        int32_t v956 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v955)];
        // pto: %721
        ;
        int64_t v957 = (int64_t) v956;
        // pto: %722
        ;
        int64_t v958 = v957 < v50 ? v50 : v957;
        // pto: %723
        ;
        int64_t v959 = (int64_t) ((uint64_t) v958 * (uint64_t) v17);
        // pto: %724
        ;
        int64_t v960 = v959 % v45;
        // pto: %725, %726, %727
        ;
        int64_t v961 = v960 < v50 ? (int64_t) ((uint64_t) v960 + (uint64_t) v45) : v960;
        // pto: %728
        ;
        if (v961 == v50) {
          // pto: %729
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v962;
          // pto: %729
          ;
          uint64_t v963 = (uint64_t) v34;
          TASSIGN(v962, v963);
          // pto: %730
          ;
          int64_t v964 = v959 / v45;
          // pto: %731
          ;
          int64_t v965 = v964 < v50 ? v50 : v964;
          // pto: %732
          ;
          __gm__ int8_t* v966 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %732
          ;
          const int64_t v967 = 0;
          // pto: %732
          ;
          const int64_t v968 = 128;
          // pto: %732
          ;
          pto::Shape<1, 1, 1, 32, 128> v969 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %732
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v970 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %732
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v971 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v966 + (v967 + v965 * v968), v969, v970);
          TLOAD(v962, v971);
        } else {
          // pto: %733
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v972;
          // pto: %733
          ;
          uint64_t v973 = (uint64_t) v34;
          TASSIGN(v972, v973);
          // pto: %734
          ;
          int64_t v974 = v959 / v45;
          // pto: %735
          ;
          int64_t v975 = v974 < v50 ? v50 : v974;
          // pto: %736
          ;
          __gm__ int8_t* v976 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %736
          ;
          const int64_t v977 = 0;
          // pto: %736
          ;
          const int64_t v978 = 128;
          // pto: %736
          ;
          pto::Shape<1, 1, 1, 32, 128> v979 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %736
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v980 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %736
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v981 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v976 + (v977 + v975 * v978), v979, v980);
          TLOAD(v972, v981);
        };
        // pto: %746, %747
        ;
        int64_t v982 = (int64_t) ((uint64_t) v643 + (uint64_t) v28) / v64;
        // pto: %751
        ;
        int64_t v983 = v982 < v230 ? v982 : v230;
        // pto: %754, %752
        ;
        int32_t v984 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v983)];
        // pto: %755
        ;
        int64_t v985 = (int64_t) v984;
        // pto: %756
        ;
        int64_t v986 = v985 < v50 ? v50 : v985;
        // pto: %757
        ;
        int64_t v987 = (int64_t) ((uint64_t) v986 * (uint64_t) v17);
        // pto: %758
        ;
        int64_t v988 = v987 % v45;
        // pto: %759, %760, %761
        ;
        int64_t v989 = v988 < v50 ? (int64_t) ((uint64_t) v988 + (uint64_t) v45) : v988;
        // pto: %762
        ;
        if (v989 == v50) {
          // pto: %763
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v990;
          // pto: %763
          ;
          uint64_t v991 = (uint64_t) v32;
          TASSIGN(v990, v991);
          // pto: %764
          ;
          int64_t v992 = v987 / v45;
          // pto: %765
          ;
          int64_t v993 = v992 < v50 ? v50 : v992;
          // pto: %766
          ;
          __gm__ int8_t* v994 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %766
          ;
          const int64_t v995 = 0;
          // pto: %766
          ;
          const int64_t v996 = 128;
          // pto: %766
          ;
          pto::Shape<1, 1, 1, 32, 128> v997 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %766
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v998 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %766
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v999 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v994 + (v995 + v993 * v996), v997, v998);
          TLOAD(v990, v999);
        } else {
          // pto: %767
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1000;
          // pto: %767
          ;
          uint64_t v1001 = (uint64_t) v32;
          TASSIGN(v1000, v1001);
          // pto: %768
          ;
          int64_t v1002 = v987 / v45;
          // pto: %769
          ;
          int64_t v1003 = v1002 < v50 ? v50 : v1002;
          // pto: %770
          ;
          __gm__ int8_t* v1004 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %770
          ;
          const int64_t v1005 = 0;
          // pto: %770
          ;
          const int64_t v1006 = 128;
          // pto: %770
          ;
          pto::Shape<1, 1, 1, 32, 128> v1007 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %770
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1008 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %770
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1009 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1004 + (v1005 + v1003 * v1006), v1007, v1008);
          TLOAD(v1000, v1009);
        };
        // pto: %780, %781
        ;
        int64_t v1010 = (int64_t) ((uint64_t) v643 + (uint64_t) v27) / v64;
        // pto: %785
        ;
        int64_t v1011 = v1010 < v230 ? v1010 : v230;
        // pto: %788, %786
        ;
        int32_t v1012 = (v10)[(int64_t) ((uint64_t) v232 + (uint64_t) v1011)];
        // pto: %789
        ;
        int64_t v1013 = (int64_t) v1012;
        // pto: %790
        ;
        int64_t v1014 = v1013 < v50 ? v50 : v1013;
        // pto: %791
        ;
        int64_t v1015 = (int64_t) ((uint64_t) v1014 * (uint64_t) v17);
        // pto: %792
        ;
        int64_t v1016 = v1015 % v45;
        // pto: %793, %794, %795
        ;
        int64_t v1017 = v1016 < v50 ? (int64_t) ((uint64_t) v1016 + (uint64_t) v45) : v1016;
        // pto: %796
        ;
        if (v1017 == v50) {
          // pto: %797
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1018;
          // pto: %797
          ;
          uint64_t v1019 = (uint64_t) v30;
          TASSIGN(v1018, v1019);
          // pto: %798
          ;
          int64_t v1020 = v1015 / v45;
          // pto: %799
          ;
          int64_t v1021 = v1020 < v50 ? v50 : v1020;
          // pto: %800
          ;
          __gm__ int8_t* v1022 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %800
          ;
          const int64_t v1023 = 0;
          // pto: %800
          ;
          const int64_t v1024 = 128;
          // pto: %800
          ;
          pto::Shape<1, 1, 1, 32, 128> v1025 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %800
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1026 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %800
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1027 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1022 + (v1023 + v1021 * v1024), v1025, v1026);
          TLOAD(v1018, v1027);
        } else {
          // pto: %801
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1028;
          // pto: %801
          ;
          uint64_t v1029 = (uint64_t) v30;
          TASSIGN(v1028, v1029);
          // pto: %802
          ;
          int64_t v1030 = v1015 / v45;
          // pto: %803
          ;
          int64_t v1031 = v1030 < v50 ? v50 : v1030;
          // pto: %804
          ;
          __gm__ int8_t* v1032 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %804
          ;
          const int64_t v1033 = 0;
          // pto: %804
          ;
          const int64_t v1034 = 128;
          // pto: %804
          ;
          pto::Shape<1, 1, 1, 32, 128> v1035 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %804
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1036 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %804
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1037 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1032 + (v1033 + v1031 * v1034), v1035, v1036);
          TLOAD(v1028, v1037);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
        // pto: %t__tmp_v794
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1038 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %t__tmp_v794
        ;
        uint64_t v1039 = (uint64_t) v40;
        TASSIGN(v1038, v1039);
        // pto: %buf_prefetched_key_inline9260__ssa_v28
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1040 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_prefetched_key_inline9260__ssa_v28
        ;
        uint64_t v1041 = (uint64_t) v39;
        TASSIGN(v1040, v1041);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        TMOV(v1040, v1038);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_key_panel_inline9272__ssa_v16
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1042 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_key_panel_inline9272__ssa_v16
        ;
        uint64_t v1043 = (uint64_t) v39;
        TASSIGN(v1042, v1043);
        // pto: %buf_scores_l1_inline9318__ssa_v20
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1044 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_l1_inline9318__ssa_v20
        ;
        uint64_t v1045 = (uint64_t) v40;
        TASSIGN(v1044, v1045);
        // pto: %buf_previous_pair_inline9269__ssa_v5
        ;
        Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1046 = Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_previous_pair_inline9269__ssa_v5
        ;
        uint64_t v1047 = (uint64_t) v41;
        TASSIGN(v1046, v1047);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID4);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v1048 = static_cast<uint16_t>(v50);
        uint16_t v1049 = static_cast<uint16_t>(v50);
        TEXTRACT(v1046, v922, v1048, v1049);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %buf_scores_inline9403__ssa_v15
        ;
        Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1050 = Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_inline9403__ssa_v15
        ;
        uint64_t v1051 = (uint64_t) v39;
        TASSIGN(v1050, v1051);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1050, v216, v1042);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline9267__ssa_v5
        ;
        Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1052 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v62, v45);
        // pto: %buf_reduced_pair_inline9267__ssa_v5
        ;
        uint64_t v1053 = (uint64_t) v42;
        TASSIGN(v1052, v1053);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1052, v218, v1046);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1054 = static_cast<uint64_t>(v65);
        uint16_t v1055 = static_cast<uint16_t>(v50);
        uint16_t v1056 = static_cast<uint16_t>(v50);
        TINSERT<Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1044, v1050, v1054, v1055, v1056);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID5);
        v1052.SetValidShape(v63, v45);
        // pto: %808
        ;
        __gm__ float* v1057 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %808
        ;
        const int64_t v1058 = 512;
        // pto: %808
        ;
        const int64_t v1059 = 768;
        // pto: %808
        ;
        pto::Shape<1, 1, 1, 2, 128> v1060 = pto::Shape<1, 1, 1, 2, 128>();
        // pto: %808
        ;
        pto::Stride<1536, 1536, 1536, 768, 1> v1061 = pto::Stride<1536, 1536, 1536, 768, 1>();
        // pto: %808
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND> v1062 = GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND>(v1057 + (v1058 + v491 * v1059), v1060, v1061);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1062, v1052);
        // pto: %buf_previous_l1_inline9375__ssa_v6
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1063 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_previous_l1_inline9375__ssa_v6
        ;
        uint64_t v1064 = (uint64_t) v40;
        TASSIGN(v1063, v1064);
        // pto: %buf_last_pair_inline9348__ssa_v0
        ;
        Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1065 = Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_last_pair_inline9348__ssa_v0
        ;
        uint64_t v1066 = (uint64_t) v41;
        TASSIGN(v1065, v1066);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID5);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1067 = static_cast<uint16_t>(v50);
        uint16_t v1068 = static_cast<uint16_t>(v50);
        TEXTRACT(v1065, v1063, v1067, v1068);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_last_scores_inline9341__ssa_v0
        ;
        Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1069 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v62, v45);
        // pto: %buf_last_scores_inline9341__ssa_v0
        ;
        uint64_t v1070 = (uint64_t) v39;
        TASSIGN(v1069, v1070);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        TMATMUL(v1069, v218, v1065);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        v1069.SetValidShape(v63, v45);
        // pto: %810
        ;
        __gm__ float* v1071 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %810
        ;
        const int64_t v1072 = 640;
        // pto: %810
        ;
        const int64_t v1073 = 768;
        // pto: %810
        ;
        pto::Shape<1, 1, 1, 2, 128> v1074 = pto::Shape<1, 1, 1, 2, 128>();
        // pto: %810
        ;
        pto::Stride<1536, 1536, 1536, 768, 1> v1075 = pto::Stride<1536, 1536, 1536, 768, 1>();
        // pto: %810
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND> v1076 = GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND>(v1071 + (v1072 + v491 * v1073), v1074, v1075);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        pipe_barrier(PIPE_FIX);
        TSTORE(v1076, v1069);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        uint16_t v1077 = getFFTSMsg(FFTS_MODE_VAL, v50);
        ffts_cross_core_sync(PIPE_FIX, v1077);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      // pto: %811
      ;
      for (int64_t v1078 = v50; v1078 < (v194 < v63 ? v194 : v63); v1078 += v43) {
        int32_t v1079 = (int32_t) v43;
        wait_flag_dev(v1079);
      };
    };
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void indexer_score_topk_native_pair_2_aiv(__gm__ int32_t* v1, __gm__ int32_t* v2, __gm__ int64_t* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, __gm__ int64_t* v7, __gm__ int8_t* v8, __gm__ half* v9, __gm__ int32_t* v10, __gm__ int8_t* v11, __gm__ int8_t* v12, __gm__ float* v13, __gm__ int8_t* v14, __gm__ float* v15, __gm__ float* v16, int64_t v17, int64_t v18, int64_t v19, int64_t v20, int64_t v21, int64_t v22, int64_t v23, int64_t v24, int32_t v25, int32_t v26, int32_t v27) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  pto::MrgSortExecutedNumList v28 = pto::MrgSortExecutedNumList{0, 0, 0, 0};
  // pto: %c28672_i64
  const int64_t v29 = 28672;
  // pto: %c61440_i64
  const int64_t v30 = 61440;
  // pto: %c12288_i64
  const int64_t v31 = 12288;
  const int64_t v32 = 30208;
  const int64_t v33 = 32768;
  const int64_t v34 = 45056;
  // pto: %c0_i64
  const int64_t v35 = 0;
  const int64_t v36 = 49152;
  const int64_t v37 = 77824;
  // pto: %c1_index
  const int64_t v38 = 1;
  // pto: %c432_index
  const int64_t v39 = 432;
  // pto: %c27648_index
  const int64_t v40 = 27648;
  // pto: %c96_index
  const int64_t v41 = 96;
  // pto: %c768_index
  const int64_t v42 = 768;
  // pto: %c8192_index
  const int64_t v43 = 8192;
  // pto: %c1024_index
  const int64_t v44 = 1024;
  // pto: %c0_index
  const int64_t v45 = 0;
  // pto: %c4_index
  const int64_t v46 = 4;
  // pto: %c262144_index
  const int64_t v47 = 262144;
  // pto: %c8191_index
  const int64_t v48 = 8191;
  // pto: %c24_index
  const int64_t v49 = 24;
  // pto: %c1_i64
  const int64_t v50 = 1;
  // pto: %c4_i64
  const int64_t v51 = 4;
  // pto: %c767_index
  const int64_t v52 = 767;
  // pto: %c384_index
  const int64_t v53 = 384;
  // pto: %c4096_index
  const int64_t v54 = 4096;
  // pto: %c383_index
  const int64_t v55 = 383;
  // pto: %c2_index
  const int64_t v56 = 2;
  // pto: %c12_index
  const int64_t v57 = 12;
  // pto: %c32_index
  const int64_t v58 = 32;
  // pto: %c64_index
  const int64_t v59 = 64;
  // pto: %c512_index
  const int64_t v60 = 512;
  // pto: %c192_index
  const int64_t v61 = 192;
  // pto: %c0_i32
  const int32_t v62 = 0;
  // pto: %cst_36
  const float v63 = -3.40282347E+38f;
  // pto: %c64_i32
  const int32_t v64 = 64;
  // pto: %c256_i32
  const int32_t v65 = 256;
  // pto: %c2048_index
  const int64_t v66 = 2048;
  // pto: %c1024_i32
  const int32_t v67 = 1024;
  // pto: %c2560_index
  const int64_t v68 = 2560;
  // pto: %c5120_index
  const int64_t v69 = 5120;
  // pto: %c3072_index
  const int64_t v70 = 3072;
  // pto: %c6144_index
  const int64_t v71 = 6144;
  // pto: %buf_score_transfer_inline9298__ssa_v0_view
  const int64_t v72 = 1;
  // pto: %buf_score_transfer_inline9298__ssa_v0_view
  const int64_t v73 = 1;
  // pto: %buf_score_transfer_inline9298__ssa_v0_view
  const int64_t v74 = 1;
  // pto: %buf_score_transfer_inline9298__ssa_v0_view
  int64_t v75 = v41 * v42;
  // pto: %buf_score_transfer_inline9298__ssa_v0_view
  int64_t v76 = v74 * v75;
  // pto: %buf_score_transfer_inline9298__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v77 = pto::Shape<1, 1, 1, -1, -1>(v72, v73, v74, v41, v42);
  // pto: %buf_score_transfer_inline9298__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v78 = pto::Stride<-1, -1, -1, -1, -1>(v73 * v76, v76, v75, v42, v38);
  // pto: %buf_score_transfer_inline9298__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v79 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v77, v78);
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v80 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v81 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v82 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v83 = (int64_t) v23;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v84 = (int64_t) v24;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v85 = v83 * v84;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v86 = v82 * v85;
  // pto: %idx_native_kv_cache__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v87 = pto::Shape<1, 1, 1, -1, -1>(v80, v81, v82, v83, (int64_t) v24);
  // pto: %idx_native_kv_cache__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v88 = pto::Stride<-1, -1, -1, -1, -1>(v81 * v86, v86, v85, v84, v38);
  // pto: %idx_native_kv_cache__rv_v2_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v89 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v87, v88);
  // pto: %score_arena_inline1388_inline5078__ssa_v0_view
  const int64_t v90 = 1;
  // pto: %score_arena_inline1388_inline5078__ssa_v0_view
  const int64_t v91 = 1;
  // pto: %score_arena_inline1388_inline5078__ssa_v0_view
  const int64_t v92 = 1;
  // pto: %score_arena_inline1388_inline5078__ssa_v0_view
  int64_t v93 = v39 * v43;
  // pto: %score_arena_inline1388_inline5078__ssa_v0_view
  int64_t v94 = v92 * v93;
  // pto: %score_arena_inline1388_inline5078__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v95 = pto::Shape<1, 1, 1, -1, -1>(v90, v91, v92, v39, v43);
  // pto: %score_arena_inline1388_inline5078__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v96 = pto::Stride<-1, -1, -1, -1, -1>(v91 * v94, v94, v93, v43, v38);
  // pto: %score_arena_inline1388_inline5078__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v97 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v95, v96);
  // pto: %pair_arena_inline1403_inline5090__ssa_v0_view
  const int64_t v98 = 1;
  // pto: %pair_arena_inline1403_inline5090__ssa_v0_view
  const int64_t v99 = 1;
  // pto: %pair_arena_inline1403_inline5090__ssa_v0_view
  const int64_t v100 = 1;
  // pto: %pair_arena_inline1403_inline5090__ssa_v0_view
  int64_t v101 = v40 * v44;
  // pto: %pair_arena_inline1403_inline5090__ssa_v0_view
  int64_t v102 = v100 * v101;
  // pto: %pair_arena_inline1403_inline5090__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v103 = pto::Shape<1, 1, 1, -1, -1>(v98, v99, v100, v40, v44);
  // pto: %pair_arena_inline1403_inline5090__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v104 = pto::Stride<-1, -1, -1, -1, -1>(v99 * v102, v102, v101, v44, v38);
  // pto: %pair_arena_inline1403_inline5090__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v105 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v103, v104);
  // pto: %buf_worker_inline9397__ssa_v0
  int64_t v106 = (int64_t) v25;
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  // pto: %buf_max_cache_len_inline9304__rv_v2
  int64_t v107;
  v107 = v45;
  for (int64_t v108 = v45; v108 < v18; v108 += v38) {
    // pto: %t__tile
    ;
    int32_t v109 = (v1)[v108];
    // pto: %0, %1
    ;
    int64_t v110 = (int64_t) v109 / v46;
    // pto: %2
    ;
    bool v111 = v107 < v110;
    // pto: %2
    ;
    int64_t v112 = v111 ? v110 : v107;
    v107 = v112;
  }
  // pto: %3
  bool v113 = v107 < v47;
  // pto: %3
  int64_t v114 = v113 ? v107 : v47;
  // pto: %4, %5
  int64_t v115 = (int64_t) ((uint64_t) v114 + (uint64_t) v48) / v43;
  // pto: %6
  int64_t v116 = v115 < v38 ? v38 : v115;
  // pto: %7
  int32_t v117 = (v2)[v45];
  // pto: %8
  int64_t v118 = (int64_t) v117;
  uint64_t v119 = reinterpret_cast<uint64_t>(v3);
  set_ffts_base_addr(v119);
  // pto: %buf_score_lane_inline9365__ssa_v0
  int64_t v120 = (int64_t) v27;
  // pto: %9
  for (int64_t v121 = v106; v121 < ((int64_t) ((uint64_t) v118 * (uint64_t) v116)); v121 += v49) {
    // pto: %10
    ;
    // pto: %buf_group_inline9381__phi_v5
    ;
    int64_t v122;
    // pto: %buf_leaf_inline9296__phi_v5
    ;
    int64_t v123;
    if (v118 < v49) {
      // pto: %11
      ;
      int64_t v124 = v121 % v118;
      // pto: %15, %12, %13, %14, %16, %17, %18
      ;
      // pto: %19
      ;
      v122 = v124 != v45 & (v124 < v45 ^ v118 < v45) ? (int64_t) ((uint64_t) v124 + (uint64_t) v118) : v124;
      v123 = v121 / v118;
    } else {
      // pto: %20
      ;
      // pto: %21
      ;
      int64_t v125 = v121 % v116;
      // pto: %25, %22, %23, %24, %26, %27, %28
      ;
      v122 = v121 / v116;
      v123 = v125 != v45 & (v125 < v45 ^ v116 < v45) ? (int64_t) ((uint64_t) v125 + (uint64_t) v116) : v125;
    };
    // pto: %29
    ;
    int32_t v126 = (v4)[v122];
    // pto: %30
    ;
    int64_t v127 = (int64_t) v126;
    // pto: %31
    ;
    int32_t v128 = (v5)[v122];
    // pto: %32
    ;
    int64_t v129 = (int64_t) v128;
    // pto: %33
    ;
    int32_t v130 = (v6)[v127];
    // pto: %34
    ;
    int64_t v131 = (int64_t) v130;
    // pto: %35, %36, %buf_last_position_inline9360__tile
    ;
    int64_t v132 = (v7)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v127 + (uint64_t) v129) - (uint64_t) v38)];
    // pto: %37
    ;
    int32_t v133 = (v1)[v131];
    // pto: %38, %39
    ;
    int64_t v134 = (int64_t) v133 / v46;
    // pto: %40, %41
    ;
    int64_t v135 = (int64_t) ((uint64_t) v132 + (uint64_t) v50) / v51;
    // pto: %43
    ;
    int64_t v136 = v134 < v135 ? v134 : v135;
    // pto: %44
    ;
    int64_t v137 = v136 < v47 ? v136 : v47;
    // pto: %45
    ;
    int64_t v138 = v137 < v45 ? v45 : v137;
    // pto: %46
    ;
    uint64_t v139 = (uint64_t) v123;
    // pto: %46
    ;
    int64_t v140 = (int64_t) (v139 * (uint64_t) v43);
    // pto: %47
    ;
    if (v140 < v138) {
      // pto: %48
      ;
      int64_t v141 = (int64_t) ((uint64_t) v138 - (uint64_t) v140);
      // pto: %49
      ;
      int64_t v142 = v141 < v43 ? v141 : v43;
      // pto: %50, %51, %52
      ;
      int64_t v143 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v142 + (uint64_t) v52) / v42) * (uint64_t) v53);
      // pto: %53
      ;
      int64_t v144 = v143 < v54 ? v143 : v54;
      // pto: %54, %55
      ;
      // pto: %56
      ;
      int64_t v145 = (int64_t) ((uint64_t) v120 * (uint64_t) v144);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      for (int64_t v146 = v45; v146 < ((int64_t) ((uint64_t) v144 + (uint64_t) v55) / v53); v146 += v38) {
        // pto: %57
        ;
        int64_t v147 = (int64_t) ((uint64_t) v146 * (uint64_t) v53);
        // pto: %58
        ;
        int64_t v148 = (int64_t) ((uint64_t) v106 * (uint64_t) v46);
        // pto: %59
        ;
        int64_t v149 = v146 % v56;
        // pto: %60, %61, %62
        ;
        int64_t v150 = v149 < v45 ? (int64_t) ((uint64_t) v149 + (uint64_t) v56) : v149;
        // pto: %64, %63
        ;
        int64_t v151 = (int64_t) ((uint64_t) v148 + (uint64_t) ((int64_t) (uint64_t) v150 * (uint64_t) v56));
        // pto: %buf_scale_bytes_inline9444__ssa_v0
        ;
        Tile<TileType::Vec, int8_t, 1, 768, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v152 = Tile<TileType::Vec, int8_t, 1, 768, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v42);
        // pto: %buf_scale_bytes_inline9444__ssa_v0
        ;
        uint64_t v153 = (uint64_t) v29;
        TASSIGN(v152, v153);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        for (int64_t v154 = v45; v154 < v57; v154 += v38) {
          // pto: %65, %66, %68, %67, %69
          ;
          int64_t v155 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v140 + (uint64_t) v147) + (uint64_t) v145) + (uint64_t) ((int64_t) (uint64_t) v154 * (uint64_t) v58)) / v58;
          // pto: %70, %71
          ;
          int64_t v156 = (int64_t) ((uint64_t) v134 - (uint64_t) v38) / v58;
          // pto: %72
          ;
          int64_t v157 = v156 < v45 ? v45 : v156;
          // pto: %73
          ;
          int64_t v158 = v155 < v157 ? v155 : v157;
          // pto: %flat_offset_mul, %flat_offset, %74
          ;
          int32_t v159 = (v10)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v131 * (uint64_t) v20) + (uint64_t) v158)];
          // pto: %75
          ;
          int64_t v160 = (int64_t) v159;
          // pto: %76
          ;
          int64_t v161 = v160 < v45 ? v45 : v160;
          // pto: %gather_row_view
          ;
          Tile<TileType::Vec, int8_t, 1, 768, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v162;
          // pto: %77, %gather_row_view
          ;
          uint64_t v163 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v154 * (uint64_t) v59) + (uint64_t) v29);
          TASSIGN(v162, v163);
          // pto: %78
          ;
          int64_t v164 = v161 < v45 ? v45 : v161;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v165 = (int64_t) v24;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v166 = 0;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          __gm__ int8_t* v167 = PTOAS__GLOBAL_TENSOR_DATA(v89);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v168 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v169 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v170 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v171 = v38 * v165;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v172 = v170 * v171;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          pto::Shape<1, 1, 1, 1, 64> v173 = pto::Shape<1, 1, 1, 1, 64>(v168, v169, v170, v38, v59);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v174 = pto::Stride<-1, -1, -1, -1, -1>(v169 * v172, v172, v171, v165, v38);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v175 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v167 + (v166 + v164 * v165 + v54 * v38), v173, v174);
          TLOAD(v162, v175);
        };
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %buf_scale_half_inline9367__ssa_v0
        ;
        Tile<TileType::Vec, half, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v176 = Tile<TileType::Vec, half, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v53);
        // pto: %buf_scale_half_inline9367__ssa_v0
        ;
        uint64_t v177 = (uint64_t) v29;
        TASSIGN(v176, v177);
        // pto: %buf_kv_scale_inline9448__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v178 = Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v53);
        // pto: %buf_kv_scale_inline9448__ssa_v0
        ;
        uint64_t v179 = (uint64_t) v30;
        TASSIGN(v178, v179);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v180 = RoundMode::CAST_ROUND;
        SaturationMode v181 = SaturationMode::ON;
        TCVT(v178, v176, v180, v181);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        int32_t v182 = (int32_t) v45;
        wait_flag_dev(v182);
        // pto: %buf_score_sums_inline9328__ssa_v0
        ;
        Tile<TileType::Vec, float, 2, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Vec, float, 2, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v56, v53);
        // pto: %buf_score_sums_inline9328__ssa_v0
        ;
        uint64_t v184 = (uint64_t) v29;
        TASSIGN(v183, v184);
        // pto: %79
        ;
        int64_t v185 = v151 < v45 ? v45 : v151;
        // pto: %80
        ;
        int64_t v186 = (int64_t) ((uint64_t) v120 * (uint64_t) v53);
        // pto: %81
        ;
        int64_t v187 = v186 < v45 ? v45 : v186;
        // pto: %buf_score_transfer_inline9298__ssa_v0_pview
        ;
        __gm__ float* v188 = PTOAS__GLOBAL_TENSOR_DATA(v79);
        // pto: %buf_score_transfer_inline9298__ssa_v0_pview
        ;
        const int64_t v189 = 0;
        // pto: %buf_score_transfer_inline9298__ssa_v0_pview
        ;
        const int64_t v190 = 768;
        // pto: %buf_score_transfer_inline9298__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 2, 384> v191 = pto::Shape<1, 1, 1, 2, 384>();
        // pto: %buf_score_transfer_inline9298__ssa_v0_pview
        ;
        pto::Stride<1536, 1536, 1536, 768, 1> v192 = pto::Stride<1536, 1536, 1536, 768, 1>();
        // pto: %buf_score_transfer_inline9298__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 2, 384>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND> v193 = GlobalTensor<float, pto::Shape<1, 1, 1, 2, 384>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND>(v188 + (v189 + v185 * v190 + v187), v191, v192);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        TLOAD(v183, v193);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        uint16_t v194 = getFFTSMsg(FFTS_MODE_VAL, v38);
        ffts_cross_core_sync(PIPE_MTE2, v194);
        // pto: %83
        ;
        int64_t v195 = (int64_t) ((uint64_t) v129 - (uint64_t) v38);
        // pto: %84
        ;
        int64_t v196 = v195 < v45 ? v195 : v45;
        // pto: %85, %buf_position_inline9457__tile
        ;
        int64_t v197 = (v7)[(int64_t) ((uint64_t) v127 + (uint64_t) v196)];
        // pto: %86, %87
        ;
        int64_t v198 = (int64_t) ((uint64_t) v197 + (uint64_t) v50) / v51;
        // pto: %89
        ;
        int64_t v199 = v134 < v198 ? v134 : v198;
        // pto: %90
        ;
        int64_t v200 = v199 < v47 ? v199 : v47;
        // pto: %91
        ;
        int64_t v201 = v200 < v45 ? v45 : v200;
        // pto: %92, %93, %94
        ;
        int64_t v202 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v201 - (uint64_t) v140) - (uint64_t) v147) - (uint64_t) v145);
        // pto: %95
        ;
        int64_t v203 = v202 < v53 ? v202 : v53;
        // pto: %96
        ;
        int64_t v204 = v203 < v45 ? v45 : v203;
        // pto: %97
        ;
        int64_t v205 = (int64_t) ((uint64_t) v144 - (uint64_t) v147);
        // pto: %98
        ;
        int64_t v206 = v205 < v45 ? v45 : v205;
        // pto: %99
        ;
        int64_t v207 = v204 < v206 ? v204 : v206;
        // pto: %buf_score_sum_inline9462__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v208 = Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v53);
        // pto: %buf_score_sum_inline9462__ssa_v0
        ;
        uint64_t v209 = (uint64_t) v29;
        TASSIGN(v208, v209);
        // pto: %slice_view
        ;
        Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, 1, 384, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v210;
        // pto: %slice_view
        ;
        uint64_t v211 = (uint64_t) v29;
        TASSIGN(v210, v211);
        // pto: %buf_score_row_inline9464__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v212 = Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v53);
        // pto: %buf_score_row_inline9464__ssa_v0
        ;
        uint64_t v213 = (uint64_t) v31;
        TASSIGN(v212, v213);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        TMUL(v212, v210, v178);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %101
        ;
        bool v214 = v116 > v38;
        // pto: %100, %buf_store_column_inline9336__phi_v2
        ;
        int64_t v215 = v214 ? v147 : (int64_t) ((uint64_t) v147 + (uint64_t) v145);
        // pto: %buf_store_row_inline9465__phi_v2
        ;
        int64_t v216;
        if (v214) {
          // pto: %103
          ;
          v216 = (int64_t) ((uint64_t) v148 + (uint64_t) v120);
        } else {
          v216 = v127;
        };
        // pto: %104, %82, %105
        ;
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        if (v207 > v45 & v129 > v45) {
          v212.SetValidShape(v38, v207);
          // pto: %106
          ;
          bool v217 = v216 < v45;
          // pto: %106
          ;
          int64_t v218 = v217 ? v45 : v216;
          // pto: %107
          ;
          int64_t v219 = v215 < v45 ? v45 : v215;
          // pto: %score_arena_inline1388_inline5078__ssa_v0_pview
          ;
          const int64_t v220 = 0;
          // pto: %score_arena_inline1388_inline5078__ssa_v0_pview
          ;
          __gm__ float* v221 = PTOAS__GLOBAL_TENSOR_DATA(v97);
          // pto: %score_arena_inline1388_inline5078__ssa_v0_pview
          ;
          const int64_t v222 = 1;
          // pto: %score_arena_inline1388_inline5078__ssa_v0_pview
          ;
          const int64_t v223 = 1;
          // pto: %score_arena_inline1388_inline5078__ssa_v0_pview
          ;
          const int64_t v224 = 1;
          // pto: %score_arena_inline1388_inline5078__ssa_v0_pview
          ;
          int64_t v225 = v38 * v43;
          // pto: %score_arena_inline1388_inline5078__ssa_v0_pview
          ;
          int64_t v226 = v224 * v225;
          // pto: %score_arena_inline1388_inline5078__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 1, -1> v227 = pto::Shape<1, 1, 1, 1, -1>(v222, v223, v224, v38, v207);
          // pto: %score_arena_inline1388_inline5078__ssa_v0_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v228 = pto::Stride<-1, -1, -1, -1, -1>(v223 * v226, v226, v225, v43, v38);
          // pto: %score_arena_inline1388_inline5078__ssa_v0_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v229 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v221 + (v220 + v218 * v43 + v219 * v38), v227, v228);
          TSTORE(v229, v212);
        };
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        // pto: %111
        ;
        int64_t v230 = v195 < v38 ? v195 : v38;
        // pto: %112, %109
        ;
        int64_t v231 = (v7)[(int64_t) ((uint64_t) v127 + (uint64_t) v230)];
        // pto: %113, %114
        ;
        int64_t v232 = (int64_t) ((uint64_t) v231 + (uint64_t) v50) / v51;
        // pto: %116
        ;
        int64_t v233 = v134 < v232 ? v134 : v232;
        // pto: %117
        ;
        int64_t v234 = v233 < v47 ? v233 : v47;
        // pto: %118
        ;
        int64_t v235 = v234 < v45 ? v45 : v234;
        // pto: %119, %120, %121
        ;
        int64_t v236 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v235 - (uint64_t) v140) - (uint64_t) v147) - (uint64_t) v145);
        // pto: %122
        ;
        int64_t v237 = v236 < v53 ? v236 : v53;
        // pto: %123
        ;
        int64_t v238 = v237 < v45 ? v45 : v237;
        // pto: %126
        ;
        int64_t v239 = v238 < v206 ? v238 : v206;
        // pto: %buf_score_sum_inline9462__ssa_v1
        ;
        Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v240 = Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v53);
        // pto: %buf_score_sum_inline9462__ssa_v1
        ;
        uint64_t v241 = (uint64_t) v32;
        TASSIGN(v240, v241);
        // pto: %127
        ;
        Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, 1, 384, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v242;
        // pto: %127
        ;
        uint64_t v243 = (uint64_t) v32;
        TASSIGN(v242, v243);
        // pto: %buf_score_row_inline9464__ssa_v1
        ;
        Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v244 = Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v53);
        // pto: %buf_score_row_inline9464__ssa_v1
        ;
        uint64_t v245 = (uint64_t) v29;
        TASSIGN(v244, v245);
        pipe_barrier(PIPE_V);
        TMUL(v244, v242, v178);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        // pto: %128
        ;
        // pto: %buf_store_column_inline9336__phi_v5
        ;
        int64_t v246;
        if (v214) {
          // pto: %132, %133
          ;
          v246 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v148 + (uint64_t) v120) + (uint64_t) v56);
        } else {
          v246 = (int64_t) ((uint64_t) v127 + (uint64_t) v38);
        };
        // pto: %134, %108, %135
        ;
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        if (v239 > v45 & v129 > v38) {
          v244.SetValidShape(v38, v239);
          // pto: %136
          ;
          bool v247 = v246 < v45;
          // pto: %136
          ;
          int64_t v248 = v247 ? v45 : v246;
          // pto: %137
          ;
          int64_t v249 = v215 < v45 ? v45 : v215;
          // pto: %138
          ;
          const int64_t v250 = 0;
          // pto: %138
          ;
          __gm__ float* v251 = PTOAS__GLOBAL_TENSOR_DATA(v97);
          // pto: %138
          ;
          const int64_t v252 = 1;
          // pto: %138
          ;
          const int64_t v253 = 1;
          // pto: %138
          ;
          const int64_t v254 = 1;
          // pto: %138
          ;
          int64_t v255 = v38 * v43;
          // pto: %138
          ;
          int64_t v256 = v254 * v255;
          // pto: %138
          ;
          pto::Shape<1, 1, 1, 1, -1> v257 = pto::Shape<1, 1, 1, 1, -1>(v252, v253, v254, v38, v239);
          // pto: %138
          ;
          pto::Stride<-1, -1, -1, -1, -1> v258 = pto::Stride<-1, -1, -1, -1, -1>(v253 * v256, v256, v255, v43, v38);
          // pto: %138
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v259 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v251 + (v250 + v248 * v43 + v249 * v38), v257, v258);
          pipe_barrier(PIPE_MTE3);
          TSTORE(v259, v244);
        };
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      // pto: %139
      ;
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      if (v116 > v38) {
        // pto: %140
        ;
        if (v129 > v45) {
          // pto: %141
          ;
          int64_t v260 = (v7)[v127];
          // pto: %142, %143
          ;
          int64_t v261 = (int64_t) ((uint64_t) v260 + (uint64_t) v50) / v51;
          // pto: %145
          ;
          int64_t v262 = v134 < v261 ? v134 : v261;
          // pto: %146
          ;
          int64_t v263 = v262 < v47 ? v262 : v47;
          // pto: %147
          ;
          int64_t v264 = v263 < v45 ? v45 : v263;
          // pto: %148
          ;
          int64_t v265 = (int64_t) ((uint64_t) v140 + (uint64_t) v145);
          // pto: %149
          ;
          int64_t v266 = (int64_t) ((uint64_t) v264 - (uint64_t) v265);
          // pto: %150
          ;
          int64_t v267 = v266 < v144 ? v266 : v144;
          // pto: %151
          ;
          int64_t v268 = v267 < v45 ? v45 : v267;
          // pto: %153
          ;
          uint64_t v269 = (uint64_t) v123;
          // pto: %152, %154, %153, %155
          ;
          int64_t v270 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v127 * (uint64_t) v59) + (uint64_t) ((int64_t) v269 * (uint64_t) v56)) + (uint64_t) v120);
          // pto: %156
          ;
          if (v268 > v45) {
            // pto: %157
            ;
            int32_t v271 = (int32_t) v265;
            // pto: %158
            ;
            if (v268 <= v60) {
              // pto: %t__ci_tmp_v0
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v272 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
              // pto: %t__ci_tmp_v0
              ;
              uint64_t v273 = (uint64_t) v30;
              TASSIGN(v272, v273);
              // pto: %t__tmp_v804
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v274 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v60);
              // pto: %t__tmp_v804
              ;
              uint64_t v275 = (uint64_t) v29;
              TASSIGN(v274, v275);
              // pto: %ci_tmp_view
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v276;
              TRESHAPE(v276, v272);
              // pto: %ci_dst_view
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v277;
              TRESHAPE(v277, v274);
              pipe_barrier(PIPE_V);
              TCI<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v277, v62, v276);
              // pto: %short_indices_inline1549_inline9373__ssa_v0
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v278 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v60);
              // pto: %short_indices_inline1549_inline9373__ssa_v0
              ;
              uint64_t v279 = (uint64_t) v30;
              TASSIGN(v278, v279);
              pipe_barrier(PIPE_V);
              TADDS(v278, v274, v271);
              set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
              // pto: %short_raw_inline1516_inline9488__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v280 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v268);
              // pto: %short_raw_inline1516_inline9488__ssa_v0
              ;
              uint64_t v281 = (uint64_t) v29;
              TASSIGN(v280, v281);
              // pto: %159, %160
              ;
              int64_t v282 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v120);
              // pto: %161
              ;
              int64_t v283 = v282 < v45 ? v45 : v282;
              // pto: %162
              ;
              const int64_t v284 = 0;
              // pto: %162
              ;
              __gm__ float* v285 = PTOAS__GLOBAL_TENSOR_DATA(v97);
              // pto: %162
              ;
              const int64_t v286 = 1;
              // pto: %162
              ;
              const int64_t v287 = 1;
              // pto: %162
              ;
              const int64_t v288 = 1;
              // pto: %162
              ;
              int64_t v289 = v38 * v43;
              // pto: %162
              ;
              int64_t v290 = v288 * v289;
              // pto: %162
              ;
              pto::Shape<1, 1, 1, 1, -1> v291 = pto::Shape<1, 1, 1, 1, -1>(v286, v287, v288, v38, v268);
              // pto: %162
              ;
              pto::Stride<-1, -1, -1, -1, -1> v292 = pto::Stride<-1, -1, -1, -1, -1>(v287 * v290, v290, v289, v43, v38);
              // pto: %162
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v293 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v285 + (v284 + v283 * v43 + v45 * v38), v291, v292);
              wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
              TLOAD(v280, v293);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
              // pto: %short_scores_inline1517_inline9407__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v294 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v60);
              // pto: %short_scores_inline1517_inline9407__ssa_v0
              ;
              uint64_t v295 = (uint64_t) v29;
              TASSIGN(v294, v295);
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
              TFILLPAD<pto::TFillPadMode::InPlace>(v294, v280);
              // pto: %short_scores_v1_inline1519_inline9261__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v296 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v60);
              // pto: %short_scores_v1_inline1519_inline9261__ssa_v0
              ;
              uint64_t v297 = (uint64_t) v31;
              TASSIGN(v296, v297);
              pipe_barrier(PIPE_V);
              TMAXS(v296, v294, v63);
              // pto: %t__tmp_v805
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v60);
              // pto: %t__tmp_v805
              ;
              uint64_t v299 = (uint64_t) v30;
              TASSIGN(v298, v299);
              // pto: %short_pairs_inline1547_inline9489__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v300 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
              // pto: %short_pairs_inline1547_inline9489__ssa_v0
              ;
              uint64_t v301 = (uint64_t) v29;
              TASSIGN(v300, v301);
              // pto: %sort32_src_view
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v302;
              TRESHAPE(v302, v296);
              // pto: %sort32_idx_view
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v303;
              TRESHAPE(v303, v298);
              // pto: %sort32_dst_view
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v304;
              TRESHAPE(v304, v300);
              pipe_barrier(PIPE_V);
              TSORT32(v304, v302, v303);
              // pto: %short_pairs_v1_inline1511_inline9491__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v305 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
              // pto: %short_pairs_v1_inline1511_inline9491__ssa_v0
              ;
              uint64_t v306 = (uint64_t) v30;
              TASSIGN(v305, v306);
              pipe_barrier(PIPE_V);
              TMRGSORT(v305, v300, v64);
              // pto: %short_pairs_v2_inline1502_inline9492__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v307 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
              // pto: %short_pairs_v2_inline1502_inline9492__ssa_v0
              ;
              uint64_t v308 = (uint64_t) v29;
              TASSIGN(v307, v308);
              pipe_barrier(PIPE_V);
              TMRGSORT(v307, v305, v65);
              set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
              // pto: %163
              ;
              int64_t v309 = v270 < v45 ? v45 : v270;
              // pto: %pair_arena_inline1403_inline5090__ssa_v0_pview
              ;
              __gm__ float* v310 = PTOAS__GLOBAL_TENSOR_DATA(v105);
              // pto: %pair_arena_inline1403_inline5090__ssa_v0_pview
              ;
              const int64_t v311 = 0;
              // pto: %pair_arena_inline1403_inline5090__ssa_v0_pview
              ;
              const int64_t v312 = 1024;
              // pto: %pair_arena_inline1403_inline5090__ssa_v0_pview
              ;
              pto::Shape<1, 1, 1, 1, 1024> v313 = pto::Shape<1, 1, 1, 1, 1024>();
              // pto: %pair_arena_inline1403_inline5090__ssa_v0_pview
              ;
              pto::Stride<1024, 1024, 1024, 1024, 1> v314 = pto::Stride<1024, 1024, 1024, 1024, 1>();
              // pto: %pair_arena_inline1403_inline5090__ssa_v0_pview
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v315 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v310 + (v311 + v309 * v312), v313, v314);
              wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
              pipe_barrier(PIPE_MTE3);
              TSTORE(v315, v307);
            } else {
              // pto: %164
              ;
              if (v268 <= v44) {
                // pto: %t__ci_tmp_v1
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v316 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
                // pto: %t__ci_tmp_v1
                ;
                uint64_t v317 = (uint64_t) v30;
                TASSIGN(v316, v317);
                // pto: %t__tmp_v806
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v318 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v44);
                // pto: %t__tmp_v806
                ;
                uint64_t v319 = (uint64_t) v29;
                TASSIGN(v318, v319);
                // pto: %165
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v320;
                TRESHAPE(v320, v316);
                // pto: %166
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v321;
                TRESHAPE(v321, v318);
                pipe_barrier(PIPE_V);
                TCI<Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v321, v62, v320);
                // pto: %small_indices_inline1510_inline9417__ssa_v0
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v322 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v44);
                // pto: %small_indices_inline1510_inline9417__ssa_v0
                ;
                uint64_t v323 = (uint64_t) v30;
                TASSIGN(v322, v323);
                pipe_barrier(PIPE_V);
                TADDS(v322, v318, v271);
                set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
                // pto: %small_raw_inline1534_inline9398__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v324 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v268);
                // pto: %small_raw_inline1534_inline9398__ssa_v0
                ;
                uint64_t v325 = (uint64_t) v29;
                TASSIGN(v324, v325);
                // pto: %167, %168
                ;
                int64_t v326 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v120);
                // pto: %169
                ;
                int64_t v327 = v326 < v45 ? v45 : v326;
                // pto: %170
                ;
                const int64_t v328 = 0;
                // pto: %170
                ;
                __gm__ float* v329 = PTOAS__GLOBAL_TENSOR_DATA(v97);
                // pto: %170
                ;
                const int64_t v330 = 1;
                // pto: %170
                ;
                const int64_t v331 = 1;
                // pto: %170
                ;
                const int64_t v332 = 1;
                // pto: %170
                ;
                int64_t v333 = v38 * v43;
                // pto: %170
                ;
                int64_t v334 = v332 * v333;
                // pto: %170
                ;
                pto::Shape<1, 1, 1, 1, -1> v335 = pto::Shape<1, 1, 1, 1, -1>(v330, v331, v332, v38, v268);
                // pto: %170
                ;
                pto::Stride<-1, -1, -1, -1, -1> v336 = pto::Stride<-1, -1, -1, -1, -1>(v331 * v334, v334, v333, v43, v38);
                // pto: %170
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v337 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v329 + (v328 + v327 * v43 + v45 * v38), v335, v336);
                wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
                TLOAD(v324, v337);
                set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
                // pto: %small_scores_inline1527_inline9493__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v338 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                // pto: %small_scores_inline1527_inline9493__ssa_v0
                ;
                uint64_t v339 = (uint64_t) v29;
                TASSIGN(v338, v339);
                wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
                TFILLPAD<pto::TFillPadMode::InPlace>(v338, v324);
                // pto: %small_scores_v1_inline1512_inline9439__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v340 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                // pto: %small_scores_v1_inline1512_inline9439__ssa_v0
                ;
                uint64_t v341 = (uint64_t) v31;
                TASSIGN(v340, v341);
                pipe_barrier(PIPE_V);
                TMAXS(v340, v338, v63);
                // pto: %t__tmp_v807
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v342 = Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v44);
                // pto: %t__tmp_v807
                ;
                uint64_t v343 = (uint64_t) v30;
                TASSIGN(v342, v343);
                // pto: %small_pairs_inline1538_inline9494__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v344 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                // pto: %small_pairs_inline1538_inline9494__ssa_v0
                ;
                uint64_t v345 = (uint64_t) v29;
                TASSIGN(v344, v345);
                // pto: %171
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v346;
                TRESHAPE(v346, v340);
                // pto: %172
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v347;
                TRESHAPE(v347, v342);
                // pto: %173
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v348;
                TRESHAPE(v348, v344);
                pipe_barrier(PIPE_V);
                TSORT32(v348, v346, v347);
                // pto: %small_pairs_v1_inline1544_inline9455__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v349 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                // pto: %small_pairs_v1_inline1544_inline9455__ssa_v0
                ;
                uint64_t v350 = (uint64_t) v30;
                TASSIGN(v349, v350);
                pipe_barrier(PIPE_V);
                TMRGSORT(v349, v344, v64);
                // pto: %small_pairs_v2_inline1504_inline9486__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v351 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                // pto: %small_pairs_v2_inline1504_inline9486__ssa_v0
                ;
                uint64_t v352 = (uint64_t) v29;
                TASSIGN(v351, v352);
                pipe_barrier(PIPE_V);
                TMRGSORT(v351, v349, v65);
                // pto: %small_left_inline1526_inline9352__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v353 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                // pto: %small_left_inline1526_inline9352__ssa_v0
                ;
                uint64_t v354 = (uint64_t) v29;
                TASSIGN(v353, v354);
                // pto: %174
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v355;
                // pto: %174
                ;
                uint64_t v356 = (uint64_t) v29;
                TASSIGN(v355, v356);
                // pto: %small_right_inline1509_inline9497__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v357 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                // pto: %small_right_inline1509_inline9497__ssa_v0
                ;
                uint64_t v358 = (uint64_t) v33;
                TASSIGN(v357, v358);
                // pto: %175
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v359;
                // pto: %175
                ;
                uint64_t v360 = (uint64_t) v33;
                TASSIGN(v359, v360);
                // pto: %small_tmp_inline1503_inline9498__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v361 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                // pto: %small_tmp_inline1503_inline9498__ssa_v0
                ;
                uint64_t v362 = (uint64_t) v30;
                TASSIGN(v361, v362);
                // pto: %small_merged_inline1536_inline9278__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v363 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                // pto: %small_merged_inline1536_inline9278__ssa_v0
                ;
                uint64_t v364 = (uint64_t) v31;
                TASSIGN(v363, v364);
                pipe_barrier(PIPE_V);
                TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v363, v28, v361, v355, v359);
                set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
                // pto: %small_top_inline1501_inline9271__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v365 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                // pto: %small_top_inline1501_inline9271__ssa_v0
                ;
                uint64_t v366 = (uint64_t) v31;
                TASSIGN(v365, v366);
                // pto: %176
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v367;
                // pto: %176
                ;
                uint64_t v368 = (uint64_t) v31;
                TASSIGN(v367, v368);
                // pto: %177
                ;
                int64_t v369 = v270 < v45 ? v45 : v270;
                // pto: %178
                ;
                __gm__ float* v370 = PTOAS__GLOBAL_TENSOR_DATA(v105);
                // pto: %178
                ;
                const int64_t v371 = 0;
                // pto: %178
                ;
                const int64_t v372 = 1024;
                // pto: %178
                ;
                pto::Shape<1, 1, 1, 1, 1024> v373 = pto::Shape<1, 1, 1, 1, 1024>();
                // pto: %178
                ;
                pto::Stride<1024, 1024, 1024, 1024, 1> v374 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                // pto: %178
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v375 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v370 + (v371 + v369 * v372), v373, v374);
                wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
                pipe_barrier(PIPE_MTE3);
                TSTORE(v375, v367);
              } else {
                // pto: %179
                ;
                if (v268 <= v66) {
                  // pto: %t__ci_tmp_v2
                  ;
                  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v376 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
                  // pto: %t__ci_tmp_v2
                  ;
                  uint64_t v377 = (uint64_t) v30;
                  TASSIGN(v376, v377);
                  // pto: %t__tmp_v808
                  ;
                  Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v378 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                  // pto: %t__tmp_v808
                  ;
                  uint64_t v379 = (uint64_t) v29;
                  TASSIGN(v378, v379);
                  // pto: %180
                  ;
                  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v380;
                  TRESHAPE(v380, v376);
                  // pto: %181
                  ;
                  Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v381;
                  TRESHAPE(v381, v378);
                  pipe_barrier(PIPE_V);
                  TCI<Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v381, v62, v380);
                  // pto: %leaf_indices_inline1500_inline9500__ssa_v0
                  ;
                  Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v382 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                  // pto: %leaf_indices_inline1500_inline9500__ssa_v0
                  ;
                  uint64_t v383 = (uint64_t) v30;
                  TASSIGN(v382, v383);
                  pipe_barrier(PIPE_V);
                  TADDS(v382, v378, v271);
                  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
                  // pto: %leaf_scores_raw_inline1525_inline9499__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v384 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v268);
                  // pto: %leaf_scores_raw_inline1525_inline9499__ssa_v0
                  ;
                  uint64_t v385 = (uint64_t) v29;
                  TASSIGN(v384, v385);
                  // pto: %182, %183
                  ;
                  int64_t v386 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v120);
                  // pto: %184
                  ;
                  int64_t v387 = v386 < v45 ? v45 : v386;
                  // pto: %185
                  ;
                  const int64_t v388 = 0;
                  // pto: %185
                  ;
                  __gm__ float* v389 = PTOAS__GLOBAL_TENSOR_DATA(v97);
                  // pto: %185
                  ;
                  const int64_t v390 = 1;
                  // pto: %185
                  ;
                  const int64_t v391 = 1;
                  // pto: %185
                  ;
                  const int64_t v392 = 1;
                  // pto: %185
                  ;
                  int64_t v393 = v38 * v43;
                  // pto: %185
                  ;
                  int64_t v394 = v392 * v393;
                  // pto: %185
                  ;
                  pto::Shape<1, 1, 1, 1, -1> v395 = pto::Shape<1, 1, 1, 1, -1>(v390, v391, v392, v38, v268);
                  // pto: %185
                  ;
                  pto::Stride<-1, -1, -1, -1, -1> v396 = pto::Stride<-1, -1, -1, -1, -1>(v391 * v394, v394, v393, v43, v38);
                  // pto: %185
                  ;
                  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v397 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v389 + (v388 + v387 * v43 + v45 * v38), v395, v396);
                  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
                  TLOAD(v384, v397);
                  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
                  // pto: %leaf_scores_inline1531_inline9289__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v398 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                  // pto: %leaf_scores_inline1531_inline9289__ssa_v0
                  ;
                  uint64_t v399 = (uint64_t) v29;
                  TASSIGN(v398, v399);
                  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
                  TFILLPAD<pto::TFillPadMode::InPlace>(v398, v384);
                  // pto: %leaf_scores_v1_inline1499_inline9241__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v400 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                  // pto: %leaf_scores_v1_inline1499_inline9241__ssa_v0
                  ;
                  uint64_t v401 = (uint64_t) v31;
                  TASSIGN(v400, v401);
                  pipe_barrier(PIPE_V);
                  TMAXS(v400, v398, v63);
                  // pto: %t__tmp_v809
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v402 = Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                  // pto: %t__tmp_v809
                  ;
                  uint64_t v403 = (uint64_t) v30;
                  TASSIGN(v402, v403);
                  // pto: %pairs_inline1508_inline9501__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v404 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                  // pto: %pairs_inline1508_inline9501__ssa_v0
                  ;
                  uint64_t v405 = (uint64_t) v29;
                  TASSIGN(v404, v405);
                  // pto: %186
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v406;
                  TRESHAPE(v406, v400);
                  // pto: %187
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v407;
                  TRESHAPE(v407, v402);
                  // pto: %188
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v408;
                  TRESHAPE(v408, v404);
                  pipe_barrier(PIPE_V);
                  TSORT32(v408, v406, v407);
                  // pto: %pairs_v1_inline1530_inline9251__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v409 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                  // pto: %pairs_v1_inline1530_inline9251__ssa_v0
                  ;
                  uint64_t v410 = (uint64_t) v30;
                  TASSIGN(v409, v410);
                  pipe_barrier(PIPE_V);
                  TMRGSORT(v409, v404, v64);
                  // pto: %pairs_v2_inline1528_inline9329__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v411 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                  // pto: %pairs_v2_inline1528_inline9329__ssa_v0
                  ;
                  uint64_t v412 = (uint64_t) v29;
                  TASSIGN(v411, v412);
                  pipe_barrier(PIPE_V);
                  TMRGSORT(v411, v409, v65);
                  // pto: %pairs_v3_inline1521_inline9343__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v413 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                  // pto: %pairs_v3_inline1521_inline9343__ssa_v0
                  ;
                  uint64_t v414 = (uint64_t) v30;
                  TASSIGN(v413, v414);
                  pipe_barrier(PIPE_V);
                  TMRGSORT(v413, v411, v67);
                  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
                  // pto: %t__tmp_v810
                  ;
                  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v415 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                  // pto: %t__tmp_v810
                  ;
                  uint64_t v416 = (uint64_t) v30;
                  TASSIGN(v415, v416);
                  // pto: %189
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v417;
                  // pto: %189
                  ;
                  uint64_t v418 = (uint64_t) v30;
                  TASSIGN(v417, v418);
                  // pto: %190
                  ;
                  int64_t v419 = v270 < v45 ? v45 : v270;
                  // pto: %191
                  ;
                  __gm__ float* v420 = PTOAS__GLOBAL_TENSOR_DATA(v105);
                  // pto: %191
                  ;
                  const int64_t v421 = 0;
                  // pto: %191
                  ;
                  const int64_t v422 = 1024;
                  // pto: %191
                  ;
                  pto::Shape<1, 1, 1, 1, 1024> v423 = pto::Shape<1, 1, 1, 1, 1024>();
                  // pto: %191
                  ;
                  pto::Stride<1024, 1024, 1024, 1024, 1> v424 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                  // pto: %191
                  ;
                  GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v425 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v420 + (v421 + v419 * v422), v423, v424);
                  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
                  pipe_barrier(PIPE_MTE3);
                  TSTORE(v425, v417);
                } else {
                  // pto: %192
                  ;
                  if (v268 <= v68) {
                    // pto: %t__ci_tmp_v3
                    ;
                    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v426 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
                    // pto: %t__ci_tmp_v3
                    ;
                    uint64_t v427 = (uint64_t) v30;
                    TASSIGN(v426, v427);
                    // pto: %t__tmp_v811
                    ;
                    Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v428 = Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v68);
                    // pto: %t__tmp_v811
                    ;
                    uint64_t v429 = (uint64_t) v29;
                    TASSIGN(v428, v429);
                    // pto: %193
                    ;
                    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v430;
                    TRESHAPE(v430, v426);
                    // pto: %194
                    ;
                    Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v431;
                    TRESHAPE(v431, v428);
                    pipe_barrier(PIPE_V);
                    TCI<Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v431, v62, v430);
                    // pto: %partial_indices_inline1535_inline9502__ssa_v0
                    ;
                    Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v432 = Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v68);
                    // pto: %partial_indices_inline1535_inline9502__ssa_v0
                    ;
                    uint64_t v433 = (uint64_t) v30;
                    TASSIGN(v432, v433);
                    pipe_barrier(PIPE_V);
                    TADDS(v432, v428, v271);
                    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
                    // pto: %partial_raw_inline1540_inline9504__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v434 = Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v268);
                    // pto: %partial_raw_inline1540_inline9504__ssa_v0
                    ;
                    uint64_t v435 = (uint64_t) v29;
                    TASSIGN(v434, v435);
                    // pto: %195, %196
                    ;
                    int64_t v436 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v120);
                    // pto: %197
                    ;
                    int64_t v437 = v436 < v45 ? v45 : v436;
                    // pto: %198
                    ;
                    const int64_t v438 = 0;
                    // pto: %198
                    ;
                    __gm__ float* v439 = PTOAS__GLOBAL_TENSOR_DATA(v97);
                    // pto: %198
                    ;
                    const int64_t v440 = 1;
                    // pto: %198
                    ;
                    const int64_t v441 = 1;
                    // pto: %198
                    ;
                    const int64_t v442 = 1;
                    // pto: %198
                    ;
                    int64_t v443 = v38 * v43;
                    // pto: %198
                    ;
                    int64_t v444 = v442 * v443;
                    // pto: %198
                    ;
                    pto::Shape<1, 1, 1, 1, -1> v445 = pto::Shape<1, 1, 1, 1, -1>(v440, v441, v442, v38, v268);
                    // pto: %198
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v446 = pto::Stride<-1, -1, -1, -1, -1>(v441 * v444, v444, v443, v43, v38);
                    // pto: %198
                    ;
                    GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v447 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v439 + (v438 + v437 * v43 + v45 * v38), v445, v446);
                    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
                    TLOAD(v434, v447);
                    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
                    // pto: %partial_scores_inline1524_inline9505__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v448 = Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v68);
                    // pto: %partial_scores_inline1524_inline9505__ssa_v0
                    ;
                    uint64_t v449 = (uint64_t) v29;
                    TASSIGN(v448, v449);
                    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
                    TFILLPAD<pto::TFillPadMode::InPlace>(v448, v434);
                    // pto: %partial_scores_v1_inline1542_inline9506__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v450 = Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v68);
                    // pto: %partial_scores_v1_inline1542_inline9506__ssa_v0
                    ;
                    uint64_t v451 = (uint64_t) v31;
                    TASSIGN(v450, v451);
                    pipe_barrier(PIPE_V);
                    TMAXS(v450, v448, v63);
                    // pto: %t__tmp_v812
                    ;
                    Tile<TileType::Vec, uint32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v452 = Tile<TileType::Vec, uint32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v68);
                    // pto: %t__tmp_v812
                    ;
                    uint64_t v453 = (uint64_t) v30;
                    TASSIGN(v452, v453);
                    // pto: %partial_pairs_inline1532_inline9507__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v454 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v69);
                    // pto: %partial_pairs_inline1532_inline9507__ssa_v0
                    ;
                    uint64_t v455 = (uint64_t) v29;
                    TASSIGN(v454, v455);
                    // pto: %199
                    ;
                    Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v456;
                    TRESHAPE(v456, v450);
                    // pto: %200
                    ;
                    Tile<TileType::Vec, uint32_t, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v457;
                    TRESHAPE(v457, v452);
                    // pto: %201
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 5120, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v458;
                    TRESHAPE(v458, v454);
                    pipe_barrier(PIPE_V);
                    TSORT32(v458, v456, v457);
                    // pto: %partial_pairs_v1_inline1543_inline9361__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v459 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v69);
                    // pto: %partial_pairs_v1_inline1543_inline9361__ssa_v0
                    ;
                    uint64_t v460 = (uint64_t) v30;
                    TASSIGN(v459, v460);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v459, v454, v64);
                    // pto: %partial_pairs_v2_inline1546_inline9287__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v461 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v69);
                    // pto: %partial_pairs_v2_inline1546_inline9287__ssa_v0
                    ;
                    uint64_t v462 = (uint64_t) v29;
                    TASSIGN(v461, v462);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v461, v459, v65);
                    v461.SetValidShape(v38, v54);
                    // pto: %partial_prefix_v1_inline1548_inline9238__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v463 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v69);
                    // pto: %partial_prefix_v1_inline1548_inline9238__ssa_v0
                    ;
                    uint64_t v464 = (uint64_t) v30;
                    TASSIGN(v463, v464);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v463, v461, v67);
                    // pto: %partial_left_inline1550_inline9495__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v465 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                    // pto: %partial_left_inline1550_inline9495__ssa_v0
                    ;
                    uint64_t v466 = (uint64_t) v30;
                    TASSIGN(v465, v466);
                    // pto: %202
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v467;
                    // pto: %202
                    ;
                    uint64_t v468 = (uint64_t) v30;
                    TASSIGN(v467, v468);
                    // pto: %partial_right_inline1541_inline9237__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v469 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                    // pto: %partial_right_inline1541_inline9237__ssa_v0
                    ;
                    uint64_t v470 = (uint64_t) v34;
                    TASSIGN(v469, v470);
                    // pto: %203
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v471;
                    // pto: %203
                    ;
                    uint64_t v472 = (uint64_t) v34;
                    TASSIGN(v471, v472);
                    // pto: %partial_tmp_inline1522_inline9236__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v473 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                    // pto: %partial_tmp_inline1522_inline9236__ssa_v0
                    ;
                    uint64_t v474 = (uint64_t) v31;
                    TASSIGN(v473, v474);
                    // pto: %partial_merged_inline1529_inline9235__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v475 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                    // pto: %partial_merged_inline1529_inline9235__ssa_v0
                    ;
                    uint64_t v476 = (uint64_t) v35;
                    TASSIGN(v475, v476);
                    pipe_barrier(PIPE_V);
                    TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v475, v28, v473, v471, v467);
                    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
                    // pto: %t__tmp_v813
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v477 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                    // pto: %t__tmp_v813
                    ;
                    uint64_t v478 = (uint64_t) v35;
                    TASSIGN(v477, v478);
                    // pto: %205
                    ;
                    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v479;
                    // pto: %205
                    ;
                    uint64_t v480 = (uint64_t) v35;
                    TASSIGN(v479, v480);
                    // pto: %206
                    ;
                    int64_t v481 = v270 < v45 ? v45 : v270;
                    // pto: %207
                    ;
                    __gm__ float* v482 = PTOAS__GLOBAL_TENSOR_DATA(v105);
                    // pto: %207
                    ;
                    const int64_t v483 = 0;
                    // pto: %207
                    ;
                    const int64_t v484 = 1024;
                    // pto: %207
                    ;
                    pto::Shape<1, 1, 1, 1, 1024> v485 = pto::Shape<1, 1, 1, 1, 1024>();
                    // pto: %207
                    ;
                    pto::Stride<1024, 1024, 1024, 1024, 1> v486 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                    // pto: %207
                    ;
                    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v487 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v482 + (v483 + v481 * v484), v485, v486);
                    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
                    TSTORE(v487, v479);
                  } else {
                    // pto: %208
                    ;
                    if (v268 <= v70) {
                      // pto: %t__ci_tmp_v4
                      ;
                      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v488 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
                      // pto: %t__ci_tmp_v4
                      ;
                      uint64_t v489 = (uint64_t) v30;
                      TASSIGN(v488, v489);
                      // pto: %t__tmp_v814
                      ;
                      Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v490 = Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v70);
                      // pto: %t__tmp_v814
                      ;
                      uint64_t v491 = (uint64_t) v29;
                      TASSIGN(v490, v491);
                      // pto: %209
                      ;
                      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v492;
                      TRESHAPE(v492, v488);
                      // pto: %210
                      ;
                      Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v493;
                      TRESHAPE(v493, v490);
                      pipe_barrier(PIPE_V);
                      TCI<Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v493, v62, v492);
                      // pto: %triple_indices_inline1551_inline9234__ssa_v0
                      ;
                      Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v494 = Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v70);
                      // pto: %triple_indices_inline1551_inline9234__ssa_v0
                      ;
                      uint64_t v495 = (uint64_t) v30;
                      TASSIGN(v494, v495);
                      pipe_barrier(PIPE_V);
                      TADDS(v494, v490, v271);
                      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
                      // pto: %triple_raw_inline1515_inline9233__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v496 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v268);
                      // pto: %triple_raw_inline1515_inline9233__ssa_v0
                      ;
                      uint64_t v497 = (uint64_t) v29;
                      TASSIGN(v496, v497);
                      // pto: %211, %212
                      ;
                      int64_t v498 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v120);
                      // pto: %213
                      ;
                      int64_t v499 = v498 < v45 ? v45 : v498;
                      // pto: %214
                      ;
                      const int64_t v500 = 0;
                      // pto: %214
                      ;
                      __gm__ float* v501 = PTOAS__GLOBAL_TENSOR_DATA(v97);
                      // pto: %214
                      ;
                      const int64_t v502 = 1;
                      // pto: %214
                      ;
                      const int64_t v503 = 1;
                      // pto: %214
                      ;
                      const int64_t v504 = 1;
                      // pto: %214
                      ;
                      int64_t v505 = v38 * v43;
                      // pto: %214
                      ;
                      int64_t v506 = v504 * v505;
                      // pto: %214
                      ;
                      pto::Shape<1, 1, 1, 1, -1> v507 = pto::Shape<1, 1, 1, 1, -1>(v502, v503, v504, v38, v268);
                      // pto: %214
                      ;
                      pto::Stride<-1, -1, -1, -1, -1> v508 = pto::Stride<-1, -1, -1, -1, -1>(v503 * v506, v506, v505, v43, v38);
                      // pto: %214
                      ;
                      GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v509 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v501 + (v500 + v499 * v43 + v45 * v38), v507, v508);
                      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
                      TLOAD(v496, v509);
                      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
                      // pto: %triple_scores_inline1554_inline9445__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v510 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v70);
                      // pto: %triple_scores_inline1554_inline9445__ssa_v0
                      ;
                      uint64_t v511 = (uint64_t) v29;
                      TASSIGN(v510, v511);
                      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
                      TFILLPAD<pto::TFillPadMode::InPlace>(v510, v496);
                      // pto: %triple_scores_v1_inline1514_inline9232__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v512 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v70);
                      // pto: %triple_scores_v1_inline1514_inline9232__ssa_v0
                      ;
                      uint64_t v513 = (uint64_t) v31;
                      TASSIGN(v512, v513);
                      pipe_barrier(PIPE_V);
                      TMAXS(v512, v510, v63);
                      // pto: %t__tmp_v815
                      ;
                      Tile<TileType::Vec, uint32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v514 = Tile<TileType::Vec, uint32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v70);
                      // pto: %t__tmp_v815
                      ;
                      uint64_t v515 = (uint64_t) v30;
                      TASSIGN(v514, v515);
                      // pto: %triple_pairs_inline1539_inline9263__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v516 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v71);
                      // pto: %triple_pairs_inline1539_inline9263__ssa_v0
                      ;
                      uint64_t v517 = (uint64_t) v29;
                      TASSIGN(v516, v517);
                      // pto: %215
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v518;
                      TRESHAPE(v518, v512);
                      // pto: %216
                      ;
                      Tile<TileType::Vec, uint32_t, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v519;
                      TRESHAPE(v519, v514);
                      // pto: %217
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 6144, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v520;
                      TRESHAPE(v520, v516);
                      pipe_barrier(PIPE_V);
                      TSORT32(v520, v518, v519);
                      // pto: %triple_pairs_v1_inline1505_inline9231__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v521 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v71);
                      // pto: %triple_pairs_v1_inline1505_inline9231__ssa_v0
                      ;
                      uint64_t v522 = (uint64_t) v30;
                      TASSIGN(v521, v522);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v521, v516, v64);
                      // pto: %triple_pairs_v2_inline1553_inline9230__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v523 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v71);
                      // pto: %triple_pairs_v2_inline1553_inline9230__ssa_v0
                      ;
                      uint64_t v524 = (uint64_t) v29;
                      TASSIGN(v523, v524);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v523, v521, v65);
                      v523.SetValidShape(v38, v54);
                      // pto: %triple_prefix_v1_inline1513_inline9228__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v525 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v71);
                      // pto: %triple_prefix_v1_inline1513_inline9228__ssa_v0
                      ;
                      uint64_t v526 = (uint64_t) v30;
                      TASSIGN(v525, v526);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v525, v523, v67);
                      // pto: %triple_left_inline1552_inline9421__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v527 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %triple_left_inline1552_inline9421__ssa_v0
                      ;
                      uint64_t v528 = (uint64_t) v30;
                      TASSIGN(v527, v528);
                      // pto: %218
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v529;
                      // pto: %218
                      ;
                      uint64_t v530 = (uint64_t) v30;
                      TASSIGN(v529, v530);
                      // pto: %triple_right0_inline1523_inline9227__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v531 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %triple_right0_inline1523_inline9227__ssa_v0
                      ;
                      uint64_t v532 = (uint64_t) v34;
                      TASSIGN(v531, v532);
                      // pto: %219
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v533;
                      // pto: %219
                      ;
                      uint64_t v534 = (uint64_t) v34;
                      TASSIGN(v533, v534);
                      // pto: %triple_right1_inline1518_inline9399__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v535 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %triple_right1_inline1518_inline9399__ssa_v0
                      ;
                      uint64_t v536 = (uint64_t) v36;
                      TASSIGN(v535, v536);
                      // pto: %220
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v537;
                      // pto: %220
                      ;
                      uint64_t v538 = (uint64_t) v36;
                      TASSIGN(v537, v538);
                      // pto: %triple_tmp_inline1520_inline9226__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v539 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v70);
                      // pto: %triple_tmp_inline1520_inline9226__ssa_v0
                      ;
                      uint64_t v540 = (uint64_t) v31;
                      TASSIGN(v539, v540);
                      // pto: %triple_merged_inline1555_inline9225__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v541 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v70);
                      // pto: %triple_merged_inline1555_inline9225__ssa_v0
                      ;
                      uint64_t v542 = (uint64_t) v35;
                      TASSIGN(v541, v542);
                      pipe_barrier(PIPE_V);
                      TMRGSORT<Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v541, v28, v539, v533, v537, v529);
                      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
                      // pto: %t__tmp_v816
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v543 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %t__tmp_v816
                      ;
                      uint64_t v544 = (uint64_t) v35;
                      TASSIGN(v543, v544);
                      // pto: %222
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v545;
                      // pto: %222
                      ;
                      uint64_t v546 = (uint64_t) v35;
                      TASSIGN(v545, v546);
                      // pto: %223
                      ;
                      int64_t v547 = v270 < v45 ? v45 : v270;
                      // pto: %224
                      ;
                      __gm__ float* v548 = PTOAS__GLOBAL_TENSOR_DATA(v105);
                      // pto: %224
                      ;
                      const int64_t v549 = 0;
                      // pto: %224
                      ;
                      const int64_t v550 = 1024;
                      // pto: %224
                      ;
                      pto::Shape<1, 1, 1, 1, 1024> v551 = pto::Shape<1, 1, 1, 1, 1024>();
                      // pto: %224
                      ;
                      pto::Stride<1024, 1024, 1024, 1024, 1> v552 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                      // pto: %224
                      ;
                      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v553 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v548 + (v549 + v547 * v550), v551, v552);
                      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
                      TSTORE(v553, v545);
                    } else {
                      // pto: %t__ci_tmp_v5
                      ;
                      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v554 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
                      // pto: %t__ci_tmp_v5
                      ;
                      uint64_t v555 = (uint64_t) v30;
                      TASSIGN(v554, v555);
                      // pto: %t__tmp_v817
                      ;
                      Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v556 = Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v54);
                      // pto: %t__tmp_v817
                      ;
                      uint64_t v557 = (uint64_t) v29;
                      TASSIGN(v556, v557);
                      // pto: %225
                      ;
                      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v558;
                      TRESHAPE(v558, v554);
                      // pto: %226
                      ;
                      Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v559;
                      TRESHAPE(v559, v556);
                      pipe_barrier(PIPE_V);
                      TCI<Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v559, v62, v558);
                      // pto: %medium_indices_inline1557_inline9224__ssa_v0
                      ;
                      Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v560 = Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v54);
                      // pto: %medium_indices_inline1557_inline9224__ssa_v0
                      ;
                      uint64_t v561 = (uint64_t) v30;
                      TASSIGN(v560, v561);
                      pipe_barrier(PIPE_V);
                      TADDS(v560, v556, v271);
                      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                      // pto: %medium_scores_raw_inline1556_inline9477__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v562 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v268);
                      // pto: %medium_scores_raw_inline1556_inline9477__ssa_v0
                      ;
                      uint64_t v563 = (uint64_t) v29;
                      TASSIGN(v562, v563);
                      // pto: %227, %228
                      ;
                      int64_t v564 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v120);
                      // pto: %229
                      ;
                      int64_t v565 = v564 < v45 ? v45 : v564;
                      // pto: %230
                      ;
                      const int64_t v566 = 0;
                      // pto: %230
                      ;
                      __gm__ float* v567 = PTOAS__GLOBAL_TENSOR_DATA(v97);
                      // pto: %230
                      ;
                      const int64_t v568 = 1;
                      // pto: %230
                      ;
                      const int64_t v569 = 1;
                      // pto: %230
                      ;
                      const int64_t v570 = 1;
                      // pto: %230
                      ;
                      int64_t v571 = v38 * v43;
                      // pto: %230
                      ;
                      int64_t v572 = v570 * v571;
                      // pto: %230
                      ;
                      pto::Shape<1, 1, 1, 1, -1> v573 = pto::Shape<1, 1, 1, 1, -1>(v568, v569, v570, v38, v268);
                      // pto: %230
                      ;
                      pto::Stride<-1, -1, -1, -1, -1> v574 = pto::Stride<-1, -1, -1, -1, -1>(v569 * v572, v572, v571, v43, v38);
                      // pto: %230
                      ;
                      GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v575 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v567 + (v566 + v565 * v43 + v45 * v38), v573, v574);
                      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                      TLOAD(v562, v575);
                      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
                      // pto: %medium_scores_inline1507_inline9223__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v576 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                      // pto: %medium_scores_inline1507_inline9223__ssa_v0
                      ;
                      uint64_t v577 = (uint64_t) v29;
                      TASSIGN(v576, v577);
                      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
                      TFILLPAD<pto::TFillPadMode::InPlace>(v576, v562);
                      // pto: %medium_scores_v1_inline1558_inline9222__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v578 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                      // pto: %medium_scores_v1_inline1558_inline9222__ssa_v0
                      ;
                      uint64_t v579 = (uint64_t) v31;
                      TASSIGN(v578, v579);
                      pipe_barrier(PIPE_V);
                      TMAXS(v578, v576, v63);
                      // pto: %t__tmp_v818
                      ;
                      Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v580 = Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v54);
                      // pto: %t__tmp_v818
                      ;
                      uint64_t v581 = (uint64_t) v30;
                      TASSIGN(v580, v581);
                      // pto: %medium_pairs_inline1498_inline9275__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v582 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v43);
                      // pto: %medium_pairs_inline1498_inline9275__ssa_v0
                      ;
                      uint64_t v583 = (uint64_t) v29;
                      TASSIGN(v582, v583);
                      // pto: %231
                      ;
                      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v584;
                      TRESHAPE(v584, v578);
                      // pto: %232
                      ;
                      Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v585;
                      TRESHAPE(v585, v580);
                      // pto: %233
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 8192, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v586;
                      TRESHAPE(v586, v582);
                      pipe_barrier(PIPE_V);
                      TSORT32(v586, v584, v585);
                      // pto: %medium_pairs_v1_inline1506_inline9335__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v587 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v43);
                      // pto: %medium_pairs_v1_inline1506_inline9335__ssa_v0
                      ;
                      uint64_t v588 = (uint64_t) v30;
                      TASSIGN(v587, v588);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v587, v582, v64);
                      // pto: %medium_pairs_v2_inline1497_inline9221__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v589 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v43);
                      // pto: %medium_pairs_v2_inline1497_inline9221__ssa_v0
                      ;
                      uint64_t v590 = (uint64_t) v29;
                      TASSIGN(v589, v590);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v589, v587, v65);
                      // pto: %medium_pairs_v3_inline1496_inline9220__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v591 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v43);
                      // pto: %medium_pairs_v3_inline1496_inline9220__ssa_v0
                      ;
                      uint64_t v592 = (uint64_t) v30;
                      TASSIGN(v591, v592);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v591, v589, v67);
                      // pto: %medium_left_inline1495_inline9262__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v593 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %medium_left_inline1495_inline9262__ssa_v0
                      ;
                      uint64_t v594 = (uint64_t) v30;
                      TASSIGN(v593, v594);
                      // pto: %234
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v595;
                      // pto: %234
                      ;
                      uint64_t v596 = (uint64_t) v30;
                      TASSIGN(v595, v596);
                      // pto: %medium_right_inline1494_inline9257__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v597 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %medium_right_inline1494_inline9257__ssa_v0
                      ;
                      uint64_t v598 = (uint64_t) v37;
                      TASSIGN(v597, v598);
                      // pto: %235
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v599;
                      // pto: %235
                      ;
                      uint64_t v600 = (uint64_t) v37;
                      TASSIGN(v599, v600);
                      // pto: %medium_tmp_inline1493_inline9219__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v601 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                      // pto: %medium_tmp_inline1493_inline9219__ssa_v0
                      ;
                      uint64_t v602 = (uint64_t) v29;
                      TASSIGN(v601, v602);
                      // pto: %medium_merged_inline1492_inline9218__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v603 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                      // pto: %medium_merged_inline1492_inline9218__ssa_v0
                      ;
                      uint64_t v604 = (uint64_t) v31;
                      TASSIGN(v603, v604);
                      pipe_barrier(PIPE_V);
                      TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v603, v28, v601, v599, v595);
                      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
                      // pto: %t__tmp_v819
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v605 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %t__tmp_v819
                      ;
                      uint64_t v606 = (uint64_t) v31;
                      TASSIGN(v605, v606);
                      // pto: %237
                      ;
                      Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v607;
                      // pto: %237
                      ;
                      uint64_t v608 = (uint64_t) v31;
                      TASSIGN(v607, v608);
                      // pto: %238
                      ;
                      int64_t v609 = v270 < v45 ? v45 : v270;
                      // pto: %239
                      ;
                      __gm__ float* v610 = PTOAS__GLOBAL_TENSOR_DATA(v105);
                      // pto: %239
                      ;
                      const int64_t v611 = 0;
                      // pto: %239
                      ;
                      const int64_t v612 = 1024;
                      // pto: %239
                      ;
                      pto::Shape<1, 1, 1, 1, 1024> v613 = pto::Shape<1, 1, 1, 1, 1024>();
                      // pto: %239
                      ;
                      pto::Stride<1024, 1024, 1024, 1024, 1> v614 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                      // pto: %239
                      ;
                      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v615 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v610 + (v611 + v609 * v612), v613, v614);
                      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
                      pipe_barrier(PIPE_MTE3);
                      TSTORE(v615, v607);
                    };
                  };
                };
              };
            };
          } else {
            // pto: %t__tmp_v820
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v616 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v44);
            // pto: %t__tmp_v820
            ;
            uint64_t v617 = (uint64_t) v29;
            TASSIGN(v616, v617);
            pipe_barrier(PIPE_V);
            TEXPANDS(v616, v63);
            set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
            // pto: %240
            ;
            int64_t v618 = v270 < v45 ? v45 : v270;
            // pto: %241
            ;
            __gm__ float* v619 = PTOAS__GLOBAL_TENSOR_DATA(v105);
            // pto: %241
            ;
            const int64_t v620 = 0;
            // pto: %241
            ;
            const int64_t v621 = 1024;
            // pto: %241
            ;
            pto::Shape<1, 1, 1, 1, 1024> v622 = pto::Shape<1, 1, 1, 1, 1024>();
            // pto: %241
            ;
            pto::Stride<1024, 1024, 1024, 1024, 1> v623 = pto::Stride<1024, 1024, 1024, 1024, 1>();
            // pto: %241
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v624 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v619 + (v620 + v618 * v621), v622, v623);
            wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
            pipe_barrier(PIPE_MTE3);
            TSTORE(v624, v616);
          };
        };
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
        // pto: %242
        ;
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
        if (v129 > v38) {
          // pto: %244, %243
          ;
          int64_t v625 = (v7)[(int64_t) ((uint64_t) v127 + (uint64_t) v38)];
          // pto: %245, %246
          ;
          int64_t v626 = (int64_t) ((uint64_t) v625 + (uint64_t) v50) / v51;
          // pto: %248
          ;
          int64_t v627 = v134 < v626 ? v134 : v626;
          // pto: %249
          ;
          int64_t v628 = v627 < v47 ? v627 : v47;
          // pto: %250
          ;
          int64_t v629 = v628 < v45 ? v45 : v628;
          // pto: %251
          ;
          int64_t v630 = (int64_t) ((uint64_t) v140 + (uint64_t) v145);
          // pto: %252
          ;
          int64_t v631 = (int64_t) ((uint64_t) v629 - (uint64_t) v630);
          // pto: %253
          ;
          int64_t v632 = v631 < v144 ? v631 : v144;
          // pto: %254
          ;
          int64_t v633 = v632 < v45 ? v45 : v632;
          // pto: %256
          ;
          uint64_t v634 = (uint64_t) v123;
          // pto: %255, %257, %256, %258, %259
          ;
          int64_t v635 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v127 * (uint64_t) v59) + (uint64_t) ((int64_t) v634 * (uint64_t) v56)) + (uint64_t) v120) + (uint64_t) v59);
          // pto: %260
          ;
          if (v633 > v45) {
            // pto: %261
            ;
            int32_t v636 = (int32_t) v630;
            // pto: %262
            ;
            if (v633 <= v60) {
              // pto: %t__ci_tmp_v6
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v637 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
              // pto: %t__ci_tmp_v6
              ;
              uint64_t v638 = (uint64_t) v30;
              TASSIGN(v637, v638);
              // pto: %t__tmp_v821
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v639 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v60);
              // pto: %t__tmp_v821
              ;
              uint64_t v640 = (uint64_t) v29;
              TASSIGN(v639, v640);
              // pto: %263
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v641;
              TRESHAPE(v641, v637);
              // pto: %264
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v642;
              TRESHAPE(v642, v639);
              pipe_barrier(PIPE_V);
              TCI<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v642, v62, v641);
              // pto: %short_indices_inline1549_inline9373__ssa_v1
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v643 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v60);
              // pto: %short_indices_inline1549_inline9373__ssa_v1
              ;
              uint64_t v644 = (uint64_t) v30;
              TASSIGN(v643, v644);
              pipe_barrier(PIPE_V);
              TADDS(v643, v639, v636);
              set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
              // pto: %short_raw_inline1516_inline9488__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v645 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v633);
              // pto: %short_raw_inline1516_inline9488__ssa_v1
              ;
              uint64_t v646 = (uint64_t) v29;
              TASSIGN(v645, v646);
              // pto: %265, %266, %267
              ;
              int64_t v647 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v120) + (uint64_t) v56);
              // pto: %268
              ;
              int64_t v648 = v647 < v45 ? v45 : v647;
              // pto: %269
              ;
              const int64_t v649 = 0;
              // pto: %269
              ;
              __gm__ float* v650 = PTOAS__GLOBAL_TENSOR_DATA(v97);
              // pto: %269
              ;
              const int64_t v651 = 1;
              // pto: %269
              ;
              const int64_t v652 = 1;
              // pto: %269
              ;
              const int64_t v653 = 1;
              // pto: %269
              ;
              int64_t v654 = v38 * v43;
              // pto: %269
              ;
              int64_t v655 = v653 * v654;
              // pto: %269
              ;
              pto::Shape<1, 1, 1, 1, -1> v656 = pto::Shape<1, 1, 1, 1, -1>(v651, v652, v653, v38, v633);
              // pto: %269
              ;
              pto::Stride<-1, -1, -1, -1, -1> v657 = pto::Stride<-1, -1, -1, -1, -1>(v652 * v655, v655, v654, v43, v38);
              // pto: %269
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v658 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v650 + (v649 + v648 * v43 + v45 * v38), v656, v657);
              wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
              TLOAD(v645, v658);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
              // pto: %short_scores_inline1517_inline9407__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v659 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v60);
              // pto: %short_scores_inline1517_inline9407__ssa_v1
              ;
              uint64_t v660 = (uint64_t) v29;
              TASSIGN(v659, v660);
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
              TFILLPAD<pto::TFillPadMode::InPlace>(v659, v645);
              // pto: %short_scores_v1_inline1519_inline9261__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v661 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v60);
              // pto: %short_scores_v1_inline1519_inline9261__ssa_v1
              ;
              uint64_t v662 = (uint64_t) v31;
              TASSIGN(v661, v662);
              pipe_barrier(PIPE_V);
              TMAXS(v661, v659, v63);
              // pto: %t__tmp_v822
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v663 = Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v60);
              // pto: %t__tmp_v822
              ;
              uint64_t v664 = (uint64_t) v30;
              TASSIGN(v663, v664);
              // pto: %short_pairs_inline1547_inline9489__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v665 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
              // pto: %short_pairs_inline1547_inline9489__ssa_v1
              ;
              uint64_t v666 = (uint64_t) v29;
              TASSIGN(v665, v666);
              // pto: %270
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v667;
              TRESHAPE(v667, v661);
              // pto: %271
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v668;
              TRESHAPE(v668, v663);
              // pto: %272
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v669;
              TRESHAPE(v669, v665);
              pipe_barrier(PIPE_V);
              TSORT32(v669, v667, v668);
              // pto: %short_pairs_v1_inline1511_inline9491__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v670 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
              // pto: %short_pairs_v1_inline1511_inline9491__ssa_v1
              ;
              uint64_t v671 = (uint64_t) v30;
              TASSIGN(v670, v671);
              pipe_barrier(PIPE_V);
              TMRGSORT(v670, v665, v64);
              // pto: %short_pairs_v2_inline1502_inline9492__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v672 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
              // pto: %short_pairs_v2_inline1502_inline9492__ssa_v1
              ;
              uint64_t v673 = (uint64_t) v29;
              TASSIGN(v672, v673);
              pipe_barrier(PIPE_V);
              TMRGSORT(v672, v670, v65);
              set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
              // pto: %273
              ;
              int64_t v674 = v635 < v45 ? v45 : v635;
              // pto: %274
              ;
              __gm__ float* v675 = PTOAS__GLOBAL_TENSOR_DATA(v105);
              // pto: %274
              ;
              const int64_t v676 = 0;
              // pto: %274
              ;
              const int64_t v677 = 1024;
              // pto: %274
              ;
              pto::Shape<1, 1, 1, 1, 1024> v678 = pto::Shape<1, 1, 1, 1, 1024>();
              // pto: %274
              ;
              pto::Stride<1024, 1024, 1024, 1024, 1> v679 = pto::Stride<1024, 1024, 1024, 1024, 1>();
              // pto: %274
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v680 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v675 + (v676 + v674 * v677), v678, v679);
              wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
              pipe_barrier(PIPE_MTE3);
              TSTORE(v680, v672);
            } else {
              // pto: %275
              ;
              if (v633 <= v44) {
                // pto: %t__ci_tmp_v7
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v681 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
                // pto: %t__ci_tmp_v7
                ;
                uint64_t v682 = (uint64_t) v30;
                TASSIGN(v681, v682);
                // pto: %t__tmp_v823
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v683 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v44);
                // pto: %t__tmp_v823
                ;
                uint64_t v684 = (uint64_t) v29;
                TASSIGN(v683, v684);
                // pto: %276
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v685;
                TRESHAPE(v685, v681);
                // pto: %277
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v686;
                TRESHAPE(v686, v683);
                pipe_barrier(PIPE_V);
                TCI<Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v686, v62, v685);
                // pto: %small_indices_inline1510_inline9417__ssa_v1
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v687 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v44);
                // pto: %small_indices_inline1510_inline9417__ssa_v1
                ;
                uint64_t v688 = (uint64_t) v30;
                TASSIGN(v687, v688);
                pipe_barrier(PIPE_V);
                TADDS(v687, v683, v636);
                set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                // pto: %small_raw_inline1534_inline9398__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v689 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v633);
                // pto: %small_raw_inline1534_inline9398__ssa_v1
                ;
                uint64_t v690 = (uint64_t) v29;
                TASSIGN(v689, v690);
                // pto: %278, %279, %280
                ;
                int64_t v691 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v120) + (uint64_t) v56);
                // pto: %281
                ;
                int64_t v692 = v691 < v45 ? v45 : v691;
                // pto: %282
                ;
                const int64_t v693 = 0;
                // pto: %282
                ;
                __gm__ float* v694 = PTOAS__GLOBAL_TENSOR_DATA(v97);
                // pto: %282
                ;
                const int64_t v695 = 1;
                // pto: %282
                ;
                const int64_t v696 = 1;
                // pto: %282
                ;
                const int64_t v697 = 1;
                // pto: %282
                ;
                int64_t v698 = v38 * v43;
                // pto: %282
                ;
                int64_t v699 = v697 * v698;
                // pto: %282
                ;
                pto::Shape<1, 1, 1, 1, -1> v700 = pto::Shape<1, 1, 1, 1, -1>(v695, v696, v697, v38, v633);
                // pto: %282
                ;
                pto::Stride<-1, -1, -1, -1, -1> v701 = pto::Stride<-1, -1, -1, -1, -1>(v696 * v699, v699, v698, v43, v38);
                // pto: %282
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v702 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v694 + (v693 + v692 * v43 + v45 * v38), v700, v701);
                wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                TLOAD(v689, v702);
                set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                // pto: %small_scores_inline1527_inline9493__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v703 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                // pto: %small_scores_inline1527_inline9493__ssa_v1
                ;
                uint64_t v704 = (uint64_t) v29;
                TASSIGN(v703, v704);
                wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                TFILLPAD<pto::TFillPadMode::InPlace>(v703, v689);
                // pto: %small_scores_v1_inline1512_inline9439__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v705 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                // pto: %small_scores_v1_inline1512_inline9439__ssa_v1
                ;
                uint64_t v706 = (uint64_t) v31;
                TASSIGN(v705, v706);
                pipe_barrier(PIPE_V);
                TMAXS(v705, v703, v63);
                // pto: %t__tmp_v824
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v707 = Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v44);
                // pto: %t__tmp_v824
                ;
                uint64_t v708 = (uint64_t) v30;
                TASSIGN(v707, v708);
                // pto: %small_pairs_inline1538_inline9494__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v709 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                // pto: %small_pairs_inline1538_inline9494__ssa_v1
                ;
                uint64_t v710 = (uint64_t) v29;
                TASSIGN(v709, v710);
                // pto: %283
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v711;
                TRESHAPE(v711, v705);
                // pto: %284
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v712;
                TRESHAPE(v712, v707);
                // pto: %285
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v713;
                TRESHAPE(v713, v709);
                pipe_barrier(PIPE_V);
                TSORT32(v713, v711, v712);
                // pto: %small_pairs_v1_inline1544_inline9455__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v714 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                // pto: %small_pairs_v1_inline1544_inline9455__ssa_v1
                ;
                uint64_t v715 = (uint64_t) v30;
                TASSIGN(v714, v715);
                pipe_barrier(PIPE_V);
                TMRGSORT(v714, v709, v64);
                // pto: %small_pairs_v2_inline1504_inline9486__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v716 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                // pto: %small_pairs_v2_inline1504_inline9486__ssa_v1
                ;
                uint64_t v717 = (uint64_t) v29;
                TASSIGN(v716, v717);
                pipe_barrier(PIPE_V);
                TMRGSORT(v716, v714, v65);
                // pto: %small_left_inline1526_inline9352__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v718 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                // pto: %small_left_inline1526_inline9352__ssa_v1
                ;
                uint64_t v719 = (uint64_t) v29;
                TASSIGN(v718, v719);
                // pto: %286
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v720;
                // pto: %286
                ;
                uint64_t v721 = (uint64_t) v29;
                TASSIGN(v720, v721);
                // pto: %small_right_inline1509_inline9497__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v722 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                // pto: %small_right_inline1509_inline9497__ssa_v1
                ;
                uint64_t v723 = (uint64_t) v33;
                TASSIGN(v722, v723);
                // pto: %287
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v724;
                // pto: %287
                ;
                uint64_t v725 = (uint64_t) v33;
                TASSIGN(v724, v725);
                // pto: %small_tmp_inline1503_inline9498__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v726 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                // pto: %small_tmp_inline1503_inline9498__ssa_v1
                ;
                uint64_t v727 = (uint64_t) v30;
                TASSIGN(v726, v727);
                // pto: %small_merged_inline1536_inline9278__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v728 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                // pto: %small_merged_inline1536_inline9278__ssa_v1
                ;
                uint64_t v729 = (uint64_t) v31;
                TASSIGN(v728, v729);
                pipe_barrier(PIPE_V);
                TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v728, v28, v726, v720, v724);
                set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                // pto: %small_top_inline1501_inline9271__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v730 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                // pto: %small_top_inline1501_inline9271__ssa_v1
                ;
                uint64_t v731 = (uint64_t) v31;
                TASSIGN(v730, v731);
                // pto: %289
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v732;
                // pto: %289
                ;
                uint64_t v733 = (uint64_t) v31;
                TASSIGN(v732, v733);
                // pto: %290
                ;
                int64_t v734 = v635 < v45 ? v45 : v635;
                // pto: %291
                ;
                __gm__ float* v735 = PTOAS__GLOBAL_TENSOR_DATA(v105);
                // pto: %291
                ;
                const int64_t v736 = 0;
                // pto: %291
                ;
                const int64_t v737 = 1024;
                // pto: %291
                ;
                pto::Shape<1, 1, 1, 1, 1024> v738 = pto::Shape<1, 1, 1, 1, 1024>();
                // pto: %291
                ;
                pto::Stride<1024, 1024, 1024, 1024, 1> v739 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                // pto: %291
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v740 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v735 + (v736 + v734 * v737), v738, v739);
                wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                pipe_barrier(PIPE_MTE3);
                TSTORE(v740, v732);
              } else {
                // pto: %292
                ;
                if (v633 <= v66) {
                  // pto: %t__ci_tmp_v8
                  ;
                  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v741 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
                  // pto: %t__ci_tmp_v8
                  ;
                  uint64_t v742 = (uint64_t) v30;
                  TASSIGN(v741, v742);
                  // pto: %t__tmp_v825
                  ;
                  Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v743 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                  // pto: %t__tmp_v825
                  ;
                  uint64_t v744 = (uint64_t) v29;
                  TASSIGN(v743, v744);
                  // pto: %293
                  ;
                  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v745;
                  TRESHAPE(v745, v741);
                  // pto: %294
                  ;
                  Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v746;
                  TRESHAPE(v746, v743);
                  pipe_barrier(PIPE_V);
                  TCI<Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v746, v62, v745);
                  // pto: %leaf_indices_inline1500_inline9500__ssa_v1
                  ;
                  Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v747 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                  // pto: %leaf_indices_inline1500_inline9500__ssa_v1
                  ;
                  uint64_t v748 = (uint64_t) v30;
                  TASSIGN(v747, v748);
                  pipe_barrier(PIPE_V);
                  TADDS(v747, v743, v636);
                  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                  // pto: %leaf_scores_raw_inline1525_inline9499__ssa_v1
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v749 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v633);
                  // pto: %leaf_scores_raw_inline1525_inline9499__ssa_v1
                  ;
                  uint64_t v750 = (uint64_t) v29;
                  TASSIGN(v749, v750);
                  // pto: %295, %296, %297
                  ;
                  int64_t v751 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v120) + (uint64_t) v56);
                  // pto: %298
                  ;
                  int64_t v752 = v751 < v45 ? v45 : v751;
                  // pto: %299
                  ;
                  const int64_t v753 = 0;
                  // pto: %299
                  ;
                  __gm__ float* v754 = PTOAS__GLOBAL_TENSOR_DATA(v97);
                  // pto: %299
                  ;
                  const int64_t v755 = 1;
                  // pto: %299
                  ;
                  const int64_t v756 = 1;
                  // pto: %299
                  ;
                  const int64_t v757 = 1;
                  // pto: %299
                  ;
                  int64_t v758 = v38 * v43;
                  // pto: %299
                  ;
                  int64_t v759 = v757 * v758;
                  // pto: %299
                  ;
                  pto::Shape<1, 1, 1, 1, -1> v760 = pto::Shape<1, 1, 1, 1, -1>(v755, v756, v757, v38, v633);
                  // pto: %299
                  ;
                  pto::Stride<-1, -1, -1, -1, -1> v761 = pto::Stride<-1, -1, -1, -1, -1>(v756 * v759, v759, v758, v43, v38);
                  // pto: %299
                  ;
                  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v762 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v754 + (v753 + v752 * v43 + v45 * v38), v760, v761);
                  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                  TLOAD(v749, v762);
                  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                  // pto: %leaf_scores_inline1531_inline9289__ssa_v1
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v763 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                  // pto: %leaf_scores_inline1531_inline9289__ssa_v1
                  ;
                  uint64_t v764 = (uint64_t) v29;
                  TASSIGN(v763, v764);
                  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                  TFILLPAD<pto::TFillPadMode::InPlace>(v763, v749);
                  // pto: %leaf_scores_v1_inline1499_inline9241__ssa_v1
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v765 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                  // pto: %leaf_scores_v1_inline1499_inline9241__ssa_v1
                  ;
                  uint64_t v766 = (uint64_t) v31;
                  TASSIGN(v765, v766);
                  pipe_barrier(PIPE_V);
                  TMAXS(v765, v763, v63);
                  // pto: %t__tmp_v826
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v767 = Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                  // pto: %t__tmp_v826
                  ;
                  uint64_t v768 = (uint64_t) v30;
                  TASSIGN(v767, v768);
                  // pto: %pairs_inline1508_inline9501__ssa_v1
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v769 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                  // pto: %pairs_inline1508_inline9501__ssa_v1
                  ;
                  uint64_t v770 = (uint64_t) v29;
                  TASSIGN(v769, v770);
                  // pto: %300
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v771;
                  TRESHAPE(v771, v765);
                  // pto: %301
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v772;
                  TRESHAPE(v772, v767);
                  // pto: %302
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v773;
                  TRESHAPE(v773, v769);
                  pipe_barrier(PIPE_V);
                  TSORT32(v773, v771, v772);
                  // pto: %pairs_v1_inline1530_inline9251__ssa_v1
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v774 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                  // pto: %pairs_v1_inline1530_inline9251__ssa_v1
                  ;
                  uint64_t v775 = (uint64_t) v30;
                  TASSIGN(v774, v775);
                  pipe_barrier(PIPE_V);
                  TMRGSORT(v774, v769, v64);
                  // pto: %pairs_v2_inline1528_inline9329__ssa_v1
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v776 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                  // pto: %pairs_v2_inline1528_inline9329__ssa_v1
                  ;
                  uint64_t v777 = (uint64_t) v29;
                  TASSIGN(v776, v777);
                  pipe_barrier(PIPE_V);
                  TMRGSORT(v776, v774, v65);
                  // pto: %pairs_v3_inline1521_inline9343__ssa_v1
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v778 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                  // pto: %pairs_v3_inline1521_inline9343__ssa_v1
                  ;
                  uint64_t v779 = (uint64_t) v30;
                  TASSIGN(v778, v779);
                  pipe_barrier(PIPE_V);
                  TMRGSORT(v778, v776, v67);
                  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                  // pto: %t__tmp_v827
                  ;
                  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v780 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                  // pto: %t__tmp_v827
                  ;
                  uint64_t v781 = (uint64_t) v30;
                  TASSIGN(v780, v781);
                  // pto: %303
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v782;
                  // pto: %303
                  ;
                  uint64_t v783 = (uint64_t) v30;
                  TASSIGN(v782, v783);
                  // pto: %304
                  ;
                  int64_t v784 = v635 < v45 ? v45 : v635;
                  // pto: %305
                  ;
                  __gm__ float* v785 = PTOAS__GLOBAL_TENSOR_DATA(v105);
                  // pto: %305
                  ;
                  const int64_t v786 = 0;
                  // pto: %305
                  ;
                  const int64_t v787 = 1024;
                  // pto: %305
                  ;
                  pto::Shape<1, 1, 1, 1, 1024> v788 = pto::Shape<1, 1, 1, 1, 1024>();
                  // pto: %305
                  ;
                  pto::Stride<1024, 1024, 1024, 1024, 1> v789 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                  // pto: %305
                  ;
                  GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v790 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v785 + (v786 + v784 * v787), v788, v789);
                  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                  pipe_barrier(PIPE_MTE3);
                  TSTORE(v790, v782);
                } else {
                  // pto: %306
                  ;
                  if (v633 <= v68) {
                    // pto: %t__ci_tmp_v9
                    ;
                    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v791 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
                    // pto: %t__ci_tmp_v9
                    ;
                    uint64_t v792 = (uint64_t) v30;
                    TASSIGN(v791, v792);
                    // pto: %t__tmp_v828
                    ;
                    Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v793 = Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v68);
                    // pto: %t__tmp_v828
                    ;
                    uint64_t v794 = (uint64_t) v29;
                    TASSIGN(v793, v794);
                    // pto: %307
                    ;
                    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v795;
                    TRESHAPE(v795, v791);
                    // pto: %308
                    ;
                    Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v796;
                    TRESHAPE(v796, v793);
                    pipe_barrier(PIPE_V);
                    TCI<Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v796, v62, v795);
                    // pto: %partial_indices_inline1535_inline9502__ssa_v1
                    ;
                    Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v797 = Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v68);
                    // pto: %partial_indices_inline1535_inline9502__ssa_v1
                    ;
                    uint64_t v798 = (uint64_t) v30;
                    TASSIGN(v797, v798);
                    pipe_barrier(PIPE_V);
                    TADDS(v797, v793, v636);
                    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                    // pto: %partial_raw_inline1540_inline9504__ssa_v1
                    ;
                    Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v799 = Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v633);
                    // pto: %partial_raw_inline1540_inline9504__ssa_v1
                    ;
                    uint64_t v800 = (uint64_t) v29;
                    TASSIGN(v799, v800);
                    // pto: %309, %310, %311
                    ;
                    int64_t v801 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v120) + (uint64_t) v56);
                    // pto: %312
                    ;
                    int64_t v802 = v801 < v45 ? v45 : v801;
                    // pto: %313
                    ;
                    const int64_t v803 = 0;
                    // pto: %313
                    ;
                    __gm__ float* v804 = PTOAS__GLOBAL_TENSOR_DATA(v97);
                    // pto: %313
                    ;
                    const int64_t v805 = 1;
                    // pto: %313
                    ;
                    const int64_t v806 = 1;
                    // pto: %313
                    ;
                    const int64_t v807 = 1;
                    // pto: %313
                    ;
                    int64_t v808 = v38 * v43;
                    // pto: %313
                    ;
                    int64_t v809 = v807 * v808;
                    // pto: %313
                    ;
                    pto::Shape<1, 1, 1, 1, -1> v810 = pto::Shape<1, 1, 1, 1, -1>(v805, v806, v807, v38, v633);
                    // pto: %313
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v811 = pto::Stride<-1, -1, -1, -1, -1>(v806 * v809, v809, v808, v43, v38);
                    // pto: %313
                    ;
                    GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v812 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v804 + (v803 + v802 * v43 + v45 * v38), v810, v811);
                    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                    TLOAD(v799, v812);
                    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                    // pto: %partial_scores_inline1524_inline9505__ssa_v1
                    ;
                    Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v813 = Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v68);
                    // pto: %partial_scores_inline1524_inline9505__ssa_v1
                    ;
                    uint64_t v814 = (uint64_t) v29;
                    TASSIGN(v813, v814);
                    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                    TFILLPAD<pto::TFillPadMode::InPlace>(v813, v799);
                    // pto: %partial_scores_v1_inline1542_inline9506__ssa_v1
                    ;
                    Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v815 = Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v68);
                    // pto: %partial_scores_v1_inline1542_inline9506__ssa_v1
                    ;
                    uint64_t v816 = (uint64_t) v31;
                    TASSIGN(v815, v816);
                    pipe_barrier(PIPE_V);
                    TMAXS(v815, v813, v63);
                    // pto: %t__tmp_v829
                    ;
                    Tile<TileType::Vec, uint32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v817 = Tile<TileType::Vec, uint32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v68);
                    // pto: %t__tmp_v829
                    ;
                    uint64_t v818 = (uint64_t) v30;
                    TASSIGN(v817, v818);
                    // pto: %partial_pairs_inline1532_inline9507__ssa_v1
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v819 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v69);
                    // pto: %partial_pairs_inline1532_inline9507__ssa_v1
                    ;
                    uint64_t v820 = (uint64_t) v29;
                    TASSIGN(v819, v820);
                    // pto: %314
                    ;
                    Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v821;
                    TRESHAPE(v821, v815);
                    // pto: %315
                    ;
                    Tile<TileType::Vec, uint32_t, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v822;
                    TRESHAPE(v822, v817);
                    // pto: %316
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 5120, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v823;
                    TRESHAPE(v823, v819);
                    pipe_barrier(PIPE_V);
                    TSORT32(v823, v821, v822);
                    // pto: %partial_pairs_v1_inline1543_inline9361__ssa_v1
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v824 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v69);
                    // pto: %partial_pairs_v1_inline1543_inline9361__ssa_v1
                    ;
                    uint64_t v825 = (uint64_t) v30;
                    TASSIGN(v824, v825);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v824, v819, v64);
                    // pto: %partial_pairs_v2_inline1546_inline9287__ssa_v1
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v826 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v69);
                    // pto: %partial_pairs_v2_inline1546_inline9287__ssa_v1
                    ;
                    uint64_t v827 = (uint64_t) v29;
                    TASSIGN(v826, v827);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v826, v824, v65);
                    v826.SetValidShape(v38, v54);
                    // pto: %partial_prefix_v1_inline1548_inline9238__ssa_v1
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v828 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v69);
                    // pto: %partial_prefix_v1_inline1548_inline9238__ssa_v1
                    ;
                    uint64_t v829 = (uint64_t) v30;
                    TASSIGN(v828, v829);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v828, v826, v67);
                    // pto: %partial_left_inline1550_inline9495__ssa_v1
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v830 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                    // pto: %partial_left_inline1550_inline9495__ssa_v1
                    ;
                    uint64_t v831 = (uint64_t) v30;
                    TASSIGN(v830, v831);
                    // pto: %317
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v832;
                    // pto: %317
                    ;
                    uint64_t v833 = (uint64_t) v30;
                    TASSIGN(v832, v833);
                    // pto: %partial_right_inline1541_inline9237__ssa_v1
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v834 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                    // pto: %partial_right_inline1541_inline9237__ssa_v1
                    ;
                    uint64_t v835 = (uint64_t) v34;
                    TASSIGN(v834, v835);
                    // pto: %318
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v836;
                    // pto: %318
                    ;
                    uint64_t v837 = (uint64_t) v34;
                    TASSIGN(v836, v837);
                    // pto: %partial_tmp_inline1522_inline9236__ssa_v1
                    ;
                    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v838 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                    // pto: %partial_tmp_inline1522_inline9236__ssa_v1
                    ;
                    uint64_t v839 = (uint64_t) v31;
                    TASSIGN(v838, v839);
                    // pto: %partial_merged_inline1529_inline9235__ssa_v1
                    ;
                    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v840 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                    // pto: %partial_merged_inline1529_inline9235__ssa_v1
                    ;
                    uint64_t v841 = (uint64_t) v35;
                    TASSIGN(v840, v841);
                    pipe_barrier(PIPE_V);
                    TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v840, v28, v838, v836, v832);
                    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                    // pto: %t__tmp_v830
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v842 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                    // pto: %t__tmp_v830
                    ;
                    uint64_t v843 = (uint64_t) v35;
                    TASSIGN(v842, v843);
                    // pto: %320
                    ;
                    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v844;
                    // pto: %320
                    ;
                    uint64_t v845 = (uint64_t) v35;
                    TASSIGN(v844, v845);
                    // pto: %321
                    ;
                    int64_t v846 = v635 < v45 ? v45 : v635;
                    // pto: %322
                    ;
                    __gm__ float* v847 = PTOAS__GLOBAL_TENSOR_DATA(v105);
                    // pto: %322
                    ;
                    const int64_t v848 = 0;
                    // pto: %322
                    ;
                    const int64_t v849 = 1024;
                    // pto: %322
                    ;
                    pto::Shape<1, 1, 1, 1, 1024> v850 = pto::Shape<1, 1, 1, 1, 1024>();
                    // pto: %322
                    ;
                    pto::Stride<1024, 1024, 1024, 1024, 1> v851 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                    // pto: %322
                    ;
                    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v852 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v847 + (v848 + v846 * v849), v850, v851);
                    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                    TSTORE(v852, v844);
                  } else {
                    // pto: %323
                    ;
                    if (v633 <= v70) {
                      // pto: %t__ci_tmp_v10
                      ;
                      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v853 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
                      // pto: %t__ci_tmp_v10
                      ;
                      uint64_t v854 = (uint64_t) v30;
                      TASSIGN(v853, v854);
                      // pto: %t__tmp_v831
                      ;
                      Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v855 = Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v70);
                      // pto: %t__tmp_v831
                      ;
                      uint64_t v856 = (uint64_t) v29;
                      TASSIGN(v855, v856);
                      // pto: %324
                      ;
                      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v857;
                      TRESHAPE(v857, v853);
                      // pto: %325
                      ;
                      Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v858;
                      TRESHAPE(v858, v855);
                      pipe_barrier(PIPE_V);
                      TCI<Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v858, v62, v857);
                      // pto: %triple_indices_inline1551_inline9234__ssa_v1
                      ;
                      Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v859 = Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v70);
                      // pto: %triple_indices_inline1551_inline9234__ssa_v1
                      ;
                      uint64_t v860 = (uint64_t) v30;
                      TASSIGN(v859, v860);
                      pipe_barrier(PIPE_V);
                      TADDS(v859, v855, v636);
                      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                      // pto: %triple_raw_inline1515_inline9233__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v861 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v633);
                      // pto: %triple_raw_inline1515_inline9233__ssa_v1
                      ;
                      uint64_t v862 = (uint64_t) v29;
                      TASSIGN(v861, v862);
                      // pto: %326, %327, %328
                      ;
                      int64_t v863 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v120) + (uint64_t) v56);
                      // pto: %329
                      ;
                      int64_t v864 = v863 < v45 ? v45 : v863;
                      // pto: %330
                      ;
                      const int64_t v865 = 0;
                      // pto: %330
                      ;
                      __gm__ float* v866 = PTOAS__GLOBAL_TENSOR_DATA(v97);
                      // pto: %330
                      ;
                      const int64_t v867 = 1;
                      // pto: %330
                      ;
                      const int64_t v868 = 1;
                      // pto: %330
                      ;
                      const int64_t v869 = 1;
                      // pto: %330
                      ;
                      int64_t v870 = v38 * v43;
                      // pto: %330
                      ;
                      int64_t v871 = v869 * v870;
                      // pto: %330
                      ;
                      pto::Shape<1, 1, 1, 1, -1> v872 = pto::Shape<1, 1, 1, 1, -1>(v867, v868, v869, v38, v633);
                      // pto: %330
                      ;
                      pto::Stride<-1, -1, -1, -1, -1> v873 = pto::Stride<-1, -1, -1, -1, -1>(v868 * v871, v871, v870, v43, v38);
                      // pto: %330
                      ;
                      GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v874 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v866 + (v865 + v864 * v43 + v45 * v38), v872, v873);
                      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                      TLOAD(v861, v874);
                      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                      // pto: %triple_scores_inline1554_inline9445__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v875 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v70);
                      // pto: %triple_scores_inline1554_inline9445__ssa_v1
                      ;
                      uint64_t v876 = (uint64_t) v29;
                      TASSIGN(v875, v876);
                      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                      TFILLPAD<pto::TFillPadMode::InPlace>(v875, v861);
                      // pto: %triple_scores_v1_inline1514_inline9232__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v877 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v70);
                      // pto: %triple_scores_v1_inline1514_inline9232__ssa_v1
                      ;
                      uint64_t v878 = (uint64_t) v31;
                      TASSIGN(v877, v878);
                      pipe_barrier(PIPE_V);
                      TMAXS(v877, v875, v63);
                      // pto: %t__tmp_v832
                      ;
                      Tile<TileType::Vec, uint32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v879 = Tile<TileType::Vec, uint32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v70);
                      // pto: %t__tmp_v832
                      ;
                      uint64_t v880 = (uint64_t) v30;
                      TASSIGN(v879, v880);
                      // pto: %triple_pairs_inline1539_inline9263__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v881 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v71);
                      // pto: %triple_pairs_inline1539_inline9263__ssa_v1
                      ;
                      uint64_t v882 = (uint64_t) v29;
                      TASSIGN(v881, v882);
                      // pto: %331
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v883;
                      TRESHAPE(v883, v877);
                      // pto: %332
                      ;
                      Tile<TileType::Vec, uint32_t, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v884;
                      TRESHAPE(v884, v879);
                      // pto: %333
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 6144, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v885;
                      TRESHAPE(v885, v881);
                      pipe_barrier(PIPE_V);
                      TSORT32(v885, v883, v884);
                      // pto: %triple_pairs_v1_inline1505_inline9231__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v886 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v71);
                      // pto: %triple_pairs_v1_inline1505_inline9231__ssa_v1
                      ;
                      uint64_t v887 = (uint64_t) v30;
                      TASSIGN(v886, v887);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v886, v881, v64);
                      // pto: %triple_pairs_v2_inline1553_inline9230__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v888 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v71);
                      // pto: %triple_pairs_v2_inline1553_inline9230__ssa_v1
                      ;
                      uint64_t v889 = (uint64_t) v29;
                      TASSIGN(v888, v889);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v888, v886, v65);
                      v888.SetValidShape(v38, v54);
                      // pto: %triple_prefix_v1_inline1513_inline9228__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v890 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v71);
                      // pto: %triple_prefix_v1_inline1513_inline9228__ssa_v1
                      ;
                      uint64_t v891 = (uint64_t) v30;
                      TASSIGN(v890, v891);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v890, v888, v67);
                      // pto: %triple_left_inline1552_inline9421__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v892 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %triple_left_inline1552_inline9421__ssa_v1
                      ;
                      uint64_t v893 = (uint64_t) v30;
                      TASSIGN(v892, v893);
                      // pto: %334
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v894;
                      // pto: %334
                      ;
                      uint64_t v895 = (uint64_t) v30;
                      TASSIGN(v894, v895);
                      // pto: %triple_right0_inline1523_inline9227__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v896 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %triple_right0_inline1523_inline9227__ssa_v1
                      ;
                      uint64_t v897 = (uint64_t) v34;
                      TASSIGN(v896, v897);
                      // pto: %335
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v898;
                      // pto: %335
                      ;
                      uint64_t v899 = (uint64_t) v34;
                      TASSIGN(v898, v899);
                      // pto: %triple_right1_inline1518_inline9399__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v900 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %triple_right1_inline1518_inline9399__ssa_v1
                      ;
                      uint64_t v901 = (uint64_t) v36;
                      TASSIGN(v900, v901);
                      // pto: %336
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v902;
                      // pto: %336
                      ;
                      uint64_t v903 = (uint64_t) v36;
                      TASSIGN(v902, v903);
                      // pto: %triple_tmp_inline1520_inline9226__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v904 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v70);
                      // pto: %triple_tmp_inline1520_inline9226__ssa_v1
                      ;
                      uint64_t v905 = (uint64_t) v31;
                      TASSIGN(v904, v905);
                      // pto: %triple_merged_inline1555_inline9225__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v906 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v70);
                      // pto: %triple_merged_inline1555_inline9225__ssa_v1
                      ;
                      uint64_t v907 = (uint64_t) v35;
                      TASSIGN(v906, v907);
                      pipe_barrier(PIPE_V);
                      TMRGSORT<Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v906, v28, v904, v898, v902, v894);
                      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                      // pto: %t__tmp_v833
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v908 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %t__tmp_v833
                      ;
                      uint64_t v909 = (uint64_t) v35;
                      TASSIGN(v908, v909);
                      // pto: %338
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v910;
                      // pto: %338
                      ;
                      uint64_t v911 = (uint64_t) v35;
                      TASSIGN(v910, v911);
                      // pto: %339
                      ;
                      int64_t v912 = v635 < v45 ? v45 : v635;
                      // pto: %340
                      ;
                      __gm__ float* v913 = PTOAS__GLOBAL_TENSOR_DATA(v105);
                      // pto: %340
                      ;
                      const int64_t v914 = 0;
                      // pto: %340
                      ;
                      const int64_t v915 = 1024;
                      // pto: %340
                      ;
                      pto::Shape<1, 1, 1, 1, 1024> v916 = pto::Shape<1, 1, 1, 1, 1024>();
                      // pto: %340
                      ;
                      pto::Stride<1024, 1024, 1024, 1024, 1> v917 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                      // pto: %340
                      ;
                      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v918 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v913 + (v914 + v912 * v915), v916, v917);
                      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                      TSTORE(v918, v910);
                    } else {
                      // pto: %t__ci_tmp_v11
                      ;
                      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v919 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
                      // pto: %t__ci_tmp_v11
                      ;
                      uint64_t v920 = (uint64_t) v30;
                      TASSIGN(v919, v920);
                      // pto: %t__tmp_v834
                      ;
                      Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v921 = Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v54);
                      // pto: %t__tmp_v834
                      ;
                      uint64_t v922 = (uint64_t) v29;
                      TASSIGN(v921, v922);
                      // pto: %341
                      ;
                      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v923;
                      TRESHAPE(v923, v919);
                      // pto: %342
                      ;
                      Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v924;
                      TRESHAPE(v924, v921);
                      pipe_barrier(PIPE_V);
                      TCI<Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v924, v62, v923);
                      // pto: %medium_indices_inline1557_inline9224__ssa_v1
                      ;
                      Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v925 = Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v54);
                      // pto: %medium_indices_inline1557_inline9224__ssa_v1
                      ;
                      uint64_t v926 = (uint64_t) v30;
                      TASSIGN(v925, v926);
                      pipe_barrier(PIPE_V);
                      TADDS(v925, v921, v636);
                      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                      // pto: %medium_scores_raw_inline1556_inline9477__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v927 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v633);
                      // pto: %medium_scores_raw_inline1556_inline9477__ssa_v1
                      ;
                      uint64_t v928 = (uint64_t) v29;
                      TASSIGN(v927, v928);
                      // pto: %343, %344, %345
                      ;
                      int64_t v929 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v120) + (uint64_t) v56);
                      // pto: %346
                      ;
                      int64_t v930 = v929 < v45 ? v45 : v929;
                      // pto: %347
                      ;
                      const int64_t v931 = 0;
                      // pto: %347
                      ;
                      __gm__ float* v932 = PTOAS__GLOBAL_TENSOR_DATA(v97);
                      // pto: %347
                      ;
                      const int64_t v933 = 1;
                      // pto: %347
                      ;
                      const int64_t v934 = 1;
                      // pto: %347
                      ;
                      const int64_t v935 = 1;
                      // pto: %347
                      ;
                      int64_t v936 = v38 * v43;
                      // pto: %347
                      ;
                      int64_t v937 = v935 * v936;
                      // pto: %347
                      ;
                      pto::Shape<1, 1, 1, 1, -1> v938 = pto::Shape<1, 1, 1, 1, -1>(v933, v934, v935, v38, v633);
                      // pto: %347
                      ;
                      pto::Stride<-1, -1, -1, -1, -1> v939 = pto::Stride<-1, -1, -1, -1, -1>(v934 * v937, v937, v936, v43, v38);
                      // pto: %347
                      ;
                      GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v940 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v932 + (v931 + v930 * v43 + v45 * v38), v938, v939);
                      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                      TLOAD(v927, v940);
                      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                      // pto: %medium_scores_inline1507_inline9223__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v941 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                      // pto: %medium_scores_inline1507_inline9223__ssa_v1
                      ;
                      uint64_t v942 = (uint64_t) v29;
                      TASSIGN(v941, v942);
                      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                      TFILLPAD<pto::TFillPadMode::InPlace>(v941, v927);
                      // pto: %medium_scores_v1_inline1558_inline9222__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v943 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                      // pto: %medium_scores_v1_inline1558_inline9222__ssa_v1
                      ;
                      uint64_t v944 = (uint64_t) v31;
                      TASSIGN(v943, v944);
                      pipe_barrier(PIPE_V);
                      TMAXS(v943, v941, v63);
                      // pto: %t__tmp_v835
                      ;
                      Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v945 = Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v54);
                      // pto: %t__tmp_v835
                      ;
                      uint64_t v946 = (uint64_t) v30;
                      TASSIGN(v945, v946);
                      // pto: %medium_pairs_inline1498_inline9275__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v947 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v43);
                      // pto: %medium_pairs_inline1498_inline9275__ssa_v1
                      ;
                      uint64_t v948 = (uint64_t) v29;
                      TASSIGN(v947, v948);
                      // pto: %348
                      ;
                      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v949;
                      TRESHAPE(v949, v943);
                      // pto: %349
                      ;
                      Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v950;
                      TRESHAPE(v950, v945);
                      // pto: %350
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 8192, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v951;
                      TRESHAPE(v951, v947);
                      pipe_barrier(PIPE_V);
                      TSORT32(v951, v949, v950);
                      // pto: %medium_pairs_v1_inline1506_inline9335__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v952 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v43);
                      // pto: %medium_pairs_v1_inline1506_inline9335__ssa_v1
                      ;
                      uint64_t v953 = (uint64_t) v30;
                      TASSIGN(v952, v953);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v952, v947, v64);
                      // pto: %medium_pairs_v2_inline1497_inline9221__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v954 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v43);
                      // pto: %medium_pairs_v2_inline1497_inline9221__ssa_v1
                      ;
                      uint64_t v955 = (uint64_t) v29;
                      TASSIGN(v954, v955);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v954, v952, v65);
                      // pto: %medium_pairs_v3_inline1496_inline9220__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v956 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v43);
                      // pto: %medium_pairs_v3_inline1496_inline9220__ssa_v1
                      ;
                      uint64_t v957 = (uint64_t) v30;
                      TASSIGN(v956, v957);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v956, v954, v67);
                      // pto: %medium_left_inline1495_inline9262__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v958 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %medium_left_inline1495_inline9262__ssa_v1
                      ;
                      uint64_t v959 = (uint64_t) v30;
                      TASSIGN(v958, v959);
                      // pto: %351
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v960;
                      // pto: %351
                      ;
                      uint64_t v961 = (uint64_t) v30;
                      TASSIGN(v960, v961);
                      // pto: %medium_right_inline1494_inline9257__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v962 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %medium_right_inline1494_inline9257__ssa_v1
                      ;
                      uint64_t v963 = (uint64_t) v37;
                      TASSIGN(v962, v963);
                      // pto: %352
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v964;
                      // pto: %352
                      ;
                      uint64_t v965 = (uint64_t) v37;
                      TASSIGN(v964, v965);
                      // pto: %medium_tmp_inline1493_inline9219__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v966 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                      // pto: %medium_tmp_inline1493_inline9219__ssa_v1
                      ;
                      uint64_t v967 = (uint64_t) v29;
                      TASSIGN(v966, v967);
                      // pto: %medium_merged_inline1492_inline9218__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v968 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                      // pto: %medium_merged_inline1492_inline9218__ssa_v1
                      ;
                      uint64_t v969 = (uint64_t) v31;
                      TASSIGN(v968, v969);
                      pipe_barrier(PIPE_V);
                      TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v968, v28, v966, v964, v960);
                      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                      // pto: %t__tmp_v836
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v970 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %t__tmp_v836
                      ;
                      uint64_t v971 = (uint64_t) v31;
                      TASSIGN(v970, v971);
                      // pto: %354
                      ;
                      Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v972;
                      // pto: %354
                      ;
                      uint64_t v973 = (uint64_t) v31;
                      TASSIGN(v972, v973);
                      // pto: %355
                      ;
                      int64_t v974 = v635 < v45 ? v45 : v635;
                      // pto: %356
                      ;
                      __gm__ float* v975 = PTOAS__GLOBAL_TENSOR_DATA(v105);
                      // pto: %356
                      ;
                      const int64_t v976 = 0;
                      // pto: %356
                      ;
                      const int64_t v977 = 1024;
                      // pto: %356
                      ;
                      pto::Shape<1, 1, 1, 1, 1024> v978 = pto::Shape<1, 1, 1, 1, 1024>();
                      // pto: %356
                      ;
                      pto::Stride<1024, 1024, 1024, 1024, 1> v979 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                      // pto: %356
                      ;
                      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v980 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v975 + (v976 + v974 * v977), v978, v979);
                      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                      pipe_barrier(PIPE_MTE3);
                      TSTORE(v980, v972);
                    };
                  };
                };
              };
            };
          } else {
            // pto: %t__tmp_v837
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v981 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v44);
            // pto: %t__tmp_v837
            ;
            uint64_t v982 = (uint64_t) v29;
            TASSIGN(v981, v982);
            pipe_barrier(PIPE_V);
            TEXPANDS(v981, v63);
            set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
            // pto: %357
            ;
            int64_t v983 = v635 < v45 ? v45 : v635;
            // pto: %358
            ;
            __gm__ float* v984 = PTOAS__GLOBAL_TENSOR_DATA(v105);
            // pto: %358
            ;
            const int64_t v985 = 0;
            // pto: %358
            ;
            const int64_t v986 = 1024;
            // pto: %358
            ;
            pto::Shape<1, 1, 1, 1, 1024> v987 = pto::Shape<1, 1, 1, 1, 1024>();
            // pto: %358
            ;
            pto::Stride<1024, 1024, 1024, 1024, 1> v988 = pto::Stride<1024, 1024, 1024, 1024, 1>();
            // pto: %358
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v989 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v984 + (v985 + v983 * v986), v987, v988);
            wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
            pipe_barrier(PIPE_MTE3);
            TSTORE(v989, v981);
          };
        };
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    };
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}