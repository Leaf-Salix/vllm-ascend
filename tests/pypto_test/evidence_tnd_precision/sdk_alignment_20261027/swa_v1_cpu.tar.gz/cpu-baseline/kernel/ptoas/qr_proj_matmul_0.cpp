#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qr_proj_matmul_0(__gm__ float* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, int64_t v4, int64_t v5, int64_t v6, int64_t v7, int64_t v8, int64_t v9, int32_t v10, int32_t v11) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v12 = 0;
  // pto: %c32768_i64
  const int64_t v13 = 32768;
  // pto: %c49152_i64
  const int64_t v14 = 49152;
  // pto: %c81920_i64
  const int64_t v15 = 81920;
  // pto: %c16384_i64
  const int64_t v16 = 16384;
  // pto: %c1024_index
  const int64_t v17 = 1024;
  // pto: %c1_index
  const int64_t v18 = 1;
  // pto: %c4096_index
  const int64_t v19 = 4096;
  // pto: %c256_index
  const int64_t v20 = 256;
  // pto: %c64_index
  const int64_t v21 = 64;
  // pto: %c16_index
  const int64_t v22 = 16;
  // pto: %c4194304_index
  const int64_t v23 = 4194304;
  // pto: %c16384_index
  const int64_t v24 = 16384;
  // pto: %c32_index
  const int64_t v25 = 32;
  // pto: %c96_index
  const int64_t v26 = 96;
  // pto: %c0_index
  const int64_t v27 = 0;
  // pto: %c2_index
  const int64_t v28 = 2;
  // pto: %c9_index
  const int64_t v29 = 9;
  // pto: %c7_index
  const int64_t v30 = 7;
  // pto: %c8_index
  const int64_t v31 = 8;
  // pto: %cn1_index
  const int64_t v32 = -1;
  // pto: %qr_fp32_inline0_inline4556__rv_v13_view
  const int64_t v33 = 1;
  // pto: %qr_fp32_inline0_inline4556__rv_v13_view
  const int64_t v34 = 1;
  // pto: %qr_fp32_inline0_inline4556__rv_v13_view
  const int64_t v35 = 1;
  // pto: %qr_fp32_inline0_inline4556__rv_v13_view
  int64_t v36 = (int64_t) v8;
  // pto: %qr_fp32_inline0_inline4556__rv_v13_view
  int64_t v37 = v36 * v17;
  // pto: %qr_fp32_inline0_inline4556__rv_v13_view
  int64_t v38 = v35 * v37;
  // pto: %qr_fp32_inline0_inline4556__rv_v13_view
  pto::Shape<1, 1, 1, -1, -1> v39 = pto::Shape<1, 1, 1, -1, -1>(v33, v34, v35, v36, v17);
  // pto: %qr_fp32_inline0_inline4556__rv_v13_view
  pto::Stride<-1, -1, -1, -1, -1> v40 = pto::Stride<-1, -1, -1, -1, -1>(v34 * v38, v38, v37, v17, v18);
  // pto: %qr_fp32_inline0_inline4556__rv_v13_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v41 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v39, v40);
  // pto: %x_view_inline8070__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %x_view_inline8070__ssa_v0_view
  const int64_t v43 = 1;
  // pto: %x_view_inline8070__ssa_v0_view
  const int64_t v44 = 1;
  // pto: %x_view_inline8070__ssa_v0_view
  int64_t v45 = (int64_t) v9;
  // pto: %x_view_inline8070__ssa_v0_view
  int64_t v46 = v45 * v19;
  // pto: %x_view_inline8070__ssa_v0_view
  int64_t v47 = v44 * v46;
  // pto: %x_view_inline8070__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v48 = pto::Shape<1, 1, 1, -1, -1>(v42, v43, v44, v45, v19);
  // pto: %x_view_inline8070__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v49 = pto::Stride<-1, -1, -1, -1, -1>(v43 * v47, v47, v46, v19, v18);
  // pto: %x_view_inline8070__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v50 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v48, v49);
  // pto: %wq_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v51 = pto::Shape<-1, -1, -1, -1, -1>(v18, v20, v21, v22, v22);
  // pto: %wq_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v52 = pto::Stride<-1, -1, -1, -1, -1>(v23, v24, v20, v22, v18);
  // pto: %wq_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v53 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v3, v51, v52);
  // pto: %qbg_idx_inline8065__ssa_v0, %14
  int64_t v54 = (int64_t) ((uint64_t) ((int64_t) v10) * (uint64_t) v25);
  // pto: %15
  int64_t v55 = v54 / v26;
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  for (int64_t v56 = v27; v56 < v4; v56 += v21) {
    // pto: %16
    ;
    int64_t v57 = (int64_t) ((uint64_t) v5 + (uint64_t) v56);
    // pto: %dense_acc_inline8075__tile
    ;
    Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v58 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v21, v25);
    // pto: %dense_acc_inline8075__tile
    ;
    uint64_t v59 = (uint64_t) v12;
    TASSIGN(v58, v59);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    for (int64_t v60 = v27; v60 < v22; v60 += v28) {
      // pto: %17
      ;
      int64_t v61 = (int64_t) ((uint64_t) v60 + (uint64_t) v18);
      // pto: %18
      ;
      bool v62 = v55 < v29;
      // pto: %dense_k_order_inline8076__phi_v2
      ;
      int64_t v63;
      if (v62) {
        // pto: %19
        ;
        int64_t v64 = v60 / v28;
        // pto: %20
        ;
        int64_t v65 = v55 % v28;
        // pto: %21, %22, %23
        ;
        int64_t v66 = v65 < v27 ? (int64_t) ((uint64_t) v65 + (uint64_t) v28) : v65;
        // pto: %24
        ;
        // pto: %native_packet_inline8082__phi_v2
        ;
        int64_t v67;
        if (v66 == v18) {
          // pto: %25
          ;
          v67 = (int64_t) ((uint64_t) v30 - (uint64_t) v64);
        } else {
          v67 = v64;
        };
        // pto: %27
        ;
        uint64_t v68 = (uint64_t) v67;
        // pto: %26, %27, %28
        ;
        int64_t v69 = (int64_t) ((uint64_t) (v55 / v28) + v68) % v31;
        // pto: %29, %30, %31
        ;
        int64_t v70 = v69 < v27 ? (int64_t) ((uint64_t) v69 + (uint64_t) v31) : v69;
        // pto: %33
        ;
        int64_t v71 = v60 % v28;
        // pto: %34, %35, %36
        ;
        int64_t v72 = v71 < v27 ? (int64_t) ((uint64_t) v71 + (uint64_t) v28) : v71;
        // pto: %32, %37
        ;
        v63 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v70 * (uint64_t) v28) + (uint64_t) v72);
      } else {
        v63 = v60;
      };
      // pto: %38
      ;
      bool v73 = v63 < v27;
      // pto: %38
      ;
      int64_t v74 = v73 ? v27 : v63;
      // pto: %39
      ;
      int64_t v75 = (int64_t) ((uint64_t) v74 * (uint64_t) v20);
      // pto: %dense_x_inline8077__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v76 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v21, v20);
      // pto: %dense_x_inline8077__tile
      ;
      uint64_t v77 = (uint64_t) v12;
      TASSIGN(v76, v77);
      // pto: %40
      ;
      int64_t v78 = v57 < v27 ? v27 : v57;
      // pto: %41
      ;
      int64_t v79 = v75 < v27 ? v27 : v75;
      // pto: %x_view_inline8070__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v80 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %x_view_inline8070__ssa_v0_pview
      ;
      const int64_t v81 = 0;
      // pto: %x_view_inline8070__ssa_v0_pview
      ;
      const int64_t v82 = 4096;
      // pto: %x_view_inline8070__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 64, 256> v83 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %x_view_inline8070__ssa_v0_pview
      ;
      pto::Stride<262144, 262144, 262144, 4096, 1> v84 = pto::Stride<262144, 262144, 262144, 4096, 1>();
      // pto: %x_view_inline8070__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND> v85 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND>(v80 + (v81 + v78 * v82 + v79), v83, v84);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v76, v85);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %dense_w_inline8080__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v86 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v20);
      // pto: %dense_w_inline8080__tile
      ;
      uint64_t v87 = (uint64_t) v13;
      TASSIGN(v86, v87);
      // pto: %42
      ;
      int64_t v88 = v75 / v22;
      // pto: %43
      ;
      int64_t v89 = v88 < v27 ? v27 : v88;
      // pto: %44
      ;
      int64_t v90 = v54 / v22;
      // pto: %45
      ;
      int64_t v91 = v90 < v27 ? v27 : v90;
      // pto: %wq_a__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v92 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %wq_a__ssa_v0_pview
      ;
      const int64_t v93 = 0;
      // pto: %wq_a__ssa_v0_pview
      ;
      const int64_t v94 = 16384;
      // pto: %wq_a__ssa_v0_pview
      ;
      const int64_t v95 = 256;
      // pto: %wq_a__ssa_v0_pview
      ;
      pto::Shape<1, 16, 2, 16, 16> v96 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %wq_a__ssa_v0_pview
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v97 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %wq_a__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v98 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v92 + (v93 + v89 * v94 + v91 * v95), v96, v97);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v86, v98);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %47
      ;
      int64_t v99;
      if (v62) {
        // pto: %49
        ;
        int64_t v100 = v61 / v28;
        // pto: %50
        ;
        int64_t v101 = v55 % v28;
        // pto: %51, %52, %53
        ;
        int64_t v102 = v101 < v27 ? (int64_t) ((uint64_t) v101 + (uint64_t) v28) : v101;
        // pto: %54
        ;
        // pto: %55
        ;
        int64_t v103;
        if (v102 == v18) {
          // pto: %56
          ;
          v103 = (int64_t) ((uint64_t) v30 - (uint64_t) v100);
        } else {
          v103 = v100;
        };
        // pto: %58
        ;
        uint64_t v104 = (uint64_t) v103;
        // pto: %57, %58, %59
        ;
        int64_t v105 = (int64_t) ((uint64_t) (v55 / v28) + v104) % v31;
        // pto: %60, %61, %62
        ;
        int64_t v106 = v105 < v27 ? (int64_t) ((uint64_t) v105 + (uint64_t) v31) : v105;
        // pto: %65
        ;
        int64_t v107 = v61 % v28;
        // pto: %66, %67, %68
        ;
        int64_t v108 = v107 < v27 ? (int64_t) ((uint64_t) v107 + (uint64_t) v28) : v107;
        // pto: %63, %69
        ;
        v99 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v28) + (uint64_t) v108);
      } else {
        v99 = v61;
      };
      // pto: %70
      ;
      bool v109 = v99 < v27;
      // pto: %70
      ;
      int64_t v110 = v109 ? v27 : v99;
      // pto: %71
      ;
      int64_t v111 = (int64_t) ((uint64_t) v110 * (uint64_t) v20);
      // pto: %0
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v112 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v21, v20);
      // pto: %0
      ;
      uint64_t v113 = (uint64_t) v14;
      TASSIGN(v112, v113);
      // pto: %73
      ;
      int64_t v114 = v111 < v27 ? v27 : v111;
      // pto: %74
      ;
      __gm__ bfloat16_t* v115 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %74
      ;
      const int64_t v116 = 0;
      // pto: %74
      ;
      const int64_t v117 = 4096;
      // pto: %74
      ;
      pto::Shape<1, 1, 1, 64, 256> v118 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %74
      ;
      pto::Stride<262144, 262144, 262144, 4096, 1> v119 = pto::Stride<262144, 262144, 262144, 4096, 1>();
      // pto: %74
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND> v120 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND>(v115 + (v116 + v78 * v117 + v114), v118, v119);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v112, v120);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      // pto: %1
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v20);
      // pto: %1
      ;
      uint64_t v122 = (uint64_t) v15;
      TASSIGN(v121, v122);
      // pto: %75
      ;
      int64_t v123 = v111 / v22;
      // pto: %76
      ;
      int64_t v124 = v123 < v27 ? v27 : v123;
      // pto: %79
      ;
      __gm__ bfloat16_t* v125 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %79
      ;
      const int64_t v126 = 0;
      // pto: %79
      ;
      const int64_t v127 = 16384;
      // pto: %79
      ;
      const int64_t v128 = 256;
      // pto: %79
      ;
      pto::Shape<1, 16, 2, 16, 16> v129 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %79
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v130 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %79
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v131 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v125 + (v126 + v124 * v127 + v91 * v128), v129, v130);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v121, v131);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %dense_w_inline8080__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v132 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %dense_w_inline8080__tile_t
      ;
      uint64_t v133 = (uint64_t) v13;
      TASSIGN(v132, v133);
      // pto: %dense_x_inline8077__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v134 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v21, v20);
      // pto: %dense_x_inline8077__tile_Left
      ;
      uint64_t v135 = (uint64_t) v13;
      TASSIGN(v134, v135);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      TMOV(v134, v76);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %dense_w_inline8080__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v136 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %dense_w_inline8080__tile_t_Right
      ;
      uint64_t v137 = (uint64_t) v16;
      TASSIGN(v136, v137);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      TMOV(v136, v132);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %80
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (v60 == v27) {
        pipe_barrier(PIPE_M);
        TMATMUL(v58, v134, v136);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v58, v58, v134, v136);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      // pto: %3
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v138 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %3
      ;
      uint64_t v139 = (uint64_t) v15;
      TASSIGN(v138, v139);
      // pto: %4
      ;
      Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v140 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v21, v20);
      // pto: %4
      ;
      uint64_t v141 = (uint64_t) v12;
      TASSIGN(v140, v141);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      TMOV(v140, v112);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      // pto: %5
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v142 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %5
      ;
      uint64_t v143 = (uint64_t) v12;
      TASSIGN(v142, v143);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      TMOV(v142, v138);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      // pto: %81
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      if (v60 == v32) {
        pipe_barrier(PIPE_M);
        TMATMUL(v58, v140, v142);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v58, v58, v140, v142);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    };
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %82
    ;
    int64_t v144 = v56 < v27 ? v27 : v56;
    // pto: %83
    ;
    int64_t v145 = v54 < v27 ? v27 : v54;
    // pto: %qr_fp32_inline0_inline4556__iter_v17_pview
    ;
    __gm__ float* v146 = PTOAS__GLOBAL_TENSOR_DATA(v41);
    // pto: %qr_fp32_inline0_inline4556__iter_v17_pview
    ;
    const int64_t v147 = 0;
    // pto: %qr_fp32_inline0_inline4556__iter_v17_pview
    ;
    const int64_t v148 = 1024;
    // pto: %qr_fp32_inline0_inline4556__iter_v17_pview
    ;
    pto::Shape<1, 1, 1, 64, 32> v149 = pto::Shape<1, 1, 1, 64, 32>();
    // pto: %qr_fp32_inline0_inline4556__iter_v17_pview
    ;
    pto::Stride<65536, 65536, 65536, 1024, 1> v150 = pto::Stride<65536, 65536, 65536, 1024, 1>();
    // pto: %qr_fp32_inline0_inline4556__iter_v17_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 64, 32>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND> v151 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 32>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND>(v146 + (v147 + v144 * v148 + v145), v149, v150);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE(v151, v58);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  for (int64_t v152 = v4; v152 < v6; v152 += v22) {
    // pto: %q_acc_inline8087__tile
    ;
    Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v153 = Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %q_acc_inline8087__tile
    ;
    uint64_t v154 = (uint64_t) v12;
    TASSIGN(v153, v154);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    for (int64_t v155 = v27; v155 < v22; v155 += v28) {
      // pto: %84
      ;
      int64_t v156 = (int64_t) ((uint64_t) v7 - (uint64_t) v152);
      // pto: %85
      ;
      int64_t v157 = v156 < v22 ? v156 : v22;
      // pto: %86
      ;
      int64_t v158 = (int64_t) ((uint64_t) v5 + (uint64_t) v152);
      // pto: %87
      ;
      int64_t v159 = (int64_t) ((uint64_t) v155 + (uint64_t) v18);
      // pto: %91
      ;
      bool v160 = v55 < v29;
      // pto: %qr_k_order_inline8084__phi_v2
      ;
      int64_t v161;
      if (v160) {
        // pto: %92
        ;
        int64_t v162 = v155 / v28;
        // pto: %93
        ;
        int64_t v163 = v55 % v28;
        // pto: %94, %95, %96
        ;
        int64_t v164 = v163 < v27 ? (int64_t) ((uint64_t) v163 + (uint64_t) v28) : v163;
        // pto: %97
        ;
        // pto: %native_packet_v1_inline8072__phi_v2
        ;
        int64_t v165;
        if (v164 == v18) {
          // pto: %98
          ;
          v165 = (int64_t) ((uint64_t) v30 - (uint64_t) v162);
        } else {
          v165 = v162;
        };
        // pto: %100
        ;
        uint64_t v166 = (uint64_t) v165;
        // pto: %99, %100, %101
        ;
        int64_t v167 = (int64_t) ((uint64_t) (v55 / v28) + v166) % v31;
        // pto: %102, %103, %104
        ;
        int64_t v168 = v167 < v27 ? (int64_t) ((uint64_t) v167 + (uint64_t) v31) : v167;
        // pto: %106
        ;
        int64_t v169 = v155 % v28;
        // pto: %107, %108, %109
        ;
        int64_t v170 = v169 < v27 ? (int64_t) ((uint64_t) v169 + (uint64_t) v28) : v169;
        // pto: %105, %110
        ;
        v161 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v168 * (uint64_t) v28) + (uint64_t) v170);
      } else {
        v161 = v155;
      };
      // pto: %111
      ;
      bool v171 = v161 < v27;
      // pto: %111
      ;
      int64_t v172 = v171 ? v27 : v161;
      // pto: %112
      ;
      int64_t v173 = (int64_t) ((uint64_t) v172 * (uint64_t) v20);
      // pto: %q_x_chunk_bf16_inline8078__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v174 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v157, v20);
      // pto: %q_x_chunk_bf16_inline8078__tile
      ;
      uint64_t v175 = (uint64_t) v13;
      TASSIGN(v174, v175);
      // pto: %113
      ;
      int64_t v176 = v158 < v27 ? v27 : v158;
      // pto: %114
      ;
      int64_t v177 = v173 < v27 ? v27 : v173;
      // pto: %115
      ;
      const int64_t v178 = 0;
      // pto: %115
      ;
      __gm__ bfloat16_t* v179 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %115
      ;
      const int64_t v180 = 1;
      // pto: %115
      ;
      const int64_t v181 = 1;
      // pto: %115
      ;
      const int64_t v182 = 1;
      // pto: %115
      ;
      int64_t v183 = v157 * v19;
      // pto: %115
      ;
      int64_t v184 = v182 * v183;
      // pto: %115
      ;
      pto::Shape<1, 1, 1, -1, 256> v185 = pto::Shape<1, 1, 1, -1, 256>(v180, v181, v182, v157, v20);
      // pto: %115
      ;
      pto::Stride<-1, -1, -1, -1, -1> v186 = pto::Stride<-1, -1, -1, -1, -1>(v181 * v184, v184, v183, v19, v18);
      // pto: %115
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v187 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v179 + (v178 + v176 * v19 + v177 * v18), v185, v186);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      TLOAD(v174, v187);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      // pto: %w_chunk_inline8059__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v188 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v20);
      // pto: %w_chunk_inline8059__tile
      ;
      uint64_t v189 = (uint64_t) v12;
      TASSIGN(v188, v189);
      // pto: %116
      ;
      int64_t v190 = v173 / v22;
      // pto: %117
      ;
      int64_t v191 = v190 < v27 ? v27 : v190;
      // pto: %118
      ;
      int64_t v192 = v54 / v22;
      // pto: %119
      ;
      int64_t v193 = v192 < v27 ? v27 : v192;
      // pto: %120
      ;
      __gm__ bfloat16_t* v194 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %120
      ;
      const int64_t v195 = 0;
      // pto: %120
      ;
      const int64_t v196 = 16384;
      // pto: %120
      ;
      const int64_t v197 = 256;
      // pto: %120
      ;
      pto::Shape<1, 16, 2, 16, 16> v198 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %120
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v199 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %120
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v200 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v194 + (v195 + v191 * v196 + v193 * v197), v198, v199);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      TLOAD(v188, v200);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      // pto: %122
      ;
      int64_t v201;
      if (v160) {
        // pto: %124
        ;
        int64_t v202 = v159 / v28;
        // pto: %125
        ;
        int64_t v203 = v55 % v28;
        // pto: %126, %127, %128
        ;
        int64_t v204 = v203 < v27 ? (int64_t) ((uint64_t) v203 + (uint64_t) v28) : v203;
        // pto: %129
        ;
        // pto: %130
        ;
        int64_t v205;
        if (v204 == v18) {
          // pto: %131
          ;
          v205 = (int64_t) ((uint64_t) v30 - (uint64_t) v202);
        } else {
          v205 = v202;
        };
        // pto: %133
        ;
        uint64_t v206 = (uint64_t) v205;
        // pto: %132, %133, %134
        ;
        int64_t v207 = (int64_t) ((uint64_t) (v55 / v28) + v206) % v31;
        // pto: %135, %136, %137
        ;
        int64_t v208 = v207 < v27 ? (int64_t) ((uint64_t) v207 + (uint64_t) v31) : v207;
        // pto: %140
        ;
        int64_t v209 = v159 % v28;
        // pto: %141, %142, %143
        ;
        int64_t v210 = v209 < v27 ? (int64_t) ((uint64_t) v209 + (uint64_t) v28) : v209;
        // pto: %138, %144
        ;
        v201 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v208 * (uint64_t) v28) + (uint64_t) v210);
      } else {
        v201 = v159;
      };
      // pto: %145
      ;
      bool v211 = v201 < v27;
      // pto: %145
      ;
      int64_t v212 = v211 ? v27 : v201;
      // pto: %146
      ;
      int64_t v213 = (int64_t) ((uint64_t) v212 * (uint64_t) v20);
      // pto: %7
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v214 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v157, v20);
      // pto: %7
      ;
      uint64_t v215 = (uint64_t) v15;
      TASSIGN(v214, v215);
      // pto: %148
      ;
      int64_t v216 = v213 < v27 ? v27 : v213;
      // pto: %149
      ;
      const int64_t v217 = 0;
      // pto: %149
      ;
      __gm__ bfloat16_t* v218 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %149
      ;
      const int64_t v219 = 1;
      // pto: %149
      ;
      const int64_t v220 = 1;
      // pto: %149
      ;
      const int64_t v221 = 1;
      // pto: %149
      ;
      int64_t v222 = v157 * v19;
      // pto: %149
      ;
      int64_t v223 = v221 * v222;
      // pto: %149
      ;
      pto::Shape<1, 1, 1, -1, 256> v224 = pto::Shape<1, 1, 1, -1, 256>(v219, v220, v221, v157, v20);
      // pto: %149
      ;
      pto::Stride<-1, -1, -1, -1, -1> v225 = pto::Stride<-1, -1, -1, -1, -1>(v220 * v223, v223, v222, v19, v18);
      // pto: %149
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v226 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v218 + (v217 + v176 * v19 + v216 * v18), v224, v225);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      TLOAD(v214, v226);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
      // pto: %8
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v227 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v20);
      // pto: %8
      ;
      uint64_t v228 = (uint64_t) v14;
      TASSIGN(v227, v228);
      // pto: %150
      ;
      int64_t v229 = v213 / v22;
      // pto: %151
      ;
      int64_t v230 = v229 < v27 ? v27 : v229;
      // pto: %154
      ;
      __gm__ bfloat16_t* v231 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %154
      ;
      const int64_t v232 = 0;
      // pto: %154
      ;
      const int64_t v233 = 16384;
      // pto: %154
      ;
      const int64_t v234 = 256;
      // pto: %154
      ;
      pto::Shape<1, 16, 2, 16, 16> v235 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %154
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v236 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %154
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v237 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v231 + (v232 + v230 * v233 + v193 * v234), v235, v236);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v227, v237);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
      // pto: %w_chunk_inline8059__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v238 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %w_chunk_inline8059__tile_t
      ;
      uint64_t v239 = (uint64_t) v12;
      TASSIGN(v238, v239);
      // pto: %q_x_chunk_bf16_inline8078__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v240 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v157, v20);
      // pto: %q_x_chunk_bf16_inline8078__tile_Left
      ;
      uint64_t v241 = (uint64_t) v13;
      TASSIGN(v240, v241);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      TMOV(v240, v174);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      // pto: %w_chunk_inline8059__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v242 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %w_chunk_inline8059__tile_t_Right
      ;
      uint64_t v243 = (uint64_t) v16;
      TASSIGN(v242, v243);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      TMOV(v242, v238);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      // pto: %155
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      if (v155 == v27) {
        pipe_barrier(PIPE_M);
        TMATMUL(v153, v240, v242);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v153, v153, v240, v242);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      // pto: %10
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v244 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %10
      ;
      uint64_t v245 = (uint64_t) v14;
      TASSIGN(v244, v245);
      // pto: %11
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v246 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v157, v20);
      // pto: %11
      ;
      uint64_t v247 = (uint64_t) v12;
      TASSIGN(v246, v247);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      TMOV(v246, v214);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      // pto: %12
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v248 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %12
      ;
      uint64_t v249 = (uint64_t) v12;
      TASSIGN(v248, v249);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
      TMOV(v248, v244);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %156
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      if (v155 == v32) {
        pipe_barrier(PIPE_M);
        TMATMUL(v153, v246, v248);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v153, v153, v246, v248);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    };
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
    // pto: %158
    ;
    int64_t v250 = v152 < v27 ? v27 : v152;
    // pto: %159
    ;
    int64_t v251 = v54 < v27 ? v27 : v54;
    // pto: %qr_fp32_inline0_inline4556__iter_v20_pview
    ;
    __gm__ float* v252 = PTOAS__GLOBAL_TENSOR_DATA(v41);
    // pto: %qr_fp32_inline0_inline4556__iter_v20_pview
    ;
    const int64_t v253 = 0;
    // pto: %qr_fp32_inline0_inline4556__iter_v20_pview
    ;
    const int64_t v254 = 1024;
    // pto: %qr_fp32_inline0_inline4556__iter_v20_pview
    ;
    pto::Shape<1, 1, 1, 16, 32> v255 = pto::Shape<1, 1, 1, 16, 32>();
    // pto: %qr_fp32_inline0_inline4556__iter_v20_pview
    ;
    pto::Stride<16384, 16384, 16384, 1024, 1> v256 = pto::Stride<16384, 16384, 16384, 1024, 1>();
    // pto: %qr_fp32_inline0_inline4556__iter_v20_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND> v257 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND>(v252 + (v253 + v250 * v254 + v251), v255, v256);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
    pipe_barrier(PIPE_FIX);
    TSTORE(v257, v153);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}