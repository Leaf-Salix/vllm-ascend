#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qproj_dequant_rms_nope_rope(__gm__ bfloat16_t* v1, __gm__ float* v2, __gm__ float* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, __gm__ float* v7, int64_t v8, int64_t v9, int64_t v10, int64_t v11, int64_t v12, int64_t v13, int32_t v14, int32_t v15) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v16 = 256;
  // pto: %c79872_i64
  const int64_t v17 = 79872;
  // pto: %c79904_i64
  const int64_t v18 = 79904;
  // pto: %c81952_i64
  const int64_t v19 = 81952;
  // pto: %c0_i64
  const int64_t v20 = 0;
  // pto: %c2048_i64
  const int64_t v21 = 2048;
  // pto: %c18432_i64
  const int64_t v22 = 18432;
  // pto: %c20480_i64
  const int64_t v23 = 20480;
  // pto: %c36864_i64
  const int64_t v24 = 36864;
  // pto: %c38912_i64
  const int64_t v25 = 38912;
  const int64_t v26 = 39936;
  const int64_t v27 = 39168;
  const int64_t v28 = 40192;
  // pto: %c55296_i64
  const int64_t v29 = 55296;
  const int64_t v30 = 39424;
  const int64_t v31 = 40448;
  // pto: %c57344_i64
  const int64_t v32 = 57344;
  const int64_t v33 = 39680;
  const int64_t v34 = 40704;
  const int64_t v35 = 3840;
  // pto: %c59392_i64
  const int64_t v36 = 59392;
  const int64_t v37 = 60416;
  const int64_t v38 = 59648;
  const int64_t v39 = 60672;
  // pto: %c75776_i64
  const int64_t v40 = 75776;
  const int64_t v41 = 59904;
  const int64_t v42 = 60928;
  // pto: %c77824_i64
  const int64_t v43 = 77824;
  const int64_t v44 = 60160;
  const int64_t v45 = 61184;
  const int64_t v46 = 22272;
  const int64_t v47 = 21504;
  const int64_t v48 = 20736;
  const int64_t v49 = 21760;
  const int64_t v50 = 20992;
  const int64_t v51 = 22016;
  const int64_t v52 = 21248;
  // pto: %c32768_index
  const int64_t v53 = 32768;
  // pto: %c1_index
  const int64_t v54 = 1;
  // pto: %c512_index
  const int64_t v55 = 512;
  // pto: %c64_index
  const int64_t v56 = 64;
  // pto: %c384_index
  const int64_t v57 = 384;
  // pto: %c0_index
  const int64_t v58 = 0;
  // pto: %c96_index
  const int64_t v59 = 96;
  // pto: %c16_index
  const int64_t v60 = 16;
  // pto: %c4_index
  const int64_t v61 = 4;
  // pto: %c7_index
  const int64_t v62 = 7;
  // pto: %c8_index
  const int64_t v63 = 8;
  // pto: %c48_index
  const int64_t v64 = 48;
  // pto: %c2_index
  const int64_t v65 = 2;
  // pto: %cst_49
  const float v66 = 1.0f;
  // pto: %c128_index
  const int64_t v67 = 128;
  // pto: %c192_index
  const int64_t v68 = 192;
  // pto: %c448_index
  const int64_t v69 = 448;
  // pto: %cst_55
  const float v70 = 0.001953125f;
  // pto: %cst_56
  const float v71 = 9.99999997E-7f;
  // pto: %c0_i32
  const int32_t v72 = 0;
  // pto: %cst_58
  const float v73 = 0.5f;
  // pto: %cst_59
  const float v74 = 2.0f;
  // pto: %cst_60
  const float v75 = 64.0f;
  // pto: %q_flat_inline8276__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %q_flat_inline8276__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %q_flat_inline8276__ssa_v0_view
  const int64_t v78 = 1;
  // pto: %q_flat_inline8276__ssa_v0_view
  int64_t v79 = (int64_t) v10;
  // pto: %q_flat_inline8276__ssa_v0_view
  int64_t v80 = v79 * v53;
  // pto: %q_flat_inline8276__ssa_v0_view
  int64_t v81 = v78 * v80;
  // pto: %q_flat_inline8276__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v82 = pto::Shape<1, 1, 1, -1, -1>(v76, v77, v78, v79, v53);
  // pto: %q_flat_inline8276__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v83 = pto::Stride<-1, -1, -1, -1, -1>(v77 * v81, v81, v80, v53, v54);
  // pto: %q_flat_inline8276__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v84 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v82, v83);
  // pto: %qr_scale_pad_store_inline4553__rv_v2_view
  const int64_t v85 = 1;
  // pto: %qr_scale_pad_store_inline4553__rv_v2_view
  const int64_t v86 = 1;
  // pto: %qr_scale_pad_store_inline4553__rv_v2_view
  const int64_t v87 = 1;
  // pto: %qr_scale_pad_store_inline4553__rv_v2_view
  int64_t v88 = v55 * v54;
  // pto: %qr_scale_pad_store_inline4553__rv_v2_view
  int64_t v89 = v87 * v88;
  // pto: %qr_scale_pad_store_inline4553__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v90 = pto::Shape<1, 1, 1, -1, -1>(v85, v86, v87, v55, v54);
  // pto: %qr_scale_pad_store_inline4553__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v91 = pto::Stride<-1, -1, -1, -1, -1>(v86 * v89, v89, v88, v54, v55);
  // pto: %qr_scale_pad_store_inline4553__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v92 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v2, v90, v91);
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v93 = 1;
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v94 = 1;
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v96 = (int64_t) v11;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v97 = v96 * v56;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v98 = v95 * v97;
  // pto: %freqs_cos__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v99 = pto::Shape<1, 1, 1, -1, -1>(v93, v94, v95, v96, v56);
  // pto: %freqs_cos__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v100 = pto::Stride<-1, -1, -1, -1, -1>(v94 * v98, v98, v97, v56, v54);
  // pto: %freqs_cos__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v101 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v99, v100);
  // pto: %q_rope_sin_signed_inline954__ssa_v0_view
  const int64_t v102 = 1;
  // pto: %q_rope_sin_signed_inline954__ssa_v0_view
  const int64_t v103 = 1;
  // pto: %q_rope_sin_signed_inline954__ssa_v0_view
  const int64_t v104 = 1;
  // pto: %q_rope_sin_signed_inline954__ssa_v0_view
  int64_t v105 = (int64_t) v12;
  // pto: %q_rope_sin_signed_inline954__ssa_v0_view
  int64_t v106 = v105 * v56;
  // pto: %q_rope_sin_signed_inline954__ssa_v0_view
  int64_t v107 = v104 * v106;
  // pto: %q_rope_sin_signed_inline954__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v108 = pto::Shape<1, 1, 1, -1, -1>(v102, v103, v104, v105, v56);
  // pto: %q_rope_sin_signed_inline954__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v109 = pto::Stride<-1, -1, -1, -1, -1>(v103 * v107, v107, v106, v56, v54);
  // pto: %q_rope_sin_signed_inline954__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v110 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v108, v109);
  // pto: %q_rope_swap_idx_inline955__ssa_v0_view
  const int64_t v111 = 1;
  // pto: %q_rope_swap_idx_inline955__ssa_v0_view
  const int64_t v112 = 1;
  // pto: %q_rope_swap_idx_inline955__ssa_v0_view
  const int64_t v113 = 1;
  // pto: %q_rope_swap_idx_inline955__ssa_v0_view
  int64_t v114 = (int64_t) v12;
  // pto: %q_rope_swap_idx_inline955__ssa_v0_view
  int64_t v115 = v114 * v56;
  // pto: %q_rope_swap_idx_inline955__ssa_v0_view
  int64_t v116 = v113 * v115;
  // pto: %q_rope_swap_idx_inline955__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v117 = pto::Shape<1, 1, 1, -1, -1>(v111, v112, v113, v114, v56);
  // pto: %q_rope_swap_idx_inline955__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v118 = pto::Stride<-1, -1, -1, -1, -1>(v112 * v116, v116, v115, v56, v54);
  // pto: %q_rope_swap_idx_inline955__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v119 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v117, v118);
  // pto: %q_proj_i32_inline6_inline4554__ssa_v9_view
  const int64_t v120 = 1;
  // pto: %q_proj_i32_inline6_inline4554__ssa_v9_view
  const int64_t v121 = 1;
  // pto: %q_proj_i32_inline6_inline4554__ssa_v9_view
  const int64_t v122 = 1;
  // pto: %q_proj_i32_inline6_inline4554__ssa_v9_view
  int64_t v123 = (int64_t) v13;
  // pto: %q_proj_i32_inline6_inline4554__ssa_v9_view
  int64_t v124 = v123 * v53;
  // pto: %q_proj_i32_inline6_inline4554__ssa_v9_view
  int64_t v125 = v122 * v124;
  // pto: %q_proj_i32_inline6_inline4554__ssa_v9_view
  pto::Shape<1, 1, 1, -1, -1> v126 = pto::Shape<1, 1, 1, -1, -1>(v120, v121, v122, v123, v53);
  // pto: %q_proj_i32_inline6_inline4554__ssa_v9_view
  pto::Stride<-1, -1, -1, -1, -1> v127 = pto::Stride<-1, -1, -1, -1, -1>(v121 * v125, v125, v124, v53, v54);
  // pto: %q_proj_i32_inline6_inline4554__ssa_v9_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v128 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v126, v127);
  // pto: %wq_b_scale__ssa_v0_view
  const int64_t v129 = 1;
  // pto: %wq_b_scale__ssa_v0_view
  const int64_t v130 = 1;
  // pto: %wq_b_scale__ssa_v0_view
  const int64_t v131 = 1;
  // pto: %wq_b_scale__ssa_v0_view
  const int64_t v132 = 1;
  // pto: %wq_b_scale__ssa_v0_view
  int64_t v133 = v53 * v54;
  // pto: %wq_b_scale__ssa_v0_view
  int64_t v134 = v132 * v133;
  // pto: %wq_b_scale__ssa_v0_view
  int64_t v135 = v131 * v134;
  // pto: %wq_b_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v136 = pto::Shape<1, 1, 1, 1, -1>(v129, v130, v131, v132, v53);
  // pto: %wq_b_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v137 = pto::Stride<-1, -1, -1, -1, -1>(v130 * v135, v135, v134, v133, v54);
  // pto: %wq_b_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v138 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v136, v137);
  // pto: %dq_worker_inline8255__ssa_v0
  // pto: %118
  int64_t v139 = v8 % v57;
  // pto: %119, %120, %121
  int64_t v140 = v139 < v58 ? (int64_t) ((uint64_t) v139 + (uint64_t) v57) : v139;
  // pto: %117, %122, %123
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  // pto: %dq_head_tile_inline8273__phi_v4
  int64_t v141;
  if (v8 >= v57 & v140 == v58) {
    v141 = v56;
  } else {
    // pto: %125
    ;
    int64_t v142 = v8 % v59;
    // pto: %126, %127, %128
    ;
    int64_t v143 = v142 < v58 ? (int64_t) ((uint64_t) v142 + (uint64_t) v59) : v142;
    // pto: %124, %129, %130, %dq_head_tile_inline8273__phi_v3
    ;
    v141 = v8 >= v59 & v143 == v58 ? v60 : v61;
  }
  // pto: %133
  int64_t v144 = v56 / v141;
  // pto: %131, %132, %134
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v145 = (int64_t) v14; v145 < ((int64_t) ((uint64_t) ((int64_t) ((uint64_t) v8 + (uint64_t) v62) / v63) * (uint64_t) v144)); v145 += v64) {
    // pto: %136
    ;
    int64_t v146 = v145 % v144;
    // pto: %140, %137, %138, %139, %141, %142, %143
    ;
    int64_t v147 = v146 != v58 & (v146 < v58 ^ v144 < v58) ? (int64_t) ((uint64_t) v146 + (uint64_t) v144) : v146;
    // pto: %144
    ;
    uint64_t v148 = (uint64_t) v141;
    // pto: %144
    ;
    int64_t v149 = (int64_t) ((uint64_t) v147 * v148);
    // pto: %146, %147
    ;
    int64_t v150 = (int64_t) ((uint64_t) (v145 / v144) * (uint64_t) v63);
    // pto: %148
    ;
    int64_t v151 = (int64_t) ((uint64_t) v9 + (uint64_t) v150);
    // pto: %149, %150
    ;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    if ((int64_t) ((uint64_t) v150 + (uint64_t) v63) <= v8) {
      // pto: %qr_scale_dq_t_inline8242__tile
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v152 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
      // pto: %qr_scale_dq_t_inline8242__tile
      ;
      uint64_t v153 = (uint64_t) v17;
      TASSIGN(v152, v153);
      // pto: %151
      ;
      int64_t v154 = v150 < v58 ? v58 : v150;
      // pto: %qr_scale_pad_store_inline4553__rv_v2_pview
      ;
      __gm__ float* v155 = PTOAS__GLOBAL_TENSOR_DATA(v92);
      // pto: %qr_scale_pad_store_inline4553__rv_v2_pview
      ;
      const int64_t v156 = 0;
      // pto: %qr_scale_pad_store_inline4553__rv_v2_pview
      ;
      pto::Shape<1, 1, 1, 8, 1> v157 = pto::Shape<1, 1, 1, 8, 1>();
      // pto: %qr_scale_pad_store_inline4553__rv_v2_pview
      ;
      pto::Stride<8, 8, 8, 1, 512> v158 = pto::Stride<8, 8, 8, 1, 512>();
      // pto: %qr_scale_pad_store_inline4553__rv_v2_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 512>, pto::Layout::DN> v159 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 512>, pto::Layout::DN>(v155 + (v156 + v154), v157, v158);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
      pipe_barrier(PIPE_ALL);
      TLOAD(v152, v159);
      // pto: %q_cos_il_inline8245__tile
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v160 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_cos_il_inline8245__tile
      ;
      uint64_t v161 = (uint64_t) v18;
      TASSIGN(v160, v161);
      // pto: %152
      ;
      int64_t v162 = v151 < v58 ? v58 : v151;
      // pto: %freqs_cos__ssa_v0_pview
      ;
      __gm__ float* v163 = PTOAS__GLOBAL_TENSOR_DATA(v101);
      // pto: %freqs_cos__ssa_v0_pview
      ;
      const int64_t v164 = 0;
      // pto: %freqs_cos__ssa_v0_pview
      ;
      const int64_t v165 = 64;
      // pto: %freqs_cos__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 64> v166 = pto::Shape<1, 1, 1, 8, 64>();
      // pto: %freqs_cos__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 64, 1> v167 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %freqs_cos__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v168 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v163 + (v164 + v162 * v165), v166, v167);
      pipe_barrier(PIPE_ALL);
      TLOAD(v160, v168);
      // pto: %q_sin_signed_inline8271__tile
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_sin_signed_inline8271__tile
      ;
      uint64_t v170 = (uint64_t) v19;
      TASSIGN(v169, v170);
      // pto: %q_rope_sin_signed_inline954__ssa_v0_pview
      ;
      __gm__ float* v171 = PTOAS__GLOBAL_TENSOR_DATA(v110);
      // pto: %q_rope_sin_signed_inline954__ssa_v0_pview
      ;
      const int64_t v172 = 0;
      // pto: %q_rope_sin_signed_inline954__ssa_v0_pview
      ;
      const int64_t v173 = 64;
      // pto: %q_rope_sin_signed_inline954__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 64> v174 = pto::Shape<1, 1, 1, 8, 64>();
      // pto: %q_rope_sin_signed_inline954__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 64, 1> v175 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %q_rope_sin_signed_inline954__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v176 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v171 + (v172 + v162 * v173), v174, v175);
      pipe_barrier(PIPE_ALL);
      TLOAD(v169, v176);
      // pto: %q_swap_idx_inline8250__tile
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_swap_idx_inline8250__tile
      ;
      uint64_t v178 = (uint64_t) v20;
      TASSIGN(v177, v178);
      // pto: %q_rope_swap_idx_inline955__ssa_v0_pview
      ;
      __gm__ int32_t* v179 = PTOAS__GLOBAL_TENSOR_DATA(v119);
      // pto: %q_rope_swap_idx_inline955__ssa_v0_pview
      ;
      const int64_t v180 = 0;
      // pto: %q_rope_swap_idx_inline955__ssa_v0_pview
      ;
      const int64_t v181 = 64;
      // pto: %q_rope_swap_idx_inline955__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 64> v182 = pto::Shape<1, 1, 1, 8, 64>();
      // pto: %q_rope_swap_idx_inline955__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 64, 1> v183 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %q_rope_swap_idx_inline955__ssa_v0_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v184 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v179 + (v180 + v162 * v181), v182, v183);
      TLOAD(v177, v184);
      // pto: %155
      ;
      int64_t v185 = v141 / v65;
      // pto: %156
      ;
      int64_t v186 = (int64_t) ((uint64_t) v185 * (uint64_t) v65);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      for (int64_t v187 = v58; v187 < v186; v187 += v65) {
        // pto: %157, %158
        ;
        int64_t v188 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v149 + (uint64_t) v187) * (uint64_t) v55);
        // pto: %160, %159, %161
        ;
        int64_t v189 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v149 + (uint64_t) ((int64_t) (uint64_t) v187 + (uint64_t) v54)) * (uint64_t) v55);
        // pto: %q_head_acc_inline8251__tile
        ;
        Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v190 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_acc_inline8251__tile
        ;
        uint64_t v191 = (uint64_t) v21;
        TASSIGN(v190, v191);
        // pto: %163
        ;
        int64_t v192 = v188 < v58 ? v58 : v188;
        // pto: %q_proj_i32_inline6_inline4554__ssa_v9_pview
        ;
        __gm__ int32_t* v193 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %q_proj_i32_inline6_inline4554__ssa_v9_pview
        ;
        const int64_t v194 = 0;
        // pto: %q_proj_i32_inline6_inline4554__ssa_v9_pview
        ;
        const int64_t v195 = 32768;
        // pto: %q_proj_i32_inline6_inline4554__ssa_v9_pview
        ;
        pto::Shape<1, 1, 1, 8, 512> v196 = pto::Shape<1, 1, 1, 8, 512>();
        // pto: %q_proj_i32_inline6_inline4554__ssa_v9_pview
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v197 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %q_proj_i32_inline6_inline4554__ssa_v9_pview
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v198 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v193 + (v194 + v154 * v195 + v192), v196, v197);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        TLOAD(v190, v198);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %t__tile
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v199 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %t__tile
        ;
        uint64_t v200 = (uint64_t) v22;
        TASSIGN(v199, v200);
        // pto: %wq_b_scale__ssa_v0_pview
        ;
        __gm__ float* v201 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %wq_b_scale__ssa_v0_pview
        ;
        const int64_t v202 = 0;
        // pto: %wq_b_scale__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 512> v203 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %wq_b_scale__ssa_v0_pview
        ;
        pto::Stride<512, 512, 512, 512, 1> v204 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %wq_b_scale__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v205 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v201 + (v202 + v192), v203, v204);
        TLOAD(v199, v205);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        // pto: %0
        ;
        Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v206 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %0
        ;
        uint64_t v207 = (uint64_t) v23;
        TASSIGN(v206, v207);
        // pto: %166
        ;
        int64_t v208 = v189 < v58 ? v58 : v189;
        // pto: %167
        ;
        __gm__ int32_t* v209 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %167
        ;
        const int64_t v210 = 0;
        // pto: %167
        ;
        const int64_t v211 = 32768;
        // pto: %167
        ;
        pto::Shape<1, 1, 1, 8, 512> v212 = pto::Shape<1, 1, 1, 8, 512>();
        // pto: %167
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v213 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %167
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v214 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v209 + (v210 + v154 * v211 + v208), v212, v213);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
        TLOAD(v206, v214);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        // pto: %1
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %1
        ;
        uint64_t v216 = (uint64_t) v24;
        TASSIGN(v215, v216);
        // pto: %169
        ;
        __gm__ float* v217 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %169
        ;
        const int64_t v218 = 0;
        // pto: %169
        ;
        pto::Shape<1, 1, 1, 1, 512> v219 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %169
        ;
        pto::Stride<512, 512, 512, 512, 1> v220 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %169
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v221 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v217 + (v218 + v208), v219, v220);
        TLOAD(v215, v221);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
        // pto: %q_head_scale_inline8244__tile
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v222 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %q_head_scale_inline8244__tile
        ;
        uint64_t v223 = (uint64_t) v22;
        TASSIGN(v222, v223);
        // pto: %q_head_acc_fp32_inline8252__tile
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v224 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_acc_fp32_inline8252__tile
        ;
        uint64_t v225 = (uint64_t) v21;
        TASSIGN(v224, v225);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v226 = RoundMode::CAST_NONE;
        SaturationMode v227 = SaturationMode::ON;
        TCVT(v224, v190, v226, v227);
        // pto: %2
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v228 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %2
        ;
        uint64_t v229 = (uint64_t) v25;
        TASSIGN(v228, v229);
        TEXPANDS(v228, v66);
        // pto: %3
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v230 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %3
        ;
        uint64_t v231 = (uint64_t) v25;
        TASSIGN(v230, v231);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v230, v228, v152);
        // pto: %q_head_scale_combined_inline8292__tile
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v232 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_scale_combined_inline8292__tile
        ;
        uint64_t v233 = (uint64_t) v25;
        TASSIGN(v232, v233);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        TCOLEXPANDMUL(v232, v230, v222);
        // pto: %q_head_dq_inline8267__tile
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v234 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_dq_inline8267__tile
        ;
        uint64_t v235 = (uint64_t) v21;
        TASSIGN(v234, v235);
        pipe_barrier(PIPE_V);
        TMUL(v234, v224, v232);
        // pto: %4
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v236 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %4
        ;
        uint64_t v237 = (uint64_t) v25;
        TASSIGN(v236, v237);
        pipe_barrier(PIPE_V);
        RoundMode v238 = RoundMode::CAST_RINT;
        SaturationMode v239 = SaturationMode::ON;
        TCVT(v236, v234, v238, v239);
        // pto: %q_head_dq_v1_inline8236__tile
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v240 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_dq_v1_inline8236__tile
        ;
        uint64_t v241 = (uint64_t) v21;
        TASSIGN(v240, v241);
        pipe_barrier(PIPE_V);
        RoundMode v242 = RoundMode::CAST_ROUND;
        SaturationMode v243 = SaturationMode::ON;
        TCVT(v240, v236, v242, v243);
        // pto: %q_head_sq_inline8232__tile
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v244 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_sq_inline8232__tile
        ;
        uint64_t v245 = (uint64_t) v25;
        TASSIGN(v244, v245);
        pipe_barrier(PIPE_V);
        TMUL(v244, v240, v240);
        // pto: %5
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v246 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %5
        ;
        uint64_t v247 = (uint64_t) v25;
        TASSIGN(v246, v247);
        // pto: %slice_view
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v248;
        // pto: %slice_view
        ;
        uint64_t v249 = (uint64_t) v25;
        TASSIGN(v248, v249);
        // pto: %6
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v250 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %6
        ;
        uint64_t v251 = (uint64_t) v26;
        TASSIGN(v250, v251);
        // pto: %170
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v252;
        // pto: %170
        ;
        uint64_t v253 = (uint64_t) v26;
        TASSIGN(v252, v253);
        // pto: %q_sq_04_inline8231__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v254 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_04_inline8231__tile
        ;
        uint64_t v255 = (uint64_t) v22;
        TASSIGN(v254, v255);
        pipe_barrier(PIPE_V);
        TADD(v254, v248, v252);
        // pto: %7
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v256 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %7
        ;
        uint64_t v257 = (uint64_t) v27;
        TASSIGN(v256, v257);
        // pto: %171
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v258;
        // pto: %171
        ;
        uint64_t v259 = (uint64_t) v27;
        TASSIGN(v258, v259);
        // pto: %8
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v260 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %8
        ;
        uint64_t v261 = (uint64_t) v28;
        TASSIGN(v260, v261);
        // pto: %172
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v262;
        // pto: %172
        ;
        uint64_t v263 = (uint64_t) v28;
        TASSIGN(v262, v263);
        // pto: %q_sq_15_inline8287__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v264 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_15_inline8287__tile
        ;
        uint64_t v265 = (uint64_t) v29;
        TASSIGN(v264, v265);
        TADD(v264, v258, v262);
        // pto: %9
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v266 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %9
        ;
        uint64_t v267 = (uint64_t) v30;
        TASSIGN(v266, v267);
        // pto: %173
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v268;
        // pto: %173
        ;
        uint64_t v269 = (uint64_t) v30;
        TASSIGN(v268, v269);
        // pto: %10
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v270 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %10
        ;
        uint64_t v271 = (uint64_t) v31;
        TASSIGN(v270, v271);
        // pto: %174
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v272;
        // pto: %174
        ;
        uint64_t v273 = (uint64_t) v31;
        TASSIGN(v272, v273);
        // pto: %q_sq_26_inline8228__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v274 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_26_inline8228__tile
        ;
        uint64_t v275 = (uint64_t) v32;
        TASSIGN(v274, v275);
        TADD(v274, v268, v272);
        // pto: %11
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v276 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %11
        ;
        uint64_t v277 = (uint64_t) v33;
        TASSIGN(v276, v277);
        // pto: %175
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v278;
        // pto: %175
        ;
        uint64_t v279 = (uint64_t) v33;
        TASSIGN(v278, v279);
        // pto: %12
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v280 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %12
        ;
        uint64_t v281 = (uint64_t) v34;
        TASSIGN(v280, v281);
        // pto: %176
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v282;
        // pto: %176
        ;
        uint64_t v283 = (uint64_t) v34;
        TASSIGN(v282, v283);
        // pto: %q_sq_37_inline8285__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v284 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_37_inline8285__tile
        ;
        uint64_t v285 = (uint64_t) v25;
        TASSIGN(v284, v285);
        pipe_barrier(PIPE_V);
        TADD(v284, v278, v282);
        // pto: %q_sq_0246_inline8266__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v286 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_0246_inline8266__tile
        ;
        uint64_t v287 = (uint64_t) v22;
        TASSIGN(v286, v287);
        TADD(v286, v254, v274);
        // pto: %q_sq_1357_inline8291__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v288 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_1357_inline8291__tile
        ;
        uint64_t v289 = (uint64_t) v25;
        TASSIGN(v288, v289);
        pipe_barrier(PIPE_V);
        TADD(v288, v264, v284);
        // pto: %q_sq_64_inline8240__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v290 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_64_inline8240__tile
        ;
        uint64_t v291 = (uint64_t) v22;
        TASSIGN(v290, v291);
        pipe_barrier(PIPE_V);
        TADD(v290, v286, v288);
        // pto: %tmp_tile
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v292 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v67);
        // pto: %tmp_tile
        ;
        uint64_t v293 = (uint64_t) v25;
        TASSIGN(v292, v293);
        // pto: %q_head_sq_row_inline8278__tile
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v294 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %q_head_sq_row_inline8278__tile
        ;
        uint64_t v295 = (uint64_t) v29;
        TASSIGN(v294, v295);
        pipe_barrier(PIPE_V);
        TROWSUM(v294, v290, v292);
        // pto: %q_head_sq_sum_inline8270__tile
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v296 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_sq_sum_inline8270__tile
        ;
        uint64_t v297 = (uint64_t) v29;
        TASSIGN(v296, v297);
        // pto: %q_head_sq_mean_inline8288__tile
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_sq_mean_inline8288__tile
        ;
        uint64_t v299 = (uint64_t) v25;
        TASSIGN(v298, v299);
        pipe_barrier(PIPE_V);
        TMULS(v298, v296, v70);
        // pto: %q_head_var_inline8260__tile
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v300 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_var_inline8260__tile
        ;
        uint64_t v301 = (uint64_t) v25;
        TASSIGN(v300, v301);
        pipe_barrier(PIPE_V);
        TADDS(v300, v298, v71);
        // pto: %rsqrt_tmp
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v302 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %rsqrt_tmp
        ;
        uint64_t v303 = (uint64_t) v22;
        TASSIGN(v302, v303);
        // pto: %q_head_inv_rms_inline8237__tile
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v304 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_inv_rms_inline8237__tile
        ;
        uint64_t v305 = (uint64_t) v29;
        TASSIGN(v304, v305);
        pipe_barrier(PIPE_V);
        TRSQRT(v304, v300, v302);
        // pto: %q_head_inv_rms_t_inline8230__tile
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v306 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %q_head_inv_rms_t_inline8230__tile
        ;
        uint64_t v307 = (uint64_t) v29;
        TASSIGN(v306, v307);
        // pto: %13
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v308 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %13
        ;
        uint64_t v309 = (uint64_t) v21;
        TASSIGN(v308, v309);
        // pto: %177
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 448, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v310;
        // pto: %177
        ;
        uint64_t v311 = (uint64_t) v21;
        TASSIGN(v310, v311);
        // pto: %q_nope_normed_inline8243__tile
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v312 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %q_nope_normed_inline8243__tile
        ;
        uint64_t v313 = (uint64_t) v25;
        TASSIGN(v312, v313);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v312, v310, v306);
        // pto: %q_nope_bf16_inline8249__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v314 = Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %q_nope_bf16_inline8249__tile
        ;
        uint64_t v315 = (uint64_t) v25;
        TASSIGN(v314, v315);
        pipe_barrier(PIPE_V);
        RoundMode v316 = RoundMode::CAST_RINT;
        SaturationMode v317 = SaturationMode::ON;
        TCVT(v314, v312, v316, v317);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %q_rope_chunk_raw_inline8282__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v318 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_chunk_raw_inline8282__tile
        ;
        uint64_t v319 = (uint64_t) v35;
        TASSIGN(v318, v319);
        // pto: %178
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v320;
        // pto: %178
        ;
        uint64_t v321 = (uint64_t) v35;
        TASSIGN(v320, v321);
        // pto: %q_rope_chunk_inline8283__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v322 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_chunk_inline8283__tile
        ;
        uint64_t v323 = (uint64_t) v21;
        TASSIGN(v322, v323);
        TROWEXPANDMUL(v322, v320, v306);
        // pto: %14
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v324 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %14
        ;
        uint64_t v325 = (uint64_t) v22;
        TASSIGN(v324, v325);
        pipe_barrier(PIPE_V);
        RoundMode v326 = RoundMode::CAST_RINT;
        SaturationMode v327 = SaturationMode::ON;
        TCVT(v324, v322, v326, v327);
        // pto: %q_rope_chunk_v1_inline8233__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v328 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_chunk_v1_inline8233__tile
        ;
        uint64_t v329 = (uint64_t) v21;
        TASSIGN(v328, v329);
        pipe_barrier(PIPE_V);
        RoundMode v330 = RoundMode::CAST_ROUND;
        SaturationMode v331 = SaturationMode::ON;
        TCVT(v328, v324, v330, v331);
        // pto: %gather_acc_init
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v332 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %gather_acc_init
        ;
        uint64_t v333 = (uint64_t) v22;
        TASSIGN(v332, v333);
        for (int64_t v334 = v58; v334 < v63; v334 += v54) {
          // pto: %gather_inp_row
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v335 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %gather_inp_row
          ;
          uint64_t v336 = (uint64_t) v21;
          TASSIGN(v335, v336);
          // pto: %179
          ;
          int64_t v337 = (int64_t) ((uint64_t) v334 * (uint64_t) v16);
          // pto: %179
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v338;
          // pto: %179
          ;
          uint64_t v339 = (uint64_t) ((int64_t) (uint64_t) v337 + (uint64_t) v21);
          TASSIGN(v338, v339);
          // pto: %gather_idx_row
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v340 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %gather_idx_row
          ;
          uint64_t v341 = (uint64_t) v20;
          TASSIGN(v340, v341);
          // pto: %180
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v342;
          // pto: %180
          ;
          uint64_t v343 = (uint64_t) v337;
          TASSIGN(v342, v343);
          // pto: %gather_row_tmp
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v344 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %gather_row_tmp
          ;
          uint64_t v345 = (uint64_t) v29;
          TASSIGN(v344, v345);
          // pto: %gather_row
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v346 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %gather_row
          ;
          uint64_t v347 = (uint64_t) v32;
          TASSIGN(v346, v347);
          pipe_barrier(PIPE_V);
          TGATHER(v346, v338, v342, v344);
          // pto: %assemble_view
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v348;
          // pto: %assemble_view
          ;
          uint64_t v349 = (uint64_t) ((int64_t) (uint64_t) v337 + (uint64_t) v22);
          TASSIGN(v348, v349);
          pipe_barrier(PIPE_V);
          TMOV(v348, v346);
        };
        // pto: %q_rope_swapped_inline8234__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v350 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_swapped_inline8234__tile
        ;
        uint64_t v351 = (uint64_t) v22;
        TASSIGN(v350, v351);
        // pto: %q_rope_base_inline8262__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v352 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_base_inline8262__tile
        ;
        uint64_t v353 = (uint64_t) v21;
        TASSIGN(v352, v353);
        pipe_barrier(PIPE_V);
        TMUL(v352, v328, v160);
        // pto: %q_rope_delta_inline8274__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v354 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_delta_inline8274__tile
        ;
        uint64_t v355 = (uint64_t) v22;
        TASSIGN(v354, v355);
        TMUL(v354, v350, v169);
        // pto: %q_rope_rot_inline8248__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v356 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_rot_inline8248__tile
        ;
        uint64_t v357 = (uint64_t) v21;
        TASSIGN(v356, v357);
        pipe_barrier(PIPE_V);
        TADD(v356, v352, v354);
        // pto: %q_rope_bf16_inline8280__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v358 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_bf16_inline8280__tile
        ;
        uint64_t v359 = (uint64_t) v21;
        TASSIGN(v358, v359);
        pipe_barrier(PIPE_V);
        RoundMode v360 = RoundMode::CAST_RINT;
        SaturationMode v361 = SaturationMode::ON;
        TCVT(v358, v356, v360, v361);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        // pto: %q_flat_inline8276__iter_v3_pview
        ;
        __gm__ bfloat16_t* v362 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %q_flat_inline8276__iter_v3_pview
        ;
        const int64_t v363 = 0;
        // pto: %q_flat_inline8276__iter_v3_pview
        ;
        const int64_t v364 = 32768;
        // pto: %q_flat_inline8276__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, 8, 448> v365 = pto::Shape<1, 1, 1, 8, 448>();
        // pto: %q_flat_inline8276__iter_v3_pview
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v366 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %q_flat_inline8276__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v367 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v362 + (v363 + v162 * v364 + v192), v365, v366);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v367, v314);
        // pto: %185
        ;
        int64_t v368 = (int64_t) ((uint64_t) v188 + (uint64_t) v69);
        // pto: %186
        ;
        int64_t v369 = v368 < v58 ? v58 : v368;
        // pto: %q_flat_inline8276__tile_pview
        ;
        __gm__ bfloat16_t* v370 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %q_flat_inline8276__tile_pview
        ;
        const int64_t v371 = 0;
        // pto: %q_flat_inline8276__tile_pview
        ;
        const int64_t v372 = 32768;
        // pto: %q_flat_inline8276__tile_pview
        ;
        pto::Shape<1, 1, 1, 8, 64> v373 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %q_flat_inline8276__tile_pview
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v374 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %q_flat_inline8276__tile_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v375 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v370 + (v371 + v162 * v372 + v369), v373, v374);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v375, v358);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        // pto: %15
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v376 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %15
        ;
        uint64_t v377 = (uint64_t) v24;
        TASSIGN(v376, v377);
        // pto: %16
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v378 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %16
        ;
        uint64_t v379 = (uint64_t) v23;
        TASSIGN(v378, v379);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        RoundMode v380 = RoundMode::CAST_NONE;
        SaturationMode v381 = SaturationMode::ON;
        TCVT(v378, v206, v380, v381);
        // pto: %17
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v382 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %17
        ;
        uint64_t v383 = (uint64_t) v36;
        TASSIGN(v382, v383);
        TEXPANDS(v382, v66);
        // pto: %18
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v384 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %18
        ;
        uint64_t v385 = (uint64_t) v36;
        TASSIGN(v384, v385);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v384, v382, v152);
        // pto: %19
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v386 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %19
        ;
        uint64_t v387 = (uint64_t) v36;
        TASSIGN(v386, v387);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
        TCOLEXPANDMUL(v386, v384, v376);
        // pto: %20
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v388 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %20
        ;
        uint64_t v389 = (uint64_t) v23;
        TASSIGN(v388, v389);
        pipe_barrier(PIPE_V);
        TMUL(v388, v378, v386);
        // pto: %21
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v390 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %21
        ;
        uint64_t v391 = (uint64_t) v36;
        TASSIGN(v390, v391);
        pipe_barrier(PIPE_V);
        RoundMode v392 = RoundMode::CAST_RINT;
        SaturationMode v393 = SaturationMode::ON;
        TCVT(v390, v388, v392, v393);
        // pto: %22
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v394 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %22
        ;
        uint64_t v395 = (uint64_t) v23;
        TASSIGN(v394, v395);
        pipe_barrier(PIPE_V);
        RoundMode v396 = RoundMode::CAST_ROUND;
        SaturationMode v397 = SaturationMode::ON;
        TCVT(v394, v390, v396, v397);
        // pto: %23
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v398 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %23
        ;
        uint64_t v399 = (uint64_t) v36;
        TASSIGN(v398, v399);
        pipe_barrier(PIPE_V);
        TMUL(v398, v394, v394);
        // pto: %24
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v400 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %24
        ;
        uint64_t v401 = (uint64_t) v36;
        TASSIGN(v400, v401);
        // pto: %187
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v402;
        // pto: %187
        ;
        uint64_t v403 = (uint64_t) v36;
        TASSIGN(v402, v403);
        // pto: %25
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v404 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %25
        ;
        uint64_t v405 = (uint64_t) v37;
        TASSIGN(v404, v405);
        // pto: %188
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v406;
        // pto: %188
        ;
        uint64_t v407 = (uint64_t) v37;
        TASSIGN(v406, v407);
        // pto: %26
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v408 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %26
        ;
        uint64_t v409 = (uint64_t) v24;
        TASSIGN(v408, v409);
        pipe_barrier(PIPE_V);
        TADD(v408, v402, v406);
        // pto: %27
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v410 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %27
        ;
        uint64_t v411 = (uint64_t) v38;
        TASSIGN(v410, v411);
        // pto: %189
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v412;
        // pto: %189
        ;
        uint64_t v413 = (uint64_t) v38;
        TASSIGN(v412, v413);
        // pto: %28
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v414 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %28
        ;
        uint64_t v415 = (uint64_t) v39;
        TASSIGN(v414, v415);
        // pto: %190
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v416;
        // pto: %190
        ;
        uint64_t v417 = (uint64_t) v39;
        TASSIGN(v416, v417);
        // pto: %29
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v418 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %29
        ;
        uint64_t v419 = (uint64_t) v40;
        TASSIGN(v418, v419);
        TADD(v418, v412, v416);
        // pto: %30
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v420 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %30
        ;
        uint64_t v421 = (uint64_t) v41;
        TASSIGN(v420, v421);
        // pto: %191
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v422;
        // pto: %191
        ;
        uint64_t v423 = (uint64_t) v41;
        TASSIGN(v422, v423);
        // pto: %31
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v424 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %31
        ;
        uint64_t v425 = (uint64_t) v42;
        TASSIGN(v424, v425);
        // pto: %192
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v426;
        // pto: %192
        ;
        uint64_t v427 = (uint64_t) v42;
        TASSIGN(v426, v427);
        // pto: %32
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v428 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %32
        ;
        uint64_t v429 = (uint64_t) v43;
        TASSIGN(v428, v429);
        TADD(v428, v422, v426);
        // pto: %33
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v430 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %33
        ;
        uint64_t v431 = (uint64_t) v44;
        TASSIGN(v430, v431);
        // pto: %193
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v432;
        // pto: %193
        ;
        uint64_t v433 = (uint64_t) v44;
        TASSIGN(v432, v433);
        // pto: %34
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v434 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %34
        ;
        uint64_t v435 = (uint64_t) v45;
        TASSIGN(v434, v435);
        // pto: %194
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v436;
        // pto: %194
        ;
        uint64_t v437 = (uint64_t) v45;
        TASSIGN(v436, v437);
        // pto: %35
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v438 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %35
        ;
        uint64_t v439 = (uint64_t) v36;
        TASSIGN(v438, v439);
        pipe_barrier(PIPE_V);
        TADD(v438, v432, v436);
        // pto: %36
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v440 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %36
        ;
        uint64_t v441 = (uint64_t) v24;
        TASSIGN(v440, v441);
        TADD(v440, v408, v428);
        // pto: %37
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v442 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %37
        ;
        uint64_t v443 = (uint64_t) v36;
        TASSIGN(v442, v443);
        pipe_barrier(PIPE_V);
        TADD(v442, v418, v438);
        // pto: %38
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v444 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %38
        ;
        uint64_t v445 = (uint64_t) v24;
        TASSIGN(v444, v445);
        pipe_barrier(PIPE_V);
        TADD(v444, v440, v442);
        // pto: %39
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v446 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v67);
        // pto: %39
        ;
        uint64_t v447 = (uint64_t) v36;
        TASSIGN(v446, v447);
        // pto: %40
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v448 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %40
        ;
        uint64_t v449 = (uint64_t) v40;
        TASSIGN(v448, v449);
        pipe_barrier(PIPE_V);
        TROWSUM(v448, v444, v446);
        // pto: %41
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v450 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %41
        ;
        uint64_t v451 = (uint64_t) v40;
        TASSIGN(v450, v451);
        // pto: %42
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v452 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %42
        ;
        uint64_t v453 = (uint64_t) v36;
        TASSIGN(v452, v453);
        pipe_barrier(PIPE_V);
        TMULS(v452, v450, v70);
        // pto: %43
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v454 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %43
        ;
        uint64_t v455 = (uint64_t) v36;
        TASSIGN(v454, v455);
        pipe_barrier(PIPE_V);
        TADDS(v454, v452, v71);
        // pto: %44
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v456 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %44
        ;
        uint64_t v457 = (uint64_t) v24;
        TASSIGN(v456, v457);
        // pto: %45
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v458 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %45
        ;
        uint64_t v459 = (uint64_t) v40;
        TASSIGN(v458, v459);
        pipe_barrier(PIPE_V);
        TRSQRT(v458, v454, v456);
        // pto: %46
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v460 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %46
        ;
        uint64_t v461 = (uint64_t) v40;
        TASSIGN(v460, v461);
        // pto: %47
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v462 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %47
        ;
        uint64_t v463 = (uint64_t) v23;
        TASSIGN(v462, v463);
        // pto: %195
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 448, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v464;
        // pto: %195
        ;
        uint64_t v465 = (uint64_t) v23;
        TASSIGN(v464, v465);
        // pto: %48
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v466 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %48
        ;
        uint64_t v467 = (uint64_t) v36;
        TASSIGN(v466, v467);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v466, v464, v460);
        // pto: %49
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v468 = Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %49
        ;
        uint64_t v469 = (uint64_t) v36;
        TASSIGN(v468, v469);
        pipe_barrier(PIPE_V);
        RoundMode v470 = RoundMode::CAST_RINT;
        SaturationMode v471 = SaturationMode::ON;
        TCVT(v468, v466, v470, v471);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        // pto: %50
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v472 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %50
        ;
        uint64_t v473 = (uint64_t) v46;
        TASSIGN(v472, v473);
        // pto: %196
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v474;
        // pto: %196
        ;
        uint64_t v475 = (uint64_t) v46;
        TASSIGN(v474, v475);
        // pto: %51
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v476 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %51
        ;
        uint64_t v477 = (uint64_t) v23;
        TASSIGN(v476, v477);
        TROWEXPANDMUL(v476, v474, v460);
        // pto: %52
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v478 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %52
        ;
        uint64_t v479 = (uint64_t) v24;
        TASSIGN(v478, v479);
        pipe_barrier(PIPE_V);
        RoundMode v480 = RoundMode::CAST_RINT;
        SaturationMode v481 = SaturationMode::ON;
        TCVT(v478, v476, v480, v481);
        // pto: %53
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v482 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %53
        ;
        uint64_t v483 = (uint64_t) v23;
        TASSIGN(v482, v483);
        pipe_barrier(PIPE_V);
        RoundMode v484 = RoundMode::CAST_ROUND;
        SaturationMode v485 = SaturationMode::ON;
        TCVT(v482, v478, v484, v485);
        // pto: %54
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v486 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %54
        ;
        uint64_t v487 = (uint64_t) v24;
        TASSIGN(v486, v487);
        for (int64_t v488 = v58; v488 < v63; v488 += v54) {
          // pto: %55
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v489 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %55
          ;
          uint64_t v490 = (uint64_t) v23;
          TASSIGN(v489, v490);
          // pto: %198
          ;
          int64_t v491 = (int64_t) ((uint64_t) v488 * (uint64_t) v16);
          // pto: %198
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v492;
          // pto: %198
          ;
          uint64_t v493 = (uint64_t) ((int64_t) (uint64_t) v491 + (uint64_t) v23);
          TASSIGN(v492, v493);
          // pto: %56
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v494 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %56
          ;
          uint64_t v495 = (uint64_t) v20;
          TASSIGN(v494, v495);
          // pto: %199
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v496;
          // pto: %199
          ;
          uint64_t v497 = (uint64_t) v491;
          TASSIGN(v496, v497);
          // pto: %57
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v498 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %57
          ;
          uint64_t v499 = (uint64_t) v40;
          TASSIGN(v498, v499);
          // pto: %58
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v500 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %58
          ;
          uint64_t v501 = (uint64_t) v43;
          TASSIGN(v500, v501);
          pipe_barrier(PIPE_V);
          TGATHER(v500, v492, v496, v498);
          // pto: %200
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v502;
          // pto: %200
          ;
          uint64_t v503 = (uint64_t) ((int64_t) (uint64_t) v491 + (uint64_t) v24);
          TASSIGN(v502, v503);
          pipe_barrier(PIPE_V);
          TMOV(v502, v500);
        };
        // pto: %60
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v504 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %60
        ;
        uint64_t v505 = (uint64_t) v24;
        TASSIGN(v504, v505);
        // pto: %61
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v506 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %61
        ;
        uint64_t v507 = (uint64_t) v23;
        TASSIGN(v506, v507);
        pipe_barrier(PIPE_V);
        TMUL(v506, v482, v160);
        // pto: %62
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v508 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %62
        ;
        uint64_t v509 = (uint64_t) v24;
        TASSIGN(v508, v509);
        TMUL(v508, v504, v169);
        // pto: %63
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v510 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %63
        ;
        uint64_t v511 = (uint64_t) v23;
        TASSIGN(v510, v511);
        pipe_barrier(PIPE_V);
        TADD(v510, v506, v508);
        // pto: %64
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v512 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %64
        ;
        uint64_t v513 = (uint64_t) v23;
        TASSIGN(v512, v513);
        pipe_barrier(PIPE_V);
        RoundMode v514 = RoundMode::CAST_RINT;
        SaturationMode v515 = SaturationMode::ON;
        TCVT(v512, v510, v514, v515);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        // pto: %204
        ;
        __gm__ bfloat16_t* v516 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %204
        ;
        const int64_t v517 = 0;
        // pto: %204
        ;
        const int64_t v518 = 32768;
        // pto: %204
        ;
        pto::Shape<1, 1, 1, 8, 448> v519 = pto::Shape<1, 1, 1, 8, 448>();
        // pto: %204
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v520 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %204
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v521 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v516 + (v517 + v162 * v518 + v208), v519, v520);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v521, v468);
        // pto: %207
        ;
        int64_t v522 = (int64_t) ((uint64_t) v189 + (uint64_t) v69);
        // pto: %208
        ;
        int64_t v523 = v522 < v58 ? v58 : v522;
        // pto: %209
        ;
        __gm__ bfloat16_t* v524 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %209
        ;
        const int64_t v525 = 0;
        // pto: %209
        ;
        const int64_t v526 = 32768;
        // pto: %209
        ;
        pto::Shape<1, 1, 1, 8, 64> v527 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %209
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v528 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %209
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v529 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v524 + (v525 + v162 * v526 + v523), v527, v528);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        TSTORE(v529, v512);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
      // pto: %210
      ;
      uint64_t v530 = (uint64_t) v141;
      // pto: %210, %211
      ;
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
      if ((int64_t) (v530 - (uint64_t) v186) == v54) {
        // pto: %212, %213
        ;
        int64_t v531 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v149 + (uint64_t) v186) * (uint64_t) v55);
        // pto: %65
        ;
        Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v532 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %65
        ;
        uint64_t v533 = (uint64_t) v21;
        TASSIGN(v532, v533);
        // pto: %215
        ;
        int64_t v534 = v531 < v58 ? v58 : v531;
        // pto: %216
        ;
        __gm__ int32_t* v535 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %216
        ;
        const int64_t v536 = 0;
        // pto: %216
        ;
        const int64_t v537 = 32768;
        // pto: %216
        ;
        pto::Shape<1, 1, 1, 8, 512> v538 = pto::Shape<1, 1, 1, 8, 512>();
        // pto: %216
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v539 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %216
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v540 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v535 + (v536 + v154 * v537 + v534), v538, v539);
        TLOAD(v532, v540);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        // pto: %66
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v541 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %66
        ;
        uint64_t v542 = (uint64_t) v25;
        TASSIGN(v541, v542);
        // pto: %218
        ;
        __gm__ float* v543 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %218
        ;
        const int64_t v544 = 0;
        // pto: %218
        ;
        pto::Shape<1, 1, 1, 1, 512> v545 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %218
        ;
        pto::Stride<512, 512, 512, 512, 1> v546 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %218
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v547 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v543 + (v544 + v534), v545, v546);
        TLOAD(v541, v547);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        // pto: %67
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v548 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %67
        ;
        uint64_t v549 = (uint64_t) v25;
        TASSIGN(v548, v549);
        // pto: %68
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v550 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %68
        ;
        uint64_t v551 = (uint64_t) v21;
        TASSIGN(v550, v551);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        RoundMode v552 = RoundMode::CAST_NONE;
        SaturationMode v553 = SaturationMode::ON;
        TCVT(v550, v532, v552, v553);
        // pto: %69
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v554 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %69
        ;
        uint64_t v555 = (uint64_t) v23;
        TASSIGN(v554, v555);
        TEXPANDS(v554, v66);
        // pto: %70
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v556 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %70
        ;
        uint64_t v557 = (uint64_t) v23;
        TASSIGN(v556, v557);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v556, v554, v152);
        // pto: %71
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v558 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %71
        ;
        uint64_t v559 = (uint64_t) v23;
        TASSIGN(v558, v559);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        TCOLEXPANDMUL(v558, v556, v548);
        // pto: %72
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v560 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %72
        ;
        uint64_t v561 = (uint64_t) v21;
        TASSIGN(v560, v561);
        pipe_barrier(PIPE_V);
        TMUL(v560, v550, v558);
        // pto: %73
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v562 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %73
        ;
        uint64_t v563 = (uint64_t) v23;
        TASSIGN(v562, v563);
        pipe_barrier(PIPE_V);
        RoundMode v564 = RoundMode::CAST_RINT;
        SaturationMode v565 = SaturationMode::ON;
        TCVT(v562, v560, v564, v565);
        // pto: %74
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v566 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %74
        ;
        uint64_t v567 = (uint64_t) v21;
        TASSIGN(v566, v567);
        pipe_barrier(PIPE_V);
        RoundMode v568 = RoundMode::CAST_ROUND;
        SaturationMode v569 = SaturationMode::ON;
        TCVT(v566, v562, v568, v569);
        // pto: %75
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v570 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %75
        ;
        uint64_t v571 = (uint64_t) v23;
        TASSIGN(v570, v571);
        pipe_barrier(PIPE_V);
        TMUL(v570, v566, v566);
        // pto: %76
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v572 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %76
        ;
        uint64_t v573 = (uint64_t) v23;
        TASSIGN(v572, v573);
        // pto: %219
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v574;
        // pto: %219
        ;
        uint64_t v575 = (uint64_t) v23;
        TASSIGN(v574, v575);
        // pto: %77
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v576 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %77
        ;
        uint64_t v577 = (uint64_t) v47;
        TASSIGN(v576, v577);
        // pto: %220
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v578;
        // pto: %220
        ;
        uint64_t v579 = (uint64_t) v47;
        TASSIGN(v578, v579);
        // pto: %78
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v580 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %78
        ;
        uint64_t v581 = (uint64_t) v25;
        TASSIGN(v580, v581);
        pipe_barrier(PIPE_V);
        TADD(v580, v574, v578);
        // pto: %79
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v582 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %79
        ;
        uint64_t v583 = (uint64_t) v48;
        TASSIGN(v582, v583);
        // pto: %221
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v584;
        // pto: %221
        ;
        uint64_t v585 = (uint64_t) v48;
        TASSIGN(v584, v585);
        // pto: %80
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v586 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %80
        ;
        uint64_t v587 = (uint64_t) v49;
        TASSIGN(v586, v587);
        // pto: %222
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v588;
        // pto: %222
        ;
        uint64_t v589 = (uint64_t) v49;
        TASSIGN(v588, v589);
        // pto: %81
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v590 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %81
        ;
        uint64_t v591 = (uint64_t) v36;
        TASSIGN(v590, v591);
        TADD(v590, v584, v588);
        // pto: %82
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v592 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %82
        ;
        uint64_t v593 = (uint64_t) v50;
        TASSIGN(v592, v593);
        // pto: %223
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v594;
        // pto: %223
        ;
        uint64_t v595 = (uint64_t) v50;
        TASSIGN(v594, v595);
        // pto: %83
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v596 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %83
        ;
        uint64_t v597 = (uint64_t) v51;
        TASSIGN(v596, v597);
        // pto: %224
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v598;
        // pto: %224
        ;
        uint64_t v599 = (uint64_t) v51;
        TASSIGN(v598, v599);
        // pto: %84
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v600 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %84
        ;
        uint64_t v601 = (uint64_t) v22;
        TASSIGN(v600, v601);
        TADD(v600, v594, v598);
        // pto: %85
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v602 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %85
        ;
        uint64_t v603 = (uint64_t) v52;
        TASSIGN(v602, v603);
        // pto: %225
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v604;
        // pto: %225
        ;
        uint64_t v605 = (uint64_t) v52;
        TASSIGN(v604, v605);
        // pto: %86
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v606 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %86
        ;
        uint64_t v607 = (uint64_t) v46;
        TASSIGN(v606, v607);
        // pto: %226
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v608;
        // pto: %226
        ;
        uint64_t v609 = (uint64_t) v46;
        TASSIGN(v608, v609);
        // pto: %87
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v610 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %87
        ;
        uint64_t v611 = (uint64_t) v23;
        TASSIGN(v610, v611);
        pipe_barrier(PIPE_V);
        TADD(v610, v604, v608);
        // pto: %88
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v612 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %88
        ;
        uint64_t v613 = (uint64_t) v25;
        TASSIGN(v612, v613);
        TADD(v612, v580, v600);
        // pto: %89
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v614 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %89
        ;
        uint64_t v615 = (uint64_t) v23;
        TASSIGN(v614, v615);
        pipe_barrier(PIPE_V);
        TADD(v614, v590, v610);
        // pto: %90
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v616 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %90
        ;
        uint64_t v617 = (uint64_t) v25;
        TASSIGN(v616, v617);
        pipe_barrier(PIPE_V);
        TADD(v616, v612, v614);
        // pto: %91
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v618 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v67);
        // pto: %91
        ;
        uint64_t v619 = (uint64_t) v23;
        TASSIGN(v618, v619);
        // pto: %92
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v620 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %92
        ;
        uint64_t v621 = (uint64_t) v36;
        TASSIGN(v620, v621);
        pipe_barrier(PIPE_V);
        TROWSUM(v620, v616, v618);
        // pto: %93
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v622 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %93
        ;
        uint64_t v623 = (uint64_t) v36;
        TASSIGN(v622, v623);
        // pto: %94
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v624 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %94
        ;
        uint64_t v625 = (uint64_t) v23;
        TASSIGN(v624, v625);
        pipe_barrier(PIPE_V);
        TMULS(v624, v622, v70);
        // pto: %95
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v626 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %95
        ;
        uint64_t v627 = (uint64_t) v23;
        TASSIGN(v626, v627);
        pipe_barrier(PIPE_V);
        TADDS(v626, v624, v71);
        // pto: %96
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v628 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %96
        ;
        uint64_t v629 = (uint64_t) v25;
        TASSIGN(v628, v629);
        // pto: %97
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v630 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %97
        ;
        uint64_t v631 = (uint64_t) v36;
        TASSIGN(v630, v631);
        pipe_barrier(PIPE_V);
        TRSQRT(v630, v626, v628);
        // pto: %98
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v632 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %98
        ;
        uint64_t v633 = (uint64_t) v36;
        TASSIGN(v632, v633);
        // pto: %99
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v634 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %99
        ;
        uint64_t v635 = (uint64_t) v21;
        TASSIGN(v634, v635);
        // pto: %227
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 448, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v636;
        // pto: %227
        ;
        uint64_t v637 = (uint64_t) v21;
        TASSIGN(v636, v637);
        // pto: %100
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v638 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %100
        ;
        uint64_t v639 = (uint64_t) v23;
        TASSIGN(v638, v639);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v638, v636, v632);
        // pto: %101
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v640 = Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %101
        ;
        uint64_t v641 = (uint64_t) v23;
        TASSIGN(v640, v641);
        pipe_barrier(PIPE_V);
        RoundMode v642 = RoundMode::CAST_RINT;
        SaturationMode v643 = SaturationMode::ON;
        TCVT(v640, v638, v642, v643);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        // pto: %q_flat_inline8276__rv_v4_main_pview
        ;
        __gm__ bfloat16_t* v644 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %q_flat_inline8276__rv_v4_main_pview
        ;
        const int64_t v645 = 0;
        // pto: %q_flat_inline8276__rv_v4_main_pview
        ;
        const int64_t v646 = 32768;
        // pto: %q_flat_inline8276__rv_v4_main_pview
        ;
        pto::Shape<1, 1, 1, 8, 448> v647 = pto::Shape<1, 1, 1, 8, 448>();
        // pto: %q_flat_inline8276__rv_v4_main_pview
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v648 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %q_flat_inline8276__rv_v4_main_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v649 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v644 + (v645 + v162 * v646 + v534), v647, v648);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        TSTORE(v649, v640);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
        // pto: %102
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v650 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %102
        ;
        uint64_t v651 = (uint64_t) v35;
        TASSIGN(v650, v651);
        // pto: %231
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v652;
        // pto: %231
        ;
        uint64_t v653 = (uint64_t) v35;
        TASSIGN(v652, v653);
        // pto: %103
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v654 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %103
        ;
        uint64_t v655 = (uint64_t) v21;
        TASSIGN(v654, v655);
        TROWEXPANDMUL(v654, v652, v632);
        // pto: %104
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v656 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %104
        ;
        uint64_t v657 = (uint64_t) v23;
        TASSIGN(v656, v657);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
        RoundMode v658 = RoundMode::CAST_RINT;
        SaturationMode v659 = SaturationMode::ON;
        TCVT(v656, v654, v658, v659);
        // pto: %105
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v660 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %105
        ;
        uint64_t v661 = (uint64_t) v21;
        TASSIGN(v660, v661);
        pipe_barrier(PIPE_V);
        RoundMode v662 = RoundMode::CAST_ROUND;
        SaturationMode v663 = SaturationMode::ON;
        TCVT(v660, v656, v662, v663);
        // pto: %106
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v664 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %106
        ;
        uint64_t v665 = (uint64_t) v23;
        TASSIGN(v664, v665);
        for (int64_t v666 = v58; v666 < v63; v666 += v54) {
          // pto: %107
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v667 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %107
          ;
          uint64_t v668 = (uint64_t) v21;
          TASSIGN(v667, v668);
          // pto: %233
          ;
          int64_t v669 = (int64_t) ((uint64_t) v666 * (uint64_t) v16);
          // pto: %233
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v670;
          // pto: %233
          ;
          uint64_t v671 = (uint64_t) ((int64_t) (uint64_t) v669 + (uint64_t) v21);
          TASSIGN(v670, v671);
          // pto: %108
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v672 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %108
          ;
          uint64_t v673 = (uint64_t) v20;
          TASSIGN(v672, v673);
          // pto: %234
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v674;
          // pto: %234
          ;
          uint64_t v675 = (uint64_t) v669;
          TASSIGN(v674, v675);
          // pto: %109
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v676 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %109
          ;
          uint64_t v677 = (uint64_t) v25;
          TASSIGN(v676, v677);
          // pto: %110
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v678 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %110
          ;
          uint64_t v679 = (uint64_t) v36;
          TASSIGN(v678, v679);
          pipe_barrier(PIPE_V);
          TGATHER(v678, v670, v674, v676);
          // pto: %235
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v680;
          // pto: %235
          ;
          uint64_t v681 = (uint64_t) ((int64_t) (uint64_t) v669 + (uint64_t) v23);
          TASSIGN(v680, v681);
          pipe_barrier(PIPE_V);
          TMOV(v680, v678);
        };
        // pto: %112
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v682 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %112
        ;
        uint64_t v683 = (uint64_t) v23;
        TASSIGN(v682, v683);
        // pto: %113
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v684 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %113
        ;
        uint64_t v685 = (uint64_t) v21;
        TASSIGN(v684, v685);
        pipe_barrier(PIPE_V);
        TMUL(v684, v660, v160);
        // pto: %114
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v686 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %114
        ;
        uint64_t v687 = (uint64_t) v23;
        TASSIGN(v686, v687);
        TMUL(v686, v682, v169);
        // pto: %115
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v688 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %115
        ;
        uint64_t v689 = (uint64_t) v21;
        TASSIGN(v688, v689);
        pipe_barrier(PIPE_V);
        TADD(v688, v684, v686);
        // pto: %116
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v690 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %116
        ;
        uint64_t v691 = (uint64_t) v21;
        TASSIGN(v690, v691);
        pipe_barrier(PIPE_V);
        RoundMode v692 = RoundMode::CAST_RINT;
        SaturationMode v693 = SaturationMode::ON;
        TCVT(v690, v688, v692, v693);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        // pto: %238
        ;
        int64_t v694 = (int64_t) ((uint64_t) v531 + (uint64_t) v69);
        // pto: %239
        ;
        int64_t v695 = v694 < v58 ? v58 : v694;
        // pto: %240
        ;
        __gm__ bfloat16_t* v696 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %240
        ;
        const int64_t v697 = 0;
        // pto: %240
        ;
        const int64_t v698 = 32768;
        // pto: %240
        ;
        pto::Shape<1, 1, 1, 8, 64> v699 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %240
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v700 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %240
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v701 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v696 + (v697 + v162 * v698 + v695), v699, v700);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        TSTORE(v701, v690);
      };
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    } else {
      // pto: %241
      ;
      int64_t v702 = (int64_t) ((uint64_t) v8 - (uint64_t) v150);
      // pto: %qr_scale_dq_tail_inline8254__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v703 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
      // pto: %qr_scale_dq_tail_inline8254__ssa_v0
      ;
      uint64_t v704 = (uint64_t) v32;
      TASSIGN(v703, v704);
      // pto: %242
      ;
      int64_t v705 = v150 < v58 ? v58 : v150;
      // pto: %243
      ;
      __gm__ float* v706 = PTOAS__GLOBAL_TENSOR_DATA(v92);
      // pto: %243
      ;
      const int64_t v707 = 0;
      // pto: %243
      ;
      pto::Shape<1, 1, 1, 8, 1> v708 = pto::Shape<1, 1, 1, 8, 1>();
      // pto: %243
      ;
      pto::Stride<8, 8, 8, 1, 512> v709 = pto::Stride<8, 8, 8, 1, 512>();
      // pto: %243
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 512>, pto::Layout::DN> v710 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 512>, pto::Layout::DN>(v706 + (v707 + v705), v708, v709);
      pipe_barrier(PIPE_ALL);
      TLOAD(v703, v710);
      // pto: %q_cos_il_tail_inline8277__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v711 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v702, v56);
      // pto: %q_cos_il_tail_inline8277__ssa_v0
      ;
      uint64_t v712 = (uint64_t) v25;
      TASSIGN(v711, v712);
      // pto: %244
      ;
      int64_t v713 = v151 < v58 ? v58 : v151;
      // pto: %245
      ;
      const int64_t v714 = 0;
      // pto: %245
      ;
      __gm__ float* v715 = PTOAS__GLOBAL_TENSOR_DATA(v101);
      // pto: %245
      ;
      const int64_t v716 = 1;
      // pto: %245
      ;
      const int64_t v717 = 1;
      // pto: %245
      ;
      const int64_t v718 = 1;
      // pto: %245
      ;
      int64_t v719 = v702 * v56;
      // pto: %245
      ;
      int64_t v720 = v718 * v719;
      // pto: %245
      ;
      pto::Shape<1, 1, 1, -1, 64> v721 = pto::Shape<1, 1, 1, -1, 64>(v716, v717, v718, v702, v56);
      // pto: %245
      ;
      pto::Stride<-1, -1, -1, -1, -1> v722 = pto::Stride<-1, -1, -1, -1, -1>(v717 * v720, v720, v719, v56, v54);
      // pto: %245
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v723 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v715 + (v714 + v713 * v56 + v58 * v54), v721, v722);
      pipe_barrier(PIPE_ALL);
      TLOAD(v711, v723);
      // pto: %q_sin_signed_tail_inline8256__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v724 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v702, v56);
      // pto: %q_sin_signed_tail_inline8256__ssa_v0
      ;
      uint64_t v725 = (uint64_t) v36;
      TASSIGN(v724, v725);
      // pto: %247
      ;
      const int64_t v726 = 0;
      // pto: %247
      ;
      __gm__ float* v727 = PTOAS__GLOBAL_TENSOR_DATA(v110);
      // pto: %247
      ;
      const int64_t v728 = 1;
      // pto: %247
      ;
      const int64_t v729 = 1;
      // pto: %247
      ;
      const int64_t v730 = 1;
      // pto: %247
      ;
      int64_t v731 = v702 * v56;
      // pto: %247
      ;
      int64_t v732 = v730 * v731;
      // pto: %247
      ;
      pto::Shape<1, 1, 1, -1, 64> v733 = pto::Shape<1, 1, 1, -1, 64>(v728, v729, v730, v702, v56);
      // pto: %247
      ;
      pto::Stride<-1, -1, -1, -1, -1> v734 = pto::Stride<-1, -1, -1, -1, -1>(v729 * v732, v732, v731, v56, v54);
      // pto: %247
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v735 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v727 + (v726 + v713 * v56 + v58 * v54), v733, v734);
      pipe_barrier(PIPE_ALL);
      TLOAD(v724, v735);
      // pto: %t__tmp_v68
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v736 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %t__tmp_v68
      ;
      uint64_t v737 = (uint64_t) v21;
      TASSIGN(v736, v737);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      pipe_barrier(PIPE_V);
      TEXPANDS(v736, v66);
      // pto: %t__ci_tmp_v0
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v738 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v68);
      // pto: %t__ci_tmp_v0
      ;
      uint64_t v739 = (uint64_t) v23;
      TASSIGN(v738, v739);
      // pto: %t__tmp_v69
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v740 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
      // pto: %t__tmp_v69
      ;
      uint64_t v741 = (uint64_t) v18;
      TASSIGN(v740, v741);
      // pto: %ci_tmp_view
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v742;
      TRESHAPE(v742, v738);
      // pto: %ci_dst_view
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v743;
      TRESHAPE(v743, v740);
      TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v743, v72, v742);
      // pto: %t__tmp_v70
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v744 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
      // pto: %t__tmp_v70
      ;
      uint64_t v745 = (uint64_t) v23;
      TASSIGN(v744, v745);
      pipe_barrier(PIPE_V);
      RoundMode v746 = RoundMode::CAST_ROUND;
      SaturationMode v747 = SaturationMode::ON;
      TCVT(v744, v740, v746, v747);
      // pto: %q_col_inline8289__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v748 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_col_inline8289__ssa_v0
      ;
      uint64_t v749 = (uint64_t) v21;
      TASSIGN(v748, v749);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v748, v736, v744);
      // pto: %t__tmp_v71
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v750 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %t__tmp_v71
      ;
      uint64_t v751 = (uint64_t) v23;
      TASSIGN(v750, v751);
      pipe_barrier(PIPE_V);
      TMULS(v750, v748, v73);
      // pto: %t__tmp_v72
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v752 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %t__tmp_v72
      ;
      uint64_t v753 = (uint64_t) v23;
      TASSIGN(v752, v753);
      pipe_barrier(PIPE_V);
      RoundMode v754 = RoundMode::CAST_TRUNC;
      SaturationMode v755 = SaturationMode::ON;
      TCVT(v752, v750, v754, v755);
      // pto: %q_dup_f_inline8293__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v756 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_dup_f_inline8293__ssa_v0
      ;
      uint64_t v757 = (uint64_t) v23;
      TASSIGN(v756, v757);
      pipe_barrier(PIPE_V);
      RoundMode v758 = RoundMode::CAST_ROUND;
      SaturationMode v759 = SaturationMode::ON;
      TCVT(v756, v752, v758, v759);
      // pto: %t__tmp_v73
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v760 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %t__tmp_v73
      ;
      uint64_t v761 = (uint64_t) v23;
      TASSIGN(v760, v761);
      pipe_barrier(PIPE_V);
      TMULS(v760, v756, v74);
      // pto: %q_lane_inline8265__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v762 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_lane_inline8265__ssa_v0
      ;
      uint64_t v763 = (uint64_t) v23;
      TASSIGN(v762, v763);
      pipe_barrier(PIPE_V);
      TSUB(v762, v748, v760);
      // pto: %t__tmp_v74
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v764 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %t__tmp_v74
      ;
      uint64_t v765 = (uint64_t) v21;
      TASSIGN(v764, v765);
      pipe_barrier(PIPE_V);
      TADDS(v764, v748, v66);
      // pto: %t__tmp_v75
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v766 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %t__tmp_v75
      ;
      uint64_t v767 = (uint64_t) v23;
      TASSIGN(v766, v767);
      TMULS(v766, v762, v74);
      // pto: %q_swap_f_inline8295__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v768 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_swap_f_inline8295__ssa_v0
      ;
      uint64_t v769 = (uint64_t) v21;
      TASSIGN(v768, v769);
      pipe_barrier(PIPE_V);
      TSUB(v768, v764, v766);
      // pto: %t__ci_tmp_v1
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v770 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v68);
      // pto: %t__ci_tmp_v1
      ;
      uint64_t v771 = (uint64_t) v23;
      TASSIGN(v770, v771);
      // pto: %t__tmp_v76
      ;
      Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v772 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
      // pto: %t__tmp_v76
      ;
      uint64_t v773 = (uint64_t) v18;
      TASSIGN(v772, v773);
      // pto: %248
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v774;
      TRESHAPE(v774, v770);
      // pto: %249
      ;
      Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v775;
      TRESHAPE(v775, v772);
      pipe_barrier(PIPE_V);
      TCI<Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v775, v72, v774);
      // pto: %t__tmp_v77
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v776 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
      // pto: %t__tmp_v77
      ;
      uint64_t v777 = (uint64_t) v23;
      TASSIGN(v776, v777);
      pipe_barrier(PIPE_V);
      RoundMode v778 = RoundMode::CAST_ROUND;
      SaturationMode v779 = SaturationMode::ON;
      TCVT(v776, v772, v778, v779);
      // pto: %q_row_seed_inline8284__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v780 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
      // pto: %q_row_seed_inline8284__ssa_v0
      ;
      uint64_t v781 = (uint64_t) v18;
      TASSIGN(v780, v781);
      pipe_barrier(PIPE_V);
      TMULS(v780, v776, v75);
      // pto: %t__tmp_v78
      ;
      Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v782 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v56, v63);
      // pto: %t__tmp_v78
      ;
      uint64_t v783 = (uint64_t) v23;
      TASSIGN(v782, v783);
      pipe_barrier(PIPE_V);
      TEXPANDS(v782, v66);
      // pto: %q_row_grid_inline8296__ssa_v0
      ;
      Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v784 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v56, v63);
      // pto: %q_row_grid_inline8296__ssa_v0
      ;
      uint64_t v785 = (uint64_t) v23;
      TASSIGN(v784, v785);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v784, v782, v780);
      // pto: %transpose_tmp
      ;
      Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v786 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v56, v63);
      // pto: %transpose_tmp
      ;
      uint64_t v787 = (uint64_t) v18;
      TASSIGN(v786, v787);
      // pto: %q_row_offset_inline8258__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v788 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_row_offset_inline8258__ssa_v0
      ;
      uint64_t v789 = (uint64_t) v19;
      TASSIGN(v788, v789);
      pipe_barrier(PIPE_V);
      TTRANS(v788, v784, v786);
      // pto: %t__tmp_v79
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v790 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %t__tmp_v79
      ;
      uint64_t v791 = (uint64_t) v21;
      TASSIGN(v790, v791);
      pipe_barrier(PIPE_V);
      TADD(v790, v768, v788);
      // pto: %q_swap_idx_tail_inline8298__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v792 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_swap_idx_tail_inline8298__ssa_v0
      ;
      uint64_t v793 = (uint64_t) v18;
      TASSIGN(v792, v793);
      pipe_barrier(PIPE_V);
      RoundMode v794 = RoundMode::CAST_ROUND;
      SaturationMode v795 = SaturationMode::ON;
      TCVT(v792, v790, v794, v795);
      // pto: %q_head_reduce_tmp_inline8299__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v796 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_head_reduce_tmp_inline8299__ssa_v0
      ;
      uint64_t v797 = (uint64_t) v19;
      TASSIGN(v796, v797);
      // pto: %q_rsqrt_tmp_inline8300__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v798 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
      // pto: %q_rsqrt_tmp_inline8300__ssa_v0
      ;
      uint64_t v799 = (uint64_t) v40;
      TASSIGN(v798, v799);
      // pto: %q_gather_tmp_inline8253__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v800 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_gather_tmp_inline8253__ssa_v0
      ;
      uint64_t v801 = (uint64_t) v20;
      TASSIGN(v800, v801);
      pipe_barrier(PIPE_ALL);
      for (int64_t v802 = v58; v802 < v141; v802 += v54) {
        // pto: %250, %251
        ;
        int64_t v803 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v149 + (uint64_t) v802) * (uint64_t) v55);
        // pto: %q_head_acc_tail_inline8223__ssa_v0
        ;
        Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v804 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_acc_tail_inline8223__ssa_v0
        ;
        uint64_t v805 = (uint64_t) v21;
        TASSIGN(v804, v805);
        // pto: %253
        ;
        int64_t v806 = v803 < v58 ? v58 : v803;
        // pto: %254
        ;
        __gm__ int32_t* v807 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %254
        ;
        const int64_t v808 = 0;
        // pto: %254
        ;
        const int64_t v809 = 32768;
        // pto: %254
        ;
        pto::Shape<1, 1, 1, 8, 512> v810 = pto::Shape<1, 1, 1, 8, 512>();
        // pto: %254
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v811 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %254
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v812 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v807 + (v808 + v705 * v809 + v806), v810, v811);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
        TLOAD(v804, v812);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %q_head_scale_input_tail_inline8222__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v813 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %q_head_scale_input_tail_inline8222__ssa_v0
        ;
        uint64_t v814 = (uint64_t) v22;
        TASSIGN(v813, v814);
        // pto: %256
        ;
        __gm__ float* v815 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %256
        ;
        const int64_t v816 = 0;
        // pto: %256
        ;
        pto::Shape<1, 1, 1, 1, 512> v817 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %256
        ;
        pto::Stride<512, 512, 512, 512, 1> v818 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %256
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v819 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v815 + (v816 + v806), v817, v818);
        TLOAD(v813, v819);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        // pto: %q_head_scale_tail_inline8239__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v820 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %q_head_scale_tail_inline8239__ssa_v0
        ;
        uint64_t v821 = (uint64_t) v22;
        TASSIGN(v820, v821);
        // pto: %q_head_acc_fp32_tail_inline8229__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v822 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_acc_fp32_tail_inline8229__ssa_v0
        ;
        uint64_t v823 = (uint64_t) v21;
        TASSIGN(v822, v823);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v824 = RoundMode::CAST_NONE;
        SaturationMode v825 = SaturationMode::ON;
        TCVT(v822, v804, v824, v825);
        // pto: %t__tmp_v80
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v826 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %t__tmp_v80
        ;
        uint64_t v827 = (uint64_t) v23;
        TASSIGN(v826, v827);
        TEXPANDS(v826, v66);
        // pto: %t__tmp_v81
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v828 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %t__tmp_v81
        ;
        uint64_t v829 = (uint64_t) v23;
        TASSIGN(v828, v829);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v828, v826, v703);
        // pto: %q_head_scale_combined_tail_inline8290__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v830 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_scale_combined_tail_inline8290__ssa_v0
        ;
        uint64_t v831 = (uint64_t) v23;
        TASSIGN(v830, v831);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        TCOLEXPANDMUL(v830, v828, v820);
        // pto: %q_head_dq_tail_inline8275__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v832 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_dq_tail_inline8275__ssa_v0
        ;
        uint64_t v833 = (uint64_t) v21;
        TASSIGN(v832, v833);
        pipe_barrier(PIPE_V);
        TMUL(v832, v822, v830);
        // pto: %t__tmp_v82
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v834 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %t__tmp_v82
        ;
        uint64_t v835 = (uint64_t) v23;
        TASSIGN(v834, v835);
        pipe_barrier(PIPE_V);
        RoundMode v836 = RoundMode::CAST_RINT;
        SaturationMode v837 = SaturationMode::ON;
        TCVT(v834, v832, v836, v837);
        // pto: %q_head_dq_tail_v1_inline8264__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v838 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_dq_tail_v1_inline8264__ssa_v0
        ;
        uint64_t v839 = (uint64_t) v21;
        TASSIGN(v838, v839);
        pipe_barrier(PIPE_V);
        RoundMode v840 = RoundMode::CAST_ROUND;
        SaturationMode v841 = SaturationMode::ON;
        TCVT(v838, v834, v840, v841);
        // pto: %q_head_sq_tail_inline8221__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v842 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_sq_tail_inline8221__ssa_v0
        ;
        uint64_t v843 = (uint64_t) v23;
        TASSIGN(v842, v843);
        pipe_barrier(PIPE_V);
        TMUL(v842, v838, v838);
        // pto: %t__tmp_v83
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v844 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v83
        ;
        uint64_t v845 = (uint64_t) v23;
        TASSIGN(v844, v845);
        // pto: %257
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v846;
        // pto: %257
        ;
        uint64_t v847 = (uint64_t) v23;
        TASSIGN(v846, v847);
        // pto: %t__tmp_v84
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v848 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v84
        ;
        uint64_t v849 = (uint64_t) v47;
        TASSIGN(v848, v849);
        // pto: %258
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v850;
        // pto: %258
        ;
        uint64_t v851 = (uint64_t) v47;
        TASSIGN(v850, v851);
        // pto: %q_sq_04_tail_inline8220__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v852 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_04_tail_inline8220__ssa_v0
        ;
        uint64_t v853 = (uint64_t) v22;
        TASSIGN(v852, v853);
        pipe_barrier(PIPE_V);
        TADD(v852, v846, v850);
        // pto: %t__tmp_v85
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v854 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v85
        ;
        uint64_t v855 = (uint64_t) v48;
        TASSIGN(v854, v855);
        // pto: %259
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v856;
        // pto: %259
        ;
        uint64_t v857 = (uint64_t) v48;
        TASSIGN(v856, v857);
        // pto: %t__tmp_v86
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v858 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v86
        ;
        uint64_t v859 = (uint64_t) v49;
        TASSIGN(v858, v859);
        // pto: %260
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v860;
        // pto: %260
        ;
        uint64_t v861 = (uint64_t) v49;
        TASSIGN(v860, v861);
        // pto: %q_sq_15_tail_inline8219__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v862 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_15_tail_inline8219__ssa_v0
        ;
        uint64_t v863 = (uint64_t) v24;
        TASSIGN(v862, v863);
        TADD(v862, v856, v860);
        // pto: %t__tmp_v87
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v864 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v87
        ;
        uint64_t v865 = (uint64_t) v50;
        TASSIGN(v864, v865);
        // pto: %261
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v866;
        // pto: %261
        ;
        uint64_t v867 = (uint64_t) v50;
        TASSIGN(v866, v867);
        // pto: %t__tmp_v88
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v868 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v88
        ;
        uint64_t v869 = (uint64_t) v51;
        TASSIGN(v868, v869);
        // pto: %262
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v870;
        // pto: %262
        ;
        uint64_t v871 = (uint64_t) v51;
        TASSIGN(v870, v871);
        // pto: %q_sq_26_tail_inline8218__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v872 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_26_tail_inline8218__ssa_v0
        ;
        uint64_t v873 = (uint64_t) v29;
        TASSIGN(v872, v873);
        TADD(v872, v866, v870);
        // pto: %t__tmp_v89
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v874 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v89
        ;
        uint64_t v875 = (uint64_t) v52;
        TASSIGN(v874, v875);
        // pto: %263
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v876;
        // pto: %263
        ;
        uint64_t v877 = (uint64_t) v52;
        TASSIGN(v876, v877);
        // pto: %t__tmp_v90
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v878 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v90
        ;
        uint64_t v879 = (uint64_t) v46;
        TASSIGN(v878, v879);
        // pto: %264
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v880;
        // pto: %264
        ;
        uint64_t v881 = (uint64_t) v46;
        TASSIGN(v880, v881);
        // pto: %q_sq_37_tail_inline8216__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v882 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_37_tail_inline8216__ssa_v0
        ;
        uint64_t v883 = (uint64_t) v23;
        TASSIGN(v882, v883);
        pipe_barrier(PIPE_V);
        TADD(v882, v876, v880);
        // pto: %q_sq_0246_tail_inline8217__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v884 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_0246_tail_inline8217__ssa_v0
        ;
        uint64_t v885 = (uint64_t) v22;
        TASSIGN(v884, v885);
        TADD(v884, v852, v872);
        // pto: %q_sq_1357_tail_inline8259__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v886 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_1357_tail_inline8259__ssa_v0
        ;
        uint64_t v887 = (uint64_t) v23;
        TASSIGN(v886, v887);
        pipe_barrier(PIPE_V);
        TADD(v886, v862, v882);
        // pto: %q_sq_64_tail_inline8215__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v888 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_64_tail_inline8215__ssa_v0
        ;
        uint64_t v889 = (uint64_t) v23;
        TASSIGN(v888, v889);
        pipe_barrier(PIPE_V);
        TADD(v888, v884, v886);
        // pto: %q_head_sq_sum_tail_inline8214__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v890 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %q_head_sq_sum_tail_inline8214__ssa_v0
        ;
        uint64_t v891 = (uint64_t) v22;
        TASSIGN(v890, v891);
        pipe_barrier(PIPE_V);
        TROWSUM(v890, v888, v796);
        // pto: %t__rm_a0_tmp_v0
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v892 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %t__rm_a0_tmp_v0
        ;
        uint64_t v893 = (uint64_t) v22;
        TASSIGN(v892, v893);
        // pto: %t__row_major_tmp_v1
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v894 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %t__row_major_tmp_v1
        ;
        uint64_t v895 = (uint64_t) v23;
        TASSIGN(v894, v895);
        pipe_barrier(PIPE_V);
        TMULS(v894, v892, v70);
        // pto: %t__tmp_v91
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v896 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %t__tmp_v91
        ;
        uint64_t v897 = (uint64_t) v23;
        TASSIGN(v896, v897);
        // pto: %q_head_var_tail_inline8213__rm_a0_tmp_v2
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v898 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_var_tail_inline8213__rm_a0_tmp_v2
        ;
        uint64_t v899 = (uint64_t) v23;
        TASSIGN(v898, v899);
        // pto: %q_head_var_tail_inline8213__row_major_tmp_v3
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v900 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_var_tail_inline8213__row_major_tmp_v3
        ;
        uint64_t v901 = (uint64_t) v23;
        TASSIGN(v900, v901);
        pipe_barrier(PIPE_V);
        TADDS(v900, v898, v71);
        // pto: %q_head_var_tail_inline8213__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v902 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %q_head_var_tail_inline8213__ssa_v0
        ;
        uint64_t v903 = (uint64_t) v23;
        TASSIGN(v902, v903);
        // pto: %q_head_inv_rms_tail_inline8226__rm_a0_tmp_v4
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v904 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_inv_rms_tail_inline8226__rm_a0_tmp_v4
        ;
        uint64_t v905 = (uint64_t) v23;
        TASSIGN(v904, v905);
        // pto: %q_head_inv_rms_tail_inline8226__rm_a1_tmp_v5
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v906 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_inv_rms_tail_inline8226__rm_a1_tmp_v5
        ;
        uint64_t v907 = (uint64_t) v40;
        TASSIGN(v906, v907);
        // pto: %q_head_inv_rms_tail_inline8226__row_major_tmp_v6
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v908 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_inv_rms_tail_inline8226__row_major_tmp_v6
        ;
        uint64_t v909 = (uint64_t) v22;
        TASSIGN(v908, v909);
        pipe_barrier(PIPE_V);
        TRSQRT(v908, v904, v906);
        // pto: %q_head_inv_rms_tail_inline8226__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v910 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %q_head_inv_rms_tail_inline8226__ssa_v0
        ;
        uint64_t v911 = (uint64_t) v22;
        TASSIGN(v910, v911);
        // pto: %t__tmp_v92
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v912 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %t__tmp_v92
        ;
        uint64_t v913 = (uint64_t) v21;
        TASSIGN(v912, v913);
        // pto: %265
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 448, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v914;
        // pto: %265
        ;
        uint64_t v915 = (uint64_t) v21;
        TASSIGN(v914, v915);
        // pto: %q_nope_normed_tail_inline8281__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v916 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %q_nope_normed_tail_inline8281__ssa_v0
        ;
        uint64_t v917 = (uint64_t) v23;
        TASSIGN(v916, v917);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v916, v914, v910);
        // pto: %q_nope_bf16_tail_inline8246__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v918 = Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %q_nope_bf16_tail_inline8246__ssa_v0
        ;
        uint64_t v919 = (uint64_t) v23;
        TASSIGN(v918, v919);
        pipe_barrier(PIPE_V);
        RoundMode v920 = RoundMode::CAST_RINT;
        SaturationMode v921 = SaturationMode::ON;
        TCVT(v918, v916, v920, v921);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        v918.SetValidShape(v702, v69);
        // pto: %q_flat_inline8276__iter_v1_pview
        ;
        const int64_t v922 = 0;
        // pto: %q_flat_inline8276__iter_v1_pview
        ;
        __gm__ bfloat16_t* v923 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %q_flat_inline8276__iter_v1_pview
        ;
        const int64_t v924 = 1;
        // pto: %q_flat_inline8276__iter_v1_pview
        ;
        const int64_t v925 = 1;
        // pto: %q_flat_inline8276__iter_v1_pview
        ;
        const int64_t v926 = 1;
        // pto: %q_flat_inline8276__iter_v1_pview
        ;
        int64_t v927 = v702 * v53;
        // pto: %q_flat_inline8276__iter_v1_pview
        ;
        int64_t v928 = v926 * v927;
        // pto: %q_flat_inline8276__iter_v1_pview
        ;
        pto::Shape<1, 1, 1, -1, 448> v929 = pto::Shape<1, 1, 1, -1, 448>(v924, v925, v926, v702, v69);
        // pto: %q_flat_inline8276__iter_v1_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v930 = pto::Stride<-1, -1, -1, -1, -1>(v925 * v928, v928, v927, v53, v54);
        // pto: %q_flat_inline8276__iter_v1_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 448>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v931 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 448>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v923 + (v922 + v713 * v53 + v806 * v54), v929, v930);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        TSTORE(v931, v918);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
        // pto: %q_rope_chunk_raw_tail_inline8211__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v932 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_chunk_raw_tail_inline8211__ssa_v0
        ;
        uint64_t v933 = (uint64_t) v35;
        TASSIGN(v932, v933);
        // pto: %268
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v934;
        // pto: %268
        ;
        uint64_t v935 = (uint64_t) v35;
        TASSIGN(v934, v935);
        // pto: %q_rope_chunk_tail_inline8238__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v936 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_chunk_tail_inline8238__ssa_v0
        ;
        uint64_t v937 = (uint64_t) v21;
        TASSIGN(v936, v937);
        TROWEXPANDMUL(v936, v934, v910);
        // pto: %t__tmp_v93
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v938 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v93
        ;
        uint64_t v939 = (uint64_t) v23;
        TASSIGN(v938, v939);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
        RoundMode v940 = RoundMode::CAST_RINT;
        SaturationMode v941 = SaturationMode::ON;
        TCVT(v938, v936, v940, v941);
        // pto: %q_rope_chunk_tail_v1_inline8210__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v942 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_chunk_tail_v1_inline8210__ssa_v0
        ;
        uint64_t v943 = (uint64_t) v21;
        TASSIGN(v942, v943);
        pipe_barrier(PIPE_V);
        RoundMode v944 = RoundMode::CAST_ROUND;
        SaturationMode v945 = SaturationMode::ON;
        TCVT(v942, v938, v944, v945);
        // pto: %q_rope_swapped_tail_inline8209__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v946 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_swapped_tail_inline8209__ssa_v0
        ;
        uint64_t v947 = (uint64_t) v23;
        TASSIGN(v946, v947);
        pipe_barrier(PIPE_V);
        TGATHER(v946, v942, v792, v800);
        v942.SetValidShape(v702, v56);
        v946.SetValidShape(v702, v56);
        // pto: %q_rope_base_tail_inline8294__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v948 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v702, v56);
        // pto: %q_rope_base_tail_inline8294__ssa_v0
        ;
        uint64_t v949 = (uint64_t) v21;
        TASSIGN(v948, v949);
        pipe_barrier(PIPE_V);
        TMUL(v948, v942, v711);
        // pto: %q_rope_delta_tail_inline8263__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v950 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v702, v56);
        // pto: %q_rope_delta_tail_inline8263__ssa_v0
        ;
        uint64_t v951 = (uint64_t) v23;
        TASSIGN(v950, v951);
        TMUL(v950, v946, v724);
        // pto: %q_rope_rot_tail_inline8279__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v952 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v702, v56);
        // pto: %q_rope_rot_tail_inline8279__ssa_v0
        ;
        uint64_t v953 = (uint64_t) v21;
        TASSIGN(v952, v953);
        pipe_barrier(PIPE_V);
        TADD(v952, v948, v950);
        // pto: %q_rope_bf16_tail_inline8206__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v954 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v702, v56);
        // pto: %q_rope_bf16_tail_inline8206__ssa_v0
        ;
        uint64_t v955 = (uint64_t) v21;
        TASSIGN(v954, v955);
        pipe_barrier(PIPE_V);
        RoundMode v956 = RoundMode::CAST_RINT;
        SaturationMode v957 = SaturationMode::ON;
        TCVT(v954, v952, v956, v957);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        v954.SetValidShape(v702, v56);
        // pto: %270
        ;
        int64_t v958 = (int64_t) ((uint64_t) v803 + (uint64_t) v69);
        // pto: %271
        ;
        int64_t v959 = v958 < v58 ? v58 : v958;
        // pto: %272
        ;
        const int64_t v960 = 0;
        // pto: %272
        ;
        __gm__ bfloat16_t* v961 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %272
        ;
        const int64_t v962 = 1;
        // pto: %272
        ;
        const int64_t v963 = 1;
        // pto: %272
        ;
        const int64_t v964 = 1;
        // pto: %272
        ;
        int64_t v965 = v702 * v53;
        // pto: %272
        ;
        int64_t v966 = v964 * v965;
        // pto: %272
        ;
        pto::Shape<1, 1, 1, -1, 64> v967 = pto::Shape<1, 1, 1, -1, 64>(v962, v963, v964, v702, v56);
        // pto: %272
        ;
        pto::Stride<-1, -1, -1, -1, -1> v968 = pto::Stride<-1, -1, -1, -1, -1>(v963 * v966, v966, v965, v53, v54);
        // pto: %272
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v969 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v961 + (v960 + v713 * v53 + v959 * v54), v967, v968);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        TSTORE(v969, v954);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
    };
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}