#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qk_pv_aic(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ bfloat16_t* v3, __gm__ int32_t* v4, __gm__ bfloat16_t* v5, __gm__ float* v6, __gm__ bfloat16_t* v7, __gm__ float* v8, __gm__ float* v9, __gm__ float* v10, __gm__ float* v11, __gm__ int64_t* v12, __gm__ int32_t* v13, __gm__ bfloat16_t* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, __gm__ bfloat16_t* v17, __gm__ float* v18, __gm__ float* v19, __gm__ float* v20, __gm__ float* v21, __gm__ float* v22, __gm__ bfloat16_t* v23, int64_t v24, int64_t v25, int64_t v26, int64_t v27, int64_t v28, int64_t v29, int64_t v30, int64_t v31, int64_t v32, int32_t v33, int32_t v34) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int64_t v35 = 32;
  // pto: %c0_i64
  const int64_t v36 = 0;
  // pto: %c393216_i64
  const int64_t v37 = 393216;
  // pto: %c16384_i64
  const int64_t v38 = 16384;
  // pto: %c32768_i64
  const int64_t v39 = 32768;
  // pto: %c458752_i64
  const int64_t v40 = 458752;
  // pto: %c1_index
  const int64_t v41 = 1;
  // pto: %c512_index
  const int64_t v42 = 512;
  // pto: %c16_index
  const int64_t v43 = 16;
  // pto: %c24576_index
  const int64_t v44 = 24576;
  // pto: %c3072_index
  const int64_t v45 = 3072;
  // pto: %c1536_index
  const int64_t v46 = 1536;
  // pto: %c64_index
  const int64_t v47 = 64;
  // pto: %c128_index
  const int64_t v48 = 128;
  // pto: %c384_index
  const int64_t v49 = 384;
  // pto: %c24_index
  const int64_t v50 = 24;
  // pto: %c0_index
  const int64_t v51 = 0;
  // pto: %c2_index
  const int64_t v52 = 2;
  // pto: %c4_index
  const int64_t v53 = 4;
  // pto: %c256_index
  const int64_t v54 = 256;
  // pto: %cn128_index
  const int64_t v55 = -128;
  // pto: %c32_index
  const int64_t v56 = 32;
  // pto: %cn32_index
  const int64_t v57 = -32;
  // pto: %c3_index
  const int64_t v58 = 3;
  // pto: %q_flat_inline5169__ssa_v0_view
  const int64_t v59 = 1;
  // pto: %q_flat_inline5169__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %q_flat_inline5169__ssa_v0_view
  const int64_t v61 = 1;
  // pto: %q_flat_inline5169__ssa_v0_view
  int64_t v62 = (int64_t) v26;
  // pto: %q_flat_inline5169__ssa_v0_view
  int64_t v63 = v62 * v42;
  // pto: %q_flat_inline5169__ssa_v0_view
  int64_t v64 = v61 * v63;
  // pto: %q_flat_inline5169__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v65 = pto::Shape<1, 1, 1, -1, -1>(v59, v60, v61, v62, v42);
  // pto: %q_flat_inline5169__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v66 = pto::Stride<-1, -1, -1, -1, -1>(v60 * v64, v64, v63, v42, v41);
  // pto: %q_flat_inline5169__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v67 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v65, v66);
  // pto: %kv_transfer_inline5167__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %kv_transfer_inline5167__ssa_v0_view
  const int64_t v69 = 1;
  // pto: %kv_transfer_inline5167__ssa_v0_view
  const int64_t v70 = 1;
  // pto: %kv_transfer_inline5167__ssa_v0_view
  int64_t v71 = v44 * v42;
  // pto: %kv_transfer_inline5167__ssa_v0_view
  int64_t v72 = v70 * v71;
  // pto: %kv_transfer_inline5167__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v73 = pto::Shape<1, 1, 1, -1, -1>(v68, v69, v70, v44, v42);
  // pto: %kv_transfer_inline5167__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v74 = pto::Stride<-1, -1, -1, -1, -1>(v69 * v72, v72, v71, v42, v41);
  // pto: %kv_transfer_inline5167__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v75 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v73, v74);
  // pto: %score_transfer_inline5311__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %score_transfer_inline5311__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %score_transfer_inline5311__ssa_v0_view
  const int64_t v78 = 1;
  // pto: %score_transfer_inline5311__ssa_v0_view
  int64_t v79 = v45 * v42;
  // pto: %score_transfer_inline5311__ssa_v0_view
  int64_t v80 = v78 * v79;
  // pto: %score_transfer_inline5311__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v81 = pto::Shape<1, 1, 1, -1, -1>(v76, v77, v78, v45, v42);
  // pto: %score_transfer_inline5311__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v82 = pto::Stride<-1, -1, -1, -1, -1>(v77 * v80, v80, v79, v42, v41);
  // pto: %score_transfer_inline5311__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v83 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v81, v82);
  // pto: %probability_transfer_inline5166__ssa_v0_view
  const int64_t v84 = 1;
  // pto: %probability_transfer_inline5166__ssa_v0_view
  const int64_t v85 = 1;
  // pto: %probability_transfer_inline5166__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %probability_transfer_inline5166__ssa_v0_view
  int64_t v87 = v46 * v42;
  // pto: %probability_transfer_inline5166__ssa_v0_view
  int64_t v88 = v86 * v87;
  // pto: %probability_transfer_inline5166__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v89 = pto::Shape<1, 1, 1, -1, -1>(v84, v85, v86, v46, v42);
  // pto: %probability_transfer_inline5166__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v90 = pto::Stride<-1, -1, -1, -1, -1>(v85 * v88, v88, v87, v42, v41);
  // pto: %probability_transfer_inline5166__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v91 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v89, v90);
  // pto: %pv_transfer_inline5179__ssa_v0_view
  const int64_t v92 = 1;
  // pto: %pv_transfer_inline5179__ssa_v0_view
  const int64_t v93 = 1;
  // pto: %pv_transfer_inline5179__ssa_v0_view
  const int64_t v94 = 1;
  // pto: %pv_transfer_inline5179__ssa_v0_view
  int64_t v95 = v46 * v42;
  // pto: %pv_transfer_inline5179__ssa_v0_view
  int64_t v96 = v94 * v95;
  // pto: %pv_transfer_inline5179__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v97 = pto::Shape<1, 1, 1, -1, -1>(v92, v93, v94, v46, v42);
  // pto: %pv_transfer_inline5179__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v98 = pto::Stride<-1, -1, -1, -1, -1>(v93 * v96, v96, v95, v42, v41);
  // pto: %pv_transfer_inline5179__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v99 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v97, v98);
  // pto: %qk_l1_inline5159__phi_v16
  Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v100 = Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v49, v42);
  // pto: %qk_l1_inline5159__phi_v16
  uint64_t v101 = (uint64_t) v36;
  TASSIGN(v100, v101);
  // pto: %qk_l1_inline5159__phi_v8
  Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v49, v42);
  // pto: %qk_l1_inline5159__phi_v8
  uint64_t v103 = (uint64_t) v36;
  TASSIGN(v102, v103);
  // pto: %pv_acc_inline5336__phi_v4
  Tile<TileType::Acc, float, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v104 = Tile<TileType::Acc, float, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v47, v42);
  // pto: %pv_acc_inline5336__phi_v4
  uint64_t v105 = (uint64_t) v36;
  TASSIGN(v104, v105);
  // pto: %qk_l1_inline5159__phi_v15
  Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v49, v42);
  // pto: %qk_l1_inline5159__phi_v15
  uint64_t v107 = (uint64_t) v36;
  TASSIGN(v106, v107);
  // pto: %qk_l1_inline5159__phi_v14
  Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v49, v42);
  // pto: %qk_l1_inline5159__phi_v14
  uint64_t v109 = (uint64_t) v36;
  TASSIGN(v108, v109);
  // pto: %qk_core_inline5266__ssa_v0
  int64_t v110 = (int64_t) v33;
  // pto: %6
  int64_t v111 = (int64_t) ((uint64_t) v110 * (uint64_t) v47);
  uint64_t v112 = reinterpret_cast<uint64_t>(v1);
  set_ffts_base_addr(v112);
  // pto: %qk_l1_inline5159__ssa_v0
  Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v49, v42);
  // pto: %qk_l1_inline5159__ssa_v0
  uint64_t v114 = (uint64_t) v36;
  TASSIGN(v113, v114);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  for (int64_t v115 = v110; v115 < v24; v115 += v50) {
    // pto: %qk_q_inline5235__ssa_v0
    ;
    Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v42);
    // pto: %qk_q_inline5235__ssa_v0
    ;
    uint64_t v117 = (uint64_t) v37;
    TASSIGN(v116, v117);
    // pto: %8
    ;
    int64_t v118 = (int64_t) ((uint64_t) v115 * (uint64_t) v47);
    // pto: %9
    ;
    int64_t v119 = v118 < v51 ? v51 : v118;
    // pto: %q_flat_inline5169__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v120 = PTOAS__GLOBAL_TENSOR_DATA(v67);
    // pto: %q_flat_inline5169__ssa_v0_pview
    ;
    const int64_t v121 = 0;
    // pto: %q_flat_inline5169__ssa_v0_pview
    ;
    const int64_t v122 = 512;
    // pto: %q_flat_inline5169__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 64, 512> v123 = pto::Shape<1, 1, 1, 64, 512>();
    // pto: %q_flat_inline5169__ssa_v0_pview
    ;
    pto::Stride<32768, 32768, 32768, 512, 1> v124 = pto::Stride<32768, 32768, 32768, 512, 1>();
    // pto: %q_flat_inline5169__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v125 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v120 + (v121 + v119 * v122), v123, v124);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v116, v125);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    // pto: %flat_offset_mul
    ;
    int64_t v126 = (int64_t) ((uint64_t) v115 * (uint64_t) v43);
    // pto: %t__tile
    ;
    int32_t v127 = (v4)[v126];
    // pto: %13, %11
    ;
    int32_t v128 = (v4)[(int64_t) ((uint64_t) v126 + (uint64_t) v41)];
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    for (int64_t v129 = v51; v129 < v52; v129 += v41) {
      // pto: %22, %20
      ;
      int32_t v130 = (v4)[(int64_t) ((uint64_t) v126 + (uint64_t) v129)];
      // pto: %23, %24
      ;
      if ((int64_t) v130 > v51) {
        // pto: %25, %26, %27
        ;
        int64_t v131 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v115 - (uint64_t) v110) / v50) * (uint64_t) v52);
        // pto: %29
        ;
        int64_t v132 = (int64_t) ((uint64_t) v110 * (uint64_t) v52);
        // pto: %28, %30
        ;
        int64_t v133 = (int64_t) ((uint64_t) v131 + (uint64_t) v129) % v52;
        // pto: %31, %32, %33
        ;
        int64_t v134 = v133 < v51 ? (int64_t) ((uint64_t) v133 + (uint64_t) v52) : v133;
        int32_t v135 = (int32_t) v51;
        wait_flag_dev(v135);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        for (int64_t v136 = v51; v136 < v53; v136 += v41) {
          // pto: %36
          ;
          int64_t v137 = (int64_t) ((uint64_t) v136 * (uint64_t) v48);
          // pto: %37
          ;
          int64_t v138 = (int64_t) ((uint64_t) v136 - (uint64_t) v41);
          // pto: %38
          ;
          int64_t v139 = v138 < v51 ? v51 : v138;
          // pto: %39
          ;
          int64_t v140 = (int64_t) ((uint64_t) v139 * (uint64_t) v48);
          // pto: %40, %41, %42
          ;
          if (v129 > v51 | v136 == v51) {
            // pto: %gather_row_view
            ;
            Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, 128, 512, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v141;
            // pto: %gather_row_view
            ;
            uint64_t v142 = (uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v35);
            TASSIGN(v141, v142);
            // pto: %34, %35, %43
            ;
            int64_t v143 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v132 + (uint64_t) v134) * (uint64_t) v42) + (uint64_t) v137);
            // pto: %44
            ;
            int64_t v144 = v143 < v51 ? v51 : v143;
            // pto: %kv_transfer_inline5167__ssa_v0_pview
            ;
            __gm__ bfloat16_t* v145 = PTOAS__GLOBAL_TENSOR_DATA(v75);
            // pto: %kv_transfer_inline5167__ssa_v0_pview
            ;
            const int64_t v146 = 0;
            // pto: %kv_transfer_inline5167__ssa_v0_pview
            ;
            const int64_t v147 = 512;
            // pto: %kv_transfer_inline5167__ssa_v0_pview
            ;
            pto::Shape<1, 1, 1, 128, 512> v148 = pto::Shape<1, 1, 1, 128, 512>();
            // pto: %kv_transfer_inline5167__ssa_v0_pview
            ;
            pto::Stride<65536, 65536, 65536, 512, 1> v149 = pto::Stride<65536, 65536, 65536, 512, 1>();
            // pto: %kv_transfer_inline5167__ssa_v0_pview
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 512>, pto::Stride<65536, 65536, 65536, 512, 1>, pto::Layout::ND> v150 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 512>, pto::Stride<65536, 65536, 65536, 512, 1>, pto::Layout::ND>(v145 + (v146 + v144 * v147), v148, v149);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            TLOAD(v141, v150);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %qk_l1_t_inline5358__ssa_v0
            ;
            Tile<TileType::Mat, bfloat16_t, 512, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v151 = Tile<TileType::Mat, bfloat16_t, 512, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v42, v49);
            // pto: %qk_l1_t_inline5358__ssa_v0
            ;
            uint64_t v152 = (uint64_t) v36;
            TASSIGN(v151, v152);
            // pto: %qk_scores_inline5333__ssa_v0_l0_init
            ;
            Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v153 = Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v47, v48);
            // pto: %qk_scores_inline5333__ssa_v0_l0_init
            ;
            uint64_t v154 = (uint64_t) v36;
            TASSIGN(v153, v154);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
            for (int64_t v155 = v51; v155 < v42; v155 += v54) {
              // pto: %qk_scores_inline5333__ssa_v0_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v156 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v48);
              // pto: %qk_scores_inline5333__ssa_v0_l0_a
              ;
              uint64_t v157 = (uint64_t) v36;
              TASSIGN(v156, v157);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              pipe_barrier(PIPE_MTE1);
              uint16_t v158 = static_cast<uint16_t>(v51);
              uint16_t v159 = static_cast<uint16_t>(v155);
              TEXTRACT(v156, v116, v158, v159);
              // pto: %qk_scores_inline5333__ssa_v0_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v160 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v48, v48);
              // pto: %qk_scores_inline5333__ssa_v0_l0_b
              ;
              uint64_t v161 = (uint64_t) v36;
              TASSIGN(v160, v161);
              uint16_t v162 = static_cast<uint16_t>(v155);
              uint16_t v163 = static_cast<uint16_t>(v140);
              TEXTRACT(v160, v151, v162, v163);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              // pto: %0
              ;
              Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v164 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v48);
              // pto: %0
              ;
              uint64_t v165 = (uint64_t) v38;
              TASSIGN(v164, v165);
              // pto: %45
              ;
              int64_t v166 = (int64_t) ((uint64_t) v155 + (uint64_t) v48);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              uint16_t v167 = static_cast<uint16_t>(v51);
              uint16_t v168 = static_cast<uint16_t>(v166);
              TEXTRACT(v164, v116, v167, v168);
              // pto: %1
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v48, v48);
              // pto: %1
              ;
              uint64_t v170 = (uint64_t) v39;
              TASSIGN(v169, v170);
              uint16_t v171 = static_cast<uint16_t>(v166);
              uint16_t v172 = static_cast<uint16_t>(v140);
              TEXTRACT(v169, v151, v171, v172);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              // pto: %47
              ;
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              if (v155 == v51) {
                pipe_barrier(PIPE_M);
                TMATMUL(v153, v156, v160);
              } else {
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v153, v153, v156, v160);
              };
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              // pto: %48
              ;
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              if (v155 == v55) {
                pipe_barrier(PIPE_M);
                TMATMUL(v153, v164, v169);
              } else {
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v153, v153, v164, v169);
              };
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
            };
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
            // pto: %7, %50, %49
            ;
            int64_t v173 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v110 * (uint64_t) v48) + (uint64_t) ((int64_t) (uint64_t) v129 * (uint64_t) v47));
            // pto: %51
            ;
            int64_t v174 = v173 < v51 ? v51 : v173;
            // pto: %52
            ;
            int64_t v175 = v137 < v51 ? v51 : v137;
            // pto: %score_transfer_inline5311__ssa_v0_pview
            ;
            __gm__ float* v176 = PTOAS__GLOBAL_TENSOR_DATA(v83);
            // pto: %score_transfer_inline5311__ssa_v0_pview
            ;
            const int64_t v177 = 0;
            // pto: %score_transfer_inline5311__ssa_v0_pview
            ;
            const int64_t v178 = 512;
            // pto: %score_transfer_inline5311__ssa_v0_pview
            ;
            pto::Shape<1, 1, 1, 64, 128> v179 = pto::Shape<1, 1, 1, 64, 128>();
            // pto: %score_transfer_inline5311__ssa_v0_pview
            ;
            pto::Stride<32768, 32768, 32768, 512, 1> v180 = pto::Stride<32768, 32768, 32768, 512, 1>();
            // pto: %score_transfer_inline5311__ssa_v0_pview
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v181 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v176 + (v177 + v174 * v178 + v175), v179, v180);
            wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
            pipe_barrier(PIPE_FIX);
            TSTORE(v181, v153);
            set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
          };
        };
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        uint16_t v182 = getFFTSMsg(FFTS_MODE_VAL, v41);
        ffts_cross_core_sync(PIPE_FIX, v182);
        // pto: %14, %15, %16, %17, %18, %qk_pair_lookahead_inline5396__phi_v2, %54, %55
        ;
        bool v183 = (int64_t) ((int32_t) (int64_t) v127 > v51 & (int64_t) v128 > v51) > v51;
        // pto: %pv_begin_inline5335__phi_v2
        ;
        int64_t v184 = v183 ? v51 : v129;
        // pto: %pv_count_inline5196__phi_v2
        ;
        int64_t v185;
        if (v183) {
          // pto: %57
          ;
          v185 = (int64_t) ((uint64_t) v129 * (uint64_t) v52);
        } else {
          v185 = v41;
        };
        // pto: %58
        ;
        uint64_t v186 = (uint64_t) v185;
        // pto: %58
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        for (int64_t v187 = v184; v187 < ((int64_t) ((uint64_t) v184 + v186)); v187 += v41) {
          // pto: %62, %64
          ;
          int64_t v188 = (int64_t) ((uint64_t) v131 + (uint64_t) v187) % v52;
          // pto: %65, %66, %67
          ;
          int64_t v189 = v188 < v51 ? (int64_t) ((uint64_t) v188 + (uint64_t) v52) : v188;
          int32_t v190 = (int32_t) v52;
          wait_flag_dev(v190);
          // pto: %pv_acc_inline5336__ssa_v0
          ;
          Tile<TileType::Acc, float, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v191 = Tile<TileType::Acc, float, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %pv_acc_inline5336__ssa_v0
          ;
          uint64_t v192 = (uint64_t) v36;
          TASSIGN(v191, v192);
          wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
          for (int64_t v193 = v51; v193 < v53; v193 += v41) {
            // pto: %71
            ;
            bool v194 = v193 == v51;
            // pto: %70, %72
            ;
            if (v187 > v51 | v194) {
              // pto: %73
              ;
              int64_t v195 = (int64_t) ((uint64_t) v193 * (uint64_t) v48);
              // pto: %pv_probability_inline5364__ssa_v0
              ;
              Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v196 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v48);
              // pto: %pv_probability_inline5364__ssa_v0
              ;
              uint64_t v197 = (uint64_t) v40;
              TASSIGN(v196, v197);
              // pto: %74
              ;
              int64_t v198 = v111 < v51 ? v51 : v111;
              // pto: %75
              ;
              int64_t v199 = v195 < v51 ? v51 : v195;
              // pto: %probability_transfer_inline5166__ssa_v0_pview
              ;
              __gm__ bfloat16_t* v200 = PTOAS__GLOBAL_TENSOR_DATA(v91);
              // pto: %probability_transfer_inline5166__ssa_v0_pview
              ;
              const int64_t v201 = 0;
              // pto: %probability_transfer_inline5166__ssa_v0_pview
              ;
              const int64_t v202 = 512;
              // pto: %probability_transfer_inline5166__ssa_v0_pview
              ;
              pto::Shape<1, 1, 1, 64, 128> v203 = pto::Shape<1, 1, 1, 64, 128>();
              // pto: %probability_transfer_inline5166__ssa_v0_pview
              ;
              pto::Stride<32768, 32768, 32768, 512, 1> v204 = pto::Stride<32768, 32768, 32768, 512, 1>();
              // pto: %probability_transfer_inline5166__ssa_v0_pview
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v205 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v200 + (v201 + v198 * v202 + v199), v203, v204);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
              TLOAD(v196, v205);
              // pto: %76
              ;
              int64_t v206 = (int64_t) ((uint64_t) v193 - (uint64_t) v41);
              // pto: %77
              ;
              int64_t v207 = v206 < v51 ? v51 : v206;
              // pto: %78
              ;
              int64_t v208 = (int64_t) ((uint64_t) v207 * (uint64_t) v48);
              // pto: %79
              ;
              if (v193 < v52) {
                // pto: %80
                ;
                Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, 128, 512, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v209;
                // pto: %80
                ;
                uint64_t v210 = (uint64_t) ((int64_t) (uint64_t) v208 * (uint64_t) v35);
                TASSIGN(v209, v210);
                // pto: %68, %69, %81
                ;
                int64_t v211 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v132 + (uint64_t) v189) * (uint64_t) v42) + (uint64_t) v195);
                // pto: %82
                ;
                int64_t v212 = v211 < v51 ? v51 : v211;
                // pto: %83
                ;
                __gm__ bfloat16_t* v213 = PTOAS__GLOBAL_TENSOR_DATA(v75);
                // pto: %83
                ;
                const int64_t v214 = 0;
                // pto: %83
                ;
                const int64_t v215 = 512;
                // pto: %83
                ;
                pto::Shape<1, 1, 1, 128, 512> v216 = pto::Shape<1, 1, 1, 128, 512>();
                // pto: %83
                ;
                pto::Stride<65536, 65536, 65536, 512, 1> v217 = pto::Stride<65536, 65536, 65536, 512, 1>();
                // pto: %83
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 512>, pto::Stride<65536, 65536, 65536, 512, 1>, pto::Layout::ND> v218 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 512>, pto::Stride<65536, 65536, 65536, 512, 1>, pto::Layout::ND>(v213 + (v214 + v212 * v215), v216, v217);
                TLOAD(v209, v218);
              };
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
              for (int64_t v219 = v51; v219 < v48; v219 += v47) {
                // pto: %pv_acc_inline5336__ssa_v3_l0_a
                ;
                Tile<TileType::Left, bfloat16_t, 64, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Left, bfloat16_t, 64, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v56);
                // pto: %pv_acc_inline5336__ssa_v3_l0_a
                ;
                uint64_t v221 = (uint64_t) v36;
                TASSIGN(v220, v221);
                pipe_barrier(PIPE_MTE1);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
                uint16_t v222 = static_cast<uint16_t>(v51);
                uint16_t v223 = static_cast<uint16_t>(v219);
                TEXTRACT(v220, v196, v222, v223);
                // pto: %pv_acc_inline5336__ssa_v3_l0_b
                ;
                Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v224 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v56, v42);
                // pto: %pv_acc_inline5336__ssa_v3_l0_b
                ;
                uint64_t v225 = (uint64_t) v36;
                TASSIGN(v224, v225);
                // pto: %84
                ;
                int64_t v226 = (int64_t) ((uint64_t) v219 + (uint64_t) v208);
                uint16_t v227 = static_cast<uint16_t>(v226);
                uint16_t v228 = static_cast<uint16_t>(v51);
                TEXTRACT(v224, v108, v227, v228);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
                // pto: %3
                ;
                Tile<TileType::Left, bfloat16_t, 64, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v229 = Tile<TileType::Left, bfloat16_t, 64, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v56);
                // pto: %3
                ;
                uint64_t v230 = (uint64_t) v38;
                TASSIGN(v229, v230);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
                uint16_t v231 = static_cast<uint16_t>(v51);
                // pto: %85
                ;
                uint16_t v232 = static_cast<uint16_t>((int64_t) ((uint64_t) v219 + (uint64_t) v56));
                TEXTRACT(v229, v196, v231, v232);
                // pto: %4
                ;
                Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v233 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v56, v42);
                // pto: %4
                ;
                uint64_t v234 = (uint64_t) v39;
                TASSIGN(v233, v234);
                // pto: %87
                ;
                uint16_t v235 = static_cast<uint16_t>((int64_t) ((uint64_t) v226 + (uint64_t) v56));
                uint16_t v236 = static_cast<uint16_t>(v51);
                TEXTRACT(v233, v108, v235, v236);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
                // pto: %89, %90
                ;
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
                if (v194 & v219 == v51) {
                  pipe_barrier(PIPE_M);
                  TMATMUL(v191, v220, v224);
                } else {
                  pipe_barrier(PIPE_M);
                  TMATMUL_ACC(v191, v191, v220, v224);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
                // pto: %92, %93
                ;
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
                if (v194 & v219 == v57) {
                  pipe_barrier(PIPE_M);
                  TMATMUL(v191, v229, v233);
                } else {
                  pipe_barrier(PIPE_M);
                  TMATMUL_ACC(v191, v191, v229, v233);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
              };
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
            };
          };
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
          // pto: %94
          ;
          int64_t v237 = v111 < v51 ? v51 : v111;
          // pto: %pv_transfer_inline5179__ssa_v0_pview
          ;
          __gm__ float* v238 = PTOAS__GLOBAL_TENSOR_DATA(v99);
          // pto: %pv_transfer_inline5179__ssa_v0_pview
          ;
          const int64_t v239 = 0;
          // pto: %pv_transfer_inline5179__ssa_v0_pview
          ;
          const int64_t v240 = 512;
          // pto: %pv_transfer_inline5179__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 64, 512> v241 = pto::Shape<1, 1, 1, 64, 512>();
          // pto: %pv_transfer_inline5179__ssa_v0_pview
          ;
          pto::Stride<32768, 32768, 32768, 512, 1> v242 = pto::Stride<32768, 32768, 32768, 512, 1>();
          // pto: %pv_transfer_inline5179__ssa_v0_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v243 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v238 + (v239 + v237 * v240), v241, v242);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
          pipe_barrier(PIPE_FIX);
          TSTORE(v243, v191);
          set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
          uint16_t v244 = getFFTSMsg(FFTS_MODE_VAL, v58);
          ffts_cross_core_sync(PIPE_FIX, v244);
        };
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      };
    };
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    uint64_t v245 = reinterpret_cast<uint64_t>(v1);
    set_ffts_base_addr(v245);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void qk_pv_aiv(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ bfloat16_t* v3, __gm__ int32_t* v4, __gm__ bfloat16_t* v5, __gm__ float* v6, __gm__ bfloat16_t* v7, __gm__ float* v8, __gm__ float* v9, __gm__ float* v10, __gm__ float* v11, __gm__ int64_t* v12, __gm__ int32_t* v13, __gm__ bfloat16_t* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, __gm__ bfloat16_t* v17, __gm__ float* v18, __gm__ float* v19, __gm__ float* v20, __gm__ float* v21, __gm__ float* v22, __gm__ bfloat16_t* v23, int64_t v24, int64_t v25, int64_t v26, int64_t v27, int64_t v28, int64_t v29, int64_t v30, int64_t v31, int64_t v32, int32_t v33, int32_t v34, int32_t v35) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v36 = 1024;
  // pto: %c128_i64
  const int64_t v37 = 128;
  // pto: %c82048_i64
  const int64_t v38 = 82048;
  // pto: %c82176_i64
  const int64_t v39 = 82176;
  // pto: %c16512_i64
  const int64_t v40 = 16512;
  // pto: %c49280_i64
  const int64_t v41 = 49280;
  // pto: %c110720_i64
  const int64_t v42 = 110720;
  // pto: %c98432_i64
  const int64_t v43 = 98432;
  // pto: %c98464_i64
  const int64_t v44 = 98464;
  // pto: %c116864_i64
  const int64_t v45 = 116864;
  // pto: %c116896_i64
  const int64_t v46 = 116896;
  // pto: %c116928_i64
  const int64_t v47 = 116928;
  // pto: %c116960_i64
  const int64_t v48 = 116960;
  // pto: %c100480_i64
  const int64_t v49 = 100480;
  // pto: %c101248_i64
  const int64_t v50 = 101248;
  const int64_t v51 = 82304;
  // pto: %c102528_i64
  const int64_t v52 = 102528;
  // pto: %c104576_i64
  const int64_t v53 = 104576;
  // pto: %c104832_i64
  const int64_t v54 = 104832;
  const int64_t v55 = 82560;
  const int64_t v56 = 82816;
  const int64_t v57 = 83072;
  const int64_t v58 = 83328;
  const int64_t v59 = 83584;
  const int64_t v60 = 83840;
  // pto: %c114816_i64
  const int64_t v61 = 114816;
  // pto: %c98688_i64
  const int64_t v62 = 98688;
  // pto: %c0_i64
  const int64_t v63 = 0;
  // pto: %c118912_i64
  const int64_t v64 = 118912;
  // pto: %c119168_i64
  const int64_t v65 = 119168;
  // pto: %c84096_i64
  const int64_t v66 = 84096;
  // pto: %c84864_i64
  const int64_t v67 = 84864;
  // pto: %c119424_i64
  const int64_t v68 = 119424;
  // pto: %c106624_i64
  const int64_t v69 = 106624;
  // pto: %c108672_i64
  const int64_t v70 = 108672;
  // pto: %c90240_i64
  const int64_t v71 = 90240;
  // pto: %c1_index
  const int64_t v72 = 1;
  // pto: %c512_index
  const int64_t v73 = 512;
  // pto: %c16_index
  const int64_t v74 = 16;
  // pto: %c24576_index
  const int64_t v75 = 24576;
  // pto: %c3072_index
  const int64_t v76 = 3072;
  // pto: %c1536_index
  const int64_t v77 = 1536;
  // pto: %c64_index
  const int64_t v78 = 64;
  // pto: %c1024_index
  const int64_t v79 = 1024;
  // pto: %c32768_index
  const int64_t v80 = 32768;
  // pto: %c128_index
  const int64_t v81 = 128;
  // pto: %c24_index
  const int64_t v82 = 24;
  // pto: %c0_index
  const int64_t v83 = 0;
  // pto: %c32_index
  const int64_t v84 = 32;
  // pto: %c8_index
  const int64_t v85 = 8;
  // pto: %cst_49
  const float v86 = 0.0f;
  // pto: %cst_50
  const float v87 = 1.0f;
  // pto: %c256_index
  const int64_t v88 = 256;
  // pto: %c2_index
  const int64_t v89 = 2;
  // pto: %c4_index
  const int64_t v90 = 4;
  // pto: %cst_54
  const bfloat16_t v91 = 0.0f;
  // pto: %c96_index
  const int64_t v92 = 96;
  // pto: %c160_index
  const int64_t v93 = 160;
  // pto: %c384_index
  const int64_t v94 = 384;
  // pto: %cst_58
  const float v95 = 0.0441941731f;
  // pto: %c192_index
  const int64_t v96 = 192;
  const int32_t v97 = 0;
  // pto: %c320_index
  const int64_t v98 = 320;
  // pto: %c448_index
  const int64_t v99 = 448;
  // pto: %c3_index
  const int64_t v100 = 3;
  // pto: %cst_64
  const float v101 = 0.5f;
  // pto: %cst_65
  const float v102 = 2.0f;
  // pto: %c2_i32
  const int32_t v103 = 2;
  // pto: %c449_i32
  const int32_t v104 = 449;
  // pto: %c512_i32
  const int32_t v105 = 512;
  // pto: %c4096_index
  const int64_t v106 = 4096;
  // pto: %kv_transfer_inline5167__ssa_v0_view
  const int64_t v107 = 1;
  // pto: %kv_transfer_inline5167__ssa_v0_view
  const int64_t v108 = 1;
  // pto: %kv_transfer_inline5167__ssa_v0_view
  const int64_t v109 = 1;
  // pto: %kv_transfer_inline5167__ssa_v0_view
  int64_t v110 = v75 * v73;
  // pto: %kv_transfer_inline5167__ssa_v0_view
  int64_t v111 = v109 * v110;
  // pto: %kv_transfer_inline5167__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v112 = pto::Shape<1, 1, 1, -1, -1>(v107, v108, v109, v75, v73);
  // pto: %kv_transfer_inline5167__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v113 = pto::Stride<-1, -1, -1, -1, -1>(v108 * v111, v111, v110, v73, v72);
  // pto: %kv_transfer_inline5167__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v114 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v112, v113);
  // pto: %score_transfer_inline5311__ssa_v0_view
  const int64_t v115 = 1;
  // pto: %score_transfer_inline5311__ssa_v0_view
  const int64_t v116 = 1;
  // pto: %score_transfer_inline5311__ssa_v0_view
  const int64_t v117 = 1;
  // pto: %score_transfer_inline5311__ssa_v0_view
  int64_t v118 = v76 * v73;
  // pto: %score_transfer_inline5311__ssa_v0_view
  int64_t v119 = v117 * v118;
  // pto: %score_transfer_inline5311__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v120 = pto::Shape<1, 1, 1, -1, -1>(v115, v116, v117, v76, v73);
  // pto: %score_transfer_inline5311__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v121 = pto::Stride<-1, -1, -1, -1, -1>(v116 * v119, v119, v118, v73, v72);
  // pto: %score_transfer_inline5311__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v122 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v120, v121);
  // pto: %probability_transfer_inline5166__ssa_v0_view
  const int64_t v123 = 1;
  // pto: %probability_transfer_inline5166__ssa_v0_view
  const int64_t v124 = 1;
  // pto: %probability_transfer_inline5166__ssa_v0_view
  const int64_t v125 = 1;
  // pto: %probability_transfer_inline5166__ssa_v0_view
  int64_t v126 = v77 * v73;
  // pto: %probability_transfer_inline5166__ssa_v0_view
  int64_t v127 = v125 * v126;
  // pto: %probability_transfer_inline5166__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v128 = pto::Shape<1, 1, 1, -1, -1>(v123, v124, v125, v77, v73);
  // pto: %probability_transfer_inline5166__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v129 = pto::Stride<-1, -1, -1, -1, -1>(v124 * v127, v127, v126, v73, v72);
  // pto: %probability_transfer_inline5166__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v130 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v128, v129);
  // pto: %pv_transfer_inline5179__ssa_v0_view
  const int64_t v131 = 1;
  // pto: %pv_transfer_inline5179__ssa_v0_view
  const int64_t v132 = 1;
  // pto: %pv_transfer_inline5179__ssa_v0_view
  const int64_t v133 = 1;
  // pto: %pv_transfer_inline5179__ssa_v0_view
  int64_t v134 = v77 * v73;
  // pto: %pv_transfer_inline5179__ssa_v0_view
  int64_t v135 = v133 * v134;
  // pto: %pv_transfer_inline5179__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v136 = pto::Shape<1, 1, 1, -1, -1>(v131, v132, v133, v77, v73);
  // pto: %pv_transfer_inline5179__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v137 = pto::Stride<-1, -1, -1, -1, -1>(v132 * v135, v135, v134, v73, v72);
  // pto: %pv_transfer_inline5179__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v138 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v136, v137);
  // pto: %attn_sink_col_inline5285__ssa_v0_view
  const int64_t v139 = 1;
  // pto: %attn_sink_col_inline5285__ssa_v0_view
  const int64_t v140 = 1;
  // pto: %attn_sink_col_inline5285__ssa_v0_view
  const int64_t v141 = 1;
  // pto: %attn_sink_col_inline5285__ssa_v0_view
  int64_t v142 = v78 * v72;
  // pto: %attn_sink_col_inline5285__ssa_v0_view
  int64_t v143 = v141 * v142;
  // pto: %attn_sink_col_inline5285__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v144 = pto::Shape<1, 1, 1, -1, -1>(v139, v140, v141, v78, v72);
  // pto: %attn_sink_col_inline5285__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v145 = pto::Stride<-1, -1, -1, -1, -1>(v140 * v143, v143, v142, v72, v78);
  // pto: %attn_sink_col_inline5285__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v146 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v9, v144, v145);
  // pto: %mi_transfer_inline5223__ssa_v0_view
  const int64_t v147 = 1;
  // pto: %mi_transfer_inline5223__ssa_v0_view
  const int64_t v148 = 1;
  // pto: %mi_transfer_inline5223__ssa_v0_view
  const int64_t v149 = 1;
  // pto: %mi_transfer_inline5223__ssa_v0_view
  int64_t v150 = v77 * v72;
  // pto: %mi_transfer_inline5223__ssa_v0_view
  int64_t v151 = v149 * v150;
  // pto: %mi_transfer_inline5223__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v152 = pto::Shape<1, 1, 1, -1, -1>(v147, v148, v149, v77, v72);
  // pto: %mi_transfer_inline5223__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v153 = pto::Stride<-1, -1, -1, -1, -1>(v148 * v151, v151, v150, v72, v77);
  // pto: %mi_transfer_inline5223__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v154 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v10, v152, v153);
  // pto: %li_transfer_inline5199__ssa_v0_view
  const int64_t v155 = 1;
  // pto: %li_transfer_inline5199__ssa_v0_view
  const int64_t v156 = 1;
  // pto: %li_transfer_inline5199__ssa_v0_view
  const int64_t v157 = 1;
  // pto: %li_transfer_inline5199__ssa_v0_view
  int64_t v158 = v77 * v72;
  // pto: %li_transfer_inline5199__ssa_v0_view
  int64_t v159 = v157 * v158;
  // pto: %li_transfer_inline5199__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v160 = pto::Shape<1, 1, 1, -1, -1>(v155, v156, v157, v77, v72);
  // pto: %li_transfer_inline5199__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v161 = pto::Stride<-1, -1, -1, -1, -1>(v156 * v159, v159, v158, v72, v77);
  // pto: %li_transfer_inline5199__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v162 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v11, v160, v161);
  // pto: %558
  int64_t v163 = (int64_t) ((uint64_t) v30 * (uint64_t) v84);
  // pto: %ori_kv_flat_inline5269__ssa_v1_view
  const int64_t v164 = 1;
  // pto: %ori_kv_flat_inline5269__ssa_v1_view
  const int64_t v165 = 1;
  // pto: %ori_kv_flat_inline5269__ssa_v1_view
  const int64_t v166 = 1;
  // pto: %ori_kv_flat_inline5269__ssa_v1_view
  int64_t v167 = v163 * v73;
  // pto: %ori_kv_flat_inline5269__ssa_v1_view
  int64_t v168 = v166 * v167;
  // pto: %ori_kv_flat_inline5269__ssa_v1_view
  pto::Shape<1, 1, 1, -1, -1> v169 = pto::Shape<1, 1, 1, -1, -1>(v164, v165, v166, v163, v73);
  // pto: %ori_kv_flat_inline5269__ssa_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v170 = pto::Stride<-1, -1, -1, -1, -1>(v165 * v168, v168, v167, v73, v72);
  // pto: %ori_kv_flat_inline5269__ssa_v1_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v171 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v169, v170);
  // pto: %559
  int64_t v172 = (int64_t) ((uint64_t) v32 * (uint64_t) v84);
  // pto: %cmp_kv_flat_inline5175__ssa_v0_view
  const int64_t v173 = 1;
  // pto: %cmp_kv_flat_inline5175__ssa_v0_view
  const int64_t v174 = 1;
  // pto: %cmp_kv_flat_inline5175__ssa_v0_view
  const int64_t v175 = 1;
  // pto: %cmp_kv_flat_inline5175__ssa_v0_view
  int64_t v176 = v172 * v73;
  // pto: %cmp_kv_flat_inline5175__ssa_v0_view
  int64_t v177 = v175 * v176;
  // pto: %cmp_kv_flat_inline5175__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v178 = pto::Shape<1, 1, 1, -1, -1>(v173, v174, v175, v172, v73);
  // pto: %cmp_kv_flat_inline5175__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v179 = pto::Stride<-1, -1, -1, -1, -1>(v174 * v177, v177, v176, v73, v72);
  // pto: %cmp_kv_flat_inline5175__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v180 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v17, v178, v179);
  // pto: %sparse_bias_inline5240__rv_v2_view
  const int64_t v181 = 1;
  // pto: %sparse_bias_inline5240__rv_v2_view
  const int64_t v182 = 1;
  // pto: %sparse_bias_inline5240__rv_v2_view
  const int64_t v183 = 1;
  // pto: %sparse_bias_inline5240__rv_v2_view
  int64_t v184 = (int64_t) v27;
  // pto: %sparse_bias_inline5240__rv_v2_view
  int64_t v185 = v184 * v79;
  // pto: %sparse_bias_inline5240__rv_v2_view
  int64_t v186 = v183 * v185;
  // pto: %sparse_bias_inline5240__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v187 = pto::Shape<1, 1, 1, -1, -1>(v181, v182, v183, v184, v79);
  // pto: %sparse_bias_inline5240__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v188 = pto::Stride<-1, -1, -1, -1, -1>(v182 * v186, v186, v185, v79, v72);
  // pto: %sparse_bias_inline5240__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v189 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v18, v187, v188);
  // pto: %softmax_copy64_inline5292__ssa_v0_view
  const int64_t v190 = 1;
  // pto: %softmax_copy64_inline5292__ssa_v0_view
  const int64_t v191 = 1;
  // pto: %softmax_copy64_inline5292__ssa_v0_view
  const int64_t v192 = 1;
  // pto: %softmax_copy64_inline5292__ssa_v0_view
  int64_t v193 = v77 * v78;
  // pto: %softmax_copy64_inline5292__ssa_v0_view
  int64_t v194 = v192 * v193;
  // pto: %softmax_copy64_inline5292__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v195 = pto::Shape<1, 1, 1, -1, -1>(v190, v191, v192, v77, v78);
  // pto: %softmax_copy64_inline5292__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v196 = pto::Stride<-1, -1, -1, -1, -1>(v191 * v194, v194, v193, v78, v72);
  // pto: %softmax_copy64_inline5292__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v197 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v19, v195, v196);
  // pto: %alpha_transfer_inline5327__ssa_v0_view
  const int64_t v198 = 1;
  // pto: %alpha_transfer_inline5327__ssa_v0_view
  const int64_t v199 = 1;
  // pto: %alpha_transfer_inline5327__ssa_v0_view
  const int64_t v200 = 1;
  // pto: %alpha_transfer_inline5327__ssa_v0_view
  int64_t v201 = v77 * v72;
  // pto: %alpha_transfer_inline5327__ssa_v0_view
  int64_t v202 = v200 * v201;
  // pto: %alpha_transfer_inline5327__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v203 = pto::Shape<1, 1, 1, -1, -1>(v198, v199, v200, v77, v72);
  // pto: %alpha_transfer_inline5327__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v204 = pto::Stride<-1, -1, -1, -1, -1>(v199 * v202, v202, v201, v72, v77);
  // pto: %alpha_transfer_inline5327__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v205 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v20, v203, v204);
  // pto: %freqs_sin__ssa_v0_view
  const int64_t v206 = 1;
  // pto: %freqs_sin__ssa_v0_view
  const int64_t v207 = 1;
  // pto: %freqs_sin__ssa_v0_view
  const int64_t v208 = 1;
  // pto: %freqs_sin__ssa_v0_view
  int64_t v209 = (int64_t) v25;
  // pto: %freqs_sin__ssa_v0_view
  int64_t v210 = v209 * v78;
  // pto: %freqs_sin__ssa_v0_view
  int64_t v211 = v208 * v210;
  // pto: %freqs_sin__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v212 = pto::Shape<1, 1, 1, -1, -1>(v206, v207, v208, v209, v78);
  // pto: %freqs_sin__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v213 = pto::Stride<-1, -1, -1, -1, -1>(v207 * v211, v211, v210, v78, v72);
  // pto: %freqs_sin__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v214 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v21, v212, v213);
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v215 = 1;
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v216 = 1;
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v217 = 1;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v218 = (int64_t) v25;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v219 = v218 * v78;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v220 = v217 * v219;
  // pto: %freqs_cos__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v221 = pto::Shape<1, 1, 1, -1, -1>(v215, v216, v217, v218, v78);
  // pto: %freqs_cos__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v222 = pto::Stride<-1, -1, -1, -1, -1>(v216 * v220, v220, v219, v78, v72);
  // pto: %freqs_cos__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v223 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v22, v221, v222);
  // pto: %heads__ssa_v0_view
  const int64_t v224 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v225 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v226 = 1;
  // pto: %heads__ssa_v0_view
  int64_t v227 = (int64_t) v25;
  // pto: %heads__ssa_v0_view
  int64_t v228 = v227 * v80;
  // pto: %heads__ssa_v0_view
  int64_t v229 = v226 * v228;
  // pto: %heads__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v230 = pto::Shape<1, 1, 1, -1, -1>(v224, v225, v226, v227, v80);
  // pto: %heads__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v231 = pto::Stride<-1, -1, -1, -1, -1>(v225 * v229, v229, v228, v80, v72);
  // pto: %heads__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v232 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v23, v230, v231);
  // pto: %left_after_inline5353__rv_v0
  Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v233 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v88);
  // pto: %left_after_inline5353__rv_v0
  uint64_t v234 = (uint64_t) v40;
  TASSIGN(v233, v234);
  // pto: %right_after_inline5312__rv_v0
  Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v235 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v88);
  // pto: %right_after_inline5312__rv_v0
  uint64_t v236 = (uint64_t) v41;
  TASSIGN(v235, v236);
  // pto: %qk_kv_half_inline5362__phi_v22
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v237 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5362__phi_v22
  uint64_t v238 = (uint64_t) v38;
  TASSIGN(v237, v238);
  // pto: %qk_kv_half_inline5362__phi_v3
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v239 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5362__phi_v3
  uint64_t v240 = (uint64_t) v38;
  TASSIGN(v239, v240);
  // pto: %qk_kv_half_inline5362__phi_v2
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v241 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5362__phi_v2
  uint64_t v242 = (uint64_t) v38;
  TASSIGN(v241, v242);
  // pto: %qk_kv_half_inline5362__phi_v6
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v243 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5362__phi_v6
  uint64_t v244 = (uint64_t) v38;
  TASSIGN(v243, v244);
  // pto: %qk_kv_half_inline5362__phi_v5
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v245 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5362__phi_v5
  uint64_t v246 = (uint64_t) v38;
  TASSIGN(v245, v246);
  // pto: %qk_kv_half_inline5362__phi_v9
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v247 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5362__phi_v9
  uint64_t v248 = (uint64_t) v38;
  TASSIGN(v247, v248);
  // pto: %qk_kv_half_inline5362__phi_v8
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v249 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5362__phi_v8
  uint64_t v250 = (uint64_t) v38;
  TASSIGN(v249, v250);
  // pto: %qk_kv_half_inline5362__phi_v12
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v251 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5362__phi_v12
  uint64_t v252 = (uint64_t) v38;
  TASSIGN(v251, v252);
  // pto: %qk_kv_half_inline5362__phi_v11
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v253 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5362__phi_v11
  uint64_t v254 = (uint64_t) v38;
  TASSIGN(v253, v254);
  // pto: %qk_kv_half_inline5362__phi_v15
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v255 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5362__phi_v15
  uint64_t v256 = (uint64_t) v38;
  TASSIGN(v255, v256);
  // pto: %qk_kv_half_inline5362__phi_v14
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v257 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5362__phi_v14
  uint64_t v258 = (uint64_t) v38;
  TASSIGN(v257, v258);
  // pto: %qk_kv_half_inline5362__phi_v21
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v259 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5362__phi_v21
  uint64_t v260 = (uint64_t) v38;
  TASSIGN(v259, v260);
  // pto: %qk_kv_half_inline5362__phi_v20
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v261 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5362__phi_v20
  uint64_t v262 = (uint64_t) v38;
  TASSIGN(v261, v262);
  // pto: %qk_kv_half_inline5362__phi_v19
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v263 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5362__phi_v19
  uint64_t v264 = (uint64_t) v38;
  TASSIGN(v263, v264);
  // pto: %prefetch_kv_half_inline5261__phi_v21
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v265 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_inline5261__phi_v21
  uint64_t v266 = (uint64_t) v38;
  TASSIGN(v265, v266);
  // pto: %prefetch_kv_half_inline5261__phi_v20
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v267 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_inline5261__phi_v20
  uint64_t v268 = (uint64_t) v38;
  TASSIGN(v267, v268);
  // pto: %prefetch_kv_half_inline5261__phi_v19
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v269 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_inline5261__phi_v19
  uint64_t v270 = (uint64_t) v38;
  TASSIGN(v269, v270);
  // pto: %sm_scores_inline5252__phi_v2
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v271 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
  // pto: %sm_scores_inline5252__phi_v2
  uint64_t v272 = (uint64_t) v38;
  TASSIGN(v271, v272);
  // pto: %sm_block_sum_inline5430__phi_v4
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v273 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
  // pto: %sm_block_sum_inline5430__phi_v4
  uint64_t v274 = (uint64_t) v48;
  TASSIGN(v273, v274);
  // pto: %sm_block_sum_inline5430__phi_v3
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v275 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
  // pto: %sm_block_sum_inline5430__phi_v3
  uint64_t v276 = (uint64_t) v48;
  TASSIGN(v275, v276);
  // pto: %sm_fold64_inline5376__phi_v4
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v277 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5376__phi_v4
  uint64_t v278 = (uint64_t) v52;
  TASSIGN(v277, v278);
  // pto: %sm_fold64_inline5376__phi_v3
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v279 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5376__phi_v3
  uint64_t v280 = (uint64_t) v52;
  TASSIGN(v279, v280);
  // pto: %sm_fold64_inline5376__phi_v8
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v281 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5376__phi_v8
  uint64_t v282 = (uint64_t) v49;
  TASSIGN(v281, v282);
  // pto: %sm_fold64_inline5376__phi_v7
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v283 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5376__phi_v7
  uint64_t v284 = (uint64_t) v49;
  TASSIGN(v283, v284);
  // pto: %sm_fold64_inline5376__phi_v12
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v285 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5376__phi_v12
  uint64_t v286 = (uint64_t) v52;
  TASSIGN(v285, v286);
  // pto: %sm_fold64_inline5376__phi_v11
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v287 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5376__phi_v11
  uint64_t v288 = (uint64_t) v52;
  TASSIGN(v287, v288);
  // pto: %sm_fold64_inline5376__phi_v16
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v289 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5376__phi_v16
  uint64_t v290 = (uint64_t) v49;
  TASSIGN(v289, v290);
  // pto: %sm_fold64_inline5376__phi_v15
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v291 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5376__phi_v15
  uint64_t v292 = (uint64_t) v49;
  TASSIGN(v291, v292);
  // pto: %sm_fold64_inline5376__phi_v20
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v293 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5376__phi_v20
  uint64_t v294 = (uint64_t) v52;
  TASSIGN(v293, v294);
  // pto: %sm_fold64_inline5376__phi_v19
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v295 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5376__phi_v19
  uint64_t v296 = (uint64_t) v52;
  TASSIGN(v295, v296);
  // pto: %sm_fold64_inline5376__phi_v24
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v297 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5376__phi_v24
  uint64_t v298 = (uint64_t) v49;
  TASSIGN(v297, v298);
  // pto: %sm_fold64_inline5376__phi_v23
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v299 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5376__phi_v23
  uint64_t v300 = (uint64_t) v49;
  TASSIGN(v299, v300);
  // pto: %sm_fold64_inline5376__phi_v28
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v301 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5376__phi_v28
  uint64_t v302 = (uint64_t) v43;
  TASSIGN(v301, v302);
  // pto: %prefetch_kv_half_v1_inline5426__phi_v3
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v303 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_v1_inline5426__phi_v3
  uint64_t v304 = (uint64_t) v38;
  TASSIGN(v303, v304);
  // pto: %prefetch_kv_half_v1_inline5426__phi_v2
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v305 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_v1_inline5426__phi_v2
  uint64_t v306 = (uint64_t) v38;
  TASSIGN(v305, v306);
  // pto: %prefetch_kv_half_v1_inline5426__phi_v6
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v307 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_v1_inline5426__phi_v6
  uint64_t v308 = (uint64_t) v38;
  TASSIGN(v307, v308);
  // pto: %prefetch_kv_half_v1_inline5426__phi_v5
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_v1_inline5426__phi_v5
  uint64_t v310 = (uint64_t) v38;
  TASSIGN(v309, v310);
  // pto: %prefetch_kv_half_v1_inline5426__phi_v9
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v311 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_v1_inline5426__phi_v9
  uint64_t v312 = (uint64_t) v38;
  TASSIGN(v311, v312);
  // pto: %prefetch_kv_half_v1_inline5426__phi_v8
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_v1_inline5426__phi_v8
  uint64_t v314 = (uint64_t) v38;
  TASSIGN(v313, v314);
  // pto: %prefetch_kv_half_v1_inline5426__phi_v12
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_v1_inline5426__phi_v12
  uint64_t v316 = (uint64_t) v38;
  TASSIGN(v315, v316);
  // pto: %prefetch_kv_half_v1_inline5426__phi_v11
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v317 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_v1_inline5426__phi_v11
  uint64_t v318 = (uint64_t) v38;
  TASSIGN(v317, v318);
  // pto: %prefetch_kv_half_v1_inline5426__phi_v15
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v319 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_v1_inline5426__phi_v15
  uint64_t v320 = (uint64_t) v38;
  TASSIGN(v319, v320);
  // pto: %prefetch_kv_half_v1_inline5426__phi_v14
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v321 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_v1_inline5426__phi_v14
  uint64_t v322 = (uint64_t) v38;
  TASSIGN(v321, v322);
  // pto: %qk_core_inline5266__ssa_v0
  int64_t v323 = (int64_t) v33;
  uint64_t v324 = reinterpret_cast<uint64_t>(v1);
  set_ffts_base_addr(v324);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v325 = v323; v325 < v24; v325 += v82) {
    // pto: %t__tile
    ;
    int32_t v326 = (v2)[v325];
    // pto: %3
    ;
    int64_t v327 = (int64_t) v326;
    // pto: %4
    ;
    int64_t v328 = v327 < v83 ? v83 : v327;
    // pto: %qk_aiv_inline5260__ssa_v0
    ;
    int64_t v329 = (int64_t) v35;
    uint64_t v330 = reinterpret_cast<uint64_t>(v1);
    set_ffts_base_addr(v330);
    // pto: %14
    ;
    int64_t v331 = (int64_t) ((uint64_t) v329 * (uint64_t) v84);
    // pto: %15
    ;
    int64_t v332 = (int64_t) ((uint64_t) v329 * (uint64_t) v78);
    // pto: %qk_reduce_tmp_inline5200__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v333 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
    // pto: %qk_reduce_tmp_inline5200__ssa_v0
    ;
    uint64_t v334 = (uint64_t) v37;
    TASSIGN(v333, v334);
    // pto: %running_m_inline5290__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v335 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v72);
    // pto: %running_m_inline5290__ssa_v0
    ;
    uint64_t v336 = (uint64_t) v38;
    TASSIGN(v335, v336);
    // pto: %16
    ;
    int64_t v337 = v331 < v83 ? v83 : v331;
    // pto: %attn_sink_col_inline5285__ssa_v0_pview
    ;
    __gm__ float* v338 = PTOAS__GLOBAL_TENSOR_DATA(v146);
    // pto: %attn_sink_col_inline5285__ssa_v0_pview
    ;
    const int64_t v339 = 0;
    // pto: %attn_sink_col_inline5285__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 32, 1> v340 = pto::Shape<1, 1, 1, 32, 1>();
    // pto: %attn_sink_col_inline5285__ssa_v0_pview
    ;
    pto::Stride<32, 32, 32, 1, 64> v341 = pto::Stride<32, 32, 32, 1, 64>();
    // pto: %attn_sink_col_inline5285__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 64>, pto::Layout::DN> v342 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 64>, pto::Layout::DN>(v338 + (v339 + v337), v340, v341);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    TLOAD(v335, v342);
    set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %t__rm_a0_tmp_v0
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v343 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v84);
    // pto: %t__rm_a0_tmp_v0
    ;
    uint64_t v344 = (uint64_t) v38;
    TASSIGN(v343, v344);
    // pto: %t__row_major_tmp_v1
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v345 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v84);
    // pto: %t__row_major_tmp_v1
    ;
    uint64_t v346 = (uint64_t) v39;
    TASSIGN(v345, v346);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    TMULS(v345, v343, v86);
    // pto: %t__tmp_v939
    ;
    Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v347 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v72);
    // pto: %t__tmp_v939
    ;
    uint64_t v348 = (uint64_t) v39;
    TASSIGN(v347, v348);
    // pto: %running_l_inline5205__rm_a0_tmp_v2
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v349 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v84);
    // pto: %running_l_inline5205__rm_a0_tmp_v2
    ;
    uint64_t v350 = (uint64_t) v39;
    TASSIGN(v349, v350);
    // pto: %running_l_inline5205__row_major_tmp_v3
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v351 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v84);
    // pto: %running_l_inline5205__row_major_tmp_v3
    ;
    uint64_t v352 = (uint64_t) v39;
    TASSIGN(v351, v352);
    pipe_barrier(PIPE_V);
    TADDS(v351, v349, v87);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %running_l_inline5205__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v353 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v72);
    // pto: %running_l_inline5205__ssa_v0
    ;
    uint64_t v354 = (uint64_t) v39;
    TASSIGN(v353, v354);
    // pto: %running_left_inline5415__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v355 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v88);
    // pto: %running_left_inline5415__ssa_v0
    ;
    uint64_t v356 = (uint64_t) v40;
    TASSIGN(v355, v356);
    TEXPANDS(v355, v86);
    // pto: %running_right_inline5344__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v357 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v88);
    // pto: %running_right_inline5344__ssa_v0
    ;
    uint64_t v358 = (uint64_t) v41;
    TASSIGN(v357, v358);
    TEXPANDS(v357, v86);
    // pto: %1, %17
    ;
    int64_t v359 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v323 * (uint64_t) v78) + (uint64_t) v331);
    // pto: %18
    ;
    int64_t v360 = v359 < v83 ? v83 : v359;
    // pto: %mi_transfer_inline5223__ssa_v0_pview
    ;
    __gm__ float* v361 = PTOAS__GLOBAL_TENSOR_DATA(v154);
    // pto: %mi_transfer_inline5223__ssa_v0_pview
    ;
    const int64_t v362 = 0;
    // pto: %mi_transfer_inline5223__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 32, 1> v363 = pto::Shape<1, 1, 1, 32, 1>();
    // pto: %mi_transfer_inline5223__ssa_v0_pview
    ;
    pto::Stride<32, 32, 32, 1, 1536> v364 = pto::Stride<32, 32, 32, 1, 1536>();
    // pto: %mi_transfer_inline5223__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN> v365 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN>(v361 + (v362 + v360), v363, v364);
    wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    TSTORE(v365, v335);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    // pto: %li_transfer_inline5199__ssa_v0_pview
    ;
    __gm__ float* v366 = PTOAS__GLOBAL_TENSOR_DATA(v162);
    // pto: %li_transfer_inline5199__ssa_v0_pview
    ;
    const int64_t v367 = 0;
    // pto: %li_transfer_inline5199__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 32, 1> v368 = pto::Shape<1, 1, 1, 32, 1>();
    // pto: %li_transfer_inline5199__ssa_v0_pview
    ;
    pto::Stride<32, 32, 32, 1, 1536> v369 = pto::Stride<32, 32, 32, 1, 1536>();
    // pto: %li_transfer_inline5199__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN> v370 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN>(v366 + (v367 + v360), v368, v369);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v370, v353);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    for (int64_t v371 = v83; v371 < v89; v371 += v72) {
      // pto: %22
      ;
      int64_t v372 = (int64_t) ((uint64_t) v325 * (uint64_t) v74);
      // pto: %23, %21
      ;
      int32_t v373 = (v4)[(int64_t) ((uint64_t) v372 + (uint64_t) v371)];
      // pto: %24, %25
      ;
      if ((int64_t) v373 > v83) {
        // pto: %26, %27, %28, %29
        ;
        int64_t v374 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) ((uint64_t) v325 - (uint64_t) v323) / v82) * (uint64_t) v89) + (uint64_t) v371);
        // pto: %30
        ;
        int64_t v375 = (int64_t) ((uint64_t) v323 * (uint64_t) v89);
        // pto: %31
        ;
        int64_t v376 = v374 % v89;
        // pto: %32, %33, %34
        ;
        int64_t v377 = v376 < v83 ? (int64_t) ((uint64_t) v376 + (uint64_t) v89) : v376;
        // pto: %38
        ;
        bool v378 = v371 > v83;
        // pto: %previous_valid_inline5360__phi_v4
        ;
        int32_t v379;
        if (v378) {
          // pto: %41, %39, %previous_valid_inline5360__tile
          ;
          int32_t v380 = (v4)[(int64_t) ((uint64_t) v372 + (uint64_t) ((int64_t) (uint64_t) v371 - (uint64_t) v72))];
          v379 = v380;
        } else {
          // pto: %42, %43
          ;
          // pto: %previous_valid_inline5360__phi_v3
          ;
          int32_t v381;
          if ((int64_t) ((uint64_t) v323 + (uint64_t) v82) <= v325) {
            // pto: %45, %46, %47, %44
            ;
            int32_t v382 = (v4)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v325 - (uint64_t) v82) * (uint64_t) v74) + (uint64_t) v72)];
            v381 = v382;
          } else {
            v381 = v97;
          };
          v379 = v381;
        };
        // pto: %48
        ;
        int64_t v383 = (int64_t) v379;
        // pto: %49
        ;
        if (v383 <= v83) {
          set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
          for (int64_t v384 = v83; v384 < v90; v384 += v72) {
            // pto: %51, %52
            ;
            if (v378 | v384 == v83) {
              // pto: %53, %54
              ;
              int64_t v385 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v384 * (uint64_t) v81) + (uint64_t) v332);
              // pto: %0
              ;
              Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v386 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
              // pto: %0
              ;
              uint64_t v387 = (uint64_t) v38;
              TASSIGN(v386, v387);
              wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
              pipe_barrier(PIPE_V);
              TEXPANDS(v386, v91);
              set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
              set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
              set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
              set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
              set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
              set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
              // pto: %55
              ;
              wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
              wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
              wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
              wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
              wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
              if (v371 == v83) {
                // pto: %56
                ;
                int64_t v388 = (v12)[v325];
                // pto: %60
                ;
                int64_t v389 = (int64_t) ((uint64_t) v388 + (uint64_t) v72);
                // pto: %61
                ;
                int64_t v390 = v389 < v81 ? v389 : v81;
                // pto: %62, %63
                ;
                int64_t v391 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v388 - (uint64_t) v390) + (uint64_t) v72);
                // pto: %64
                ;
                int64_t v392 = v391 % v84;
                // pto: %65, %66, %67
                ;
                int64_t v393 = v392 < v83 ? (int64_t) ((uint64_t) v392 + (uint64_t) v84) : v392;
                // pto: %68
                ;
                int64_t v394 = (int64_t) ((uint64_t) v390 - (uint64_t) v385);
                // pto: %69
                ;
                int64_t v395 = v394 < v83 ? v83 : v394;
                // pto: %70
                ;
                int64_t v396 = v395 < v78 ? v395 : v78;
                // pto: %71, %72
                ;
                int64_t v397 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v84 - (uint64_t) v393) - (uint64_t) v385);
                // pto: %73
                ;
                int64_t v398 = v397 < v396 ? v397 : v396;
                // pto: %74
                ;
                if (v398 > v83) {
                  // pto: %75
                  ;
                  int64_t v399 = (int64_t) ((uint64_t) v391 + (uint64_t) v385);
                  // pto: %78, %79, %77, %qk_raw_page_inline5274__tile
                  ;
                  int32_t v400 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v328 * (uint64_t) v29) + (uint64_t) (v399 / v84))];
                  // pto: %80
                  ;
                  int64_t v401 = (int64_t) v400;
                  // pto: %81
                  ;
                  if (v401 >= v83) {
                    // pto: %84
                    ;
                    int64_t v402 = v399 % v84;
                    // pto: %85, %86, %87
                    ;
                    int64_t v403 = v402 < v83 ? (int64_t) ((uint64_t) v402 + (uint64_t) v84) : v402;
                    // pto: %83, %88
                    ;
                    int64_t v404 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v401 * (uint64_t) v84) + (uint64_t) v403);
                    // pto: %gather_row_view
                    ;
                    Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v405 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v398);
                    // pto: %gather_row_view
                    ;
                    uint64_t v406 = (uint64_t) v38;
                    TASSIGN(v405, v406);
                    // pto: %90
                    ;
                    int64_t v407 = v404 < v83 ? v83 : v404;
                    // pto: %ori_kv_flat_inline5269__ssa_v1_pview
                    ;
                    const int64_t v408 = 0;
                    // pto: %ori_kv_flat_inline5269__ssa_v1_pview
                    ;
                    __gm__ bfloat16_t* v409 = PTOAS__GLOBAL_TENSOR_DATA(v171);
                    // pto: %ori_kv_flat_inline5269__ssa_v1_pview
                    ;
                    const int64_t v410 = 1;
                    // pto: %ori_kv_flat_inline5269__ssa_v1_pview
                    ;
                    const int64_t v411 = 1;
                    // pto: %ori_kv_flat_inline5269__ssa_v1_pview
                    ;
                    const int64_t v412 = 1;
                    // pto: %ori_kv_flat_inline5269__ssa_v1_pview
                    ;
                    int64_t v413 = v398 * v73;
                    // pto: %ori_kv_flat_inline5269__ssa_v1_pview
                    ;
                    int64_t v414 = v412 * v413;
                    // pto: %ori_kv_flat_inline5269__ssa_v1_pview
                    ;
                    pto::Shape<1, 1, 1, -1, 512> v415 = pto::Shape<1, 1, 1, -1, 512>(v410, v411, v412, v398, v73);
                    // pto: %ori_kv_flat_inline5269__ssa_v1_pview
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v416 = pto::Stride<-1, -1, -1, -1, -1>(v411 * v414, v414, v413, v73, v72);
                    // pto: %ori_kv_flat_inline5269__ssa_v1_pview
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v417 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v409 + (v408 + v407 * v73 + v83 * v72), v415, v416);
                    TLOAD(v405, v417);
                  };
                };
                // pto: %93
                ;
                int64_t v418 = v397 < v83 ? v83 : v397;
                // pto: %94, %95
                ;
                int64_t v419 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v78 - (uint64_t) v393) - (uint64_t) v385);
                // pto: %96
                ;
                int64_t v420 = v419 < v396 ? v419 : v396;
                // pto: %97
                ;
                if (v418 < v420) {
                  // pto: %98, %99
                  ;
                  int64_t v421 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v391 + (uint64_t) v385) + (uint64_t) v418);
                  // pto: %102, %103, %101, %100
                  ;
                  int32_t v422 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v328 * (uint64_t) v29) + (uint64_t) (v421 / v84))];
                  // pto: %104
                  ;
                  int64_t v423 = (int64_t) v422;
                  // pto: %105
                  ;
                  if (v423 >= v83) {
                    // pto: %108
                    ;
                    int64_t v424 = v421 % v84;
                    // pto: %109, %110, %111
                    ;
                    int64_t v425 = v424 < v83 ? (int64_t) ((uint64_t) v424 + (uint64_t) v84) : v424;
                    // pto: %107, %112
                    ;
                    int64_t v426 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v423 * (uint64_t) v84) + (uint64_t) v425);
                    // pto: %113
                    ;
                    int64_t v427 = (int64_t) ((uint64_t) v420 - (uint64_t) v418);
                    // pto: %114
                    ;
                    Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v428 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v427);
                    // pto: %114
                    ;
                    uint64_t v429 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v418 * (uint64_t) v36) + (uint64_t) v38);
                    TASSIGN(v428, v429);
                    // pto: %115
                    ;
                    int64_t v430 = v426 < v83 ? v83 : v426;
                    // pto: %116
                    ;
                    const int64_t v431 = 0;
                    // pto: %116
                    ;
                    __gm__ bfloat16_t* v432 = PTOAS__GLOBAL_TENSOR_DATA(v171);
                    // pto: %116
                    ;
                    const int64_t v433 = 1;
                    // pto: %116
                    ;
                    const int64_t v434 = 1;
                    // pto: %116
                    ;
                    const int64_t v435 = 1;
                    // pto: %116
                    ;
                    int64_t v436 = v427 * v73;
                    // pto: %116
                    ;
                    int64_t v437 = v435 * v436;
                    // pto: %116
                    ;
                    pto::Shape<1, 1, 1, -1, 512> v438 = pto::Shape<1, 1, 1, -1, 512>(v433, v434, v435, v427, v73);
                    // pto: %116
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v439 = pto::Stride<-1, -1, -1, -1, -1>(v434 * v437, v437, v436, v73, v72);
                    // pto: %116
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v440 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v432 + (v431 + v430 * v73 + v83 * v72), v438, v439);
                    TLOAD(v428, v440);
                  };
                };
                // pto: %119
                ;
                int64_t v441 = v419 < v83 ? v83 : v419;
                // pto: %120, %121
                ;
                int64_t v442 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v92 - (uint64_t) v393) - (uint64_t) v385);
                // pto: %122
                ;
                int64_t v443 = v442 < v396 ? v442 : v396;
                // pto: %123
                ;
                if (v441 < v443) {
                  // pto: %124, %125
                  ;
                  int64_t v444 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v391 + (uint64_t) v385) + (uint64_t) v441);
                  // pto: %128, %129, %127, %126
                  ;
                  int32_t v445 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v328 * (uint64_t) v29) + (uint64_t) (v444 / v84))];
                  // pto: %130
                  ;
                  int64_t v446 = (int64_t) v445;
                  // pto: %131
                  ;
                  if (v446 >= v83) {
                    // pto: %134
                    ;
                    int64_t v447 = v444 % v84;
                    // pto: %135, %136, %137
                    ;
                    int64_t v448 = v447 < v83 ? (int64_t) ((uint64_t) v447 + (uint64_t) v84) : v447;
                    // pto: %133, %138
                    ;
                    int64_t v449 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v446 * (uint64_t) v84) + (uint64_t) v448);
                    // pto: %139
                    ;
                    int64_t v450 = (int64_t) ((uint64_t) v443 - (uint64_t) v441);
                    // pto: %140
                    ;
                    Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v451 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v450);
                    // pto: %140
                    ;
                    uint64_t v452 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v441 * (uint64_t) v36) + (uint64_t) v38);
                    TASSIGN(v451, v452);
                    // pto: %141
                    ;
                    int64_t v453 = v449 < v83 ? v83 : v449;
                    // pto: %142
                    ;
                    const int64_t v454 = 0;
                    // pto: %142
                    ;
                    __gm__ bfloat16_t* v455 = PTOAS__GLOBAL_TENSOR_DATA(v171);
                    // pto: %142
                    ;
                    const int64_t v456 = 1;
                    // pto: %142
                    ;
                    const int64_t v457 = 1;
                    // pto: %142
                    ;
                    const int64_t v458 = 1;
                    // pto: %142
                    ;
                    int64_t v459 = v450 * v73;
                    // pto: %142
                    ;
                    int64_t v460 = v458 * v459;
                    // pto: %142
                    ;
                    pto::Shape<1, 1, 1, -1, 512> v461 = pto::Shape<1, 1, 1, -1, 512>(v456, v457, v458, v450, v73);
                    // pto: %142
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v462 = pto::Stride<-1, -1, -1, -1, -1>(v457 * v460, v460, v459, v73, v72);
                    // pto: %142
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v463 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v455 + (v454 + v453 * v73 + v83 * v72), v461, v462);
                    TLOAD(v451, v463);
                  };
                };
                // pto: %145
                ;
                int64_t v464 = v442 < v83 ? v83 : v442;
                // pto: %146, %147
                ;
                int64_t v465 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v81 - (uint64_t) v393) - (uint64_t) v385);
                // pto: %148
                ;
                int64_t v466 = v465 < v396 ? v465 : v396;
                // pto: %149
                ;
                if (v464 < v466) {
                  // pto: %150, %151
                  ;
                  int64_t v467 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v391 + (uint64_t) v385) + (uint64_t) v464);
                  // pto: %154, %155, %153, %152
                  ;
                  int32_t v468 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v328 * (uint64_t) v29) + (uint64_t) (v467 / v84))];
                  // pto: %156
                  ;
                  int64_t v469 = (int64_t) v468;
                  // pto: %157
                  ;
                  if (v469 >= v83) {
                    // pto: %160
                    ;
                    int64_t v470 = v467 % v84;
                    // pto: %161, %162, %163
                    ;
                    int64_t v471 = v470 < v83 ? (int64_t) ((uint64_t) v470 + (uint64_t) v84) : v470;
                    // pto: %159, %164
                    ;
                    int64_t v472 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v469 * (uint64_t) v84) + (uint64_t) v471);
                    // pto: %165
                    ;
                    int64_t v473 = (int64_t) ((uint64_t) v466 - (uint64_t) v464);
                    // pto: %166
                    ;
                    Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v474 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v473);
                    // pto: %166
                    ;
                    uint64_t v475 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v464 * (uint64_t) v36) + (uint64_t) v38);
                    TASSIGN(v474, v475);
                    // pto: %167
                    ;
                    int64_t v476 = v472 < v83 ? v83 : v472;
                    // pto: %168
                    ;
                    const int64_t v477 = 0;
                    // pto: %168
                    ;
                    __gm__ bfloat16_t* v478 = PTOAS__GLOBAL_TENSOR_DATA(v171);
                    // pto: %168
                    ;
                    const int64_t v479 = 1;
                    // pto: %168
                    ;
                    const int64_t v480 = 1;
                    // pto: %168
                    ;
                    const int64_t v481 = 1;
                    // pto: %168
                    ;
                    int64_t v482 = v473 * v73;
                    // pto: %168
                    ;
                    int64_t v483 = v481 * v482;
                    // pto: %168
                    ;
                    pto::Shape<1, 1, 1, -1, 512> v484 = pto::Shape<1, 1, 1, -1, 512>(v479, v480, v481, v473, v73);
                    // pto: %168
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v485 = pto::Stride<-1, -1, -1, -1, -1>(v480 * v483, v483, v482, v73, v72);
                    // pto: %168
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v486 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v478 + (v477 + v476 * v73 + v83 * v72), v484, v485);
                    TLOAD(v474, v486);
                  };
                };
                // pto: %171
                ;
                int64_t v487 = v465 < v83 ? v83 : v465;
                // pto: %172, %173
                ;
                int64_t v488 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v93 - (uint64_t) v393) - (uint64_t) v385);
                // pto: %174
                ;
                int64_t v489 = v488 < v396 ? v488 : v396;
                // pto: %175
                ;
                if (v487 < v489) {
                  // pto: %176, %177
                  ;
                  int64_t v490 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v391 + (uint64_t) v385) + (uint64_t) v487);
                  // pto: %180, %181, %179, %178
                  ;
                  int32_t v491 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v328 * (uint64_t) v29) + (uint64_t) (v490 / v84))];
                  // pto: %182
                  ;
                  int64_t v492 = (int64_t) v491;
                  // pto: %183
                  ;
                  if (v492 >= v83) {
                    // pto: %186
                    ;
                    int64_t v493 = v490 % v84;
                    // pto: %187, %188, %189
                    ;
                    int64_t v494 = v493 < v83 ? (int64_t) ((uint64_t) v493 + (uint64_t) v84) : v493;
                    // pto: %185, %190
                    ;
                    int64_t v495 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v492 * (uint64_t) v84) + (uint64_t) v494);
                    // pto: %191
                    ;
                    int64_t v496 = (int64_t) ((uint64_t) v489 - (uint64_t) v487);
                    // pto: %192
                    ;
                    Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v497 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v496);
                    // pto: %192
                    ;
                    uint64_t v498 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v487 * (uint64_t) v36) + (uint64_t) v38);
                    TASSIGN(v497, v498);
                    // pto: %193
                    ;
                    int64_t v499 = v495 < v83 ? v83 : v495;
                    // pto: %194
                    ;
                    const int64_t v500 = 0;
                    // pto: %194
                    ;
                    __gm__ bfloat16_t* v501 = PTOAS__GLOBAL_TENSOR_DATA(v171);
                    // pto: %194
                    ;
                    const int64_t v502 = 1;
                    // pto: %194
                    ;
                    const int64_t v503 = 1;
                    // pto: %194
                    ;
                    const int64_t v504 = 1;
                    // pto: %194
                    ;
                    int64_t v505 = v496 * v73;
                    // pto: %194
                    ;
                    int64_t v506 = v504 * v505;
                    // pto: %194
                    ;
                    pto::Shape<1, 1, 1, -1, 512> v507 = pto::Shape<1, 1, 1, -1, 512>(v502, v503, v504, v496, v73);
                    // pto: %194
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v508 = pto::Stride<-1, -1, -1, -1, -1>(v503 * v506, v506, v505, v73, v72);
                    // pto: %194
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v509 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v501 + (v500 + v499 * v73 + v83 * v72), v507, v508);
                    TLOAD(v497, v509);
                  };
                };
              } else {
                pipe_barrier(PIPE_V);
                TEXPANDS(v386, v91);
                set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
                wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
                for (int64_t v510 = v83; v510 < v78; v510 += v72) {
                  // pto: %195, %196, %197, %198
                  ;
                  int64_t v511 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v371 - (uint64_t) v72) * (uint64_t) v73) + (uint64_t) v385) + (uint64_t) v510);
                  // pto: %199
                  ;
                  if (v511 < v73) {
                    // pto: %200, %201, %qk_ridx_inline5303__tile
                    ;
                    int32_t v512 = (v15)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v325 * (uint64_t) v73) + (uint64_t) v511)];
                    // pto: %202
                    ;
                    int64_t v513 = (int64_t) v512;
                    // pto: %203
                    ;
                    if (v513 >= v83) {
                      // pto: %207, %208, %206, %204
                      ;
                      int32_t v514 = (v16)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v328 * (uint64_t) v31) + (uint64_t) (v513 / v84))];
                      // pto: %209
                      ;
                      int64_t v515 = (int64_t) v514;
                      // pto: %210
                      ;
                      if (v515 >= v83) {
                        // pto: %213
                        ;
                        int64_t v516 = v513 % v84;
                        // pto: %214, %215, %216
                        ;
                        int64_t v517 = v516 < v83 ? (int64_t) ((uint64_t) v516 + (uint64_t) v84) : v516;
                        // pto: %211, %217
                        ;
                        int64_t v518 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v515 * (uint64_t) v84) + (uint64_t) v517);
                        // pto: %218
                        ;
                        Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v519;
                        // pto: %218
                        ;
                        uint64_t v520 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v510 * (uint64_t) v36) + (uint64_t) v38);
                        TASSIGN(v519, v520);
                        // pto: %219
                        ;
                        int64_t v521 = v518 < v83 ? v83 : v518;
                        // pto: %cmp_kv_flat_inline5175__ssa_v0_pview
                        ;
                        __gm__ bfloat16_t* v522 = PTOAS__GLOBAL_TENSOR_DATA(v180);
                        // pto: %cmp_kv_flat_inline5175__ssa_v0_pview
                        ;
                        const int64_t v523 = 0;
                        // pto: %cmp_kv_flat_inline5175__ssa_v0_pview
                        ;
                        const int64_t v524 = 512;
                        // pto: %cmp_kv_flat_inline5175__ssa_v0_pview
                        ;
                        pto::Shape<1, 1, 1, 1, 512> v525 = pto::Shape<1, 1, 1, 1, 512>();
                        // pto: %cmp_kv_flat_inline5175__ssa_v0_pview
                        ;
                        pto::Stride<512, 512, 512, 512, 1> v526 = pto::Stride<512, 512, 512, 512, 1>();
                        // pto: %cmp_kv_flat_inline5175__ssa_v0_pview
                        ;
                        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v527 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v522 + (v523 + v521 * v524), v525, v526);
                        TLOAD(v519, v527);
                      };
                    };
                  };
                };
              };
              set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID5);
              set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID4);
              set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID3);
              set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
              set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
              set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
              set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID6);
              // pto: %35, %36, %220
              ;
              int64_t v528 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v375 + (uint64_t) v377) * (uint64_t) v73) + (uint64_t) v385);
              // pto: %221
              ;
              int64_t v529 = v528 < v83 ? v83 : v528;
              // pto: %kv_transfer_inline5167__ssa_v0_pview
              ;
              __gm__ bfloat16_t* v530 = PTOAS__GLOBAL_TENSOR_DATA(v114);
              // pto: %kv_transfer_inline5167__ssa_v0_pview
              ;
              const int64_t v531 = 0;
              // pto: %kv_transfer_inline5167__ssa_v0_pview
              ;
              const int64_t v532 = 512;
              // pto: %kv_transfer_inline5167__ssa_v0_pview
              ;
              pto::Shape<1, 1, 1, 64, 512> v533 = pto::Shape<1, 1, 1, 64, 512>();
              // pto: %kv_transfer_inline5167__ssa_v0_pview
              ;
              pto::Stride<32768, 32768, 32768, 512, 1> v534 = pto::Stride<32768, 32768, 32768, 512, 1>();
              // pto: %kv_transfer_inline5167__ssa_v0_pview
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v535 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v530 + (v531 + v529 * v532), v533, v534);
              wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
              wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
              wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID3);
              wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID4);
              wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID5);
              wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID6);
              wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
              wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
              TSTORE(v535, v237);
              set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
            };
          };
          wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
          uint16_t v536 = getFFTSMsg(FFTS_MODE_VAL, v83);
          ffts_cross_core_sync(PIPE_MTE3, v536);
        };
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
        int32_t v537 = (int32_t) v72;
        wait_flag_dev(v537);
        // pto: %222
        ;
        bool v538 = v371 == v83;
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
        if (v538) {
          // pto: %223
          ;
          int64_t v539 = (int64_t) ((uint64_t) v371 + (uint64_t) v72);
          // pto: %224
          ;
          if (v325 < v24) {
            // pto: %227, %225
            ;
            int32_t v540 = (v4)[(int64_t) ((uint64_t) v372 + (uint64_t) v539)];
            // pto: %228, %229
            ;
            if ((int64_t) v540 > v83) {
              // pto: %230
              ;
              int32_t v541 = (v2)[v325];
              // pto: %231
              ;
              int64_t v542 = (int64_t) v541;
              // pto: %232
              ;
              int64_t v543 = v542 < v83 ? v83 : v542;
              // pto: %234, %235
              ;
              int64_t v544 = (int64_t) ((uint64_t) v374 + (uint64_t) v72) % v89;
              // pto: %236, %237, %238
              ;
              int64_t v545 = v544 < v83 ? (int64_t) ((uint64_t) v544 + (uint64_t) v89) : v544;
              set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
              for (int64_t v546 = v83; v546 < v90; v546 += v72) {
                // pto: %241, %242, %243
                ;
                if (v539 > v83 | v546 == v83) {
                  // pto: %244, %245
                  ;
                  int64_t v547 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v546 * (uint64_t) v81) + (uint64_t) v332);
                  // pto: %prefetch_kv_half_inline5261__ssa_v0
                  ;
                  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v548 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                  // pto: %prefetch_kv_half_inline5261__ssa_v0
                  ;
                  uint64_t v549 = (uint64_t) v38;
                  TASSIGN(v548, v549);
                  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
                  pipe_barrier(PIPE_V);
                  TEXPANDS(v548, v91);
                  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
                  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                  for (int64_t v550 = v83; v550 < v78; v550 += v72) {
                    // pto: %247, %248, %249
                    ;
                    int64_t v551 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v371 * (uint64_t) v73) + (uint64_t) v547) + (uint64_t) v550);
                    // pto: %250
                    ;
                    if (v551 < v73) {
                      // pto: %251, %252, %prefetch_ridx_inline5401__tile
                      ;
                      int32_t v552 = (v15)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v325 * (uint64_t) v73) + (uint64_t) v551)];
                      // pto: %253
                      ;
                      int64_t v553 = (int64_t) v552;
                      // pto: %254
                      ;
                      if (v553 >= v83) {
                        // pto: %258, %259, %257, %255
                        ;
                        int32_t v554 = (v16)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v543 * (uint64_t) v31) + (uint64_t) (v553 / v84))];
                        // pto: %260
                        ;
                        int64_t v555 = (int64_t) v554;
                        // pto: %261
                        ;
                        if (v555 >= v83) {
                          // pto: %264
                          ;
                          int64_t v556 = v553 % v84;
                          // pto: %265, %266, %267
                          ;
                          int64_t v557 = v556 < v83 ? (int64_t) ((uint64_t) v556 + (uint64_t) v84) : v556;
                          // pto: %262, %268
                          ;
                          int64_t v558 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v555 * (uint64_t) v84) + (uint64_t) v557);
                          // pto: %269
                          ;
                          Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v559;
                          // pto: %269
                          ;
                          uint64_t v560 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v550 * (uint64_t) v36) + (uint64_t) v38);
                          TASSIGN(v559, v560);
                          // pto: %270
                          ;
                          int64_t v561 = v558 < v83 ? v83 : v558;
                          // pto: %271
                          ;
                          __gm__ bfloat16_t* v562 = PTOAS__GLOBAL_TENSOR_DATA(v180);
                          // pto: %271
                          ;
                          const int64_t v563 = 0;
                          // pto: %271
                          ;
                          const int64_t v564 = 512;
                          // pto: %271
                          ;
                          pto::Shape<1, 1, 1, 1, 512> v565 = pto::Shape<1, 1, 1, 1, 512>();
                          // pto: %271
                          ;
                          pto::Stride<512, 512, 512, 512, 1> v566 = pto::Stride<512, 512, 512, 512, 1>();
                          // pto: %271
                          ;
                          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v567 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v562 + (v563 + v561 * v564), v565, v566);
                          TLOAD(v559, v567);
                        };
                      };
                    };
                  };
                  set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID7);
                  // pto: %239, %240, %272
                  ;
                  int64_t v568 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v375 + (uint64_t) v545) * (uint64_t) v73) + (uint64_t) v547);
                  // pto: %273
                  ;
                  int64_t v569 = v568 < v83 ? v83 : v568;
                  // pto: %274
                  ;
                  __gm__ bfloat16_t* v570 = PTOAS__GLOBAL_TENSOR_DATA(v114);
                  // pto: %274
                  ;
                  const int64_t v571 = 0;
                  // pto: %274
                  ;
                  const int64_t v572 = 512;
                  // pto: %274
                  ;
                  pto::Shape<1, 1, 1, 64, 512> v573 = pto::Shape<1, 1, 1, 64, 512>();
                  // pto: %274
                  ;
                  pto::Stride<32768, 32768, 32768, 512, 1> v574 = pto::Stride<32768, 32768, 32768, 512, 1>();
                  // pto: %274
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v575 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v570 + (v571 + v569 * v572), v573, v574);
                  wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID7);
                  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
                  TSTORE(v575, v548);
                  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
                };
              };
              wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
              uint16_t v576 = getFFTSMsg(FFTS_MODE_VAL, v83);
              ffts_cross_core_sync(PIPE_MTE3, v576);
            };
          };
        };
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        pipe_barrier(PIPE_ALL);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
        for (int64_t v577 = v83; v577 < v90; v577 += v72) {
          // pto: %275
          ;
          int64_t v578 = (int64_t) ((uint64_t) v577 * (uint64_t) v85);
          // pto: %277
          ;
          int64_t v579 = (int64_t) ((uint64_t) v359 + (uint64_t) v578);
          // pto: %2, %279, %278, %280, %281
          ;
          int64_t v580 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v323 * (uint64_t) v81) + (uint64_t) ((int64_t) (uint64_t) v371 * (uint64_t) v78)) + (uint64_t) v331) + (uint64_t) v578);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
          if (v538) {
            // pto: %sm_live_scores_inline5409__ssa_v0
            ;
            Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v581 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v81);
            // pto: %sm_live_scores_inline5409__ssa_v0
            ;
            uint64_t v582 = (uint64_t) v42;
            TASSIGN(v581, v582);
            // pto: %283
            ;
            int64_t v583 = v580 < v83 ? v83 : v580;
            // pto: %score_transfer_inline5311__ssa_v0_pview
            ;
            __gm__ float* v584 = PTOAS__GLOBAL_TENSOR_DATA(v122);
            // pto: %score_transfer_inline5311__ssa_v0_pview
            ;
            const int64_t v585 = 0;
            // pto: %score_transfer_inline5311__ssa_v0_pview
            ;
            const int64_t v586 = 512;
            // pto: %score_transfer_inline5311__ssa_v0_pview
            ;
            pto::Shape<1, 1, 1, 8, 128> v587 = pto::Shape<1, 1, 1, 8, 128>();
            // pto: %score_transfer_inline5311__ssa_v0_pview
            ;
            pto::Stride<4096, 4096, 4096, 512, 1> v588 = pto::Stride<4096, 4096, 4096, 512, 1>();
            // pto: %score_transfer_inline5311__ssa_v0_pview
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 8, 128>, pto::Stride<4096, 4096, 4096, 512, 1>, pto::Layout::ND> v589 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 128>, pto::Stride<4096, 4096, 4096, 512, 1>, pto::Layout::ND>(v584 + (v585 + v583 * v586), v587, v588);
            TLOAD(v581, v589);
            set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
            // pto: %t__tmp_v946
            ;
            Tile<TileType::Vec, float, 8, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v590 = Tile<TileType::Vec, float, 8, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v94);
            // pto: %t__tmp_v946
            ;
            uint64_t v591 = (uint64_t) v43;
            TASSIGN(v590, v591);
            pipe_barrier(PIPE_V);
            TEXPANDS(v590, v86);
            // pto: %sm_scores_inline5252__ssa_v0
            ;
            Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v592 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
            // pto: %sm_scores_inline5252__ssa_v0
            ;
            uint64_t v593 = (uint64_t) v38;
            TASSIGN(v592, v593);
            pipe_barrier(PIPE_V);
            wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
            TCONCAT(v592, v581, v590);
          } else {
            // pto: %sm_scores_inline5252__ssa_v1
            ;
            Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v594 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
            // pto: %sm_scores_inline5252__ssa_v1
            ;
            uint64_t v595 = (uint64_t) v38;
            TASSIGN(v594, v595);
            // pto: %284
            ;
            int64_t v596 = v580 < v83 ? v83 : v580;
            // pto: %285
            ;
            __gm__ float* v597 = PTOAS__GLOBAL_TENSOR_DATA(v122);
            // pto: %285
            ;
            const int64_t v598 = 0;
            // pto: %285
            ;
            const int64_t v599 = 512;
            // pto: %285
            ;
            pto::Shape<1, 1, 1, 8, 512> v600 = pto::Shape<1, 1, 1, 8, 512>();
            // pto: %285
            ;
            pto::Stride<4096, 4096, 4096, 512, 1> v601 = pto::Stride<4096, 4096, 4096, 512, 1>();
            // pto: %285
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<4096, 4096, 4096, 512, 1>, pto::Layout::ND> v602 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<4096, 4096, 4096, 512, 1>, pto::Layout::ND>(v597 + (v598 + v596 * v599), v600, v601);
            TLOAD(v594, v602);
          };
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          // pto: %sm_bias_inline5286__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v603 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v73);
          // pto: %sm_bias_inline5286__ssa_v0
          ;
          uint64_t v604 = (uint64_t) v43;
          TASSIGN(v603, v604);
          // pto: %286
          ;
          int64_t v605 = v325 < v83 ? v83 : v325;
          // pto: %287
          ;
          int64_t v606 = (int64_t) ((uint64_t) v371 * (uint64_t) v73);
          // pto: %288
          ;
          int64_t v607 = v606 < v83 ? v83 : v606;
          // pto: %sparse_bias_inline5240__rv_v2_pview
          ;
          __gm__ float* v608 = PTOAS__GLOBAL_TENSOR_DATA(v189);
          // pto: %sparse_bias_inline5240__rv_v2_pview
          ;
          const int64_t v609 = 0;
          // pto: %sparse_bias_inline5240__rv_v2_pview
          ;
          const int64_t v610 = 1024;
          // pto: %sparse_bias_inline5240__rv_v2_pview
          ;
          pto::Shape<1, 1, 1, 1, 512> v611 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %sparse_bias_inline5240__rv_v2_pview
          ;
          pto::Stride<1024, 1024, 1024, 1024, 1> v612 = pto::Stride<1024, 1024, 1024, 1024, 1>();
          // pto: %sparse_bias_inline5240__rv_v2_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v613 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v608 + (v609 + v605 * v610 + v607), v611, v612);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
          TLOAD(v603, v613);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
          // pto: %t__tmp_v947
          ;
          Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v614 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
          // pto: %t__tmp_v947
          ;
          uint64_t v615 = (uint64_t) v38;
          TASSIGN(v614, v615);
          pipe_barrier(PIPE_V);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
          TMULS(v614, v271, v95);
          // pto: %sm_masked_inline5410__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v616 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
          // pto: %sm_masked_inline5410__ssa_v0
          ;
          uint64_t v617 = (uint64_t) v38;
          TASSIGN(v616, v617);
          pipe_barrier(PIPE_V);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
          TCOLEXPANDADD(v616, v614, v603);
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
          // pto: %sm_block_max_inline5411__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v618 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
          // pto: %sm_block_max_inline5411__ssa_v0
          ;
          uint64_t v619 = (uint64_t) v43;
          TASSIGN(v618, v619);
          pipe_barrier(PIPE_V);
          TROWMAX(v618, v616, v333);
          // pto: %sm_old_m_inline5374__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v620 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
          // pto: %sm_old_m_inline5374__ssa_v0
          ;
          uint64_t v621 = (uint64_t) v44;
          TASSIGN(v620, v621);
          // pto: %289
          ;
          int64_t v622 = v579 < v83 ? v83 : v579;
          // pto: %290
          ;
          __gm__ float* v623 = PTOAS__GLOBAL_TENSOR_DATA(v154);
          // pto: %290
          ;
          const int64_t v624 = 0;
          // pto: %290
          ;
          pto::Shape<1, 1, 1, 8, 1> v625 = pto::Shape<1, 1, 1, 8, 1>();
          // pto: %290
          ;
          pto::Stride<8, 8, 8, 1, 1536> v626 = pto::Stride<8, 8, 8, 1, 1536>();
          // pto: %290
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN> v627 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN>(v623 + (v624 + v622), v625, v626);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
          TLOAD(v620, v627);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
          // pto: %sm_old_l_inline5214__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v628 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
          // pto: %sm_old_l_inline5214__ssa_v0
          ;
          uint64_t v629 = (uint64_t) v45;
          TASSIGN(v628, v629);
          // pto: %292
          ;
          __gm__ float* v630 = PTOAS__GLOBAL_TENSOR_DATA(v162);
          // pto: %292
          ;
          const int64_t v631 = 0;
          // pto: %292
          ;
          pto::Shape<1, 1, 1, 8, 1> v632 = pto::Shape<1, 1, 1, 8, 1>();
          // pto: %292
          ;
          pto::Stride<8, 8, 8, 1, 1536> v633 = pto::Stride<8, 8, 8, 1, 1536>();
          // pto: %292
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN> v634 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN>(v630 + (v631 + v622), v632, v633);
          TLOAD(v628, v634);
          // pto: %sm_max_inline5412__rm_a0_tmp_v4
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v635 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %sm_max_inline5412__rm_a0_tmp_v4
          ;
          uint64_t v636 = (uint64_t) v44;
          TASSIGN(v635, v636);
          // pto: %sm_max_inline5412__rm_a1_tmp_v5
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v637 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %sm_max_inline5412__rm_a1_tmp_v5
          ;
          uint64_t v638 = (uint64_t) v43;
          TASSIGN(v637, v638);
          // pto: %sm_max_inline5412__row_major_tmp_v6
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v639 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %sm_max_inline5412__row_major_tmp_v6
          ;
          uint64_t v640 = (uint64_t) v46;
          TASSIGN(v639, v640);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
          pipe_barrier(PIPE_V);
          TMAX(v639, v635, v637);
          // pto: %sm_max_inline5412__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v641 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
          // pto: %sm_max_inline5412__ssa_v0
          ;
          uint64_t v642 = (uint64_t) v46;
          TASSIGN(v641, v642);
          // pto: %t__rm_a0_tmp_v7
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v643 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %t__rm_a0_tmp_v7
          ;
          uint64_t v644 = (uint64_t) v44;
          TASSIGN(v643, v644);
          // pto: %t__rm_a1_tmp_v8
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v645 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %t__rm_a1_tmp_v8
          ;
          uint64_t v646 = (uint64_t) v46;
          TASSIGN(v645, v646);
          // pto: %t__row_major_tmp_v9
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v647 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %t__row_major_tmp_v9
          ;
          uint64_t v648 = (uint64_t) v43;
          TASSIGN(v647, v648);
          pipe_barrier(PIPE_V);
          TSUB(v647, v643, v645);
          // pto: %t__tmp_v948
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v649 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
          // pto: %t__tmp_v948
          ;
          uint64_t v650 = (uint64_t) v43;
          TASSIGN(v649, v650);
          // pto: %sm_alpha_inline5413__rm_a0_tmp_v10
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v651 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %sm_alpha_inline5413__rm_a0_tmp_v10
          ;
          uint64_t v652 = (uint64_t) v43;
          TASSIGN(v651, v652);
          // pto: %sm_alpha_inline5413__row_major_tmp_v11
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v653 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %sm_alpha_inline5413__row_major_tmp_v11
          ;
          uint64_t v654 = (uint64_t) v47;
          TASSIGN(v653, v654);
          pipe_barrier(PIPE_V);
          wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
          TEXP(v653, v651);
          // pto: %sm_alpha_inline5413__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v655 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
          // pto: %sm_alpha_inline5413__ssa_v0
          ;
          uint64_t v656 = (uint64_t) v47;
          TASSIGN(v655, v656);
          // pto: %t__tmp_v949
          ;
          Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v657 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
          // pto: %t__tmp_v949
          ;
          uint64_t v658 = (uint64_t) v38;
          TASSIGN(v657, v658);
          TROWEXPANDSUB(v657, v616, v641);
          // pto: %sm_exp_inline5198__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v659 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
          // pto: %sm_exp_inline5198__ssa_v0
          ;
          uint64_t v660 = (uint64_t) v38;
          TASSIGN(v659, v660);
          pipe_barrier(PIPE_V);
          TEXP(v659, v657);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
          // pto: %293
          ;
          int64_t v661 = (v12)[v325];
          // pto: %sm_key_count_inline5301__phi_v2
          ;
          int64_t v662;
          if (v538) {
            // pto: %298
            ;
            int64_t v663 = (int64_t) ((uint64_t) v661 + (uint64_t) v72);
            // pto: %299
            ;
            v662 = v663 < v81 ? v663 : v81;
          } else {
            // pto: %300, %301
            ;
            int64_t v664 = (int64_t) ((uint64_t) v661 + (uint64_t) v72) / v90;
            // pto: %302
            ;
            v662 = v664 < v73 ? v664 : v73;
          };
          // pto: %303
          ;
          bool v665 = v662 < v78;
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
          if (v665) {
            // pto: %sm_short_inline5307__ssa_v0
            ;
            Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v666 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v662);
            // pto: %sm_short_inline5307__ssa_v0
            ;
            uint64_t v667 = (uint64_t) v38;
            TASSIGN(v666, v667);
            // pto: %slice_view
            ;
            Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v668 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v662);
            // pto: %slice_view
            ;
            uint64_t v669 = (uint64_t) v38;
            TASSIGN(v668, v669);
            // pto: %t__tmp_v951
            ;
            Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v670 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
            // pto: %t__tmp_v951
            ;
            uint64_t v671 = (uint64_t) v43;
            TASSIGN(v670, v671);
            // pto: %sm_block_sum_inline5430__ssa_v0
            ;
            Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v672 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
            // pto: %sm_block_sum_inline5430__ssa_v0
            ;
            uint64_t v673 = (uint64_t) v48;
            TASSIGN(v672, v673);
            pipe_barrier(PIPE_V);
            TROWSUM(v672, v668, v670);
          } else {
            // pto: %304
            ;
            bool v674 = v662 < v73;
            if (v674) {
              // pto: %t__tmp_v952
              ;
              Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v675 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
              // pto: %t__tmp_v952
              ;
              uint64_t v676 = (uint64_t) v43;
              TASSIGN(v675, v676);
              TEXPANDS(v675, v86);
              // pto: %t__ci_tmp_v0
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v677 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v96);
              // pto: %t__ci_tmp_v0
              ;
              uint64_t v678 = (uint64_t) v49;
              TASSIGN(v677, v678);
              // pto: %t__tmp_v953
              ;
              Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v679 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
              // pto: %t__tmp_v953
              ;
              uint64_t v680 = (uint64_t) v50;
              TASSIGN(v679, v680);
              // pto: %ci_tmp_view
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v681;
              TRESHAPE(v681, v677);
              // pto: %ci_dst_view
              ;
              Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v682;
              TRESHAPE(v682, v679);
              TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v682, v97, v681);
              // pto: %t__tmp_v954
              ;
              Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v683 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
              // pto: %t__tmp_v954
              ;
              uint64_t v684 = (uint64_t) v49;
              TASSIGN(v683, v684);
              pipe_barrier(PIPE_V);
              RoundMode v685 = RoundMode::CAST_ROUND;
              SaturationMode v686 = SaturationMode::ON;
              TCVT(v683, v679, v685, v686);
              // pto: %sm_columns_inline5210__ssa_v0
              ;
              Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v687 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
              // pto: %sm_columns_inline5210__ssa_v0
              ;
              uint64_t v688 = (uint64_t) v43;
              TASSIGN(v687, v688);
              pipe_barrier(PIPE_V);
              TCOLEXPANDADD(v687, v675, v683);
              set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
              // pto: %t__tmp_v955
              ;
              Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v689 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
              // pto: %t__tmp_v955
              ;
              uint64_t v690 = (uint64_t) v38;
              TASSIGN(v689, v690);
              // pto: %305
              ;
              Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v691;
              // pto: %305
              ;
              uint64_t v692 = (uint64_t) v38;
              TASSIGN(v691, v692);
              // pto: %softmax_copy64_inline5292__ssa_v0_pview
              ;
              __gm__ float* v693 = PTOAS__GLOBAL_TENSOR_DATA(v197);
              // pto: %softmax_copy64_inline5292__ssa_v0_pview
              ;
              const int64_t v694 = 0;
              // pto: %softmax_copy64_inline5292__ssa_v0_pview
              ;
              const int64_t v695 = 64;
              // pto: %softmax_copy64_inline5292__ssa_v0_pview
              ;
              pto::Shape<1, 1, 1, 8, 64> v696 = pto::Shape<1, 1, 1, 8, 64>();
              // pto: %softmax_copy64_inline5292__ssa_v0_pview
              ;
              pto::Stride<512, 512, 512, 64, 1> v697 = pto::Stride<512, 512, 512, 64, 1>();
              // pto: %softmax_copy64_inline5292__ssa_v0_pview
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v698 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v693 + (v694 + v622 * v695), v696, v697);
              TSTORE(v698, v691);
              set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
              // pto: %sm_fold64_inline5376__ssa_v0
              ;
              Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v699 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
              // pto: %sm_fold64_inline5376__ssa_v0
              ;
              uint64_t v700 = (uint64_t) v49;
              TASSIGN(v699, v700);
              wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
              wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
              TLOAD(v699, v698);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
              // pto: %309
              ;
              bool v701 = v662 > v78;
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
              if (v701) {
                // pto: %t__tmp_v956
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v702 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %t__tmp_v956
                ;
                uint64_t v703 = (uint64_t) v51;
                TASSIGN(v702, v703);
                // pto: %310
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v704;
                // pto: %310
                ;
                uint64_t v705 = (uint64_t) v51;
                TASSIGN(v704, v705);
                // pto: %sm_added_inline5416__ssa_v0
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v706 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_added_inline5416__ssa_v0
                ;
                uint64_t v707 = (uint64_t) v52;
                TASSIGN(v706, v707);
                TADD(v706, v699, v704);
                // pto: %311
                ;
                bool v708 = v662 < v81;
                if (v708) {
                  // pto: %312
                  ;
                  uint64_t v709 = (uint64_t) v662;
                  // pto: %312, %313, %314
                  ;
                  float v710 = (float) ((int32_t) (int64_t) (v709 - (uint64_t) v78));
                  // pto: %sm_tail_mask_inline5418__ssa_v0
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v711 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v85);
                  // pto: %sm_tail_mask_inline5418__ssa_v0
                  ;
                  uint64_t v712 = (uint64_t) v53;
                  TASSIGN(v711, v712);
                  CmpMode v713 = CmpMode::LT;
                  TCMPS(v711, v687, v710, v713);
                  // pto: %t__tmp_v957
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v714 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v74);
                  // pto: %t__tmp_v957
                  ;
                  uint64_t v715 = (uint64_t) v54;
                  TASSIGN(v714, v715);
                  // pto: %sm_fold64_inline5376__ssa_v1
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v716 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5376__ssa_v1
                  ;
                  uint64_t v717 = (uint64_t) v52;
                  TASSIGN(v716, v717);
                  pipe_barrier(PIPE_V);
                  TSEL(v716, v711, v706, v699, v714);
                } else {
                  // pto: %sm_fold64_inline5376__ssa_v2
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v718 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5376__ssa_v2
                  ;
                  uint64_t v719 = (uint64_t) v52;
                  TASSIGN(v718, v719);
                };
              } else {
                // pto: %sm_fold64_inline5376__ssa_v0_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v720 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_fold64_inline5376__ssa_v0_mv
                ;
                uint64_t v721 = (uint64_t) v52;
                TASSIGN(v720, v721);
                TMOV(v720, v699);
              };
              // pto: %315
              ;
              bool v722 = v662 > v81;
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
              if (v722) {
                // pto: %t__tmp_v958
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v723 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %t__tmp_v958
                ;
                uint64_t v724 = (uint64_t) v55;
                TASSIGN(v723, v724);
                // pto: %316
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v725;
                // pto: %316
                ;
                uint64_t v726 = (uint64_t) v55;
                TASSIGN(v725, v726);
                // pto: %sm_added_inline5416__ssa_v1
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v727 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_added_inline5416__ssa_v1
                ;
                uint64_t v728 = (uint64_t) v49;
                TASSIGN(v727, v728);
                pipe_barrier(PIPE_V);
                TADD(v727, v277, v725);
                // pto: %317
                ;
                bool v729 = v662 < v96;
                if (v729) {
                  // pto: %318
                  ;
                  uint64_t v730 = (uint64_t) v662;
                  // pto: %318, %319, %320
                  ;
                  float v731 = (float) ((int32_t) (int64_t) (v730 - (uint64_t) v81));
                  // pto: %sm_tail_mask_inline5418__ssa_v1
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v732 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v85);
                  // pto: %sm_tail_mask_inline5418__ssa_v1
                  ;
                  uint64_t v733 = (uint64_t) v53;
                  TASSIGN(v732, v733);
                  CmpMode v734 = CmpMode::LT;
                  TCMPS(v732, v687, v731, v734);
                  // pto: %t__tmp_v959
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v735 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v74);
                  // pto: %t__tmp_v959
                  ;
                  uint64_t v736 = (uint64_t) v54;
                  TASSIGN(v735, v736);
                  // pto: %sm_fold64_inline5376__ssa_v5
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v737 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5376__ssa_v5
                  ;
                  uint64_t v738 = (uint64_t) v49;
                  TASSIGN(v737, v738);
                  pipe_barrier(PIPE_V);
                  TSEL(v737, v732, v727, v277, v735);
                } else {
                  // pto: %sm_fold64_inline5376__ssa_v6
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v739 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5376__ssa_v6
                  ;
                  uint64_t v740 = (uint64_t) v49;
                  TASSIGN(v739, v740);
                };
              } else {
                // pto: %sm_fold64_inline5376__phi_v4_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v741 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_fold64_inline5376__phi_v4_mv
                ;
                uint64_t v742 = (uint64_t) v49;
                TASSIGN(v741, v742);
                pipe_barrier(PIPE_V);
                TMOV(v741, v277);
              };
              // pto: %321
              ;
              bool v743 = v662 > v96;
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
              if (v743) {
                // pto: %t__tmp_v960
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v744 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %t__tmp_v960
                ;
                uint64_t v745 = (uint64_t) v56;
                TASSIGN(v744, v745);
                // pto: %322
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v746;
                // pto: %322
                ;
                uint64_t v747 = (uint64_t) v56;
                TASSIGN(v746, v747);
                // pto: %sm_added_inline5416__ssa_v2
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v748 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_added_inline5416__ssa_v2
                ;
                uint64_t v749 = (uint64_t) v52;
                TASSIGN(v748, v749);
                pipe_barrier(PIPE_V);
                TADD(v748, v281, v746);
                // pto: %323
                ;
                bool v750 = v662 < v88;
                if (v750) {
                  // pto: %324
                  ;
                  uint64_t v751 = (uint64_t) v662;
                  // pto: %324, %325, %326
                  ;
                  float v752 = (float) ((int32_t) (int64_t) (v751 - (uint64_t) v96));
                  // pto: %sm_tail_mask_inline5418__ssa_v2
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v753 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v85);
                  // pto: %sm_tail_mask_inline5418__ssa_v2
                  ;
                  uint64_t v754 = (uint64_t) v53;
                  TASSIGN(v753, v754);
                  CmpMode v755 = CmpMode::LT;
                  TCMPS(v753, v687, v752, v755);
                  // pto: %t__tmp_v961
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v756 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v74);
                  // pto: %t__tmp_v961
                  ;
                  uint64_t v757 = (uint64_t) v54;
                  TASSIGN(v756, v757);
                  // pto: %sm_fold64_inline5376__ssa_v9
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v758 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5376__ssa_v9
                  ;
                  uint64_t v759 = (uint64_t) v52;
                  TASSIGN(v758, v759);
                  pipe_barrier(PIPE_V);
                  TSEL(v758, v753, v748, v281, v756);
                } else {
                  // pto: %sm_fold64_inline5376__ssa_v10
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v760 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5376__ssa_v10
                  ;
                  uint64_t v761 = (uint64_t) v52;
                  TASSIGN(v760, v761);
                };
              } else {
                // pto: %sm_fold64_inline5376__phi_v8_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v762 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_fold64_inline5376__phi_v8_mv
                ;
                uint64_t v763 = (uint64_t) v52;
                TASSIGN(v762, v763);
                pipe_barrier(PIPE_V);
                TMOV(v762, v281);
              };
              // pto: %327
              ;
              bool v764 = v662 > v88;
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
              if (v764) {
                // pto: %t__tmp_v962
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v765 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %t__tmp_v962
                ;
                uint64_t v766 = (uint64_t) v57;
                TASSIGN(v765, v766);
                // pto: %328
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v767;
                // pto: %328
                ;
                uint64_t v768 = (uint64_t) v57;
                TASSIGN(v767, v768);
                // pto: %sm_added_inline5416__ssa_v3
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v769 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_added_inline5416__ssa_v3
                ;
                uint64_t v770 = (uint64_t) v49;
                TASSIGN(v769, v770);
                pipe_barrier(PIPE_V);
                TADD(v769, v285, v767);
                // pto: %329
                ;
                bool v771 = v662 < v98;
                if (v771) {
                  // pto: %330
                  ;
                  uint64_t v772 = (uint64_t) v662;
                  // pto: %330, %331, %332
                  ;
                  float v773 = (float) ((int32_t) (int64_t) (v772 - (uint64_t) v88));
                  // pto: %sm_tail_mask_inline5418__ssa_v3
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v774 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v85);
                  // pto: %sm_tail_mask_inline5418__ssa_v3
                  ;
                  uint64_t v775 = (uint64_t) v53;
                  TASSIGN(v774, v775);
                  CmpMode v776 = CmpMode::LT;
                  TCMPS(v774, v687, v773, v776);
                  // pto: %t__tmp_v963
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v777 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v74);
                  // pto: %t__tmp_v963
                  ;
                  uint64_t v778 = (uint64_t) v54;
                  TASSIGN(v777, v778);
                  // pto: %sm_fold64_inline5376__ssa_v13
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v779 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5376__ssa_v13
                  ;
                  uint64_t v780 = (uint64_t) v49;
                  TASSIGN(v779, v780);
                  pipe_barrier(PIPE_V);
                  TSEL(v779, v774, v769, v285, v777);
                } else {
                  // pto: %sm_fold64_inline5376__ssa_v14
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v781 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5376__ssa_v14
                  ;
                  uint64_t v782 = (uint64_t) v49;
                  TASSIGN(v781, v782);
                };
              } else {
                // pto: %sm_fold64_inline5376__phi_v12_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v783 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_fold64_inline5376__phi_v12_mv
                ;
                uint64_t v784 = (uint64_t) v49;
                TASSIGN(v783, v784);
                pipe_barrier(PIPE_V);
                TMOV(v783, v285);
              };
              // pto: %333
              ;
              bool v785 = v662 > v98;
              pipe_barrier(PIPE_ALL);
              if (v785) {
                // pto: %t__tmp_v964
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v786 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %t__tmp_v964
                ;
                uint64_t v787 = (uint64_t) v58;
                TASSIGN(v786, v787);
                // pto: %334
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v788;
                // pto: %334
                ;
                uint64_t v789 = (uint64_t) v58;
                TASSIGN(v788, v789);
                // pto: %sm_added_inline5416__ssa_v4
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v790 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_added_inline5416__ssa_v4
                ;
                uint64_t v791 = (uint64_t) v52;
                TASSIGN(v790, v791);
                pipe_barrier(PIPE_V);
                TADD(v790, v289, v788);
                // pto: %335
                ;
                bool v792 = v662 < v94;
                if (v792) {
                  // pto: %336
                  ;
                  uint64_t v793 = (uint64_t) v662;
                  // pto: %336, %337, %338
                  ;
                  float v794 = (float) ((int32_t) (int64_t) (v793 - (uint64_t) v98));
                  // pto: %sm_tail_mask_inline5418__ssa_v4
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v795 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v85);
                  // pto: %sm_tail_mask_inline5418__ssa_v4
                  ;
                  uint64_t v796 = (uint64_t) v53;
                  TASSIGN(v795, v796);
                  CmpMode v797 = CmpMode::LT;
                  TCMPS(v795, v687, v794, v797);
                  // pto: %t__tmp_v965
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v798 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v74);
                  // pto: %t__tmp_v965
                  ;
                  uint64_t v799 = (uint64_t) v54;
                  TASSIGN(v798, v799);
                  // pto: %sm_fold64_inline5376__ssa_v17
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v800 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5376__ssa_v17
                  ;
                  uint64_t v801 = (uint64_t) v52;
                  TASSIGN(v800, v801);
                  pipe_barrier(PIPE_V);
                  TSEL(v800, v795, v790, v289, v798);
                } else {
                  // pto: %sm_fold64_inline5376__ssa_v18
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v802 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5376__ssa_v18
                  ;
                  uint64_t v803 = (uint64_t) v52;
                  TASSIGN(v802, v803);
                };
              } else {
                // pto: %sm_fold64_inline5376__phi_v16_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v804 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_fold64_inline5376__phi_v16_mv
                ;
                uint64_t v805 = (uint64_t) v52;
                TASSIGN(v804, v805);
                pipe_barrier(PIPE_V);
                TMOV(v804, v289);
              };
              // pto: %339
              ;
              bool v806 = v662 > v94;
              pipe_barrier(PIPE_ALL);
              if (v806) {
                // pto: %t__tmp_v966
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v807 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %t__tmp_v966
                ;
                uint64_t v808 = (uint64_t) v59;
                TASSIGN(v807, v808);
                // pto: %340
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v809;
                // pto: %340
                ;
                uint64_t v810 = (uint64_t) v59;
                TASSIGN(v809, v810);
                // pto: %sm_added_inline5416__ssa_v5
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v811 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_added_inline5416__ssa_v5
                ;
                uint64_t v812 = (uint64_t) v49;
                TASSIGN(v811, v812);
                pipe_barrier(PIPE_V);
                TADD(v811, v293, v809);
                // pto: %341
                ;
                bool v813 = v662 < v99;
                if (v813) {
                  // pto: %342
                  ;
                  uint64_t v814 = (uint64_t) v662;
                  // pto: %342, %343, %344
                  ;
                  float v815 = (float) ((int32_t) (int64_t) (v814 - (uint64_t) v94));
                  // pto: %sm_tail_mask_inline5418__ssa_v5
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v816 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v85);
                  // pto: %sm_tail_mask_inline5418__ssa_v5
                  ;
                  uint64_t v817 = (uint64_t) v53;
                  TASSIGN(v816, v817);
                  CmpMode v818 = CmpMode::LT;
                  TCMPS(v816, v687, v815, v818);
                  // pto: %t__tmp_v967
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v819 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v74);
                  // pto: %t__tmp_v967
                  ;
                  uint64_t v820 = (uint64_t) v54;
                  TASSIGN(v819, v820);
                  // pto: %sm_fold64_inline5376__ssa_v21
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v821 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5376__ssa_v21
                  ;
                  uint64_t v822 = (uint64_t) v49;
                  TASSIGN(v821, v822);
                  pipe_barrier(PIPE_V);
                  TSEL(v821, v816, v811, v293, v819);
                } else {
                  // pto: %sm_fold64_inline5376__ssa_v22
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v823 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5376__ssa_v22
                  ;
                  uint64_t v824 = (uint64_t) v49;
                  TASSIGN(v823, v824);
                };
              } else {
                // pto: %sm_fold64_inline5376__phi_v20_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v825 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_fold64_inline5376__phi_v20_mv
                ;
                uint64_t v826 = (uint64_t) v49;
                TASSIGN(v825, v826);
                pipe_barrier(PIPE_V);
                TMOV(v825, v293);
              };
              // pto: %345
              ;
              bool v827 = v662 > v99;
              pipe_barrier(PIPE_ALL);
              if (v827) {
                // pto: %t__tmp_v968
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v828 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %t__tmp_v968
                ;
                uint64_t v829 = (uint64_t) v60;
                TASSIGN(v828, v829);
                // pto: %346
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v830;
                // pto: %346
                ;
                uint64_t v831 = (uint64_t) v60;
                TASSIGN(v830, v831);
                // pto: %sm_added_inline5416__ssa_v6
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v832 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_added_inline5416__ssa_v6
                ;
                uint64_t v833 = (uint64_t) v52;
                TASSIGN(v832, v833);
                pipe_barrier(PIPE_V);
                TADD(v832, v297, v830);
                // pto: %347
                ;
                uint64_t v834 = (uint64_t) v662;
                // pto: %347, %348, %349
                ;
                float v835 = (float) ((int32_t) (int64_t) (v834 - (uint64_t) v99));
                // pto: %sm_tail_mask_inline5418__ssa_v6
                ;
                Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v836 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v85);
                // pto: %sm_tail_mask_inline5418__ssa_v6
                ;
                uint64_t v837 = (uint64_t) v53;
                TASSIGN(v836, v837);
                CmpMode v838 = CmpMode::LT;
                TCMPS(v836, v687, v835, v838);
                // pto: %t__tmp_v969
                ;
                Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v839 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v74);
                // pto: %t__tmp_v969
                ;
                uint64_t v840 = (uint64_t) v54;
                TASSIGN(v839, v840);
                // pto: %sm_fold64_inline5376__ssa_v25
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v841 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_fold64_inline5376__ssa_v25
                ;
                uint64_t v842 = (uint64_t) v43;
                TASSIGN(v841, v842);
                pipe_barrier(PIPE_V);
                TSEL(v841, v836, v832, v297, v839);
              } else {
                // pto: %sm_fold64_inline5376__phi_v24_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v843 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_fold64_inline5376__phi_v24_mv
                ;
                uint64_t v844 = (uint64_t) v43;
                TASSIGN(v843, v844);
                pipe_barrier(PIPE_V);
                TMOV(v843, v297);
              };
              // pto: %sm_groups64_inline5419__ssa_v0
              ;
              Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v845 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v85);
              // pto: %sm_groups64_inline5419__ssa_v0
              ;
              uint64_t v846 = (uint64_t) v43;
              TASSIGN(v845, v846);
              // pto: %t__tmp_v970
              ;
              Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v847 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v85);
              // pto: %t__tmp_v970
              ;
              uint64_t v848 = (uint64_t) v49;
              TASSIGN(v847, v848);
              // pto: %sm_sum8_inline5421__ssa_v0
              ;
              Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v849 = Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v72);
              // pto: %sm_sum8_inline5421__ssa_v0
              ;
              uint64_t v850 = (uint64_t) v52;
              TASSIGN(v849, v850);
              pipe_barrier(PIPE_V);
              pipe_barrier(PIPE_ALL);
              TROWSUM(v849, v845, v847);
              // pto: %sm_final8_inline5255__ssa_v0
              ;
              Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v851 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v85);
              // pto: %sm_final8_inline5255__ssa_v0
              ;
              uint64_t v852 = (uint64_t) v52;
              TASSIGN(v851, v852);
              // pto: %t__tmp_v971
              ;
              Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v853 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v85);
              // pto: %t__tmp_v971
              ;
              uint64_t v854 = (uint64_t) v43;
              TASSIGN(v853, v854);
              // pto: %sm_block_sum_inline5430__ssa_v1
              ;
              Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v855 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
              // pto: %sm_block_sum_inline5430__ssa_v1
              ;
              uint64_t v856 = (uint64_t) v48;
              TASSIGN(v855, v856);
              pipe_barrier(PIPE_V);
              TROWSUM(v855, v851, v853);
            } else {
              // pto: %sm_groups8_inline5422__ssa_v0
              ;
              Tile<TileType::Vec, float, 512, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v857 = Tile<TileType::Vec, float, 512, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v85);
              // pto: %sm_groups8_inline5422__ssa_v0
              ;
              uint64_t v858 = (uint64_t) v38;
              TASSIGN(v857, v858);
              // pto: %t__tmp_v972
              ;
              Tile<TileType::Vec, float, 512, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v859 = Tile<TileType::Vec, float, 512, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v85);
              // pto: %t__tmp_v972
              ;
              uint64_t v860 = (uint64_t) v43;
              TASSIGN(v859, v860);
              // pto: %sm_sum64_inline5361__ssa_v0
              ;
              Tile<TileType::Vec, float, 512, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v861 = Tile<TileType::Vec, float, 512, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v72);
              // pto: %sm_sum64_inline5361__ssa_v0
              ;
              uint64_t v862 = (uint64_t) v61;
              TASSIGN(v861, v862);
              pipe_barrier(PIPE_V);
              TROWSUM(v861, v857, v859);
              // pto: %sm_groups64_inline5419__ssa_v1
              ;
              Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v863 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v85);
              // pto: %sm_groups64_inline5419__ssa_v1
              ;
              uint64_t v864 = (uint64_t) v61;
              TASSIGN(v863, v864);
              // pto: %t__tmp_v973
              ;
              Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v865 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v85);
              // pto: %t__tmp_v973
              ;
              uint64_t v866 = (uint64_t) v43;
              TASSIGN(v865, v866);
              // pto: %sm_sum8_inline5421__ssa_v1
              ;
              Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v867 = Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v72);
              // pto: %sm_sum8_inline5421__ssa_v1
              ;
              uint64_t v868 = (uint64_t) v49;
              TASSIGN(v867, v868);
              pipe_barrier(PIPE_V);
              TROWSUM(v867, v863, v865);
              // pto: %sm_final8_inline5255__ssa_v1
              ;
              Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v869 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v85);
              // pto: %sm_final8_inline5255__ssa_v1
              ;
              uint64_t v870 = (uint64_t) v49;
              TASSIGN(v869, v870);
              // pto: %t__tmp_v974
              ;
              Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v871 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v85);
              // pto: %t__tmp_v974
              ;
              uint64_t v872 = (uint64_t) v43;
              TASSIGN(v871, v872);
              // pto: %sm_block_sum_inline5430__ssa_v2
              ;
              Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v873 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
              // pto: %sm_block_sum_inline5430__ssa_v2
              ;
              uint64_t v874 = (uint64_t) v62;
              TASSIGN(v873, v874);
              pipe_barrier(PIPE_V);
              TROWSUM(v873, v869, v871);
              // pto: %sm_block_sum_inline5430__ssa_v2_mv
              ;
              Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v875 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
              // pto: %sm_block_sum_inline5430__ssa_v2_mv
              ;
              uint64_t v876 = (uint64_t) v48;
              TASSIGN(v875, v876);
              pipe_barrier(PIPE_V);
              TMOV(v875, v873);
            };
          };
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
          // pto: %t__rm_a0_tmp_v12
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v877 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %t__rm_a0_tmp_v12
          ;
          uint64_t v878 = (uint64_t) v45;
          TASSIGN(v877, v878);
          // pto: %t__rm_a1_tmp_v13
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v879 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %t__rm_a1_tmp_v13
          ;
          uint64_t v880 = (uint64_t) v47;
          TASSIGN(v879, v880);
          // pto: %t__row_major_tmp_v14
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v881 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %t__row_major_tmp_v14
          ;
          uint64_t v882 = (uint64_t) v43;
          TASSIGN(v881, v882);
          pipe_barrier(PIPE_V);
          pipe_barrier(PIPE_ALL);
          TMUL(v881, v877, v879);
          // pto: %t__tmp_v975
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v883 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
          // pto: %t__tmp_v975
          ;
          uint64_t v884 = (uint64_t) v43;
          TASSIGN(v883, v884);
          // pto: %sm_sum_inline5329__rm_a0_tmp_v15
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v885 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %sm_sum_inline5329__rm_a0_tmp_v15
          ;
          uint64_t v886 = (uint64_t) v43;
          TASSIGN(v885, v886);
          // pto: %sm_sum_inline5329__rm_a1_tmp_v16
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v887 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %sm_sum_inline5329__rm_a1_tmp_v16
          ;
          uint64_t v888 = (uint64_t) v48;
          TASSIGN(v887, v888);
          // pto: %sm_sum_inline5329__row_major_tmp_v17
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v889 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %sm_sum_inline5329__row_major_tmp_v17
          ;
          uint64_t v890 = (uint64_t) v43;
          TASSIGN(v889, v890);
          pipe_barrier(PIPE_V);
          TADD(v889, v885, v887);
          // pto: %sm_sum_inline5329__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v891 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
          // pto: %sm_sum_inline5329__ssa_v0
          ;
          uint64_t v892 = (uint64_t) v43;
          TASSIGN(v891, v892);
          // pto: %sm_probability_inline5423__ssa_v0
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v893 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
          // pto: %sm_probability_inline5423__ssa_v0
          ;
          uint64_t v894 = (uint64_t) v38;
          TASSIGN(v893, v894);
          RoundMode v895 = RoundMode::CAST_ROUND;
          SaturationMode v896 = SaturationMode::ON;
          TCVT(v893, v659, v895, v896);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
          // pto: %probability_transfer_inline5166__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v897 = PTOAS__GLOBAL_TENSOR_DATA(v130);
          // pto: %probability_transfer_inline5166__ssa_v0_pview
          ;
          const int64_t v898 = 0;
          // pto: %probability_transfer_inline5166__ssa_v0_pview
          ;
          const int64_t v899 = 512;
          // pto: %probability_transfer_inline5166__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 8, 512> v900 = pto::Shape<1, 1, 1, 8, 512>();
          // pto: %probability_transfer_inline5166__ssa_v0_pview
          ;
          pto::Stride<4096, 4096, 4096, 512, 1> v901 = pto::Stride<4096, 4096, 4096, 512, 1>();
          // pto: %probability_transfer_inline5166__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<4096, 4096, 4096, 512, 1>, pto::Layout::ND> v902 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<4096, 4096, 4096, 512, 1>, pto::Layout::ND>(v897 + (v898 + v622 * v899), v900, v901);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
          TSTORE(v902, v893);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
          set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
          TSTORE(v627, v641);
          TSTORE(v634, v891);
          set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
          // pto: %alpha_transfer_inline5327__ssa_v0_pview
          ;
          __gm__ float* v903 = PTOAS__GLOBAL_TENSOR_DATA(v205);
          // pto: %alpha_transfer_inline5327__ssa_v0_pview
          ;
          const int64_t v904 = 0;
          // pto: %alpha_transfer_inline5327__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 8, 1> v905 = pto::Shape<1, 1, 1, 8, 1>();
          // pto: %alpha_transfer_inline5327__ssa_v0_pview
          ;
          pto::Stride<8, 8, 8, 1, 1536> v906 = pto::Stride<8, 8, 8, 1, 1536>();
          // pto: %alpha_transfer_inline5327__ssa_v0_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN> v907 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN>(v903 + (v904 + v622), v905, v906);
          TSTORE(v907, v655);
          set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
        };
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        uint16_t v908 = getFFTSMsg(FFTS_MODE_VAL, v89);
        ffts_cross_core_sync(PIPE_MTE3, v908);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        if (v378) {
          // pto: %357
          ;
          int64_t v909 = (int64_t) ((uint64_t) v325 + (uint64_t) v82);
          // pto: %359
          ;
          if (v909 < v24) {
            // pto: %361, %360
            ;
            int32_t v910 = (v4)[(int64_t) ((uint64_t) v909 * (uint64_t) v74)];
            // pto: %363, %364
            ;
            if ((int64_t) v910 > v83) {
              // pto: %365
              ;
              int32_t v911 = (v2)[v909];
              // pto: %366
              ;
              int64_t v912 = (int64_t) v911;
              // pto: %367
              ;
              int64_t v913 = v912 < v83 ? v83 : v912;
              // pto: %369, %370
              ;
              int64_t v914 = (int64_t) ((uint64_t) v374 + (uint64_t) v72) % v89;
              // pto: %371, %372, %373
              ;
              int64_t v915 = v914 < v83 ? (int64_t) ((uint64_t) v914 + (uint64_t) v89) : v914;
              set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
              for (int64_t v916 = v83; v916 < v90; v916 += v72) {
                // pto: %377
                ;
                if (v916 == v83) {
                  // pto: %379, %380
                  ;
                  int64_t v917 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v916 * (uint64_t) v81) + (uint64_t) v332);
                  // pto: %prefetch_kv_half_v1_inline5426__ssa_v0
                  ;
                  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v918 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                  // pto: %prefetch_kv_half_v1_inline5426__ssa_v0
                  ;
                  uint64_t v919 = (uint64_t) v38;
                  TASSIGN(v918, v919);
                  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
                  pipe_barrier(PIPE_V);
                  TEXPANDS(v918, v91);
                  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
                  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
                  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
                  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
                  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
                  // pto: %381
                  ;
                  int64_t v920 = (v12)[v909];
                  // pto: %385
                  ;
                  int64_t v921 = (int64_t) ((uint64_t) v920 + (uint64_t) v72);
                  // pto: %386
                  ;
                  int64_t v922 = v921 < v81 ? v921 : v81;
                  // pto: %387, %388
                  ;
                  int64_t v923 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v920 - (uint64_t) v922) + (uint64_t) v72);
                  // pto: %389
                  ;
                  int64_t v924 = v923 % v84;
                  // pto: %390, %391, %392
                  ;
                  int64_t v925 = v924 < v83 ? (int64_t) ((uint64_t) v924 + (uint64_t) v84) : v924;
                  // pto: %393
                  ;
                  int64_t v926 = (int64_t) ((uint64_t) v922 - (uint64_t) v917);
                  // pto: %394
                  ;
                  int64_t v927 = v926 < v83 ? v83 : v926;
                  // pto: %395
                  ;
                  int64_t v928 = v927 < v78 ? v927 : v78;
                  // pto: %396, %397
                  ;
                  int64_t v929 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v84 - (uint64_t) v925) - (uint64_t) v917);
                  // pto: %398
                  ;
                  int64_t v930 = v929 < v928 ? v929 : v928;
                  // pto: %399
                  ;
                  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                  if (v930 > v83) {
                    // pto: %400
                    ;
                    int64_t v931 = (int64_t) ((uint64_t) v923 + (uint64_t) v917);
                    // pto: %403, %404, %402, %prefetch_raw_page_inline5393__tile
                    ;
                    int32_t v932 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v913 * (uint64_t) v29) + (uint64_t) (v931 / v84))];
                    // pto: %405
                    ;
                    int64_t v933 = (int64_t) v932;
                    // pto: %406
                    ;
                    if (v933 >= v83) {
                      // pto: %409
                      ;
                      int64_t v934 = v931 % v84;
                      // pto: %410, %411, %412
                      ;
                      int64_t v935 = v934 < v83 ? (int64_t) ((uint64_t) v934 + (uint64_t) v84) : v934;
                      // pto: %408, %413
                      ;
                      int64_t v936 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v933 * (uint64_t) v84) + (uint64_t) v935);
                      // pto: %415
                      ;
                      Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v937 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v930);
                      // pto: %415
                      ;
                      uint64_t v938 = (uint64_t) v38;
                      TASSIGN(v937, v938);
                      // pto: %416
                      ;
                      int64_t v939 = v936 < v83 ? v83 : v936;
                      // pto: %417
                      ;
                      const int64_t v940 = 0;
                      // pto: %417
                      ;
                      __gm__ bfloat16_t* v941 = PTOAS__GLOBAL_TENSOR_DATA(v171);
                      // pto: %417
                      ;
                      const int64_t v942 = 1;
                      // pto: %417
                      ;
                      const int64_t v943 = 1;
                      // pto: %417
                      ;
                      const int64_t v944 = 1;
                      // pto: %417
                      ;
                      int64_t v945 = v930 * v73;
                      // pto: %417
                      ;
                      int64_t v946 = v944 * v945;
                      // pto: %417
                      ;
                      pto::Shape<1, 1, 1, -1, 512> v947 = pto::Shape<1, 1, 1, -1, 512>(v942, v943, v944, v930, v73);
                      // pto: %417
                      ;
                      pto::Stride<-1, -1, -1, -1, -1> v948 = pto::Stride<-1, -1, -1, -1, -1>(v943 * v946, v946, v945, v73, v72);
                      // pto: %417
                      ;
                      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v949 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v941 + (v940 + v939 * v73 + v83 * v72), v947, v948);
                      TLOAD(v937, v949);
                    };
                  };
                  set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID4);
                  // pto: %420
                  ;
                  int64_t v950 = v929 < v83 ? v83 : v929;
                  // pto: %421, %422
                  ;
                  int64_t v951 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v78 - (uint64_t) v925) - (uint64_t) v917);
                  // pto: %423
                  ;
                  int64_t v952 = v951 < v928 ? v951 : v928;
                  // pto: %424
                  ;
                  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
                  if (v950 < v952) {
                    // pto: %425, %426
                    ;
                    int64_t v953 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v923 + (uint64_t) v917) + (uint64_t) v950);
                    // pto: %429, %430, %428, %427
                    ;
                    int32_t v954 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v913 * (uint64_t) v29) + (uint64_t) (v953 / v84))];
                    // pto: %431
                    ;
                    int64_t v955 = (int64_t) v954;
                    // pto: %432
                    ;
                    if (v955 >= v83) {
                      // pto: %435
                      ;
                      int64_t v956 = v953 % v84;
                      // pto: %436, %437, %438
                      ;
                      int64_t v957 = v956 < v83 ? (int64_t) ((uint64_t) v956 + (uint64_t) v84) : v956;
                      // pto: %434, %439
                      ;
                      int64_t v958 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v955 * (uint64_t) v84) + (uint64_t) v957);
                      // pto: %440
                      ;
                      int64_t v959 = (int64_t) ((uint64_t) v952 - (uint64_t) v950);
                      // pto: %441
                      ;
                      Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v960 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v959);
                      // pto: %441
                      ;
                      uint64_t v961 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v950 * (uint64_t) v36) + (uint64_t) v38);
                      TASSIGN(v960, v961);
                      // pto: %442
                      ;
                      int64_t v962 = v958 < v83 ? v83 : v958;
                      // pto: %443
                      ;
                      const int64_t v963 = 0;
                      // pto: %443
                      ;
                      __gm__ bfloat16_t* v964 = PTOAS__GLOBAL_TENSOR_DATA(v171);
                      // pto: %443
                      ;
                      const int64_t v965 = 1;
                      // pto: %443
                      ;
                      const int64_t v966 = 1;
                      // pto: %443
                      ;
                      const int64_t v967 = 1;
                      // pto: %443
                      ;
                      int64_t v968 = v959 * v73;
                      // pto: %443
                      ;
                      int64_t v969 = v967 * v968;
                      // pto: %443
                      ;
                      pto::Shape<1, 1, 1, -1, 512> v970 = pto::Shape<1, 1, 1, -1, 512>(v965, v966, v967, v959, v73);
                      // pto: %443
                      ;
                      pto::Stride<-1, -1, -1, -1, -1> v971 = pto::Stride<-1, -1, -1, -1, -1>(v966 * v969, v969, v968, v73, v72);
                      // pto: %443
                      ;
                      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v972 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v964 + (v963 + v962 * v73 + v83 * v72), v970, v971);
                      TLOAD(v960, v972);
                    };
                  };
                  set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID3);
                  // pto: %446
                  ;
                  int64_t v973 = v951 < v83 ? v83 : v951;
                  // pto: %447, %448
                  ;
                  int64_t v974 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v92 - (uint64_t) v925) - (uint64_t) v917);
                  // pto: %449
                  ;
                  int64_t v975 = v974 < v928 ? v974 : v928;
                  // pto: %450
                  ;
                  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
                  if (v973 < v975) {
                    // pto: %451, %452
                    ;
                    int64_t v976 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v923 + (uint64_t) v917) + (uint64_t) v973);
                    // pto: %455, %456, %454, %453
                    ;
                    int32_t v977 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v913 * (uint64_t) v29) + (uint64_t) (v976 / v84))];
                    // pto: %457
                    ;
                    int64_t v978 = (int64_t) v977;
                    // pto: %458
                    ;
                    if (v978 >= v83) {
                      // pto: %461
                      ;
                      int64_t v979 = v976 % v84;
                      // pto: %462, %463, %464
                      ;
                      int64_t v980 = v979 < v83 ? (int64_t) ((uint64_t) v979 + (uint64_t) v84) : v979;
                      // pto: %460, %465
                      ;
                      int64_t v981 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v978 * (uint64_t) v84) + (uint64_t) v980);
                      // pto: %466
                      ;
                      int64_t v982 = (int64_t) ((uint64_t) v975 - (uint64_t) v973);
                      // pto: %467
                      ;
                      Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v983 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v982);
                      // pto: %467
                      ;
                      uint64_t v984 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v973 * (uint64_t) v36) + (uint64_t) v38);
                      TASSIGN(v983, v984);
                      // pto: %468
                      ;
                      int64_t v985 = v981 < v83 ? v83 : v981;
                      // pto: %469
                      ;
                      const int64_t v986 = 0;
                      // pto: %469
                      ;
                      __gm__ bfloat16_t* v987 = PTOAS__GLOBAL_TENSOR_DATA(v171);
                      // pto: %469
                      ;
                      const int64_t v988 = 1;
                      // pto: %469
                      ;
                      const int64_t v989 = 1;
                      // pto: %469
                      ;
                      const int64_t v990 = 1;
                      // pto: %469
                      ;
                      int64_t v991 = v982 * v73;
                      // pto: %469
                      ;
                      int64_t v992 = v990 * v991;
                      // pto: %469
                      ;
                      pto::Shape<1, 1, 1, -1, 512> v993 = pto::Shape<1, 1, 1, -1, 512>(v988, v989, v990, v982, v73);
                      // pto: %469
                      ;
                      pto::Stride<-1, -1, -1, -1, -1> v994 = pto::Stride<-1, -1, -1, -1, -1>(v989 * v992, v992, v991, v73, v72);
                      // pto: %469
                      ;
                      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v995 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v987 + (v986 + v985 * v73 + v83 * v72), v993, v994);
                      TLOAD(v983, v995);
                    };
                  };
                  set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
                  // pto: %472
                  ;
                  int64_t v996 = v974 < v83 ? v83 : v974;
                  // pto: %473, %474
                  ;
                  int64_t v997 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v81 - (uint64_t) v925) - (uint64_t) v917);
                  // pto: %475
                  ;
                  int64_t v998 = v997 < v928 ? v997 : v928;
                  // pto: %476
                  ;
                  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
                  if (v996 < v998) {
                    // pto: %477, %478
                    ;
                    int64_t v999 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v923 + (uint64_t) v917) + (uint64_t) v996);
                    // pto: %481, %482, %480, %479
                    ;
                    int32_t v1000 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v913 * (uint64_t) v29) + (uint64_t) (v999 / v84))];
                    // pto: %483
                    ;
                    int64_t v1001 = (int64_t) v1000;
                    // pto: %484
                    ;
                    if (v1001 >= v83) {
                      // pto: %487
                      ;
                      int64_t v1002 = v999 % v84;
                      // pto: %488, %489, %490
                      ;
                      int64_t v1003 = v1002 < v83 ? (int64_t) ((uint64_t) v1002 + (uint64_t) v84) : v1002;
                      // pto: %486, %491
                      ;
                      int64_t v1004 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v1001 * (uint64_t) v84) + (uint64_t) v1003);
                      // pto: %492
                      ;
                      int64_t v1005 = (int64_t) ((uint64_t) v998 - (uint64_t) v996);
                      // pto: %493
                      ;
                      Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1006 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1005);
                      // pto: %493
                      ;
                      uint64_t v1007 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v996 * (uint64_t) v36) + (uint64_t) v38);
                      TASSIGN(v1006, v1007);
                      // pto: %494
                      ;
                      int64_t v1008 = v1004 < v83 ? v83 : v1004;
                      // pto: %495
                      ;
                      const int64_t v1009 = 0;
                      // pto: %495
                      ;
                      __gm__ bfloat16_t* v1010 = PTOAS__GLOBAL_TENSOR_DATA(v171);
                      // pto: %495
                      ;
                      const int64_t v1011 = 1;
                      // pto: %495
                      ;
                      const int64_t v1012 = 1;
                      // pto: %495
                      ;
                      const int64_t v1013 = 1;
                      // pto: %495
                      ;
                      int64_t v1014 = v1005 * v73;
                      // pto: %495
                      ;
                      int64_t v1015 = v1013 * v1014;
                      // pto: %495
                      ;
                      pto::Shape<1, 1, 1, -1, 512> v1016 = pto::Shape<1, 1, 1, -1, 512>(v1011, v1012, v1013, v1005, v73);
                      // pto: %495
                      ;
                      pto::Stride<-1, -1, -1, -1, -1> v1017 = pto::Stride<-1, -1, -1, -1, -1>(v1012 * v1015, v1015, v1014, v73, v72);
                      // pto: %495
                      ;
                      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1018 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1010 + (v1009 + v1008 * v73 + v83 * v72), v1016, v1017);
                      TLOAD(v1006, v1018);
                    };
                  };
                  set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
                  // pto: %498
                  ;
                  int64_t v1019 = v997 < v83 ? v83 : v997;
                  // pto: %499, %500
                  ;
                  int64_t v1020 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v93 - (uint64_t) v925) - (uint64_t) v917);
                  // pto: %501
                  ;
                  int64_t v1021 = v1020 < v928 ? v1020 : v928;
                  // pto: %502
                  ;
                  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
                  if (v1019 < v1021) {
                    // pto: %503, %504
                    ;
                    int64_t v1022 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v923 + (uint64_t) v917) + (uint64_t) v1019);
                    // pto: %507, %508, %506, %505
                    ;
                    int32_t v1023 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v913 * (uint64_t) v29) + (uint64_t) (v1022 / v84))];
                    // pto: %509
                    ;
                    int64_t v1024 = (int64_t) v1023;
                    // pto: %510
                    ;
                    if (v1024 >= v83) {
                      // pto: %513
                      ;
                      int64_t v1025 = v1022 % v84;
                      // pto: %514, %515, %516
                      ;
                      int64_t v1026 = v1025 < v83 ? (int64_t) ((uint64_t) v1025 + (uint64_t) v84) : v1025;
                      // pto: %512, %517
                      ;
                      int64_t v1027 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v1024 * (uint64_t) v84) + (uint64_t) v1026);
                      // pto: %518
                      ;
                      int64_t v1028 = (int64_t) ((uint64_t) v1021 - (uint64_t) v1019);
                      // pto: %519
                      ;
                      Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1029 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1028);
                      // pto: %519
                      ;
                      uint64_t v1030 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v1019 * (uint64_t) v36) + (uint64_t) v38);
                      TASSIGN(v1029, v1030);
                      // pto: %520
                      ;
                      int64_t v1031 = v1027 < v83 ? v83 : v1027;
                      // pto: %521
                      ;
                      const int64_t v1032 = 0;
                      // pto: %521
                      ;
                      __gm__ bfloat16_t* v1033 = PTOAS__GLOBAL_TENSOR_DATA(v171);
                      // pto: %521
                      ;
                      const int64_t v1034 = 1;
                      // pto: %521
                      ;
                      const int64_t v1035 = 1;
                      // pto: %521
                      ;
                      const int64_t v1036 = 1;
                      // pto: %521
                      ;
                      int64_t v1037 = v1028 * v73;
                      // pto: %521
                      ;
                      int64_t v1038 = v1036 * v1037;
                      // pto: %521
                      ;
                      pto::Shape<1, 1, 1, -1, 512> v1039 = pto::Shape<1, 1, 1, -1, 512>(v1034, v1035, v1036, v1028, v73);
                      // pto: %521
                      ;
                      pto::Stride<-1, -1, -1, -1, -1> v1040 = pto::Stride<-1, -1, -1, -1, -1>(v1035 * v1038, v1038, v1037, v73, v72);
                      // pto: %521
                      ;
                      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1041 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1033 + (v1032 + v1031 * v73 + v83 * v72), v1039, v1040);
                      TLOAD(v1029, v1041);
                    };
                  };
                  set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
                  // pto: %374, %375, %522
                  ;
                  int64_t v1042 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v375 + (uint64_t) v915) * (uint64_t) v73) + (uint64_t) v917);
                  // pto: %523
                  ;
                  int64_t v1043 = v1042 < v83 ? v83 : v1042;
                  // pto: %524
                  ;
                  __gm__ bfloat16_t* v1044 = PTOAS__GLOBAL_TENSOR_DATA(v114);
                  // pto: %524
                  ;
                  const int64_t v1045 = 0;
                  // pto: %524
                  ;
                  const int64_t v1046 = 512;
                  // pto: %524
                  ;
                  pto::Shape<1, 1, 1, 64, 512> v1047 = pto::Shape<1, 1, 1, 64, 512>();
                  // pto: %524
                  ;
                  pto::Stride<32768, 32768, 32768, 512, 1> v1048 = pto::Stride<32768, 32768, 32768, 512, 1>();
                  // pto: %524
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v1049 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v1044 + (v1045 + v1043 * v1046), v1047, v1048);
                  wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
                  wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
                  wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
                  wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID3);
                  wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID4);
                  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
                  TSTORE(v1049, v319);
                  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
                };
              };
              wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
              uint16_t v1050 = getFFTSMsg(FFTS_MODE_VAL, v83);
              ffts_cross_core_sync(PIPE_MTE3, v1050);
            };
          };
        };
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        int32_t v1051 = (int32_t) v100;
        wait_flag_dev(v1051);
        // pto: %alpha_inline5298__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1052 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v72);
        // pto: %alpha_inline5298__ssa_v0
        ;
        uint64_t v1053 = (uint64_t) v63;
        TASSIGN(v1052, v1053);
        // pto: %527
        ;
        __gm__ float* v1054 = PTOAS__GLOBAL_TENSOR_DATA(v205);
        // pto: %527
        ;
        const int64_t v1055 = 0;
        // pto: %527
        ;
        pto::Shape<1, 1, 1, 32, 1> v1056 = pto::Shape<1, 1, 1, 32, 1>();
        // pto: %527
        ;
        pto::Stride<32, 32, 32, 1, 1536> v1057 = pto::Stride<32, 32, 32, 1, 1536>();
        // pto: %527
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN> v1058 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN>(v1054 + (v1055 + v360), v1056, v1057);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        TLOAD(v1052, v1058);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %pv_left_inline5300__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1059 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v88);
        // pto: %pv_left_inline5300__ssa_v0
        ;
        uint64_t v1060 = (uint64_t) v38;
        TASSIGN(v1059, v1060);
        // pto: %pv_transfer_inline5179__ssa_v0_pview
        ;
        __gm__ float* v1061 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %pv_transfer_inline5179__ssa_v0_pview
        ;
        const int64_t v1062 = 0;
        // pto: %pv_transfer_inline5179__ssa_v0_pview
        ;
        const int64_t v1063 = 512;
        // pto: %pv_transfer_inline5179__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 32, 256> v1064 = pto::Shape<1, 1, 1, 32, 256>();
        // pto: %pv_transfer_inline5179__ssa_v0_pview
        ;
        pto::Stride<16384, 16384, 16384, 512, 1> v1065 = pto::Stride<16384, 16384, 16384, 512, 1>();
        // pto: %pv_transfer_inline5179__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v1066 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v1061 + (v1062 + v360 * v1063), v1064, v1065);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        TLOAD(v1059, v1066);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %t__tmp_v980
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1067 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v88);
        // pto: %t__tmp_v980
        ;
        uint64_t v1068 = (uint64_t) v61;
        TASSIGN(v1067, v1068);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v1067, v355, v1052);
        // pto: %next_left_inline5161__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1069 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v88);
        // pto: %next_left_inline5161__ssa_v0
        ;
        uint64_t v1070 = (uint64_t) v40;
        TASSIGN(v1069, v1070);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        TADD(v1069, v1067, v1059);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        // pto: %pv_right_inline5310__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1071 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v88);
        // pto: %pv_right_inline5310__ssa_v0
        ;
        uint64_t v1072 = (uint64_t) v38;
        TASSIGN(v1071, v1072);
        // pto: %530
        ;
        __gm__ float* v1073 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %530
        ;
        const int64_t v1074 = 256;
        // pto: %530
        ;
        const int64_t v1075 = 512;
        // pto: %530
        ;
        pto::Shape<1, 1, 1, 32, 256> v1076 = pto::Shape<1, 1, 1, 32, 256>();
        // pto: %530
        ;
        pto::Stride<16384, 16384, 16384, 512, 1> v1077 = pto::Stride<16384, 16384, 16384, 512, 1>();
        // pto: %530
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v1078 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v1073 + (v1074 + v360 * v1075), v1076, v1077);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        TLOAD(v1071, v1078);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %t__tmp_v981
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1079 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v88);
        // pto: %t__tmp_v981
        ;
        uint64_t v1080 = (uint64_t) v61;
        TASSIGN(v1079, v1080);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v1079, v357, v1052);
        // pto: %next_right_inline5157__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1081 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v88);
        // pto: %next_right_inline5157__ssa_v0
        ;
        uint64_t v1082 = (uint64_t) v41;
        TASSIGN(v1081, v1082);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        TADD(v1081, v1079, v1071);
      };
    };
    // pto: %531
    ;
    int32_t v1083 = (v2)[v325];
    // pto: %532, %533
    ;
    pipe_barrier(PIPE_ALL);
    if ((int64_t) v1083 >= v83) {
      // pto: %cs_ones_inline5246__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1084 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %cs_ones_inline5246__ssa_v0
      ;
      uint64_t v1085 = (uint64_t) v56;
      TASSIGN(v1084, v1085);
      pipe_barrier(PIPE_V);
      TEXPANDS(v1084, v87);
      // pto: %t__ci_tmp_v1
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1086 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v96);
      // pto: %t__ci_tmp_v1
      ;
      uint64_t v1087 = (uint64_t) v38;
      TASSIGN(v1086, v1087);
      // pto: %t__tmp_v983
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1088 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %t__tmp_v983
      ;
      uint64_t v1089 = (uint64_t) v57;
      TASSIGN(v1088, v1089);
      // pto: %534
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1090;
      TRESHAPE(v1090, v1086);
      // pto: %535
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1091;
      TRESHAPE(v1091, v1088);
      TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v1091, v97, v1090);
      // pto: %cs_idx_f_inline5156__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1092 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %cs_idx_f_inline5156__ssa_v0
      ;
      uint64_t v1093 = (uint64_t) v38;
      TASSIGN(v1092, v1093);
      pipe_barrier(PIPE_V);
      RoundMode v1094 = RoundMode::CAST_ROUND;
      SaturationMode v1095 = SaturationMode::ON;
      TCVT(v1092, v1088, v1094, v1095);
      // pto: %cs_col_inline5155__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1096 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %cs_col_inline5155__ssa_v0
      ;
      uint64_t v1097 = (uint64_t) v51;
      TASSIGN(v1096, v1097);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v1096, v1084, v1092);
      // pto: %t__tmp_v984
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1098 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %t__tmp_v984
      ;
      uint64_t v1099 = (uint64_t) v38;
      TASSIGN(v1098, v1099);
      pipe_barrier(PIPE_V);
      TMULS(v1098, v1096, v101);
      // pto: %cs_dup_i32_inline5345__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1100 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %cs_dup_i32_inline5345__ssa_v0
      ;
      uint64_t v1101 = (uint64_t) v38;
      TASSIGN(v1100, v1101);
      pipe_barrier(PIPE_V);
      RoundMode v1102 = RoundMode::CAST_TRUNC;
      SaturationMode v1103 = SaturationMode::ON;
      TCVT(v1100, v1098, v1102, v1103);
      // pto: %cs_dup_f_inline5154__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1104 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %cs_dup_f_inline5154__ssa_v0
      ;
      uint64_t v1105 = (uint64_t) v38;
      TASSIGN(v1104, v1105);
      pipe_barrier(PIPE_V);
      RoundMode v1106 = RoundMode::CAST_ROUND;
      SaturationMode v1107 = SaturationMode::ON;
      TCVT(v1104, v1100, v1106, v1107);
      // pto: %t__tmp_v985
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1108 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %t__tmp_v985
      ;
      uint64_t v1109 = (uint64_t) v38;
      TASSIGN(v1108, v1109);
      pipe_barrier(PIPE_V);
      TMULS(v1108, v1104, v102);
      // pto: %cs_lane_inline5171__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1110 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %cs_lane_inline5171__ssa_v0
      ;
      uint64_t v1111 = (uint64_t) v38;
      TASSIGN(v1110, v1111);
      pipe_barrier(PIPE_V);
      TSUB(v1110, v1096, v1108);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      // pto: %t__tmp_v986
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1112 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %t__tmp_v986
      ;
      uint64_t v1113 = (uint64_t) v38;
      TASSIGN(v1112, v1113);
      pipe_barrier(PIPE_V);
      TMULS(v1112, v1110, v102);
      // pto: %t__tmp_v987
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1114 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %t__tmp_v987
      ;
      uint64_t v1115 = (uint64_t) v38;
      TASSIGN(v1114, v1115);
      pipe_barrier(PIPE_V);
      TSUBS(v1114, v1112, v87);
      // pto: %cs_sign_inline5390__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1116 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %cs_sign_inline5390__ssa_v0
      ;
      uint64_t v1117 = (uint64_t) v38;
      TASSIGN(v1116, v1117);
      pipe_barrier(PIPE_V);
      TNEG(v1116, v1114);
      // pto: %cs_sin_inline5289__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1118 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %cs_sin_inline5289__ssa_v0
      ;
      uint64_t v1119 = (uint64_t) v51;
      TASSIGN(v1118, v1119);
      // pto: %536
      ;
      int64_t v1120 = v325 < v83 ? v83 : v325;
      // pto: %freqs_sin__ssa_v0_pview
      ;
      __gm__ float* v1121 = PTOAS__GLOBAL_TENSOR_DATA(v214);
      // pto: %freqs_sin__ssa_v0_pview
      ;
      const int64_t v1122 = 0;
      // pto: %freqs_sin__ssa_v0_pview
      ;
      const int64_t v1123 = 64;
      // pto: %freqs_sin__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 64> v1124 = pto::Shape<1, 1, 1, 1, 64>();
      // pto: %freqs_sin__ssa_v0_pview
      ;
      pto::Stride<64, 64, 64, 64, 1> v1125 = pto::Stride<64, 64, 64, 64, 1>();
      // pto: %freqs_sin__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v1126 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v1121 + (v1122 + v1120 * v1123), v1124, v1125);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      TLOAD(v1118, v1126);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %m_sin_signed_inline5427__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1127 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %m_sin_signed_inline5427__ssa_v0
      ;
      uint64_t v1128 = (uint64_t) v64;
      TASSIGN(v1127, v1128);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      pipe_barrier(PIPE_V);
      TMUL(v1127, v1118, v1116);
      // pto: %m_cos_il_inline5153__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1129 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %m_cos_il_inline5153__ssa_v0
      ;
      uint64_t v1130 = (uint64_t) v65;
      TASSIGN(v1129, v1130);
      // pto: %freqs_cos__ssa_v0_pview
      ;
      __gm__ float* v1131 = PTOAS__GLOBAL_TENSOR_DATA(v223);
      // pto: %freqs_cos__ssa_v0_pview
      ;
      const int64_t v1132 = 0;
      // pto: %freqs_cos__ssa_v0_pview
      ;
      const int64_t v1133 = 64;
      // pto: %freqs_cos__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 64> v1134 = pto::Shape<1, 1, 1, 1, 64>();
      // pto: %freqs_cos__ssa_v0_pview
      ;
      pto::Stride<64, 64, 64, 64, 1> v1135 = pto::Stride<64, 64, 64, 64, 1>();
      // pto: %freqs_cos__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v1136 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v1131 + (v1132 + v1120 * v1133), v1134, v1135);
      TLOAD(v1129, v1136);
      // pto: %m_idx_inline5152__ci_tmp_v2
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1137 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v96);
      // pto: %m_idx_inline5152__ci_tmp_v2
      ;
      uint64_t v1138 = (uint64_t) v38;
      TASSIGN(v1137, v1138);
      // pto: %m_idx_inline5152__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1139 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %m_idx_inline5152__ssa_v0
      ;
      uint64_t v1140 = (uint64_t) v56;
      TASSIGN(v1139, v1140);
      // pto: %538
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1141;
      TRESHAPE(v1141, v1137);
      // pto: %539
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1142;
      TRESHAPE(v1142, v1139);
      pipe_barrier(PIPE_V);
      TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v1142, v97, v1141);
      // pto: %m_rem_tmp_inline5406__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1143 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %m_rem_tmp_inline5406__ssa_v0
      ;
      uint64_t v1144 = (uint64_t) v38;
      TASSIGN(v1143, v1144);
      // pto: %m_lane_inline5151__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1145 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %m_lane_inline5151__ssa_v0
      ;
      uint64_t v1146 = (uint64_t) v51;
      TASSIGN(v1145, v1146);
      pipe_barrier(PIPE_V);
      TREMS(v1145, v1139, v103, v1143);
      // pto: %t__tmp_v988
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1147 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %t__tmp_v988
      ;
      uint64_t v1148 = (uint64_t) v38;
      TASSIGN(v1147, v1148);
      pipe_barrier(PIPE_V);
      TMULS(v1147, v1145, v103);
      // pto: %t__tmp_v989
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1149 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %t__tmp_v989
      ;
      uint64_t v1150 = (uint64_t) v38;
      TASSIGN(v1149, v1150);
      pipe_barrier(PIPE_V);
      TSUB(v1149, v1139, v1147);
      // pto: %m_swap_row_inline5150__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1151 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %m_swap_row_inline5150__ssa_v0
      ;
      uint64_t v1152 = (uint64_t) v66;
      TASSIGN(v1151, v1152);
      pipe_barrier(PIPE_V);
      TADDS(v1151, v1149, v104);
      // pto: %m_swap_base_inline5149__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1153 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
      // pto: %m_swap_base_inline5149__ssa_v0
      ;
      uint64_t v1154 = (uint64_t) v38;
      TASSIGN(v1153, v1154);
      // pto: %m_swap_source_inline5148__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1155 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
      // pto: %m_swap_source_inline5148__ssa_v0
      ;
      uint64_t v1156 = (uint64_t) v38;
      TASSIGN(v1155, v1156);
      pipe_barrier(PIPE_V);
      TCOLEXPAND(v1155, v1151);
      // pto: %t__ci_tmp_v3
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1157 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v96);
      // pto: %t__ci_tmp_v3
      ;
      uint64_t v1158 = (uint64_t) v66;
      TASSIGN(v1157, v1158);
      // pto: %t__tmp_v990
      ;
      Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1159 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
      // pto: %t__tmp_v990
      ;
      uint64_t v1160 = (uint64_t) v67;
      TASSIGN(v1159, v1160);
      // pto: %540
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1161;
      TRESHAPE(v1161, v1157);
      // pto: %541
      ;
      Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1162;
      TRESHAPE(v1162, v1159);
      pipe_barrier(PIPE_V);
      TCI<Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v1162, v97, v1161);
      // pto: %m_row_offsets_inline5221__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1163 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
      // pto: %m_row_offsets_inline5221__ssa_v0
      ;
      uint64_t v1164 = (uint64_t) v66;
      TASSIGN(v1163, v1164);
      pipe_barrier(PIPE_V);
      TMULS(v1163, v1159, v105);
      // pto: %t__tmp_v991
      ;
      Tile<TileType::Vec, int32_t, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1165 = Tile<TileType::Vec, int32_t, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
      // pto: %t__tmp_v991
      ;
      uint64_t v1166 = (uint64_t) v66;
      TASSIGN(v1165, v1166);
      // pto: %m_swap_idx_inline5320__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1167 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
      // pto: %m_swap_idx_inline5320__ssa_v0
      ;
      uint64_t v1168 = (uint64_t) v61;
      TASSIGN(v1167, v1168);
      pipe_barrier(PIPE_V);
      TROWEXPANDADD(v1167, v1155, v1165);
      // pto: %m_gather_tmp_inline5147__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1169 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
      // pto: %m_gather_tmp_inline5147__ssa_v0
      ;
      uint64_t v1170 = (uint64_t) v45;
      TASSIGN(v1169, v1170);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      for (int64_t v1171 = v83; v1171 < v90; v1171 += v72) {
        // pto: %542
        ;
        int64_t v1172 = (int64_t) ((uint64_t) v1171 * (uint64_t) v85);
        // pto: %m_li_inline5425__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1173 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
        // pto: %m_li_inline5425__ssa_v0
        ;
        uint64_t v1174 = (uint64_t) v68;
        TASSIGN(v1173, v1174);
        // pto: %544
        ;
        int64_t v1175 = (int64_t) ((uint64_t) v359 + (uint64_t) v1172);
        // pto: %545
        ;
        int64_t v1176 = v1175 < v83 ? v83 : v1175;
        // pto: %546
        ;
        __gm__ float* v1177 = PTOAS__GLOBAL_TENSOR_DATA(v162);
        // pto: %546
        ;
        const int64_t v1178 = 0;
        // pto: %546
        ;
        pto::Shape<1, 1, 1, 8, 1> v1179 = pto::Shape<1, 1, 1, 8, 1>();
        // pto: %546
        ;
        pto::Stride<8, 8, 8, 1, 1536> v1180 = pto::Stride<8, 8, 8, 1, 1536>();
        // pto: %546
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN> v1181 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN>(v1177 + (v1178 + v1176), v1179, v1180);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        TLOAD(v1173, v1181);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %publish_left_inline5232__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1182 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v88);
        // pto: %publish_left_inline5232__ssa_v0
        ;
        uint64_t v1183 = (uint64_t) v43;
        TASSIGN(v1182, v1183);
        pipe_barrier(PIPE_V);
        uint16_t v1184 = static_cast<uint16_t>(v1172);
        uint16_t v1185 = static_cast<uint16_t>(v83);
        TEXTRACT(v1182, v355, v1184, v1185);
        // pto: %publish_right_inline5357__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1186 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v88);
        // pto: %publish_right_inline5357__ssa_v0
        ;
        uint64_t v1187 = (uint64_t) v69;
        TASSIGN(v1186, v1187);
        uint16_t v1188 = static_cast<uint16_t>(v1172);
        uint16_t v1189 = static_cast<uint16_t>(v83);
        TEXTRACT(v1186, v357, v1188, v1189);
        // pto: %m_oi_inline5145__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1190 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
        // pto: %m_oi_inline5145__ssa_v0
        ;
        uint64_t v1191 = (uint64_t) v38;
        TASSIGN(v1190, v1191);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        TCONCAT(v1190, v1182, v1186);
        // pto: %n_full_inline5204__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1192 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
        // pto: %n_full_inline5204__ssa_v0
        ;
        uint64_t v1193 = (uint64_t) v38;
        TASSIGN(v1192, v1193);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        TROWEXPANDDIV(v1192, v1190, v1173);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        // pto: %n_bf16_inline5238__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1194 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
        // pto: %n_bf16_inline5238__ssa_v0
        ;
        uint64_t v1195 = (uint64_t) v43;
        TASSIGN(v1194, v1195);
        pipe_barrier(PIPE_V);
        RoundMode v1196 = RoundMode::CAST_RINT;
        SaturationMode v1197 = SaturationMode::ON;
        TCVT(v1194, v1192, v1196, v1197);
        // pto: %n_rounded_inline5144__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1198 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
        // pto: %n_rounded_inline5144__ssa_v0
        ;
        uint64_t v1199 = (uint64_t) v38;
        TASSIGN(v1198, v1199);
        pipe_barrier(PIPE_V);
        RoundMode v1200 = RoundMode::CAST_ROUND;
        SaturationMode v1201 = SaturationMode::ON;
        TCVT(v1198, v1194, v1200, v1201);
        // pto: %m_swapped_inline5309__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1202 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
        // pto: %m_swapped_inline5309__ssa_v0
        ;
        uint64_t v1203 = (uint64_t) v69;
        TASSIGN(v1202, v1203);
        pipe_barrier(PIPE_V);
        TGATHER(v1202, v1198, v1167, v1169);
        // pto: %m_rope_inline5178__ssa_v0_textract
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1204 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
        // pto: %m_rope_inline5178__ssa_v0_textract
        ;
        uint64_t v1205 = (uint64_t) v70;
        TASSIGN(v1204, v1205);
        uint16_t v1206 = static_cast<uint16_t>(v83);
        uint16_t v1207 = static_cast<uint16_t>(v99);
        TEXTRACT(v1204, v1198, v1206, v1207);
        // pto: %t__tmp_v992
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1208 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
        // pto: %t__tmp_v992
        ;
        uint64_t v1209 = (uint64_t) v38;
        TASSIGN(v1208, v1209);
        pipe_barrier(PIPE_V);
        TCOLEXPANDMUL(v1208, v1204, v1129);
        // pto: %t__tmp_v993
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1210 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
        // pto: %t__tmp_v993
        ;
        uint64_t v1211 = (uint64_t) v66;
        TASSIGN(v1210, v1211);
        TCOLEXPANDMUL(v1210, v1202, v1127);
        // pto: %m_rot_inline5143__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1212 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
        // pto: %m_rot_inline5143__ssa_v0
        ;
        uint64_t v1213 = (uint64_t) v38;
        TASSIGN(v1212, v1213);
        pipe_barrier(PIPE_V);
        TADD(v1212, v1208, v1210);
        // pto: %n_rope_bf16_inline5332__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1214 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
        // pto: %n_rope_bf16_inline5332__ssa_v0
        ;
        uint64_t v1215 = (uint64_t) v71;
        TASSIGN(v1214, v1215);
        pipe_barrier(PIPE_V);
        RoundMode v1216 = RoundMode::CAST_RINT;
        SaturationMode v1217 = SaturationMode::ON;
        TCVT(v1214, v1212, v1216, v1217);
        // pto: %t__tmp_v994
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1218 = Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v99);
        // pto: %t__tmp_v994
        ;
        uint64_t v1219 = (uint64_t) v43;
        TASSIGN(v1218, v1219);
        // pto: %547
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, 8, 448, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1220;
        // pto: %547
        ;
        uint64_t v1221 = (uint64_t) v43;
        TASSIGN(v1220, v1221);
        // pto: %n_full_bf16_inline5142__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1222 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
        // pto: %n_full_bf16_inline5142__ssa_v0
        ;
        uint64_t v1223 = (uint64_t) v38;
        TASSIGN(v1222, v1223);
        pipe_barrier(PIPE_V);
        TCONCAT(v1222, v1220, v1214);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        // pto: %publish_row_inline5141__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1224 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v106);
        // pto: %publish_row_inline5141__ssa_v0
        ;
        uint64_t v1225 = (uint64_t) v38;
        TASSIGN(v1224, v1225);
        // pto: %549, %550
        ;
        int64_t v1226 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v331 + (uint64_t) v1172) * (uint64_t) v73);
        // pto: %551
        ;
        int64_t v1227 = v1226 < v83 ? v83 : v1226;
        // pto: %heads__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v1228 = PTOAS__GLOBAL_TENSOR_DATA(v232);
        // pto: %heads__ssa_v0_pview
        ;
        const int64_t v1229 = 0;
        // pto: %heads__ssa_v0_pview
        ;
        const int64_t v1230 = 32768;
        // pto: %heads__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1231 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %heads__ssa_v0_pview
        ;
        pto::Stride<32768, 32768, 32768, 32768, 1> v1232 = pto::Stride<32768, 32768, 32768, 32768, 1>();
        // pto: %heads__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<32768, 32768, 32768, 32768, 1>, pto::Layout::ND> v1233 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<32768, 32768, 32768, 32768, 1>, pto::Layout::ND>(v1228 + (v1229 + v1120 * v1230 + v1227), v1231, v1232);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        TSTORE(v1233, v1224);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      };
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    } else {
      // pto: %publish_zero_inline5378__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1234 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v106);
      // pto: %publish_zero_inline5378__ssa_v0
      ;
      uint64_t v1235 = (uint64_t) v38;
      TASSIGN(v1234, v1235);
      pipe_barrier(PIPE_V);
      TEXPANDS(v1234, v91);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      for (int64_t v1236 = v83; v1236 < v90; v1236 += v72) {
        // pto: %552
        ;
        int64_t v1237 = v325 < v83 ? v83 : v325;
        // pto: %554, %553, %555
        ;
        int64_t v1238 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v331 + (uint64_t) ((int64_t) (uint64_t) v1236 * (uint64_t) v85)) * (uint64_t) v73);
        // pto: %556
        ;
        int64_t v1239 = v1238 < v83 ? v83 : v1238;
        // pto: %557
        ;
        __gm__ bfloat16_t* v1240 = PTOAS__GLOBAL_TENSOR_DATA(v232);
        // pto: %557
        ;
        const int64_t v1241 = 0;
        // pto: %557
        ;
        const int64_t v1242 = 32768;
        // pto: %557
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1243 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %557
        ;
        pto::Stride<32768, 32768, 32768, 32768, 1> v1244 = pto::Stride<32768, 32768, 32768, 32768, 1>();
        // pto: %557
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<32768, 32768, 32768, 32768, 1>, pto::Layout::ND> v1245 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<32768, 32768, 32768, 32768, 1>, pto::Layout::ND>(v1240 + (v1241 + v1237 * v1242 + v1239), v1243, v1244);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v1245, v1234);
      };
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}