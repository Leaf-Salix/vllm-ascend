#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void kv_and_cache_write(__gm__ float* v1, __gm__ float* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ int64_t* v6, __gm__ int32_t* v7, __gm__ int32_t* v8, __gm__ int32_t* v9, int64_t v10, int64_t v11, int64_t v12, int64_t v13, int64_t v14, int64_t v15, int64_t v16, int32_t v17, int32_t v18) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v19 = 512;
  const int64_t v20 = 128;
  // pto: %c16448_i64
  const int64_t v21 = 16448;
  // pto: %c0_i64
  const int64_t v22 = 0;
  // pto: %c8192_i64
  const int64_t v23 = 8192;
  // pto: %c16384_i64
  const int64_t v24 = 16384;
  // pto: %c384_index
  const int64_t v25 = 384;
  // pto: %c128_index
  const int64_t v26 = 128;
  // pto: %c1_index
  const int64_t v27 = 1;
  // pto: %c2_index
  const int64_t v28 = 2;
  // pto: %c16_index
  const int64_t v29 = 16;
  // pto: %c0_index
  const int64_t v30 = 0;
  // pto: %cst_10
  const float v31 = 0.0883883461f;
  // pto: %cst_11
  const float v32 = 9.99999974E-5f;
  // pto: %cst_12
  const float v33 = 127.0f;
  // pto: %c4_index
  const int64_t v34 = 4;
  // pto: %c3_index
  const int64_t v35 = 3;
  // pto: %c1_i64
  const int64_t v36 = 1;
  // pto: %c4_i64
  const int64_t v37 = 4;
  // pto: %kv_final_inline4938__rv_v2_view
  const int64_t v38 = 1;
  // pto: %kv_final_inline4938__rv_v2_view
  const int64_t v39 = 1;
  // pto: %kv_final_inline4938__rv_v2_view
  const int64_t v40 = 1;
  // pto: %kv_final_inline4938__rv_v2_view
  int64_t v41 = v25 * v26;
  // pto: %kv_final_inline4938__rv_v2_view
  int64_t v42 = v40 * v41;
  // pto: %kv_final_inline4938__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v43 = pto::Shape<1, 1, 1, -1, -1>(v38, v39, v40, v25, v26);
  // pto: %kv_final_inline4938__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v44 = pto::Stride<-1, -1, -1, -1, -1>(v39 * v42, v42, v41, v26, v27);
  // pto: %kv_final_inline4938__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v45 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v43, v44);
  // pto: %idx_kv_scale_values_inline4935__ssa_v0_view
  const int64_t v46 = 1;
  // pto: %idx_kv_scale_values_inline4935__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %idx_kv_scale_values_inline4935__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %idx_kv_scale_values_inline4935__ssa_v0_view
  int64_t v49 = v25 * v27;
  // pto: %idx_kv_scale_values_inline4935__ssa_v0_view
  int64_t v50 = v48 * v49;
  // pto: %idx_kv_scale_values_inline4935__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v51 = pto::Shape<1, 1, 1, -1, -1>(v46, v47, v48, v25, v27);
  // pto: %idx_kv_scale_values_inline4935__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v52 = pto::Stride<-1, -1, -1, -1, -1>(v47 * v50, v50, v49, v27, v25);
  // pto: %idx_kv_scale_values_inline4935__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v53 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v2, v51, v52);
  // pto: %idx_native_kv_cache__ssa_v0_view
  const int64_t v54 = 1;
  // pto: %idx_native_kv_cache__ssa_v0_view
  const int64_t v55 = 1;
  // pto: %idx_native_kv_cache__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %idx_native_kv_cache__ssa_v0_view
  int64_t v57 = (int64_t) v11;
  // pto: %idx_native_kv_cache__ssa_v0_view
  int64_t v58 = (int64_t) v12;
  // pto: %idx_native_kv_cache__ssa_v0_view
  int64_t v59 = v57 * v58;
  // pto: %idx_native_kv_cache__ssa_v0_view
  int64_t v60 = v56 * v59;
  // pto: %idx_native_kv_cache__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v61 = pto::Shape<1, 1, 1, -1, -1>(v54, v55, v56, v57, (int64_t) v12);
  // pto: %idx_native_kv_cache__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v62 = pto::Stride<-1, -1, -1, -1, -1>(v55 * v60, v60, v59, v58, v27);
  // pto: %idx_native_kv_cache__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v63 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v61, v62);
  // pto: %kv_flat_inline4945__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %kv_flat_inline4945__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %kv_flat_inline4945__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %kv_flat_inline4945__ssa_v0_view
  int64_t v67 = (int64_t) v13;
  // pto: %kv_flat_inline4945__ssa_v0_view
  int64_t v68 = v67 * v26;
  // pto: %kv_flat_inline4945__ssa_v0_view
  int64_t v69 = v66 * v68;
  // pto: %kv_flat_inline4945__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v70 = pto::Shape<1, 1, 1, -1, -1>(v64, v65, v66, v67, v26);
  // pto: %kv_flat_inline4945__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v71 = pto::Stride<-1, -1, -1, -1, -1>(v65 * v69, v69, v68, v26, v27);
  // pto: %kv_flat_inline4945__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v72 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v70, v71);
  // pto: %wr_blk_inline4956__ssa_v0, %10
  int64_t v73 = (int64_t) ((uint64_t) ((int64_t) v17) * (uint64_t) v29);
  // pto: %11
  int64_t v74 = (int64_t) ((uint64_t) v10 - (uint64_t) v73);
  // pto: %12
  // pto: %t__tile
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v75 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v29, v26);
  // pto: %t__tile
  uint64_t v76 = (uint64_t) v21;
  TASSIGN(v75, v76);
  // pto: %13
  int64_t v77 = v73 < v30 ? v30 : v73;
  // pto: %kv_final_inline4938__rv_v2_pview
  __gm__ float* v78 = PTOAS__GLOBAL_TENSOR_DATA(v45);
  // pto: %kv_final_inline4938__rv_v2_pview
  const int64_t v79 = 0;
  // pto: %kv_final_inline4938__rv_v2_pview
  const int64_t v80 = 128;
  // pto: %kv_final_inline4938__rv_v2_pview
  pto::Shape<1, 1, 1, 16, 128> v81 = pto::Shape<1, 1, 1, 16, 128>();
  // pto: %kv_final_inline4938__rv_v2_pview
  pto::Stride<2048, 2048, 2048, 128, 1> v82 = pto::Stride<2048, 2048, 2048, 128, 1>();
  // pto: %kv_final_inline4938__rv_v2_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<2048, 2048, 2048, 128, 1>, pto::Layout::ND> v83 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<2048, 2048, 2048, 128, 1>, pto::Layout::ND>(v78 + (v79 + v77 * v80), v81, v82);
  TLOAD(v75, v83);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %0
  Tile<TileType::Vec, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v84 = Tile<TileType::Vec, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v29, v26);
  // pto: %0
  uint64_t v85 = (uint64_t) v22;
  TASSIGN(v84, v85);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  RoundMode v86 = RoundMode::CAST_RINT;
  SaturationMode v87 = SaturationMode::ON;
  TCVT(v84, v75, v86, v87);
  // pto: %kv_blk_f32_inline4962__tile
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v88 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v29, v26);
  // pto: %kv_blk_f32_inline4962__tile
  uint64_t v89 = (uint64_t) v21;
  TASSIGN(v88, v89);
  pipe_barrier(PIPE_V);
  RoundMode v90 = RoundMode::CAST_ROUND;
  SaturationMode v91 = SaturationMode::ON;
  TCVT(v88, v84, v90, v91);
  // pto: %1
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v92 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v29, v26);
  // pto: %1
  uint64_t v93 = (uint64_t) v21;
  TASSIGN(v92, v93);
  pipe_barrier(PIPE_V);
  TMULS(v92, v88, v31);
  // pto: %2
  Tile<TileType::Vec, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Vec, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v29, v26);
  // pto: %2
  uint64_t v95 = (uint64_t) v22;
  TASSIGN(v94, v95);
  pipe_barrier(PIPE_V);
  RoundMode v96 = RoundMode::CAST_RINT;
  SaturationMode v97 = SaturationMode::ON;
  TCVT(v94, v92, v96, v97);
  // pto: %kv_blk_f32_v1_inline4955__tile
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v98 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v29, v26);
  // pto: %kv_blk_f32_v1_inline4955__tile
  uint64_t v99 = (uint64_t) v21;
  TASSIGN(v98, v99);
  pipe_barrier(PIPE_V);
  RoundMode v100 = RoundMode::CAST_ROUND;
  SaturationMode v101 = SaturationMode::ON;
  TCVT(v98, v94, v100, v101);
  // pto: %3
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v29, v26);
  // pto: %3
  uint64_t v103 = (uint64_t) v22;
  TASSIGN(v102, v103);
  pipe_barrier(PIPE_V);
  TABS(v102, v98);
  // pto: %tmp_tile
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v104 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v29, v26);
  // pto: %tmp_tile
  uint64_t v105 = (uint64_t) v23;
  TASSIGN(v104, v105);
  // pto: %4
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v29, v27);
  // pto: %4
  uint64_t v107 = (uint64_t) v24;
  TASSIGN(v106, v107);
  pipe_barrier(PIPE_V);
  TROWMAX(v106, v102, v104);
  // pto: %kv_amax_inline4953__tile
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v29);
  // pto: %kv_amax_inline4953__tile
  uint64_t v109 = (uint64_t) v24;
  TASSIGN(v108, v109);
  // pto: %5
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v29);
  // pto: %5
  uint64_t v111 = (uint64_t) v22;
  TASSIGN(v110, v111);
  pipe_barrier(PIPE_V);
  TEXPANDS(v110, v32);
  // pto: %kv_amax_v1_inline4946__tile
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v112 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v29);
  // pto: %kv_amax_v1_inline4946__tile
  uint64_t v113 = (uint64_t) v22;
  TASSIGN(v112, v113);
  pipe_barrier(PIPE_V);
  TMAX(v112, v108, v110);
  // pto: %6
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v114 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v29);
  // pto: %6
  uint64_t v115 = (uint64_t) v23;
  TASSIGN(v114, v115);
  TEXPANDS(v114, v33);
  // pto: %kv_scale_q_row_inline4970__tile
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v29);
  // pto: %kv_scale_q_row_inline4970__tile
  uint64_t v117 = (uint64_t) v23;
  TASSIGN(v116, v117);
  pipe_barrier(PIPE_V);
  TDIV(v116, v114, v112);
  // pto: %7
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v118 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v29);
  // pto: %7
  uint64_t v119 = (uint64_t) v22;
  TASSIGN(v118, v119);
  pipe_barrier(PIPE_V);
  TRECIP(v118, v116);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %kv_scale_dq_col_inline4965__tile
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v29, v27);
  // pto: %kv_scale_dq_col_inline4965__tile
  uint64_t v121 = (uint64_t) v22;
  TASSIGN(v120, v121);
  // pto: %kv_scale_q_col_inline4948__tile
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v122 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v29, v27);
  // pto: %kv_scale_q_col_inline4948__tile
  uint64_t v123 = (uint64_t) v23;
  TASSIGN(v122, v123);
  // pto: %idx_kv_scale_values_inline4935__ssa_v0_pview
  __gm__ float* v124 = PTOAS__GLOBAL_TENSOR_DATA(v53);
  // pto: %idx_kv_scale_values_inline4935__ssa_v0_pview
  const int64_t v125 = 0;
  // pto: %idx_kv_scale_values_inline4935__ssa_v0_pview
  pto::Shape<1, 1, 1, 16, 1> v126 = pto::Shape<1, 1, 1, 16, 1>();
  // pto: %idx_kv_scale_values_inline4935__ssa_v0_pview
  pto::Stride<16, 16, 16, 1, 384> v127 = pto::Stride<16, 16, 16, 1, 384>();
  // pto: %idx_kv_scale_values_inline4935__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<16, 16, 16, 1, 384>, pto::Layout::DN> v128 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<16, 16, 16, 1, 384>, pto::Layout::DN>(v124 + (v125 + v77), v126, v127);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v128, v120);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  // pto: %kv_scaled_inline4966__tile
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v29, v26);
  // pto: %kv_scaled_inline4966__tile
  uint64_t v130 = (uint64_t) v22;
  TASSIGN(v129, v130);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  TROWEXPANDMUL(v129, v98, v122);
  // pto: %kv_i32_inline4968__tile
  Tile<TileType::Vec, int32_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Vec, int32_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v29, v26);
  // pto: %kv_i32_inline4968__tile
  uint64_t v132 = (uint64_t) v22;
  TASSIGN(v131, v132);
  pipe_barrier(PIPE_V);
  RoundMode v133 = RoundMode::CAST_RINT;
  SaturationMode v134 = SaturationMode::ON;
  TCVT(v131, v129, v133, v134);
  // pto: %kv_half_inline4969__tile
  Tile<TileType::Vec, half, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v135 = Tile<TileType::Vec, half, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v29, v26);
  // pto: %kv_half_inline4969__tile
  uint64_t v136 = (uint64_t) v22;
  TASSIGN(v135, v136);
  pipe_barrier(PIPE_V);
  RoundMode v137 = RoundMode::CAST_ROUND;
  SaturationMode v138 = SaturationMode::ON;
  TCVT(v135, v131, v137, v138);
  // pto: %kv_i8_blk_inline4971__tile
  Tile<TileType::Vec, int8_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v139 = Tile<TileType::Vec, int8_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v29, v26);
  // pto: %kv_i8_blk_inline4971__tile
  uint64_t v140 = (uint64_t) v22;
  TASSIGN(v139, v140);
  pipe_barrier(PIPE_V);
  RoundMode v141 = RoundMode::CAST_TRUNC;
  SaturationMode v142 = SaturationMode::ON;
  TCVT(v139, v135, v141, v142);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
  for (int64_t v143 = v30; v143 < (v74 < v29 ? v74 : v29); v143 += v27) {
    // pto: %15
    ;
    int64_t v144 = (int64_t) ((uint64_t) v73 + (uint64_t) v143);
    // pto: %16
    ;
    int64_t v145 = v144 / v28;
    // pto: %17
    ;
    int32_t v146 = (v5)[v145];
    // pto: %18
    ;
    int64_t v147 = (int64_t) v146;
    // pto: %20, %19
    ;
    int32_t v148 = (v5)[(int64_t) ((uint64_t) v145 + (uint64_t) v27)];
    // pto: %21
    ;
    int64_t v149 = (int64_t) v148;
    // pto: %23
    ;
    // pto: %first_pos_inline4924__phi_v2
    ;
    int64_t v150;
    if (v147 < v149) {
      // pto: %24
      ;
      int64_t v151 = (v6)[v147];
      v150 = v151;
    } else {
      v150 = v30;
    };
    // pto: %26
    ;
    int64_t v152 = v144 % v28;
    // pto: %27, %28, %29
    ;
    int64_t v153 = v152 < v30 ? (int64_t) ((uint64_t) v152 + (uint64_t) v28) : v152;
    // pto: %31
    ;
    int64_t v154 = v150 % v34;
    // pto: %32, %33, %34
    ;
    int64_t v155 = v154 < v30 ? (int64_t) ((uint64_t) v154 + (uint64_t) v34) : v154;
    // pto: %30, %35, %36
    ;
    int64_t v156 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v153 * (uint64_t) v34) - (uint64_t) v155) + (uint64_t) v35);
    // pto: %37
    ;
    int32_t v157 = (v7)[v145];
    // pto: %38, %39, %40, %41, %42
    ;
    if ((int64_t) v157 > v30 & v156 < (int64_t) ((uint64_t) v149 - (uint64_t) v147)) {
      // pto: %43
      ;
      int64_t v158 = (int64_t) ((uint64_t) v147 + (uint64_t) v156);
      // pto: %token_pos_inline4967__tile
      ;
      int64_t v159 = (v6)[v158];
      // pto: %44
      ;
      int32_t v160 = (v8)[v145];
      // pto: %45, %49, %46, %47
      ;
      int64_t v161 = (int64_t) ((uint64_t) ((int64_t) v160) + (uint64_t) ((int64_t) ((uint64_t) v159 + (uint64_t) v36) / v37));
      // pto: %50
      ;
      int64_t v162 = (int64_t) ((uint64_t) v16 - (uint64_t) v27);
      // pto: %51
      ;
      int64_t v163 = v161 < v162 ? v161 : v162;
      // pto: %flat_offset_mul
      ;
      int64_t v164 = (int64_t) ((uint64_t) v163 * (uint64_t) v28);
      // pto: %native_page_inline4921__tile
      ;
      int32_t v165 = (v9)[v164];
      // pto: %53, %native_offset_inline4919__tile
      ;
      int32_t v166 = (v9)[(int64_t) ((uint64_t) v164 + (uint64_t) v27)];
      // pto: %55
      ;
      int64_t v167 = (int64_t) v165;
      // pto: %58
      ;
      int64_t v168 = (int64_t) v166;
      // pto: %54, %56, %57, %59, %60
      ;
      if ((v161 < v16 & v167 >= v30) & v168 >= v30) {
        // pto: %8
        ;
        Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v26);
        // pto: %8
        ;
        uint64_t v170 = (uint64_t) v21;
        TASSIGN(v169, v170);
        // pto: %slice_view
        ;
        Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v171;
        // pto: %slice_view
        ;
        uint64_t v172 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v143 * (uint64_t) v19) + (uint64_t) v21);
        TASSIGN(v171, v172);
        // pto: %61
        ;
        int64_t v173 = v158 < v30 ? v30 : v158;
        // pto: %kv_flat_inline4945__iter_v1_pview
        ;
        __gm__ float* v174 = PTOAS__GLOBAL_TENSOR_DATA(v72);
        // pto: %kv_flat_inline4945__iter_v1_pview
        ;
        const int64_t v175 = 0;
        // pto: %kv_flat_inline4945__iter_v1_pview
        ;
        const int64_t v176 = 128;
        // pto: %kv_flat_inline4945__iter_v1_pview
        ;
        pto::Shape<1, 1, 1, 1, 128> v177 = pto::Shape<1, 1, 1, 1, 128>();
        // pto: %kv_flat_inline4945__iter_v1_pview
        ;
        pto::Stride<128, 128, 128, 128, 1> v178 = pto::Stride<128, 128, 128, 128, 1>();
        // pto: %kv_flat_inline4945__iter_v1_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v179 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v174 + (v175 + v173 * v176), v177, v178);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v179, v171);
        // pto: %64
        ;
        int64_t v180 = (int64_t) ((uint64_t) v168 * (uint64_t) v26);
        // pto: %9
        ;
        Tile<TileType::Vec, int8_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Vec, int8_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v26);
        // pto: %9
        ;
        uint64_t v182 = (uint64_t) v22;
        TASSIGN(v181, v182);
        // pto: %65
        ;
        Tile<TileType::Vec, int8_t, 1, 128, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v183;
        // pto: %slice_view, %65
        ;
        uint64_t v184 = (uint64_t) ((int64_t) (uint64_t) v143 * (uint64_t) v20);
        TASSIGN(v183, v184);
        // pto: %66
        ;
        int64_t v185 = v167 < v30 ? v30 : v167;
        // pto: %67
        ;
        int64_t v186 = v180 < v30 ? v30 : v180;
        // pto: %idx_native_kv_cache__iter_v1_pview
        ;
        int64_t v187 = (int64_t) v12;
        // pto: %idx_native_kv_cache__iter_v1_pview
        ;
        const int64_t v188 = 0;
        // pto: %idx_native_kv_cache__iter_v1_pview
        ;
        __gm__ int8_t* v189 = PTOAS__GLOBAL_TENSOR_DATA(v63);
        // pto: %idx_native_kv_cache__iter_v1_pview
        ;
        const int64_t v190 = 1;
        // pto: %idx_native_kv_cache__iter_v1_pview
        ;
        const int64_t v191 = 1;
        // pto: %idx_native_kv_cache__iter_v1_pview
        ;
        const int64_t v192 = 1;
        // pto: %idx_native_kv_cache__iter_v1_pview
        ;
        int64_t v193 = v27 * v187;
        // pto: %idx_native_kv_cache__iter_v1_pview
        ;
        int64_t v194 = v192 * v193;
        // pto: %idx_native_kv_cache__iter_v1_pview
        ;
        pto::Shape<1, 1, 1, 1, 128> v195 = pto::Shape<1, 1, 1, 1, 128>(v190, v191, v192, v27, v26);
        // pto: %idx_native_kv_cache__iter_v1_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v196 = pto::Stride<-1, -1, -1, -1, -1>(v191 * v194, v194, v193, v187, v27);
        // pto: %idx_native_kv_cache__iter_v1_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v197 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v189 + (v188 + v185 * v187 + v186 * v27), v195, v196);
        TSTORE(v197, v183);
      };
    };
  }
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}