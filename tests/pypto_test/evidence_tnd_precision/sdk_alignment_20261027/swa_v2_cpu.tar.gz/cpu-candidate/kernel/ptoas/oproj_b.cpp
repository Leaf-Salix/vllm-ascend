#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_b(__gm__ int8_t* v1, __gm__ int8_t* v2, __gm__ int32_t* v3, int64_t v4, int64_t v5, int64_t v6, int32_t v7, int32_t v8) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v9 = 0;
  // pto: %c8192_i64
  const int64_t v10 = 8192;
  // pto: %c4096_i64
  const int64_t v11 = 4096;
  // pto: %c32768_i64
  const int64_t v12 = 32768;
  // pto: %c8192_index
  const int64_t v13 = 8192;
  // pto: %c1_index
  const int64_t v14 = 1;
  // pto: %c128_index
  const int64_t v15 = 128;
  // pto: %c512_index
  const int64_t v16 = 512;
  // pto: %c16_index
  const int64_t v17 = 16;
  // pto: %c32_index
  const int64_t v18 = 32;
  // pto: %c33554432_index
  const int64_t v19 = 33554432;
  // pto: %c262144_index
  const int64_t v20 = 262144;
  // pto: %c4096_index
  const int64_t v21 = 4096;
  // pto: %c0_index
  const int64_t v22 = 0;
  // pto: %c256_index
  const int64_t v23 = 256;
  // pto: %c63_index
  const int64_t v24 = 63;
  // pto: %quantized_o__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %quantized_o__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %quantized_o__ssa_v0_view
  const int64_t v27 = 1;
  // pto: %quantized_o__ssa_v0_view
  int64_t v28 = (int64_t) v5;
  // pto: %quantized_o__ssa_v0_view
  int64_t v29 = v28 * v13;
  // pto: %quantized_o__ssa_v0_view
  int64_t v30 = v27 * v29;
  // pto: %quantized_o__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v31 = pto::Shape<1, 1, 1, -1, -1>(v25, v26, v27, v28, v13);
  // pto: %quantized_o__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v32 = pto::Stride<-1, -1, -1, -1, -1>(v26 * v30, v30, v29, v13, v14);
  // pto: %quantized_o__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v33 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v31, v32);
  // pto: %wo_b__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v34 = pto::Shape<-1, -1, -1, -1, -1>(v14, v15, v16, v17, v18);
  // pto: %wo_b__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v35 = pto::Stride<-1, -1, -1, -1, -1>(v19, v20, v16, v18, v14);
  // pto: %wo_b__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v36 = GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v2, v34, v35);
  // pto: %23
  int64_t v37 = (int64_t) ((uint64_t) v6 + (uint64_t) v24);
  // pto: %integer_accum_inline1120__ssa_v0_view
  const int64_t v38 = 1;
  // pto: %integer_accum_inline1120__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %integer_accum_inline1120__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %integer_accum_inline1120__ssa_v0_view
  int64_t v41 = v37 * v21;
  // pto: %integer_accum_inline1120__ssa_v0_view
  int64_t v42 = v40 * v41;
  // pto: %integer_accum_inline1120__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v43 = pto::Shape<1, 1, 1, -1, -1>(v38, v39, v40, v37, v21);
  // pto: %integer_accum_inline1120__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v44 = pto::Stride<-1, -1, -1, -1, -1>(v39 * v42, v42, v41, v21, v14);
  // pto: %integer_accum_inline1120__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v45 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v43, v44);
  // pto: %block_inline1052__ssa_v0
  int64_t v46 = (int64_t) v7;
  // pto: %3, %4
  int64_t v47 = (int64_t) ((uint64_t) (v46 / v18) * (uint64_t) v17);
  // pto: %5
  int64_t v48 = v46 % v18;
  // pto: %6, %7, %8
  int64_t v49 = v48 < v22 ? (int64_t) ((uint64_t) v48 + (uint64_t) v18) : v48;
  // pto: %9
  int64_t v50 = (int64_t) ((uint64_t) v49 * (uint64_t) v15);
  // pto: %10
  int64_t v51 = (int64_t) ((uint64_t) v6 - (uint64_t) v47);
  // pto: %b_acc_inline1121__tile
  Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v52 = Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v15);
  // pto: %b_acc_inline1121__tile
  uint64_t v53 = (uint64_t) v9;
  TASSIGN(v52, v53);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  for (int64_t v54 = v22; v54 < v17; v54 += v14) {
    // pto: %11
    ;
    int64_t v55 = (int64_t) ((uint64_t) v54 * (uint64_t) v16);
    // pto: %b_input_inline1127__tile
    ;
    Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v56 = Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v16);
    // pto: %b_input_inline1127__tile
    ;
    uint64_t v57 = (uint64_t) v9;
    TASSIGN(v56, v57);
    // pto: %12
    ;
    int64_t v58 = v47 < v22 ? v22 : v47;
    // pto: %13
    ;
    int64_t v59 = v55 < v22 ? v22 : v55;
    // pto: %quantized_o__ssa_v0_pview
    ;
    const int64_t v60 = 0;
    // pto: %quantized_o__ssa_v0_pview
    ;
    __gm__ int8_t* v61 = PTOAS__GLOBAL_TENSOR_DATA(v33);
    // pto: %quantized_o__ssa_v0_pview
    ;
    const int64_t v62 = 1;
    // pto: %quantized_o__ssa_v0_pview
    ;
    const int64_t v63 = 1;
    // pto: %quantized_o__ssa_v0_pview
    ;
    const int64_t v64 = 1;
    // pto: %quantized_o__ssa_v0_pview
    ;
    int64_t v65 = v51 * v13;
    // pto: %quantized_o__ssa_v0_pview
    ;
    int64_t v66 = v64 * v65;
    // pto: %quantized_o__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v67 = pto::Shape<1, 1, 1, -1, 512>(v62, v63, v64, v51, v16);
    // pto: %quantized_o__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v68 = pto::Stride<-1, -1, -1, -1, -1>(v63 * v66, v66, v65, v13, v14);
    // pto: %quantized_o__ssa_v0_pview
    ;
    GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v69 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v61 + (v60 + v58 * v13 + v59 * v14), v67, v68);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v56, v69);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    // pto: %b_weight_inline1128__tile
    ;
    Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v70 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v15);
    // pto: %b_weight_inline1128__tile
    ;
    uint64_t v71 = (uint64_t) v10;
    TASSIGN(v70, v71);
    // pto: %14
    ;
    int64_t v72 = v50 / v18;
    // pto: %15
    ;
    int64_t v73 = v72 < v22 ? v22 : v72;
    // pto: %16
    ;
    int64_t v74 = v55 / v17;
    // pto: %17
    ;
    int64_t v75 = v74 < v22 ? v22 : v74;
    // pto: %wo_b__ssa_v0_pview
    ;
    __gm__ int8_t* v76 = PTOAS__GLOBAL_TENSOR_DATA(v36);
    // pto: %wo_b__ssa_v0_pview
    ;
    const int64_t v77 = 0;
    // pto: %wo_b__ssa_v0_pview
    ;
    const int64_t v78 = 262144;
    // pto: %wo_b__ssa_v0_pview
    ;
    const int64_t v79 = 512;
    // pto: %wo_b__ssa_v0_pview
    ;
    pto::Shape<1, 4, 32, 16, 32> v80 = pto::Shape<1, 4, 32, 16, 32>();
    // pto: %wo_b__ssa_v0_pview
    ;
    pto::Stride<33554432, 262144, 512, 32, 1> v81 = pto::Stride<33554432, 262144, 512, 32, 1>();
    // pto: %wo_b__ssa_v0_pview
    ;
    GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v82 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v76 + (v77 + v73 * v78 + v75 * v79), v80, v81);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    TLOAD(v70, v82);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    // pto: %18
    ;
    int64_t v83 = v51 < v17 ? v51 : v17;
    // pto: %b_acc_inline1121__tile_l0_a
    ;
    Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v84 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v83, v23);
    // pto: %b_acc_inline1121__tile_l0_a
    ;
    uint64_t v85 = (uint64_t) v9;
    TASSIGN(v84, v85);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    uint16_t v86 = static_cast<uint16_t>(v22);
    uint16_t v87 = static_cast<uint16_t>(v22);
    TEXTRACT(v84, v56, v86, v87);
    // pto: %b_acc_inline1121__tile_l0_b
    ;
    Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v88 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v15);
    // pto: %b_acc_inline1121__tile_l0_b
    ;
    uint64_t v89 = (uint64_t) v9;
    TASSIGN(v88, v89);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    uint16_t v90 = static_cast<uint16_t>(v22);
    uint16_t v91 = static_cast<uint16_t>(v22);
    TEXTRACT(v88, v70, v90, v91);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    // pto: %0
    ;
    Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v92 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v83, v23);
    // pto: %0
    ;
    uint64_t v93 = (uint64_t) v11;
    TASSIGN(v92, v93);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    uint16_t v94 = static_cast<uint16_t>(v22);
    uint16_t v95 = static_cast<uint16_t>(v23);
    TEXTRACT(v92, v56, v94, v95);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    // pto: %1
    ;
    Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v96 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v15);
    // pto: %1
    ;
    uint64_t v97 = (uint64_t) v12;
    TASSIGN(v96, v97);
    uint16_t v98 = static_cast<uint16_t>(v23);
    uint16_t v99 = static_cast<uint16_t>(v22);
    TEXTRACT(v96, v70, v98, v99);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
    // pto: %20
    ;
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    if (v54 == v22) {
      pipe_barrier(PIPE_M);
      TMATMUL(v52, v84, v88);
    } else {
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v52, v52, v84, v88);
    };
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    pipe_barrier(PIPE_M);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
    TMATMUL_ACC(v52, v52, v92, v96);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  }
  set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  // pto: %21
  int64_t v100 = v47 < v22 ? v22 : v47;
  // pto: %22
  int64_t v101 = v50 < v22 ? v22 : v50;
  // pto: %integer_accum_inline1120__ssa_v0_pview
  __gm__ int32_t* v102 = PTOAS__GLOBAL_TENSOR_DATA(v45);
  // pto: %integer_accum_inline1120__ssa_v0_pview
  const int64_t v103 = 0;
  // pto: %integer_accum_inline1120__ssa_v0_pview
  const int64_t v104 = 4096;
  // pto: %integer_accum_inline1120__ssa_v0_pview
  pto::Shape<1, 1, 1, 16, 128> v105 = pto::Shape<1, 1, 1, 16, 128>();
  // pto: %integer_accum_inline1120__ssa_v0_pview
  pto::Stride<65536, 65536, 65536, 4096, 1> v106 = pto::Stride<65536, 65536, 65536, 4096, 1>();
  // pto: %integer_accum_inline1120__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v107 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v102 + (v103 + v100 * v104 + v101), v105, v106);
  wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  TSTORE(v107, v52);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}