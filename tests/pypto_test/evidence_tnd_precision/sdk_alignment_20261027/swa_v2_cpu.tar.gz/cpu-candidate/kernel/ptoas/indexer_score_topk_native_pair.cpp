#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void indexer_score_topk_native_pair_aic(__gm__ int32_t* v1, __gm__ int32_t* v2, __gm__ int64_t* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, __gm__ int64_t* v7, __gm__ int8_t* v8, __gm__ half* v9, __gm__ int32_t* v10, __gm__ int8_t* v11, __gm__ int8_t* v12, __gm__ float* v13, __gm__ int8_t* v14, __gm__ float* v15, int64_t v16, int64_t v17, int64_t v18, int64_t v19, int64_t v20, int64_t v21, int64_t v22, int64_t v23, int32_t v24, int32_t v25) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int64_t v26 = 992;
  const int64_t v27 = 928;
  const int64_t v28 = 864;
  const int64_t v29 = 800;
  const int64_t v30 = 736;
  const int64_t v31 = 672;
  const int64_t v32 = 608;
  const int64_t v33 = 544;
  const int64_t v34 = 480;
  const int64_t v35 = 416;
  const int64_t v36 = 352;
  const int64_t v37 = 224;
  const int64_t v38 = 160;
  const int64_t v39 = 52224;
  const int64_t v40 = 96;
  const int64_t v41 = 51200;
  const int64_t v42 = 50176;
  // pto: %c0_i64
  const int64_t v43 = 0;
  // pto: %c65536_i64
  const int64_t v44 = 65536;
  // pto: %c49152_i64
  const int64_t v45 = 49152;
  // pto: %c16384_i64
  const int64_t v46 = 16384;
  // pto: %c8192_i64
  const int64_t v47 = 8192;
  // pto: %c98304_i64
  const int64_t v48 = 98304;
  // pto: %c1_index
  const int64_t v49 = 1;
  // pto: %c27648_index
  const int64_t v50 = 27648;
  const int64_t v51 = 128;
  // pto: %c1152_index
  const int64_t v52 = 1152;
  const int64_t v53 = 384;
  const int64_t v54 = 288;
  // pto: %c1024_index
  const int64_t v55 = 1024;
  const int64_t v56 = 0;
  // pto: %c4_index
  const int64_t v57 = 4;
  // pto: %c262144_index
  const int64_t v58 = 262144;
  // pto: %c1023_index
  const int64_t v59 = 1023;
  // pto: %c8191_index
  const int64_t v60 = 8191;
  // pto: %c8192_index
  const int64_t v61 = 8192;
  // pto: %c3_index
  const int64_t v62 = 3;
  // pto: %c48_index
  const int64_t v63 = 48;
  // pto: %c24_index
  const int64_t v64 = 24;
  // pto: %c6_index
  const int64_t v65 = 6;
  const int64_t v66 = 32;
  // pto: %c8_index
  const int64_t v67 = 8;
  // pto: %c1_i64
  const int64_t v68 = 1;
  // pto: %c4_i64
  const int64_t v69 = 4;
  const int64_t v70 = 512;
  // pto: %c4096_index
  const int64_t v71 = 4096;
  // pto: %c511_index
  const int64_t v72 = 511;
  const int64_t v73 = 64;
  // pto: %c16_index
  const int64_t v74 = 16;
  // pto: %c2_index
  const int64_t v75 = 2;
  // pto: %c12_index
  const int64_t v76 = 12;
  // pto: %c981467136_i64
  const int64_t v77 = 981467136;
  const int64_t v78 = 192;
  const int64_t v79 = 256;
  const int64_t v80 = 320;
  const int64_t v81 = 448;
  const int64_t v82 = 576;
  const int64_t v83 = 640;
  const int64_t v84 = 704;
  const int64_t v85 = 768;
  const int64_t v86 = 832;
  const int64_t v87 = 896;
  // pto: %c960_index
  const int64_t v88 = 960;
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  const int64_t v89 = 1;
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  const int64_t v90 = 1;
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  const int64_t v91 = 1;
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  int64_t v92 = v50 * v51;
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  int64_t v93 = v91 * v92;
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v94 = pto::Shape<1, 1, 1, -1, -1>(v89, v90, v91, v50, v51);
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v95 = pto::Stride<-1, -1, -1, -1, -1>(v90 * v93, v93, v92, v51, v49);
  // pto: %qr_hadamard_i8_inline979__rv_v2_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v96 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v94, v95);
  // pto: %coefficients_inline8426__ssa_v0_view
  const int64_t v97 = 1;
  // pto: %coefficients_inline8426__ssa_v0_view
  const int64_t v98 = 1;
  // pto: %coefficients_inline8426__ssa_v0_view
  const int64_t v99 = 1;
  // pto: %coefficients_inline8426__ssa_v0_view
  int64_t v100 = v52 * v53;
  // pto: %coefficients_inline8426__ssa_v0_view
  int64_t v101 = v99 * v100;
  // pto: %coefficients_inline8426__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v102 = pto::Shape<1, 1, 1, -1, -1>(v97, v98, v99, v52, v53);
  // pto: %coefficients_inline8426__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v103 = pto::Stride<-1, -1, -1, -1, -1>(v98 * v101, v101, v100, v53, v49);
  // pto: %coefficients_inline8426__ssa_v0_view
  GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v104 = GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v102, v103);
  // pto: %idx_kv_cache_inline8469__ssa_v0_view
  const int64_t v105 = 1;
  // pto: %idx_kv_cache_inline8469__ssa_v0_view
  const int64_t v106 = 1;
  // pto: %idx_kv_cache_inline8469__ssa_v0_view
  const int64_t v107 = 1;
  // pto: %idx_kv_cache_inline8469__ssa_v0_view
  int64_t v108 = (int64_t) v20;
  // pto: %idx_kv_cache_inline8469__ssa_v0_view
  int64_t v109 = v108 * v51;
  // pto: %idx_kv_cache_inline8469__ssa_v0_view
  int64_t v110 = v107 * v109;
  // pto: %idx_kv_cache_inline8469__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v111 = pto::Shape<1, 1, 1, -1, -1>(v105, v106, v107, v108, v51);
  // pto: %idx_kv_cache_inline8469__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v112 = pto::Stride<-1, -1, -1, -1, -1>(v106 * v110, v110, v109, v51, v49);
  // pto: %idx_kv_cache_inline8469__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v113 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v11, v111, v112);
  // pto: %idx_kv_cache_shift64_inline8488__ssa_v0_view
  const int64_t v114 = 1;
  // pto: %idx_kv_cache_shift64_inline8488__ssa_v0_view
  const int64_t v115 = 1;
  // pto: %idx_kv_cache_shift64_inline8488__ssa_v0_view
  const int64_t v116 = 1;
  // pto: %idx_kv_cache_shift64_inline8488__ssa_v0_view
  int64_t v117 = (int64_t) v21;
  // pto: %idx_kv_cache_shift64_inline8488__ssa_v0_view
  int64_t v118 = v117 * v51;
  // pto: %idx_kv_cache_shift64_inline8488__ssa_v0_view
  int64_t v119 = v116 * v118;
  // pto: %idx_kv_cache_shift64_inline8488__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v120 = pto::Shape<1, 1, 1, -1, -1>(v114, v115, v116, v117, v51);
  // pto: %idx_kv_cache_shift64_inline8488__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v121 = pto::Stride<-1, -1, -1, -1, -1>(v115 * v119, v119, v118, v51, v49);
  // pto: %idx_kv_cache_shift64_inline8488__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v122 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v12, v120, v121);
  // pto: %buf_score_transfer_inline8569__ssa_v0_view
  const int64_t v123 = 1;
  // pto: %buf_score_transfer_inline8569__ssa_v0_view
  const int64_t v124 = 1;
  // pto: %buf_score_transfer_inline8569__ssa_v0_view
  const int64_t v125 = 1;
  // pto: %buf_score_transfer_inline8569__ssa_v0_view
  int64_t v126 = v54 * v55;
  // pto: %buf_score_transfer_inline8569__ssa_v0_view
  int64_t v127 = v125 * v126;
  // pto: %buf_score_transfer_inline8569__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v128 = pto::Shape<1, 1, 1, -1, -1>(v123, v124, v125, v54, v55);
  // pto: %buf_score_transfer_inline8569__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v129 = pto::Stride<-1, -1, -1, -1, -1>(v124 * v127, v127, v126, v55, v49);
  // pto: %buf_score_transfer_inline8569__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v130 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v128, v129);
  // pto: %buf_key_l1_pool_inline8539__phi_v3
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v3
  uint64_t v132 = (uint64_t) v45;
  TASSIGN(v131, v132);
  // pto: %buf_key_l1_pool_inline8539__phi_v6
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v6
  uint64_t v134 = (uint64_t) v45;
  TASSIGN(v133, v134);
  // pto: %buf_key_l1_pool_inline8539__phi_v12
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v135 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v12
  uint64_t v136 = (uint64_t) v45;
  TASSIGN(v135, v136);
  // pto: %buf_key_l1_pool_inline8539__phi_v17
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v17
  uint64_t v138 = (uint64_t) v45;
  TASSIGN(v137, v138);
  // pto: %buf_key_l1_pool_inline8539__phi_v23
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v139 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v23
  uint64_t v140 = (uint64_t) v45;
  TASSIGN(v139, v140);
  // pto: %buf_key_l1_pool_inline8539__phi_v28
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v141 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v28
  uint64_t v142 = (uint64_t) v45;
  TASSIGN(v141, v142);
  // pto: %buf_key_l1_pool_inline8539__phi_v34
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v143 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v34
  uint64_t v144 = (uint64_t) v45;
  TASSIGN(v143, v144);
  // pto: %buf_key_l1_pool_inline8539__phi_v39
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v145 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v39
  uint64_t v146 = (uint64_t) v45;
  TASSIGN(v145, v146);
  // pto: %buf_key_l1_pool_inline8539__phi_v45
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v147 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v45
  uint64_t v148 = (uint64_t) v45;
  TASSIGN(v147, v148);
  // pto: %buf_key_l1_pool_inline8539__phi_v50
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v149 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v50
  uint64_t v150 = (uint64_t) v45;
  TASSIGN(v149, v150);
  // pto: %buf_key_l1_pool_inline8539__phi_v56
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v151 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v56
  uint64_t v152 = (uint64_t) v45;
  TASSIGN(v151, v152);
  // pto: %buf_key_l1_pool_inline8539__phi_v61
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v153 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v61
  uint64_t v154 = (uint64_t) v45;
  TASSIGN(v153, v154);
  // pto: %buf_key_l1_pool_inline8539__phi_v67
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v155 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v67
  uint64_t v156 = (uint64_t) v45;
  TASSIGN(v155, v156);
  // pto: %buf_key_l1_pool_inline8539__phi_v72
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v72
  uint64_t v158 = (uint64_t) v45;
  TASSIGN(v157, v158);
  // pto: %buf_key_l1_pool_inline8539__phi_v78
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v159 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v78
  uint64_t v160 = (uint64_t) v45;
  TASSIGN(v159, v160);
  // pto: %buf_key_l1_pool_inline8539__phi_v83
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v161 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v83
  uint64_t v162 = (uint64_t) v45;
  TASSIGN(v161, v162);
  // pto: %buf_key_l1_pool_inline8539__phi_v89
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v163 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v89
  uint64_t v164 = (uint64_t) v45;
  TASSIGN(v163, v164);
  // pto: %buf_key_l1_pool_inline8539__phi_v94
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v165 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v94
  uint64_t v166 = (uint64_t) v45;
  TASSIGN(v165, v166);
  // pto: %buf_key_l1_pool_inline8539__phi_v100
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v167 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v100
  uint64_t v168 = (uint64_t) v45;
  TASSIGN(v167, v168);
  // pto: %buf_key_l1_pool_inline8539__phi_v105
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v105
  uint64_t v170 = (uint64_t) v45;
  TASSIGN(v169, v170);
  // pto: %buf_key_l1_pool_inline8539__phi_v111
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v171 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v111
  uint64_t v172 = (uint64_t) v45;
  TASSIGN(v171, v172);
  // pto: %buf_key_l1_pool_inline8539__phi_v116
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v173 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v116
  uint64_t v174 = (uint64_t) v45;
  TASSIGN(v173, v174);
  // pto: %buf_key_l1_pool_inline8539__phi_v122
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v122
  uint64_t v176 = (uint64_t) v45;
  TASSIGN(v175, v176);
  // pto: %buf_key_l1_pool_inline8539__phi_v127
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v127
  uint64_t v178 = (uint64_t) v45;
  TASSIGN(v177, v178);
  // pto: %buf_key_l1_pool_inline8539__phi_v133
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v179 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v133
  uint64_t v180 = (uint64_t) v45;
  TASSIGN(v179, v180);
  // pto: %buf_key_l1_pool_inline8539__phi_v138
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v138
  uint64_t v182 = (uint64_t) v45;
  TASSIGN(v181, v182);
  // pto: %buf_key_l1_pool_inline8539__phi_v144
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v144
  uint64_t v184 = (uint64_t) v45;
  TASSIGN(v183, v184);
  // pto: %buf_key_l1_pool_inline8539__phi_v149
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v185 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v149
  uint64_t v186 = (uint64_t) v45;
  TASSIGN(v185, v186);
  // pto: %buf_key_l1_pool_inline8539__phi_v155
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v187 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v155
  uint64_t v188 = (uint64_t) v45;
  TASSIGN(v187, v188);
  // pto: %buf_key_l1_pool_inline8539__phi_v160
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v189 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v160
  uint64_t v190 = (uint64_t) v45;
  TASSIGN(v189, v190);
  // pto: %buf_key_l1_pool_inline8539__phi_v166
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v191 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v166
  uint64_t v192 = (uint64_t) v45;
  TASSIGN(v191, v192);
  // pto: %buf_key_l1_pool_inline8539__phi_v171
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v193 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8539__phi_v171
  uint64_t v194 = (uint64_t) v45;
  TASSIGN(v193, v194);
  // pto: %buf_worker_inline8582__ssa_v0
  int64_t v195 = (int64_t) v24;
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  // pto: %buf_max_cache_len_inline8525__rv_v2
  int64_t v196;
  v196 = v56;
  for (int64_t v197 = v56; v197 < v17; v197 += v49) {
    // pto: %t__tile
    ;
    int32_t v198 = (v1)[v197];
    // pto: %0, %1
    ;
    int64_t v199 = (int64_t) v198 / v57;
    // pto: %2
    ;
    bool v200 = v196 < v199;
    // pto: %2
    ;
    int64_t v201 = v200 ? v199 : v196;
    v196 = v201;
  }
  // pto: %3
  bool v202 = v196 < v58;
  // pto: %3
  int64_t v203 = v202 ? v196 : v58;
  // pto: %4
  int32_t v204 = (v2)[v56];
  // pto: %5
  int64_t v205 = (int64_t) v204;
  // pto: %6, %7
  int64_t v206 = (int64_t) ((uint64_t) v203 + (uint64_t) v59) / v55;
  // pto: %8, %9
  int64_t v207 = (int64_t) ((uint64_t) v203 + (uint64_t) v60) / v61;
  // pto: %10
  int64_t v208 = v207 < v49 ? v49 : v207;
  // pto: %11
  int64_t v209 = (int64_t) ((uint64_t) v205 * (uint64_t) v62);
  // pto: %12
  // pto: %leaf_multiple_inline2661_inline8467__phi_v6
  int64_t v210;
  if (v209 == v63) {
    v210 = v62;
  } else {
    // pto: %14
    ;
    // pto: %leaf_multiple_inline2661_inline8467__phi_v5
    ;
    int64_t v211;
    if (v209 == v64) {
      v211 = v62;
    } else {
      // pto: %15, %16, %leaf_multiple_inline2661_inline8467__phi_v4
      ;
      v211 = (int64_t) ((uint64_t) v205 * (uint64_t) v65) == v64 ? v65 : v49;
    };
    v210 = v211;
  }
  // pto: %17
  bool v212 = v210 > v49;
  // pto: %extra_leaves_inline2660_inline8396__phi_v3
  int64_t v213;
  // pto: %leaf_count_inline2663_inline8421__phi_v3
  int64_t v214;
  // pto: %leaf_tiles_inline2662_inline8533__phi_v3
  int64_t v215;
  if (v212) {
    // pto: %18
    ;
    uint64_t v216 = (uint64_t) v210;
    // pto: %18, %19, %20
    ;
    int64_t v217 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v208 + v216) - (uint64_t) v49) / v210;
    // pto: %21
    ;
    uint64_t v218 = (uint64_t) v210;
    // pto: %21
    ;
    int64_t v219 = (int64_t) ((uint64_t) v217 * v218);
    // pto: %22
    ;
    bool v220 = v219 <= v66;
    // pto: %extra_leaves_inline2660_inline8396__phi_v2
    ;
    // pto: %leaf_count_inline2663_inline8421__phi_v2
    ;
    int64_t v221;
    // pto: %leaf_tiles_inline2662_inline8533__phi_v2
    ;
    int64_t v222;
    if (v220) {
      // pto: %23
      ;
      int64_t v223 = v206 / v219;
      // pto: %24
      ;
      // pto: %25
      ;
      int64_t v224 = v206 % v219;
      // pto: %29, %26, %27, %28, %30, %31, %32
      ;
      v221 = v224 != v56 & (v224 < v56 ^ v219 < v56) ? (int64_t) ((uint64_t) v224 + (uint64_t) v219) : v224;
      v222 = v223 < v49 ? v49 : v223;
    } else {
      v221 = v56;
      v222 = v67;
    };
    v213 = v221;
    v214 = v220 ? v219 : v208;
    v215 = v222;
  } else {
    v213 = v56;
    v214 = v208;
    v215 = v67;
  }
  uint64_t v225 = reinterpret_cast<uint64_t>(v3);
  set_ffts_base_addr(v225);
  // pto: %33
  uint64_t v226 = (uint64_t) v214;
  // pto: %33
  for (int64_t v227 = v195; v227 < ((int64_t) ((uint64_t) v205 * v226)); v227 += v64) {
    // pto: %34
    ;
    // pto: %buf_group_inline8534__phi_v2
    ;
    int64_t v228;
    // pto: %buf_leaf_inline8504__phi_v2
    ;
    int64_t v229;
    if (v205 < v64) {
      // pto: %35
      ;
      int64_t v230 = v227 % v205;
      // pto: %39, %36, %37, %38, %40, %41, %42
      ;
      // pto: %43
      ;
      v228 = v230 != v56 & (v230 < v56 ^ v205 < v56) ? (int64_t) ((uint64_t) v230 + (uint64_t) v205) : v230;
      v229 = v227 / v205;
    } else {
      // pto: %44
      ;
      int64_t v231 = v227 / v214;
      // pto: %45
      ;
      int64_t v232 = v227 % v214;
      // pto: %47
      ;
      bool v233 = v214 < v56;
      // pto: %51
      ;
      uint64_t v234 = (uint64_t) v214;
      // pto: %49, %46, %48, %50, %51, %52
      ;
      v228 = v231;
      v229 = v232 != v56 & (v232 < v56 ^ v233) ? (int64_t) ((uint64_t) v232 + v234) : v232;
    };
    // pto: %53
    ;
    int32_t v235 = (v4)[v228];
    // pto: %54
    ;
    int64_t v236 = (int64_t) v235;
    // pto: %55
    ;
    int32_t v237 = (v5)[v228];
    // pto: %57
    ;
    int32_t v238 = (v6)[v236];
    // pto: %58
    ;
    int64_t v239 = (int64_t) v238;
    // pto: %59, %56, %60, %buf_last_position_inline8542__tile
    ;
    int64_t v240 = (v7)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v236 + (uint64_t) ((int64_t) v237)) - (uint64_t) v49)];
    // pto: %61
    ;
    int32_t v241 = (v1)[v239];
    // pto: %62, %63
    ;
    int64_t v242 = (int64_t) v241 / v57;
    // pto: %64, %65
    ;
    int64_t v243 = (int64_t) ((uint64_t) v240 + (uint64_t) v68) / v69;
    // pto: %67
    ;
    int64_t v244 = v242 < v243 ? v242 : v243;
    // pto: %68
    ;
    int64_t v245 = v244 < v58 ? v244 : v58;
    // pto: %69
    ;
    int64_t v246 = v245 < v56 ? v56 : v245;
    // pto: %70
    ;
    uint64_t v247 = (uint64_t) v229;
    // pto: %70
    ;
    uint64_t v248 = (uint64_t) v215;
    // pto: %71
    ;
    bool v249 = v229 < v213;
    // pto: %71
    ;
    int64_t v250 = v249 ? v229 : v213;
    // pto: %70, %72, %73
    ;
    int64_t v251 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v247 * v248) + (uint64_t) v250) * (uint64_t) v55);
    // pto: %74
    ;
    bool v252 = v229 < v213;
    // pto: %76
    ;
    uint64_t v253 = (uint64_t) v215;
    // pto: %75, %76, %77
    ;
    int64_t v254 = (int64_t) ((uint64_t) ((int64_t) v253 + (uint64_t) ((int64_t) v252)) * (uint64_t) v55);
    // pto: %78
    ;
    if (v251 < v246) {
      // pto: %79
      ;
      int64_t v255 = (int64_t) ((uint64_t) v246 - (uint64_t) v251);
      // pto: %80
      ;
      int64_t v256 = v254 < v255 ? v254 : v255;
      // pto: %81, %82, %83
      ;
      int64_t v257 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v256 + (uint64_t) v59) / v55) * (uint64_t) v70);
      // pto: %84
      ;
      int64_t v258 = v257 < v71 ? v257 : v71;
      // pto: %85, %86
      ;
      int64_t v259 = (int64_t) ((uint64_t) v258 + (uint64_t) v72) / v70;
      // pto: %buf_query_vector_inline8544__ssa_v0
      ;
      Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v260 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v51);
      // pto: %buf_query_vector_inline8544__ssa_v0
      ;
      uint64_t v261 = (uint64_t) v43;
      TASSIGN(v260, v261);
      // pto: %87
      ;
      int64_t v262 = (int64_t) ((uint64_t) v236 * (uint64_t) v73);
      // pto: %88
      ;
      int64_t v263 = v262 < v56 ? v56 : v262;
      // pto: %qr_hadamard_i8_inline979__rv_v2_pview
      ;
      __gm__ int8_t* v264 = PTOAS__GLOBAL_TENSOR_DATA(v96);
      // pto: %qr_hadamard_i8_inline979__rv_v2_pview
      ;
      const int64_t v265 = 0;
      // pto: %qr_hadamard_i8_inline979__rv_v2_pview
      ;
      const int64_t v266 = 128;
      // pto: %qr_hadamard_i8_inline979__rv_v2_pview
      ;
      pto::Shape<1, 1, 1, 384, 128> v267 = pto::Shape<1, 1, 1, 384, 128>();
      // pto: %qr_hadamard_i8_inline979__rv_v2_pview
      ;
      pto::Stride<49152, 49152, 49152, 128, 1> v268 = pto::Stride<49152, 49152, 49152, 128, 1>();
      // pto: %qr_hadamard_i8_inline979__rv_v2_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, 384, 128>, pto::Stride<49152, 49152, 49152, 128, 1>, pto::Layout::ND> v269 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 384, 128>, pto::Stride<49152, 49152, 49152, 128, 1>, pto::Layout::ND>(v264 + (v265 + v263 * v266), v267, v268);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v260, v269);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %buf_coefficients_l1_inline8440__ssa_v0
      ;
      Tile<TileType::Mat, half, 16, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v270 = Tile<TileType::Mat, half, 16, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v74, v53);
      // pto: %buf_coefficients_l1_inline8440__ssa_v0
      ;
      uint64_t v271 = (uint64_t) v44;
      TASSIGN(v270, v271);
      // pto: %89
      ;
      uint64_t v272 = (uint64_t) v228;
      // pto: %89
      ;
      int64_t v273 = (int64_t) (v272 * (uint64_t) v74);
      // pto: %90
      ;
      int64_t v274 = v273 < v56 ? v56 : v273;
      // pto: %coefficients_inline8426__ssa_v0_pview
      ;
      __gm__ half* v275 = PTOAS__GLOBAL_TENSOR_DATA(v104);
      // pto: %coefficients_inline8426__ssa_v0_pview
      ;
      const int64_t v276 = 0;
      // pto: %coefficients_inline8426__ssa_v0_pview
      ;
      const int64_t v277 = 384;
      // pto: %coefficients_inline8426__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 384> v278 = pto::Shape<1, 1, 1, 16, 384>();
      // pto: %coefficients_inline8426__ssa_v0_pview
      ;
      pto::Stride<6144, 6144, 6144, 384, 1> v279 = pto::Stride<6144, 6144, 6144, 384, 1>();
      // pto: %coefficients_inline8426__ssa_v0_pview
      ;
      GlobalTensor<half, pto::Shape<1, 1, 1, 16, 384>, pto::Stride<6144, 6144, 6144, 384, 1>, pto::Layout::ND> v280 = GlobalTensor<half, pto::Shape<1, 1, 1, 16, 384>, pto::Stride<6144, 6144, 6144, 384, 1>, pto::Layout::ND>(v275 + (v276 + v274 * v277), v278, v279);
      TLOAD(v270, v280);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %buf_query_left_inline8438__ssa_v0
      ;
      Tile<TileType::Left, int8_t, 384, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v281 = Tile<TileType::Left, int8_t, 384, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v51);
      // pto: %buf_query_left_inline8438__ssa_v0
      ;
      uint64_t v282 = (uint64_t) v43;
      TASSIGN(v281, v282);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      TMOV(v281, v260);
      // pto: %buf_coefficient_pair_inline8447__ssa_v0
      ;
      Tile<TileType::Left, half, 16, 384, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v283 = Tile<TileType::Left, half, 16, 384, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v74, v53);
      // pto: %buf_coefficient_pair_inline8447__ssa_v0
      ;
      uint64_t v284 = (uint64_t) v45;
      TASSIGN(v283, v284);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      TMOV(v283, v270);
      for (int64_t v285 = v56; v285 < v259; v285 += v49) {
        // pto: %91
        ;
        if (v285 >= v75) {
          int32_t v286 = (int32_t) v49;
          wait_flag_dev(v286);
        };
        // pto: %94
        ;
        int64_t v287 = v285 % v75;
        // pto: %95, %96, %97
        ;
        int64_t v288 = v287 < v56 ? (int64_t) ((uint64_t) v287 + (uint64_t) v75) : v287;
        // pto: %93, %99, %98
        ;
        int64_t v289 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v195 * (uint64_t) v76) + (uint64_t) ((int64_t) (uint64_t) v288 * (uint64_t) v65));
        // pto: %buf_key_l1_pool_inline8539__ssa_v0
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v290 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %buf_key_l1_pool_inline8539__ssa_v0
        ;
        uint64_t v291 = (uint64_t) v45;
        TASSIGN(v290, v291);
        // pto: %100, %92
        ;
        int64_t v292 = (int64_t) ((uint64_t) v251 + (uint64_t) ((int64_t) (uint64_t) v285 * (uint64_t) v55));
        // pto: %102
        ;
        int64_t v293 = v292 / v66;
        // pto: %103, %104
        ;
        int64_t v294 = (int64_t) ((uint64_t) v242 - (uint64_t) v49) / v66;
        // pto: %105
        ;
        int64_t v295 = v294 < v56 ? v56 : v294;
        // pto: %106
        ;
        int64_t v296 = v293 < v295 ? v293 : v295;
        // pto: %flat_offset_mul
        ;
        int64_t v297 = (int64_t) ((uint64_t) v239 * (uint64_t) v19);
        // pto: %flat_offset, %107
        ;
        int32_t v298 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v296)];
        // pto: %108
        ;
        int64_t v299 = (int64_t) v298;
        // pto: %109
        ;
        int64_t v300 = v299 < v56 ? v56 : v299;
        // pto: %110
        ;
        int64_t v301 = (int64_t) ((uint64_t) v300 * (uint64_t) v16);
        // pto: %111
        ;
        int64_t v302 = v301 % v51;
        // pto: %112, %113, %114
        ;
        int64_t v303 = v302 < v56 ? (int64_t) ((uint64_t) v302 + (uint64_t) v51) : v302;
        // pto: %115
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        if (v303 == v56) {
          // pto: %gather_row_view
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v304;
          // pto: %gather_row_view
          ;
          uint64_t v305 = (uint64_t) v45;
          TASSIGN(v304, v305);
          // pto: %116
          ;
          int64_t v306 = v301 / v51;
          // pto: %117
          ;
          int64_t v307 = v306 < v56 ? v56 : v306;
          // pto: %idx_kv_cache_inline8469__ssa_v0_pview
          ;
          __gm__ int8_t* v308 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %idx_kv_cache_inline8469__ssa_v0_pview
          ;
          const int64_t v309 = 0;
          // pto: %idx_kv_cache_inline8469__ssa_v0_pview
          ;
          const int64_t v310 = 128;
          // pto: %idx_kv_cache_inline8469__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 32, 128> v311 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %idx_kv_cache_inline8469__ssa_v0_pview
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v312 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %idx_kv_cache_inline8469__ssa_v0_pview
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v313 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v308 + (v309 + v307 * v310), v311, v312);
          TLOAD(v304, v313);
        } else {
          // pto: %118
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v314;
          // pto: %118
          ;
          uint64_t v315 = (uint64_t) v45;
          TASSIGN(v314, v315);
          // pto: %119
          ;
          int64_t v316 = v301 / v51;
          // pto: %120
          ;
          int64_t v317 = v316 < v56 ? v56 : v316;
          // pto: %idx_kv_cache_shift64_inline8488__ssa_v0_pview
          ;
          __gm__ int8_t* v318 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %idx_kv_cache_shift64_inline8488__ssa_v0_pview
          ;
          const int64_t v319 = 0;
          // pto: %idx_kv_cache_shift64_inline8488__ssa_v0_pview
          ;
          const int64_t v320 = 128;
          // pto: %idx_kv_cache_shift64_inline8488__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 32, 128> v321 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %idx_kv_cache_shift64_inline8488__ssa_v0_pview
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v322 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %idx_kv_cache_shift64_inline8488__ssa_v0_pview
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v323 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v318 + (v319 + v317 * v320), v321, v322);
          TLOAD(v314, v323);
        };
        // pto: %123, %124
        ;
        int64_t v324 = (int64_t) ((uint64_t) v292 + (uint64_t) v66) / v66;
        // pto: %128
        ;
        int64_t v325 = v324 < v295 ? v324 : v295;
        // pto: %131, %129
        ;
        int32_t v326 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v325)];
        // pto: %132
        ;
        int64_t v327 = (int64_t) v326;
        // pto: %133
        ;
        int64_t v328 = v327 < v56 ? v56 : v327;
        // pto: %134
        ;
        int64_t v329 = (int64_t) ((uint64_t) v328 * (uint64_t) v16);
        // pto: %135
        ;
        int64_t v330 = v329 % v51;
        // pto: %136, %137, %138
        ;
        int64_t v331 = v330 < v56 ? (int64_t) ((uint64_t) v330 + (uint64_t) v51) : v330;
        // pto: %139
        ;
        if (v331 == v56) {
          // pto: %140
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v332;
          // pto: %140
          ;
          uint64_t v333 = (uint64_t) v42;
          TASSIGN(v332, v333);
          // pto: %141
          ;
          int64_t v334 = v329 / v51;
          // pto: %142
          ;
          int64_t v335 = v334 < v56 ? v56 : v334;
          // pto: %143
          ;
          __gm__ int8_t* v336 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %143
          ;
          const int64_t v337 = 0;
          // pto: %143
          ;
          const int64_t v338 = 128;
          // pto: %143
          ;
          pto::Shape<1, 1, 1, 32, 128> v339 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %143
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v340 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %143
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v341 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v336 + (v337 + v335 * v338), v339, v340);
          TLOAD(v332, v341);
        } else {
          // pto: %144
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v342;
          // pto: %144
          ;
          uint64_t v343 = (uint64_t) v42;
          TASSIGN(v342, v343);
          // pto: %145
          ;
          int64_t v344 = v329 / v51;
          // pto: %146
          ;
          int64_t v345 = v344 < v56 ? v56 : v344;
          // pto: %147
          ;
          __gm__ int8_t* v346 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %147
          ;
          const int64_t v347 = 0;
          // pto: %147
          ;
          const int64_t v348 = 128;
          // pto: %147
          ;
          pto::Shape<1, 1, 1, 32, 128> v349 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %147
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v350 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %147
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v351 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v346 + (v347 + v345 * v348), v349, v350);
          TLOAD(v342, v351);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        // pto: %t__tmp_v360
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v352 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v360
        ;
        uint64_t v353 = (uint64_t) v45;
        TASSIGN(v352, v353);
        // pto: %buf_current_key_inline8472__ssa_v1
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v354 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8472__ssa_v1
        ;
        uint64_t v355 = (uint64_t) v46;
        TASSIGN(v354, v355);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v356 = static_cast<uint16_t>(v56);
        uint16_t v357 = static_cast<uint16_t>(v56);
        TEXTRACT(v354, v352, v356, v357);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        // pto: %149, %150
        ;
        int64_t v358 = (int64_t) ((uint64_t) v292 + (uint64_t) v73) / v66;
        // pto: %154
        ;
        int64_t v359 = v358 < v295 ? v358 : v295;
        // pto: %157, %155
        ;
        int32_t v360 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v359)];
        // pto: %158
        ;
        int64_t v361 = (int64_t) v360;
        // pto: %159
        ;
        int64_t v362 = v361 < v56 ? v56 : v361;
        // pto: %160
        ;
        int64_t v363 = (int64_t) ((uint64_t) v362 * (uint64_t) v16);
        // pto: %161
        ;
        int64_t v364 = v363 % v51;
        // pto: %162, %163, %164
        ;
        int64_t v365 = v364 < v56 ? (int64_t) ((uint64_t) v364 + (uint64_t) v51) : v364;
        // pto: %165
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        if (v365 == v56) {
          // pto: %166
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v366;
          // pto: %166
          ;
          uint64_t v367 = (uint64_t) v41;
          TASSIGN(v366, v367);
          // pto: %167
          ;
          int64_t v368 = v363 / v51;
          // pto: %168
          ;
          int64_t v369 = v368 < v56 ? v56 : v368;
          // pto: %169
          ;
          __gm__ int8_t* v370 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %169
          ;
          const int64_t v371 = 0;
          // pto: %169
          ;
          const int64_t v372 = 128;
          // pto: %169
          ;
          pto::Shape<1, 1, 1, 32, 128> v373 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %169
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v374 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %169
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v375 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v370 + (v371 + v369 * v372), v373, v374);
          TLOAD(v366, v375);
        } else {
          // pto: %170
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v376;
          // pto: %170
          ;
          uint64_t v377 = (uint64_t) v41;
          TASSIGN(v376, v377);
          // pto: %171
          ;
          int64_t v378 = v363 / v51;
          // pto: %172
          ;
          int64_t v379 = v378 < v56 ? v56 : v378;
          // pto: %173
          ;
          __gm__ int8_t* v380 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %173
          ;
          const int64_t v381 = 0;
          // pto: %173
          ;
          const int64_t v382 = 128;
          // pto: %173
          ;
          pto::Shape<1, 1, 1, 32, 128> v383 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %173
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v384 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %173
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v385 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v380 + (v381 + v379 * v382), v383, v384);
          TLOAD(v376, v385);
        };
        // pto: %176, %177
        ;
        int64_t v386 = (int64_t) ((uint64_t) v292 + (uint64_t) v40) / v66;
        // pto: %181
        ;
        int64_t v387 = v386 < v295 ? v386 : v295;
        // pto: %184, %182
        ;
        int32_t v388 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v387)];
        // pto: %185
        ;
        int64_t v389 = (int64_t) v388;
        // pto: %186
        ;
        int64_t v390 = v389 < v56 ? v56 : v389;
        // pto: %187
        ;
        int64_t v391 = (int64_t) ((uint64_t) v390 * (uint64_t) v16);
        // pto: %188
        ;
        int64_t v392 = v391 % v51;
        // pto: %189, %190, %191
        ;
        int64_t v393 = v392 < v56 ? (int64_t) ((uint64_t) v392 + (uint64_t) v51) : v392;
        // pto: %192
        ;
        if (v393 == v56) {
          // pto: %194
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v394;
          // pto: %194
          ;
          uint64_t v395 = (uint64_t) v39;
          TASSIGN(v394, v395);
          // pto: %195
          ;
          int64_t v396 = v391 / v51;
          // pto: %196
          ;
          int64_t v397 = v396 < v56 ? v56 : v396;
          // pto: %197
          ;
          __gm__ int8_t* v398 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %197
          ;
          const int64_t v399 = 0;
          // pto: %197
          ;
          const int64_t v400 = 128;
          // pto: %197
          ;
          pto::Shape<1, 1, 1, 32, 128> v401 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %197
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v402 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %197
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v403 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v398 + (v399 + v397 * v400), v401, v402);
          TLOAD(v394, v403);
        } else {
          // pto: %199
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v404;
          // pto: %199
          ;
          uint64_t v405 = (uint64_t) v39;
          TASSIGN(v404, v405);
          // pto: %200
          ;
          int64_t v406 = v391 / v51;
          // pto: %201
          ;
          int64_t v407 = v406 < v56 ? v56 : v406;
          // pto: %202
          ;
          __gm__ int8_t* v408 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %202
          ;
          const int64_t v409 = 0;
          // pto: %202
          ;
          const int64_t v410 = 128;
          // pto: %202
          ;
          pto::Shape<1, 1, 1, 32, 128> v411 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %202
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v412 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %202
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v413 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v408 + (v409 + v407 * v410), v411, v412);
          TLOAD(v404, v413);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
        // pto: %t__tmp_v363
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v414 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v363
        ;
        uint64_t v415 = (uint64_t) v45;
        TASSIGN(v414, v415);
        // pto: %buf_prefetched_key_inline8551__ssa_v1
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v416 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8551__ssa_v1
        ;
        uint64_t v417 = (uint64_t) v43;
        TASSIGN(v416, v417);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
        uint16_t v418 = static_cast<uint16_t>(v56);
        uint16_t v419 = static_cast<uint16_t>(v73);
        TEXTRACT(v416, v414, v418, v419);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        // pto: %buf_key_panel_inline8420__ssa_v0
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v420 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8420__ssa_v0
        ;
        uint64_t v421 = (uint64_t) v46;
        TASSIGN(v420, v421);
        // pto: %buf_scores_l1_inline8475__ssa_v0
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v422 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8475__ssa_v0
        ;
        uint64_t v423 = (uint64_t) v43;
        TASSIGN(v422, v423);
        // pto: %buf_scores_inline8619__ssa_v1
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v424 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8619__ssa_v1
        ;
        uint64_t v425 = (uint64_t) v43;
        TASSIGN(v424, v425);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        TMATMUL(v424, v281, v420);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v426 = static_cast<uint64_t>(v77);
        uint16_t v427 = static_cast<uint16_t>(v56);
        uint16_t v428 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v422, v424, v426, v427, v428);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        // pto: %buf_previous_l1_inline8435__ssa_v1
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v429 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8435__ssa_v1
        ;
        uint64_t v430 = (uint64_t) v43;
        TASSIGN(v429, v430);
        // pto: %buf_current_key_inline8472__ssa_v7
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v431 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8472__ssa_v7
        ;
        uint64_t v432 = (uint64_t) v43;
        TASSIGN(v431, v432);
        // pto: %204, %205
        ;
        int64_t v433 = (int64_t) ((uint64_t) v292 + (uint64_t) v51) / v66;
        // pto: %209
        ;
        int64_t v434 = v433 < v295 ? v433 : v295;
        // pto: %212, %210
        ;
        int32_t v435 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v434)];
        // pto: %213
        ;
        int64_t v436 = (int64_t) v435;
        // pto: %214
        ;
        int64_t v437 = v436 < v56 ? v56 : v436;
        // pto: %215
        ;
        int64_t v438 = (int64_t) ((uint64_t) v437 * (uint64_t) v16);
        // pto: %216
        ;
        int64_t v439 = v438 % v51;
        // pto: %217, %218, %219
        ;
        int64_t v440 = v439 < v56 ? (int64_t) ((uint64_t) v439 + (uint64_t) v51) : v439;
        // pto: %220
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        if (v440 == v56) {
          // pto: %221
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v441;
          // pto: %221
          ;
          uint64_t v442 = (uint64_t) v45;
          TASSIGN(v441, v442);
          // pto: %222
          ;
          int64_t v443 = v438 / v51;
          // pto: %223
          ;
          int64_t v444 = v443 < v56 ? v56 : v443;
          // pto: %224
          ;
          __gm__ int8_t* v445 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %224
          ;
          const int64_t v446 = 0;
          // pto: %224
          ;
          const int64_t v447 = 128;
          // pto: %224
          ;
          pto::Shape<1, 1, 1, 32, 128> v448 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %224
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v449 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %224
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v450 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v445 + (v446 + v444 * v447), v448, v449);
          TLOAD(v441, v450);
        } else {
          // pto: %225
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v451;
          // pto: %225
          ;
          uint64_t v452 = (uint64_t) v45;
          TASSIGN(v451, v452);
          // pto: %226
          ;
          int64_t v453 = v438 / v51;
          // pto: %227
          ;
          int64_t v454 = v453 < v56 ? v56 : v453;
          // pto: %228
          ;
          __gm__ int8_t* v455 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %228
          ;
          const int64_t v456 = 0;
          // pto: %228
          ;
          const int64_t v457 = 128;
          // pto: %228
          ;
          pto::Shape<1, 1, 1, 32, 128> v458 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %228
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v459 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %228
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v460 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v455 + (v456 + v454 * v457), v458, v459);
          TLOAD(v451, v460);
        };
        // pto: %231, %232
        ;
        int64_t v461 = (int64_t) ((uint64_t) v292 + (uint64_t) v38) / v66;
        // pto: %236
        ;
        int64_t v462 = v461 < v295 ? v461 : v295;
        // pto: %239, %237
        ;
        int32_t v463 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v462)];
        // pto: %240
        ;
        int64_t v464 = (int64_t) v463;
        // pto: %241
        ;
        int64_t v465 = v464 < v56 ? v56 : v464;
        // pto: %242
        ;
        int64_t v466 = (int64_t) ((uint64_t) v465 * (uint64_t) v16);
        // pto: %243
        ;
        int64_t v467 = v466 % v51;
        // pto: %244, %245, %246
        ;
        int64_t v468 = v467 < v56 ? (int64_t) ((uint64_t) v467 + (uint64_t) v51) : v467;
        // pto: %247
        ;
        if (v468 == v56) {
          // pto: %249
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v469;
          // pto: %249
          ;
          uint64_t v470 = (uint64_t) v42;
          TASSIGN(v469, v470);
          // pto: %250
          ;
          int64_t v471 = v466 / v51;
          // pto: %251
          ;
          int64_t v472 = v471 < v56 ? v56 : v471;
          // pto: %252
          ;
          __gm__ int8_t* v473 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %252
          ;
          const int64_t v474 = 0;
          // pto: %252
          ;
          const int64_t v475 = 128;
          // pto: %252
          ;
          pto::Shape<1, 1, 1, 32, 128> v476 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %252
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v477 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %252
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v478 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v473 + (v474 + v472 * v475), v476, v477);
          TLOAD(v469, v478);
        } else {
          // pto: %254
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v479;
          // pto: %254
          ;
          uint64_t v480 = (uint64_t) v42;
          TASSIGN(v479, v480);
          // pto: %255
          ;
          int64_t v481 = v466 / v51;
          // pto: %256
          ;
          int64_t v482 = v481 < v56 ? v56 : v481;
          // pto: %257
          ;
          __gm__ int8_t* v483 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %257
          ;
          const int64_t v484 = 0;
          // pto: %257
          ;
          const int64_t v485 = 128;
          // pto: %257
          ;
          pto::Shape<1, 1, 1, 32, 128> v486 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %257
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v487 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %257
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v488 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v483 + (v484 + v482 * v485), v486, v487);
          TLOAD(v479, v488);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
        // pto: %t__tmp_v366
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v489 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v366
        ;
        uint64_t v490 = (uint64_t) v45;
        TASSIGN(v489, v490);
        // pto: %buf_prefetched_key_inline8551__ssa_v6
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v491 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8551__ssa_v6
        ;
        uint64_t v492 = (uint64_t) v47;
        TASSIGN(v491, v492);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
        uint16_t v493 = static_cast<uint16_t>(v56);
        uint16_t v494 = static_cast<uint16_t>(v56);
        TEXTRACT(v491, v489, v493, v494);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        // pto: %buf_key_panel_inline8420__ssa_v3
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v495 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8420__ssa_v3
        ;
        uint64_t v496 = (uint64_t) v43;
        TASSIGN(v495, v496);
        // pto: %buf_scores_l1_inline8475__ssa_v4
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v497 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8475__ssa_v4
        ;
        uint64_t v498 = (uint64_t) v44;
        TASSIGN(v497, v498);
        // pto: %buf_previous_pair_inline8418__ssa_v1
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v499 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8418__ssa_v1
        ;
        uint64_t v500 = (uint64_t) v46;
        TASSIGN(v499, v500);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        uint16_t v501 = static_cast<uint16_t>(v56);
        uint16_t v502 = static_cast<uint16_t>(v56);
        TEXTRACT(v499, v429, v501, v502);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %buf_scores_inline8619__ssa_v3
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v503 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8619__ssa_v3
        ;
        uint64_t v504 = (uint64_t) v43;
        TASSIGN(v503, v504);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL(v503, v281, v495);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        // pto: %buf_reduced_pair_inline8484__ssa_v1
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v505 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8484__ssa_v1
        ;
        uint64_t v506 = (uint64_t) v48;
        TASSIGN(v505, v506);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        TMATMUL(v505, v283, v499);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        uint64_t v507 = static_cast<uint64_t>(v77);
        uint16_t v508 = static_cast<uint16_t>(v56);
        uint16_t v509 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v497, v503, v507, v508, v509);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID1);
        v505.SetValidShape(v65, v73);
        // pto: %258
        ;
        int64_t v510 = v289 < v56 ? v56 : v289;
        // pto: %buf_score_transfer_inline8569__ssa_v0_pview
        ;
        __gm__ float* v511 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %buf_score_transfer_inline8569__ssa_v0_pview
        ;
        const int64_t v512 = 0;
        // pto: %buf_score_transfer_inline8569__ssa_v0_pview
        ;
        const int64_t v513 = 1024;
        // pto: %buf_score_transfer_inline8569__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 6, 64> v514 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %buf_score_transfer_inline8569__ssa_v0_pview
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v515 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %buf_score_transfer_inline8569__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v516 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v511 + (v512 + v510 * v513), v514, v515);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
        TSTORE(v516, v505);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
        // pto: %buf_previous_l1_inline8435__ssa_v2
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v517 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8435__ssa_v2
        ;
        uint64_t v518 = (uint64_t) v44;
        TASSIGN(v517, v518);
        // pto: %buf_current_key_inline8472__ssa_v14
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v519 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8472__ssa_v14
        ;
        uint64_t v520 = (uint64_t) v47;
        TASSIGN(v519, v520);
        // pto: %262, %263
        ;
        int64_t v521 = (int64_t) ((uint64_t) v292 + (uint64_t) v78) / v66;
        // pto: %267
        ;
        int64_t v522 = v521 < v295 ? v521 : v295;
        // pto: %270, %268
        ;
        int32_t v523 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v522)];
        // pto: %271
        ;
        int64_t v524 = (int64_t) v523;
        // pto: %272
        ;
        int64_t v525 = v524 < v56 ? v56 : v524;
        // pto: %273
        ;
        int64_t v526 = (int64_t) ((uint64_t) v525 * (uint64_t) v16);
        // pto: %274
        ;
        int64_t v527 = v526 % v51;
        // pto: %275, %276, %277
        ;
        int64_t v528 = v527 < v56 ? (int64_t) ((uint64_t) v527 + (uint64_t) v51) : v527;
        // pto: %278
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        if (v528 == v56) {
          // pto: %279
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v529;
          // pto: %279
          ;
          uint64_t v530 = (uint64_t) v41;
          TASSIGN(v529, v530);
          // pto: %280
          ;
          int64_t v531 = v526 / v51;
          // pto: %281
          ;
          int64_t v532 = v531 < v56 ? v56 : v531;
          // pto: %282
          ;
          __gm__ int8_t* v533 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %282
          ;
          const int64_t v534 = 0;
          // pto: %282
          ;
          const int64_t v535 = 128;
          // pto: %282
          ;
          pto::Shape<1, 1, 1, 32, 128> v536 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %282
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v537 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %282
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v538 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v533 + (v534 + v532 * v535), v536, v537);
          TLOAD(v529, v538);
        } else {
          // pto: %283
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v539;
          // pto: %283
          ;
          uint64_t v540 = (uint64_t) v41;
          TASSIGN(v539, v540);
          // pto: %284
          ;
          int64_t v541 = v526 / v51;
          // pto: %285
          ;
          int64_t v542 = v541 < v56 ? v56 : v541;
          // pto: %286
          ;
          __gm__ int8_t* v543 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %286
          ;
          const int64_t v544 = 0;
          // pto: %286
          ;
          const int64_t v545 = 128;
          // pto: %286
          ;
          pto::Shape<1, 1, 1, 32, 128> v546 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %286
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v547 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %286
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v548 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v543 + (v544 + v542 * v545), v546, v547);
          TLOAD(v539, v548);
        };
        // pto: %289, %290
        ;
        int64_t v549 = (int64_t) ((uint64_t) v292 + (uint64_t) v37) / v66;
        // pto: %294
        ;
        int64_t v550 = v549 < v295 ? v549 : v295;
        // pto: %297, %295
        ;
        int32_t v551 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v550)];
        // pto: %298
        ;
        int64_t v552 = (int64_t) v551;
        // pto: %299
        ;
        int64_t v553 = v552 < v56 ? v56 : v552;
        // pto: %300
        ;
        int64_t v554 = (int64_t) ((uint64_t) v553 * (uint64_t) v16);
        // pto: %301
        ;
        int64_t v555 = v554 % v51;
        // pto: %302, %303, %304
        ;
        int64_t v556 = v555 < v56 ? (int64_t) ((uint64_t) v555 + (uint64_t) v51) : v555;
        // pto: %305
        ;
        if (v556 == v56) {
          // pto: %307
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v557;
          // pto: %307
          ;
          uint64_t v558 = (uint64_t) v39;
          TASSIGN(v557, v558);
          // pto: %308
          ;
          int64_t v559 = v554 / v51;
          // pto: %309
          ;
          int64_t v560 = v559 < v56 ? v56 : v559;
          // pto: %310
          ;
          __gm__ int8_t* v561 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %310
          ;
          const int64_t v562 = 0;
          // pto: %310
          ;
          const int64_t v563 = 128;
          // pto: %310
          ;
          pto::Shape<1, 1, 1, 32, 128> v564 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %310
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v565 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %310
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v566 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v561 + (v562 + v560 * v563), v564, v565);
          TLOAD(v557, v566);
        } else {
          // pto: %312
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v567;
          // pto: %312
          ;
          uint64_t v568 = (uint64_t) v39;
          TASSIGN(v567, v568);
          // pto: %313
          ;
          int64_t v569 = v554 / v51;
          // pto: %314
          ;
          int64_t v570 = v569 < v56 ? v56 : v569;
          // pto: %315
          ;
          __gm__ int8_t* v571 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %315
          ;
          const int64_t v572 = 0;
          // pto: %315
          ;
          const int64_t v573 = 128;
          // pto: %315
          ;
          pto::Shape<1, 1, 1, 32, 128> v574 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %315
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v575 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %315
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v576 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v571 + (v572 + v570 * v573), v574, v575);
          TLOAD(v567, v576);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        // pto: %t__tmp_v370
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v577 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v370
        ;
        uint64_t v578 = (uint64_t) v45;
        TASSIGN(v577, v578);
        // pto: %buf_prefetched_key_inline8551__ssa_v11
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v579 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8551__ssa_v11
        ;
        uint64_t v580 = (uint64_t) v43;
        TASSIGN(v579, v580);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v581 = static_cast<uint16_t>(v56);
        uint16_t v582 = static_cast<uint16_t>(v73);
        TEXTRACT(v579, v577, v581, v582);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        // pto: %buf_key_panel_inline8420__ssa_v6
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v583 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8420__ssa_v6
        ;
        uint64_t v584 = (uint64_t) v47;
        TASSIGN(v583, v584);
        // pto: %buf_scores_l1_inline8475__ssa_v8
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v585 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8475__ssa_v8
        ;
        uint64_t v586 = (uint64_t) v43;
        TASSIGN(v585, v586);
        // pto: %buf_previous_pair_inline8418__ssa_v2
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v587 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8418__ssa_v2
        ;
        uint64_t v588 = (uint64_t) v46;
        TASSIGN(v587, v588);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v589 = static_cast<uint16_t>(v56);
        uint16_t v590 = static_cast<uint16_t>(v56);
        TEXTRACT(v587, v517, v589, v590);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        // pto: %buf_scores_inline8619__ssa_v6
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v591 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8619__ssa_v6
        ;
        uint64_t v592 = (uint64_t) v43;
        TASSIGN(v591, v592);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v591, v281, v583);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
        // pto: %buf_reduced_pair_inline8484__ssa_v2
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v593 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8484__ssa_v2
        ;
        uint64_t v594 = (uint64_t) v48;
        TASSIGN(v593, v594);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
        TMATMUL(v593, v283, v587);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
        uint64_t v595 = static_cast<uint64_t>(v77);
        uint16_t v596 = static_cast<uint16_t>(v56);
        uint16_t v597 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v585, v591, v595, v596, v597);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID2);
        v593.SetValidShape(v65, v73);
        // pto: %319
        ;
        __gm__ float* v598 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %319
        ;
        const int64_t v599 = 64;
        // pto: %319
        ;
        const int64_t v600 = 1024;
        // pto: %319
        ;
        pto::Shape<1, 1, 1, 6, 64> v601 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %319
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v602 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %319
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v603 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v598 + (v599 + v510 * v600), v601, v602);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
        TSTORE(v603, v593);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
        // pto: %buf_previous_l1_inline8435__ssa_v3
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v604 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8435__ssa_v3
        ;
        uint64_t v605 = (uint64_t) v43;
        TASSIGN(v604, v605);
        // pto: %buf_current_key_inline8472__ssa_v21
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v606 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8472__ssa_v21
        ;
        uint64_t v607 = (uint64_t) v43;
        TASSIGN(v606, v607);
        // pto: %321, %322
        ;
        int64_t v608 = (int64_t) ((uint64_t) v292 + (uint64_t) v79) / v66;
        // pto: %326
        ;
        int64_t v609 = v608 < v295 ? v608 : v295;
        // pto: %329, %327
        ;
        int32_t v610 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v609)];
        // pto: %330
        ;
        int64_t v611 = (int64_t) v610;
        // pto: %331
        ;
        int64_t v612 = v611 < v56 ? v56 : v611;
        // pto: %332
        ;
        int64_t v613 = (int64_t) ((uint64_t) v612 * (uint64_t) v16);
        // pto: %333
        ;
        int64_t v614 = v613 % v51;
        // pto: %334, %335, %336
        ;
        int64_t v615 = v614 < v56 ? (int64_t) ((uint64_t) v614 + (uint64_t) v51) : v614;
        // pto: %337
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        if (v615 == v56) {
          // pto: %338
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v616;
          // pto: %338
          ;
          uint64_t v617 = (uint64_t) v45;
          TASSIGN(v616, v617);
          // pto: %339
          ;
          int64_t v618 = v613 / v51;
          // pto: %340
          ;
          int64_t v619 = v618 < v56 ? v56 : v618;
          // pto: %341
          ;
          __gm__ int8_t* v620 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %341
          ;
          const int64_t v621 = 0;
          // pto: %341
          ;
          const int64_t v622 = 128;
          // pto: %341
          ;
          pto::Shape<1, 1, 1, 32, 128> v623 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %341
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v624 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %341
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v625 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v620 + (v621 + v619 * v622), v623, v624);
          TLOAD(v616, v625);
        } else {
          // pto: %342
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v626;
          // pto: %342
          ;
          uint64_t v627 = (uint64_t) v45;
          TASSIGN(v626, v627);
          // pto: %343
          ;
          int64_t v628 = v613 / v51;
          // pto: %344
          ;
          int64_t v629 = v628 < v56 ? v56 : v628;
          // pto: %345
          ;
          __gm__ int8_t* v630 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %345
          ;
          const int64_t v631 = 0;
          // pto: %345
          ;
          const int64_t v632 = 128;
          // pto: %345
          ;
          pto::Shape<1, 1, 1, 32, 128> v633 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %345
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v634 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %345
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v635 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v630 + (v631 + v629 * v632), v633, v634);
          TLOAD(v626, v635);
        };
        // pto: %348, %349
        ;
        int64_t v636 = (int64_t) ((uint64_t) v292 + (uint64_t) v54) / v66;
        // pto: %353
        ;
        int64_t v637 = v636 < v295 ? v636 : v295;
        // pto: %356, %354
        ;
        int32_t v638 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v637)];
        // pto: %357
        ;
        int64_t v639 = (int64_t) v638;
        // pto: %358
        ;
        int64_t v640 = v639 < v56 ? v56 : v639;
        // pto: %359
        ;
        int64_t v641 = (int64_t) ((uint64_t) v640 * (uint64_t) v16);
        // pto: %360
        ;
        int64_t v642 = v641 % v51;
        // pto: %361, %362, %363
        ;
        int64_t v643 = v642 < v56 ? (int64_t) ((uint64_t) v642 + (uint64_t) v51) : v642;
        // pto: %364
        ;
        if (v643 == v56) {
          // pto: %366
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v644;
          // pto: %366
          ;
          uint64_t v645 = (uint64_t) v42;
          TASSIGN(v644, v645);
          // pto: %367
          ;
          int64_t v646 = v641 / v51;
          // pto: %368
          ;
          int64_t v647 = v646 < v56 ? v56 : v646;
          // pto: %369
          ;
          __gm__ int8_t* v648 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %369
          ;
          const int64_t v649 = 0;
          // pto: %369
          ;
          const int64_t v650 = 128;
          // pto: %369
          ;
          pto::Shape<1, 1, 1, 32, 128> v651 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %369
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v652 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %369
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v653 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v648 + (v649 + v647 * v650), v651, v652);
          TLOAD(v644, v653);
        } else {
          // pto: %371
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v654;
          // pto: %371
          ;
          uint64_t v655 = (uint64_t) v42;
          TASSIGN(v654, v655);
          // pto: %372
          ;
          int64_t v656 = v641 / v51;
          // pto: %373
          ;
          int64_t v657 = v656 < v56 ? v56 : v656;
          // pto: %374
          ;
          __gm__ int8_t* v658 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %374
          ;
          const int64_t v659 = 0;
          // pto: %374
          ;
          const int64_t v660 = 128;
          // pto: %374
          ;
          pto::Shape<1, 1, 1, 32, 128> v661 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %374
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v662 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %374
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v663 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v658 + (v659 + v657 * v660), v661, v662);
          TLOAD(v654, v663);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
        // pto: %t__tmp_v374
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v664 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v374
        ;
        uint64_t v665 = (uint64_t) v45;
        TASSIGN(v664, v665);
        // pto: %buf_prefetched_key_inline8551__ssa_v16
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v666 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8551__ssa_v16
        ;
        uint64_t v667 = (uint64_t) v47;
        TASSIGN(v666, v667);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        uint16_t v668 = static_cast<uint16_t>(v56);
        uint16_t v669 = static_cast<uint16_t>(v56);
        TEXTRACT(v666, v664, v668, v669);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
        // pto: %buf_key_panel_inline8420__ssa_v9
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v670 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8420__ssa_v9
        ;
        uint64_t v671 = (uint64_t) v43;
        TASSIGN(v670, v671);
        // pto: %buf_scores_l1_inline8475__ssa_v12
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v672 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8475__ssa_v12
        ;
        uint64_t v673 = (uint64_t) v44;
        TASSIGN(v672, v673);
        // pto: %buf_previous_pair_inline8418__ssa_v3
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v674 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8418__ssa_v3
        ;
        uint64_t v675 = (uint64_t) v46;
        TASSIGN(v674, v675);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        uint16_t v676 = static_cast<uint16_t>(v56);
        uint16_t v677 = static_cast<uint16_t>(v56);
        TEXTRACT(v674, v604, v676, v677);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        // pto: %buf_scores_inline8619__ssa_v9
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v678 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8619__ssa_v9
        ;
        uint64_t v679 = (uint64_t) v43;
        TASSIGN(v678, v679);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
        TMATMUL(v678, v281, v670);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
        // pto: %buf_reduced_pair_inline8484__ssa_v3
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v680 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8484__ssa_v3
        ;
        uint64_t v681 = (uint64_t) v48;
        TASSIGN(v680, v681);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
        TMATMUL(v680, v283, v674);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID6);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
        uint64_t v682 = static_cast<uint64_t>(v77);
        uint16_t v683 = static_cast<uint16_t>(v56);
        uint16_t v684 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v672, v678, v682, v683, v684);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID3);
        v680.SetValidShape(v65, v73);
        // pto: %378
        ;
        __gm__ float* v685 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %378
        ;
        const int64_t v686 = 128;
        // pto: %378
        ;
        const int64_t v687 = 1024;
        // pto: %378
        ;
        pto::Shape<1, 1, 1, 6, 64> v688 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %378
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v689 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %378
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v690 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v685 + (v686 + v510 * v687), v688, v689);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID6);
        TSTORE(v690, v680);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
        // pto: %buf_previous_l1_inline8435__ssa_v4
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v691 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8435__ssa_v4
        ;
        uint64_t v692 = (uint64_t) v44;
        TASSIGN(v691, v692);
        // pto: %buf_current_key_inline8472__ssa_v28
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v693 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8472__ssa_v28
        ;
        uint64_t v694 = (uint64_t) v47;
        TASSIGN(v693, v694);
        // pto: %380, %381
        ;
        int64_t v695 = (int64_t) ((uint64_t) v292 + (uint64_t) v80) / v66;
        // pto: %385
        ;
        int64_t v696 = v695 < v295 ? v695 : v295;
        // pto: %388, %386
        ;
        int32_t v697 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v696)];
        // pto: %389
        ;
        int64_t v698 = (int64_t) v697;
        // pto: %390
        ;
        int64_t v699 = v698 < v56 ? v56 : v698;
        // pto: %391
        ;
        int64_t v700 = (int64_t) ((uint64_t) v699 * (uint64_t) v16);
        // pto: %392
        ;
        int64_t v701 = v700 % v51;
        // pto: %393, %394, %395
        ;
        int64_t v702 = v701 < v56 ? (int64_t) ((uint64_t) v701 + (uint64_t) v51) : v701;
        // pto: %396
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
        if (v702 == v56) {
          // pto: %397
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v703;
          // pto: %397
          ;
          uint64_t v704 = (uint64_t) v41;
          TASSIGN(v703, v704);
          // pto: %398
          ;
          int64_t v705 = v700 / v51;
          // pto: %399
          ;
          int64_t v706 = v705 < v56 ? v56 : v705;
          // pto: %400
          ;
          __gm__ int8_t* v707 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %400
          ;
          const int64_t v708 = 0;
          // pto: %400
          ;
          const int64_t v709 = 128;
          // pto: %400
          ;
          pto::Shape<1, 1, 1, 32, 128> v710 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %400
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v711 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %400
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v712 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v707 + (v708 + v706 * v709), v710, v711);
          TLOAD(v703, v712);
        } else {
          // pto: %401
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v713;
          // pto: %401
          ;
          uint64_t v714 = (uint64_t) v41;
          TASSIGN(v713, v714);
          // pto: %402
          ;
          int64_t v715 = v700 / v51;
          // pto: %403
          ;
          int64_t v716 = v715 < v56 ? v56 : v715;
          // pto: %404
          ;
          __gm__ int8_t* v717 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %404
          ;
          const int64_t v718 = 0;
          // pto: %404
          ;
          const int64_t v719 = 128;
          // pto: %404
          ;
          pto::Shape<1, 1, 1, 32, 128> v720 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %404
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v721 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %404
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v722 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v717 + (v718 + v716 * v719), v720, v721);
          TLOAD(v713, v722);
        };
        // pto: %407, %408
        ;
        int64_t v723 = (int64_t) ((uint64_t) v292 + (uint64_t) v36) / v66;
        // pto: %412
        ;
        int64_t v724 = v723 < v295 ? v723 : v295;
        // pto: %415, %413
        ;
        int32_t v725 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v724)];
        // pto: %416
        ;
        int64_t v726 = (int64_t) v725;
        // pto: %417
        ;
        int64_t v727 = v726 < v56 ? v56 : v726;
        // pto: %418
        ;
        int64_t v728 = (int64_t) ((uint64_t) v727 * (uint64_t) v16);
        // pto: %419
        ;
        int64_t v729 = v728 % v51;
        // pto: %420, %421, %422
        ;
        int64_t v730 = v729 < v56 ? (int64_t) ((uint64_t) v729 + (uint64_t) v51) : v729;
        // pto: %423
        ;
        if (v730 == v56) {
          // pto: %425
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v731;
          // pto: %425
          ;
          uint64_t v732 = (uint64_t) v39;
          TASSIGN(v731, v732);
          // pto: %426
          ;
          int64_t v733 = v728 / v51;
          // pto: %427
          ;
          int64_t v734 = v733 < v56 ? v56 : v733;
          // pto: %428
          ;
          __gm__ int8_t* v735 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %428
          ;
          const int64_t v736 = 0;
          // pto: %428
          ;
          const int64_t v737 = 128;
          // pto: %428
          ;
          pto::Shape<1, 1, 1, 32, 128> v738 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %428
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v739 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %428
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v740 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v735 + (v736 + v734 * v737), v738, v739);
          TLOAD(v731, v740);
        } else {
          // pto: %430
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v741;
          // pto: %430
          ;
          uint64_t v742 = (uint64_t) v39;
          TASSIGN(v741, v742);
          // pto: %431
          ;
          int64_t v743 = v728 / v51;
          // pto: %432
          ;
          int64_t v744 = v743 < v56 ? v56 : v743;
          // pto: %433
          ;
          __gm__ int8_t* v745 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %433
          ;
          const int64_t v746 = 0;
          // pto: %433
          ;
          const int64_t v747 = 128;
          // pto: %433
          ;
          pto::Shape<1, 1, 1, 32, 128> v748 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %433
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v749 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %433
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v750 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v745 + (v746 + v744 * v747), v748, v749);
          TLOAD(v741, v750);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
        // pto: %t__tmp_v378
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v751 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v378
        ;
        uint64_t v752 = (uint64_t) v45;
        TASSIGN(v751, v752);
        // pto: %buf_prefetched_key_inline8551__ssa_v21
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v753 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8551__ssa_v21
        ;
        uint64_t v754 = (uint64_t) v43;
        TASSIGN(v753, v754);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
        uint16_t v755 = static_cast<uint16_t>(v56);
        uint16_t v756 = static_cast<uint16_t>(v73);
        TEXTRACT(v753, v751, v755, v756);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
        // pto: %buf_key_panel_inline8420__ssa_v12
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v757 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8420__ssa_v12
        ;
        uint64_t v758 = (uint64_t) v47;
        TASSIGN(v757, v758);
        // pto: %buf_scores_l1_inline8475__ssa_v16
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v759 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8475__ssa_v16
        ;
        uint64_t v760 = (uint64_t) v43;
        TASSIGN(v759, v760);
        // pto: %buf_previous_pair_inline8418__ssa_v4
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v761 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8418__ssa_v4
        ;
        uint64_t v762 = (uint64_t) v46;
        TASSIGN(v761, v762);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID3);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        uint16_t v763 = static_cast<uint16_t>(v56);
        uint16_t v764 = static_cast<uint16_t>(v56);
        TEXTRACT(v761, v691, v763, v764);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        // pto: %buf_scores_inline8619__ssa_v12
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v765 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8619__ssa_v12
        ;
        uint64_t v766 = (uint64_t) v43;
        TASSIGN(v765, v766);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
        TMATMUL(v765, v281, v757);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID7);
        // pto: %buf_reduced_pair_inline8484__ssa_v4
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v767 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8484__ssa_v4
        ;
        uint64_t v768 = (uint64_t) v48;
        TASSIGN(v767, v768);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
        TMATMUL(v767, v283, v761);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID7);
        uint64_t v769 = static_cast<uint64_t>(v77);
        uint16_t v770 = static_cast<uint16_t>(v56);
        uint16_t v771 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v759, v765, v769, v770, v771);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID4);
        v767.SetValidShape(v65, v73);
        // pto: %437
        ;
        __gm__ float* v772 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %437
        ;
        const int64_t v773 = 192;
        // pto: %437
        ;
        const int64_t v774 = 1024;
        // pto: %437
        ;
        pto::Shape<1, 1, 1, 6, 64> v775 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %437
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v776 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %437
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v777 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v772 + (v773 + v510 * v774), v775, v776);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        TSTORE(v777, v767);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline8435__ssa_v5
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v778 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8435__ssa_v5
        ;
        uint64_t v779 = (uint64_t) v43;
        TASSIGN(v778, v779);
        // pto: %buf_current_key_inline8472__ssa_v35
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v780 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8472__ssa_v35
        ;
        uint64_t v781 = (uint64_t) v43;
        TASSIGN(v780, v781);
        // pto: %439, %440
        ;
        int64_t v782 = (int64_t) ((uint64_t) v292 + (uint64_t) v53) / v66;
        // pto: %444
        ;
        int64_t v783 = v782 < v295 ? v782 : v295;
        // pto: %447, %445
        ;
        int32_t v784 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v783)];
        // pto: %448
        ;
        int64_t v785 = (int64_t) v784;
        // pto: %449
        ;
        int64_t v786 = v785 < v56 ? v56 : v785;
        // pto: %450
        ;
        int64_t v787 = (int64_t) ((uint64_t) v786 * (uint64_t) v16);
        // pto: %451
        ;
        int64_t v788 = v787 % v51;
        // pto: %452, %453, %454
        ;
        int64_t v789 = v788 < v56 ? (int64_t) ((uint64_t) v788 + (uint64_t) v51) : v788;
        // pto: %455
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
        if (v789 == v56) {
          // pto: %456
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v790;
          // pto: %456
          ;
          uint64_t v791 = (uint64_t) v45;
          TASSIGN(v790, v791);
          // pto: %457
          ;
          int64_t v792 = v787 / v51;
          // pto: %458
          ;
          int64_t v793 = v792 < v56 ? v56 : v792;
          // pto: %459
          ;
          __gm__ int8_t* v794 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %459
          ;
          const int64_t v795 = 0;
          // pto: %459
          ;
          const int64_t v796 = 128;
          // pto: %459
          ;
          pto::Shape<1, 1, 1, 32, 128> v797 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %459
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v798 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %459
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v799 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v794 + (v795 + v793 * v796), v797, v798);
          TLOAD(v790, v799);
        } else {
          // pto: %460
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v800;
          // pto: %460
          ;
          uint64_t v801 = (uint64_t) v45;
          TASSIGN(v800, v801);
          // pto: %461
          ;
          int64_t v802 = v787 / v51;
          // pto: %462
          ;
          int64_t v803 = v802 < v56 ? v56 : v802;
          // pto: %463
          ;
          __gm__ int8_t* v804 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %463
          ;
          const int64_t v805 = 0;
          // pto: %463
          ;
          const int64_t v806 = 128;
          // pto: %463
          ;
          pto::Shape<1, 1, 1, 32, 128> v807 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %463
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v808 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %463
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v809 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v804 + (v805 + v803 * v806), v807, v808);
          TLOAD(v800, v809);
        };
        // pto: %466, %467
        ;
        int64_t v810 = (int64_t) ((uint64_t) v292 + (uint64_t) v35) / v66;
        // pto: %471
        ;
        int64_t v811 = v810 < v295 ? v810 : v295;
        // pto: %474, %472
        ;
        int32_t v812 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v811)];
        // pto: %475
        ;
        int64_t v813 = (int64_t) v812;
        // pto: %476
        ;
        int64_t v814 = v813 < v56 ? v56 : v813;
        // pto: %477
        ;
        int64_t v815 = (int64_t) ((uint64_t) v814 * (uint64_t) v16);
        // pto: %478
        ;
        int64_t v816 = v815 % v51;
        // pto: %479, %480, %481
        ;
        int64_t v817 = v816 < v56 ? (int64_t) ((uint64_t) v816 + (uint64_t) v51) : v816;
        // pto: %482
        ;
        if (v817 == v56) {
          // pto: %484
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v818;
          // pto: %484
          ;
          uint64_t v819 = (uint64_t) v42;
          TASSIGN(v818, v819);
          // pto: %485
          ;
          int64_t v820 = v815 / v51;
          // pto: %486
          ;
          int64_t v821 = v820 < v56 ? v56 : v820;
          // pto: %487
          ;
          __gm__ int8_t* v822 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %487
          ;
          const int64_t v823 = 0;
          // pto: %487
          ;
          const int64_t v824 = 128;
          // pto: %487
          ;
          pto::Shape<1, 1, 1, 32, 128> v825 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %487
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v826 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %487
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v827 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v822 + (v823 + v821 * v824), v825, v826);
          TLOAD(v818, v827);
        } else {
          // pto: %489
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v828;
          // pto: %489
          ;
          uint64_t v829 = (uint64_t) v42;
          TASSIGN(v828, v829);
          // pto: %490
          ;
          int64_t v830 = v815 / v51;
          // pto: %491
          ;
          int64_t v831 = v830 < v56 ? v56 : v830;
          // pto: %492
          ;
          __gm__ int8_t* v832 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %492
          ;
          const int64_t v833 = 0;
          // pto: %492
          ;
          const int64_t v834 = 128;
          // pto: %492
          ;
          pto::Shape<1, 1, 1, 32, 128> v835 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %492
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v836 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %492
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v837 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v832 + (v833 + v831 * v834), v835, v836);
          TLOAD(v828, v837);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v382
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v838 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v382
        ;
        uint64_t v839 = (uint64_t) v45;
        TASSIGN(v838, v839);
        // pto: %buf_prefetched_key_inline8551__ssa_v26
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v840 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8551__ssa_v26
        ;
        uint64_t v841 = (uint64_t) v47;
        TASSIGN(v840, v841);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v842 = static_cast<uint16_t>(v56);
        uint16_t v843 = static_cast<uint16_t>(v56);
        TEXTRACT(v840, v838, v842, v843);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        // pto: %buf_key_panel_inline8420__ssa_v15
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v844 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8420__ssa_v15
        ;
        uint64_t v845 = (uint64_t) v43;
        TASSIGN(v844, v845);
        // pto: %buf_scores_l1_inline8475__ssa_v20
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v846 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8475__ssa_v20
        ;
        uint64_t v847 = (uint64_t) v44;
        TASSIGN(v846, v847);
        // pto: %buf_previous_pair_inline8418__ssa_v5
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v848 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8418__ssa_v5
        ;
        uint64_t v849 = (uint64_t) v46;
        TASSIGN(v848, v849);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID4);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v850 = static_cast<uint16_t>(v56);
        uint16_t v851 = static_cast<uint16_t>(v56);
        TEXTRACT(v848, v778, v850, v851);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
        // pto: %buf_scores_inline8619__ssa_v15
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v852 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8619__ssa_v15
        ;
        uint64_t v853 = (uint64_t) v43;
        TASSIGN(v852, v853);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v852, v281, v844);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline8484__ssa_v5
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v854 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8484__ssa_v5
        ;
        uint64_t v855 = (uint64_t) v48;
        TASSIGN(v854, v855);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v854, v283, v848);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v856 = static_cast<uint64_t>(v77);
        uint16_t v857 = static_cast<uint16_t>(v56);
        uint16_t v858 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v846, v852, v856, v857, v858);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID5);
        v854.SetValidShape(v65, v73);
        // pto: %496
        ;
        __gm__ float* v859 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %496
        ;
        const int64_t v860 = 256;
        // pto: %496
        ;
        const int64_t v861 = 1024;
        // pto: %496
        ;
        pto::Shape<1, 1, 1, 6, 64> v862 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %496
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v863 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %496
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v864 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v859 + (v860 + v510 * v861), v862, v863);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v864, v854);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline8435__ssa_v6
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v865 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8435__ssa_v6
        ;
        uint64_t v866 = (uint64_t) v44;
        TASSIGN(v865, v866);
        // pto: %buf_current_key_inline8472__ssa_v42
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v867 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8472__ssa_v42
        ;
        uint64_t v868 = (uint64_t) v47;
        TASSIGN(v867, v868);
        // pto: %498, %499
        ;
        int64_t v869 = (int64_t) ((uint64_t) v292 + (uint64_t) v81) / v66;
        // pto: %503
        ;
        int64_t v870 = v869 < v295 ? v869 : v295;
        // pto: %506, %504
        ;
        int32_t v871 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v870)];
        // pto: %507
        ;
        int64_t v872 = (int64_t) v871;
        // pto: %508
        ;
        int64_t v873 = v872 < v56 ? v56 : v872;
        // pto: %509
        ;
        int64_t v874 = (int64_t) ((uint64_t) v873 * (uint64_t) v16);
        // pto: %510
        ;
        int64_t v875 = v874 % v51;
        // pto: %511, %512, %513
        ;
        int64_t v876 = v875 < v56 ? (int64_t) ((uint64_t) v875 + (uint64_t) v51) : v875;
        // pto: %514
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        if (v876 == v56) {
          // pto: %515
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v877;
          // pto: %515
          ;
          uint64_t v878 = (uint64_t) v41;
          TASSIGN(v877, v878);
          // pto: %516
          ;
          int64_t v879 = v874 / v51;
          // pto: %517
          ;
          int64_t v880 = v879 < v56 ? v56 : v879;
          // pto: %518
          ;
          __gm__ int8_t* v881 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %518
          ;
          const int64_t v882 = 0;
          // pto: %518
          ;
          const int64_t v883 = 128;
          // pto: %518
          ;
          pto::Shape<1, 1, 1, 32, 128> v884 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %518
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v885 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %518
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v886 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v881 + (v882 + v880 * v883), v884, v885);
          TLOAD(v877, v886);
        } else {
          // pto: %519
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v887;
          // pto: %519
          ;
          uint64_t v888 = (uint64_t) v41;
          TASSIGN(v887, v888);
          // pto: %520
          ;
          int64_t v889 = v874 / v51;
          // pto: %521
          ;
          int64_t v890 = v889 < v56 ? v56 : v889;
          // pto: %522
          ;
          __gm__ int8_t* v891 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %522
          ;
          const int64_t v892 = 0;
          // pto: %522
          ;
          const int64_t v893 = 128;
          // pto: %522
          ;
          pto::Shape<1, 1, 1, 32, 128> v894 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %522
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v895 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %522
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v896 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v891 + (v892 + v890 * v893), v894, v895);
          TLOAD(v887, v896);
        };
        // pto: %525, %526
        ;
        int64_t v897 = (int64_t) ((uint64_t) v292 + (uint64_t) v34) / v66;
        // pto: %530
        ;
        int64_t v898 = v897 < v295 ? v897 : v295;
        // pto: %533, %531
        ;
        int32_t v899 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v898)];
        // pto: %534
        ;
        int64_t v900 = (int64_t) v899;
        // pto: %535
        ;
        int64_t v901 = v900 < v56 ? v56 : v900;
        // pto: %536
        ;
        int64_t v902 = (int64_t) ((uint64_t) v901 * (uint64_t) v16);
        // pto: %537
        ;
        int64_t v903 = v902 % v51;
        // pto: %538, %539, %540
        ;
        int64_t v904 = v903 < v56 ? (int64_t) ((uint64_t) v903 + (uint64_t) v51) : v903;
        // pto: %541
        ;
        if (v904 == v56) {
          // pto: %543
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v905;
          // pto: %543
          ;
          uint64_t v906 = (uint64_t) v39;
          TASSIGN(v905, v906);
          // pto: %544
          ;
          int64_t v907 = v902 / v51;
          // pto: %545
          ;
          int64_t v908 = v907 < v56 ? v56 : v907;
          // pto: %546
          ;
          __gm__ int8_t* v909 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %546
          ;
          const int64_t v910 = 0;
          // pto: %546
          ;
          const int64_t v911 = 128;
          // pto: %546
          ;
          pto::Shape<1, 1, 1, 32, 128> v912 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %546
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v913 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %546
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v914 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v909 + (v910 + v908 * v911), v912, v913);
          TLOAD(v905, v914);
        } else {
          // pto: %548
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v915;
          // pto: %548
          ;
          uint64_t v916 = (uint64_t) v39;
          TASSIGN(v915, v916);
          // pto: %549
          ;
          int64_t v917 = v902 / v51;
          // pto: %550
          ;
          int64_t v918 = v917 < v56 ? v56 : v917;
          // pto: %551
          ;
          __gm__ int8_t* v919 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %551
          ;
          const int64_t v920 = 0;
          // pto: %551
          ;
          const int64_t v921 = 128;
          // pto: %551
          ;
          pto::Shape<1, 1, 1, 32, 128> v922 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %551
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v923 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %551
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v924 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v919 + (v920 + v918 * v921), v922, v923);
          TLOAD(v915, v924);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v386
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v925 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v386
        ;
        uint64_t v926 = (uint64_t) v45;
        TASSIGN(v925, v926);
        // pto: %buf_prefetched_key_inline8551__ssa_v31
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v927 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8551__ssa_v31
        ;
        uint64_t v928 = (uint64_t) v43;
        TASSIGN(v927, v928);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v929 = static_cast<uint16_t>(v56);
        uint16_t v930 = static_cast<uint16_t>(v73);
        TEXTRACT(v927, v925, v929, v930);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        // pto: %buf_key_panel_inline8420__ssa_v18
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v931 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8420__ssa_v18
        ;
        uint64_t v932 = (uint64_t) v47;
        TASSIGN(v931, v932);
        // pto: %buf_scores_l1_inline8475__ssa_v24
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v933 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8475__ssa_v24
        ;
        uint64_t v934 = (uint64_t) v43;
        TASSIGN(v933, v934);
        // pto: %buf_previous_pair_inline8418__ssa_v6
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v935 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8418__ssa_v6
        ;
        uint64_t v936 = (uint64_t) v46;
        TASSIGN(v935, v936);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID5);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v937 = static_cast<uint16_t>(v56);
        uint16_t v938 = static_cast<uint16_t>(v56);
        TEXTRACT(v935, v865, v937, v938);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        // pto: %buf_scores_inline8619__ssa_v18
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v939 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8619__ssa_v18
        ;
        uint64_t v940 = (uint64_t) v43;
        TASSIGN(v939, v940);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v939, v281, v931);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline8484__ssa_v6
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v941 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8484__ssa_v6
        ;
        uint64_t v942 = (uint64_t) v48;
        TASSIGN(v941, v942);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v941, v283, v935);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v943 = static_cast<uint64_t>(v77);
        uint16_t v944 = static_cast<uint16_t>(v56);
        uint16_t v945 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v933, v939, v943, v944, v945);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID6);
        v941.SetValidShape(v65, v73);
        // pto: %555
        ;
        __gm__ float* v946 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %555
        ;
        const int64_t v947 = 320;
        // pto: %555
        ;
        const int64_t v948 = 1024;
        // pto: %555
        ;
        pto::Shape<1, 1, 1, 6, 64> v949 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %555
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v950 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %555
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v951 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v946 + (v947 + v510 * v948), v949, v950);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v951, v941);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline8435__ssa_v7
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v952 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8435__ssa_v7
        ;
        uint64_t v953 = (uint64_t) v43;
        TASSIGN(v952, v953);
        // pto: %buf_current_key_inline8472__ssa_v49
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v954 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8472__ssa_v49
        ;
        uint64_t v955 = (uint64_t) v43;
        TASSIGN(v954, v955);
        // pto: %557, %558
        ;
        int64_t v956 = (int64_t) ((uint64_t) v292 + (uint64_t) v70) / v66;
        // pto: %562
        ;
        int64_t v957 = v956 < v295 ? v956 : v295;
        // pto: %565, %563
        ;
        int32_t v958 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v957)];
        // pto: %566
        ;
        int64_t v959 = (int64_t) v958;
        // pto: %567
        ;
        int64_t v960 = v959 < v56 ? v56 : v959;
        // pto: %568
        ;
        int64_t v961 = (int64_t) ((uint64_t) v960 * (uint64_t) v16);
        // pto: %569
        ;
        int64_t v962 = v961 % v51;
        // pto: %570, %571, %572
        ;
        int64_t v963 = v962 < v56 ? (int64_t) ((uint64_t) v962 + (uint64_t) v51) : v962;
        // pto: %573
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        if (v963 == v56) {
          // pto: %574
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v964;
          // pto: %574
          ;
          uint64_t v965 = (uint64_t) v45;
          TASSIGN(v964, v965);
          // pto: %575
          ;
          int64_t v966 = v961 / v51;
          // pto: %576
          ;
          int64_t v967 = v966 < v56 ? v56 : v966;
          // pto: %577
          ;
          __gm__ int8_t* v968 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %577
          ;
          const int64_t v969 = 0;
          // pto: %577
          ;
          const int64_t v970 = 128;
          // pto: %577
          ;
          pto::Shape<1, 1, 1, 32, 128> v971 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %577
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v972 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %577
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v973 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v968 + (v969 + v967 * v970), v971, v972);
          TLOAD(v964, v973);
        } else {
          // pto: %578
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v974;
          // pto: %578
          ;
          uint64_t v975 = (uint64_t) v45;
          TASSIGN(v974, v975);
          // pto: %579
          ;
          int64_t v976 = v961 / v51;
          // pto: %580
          ;
          int64_t v977 = v976 < v56 ? v56 : v976;
          // pto: %581
          ;
          __gm__ int8_t* v978 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %581
          ;
          const int64_t v979 = 0;
          // pto: %581
          ;
          const int64_t v980 = 128;
          // pto: %581
          ;
          pto::Shape<1, 1, 1, 32, 128> v981 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %581
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v982 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %581
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v983 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v978 + (v979 + v977 * v980), v981, v982);
          TLOAD(v974, v983);
        };
        // pto: %584, %585
        ;
        int64_t v984 = (int64_t) ((uint64_t) v292 + (uint64_t) v33) / v66;
        // pto: %589
        ;
        int64_t v985 = v984 < v295 ? v984 : v295;
        // pto: %592, %590
        ;
        int32_t v986 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v985)];
        // pto: %593
        ;
        int64_t v987 = (int64_t) v986;
        // pto: %594
        ;
        int64_t v988 = v987 < v56 ? v56 : v987;
        // pto: %595
        ;
        int64_t v989 = (int64_t) ((uint64_t) v988 * (uint64_t) v16);
        // pto: %596
        ;
        int64_t v990 = v989 % v51;
        // pto: %597, %598, %599
        ;
        int64_t v991 = v990 < v56 ? (int64_t) ((uint64_t) v990 + (uint64_t) v51) : v990;
        // pto: %600
        ;
        if (v991 == v56) {
          // pto: %602
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v992;
          // pto: %602
          ;
          uint64_t v993 = (uint64_t) v42;
          TASSIGN(v992, v993);
          // pto: %603
          ;
          int64_t v994 = v989 / v51;
          // pto: %604
          ;
          int64_t v995 = v994 < v56 ? v56 : v994;
          // pto: %605
          ;
          __gm__ int8_t* v996 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %605
          ;
          const int64_t v997 = 0;
          // pto: %605
          ;
          const int64_t v998 = 128;
          // pto: %605
          ;
          pto::Shape<1, 1, 1, 32, 128> v999 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %605
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1000 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %605
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1001 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v996 + (v997 + v995 * v998), v999, v1000);
          TLOAD(v992, v1001);
        } else {
          // pto: %607
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1002;
          // pto: %607
          ;
          uint64_t v1003 = (uint64_t) v42;
          TASSIGN(v1002, v1003);
          // pto: %608
          ;
          int64_t v1004 = v989 / v51;
          // pto: %609
          ;
          int64_t v1005 = v1004 < v56 ? v56 : v1004;
          // pto: %610
          ;
          __gm__ int8_t* v1006 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %610
          ;
          const int64_t v1007 = 0;
          // pto: %610
          ;
          const int64_t v1008 = 128;
          // pto: %610
          ;
          pto::Shape<1, 1, 1, 32, 128> v1009 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %610
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1010 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %610
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1011 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1006 + (v1007 + v1005 * v1008), v1009, v1010);
          TLOAD(v1002, v1011);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v390
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1012 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v390
        ;
        uint64_t v1013 = (uint64_t) v45;
        TASSIGN(v1012, v1013);
        // pto: %buf_prefetched_key_inline8551__ssa_v36
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1014 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8551__ssa_v36
        ;
        uint64_t v1015 = (uint64_t) v47;
        TASSIGN(v1014, v1015);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1016 = static_cast<uint16_t>(v56);
        uint16_t v1017 = static_cast<uint16_t>(v56);
        TEXTRACT(v1014, v1012, v1016, v1017);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        // pto: %buf_key_panel_inline8420__ssa_v21
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1018 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8420__ssa_v21
        ;
        uint64_t v1019 = (uint64_t) v43;
        TASSIGN(v1018, v1019);
        // pto: %buf_scores_l1_inline8475__ssa_v28
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1020 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8475__ssa_v28
        ;
        uint64_t v1021 = (uint64_t) v44;
        TASSIGN(v1020, v1021);
        // pto: %buf_previous_pair_inline8418__ssa_v7
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1022 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8418__ssa_v7
        ;
        uint64_t v1023 = (uint64_t) v46;
        TASSIGN(v1022, v1023);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID6);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v1024 = static_cast<uint16_t>(v56);
        uint16_t v1025 = static_cast<uint16_t>(v56);
        TEXTRACT(v1022, v952, v1024, v1025);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline8619__ssa_v21
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1026 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8619__ssa_v21
        ;
        uint64_t v1027 = (uint64_t) v43;
        TASSIGN(v1026, v1027);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1026, v281, v1018);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline8484__ssa_v7
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1028 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8484__ssa_v7
        ;
        uint64_t v1029 = (uint64_t) v48;
        TASSIGN(v1028, v1029);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1028, v283, v1022);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1030 = static_cast<uint64_t>(v77);
        uint16_t v1031 = static_cast<uint16_t>(v56);
        uint16_t v1032 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1020, v1026, v1030, v1031, v1032);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID7);
        v1028.SetValidShape(v65, v73);
        // pto: %614
        ;
        __gm__ float* v1033 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %614
        ;
        const int64_t v1034 = 384;
        // pto: %614
        ;
        const int64_t v1035 = 1024;
        // pto: %614
        ;
        pto::Shape<1, 1, 1, 6, 64> v1036 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %614
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1037 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %614
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1038 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1033 + (v1034 + v510 * v1035), v1036, v1037);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1038, v1028);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline8435__ssa_v8
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1039 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8435__ssa_v8
        ;
        uint64_t v1040 = (uint64_t) v44;
        TASSIGN(v1039, v1040);
        // pto: %buf_current_key_inline8472__ssa_v56
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1041 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8472__ssa_v56
        ;
        uint64_t v1042 = (uint64_t) v47;
        TASSIGN(v1041, v1042);
        // pto: %616, %617
        ;
        int64_t v1043 = (int64_t) ((uint64_t) v292 + (uint64_t) v82) / v66;
        // pto: %621
        ;
        int64_t v1044 = v1043 < v295 ? v1043 : v295;
        // pto: %624, %622
        ;
        int32_t v1045 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v1044)];
        // pto: %625
        ;
        int64_t v1046 = (int64_t) v1045;
        // pto: %626
        ;
        int64_t v1047 = v1046 < v56 ? v56 : v1046;
        // pto: %627
        ;
        int64_t v1048 = (int64_t) ((uint64_t) v1047 * (uint64_t) v16);
        // pto: %628
        ;
        int64_t v1049 = v1048 % v51;
        // pto: %629, %630, %631
        ;
        int64_t v1050 = v1049 < v56 ? (int64_t) ((uint64_t) v1049 + (uint64_t) v51) : v1049;
        // pto: %632
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        if (v1050 == v56) {
          // pto: %633
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1051;
          // pto: %633
          ;
          uint64_t v1052 = (uint64_t) v41;
          TASSIGN(v1051, v1052);
          // pto: %634
          ;
          int64_t v1053 = v1048 / v51;
          // pto: %635
          ;
          int64_t v1054 = v1053 < v56 ? v56 : v1053;
          // pto: %636
          ;
          __gm__ int8_t* v1055 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %636
          ;
          const int64_t v1056 = 0;
          // pto: %636
          ;
          const int64_t v1057 = 128;
          // pto: %636
          ;
          pto::Shape<1, 1, 1, 32, 128> v1058 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %636
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1059 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %636
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1060 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1055 + (v1056 + v1054 * v1057), v1058, v1059);
          TLOAD(v1051, v1060);
        } else {
          // pto: %637
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1061;
          // pto: %637
          ;
          uint64_t v1062 = (uint64_t) v41;
          TASSIGN(v1061, v1062);
          // pto: %638
          ;
          int64_t v1063 = v1048 / v51;
          // pto: %639
          ;
          int64_t v1064 = v1063 < v56 ? v56 : v1063;
          // pto: %640
          ;
          __gm__ int8_t* v1065 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %640
          ;
          const int64_t v1066 = 0;
          // pto: %640
          ;
          const int64_t v1067 = 128;
          // pto: %640
          ;
          pto::Shape<1, 1, 1, 32, 128> v1068 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %640
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1069 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %640
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1070 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1065 + (v1066 + v1064 * v1067), v1068, v1069);
          TLOAD(v1061, v1070);
        };
        // pto: %643, %644
        ;
        int64_t v1071 = (int64_t) ((uint64_t) v292 + (uint64_t) v32) / v66;
        // pto: %648
        ;
        int64_t v1072 = v1071 < v295 ? v1071 : v295;
        // pto: %651, %649
        ;
        int32_t v1073 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v1072)];
        // pto: %652
        ;
        int64_t v1074 = (int64_t) v1073;
        // pto: %653
        ;
        int64_t v1075 = v1074 < v56 ? v56 : v1074;
        // pto: %654
        ;
        int64_t v1076 = (int64_t) ((uint64_t) v1075 * (uint64_t) v16);
        // pto: %655
        ;
        int64_t v1077 = v1076 % v51;
        // pto: %656, %657, %658
        ;
        int64_t v1078 = v1077 < v56 ? (int64_t) ((uint64_t) v1077 + (uint64_t) v51) : v1077;
        // pto: %659
        ;
        if (v1078 == v56) {
          // pto: %661
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1079;
          // pto: %661
          ;
          uint64_t v1080 = (uint64_t) v39;
          TASSIGN(v1079, v1080);
          // pto: %662
          ;
          int64_t v1081 = v1076 / v51;
          // pto: %663
          ;
          int64_t v1082 = v1081 < v56 ? v56 : v1081;
          // pto: %664
          ;
          __gm__ int8_t* v1083 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %664
          ;
          const int64_t v1084 = 0;
          // pto: %664
          ;
          const int64_t v1085 = 128;
          // pto: %664
          ;
          pto::Shape<1, 1, 1, 32, 128> v1086 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %664
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1087 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %664
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1088 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1083 + (v1084 + v1082 * v1085), v1086, v1087);
          TLOAD(v1079, v1088);
        } else {
          // pto: %666
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1089;
          // pto: %666
          ;
          uint64_t v1090 = (uint64_t) v39;
          TASSIGN(v1089, v1090);
          // pto: %667
          ;
          int64_t v1091 = v1076 / v51;
          // pto: %668
          ;
          int64_t v1092 = v1091 < v56 ? v56 : v1091;
          // pto: %669
          ;
          __gm__ int8_t* v1093 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %669
          ;
          const int64_t v1094 = 0;
          // pto: %669
          ;
          const int64_t v1095 = 128;
          // pto: %669
          ;
          pto::Shape<1, 1, 1, 32, 128> v1096 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %669
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1097 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %669
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1098 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1093 + (v1094 + v1092 * v1095), v1096, v1097);
          TLOAD(v1089, v1098);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v394
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1099 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v394
        ;
        uint64_t v1100 = (uint64_t) v45;
        TASSIGN(v1099, v1100);
        // pto: %buf_prefetched_key_inline8551__ssa_v41
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1101 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8551__ssa_v41
        ;
        uint64_t v1102 = (uint64_t) v43;
        TASSIGN(v1101, v1102);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1103 = static_cast<uint16_t>(v56);
        uint16_t v1104 = static_cast<uint16_t>(v73);
        TEXTRACT(v1101, v1099, v1103, v1104);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        // pto: %buf_key_panel_inline8420__ssa_v24
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1105 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8420__ssa_v24
        ;
        uint64_t v1106 = (uint64_t) v47;
        TASSIGN(v1105, v1106);
        // pto: %buf_scores_l1_inline8475__ssa_v32
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1107 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8475__ssa_v32
        ;
        uint64_t v1108 = (uint64_t) v43;
        TASSIGN(v1107, v1108);
        // pto: %buf_previous_pair_inline8418__ssa_v8
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1109 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8418__ssa_v8
        ;
        uint64_t v1110 = (uint64_t) v46;
        TASSIGN(v1109, v1110);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID7);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v1111 = static_cast<uint16_t>(v56);
        uint16_t v1112 = static_cast<uint16_t>(v56);
        TEXTRACT(v1109, v1039, v1111, v1112);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline8619__ssa_v24
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1113 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8619__ssa_v24
        ;
        uint64_t v1114 = (uint64_t) v43;
        TASSIGN(v1113, v1114);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1113, v281, v1105);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline8484__ssa_v8
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1115 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8484__ssa_v8
        ;
        uint64_t v1116 = (uint64_t) v48;
        TASSIGN(v1115, v1116);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1115, v283, v1109);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1117 = static_cast<uint64_t>(v77);
        uint16_t v1118 = static_cast<uint16_t>(v56);
        uint16_t v1119 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1107, v1113, v1117, v1118, v1119);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v1115.SetValidShape(v65, v73);
        // pto: %673
        ;
        __gm__ float* v1120 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %673
        ;
        const int64_t v1121 = 448;
        // pto: %673
        ;
        const int64_t v1122 = 1024;
        // pto: %673
        ;
        pto::Shape<1, 1, 1, 6, 64> v1123 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %673
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1124 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %673
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1125 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1120 + (v1121 + v510 * v1122), v1123, v1124);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1125, v1115);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline8435__ssa_v9
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1126 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8435__ssa_v9
        ;
        uint64_t v1127 = (uint64_t) v43;
        TASSIGN(v1126, v1127);
        // pto: %buf_current_key_inline8472__ssa_v63
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1128 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8472__ssa_v63
        ;
        uint64_t v1129 = (uint64_t) v43;
        TASSIGN(v1128, v1129);
        // pto: %675, %676
        ;
        int64_t v1130 = (int64_t) ((uint64_t) v292 + (uint64_t) v83) / v66;
        // pto: %680
        ;
        int64_t v1131 = v1130 < v295 ? v1130 : v295;
        // pto: %683, %681
        ;
        int32_t v1132 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v1131)];
        // pto: %684
        ;
        int64_t v1133 = (int64_t) v1132;
        // pto: %685
        ;
        int64_t v1134 = v1133 < v56 ? v56 : v1133;
        // pto: %686
        ;
        int64_t v1135 = (int64_t) ((uint64_t) v1134 * (uint64_t) v16);
        // pto: %687
        ;
        int64_t v1136 = v1135 % v51;
        // pto: %688, %689, %690
        ;
        int64_t v1137 = v1136 < v56 ? (int64_t) ((uint64_t) v1136 + (uint64_t) v51) : v1136;
        // pto: %691
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        if (v1137 == v56) {
          // pto: %692
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1138;
          // pto: %692
          ;
          uint64_t v1139 = (uint64_t) v45;
          TASSIGN(v1138, v1139);
          // pto: %693
          ;
          int64_t v1140 = v1135 / v51;
          // pto: %694
          ;
          int64_t v1141 = v1140 < v56 ? v56 : v1140;
          // pto: %695
          ;
          __gm__ int8_t* v1142 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %695
          ;
          const int64_t v1143 = 0;
          // pto: %695
          ;
          const int64_t v1144 = 128;
          // pto: %695
          ;
          pto::Shape<1, 1, 1, 32, 128> v1145 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %695
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1146 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %695
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1147 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1142 + (v1143 + v1141 * v1144), v1145, v1146);
          TLOAD(v1138, v1147);
        } else {
          // pto: %696
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1148;
          // pto: %696
          ;
          uint64_t v1149 = (uint64_t) v45;
          TASSIGN(v1148, v1149);
          // pto: %697
          ;
          int64_t v1150 = v1135 / v51;
          // pto: %698
          ;
          int64_t v1151 = v1150 < v56 ? v56 : v1150;
          // pto: %699
          ;
          __gm__ int8_t* v1152 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %699
          ;
          const int64_t v1153 = 0;
          // pto: %699
          ;
          const int64_t v1154 = 128;
          // pto: %699
          ;
          pto::Shape<1, 1, 1, 32, 128> v1155 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %699
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1156 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %699
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1157 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1152 + (v1153 + v1151 * v1154), v1155, v1156);
          TLOAD(v1148, v1157);
        };
        // pto: %702, %703
        ;
        int64_t v1158 = (int64_t) ((uint64_t) v292 + (uint64_t) v31) / v66;
        // pto: %707
        ;
        int64_t v1159 = v1158 < v295 ? v1158 : v295;
        // pto: %710, %708
        ;
        int32_t v1160 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v1159)];
        // pto: %711
        ;
        int64_t v1161 = (int64_t) v1160;
        // pto: %712
        ;
        int64_t v1162 = v1161 < v56 ? v56 : v1161;
        // pto: %713
        ;
        int64_t v1163 = (int64_t) ((uint64_t) v1162 * (uint64_t) v16);
        // pto: %714
        ;
        int64_t v1164 = v1163 % v51;
        // pto: %715, %716, %717
        ;
        int64_t v1165 = v1164 < v56 ? (int64_t) ((uint64_t) v1164 + (uint64_t) v51) : v1164;
        // pto: %718
        ;
        if (v1165 == v56) {
          // pto: %720
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1166;
          // pto: %720
          ;
          uint64_t v1167 = (uint64_t) v42;
          TASSIGN(v1166, v1167);
          // pto: %721
          ;
          int64_t v1168 = v1163 / v51;
          // pto: %722
          ;
          int64_t v1169 = v1168 < v56 ? v56 : v1168;
          // pto: %723
          ;
          __gm__ int8_t* v1170 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %723
          ;
          const int64_t v1171 = 0;
          // pto: %723
          ;
          const int64_t v1172 = 128;
          // pto: %723
          ;
          pto::Shape<1, 1, 1, 32, 128> v1173 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %723
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1174 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %723
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1175 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1170 + (v1171 + v1169 * v1172), v1173, v1174);
          TLOAD(v1166, v1175);
        } else {
          // pto: %725
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1176;
          // pto: %725
          ;
          uint64_t v1177 = (uint64_t) v42;
          TASSIGN(v1176, v1177);
          // pto: %726
          ;
          int64_t v1178 = v1163 / v51;
          // pto: %727
          ;
          int64_t v1179 = v1178 < v56 ? v56 : v1178;
          // pto: %728
          ;
          __gm__ int8_t* v1180 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %728
          ;
          const int64_t v1181 = 0;
          // pto: %728
          ;
          const int64_t v1182 = 128;
          // pto: %728
          ;
          pto::Shape<1, 1, 1, 32, 128> v1183 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %728
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1184 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %728
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1185 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1180 + (v1181 + v1179 * v1182), v1183, v1184);
          TLOAD(v1176, v1185);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v398
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1186 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v398
        ;
        uint64_t v1187 = (uint64_t) v45;
        TASSIGN(v1186, v1187);
        // pto: %buf_prefetched_key_inline8551__ssa_v46
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1188 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8551__ssa_v46
        ;
        uint64_t v1189 = (uint64_t) v47;
        TASSIGN(v1188, v1189);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1190 = static_cast<uint16_t>(v56);
        uint16_t v1191 = static_cast<uint16_t>(v56);
        TEXTRACT(v1188, v1186, v1190, v1191);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        // pto: %buf_key_panel_inline8420__ssa_v27
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1192 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8420__ssa_v27
        ;
        uint64_t v1193 = (uint64_t) v43;
        TASSIGN(v1192, v1193);
        // pto: %buf_scores_l1_inline8475__ssa_v36
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1194 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8475__ssa_v36
        ;
        uint64_t v1195 = (uint64_t) v44;
        TASSIGN(v1194, v1195);
        // pto: %buf_previous_pair_inline8418__ssa_v9
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1196 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8418__ssa_v9
        ;
        uint64_t v1197 = (uint64_t) v46;
        TASSIGN(v1196, v1197);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v1198 = static_cast<uint16_t>(v56);
        uint16_t v1199 = static_cast<uint16_t>(v56);
        TEXTRACT(v1196, v1126, v1198, v1199);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline8619__ssa_v27
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1200 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8619__ssa_v27
        ;
        uint64_t v1201 = (uint64_t) v43;
        TASSIGN(v1200, v1201);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1200, v281, v1192);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline8484__ssa_v9
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1202 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8484__ssa_v9
        ;
        uint64_t v1203 = (uint64_t) v48;
        TASSIGN(v1202, v1203);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1202, v283, v1196);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1204 = static_cast<uint64_t>(v77);
        uint16_t v1205 = static_cast<uint16_t>(v56);
        uint16_t v1206 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1194, v1200, v1204, v1205, v1206);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v1202.SetValidShape(v65, v73);
        // pto: %732
        ;
        __gm__ float* v1207 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %732
        ;
        const int64_t v1208 = 512;
        // pto: %732
        ;
        const int64_t v1209 = 1024;
        // pto: %732
        ;
        pto::Shape<1, 1, 1, 6, 64> v1210 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %732
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1211 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %732
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1212 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1207 + (v1208 + v510 * v1209), v1210, v1211);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1212, v1202);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline8435__ssa_v10
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1213 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8435__ssa_v10
        ;
        uint64_t v1214 = (uint64_t) v44;
        TASSIGN(v1213, v1214);
        // pto: %buf_current_key_inline8472__ssa_v70
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1215 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8472__ssa_v70
        ;
        uint64_t v1216 = (uint64_t) v47;
        TASSIGN(v1215, v1216);
        // pto: %734, %735
        ;
        int64_t v1217 = (int64_t) ((uint64_t) v292 + (uint64_t) v84) / v66;
        // pto: %739
        ;
        int64_t v1218 = v1217 < v295 ? v1217 : v295;
        // pto: %742, %740
        ;
        int32_t v1219 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v1218)];
        // pto: %743
        ;
        int64_t v1220 = (int64_t) v1219;
        // pto: %744
        ;
        int64_t v1221 = v1220 < v56 ? v56 : v1220;
        // pto: %745
        ;
        int64_t v1222 = (int64_t) ((uint64_t) v1221 * (uint64_t) v16);
        // pto: %746
        ;
        int64_t v1223 = v1222 % v51;
        // pto: %747, %748, %749
        ;
        int64_t v1224 = v1223 < v56 ? (int64_t) ((uint64_t) v1223 + (uint64_t) v51) : v1223;
        // pto: %750
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        if (v1224 == v56) {
          // pto: %751
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1225;
          // pto: %751
          ;
          uint64_t v1226 = (uint64_t) v41;
          TASSIGN(v1225, v1226);
          // pto: %752
          ;
          int64_t v1227 = v1222 / v51;
          // pto: %753
          ;
          int64_t v1228 = v1227 < v56 ? v56 : v1227;
          // pto: %754
          ;
          __gm__ int8_t* v1229 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %754
          ;
          const int64_t v1230 = 0;
          // pto: %754
          ;
          const int64_t v1231 = 128;
          // pto: %754
          ;
          pto::Shape<1, 1, 1, 32, 128> v1232 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %754
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1233 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %754
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1234 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1229 + (v1230 + v1228 * v1231), v1232, v1233);
          TLOAD(v1225, v1234);
        } else {
          // pto: %755
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1235;
          // pto: %755
          ;
          uint64_t v1236 = (uint64_t) v41;
          TASSIGN(v1235, v1236);
          // pto: %756
          ;
          int64_t v1237 = v1222 / v51;
          // pto: %757
          ;
          int64_t v1238 = v1237 < v56 ? v56 : v1237;
          // pto: %758
          ;
          __gm__ int8_t* v1239 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %758
          ;
          const int64_t v1240 = 0;
          // pto: %758
          ;
          const int64_t v1241 = 128;
          // pto: %758
          ;
          pto::Shape<1, 1, 1, 32, 128> v1242 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %758
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1243 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %758
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1244 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1239 + (v1240 + v1238 * v1241), v1242, v1243);
          TLOAD(v1235, v1244);
        };
        // pto: %761, %762
        ;
        int64_t v1245 = (int64_t) ((uint64_t) v292 + (uint64_t) v30) / v66;
        // pto: %766
        ;
        int64_t v1246 = v1245 < v295 ? v1245 : v295;
        // pto: %769, %767
        ;
        int32_t v1247 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v1246)];
        // pto: %770
        ;
        int64_t v1248 = (int64_t) v1247;
        // pto: %771
        ;
        int64_t v1249 = v1248 < v56 ? v56 : v1248;
        // pto: %772
        ;
        int64_t v1250 = (int64_t) ((uint64_t) v1249 * (uint64_t) v16);
        // pto: %773
        ;
        int64_t v1251 = v1250 % v51;
        // pto: %774, %775, %776
        ;
        int64_t v1252 = v1251 < v56 ? (int64_t) ((uint64_t) v1251 + (uint64_t) v51) : v1251;
        // pto: %777
        ;
        if (v1252 == v56) {
          // pto: %779
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1253;
          // pto: %779
          ;
          uint64_t v1254 = (uint64_t) v39;
          TASSIGN(v1253, v1254);
          // pto: %780
          ;
          int64_t v1255 = v1250 / v51;
          // pto: %781
          ;
          int64_t v1256 = v1255 < v56 ? v56 : v1255;
          // pto: %782
          ;
          __gm__ int8_t* v1257 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %782
          ;
          const int64_t v1258 = 0;
          // pto: %782
          ;
          const int64_t v1259 = 128;
          // pto: %782
          ;
          pto::Shape<1, 1, 1, 32, 128> v1260 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %782
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1261 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %782
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1262 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1257 + (v1258 + v1256 * v1259), v1260, v1261);
          TLOAD(v1253, v1262);
        } else {
          // pto: %784
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1263;
          // pto: %784
          ;
          uint64_t v1264 = (uint64_t) v39;
          TASSIGN(v1263, v1264);
          // pto: %785
          ;
          int64_t v1265 = v1250 / v51;
          // pto: %786
          ;
          int64_t v1266 = v1265 < v56 ? v56 : v1265;
          // pto: %787
          ;
          __gm__ int8_t* v1267 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %787
          ;
          const int64_t v1268 = 0;
          // pto: %787
          ;
          const int64_t v1269 = 128;
          // pto: %787
          ;
          pto::Shape<1, 1, 1, 32, 128> v1270 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %787
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1271 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %787
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1272 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1267 + (v1268 + v1266 * v1269), v1270, v1271);
          TLOAD(v1263, v1272);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v402
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1273 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v402
        ;
        uint64_t v1274 = (uint64_t) v45;
        TASSIGN(v1273, v1274);
        // pto: %buf_prefetched_key_inline8551__ssa_v51
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1275 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8551__ssa_v51
        ;
        uint64_t v1276 = (uint64_t) v43;
        TASSIGN(v1275, v1276);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1277 = static_cast<uint16_t>(v56);
        uint16_t v1278 = static_cast<uint16_t>(v73);
        TEXTRACT(v1275, v1273, v1277, v1278);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        // pto: %buf_key_panel_inline8420__ssa_v30
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1279 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8420__ssa_v30
        ;
        uint64_t v1280 = (uint64_t) v47;
        TASSIGN(v1279, v1280);
        // pto: %buf_scores_l1_inline8475__ssa_v40
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1281 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8475__ssa_v40
        ;
        uint64_t v1282 = (uint64_t) v43;
        TASSIGN(v1281, v1282);
        // pto: %buf_previous_pair_inline8418__ssa_v10
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1283 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8418__ssa_v10
        ;
        uint64_t v1284 = (uint64_t) v46;
        TASSIGN(v1283, v1284);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v1285 = static_cast<uint16_t>(v56);
        uint16_t v1286 = static_cast<uint16_t>(v56);
        TEXTRACT(v1283, v1213, v1285, v1286);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline8619__ssa_v30
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1287 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8619__ssa_v30
        ;
        uint64_t v1288 = (uint64_t) v43;
        TASSIGN(v1287, v1288);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1287, v281, v1279);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline8484__ssa_v10
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1289 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8484__ssa_v10
        ;
        uint64_t v1290 = (uint64_t) v48;
        TASSIGN(v1289, v1290);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1289, v283, v1283);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1291 = static_cast<uint64_t>(v77);
        uint16_t v1292 = static_cast<uint16_t>(v56);
        uint16_t v1293 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1281, v1287, v1291, v1292, v1293);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v1289.SetValidShape(v65, v73);
        // pto: %791
        ;
        __gm__ float* v1294 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %791
        ;
        const int64_t v1295 = 576;
        // pto: %791
        ;
        const int64_t v1296 = 1024;
        // pto: %791
        ;
        pto::Shape<1, 1, 1, 6, 64> v1297 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %791
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1298 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %791
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1299 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1294 + (v1295 + v510 * v1296), v1297, v1298);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1299, v1289);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline8435__ssa_v11
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1300 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8435__ssa_v11
        ;
        uint64_t v1301 = (uint64_t) v43;
        TASSIGN(v1300, v1301);
        // pto: %buf_current_key_inline8472__ssa_v77
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1302 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8472__ssa_v77
        ;
        uint64_t v1303 = (uint64_t) v43;
        TASSIGN(v1302, v1303);
        // pto: %793, %794
        ;
        int64_t v1304 = (int64_t) ((uint64_t) v292 + (uint64_t) v85) / v66;
        // pto: %798
        ;
        int64_t v1305 = v1304 < v295 ? v1304 : v295;
        // pto: %801, %799
        ;
        int32_t v1306 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v1305)];
        // pto: %802
        ;
        int64_t v1307 = (int64_t) v1306;
        // pto: %803
        ;
        int64_t v1308 = v1307 < v56 ? v56 : v1307;
        // pto: %804
        ;
        int64_t v1309 = (int64_t) ((uint64_t) v1308 * (uint64_t) v16);
        // pto: %805
        ;
        int64_t v1310 = v1309 % v51;
        // pto: %806, %807, %808
        ;
        int64_t v1311 = v1310 < v56 ? (int64_t) ((uint64_t) v1310 + (uint64_t) v51) : v1310;
        // pto: %809
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        if (v1311 == v56) {
          // pto: %810
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1312;
          // pto: %810
          ;
          uint64_t v1313 = (uint64_t) v45;
          TASSIGN(v1312, v1313);
          // pto: %811
          ;
          int64_t v1314 = v1309 / v51;
          // pto: %812
          ;
          int64_t v1315 = v1314 < v56 ? v56 : v1314;
          // pto: %813
          ;
          __gm__ int8_t* v1316 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %813
          ;
          const int64_t v1317 = 0;
          // pto: %813
          ;
          const int64_t v1318 = 128;
          // pto: %813
          ;
          pto::Shape<1, 1, 1, 32, 128> v1319 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %813
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1320 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %813
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1321 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1316 + (v1317 + v1315 * v1318), v1319, v1320);
          TLOAD(v1312, v1321);
        } else {
          // pto: %814
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1322;
          // pto: %814
          ;
          uint64_t v1323 = (uint64_t) v45;
          TASSIGN(v1322, v1323);
          // pto: %815
          ;
          int64_t v1324 = v1309 / v51;
          // pto: %816
          ;
          int64_t v1325 = v1324 < v56 ? v56 : v1324;
          // pto: %817
          ;
          __gm__ int8_t* v1326 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %817
          ;
          const int64_t v1327 = 0;
          // pto: %817
          ;
          const int64_t v1328 = 128;
          // pto: %817
          ;
          pto::Shape<1, 1, 1, 32, 128> v1329 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %817
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1330 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %817
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1331 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1326 + (v1327 + v1325 * v1328), v1329, v1330);
          TLOAD(v1322, v1331);
        };
        // pto: %820, %821
        ;
        int64_t v1332 = (int64_t) ((uint64_t) v292 + (uint64_t) v29) / v66;
        // pto: %825
        ;
        int64_t v1333 = v1332 < v295 ? v1332 : v295;
        // pto: %828, %826
        ;
        int32_t v1334 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v1333)];
        // pto: %829
        ;
        int64_t v1335 = (int64_t) v1334;
        // pto: %830
        ;
        int64_t v1336 = v1335 < v56 ? v56 : v1335;
        // pto: %831
        ;
        int64_t v1337 = (int64_t) ((uint64_t) v1336 * (uint64_t) v16);
        // pto: %832
        ;
        int64_t v1338 = v1337 % v51;
        // pto: %833, %834, %835
        ;
        int64_t v1339 = v1338 < v56 ? (int64_t) ((uint64_t) v1338 + (uint64_t) v51) : v1338;
        // pto: %836
        ;
        if (v1339 == v56) {
          // pto: %838
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1340;
          // pto: %838
          ;
          uint64_t v1341 = (uint64_t) v42;
          TASSIGN(v1340, v1341);
          // pto: %839
          ;
          int64_t v1342 = v1337 / v51;
          // pto: %840
          ;
          int64_t v1343 = v1342 < v56 ? v56 : v1342;
          // pto: %841
          ;
          __gm__ int8_t* v1344 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %841
          ;
          const int64_t v1345 = 0;
          // pto: %841
          ;
          const int64_t v1346 = 128;
          // pto: %841
          ;
          pto::Shape<1, 1, 1, 32, 128> v1347 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %841
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1348 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %841
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1349 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1344 + (v1345 + v1343 * v1346), v1347, v1348);
          TLOAD(v1340, v1349);
        } else {
          // pto: %843
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1350;
          // pto: %843
          ;
          uint64_t v1351 = (uint64_t) v42;
          TASSIGN(v1350, v1351);
          // pto: %844
          ;
          int64_t v1352 = v1337 / v51;
          // pto: %845
          ;
          int64_t v1353 = v1352 < v56 ? v56 : v1352;
          // pto: %846
          ;
          __gm__ int8_t* v1354 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %846
          ;
          const int64_t v1355 = 0;
          // pto: %846
          ;
          const int64_t v1356 = 128;
          // pto: %846
          ;
          pto::Shape<1, 1, 1, 32, 128> v1357 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %846
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1358 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %846
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1359 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1354 + (v1355 + v1353 * v1356), v1357, v1358);
          TLOAD(v1350, v1359);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v406
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1360 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v406
        ;
        uint64_t v1361 = (uint64_t) v45;
        TASSIGN(v1360, v1361);
        // pto: %buf_prefetched_key_inline8551__ssa_v56
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1362 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8551__ssa_v56
        ;
        uint64_t v1363 = (uint64_t) v47;
        TASSIGN(v1362, v1363);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1364 = static_cast<uint16_t>(v56);
        uint16_t v1365 = static_cast<uint16_t>(v56);
        TEXTRACT(v1362, v1360, v1364, v1365);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        // pto: %buf_key_panel_inline8420__ssa_v33
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1366 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8420__ssa_v33
        ;
        uint64_t v1367 = (uint64_t) v43;
        TASSIGN(v1366, v1367);
        // pto: %buf_scores_l1_inline8475__ssa_v44
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1368 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8475__ssa_v44
        ;
        uint64_t v1369 = (uint64_t) v44;
        TASSIGN(v1368, v1369);
        // pto: %buf_previous_pair_inline8418__ssa_v11
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1370 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8418__ssa_v11
        ;
        uint64_t v1371 = (uint64_t) v46;
        TASSIGN(v1370, v1371);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v1372 = static_cast<uint16_t>(v56);
        uint16_t v1373 = static_cast<uint16_t>(v56);
        TEXTRACT(v1370, v1300, v1372, v1373);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline8619__ssa_v33
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1374 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8619__ssa_v33
        ;
        uint64_t v1375 = (uint64_t) v43;
        TASSIGN(v1374, v1375);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1374, v281, v1366);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline8484__ssa_v11
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1376 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8484__ssa_v11
        ;
        uint64_t v1377 = (uint64_t) v48;
        TASSIGN(v1376, v1377);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1376, v283, v1370);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1378 = static_cast<uint64_t>(v77);
        uint16_t v1379 = static_cast<uint16_t>(v56);
        uint16_t v1380 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1368, v1374, v1378, v1379, v1380);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v1376.SetValidShape(v65, v73);
        // pto: %850
        ;
        __gm__ float* v1381 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %850
        ;
        const int64_t v1382 = 640;
        // pto: %850
        ;
        const int64_t v1383 = 1024;
        // pto: %850
        ;
        pto::Shape<1, 1, 1, 6, 64> v1384 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %850
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1385 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %850
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1386 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1381 + (v1382 + v510 * v1383), v1384, v1385);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1386, v1376);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline8435__ssa_v12
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1387 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8435__ssa_v12
        ;
        uint64_t v1388 = (uint64_t) v44;
        TASSIGN(v1387, v1388);
        // pto: %buf_current_key_inline8472__ssa_v84
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1389 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8472__ssa_v84
        ;
        uint64_t v1390 = (uint64_t) v47;
        TASSIGN(v1389, v1390);
        // pto: %852, %853
        ;
        int64_t v1391 = (int64_t) ((uint64_t) v292 + (uint64_t) v86) / v66;
        // pto: %857
        ;
        int64_t v1392 = v1391 < v295 ? v1391 : v295;
        // pto: %860, %858
        ;
        int32_t v1393 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v1392)];
        // pto: %861
        ;
        int64_t v1394 = (int64_t) v1393;
        // pto: %862
        ;
        int64_t v1395 = v1394 < v56 ? v56 : v1394;
        // pto: %863
        ;
        int64_t v1396 = (int64_t) ((uint64_t) v1395 * (uint64_t) v16);
        // pto: %864
        ;
        int64_t v1397 = v1396 % v51;
        // pto: %865, %866, %867
        ;
        int64_t v1398 = v1397 < v56 ? (int64_t) ((uint64_t) v1397 + (uint64_t) v51) : v1397;
        // pto: %868
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        if (v1398 == v56) {
          // pto: %869
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1399;
          // pto: %869
          ;
          uint64_t v1400 = (uint64_t) v41;
          TASSIGN(v1399, v1400);
          // pto: %870
          ;
          int64_t v1401 = v1396 / v51;
          // pto: %871
          ;
          int64_t v1402 = v1401 < v56 ? v56 : v1401;
          // pto: %872
          ;
          __gm__ int8_t* v1403 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %872
          ;
          const int64_t v1404 = 0;
          // pto: %872
          ;
          const int64_t v1405 = 128;
          // pto: %872
          ;
          pto::Shape<1, 1, 1, 32, 128> v1406 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %872
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1407 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %872
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1408 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1403 + (v1404 + v1402 * v1405), v1406, v1407);
          TLOAD(v1399, v1408);
        } else {
          // pto: %873
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1409;
          // pto: %873
          ;
          uint64_t v1410 = (uint64_t) v41;
          TASSIGN(v1409, v1410);
          // pto: %874
          ;
          int64_t v1411 = v1396 / v51;
          // pto: %875
          ;
          int64_t v1412 = v1411 < v56 ? v56 : v1411;
          // pto: %876
          ;
          __gm__ int8_t* v1413 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %876
          ;
          const int64_t v1414 = 0;
          // pto: %876
          ;
          const int64_t v1415 = 128;
          // pto: %876
          ;
          pto::Shape<1, 1, 1, 32, 128> v1416 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %876
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1417 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %876
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1418 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1413 + (v1414 + v1412 * v1415), v1416, v1417);
          TLOAD(v1409, v1418);
        };
        // pto: %879, %880
        ;
        int64_t v1419 = (int64_t) ((uint64_t) v292 + (uint64_t) v28) / v66;
        // pto: %884
        ;
        int64_t v1420 = v1419 < v295 ? v1419 : v295;
        // pto: %887, %885
        ;
        int32_t v1421 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v1420)];
        // pto: %888
        ;
        int64_t v1422 = (int64_t) v1421;
        // pto: %889
        ;
        int64_t v1423 = v1422 < v56 ? v56 : v1422;
        // pto: %890
        ;
        int64_t v1424 = (int64_t) ((uint64_t) v1423 * (uint64_t) v16);
        // pto: %891
        ;
        int64_t v1425 = v1424 % v51;
        // pto: %892, %893, %894
        ;
        int64_t v1426 = v1425 < v56 ? (int64_t) ((uint64_t) v1425 + (uint64_t) v51) : v1425;
        // pto: %895
        ;
        if (v1426 == v56) {
          // pto: %897
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1427;
          // pto: %897
          ;
          uint64_t v1428 = (uint64_t) v39;
          TASSIGN(v1427, v1428);
          // pto: %898
          ;
          int64_t v1429 = v1424 / v51;
          // pto: %899
          ;
          int64_t v1430 = v1429 < v56 ? v56 : v1429;
          // pto: %900
          ;
          __gm__ int8_t* v1431 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %900
          ;
          const int64_t v1432 = 0;
          // pto: %900
          ;
          const int64_t v1433 = 128;
          // pto: %900
          ;
          pto::Shape<1, 1, 1, 32, 128> v1434 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %900
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1435 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %900
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1436 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1431 + (v1432 + v1430 * v1433), v1434, v1435);
          TLOAD(v1427, v1436);
        } else {
          // pto: %902
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1437;
          // pto: %902
          ;
          uint64_t v1438 = (uint64_t) v39;
          TASSIGN(v1437, v1438);
          // pto: %903
          ;
          int64_t v1439 = v1424 / v51;
          // pto: %904
          ;
          int64_t v1440 = v1439 < v56 ? v56 : v1439;
          // pto: %905
          ;
          __gm__ int8_t* v1441 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %905
          ;
          const int64_t v1442 = 0;
          // pto: %905
          ;
          const int64_t v1443 = 128;
          // pto: %905
          ;
          pto::Shape<1, 1, 1, 32, 128> v1444 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %905
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1445 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %905
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1446 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1441 + (v1442 + v1440 * v1443), v1444, v1445);
          TLOAD(v1437, v1446);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v410
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1447 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v410
        ;
        uint64_t v1448 = (uint64_t) v45;
        TASSIGN(v1447, v1448);
        // pto: %buf_prefetched_key_inline8551__ssa_v61
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1449 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8551__ssa_v61
        ;
        uint64_t v1450 = (uint64_t) v43;
        TASSIGN(v1449, v1450);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1451 = static_cast<uint16_t>(v56);
        uint16_t v1452 = static_cast<uint16_t>(v73);
        TEXTRACT(v1449, v1447, v1451, v1452);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        // pto: %buf_key_panel_inline8420__ssa_v36
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1453 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8420__ssa_v36
        ;
        uint64_t v1454 = (uint64_t) v47;
        TASSIGN(v1453, v1454);
        // pto: %buf_scores_l1_inline8475__ssa_v48
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1455 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8475__ssa_v48
        ;
        uint64_t v1456 = (uint64_t) v43;
        TASSIGN(v1455, v1456);
        // pto: %buf_previous_pair_inline8418__ssa_v12
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1457 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8418__ssa_v12
        ;
        uint64_t v1458 = (uint64_t) v46;
        TASSIGN(v1457, v1458);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v1459 = static_cast<uint16_t>(v56);
        uint16_t v1460 = static_cast<uint16_t>(v56);
        TEXTRACT(v1457, v1387, v1459, v1460);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline8619__ssa_v36
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1461 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8619__ssa_v36
        ;
        uint64_t v1462 = (uint64_t) v43;
        TASSIGN(v1461, v1462);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1461, v281, v1453);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline8484__ssa_v12
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1463 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8484__ssa_v12
        ;
        uint64_t v1464 = (uint64_t) v48;
        TASSIGN(v1463, v1464);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1463, v283, v1457);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1465 = static_cast<uint64_t>(v77);
        uint16_t v1466 = static_cast<uint16_t>(v56);
        uint16_t v1467 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1455, v1461, v1465, v1466, v1467);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v1463.SetValidShape(v65, v73);
        // pto: %909
        ;
        __gm__ float* v1468 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %909
        ;
        const int64_t v1469 = 704;
        // pto: %909
        ;
        const int64_t v1470 = 1024;
        // pto: %909
        ;
        pto::Shape<1, 1, 1, 6, 64> v1471 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %909
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1472 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %909
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1473 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1468 + (v1469 + v510 * v1470), v1471, v1472);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1473, v1463);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline8435__ssa_v13
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1474 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8435__ssa_v13
        ;
        uint64_t v1475 = (uint64_t) v43;
        TASSIGN(v1474, v1475);
        // pto: %buf_current_key_inline8472__ssa_v91
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1476 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8472__ssa_v91
        ;
        uint64_t v1477 = (uint64_t) v43;
        TASSIGN(v1476, v1477);
        // pto: %911, %912
        ;
        int64_t v1478 = (int64_t) ((uint64_t) v292 + (uint64_t) v87) / v66;
        // pto: %916
        ;
        int64_t v1479 = v1478 < v295 ? v1478 : v295;
        // pto: %919, %917
        ;
        int32_t v1480 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v1479)];
        // pto: %920
        ;
        int64_t v1481 = (int64_t) v1480;
        // pto: %921
        ;
        int64_t v1482 = v1481 < v56 ? v56 : v1481;
        // pto: %922
        ;
        int64_t v1483 = (int64_t) ((uint64_t) v1482 * (uint64_t) v16);
        // pto: %923
        ;
        int64_t v1484 = v1483 % v51;
        // pto: %924, %925, %926
        ;
        int64_t v1485 = v1484 < v56 ? (int64_t) ((uint64_t) v1484 + (uint64_t) v51) : v1484;
        // pto: %927
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        if (v1485 == v56) {
          // pto: %928
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1486;
          // pto: %928
          ;
          uint64_t v1487 = (uint64_t) v45;
          TASSIGN(v1486, v1487);
          // pto: %929
          ;
          int64_t v1488 = v1483 / v51;
          // pto: %930
          ;
          int64_t v1489 = v1488 < v56 ? v56 : v1488;
          // pto: %931
          ;
          __gm__ int8_t* v1490 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %931
          ;
          const int64_t v1491 = 0;
          // pto: %931
          ;
          const int64_t v1492 = 128;
          // pto: %931
          ;
          pto::Shape<1, 1, 1, 32, 128> v1493 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %931
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1494 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %931
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1495 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1490 + (v1491 + v1489 * v1492), v1493, v1494);
          TLOAD(v1486, v1495);
        } else {
          // pto: %932
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1496;
          // pto: %932
          ;
          uint64_t v1497 = (uint64_t) v45;
          TASSIGN(v1496, v1497);
          // pto: %933
          ;
          int64_t v1498 = v1483 / v51;
          // pto: %934
          ;
          int64_t v1499 = v1498 < v56 ? v56 : v1498;
          // pto: %935
          ;
          __gm__ int8_t* v1500 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %935
          ;
          const int64_t v1501 = 0;
          // pto: %935
          ;
          const int64_t v1502 = 128;
          // pto: %935
          ;
          pto::Shape<1, 1, 1, 32, 128> v1503 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %935
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1504 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %935
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1505 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1500 + (v1501 + v1499 * v1502), v1503, v1504);
          TLOAD(v1496, v1505);
        };
        // pto: %938, %939
        ;
        int64_t v1506 = (int64_t) ((uint64_t) v292 + (uint64_t) v27) / v66;
        // pto: %943
        ;
        int64_t v1507 = v1506 < v295 ? v1506 : v295;
        // pto: %946, %944
        ;
        int32_t v1508 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v1507)];
        // pto: %947
        ;
        int64_t v1509 = (int64_t) v1508;
        // pto: %948
        ;
        int64_t v1510 = v1509 < v56 ? v56 : v1509;
        // pto: %949
        ;
        int64_t v1511 = (int64_t) ((uint64_t) v1510 * (uint64_t) v16);
        // pto: %950
        ;
        int64_t v1512 = v1511 % v51;
        // pto: %951, %952, %953
        ;
        int64_t v1513 = v1512 < v56 ? (int64_t) ((uint64_t) v1512 + (uint64_t) v51) : v1512;
        // pto: %954
        ;
        if (v1513 == v56) {
          // pto: %956
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1514;
          // pto: %956
          ;
          uint64_t v1515 = (uint64_t) v42;
          TASSIGN(v1514, v1515);
          // pto: %957
          ;
          int64_t v1516 = v1511 / v51;
          // pto: %958
          ;
          int64_t v1517 = v1516 < v56 ? v56 : v1516;
          // pto: %959
          ;
          __gm__ int8_t* v1518 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %959
          ;
          const int64_t v1519 = 0;
          // pto: %959
          ;
          const int64_t v1520 = 128;
          // pto: %959
          ;
          pto::Shape<1, 1, 1, 32, 128> v1521 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %959
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1522 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %959
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1523 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1518 + (v1519 + v1517 * v1520), v1521, v1522);
          TLOAD(v1514, v1523);
        } else {
          // pto: %961
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1524;
          // pto: %961
          ;
          uint64_t v1525 = (uint64_t) v42;
          TASSIGN(v1524, v1525);
          // pto: %962
          ;
          int64_t v1526 = v1511 / v51;
          // pto: %963
          ;
          int64_t v1527 = v1526 < v56 ? v56 : v1526;
          // pto: %964
          ;
          __gm__ int8_t* v1528 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %964
          ;
          const int64_t v1529 = 0;
          // pto: %964
          ;
          const int64_t v1530 = 128;
          // pto: %964
          ;
          pto::Shape<1, 1, 1, 32, 128> v1531 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %964
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1532 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %964
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1533 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1528 + (v1529 + v1527 * v1530), v1531, v1532);
          TLOAD(v1524, v1533);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v414
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1534 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v414
        ;
        uint64_t v1535 = (uint64_t) v45;
        TASSIGN(v1534, v1535);
        // pto: %buf_prefetched_key_inline8551__ssa_v66
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1536 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8551__ssa_v66
        ;
        uint64_t v1537 = (uint64_t) v47;
        TASSIGN(v1536, v1537);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1538 = static_cast<uint16_t>(v56);
        uint16_t v1539 = static_cast<uint16_t>(v56);
        TEXTRACT(v1536, v1534, v1538, v1539);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        // pto: %buf_key_panel_inline8420__ssa_v39
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1540 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8420__ssa_v39
        ;
        uint64_t v1541 = (uint64_t) v43;
        TASSIGN(v1540, v1541);
        // pto: %buf_scores_l1_inline8475__ssa_v52
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1542 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8475__ssa_v52
        ;
        uint64_t v1543 = (uint64_t) v44;
        TASSIGN(v1542, v1543);
        // pto: %buf_previous_pair_inline8418__ssa_v13
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1544 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8418__ssa_v13
        ;
        uint64_t v1545 = (uint64_t) v46;
        TASSIGN(v1544, v1545);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v1546 = static_cast<uint16_t>(v56);
        uint16_t v1547 = static_cast<uint16_t>(v56);
        TEXTRACT(v1544, v1474, v1546, v1547);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline8619__ssa_v39
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1548 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8619__ssa_v39
        ;
        uint64_t v1549 = (uint64_t) v43;
        TASSIGN(v1548, v1549);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1548, v281, v1540);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline8484__ssa_v13
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1550 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8484__ssa_v13
        ;
        uint64_t v1551 = (uint64_t) v48;
        TASSIGN(v1550, v1551);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1550, v283, v1544);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1552 = static_cast<uint64_t>(v77);
        uint16_t v1553 = static_cast<uint16_t>(v56);
        uint16_t v1554 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1542, v1548, v1552, v1553, v1554);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v1550.SetValidShape(v65, v73);
        // pto: %968
        ;
        __gm__ float* v1555 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %968
        ;
        const int64_t v1556 = 768;
        // pto: %968
        ;
        const int64_t v1557 = 1024;
        // pto: %968
        ;
        pto::Shape<1, 1, 1, 6, 64> v1558 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %968
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1559 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %968
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1560 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1555 + (v1556 + v510 * v1557), v1558, v1559);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1560, v1550);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline8435__ssa_v14
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1561 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8435__ssa_v14
        ;
        uint64_t v1562 = (uint64_t) v44;
        TASSIGN(v1561, v1562);
        // pto: %buf_current_key_inline8472__ssa_v98
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1563 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8472__ssa_v98
        ;
        uint64_t v1564 = (uint64_t) v47;
        TASSIGN(v1563, v1564);
        // pto: %970, %971
        ;
        int64_t v1565 = (int64_t) ((uint64_t) v292 + (uint64_t) v88) / v66;
        // pto: %975
        ;
        int64_t v1566 = v1565 < v295 ? v1565 : v295;
        // pto: %978, %976
        ;
        int32_t v1567 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v1566)];
        // pto: %979
        ;
        int64_t v1568 = (int64_t) v1567;
        // pto: %980
        ;
        int64_t v1569 = v1568 < v56 ? v56 : v1568;
        // pto: %981
        ;
        int64_t v1570 = (int64_t) ((uint64_t) v1569 * (uint64_t) v16);
        // pto: %982
        ;
        int64_t v1571 = v1570 % v51;
        // pto: %983, %984, %985
        ;
        int64_t v1572 = v1571 < v56 ? (int64_t) ((uint64_t) v1571 + (uint64_t) v51) : v1571;
        // pto: %986
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        if (v1572 == v56) {
          // pto: %987
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1573;
          // pto: %987
          ;
          uint64_t v1574 = (uint64_t) v41;
          TASSIGN(v1573, v1574);
          // pto: %988
          ;
          int64_t v1575 = v1570 / v51;
          // pto: %989
          ;
          int64_t v1576 = v1575 < v56 ? v56 : v1575;
          // pto: %990
          ;
          __gm__ int8_t* v1577 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %990
          ;
          const int64_t v1578 = 0;
          // pto: %990
          ;
          const int64_t v1579 = 128;
          // pto: %990
          ;
          pto::Shape<1, 1, 1, 32, 128> v1580 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %990
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1581 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %990
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1582 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1577 + (v1578 + v1576 * v1579), v1580, v1581);
          TLOAD(v1573, v1582);
        } else {
          // pto: %991
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1583;
          // pto: %991
          ;
          uint64_t v1584 = (uint64_t) v41;
          TASSIGN(v1583, v1584);
          // pto: %992
          ;
          int64_t v1585 = v1570 / v51;
          // pto: %993
          ;
          int64_t v1586 = v1585 < v56 ? v56 : v1585;
          // pto: %994
          ;
          __gm__ int8_t* v1587 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %994
          ;
          const int64_t v1588 = 0;
          // pto: %994
          ;
          const int64_t v1589 = 128;
          // pto: %994
          ;
          pto::Shape<1, 1, 1, 32, 128> v1590 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %994
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1591 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %994
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1592 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1587 + (v1588 + v1586 * v1589), v1590, v1591);
          TLOAD(v1583, v1592);
        };
        // pto: %998
        ;
        int64_t v1593 = (int64_t) ((uint64_t) v292 + (uint64_t) v26) / v66;
        // pto: %1002
        ;
        int64_t v1594 = v1593 < v295 ? v1593 : v295;
        // pto: %1005, %1003
        ;
        int32_t v1595 = (v10)[(int64_t) ((uint64_t) v297 + (uint64_t) v1594)];
        // pto: %1006
        ;
        int64_t v1596 = (int64_t) v1595;
        // pto: %1007
        ;
        int64_t v1597 = v1596 < v56 ? v56 : v1596;
        // pto: %1008
        ;
        int64_t v1598 = (int64_t) ((uint64_t) v1597 * (uint64_t) v16);
        // pto: %1009
        ;
        int64_t v1599 = v1598 % v51;
        // pto: %1010, %1011, %1012
        ;
        int64_t v1600 = v1599 < v56 ? (int64_t) ((uint64_t) v1599 + (uint64_t) v51) : v1599;
        // pto: %1013
        ;
        if (v1600 == v56) {
          // pto: %1015
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1601;
          // pto: %1015
          ;
          uint64_t v1602 = (uint64_t) v39;
          TASSIGN(v1601, v1602);
          // pto: %1016
          ;
          int64_t v1603 = v1598 / v51;
          // pto: %1017
          ;
          int64_t v1604 = v1603 < v56 ? v56 : v1603;
          // pto: %1018
          ;
          __gm__ int8_t* v1605 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %1018
          ;
          const int64_t v1606 = 0;
          // pto: %1018
          ;
          const int64_t v1607 = 128;
          // pto: %1018
          ;
          pto::Shape<1, 1, 1, 32, 128> v1608 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %1018
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1609 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %1018
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1610 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1605 + (v1606 + v1604 * v1607), v1608, v1609);
          TLOAD(v1601, v1610);
        } else {
          // pto: %1020
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1611;
          // pto: %1020
          ;
          uint64_t v1612 = (uint64_t) v39;
          TASSIGN(v1611, v1612);
          // pto: %1021
          ;
          int64_t v1613 = v1598 / v51;
          // pto: %1022
          ;
          int64_t v1614 = v1613 < v56 ? v56 : v1613;
          // pto: %1023
          ;
          __gm__ int8_t* v1615 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %1023
          ;
          const int64_t v1616 = 0;
          // pto: %1023
          ;
          const int64_t v1617 = 128;
          // pto: %1023
          ;
          pto::Shape<1, 1, 1, 32, 128> v1618 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %1023
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1619 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %1023
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1620 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1615 + (v1616 + v1614 * v1617), v1618, v1619);
          TLOAD(v1611, v1620);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v418
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1621 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v418
        ;
        uint64_t v1622 = (uint64_t) v45;
        TASSIGN(v1621, v1622);
        // pto: %buf_prefetched_key_inline8551__ssa_v71
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1623 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8551__ssa_v71
        ;
        uint64_t v1624 = (uint64_t) v43;
        TASSIGN(v1623, v1624);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1625 = static_cast<uint16_t>(v56);
        uint16_t v1626 = static_cast<uint16_t>(v73);
        TEXTRACT(v1623, v1621, v1625, v1626);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        // pto: %buf_key_panel_inline8420__ssa_v42
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1627 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8420__ssa_v42
        ;
        uint64_t v1628 = (uint64_t) v47;
        TASSIGN(v1627, v1628);
        // pto: %buf_scores_l1_inline8475__ssa_v56
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1629 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8475__ssa_v56
        ;
        uint64_t v1630 = (uint64_t) v43;
        TASSIGN(v1629, v1630);
        // pto: %buf_previous_pair_inline8418__ssa_v14
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1631 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8418__ssa_v14
        ;
        uint64_t v1632 = (uint64_t) v46;
        TASSIGN(v1631, v1632);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v1633 = static_cast<uint16_t>(v56);
        uint16_t v1634 = static_cast<uint16_t>(v56);
        TEXTRACT(v1631, v1561, v1633, v1634);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline8619__ssa_v42
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1635 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8619__ssa_v42
        ;
        uint64_t v1636 = (uint64_t) v43;
        TASSIGN(v1635, v1636);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1635, v281, v1627);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline8484__ssa_v14
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1637 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8484__ssa_v14
        ;
        uint64_t v1638 = (uint64_t) v48;
        TASSIGN(v1637, v1638);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1637, v283, v1631);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1639 = static_cast<uint64_t>(v77);
        uint16_t v1640 = static_cast<uint16_t>(v56);
        uint16_t v1641 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1629, v1635, v1639, v1640, v1641);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v1637.SetValidShape(v65, v73);
        // pto: %1027
        ;
        __gm__ float* v1642 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %1027
        ;
        const int64_t v1643 = 832;
        // pto: %1027
        ;
        const int64_t v1644 = 1024;
        // pto: %1027
        ;
        pto::Shape<1, 1, 1, 6, 64> v1645 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %1027
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1646 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %1027
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1647 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1642 + (v1643 + v510 * v1644), v1645, v1646);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1647, v1637);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline8435__ssa_v15
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1648 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8435__ssa_v15
        ;
        uint64_t v1649 = (uint64_t) v43;
        TASSIGN(v1648, v1649);
        // pto: %buf_current_key_inline8472__ssa_v105
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1650 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8472__ssa_v105
        ;
        uint64_t v1651 = (uint64_t) v43;
        TASSIGN(v1650, v1651);
        // pto: %buf_key_panel_inline8420__ssa_v45
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1652 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8420__ssa_v45
        ;
        uint64_t v1653 = (uint64_t) v43;
        TASSIGN(v1652, v1653);
        // pto: %buf_scores_l1_inline8475__ssa_v60
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1654 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8475__ssa_v60
        ;
        uint64_t v1655 = (uint64_t) v44;
        TASSIGN(v1654, v1655);
        // pto: %buf_previous_pair_inline8418__ssa_v15
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1656 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8418__ssa_v15
        ;
        uint64_t v1657 = (uint64_t) v46;
        TASSIGN(v1656, v1657);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1658 = static_cast<uint16_t>(v56);
        uint16_t v1659 = static_cast<uint16_t>(v56);
        TEXTRACT(v1656, v1648, v1658, v1659);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline8619__ssa_v45
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1660 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8619__ssa_v45
        ;
        uint64_t v1661 = (uint64_t) v43;
        TASSIGN(v1660, v1661);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1660, v281, v1652);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline8484__ssa_v15
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1662 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8484__ssa_v15
        ;
        uint64_t v1663 = (uint64_t) v48;
        TASSIGN(v1662, v1663);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1662, v283, v1656);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1664 = static_cast<uint64_t>(v77);
        uint16_t v1665 = static_cast<uint16_t>(v56);
        uint16_t v1666 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1654, v1660, v1664, v1665, v1666);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v1662.SetValidShape(v65, v73);
        // pto: %1031
        ;
        __gm__ float* v1667 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %1031
        ;
        const int64_t v1668 = 896;
        // pto: %1031
        ;
        const int64_t v1669 = 1024;
        // pto: %1031
        ;
        pto::Shape<1, 1, 1, 6, 64> v1670 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %1031
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1671 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %1031
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1672 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1667 + (v1668 + v510 * v1669), v1670, v1671);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1672, v1662);
        // pto: %buf_previous_l1_inline8435__ssa_v16
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1673 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8435__ssa_v16
        ;
        uint64_t v1674 = (uint64_t) v44;
        TASSIGN(v1673, v1674);
        // pto: %buf_last_pair_inline8424__ssa_v0
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1675 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_last_pair_inline8424__ssa_v0
        ;
        uint64_t v1676 = (uint64_t) v46;
        TASSIGN(v1675, v1676);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1677 = static_cast<uint16_t>(v56);
        uint16_t v1678 = static_cast<uint16_t>(v56);
        TEXTRACT(v1675, v1673, v1677, v1678);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_last_scores_inline8414__ssa_v0
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1679 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_last_scores_inline8414__ssa_v0
        ;
        uint64_t v1680 = (uint64_t) v43;
        TASSIGN(v1679, v1680);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        TMATMUL(v1679, v283, v1675);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        v1679.SetValidShape(v65, v73);
        // pto: %1033
        ;
        __gm__ float* v1681 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %1033
        ;
        const int64_t v1682 = 960;
        // pto: %1033
        ;
        const int64_t v1683 = 1024;
        // pto: %1033
        ;
        pto::Shape<1, 1, 1, 6, 64> v1684 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %1033
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1685 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %1033
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1686 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1681 + (v1682 + v510 * v1683), v1684, v1685);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        pipe_barrier(PIPE_FIX);
        TSTORE(v1686, v1679);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        uint16_t v1687 = getFFTSMsg(FFTS_MODE_VAL, v56);
        ffts_cross_core_sync(PIPE_FIX, v1687);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      // pto: %1034
      ;
      for (int64_t v1688 = v56; v1688 < (v259 < v75 ? v259 : v75); v1688 += v49) {
        int32_t v1689 = (int32_t) v49;
        wait_flag_dev(v1689);
      };
    };
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void indexer_score_topk_native_pair_aiv(__gm__ int32_t* v1, __gm__ int32_t* v2, __gm__ int64_t* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, __gm__ int64_t* v7, __gm__ int8_t* v8, __gm__ half* v9, __gm__ int32_t* v10, __gm__ int8_t* v11, __gm__ int8_t* v12, __gm__ float* v13, __gm__ int8_t* v14, __gm__ float* v15, int64_t v16, int64_t v17, int64_t v18, int64_t v19, int64_t v20, int64_t v21, int64_t v22, int64_t v23, int32_t v24, int32_t v25, int32_t v26) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v27 = 8192;
  const int64_t v28 = 4096;
  pto::MrgSortExecutedNumList v29 = pto::MrgSortExecutedNumList{0, 0, 0, 0};
  // pto: %c0_i64
  const int64_t v30 = 0;
  // pto: %c12288_i64
  const int64_t v31 = 12288;
  // pto: %c57344_i64
  const int64_t v32 = 57344;
  // pto: %c73728_i64
  const int64_t v33 = 73728;
  // pto: %c40960_i64
  const int64_t v34 = 40960;
  // pto: %c49152_i64
  const int64_t v35 = 49152;
  // pto: %c36864_i64
  const int64_t v36 = 36864;
  const int64_t v37 = 77824;
  // pto: %c1_index
  const int64_t v38 = 1;
  // pto: %c27648_index
  const int64_t v39 = 27648;
  // pto: %c288_index
  const int64_t v40 = 288;
  // pto: %c1024_index
  const int64_t v41 = 1024;
  // pto: %c0_index
  const int64_t v42 = 0;
  // pto: %c4_index
  const int64_t v43 = 4;
  // pto: %c262144_index
  const int64_t v44 = 262144;
  // pto: %c1023_index
  const int64_t v45 = 1023;
  // pto: %c8191_index
  const int64_t v46 = 8191;
  // pto: %c8192_index
  const int64_t v47 = 8192;
  // pto: %c3_index
  const int64_t v48 = 3;
  // pto: %c48_index
  const int64_t v49 = 48;
  // pto: %c24_index
  const int64_t v50 = 24;
  // pto: %c6_index
  const int64_t v51 = 6;
  // pto: %c32_index
  const int64_t v52 = 32;
  // pto: %c8_index
  const int64_t v53 = 8;
  // pto: %c1_i64
  const int64_t v54 = 1;
  // pto: %c4_i64
  const int64_t v55 = 4;
  // pto: %cst_30
  const float v56 = -3.40282347E+38f;
  // pto: %c12_index
  const int64_t v57 = 12;
  // pto: %c2_index
  const int64_t v58 = 2;
  // pto: %c2048_index
  const int64_t v59 = 2048;
  // pto: %c64_index
  const int64_t v60 = 64;
  // pto: %c4096_index
  const int64_t v61 = 4096;
  // pto: %c512_index
  const int64_t v62 = 512;
  // pto: %c192_index
  const int64_t v63 = 192;
  // pto: %c0_i32
  const int32_t v64 = 0;
  // pto: %c64_i32
  const int32_t v65 = 64;
  // pto: %c256_i32
  const int32_t v66 = 256;
  // pto: %c1024_i32
  const int32_t v67 = 1024;
  // pto: %buf_score_transfer_inline8569__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %buf_score_transfer_inline8569__ssa_v0_view
  const int64_t v69 = 1;
  // pto: %buf_score_transfer_inline8569__ssa_v0_view
  const int64_t v70 = 1;
  // pto: %buf_score_transfer_inline8569__ssa_v0_view
  int64_t v71 = v40 * v41;
  // pto: %buf_score_transfer_inline8569__ssa_v0_view
  int64_t v72 = v70 * v71;
  // pto: %buf_score_transfer_inline8569__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v73 = pto::Shape<1, 1, 1, -1, -1>(v68, v69, v70, v40, v41);
  // pto: %buf_score_transfer_inline8569__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v74 = pto::Stride<-1, -1, -1, -1, -1>(v69 * v72, v72, v71, v41, v38);
  // pto: %buf_score_transfer_inline8569__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v75 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v73, v74);
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v76 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v77 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v78 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v79 = (int64_t) v22;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v80 = (int64_t) v23;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v81 = v79 * v80;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v82 = v78 * v81;
  // pto: %idx_native_kv_cache__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v83 = pto::Shape<1, 1, 1, -1, -1>(v76, v77, v78, v79, (int64_t) v23);
  // pto: %idx_native_kv_cache__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v84 = pto::Stride<-1, -1, -1, -1, -1>(v77 * v82, v82, v81, v80, v38);
  // pto: %idx_native_kv_cache__rv_v2_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v85 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v83, v84);
  // pto: %pair_arena_inline1403_inline5107__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %pair_arena_inline1403_inline5107__ssa_v0_view
  const int64_t v87 = 1;
  // pto: %pair_arena_inline1403_inline5107__ssa_v0_view
  const int64_t v88 = 1;
  // pto: %pair_arena_inline1403_inline5107__ssa_v0_view
  int64_t v89 = v39 * v41;
  // pto: %pair_arena_inline1403_inline5107__ssa_v0_view
  int64_t v90 = v88 * v89;
  // pto: %pair_arena_inline1403_inline5107__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v91 = pto::Shape<1, 1, 1, -1, -1>(v86, v87, v88, v39, v41);
  // pto: %pair_arena_inline1403_inline5107__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v92 = pto::Stride<-1, -1, -1, -1, -1>(v87 * v90, v90, v89, v41, v38);
  // pto: %pair_arena_inline1403_inline5107__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v93 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v91, v92);
  // pto: %single_roots_inline8478__phi_v15
  Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
  // pto: %single_roots_inline8478__phi_v15
  uint64_t v95 = (uint64_t) v30;
  TASSIGN(v94, v95);
  // pto: %single_roots_inline8478__phi_v6
  Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v96 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
  // pto: %single_roots_inline8478__phi_v6
  uint64_t v97 = (uint64_t) v30;
  TASSIGN(v96, v97);
  // pto: %single_new_root_inline8558__phi_v4
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v98 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
  // pto: %single_new_root_inline8558__phi_v4
  uint64_t v99 = (uint64_t) v36;
  TASSIGN(v98, v99);
  // pto: %single_new_root_inline8558__phi_v3
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v100 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
  // pto: %single_new_root_inline8558__phi_v3
  uint64_t v101 = (uint64_t) v36;
  TASSIGN(v100, v101);
  // pto: %single_roots_inline8478__phi_v5
  Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
  // pto: %single_roots_inline8478__phi_v5
  uint64_t v103 = (uint64_t) v30;
  TASSIGN(v102, v103);
  // pto: %single_roots_inline8478__phi_v10
  Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v104 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
  // pto: %single_roots_inline8478__phi_v10
  uint64_t v105 = (uint64_t) v30;
  TASSIGN(v104, v105);
  // pto: %single_new_root_inline8558__phi_v9
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
  // pto: %single_new_root_inline8558__phi_v9
  uint64_t v107 = (uint64_t) v36;
  TASSIGN(v106, v107);
  // pto: %single_new_root_inline8558__phi_v8
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
  // pto: %single_new_root_inline8558__phi_v8
  uint64_t v109 = (uint64_t) v36;
  TASSIGN(v108, v109);
  // pto: %single_roots_inline8478__phi_v9
  Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
  // pto: %single_roots_inline8478__phi_v9
  uint64_t v111 = (uint64_t) v30;
  TASSIGN(v110, v111);
  // pto: %single_roots_inline8478__phi_v14
  Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v112 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
  // pto: %single_roots_inline8478__phi_v14
  uint64_t v113 = (uint64_t) v30;
  TASSIGN(v112, v113);
  // pto: %single_new_root_inline8558__phi_v14
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v114 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
  // pto: %single_new_root_inline8558__phi_v14
  uint64_t v115 = (uint64_t) v36;
  TASSIGN(v114, v115);
  // pto: %single_new_root_inline8558__phi_v13
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
  // pto: %single_new_root_inline8558__phi_v13
  uint64_t v117 = (uint64_t) v36;
  TASSIGN(v116, v117);
  // pto: %single_roots_inline8478__phi_v13
  Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v118 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
  // pto: %single_roots_inline8478__phi_v13
  uint64_t v119 = (uint64_t) v30;
  TASSIGN(v118, v119);
  // pto: %buf_worker_inline8582__ssa_v0
  int64_t v120 = (int64_t) v24;
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  // pto: %buf_max_cache_len_inline8525__rv_v2
  int64_t v121;
  v121 = v42;
  for (int64_t v122 = v42; v122 < v17; v122 += v38) {
    // pto: %t__tile
    ;
    int32_t v123 = (v1)[v122];
    // pto: %0, %1
    ;
    int64_t v124 = (int64_t) v123 / v43;
    // pto: %2
    ;
    bool v125 = v121 < v124;
    // pto: %2
    ;
    int64_t v126 = v125 ? v124 : v121;
    v121 = v126;
  }
  // pto: %3
  bool v127 = v121 < v44;
  // pto: %3
  int64_t v128 = v127 ? v121 : v44;
  // pto: %4
  int32_t v129 = (v2)[v42];
  // pto: %5
  int64_t v130 = (int64_t) v129;
  // pto: %6, %7
  int64_t v131 = (int64_t) ((uint64_t) v128 + (uint64_t) v45) / v41;
  // pto: %8, %9
  int64_t v132 = (int64_t) ((uint64_t) v128 + (uint64_t) v46) / v47;
  // pto: %10
  int64_t v133 = v132 < v38 ? v38 : v132;
  // pto: %11
  int64_t v134 = (int64_t) ((uint64_t) v130 * (uint64_t) v48);
  // pto: %12
  // pto: %leaf_multiple_inline2661_inline8467__phi_v6
  int64_t v135;
  if (v134 == v49) {
    v135 = v48;
  } else {
    // pto: %14
    ;
    // pto: %leaf_multiple_inline2661_inline8467__phi_v5
    ;
    int64_t v136;
    if (v134 == v50) {
      v136 = v48;
    } else {
      // pto: %15, %16, %leaf_multiple_inline2661_inline8467__phi_v4
      ;
      v136 = (int64_t) ((uint64_t) v130 * (uint64_t) v51) == v50 ? v51 : v38;
    };
    v135 = v136;
  }
  // pto: %17
  bool v137 = v135 > v38;
  // pto: %extra_leaves_inline2660_inline8396__phi_v3
  int64_t v138;
  // pto: %leaf_count_inline2663_inline8421__phi_v3
  int64_t v139;
  // pto: %leaf_tiles_inline2662_inline8533__phi_v3
  int64_t v140;
  if (v137) {
    // pto: %18
    ;
    uint64_t v141 = (uint64_t) v135;
    // pto: %18, %19, %20
    ;
    int64_t v142 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v133 + v141) - (uint64_t) v38) / v135;
    // pto: %21
    ;
    uint64_t v143 = (uint64_t) v135;
    // pto: %21
    ;
    int64_t v144 = (int64_t) ((uint64_t) v142 * v143);
    // pto: %22
    ;
    bool v145 = v144 <= v52;
    // pto: %extra_leaves_inline2660_inline8396__phi_v2
    ;
    // pto: %leaf_count_inline2663_inline8421__phi_v2
    ;
    int64_t v146;
    // pto: %leaf_tiles_inline2662_inline8533__phi_v2
    ;
    int64_t v147;
    if (v145) {
      // pto: %23
      ;
      int64_t v148 = v131 / v144;
      // pto: %24
      ;
      // pto: %25
      ;
      int64_t v149 = v131 % v144;
      // pto: %29, %26, %27, %28, %30, %31, %32
      ;
      v146 = v149 != v42 & (v149 < v42 ^ v144 < v42) ? (int64_t) ((uint64_t) v149 + (uint64_t) v144) : v149;
      v147 = v148 < v38 ? v38 : v148;
    } else {
      v146 = v42;
      v147 = v53;
    };
    v138 = v146;
    v139 = v145 ? v144 : v133;
    v140 = v147;
  } else {
    v138 = v42;
    v139 = v133;
    v140 = v53;
  }
  uint64_t v150 = reinterpret_cast<uint64_t>(v3);
  set_ffts_base_addr(v150);
  // pto: %buf_score_lane_inline8581__ssa_v0
  int64_t v151 = (int64_t) v26;
  // pto: %33
  uint64_t v152 = (uint64_t) v139;
  // pto: %33
  for (int64_t v153 = v120; v153 < ((int64_t) ((uint64_t) v130 * v152)); v153 += v50) {
    // pto: %34
    ;
    // pto: %single_group_inline8407__phi_v2
    ;
    int64_t v154;
    // pto: %single_leaf_inline8406__phi_v2
    ;
    int64_t v155;
    if (v130 < v50) {
      // pto: %35
      ;
      int64_t v156 = v153 % v130;
      // pto: %39, %36, %37, %38, %40, %41, %42
      ;
      // pto: %43
      ;
      v154 = v156 != v42 & (v156 < v42 ^ v130 < v42) ? (int64_t) ((uint64_t) v156 + (uint64_t) v130) : v156;
      v155 = v153 / v130;
    } else {
      // pto: %44
      ;
      int64_t v157 = v153 / v139;
      // pto: %45
      ;
      int64_t v158 = v153 % v139;
      // pto: %47
      ;
      bool v159 = v139 < v42;
      // pto: %51
      ;
      uint64_t v160 = (uint64_t) v139;
      // pto: %49, %46, %48, %50, %51, %52
      ;
      v154 = v157;
      v155 = v158 != v42 & (v158 < v42 ^ v159) ? (int64_t) ((uint64_t) v158 + v160) : v158;
    };
    // pto: %53
    ;
    int32_t v161 = (v4)[v154];
    // pto: %54
    ;
    int64_t v162 = (int64_t) v161;
    // pto: %55
    ;
    int32_t v163 = (v5)[v154];
    // pto: %56
    ;
    int64_t v164 = (int64_t) v163;
    // pto: %57
    ;
    int32_t v165 = (v6)[v162];
    // pto: %58
    ;
    int64_t v166 = (int64_t) v165;
    // pto: %59
    ;
    int32_t v167 = (v1)[v166];
    // pto: %60, %61
    ;
    int64_t v168 = (int64_t) v167 / v43;
    // pto: %62, %63, %single_last_position_inline8410__tile
    ;
    int64_t v169 = (v7)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v162 + (uint64_t) v164) - (uint64_t) v38)];
    // pto: %64, %65
    ;
    int64_t v170 = (int64_t) ((uint64_t) v169 + (uint64_t) v54) / v55;
    // pto: %67
    ;
    int64_t v171 = v168 < v170 ? v168 : v170;
    // pto: %68
    ;
    int64_t v172 = v171 < v44 ? v171 : v44;
    // pto: %69
    ;
    int64_t v173 = v172 < v42 ? v42 : v172;
    // pto: %70
    ;
    uint64_t v174 = (uint64_t) v155;
    // pto: %70
    ;
    uint64_t v175 = (uint64_t) v140;
    // pto: %71
    ;
    bool v176 = v155 < v138;
    // pto: %71
    ;
    int64_t v177 = v176 ? v155 : v138;
    // pto: %70, %72, %73
    ;
    int64_t v178 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v174 * v175) + (uint64_t) v177) * (uint64_t) v41);
    // pto: %74
    ;
    bool v179 = v155 < v138;
    // pto: %76
    ;
    uint64_t v180 = (uint64_t) v140;
    // pto: %75, %76, %77
    ;
    int64_t v181 = (int64_t) ((uint64_t) ((int64_t) v180 + (uint64_t) ((int64_t) v179)) * (uint64_t) v41);
    // pto: %78
    ;
    if (v178 < v173) {
      // pto: %79
      ;
      int64_t v182 = (int64_t) ((uint64_t) v173 - (uint64_t) v178);
      // pto: %80
      ;
      int64_t v183 = v181 < v182 ? v181 : v182;
      // pto: %81, %82
      ;
      int64_t v184 = (int64_t) ((uint64_t) v183 + (uint64_t) v45) / v41;
      // pto: %single_roots_inline8478__ssa_v0
      ;
      Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v185 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
      // pto: %single_roots_inline8478__ssa_v0
      ;
      uint64_t v186 = (uint64_t) v30;
      TASSIGN(v185, v186);
      pipe_barrier(PIPE_V);
      TEXPANDS(v185, v56);
      // pto: %single_segments_inline8490__ssa_v0
      ;
      Tile<TileType::Vec, float, 6, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v187 = Tile<TileType::Vec, float, 6, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v51, v41);
      // pto: %single_segments_inline8490__ssa_v0
      ;
      uint64_t v188 = (uint64_t) v31;
      TASSIGN(v187, v188);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      TEXPANDS(v187, v56);
      for (int64_t v189 = v42; v189 < v184; v189 += v38) {
        // pto: %86
        ;
        int64_t v190 = v189 % v58;
        // pto: %87, %88, %89
        ;
        int64_t v191 = v190 < v42 ? (int64_t) ((uint64_t) v190 + (uint64_t) v58) : v190;
        // pto: %92
        ;
        int64_t v192 = (int64_t) ((uint64_t) v151 * (uint64_t) v48);
        // pto: %85, %91, %90, %93
        ;
        int64_t v193 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v120 * (uint64_t) v57) + (uint64_t) ((int64_t) (uint64_t) v191 * (uint64_t) v51)) + (uint64_t) v192);
        // pto: %single_scale_bytes_inline8397__ssa_v0
        ;
        Tile<TileType::Vec, int8_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v194 = Tile<TileType::Vec, int8_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
        // pto: %single_scale_bytes_inline8397__ssa_v0
        ;
        uint64_t v195 = (uint64_t) v32;
        TASSIGN(v194, v195);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
        for (int64_t v196 = v42; v196 < v52; v196 += v38) {
          // pto: %84, %83, %94, %95
          ;
          int64_t v197 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v178 + (uint64_t) ((int64_t) (uint64_t) v189 * (uint64_t) v41)) / v52) + (uint64_t) v196);
          // pto: %96, %97
          ;
          int64_t v198 = (int64_t) ((uint64_t) v168 - (uint64_t) v38) / v52;
          // pto: %98
          ;
          int64_t v199 = v198 < v42 ? v42 : v198;
          // pto: %99
          ;
          int64_t v200 = v197 < v199 ? v197 : v199;
          // pto: %flat_offset_mul, %flat_offset, %100
          ;
          int32_t v201 = (v10)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v166 * (uint64_t) v19) + (uint64_t) v200)];
          // pto: %101
          ;
          int64_t v202 = (int64_t) v201;
          // pto: %102
          ;
          int64_t v203 = v202 < v42 ? v42 : v202;
          // pto: %gather_row_view
          ;
          Tile<TileType::Vec, int8_t, 1, 2048, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v204;
          // pto: %103, %gather_row_view
          ;
          uint64_t v205 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v196 * (uint64_t) v60) + (uint64_t) v32);
          TASSIGN(v204, v205);
          // pto: %104
          ;
          int64_t v206 = v203 < v42 ? v42 : v203;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v207 = (int64_t) v23;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v208 = 0;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          __gm__ int8_t* v209 = PTOAS__GLOBAL_TENSOR_DATA(v85);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v210 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v211 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v212 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v213 = v38 * v207;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v214 = v212 * v213;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          pto::Shape<1, 1, 1, 1, 64> v215 = pto::Shape<1, 1, 1, 1, 64>(v210, v211, v212, v38, v60);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v216 = pto::Stride<-1, -1, -1, -1, -1>(v211 * v214, v214, v213, v207, v38);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v217 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v209 + (v208 + v206 * v207 + v61 * v38), v215, v216);
          TLOAD(v204, v217);
        };
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %single_scale_half_inline8417__ssa_v0
        ;
        Tile<TileType::Vec, half, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Vec, half, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_scale_half_inline8417__ssa_v0
        ;
        uint64_t v219 = (uint64_t) v32;
        TASSIGN(v218, v219);
        // pto: %single_kv_scale_inline8635__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_kv_scale_inline8635__ssa_v0
        ;
        uint64_t v221 = (uint64_t) v33;
        TASSIGN(v220, v221);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v222 = RoundMode::CAST_ROUND;
        SaturationMode v223 = SaturationMode::ON;
        TCVT(v220, v218, v222, v223);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        int32_t v224 = (int32_t) v42;
        wait_flag_dev(v224);
        // pto: %single_scores_inline8393__ssa_v0
        ;
        Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v225 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
        // pto: %single_scores_inline8393__ssa_v0
        ;
        uint64_t v226 = (uint64_t) v32;
        TASSIGN(v225, v226);
        // pto: %105
        ;
        int64_t v227 = v193 < v42 ? v42 : v193;
        // pto: %buf_score_transfer_inline8569__ssa_v0_pview
        ;
        __gm__ float* v228 = PTOAS__GLOBAL_TENSOR_DATA(v75);
        // pto: %buf_score_transfer_inline8569__ssa_v0_pview
        ;
        const int64_t v229 = 0;
        // pto: %buf_score_transfer_inline8569__ssa_v0_pview
        ;
        const int64_t v230 = 1024;
        // pto: %buf_score_transfer_inline8569__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 3, 1024> v231 = pto::Shape<1, 1, 1, 3, 1024>();
        // pto: %buf_score_transfer_inline8569__ssa_v0_pview
        ;
        pto::Stride<3072, 3072, 3072, 1024, 1> v232 = pto::Stride<3072, 3072, 3072, 1024, 1>();
        // pto: %buf_score_transfer_inline8569__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 3, 1024>, pto::Stride<3072, 3072, 3072, 1024, 1>, pto::Layout::ND> v233 = GlobalTensor<float, pto::Shape<1, 1, 1, 3, 1024>, pto::Stride<3072, 3072, 3072, 1024, 1>, pto::Layout::ND>(v228 + (v229 + v227 * v230), v231, v232);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        TLOAD(v225, v233);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        uint16_t v234 = getFFTSMsg(FFTS_MODE_VAL, v38);
        ffts_cross_core_sync(PIPE_MTE2, v234);
        // pto: %single_score_row_inline8620__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v235 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_score_row_inline8620__ssa_v0
        ;
        uint64_t v236 = (uint64_t) v34;
        TASSIGN(v235, v236);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        uint16_t v237 = static_cast<uint16_t>(v42);
        uint16_t v238 = static_cast<uint16_t>(v42);
        TEXTRACT(v235, v225, v237, v238);
        // pto: %single_scaled_inline8450__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v239 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_scaled_inline8450__ssa_v0
        ;
        uint64_t v240 = (uint64_t) v34;
        TASSIGN(v239, v240);
        pipe_barrier(PIPE_V);
        TMUL(v239, v235, v220);
        // pto: %assemble_view
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v241;
        // pto: %assemble_view
        ;
        uint64_t v242 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v191 * (uint64_t) v28) + (uint64_t) v31);
        TASSIGN(v241, v242);
        pipe_barrier(PIPE_V);
        TMOV(v241, v239);
        // pto: %single_score_row_inline8620__ssa_v1
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v243 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_score_row_inline8620__ssa_v1
        ;
        uint64_t v244 = (uint64_t) v34;
        TASSIGN(v243, v244);
        pipe_barrier(PIPE_V);
        uint16_t v245 = static_cast<uint16_t>(v38);
        uint16_t v246 = static_cast<uint16_t>(v42);
        TEXTRACT(v243, v225, v245, v246);
        // pto: %single_scaled_inline8450__ssa_v1
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v247 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_scaled_inline8450__ssa_v1
        ;
        uint64_t v248 = (uint64_t) v34;
        TASSIGN(v247, v248);
        pipe_barrier(PIPE_V);
        TMUL(v247, v243, v220);
        // pto: %115
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v249;
        // pto: %114, %115
        ;
        uint64_t v250 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v191 + (uint64_t) v58) * (uint64_t) v28) + (uint64_t) v31);
        TASSIGN(v249, v250);
        pipe_barrier(PIPE_V);
        TMOV(v249, v247);
        // pto: %single_score_row_inline8620__ssa_v2
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v251 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_score_row_inline8620__ssa_v2
        ;
        uint64_t v252 = (uint64_t) v34;
        TASSIGN(v251, v252);
        pipe_barrier(PIPE_V);
        uint16_t v253 = static_cast<uint16_t>(v58);
        uint16_t v254 = static_cast<uint16_t>(v42);
        TEXTRACT(v251, v225, v253, v254);
        // pto: %single_scaled_inline8450__ssa_v2
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v255 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_scaled_inline8450__ssa_v2
        ;
        uint64_t v256 = (uint64_t) v32;
        TASSIGN(v255, v256);
        pipe_barrier(PIPE_V);
        TMUL(v255, v251, v220);
        // pto: %121
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v257;
        // pto: %120, %121
        ;
        uint64_t v258 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v191 + (uint64_t) v43) * (uint64_t) v28) + (uint64_t) v31);
        TASSIGN(v257, v258);
        pipe_barrier(PIPE_V);
        TMOV(v257, v255);
        // pto: %126, %127, %128, %129
        ;
        if (v191 == v38 | (int64_t) ((uint64_t) v189 + (uint64_t) v38) == v184) {
          // pto: %132, %130, %131
          ;
          int64_t v259 = (int64_t) ((uint64_t) v178 + (uint64_t) ((int64_t) (uint64_t) (v189 / v58) * (uint64_t) v59));
          // pto: %137, %138
          ;
          int64_t v260 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v191 * (uint64_t) v41) + (uint64_t) v41);
          // pto: %single_segment_rows_inline8391__ssa_v0
          ;
          Tile<TileType::Vec, float, 3, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v261 = Tile<TileType::Vec, float, 3, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v59);
          // pto: %single_segment_rows_inline8391__ssa_v0
          ;
          uint64_t v262 = (uint64_t) v31;
          TASSIGN(v261, v262);
          // pto: %141
          ;
          int64_t v263 = (int64_t) ((uint64_t) v164 - (uint64_t) v38);
          // pto: %142
          ;
          int64_t v264 = v192 < v263 ? v192 : v263;
          // pto: %143, %single_position_inline8556__tile
          ;
          int64_t v265 = (v7)[(int64_t) ((uint64_t) v162 + (uint64_t) v264)];
          // pto: %144, %145
          ;
          int64_t v266 = (int64_t) ((uint64_t) v265 + (uint64_t) v54) / v55;
          // pto: %147
          ;
          int64_t v267 = v168 < v266 ? v168 : v266;
          // pto: %148
          ;
          int64_t v268 = v267 < v44 ? v267 : v44;
          // pto: %149
          ;
          int64_t v269 = v268 < v42 ? v42 : v268;
          // pto: %150
          ;
          int64_t v270 = (int64_t) ((uint64_t) v269 - (uint64_t) v259);
          // pto: %151
          ;
          int64_t v271 = v270 < v260 ? v270 : v260;
          // pto: %152
          ;
          int64_t v272 = v271 < v42 ? v42 : v271;
          // pto: %153, %140, %154
          ;
          if (v272 > v42 & v192 < v164) {
            // pto: %single_segment_data_inline8457__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v273 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
            // pto: %single_segment_data_inline8457__ssa_v0
            ;
            uint64_t v274 = (uint64_t) v32;
            TASSIGN(v273, v274);
            pipe_barrier(PIPE_V);
            uint16_t v275 = static_cast<uint16_t>(v42);
            uint16_t v276 = static_cast<uint16_t>(v42);
            TEXTRACT(v273, v261, v275, v276);
            // pto: %155
            ;
            int32_t v277 = (int32_t) v259;
            // pto: %156
            ;
            if (v272 <= v62) {
              // pto: %t__ci_tmp_v0
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v278 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
              // pto: %t__ci_tmp_v0
              ;
              uint64_t v279 = (uint64_t) v34;
              TASSIGN(v278, v279);
              // pto: %t__tmp_v427
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v280 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v427
              ;
              uint64_t v281 = (uint64_t) v33;
              TASSIGN(v280, v281);
              // pto: %ci_tmp_view
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v282;
              TRESHAPE(v282, v278);
              // pto: %ci_dst_view
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v283;
              TRESHAPE(v283, v280);
              TCI<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v283, v64, v282);
              // pto: %tiny_indices_inline8552__ssa_v0
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v284 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %tiny_indices_inline8552__ssa_v0
              ;
              uint64_t v285 = (uint64_t) v34;
              TASSIGN(v284, v285);
              pipe_barrier(PIPE_V);
              TADDS(v284, v280, v277);
              // pto: %tiny_tile_inline8508__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v286 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %tiny_tile_inline8508__ssa_v0
              ;
              uint64_t v287 = (uint64_t) v33;
              TASSIGN(v286, v287);
              pipe_barrier(PIPE_V);
              uint16_t v288 = static_cast<uint16_t>(v42);
              uint16_t v289 = static_cast<uint16_t>(v42);
              TEXTRACT(v286, v273, v288, v289);
              v286.SetValidShape(v38, v272);
              // pto: %t__tmp_v428
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v290 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v428
              ;
              uint64_t v291 = (uint64_t) v33;
              TASSIGN(v290, v291);
              pipe_barrier(PIPE_V);
              TFILLPAD<pto::TFillPadMode::InPlace>(v290, v286);
              // pto: %tiny_scores_inline8554__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v292 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v62);
              // pto: %tiny_scores_inline8554__ssa_v0
              ;
              uint64_t v293 = (uint64_t) v35;
              TASSIGN(v292, v293);
              pipe_barrier(PIPE_V);
              TMAXS(v292, v290, v56);
              // pto: %t__tmp_v429
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v294 = Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v429
              ;
              uint64_t v295 = (uint64_t) v34;
              TASSIGN(v294, v295);
              // pto: %tiny_pairs_inline8610__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v296 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_inline8610__ssa_v0
              ;
              uint64_t v297 = (uint64_t) v33;
              TASSIGN(v296, v297);
              // pto: %sort32_src_view
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v298;
              TRESHAPE(v298, v292);
              // pto: %sort32_idx_view
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v299;
              TRESHAPE(v299, v294);
              // pto: %sort32_dst_view
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v300;
              TRESHAPE(v300, v296);
              pipe_barrier(PIPE_V);
              TSORT32(v300, v298, v299);
              // pto: %tiny_pairs_v1_inline8538__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v301 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_v1_inline8538__ssa_v0
              ;
              uint64_t v302 = (uint64_t) v34;
              TASSIGN(v301, v302);
              pipe_barrier(PIPE_V);
              TMRGSORT(v301, v296, v65);
              // pto: %tiny_pairs_v2_inline8557__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v303 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_v2_inline8557__ssa_v0
              ;
              uint64_t v304 = (uint64_t) v33;
              TASSIGN(v303, v304);
              pipe_barrier(PIPE_V);
              TMRGSORT(v303, v301, v66);
              // pto: %single_new_root_inline8558__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v305 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_new_root_inline8558__ssa_v0
              ;
              uint64_t v306 = (uint64_t) v36;
              TASSIGN(v305, v306);
              pipe_barrier(PIPE_V);
              uint16_t v307 = static_cast<uint16_t>(v42);
              uint16_t v308 = static_cast<uint16_t>(v42);
              TEXTRACT(v305, v303, v307, v308);
            } else {
              // pto: %157
              ;
              if (v272 <= v41) {
                // pto: %t__ci_tmp_v1
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
                // pto: %t__ci_tmp_v1
                ;
                uint64_t v310 = (uint64_t) v34;
                TASSIGN(v309, v310);
                // pto: %t__tmp_v430
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v311 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v430
                ;
                uint64_t v312 = (uint64_t) v33;
                TASSIGN(v311, v312);
                // pto: %158
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v313;
                TRESHAPE(v313, v309);
                // pto: %159
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v314;
                TRESHAPE(v314, v311);
                TCI<Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v314, v64, v313);
                // pto: %small_indices_inline8607__ssa_v0
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %small_indices_inline8607__ssa_v0
                ;
                uint64_t v316 = (uint64_t) v34;
                TASSIGN(v315, v316);
                pipe_barrier(PIPE_V);
                TADDS(v315, v311, v277);
                // pto: %small_tile_inline8560__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v317 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %small_tile_inline8560__ssa_v0
                ;
                uint64_t v318 = (uint64_t) v33;
                TASSIGN(v317, v318);
                pipe_barrier(PIPE_V);
                uint16_t v319 = static_cast<uint16_t>(v42);
                uint16_t v320 = static_cast<uint16_t>(v42);
                TEXTRACT(v317, v273, v319, v320);
                v317.SetValidShape(v38, v272);
                // pto: %t__tmp_v431
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v321 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v431
                ;
                uint64_t v322 = (uint64_t) v33;
                TASSIGN(v321, v322);
                pipe_barrier(PIPE_V);
                TFILLPAD<pto::TFillPadMode::InPlace>(v321, v317);
                // pto: %small_scores_inline8492__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v323 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_scores_inline8492__ssa_v0
                ;
                uint64_t v324 = (uint64_t) v35;
                TASSIGN(v323, v324);
                pipe_barrier(PIPE_V);
                TMAXS(v323, v321, v56);
                // pto: %t__tmp_v432
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v325 = Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v432
                ;
                uint64_t v326 = (uint64_t) v34;
                TASSIGN(v325, v326);
                // pto: %small_pairs_inline8561__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v327 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_inline8561__ssa_v0
                ;
                uint64_t v328 = (uint64_t) v33;
                TASSIGN(v327, v328);
                // pto: %160
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v329;
                TRESHAPE(v329, v323);
                // pto: %161
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v330;
                TRESHAPE(v330, v325);
                // pto: %162
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v331;
                TRESHAPE(v331, v327);
                pipe_barrier(PIPE_V);
                TSORT32(v331, v329, v330);
                // pto: %small_pairs_v1_inline8559__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v332 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_v1_inline8559__ssa_v0
                ;
                uint64_t v333 = (uint64_t) v34;
                TASSIGN(v332, v333);
                pipe_barrier(PIPE_V);
                TMRGSORT(v332, v327, v65);
                // pto: %small_pairs_v2_inline8563__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v334 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_v2_inline8563__ssa_v0
                ;
                uint64_t v335 = (uint64_t) v33;
                TASSIGN(v334, v335);
                pipe_barrier(PIPE_V);
                TMRGSORT(v334, v332, v66);
                // pto: %small_left_inline8565__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v336 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_left_inline8565__ssa_v0
                ;
                uint64_t v337 = (uint64_t) v33;
                TASSIGN(v336, v337);
                // pto: %slice_view
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v338;
                // pto: %slice_view
                ;
                uint64_t v339 = (uint64_t) v33;
                TASSIGN(v338, v339);
                // pto: %small_right_inline8640__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v340 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_right_inline8640__ssa_v0
                ;
                uint64_t v341 = (uint64_t) v37;
                TASSIGN(v340, v341);
                // pto: %163
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v342;
                // pto: %163
                ;
                uint64_t v343 = (uint64_t) v37;
                TASSIGN(v342, v343);
                // pto: %small_tmp_inline8499__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v344 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %small_tmp_inline8499__ssa_v0
                ;
                uint64_t v345 = (uint64_t) v34;
                TASSIGN(v344, v345);
                // pto: %small_merged_inline8566__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v346 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_merged_inline8566__ssa_v0
                ;
                uint64_t v347 = (uint64_t) v35;
                TASSIGN(v346, v347);
                pipe_barrier(PIPE_V);
                TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v346, v29, v344, v338, v342);
                // pto: %single_new_root_inline8558__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v348 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline8558__ssa_v1
                ;
                uint64_t v349 = (uint64_t) v36;
                TASSIGN(v348, v349);
                pipe_barrier(PIPE_V);
                uint16_t v350 = static_cast<uint16_t>(v42);
                uint16_t v351 = static_cast<uint16_t>(v42);
                TEXTRACT(v348, v346, v350, v351);
              } else {
                // pto: %t__ci_tmp_v2
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v352 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
                // pto: %t__ci_tmp_v2
                ;
                uint64_t v353 = (uint64_t) v34;
                TASSIGN(v352, v353);
                // pto: %t__tmp_v433
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v354 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v433
                ;
                uint64_t v355 = (uint64_t) v33;
                TASSIGN(v354, v355);
                // pto: %164
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v356;
                TRESHAPE(v356, v352);
                // pto: %165
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v357;
                TRESHAPE(v357, v354);
                TCI<Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v357, v64, v356);
                // pto: %large_indices_inline8555__ssa_v0
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v358 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %large_indices_inline8555__ssa_v0
                ;
                uint64_t v359 = (uint64_t) v33;
                TASSIGN(v358, v359);
                pipe_barrier(PIPE_V);
                TADDS(v358, v354, v277);
                // pto: %large_tile_inline8567__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v360 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %large_tile_inline8567__ssa_v0
                ;
                uint64_t v361 = (uint64_t) v34;
                TASSIGN(v360, v361);
                uint16_t v362 = static_cast<uint16_t>(v42);
                uint16_t v363 = static_cast<uint16_t>(v42);
                TEXTRACT(v360, v273, v362, v363);
                v360.SetValidShape(v38, v272);
                // pto: %t__tmp_v434
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v364 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v434
                ;
                uint64_t v365 = (uint64_t) v32;
                TASSIGN(v364, v365);
                pipe_barrier(PIPE_V);
                TFILLPAD(v364, v360);
                // pto: %large_scores_inline8660__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v366 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %large_scores_inline8660__ssa_v0
                ;
                uint64_t v367 = (uint64_t) v34;
                TASSIGN(v366, v367);
                pipe_barrier(PIPE_V);
                TMAXS(v366, v364, v56);
                // pto: %t__tmp_v435
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v368 = Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v435
                ;
                uint64_t v369 = (uint64_t) v33;
                TASSIGN(v368, v369);
                // pto: %large_pairs_inline8456__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v370 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_inline8456__ssa_v0
                ;
                uint64_t v371 = (uint64_t) v32;
                TASSIGN(v370, v371);
                // pto: %166
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v372;
                TRESHAPE(v372, v366);
                // pto: %167
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v373;
                TRESHAPE(v373, v368);
                // pto: %168
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v374;
                TRESHAPE(v374, v370);
                pipe_barrier(PIPE_V);
                TSORT32(v374, v372, v373);
                // pto: %large_pairs_v1_inline8570__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v375 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v1_inline8570__ssa_v0
                ;
                uint64_t v376 = (uint64_t) v33;
                TASSIGN(v375, v376);
                pipe_barrier(PIPE_V);
                TMRGSORT(v375, v370, v65);
                // pto: %large_pairs_v2_inline8571__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v377 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v2_inline8571__ssa_v0
                ;
                uint64_t v378 = (uint64_t) v32;
                TASSIGN(v377, v378);
                pipe_barrier(PIPE_V);
                TMRGSORT(v377, v375, v66);
                // pto: %large_pairs_v3_inline8572__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v379 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v3_inline8572__ssa_v0
                ;
                uint64_t v380 = (uint64_t) v33;
                TASSIGN(v379, v380);
                pipe_barrier(PIPE_V);
                TMRGSORT(v379, v377, v67);
                // pto: %single_new_root_inline8558__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v381 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline8558__ssa_v2
                ;
                uint64_t v382 = (uint64_t) v34;
                TASSIGN(v381, v382);
                pipe_barrier(PIPE_V);
                uint16_t v383 = static_cast<uint16_t>(v42);
                uint16_t v384 = static_cast<uint16_t>(v42);
                TEXTRACT(v381, v379, v383, v384);
                // pto: %single_new_root_inline8558__ssa_v2_mv
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v385 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline8558__ssa_v2_mv
                ;
                uint64_t v386 = (uint64_t) v36;
                TASSIGN(v385, v386);
                pipe_barrier(PIPE_V);
                TMOV(v385, v381);
              };
            };
            // pto: %169
            ;
            if (v189 < v58) {
              // pto: %170
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v387;
              // pto: %170
              ;
              uint64_t v388 = (uint64_t) v30;
              TASSIGN(v387, v388);
              pipe_barrier(PIPE_V);
              TMOV(v387, v98);
            } else {
              // pto: %single_old_root_inline8573__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v389 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_old_root_inline8573__ssa_v0
              ;
              uint64_t v390 = (uint64_t) v35;
              TASSIGN(v389, v390);
              pipe_barrier(PIPE_V);
              uint16_t v391 = static_cast<uint16_t>(v42);
              uint16_t v392 = static_cast<uint16_t>(v42);
              TEXTRACT(v389, v185, v391, v392);
              // pto: %single_merge_tmp_inline8519__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v393 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
              // pto: %single_merge_tmp_inline8519__ssa_v0
              ;
              uint64_t v394 = (uint64_t) v32;
              TASSIGN(v393, v394);
              // pto: %single_merged_inline8505__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v395 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
              // pto: %single_merged_inline8505__ssa_v0
              ;
              uint64_t v396 = (uint64_t) v33;
              TASSIGN(v395, v396);
              pipe_barrier(PIPE_V);
              TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, false>(v395, v29, v393, v98, v389);
              // pto: %single_next_root_inline8659__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v397 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_next_root_inline8659__ssa_v0
              ;
              uint64_t v398 = (uint64_t) v32;
              TASSIGN(v397, v398);
              pipe_barrier(PIPE_V);
              uint16_t v399 = static_cast<uint16_t>(v42);
              uint16_t v400 = static_cast<uint16_t>(v42);
              TEXTRACT(v397, v395, v399, v400);
              // pto: %172
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v401;
              // pto: %172
              ;
              uint64_t v402 = (uint64_t) v30;
              TASSIGN(v401, v402);
              pipe_barrier(PIPE_V);
              TMOV(v401, v397);
            };
          };
          // pto: %174
          ;
          int64_t v403 = (int64_t) ((uint64_t) v192 + (uint64_t) v38);
          // pto: %178
          ;
          int64_t v404 = v403 < v263 ? v403 : v263;
          // pto: %179, %176
          ;
          int64_t v405 = (v7)[(int64_t) ((uint64_t) v162 + (uint64_t) v404)];
          // pto: %180, %181
          ;
          int64_t v406 = (int64_t) ((uint64_t) v405 + (uint64_t) v54) / v55;
          // pto: %183
          ;
          int64_t v407 = v168 < v406 ? v168 : v406;
          // pto: %184
          ;
          int64_t v408 = v407 < v44 ? v407 : v44;
          // pto: %185
          ;
          int64_t v409 = v408 < v42 ? v42 : v408;
          // pto: %186
          ;
          int64_t v410 = (int64_t) ((uint64_t) v409 - (uint64_t) v259);
          // pto: %187
          ;
          int64_t v411 = v410 < v260 ? v410 : v260;
          // pto: %188
          ;
          int64_t v412 = v411 < v42 ? v42 : v411;
          // pto: %189, %175, %190
          ;
          if (v412 > v42 & v403 < v164) {
            // pto: %single_segment_data_inline8457__ssa_v1
            ;
            Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v413 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
            // pto: %single_segment_data_inline8457__ssa_v1
            ;
            uint64_t v414 = (uint64_t) v32;
            TASSIGN(v413, v414);
            pipe_barrier(PIPE_V);
            uint16_t v415 = static_cast<uint16_t>(v38);
            uint16_t v416 = static_cast<uint16_t>(v42);
            TEXTRACT(v413, v261, v415, v416);
            // pto: %191
            ;
            int32_t v417 = (int32_t) v259;
            // pto: %192
            ;
            if (v412 <= v62) {
              // pto: %t__ci_tmp_v3
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v418 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
              // pto: %t__ci_tmp_v3
              ;
              uint64_t v419 = (uint64_t) v34;
              TASSIGN(v418, v419);
              // pto: %t__tmp_v436
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v420 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v436
              ;
              uint64_t v421 = (uint64_t) v33;
              TASSIGN(v420, v421);
              // pto: %193
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v422;
              TRESHAPE(v422, v418);
              // pto: %194
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v423;
              TRESHAPE(v423, v420);
              TCI<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v423, v64, v422);
              // pto: %tiny_indices_inline8552__ssa_v1
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v424 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %tiny_indices_inline8552__ssa_v1
              ;
              uint64_t v425 = (uint64_t) v34;
              TASSIGN(v424, v425);
              pipe_barrier(PIPE_V);
              TADDS(v424, v420, v417);
              // pto: %tiny_tile_inline8508__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v426 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %tiny_tile_inline8508__ssa_v1
              ;
              uint64_t v427 = (uint64_t) v33;
              TASSIGN(v426, v427);
              pipe_barrier(PIPE_V);
              uint16_t v428 = static_cast<uint16_t>(v42);
              uint16_t v429 = static_cast<uint16_t>(v42);
              TEXTRACT(v426, v413, v428, v429);
              v426.SetValidShape(v38, v412);
              // pto: %t__tmp_v437
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v430 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v437
              ;
              uint64_t v431 = (uint64_t) v33;
              TASSIGN(v430, v431);
              pipe_barrier(PIPE_V);
              TFILLPAD<pto::TFillPadMode::InPlace>(v430, v426);
              // pto: %tiny_scores_inline8554__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v432 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v62);
              // pto: %tiny_scores_inline8554__ssa_v1
              ;
              uint64_t v433 = (uint64_t) v35;
              TASSIGN(v432, v433);
              pipe_barrier(PIPE_V);
              TMAXS(v432, v430, v56);
              // pto: %t__tmp_v438
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v434 = Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v438
              ;
              uint64_t v435 = (uint64_t) v34;
              TASSIGN(v434, v435);
              // pto: %tiny_pairs_inline8610__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v436 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_inline8610__ssa_v1
              ;
              uint64_t v437 = (uint64_t) v33;
              TASSIGN(v436, v437);
              // pto: %195
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v438;
              TRESHAPE(v438, v432);
              // pto: %196
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v439;
              TRESHAPE(v439, v434);
              // pto: %197
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v440;
              TRESHAPE(v440, v436);
              pipe_barrier(PIPE_V);
              TSORT32(v440, v438, v439);
              // pto: %tiny_pairs_v1_inline8538__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v441 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_v1_inline8538__ssa_v1
              ;
              uint64_t v442 = (uint64_t) v34;
              TASSIGN(v441, v442);
              pipe_barrier(PIPE_V);
              TMRGSORT(v441, v436, v65);
              // pto: %tiny_pairs_v2_inline8557__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v443 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_v2_inline8557__ssa_v1
              ;
              uint64_t v444 = (uint64_t) v33;
              TASSIGN(v443, v444);
              pipe_barrier(PIPE_V);
              TMRGSORT(v443, v441, v66);
              // pto: %single_new_root_inline8558__ssa_v5
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v445 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_new_root_inline8558__ssa_v5
              ;
              uint64_t v446 = (uint64_t) v36;
              TASSIGN(v445, v446);
              pipe_barrier(PIPE_V);
              uint16_t v447 = static_cast<uint16_t>(v42);
              uint16_t v448 = static_cast<uint16_t>(v42);
              TEXTRACT(v445, v443, v447, v448);
            } else {
              // pto: %198
              ;
              if (v412 <= v41) {
                // pto: %t__ci_tmp_v4
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v449 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
                // pto: %t__ci_tmp_v4
                ;
                uint64_t v450 = (uint64_t) v34;
                TASSIGN(v449, v450);
                // pto: %t__tmp_v439
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v451 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v439
                ;
                uint64_t v452 = (uint64_t) v33;
                TASSIGN(v451, v452);
                // pto: %199
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v453;
                TRESHAPE(v453, v449);
                // pto: %200
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v454;
                TRESHAPE(v454, v451);
                TCI<Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v454, v64, v453);
                // pto: %small_indices_inline8607__ssa_v1
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v455 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %small_indices_inline8607__ssa_v1
                ;
                uint64_t v456 = (uint64_t) v34;
                TASSIGN(v455, v456);
                pipe_barrier(PIPE_V);
                TADDS(v455, v451, v417);
                // pto: %small_tile_inline8560__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v457 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %small_tile_inline8560__ssa_v1
                ;
                uint64_t v458 = (uint64_t) v33;
                TASSIGN(v457, v458);
                pipe_barrier(PIPE_V);
                uint16_t v459 = static_cast<uint16_t>(v42);
                uint16_t v460 = static_cast<uint16_t>(v42);
                TEXTRACT(v457, v413, v459, v460);
                v457.SetValidShape(v38, v412);
                // pto: %t__tmp_v440
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v461 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v440
                ;
                uint64_t v462 = (uint64_t) v33;
                TASSIGN(v461, v462);
                pipe_barrier(PIPE_V);
                TFILLPAD<pto::TFillPadMode::InPlace>(v461, v457);
                // pto: %small_scores_inline8492__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v463 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_scores_inline8492__ssa_v1
                ;
                uint64_t v464 = (uint64_t) v35;
                TASSIGN(v463, v464);
                pipe_barrier(PIPE_V);
                TMAXS(v463, v461, v56);
                // pto: %t__tmp_v441
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v465 = Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v441
                ;
                uint64_t v466 = (uint64_t) v34;
                TASSIGN(v465, v466);
                // pto: %small_pairs_inline8561__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v467 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_inline8561__ssa_v1
                ;
                uint64_t v468 = (uint64_t) v33;
                TASSIGN(v467, v468);
                // pto: %201
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v469;
                TRESHAPE(v469, v463);
                // pto: %202
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v470;
                TRESHAPE(v470, v465);
                // pto: %203
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v471;
                TRESHAPE(v471, v467);
                pipe_barrier(PIPE_V);
                TSORT32(v471, v469, v470);
                // pto: %small_pairs_v1_inline8559__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v472 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_v1_inline8559__ssa_v1
                ;
                uint64_t v473 = (uint64_t) v34;
                TASSIGN(v472, v473);
                pipe_barrier(PIPE_V);
                TMRGSORT(v472, v467, v65);
                // pto: %small_pairs_v2_inline8563__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v474 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_v2_inline8563__ssa_v1
                ;
                uint64_t v475 = (uint64_t) v33;
                TASSIGN(v474, v475);
                pipe_barrier(PIPE_V);
                TMRGSORT(v474, v472, v66);
                // pto: %small_left_inline8565__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v476 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_left_inline8565__ssa_v1
                ;
                uint64_t v477 = (uint64_t) v33;
                TASSIGN(v476, v477);
                // pto: %204
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v478;
                // pto: %204
                ;
                uint64_t v479 = (uint64_t) v33;
                TASSIGN(v478, v479);
                // pto: %small_right_inline8640__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v480 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_right_inline8640__ssa_v1
                ;
                uint64_t v481 = (uint64_t) v37;
                TASSIGN(v480, v481);
                // pto: %205
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v482;
                // pto: %205
                ;
                uint64_t v483 = (uint64_t) v37;
                TASSIGN(v482, v483);
                // pto: %small_tmp_inline8499__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v484 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %small_tmp_inline8499__ssa_v1
                ;
                uint64_t v485 = (uint64_t) v34;
                TASSIGN(v484, v485);
                // pto: %small_merged_inline8566__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v486 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_merged_inline8566__ssa_v1
                ;
                uint64_t v487 = (uint64_t) v35;
                TASSIGN(v486, v487);
                pipe_barrier(PIPE_V);
                TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v486, v29, v484, v478, v482);
                // pto: %single_new_root_inline8558__ssa_v6
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v488 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline8558__ssa_v6
                ;
                uint64_t v489 = (uint64_t) v36;
                TASSIGN(v488, v489);
                pipe_barrier(PIPE_V);
                uint16_t v490 = static_cast<uint16_t>(v42);
                uint16_t v491 = static_cast<uint16_t>(v42);
                TEXTRACT(v488, v486, v490, v491);
              } else {
                // pto: %t__ci_tmp_v5
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v492 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
                // pto: %t__ci_tmp_v5
                ;
                uint64_t v493 = (uint64_t) v34;
                TASSIGN(v492, v493);
                // pto: %t__tmp_v442
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v494 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v442
                ;
                uint64_t v495 = (uint64_t) v33;
                TASSIGN(v494, v495);
                // pto: %207
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v496;
                TRESHAPE(v496, v492);
                // pto: %208
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v497;
                TRESHAPE(v497, v494);
                TCI<Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v497, v64, v496);
                // pto: %large_indices_inline8555__ssa_v1
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v498 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %large_indices_inline8555__ssa_v1
                ;
                uint64_t v499 = (uint64_t) v33;
                TASSIGN(v498, v499);
                pipe_barrier(PIPE_V);
                TADDS(v498, v494, v417);
                // pto: %large_tile_inline8567__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v500 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %large_tile_inline8567__ssa_v1
                ;
                uint64_t v501 = (uint64_t) v34;
                TASSIGN(v500, v501);
                uint16_t v502 = static_cast<uint16_t>(v42);
                uint16_t v503 = static_cast<uint16_t>(v42);
                TEXTRACT(v500, v413, v502, v503);
                v500.SetValidShape(v38, v412);
                // pto: %t__tmp_v443
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v504 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v443
                ;
                uint64_t v505 = (uint64_t) v32;
                TASSIGN(v504, v505);
                pipe_barrier(PIPE_V);
                TFILLPAD(v504, v500);
                // pto: %large_scores_inline8660__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v506 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %large_scores_inline8660__ssa_v1
                ;
                uint64_t v507 = (uint64_t) v34;
                TASSIGN(v506, v507);
                pipe_barrier(PIPE_V);
                TMAXS(v506, v504, v56);
                // pto: %t__tmp_v444
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v508 = Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v444
                ;
                uint64_t v509 = (uint64_t) v33;
                TASSIGN(v508, v509);
                // pto: %large_pairs_inline8456__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v510 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_inline8456__ssa_v1
                ;
                uint64_t v511 = (uint64_t) v32;
                TASSIGN(v510, v511);
                // pto: %209
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v512;
                TRESHAPE(v512, v506);
                // pto: %210
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v513;
                TRESHAPE(v513, v508);
                // pto: %211
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v514;
                TRESHAPE(v514, v510);
                pipe_barrier(PIPE_V);
                TSORT32(v514, v512, v513);
                // pto: %large_pairs_v1_inline8570__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v515 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v1_inline8570__ssa_v1
                ;
                uint64_t v516 = (uint64_t) v33;
                TASSIGN(v515, v516);
                pipe_barrier(PIPE_V);
                TMRGSORT(v515, v510, v65);
                // pto: %large_pairs_v2_inline8571__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v517 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v2_inline8571__ssa_v1
                ;
                uint64_t v518 = (uint64_t) v32;
                TASSIGN(v517, v518);
                pipe_barrier(PIPE_V);
                TMRGSORT(v517, v515, v66);
                // pto: %large_pairs_v3_inline8572__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v519 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v3_inline8572__ssa_v1
                ;
                uint64_t v520 = (uint64_t) v33;
                TASSIGN(v519, v520);
                pipe_barrier(PIPE_V);
                TMRGSORT(v519, v517, v67);
                // pto: %single_new_root_inline8558__ssa_v7
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v521 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline8558__ssa_v7
                ;
                uint64_t v522 = (uint64_t) v34;
                TASSIGN(v521, v522);
                pipe_barrier(PIPE_V);
                uint16_t v523 = static_cast<uint16_t>(v42);
                uint16_t v524 = static_cast<uint16_t>(v42);
                TEXTRACT(v521, v519, v523, v524);
                // pto: %single_new_root_inline8558__ssa_v7_mv
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v525 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline8558__ssa_v7_mv
                ;
                uint64_t v526 = (uint64_t) v36;
                TASSIGN(v525, v526);
                pipe_barrier(PIPE_V);
                TMOV(v525, v521);
              };
            };
            // pto: %212
            ;
            if (v189 < v58) {
              // pto: %213
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v527;
              // pto: %213
              ;
              uint64_t v528 = (uint64_t) v28;
              TASSIGN(v527, v528);
              pipe_barrier(PIPE_V);
              TMOV(v527, v106);
            } else {
              // pto: %single_old_root_inline8573__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v529 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_old_root_inline8573__ssa_v1
              ;
              uint64_t v530 = (uint64_t) v35;
              TASSIGN(v529, v530);
              pipe_barrier(PIPE_V);
              uint16_t v531 = static_cast<uint16_t>(v38);
              uint16_t v532 = static_cast<uint16_t>(v42);
              TEXTRACT(v529, v96, v531, v532);
              // pto: %single_merge_tmp_inline8519__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v533 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
              // pto: %single_merge_tmp_inline8519__ssa_v1
              ;
              uint64_t v534 = (uint64_t) v32;
              TASSIGN(v533, v534);
              // pto: %single_merged_inline8505__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v535 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
              // pto: %single_merged_inline8505__ssa_v1
              ;
              uint64_t v536 = (uint64_t) v33;
              TASSIGN(v535, v536);
              pipe_barrier(PIPE_V);
              TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, false>(v535, v29, v533, v106, v529);
              // pto: %single_next_root_inline8659__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v537 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_next_root_inline8659__ssa_v1
              ;
              uint64_t v538 = (uint64_t) v32;
              TASSIGN(v537, v538);
              pipe_barrier(PIPE_V);
              uint16_t v539 = static_cast<uint16_t>(v42);
              uint16_t v540 = static_cast<uint16_t>(v42);
              TEXTRACT(v537, v535, v539, v540);
              // pto: %215
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v541;
              // pto: %215
              ;
              uint64_t v542 = (uint64_t) v28;
              TASSIGN(v541, v542);
              pipe_barrier(PIPE_V);
              TMOV(v541, v537);
            };
          };
          // pto: %217
          ;
          int64_t v543 = (int64_t) ((uint64_t) v192 + (uint64_t) v58);
          // pto: %221
          ;
          int64_t v544 = v543 < v263 ? v543 : v263;
          // pto: %222, %219
          ;
          int64_t v545 = (v7)[(int64_t) ((uint64_t) v162 + (uint64_t) v544)];
          // pto: %223, %224
          ;
          int64_t v546 = (int64_t) ((uint64_t) v545 + (uint64_t) v54) / v55;
          // pto: %226
          ;
          int64_t v547 = v168 < v546 ? v168 : v546;
          // pto: %227
          ;
          int64_t v548 = v547 < v44 ? v547 : v44;
          // pto: %228
          ;
          int64_t v549 = v548 < v42 ? v42 : v548;
          // pto: %229
          ;
          int64_t v550 = (int64_t) ((uint64_t) v549 - (uint64_t) v259);
          // pto: %230
          ;
          int64_t v551 = v550 < v260 ? v550 : v260;
          // pto: %231
          ;
          int64_t v552 = v551 < v42 ? v42 : v551;
          // pto: %232, %218, %233
          ;
          if (v552 > v42 & v543 < v164) {
            // pto: %single_segment_data_inline8457__ssa_v2
            ;
            Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v553 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
            // pto: %single_segment_data_inline8457__ssa_v2
            ;
            uint64_t v554 = (uint64_t) v32;
            TASSIGN(v553, v554);
            pipe_barrier(PIPE_V);
            uint16_t v555 = static_cast<uint16_t>(v58);
            uint16_t v556 = static_cast<uint16_t>(v42);
            TEXTRACT(v553, v261, v555, v556);
            // pto: %234
            ;
            int32_t v557 = (int32_t) v259;
            // pto: %235
            ;
            if (v552 <= v62) {
              // pto: %t__ci_tmp_v6
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v558 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
              // pto: %t__ci_tmp_v6
              ;
              uint64_t v559 = (uint64_t) v34;
              TASSIGN(v558, v559);
              // pto: %t__tmp_v445
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v560 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v445
              ;
              uint64_t v561 = (uint64_t) v33;
              TASSIGN(v560, v561);
              // pto: %236
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v562;
              TRESHAPE(v562, v558);
              // pto: %237
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v563;
              TRESHAPE(v563, v560);
              TCI<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v563, v64, v562);
              // pto: %tiny_indices_inline8552__ssa_v2
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v564 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %tiny_indices_inline8552__ssa_v2
              ;
              uint64_t v565 = (uint64_t) v34;
              TASSIGN(v564, v565);
              pipe_barrier(PIPE_V);
              TADDS(v564, v560, v557);
              // pto: %tiny_tile_inline8508__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v566 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %tiny_tile_inline8508__ssa_v2
              ;
              uint64_t v567 = (uint64_t) v33;
              TASSIGN(v566, v567);
              pipe_barrier(PIPE_V);
              uint16_t v568 = static_cast<uint16_t>(v42);
              uint16_t v569 = static_cast<uint16_t>(v42);
              TEXTRACT(v566, v553, v568, v569);
              v566.SetValidShape(v38, v552);
              // pto: %t__tmp_v446
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v570 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v446
              ;
              uint64_t v571 = (uint64_t) v33;
              TASSIGN(v570, v571);
              pipe_barrier(PIPE_V);
              TFILLPAD<pto::TFillPadMode::InPlace>(v570, v566);
              // pto: %tiny_scores_inline8554__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v572 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v62);
              // pto: %tiny_scores_inline8554__ssa_v2
              ;
              uint64_t v573 = (uint64_t) v35;
              TASSIGN(v572, v573);
              pipe_barrier(PIPE_V);
              TMAXS(v572, v570, v56);
              // pto: %t__tmp_v447
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v574 = Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v447
              ;
              uint64_t v575 = (uint64_t) v34;
              TASSIGN(v574, v575);
              // pto: %tiny_pairs_inline8610__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v576 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_inline8610__ssa_v2
              ;
              uint64_t v577 = (uint64_t) v33;
              TASSIGN(v576, v577);
              // pto: %238
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v578;
              TRESHAPE(v578, v572);
              // pto: %239
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v579;
              TRESHAPE(v579, v574);
              // pto: %240
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v580;
              TRESHAPE(v580, v576);
              pipe_barrier(PIPE_V);
              TSORT32(v580, v578, v579);
              // pto: %tiny_pairs_v1_inline8538__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v581 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_v1_inline8538__ssa_v2
              ;
              uint64_t v582 = (uint64_t) v34;
              TASSIGN(v581, v582);
              pipe_barrier(PIPE_V);
              TMRGSORT(v581, v576, v65);
              // pto: %tiny_pairs_v2_inline8557__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v583 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_v2_inline8557__ssa_v2
              ;
              uint64_t v584 = (uint64_t) v33;
              TASSIGN(v583, v584);
              pipe_barrier(PIPE_V);
              TMRGSORT(v583, v581, v66);
              // pto: %single_new_root_inline8558__ssa_v10
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v585 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_new_root_inline8558__ssa_v10
              ;
              uint64_t v586 = (uint64_t) v36;
              TASSIGN(v585, v586);
              pipe_barrier(PIPE_V);
              uint16_t v587 = static_cast<uint16_t>(v42);
              uint16_t v588 = static_cast<uint16_t>(v42);
              TEXTRACT(v585, v583, v587, v588);
            } else {
              // pto: %241
              ;
              if (v552 <= v41) {
                // pto: %t__ci_tmp_v7
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v589 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
                // pto: %t__ci_tmp_v7
                ;
                uint64_t v590 = (uint64_t) v34;
                TASSIGN(v589, v590);
                // pto: %t__tmp_v448
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v591 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v448
                ;
                uint64_t v592 = (uint64_t) v33;
                TASSIGN(v591, v592);
                // pto: %242
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v593;
                TRESHAPE(v593, v589);
                // pto: %243
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v594;
                TRESHAPE(v594, v591);
                TCI<Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v594, v64, v593);
                // pto: %small_indices_inline8607__ssa_v2
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v595 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %small_indices_inline8607__ssa_v2
                ;
                uint64_t v596 = (uint64_t) v34;
                TASSIGN(v595, v596);
                pipe_barrier(PIPE_V);
                TADDS(v595, v591, v557);
                // pto: %small_tile_inline8560__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v597 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %small_tile_inline8560__ssa_v2
                ;
                uint64_t v598 = (uint64_t) v33;
                TASSIGN(v597, v598);
                pipe_barrier(PIPE_V);
                uint16_t v599 = static_cast<uint16_t>(v42);
                uint16_t v600 = static_cast<uint16_t>(v42);
                TEXTRACT(v597, v553, v599, v600);
                v597.SetValidShape(v38, v552);
                // pto: %t__tmp_v449
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v601 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v449
                ;
                uint64_t v602 = (uint64_t) v33;
                TASSIGN(v601, v602);
                pipe_barrier(PIPE_V);
                TFILLPAD<pto::TFillPadMode::InPlace>(v601, v597);
                // pto: %small_scores_inline8492__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v603 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_scores_inline8492__ssa_v2
                ;
                uint64_t v604 = (uint64_t) v35;
                TASSIGN(v603, v604);
                pipe_barrier(PIPE_V);
                TMAXS(v603, v601, v56);
                // pto: %t__tmp_v450
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v605 = Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v450
                ;
                uint64_t v606 = (uint64_t) v34;
                TASSIGN(v605, v606);
                // pto: %small_pairs_inline8561__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v607 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_inline8561__ssa_v2
                ;
                uint64_t v608 = (uint64_t) v33;
                TASSIGN(v607, v608);
                // pto: %244
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v609;
                TRESHAPE(v609, v603);
                // pto: %245
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v610;
                TRESHAPE(v610, v605);
                // pto: %246
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v611;
                TRESHAPE(v611, v607);
                pipe_barrier(PIPE_V);
                TSORT32(v611, v609, v610);
                // pto: %small_pairs_v1_inline8559__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v612 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_v1_inline8559__ssa_v2
                ;
                uint64_t v613 = (uint64_t) v34;
                TASSIGN(v612, v613);
                pipe_barrier(PIPE_V);
                TMRGSORT(v612, v607, v65);
                // pto: %small_pairs_v2_inline8563__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v614 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_v2_inline8563__ssa_v2
                ;
                uint64_t v615 = (uint64_t) v33;
                TASSIGN(v614, v615);
                pipe_barrier(PIPE_V);
                TMRGSORT(v614, v612, v66);
                // pto: %small_left_inline8565__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v616 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_left_inline8565__ssa_v2
                ;
                uint64_t v617 = (uint64_t) v33;
                TASSIGN(v616, v617);
                // pto: %247
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v618;
                // pto: %247
                ;
                uint64_t v619 = (uint64_t) v33;
                TASSIGN(v618, v619);
                // pto: %small_right_inline8640__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v620 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_right_inline8640__ssa_v2
                ;
                uint64_t v621 = (uint64_t) v37;
                TASSIGN(v620, v621);
                // pto: %248
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v622;
                // pto: %248
                ;
                uint64_t v623 = (uint64_t) v37;
                TASSIGN(v622, v623);
                // pto: %small_tmp_inline8499__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v624 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %small_tmp_inline8499__ssa_v2
                ;
                uint64_t v625 = (uint64_t) v34;
                TASSIGN(v624, v625);
                // pto: %small_merged_inline8566__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v626 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_merged_inline8566__ssa_v2
                ;
                uint64_t v627 = (uint64_t) v35;
                TASSIGN(v626, v627);
                pipe_barrier(PIPE_V);
                TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v626, v29, v624, v618, v622);
                // pto: %single_new_root_inline8558__ssa_v11
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v628 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline8558__ssa_v11
                ;
                uint64_t v629 = (uint64_t) v36;
                TASSIGN(v628, v629);
                pipe_barrier(PIPE_V);
                uint16_t v630 = static_cast<uint16_t>(v42);
                uint16_t v631 = static_cast<uint16_t>(v42);
                TEXTRACT(v628, v626, v630, v631);
              } else {
                // pto: %t__ci_tmp_v8
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v632 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
                // pto: %t__ci_tmp_v8
                ;
                uint64_t v633 = (uint64_t) v34;
                TASSIGN(v632, v633);
                // pto: %t__tmp_v451
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v634 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v451
                ;
                uint64_t v635 = (uint64_t) v33;
                TASSIGN(v634, v635);
                // pto: %250
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v636;
                TRESHAPE(v636, v632);
                // pto: %251
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v637;
                TRESHAPE(v637, v634);
                TCI<Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v637, v64, v636);
                // pto: %large_indices_inline8555__ssa_v2
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v638 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %large_indices_inline8555__ssa_v2
                ;
                uint64_t v639 = (uint64_t) v33;
                TASSIGN(v638, v639);
                pipe_barrier(PIPE_V);
                TADDS(v638, v634, v557);
                // pto: %large_tile_inline8567__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v640 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %large_tile_inline8567__ssa_v2
                ;
                uint64_t v641 = (uint64_t) v34;
                TASSIGN(v640, v641);
                uint16_t v642 = static_cast<uint16_t>(v42);
                uint16_t v643 = static_cast<uint16_t>(v42);
                TEXTRACT(v640, v553, v642, v643);
                v640.SetValidShape(v38, v552);
                // pto: %t__tmp_v452
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v644 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v452
                ;
                uint64_t v645 = (uint64_t) v32;
                TASSIGN(v644, v645);
                pipe_barrier(PIPE_V);
                TFILLPAD(v644, v640);
                // pto: %large_scores_inline8660__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v646 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %large_scores_inline8660__ssa_v2
                ;
                uint64_t v647 = (uint64_t) v34;
                TASSIGN(v646, v647);
                pipe_barrier(PIPE_V);
                TMAXS(v646, v644, v56);
                // pto: %t__tmp_v453
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v648 = Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v453
                ;
                uint64_t v649 = (uint64_t) v33;
                TASSIGN(v648, v649);
                // pto: %large_pairs_inline8456__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v650 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_inline8456__ssa_v2
                ;
                uint64_t v651 = (uint64_t) v32;
                TASSIGN(v650, v651);
                // pto: %252
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v652;
                TRESHAPE(v652, v646);
                // pto: %253
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v653;
                TRESHAPE(v653, v648);
                // pto: %254
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v654;
                TRESHAPE(v654, v650);
                pipe_barrier(PIPE_V);
                TSORT32(v654, v652, v653);
                // pto: %large_pairs_v1_inline8570__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v655 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v1_inline8570__ssa_v2
                ;
                uint64_t v656 = (uint64_t) v33;
                TASSIGN(v655, v656);
                pipe_barrier(PIPE_V);
                TMRGSORT(v655, v650, v65);
                // pto: %large_pairs_v2_inline8571__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v657 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v2_inline8571__ssa_v2
                ;
                uint64_t v658 = (uint64_t) v32;
                TASSIGN(v657, v658);
                pipe_barrier(PIPE_V);
                TMRGSORT(v657, v655, v66);
                // pto: %large_pairs_v3_inline8572__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v659 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v3_inline8572__ssa_v2
                ;
                uint64_t v660 = (uint64_t) v33;
                TASSIGN(v659, v660);
                pipe_barrier(PIPE_V);
                TMRGSORT(v659, v657, v67);
                // pto: %single_new_root_inline8558__ssa_v12
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v661 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline8558__ssa_v12
                ;
                uint64_t v662 = (uint64_t) v34;
                TASSIGN(v661, v662);
                pipe_barrier(PIPE_V);
                uint16_t v663 = static_cast<uint16_t>(v42);
                uint16_t v664 = static_cast<uint16_t>(v42);
                TEXTRACT(v661, v659, v663, v664);
                // pto: %single_new_root_inline8558__ssa_v12_mv
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v665 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline8558__ssa_v12_mv
                ;
                uint64_t v666 = (uint64_t) v36;
                TASSIGN(v665, v666);
                pipe_barrier(PIPE_V);
                TMOV(v665, v661);
              };
            };
            // pto: %255
            ;
            if (v189 < v58) {
              // pto: %256
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v667;
              // pto: %256
              ;
              uint64_t v668 = (uint64_t) v27;
              TASSIGN(v667, v668);
              pipe_barrier(PIPE_V);
              TMOV(v667, v114);
            } else {
              // pto: %single_old_root_inline8573__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v669 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_old_root_inline8573__ssa_v2
              ;
              uint64_t v670 = (uint64_t) v35;
              TASSIGN(v669, v670);
              pipe_barrier(PIPE_V);
              uint16_t v671 = static_cast<uint16_t>(v58);
              uint16_t v672 = static_cast<uint16_t>(v42);
              TEXTRACT(v669, v104, v671, v672);
              // pto: %single_merge_tmp_inline8519__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v673 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
              // pto: %single_merge_tmp_inline8519__ssa_v2
              ;
              uint64_t v674 = (uint64_t) v32;
              TASSIGN(v673, v674);
              // pto: %single_merged_inline8505__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v675 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
              // pto: %single_merged_inline8505__ssa_v2
              ;
              uint64_t v676 = (uint64_t) v33;
              TASSIGN(v675, v676);
              pipe_barrier(PIPE_V);
              TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, false>(v675, v29, v673, v114, v669);
              // pto: %single_next_root_inline8659__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v677 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_next_root_inline8659__ssa_v2
              ;
              uint64_t v678 = (uint64_t) v32;
              TASSIGN(v677, v678);
              pipe_barrier(PIPE_V);
              uint16_t v679 = static_cast<uint16_t>(v42);
              uint16_t v680 = static_cast<uint16_t>(v42);
              TEXTRACT(v677, v675, v679, v680);
              // pto: %258
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v681;
              // pto: %258
              ;
              uint64_t v682 = (uint64_t) v27;
              TASSIGN(v681, v682);
              pipe_barrier(PIPE_V);
              TMOV(v681, v677);
            };
          };
        };
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      };
      // pto: %259
      ;
      int64_t v683 = (int64_t) ((uint64_t) v151 * (uint64_t) v48);
      // pto: %260
      ;
      if (v683 < v164) {
        // pto: %single_root_inline8649__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v684 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_root_inline8649__ssa_v0
        ;
        uint64_t v685 = (uint64_t) v31;
        TASSIGN(v684, v685);
        pipe_barrier(PIPE_V);
        uint16_t v686 = static_cast<uint16_t>(v42);
        uint16_t v687 = static_cast<uint16_t>(v42);
        TEXTRACT(v684, v185, v686, v687);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %263
        ;
        uint64_t v688 = (uint64_t) v155;
        // pto: %261, %262, %263
        ;
        int64_t v689 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v162 + (uint64_t) v683) * (uint64_t) v60) + v688);
        // pto: %264
        ;
        int64_t v690 = v689 < v42 ? v42 : v689;
        // pto: %pair_arena_inline1403_inline5107__ssa_v0_pview
        ;
        __gm__ float* v691 = PTOAS__GLOBAL_TENSOR_DATA(v93);
        // pto: %pair_arena_inline1403_inline5107__ssa_v0_pview
        ;
        const int64_t v692 = 0;
        // pto: %pair_arena_inline1403_inline5107__ssa_v0_pview
        ;
        const int64_t v693 = 1024;
        // pto: %pair_arena_inline1403_inline5107__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 1024> v694 = pto::Shape<1, 1, 1, 1, 1024>();
        // pto: %pair_arena_inline1403_inline5107__ssa_v0_pview
        ;
        pto::Stride<1024, 1024, 1024, 1024, 1> v695 = pto::Stride<1024, 1024, 1024, 1024, 1>();
        // pto: %pair_arena_inline1403_inline5107__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v696 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v691 + (v692 + v690 * v693), v694, v695);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v696, v684);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      // pto: %266
      ;
      int64_t v697 = (int64_t) ((uint64_t) v683 + (uint64_t) v38);
      // pto: %267
      ;
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      if (v697 < v164) {
        // pto: %single_root_inline8649__ssa_v1
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v698 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_root_inline8649__ssa_v1
        ;
        uint64_t v699 = (uint64_t) v31;
        TASSIGN(v698, v699);
        pipe_barrier(PIPE_V);
        uint16_t v700 = static_cast<uint16_t>(v38);
        uint16_t v701 = static_cast<uint16_t>(v42);
        TEXTRACT(v698, v185, v700, v701);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        // pto: %270
        ;
        uint64_t v702 = (uint64_t) v155;
        // pto: %268, %269, %270
        ;
        int64_t v703 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v162 + (uint64_t) v697) * (uint64_t) v60) + v702);
        // pto: %271
        ;
        int64_t v704 = v703 < v42 ? v42 : v703;
        // pto: %272
        ;
        __gm__ float* v705 = PTOAS__GLOBAL_TENSOR_DATA(v93);
        // pto: %272
        ;
        const int64_t v706 = 0;
        // pto: %272
        ;
        const int64_t v707 = 1024;
        // pto: %272
        ;
        pto::Shape<1, 1, 1, 1, 1024> v708 = pto::Shape<1, 1, 1, 1, 1024>();
        // pto: %272
        ;
        pto::Stride<1024, 1024, 1024, 1024, 1> v709 = pto::Stride<1024, 1024, 1024, 1024, 1>();
        // pto: %272
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v710 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v705 + (v706 + v704 * v707), v708, v709);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v710, v698);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      // pto: %274
      ;
      int64_t v711 = (int64_t) ((uint64_t) v683 + (uint64_t) v58);
      // pto: %275
      ;
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      if (v711 < v164) {
        // pto: %single_root_inline8649__ssa_v2
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v712 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_root_inline8649__ssa_v2
        ;
        uint64_t v713 = (uint64_t) v31;
        TASSIGN(v712, v713);
        pipe_barrier(PIPE_V);
        uint16_t v714 = static_cast<uint16_t>(v58);
        uint16_t v715 = static_cast<uint16_t>(v42);
        TEXTRACT(v712, v185, v714, v715);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        // pto: %278
        ;
        uint64_t v716 = (uint64_t) v155;
        // pto: %276, %277, %278
        ;
        int64_t v717 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v162 + (uint64_t) v711) * (uint64_t) v60) + v716);
        // pto: %279
        ;
        int64_t v718 = v717 < v42 ? v42 : v717;
        // pto: %280
        ;
        __gm__ float* v719 = PTOAS__GLOBAL_TENSOR_DATA(v93);
        // pto: %280
        ;
        const int64_t v720 = 0;
        // pto: %280
        ;
        const int64_t v721 = 1024;
        // pto: %280
        ;
        pto::Shape<1, 1, 1, 1, 1024> v722 = pto::Shape<1, 1, 1, 1, 1024>();
        // pto: %280
        ;
        pto::Stride<1024, 1024, 1024, 1024, 1> v723 = pto::Stride<1024, 1024, 1024, 1024, 1>();
        // pto: %280
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v724 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v719 + (v720 + v718 * v721), v722, v723);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        TSTORE(v724, v712);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    };
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}