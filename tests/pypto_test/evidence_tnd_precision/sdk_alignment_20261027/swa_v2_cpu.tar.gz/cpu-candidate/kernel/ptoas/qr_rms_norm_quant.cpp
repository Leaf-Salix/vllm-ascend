#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qr_rms_norm_quant(__gm__ int8_t* v1, __gm__ float* v2, __gm__ float* v3, __gm__ int8_t* v4, __gm__ float* v5, __gm__ bfloat16_t* v6, int64_t v7, int64_t v8, int64_t v9, int64_t v10, int64_t v11, int64_t v12, int32_t v13, int32_t v14) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c17504_i64
  const int64_t v15 = 17504;
  // pto: %c50272_i64
  const int64_t v16 = 50272;
  const int64_t v17 = 19552;
  const int64_t v18 = 18528;
  const int64_t v19 = 18016;
  const int64_t v20 = 17760;
  // pto: %c1088_i64
  const int64_t v21 = 1088;
  // pto: %c0_i64
  const int64_t v22 = 0;
  // pto: %c32_i64
  const int64_t v23 = 32;
  // pto: %c64_i64
  const int64_t v24 = 64;
  // pto: %c576_i64
  const int64_t v25 = 576;
  // pto: %c9280_i64
  const int64_t v26 = 9280;
  // pto: %c17472_i64
  const int64_t v27 = 17472;
  // pto: %c512_index
  const int64_t v28 = 512;
  // pto: %c1024_index
  const int64_t v29 = 1024;
  // pto: %c1_index
  const int64_t v30 = 1;
  // pto: %c8_index
  const int64_t v31 = 8;
  // pto: %c0_index
  const int64_t v32 = 0;
  // pto: %c256_index
  const int64_t v33 = 256;
  // pto: %c128_index
  const int64_t v34 = 128;
  // pto: %c64_index
  const int64_t v35 = 64;
  // pto: %cst_21
  const float v36 = 9.765625E-4f;
  // pto: %cst_22
  const float v37 = 9.99999997E-7f;
  // pto: %c0_i32
  const int32_t v38 = 0;
  // pto: %c8388608_index
  const int64_t v39 = 8388608;
  // pto: %c2139095040_i64
  const int64_t v40 = 2139095040;
  // pto: %c8388608_i64
  const int64_t v41 = 8388608;
  // pto: %c2_index
  const int64_t v42 = 2;
  // pto: %c2_i64
  const int64_t v43 = 2;
  // pto: %c152_i64
  const int64_t v44 = 152;
  // pto: %c1_i64
  const int64_t v45 = 1;
  // pto: %cst_31
  const float v46 = 0.0f;
  // pto: %cst_32
  const float v47 = 1.0f;
  // pto: %cst_33
  const float v48 = 9.99999974E-5f;
  // pto: %cst_34
  const float v49 = 127.0f;
  // pto: %qr_i8_matmul_inline4570__iter_v1_view
  const int64_t v50 = 1;
  // pto: %qr_i8_matmul_inline4570__iter_v1_view
  const int64_t v51 = 1;
  // pto: %qr_i8_matmul_inline4570__iter_v1_view
  const int64_t v52 = 1;
  // pto: %qr_i8_matmul_inline4570__iter_v1_view
  int64_t v53 = v28 * v29;
  // pto: %qr_i8_matmul_inline4570__iter_v1_view
  int64_t v54 = v52 * v53;
  // pto: %qr_i8_matmul_inline4570__iter_v1_view
  pto::Shape<1, 1, 1, -1, -1> v55 = pto::Shape<1, 1, 1, -1, -1>(v50, v51, v52, v28, v29);
  // pto: %qr_i8_matmul_inline4570__iter_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v56 = pto::Stride<-1, -1, -1, -1, -1>(v51 * v54, v54, v53, v29, v30);
  // pto: %qr_i8_matmul_inline4570__iter_v1_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v57 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v55, v56);
  // pto: %qr_scale_pad_store_inline4572__iter_v1_view
  const int64_t v58 = 1;
  // pto: %qr_scale_pad_store_inline4572__iter_v1_view
  const int64_t v59 = 1;
  // pto: %qr_scale_pad_store_inline4572__iter_v1_view
  const int64_t v60 = 1;
  // pto: %qr_scale_pad_store_inline4572__iter_v1_view
  int64_t v61 = v28 * v30;
  // pto: %qr_scale_pad_store_inline4572__iter_v1_view
  int64_t v62 = v60 * v61;
  // pto: %qr_scale_pad_store_inline4572__iter_v1_view
  pto::Shape<1, 1, 1, -1, -1> v63 = pto::Shape<1, 1, 1, -1, -1>(v58, v59, v60, v28, v30);
  // pto: %qr_scale_pad_store_inline4572__iter_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v64 = pto::Stride<-1, -1, -1, -1, -1>(v59 * v62, v62, v61, v30, v28);
  // pto: %qr_scale_pad_store_inline4572__iter_v1_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v65 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v2, v63, v64);
  // pto: %qr_scale_view_inline8184__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %qr_scale_view_inline8184__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %qr_scale_view_inline8184__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %qr_scale_view_inline8184__ssa_v0_view
  int64_t v69 = (int64_t) v11;
  // pto: %qr_scale_view_inline8184__ssa_v0_view
  int64_t v70 = v69 * v30;
  // pto: %qr_scale_view_inline8184__ssa_v0_view
  int64_t v71 = v68 * v70;
  // pto: %qr_scale_view_inline8184__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v72 = pto::Shape<1, 1, 1, -1, -1>(v66, v67, v68, v69, v30);
  // pto: %qr_scale_view_inline8184__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v73 = pto::Stride<-1, -1, -1, -1, -1>(v67 * v71, v71, v70, v30, (int64_t) v11);
  // pto: %qr_scale_view_inline8184__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v74 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v3, v72, v73);
  // pto: %qr_view_inline8175__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %qr_view_inline8175__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %qr_view_inline8175__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %qr_view_inline8175__ssa_v0_view
  int64_t v78 = (int64_t) v11;
  // pto: %qr_view_inline8175__ssa_v0_view
  int64_t v79 = v78 * v29;
  // pto: %qr_view_inline8175__ssa_v0_view
  int64_t v80 = v77 * v79;
  // pto: %qr_view_inline8175__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v81 = pto::Shape<1, 1, 1, -1, -1>(v75, v76, v77, v78, v29);
  // pto: %qr_view_inline8175__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v82 = pto::Stride<-1, -1, -1, -1, -1>(v76 * v80, v80, v79, v29, v30);
  // pto: %qr_view_inline8175__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v83 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v81, v82);
  // pto: %qr_fp32_inline0_inline4577__phi_v35_view
  const int64_t v84 = 1;
  // pto: %qr_fp32_inline0_inline4577__phi_v35_view
  const int64_t v85 = 1;
  // pto: %qr_fp32_inline0_inline4577__phi_v35_view
  const int64_t v86 = 1;
  // pto: %qr_fp32_inline0_inline4577__phi_v35_view
  int64_t v87 = (int64_t) v12;
  // pto: %qr_fp32_inline0_inline4577__phi_v35_view
  int64_t v88 = v87 * v29;
  // pto: %qr_fp32_inline0_inline4577__phi_v35_view
  int64_t v89 = v86 * v88;
  // pto: %qr_fp32_inline0_inline4577__phi_v35_view
  pto::Shape<1, 1, 1, -1, -1> v90 = pto::Shape<1, 1, 1, -1, -1>(v84, v85, v86, v87, v29);
  // pto: %qr_fp32_inline0_inline4577__phi_v35_view
  pto::Stride<-1, -1, -1, -1, -1> v91 = pto::Stride<-1, -1, -1, -1, -1>(v85 * v89, v89, v88, v29, v30);
  // pto: %qr_fp32_inline0_inline4577__phi_v35_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v92 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v90, v91);
  // pto: %gamma_cq__ssa_v0_view
  const int64_t v93 = 1;
  // pto: %gamma_cq__ssa_v0_view
  const int64_t v94 = 1;
  // pto: %gamma_cq__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %gamma_cq__ssa_v0_view
  const int64_t v96 = 1;
  // pto: %gamma_cq__ssa_v0_view
  int64_t v97 = v29 * v30;
  // pto: %gamma_cq__ssa_v0_view
  int64_t v98 = v96 * v97;
  // pto: %gamma_cq__ssa_v0_view
  int64_t v99 = v95 * v98;
  // pto: %gamma_cq__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v100 = pto::Shape<1, 1, 1, 1, -1>(v93, v94, v95, v96, v29);
  // pto: %gamma_cq__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v101 = pto::Stride<-1, -1, -1, -1, -1>(v94 * v99, v99, v98, v97, v30);
  // pto: %gamma_cq__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v102 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v100, v101);
  // pto: %tg_idx_worker_inline8176__ssa_v0
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  for (int64_t v103 = (int64_t) v13; v103 < v7; v103 += v8) {
    // pto: %49
    ;
    int64_t v104 = (int64_t) ((uint64_t) v103 * (uint64_t) v31);
    // pto: %50
    ;
    int64_t v105 = (int64_t) ((uint64_t) v9 - (uint64_t) v104);
    // pto: %51
    ;
    int64_t v106 = v105 < v31 ? v105 : v31;
    // pto: %52
    ;
    int64_t v107 = (int64_t) ((uint64_t) v10 + (uint64_t) v104);
    // pto: %t__tile
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v29);
    // pto: %t__tile
    ;
    uint64_t v109 = (uint64_t) v15;
    TASSIGN(v108, v109);
    // pto: %53
    ;
    int64_t v110 = v104 < v32 ? v32 : v104;
    // pto: %qr_fp32_inline0_inline4577__phi_v35_pview
    ;
    __gm__ float* v111 = PTOAS__GLOBAL_TENSOR_DATA(v92);
    // pto: %qr_fp32_inline0_inline4577__phi_v35_pview
    ;
    const int64_t v112 = 0;
    // pto: %qr_fp32_inline0_inline4577__phi_v35_pview
    ;
    const int64_t v113 = 1024;
    // pto: %qr_fp32_inline0_inline4577__phi_v35_pview
    ;
    pto::Shape<1, 1, 1, 8, 1024> v114 = pto::Shape<1, 1, 1, 8, 1024>();
    // pto: %qr_fp32_inline0_inline4577__phi_v35_pview
    ;
    pto::Stride<8192, 8192, 8192, 1024, 1> v115 = pto::Stride<8192, 8192, 8192, 1024, 1>();
    // pto: %qr_fp32_inline0_inline4577__phi_v35_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1024>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v116 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1024>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v111 + (v112 + v110 * v113), v114, v115);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v108, v116);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %0
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v29);
    // pto: %0
    ;
    uint64_t v118 = (uint64_t) v16;
    TASSIGN(v117, v118);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    RoundMode v119 = RoundMode::CAST_RINT;
    SaturationMode v120 = SaturationMode::ON;
    TCVT(v117, v108, v119, v120);
    // pto: %qr_rms_full_inline16_inline8197__tile
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v29);
    // pto: %qr_rms_full_inline16_inline8197__tile
    ;
    uint64_t v122 = (uint64_t) v15;
    TASSIGN(v121, v122);
    pipe_barrier(PIPE_V);
    RoundMode v123 = RoundMode::CAST_ROUND;
    SaturationMode v124 = SaturationMode::ON;
    TCVT(v121, v117, v123, v124);
    // pto: %qr_square_full_inline31_inline8198__tile
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v125 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v29);
    // pto: %qr_square_full_inline31_inline8198__tile
    ;
    uint64_t v126 = (uint64_t) v15;
    TASSIGN(v125, v126);
    pipe_barrier(PIPE_V);
    TMUL(v125, v121, v121);
    // pto: %1
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v28);
    // pto: %1
    ;
    uint64_t v128 = (uint64_t) v15;
    TASSIGN(v127, v128);
    // pto: %slice_view
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, 8, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v129;
    // pto: %slice_view
    ;
    uint64_t v130 = (uint64_t) v15;
    TASSIGN(v129, v130);
    // pto: %2
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v28);
    // pto: %2
    ;
    uint64_t v132 = (uint64_t) v17;
    TASSIGN(v131, v132);
    // pto: %54
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, 8, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v133;
    // pto: %54
    ;
    uint64_t v134 = (uint64_t) v17;
    TASSIGN(v133, v134);
    // pto: %qr_square_half_inline23_inline8189__tile
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v135 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v28);
    // pto: %qr_square_half_inline23_inline8189__tile
    ;
    uint64_t v136 = (uint64_t) v15;
    TASSIGN(v135, v136);
    pipe_barrier(PIPE_V);
    TADD(v135, v129, v133);
    // pto: %3
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
    // pto: %3
    ;
    uint64_t v138 = (uint64_t) v15;
    TASSIGN(v137, v138);
    // pto: %55
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v139;
    // pto: %55
    ;
    uint64_t v140 = (uint64_t) v15;
    TASSIGN(v139, v140);
    // pto: %4
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v141 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
    // pto: %4
    ;
    uint64_t v142 = (uint64_t) v18;
    TASSIGN(v141, v142);
    // pto: %56
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v143;
    // pto: %56
    ;
    uint64_t v144 = (uint64_t) v18;
    TASSIGN(v143, v144);
    // pto: %qr_square_quarter_inline21_inline8171__tile
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v145 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
    // pto: %qr_square_quarter_inline21_inline8171__tile
    ;
    uint64_t v146 = (uint64_t) v15;
    TASSIGN(v145, v146);
    pipe_barrier(PIPE_V);
    TADD(v145, v139, v143);
    // pto: %5
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v147 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v34);
    // pto: %5
    ;
    uint64_t v148 = (uint64_t) v15;
    TASSIGN(v147, v148);
    // pto: %57
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, 8, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v149;
    // pto: %57
    ;
    uint64_t v150 = (uint64_t) v15;
    TASSIGN(v149, v150);
    // pto: %6
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v151 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v34);
    // pto: %6
    ;
    uint64_t v152 = (uint64_t) v19;
    TASSIGN(v151, v152);
    // pto: %58
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, 8, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v153;
    // pto: %58
    ;
    uint64_t v154 = (uint64_t) v19;
    TASSIGN(v153, v154);
    // pto: %qr_square_eighth_inline37_inline8168__tile
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v155 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v34);
    // pto: %qr_square_eighth_inline37_inline8168__tile
    ;
    uint64_t v156 = (uint64_t) v15;
    TASSIGN(v155, v156);
    pipe_barrier(PIPE_V);
    TADD(v155, v149, v153);
    // pto: %7
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v35);
    // pto: %7
    ;
    uint64_t v158 = (uint64_t) v15;
    TASSIGN(v157, v158);
    // pto: %59
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v159;
    // pto: %59
    ;
    uint64_t v160 = (uint64_t) v15;
    TASSIGN(v159, v160);
    // pto: %8
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v161 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v35);
    // pto: %8
    ;
    uint64_t v162 = (uint64_t) v20;
    TASSIGN(v161, v162);
    // pto: %60
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v163;
    // pto: %60
    ;
    uint64_t v164 = (uint64_t) v20;
    TASSIGN(v163, v164);
    // pto: %qr_square_sixteenth_inline18_inline8166__tile
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v165 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v35);
    // pto: %qr_square_sixteenth_inline18_inline8166__tile
    ;
    uint64_t v166 = (uint64_t) v16;
    TASSIGN(v165, v166);
    pipe_barrier(PIPE_V);
    TADD(v165, v159, v163);
    // pto: %tmp_tile
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v167 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v34);
    // pto: %tmp_tile
    ;
    uint64_t v168 = (uint64_t) v15;
    TASSIGN(v167, v168);
    // pto: %9
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v30);
    // pto: %9
    ;
    uint64_t v170 = (uint64_t) v21;
    TASSIGN(v169, v170);
    pipe_barrier(PIPE_V);
    TROWSUM(v169, v165, v167);
    // pto: %qr_sq_sum_inline32_inline8196__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v171 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_sq_sum_inline32_inline8196__tile
    ;
    uint64_t v172 = (uint64_t) v21;
    TASSIGN(v171, v172);
    // pto: %10
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v173 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %10
    ;
    uint64_t v174 = (uint64_t) v15;
    TASSIGN(v173, v174);
    pipe_barrier(PIPE_V);
    TMULS(v173, v171, v36);
    // pto: %qr_variance_inline17_inline8179__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_variance_inline17_inline8179__tile
    ;
    uint64_t v176 = (uint64_t) v15;
    TASSIGN(v175, v176);
    pipe_barrier(PIPE_V);
    TADDS(v175, v173, v37);
    // pto: %qr_rms_approx_inline42_inline8174__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_rms_approx_inline42_inline8174__tile
    ;
    uint64_t v178 = (uint64_t) v16;
    TASSIGN(v177, v178);
    pipe_barrier(PIPE_V);
    TSQRT(v177, v175);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %qr_variance_bits_inline20_inline8180__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v179 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_variance_bits_inline20_inline8180__tile
    ;
    uint64_t v180 = (uint64_t) v15;
    TASSIGN(v179, v180);
    // pto: %qr_approx_bits_inline27_inline8185__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_approx_bits_inline27_inline8185__tile
    ;
    uint64_t v182 = (uint64_t) v16;
    TASSIGN(v181, v182);
    // pto: %qr_rounded_bits_inline26_inline8178__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_rounded_bits_inline26_inline8178__tile
    ;
    uint64_t v184 = (uint64_t) v21;
    TASSIGN(v183, v184);
    TEXPANDS(v183, v38);
    set_flag(PIPE_V, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
    for (int64_t v185 = v32; v185 < v31; v185 += v30) {
      // pto: %61
      ;
      int32_t v186 = v179.GetValue(v185);
      // pto: %62
      ;
      int64_t v187 = (int64_t) v186;
      // pto: %63
      ;
      int32_t v188 = v181.GetValue(v185);
      // pto: %66
      ;
      // pto: %68, %69, %70
      ;
      if ((int64_t) v186 >= v39 & v187 < v40) {
        // pto: %71
        ;
        int64_t v189 = v187 / v41;
        // pto: %72
        ;
        int64_t v190 = v187 % v41;
        // pto: %73, %74, %75
        ;
        int64_t v191 = v190 < v22 ? (int64_t) ((uint64_t) v190 + (uint64_t) v41) : v190;
        // pto: %76
        ;
        int64_t v192 = (int64_t) ((uint64_t) v191 + (uint64_t) v41);
        // pto: %qr_y_bits_inline22_inline8161__rv_v2
        ;
        int64_t v193;
        v193 = (int64_t) v188;
        for (int64_t v194 = v32; v194 < v42; v194 += v30) {
          // pto: %77
          ;
          int64_t v195 = v193 / v41;
          // pto: %78
          ;
          int64_t v196 = v193 % v41;
          // pto: %79, %80, %81
          ;
          int64_t v197 = v196 < v22 ? (int64_t) ((uint64_t) v196 + (uint64_t) v41) : v196;
          // pto: %82, %83, %85
          ;
          int64_t v198 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v197 + (uint64_t) v41) * (uint64_t) v43) + (uint64_t) v30);
          // pto: %86
          ;
          int64_t v199 = (int64_t) ((uint64_t) v198 * (uint64_t) v198);
          // pto: %90, %88, %87, %89
          ;
          int64_t v200 = (int64_t) ((uint64_t) v192 << (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v189 - (uint64_t) ((int64_t) (uint64_t) v195 * (uint64_t) v43)) + (uint64_t) v44));
          // pto: %91
          ;
          uint64_t v201 = (uint64_t) v193;
          // pto: %91
          ;
          int64_t v202 = (int64_t) (v201 - (uint64_t) v45);
          // pto: %93
          ;
          int64_t v203 = v202 % v41;
          // pto: %94, %95, %96
          ;
          int64_t v204 = v203 < v22 ? (int64_t) ((uint64_t) v203 + (uint64_t) v41) : v203;
          // pto: %97, %98, %100
          ;
          int64_t v205 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v204 + (uint64_t) v41) * (uint64_t) v43) + (uint64_t) v30);
          // pto: %101
          ;
          int64_t v206 = (int64_t) ((uint64_t) v205 * (uint64_t) v205);
          // pto: %105, %103, %92, %102, %104
          ;
          int64_t v207 = (int64_t) ((uint64_t) v192 << (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v189 - (uint64_t) ((int64_t) (uint64_t) (v202 / v41) * (uint64_t) v43)) + (uint64_t) v44));
          // pto: %110
          ;
          int64_t v208 = v193 % v43;
          // pto: %111, %112, %113
          ;
          int64_t v209 = v208 < v22 ? (int64_t) ((uint64_t) v208 + (uint64_t) v43) : v208;
          // pto: %114
          ;
          bool v210 = v209 == v45;
          // pto: %107, %109, %115, %116
          ;
          // pto: %qr_y_bits_inline22_inline8161__phi_v6
          ;
          int64_t v211;
          if (v199 < v200 | v200 == v199 & v210) {
            // pto: %117
            ;
            uint64_t v212 = (uint64_t) v193;
            // pto: %117
            ;
            v211 = (int64_t) (v212 + (uint64_t) v45);
          } else {
            // pto: %119, %121, %127, %128, %qr_y_bits_inline22_inline8161__phi_v5
            ;
            int64_t v213 = v207 < v206 | v207 == v206 & v210 ? v202 : v193;
            v211 = v213;
          };
          v193 = v211;
        };
        // pto: %130
        ;
        int32_t v214 = (int32_t) v193;
        v183.SetValue(v185, v214);
      } else {
        v183.SetValue(v185, v188);
      };
    };
    set_flag(PIPE_S, PIPE_MTE2, EVENT_ID0);
    // pto: %qr_rms_inline13_inline8190__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_rms_inline13_inline8190__tile
    ;
    uint64_t v216 = (uint64_t) v21;
    TASSIGN(v215, v216);
    // pto: %qr_inv_rms_inline25_inline8218__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_inv_rms_inline25_inline8218__tile
    ;
    uint64_t v218 = (uint64_t) v22;
    TASSIGN(v217, v218);
    TEXPANDS(v217, v46);
    set_flag(PIPE_V, PIPE_S, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID1);
    for (int64_t v219 = v32; v219 < v31; v219 += v30) {
      // pto: %qr_rms_value_inline36_inline8219__tile
      ;
      float v220 = v215.GetValue(v219);
      // pto: %138
      ;
      float v221 = v47 / v220;
      v217.SetValue(v219, v221);
    };
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
    // pto: %qr_inv_rms_inline8187__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v222 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_inv_rms_inline8187__ssa_v0
    ;
    uint64_t v223 = (uint64_t) v22;
    TASSIGN(v222, v223);
    // pto: %qr_inv_rms_t_inline8223__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v224 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v30);
    // pto: %qr_inv_rms_t_inline8223__tile
    ;
    uint64_t v225 = (uint64_t) v22;
    TASSIGN(v224, v225);
    // pto: %qr_tile_amax_inline8224__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v226 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_tile_amax_inline8224__tile
    ;
    uint64_t v227 = (uint64_t) v23;
    TASSIGN(v226, v227);
    TEXPANDS(v226, v48);
    wait_flag(PIPE_S, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    for (int64_t v228 = v32; v228 < v29; v228 += v28) {
      // pto: %11
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v229 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %11
      ;
      uint64_t v230 = (uint64_t) v15;
      TASSIGN(v229, v230);
      // pto: %142
      ;
      int64_t v231 = v228 < v32 ? v32 : v228;
      // pto: %143
      ;
      __gm__ float* v232 = PTOAS__GLOBAL_TENSOR_DATA(v92);
      // pto: %143
      ;
      const int64_t v233 = 0;
      // pto: %143
      ;
      const int64_t v234 = 1024;
      // pto: %143
      ;
      pto::Shape<1, 1, 1, 8, 256> v235 = pto::Shape<1, 1, 1, 8, 256>();
      // pto: %143
      ;
      pto::Stride<8192, 8192, 8192, 1024, 1> v236 = pto::Stride<8192, 8192, 8192, 1024, 1>();
      // pto: %143
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v237 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v232 + (v233 + v110 * v234 + v231), v235, v236);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      TLOAD(v229, v237);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %12
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v238 = Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %12
      ;
      uint64_t v239 = (uint64_t) v24;
      TASSIGN(v238, v239);
      // pto: %gamma_cq__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v240 = PTOAS__GLOBAL_TENSOR_DATA(v102);
      // pto: %gamma_cq__ssa_v0_pview
      ;
      const int64_t v241 = 0;
      // pto: %gamma_cq__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 256> v242 = pto::Shape<1, 1, 1, 1, 256>();
      // pto: %gamma_cq__ssa_v0_pview
      ;
      pto::Stride<256, 256, 256, 256, 1> v243 = pto::Stride<256, 256, 256, 256, 1>();
      // pto: %gamma_cq__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND> v244 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND>(v240 + (v241 + v231), v242, v243);
      TLOAD(v238, v244);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %13
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v245 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %13
      ;
      uint64_t v246 = (uint64_t) v16;
      TASSIGN(v245, v246);
      // pto: %146
      ;
      int64_t v247 = (int64_t) ((uint64_t) v228 + (uint64_t) v33);
      // pto: %147
      ;
      int64_t v248 = v247 < v32 ? v32 : v247;
      // pto: %148
      ;
      __gm__ float* v249 = PTOAS__GLOBAL_TENSOR_DATA(v92);
      // pto: %148
      ;
      const int64_t v250 = 0;
      // pto: %148
      ;
      const int64_t v251 = 1024;
      // pto: %148
      ;
      pto::Shape<1, 1, 1, 8, 256> v252 = pto::Shape<1, 1, 1, 8, 256>();
      // pto: %148
      ;
      pto::Stride<8192, 8192, 8192, 1024, 1> v253 = pto::Stride<8192, 8192, 8192, 1024, 1>();
      // pto: %148
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v254 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v249 + (v250 + v110 * v251 + v248), v252, v253);
      TLOAD(v245, v254);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %14
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v255 = Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %14
      ;
      uint64_t v256 = (uint64_t) v25;
      TASSIGN(v255, v256);
      // pto: %151
      ;
      __gm__ bfloat16_t* v257 = PTOAS__GLOBAL_TENSOR_DATA(v102);
      // pto: %151
      ;
      const int64_t v258 = 0;
      // pto: %151
      ;
      pto::Shape<1, 1, 1, 1, 256> v259 = pto::Shape<1, 1, 1, 1, 256>();
      // pto: %151
      ;
      pto::Stride<256, 256, 256, 256, 1> v260 = pto::Stride<256, 256, 256, 256, 1>();
      // pto: %151
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND> v261 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND>(v257 + (v258 + v248), v259, v260);
      TLOAD(v255, v261);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      // pto: %15
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v262 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %15
      ;
      uint64_t v263 = (uint64_t) v21;
      TASSIGN(v262, v263);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      pipe_barrier(PIPE_V);
      RoundMode v264 = RoundMode::CAST_RINT;
      SaturationMode v265 = SaturationMode::ON;
      TCVT(v262, v229, v264, v265);
      // pto: %qr_max_chunk_inline8226__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v266 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_max_chunk_inline8226__tile
      ;
      uint64_t v267 = (uint64_t) v15;
      TASSIGN(v266, v267);
      pipe_barrier(PIPE_V);
      RoundMode v268 = RoundMode::CAST_ROUND;
      SaturationMode v269 = SaturationMode::ON;
      TCVT(v266, v262, v268, v269);
      // pto: %gamma_max_cast_inline8205__tile
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v270 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %gamma_max_cast_inline8205__tile
      ;
      uint64_t v271 = (uint64_t) v21;
      TASSIGN(v270, v271);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      RoundMode v272 = RoundMode::CAST_ROUND;
      SaturationMode v273 = SaturationMode::ON;
      TCVT(v270, v238, v272, v273);
      // pto: %gamma_max_chunk_inline8222__tile
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v274 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %gamma_max_chunk_inline8222__tile
      ;
      uint64_t v275 = (uint64_t) v21;
      TASSIGN(v274, v275);
      // pto: %16
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v276 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %16
      ;
      uint64_t v277 = (uint64_t) v15;
      TASSIGN(v276, v277);
      TROWEXPANDMUL(v276, v266, v224);
      // pto: %qr_normalized_inline8202__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v278 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_normalized_inline8202__tile
      ;
      uint64_t v279 = (uint64_t) v15;
      TASSIGN(v278, v279);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v278, v276, v274);
      // pto: %17
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v280 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %17
      ;
      uint64_t v281 = (uint64_t) v15;
      TASSIGN(v280, v281);
      pipe_barrier(PIPE_V);
      TABS(v280, v278);
      // pto: %18
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v282 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %18
      ;
      uint64_t v283 = (uint64_t) v21;
      TASSIGN(v282, v283);
      // pto: %19
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v284 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v30);
      // pto: %19
      ;
      uint64_t v285 = (uint64_t) v24;
      TASSIGN(v284, v285);
      pipe_barrier(PIPE_V);
      TROWMAX(v284, v280, v282);
      // pto: %qr_normalized_max_inline8162__tile
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v286 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
      // pto: %qr_normalized_max_inline8162__tile
      ;
      uint64_t v287 = (uint64_t) v24;
      TASSIGN(v286, v287);
      // pto: %20
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v288 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
      // pto: %20
      ;
      uint64_t v289 = (uint64_t) v15;
      TASSIGN(v288, v289);
      pipe_barrier(PIPE_V);
      TMAX(v288, v226, v286);
      // pto: %21
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v290 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %21
      ;
      uint64_t v291 = (uint64_t) v26;
      TASSIGN(v290, v291);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      RoundMode v292 = RoundMode::CAST_RINT;
      SaturationMode v293 = SaturationMode::ON;
      TCVT(v290, v245, v292, v293);
      // pto: %22
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v294 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %22
      ;
      uint64_t v295 = (uint64_t) v16;
      TASSIGN(v294, v295);
      pipe_barrier(PIPE_V);
      RoundMode v296 = RoundMode::CAST_ROUND;
      SaturationMode v297 = SaturationMode::ON;
      TCVT(v294, v290, v296, v297);
      // pto: %23
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %23
      ;
      uint64_t v299 = (uint64_t) v26;
      TASSIGN(v298, v299);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      RoundMode v300 = RoundMode::CAST_ROUND;
      SaturationMode v301 = SaturationMode::ON;
      TCVT(v298, v255, v300, v301);
      // pto: %24
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v302 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %24
      ;
      uint64_t v303 = (uint64_t) v26;
      TASSIGN(v302, v303);
      // pto: %25
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v304 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %25
      ;
      uint64_t v305 = (uint64_t) v16;
      TASSIGN(v304, v305);
      TROWEXPANDMUL(v304, v294, v224);
      // pto: %26
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v306 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %26
      ;
      uint64_t v307 = (uint64_t) v16;
      TASSIGN(v306, v307);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v306, v304, v302);
      // pto: %27
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v308 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %27
      ;
      uint64_t v309 = (uint64_t) v16;
      TASSIGN(v308, v309);
      pipe_barrier(PIPE_V);
      TABS(v308, v306);
      // pto: %28
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v310 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %28
      ;
      uint64_t v311 = (uint64_t) v26;
      TASSIGN(v310, v311);
      // pto: %29
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v312 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v30);
      // pto: %29
      ;
      uint64_t v313 = (uint64_t) v25;
      TASSIGN(v312, v313);
      pipe_barrier(PIPE_V);
      TROWMAX(v312, v308, v310);
      // pto: %30
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v314 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
      // pto: %30
      ;
      uint64_t v315 = (uint64_t) v25;
      TASSIGN(v314, v315);
      // pto: %31
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v316 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
      // pto: %31
      ;
      uint64_t v317 = (uint64_t) v23;
      TASSIGN(v316, v317);
      pipe_barrier(PIPE_V);
      TMAX(v316, v288, v314);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    };
    // pto: %qr_scale_quant_row_inline8210__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v318 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_scale_quant_row_inline8210__tile
    ;
    uint64_t v319 = (uint64_t) v27;
    TASSIGN(v318, v319);
    TEXPANDS(v318, v46);
    // pto: %qr_scale_dq_row_inline8163__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v320 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_scale_dq_row_inline8163__tile
    ;
    uint64_t v321 = (uint64_t) v15;
    TASSIGN(v320, v321);
    pipe_barrier(PIPE_V);
    TEXPANDS(v320, v46);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    set_flag(PIPE_V, PIPE_S, EVENT_ID2);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID2);
    for (int64_t v322 = v32; v322 < v31; v322 += v30) {
      // pto: %qr_amax_value_inline8164__tile
      ;
      float v323 = v226.GetValue(v322);
      // pto: %154
      ;
      float v324 = v49 / v323;
      v318.SetValue(v322, v324);
      // pto: %157
      ;
      float v325 = v47 / v324;
      v320.SetValue(v322, v325);
    };
    set_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
    // pto: %qr_scale_quant_t_inline8181__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v326 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v30);
    // pto: %qr_scale_quant_t_inline8181__tile
    ;
    uint64_t v327 = (uint64_t) v27;
    TASSIGN(v326, v327);
    // pto: %qr_tile_scale_dq_inline8157__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v328 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v30);
    // pto: %qr_tile_scale_dq_inline8157__tile
    ;
    uint64_t v329 = (uint64_t) v15;
    TASSIGN(v328, v329);
    // pto: %qr_scale_pad_store_inline4572__iter_v3_pview
    ;
    __gm__ float* v330 = PTOAS__GLOBAL_TENSOR_DATA(v65);
    // pto: %qr_scale_pad_store_inline4572__iter_v3_pview
    ;
    const int64_t v331 = 0;
    // pto: %qr_scale_pad_store_inline4572__iter_v3_pview
    ;
    pto::Shape<1, 1, 1, 8, 1> v332 = pto::Shape<1, 1, 1, 8, 1>();
    // pto: %qr_scale_pad_store_inline4572__iter_v3_pview
    ;
    pto::Stride<8, 8, 8, 1, 512> v333 = pto::Stride<8, 8, 8, 1, 512>();
    // pto: %qr_scale_pad_store_inline4572__iter_v3_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 512>, pto::Layout::DN> v334 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 512>, pto::Layout::DN>(v330 + (v331 + v110), v332, v333);
    wait_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v334, v328);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    // pto: %161
    ;
    bool v335 = v106 == v31;
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    if (v335) {
      // pto: %162
      ;
      int64_t v336 = v107 < v32 ? v32 : v107;
      // pto: %qr_scale_view_inline8184__iter_v1_pview
      ;
      int64_t v337 = (int64_t) v11;
      // pto: %qr_scale_view_inline8184__iter_v1_pview
      ;
      const int64_t v338 = 0;
      // pto: %qr_scale_view_inline8184__iter_v1_pview
      ;
      __gm__ float* v339 = PTOAS__GLOBAL_TENSOR_DATA(v74);
      // pto: %qr_scale_view_inline8184__iter_v1_pview
      ;
      const int64_t v340 = 1;
      // pto: %qr_scale_view_inline8184__iter_v1_pview
      ;
      const int64_t v341 = 1;
      // pto: %qr_scale_view_inline8184__iter_v1_pview
      ;
      const int64_t v342 = 1;
      // pto: %qr_scale_view_inline8184__iter_v1_pview
      ;
      int64_t v343 = v31 * v30;
      // pto: %qr_scale_view_inline8184__iter_v1_pview
      ;
      int64_t v344 = v342 * v343;
      // pto: %qr_scale_view_inline8184__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, 8, 1> v345 = pto::Shape<1, 1, 1, 8, 1>(v340, v341, v342, v31, v30);
      // pto: %qr_scale_view_inline8184__iter_v1_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v346 = pto::Stride<-1, -1, -1, -1, -1>(v341 * v344, v344, v343, v30, v337);
      // pto: %qr_scale_view_inline8184__iter_v1_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v347 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v339 + (v338 + v336 * v30 + v32 * v337), v345, v346);
      TSTORE(v347, v328);
    } else {
      // pto: %qr_scale_tail_inline8217__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v348 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v106, v30);
      // pto: %qr_scale_tail_inline8217__ssa_v0
      ;
      uint64_t v349 = (uint64_t) v15;
      TASSIGN(v348, v349);
      // pto: %qr_scale_pad_store_inline4572__tile_pview
      ;
      const int64_t v350 = 0;
      // pto: %qr_scale_pad_store_inline4572__tile_pview
      ;
      __gm__ float* v351 = PTOAS__GLOBAL_TENSOR_DATA(v65);
      // pto: %qr_scale_pad_store_inline4572__tile_pview
      ;
      const int64_t v352 = 1;
      // pto: %qr_scale_pad_store_inline4572__tile_pview
      ;
      const int64_t v353 = 1;
      // pto: %qr_scale_pad_store_inline4572__tile_pview
      ;
      const int64_t v354 = 1;
      // pto: %qr_scale_pad_store_inline4572__tile_pview
      ;
      int64_t v355 = v106 * v30;
      // pto: %qr_scale_pad_store_inline4572__tile_pview
      ;
      int64_t v356 = v354 * v355;
      // pto: %qr_scale_pad_store_inline4572__tile_pview
      ;
      pto::Shape<1, 1, 1, -1, 1> v357 = pto::Shape<1, 1, 1, -1, 1>(v352, v353, v354, v106, v30);
      // pto: %qr_scale_pad_store_inline4572__tile_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v358 = pto::Stride<-1, -1, -1, -1, -1>(v353 * v356, v356, v355, v30, v28);
      // pto: %qr_scale_pad_store_inline4572__tile_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v359 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v351 + (v350 + v110 * v30 + v32 * v28), v357, v358);
      TLOAD(v348, v359);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
      // pto: %164
      ;
      int64_t v360 = v107 < v32 ? v32 : v107;
      // pto: %165
      ;
      int64_t v361 = (int64_t) v11;
      // pto: %165
      ;
      const int64_t v362 = 0;
      // pto: %165
      ;
      __gm__ float* v363 = PTOAS__GLOBAL_TENSOR_DATA(v74);
      // pto: %165
      ;
      const int64_t v364 = 1;
      // pto: %165
      ;
      const int64_t v365 = 1;
      // pto: %165
      ;
      const int64_t v366 = 1;
      // pto: %165
      ;
      int64_t v367 = v106 * v30;
      // pto: %165
      ;
      int64_t v368 = v366 * v367;
      // pto: %165
      ;
      pto::Shape<1, 1, 1, -1, 1> v369 = pto::Shape<1, 1, 1, -1, 1>(v364, v365, v366, v106, v30);
      // pto: %165
      ;
      pto::Stride<-1, -1, -1, -1, -1> v370 = pto::Stride<-1, -1, -1, -1, -1>(v365 * v368, v368, v367, v30, v361);
      // pto: %165
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v371 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v363 + (v362 + v360 * v30 + v32 * v361), v369, v370);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
      TSTORE(v371, v348);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    for (int64_t v372 = v32; v372 < v29; v372 += v28) {
      // pto: %32
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v373 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %32
      ;
      uint64_t v374 = (uint64_t) v15;
      TASSIGN(v373, v374);
      // pto: %167
      ;
      int64_t v375 = v372 < v32 ? v32 : v372;
      // pto: %168
      ;
      __gm__ float* v376 = PTOAS__GLOBAL_TENSOR_DATA(v92);
      // pto: %168
      ;
      const int64_t v377 = 0;
      // pto: %168
      ;
      const int64_t v378 = 1024;
      // pto: %168
      ;
      pto::Shape<1, 1, 1, 8, 256> v379 = pto::Shape<1, 1, 1, 8, 256>();
      // pto: %168
      ;
      pto::Stride<8192, 8192, 8192, 1024, 1> v380 = pto::Stride<8192, 8192, 8192, 1024, 1>();
      // pto: %168
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v381 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v376 + (v377 + v110 * v378 + v375), v379, v380);
      TLOAD(v373, v381);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      // pto: %33
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v382 = Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %33
      ;
      uint64_t v383 = (uint64_t) v24;
      TASSIGN(v382, v383);
      // pto: %170
      ;
      __gm__ bfloat16_t* v384 = PTOAS__GLOBAL_TENSOR_DATA(v102);
      // pto: %170
      ;
      const int64_t v385 = 0;
      // pto: %170
      ;
      pto::Shape<1, 1, 1, 1, 256> v386 = pto::Shape<1, 1, 1, 1, 256>();
      // pto: %170
      ;
      pto::Stride<256, 256, 256, 256, 1> v387 = pto::Stride<256, 256, 256, 256, 1>();
      // pto: %170
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND> v388 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND>(v384 + (v385 + v375), v386, v387);
      TLOAD(v382, v388);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
      // pto: %34
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v389 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %34
      ;
      uint64_t v390 = (uint64_t) v16;
      TASSIGN(v389, v390);
      // pto: %172
      ;
      int64_t v391 = (int64_t) ((uint64_t) v372 + (uint64_t) v33);
      // pto: %173
      ;
      int64_t v392 = v391 < v32 ? v32 : v391;
      // pto: %174
      ;
      __gm__ float* v393 = PTOAS__GLOBAL_TENSOR_DATA(v92);
      // pto: %174
      ;
      const int64_t v394 = 0;
      // pto: %174
      ;
      const int64_t v395 = 1024;
      // pto: %174
      ;
      pto::Shape<1, 1, 1, 8, 256> v396 = pto::Shape<1, 1, 1, 8, 256>();
      // pto: %174
      ;
      pto::Stride<8192, 8192, 8192, 1024, 1> v397 = pto::Stride<8192, 8192, 8192, 1024, 1>();
      // pto: %174
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v398 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v393 + (v394 + v110 * v395 + v392), v396, v397);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      TLOAD(v389, v398);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
      // pto: %35
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v399 = Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %35
      ;
      uint64_t v400 = (uint64_t) v25;
      TASSIGN(v399, v400);
      // pto: %177
      ;
      __gm__ bfloat16_t* v401 = PTOAS__GLOBAL_TENSOR_DATA(v102);
      // pto: %177
      ;
      const int64_t v402 = 0;
      // pto: %177
      ;
      pto::Shape<1, 1, 1, 1, 256> v403 = pto::Shape<1, 1, 1, 1, 256>();
      // pto: %177
      ;
      pto::Stride<256, 256, 256, 256, 1> v404 = pto::Stride<256, 256, 256, 256, 1>();
      // pto: %177
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND> v405 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND>(v401 + (v402 + v392), v403, v404);
      TLOAD(v399, v405);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %36
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v406 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %36
      ;
      uint64_t v407 = (uint64_t) v21;
      TASSIGN(v406, v407);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      RoundMode v408 = RoundMode::CAST_RINT;
      SaturationMode v409 = SaturationMode::ON;
      TCVT(v406, v373, v408, v409);
      // pto: %qr_chunk_inline8214__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v410 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_chunk_inline8214__tile
      ;
      uint64_t v411 = (uint64_t) v15;
      TASSIGN(v410, v411);
      pipe_barrier(PIPE_V);
      RoundMode v412 = RoundMode::CAST_ROUND;
      SaturationMode v413 = SaturationMode::ON;
      TCVT(v410, v406, v412, v413);
      // pto: %gamma_q_cast_inline8177__tile
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v414 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %gamma_q_cast_inline8177__tile
      ;
      uint64_t v415 = (uint64_t) v21;
      TASSIGN(v414, v415);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
      RoundMode v416 = RoundMode::CAST_ROUND;
      SaturationMode v417 = SaturationMode::ON;
      TCVT(v414, v382, v416, v417);
      // pto: %gamma_q_chunk_inline8225__tile
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v418 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %gamma_q_chunk_inline8225__tile
      ;
      uint64_t v419 = (uint64_t) v21;
      TASSIGN(v418, v419);
      // pto: %37
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v420 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %37
      ;
      uint64_t v421 = (uint64_t) v15;
      TASSIGN(v420, v421);
      TROWEXPANDMUL(v420, v410, v224);
      // pto: %qr_q_normed_inline8165__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v422 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_q_normed_inline8165__tile
      ;
      uint64_t v423 = (uint64_t) v15;
      TASSIGN(v422, v423);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v422, v420, v418);
      // pto: %qr_q_scaled_inline8156__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v424 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_q_scaled_inline8156__tile
      ;
      uint64_t v425 = (uint64_t) v15;
      TASSIGN(v424, v425);
      pipe_barrier(PIPE_V);
      TROWEXPANDMUL(v424, v422, v326);
      // pto: %qr_q_i32_inline8173__tile
      ;
      Tile<TileType::Vec, int32_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v426 = Tile<TileType::Vec, int32_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_q_i32_inline8173__tile
      ;
      uint64_t v427 = (uint64_t) v15;
      TASSIGN(v426, v427);
      pipe_barrier(PIPE_V);
      RoundMode v428 = RoundMode::CAST_RINT;
      SaturationMode v429 = SaturationMode::ON;
      TCVT(v426, v424, v428, v429);
      // pto: %qr_q_half_inline8193__tile
      ;
      Tile<TileType::Vec, half, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v430 = Tile<TileType::Vec, half, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_q_half_inline8193__tile
      ;
      uint64_t v431 = (uint64_t) v15;
      TASSIGN(v430, v431);
      pipe_barrier(PIPE_V);
      RoundMode v432 = RoundMode::CAST_ROUND;
      SaturationMode v433 = SaturationMode::ON;
      TCVT(v430, v426, v432, v433);
      // pto: %qr_q_i8_inline8155__tile
      ;
      Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v434 = Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_q_i8_inline8155__tile
      ;
      uint64_t v435 = (uint64_t) v15;
      TASSIGN(v434, v435);
      pipe_barrier(PIPE_V);
      RoundMode v436 = RoundMode::CAST_TRUNC;
      SaturationMode v437 = SaturationMode::ON;
      TCVT(v434, v430, v436, v437);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      // pto: %qr_i8_matmul_inline4570__iter_v5_pview
      ;
      __gm__ int8_t* v438 = PTOAS__GLOBAL_TENSOR_DATA(v57);
      // pto: %qr_i8_matmul_inline4570__iter_v5_pview
      ;
      const int64_t v439 = 0;
      // pto: %qr_i8_matmul_inline4570__iter_v5_pview
      ;
      const int64_t v440 = 1024;
      // pto: %qr_i8_matmul_inline4570__iter_v5_pview
      ;
      pto::Shape<1, 1, 1, 8, 256> v441 = pto::Shape<1, 1, 1, 8, 256>();
      // pto: %qr_i8_matmul_inline4570__iter_v5_pview
      ;
      pto::Stride<8192, 8192, 8192, 1024, 1> v442 = pto::Stride<8192, 8192, 8192, 1024, 1>();
      // pto: %qr_i8_matmul_inline4570__iter_v5_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v443 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v438 + (v439 + v110 * v440 + v375), v441, v442);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v443, v434);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      if (v335) {
        // pto: %181
        ;
        int64_t v444 = v107 < v32 ? v32 : v107;
        // pto: %qr_view_inline8175__iter_v3_pview
        ;
        __gm__ int8_t* v445 = PTOAS__GLOBAL_TENSOR_DATA(v83);
        // pto: %qr_view_inline8175__iter_v3_pview
        ;
        const int64_t v446 = 0;
        // pto: %qr_view_inline8175__iter_v3_pview
        ;
        const int64_t v447 = 1024;
        // pto: %qr_view_inline8175__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, 8, 256> v448 = pto::Shape<1, 1, 1, 8, 256>();
        // pto: %qr_view_inline8175__iter_v3_pview
        ;
        pto::Stride<8192, 8192, 8192, 1024, 1> v449 = pto::Stride<8192, 8192, 8192, 1024, 1>();
        // pto: %qr_view_inline8175__iter_v3_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v450 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v445 + (v446 + v444 * v447 + v375), v448, v449);
        TSTORE(v450, v434);
      } else {
        // pto: %qr_q_tail_inline8158__ssa_v0
        ;
        Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v451 = Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v106, v33);
        // pto: %qr_q_tail_inline8158__ssa_v0
        ;
        uint64_t v452 = (uint64_t) v15;
        TASSIGN(v451, v452);
        // pto: %qr_i8_matmul_inline4570__tile_pview
        ;
        const int64_t v453 = 0;
        // pto: %qr_i8_matmul_inline4570__tile_pview
        ;
        __gm__ int8_t* v454 = PTOAS__GLOBAL_TENSOR_DATA(v57);
        // pto: %qr_i8_matmul_inline4570__tile_pview
        ;
        const int64_t v455 = 1;
        // pto: %qr_i8_matmul_inline4570__tile_pview
        ;
        const int64_t v456 = 1;
        // pto: %qr_i8_matmul_inline4570__tile_pview
        ;
        const int64_t v457 = 1;
        // pto: %qr_i8_matmul_inline4570__tile_pview
        ;
        int64_t v458 = v106 * v29;
        // pto: %qr_i8_matmul_inline4570__tile_pview
        ;
        int64_t v459 = v457 * v458;
        // pto: %qr_i8_matmul_inline4570__tile_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v460 = pto::Shape<1, 1, 1, -1, 256>(v455, v456, v457, v106, v33);
        // pto: %qr_i8_matmul_inline4570__tile_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v461 = pto::Stride<-1, -1, -1, -1, -1>(v456 * v459, v459, v458, v29, v30);
        // pto: %qr_i8_matmul_inline4570__tile_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v462 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v454 + (v453 + v110 * v29 + v375 * v30), v460, v461);
        TLOAD(v451, v462);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
        // pto: %185
        ;
        int64_t v463 = v107 < v32 ? v32 : v107;
        // pto: %187
        ;
        const int64_t v464 = 0;
        // pto: %187
        ;
        __gm__ int8_t* v465 = PTOAS__GLOBAL_TENSOR_DATA(v83);
        // pto: %187
        ;
        const int64_t v466 = 1;
        // pto: %187
        ;
        const int64_t v467 = 1;
        // pto: %187
        ;
        const int64_t v468 = 1;
        // pto: %187
        ;
        int64_t v469 = v106 * v29;
        // pto: %187
        ;
        int64_t v470 = v468 * v469;
        // pto: %187
        ;
        pto::Shape<1, 1, 1, -1, 256> v471 = pto::Shape<1, 1, 1, -1, 256>(v466, v467, v468, v106, v33);
        // pto: %187
        ;
        pto::Stride<-1, -1, -1, -1, -1> v472 = pto::Stride<-1, -1, -1, -1, -1>(v467 * v470, v470, v469, v29, v30);
        // pto: %187
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v473 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v465 + (v464 + v463 * v29 + v375 * v30), v471, v472);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
        TSTORE(v473, v451);
      };
      // pto: %38
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v474 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %38
      ;
      uint64_t v475 = (uint64_t) v26;
      TASSIGN(v474, v475);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
      RoundMode v476 = RoundMode::CAST_RINT;
      SaturationMode v477 = SaturationMode::ON;
      TCVT(v474, v389, v476, v477);
      // pto: %39
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v478 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %39
      ;
      uint64_t v479 = (uint64_t) v16;
      TASSIGN(v478, v479);
      pipe_barrier(PIPE_V);
      RoundMode v480 = RoundMode::CAST_ROUND;
      SaturationMode v481 = SaturationMode::ON;
      TCVT(v478, v474, v480, v481);
      // pto: %40
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v482 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %40
      ;
      uint64_t v483 = (uint64_t) v26;
      TASSIGN(v482, v483);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      RoundMode v484 = RoundMode::CAST_ROUND;
      SaturationMode v485 = SaturationMode::ON;
      TCVT(v482, v399, v484, v485);
      // pto: %41
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v486 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %41
      ;
      uint64_t v487 = (uint64_t) v26;
      TASSIGN(v486, v487);
      // pto: %42
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v488 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %42
      ;
      uint64_t v489 = (uint64_t) v16;
      TASSIGN(v488, v489);
      TROWEXPANDMUL(v488, v478, v224);
      // pto: %43
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v490 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %43
      ;
      uint64_t v491 = (uint64_t) v16;
      TASSIGN(v490, v491);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v490, v488, v486);
      // pto: %44
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v492 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %44
      ;
      uint64_t v493 = (uint64_t) v16;
      TASSIGN(v492, v493);
      pipe_barrier(PIPE_V);
      TROWEXPANDMUL(v492, v490, v326);
      // pto: %45
      ;
      Tile<TileType::Vec, int32_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v494 = Tile<TileType::Vec, int32_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %45
      ;
      uint64_t v495 = (uint64_t) v16;
      TASSIGN(v494, v495);
      pipe_barrier(PIPE_V);
      RoundMode v496 = RoundMode::CAST_RINT;
      SaturationMode v497 = SaturationMode::ON;
      TCVT(v494, v492, v496, v497);
      // pto: %46
      ;
      Tile<TileType::Vec, half, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v498 = Tile<TileType::Vec, half, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %46
      ;
      uint64_t v499 = (uint64_t) v16;
      TASSIGN(v498, v499);
      pipe_barrier(PIPE_V);
      RoundMode v500 = RoundMode::CAST_ROUND;
      SaturationMode v501 = SaturationMode::ON;
      TCVT(v498, v494, v500, v501);
      // pto: %47
      ;
      Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v502 = Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %47
      ;
      uint64_t v503 = (uint64_t) v16;
      TASSIGN(v502, v503);
      pipe_barrier(PIPE_V);
      RoundMode v504 = RoundMode::CAST_TRUNC;
      SaturationMode v505 = SaturationMode::ON;
      TCVT(v502, v498, v504, v505);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      // pto: %192
      ;
      __gm__ int8_t* v506 = PTOAS__GLOBAL_TENSOR_DATA(v57);
      // pto: %192
      ;
      const int64_t v507 = 0;
      // pto: %192
      ;
      const int64_t v508 = 1024;
      // pto: %192
      ;
      pto::Shape<1, 1, 1, 8, 256> v509 = pto::Shape<1, 1, 1, 8, 256>();
      // pto: %192
      ;
      pto::Stride<8192, 8192, 8192, 1024, 1> v510 = pto::Stride<8192, 8192, 8192, 1024, 1>();
      // pto: %192
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v511 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v506 + (v507 + v110 * v508 + v392), v509, v510);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v511, v502);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      if (v335) {
        // pto: %195
        ;
        int64_t v512 = v107 < v32 ? v32 : v107;
        // pto: %qr_view_inline8175__phi_v6_pview
        ;
        __gm__ int8_t* v513 = PTOAS__GLOBAL_TENSOR_DATA(v83);
        // pto: %qr_view_inline8175__phi_v6_pview
        ;
        const int64_t v514 = 0;
        // pto: %qr_view_inline8175__phi_v6_pview
        ;
        const int64_t v515 = 1024;
        // pto: %qr_view_inline8175__phi_v6_pview
        ;
        pto::Shape<1, 1, 1, 8, 256> v516 = pto::Shape<1, 1, 1, 8, 256>();
        // pto: %qr_view_inline8175__phi_v6_pview
        ;
        pto::Stride<8192, 8192, 8192, 1024, 1> v517 = pto::Stride<8192, 8192, 8192, 1024, 1>();
        // pto: %qr_view_inline8175__phi_v6_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v518 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v513 + (v514 + v512 * v515 + v392), v516, v517);
        TSTORE(v518, v502);
      } else {
        // pto: %48
        ;
        Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v519 = Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v106, v33);
        // pto: %48
        ;
        uint64_t v520 = (uint64_t) v16;
        TASSIGN(v519, v520);
        // pto: %201
        ;
        const int64_t v521 = 0;
        // pto: %201
        ;
        __gm__ int8_t* v522 = PTOAS__GLOBAL_TENSOR_DATA(v57);
        // pto: %201
        ;
        const int64_t v523 = 1;
        // pto: %201
        ;
        const int64_t v524 = 1;
        // pto: %201
        ;
        const int64_t v525 = 1;
        // pto: %201
        ;
        int64_t v526 = v106 * v29;
        // pto: %201
        ;
        int64_t v527 = v525 * v526;
        // pto: %201
        ;
        pto::Shape<1, 1, 1, -1, 256> v528 = pto::Shape<1, 1, 1, -1, 256>(v523, v524, v525, v106, v33);
        // pto: %201
        ;
        pto::Stride<-1, -1, -1, -1, -1> v529 = pto::Stride<-1, -1, -1, -1, -1>(v524 * v527, v527, v526, v29, v30);
        // pto: %201
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v530 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v522 + (v521 + v110 * v29 + v392 * v30), v528, v529);
        TLOAD(v519, v530);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
        // pto: %202
        ;
        int64_t v531 = v107 < v32 ? v32 : v107;
        // pto: %205
        ;
        const int64_t v532 = 0;
        // pto: %205
        ;
        __gm__ int8_t* v533 = PTOAS__GLOBAL_TENSOR_DATA(v83);
        // pto: %205
        ;
        const int64_t v534 = 1;
        // pto: %205
        ;
        const int64_t v535 = 1;
        // pto: %205
        ;
        const int64_t v536 = 1;
        // pto: %205
        ;
        int64_t v537 = v106 * v29;
        // pto: %205
        ;
        int64_t v538 = v536 * v537;
        // pto: %205
        ;
        pto::Shape<1, 1, 1, -1, 256> v539 = pto::Shape<1, 1, 1, -1, 256>(v534, v535, v536, v106, v33);
        // pto: %205
        ;
        pto::Stride<-1, -1, -1, -1, -1> v540 = pto::Stride<-1, -1, -1, -1, -1>(v535 * v538, v538, v537, v29, v30);
        // pto: %205
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v541 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v533 + (v532 + v531 * v29 + v392 * v30), v539, v540);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
        TSTORE(v541, v519);
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}