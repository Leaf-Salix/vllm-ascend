#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void rmsnorm_rope(__gm__ bfloat16_t* v1, __gm__ int64_t* v2, __gm__ int32_t* v3, __gm__ int32_t* v4, __gm__ float* v5, __gm__ float* v6, __gm__ float* v7, __gm__ bfloat16_t* v8, __gm__ int32_t* v9, int64_t v10, int64_t v11, int64_t v12, int64_t v13, int64_t v14, int64_t v15, int64_t v16, int32_t v17, int32_t v18) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v19 = 128;
  const int64_t v20 = 256;
  // pto: %c20480_i64
  const int64_t v21 = 20480;
  // pto: %c0_i64
  const int64_t v22 = 0;
  // pto: %c4096_i64
  const int64_t v23 = 4096;
  // pto: %c8192_i64
  const int64_t v24 = 8192;
  // pto: %c12288_i64
  const int64_t v25 = 12288;
  // pto: %c16384_i64
  const int64_t v26 = 16384;
  // pto: %c30976_i64
  const int64_t v27 = 30976;
  // pto: %c30720_i64
  const int64_t v28 = 30720;
  // pto: %c28672_i64
  const int64_t v29 = 28672;
  // pto: %c384_index
  const int64_t v30 = 384;
  // pto: %c128_index
  const int64_t v31 = 128;
  // pto: %c1_index
  const int64_t v32 = 1;
  // pto: %c64_index
  const int64_t v33 = 64;
  // pto: %c16_index
  const int64_t v34 = 16;
  // pto: %cst_14
  const float v35 = 1.0f;
  // pto: %c192_index
  const int64_t v36 = 192;
  // pto: %c0_i32
  const int32_t v37 = 0;
  // pto: %cst_17
  const float v38 = 0.5f;
  // pto: %cst_18
  const float v39 = 2.0f;
  // pto: %cst_19
  const float v40 = 0.0f;
  // pto: %c0_index
  const int64_t v41 = 0;
  // pto: %c1_i64
  const int64_t v42 = 1;
  // pto: %c4_i64
  const int64_t v43 = 4;
  // pto: %cst_23
  const float v44 = 0.0078125f;
  // pto: %cst_24
  const float v45 = 9.99999997E-7f;
  // pto: %c3_index
  const int64_t v46 = 3;
  // pto: %c2_index
  const int64_t v47 = 2;
  // pto: %c4_index
  const int64_t v48 = 4;
  // pto: %normed_kv_inline970__ssa_v1_view
  const int64_t v49 = 1;
  // pto: %normed_kv_inline970__ssa_v1_view
  const int64_t v50 = 1;
  // pto: %normed_kv_inline970__ssa_v1_view
  const int64_t v51 = 1;
  // pto: %normed_kv_inline970__ssa_v1_view
  int64_t v52 = v30 * v31;
  // pto: %normed_kv_inline970__ssa_v1_view
  int64_t v53 = v51 * v52;
  // pto: %normed_kv_inline970__ssa_v1_view
  pto::Shape<1, 1, 1, -1, -1> v54 = pto::Shape<1, 1, 1, -1, -1>(v49, v50, v51, v30, v31);
  // pto: %normed_kv_inline970__ssa_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v55 = pto::Stride<-1, -1, -1, -1, -1>(v50 * v53, v53, v52, v31, v32);
  // pto: %normed_kv_inline970__ssa_v1_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v56 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v54, v55);
  // pto: %inner_freqs_cos__ssa_v0_view
  const int64_t v57 = 1;
  // pto: %inner_freqs_cos__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %inner_freqs_cos__ssa_v0_view
  const int64_t v59 = 1;
  // pto: %inner_freqs_cos__ssa_v0_view
  int64_t v60 = (int64_t) v15;
  // pto: %inner_freqs_cos__ssa_v0_view
  int64_t v61 = v60 * v33;
  // pto: %inner_freqs_cos__ssa_v0_view
  int64_t v62 = v59 * v61;
  // pto: %inner_freqs_cos__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v63 = pto::Shape<1, 1, 1, -1, -1>(v57, v58, v59, v60, v33);
  // pto: %inner_freqs_cos__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v64 = pto::Stride<-1, -1, -1, -1, -1>(v58 * v62, v62, v61, v33, v32);
  // pto: %inner_freqs_cos__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v65 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v63, v64);
  // pto: %inner_freqs_sin__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %inner_freqs_sin__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %inner_freqs_sin__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %inner_freqs_sin__ssa_v0_view
  int64_t v69 = (int64_t) v15;
  // pto: %inner_freqs_sin__ssa_v0_view
  int64_t v70 = v69 * v33;
  // pto: %inner_freqs_sin__ssa_v0_view
  int64_t v71 = v68 * v70;
  // pto: %inner_freqs_sin__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v72 = pto::Shape<1, 1, 1, -1, -1>(v66, v67, v68, v69, v33);
  // pto: %inner_freqs_sin__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v73 = pto::Stride<-1, -1, -1, -1, -1>(v67 * v71, v71, v70, v33, v32);
  // pto: %inner_freqs_sin__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v74 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v72, v73);
  // pto: %pooled_kv_inline4853__rv_v2_view
  const int64_t v75 = 1;
  // pto: %pooled_kv_inline4853__rv_v2_view
  const int64_t v76 = 1;
  // pto: %pooled_kv_inline4853__rv_v2_view
  const int64_t v77 = 1;
  // pto: %pooled_kv_inline4853__rv_v2_view
  int64_t v78 = v30 * v31;
  // pto: %pooled_kv_inline4853__rv_v2_view
  int64_t v79 = v77 * v78;
  // pto: %pooled_kv_inline4853__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v80 = pto::Shape<1, 1, 1, -1, -1>(v75, v76, v77, v30, v31);
  // pto: %pooled_kv_inline4853__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v81 = pto::Stride<-1, -1, -1, -1, -1>(v76 * v79, v79, v78, v31, v32);
  // pto: %pooled_kv_inline4853__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v82 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v80, v81);
  // pto: %norm_w_2d_inline733_inline4817__ssa_v0_view
  const int64_t v83 = 1;
  // pto: %norm_w_2d_inline733_inline4817__ssa_v0_view
  const int64_t v84 = 1;
  // pto: %norm_w_2d_inline733_inline4817__ssa_v0_view
  const int64_t v85 = 1;
  // pto: %norm_w_2d_inline733_inline4817__ssa_v0_view
  int64_t v86 = v32 * v31;
  // pto: %norm_w_2d_inline733_inline4817__ssa_v0_view
  int64_t v87 = v85 * v86;
  // pto: %norm_w_2d_inline733_inline4817__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v88 = pto::Shape<1, 1, 1, -1, -1>(v83, v84, v85, v32, v31);
  // pto: %norm_w_2d_inline733_inline4817__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v89 = pto::Stride<-1, -1, -1, -1, -1>(v84 * v87, v87, v86, v31, v32);
  // pto: %norm_w_2d_inline733_inline4817__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v90 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v88, v89);
  // pto: %cosine_inline8357__phi_v5
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v91 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %cosine_inline8357__phi_v5
  uint64_t v92 = (uint64_t) v24;
  TASSIGN(v91, v92);
  // pto: %sine_inline8356__phi_v5
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %sine_inline8356__phi_v5
  uint64_t v94 = (uint64_t) v25;
  TASSIGN(v93, v94);
  // pto: %cosine_inline8357__phi_v4
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v95 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %cosine_inline8357__phi_v4
  uint64_t v96 = (uint64_t) v24;
  TASSIGN(v95, v96);
  // pto: %sine_inline8356__phi_v4
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %sine_inline8356__phi_v4
  uint64_t v98 = (uint64_t) v25;
  TASSIGN(v97, v98);
  // pto: %rms_worker_inline700_inline4851__ssa_v0
  // pto: %rope_ones_inline699_inline4814__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %rope_ones_inline699_inline4814__tile
  uint64_t v100 = (uint64_t) v21;
  TASSIGN(v99, v100);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  TEXPANDS(v99, v35);
  // pto: %rope_index_inline727_inline4813__ci_tmp_v0
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v36);
  // pto: %rope_index_inline727_inline4813__ci_tmp_v0
  uint64_t v102 = (uint64_t) v22;
  TASSIGN(v101, v102);
  // pto: %rope_index_inline727_inline4813__tile
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
  // pto: %rope_index_inline727_inline4813__tile
  uint64_t v104 = (uint64_t) v23;
  TASSIGN(v103, v104);
  // pto: %ci_tmp_view
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v105;
  TRESHAPE(v105, v101);
  // pto: %ci_dst_view
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v106;
  TRESHAPE(v106, v103);
  TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v106, v37, v105);
  // pto: %rope_index_f_inline698_inline4857__tile
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v107 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
  // pto: %rope_index_f_inline698_inline4857__tile
  uint64_t v108 = (uint64_t) v22;
  TASSIGN(v107, v108);
  pipe_barrier(PIPE_V);
  RoundMode v109 = RoundMode::CAST_ROUND;
  SaturationMode v110 = SaturationMode::ON;
  TCVT(v107, v103, v109, v110);
  // pto: %rope_col_inline697_inline4811__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %rope_col_inline697_inline4811__tile
  uint64_t v112 = (uint64_t) v21;
  TASSIGN(v111, v112);
  pipe_barrier(PIPE_V);
  TCOLEXPANDMUL(v111, v99, v107);
  // pto: %t__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %t__tile
  uint64_t v114 = (uint64_t) v22;
  TASSIGN(v113, v114);
  pipe_barrier(PIPE_V);
  TMULS(v113, v111, v38);
  // pto: %0
  Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v115 = Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %0
  uint64_t v116 = (uint64_t) v22;
  TASSIGN(v115, v116);
  pipe_barrier(PIPE_V);
  RoundMode v117 = RoundMode::CAST_TRUNC;
  SaturationMode v118 = SaturationMode::ON;
  TCVT(v115, v113, v117, v118);
  // pto: %rope_dup_f_inline696_inline4886__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v119 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %rope_dup_f_inline696_inline4886__tile
  uint64_t v120 = (uint64_t) v22;
  TASSIGN(v119, v120);
  pipe_barrier(PIPE_V);
  RoundMode v121 = RoundMode::CAST_ROUND;
  SaturationMode v122 = SaturationMode::ON;
  TCVT(v119, v115, v121, v122);
  // pto: %1
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v123 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %1
  uint64_t v124 = (uint64_t) v22;
  TASSIGN(v123, v124);
  pipe_barrier(PIPE_V);
  TMULS(v123, v119, v39);
  // pto: %rope_lane_inline695_inline4890__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v125 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %rope_lane_inline695_inline4890__tile
  uint64_t v126 = (uint64_t) v22;
  TASSIGN(v125, v126);
  pipe_barrier(PIPE_V);
  TSUB(v125, v111, v123);
  // pto: %2
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %2
  uint64_t v128 = (uint64_t) v21;
  TASSIGN(v127, v128);
  pipe_barrier(PIPE_V);
  TADDS(v127, v111, v35);
  // pto: %3
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %3
  uint64_t v130 = (uint64_t) v23;
  TASSIGN(v129, v130);
  TMULS(v129, v125, v39);
  // pto: %4
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %4
  uint64_t v132 = (uint64_t) v21;
  TASSIGN(v131, v132);
  pipe_barrier(PIPE_V);
  TSUB(v131, v127, v129);
  // pto: %rope_swap_idx_inline708_inline4810__tile
  Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %rope_swap_idx_inline708_inline4810__tile
  uint64_t v134 = (uint64_t) v23;
  TASSIGN(v133, v134);
  pipe_barrier(PIPE_V);
  RoundMode v135 = RoundMode::CAST_ROUND;
  SaturationMode v136 = SaturationMode::ON;
  TCVT(v133, v131, v135, v136);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v137 = (int64_t) v17; v137 < v10; v137 += v11) {
    // pto: %20
    ;
    int64_t v138 = (int64_t) ((uint64_t) v137 * (uint64_t) v34);
    // pto: %21
    ;
    int64_t v139 = (int64_t) ((uint64_t) v12 - (uint64_t) v138);
    // pto: %22
    ;
    int64_t v140 = v139 < v34 ? v139 : v34;
    // pto: %cosine_inline8357__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v141 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %cosine_inline8357__tile
    ;
    uint64_t v142 = (uint64_t) v24;
    TASSIGN(v141, v142);
    TEXPANDS(v141, v35);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    // pto: %sine_inline8356__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v143 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %sine_inline8356__tile
    ;
    uint64_t v144 = (uint64_t) v25;
    TASSIGN(v143, v144);
    TEXPANDS(v143, v40);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    for (int64_t v145 = v41; v145 < v140; v145 += v32) {
      // pto: %23
      ;
      int64_t v146 = (int64_t) ((uint64_t) v138 + (uint64_t) v145);
      // pto: %position_inline8353__tile
      ;
      int64_t v147 = (v2)[v146];
      // pto: %24
      ;
      int32_t v148 = (v3)[v146];
      // pto: %25
      ;
      int64_t v149 = (int64_t) v148;
      // pto: %27
      ;
      int64_t v150 = (int64_t) ((uint64_t) v147 + (uint64_t) v42);
      // pto: %28
      ;
      int64_t v151 = v150 % v43;
      // pto: %29, %30, %31
      ;
      int64_t v152 = v151 < v22 ? (int64_t) ((uint64_t) v151 + (uint64_t) v43) : v151;
      // pto: %26, %32, %33
      ;
      if (v149 >= v41 & v152 == v22) {
        // pto: %34
        ;
        int32_t v153 = (v4)[v149];
        // pto: %35, %39, %37
        ;
        int64_t v154 = (int64_t) ((uint64_t) ((int64_t) v153) + (uint64_t) (v150 / v43));
        // pto: %40, %41, %42
        ;
        if (v154 >= v41 & v154 < v15) {
          // pto: %gather_row_view
          ;
          int64_t v155 = (int64_t) ((uint64_t) v145 * (uint64_t) v20);
          // pto: %gather_row_view
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v156;
          // pto: %gather_row_view
          ;
          uint64_t v157 = (uint64_t) ((int64_t) (uint64_t) v155 + (uint64_t) v24);
          TASSIGN(v156, v157);
          // pto: %43
          ;
          int64_t v158 = v154 < v41 ? v41 : v154;
          // pto: %inner_freqs_cos__ssa_v0_pview
          ;
          __gm__ float* v159 = PTOAS__GLOBAL_TENSOR_DATA(v65);
          // pto: %inner_freqs_cos__ssa_v0_pview
          ;
          const int64_t v160 = 0;
          // pto: %inner_freqs_cos__ssa_v0_pview
          ;
          const int64_t v161 = 64;
          // pto: %inner_freqs_cos__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 1, 64> v162 = pto::Shape<1, 1, 1, 1, 64>();
          // pto: %inner_freqs_cos__ssa_v0_pview
          ;
          pto::Stride<64, 64, 64, 64, 1> v163 = pto::Stride<64, 64, 64, 64, 1>();
          // pto: %inner_freqs_cos__ssa_v0_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v164 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v159 + (v160 + v158 * v161), v162, v163);
          TLOAD(v156, v164);
          // pto: %44
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v165;
          // pto: %44
          ;
          uint64_t v166 = (uint64_t) ((int64_t) (uint64_t) v155 + (uint64_t) v25);
          TASSIGN(v165, v166);
          // pto: %inner_freqs_sin__ssa_v0_pview
          ;
          __gm__ float* v167 = PTOAS__GLOBAL_TENSOR_DATA(v74);
          // pto: %inner_freqs_sin__ssa_v0_pview
          ;
          const int64_t v168 = 0;
          // pto: %inner_freqs_sin__ssa_v0_pview
          ;
          const int64_t v169 = 64;
          // pto: %inner_freqs_sin__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 1, 64> v170 = pto::Shape<1, 1, 1, 1, 64>();
          // pto: %inner_freqs_sin__ssa_v0_pview
          ;
          pto::Stride<64, 64, 64, 64, 1> v171 = pto::Stride<64, 64, 64, 64, 1>();
          // pto: %inner_freqs_sin__ssa_v0_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v172 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v167 + (v168 + v158 * v169), v170, v171);
          TLOAD(v165, v172);
        };
      };
    };
    // pto: %cos_b_inline704_inline4848__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v173 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %cos_b_inline704_inline4848__ssa_v0
    ;
    uint64_t v174 = (uint64_t) v24;
    TASSIGN(v173, v174);
    // pto: %sin_b_inline691_inline4873__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %sin_b_inline691_inline4873__ssa_v0
    ;
    uint64_t v176 = (uint64_t) v25;
    TASSIGN(v175, v176);
    // pto: %kv_rms_low_inline689_inline4834__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %kv_rms_low_inline689_inline4834__tile
    ;
    uint64_t v178 = (uint64_t) v21;
    TASSIGN(v177, v178);
    // pto: %46
    ;
    int64_t v179 = v138 < v41 ? v41 : v138;
    // pto: %pooled_kv_inline4853__rv_v2_pview
    ;
    __gm__ float* v180 = PTOAS__GLOBAL_TENSOR_DATA(v82);
    // pto: %pooled_kv_inline4853__rv_v2_pview
    ;
    const int64_t v181 = 0;
    // pto: %pooled_kv_inline4853__rv_v2_pview
    ;
    const int64_t v182 = 128;
    // pto: %pooled_kv_inline4853__rv_v2_pview
    ;
    pto::Shape<1, 1, 1, 16, 64> v183 = pto::Shape<1, 1, 1, 16, 64>();
    // pto: %pooled_kv_inline4853__rv_v2_pview
    ;
    pto::Stride<2048, 2048, 2048, 128, 1> v184 = pto::Stride<2048, 2048, 2048, 128, 1>();
    // pto: %pooled_kv_inline4853__rv_v2_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<2048, 2048, 2048, 128, 1>, pto::Layout::ND> v185 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<2048, 2048, 2048, 128, 1>, pto::Layout::ND>(v180 + (v181 + v179 * v182), v183, v184);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    TLOAD(v177, v185);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %kv_rms_high_inline770_inline4809__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v186 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %kv_rms_high_inline770_inline4809__tile
    ;
    uint64_t v187 = (uint64_t) v26;
    TASSIGN(v186, v187);
    // pto: %48
    ;
    __gm__ float* v188 = PTOAS__GLOBAL_TENSOR_DATA(v82);
    // pto: %48
    ;
    const int64_t v189 = 64;
    // pto: %48
    ;
    const int64_t v190 = 128;
    // pto: %48
    ;
    pto::Shape<1, 1, 1, 16, 64> v191 = pto::Shape<1, 1, 1, 16, 64>();
    // pto: %48
    ;
    pto::Stride<2048, 2048, 2048, 128, 1> v192 = pto::Stride<2048, 2048, 2048, 128, 1>();
    // pto: %48
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<2048, 2048, 2048, 128, 1>, pto::Layout::ND> v193 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<2048, 2048, 2048, 128, 1>, pto::Layout::ND>(v188 + (v189 + v179 * v190), v191, v192);
    TLOAD(v186, v193);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %7
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v194 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %7
    ;
    uint64_t v195 = (uint64_t) v21;
    TASSIGN(v194, v195);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TMUL(v194, v177, v177);
    // pto: %8
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v196 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %8
    ;
    uint64_t v197 = (uint64_t) v26;
    TASSIGN(v196, v197);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    TMUL(v196, v186, v186);
    // pto: %folded_sq_inline687_inline4827__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v198 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %folded_sq_inline687_inline4827__tile
    ;
    uint64_t v199 = (uint64_t) v26;
    TASSIGN(v198, v199);
    pipe_barrier(PIPE_V);
    TADD(v198, v194, v196);
    // pto: %tmp_tile
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v200 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v31);
    // pto: %tmp_tile
    ;
    uint64_t v201 = (uint64_t) v21;
    TASSIGN(v200, v201);
    // pto: %square_sum_inline724_inline4860__tile
    ;
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v202 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v32);
    // pto: %square_sum_inline724_inline4860__tile
    ;
    uint64_t v203 = (uint64_t) v27;
    TASSIGN(v202, v203);
    pipe_barrier(PIPE_V);
    TROWSUM(v202, v198, v200);
    // pto: %t__rm_a0_tmp_v0
    ;
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v204 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v34);
    // pto: %t__rm_a0_tmp_v0
    ;
    uint64_t v205 = (uint64_t) v27;
    TASSIGN(v204, v205);
    // pto: %t__row_major_tmp_v1
    ;
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v206 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v34);
    // pto: %t__row_major_tmp_v1
    ;
    uint64_t v207 = (uint64_t) v21;
    TASSIGN(v206, v207);
    pipe_barrier(PIPE_V);
    TMULS(v206, v204, v44);
    // pto: %9
    ;
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v208 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v32);
    // pto: %9
    ;
    uint64_t v209 = (uint64_t) v21;
    TASSIGN(v208, v209);
    // pto: %variance_inline737_inline4823__rm_a0_tmp_v2
    ;
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v210 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v34);
    // pto: %variance_inline737_inline4823__rm_a0_tmp_v2
    ;
    uint64_t v211 = (uint64_t) v21;
    TASSIGN(v210, v211);
    // pto: %variance_inline737_inline4823__row_major_tmp_v3
    ;
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v212 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v34);
    // pto: %variance_inline737_inline4823__row_major_tmp_v3
    ;
    uint64_t v213 = (uint64_t) v21;
    TASSIGN(v212, v213);
    pipe_barrier(PIPE_V);
    TADDS(v212, v210, v45);
    // pto: %variance_inline737_inline4823__tile
    ;
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v214 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v32);
    // pto: %variance_inline737_inline4823__tile
    ;
    uint64_t v215 = (uint64_t) v21;
    TASSIGN(v214, v215);
    // pto: %rms_inline685_inline4820__rm_a0_tmp_v4
    ;
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v216 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v34);
    // pto: %rms_inline685_inline4820__rm_a0_tmp_v4
    ;
    uint64_t v217 = (uint64_t) v21;
    TASSIGN(v216, v217);
    // pto: %rms_inline685_inline4820__row_major_tmp_v5
    ;
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v34);
    // pto: %rms_inline685_inline4820__row_major_tmp_v5
    ;
    uint64_t v219 = (uint64_t) v28;
    TASSIGN(v218, v219);
    pipe_barrier(PIPE_V);
    TSQRT(v218, v216);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    // pto: %rms_inline685_inline4820__tile
    ;
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v32);
    // pto: %rms_inline685_inline4820__tile
    ;
    uint64_t v221 = (uint64_t) v28;
    TASSIGN(v220, v221);
    // pto: %kv_norm_chunk_inline764_inline4808__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v222 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %kv_norm_chunk_inline764_inline4808__tile
    ;
    uint64_t v223 = (uint64_t) v21;
    TASSIGN(v222, v223);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    TLOAD(v222, v185);
    // pto: %10
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v224 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
    // pto: %10
    ;
    uint64_t v225 = (uint64_t) v27;
    TASSIGN(v224, v225);
    // pto: %norm_w_2d_inline733_inline4817__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v226 = PTOAS__GLOBAL_TENSOR_DATA(v90);
    // pto: %norm_w_2d_inline733_inline4817__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 64> v227 = pto::Shape<1, 1, 1, 1, 64>();
    // pto: %norm_w_2d_inline733_inline4817__ssa_v0_pview
    ;
    pto::Stride<128, 128, 128, 128, 1> v228 = pto::Stride<128, 128, 128, 128, 1>();
    // pto: %norm_w_2d_inline733_inline4817__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v229 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v226, v227, v228);
    TLOAD(v224, v229);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    // pto: %gamma_inline684_inline4807__tile
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v230 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
    // pto: %gamma_inline684_inline4807__tile
    ;
    uint64_t v231 = (uint64_t) v26;
    TASSIGN(v230, v231);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    RoundMode v232 = RoundMode::CAST_ROUND;
    SaturationMode v233 = SaturationMode::ON;
    TCVT(v230, v224, v232, v233);
    // pto: %11
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v234 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %11
    ;
    uint64_t v235 = (uint64_t) v21;
    TASSIGN(v234, v235);
    TROWEXPANDDIV(v234, v222, v220);
    // pto: %normed_chunk_inline683_inline4806__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v236 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %normed_chunk_inline683_inline4806__tile
    ;
    uint64_t v237 = (uint64_t) v21;
    TASSIGN(v236, v237);
    pipe_barrier(PIPE_V);
    TCOLEXPANDMUL(v236, v234, v230);
    // pto: %normed_nope_inline682_inline4805__tile
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v238 = Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %normed_nope_inline682_inline4805__tile
    ;
    uint64_t v239 = (uint64_t) v29;
    TASSIGN(v238, v239);
    pipe_barrier(PIPE_V);
    RoundMode v240 = RoundMode::CAST_RINT;
    SaturationMode v241 = SaturationMode::ON;
    TCVT(v238, v236, v240, v241);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    // pto: %kv_rope_norm_inline767_inline4804__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v242 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %kv_rope_norm_inline767_inline4804__tile
    ;
    uint64_t v243 = (uint64_t) v21;
    TASSIGN(v242, v243);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    TLOAD(v242, v193);
    // pto: %12
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v244 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
    // pto: %12
    ;
    uint64_t v245 = (uint64_t) v27;
    TASSIGN(v244, v245);
    // pto: %53
    ;
    __gm__ bfloat16_t* v246 = PTOAS__GLOBAL_TENSOR_DATA(v90);
    // pto: %53
    ;
    unsigned v247 = 64;
    // pto: %53
    ;
    pto::Shape<1, 1, 1, 1, 64> v248 = pto::Shape<1, 1, 1, 1, 64>();
    // pto: %53
    ;
    pto::Stride<128, 128, 128, 128, 1> v249 = pto::Stride<128, 128, 128, 128, 1>();
    // pto: %53
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v250 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v246 + v247, v248, v249);
    TLOAD(v244, v250);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    // pto: %gamma_rope_inline711_inline4854__tile
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v251 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
    // pto: %gamma_rope_inline711_inline4854__tile
    ;
    uint64_t v252 = (uint64_t) v26;
    TASSIGN(v251, v252);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    RoundMode v253 = RoundMode::CAST_ROUND;
    SaturationMode v254 = SaturationMode::ON;
    TCVT(v251, v244, v253, v254);
    // pto: %13
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v255 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %13
    ;
    uint64_t v256 = (uint64_t) v21;
    TASSIGN(v255, v256);
    TROWEXPANDDIV(v255, v242, v220);
    // pto: %rope_normed_inline681_inline4803__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v257 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %rope_normed_inline681_inline4803__tile
    ;
    uint64_t v258 = (uint64_t) v21;
    TASSIGN(v257, v258);
    pipe_barrier(PIPE_V);
    TCOLEXPANDMUL(v257, v255, v251);
    // pto: %gather_acc_init
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v259 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %gather_acc_init
    ;
    uint64_t v260 = (uint64_t) v26;
    TASSIGN(v259, v260);
    for (int64_t v261 = v41; v261 < v34; v261 += v32) {
      // pto: %gather_inp_row
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v262 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
      // pto: %gather_inp_row
      ;
      uint64_t v263 = (uint64_t) v21;
      TASSIGN(v262, v263);
      // pto: %slice_view
      ;
      int64_t v264 = (int64_t) ((uint64_t) v261 * (uint64_t) v20);
      // pto: %slice_view
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v265;
      // pto: %slice_view
      ;
      uint64_t v266 = (uint64_t) ((int64_t) (uint64_t) v264 + (uint64_t) v21);
      TASSIGN(v265, v266);
      // pto: %gather_idx_row
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v267 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
      // pto: %gather_idx_row
      ;
      uint64_t v268 = (uint64_t) v23;
      TASSIGN(v267, v268);
      // pto: %54
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v269;
      // pto: %54
      ;
      uint64_t v270 = (uint64_t) ((int64_t) (uint64_t) v264 + (uint64_t) v23);
      TASSIGN(v269, v270);
      // pto: %gather_row_tmp
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v271 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
      // pto: %gather_row_tmp
      ;
      uint64_t v272 = (uint64_t) v27;
      TASSIGN(v271, v272);
      // pto: %gather_row
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v273 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
      // pto: %gather_row
      ;
      uint64_t v274 = (uint64_t) v28;
      TASSIGN(v273, v274);
      pipe_barrier(PIPE_V);
      TGATHER(v273, v265, v269, v271);
      // pto: %assemble_view
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v275;
      // pto: %assemble_view
      ;
      uint64_t v276 = (uint64_t) ((int64_t) (uint64_t) v264 + (uint64_t) v26);
      TASSIGN(v275, v276);
      pipe_barrier(PIPE_V);
      TMOV(v275, v273);
    };
    // pto: %swapped_inline688_inline4801__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v277 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %swapped_inline688_inline4801__tile
    ;
    uint64_t v278 = (uint64_t) v26;
    TASSIGN(v277, v278);
    // pto: %14
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v279 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %14
    ;
    uint64_t v280 = (uint64_t) v27;
    TASSIGN(v279, v280);
    TMULS(v279, v125, v39);
    // pto: %15
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v281 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %15
    ;
    uint64_t v282 = (uint64_t) v27;
    TASSIGN(v281, v282);
    pipe_barrier(PIPE_V);
    TSUBS(v281, v279, v35);
    // pto: %sin_signed_inline680_inline4800__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v283 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %sin_signed_inline680_inline4800__tile
    ;
    uint64_t v284 = (uint64_t) v25;
    TASSIGN(v283, v284);
    pipe_barrier(PIPE_V);
    TMUL(v283, v175, v281);
    // pto: %16
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v285 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %16
    ;
    uint64_t v286 = (uint64_t) v21;
    TASSIGN(v285, v286);
    TMUL(v285, v257, v173);
    // pto: %17
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v287 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %17
    ;
    uint64_t v288 = (uint64_t) v24;
    TASSIGN(v287, v288);
    pipe_barrier(PIPE_V);
    TMUL(v287, v277, v283);
    // pto: %rope_rot_inline679_inline4862__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v289 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %rope_rot_inline679_inline4862__tile
    ;
    uint64_t v290 = (uint64_t) v21;
    TASSIGN(v289, v290);
    pipe_barrier(PIPE_V);
    TADD(v289, v285, v287);
    // pto: %normed_rope_inline715_inline4802__tile
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v291 = Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %normed_rope_inline715_inline4802__tile
    ;
    uint64_t v292 = (uint64_t) v21;
    TASSIGN(v291, v292);
    pipe_barrier(PIPE_V);
    RoundMode v293 = RoundMode::CAST_RINT;
    SaturationMode v294 = SaturationMode::ON;
    TCVT(v291, v289, v293, v294);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    for (int64_t v295 = v41; v295 < v140; v295 += v32) {
      // pto: %55
      ;
      int64_t v296 = (int64_t) ((uint64_t) v138 + (uint64_t) v295);
      // pto: %token_pos_inline755_inline4871__tile
      ;
      int64_t v297 = (v2)[v296];
      // pto: %56
      ;
      int32_t v298 = (v3)[v296];
      // pto: %59, %60
      ;
      int64_t v299 = (int64_t) ((uint64_t) v297 + (uint64_t) v42) % v43;
      // pto: %61, %62, %63
      ;
      int64_t v300 = v299 < v22 ? (int64_t) ((uint64_t) v299 + (uint64_t) v43) : v299;
      // pto: %57, %58, %64, %65
      ;
      if ((int64_t) v298 >= v41 & v300 == v22) {
        // pto: %66
        ;
        int32_t v301 = (v3)[v296];
        // pto: %67
        ;
        int64_t v302 = (int64_t) v301;
        // pto: %68
        ;
        int32_t v303 = (v9)[v302];
        // pto: %69
        ;
        int64_t v304 = (int64_t) v303;
        // pto: %first_pos_inline686_inline4895__tile
        ;
        int64_t v305 = (v2)[v304];
        // pto: %70
        ;
        int64_t v306 = v305 % v43;
        // pto: %71, %72, %73
        ;
        int64_t v307 = v306 < v22 ? (int64_t) ((uint64_t) v306 + (uint64_t) v43) : v306;
        // pto: %76, %80, %77, %78, %75, %79
        ;
        int64_t v308 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v302 * (uint64_t) v47) + (uint64_t) ((int64_t) ((uint64_t) ((int64_t) (uint64_t) v296 - (uint64_t) v304) - (uint64_t) ((int64_t) (uint64_t) v46 - (uint64_t) v307)) / v48));
        // pto: %18
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
        // pto: %18
        ;
        uint64_t v310 = (uint64_t) v29;
        TASSIGN(v309, v310);
        // pto: %81
        ;
        int64_t v311 = (int64_t) ((uint64_t) v295 * (uint64_t) v19);
        // pto: %81
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v312;
        // pto: %81
        ;
        uint64_t v313 = (uint64_t) ((int64_t) (uint64_t) v311 + (uint64_t) v29);
        TASSIGN(v312, v313);
        // pto: %82
        ;
        int64_t v314 = v308 < v41 ? v41 : v308;
        // pto: %normed_kv_inline970__iter_v4_pview
        ;
        __gm__ bfloat16_t* v315 = PTOAS__GLOBAL_TENSOR_DATA(v56);
        // pto: %normed_kv_inline970__iter_v4_pview
        ;
        const int64_t v316 = 0;
        // pto: %normed_kv_inline970__iter_v4_pview
        ;
        const int64_t v317 = 128;
        // pto: %normed_kv_inline970__iter_v4_pview
        ;
        pto::Shape<1, 1, 1, 1, 64> v318 = pto::Shape<1, 1, 1, 1, 64>();
        // pto: %normed_kv_inline970__iter_v4_pview
        ;
        pto::Stride<128, 128, 128, 128, 1> v319 = pto::Stride<128, 128, 128, 128, 1>();
        // pto: %normed_kv_inline970__iter_v4_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v320 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v315 + (v316 + v314 * v317), v318, v319);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v320, v312);
        // pto: %19
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v321 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
        // pto: %19
        ;
        uint64_t v322 = (uint64_t) v21;
        TASSIGN(v321, v322);
        // pto: %83
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v323;
        // pto: %83
        ;
        uint64_t v324 = (uint64_t) ((int64_t) (uint64_t) v311 + (uint64_t) v21);
        TASSIGN(v323, v324);
        // pto: %normed_kv_inline970__tile_pview
        ;
        __gm__ bfloat16_t* v325 = PTOAS__GLOBAL_TENSOR_DATA(v56);
        // pto: %normed_kv_inline970__tile_pview
        ;
        const int64_t v326 = 64;
        // pto: %normed_kv_inline970__tile_pview
        ;
        const int64_t v327 = 128;
        // pto: %normed_kv_inline970__tile_pview
        ;
        pto::Shape<1, 1, 1, 1, 64> v328 = pto::Shape<1, 1, 1, 1, 64>();
        // pto: %normed_kv_inline970__tile_pview
        ;
        pto::Stride<128, 128, 128, 128, 1> v329 = pto::Stride<128, 128, 128, 128, 1>();
        // pto: %normed_kv_inline970__tile_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v330 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v325 + (v326 + v314 * v327), v328, v329);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v330, v323);
      };
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}