#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_dequant_hcpost(__gm__ int32_t* v1, __gm__ float* v2, __gm__ float* v3, __gm__ bfloat16_t* v4, __gm__ float* v5, __gm__ float* v6, __gm__ bfloat16_t* v7, int64_t v8, int64_t v9, int64_t v10, int32_t v11, int32_t v12) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c98304_i64
  const int64_t v13 = 98304;
  // pto: %c114688_i64
  const int64_t v14 = 114688;
  // pto: %c16384_i64
  const int64_t v15 = 16384;
  // pto: %c32768_i64
  const int64_t v16 = 32768;
  // pto: %c49152_i64
  const int64_t v17 = 49152;
  // pto: %c65536_i64
  const int64_t v18 = 65536;
  // pto: %c0_i64
  const int64_t v19 = 0;
  // pto: %c81920_i64
  const int64_t v20 = 81920;
  // pto: %c90112_i64
  const int64_t v21 = 90112;
  // pto: %c4096_index
  const int64_t v22 = 4096;
  // pto: %c1_index
  const int64_t v23 = 1;
  // pto: %c16384_index
  const int64_t v24 = 16384;
  // pto: %c4_index
  const int64_t v25 = 4;
  // pto: %c16_index
  const int64_t v26 = 16;
  // pto: %c2_index
  const int64_t v27 = 2;
  // pto: %c0_index
  const int64_t v28 = 0;
  // pto: %c8_index
  const int64_t v29 = 8;
  // pto: %c12_index
  const int64_t v30 = 12;
  // pto: %c5_index
  const int64_t v31 = 5;
  // pto: %c9_index
  const int64_t v32 = 9;
  // pto: %c13_index
  const int64_t v33 = 13;
  // pto: %c6_index
  const int64_t v34 = 6;
  // pto: %c10_index
  const int64_t v35 = 10;
  // pto: %c14_index
  const int64_t v36 = 14;
  // pto: %c3_index
  const int64_t v37 = 3;
  // pto: %c7_index
  const int64_t v38 = 7;
  // pto: %c11_index
  const int64_t v39 = 11;
  // pto: %c15_index
  const int64_t v40 = 15;
  // pto: %cst_30
  const float v41 = 1.0f;
  // pto: %c63_index
  const int64_t v42 = 63;
  // pto: %405
  int64_t v43 = (int64_t) ((uint64_t) v9 + (uint64_t) v42);
  // pto: %integer_accum_inline1120__phi_v3_view
  const int64_t v44 = 1;
  // pto: %integer_accum_inline1120__phi_v3_view
  const int64_t v45 = 1;
  // pto: %integer_accum_inline1120__phi_v3_view
  const int64_t v46 = 1;
  // pto: %integer_accum_inline1120__phi_v3_view
  int64_t v47 = v43 * v22;
  // pto: %integer_accum_inline1120__phi_v3_view
  int64_t v48 = v46 * v47;
  // pto: %integer_accum_inline1120__phi_v3_view
  pto::Shape<1, 1, 1, -1, -1> v49 = pto::Shape<1, 1, 1, -1, -1>(v44, v45, v46, v43, v22);
  // pto: %integer_accum_inline1120__phi_v3_view
  pto::Stride<-1, -1, -1, -1, -1> v50 = pto::Stride<-1, -1, -1, -1, -1>(v45 * v48, v48, v47, v22, v23);
  // pto: %integer_accum_inline1120__phi_v3_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v51 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v49, v50);
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v52 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v53 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v54 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v55 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v56 = v22 * v23;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v57 = v55 * v56;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v58 = v54 * v57;
  // pto: %wo_b_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v59 = pto::Shape<1, 1, 1, 1, -1>(v52, v53, v54, v55, v22);
  // pto: %wo_b_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v60 = pto::Stride<-1, -1, -1, -1, -1>(v53 * v58, v58, v57, v56, v23);
  // pto: %wo_b_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v61 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v59, v60);
  // pto: %residual_flat_inline1086__ssa_v0_view
  const int64_t v62 = 1;
  // pto: %residual_flat_inline1086__ssa_v0_view
  const int64_t v63 = 1;
  // pto: %residual_flat_inline1086__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %residual_flat_inline1086__ssa_v0_view
  int64_t v65 = (int64_t) v9;
  // pto: %residual_flat_inline1086__ssa_v0_view
  int64_t v66 = v65 * v24;
  // pto: %residual_flat_inline1086__ssa_v0_view
  int64_t v67 = v64 * v66;
  // pto: %residual_flat_inline1086__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v68 = pto::Shape<1, 1, 1, -1, -1>(v62, v63, v64, v65, v24);
  // pto: %residual_flat_inline1086__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v69 = pto::Stride<-1, -1, -1, -1, -1>(v63 * v67, v67, v66, v24, v23);
  // pto: %residual_flat_inline1086__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v70 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v68, v69);
  // pto: %output_flat_inline1140__ssa_v0_view
  const int64_t v71 = 1;
  // pto: %output_flat_inline1140__ssa_v0_view
  const int64_t v72 = 1;
  // pto: %output_flat_inline1140__ssa_v0_view
  const int64_t v73 = 1;
  // pto: %output_flat_inline1140__ssa_v0_view
  int64_t v74 = (int64_t) v9;
  // pto: %output_flat_inline1140__ssa_v0_view
  int64_t v75 = v74 * v24;
  // pto: %output_flat_inline1140__ssa_v0_view
  int64_t v76 = v73 * v75;
  // pto: %output_flat_inline1140__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v77 = pto::Shape<1, 1, 1, -1, -1>(v71, v72, v73, v74, v24);
  // pto: %output_flat_inline1140__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v78 = pto::Stride<-1, -1, -1, -1, -1>(v72 * v76, v76, v75, v24, v23);
  // pto: %output_flat_inline1140__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v79 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v77, v78);
  // pto: %token_block_inline1131__ssa_v0, %124
  int64_t v80 = (int64_t) ((uint64_t) ((int64_t) v11) * (uint64_t) v25);
  // pto: %125
  int64_t v81 = (int64_t) ((uint64_t) v80 + (uint64_t) v25);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v82 = v80; v82 < v81; v82 += v27) {
    // pto: %126
    ;
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    if (v82 < v9) {
      // pto: %scale_inline996__tile
      ;
      float v83 = (v3)[v82];
      // pto: %127
      ;
      int64_t v84 = (int64_t) ((uint64_t) v82 * (uint64_t) v25);
      // pto: %post_scalar_inline1010__tile
      ;
      float v85 = (v5)[v84];
      // pto: %129
      ;
      int64_t v86 = (int64_t) ((uint64_t) v82 * (uint64_t) v26);
      // pto: %comb_scalar_0_inline1050__tile
      ;
      float v87 = (v6)[v86];
      // pto: %132, %comb_scalar_1_inline1021__tile
      ;
      float v88 = (v6)[(int64_t) ((uint64_t) v86 + (uint64_t) v25)];
      // pto: %134, %comb_scalar_2_inline986__tile
      ;
      float v89 = (v6)[(int64_t) ((uint64_t) v86 + (uint64_t) v29)];
      // pto: %136, %comb_scalar_3_inline984__tile
      ;
      float v90 = (v6)[(int64_t) ((uint64_t) v86 + (uint64_t) v30)];
      // pto: %139, %137
      ;
      float v91 = (v5)[(int64_t) ((uint64_t) v84 + (uint64_t) v23)];
      // pto: %142, %140
      ;
      float v92 = (v6)[(int64_t) ((uint64_t) v86 + (uint64_t) v23)];
      // pto: %145, %143
      ;
      float v93 = (v6)[(int64_t) ((uint64_t) v86 + (uint64_t) v31)];
      // pto: %148, %146
      ;
      float v94 = (v6)[(int64_t) ((uint64_t) v86 + (uint64_t) v32)];
      // pto: %151, %149
      ;
      float v95 = (v6)[(int64_t) ((uint64_t) v86 + (uint64_t) v33)];
      // pto: %154, %152
      ;
      float v96 = (v5)[(int64_t) ((uint64_t) v84 + (uint64_t) v27)];
      // pto: %157, %155
      ;
      float v97 = (v6)[(int64_t) ((uint64_t) v86 + (uint64_t) v27)];
      // pto: %160, %158
      ;
      float v98 = (v6)[(int64_t) ((uint64_t) v86 + (uint64_t) v34)];
      // pto: %163, %161
      ;
      float v99 = (v6)[(int64_t) ((uint64_t) v86 + (uint64_t) v35)];
      // pto: %166, %164
      ;
      float v100 = (v6)[(int64_t) ((uint64_t) v86 + (uint64_t) v36)];
      // pto: %169, %167
      ;
      float v101 = (v5)[(int64_t) ((uint64_t) v84 + (uint64_t) v37)];
      // pto: %172, %170
      ;
      float v102 = (v6)[(int64_t) ((uint64_t) v86 + (uint64_t) v37)];
      // pto: %175, %173
      ;
      float v103 = (v6)[(int64_t) ((uint64_t) v86 + (uint64_t) v38)];
      // pto: %178, %176
      ;
      float v104 = (v6)[(int64_t) ((uint64_t) v86 + (uint64_t) v39)];
      // pto: %181, %179
      ;
      float v105 = (v6)[(int64_t) ((uint64_t) v86 + (uint64_t) v40)];
      // pto: %ob_integer_inline999__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %ob_integer_inline999__ssa_v0
      ;
      uint64_t v107 = (uint64_t) v13;
      TASSIGN(v106, v107);
      // pto: %182
      ;
      int64_t v108 = v82 < v28 ? v28 : v82;
      // pto: %integer_accum_inline1120__phi_v3_pview
      ;
      __gm__ int32_t* v109 = PTOAS__GLOBAL_TENSOR_DATA(v51);
      // pto: %integer_accum_inline1120__phi_v3_pview
      ;
      const int64_t v110 = 0;
      // pto: %integer_accum_inline1120__phi_v3_pview
      ;
      const int64_t v111 = 4096;
      // pto: %integer_accum_inline1120__phi_v3_pview
      ;
      pto::Shape<1, 1, 1, 1, 4096> v112 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %integer_accum_inline1120__phi_v3_pview
      ;
      pto::Stride<4096, 4096, 4096, 4096, 1> v113 = pto::Stride<4096, 4096, 4096, 4096, 1>();
      // pto: %integer_accum_inline1120__phi_v3_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v114 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v109 + (v110 + v108 * v111), v112, v113);
      TLOAD(v106, v114);
      // pto: %t__tmp_v1033
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v115 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %t__tmp_v1033
      ;
      uint64_t v116 = (uint64_t) v14;
      TASSIGN(v115, v116);
      // pto: %wo_b_scale__ssa_v0_pview
      ;
      __gm__ float* v117 = PTOAS__GLOBAL_TENSOR_DATA(v61);
      // pto: %wo_b_scale__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 4096> v118 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %wo_b_scale__ssa_v0_pview
      ;
      pto::Stride<4096, 4096, 4096, 4096, 1> v119 = pto::Stride<4096, 4096, 4096, 4096, 1>();
      // pto: %wo_b_scale__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v120 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v117, v118, v119);
      TLOAD(v115, v120);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %t__tmp_v1035
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %t__tmp_v1035
      ;
      uint64_t v122 = (uint64_t) v15;
      TASSIGN(v121, v122);
      // pto: %residual_flat_inline1086__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v123 = PTOAS__GLOBAL_TENSOR_DATA(v70);
      // pto: %residual_flat_inline1086__ssa_v0_pview
      ;
      const int64_t v124 = 0;
      // pto: %residual_flat_inline1086__ssa_v0_pview
      ;
      const int64_t v125 = 16384;
      // pto: %residual_flat_inline1086__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 4096> v126 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %residual_flat_inline1086__ssa_v0_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v127 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %residual_flat_inline1086__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v128 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v123 + (v124 + v108 * v125), v126, v127);
      TLOAD(v121, v128);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %t__tmp_v1036
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %t__tmp_v1036
      ;
      uint64_t v130 = (uint64_t) v16;
      TASSIGN(v129, v130);
      // pto: %185
      ;
      __gm__ bfloat16_t* v131 = PTOAS__GLOBAL_TENSOR_DATA(v70);
      // pto: %185
      ;
      const int64_t v132 = 4096;
      // pto: %185
      ;
      const int64_t v133 = 16384;
      // pto: %185
      ;
      pto::Shape<1, 1, 1, 1, 4096> v134 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %185
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v135 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %185
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v136 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v131 + (v132 + v108 * v133), v134, v135);
      TLOAD(v129, v136);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %t__tmp_v1037
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %t__tmp_v1037
      ;
      uint64_t v138 = (uint64_t) v17;
      TASSIGN(v137, v138);
      // pto: %187
      ;
      __gm__ bfloat16_t* v139 = PTOAS__GLOBAL_TENSOR_DATA(v70);
      // pto: %187
      ;
      const int64_t v140 = 8192;
      // pto: %187
      ;
      const int64_t v141 = 16384;
      // pto: %187
      ;
      pto::Shape<1, 1, 1, 1, 4096> v142 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %187
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v143 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %187
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v144 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v139 + (v140 + v108 * v141), v142, v143);
      TLOAD(v137, v144);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %t__tmp_v1038
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v145 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %t__tmp_v1038
      ;
      uint64_t v146 = (uint64_t) v18;
      TASSIGN(v145, v146);
      // pto: %189
      ;
      __gm__ bfloat16_t* v147 = PTOAS__GLOBAL_TENSOR_DATA(v70);
      // pto: %189
      ;
      const int64_t v148 = 12288;
      // pto: %189
      ;
      const int64_t v149 = 16384;
      // pto: %189
      ;
      pto::Shape<1, 1, 1, 1, 4096> v150 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %189
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v151 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %189
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v152 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v147 + (v148 + v108 * v149), v150, v151);
      TLOAD(v145, v152);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      // pto: %channel_inline998__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v153 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %channel_inline998__ssa_v0
      ;
      uint64_t v154 = (uint64_t) v14;
      TASSIGN(v153, v154);
      // pto: %coefficient_one_inline1092__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v155 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %coefficient_one_inline1092__ssa_v0
      ;
      uint64_t v156 = (uint64_t) v19;
      TASSIGN(v155, v156);
      TEXPANDS(v155, v41);
      // pto: %coefficient_channel_inline1125__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %coefficient_channel_inline1125__ssa_v0
      ;
      uint64_t v158 = (uint64_t) v19;
      TASSIGN(v157, v158);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      TCOLEXPANDMUL(v157, v155, v153);
      // pto: %coefficient_inline1019__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v159 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %coefficient_inline1019__ssa_v0
      ;
      uint64_t v160 = (uint64_t) v14;
      TASSIGN(v159, v160);
      pipe_barrier(PIPE_V);
      TMULS(v159, v157, v83);
      // pto: %t__tmp_v1034
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v161 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %t__tmp_v1034
      ;
      uint64_t v162 = (uint64_t) v13;
      TASSIGN(v161, v162);
      RoundMode v163 = RoundMode::CAST_ROUND;
      SaturationMode v164 = SaturationMode::ON;
      TCVT(v161, v106, v163, v164);
      // pto: %ob_scaled_inline1106__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v165 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %ob_scaled_inline1106__ssa_v0
      ;
      uint64_t v166 = (uint64_t) v13;
      TASSIGN(v165, v166);
      pipe_barrier(PIPE_V);
      TMUL(v165, v161, v159);
      // pto: %attended_bf16_inline1022__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v167 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %attended_bf16_inline1022__ssa_v0
      ;
      uint64_t v168 = (uint64_t) v14;
      TASSIGN(v167, v168);
      pipe_barrier(PIPE_V);
      RoundMode v169 = RoundMode::CAST_RINT;
      SaturationMode v170 = SaturationMode::ON;
      TCVT(v167, v165, v169, v170);
      // pto: %x_f32_inline995__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v171 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %x_f32_inline995__ssa_v0
      ;
      uint64_t v172 = (uint64_t) v13;
      TASSIGN(v171, v172);
      pipe_barrier(PIPE_V);
      RoundMode v173 = RoundMode::CAST_ROUND;
      SaturationMode v174 = SaturationMode::ON;
      TCVT(v171, v167, v173, v174);
      // pto: %res_0_inline994__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %res_0_inline994__ssa_v0
      ;
      uint64_t v176 = (uint64_t) v14;
      TASSIGN(v175, v176);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      RoundMode v177 = RoundMode::CAST_ROUND;
      SaturationMode v178 = SaturationMode::ON;
      TCVT(v175, v121, v177, v178);
      // pto: %res_1_inline1005__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v179 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %res_1_inline1005__ssa_v0
      ;
      uint64_t v180 = (uint64_t) v19;
      TASSIGN(v179, v180);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      RoundMode v181 = RoundMode::CAST_ROUND;
      SaturationMode v182 = SaturationMode::ON;
      TCVT(v179, v129, v181, v182);
      // pto: %res_2_inline993__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %res_2_inline993__ssa_v0
      ;
      uint64_t v184 = (uint64_t) v15;
      TASSIGN(v183, v184);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      RoundMode v185 = RoundMode::CAST_ROUND;
      SaturationMode v186 = SaturationMode::ON;
      TCVT(v183, v137, v185, v186);
      // pto: %res_3_inline991__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v187 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %res_3_inline991__ssa_v0
      ;
      uint64_t v188 = (uint64_t) v16;
      TASSIGN(v187, v188);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      RoundMode v189 = RoundMode::CAST_ROUND;
      SaturationMode v190 = SaturationMode::ON;
      TCVT(v187, v145, v189, v190);
      // pto: %single_y_inline997__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v191 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_y_inline997__ssa_v0
      ;
      uint64_t v192 = (uint64_t) v17;
      TASSIGN(v191, v192);
      pipe_barrier(PIPE_V);
      TMULS(v191, v171, v85);
      // pto: %single_weighted_0_inline990__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v193 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_weighted_0_inline990__ssa_v0
      ;
      uint64_t v194 = (uint64_t) v18;
      TASSIGN(v193, v194);
      TMULS(v193, v175, v87);
      // pto: %single_y_v1_inline989__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v195 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_y_v1_inline989__ssa_v0
      ;
      uint64_t v196 = (uint64_t) v17;
      TASSIGN(v195, v196);
      pipe_barrier(PIPE_V);
      TADD(v195, v191, v193);
      // pto: %single_weighted_1_inline988__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v197 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_weighted_1_inline988__ssa_v0
      ;
      uint64_t v198 = (uint64_t) v18;
      TASSIGN(v197, v198);
      pipe_barrier(PIPE_V);
      TMULS(v197, v179, v88);
      // pto: %single_y_v2_inline987__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v199 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_y_v2_inline987__ssa_v0
      ;
      uint64_t v200 = (uint64_t) v17;
      TASSIGN(v199, v200);
      pipe_barrier(PIPE_V);
      TADD(v199, v195, v197);
      // pto: %single_weighted_2_inline1088__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v201 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_weighted_2_inline1088__ssa_v0
      ;
      uint64_t v202 = (uint64_t) v18;
      TASSIGN(v201, v202);
      pipe_barrier(PIPE_V);
      TMULS(v201, v183, v89);
      // pto: %single_y_v3_inline985__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v203 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_y_v3_inline985__ssa_v0
      ;
      uint64_t v204 = (uint64_t) v17;
      TASSIGN(v203, v204);
      pipe_barrier(PIPE_V);
      TADD(v203, v199, v201);
      // pto: %single_weighted_3_inline992__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v205 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_weighted_3_inline992__ssa_v0
      ;
      uint64_t v206 = (uint64_t) v18;
      TASSIGN(v205, v206);
      pipe_barrier(PIPE_V);
      TMULS(v205, v187, v90);
      // pto: %single_y_v4_inline983__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_y_v4_inline983__ssa_v0
      ;
      uint64_t v208 = (uint64_t) v17;
      TASSIGN(v207, v208);
      pipe_barrier(PIPE_V);
      TADD(v207, v203, v205);
      // pto: %single_result_inline1117__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v209 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_result_inline1117__ssa_v0
      ;
      uint64_t v210 = (uint64_t) v20;
      TASSIGN(v209, v210);
      pipe_barrier(PIPE_V);
      RoundMode v211 = RoundMode::CAST_RINT;
      SaturationMode v212 = SaturationMode::ON;
      TCVT(v209, v207, v211, v212);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      v209.SetValidShape(v23, v22);
      // pto: %single_y_inline997__ssa_v1
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v213 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_y_inline997__ssa_v1
      ;
      uint64_t v214 = (uint64_t) v17;
      TASSIGN(v213, v214);
      pipe_barrier(PIPE_V);
      TMULS(v213, v171, v91);
      // pto: %single_weighted_0_inline990__ssa_v1
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_weighted_0_inline990__ssa_v1
      ;
      uint64_t v216 = (uint64_t) v18;
      TASSIGN(v215, v216);
      TMULS(v215, v175, v92);
      // pto: %single_y_v1_inline989__ssa_v1
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_y_v1_inline989__ssa_v1
      ;
      uint64_t v218 = (uint64_t) v17;
      TASSIGN(v217, v218);
      pipe_barrier(PIPE_V);
      TADD(v217, v213, v215);
      // pto: %single_weighted_1_inline988__ssa_v1
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v219 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_weighted_1_inline988__ssa_v1
      ;
      uint64_t v220 = (uint64_t) v18;
      TASSIGN(v219, v220);
      pipe_barrier(PIPE_V);
      TMULS(v219, v179, v93);
      // pto: %single_y_v2_inline987__ssa_v1
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v221 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_y_v2_inline987__ssa_v1
      ;
      uint64_t v222 = (uint64_t) v17;
      TASSIGN(v221, v222);
      pipe_barrier(PIPE_V);
      TADD(v221, v217, v219);
      // pto: %single_weighted_2_inline1088__ssa_v1
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v223 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_weighted_2_inline1088__ssa_v1
      ;
      uint64_t v224 = (uint64_t) v18;
      TASSIGN(v223, v224);
      pipe_barrier(PIPE_V);
      TMULS(v223, v183, v94);
      // pto: %single_y_v3_inline985__ssa_v1
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v225 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_y_v3_inline985__ssa_v1
      ;
      uint64_t v226 = (uint64_t) v17;
      TASSIGN(v225, v226);
      pipe_barrier(PIPE_V);
      TADD(v225, v221, v223);
      // pto: %single_weighted_3_inline992__ssa_v1
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v227 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_weighted_3_inline992__ssa_v1
      ;
      uint64_t v228 = (uint64_t) v18;
      TASSIGN(v227, v228);
      pipe_barrier(PIPE_V);
      TMULS(v227, v187, v95);
      // pto: %single_y_v4_inline983__ssa_v1
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v229 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_y_v4_inline983__ssa_v1
      ;
      uint64_t v230 = (uint64_t) v17;
      TASSIGN(v229, v230);
      pipe_barrier(PIPE_V);
      TADD(v229, v225, v227);
      // pto: %single_result_inline1117__ssa_v1
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v231 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_result_inline1117__ssa_v1
      ;
      uint64_t v232 = (uint64_t) v21;
      TASSIGN(v231, v232);
      pipe_barrier(PIPE_V);
      RoundMode v233 = RoundMode::CAST_RINT;
      SaturationMode v234 = SaturationMode::ON;
      TCVT(v231, v229, v233, v234);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      v231.SetValidShape(v23, v22);
      // pto: %single_y_inline997__ssa_v2
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v235 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_y_inline997__ssa_v2
      ;
      uint64_t v236 = (uint64_t) v17;
      TASSIGN(v235, v236);
      pipe_barrier(PIPE_V);
      TMULS(v235, v171, v96);
      // pto: %single_weighted_0_inline990__ssa_v2
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v237 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_weighted_0_inline990__ssa_v2
      ;
      uint64_t v238 = (uint64_t) v18;
      TASSIGN(v237, v238);
      TMULS(v237, v175, v97);
      // pto: %single_y_v1_inline989__ssa_v2
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v239 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_y_v1_inline989__ssa_v2
      ;
      uint64_t v240 = (uint64_t) v17;
      TASSIGN(v239, v240);
      pipe_barrier(PIPE_V);
      TADD(v239, v235, v237);
      // pto: %single_weighted_1_inline988__ssa_v2
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v241 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_weighted_1_inline988__ssa_v2
      ;
      uint64_t v242 = (uint64_t) v18;
      TASSIGN(v241, v242);
      pipe_barrier(PIPE_V);
      TMULS(v241, v179, v98);
      // pto: %single_y_v2_inline987__ssa_v2
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v243 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_y_v2_inline987__ssa_v2
      ;
      uint64_t v244 = (uint64_t) v17;
      TASSIGN(v243, v244);
      pipe_barrier(PIPE_V);
      TADD(v243, v239, v241);
      // pto: %single_weighted_2_inline1088__ssa_v2
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v245 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_weighted_2_inline1088__ssa_v2
      ;
      uint64_t v246 = (uint64_t) v18;
      TASSIGN(v245, v246);
      pipe_barrier(PIPE_V);
      TMULS(v245, v183, v99);
      // pto: %single_y_v3_inline985__ssa_v2
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v247 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_y_v3_inline985__ssa_v2
      ;
      uint64_t v248 = (uint64_t) v17;
      TASSIGN(v247, v248);
      pipe_barrier(PIPE_V);
      TADD(v247, v243, v245);
      // pto: %single_weighted_3_inline992__ssa_v2
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v249 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_weighted_3_inline992__ssa_v2
      ;
      uint64_t v250 = (uint64_t) v18;
      TASSIGN(v249, v250);
      pipe_barrier(PIPE_V);
      TMULS(v249, v187, v100);
      // pto: %single_y_v4_inline983__ssa_v2
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v251 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_y_v4_inline983__ssa_v2
      ;
      uint64_t v252 = (uint64_t) v17;
      TASSIGN(v251, v252);
      pipe_barrier(PIPE_V);
      TADD(v251, v247, v249);
      // pto: %single_result_inline1117__ssa_v2
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v253 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_result_inline1117__ssa_v2
      ;
      uint64_t v254 = (uint64_t) v17;
      TASSIGN(v253, v254);
      pipe_barrier(PIPE_V);
      RoundMode v255 = RoundMode::CAST_RINT;
      SaturationMode v256 = SaturationMode::ON;
      TCVT(v253, v251, v255, v256);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      v253.SetValidShape(v23, v22);
      // pto: %single_y_inline997__ssa_v3
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v257 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_y_inline997__ssa_v3
      ;
      uint64_t v258 = (uint64_t) v13;
      TASSIGN(v257, v258);
      TMULS(v257, v171, v101);
      // pto: %single_weighted_0_inline990__ssa_v3
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v259 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_weighted_0_inline990__ssa_v3
      ;
      uint64_t v260 = (uint64_t) v14;
      TASSIGN(v259, v260);
      TMULS(v259, v175, v102);
      // pto: %single_y_v1_inline989__ssa_v3
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v261 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_y_v1_inline989__ssa_v3
      ;
      uint64_t v262 = (uint64_t) v13;
      TASSIGN(v261, v262);
      pipe_barrier(PIPE_V);
      TADD(v261, v257, v259);
      // pto: %single_weighted_1_inline988__ssa_v3
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v263 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_weighted_1_inline988__ssa_v3
      ;
      uint64_t v264 = (uint64_t) v14;
      TASSIGN(v263, v264);
      pipe_barrier(PIPE_V);
      TMULS(v263, v179, v103);
      // pto: %single_y_v2_inline987__ssa_v3
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v265 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_y_v2_inline987__ssa_v3
      ;
      uint64_t v266 = (uint64_t) v13;
      TASSIGN(v265, v266);
      pipe_barrier(PIPE_V);
      TADD(v265, v261, v263);
      // pto: %single_weighted_2_inline1088__ssa_v3
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v267 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_weighted_2_inline1088__ssa_v3
      ;
      uint64_t v268 = (uint64_t) v14;
      TASSIGN(v267, v268);
      pipe_barrier(PIPE_V);
      TMULS(v267, v183, v104);
      // pto: %single_y_v3_inline985__ssa_v3
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v269 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_y_v3_inline985__ssa_v3
      ;
      uint64_t v270 = (uint64_t) v13;
      TASSIGN(v269, v270);
      pipe_barrier(PIPE_V);
      TADD(v269, v265, v267);
      // pto: %single_weighted_3_inline992__ssa_v3
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v271 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_weighted_3_inline992__ssa_v3
      ;
      uint64_t v272 = (uint64_t) v14;
      TASSIGN(v271, v272);
      pipe_barrier(PIPE_V);
      TMULS(v271, v187, v105);
      // pto: %single_y_v4_inline983__ssa_v3
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v273 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_y_v4_inline983__ssa_v3
      ;
      uint64_t v274 = (uint64_t) v13;
      TASSIGN(v273, v274);
      pipe_barrier(PIPE_V);
      TADD(v273, v269, v271);
      // pto: %single_result_inline1117__ssa_v3
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v275 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %single_result_inline1117__ssa_v3
      ;
      uint64_t v276 = (uint64_t) v13;
      TASSIGN(v275, v276);
      pipe_barrier(PIPE_V);
      RoundMode v277 = RoundMode::CAST_RINT;
      SaturationMode v278 = SaturationMode::ON;
      TCVT(v275, v273, v277, v278);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      v275.SetValidShape(v23, v22);
      // pto: %output_flat_inline1140__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v279 = PTOAS__GLOBAL_TENSOR_DATA(v79);
      // pto: %output_flat_inline1140__ssa_v0_pview
      ;
      const int64_t v280 = 0;
      // pto: %output_flat_inline1140__ssa_v0_pview
      ;
      const int64_t v281 = 16384;
      // pto: %output_flat_inline1140__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 4096> v282 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %output_flat_inline1140__ssa_v0_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v283 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %output_flat_inline1140__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v284 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v279 + (v280 + v108 * v281), v282, v283);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v284, v209);
      // pto: %192
      ;
      __gm__ bfloat16_t* v285 = PTOAS__GLOBAL_TENSOR_DATA(v79);
      // pto: %192
      ;
      const int64_t v286 = 4096;
      // pto: %192
      ;
      const int64_t v287 = 16384;
      // pto: %192
      ;
      pto::Shape<1, 1, 1, 1, 4096> v288 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %192
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v289 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %192
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v290 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v285 + (v286 + v108 * v287), v288, v289);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      TSTORE(v290, v231);
      // pto: %194
      ;
      __gm__ bfloat16_t* v291 = PTOAS__GLOBAL_TENSOR_DATA(v79);
      // pto: %194
      ;
      const int64_t v292 = 8192;
      // pto: %194
      ;
      const int64_t v293 = 16384;
      // pto: %194
      ;
      pto::Shape<1, 1, 1, 1, 4096> v294 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %194
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v295 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %194
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v296 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v291 + (v292 + v108 * v293), v294, v295);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      TSTORE(v296, v253);
      // pto: %196
      ;
      __gm__ bfloat16_t* v297 = PTOAS__GLOBAL_TENSOR_DATA(v79);
      // pto: %196
      ;
      const int64_t v298 = 12288;
      // pto: %196
      ;
      const int64_t v299 = 16384;
      // pto: %196
      ;
      pto::Shape<1, 1, 1, 1, 4096> v300 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %196
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v301 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %196
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v302 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v297 + (v298 + v108 * v299), v300, v301);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      TSTORE(v302, v275);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    // pto: %197
    ;
    int64_t v303 = (int64_t) ((uint64_t) v82 + (uint64_t) v23);
    // pto: %198
    ;
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    if (v303 < v9) {
      // pto: %199
      ;
      float v304 = (v3)[v303];
      // pto: %205
      ;
      int64_t v305 = (int64_t) ((uint64_t) v303 * (uint64_t) v25);
      // pto: %203
      ;
      float v306 = (v5)[v305];
      // pto: %209
      ;
      int64_t v307 = (int64_t) ((uint64_t) v303 * (uint64_t) v26);
      // pto: %207
      ;
      float v308 = (v6)[v307];
      // pto: %214, %211
      ;
      float v309 = (v6)[(int64_t) ((uint64_t) v307 + (uint64_t) v25)];
      // pto: %218, %215
      ;
      float v310 = (v6)[(int64_t) ((uint64_t) v307 + (uint64_t) v29)];
      // pto: %222, %219
      ;
      float v311 = (v6)[(int64_t) ((uint64_t) v307 + (uint64_t) v30)];
      // pto: %226, %223
      ;
      float v312 = (v5)[(int64_t) ((uint64_t) v305 + (uint64_t) v23)];
      // pto: %230, %227
      ;
      float v313 = (v6)[(int64_t) ((uint64_t) v307 + (uint64_t) v23)];
      // pto: %234, %231
      ;
      float v314 = (v6)[(int64_t) ((uint64_t) v307 + (uint64_t) v31)];
      // pto: %238, %235
      ;
      float v315 = (v6)[(int64_t) ((uint64_t) v307 + (uint64_t) v32)];
      // pto: %242, %239
      ;
      float v316 = (v6)[(int64_t) ((uint64_t) v307 + (uint64_t) v33)];
      // pto: %246, %243
      ;
      float v317 = (v5)[(int64_t) ((uint64_t) v305 + (uint64_t) v27)];
      // pto: %250, %247
      ;
      float v318 = (v6)[(int64_t) ((uint64_t) v307 + (uint64_t) v27)];
      // pto: %254, %251
      ;
      float v319 = (v6)[(int64_t) ((uint64_t) v307 + (uint64_t) v34)];
      // pto: %258, %255
      ;
      float v320 = (v6)[(int64_t) ((uint64_t) v307 + (uint64_t) v35)];
      // pto: %262, %259
      ;
      float v321 = (v6)[(int64_t) ((uint64_t) v307 + (uint64_t) v36)];
      // pto: %266, %263
      ;
      float v322 = (v5)[(int64_t) ((uint64_t) v305 + (uint64_t) v37)];
      // pto: %270, %267
      ;
      float v323 = (v6)[(int64_t) ((uint64_t) v307 + (uint64_t) v37)];
      // pto: %274, %271
      ;
      float v324 = (v6)[(int64_t) ((uint64_t) v307 + (uint64_t) v38)];
      // pto: %278, %275
      ;
      float v325 = (v6)[(int64_t) ((uint64_t) v307 + (uint64_t) v39)];
      // pto: %282, %279
      ;
      float v326 = (v6)[(int64_t) ((uint64_t) v307 + (uint64_t) v40)];
      // pto: %0
      ;
      Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v327 = Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %0
      ;
      uint64_t v328 = (uint64_t) v13;
      TASSIGN(v327, v328);
      // pto: %284
      ;
      int64_t v329 = v303 < v28 ? v28 : v303;
      // pto: %285
      ;
      __gm__ int32_t* v330 = PTOAS__GLOBAL_TENSOR_DATA(v51);
      // pto: %285
      ;
      const int64_t v331 = 0;
      // pto: %285
      ;
      const int64_t v332 = 4096;
      // pto: %285
      ;
      pto::Shape<1, 1, 1, 1, 4096> v333 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %285
      ;
      pto::Stride<4096, 4096, 4096, 4096, 1> v334 = pto::Stride<4096, 4096, 4096, 4096, 1>();
      // pto: %285
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v335 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v330 + (v331 + v329 * v332), v333, v334);
      TLOAD(v327, v335);
      // pto: %1
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v336 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %1
      ;
      uint64_t v337 = (uint64_t) v14;
      TASSIGN(v336, v337);
      // pto: %286
      ;
      __gm__ float* v338 = PTOAS__GLOBAL_TENSOR_DATA(v61);
      // pto: %286
      ;
      pto::Shape<1, 1, 1, 1, 4096> v339 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %286
      ;
      pto::Stride<4096, 4096, 4096, 4096, 1> v340 = pto::Stride<4096, 4096, 4096, 4096, 1>();
      // pto: %286
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v341 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v338, v339, v340);
      TLOAD(v336, v341);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      // pto: %2
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v342 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %2
      ;
      uint64_t v343 = (uint64_t) v15;
      TASSIGN(v342, v343);
      // pto: %289
      ;
      __gm__ bfloat16_t* v344 = PTOAS__GLOBAL_TENSOR_DATA(v70);
      // pto: %289
      ;
      const int64_t v345 = 0;
      // pto: %289
      ;
      const int64_t v346 = 16384;
      // pto: %289
      ;
      pto::Shape<1, 1, 1, 1, 4096> v347 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %289
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v348 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %289
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v349 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v344 + (v345 + v329 * v346), v347, v348);
      TLOAD(v342, v349);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
      // pto: %3
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v350 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %3
      ;
      uint64_t v351 = (uint64_t) v16;
      TASSIGN(v350, v351);
      // pto: %292
      ;
      __gm__ bfloat16_t* v352 = PTOAS__GLOBAL_TENSOR_DATA(v70);
      // pto: %292
      ;
      const int64_t v353 = 4096;
      // pto: %292
      ;
      const int64_t v354 = 16384;
      // pto: %292
      ;
      pto::Shape<1, 1, 1, 1, 4096> v355 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %292
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v356 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %292
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v357 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v352 + (v353 + v329 * v354), v355, v356);
      TLOAD(v350, v357);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
      // pto: %4
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v358 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %4
      ;
      uint64_t v359 = (uint64_t) v17;
      TASSIGN(v358, v359);
      // pto: %295
      ;
      __gm__ bfloat16_t* v360 = PTOAS__GLOBAL_TENSOR_DATA(v70);
      // pto: %295
      ;
      const int64_t v361 = 8192;
      // pto: %295
      ;
      const int64_t v362 = 16384;
      // pto: %295
      ;
      pto::Shape<1, 1, 1, 1, 4096> v363 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %295
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v364 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %295
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v365 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v360 + (v361 + v329 * v362), v363, v364);
      TLOAD(v358, v365);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %5
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v366 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %5
      ;
      uint64_t v367 = (uint64_t) v18;
      TASSIGN(v366, v367);
      // pto: %298
      ;
      __gm__ bfloat16_t* v368 = PTOAS__GLOBAL_TENSOR_DATA(v70);
      // pto: %298
      ;
      const int64_t v369 = 12288;
      // pto: %298
      ;
      const int64_t v370 = 16384;
      // pto: %298
      ;
      pto::Shape<1, 1, 1, 1, 4096> v371 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %298
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v372 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %298
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v373 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v368 + (v369 + v329 * v370), v371, v372);
      TLOAD(v366, v373);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %6
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v374 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %6
      ;
      uint64_t v375 = (uint64_t) v14;
      TASSIGN(v374, v375);
      // pto: %7
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v376 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %7
      ;
      uint64_t v377 = (uint64_t) v19;
      TASSIGN(v376, v377);
      TEXPANDS(v376, v41);
      // pto: %8
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v378 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %8
      ;
      uint64_t v379 = (uint64_t) v19;
      TASSIGN(v378, v379);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      TCOLEXPANDMUL(v378, v376, v374);
      // pto: %9
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v380 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %9
      ;
      uint64_t v381 = (uint64_t) v14;
      TASSIGN(v380, v381);
      pipe_barrier(PIPE_V);
      TMULS(v380, v378, v304);
      // pto: %10
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v382 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %10
      ;
      uint64_t v383 = (uint64_t) v13;
      TASSIGN(v382, v383);
      RoundMode v384 = RoundMode::CAST_ROUND;
      SaturationMode v385 = SaturationMode::ON;
      TCVT(v382, v327, v384, v385);
      // pto: %11
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v386 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %11
      ;
      uint64_t v387 = (uint64_t) v13;
      TASSIGN(v386, v387);
      pipe_barrier(PIPE_V);
      TMUL(v386, v382, v380);
      // pto: %12
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v388 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %12
      ;
      uint64_t v389 = (uint64_t) v14;
      TASSIGN(v388, v389);
      pipe_barrier(PIPE_V);
      RoundMode v390 = RoundMode::CAST_RINT;
      SaturationMode v391 = SaturationMode::ON;
      TCVT(v388, v386, v390, v391);
      // pto: %13
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v392 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %13
      ;
      uint64_t v393 = (uint64_t) v13;
      TASSIGN(v392, v393);
      pipe_barrier(PIPE_V);
      RoundMode v394 = RoundMode::CAST_ROUND;
      SaturationMode v395 = SaturationMode::ON;
      TCVT(v392, v388, v394, v395);
      // pto: %14
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v396 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %14
      ;
      uint64_t v397 = (uint64_t) v14;
      TASSIGN(v396, v397);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
      RoundMode v398 = RoundMode::CAST_ROUND;
      SaturationMode v399 = SaturationMode::ON;
      TCVT(v396, v342, v398, v399);
      // pto: %15
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v400 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %15
      ;
      uint64_t v401 = (uint64_t) v19;
      TASSIGN(v400, v401);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
      RoundMode v402 = RoundMode::CAST_ROUND;
      SaturationMode v403 = SaturationMode::ON;
      TCVT(v400, v350, v402, v403);
      // pto: %16
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v404 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %16
      ;
      uint64_t v405 = (uint64_t) v15;
      TASSIGN(v404, v405);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      RoundMode v406 = RoundMode::CAST_ROUND;
      SaturationMode v407 = SaturationMode::ON;
      TCVT(v404, v358, v406, v407);
      // pto: %17
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v408 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %17
      ;
      uint64_t v409 = (uint64_t) v16;
      TASSIGN(v408, v409);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      RoundMode v410 = RoundMode::CAST_ROUND;
      SaturationMode v411 = SaturationMode::ON;
      TCVT(v408, v366, v410, v411);
      // pto: %18
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v412 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %18
      ;
      uint64_t v413 = (uint64_t) v17;
      TASSIGN(v412, v413);
      pipe_barrier(PIPE_V);
      TMULS(v412, v392, v306);
      // pto: %19
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v414 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %19
      ;
      uint64_t v415 = (uint64_t) v18;
      TASSIGN(v414, v415);
      TMULS(v414, v396, v308);
      // pto: %20
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v416 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %20
      ;
      uint64_t v417 = (uint64_t) v17;
      TASSIGN(v416, v417);
      pipe_barrier(PIPE_V);
      TADD(v416, v412, v414);
      // pto: %21
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v418 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %21
      ;
      uint64_t v419 = (uint64_t) v18;
      TASSIGN(v418, v419);
      pipe_barrier(PIPE_V);
      TMULS(v418, v400, v309);
      // pto: %22
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v420 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %22
      ;
      uint64_t v421 = (uint64_t) v17;
      TASSIGN(v420, v421);
      pipe_barrier(PIPE_V);
      TADD(v420, v416, v418);
      // pto: %23
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v422 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %23
      ;
      uint64_t v423 = (uint64_t) v18;
      TASSIGN(v422, v423);
      pipe_barrier(PIPE_V);
      TMULS(v422, v404, v310);
      // pto: %24
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v424 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %24
      ;
      uint64_t v425 = (uint64_t) v17;
      TASSIGN(v424, v425);
      pipe_barrier(PIPE_V);
      TADD(v424, v420, v422);
      // pto: %25
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v426 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %25
      ;
      uint64_t v427 = (uint64_t) v18;
      TASSIGN(v426, v427);
      pipe_barrier(PIPE_V);
      TMULS(v426, v408, v311);
      // pto: %26
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v428 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %26
      ;
      uint64_t v429 = (uint64_t) v17;
      TASSIGN(v428, v429);
      pipe_barrier(PIPE_V);
      TADD(v428, v424, v426);
      // pto: %27
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v430 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %27
      ;
      uint64_t v431 = (uint64_t) v20;
      TASSIGN(v430, v431);
      pipe_barrier(PIPE_V);
      RoundMode v432 = RoundMode::CAST_RINT;
      SaturationMode v433 = SaturationMode::ON;
      TCVT(v430, v428, v432, v433);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
      v430.SetValidShape(v23, v22);
      // pto: %29
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v434 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %29
      ;
      uint64_t v435 = (uint64_t) v17;
      TASSIGN(v434, v435);
      pipe_barrier(PIPE_V);
      TMULS(v434, v392, v312);
      // pto: %30
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v436 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %30
      ;
      uint64_t v437 = (uint64_t) v18;
      TASSIGN(v436, v437);
      TMULS(v436, v396, v313);
      // pto: %31
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v438 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %31
      ;
      uint64_t v439 = (uint64_t) v17;
      TASSIGN(v438, v439);
      pipe_barrier(PIPE_V);
      TADD(v438, v434, v436);
      // pto: %32
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v440 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %32
      ;
      uint64_t v441 = (uint64_t) v18;
      TASSIGN(v440, v441);
      pipe_barrier(PIPE_V);
      TMULS(v440, v400, v314);
      // pto: %33
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v442 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %33
      ;
      uint64_t v443 = (uint64_t) v17;
      TASSIGN(v442, v443);
      pipe_barrier(PIPE_V);
      TADD(v442, v438, v440);
      // pto: %34
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v444 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %34
      ;
      uint64_t v445 = (uint64_t) v18;
      TASSIGN(v444, v445);
      pipe_barrier(PIPE_V);
      TMULS(v444, v404, v315);
      // pto: %35
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v446 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %35
      ;
      uint64_t v447 = (uint64_t) v17;
      TASSIGN(v446, v447);
      pipe_barrier(PIPE_V);
      TADD(v446, v442, v444);
      // pto: %36
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v448 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %36
      ;
      uint64_t v449 = (uint64_t) v18;
      TASSIGN(v448, v449);
      pipe_barrier(PIPE_V);
      TMULS(v448, v408, v316);
      // pto: %37
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v450 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %37
      ;
      uint64_t v451 = (uint64_t) v17;
      TASSIGN(v450, v451);
      pipe_barrier(PIPE_V);
      TADD(v450, v446, v448);
      // pto: %38
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v452 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %38
      ;
      uint64_t v453 = (uint64_t) v21;
      TASSIGN(v452, v453);
      pipe_barrier(PIPE_V);
      RoundMode v454 = RoundMode::CAST_RINT;
      SaturationMode v455 = SaturationMode::ON;
      TCVT(v452, v450, v454, v455);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
      v452.SetValidShape(v23, v22);
      // pto: %40
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v456 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %40
      ;
      uint64_t v457 = (uint64_t) v17;
      TASSIGN(v456, v457);
      pipe_barrier(PIPE_V);
      TMULS(v456, v392, v317);
      // pto: %41
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v458 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %41
      ;
      uint64_t v459 = (uint64_t) v18;
      TASSIGN(v458, v459);
      TMULS(v458, v396, v318);
      // pto: %42
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v460 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %42
      ;
      uint64_t v461 = (uint64_t) v17;
      TASSIGN(v460, v461);
      pipe_barrier(PIPE_V);
      TADD(v460, v456, v458);
      // pto: %43
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v462 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %43
      ;
      uint64_t v463 = (uint64_t) v18;
      TASSIGN(v462, v463);
      pipe_barrier(PIPE_V);
      TMULS(v462, v400, v319);
      // pto: %44
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v464 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %44
      ;
      uint64_t v465 = (uint64_t) v17;
      TASSIGN(v464, v465);
      pipe_barrier(PIPE_V);
      TADD(v464, v460, v462);
      // pto: %45
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v466 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %45
      ;
      uint64_t v467 = (uint64_t) v18;
      TASSIGN(v466, v467);
      pipe_barrier(PIPE_V);
      TMULS(v466, v404, v320);
      // pto: %46
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v468 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %46
      ;
      uint64_t v469 = (uint64_t) v17;
      TASSIGN(v468, v469);
      pipe_barrier(PIPE_V);
      TADD(v468, v464, v466);
      // pto: %47
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v470 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %47
      ;
      uint64_t v471 = (uint64_t) v18;
      TASSIGN(v470, v471);
      pipe_barrier(PIPE_V);
      TMULS(v470, v408, v321);
      // pto: %48
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v472 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %48
      ;
      uint64_t v473 = (uint64_t) v17;
      TASSIGN(v472, v473);
      pipe_barrier(PIPE_V);
      TADD(v472, v468, v470);
      // pto: %49
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v474 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %49
      ;
      uint64_t v475 = (uint64_t) v17;
      TASSIGN(v474, v475);
      pipe_barrier(PIPE_V);
      RoundMode v476 = RoundMode::CAST_RINT;
      SaturationMode v477 = SaturationMode::ON;
      TCVT(v474, v472, v476, v477);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
      v474.SetValidShape(v23, v22);
      // pto: %51
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v478 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %51
      ;
      uint64_t v479 = (uint64_t) v13;
      TASSIGN(v478, v479);
      TMULS(v478, v392, v322);
      // pto: %52
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v480 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %52
      ;
      uint64_t v481 = (uint64_t) v14;
      TASSIGN(v480, v481);
      TMULS(v480, v396, v323);
      // pto: %53
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v482 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %53
      ;
      uint64_t v483 = (uint64_t) v13;
      TASSIGN(v482, v483);
      pipe_barrier(PIPE_V);
      TADD(v482, v478, v480);
      // pto: %54
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v484 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %54
      ;
      uint64_t v485 = (uint64_t) v14;
      TASSIGN(v484, v485);
      pipe_barrier(PIPE_V);
      TMULS(v484, v400, v324);
      // pto: %55
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v486 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %55
      ;
      uint64_t v487 = (uint64_t) v13;
      TASSIGN(v486, v487);
      pipe_barrier(PIPE_V);
      TADD(v486, v482, v484);
      // pto: %56
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v488 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %56
      ;
      uint64_t v489 = (uint64_t) v14;
      TASSIGN(v488, v489);
      pipe_barrier(PIPE_V);
      TMULS(v488, v404, v325);
      // pto: %57
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v490 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %57
      ;
      uint64_t v491 = (uint64_t) v13;
      TASSIGN(v490, v491);
      pipe_barrier(PIPE_V);
      TADD(v490, v486, v488);
      // pto: %58
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v492 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %58
      ;
      uint64_t v493 = (uint64_t) v14;
      TASSIGN(v492, v493);
      pipe_barrier(PIPE_V);
      TMULS(v492, v408, v326);
      // pto: %59
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v494 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %59
      ;
      uint64_t v495 = (uint64_t) v13;
      TASSIGN(v494, v495);
      pipe_barrier(PIPE_V);
      TADD(v494, v490, v492);
      // pto: %60
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v496 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %60
      ;
      uint64_t v497 = (uint64_t) v13;
      TASSIGN(v496, v497);
      pipe_barrier(PIPE_V);
      RoundMode v498 = RoundMode::CAST_RINT;
      SaturationMode v499 = SaturationMode::ON;
      TCVT(v496, v494, v498, v499);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
      v496.SetValidShape(v23, v22);
      // pto: %302
      ;
      __gm__ bfloat16_t* v500 = PTOAS__GLOBAL_TENSOR_DATA(v79);
      // pto: %302
      ;
      const int64_t v501 = 0;
      // pto: %302
      ;
      const int64_t v502 = 16384;
      // pto: %302
      ;
      pto::Shape<1, 1, 1, 1, 4096> v503 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %302
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v504 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %302
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v505 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v500 + (v501 + v329 * v502), v503, v504);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
      TSTORE(v505, v430);
      // pto: %306
      ;
      __gm__ bfloat16_t* v506 = PTOAS__GLOBAL_TENSOR_DATA(v79);
      // pto: %306
      ;
      const int64_t v507 = 4096;
      // pto: %306
      ;
      const int64_t v508 = 16384;
      // pto: %306
      ;
      pto::Shape<1, 1, 1, 1, 4096> v509 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %306
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v510 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %306
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v511 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v506 + (v507 + v329 * v508), v509, v510);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
      TSTORE(v511, v452);
      // pto: %310
      ;
      __gm__ bfloat16_t* v512 = PTOAS__GLOBAL_TENSOR_DATA(v79);
      // pto: %310
      ;
      const int64_t v513 = 8192;
      // pto: %310
      ;
      const int64_t v514 = 16384;
      // pto: %310
      ;
      pto::Shape<1, 1, 1, 1, 4096> v515 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %310
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v516 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %310
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v517 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v512 + (v513 + v329 * v514), v515, v516);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
      TSTORE(v517, v474);
      // pto: %314
      ;
      __gm__ bfloat16_t* v518 = PTOAS__GLOBAL_TENSOR_DATA(v79);
      // pto: %314
      ;
      const int64_t v519 = 12288;
      // pto: %314
      ;
      const int64_t v520 = 16384;
      // pto: %314
      ;
      pto::Shape<1, 1, 1, 1, 4096> v521 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %314
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v522 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %314
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v523 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v518 + (v519 + v329 * v520), v521, v522);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
      TSTORE(v523, v496);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  // pto: %315, %316, %317
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  if ((int64_t) ((uint64_t) ((int64_t) (uint64_t) v80 - (uint64_t) v81) + (uint64_t) v25) == v23) {
    // pto: %318
    ;
    if (v81 < v9) {
      // pto: %62
      ;
      Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v524 = Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %62
      ;
      uint64_t v525 = (uint64_t) v13;
      TASSIGN(v524, v525);
      // pto: %319
      ;
      int64_t v526 = v81 < v28 ? v28 : v81;
      // pto: %320
      ;
      __gm__ int32_t* v527 = PTOAS__GLOBAL_TENSOR_DATA(v51);
      // pto: %320
      ;
      const int64_t v528 = 0;
      // pto: %320
      ;
      const int64_t v529 = 4096;
      // pto: %320
      ;
      pto::Shape<1, 1, 1, 1, 4096> v530 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %320
      ;
      pto::Stride<4096, 4096, 4096, 4096, 1> v531 = pto::Stride<4096, 4096, 4096, 4096, 1>();
      // pto: %320
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v532 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v527 + (v528 + v526 * v529), v530, v531);
      TLOAD(v524, v532);
      // pto: %63
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v533 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %63
      ;
      uint64_t v534 = (uint64_t) v14;
      TASSIGN(v533, v534);
      // pto: %321
      ;
      __gm__ float* v535 = PTOAS__GLOBAL_TENSOR_DATA(v61);
      // pto: %321
      ;
      pto::Shape<1, 1, 1, 1, 4096> v536 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %321
      ;
      pto::Stride<4096, 4096, 4096, 4096, 1> v537 = pto::Stride<4096, 4096, 4096, 4096, 1>();
      // pto: %321
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v538 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v535, v536, v537);
      TLOAD(v533, v538);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %64
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v539 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %64
      ;
      uint64_t v540 = (uint64_t) v14;
      TASSIGN(v539, v540);
      // pto: %322
      ;
      float v541 = (v3)[v81];
      // pto: %65
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v542 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %65
      ;
      uint64_t v543 = (uint64_t) v19;
      TASSIGN(v542, v543);
      TEXPANDS(v542, v41);
      // pto: %66
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v544 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %66
      ;
      uint64_t v545 = (uint64_t) v19;
      TASSIGN(v544, v545);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      TCOLEXPANDMUL(v544, v542, v539);
      // pto: %67
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v546 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %67
      ;
      uint64_t v547 = (uint64_t) v14;
      TASSIGN(v546, v547);
      pipe_barrier(PIPE_V);
      TMULS(v546, v544, v541);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      // pto: %68
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v548 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %68
      ;
      uint64_t v549 = (uint64_t) v13;
      TASSIGN(v548, v549);
      RoundMode v550 = RoundMode::CAST_ROUND;
      SaturationMode v551 = SaturationMode::ON;
      TCVT(v548, v524, v550, v551);
      // pto: %69
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v552 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %69
      ;
      uint64_t v553 = (uint64_t) v13;
      TASSIGN(v552, v553);
      pipe_barrier(PIPE_V);
      TMUL(v552, v548, v546);
      // pto: %70
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v554 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %70
      ;
      uint64_t v555 = (uint64_t) v14;
      TASSIGN(v554, v555);
      pipe_barrier(PIPE_V);
      RoundMode v556 = RoundMode::CAST_RINT;
      SaturationMode v557 = SaturationMode::ON;
      TCVT(v554, v552, v556, v557);
      // pto: %71
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v558 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %71
      ;
      uint64_t v559 = (uint64_t) v13;
      TASSIGN(v558, v559);
      pipe_barrier(PIPE_V);
      RoundMode v560 = RoundMode::CAST_ROUND;
      SaturationMode v561 = SaturationMode::ON;
      TCVT(v558, v554, v560, v561);
      // pto: %72
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v562 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %72
      ;
      uint64_t v563 = (uint64_t) v19;
      TASSIGN(v562, v563);
      // pto: %326
      ;
      __gm__ bfloat16_t* v564 = PTOAS__GLOBAL_TENSOR_DATA(v70);
      // pto: %326
      ;
      const int64_t v565 = 0;
      // pto: %326
      ;
      const int64_t v566 = 16384;
      // pto: %326
      ;
      pto::Shape<1, 1, 1, 1, 4096> v567 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %326
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v568 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %326
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v569 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v564 + (v565 + v526 * v566), v567, v568);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      TLOAD(v562, v569);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %73
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v570 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %73
      ;
      uint64_t v571 = (uint64_t) v14;
      TASSIGN(v570, v571);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      pipe_barrier(PIPE_V);
      RoundMode v572 = RoundMode::CAST_ROUND;
      SaturationMode v573 = SaturationMode::ON;
      TCVT(v570, v562, v572, v573);
      // pto: %74
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v574 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %74
      ;
      uint64_t v575 = (uint64_t) v15;
      TASSIGN(v574, v575);
      // pto: %328
      ;
      __gm__ bfloat16_t* v576 = PTOAS__GLOBAL_TENSOR_DATA(v70);
      // pto: %328
      ;
      const int64_t v577 = 4096;
      // pto: %328
      ;
      const int64_t v578 = 16384;
      // pto: %328
      ;
      pto::Shape<1, 1, 1, 1, 4096> v579 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %328
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v580 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %328
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v581 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v576 + (v577 + v526 * v578), v579, v580);
      TLOAD(v574, v581);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %75
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v582 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %75
      ;
      uint64_t v583 = (uint64_t) v19;
      TASSIGN(v582, v583);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      pipe_barrier(PIPE_V);
      RoundMode v584 = RoundMode::CAST_ROUND;
      SaturationMode v585 = SaturationMode::ON;
      TCVT(v582, v574, v584, v585);
      // pto: %76
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v586 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %76
      ;
      uint64_t v587 = (uint64_t) v16;
      TASSIGN(v586, v587);
      // pto: %330
      ;
      __gm__ bfloat16_t* v588 = PTOAS__GLOBAL_TENSOR_DATA(v70);
      // pto: %330
      ;
      const int64_t v589 = 8192;
      // pto: %330
      ;
      const int64_t v590 = 16384;
      // pto: %330
      ;
      pto::Shape<1, 1, 1, 1, 4096> v591 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %330
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v592 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %330
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v593 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v588 + (v589 + v526 * v590), v591, v592);
      TLOAD(v586, v593);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %77
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v594 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %77
      ;
      uint64_t v595 = (uint64_t) v15;
      TASSIGN(v594, v595);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      pipe_barrier(PIPE_V);
      RoundMode v596 = RoundMode::CAST_ROUND;
      SaturationMode v597 = SaturationMode::ON;
      TCVT(v594, v586, v596, v597);
      // pto: %78
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v598 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %78
      ;
      uint64_t v599 = (uint64_t) v17;
      TASSIGN(v598, v599);
      // pto: %332
      ;
      __gm__ bfloat16_t* v600 = PTOAS__GLOBAL_TENSOR_DATA(v70);
      // pto: %332
      ;
      const int64_t v601 = 12288;
      // pto: %332
      ;
      const int64_t v602 = 16384;
      // pto: %332
      ;
      pto::Shape<1, 1, 1, 1, 4096> v603 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %332
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v604 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %332
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v605 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v600 + (v601 + v526 * v602), v603, v604);
      TLOAD(v598, v605);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %79
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v606 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %79
      ;
      uint64_t v607 = (uint64_t) v16;
      TASSIGN(v606, v607);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      pipe_barrier(PIPE_V);
      RoundMode v608 = RoundMode::CAST_ROUND;
      SaturationMode v609 = SaturationMode::ON;
      TCVT(v606, v598, v608, v609);
      // pto: %334
      ;
      int64_t v610 = (int64_t) ((uint64_t) v81 * (uint64_t) v25);
      // pto: %333
      ;
      float v611 = (v5)[v610];
      // pto: %80
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v612 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %80
      ;
      uint64_t v613 = (uint64_t) v17;
      TASSIGN(v612, v613);
      pipe_barrier(PIPE_V);
      TMULS(v612, v558, v611);
      // pto: %337
      ;
      int64_t v614 = (int64_t) ((uint64_t) v81 * (uint64_t) v26);
      // pto: %336
      ;
      float v615 = (v6)[v614];
      // pto: %81
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v616 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %81
      ;
      uint64_t v617 = (uint64_t) v18;
      TASSIGN(v616, v617);
      TMULS(v616, v570, v615);
      // pto: %82
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v618 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %82
      ;
      uint64_t v619 = (uint64_t) v17;
      TASSIGN(v618, v619);
      pipe_barrier(PIPE_V);
      TADD(v618, v612, v616);
      // pto: %341, %339
      ;
      float v620 = (v6)[(int64_t) ((uint64_t) v614 + (uint64_t) v25)];
      // pto: %83
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v621 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %83
      ;
      uint64_t v622 = (uint64_t) v18;
      TASSIGN(v621, v622);
      pipe_barrier(PIPE_V);
      TMULS(v621, v582, v620);
      // pto: %84
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v623 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %84
      ;
      uint64_t v624 = (uint64_t) v17;
      TASSIGN(v623, v624);
      pipe_barrier(PIPE_V);
      TADD(v623, v618, v621);
      // pto: %344, %342
      ;
      float v625 = (v6)[(int64_t) ((uint64_t) v614 + (uint64_t) v29)];
      // pto: %85
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v626 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %85
      ;
      uint64_t v627 = (uint64_t) v18;
      TASSIGN(v626, v627);
      pipe_barrier(PIPE_V);
      TMULS(v626, v594, v625);
      // pto: %86
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v628 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %86
      ;
      uint64_t v629 = (uint64_t) v17;
      TASSIGN(v628, v629);
      pipe_barrier(PIPE_V);
      TADD(v628, v623, v626);
      // pto: %347, %345
      ;
      float v630 = (v6)[(int64_t) ((uint64_t) v614 + (uint64_t) v30)];
      // pto: %87
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v631 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %87
      ;
      uint64_t v632 = (uint64_t) v18;
      TASSIGN(v631, v632);
      pipe_barrier(PIPE_V);
      TMULS(v631, v606, v630);
      // pto: %88
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v633 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %88
      ;
      uint64_t v634 = (uint64_t) v17;
      TASSIGN(v633, v634);
      pipe_barrier(PIPE_V);
      TADD(v633, v628, v631);
      // pto: %89
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v635 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %89
      ;
      uint64_t v636 = (uint64_t) v17;
      TASSIGN(v635, v636);
      pipe_barrier(PIPE_V);
      RoundMode v637 = RoundMode::CAST_RINT;
      SaturationMode v638 = SaturationMode::ON;
      TCVT(v635, v633, v637, v638);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      v635.SetValidShape(v23, v22);
      // pto: %350
      ;
      __gm__ bfloat16_t* v639 = PTOAS__GLOBAL_TENSOR_DATA(v79);
      // pto: %350
      ;
      const int64_t v640 = 0;
      // pto: %350
      ;
      const int64_t v641 = 16384;
      // pto: %350
      ;
      pto::Shape<1, 1, 1, 1, 4096> v642 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %350
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v643 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %350
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v644 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v639 + (v640 + v526 * v641), v642, v643);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v644, v635);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      // pto: %353, %351
      ;
      float v645 = (v5)[(int64_t) ((uint64_t) v610 + (uint64_t) v23)];
      // pto: %91
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v646 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %91
      ;
      uint64_t v647 = (uint64_t) v17;
      TASSIGN(v646, v647);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      TMULS(v646, v558, v645);
      // pto: %356, %354
      ;
      float v648 = (v6)[(int64_t) ((uint64_t) v614 + (uint64_t) v23)];
      // pto: %92
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v649 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %92
      ;
      uint64_t v650 = (uint64_t) v18;
      TASSIGN(v649, v650);
      TMULS(v649, v570, v648);
      // pto: %93
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v651 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %93
      ;
      uint64_t v652 = (uint64_t) v17;
      TASSIGN(v651, v652);
      pipe_barrier(PIPE_V);
      TADD(v651, v646, v649);
      // pto: %359, %357
      ;
      float v653 = (v6)[(int64_t) ((uint64_t) v614 + (uint64_t) v31)];
      // pto: %94
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v654 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %94
      ;
      uint64_t v655 = (uint64_t) v18;
      TASSIGN(v654, v655);
      pipe_barrier(PIPE_V);
      TMULS(v654, v582, v653);
      // pto: %95
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v656 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %95
      ;
      uint64_t v657 = (uint64_t) v17;
      TASSIGN(v656, v657);
      pipe_barrier(PIPE_V);
      TADD(v656, v651, v654);
      // pto: %362, %360
      ;
      float v658 = (v6)[(int64_t) ((uint64_t) v614 + (uint64_t) v32)];
      // pto: %96
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v659 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %96
      ;
      uint64_t v660 = (uint64_t) v18;
      TASSIGN(v659, v660);
      pipe_barrier(PIPE_V);
      TMULS(v659, v594, v658);
      // pto: %97
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v661 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %97
      ;
      uint64_t v662 = (uint64_t) v17;
      TASSIGN(v661, v662);
      pipe_barrier(PIPE_V);
      TADD(v661, v656, v659);
      // pto: %365, %363
      ;
      float v663 = (v6)[(int64_t) ((uint64_t) v614 + (uint64_t) v33)];
      // pto: %98
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v664 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %98
      ;
      uint64_t v665 = (uint64_t) v18;
      TASSIGN(v664, v665);
      pipe_barrier(PIPE_V);
      TMULS(v664, v606, v663);
      // pto: %99
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v666 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %99
      ;
      uint64_t v667 = (uint64_t) v17;
      TASSIGN(v666, v667);
      pipe_barrier(PIPE_V);
      TADD(v666, v661, v664);
      // pto: %100
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v668 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %100
      ;
      uint64_t v669 = (uint64_t) v17;
      TASSIGN(v668, v669);
      pipe_barrier(PIPE_V);
      RoundMode v670 = RoundMode::CAST_RINT;
      SaturationMode v671 = SaturationMode::ON;
      TCVT(v668, v666, v670, v671);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      v668.SetValidShape(v23, v22);
      // pto: %368
      ;
      __gm__ bfloat16_t* v672 = PTOAS__GLOBAL_TENSOR_DATA(v79);
      // pto: %368
      ;
      const int64_t v673 = 4096;
      // pto: %368
      ;
      const int64_t v674 = 16384;
      // pto: %368
      ;
      pto::Shape<1, 1, 1, 1, 4096> v675 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %368
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v676 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %368
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v677 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v672 + (v673 + v526 * v674), v675, v676);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v677, v668);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      // pto: %371, %369
      ;
      float v678 = (v5)[(int64_t) ((uint64_t) v610 + (uint64_t) v27)];
      // pto: %102
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v679 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %102
      ;
      uint64_t v680 = (uint64_t) v17;
      TASSIGN(v679, v680);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      TMULS(v679, v558, v678);
      // pto: %374, %372
      ;
      float v681 = (v6)[(int64_t) ((uint64_t) v614 + (uint64_t) v27)];
      // pto: %103
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v682 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %103
      ;
      uint64_t v683 = (uint64_t) v18;
      TASSIGN(v682, v683);
      TMULS(v682, v570, v681);
      // pto: %104
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v684 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %104
      ;
      uint64_t v685 = (uint64_t) v17;
      TASSIGN(v684, v685);
      pipe_barrier(PIPE_V);
      TADD(v684, v679, v682);
      // pto: %377, %375
      ;
      float v686 = (v6)[(int64_t) ((uint64_t) v614 + (uint64_t) v34)];
      // pto: %105
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v687 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %105
      ;
      uint64_t v688 = (uint64_t) v18;
      TASSIGN(v687, v688);
      pipe_barrier(PIPE_V);
      TMULS(v687, v582, v686);
      // pto: %106
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v689 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %106
      ;
      uint64_t v690 = (uint64_t) v17;
      TASSIGN(v689, v690);
      pipe_barrier(PIPE_V);
      TADD(v689, v684, v687);
      // pto: %380, %378
      ;
      float v691 = (v6)[(int64_t) ((uint64_t) v614 + (uint64_t) v35)];
      // pto: %107
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v692 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %107
      ;
      uint64_t v693 = (uint64_t) v18;
      TASSIGN(v692, v693);
      pipe_barrier(PIPE_V);
      TMULS(v692, v594, v691);
      // pto: %108
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v694 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %108
      ;
      uint64_t v695 = (uint64_t) v17;
      TASSIGN(v694, v695);
      pipe_barrier(PIPE_V);
      TADD(v694, v689, v692);
      // pto: %383, %381
      ;
      float v696 = (v6)[(int64_t) ((uint64_t) v614 + (uint64_t) v36)];
      // pto: %109
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v697 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %109
      ;
      uint64_t v698 = (uint64_t) v18;
      TASSIGN(v697, v698);
      pipe_barrier(PIPE_V);
      TMULS(v697, v606, v696);
      // pto: %110
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v699 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %110
      ;
      uint64_t v700 = (uint64_t) v17;
      TASSIGN(v699, v700);
      pipe_barrier(PIPE_V);
      TADD(v699, v694, v697);
      // pto: %111
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v701 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %111
      ;
      uint64_t v702 = (uint64_t) v17;
      TASSIGN(v701, v702);
      pipe_barrier(PIPE_V);
      RoundMode v703 = RoundMode::CAST_RINT;
      SaturationMode v704 = SaturationMode::ON;
      TCVT(v701, v699, v703, v704);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      v701.SetValidShape(v23, v22);
      // pto: %386
      ;
      __gm__ bfloat16_t* v705 = PTOAS__GLOBAL_TENSOR_DATA(v79);
      // pto: %386
      ;
      const int64_t v706 = 8192;
      // pto: %386
      ;
      const int64_t v707 = 16384;
      // pto: %386
      ;
      pto::Shape<1, 1, 1, 1, 4096> v708 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %386
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v709 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %386
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v710 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v705 + (v706 + v526 * v707), v708, v709);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v710, v701);
      // pto: %389, %387
      ;
      float v711 = (v5)[(int64_t) ((uint64_t) v610 + (uint64_t) v37)];
      // pto: %113
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v712 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %113
      ;
      uint64_t v713 = (uint64_t) v13;
      TASSIGN(v712, v713);
      TMULS(v712, v558, v711);
      // pto: %392, %390
      ;
      float v714 = (v6)[(int64_t) ((uint64_t) v614 + (uint64_t) v37)];
      // pto: %114
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v715 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %114
      ;
      uint64_t v716 = (uint64_t) v14;
      TASSIGN(v715, v716);
      TMULS(v715, v570, v714);
      // pto: %115
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v717 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %115
      ;
      uint64_t v718 = (uint64_t) v13;
      TASSIGN(v717, v718);
      pipe_barrier(PIPE_V);
      TADD(v717, v712, v715);
      // pto: %395, %393
      ;
      float v719 = (v6)[(int64_t) ((uint64_t) v614 + (uint64_t) v38)];
      // pto: %116
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v720 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %116
      ;
      uint64_t v721 = (uint64_t) v14;
      TASSIGN(v720, v721);
      pipe_barrier(PIPE_V);
      TMULS(v720, v582, v719);
      // pto: %117
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v722 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %117
      ;
      uint64_t v723 = (uint64_t) v13;
      TASSIGN(v722, v723);
      pipe_barrier(PIPE_V);
      TADD(v722, v717, v720);
      // pto: %398, %396
      ;
      float v724 = (v6)[(int64_t) ((uint64_t) v614 + (uint64_t) v39)];
      // pto: %118
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v725 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %118
      ;
      uint64_t v726 = (uint64_t) v14;
      TASSIGN(v725, v726);
      pipe_barrier(PIPE_V);
      TMULS(v725, v594, v724);
      // pto: %119
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v727 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %119
      ;
      uint64_t v728 = (uint64_t) v13;
      TASSIGN(v727, v728);
      pipe_barrier(PIPE_V);
      TADD(v727, v722, v725);
      // pto: %401, %399
      ;
      float v729 = (v6)[(int64_t) ((uint64_t) v614 + (uint64_t) v40)];
      // pto: %120
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v730 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %120
      ;
      uint64_t v731 = (uint64_t) v14;
      TASSIGN(v730, v731);
      pipe_barrier(PIPE_V);
      TMULS(v730, v606, v729);
      // pto: %121
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v732 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %121
      ;
      uint64_t v733 = (uint64_t) v13;
      TASSIGN(v732, v733);
      pipe_barrier(PIPE_V);
      TADD(v732, v727, v730);
      // pto: %122
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v734 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v22);
      // pto: %122
      ;
      uint64_t v735 = (uint64_t) v13;
      TASSIGN(v734, v735);
      pipe_barrier(PIPE_V);
      RoundMode v736 = RoundMode::CAST_RINT;
      SaturationMode v737 = SaturationMode::ON;
      TCVT(v734, v732, v736, v737);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      v734.SetValidShape(v23, v22);
      // pto: %404
      ;
      __gm__ bfloat16_t* v738 = PTOAS__GLOBAL_TENSOR_DATA(v79);
      // pto: %404
      ;
      const int64_t v739 = 12288;
      // pto: %404
      ;
      const int64_t v740 = 16384;
      // pto: %404
      ;
      pto::Shape<1, 1, 1, 1, 4096> v741 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %404
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v742 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %404
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v743 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v738 + (v739 + v526 * v740), v741, v742);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v743, v734);
    };
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}