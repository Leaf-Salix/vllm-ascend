#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void indexer_topk_query_merge(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ int32_t* v3, __gm__ int32_t* v4, __gm__ float* v5, __gm__ float* v6, __gm__ int32_t* v7, int64_t v8, int64_t v9, int64_t v10, int32_t v11, int32_t v12) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  pto::MrgSortExecutedNumList v13 = pto::MrgSortExecutedNumList{0, 0, 0, 0};
  // pto: %c36864_i64
  const int64_t v14 = 36864;
  // pto: %c40960_i64
  const int64_t v15 = 40960;
  // pto: %c45056_i64
  const int64_t v16 = 45056;
  // pto: %c0_i64
  const int64_t v17 = 0;
  // pto: %c4096_i64
  const int64_t v18 = 4096;
  // pto: %c20480_i64
  const int64_t v19 = 20480;
  // pto: %c1_index
  const int64_t v20 = 1;
  // pto: %c27648_index
  const int64_t v21 = 27648;
  // pto: %c1024_index
  const int64_t v22 = 1024;
  // pto: %c512_index
  const int64_t v23 = 512;
  // pto: %c0_index
  const int64_t v24 = 0;
  // pto: %c5_index
  const int64_t v25 = 5;
  // pto: %c6_index
  const int64_t v26 = 6;
  // pto: %c4_index
  const int64_t v27 = 4;
  // pto: %c2_index
  const int64_t v28 = 2;
  // pto: %c262144_index
  const int64_t v29 = 262144;
  // pto: %c1023_index
  const int64_t v30 = 1023;
  // pto: %c8191_index
  const int64_t v31 = 8191;
  // pto: %c8192_index
  const int64_t v32 = 8192;
  // pto: %c3_index
  const int64_t v33 = 3;
  // pto: %c48_index
  const int64_t v34 = 48;
  // pto: %c24_index
  const int64_t v35 = 24;
  // pto: %c32_index
  const int64_t v36 = 32;
  // pto: %c8_index
  const int64_t v37 = 8;
  // pto: %c1_i64
  const int64_t v38 = 1;
  // pto: %c4_i64
  const int64_t v39 = 4;
  // pto: %c64_index
  const int64_t v40 = 64;
  // pto: %c4096_index
  const int64_t v41 = 4096;
  // pto: %c3072_index
  const int64_t v42 = 3072;
  // pto: %c2048_index
  const int64_t v43 = 2048;
  // pto: %cn1_i32
  const int32_t v44 = -1;
  // pto: %cst_31
  const float v45 = -3.40282347E+38f;
  // pto: %pair_arena__ssa_v0_view
  const int64_t v46 = 1;
  // pto: %pair_arena__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %pair_arena__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %pair_arena__ssa_v0_view
  int64_t v49 = v21 * v22;
  // pto: %pair_arena__ssa_v0_view
  int64_t v50 = v48 * v49;
  // pto: %pair_arena__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v51 = pto::Shape<1, 1, 1, -1, -1>(v46, v47, v48, v21, v22);
  // pto: %pair_arena__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v52 = pto::Stride<-1, -1, -1, -1, -1>(v47 * v50, v50, v49, v22, v20);
  // pto: %pair_arena__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v53 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v51, v52);
  // pto: %topk_scores__ssa_v0_view
  const int64_t v54 = 1;
  // pto: %topk_scores__ssa_v0_view
  const int64_t v55 = 1;
  // pto: %topk_scores__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %topk_scores__ssa_v0_view
  int64_t v57 = (int64_t) v8;
  // pto: %topk_scores__ssa_v0_view
  int64_t v58 = v57 * v23;
  // pto: %topk_scores__ssa_v0_view
  int64_t v59 = v56 * v58;
  // pto: %topk_scores__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v60 = pto::Shape<1, 1, 1, -1, -1>(v54, v55, v56, v57, v23);
  // pto: %topk_scores__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v61 = pto::Stride<-1, -1, -1, -1, -1>(v55 * v59, v59, v58, v23, v20);
  // pto: %topk_scores__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v62 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v60, v61);
  // pto: %topk_indices__ssa_v0_view
  const int64_t v63 = 1;
  // pto: %topk_indices__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %topk_indices__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %topk_indices__ssa_v0_view
  int64_t v66 = (int64_t) v8;
  // pto: %topk_indices__ssa_v0_view
  int64_t v67 = v66 * v23;
  // pto: %topk_indices__ssa_v0_view
  int64_t v68 = v65 * v67;
  // pto: %topk_indices__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v69 = pto::Shape<1, 1, 1, -1, -1>(v63, v64, v65, v66, v23);
  // pto: %topk_indices__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v70 = pto::Stride<-1, -1, -1, -1, -1>(v64 * v68, v68, v67, v23, v20);
  // pto: %topk_indices__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v71 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v69, v70);
  // pto: %root_inline5605__phi_v7
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v72 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
  // pto: %root_inline5605__phi_v7
  uint64_t v73 = (uint64_t) v14;
  TASSIGN(v72, v73);
  // pto: %root_inline5605__phi_v6
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v74 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
  // pto: %root_inline5605__phi_v6
  uint64_t v75 = (uint64_t) v14;
  TASSIGN(v74, v75);
  // pto: %worker__ssa_v0
  set_flag(PIPE_S, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_S, PIPE_V, EVENT_ID1);
  // pto: %count_inline1223__rv_v2
  int64_t v76;
  v76 = v24;
  for (int64_t v77 = v24; v77 < v9; v77 += v20) {
    // pto: %t__tile
    ;
    int32_t v78 = (v4)[v77];
    // pto: %3, %2
    ;
    int32_t v79 = (v4)[(int64_t) ((uint64_t) v77 + (uint64_t) v20)];
    // pto: %5
    ;
    int32_t v80 = (v2)[v77];
    // pto: %6, %7
    ;
    // pto: %count_inline1223__phi_v4
    ;
    int64_t v81;
    if ((int64_t) v80 > v24) {
      // pto: %11
      ;
      uint64_t v82 = (uint64_t) v76;
      // pto: %4, %8, %1, %9, %10, %11
      ;
      v81 = (int64_t) (v82 + (uint64_t) ((int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v79) - (uint64_t) ((int64_t) v78)) + (uint64_t) v25) / v26));
    } else {
      v81 = v76;
    };
    v76 = v81;
  }
  // pto: %12
  bool v83 = v76 >= v27;
  // pto: %max_cache_count__rv_v2
  int64_t v84;
  v84 = v24;
  for (int64_t v85 = v24; v85 < v9; v85 += v20) {
    // pto: %14
    ;
    int32_t v86 = (v2)[v85];
    // pto: %15, %16
    ;
    int64_t v87 = (int64_t) v86 / v27;
    // pto: %17
    ;
    bool v88 = v84 < v87;
    // pto: %17
    ;
    int64_t v89 = v88 ? v87 : v84;
    v84 = v89;
  }
  // pto: %count_inline1227__rv_v2
  int64_t v90;
  v90 = v24;
  for (int64_t v91 = v24; v91 < v9; v91 += v20) {
    // pto: %19
    ;
    int32_t v92 = (v4)[v91];
    // pto: %22, %21
    ;
    int32_t v93 = (v4)[(int64_t) ((uint64_t) v91 + (uint64_t) v20)];
    // pto: %24
    ;
    int32_t v94 = (v2)[v91];
    // pto: %25, %26
    ;
    // pto: %count_inline1227__phi_v4
    ;
    int64_t v95;
    if ((int64_t) v94 > v24) {
      // pto: %30
      ;
      uint64_t v96 = (uint64_t) v90;
      // pto: %23, %27, %20, %28, %29, %30
      ;
      v95 = (int64_t) (v96 + (uint64_t) ((int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v93) - (uint64_t) ((int64_t) v92)) + (uint64_t) v20) / v28));
    } else {
      v95 = v90;
    };
    v90 = v95;
  }
  // pto: %13, %31
  bool v97 = (int64_t) v83 == v20;
  // pto: %query_groups__phi_v2
  int64_t v98 = v97 ? v76 : v90;
  // pto: %32
  bool v99 = v84 < v29;
  // pto: %32
  int64_t v100 = v99 ? v84 : v29;
  // pto: %33, %34
  int64_t v101 = (int64_t) ((uint64_t) v100 + (uint64_t) v30) / v22;
  // pto: %36, %37
  int64_t v102 = (int64_t) ((uint64_t) v100 + (uint64_t) v31) / v32;
  // pto: %38
  int64_t v103 = v102 < v20 ? v20 : v102;
  // pto: %39
  int64_t v104 = (int64_t) ((uint64_t) v98 * (uint64_t) v33);
  // pto: %40
  // pto: %leaf_multiple_inline1230__phi_v6
  int64_t v105;
  if (v104 == v34) {
    v105 = v33;
  } else {
    // pto: %42
    ;
    // pto: %leaf_multiple_inline1230__phi_v5
    ;
    int64_t v106;
    if (v104 == v35) {
      v106 = v33;
    } else {
      // pto: %43, %44, %leaf_multiple_inline1230__phi_v4
      ;
      v106 = (int64_t) ((uint64_t) v98 * (uint64_t) v26) == v35 ? v26 : v20;
    };
    v105 = v106;
  }
  // pto: %45
  bool v107 = v105 > v20;
  // pto: %extra_leaves_inline1229__phi_v3
  int64_t v108;
  // pto: %leaf_tiles_inline1231__phi_v3
  int64_t v109;
  if (v107) {
    // pto: %46
    ;
    uint64_t v110 = (uint64_t) v105;
    // pto: %46, %47, %48
    ;
    int64_t v111 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v103 + v110) - (uint64_t) v20) / v105;
    // pto: %49
    ;
    uint64_t v112 = (uint64_t) v105;
    // pto: %49
    ;
    int64_t v113 = (int64_t) ((uint64_t) v111 * v112);
    // pto: %50
    ;
    // pto: %extra_leaves_inline1229__phi_v2
    ;
    int64_t v114;
    // pto: %leaf_tiles_inline1231__phi_v2
    ;
    int64_t v115;
    if (v113 <= v36) {
      // pto: %51
      ;
      int64_t v116 = v101 / v113;
      // pto: %52
      ;
      // pto: %53
      ;
      int64_t v117 = v101 % v113;
      // pto: %57, %54, %55, %56, %58, %59, %60
      ;
      v114 = v117 != v24 & (v117 < v24 ^ v113 < v24) ? (int64_t) ((uint64_t) v117 + (uint64_t) v113) : v117;
      v115 = v116 < v20 ? v20 : v116;
    } else {
      v114 = v24;
      v115 = v37;
    };
    v108 = v114;
    v109 = v115;
  } else {
    v108 = v24;
    v109 = v37;
  }
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  for (int64_t v118 = (int64_t) v11; v118 < v8; v118 += v34) {
    // pto: %61
    ;
    int32_t v119 = (v3)[v118];
    // pto: %62
    ;
    int64_t v120 = (int64_t) v119;
    // pto: %position_inline1238__tile
    ;
    int64_t v121 = (v1)[v118];
    // pto: %64
    ;
    int64_t v122 = v120 < v24 ? v24 : v120;
    // pto: %63
    ;
    int32_t v123 = (v2)[v122];
    // pto: %67, %65, %66, %cache_len_inline1250__phi_v2
    ;
    int64_t v124 = v120 < v24 ? v24 : (int64_t) v123 / v27;
    // pto: %68, %69
    ;
    int64_t v125 = (int64_t) ((uint64_t) v121 + (uint64_t) v38) / v39;
    // pto: %71
    ;
    int64_t v126 = v124 < v125 ? v124 : v125;
    // pto: %72
    ;
    int64_t v127 = v126 < v29 ? v126 : v29;
    // pto: %73
    ;
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    if (v127 > v24) {
      // pto: %74, %75
      ;
      int64_t v128 = (int64_t) ((uint64_t) v127 + (uint64_t) v30) / v22;
      // pto: %76
      ;
      uint64_t v129 = (uint64_t) v109;
      // pto: %76
      ;
      int64_t v130 = (int64_t) (v129 + (uint64_t) v20);
      // pto: %77
      ;
      uint64_t v131 = (uint64_t) v108;
      // pto: %78
      ;
      uint64_t v132 = (uint64_t) v109;
      // pto: %78, %80
      ;
      int64_t v133 = (int64_t) ((uint64_t) v128 + v132) / v130;
      // pto: %81
      ;
      bool v134 = v108 < v133;
      // pto: %81
      ;
      int64_t v135 = v134 ? v108 : v133;
      // pto: %82, %77
      ;
      int64_t v136 = (int64_t) ((uint64_t) v128 - (uint64_t) ((int64_t) v131 * (uint64_t) v130));
      // pto: %83
      ;
      int64_t v137 = v136 < v24 ? v24 : v136;
      // pto: %84
      ;
      uint64_t v138 = (uint64_t) v109;
      // pto: %84, %85, %86
      ;
      int64_t v139 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v137 + v138) - (uint64_t) v20) / v109;
      // pto: %87
      ;
      int64_t v140 = (int64_t) ((uint64_t) v135 + (uint64_t) v139);
      // pto: %88, %half_count_inline1249__phi_v2
      ;
      int64_t v141 = v97 ? v140 : (int64_t) ((uint64_t) v140 * (uint64_t) v28);
      // pto: %90
      ;
      int64_t v142 = (int64_t) ((uint64_t) v118 * (uint64_t) v40);
      // pto: %root_inline5605__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v143 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
      // pto: %root_inline5605__ssa_v0
      ;
      uint64_t v144 = (uint64_t) v14;
      TASSIGN(v143, v144);
      // pto: %91
      ;
      int64_t v145 = v142 < v24 ? v24 : v142;
      // pto: %pair_arena__ssa_v0_pview
      ;
      __gm__ float* v146 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %pair_arena__ssa_v0_pview
      ;
      const int64_t v147 = 0;
      // pto: %pair_arena__ssa_v0_pview
      ;
      const int64_t v148 = 1024;
      // pto: %pair_arena__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 1024> v149 = pto::Shape<1, 1, 1, 1, 1024>();
      // pto: %pair_arena__ssa_v0_pview
      ;
      pto::Stride<1024, 1024, 1024, 1024, 1> v150 = pto::Stride<1024, 1024, 1024, 1024, 1>();
      // pto: %pair_arena__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v151 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v146 + (v147 + v145 * v148), v149, v150);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      TLOAD(v143, v151);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
      pipe_barrier(PIPE_ALL);
      for (int64_t v152 = v20; v152 < v141; v152 += v33) {
        // pto: %incoming1_inline5601__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v153 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
        // pto: %incoming1_inline5601__ssa_v0
        ;
        uint64_t v154 = (uint64_t) v15;
        TASSIGN(v153, v154);
        // pto: %92
        ;
        int64_t v155 = (int64_t) ((uint64_t) v142 + (uint64_t) v152);
        // pto: %93
        ;
        int64_t v156 = v155 < v24 ? v24 : v155;
        // pto: %94
        ;
        __gm__ float* v157 = PTOAS__GLOBAL_TENSOR_DATA(v53);
        // pto: %94
        ;
        const int64_t v158 = 0;
        // pto: %94
        ;
        const int64_t v159 = 1024;
        // pto: %94
        ;
        pto::Shape<1, 1, 1, 1, 1024> v160 = pto::Shape<1, 1, 1, 1, 1024>();
        // pto: %94
        ;
        pto::Stride<1024, 1024, 1024, 1024, 1> v161 = pto::Stride<1024, 1024, 1024, 1024, 1>();
        // pto: %94
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v162 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v157 + (v158 + v156 * v159), v160, v161);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
        TLOAD(v153, v162);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %95, %96
        ;
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        if ((int64_t) ((uint64_t) v152 + (uint64_t) v28) < v141) {
          // pto: %incoming2_inline5600__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v163 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
          // pto: %incoming2_inline5600__ssa_v0
          ;
          uint64_t v164 = (uint64_t) v16;
          TASSIGN(v163, v164);
          // pto: %98
          ;
          int64_t v165 = (int64_t) ((uint64_t) v155 + (uint64_t) v20);
          // pto: %99
          ;
          int64_t v166 = v165 < v24 ? v24 : v165;
          // pto: %100
          ;
          __gm__ float* v167 = PTOAS__GLOBAL_TENSOR_DATA(v53);
          // pto: %100
          ;
          const int64_t v168 = 0;
          // pto: %100
          ;
          const int64_t v169 = 1024;
          // pto: %100
          ;
          pto::Shape<1, 1, 1, 1, 1024> v170 = pto::Shape<1, 1, 1, 1, 1024>();
          // pto: %100
          ;
          pto::Stride<1024, 1024, 1024, 1024, 1> v171 = pto::Stride<1024, 1024, 1024, 1024, 1>();
          // pto: %100
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v172 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v167 + (v168 + v166 * v169), v170, v171);
          TLOAD(v163, v172);
          // pto: %incoming3_inline5599__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v173 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
          // pto: %incoming3_inline5599__ssa_v0
          ;
          uint64_t v174 = (uint64_t) v17;
          TASSIGN(v173, v174);
          // pto: %102
          ;
          int64_t v175 = (int64_t) ((uint64_t) v155 + (uint64_t) v28);
          // pto: %103
          ;
          int64_t v176 = v175 < v24 ? v24 : v175;
          // pto: %104
          ;
          __gm__ float* v177 = PTOAS__GLOBAL_TENSOR_DATA(v53);
          // pto: %104
          ;
          const int64_t v178 = 0;
          // pto: %104
          ;
          const int64_t v179 = 1024;
          // pto: %104
          ;
          pto::Shape<1, 1, 1, 1, 1024> v180 = pto::Shape<1, 1, 1, 1, 1024>();
          // pto: %104
          ;
          pto::Stride<1024, 1024, 1024, 1024, 1> v181 = pto::Stride<1024, 1024, 1024, 1024, 1>();
          // pto: %104
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v182 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v177 + (v178 + v176 * v179), v180, v181);
          TLOAD(v173, v182);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
          // pto: %merge_tmp4_inline5598__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v41);
          // pto: %merge_tmp4_inline5598__ssa_v0
          ;
          uint64_t v184 = (uint64_t) v18;
          TASSIGN(v183, v184);
          // pto: %merged4_inline5602__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v185 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v41);
          // pto: %merged4_inline5602__ssa_v0
          ;
          uint64_t v186 = (uint64_t) v19;
          TASSIGN(v185, v186);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
          pipe_barrier(PIPE_V);
          TMRGSORT<Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, true>(v185, v13, v183, v173, v163, v153, v143);
          // pto: %root_inline5605__ssa_v3
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v187 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
          // pto: %root_inline5605__ssa_v3
          ;
          uint64_t v188 = (uint64_t) v14;
          TASSIGN(v187, v188);
          pipe_barrier(PIPE_V);
          uint16_t v189 = static_cast<uint16_t>(v24);
          uint16_t v190 = static_cast<uint16_t>(v24);
          TEXTRACT(v187, v185, v189, v190);
        } else {
          // pto: %105, %106
          ;
          if ((int64_t) ((uint64_t) v152 + (uint64_t) v20) < v141) {
            // pto: %incoming2_inline5600__ssa_v1
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v191 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
            // pto: %incoming2_inline5600__ssa_v1
            ;
            uint64_t v192 = (uint64_t) v16;
            TASSIGN(v191, v192);
            // pto: %108
            ;
            int64_t v193 = (int64_t) ((uint64_t) v155 + (uint64_t) v20);
            // pto: %109
            ;
            int64_t v194 = v193 < v24 ? v24 : v193;
            // pto: %110
            ;
            __gm__ float* v195 = PTOAS__GLOBAL_TENSOR_DATA(v53);
            // pto: %110
            ;
            const int64_t v196 = 0;
            // pto: %110
            ;
            const int64_t v197 = 1024;
            // pto: %110
            ;
            pto::Shape<1, 1, 1, 1, 1024> v198 = pto::Shape<1, 1, 1, 1, 1024>();
            // pto: %110
            ;
            pto::Stride<1024, 1024, 1024, 1024, 1> v199 = pto::Stride<1024, 1024, 1024, 1024, 1>();
            // pto: %110
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v200 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v195 + (v196 + v194 * v197), v198, v199);
            TLOAD(v191, v200);
            set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
            // pto: %merge_tmp3_inline5604__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v201 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v42);
            // pto: %merge_tmp3_inline5604__ssa_v0
            ;
            uint64_t v202 = (uint64_t) v18;
            TASSIGN(v201, v202);
            // pto: %merged3_inline5597__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v203 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v42);
            // pto: %merged3_inline5597__ssa_v0
            ;
            uint64_t v204 = (uint64_t) v19;
            TASSIGN(v203, v204);
            wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
            pipe_barrier(PIPE_V);
            TMRGSORT<Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, true>(v203, v13, v201, v191, v153, v143);
            // pto: %root_inline5605__ssa_v4
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v205 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
            // pto: %root_inline5605__ssa_v4
            ;
            uint64_t v206 = (uint64_t) v14;
            TASSIGN(v205, v206);
            pipe_barrier(PIPE_V);
            uint16_t v207 = static_cast<uint16_t>(v24);
            uint16_t v208 = static_cast<uint16_t>(v24);
            TEXTRACT(v205, v203, v207, v208);
          } else {
            // pto: %merge_tmp2_inline5596__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v209 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v43);
            // pto: %merge_tmp2_inline5596__ssa_v0
            ;
            uint64_t v210 = (uint64_t) v18;
            TASSIGN(v209, v210);
            // pto: %merged2_inline5595__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v43);
            // pto: %merged2_inline5595__ssa_v0
            ;
            uint64_t v212 = (uint64_t) v19;
            TASSIGN(v211, v212);
            pipe_barrier(PIPE_V);
            TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, false>(v211, v13, v209, v153, v143);
            // pto: %root_inline5605__ssa_v5
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v213 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
            // pto: %root_inline5605__ssa_v5
            ;
            uint64_t v214 = (uint64_t) v14;
            TASSIGN(v213, v214);
            pipe_barrier(PIPE_V);
            uint16_t v215 = static_cast<uint16_t>(v24);
            uint16_t v216 = static_cast<uint16_t>(v24);
            TEXTRACT(v213, v211, v215, v216);
          };
        };
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      };
      // pto: %root_pairs_inline1252__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
      // pto: %root_pairs_inline1252__ssa_v0
      ;
      uint64_t v218 = (uint64_t) v14;
      TASSIGN(v217, v218);
      // pto: %root_scores_inline1245__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v219 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v23);
      // pto: %root_scores_inline1245__ssa_v0
      ;
      uint64_t v220 = (uint64_t) v18;
      TASSIGN(v219, v220);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      pipe_barrier(PIPE_ALL);
      wait_flag(PIPE_S, PIPE_V, EVENT_ID1);
      TGATHER<Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, MaskPattern::P0101>(v219, v217);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      // pto: %113
      ;
      int64_t v221 = v118 < v24 ? v24 : v118;
      // pto: %topk_scores__ssa_v0_pview
      ;
      __gm__ float* v222 = PTOAS__GLOBAL_TENSOR_DATA(v62);
      // pto: %topk_scores__ssa_v0_pview
      ;
      const int64_t v223 = 0;
      // pto: %topk_scores__ssa_v0_pview
      ;
      const int64_t v224 = 512;
      // pto: %topk_scores__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v225 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %topk_scores__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 512, 1> v226 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %topk_scores__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v227 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v222 + (v223 + v221 * v224), v225, v226);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v227, v219);
      // pto: %root_indices_inline1240__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v228 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v23);
      // pto: %root_indices_inline1240__ssa_v0
      ;
      uint64_t v229 = (uint64_t) v18;
      TASSIGN(v228, v229);
      pipe_barrier(PIPE_ALL);
      TGATHER<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, MaskPattern::P1010>(v228, v217);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      set_flag(PIPE_V, PIPE_S, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      // pto: %114
      ;
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
      if (v127 >= v23) {
        // pto: %topk_indices__ssa_v0_pview
        ;
        __gm__ int32_t* v230 = PTOAS__GLOBAL_TENSOR_DATA(v71);
        // pto: %topk_indices__ssa_v0_pview
        ;
        const int64_t v231 = 0;
        // pto: %topk_indices__ssa_v0_pview
        ;
        const int64_t v232 = 512;
        // pto: %topk_indices__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 512> v233 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %topk_indices__ssa_v0_pview
        ;
        pto::Stride<512, 512, 512, 512, 1> v234 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %topk_indices__ssa_v0_pview
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v235 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v230 + (v231 + v221 * v232), v233, v234);
        TSTORE(v235, v228);
      } else {
        // pto: %output_indices_inline1235__ssa_v0
        ;
        Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v236 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v23);
        // pto: %output_indices_inline1235__ssa_v0
        ;
        uint64_t v237 = (uint64_t) v19;
        TASSIGN(v236, v237);
        TEXPANDS(v236, v44);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        set_flag(PIPE_V, PIPE_S, EVENT_ID1);
        wait_flag(PIPE_V, PIPE_S, EVENT_ID1);
        for (int64_t v238 = v24; v238 < v127; v238 += v20) {
          // pto: %t__tmp_v12
          ;
          int32_t v239 = v228.GetValue(v238);
          v236.SetValue(v238, v239);
        };
        set_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
        // pto: %119
        ;
        __gm__ int32_t* v240 = PTOAS__GLOBAL_TENSOR_DATA(v71);
        // pto: %119
        ;
        const int64_t v241 = 0;
        // pto: %119
        ;
        const int64_t v242 = 512;
        // pto: %119
        ;
        pto::Shape<1, 1, 1, 1, 512> v243 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %119
        ;
        pto::Stride<512, 512, 512, 512, 1> v244 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %119
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v245 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v240 + (v241 + v221 * v242), v243, v244);
        wait_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        TSTORE(v245, v236);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
      set_flag(PIPE_S, PIPE_V, EVENT_ID1);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    } else {
      // pto: %t__tmp_v13
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v246 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v23);
      // pto: %t__tmp_v13
      ;
      uint64_t v247 = (uint64_t) v18;
      TASSIGN(v246, v247);
      pipe_barrier(PIPE_V);
      pipe_barrier(PIPE_ALL);
      TEXPANDS(v246, v45);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      // pto: %120
      ;
      int64_t v248 = v118 < v24 ? v24 : v118;
      // pto: %121
      ;
      __gm__ float* v249 = PTOAS__GLOBAL_TENSOR_DATA(v62);
      // pto: %121
      ;
      const int64_t v250 = 0;
      // pto: %121
      ;
      const int64_t v251 = 512;
      // pto: %121
      ;
      pto::Shape<1, 1, 1, 1, 512> v252 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %121
      ;
      pto::Stride<512, 512, 512, 512, 1> v253 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %121
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v254 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v249 + (v250 + v248 * v251), v252, v253);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      TSTORE(v254, v246);
      // pto: %t__tmp_v14
      ;
      Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v255 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v23);
      // pto: %t__tmp_v14
      ;
      uint64_t v256 = (uint64_t) v18;
      TASSIGN(v255, v256);
      pipe_barrier(PIPE_ALL);
      TEXPANDS(v255, v44);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
      // pto: %123
      ;
      __gm__ int32_t* v257 = PTOAS__GLOBAL_TENSOR_DATA(v71);
      // pto: %123
      ;
      const int64_t v258 = 0;
      // pto: %123
      ;
      const int64_t v259 = 512;
      // pto: %123
      ;
      pto::Shape<1, 1, 1, 1, 512> v260 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %123
      ;
      pto::Stride<512, 512, 512, 512, 1> v261 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %123
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v262 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v257 + (v258 + v248 * v259), v260, v261);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
      TSTORE(v262, v255);
    };
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID1);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}