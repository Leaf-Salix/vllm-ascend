#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void rmsnorm_rope_cache_write(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ int32_t* v3, __gm__ float* v4, __gm__ float* v5, __gm__ float* v6, __gm__ float* v7, __gm__ bfloat16_t* v8, __gm__ bfloat16_t* v9, __gm__ float* v10, __gm__ int32_t* v11, int64_t v12, int64_t v13, int64_t v14, int64_t v15, int64_t v16, int32_t v17, int32_t v18) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v19 = 256;
  // pto: %c0_i64
  const int64_t v20 = 0;
  // pto: %c4096_i64
  const int64_t v21 = 4096;
  // pto: %c8192_i64
  const int64_t v22 = 8192;
  // pto: %c24576_i64
  const int64_t v23 = 24576;
  const int64_t v24 = 8704;
  const int64_t v25 = 8448;
  // pto: %c40960_i64
  const int64_t v26 = 40960;
  // pto: %c45056_i64
  const int64_t v27 = 45056;
  // pto: %c49152_i64
  const int64_t v28 = 49152;
  // pto: %c49408_i64
  const int64_t v29 = 49408;
  // pto: %c1_index
  const int64_t v30 = 1;
  // pto: %c64_index
  const int64_t v31 = 64;
  // pto: %c384_index
  const int64_t v32 = 384;
  // pto: %c512_index
  const int64_t v33 = 512;
  // pto: %c2_index
  const int64_t v34 = 2;
  // pto: %c16_index
  const int64_t v35 = 16;
  // pto: %cst_16
  const float v36 = 1.0f;
  // pto: %cst_17
  const float v37 = 0.0f;
  // pto: %c0_index
  const int64_t v38 = 0;
  // pto: %c1_i64
  const int64_t v39 = 1;
  // pto: %c4_i64
  const int64_t v40 = 4;
  // pto: %c256_index
  const int64_t v41 = 256;
  // pto: %c128_index
  const int64_t v42 = 128;
  // pto: %cst_23
  const float v43 = 0.001953125f;
  // pto: %cst_24
  const float v44 = 9.99999997E-7f;
  // pto: %c448_index
  const int64_t v45 = 448;
  // pto: %c192_index
  const int64_t v46 = 192;
  // pto: %c0_i32
  const int32_t v47 = 0;
  // pto: %cst_28
  const float v48 = 0.5f;
  // pto: %cst_29
  const float v49 = 2.0f;
  // pto: %c32_index
  const int64_t v50 = 32;
  // pto: %cmp_freqs_cos__ssa_v0_view
  const int64_t v51 = 1;
  // pto: %cmp_freqs_cos__ssa_v0_view
  const int64_t v52 = 1;
  // pto: %cmp_freqs_cos__ssa_v0_view
  const int64_t v53 = 1;
  // pto: %cmp_freqs_cos__ssa_v0_view
  int64_t v54 = (int64_t) v15;
  // pto: %cmp_freqs_cos__ssa_v0_view
  int64_t v55 = v54 * v31;
  // pto: %cmp_freqs_cos__ssa_v0_view
  int64_t v56 = v53 * v55;
  // pto: %cmp_freqs_cos__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v57 = pto::Shape<1, 1, 1, -1, -1>(v51, v52, v53, v54, v31);
  // pto: %cmp_freqs_cos__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v58 = pto::Stride<-1, -1, -1, -1, -1>(v52 * v56, v56, v55, v31, v30);
  // pto: %cmp_freqs_cos__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v59 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v57, v58);
  // pto: %cmp_freqs_sin__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %cmp_freqs_sin__ssa_v0_view
  const int64_t v61 = 1;
  // pto: %cmp_freqs_sin__ssa_v0_view
  const int64_t v62 = 1;
  // pto: %cmp_freqs_sin__ssa_v0_view
  int64_t v63 = (int64_t) v15;
  // pto: %cmp_freqs_sin__ssa_v0_view
  int64_t v64 = v63 * v31;
  // pto: %cmp_freqs_sin__ssa_v0_view
  int64_t v65 = v62 * v64;
  // pto: %cmp_freqs_sin__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v66 = pto::Shape<1, 1, 1, -1, -1>(v60, v61, v62, v63, v31);
  // pto: %cmp_freqs_sin__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v67 = pto::Stride<-1, -1, -1, -1, -1>(v61 * v65, v65, v64, v31, v30);
  // pto: %cmp_freqs_sin__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v68 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v66, v67);
  // pto: %pooled_kv_inline963__rv_v2_view
  const int64_t v69 = 1;
  // pto: %pooled_kv_inline963__rv_v2_view
  const int64_t v70 = 1;
  // pto: %pooled_kv_inline963__rv_v2_view
  const int64_t v71 = 1;
  // pto: %pooled_kv_inline963__rv_v2_view
  int64_t v72 = v32 * v33;
  // pto: %pooled_kv_inline963__rv_v2_view
  int64_t v73 = v71 * v72;
  // pto: %pooled_kv_inline963__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v74 = pto::Shape<1, 1, 1, -1, -1>(v69, v70, v71, v32, v33);
  // pto: %pooled_kv_inline963__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v75 = pto::Stride<-1, -1, -1, -1, -1>(v70 * v73, v73, v72, v33, v30);
  // pto: %pooled_kv_inline963__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v76 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v74, v75);
  // pto: %normed_kv_inline4742__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %normed_kv_inline4742__ssa_v0_view
  const int64_t v78 = 1;
  // pto: %normed_kv_inline4742__ssa_v0_view
  const int64_t v79 = 1;
  // pto: %normed_kv_inline4742__ssa_v0_view
  int64_t v80 = v32 * v33;
  // pto: %normed_kv_inline4742__ssa_v0_view
  int64_t v81 = v79 * v80;
  // pto: %normed_kv_inline4742__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v82 = pto::Shape<1, 1, 1, -1, -1>(v77, v78, v79, v32, v33);
  // pto: %normed_kv_inline4742__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v83 = pto::Stride<-1, -1, -1, -1, -1>(v78 * v81, v81, v80, v33, v30);
  // pto: %normed_kv_inline4742__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v84 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v82, v83);
  // pto: %norm_w_2d_inline4740__ssa_v0_view
  const int64_t v85 = 1;
  // pto: %norm_w_2d_inline4740__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %norm_w_2d_inline4740__ssa_v0_view
  const int64_t v87 = 1;
  // pto: %norm_w_2d_inline4740__ssa_v0_view
  int64_t v88 = v30 * v33;
  // pto: %norm_w_2d_inline4740__ssa_v0_view
  int64_t v89 = v87 * v88;
  // pto: %norm_w_2d_inline4740__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v90 = pto::Shape<1, 1, 1, -1, -1>(v85, v86, v87, v30, v33);
  // pto: %norm_w_2d_inline4740__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v91 = pto::Stride<-1, -1, -1, -1, -1>(v86 * v89, v89, v88, v33, v30);
  // pto: %norm_w_2d_inline4740__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v92 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v90, v91);
  // pto: %102
  int64_t v93 = (int64_t) ((uint64_t) v16 * (uint64_t) v50);
  // pto: %cmp_kv_cache_flat_inline4765__ssa_v0_view
  const int64_t v94 = 1;
  // pto: %cmp_kv_cache_flat_inline4765__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %cmp_kv_cache_flat_inline4765__ssa_v0_view
  const int64_t v96 = 1;
  // pto: %cmp_kv_cache_flat_inline4765__ssa_v0_view
  int64_t v97 = v93 * v33;
  // pto: %cmp_kv_cache_flat_inline4765__ssa_v0_view
  int64_t v98 = v96 * v97;
  // pto: %cmp_kv_cache_flat_inline4765__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v99 = pto::Shape<1, 1, 1, -1, -1>(v94, v95, v96, v93, v33);
  // pto: %cmp_kv_cache_flat_inline4765__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v100 = pto::Stride<-1, -1, -1, -1, -1>(v95 * v98, v98, v97, v33, v30);
  // pto: %cmp_kv_cache_flat_inline4765__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v101 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v99, v100);
  // pto: %kv_flat_inline4777__ssa_v0_view
  const int64_t v102 = 1;
  // pto: %kv_flat_inline4777__ssa_v0_view
  const int64_t v103 = 1;
  // pto: %kv_flat_inline4777__ssa_v0_view
  const int64_t v104 = 1;
  // pto: %kv_flat_inline4777__ssa_v0_view
  int64_t v105 = (int64_t) v13;
  // pto: %kv_flat_inline4777__ssa_v0_view
  int64_t v106 = v105 * v33;
  // pto: %kv_flat_inline4777__ssa_v0_view
  int64_t v107 = v104 * v106;
  // pto: %kv_flat_inline4777__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v108 = pto::Shape<1, 1, 1, -1, -1>(v102, v103, v104, v105, v33);
  // pto: %kv_flat_inline4777__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v109 = pto::Stride<-1, -1, -1, -1, -1>(v103 * v107, v107, v106, v33, v30);
  // pto: %kv_flat_inline4777__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v110 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v10, v108, v109);
  // pto: %cosine_inline1154_inline4759__phi_v5
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %cosine_inline1154_inline4759__phi_v5
  uint64_t v112 = (uint64_t) v20;
  TASSIGN(v111, v112);
  // pto: %sine_inline1153_inline4753__phi_v5
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %sine_inline1153_inline4753__phi_v5
  uint64_t v114 = (uint64_t) v21;
  TASSIGN(v113, v114);
  // pto: %cosine_inline1154_inline4759__phi_v4
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v115 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %cosine_inline1154_inline4759__phi_v4
  uint64_t v116 = (uint64_t) v20;
  TASSIGN(v115, v116);
  // pto: %sine_inline1153_inline4753__phi_v4
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %sine_inline1153_inline4753__phi_v4
  uint64_t v118 = (uint64_t) v21;
  TASSIGN(v117, v118);
  // pto: %rms_blk_inline4736__ssa_v0, %23
  int64_t v119 = (int64_t) ((uint64_t) ((int64_t) v17) * (uint64_t) v35);
  // pto: %24
  int64_t v120 = (int64_t) ((uint64_t) v12 - (uint64_t) v119);
  // pto: %25
  int64_t v121 = v120 < v35 ? v120 : v35;
  // pto: %cosine_inline1154_inline4759__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v122 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %cosine_inline1154_inline4759__tile
  uint64_t v123 = (uint64_t) v20;
  TASSIGN(v122, v123);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  TEXPANDS(v122, v36);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  // pto: %sine_inline1153_inline4753__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %sine_inline1153_inline4753__tile
  uint64_t v125 = (uint64_t) v21;
  TASSIGN(v124, v125);
  TEXPANDS(v124, v37);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  for (int64_t v126 = v38; v126 < v121; v126 += v30) {
    // pto: %26
    ;
    int64_t v127 = (int64_t) ((uint64_t) v119 + (uint64_t) v126);
    // pto: %position_inline1150_inline4786__tile
    ;
    int64_t v128 = (v1)[v127];
    // pto: %27
    ;
    int32_t v129 = (v2)[v127];
    // pto: %28
    ;
    int64_t v130 = (int64_t) v129;
    // pto: %30
    ;
    int64_t v131 = (int64_t) ((uint64_t) v128 + (uint64_t) v39);
    // pto: %31
    ;
    int64_t v132 = v131 % v40;
    // pto: %32, %33, %34
    ;
    int64_t v133 = v132 < v20 ? (int64_t) ((uint64_t) v132 + (uint64_t) v40) : v132;
    // pto: %29, %35, %36
    ;
    if (v130 >= v38 & v133 == v20) {
      // pto: %37
      ;
      int32_t v134 = (v3)[v130];
      // pto: %38, %42, %40
      ;
      int64_t v135 = (int64_t) ((uint64_t) ((int64_t) v134) + (uint64_t) (v131 / v40));
      // pto: %43, %44, %45
      ;
      if (v135 >= v38 & v135 < v15) {
        // pto: %gather_row_view
        ;
        int64_t v136 = (int64_t) ((uint64_t) v126 * (uint64_t) v19);
        // pto: %gather_row_view
        ;
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v137;
        // pto: %gather_row_view
        ;
        uint64_t v138 = (uint64_t) v136;
        TASSIGN(v137, v138);
        // pto: %46
        ;
        int64_t v139 = v135 < v38 ? v38 : v135;
        // pto: %cmp_freqs_cos__ssa_v0_pview
        ;
        __gm__ float* v140 = PTOAS__GLOBAL_TENSOR_DATA(v59);
        // pto: %cmp_freqs_cos__ssa_v0_pview
        ;
        const int64_t v141 = 0;
        // pto: %cmp_freqs_cos__ssa_v0_pview
        ;
        const int64_t v142 = 64;
        // pto: %cmp_freqs_cos__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 64> v143 = pto::Shape<1, 1, 1, 1, 64>();
        // pto: %cmp_freqs_cos__ssa_v0_pview
        ;
        pto::Stride<64, 64, 64, 64, 1> v144 = pto::Stride<64, 64, 64, 64, 1>();
        // pto: %cmp_freqs_cos__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v145 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v140 + (v141 + v139 * v142), v143, v144);
        TLOAD(v137, v145);
        // pto: %47
        ;
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v146;
        // pto: %47
        ;
        uint64_t v147 = (uint64_t) ((int64_t) (uint64_t) v136 + (uint64_t) v21);
        TASSIGN(v146, v147);
        // pto: %cmp_freqs_sin__ssa_v0_pview
        ;
        __gm__ float* v148 = PTOAS__GLOBAL_TENSOR_DATA(v68);
        // pto: %cmp_freqs_sin__ssa_v0_pview
        ;
        const int64_t v149 = 0;
        // pto: %cmp_freqs_sin__ssa_v0_pview
        ;
        const int64_t v150 = 64;
        // pto: %cmp_freqs_sin__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 64> v151 = pto::Shape<1, 1, 1, 1, 64>();
        // pto: %cmp_freqs_sin__ssa_v0_pview
        ;
        pto::Stride<64, 64, 64, 64, 1> v152 = pto::Stride<64, 64, 64, 64, 1>();
        // pto: %cmp_freqs_sin__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v153 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v148 + (v149 + v139 * v150), v151, v152);
        TLOAD(v146, v153);
      };
    };
  }
  // pto: %cos_b_inline4783__ssa_v0
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v154 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %cos_b_inline4783__ssa_v0
  uint64_t v155 = (uint64_t) v20;
  TASSIGN(v154, v155);
  // pto: %sin_b_inline4784__ssa_v0
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v156 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %sin_b_inline4784__ssa_v0
  uint64_t v157 = (uint64_t) v21;
  TASSIGN(v156, v157);
  // pto: %rms_low_inline4775__tile
  Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v158 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v41);
  // pto: %rms_low_inline4775__tile
  uint64_t v159 = (uint64_t) v22;
  TASSIGN(v158, v159);
  // pto: %49
  int64_t v160 = v119 < v38 ? v38 : v119;
  // pto: %pooled_kv_inline963__rv_v2_pview
  __gm__ float* v161 = PTOAS__GLOBAL_TENSOR_DATA(v76);
  // pto: %pooled_kv_inline963__rv_v2_pview
  const int64_t v162 = 0;
  // pto: %pooled_kv_inline963__rv_v2_pview
  const int64_t v163 = 512;
  // pto: %pooled_kv_inline963__rv_v2_pview
  pto::Shape<1, 1, 1, 16, 256> v164 = pto::Shape<1, 1, 1, 16, 256>();
  // pto: %pooled_kv_inline963__rv_v2_pview
  pto::Stride<8192, 8192, 8192, 512, 1> v165 = pto::Stride<8192, 8192, 8192, 512, 1>();
  // pto: %pooled_kv_inline963__rv_v2_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v166 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v161 + (v162 + v160 * v163), v164, v165);
  TLOAD(v158, v166);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %rms_high_inline4785__tile
  Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v167 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v41);
  // pto: %rms_high_inline4785__tile
  uint64_t v168 = (uint64_t) v23;
  TASSIGN(v167, v168);
  // pto: %51
  __gm__ float* v169 = PTOAS__GLOBAL_TENSOR_DATA(v76);
  // pto: %51
  const int64_t v170 = 256;
  // pto: %51
  const int64_t v171 = 512;
  // pto: %51
  pto::Shape<1, 1, 1, 16, 256> v172 = pto::Shape<1, 1, 1, 16, 256>();
  // pto: %51
  pto::Stride<8192, 8192, 8192, 512, 1> v173 = pto::Stride<8192, 8192, 8192, 512, 1>();
  // pto: %51
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v174 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v169 + (v170 + v160 * v171), v172, v173);
  TLOAD(v167, v174);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  // pto: %t__tile
  Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v41);
  // pto: %t__tile
  uint64_t v176 = (uint64_t) v22;
  TASSIGN(v175, v176);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  TMUL(v175, v158, v158);
  // pto: %2
  Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v41);
  // pto: %2
  uint64_t v178 = (uint64_t) v23;
  TASSIGN(v177, v178);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  TMUL(v177, v167, v167);
  // pto: %folded4_inline4787__tile
  Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v179 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v41);
  // pto: %folded4_inline4787__tile
  uint64_t v180 = (uint64_t) v22;
  TASSIGN(v179, v180);
  pipe_barrier(PIPE_V);
  TADD(v179, v175, v177);
  // pto: %3
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %3
  uint64_t v182 = (uint64_t) v22;
  TASSIGN(v181, v182);
  // pto: %slice_view
  Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, 16, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v183;
  // pto: %slice_view
  uint64_t v184 = (uint64_t) v22;
  TASSIGN(v183, v184);
  // pto: %4
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v185 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %4
  uint64_t v186 = (uint64_t) v24;
  TASSIGN(v185, v186);
  // pto: %52
  Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, 16, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v187;
  // pto: %52
  uint64_t v188 = (uint64_t) v24;
  TASSIGN(v187, v188);
  // pto: %folded2_inline4748__tile
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v189 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %folded2_inline4748__tile
  uint64_t v190 = (uint64_t) v22;
  TASSIGN(v189, v190);
  pipe_barrier(PIPE_V);
  TADD(v189, v183, v187);
  // pto: %5
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v191 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %5
  uint64_t v192 = (uint64_t) v22;
  TASSIGN(v191, v192);
  // pto: %53
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, 16, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v193;
  // pto: %53
  uint64_t v194 = (uint64_t) v22;
  TASSIGN(v193, v194);
  // pto: %6
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v195 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %6
  uint64_t v196 = (uint64_t) v25;
  TASSIGN(v195, v196);
  // pto: %54
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, 16, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v197;
  // pto: %54
  uint64_t v198 = (uint64_t) v25;
  TASSIGN(v197, v198);
  // pto: %folded1_inline4735__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v199 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %folded1_inline4735__tile
  uint64_t v200 = (uint64_t) v23;
  TASSIGN(v199, v200);
  pipe_barrier(PIPE_V);
  TADD(v199, v193, v197);
  // pto: %tmp_tile
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v201 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %tmp_tile
  uint64_t v202 = (uint64_t) v22;
  TASSIGN(v201, v202);
  // pto: %square_sum_inline4789__tile
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v203 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v30);
  // pto: %square_sum_inline4789__tile
  uint64_t v204 = (uint64_t) v26;
  TASSIGN(v203, v204);
  pipe_barrier(PIPE_V);
  TROWSUM(v203, v199, v201);
  // pto: %t__rm_a0_tmp_v0
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v205 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v35);
  // pto: %t__rm_a0_tmp_v0
  uint64_t v206 = (uint64_t) v26;
  TASSIGN(v205, v206);
  // pto: %t__row_major_tmp_v1
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v35);
  // pto: %t__row_major_tmp_v1
  uint64_t v208 = (uint64_t) v22;
  TASSIGN(v207, v208);
  pipe_barrier(PIPE_V);
  TMULS(v207, v205, v43);
  // pto: %7
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v209 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v30);
  // pto: %7
  uint64_t v210 = (uint64_t) v22;
  TASSIGN(v209, v210);
  // pto: %variance_inline4760__rm_a0_tmp_v2
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v35);
  // pto: %variance_inline4760__rm_a0_tmp_v2
  uint64_t v212 = (uint64_t) v22;
  TASSIGN(v211, v212);
  // pto: %variance_inline4760__row_major_tmp_v3
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v213 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v35);
  // pto: %variance_inline4760__row_major_tmp_v3
  uint64_t v214 = (uint64_t) v22;
  TASSIGN(v213, v214);
  pipe_barrier(PIPE_V);
  TADDS(v213, v211, v44);
  // pto: %variance_inline4760__tile
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v30);
  // pto: %variance_inline4760__tile
  uint64_t v216 = (uint64_t) v22;
  TASSIGN(v215, v216);
  // pto: %rms_inline4791__rm_a0_tmp_v4
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v35);
  // pto: %rms_inline4791__rm_a0_tmp_v4
  uint64_t v218 = (uint64_t) v22;
  TASSIGN(v217, v218);
  // pto: %rms_inline4791__row_major_tmp_v5
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v219 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v35);
  // pto: %rms_inline4791__row_major_tmp_v5
  uint64_t v220 = (uint64_t) v27;
  TASSIGN(v219, v220);
  pipe_barrier(PIPE_V);
  TSQRT(v219, v217);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  // pto: %rms_inline4791__tile
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v221 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v30);
  // pto: %rms_inline4791__tile
  uint64_t v222 = (uint64_t) v27;
  TASSIGN(v221, v222);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  for (int64_t v223 = v38; v223 < v45; v223 += v31) {
    // pto: %kv_norm_chunk_inline4761__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v224 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
    // pto: %kv_norm_chunk_inline4761__tile
    ;
    uint64_t v225 = (uint64_t) v22;
    TASSIGN(v224, v225);
    // pto: %56
    ;
    int64_t v226 = v223 < v38 ? v38 : v223;
    // pto: %57
    ;
    __gm__ float* v227 = PTOAS__GLOBAL_TENSOR_DATA(v76);
    // pto: %57
    ;
    const int64_t v228 = 0;
    // pto: %57
    ;
    const int64_t v229 = 512;
    // pto: %57
    ;
    pto::Shape<1, 1, 1, 16, 64> v230 = pto::Shape<1, 1, 1, 16, 64>();
    // pto: %57
    ;
    pto::Stride<8192, 8192, 8192, 512, 1> v231 = pto::Stride<8192, 8192, 8192, 512, 1>();
    // pto: %57
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v232 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v227 + (v228 + v160 * v229 + v226), v230, v231);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v224, v232);
    // pto: %8
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v233 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %8
    ;
    uint64_t v234 = (uint64_t) v26;
    TASSIGN(v233, v234);
    // pto: %norm_w_2d_inline4740__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v235 = PTOAS__GLOBAL_TENSOR_DATA(v92);
    // pto: %norm_w_2d_inline4740__ssa_v0_pview
    ;
    const int64_t v236 = 0;
    // pto: %norm_w_2d_inline4740__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 64> v237 = pto::Shape<1, 1, 1, 1, 64>();
    // pto: %norm_w_2d_inline4740__ssa_v0_pview
    ;
    pto::Stride<512, 512, 512, 512, 1> v238 = pto::Stride<512, 512, 512, 512, 1>();
    // pto: %norm_w_2d_inline4740__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v239 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v235 + (v236 + v226), v237, v238);
    TLOAD(v233, v239);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    // pto: %gamma_inline4793__tile
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v240 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %gamma_inline4793__tile
    ;
    uint64_t v241 = (uint64_t) v23;
    TASSIGN(v240, v241);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    RoundMode v242 = RoundMode::CAST_ROUND;
    SaturationMode v243 = SaturationMode::ON;
    TCVT(v240, v233, v242, v243);
    // pto: %9
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v244 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
    // pto: %9
    ;
    uint64_t v245 = (uint64_t) v22;
    TASSIGN(v244, v245);
    TROWEXPANDDIV(v244, v224, v221);
    // pto: %normed_chunk_inline4780__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v246 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
    // pto: %normed_chunk_inline4780__tile
    ;
    uint64_t v247 = (uint64_t) v22;
    TASSIGN(v246, v247);
    pipe_barrier(PIPE_V);
    TCOLEXPANDMUL(v246, v244, v240);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %normed_kv_inline4742__iter_v1_pview
    ;
    __gm__ float* v248 = PTOAS__GLOBAL_TENSOR_DATA(v84);
    // pto: %normed_kv_inline4742__iter_v1_pview
    ;
    const int64_t v249 = 0;
    // pto: %normed_kv_inline4742__iter_v1_pview
    ;
    const int64_t v250 = 512;
    // pto: %normed_kv_inline4742__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 64> v251 = pto::Shape<1, 1, 1, 16, 64>();
    // pto: %normed_kv_inline4742__iter_v1_pview
    ;
    pto::Stride<8192, 8192, 8192, 512, 1> v252 = pto::Stride<8192, 8192, 8192, 512, 1>();
    // pto: %normed_kv_inline4742__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v253 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v248 + (v249 + v160 * v250 + v226), v251, v252);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v253, v246);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  // pto: %kv_rope_norm_inline4750__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v254 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %kv_rope_norm_inline4750__tile
  uint64_t v255 = (uint64_t) v22;
  TASSIGN(v254, v255);
  // pto: %62
  __gm__ float* v256 = PTOAS__GLOBAL_TENSOR_DATA(v76);
  // pto: %62
  const int64_t v257 = 448;
  // pto: %62
  const int64_t v258 = 512;
  // pto: %62
  pto::Shape<1, 1, 1, 16, 64> v259 = pto::Shape<1, 1, 1, 16, 64>();
  // pto: %62
  pto::Stride<8192, 8192, 8192, 512, 1> v260 = pto::Stride<8192, 8192, 8192, 512, 1>();
  // pto: %62
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v261 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v256 + (v257 + v160 * v258), v259, v260);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  TLOAD(v254, v261);
  // pto: %10
  Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v262 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
  // pto: %10
  uint64_t v263 = (uint64_t) v26;
  TASSIGN(v262, v263);
  // pto: %63
  __gm__ bfloat16_t* v264 = PTOAS__GLOBAL_TENSOR_DATA(v92);
  // pto: %63
  unsigned v265 = 448;
  // pto: %63
  pto::Shape<1, 1, 1, 1, 64> v266 = pto::Shape<1, 1, 1, 1, 64>();
  // pto: %63
  pto::Stride<512, 512, 512, 512, 1> v267 = pto::Stride<512, 512, 512, 512, 1>();
  // pto: %63
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v268 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v264 + v265, v266, v267);
  TLOAD(v262, v268);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
  // pto: %gamma_rope_inline4757__tile
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v269 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
  // pto: %gamma_rope_inline4757__tile
  uint64_t v270 = (uint64_t) v23;
  TASSIGN(v269, v270);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
  RoundMode v271 = RoundMode::CAST_ROUND;
  SaturationMode v272 = SaturationMode::ON;
  TCVT(v269, v262, v271, v272);
  // pto: %11
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v273 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %11
  uint64_t v274 = (uint64_t) v22;
  TASSIGN(v273, v274);
  TROWEXPANDDIV(v273, v254, v221);
  // pto: %rope_normed_inline4768__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v275 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %rope_normed_inline4768__tile
  uint64_t v276 = (uint64_t) v22;
  TASSIGN(v275, v276);
  pipe_barrier(PIPE_V);
  TCOLEXPANDMUL(v275, v273, v269);
  // pto: %rope_ones_inline4782__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v277 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %rope_ones_inline4782__tile
  uint64_t v278 = (uint64_t) v23;
  TASSIGN(v277, v278);
  pipe_barrier(PIPE_V);
  TEXPANDS(v277, v36);
  // pto: %rope_index_inline4746__ci_tmp_v0
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v279 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v46);
  // pto: %rope_index_inline4746__ci_tmp_v0
  uint64_t v280 = (uint64_t) v26;
  TASSIGN(v279, v280);
  // pto: %rope_index_inline4746__tile
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v281 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
  // pto: %rope_index_inline4746__tile
  uint64_t v282 = (uint64_t) v27;
  TASSIGN(v281, v282);
  // pto: %ci_tmp_view
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v283;
  TRESHAPE(v283, v279);
  // pto: %ci_dst_view
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v284;
  TRESHAPE(v284, v281);
  TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v284, v47, v283);
  // pto: %rope_index_f_inline4794__tile
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v285 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
  // pto: %rope_index_f_inline4794__tile
  uint64_t v286 = (uint64_t) v26;
  TASSIGN(v285, v286);
  pipe_barrier(PIPE_V);
  RoundMode v287 = RoundMode::CAST_ROUND;
  SaturationMode v288 = SaturationMode::ON;
  TCVT(v285, v281, v287, v288);
  // pto: %rope_col_inline4796__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v289 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %rope_col_inline4796__tile
  uint64_t v290 = (uint64_t) v23;
  TASSIGN(v289, v290);
  pipe_barrier(PIPE_V);
  TCOLEXPANDMUL(v289, v277, v285);
  // pto: %12
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v291 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %12
  uint64_t v292 = (uint64_t) v26;
  TASSIGN(v291, v292);
  pipe_barrier(PIPE_V);
  TMULS(v291, v289, v48);
  // pto: %13
  Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v293 = Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %13
  uint64_t v294 = (uint64_t) v26;
  TASSIGN(v293, v294);
  pipe_barrier(PIPE_V);
  RoundMode v295 = RoundMode::CAST_TRUNC;
  SaturationMode v296 = SaturationMode::ON;
  TCVT(v293, v291, v295, v296);
  // pto: %rope_dup_f_inline4773__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v297 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %rope_dup_f_inline4773__tile
  uint64_t v298 = (uint64_t) v26;
  TASSIGN(v297, v298);
  pipe_barrier(PIPE_V);
  RoundMode v299 = RoundMode::CAST_ROUND;
  SaturationMode v300 = SaturationMode::ON;
  TCVT(v297, v293, v299, v300);
  // pto: %14
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v301 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %14
  uint64_t v302 = (uint64_t) v26;
  TASSIGN(v301, v302);
  pipe_barrier(PIPE_V);
  TMULS(v301, v297, v49);
  // pto: %rope_lane_inline4790__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v303 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %rope_lane_inline4790__tile
  uint64_t v304 = (uint64_t) v26;
  TASSIGN(v303, v304);
  pipe_barrier(PIPE_V);
  TSUB(v303, v289, v301);
  // pto: %15
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v305 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %15
  uint64_t v306 = (uint64_t) v23;
  TASSIGN(v305, v306);
  pipe_barrier(PIPE_V);
  TADDS(v305, v289, v36);
  // pto: %16
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v307 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %16
  uint64_t v308 = (uint64_t) v27;
  TASSIGN(v307, v308);
  TMULS(v307, v303, v49);
  // pto: %17
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %17
  uint64_t v310 = (uint64_t) v23;
  TASSIGN(v309, v310);
  pipe_barrier(PIPE_V);
  TSUB(v309, v305, v307);
  // pto: %rope_swap_idx_inline4781__tile
  Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v311 = Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %rope_swap_idx_inline4781__tile
  uint64_t v312 = (uint64_t) v23;
  TASSIGN(v311, v312);
  pipe_barrier(PIPE_V);
  RoundMode v313 = RoundMode::CAST_ROUND;
  SaturationMode v314 = SaturationMode::ON;
  TCVT(v311, v309, v313, v314);
  // pto: %gather_acc_init
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %gather_acc_init
  uint64_t v316 = (uint64_t) v27;
  TASSIGN(v315, v316);
  for (int64_t v317 = v38; v317 < v35; v317 += v30) {
    // pto: %gather_inp_row
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v318 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %gather_inp_row
    ;
    uint64_t v319 = (uint64_t) v22;
    TASSIGN(v318, v319);
    // pto: %64
    ;
    int64_t v320 = (int64_t) ((uint64_t) v317 * (uint64_t) v19);
    // pto: %64
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v321;
    // pto: %64
    ;
    uint64_t v322 = (uint64_t) ((int64_t) (uint64_t) v320 + (uint64_t) v22);
    TASSIGN(v321, v322);
    // pto: %gather_idx_row
    ;
    Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v323 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %gather_idx_row
    ;
    uint64_t v324 = (uint64_t) v23;
    TASSIGN(v323, v324);
    // pto: %65
    ;
    Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v325;
    // pto: %65
    ;
    uint64_t v326 = (uint64_t) ((int64_t) (uint64_t) v320 + (uint64_t) v23);
    TASSIGN(v325, v326);
    // pto: %gather_row_tmp
    ;
    Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v327 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %gather_row_tmp
    ;
    uint64_t v328 = (uint64_t) v28;
    TASSIGN(v327, v328);
    // pto: %gather_row
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v329 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %gather_row
    ;
    uint64_t v330 = (uint64_t) v29;
    TASSIGN(v329, v330);
    pipe_barrier(PIPE_V);
    TGATHER(v329, v321, v325, v327);
    // pto: %assemble_view
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v331;
    // pto: %assemble_view
    ;
    uint64_t v332 = (uint64_t) ((int64_t) (uint64_t) v320 + (uint64_t) v27);
    TASSIGN(v331, v332);
    pipe_barrier(PIPE_V);
    TMOV(v331, v329);
  }
  // pto: %swapped_inline4739__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v333 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %swapped_inline4739__tile
  uint64_t v334 = (uint64_t) v27;
  TASSIGN(v333, v334);
  // pto: %18
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v335 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %18
  uint64_t v336 = (uint64_t) v23;
  TASSIGN(v335, v336);
  pipe_barrier(PIPE_V);
  TMULS(v335, v303, v49);
  // pto: %19
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v337 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %19
  uint64_t v338 = (uint64_t) v23;
  TASSIGN(v337, v338);
  pipe_barrier(PIPE_V);
  TSUBS(v337, v335, v36);
  // pto: %sin_signed_inline4734__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v339 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %sin_signed_inline4734__tile
  uint64_t v340 = (uint64_t) v23;
  TASSIGN(v339, v340);
  pipe_barrier(PIPE_V);
  TMUL(v339, v156, v337);
  // pto: %20
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v341 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %20
  uint64_t v342 = (uint64_t) v22;
  TASSIGN(v341, v342);
  TMUL(v341, v275, v154);
  // pto: %21
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v343 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %21
  uint64_t v344 = (uint64_t) v23;
  TASSIGN(v343, v344);
  pipe_barrier(PIPE_V);
  TMUL(v343, v333, v339);
  // pto: %rope_rot_inline4733__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v345 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %rope_rot_inline4733__tile
  uint64_t v346 = (uint64_t) v22;
  TASSIGN(v345, v346);
  pipe_barrier(PIPE_V);
  TADD(v345, v341, v343);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
  // pto: %normed_kv_inline4742__rv_v2_pview
  __gm__ float* v347 = PTOAS__GLOBAL_TENSOR_DATA(v84);
  // pto: %normed_kv_inline4742__rv_v2_pview
  const int64_t v348 = 448;
  // pto: %normed_kv_inline4742__rv_v2_pview
  const int64_t v349 = 512;
  // pto: %normed_kv_inline4742__rv_v2_pview
  pto::Shape<1, 1, 1, 16, 64> v350 = pto::Shape<1, 1, 1, 16, 64>();
  // pto: %normed_kv_inline4742__rv_v2_pview
  pto::Stride<8192, 8192, 8192, 512, 1> v351 = pto::Stride<8192, 8192, 8192, 512, 1>();
  // pto: %normed_kv_inline4742__rv_v2_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v352 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v347 + (v348 + v160 * v349), v350, v351);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
  TSTORE(v352, v345);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  for (int64_t v353 = v38; v353 < v121; v353 += v30) {
    // pto: %68
    ;
    int64_t v354 = (int64_t) ((uint64_t) v119 + (uint64_t) v353);
    // pto: %token_pos_inline4741__tile
    ;
    int64_t v355 = (v1)[v354];
    // pto: %69
    ;
    int32_t v356 = (v2)[v354];
    // pto: %70
    ;
    int64_t v357 = (int64_t) v356;
    // pto: %72
    ;
    int64_t v358 = (int64_t) ((uint64_t) v355 + (uint64_t) v39);
    // pto: %73
    ;
    int64_t v359 = v358 % v40;
    // pto: %74, %75, %76
    ;
    int64_t v360 = v359 < v20 ? (int64_t) ((uint64_t) v359 + (uint64_t) v40) : v359;
    // pto: %71, %77, %78
    ;
    if (v357 >= v38 & v360 == v20) {
      // pto: %79
      ;
      int32_t v361 = (v3)[v357];
      // pto: %80, %84, %82
      ;
      int64_t v362 = (int64_t) ((uint64_t) ((int64_t) v361) + (uint64_t) (v358 / v40));
      // pto: %85, %86, %87
      ;
      if (v362 >= v38 & v362 < v15) {
        // pto: %flat_offset_mul
        ;
        int64_t v363 = (int64_t) ((uint64_t) v362 * (uint64_t) v34);
        // pto: %cache_page_inline4738__tile
        ;
        int32_t v364 = (v11)[v363];
        // pto: %89, %cache_offset_inline4745__tile
        ;
        int32_t v365 = (v11)[(int64_t) ((uint64_t) v363 + (uint64_t) v30)];
        // pto: %90
        ;
        int64_t v366 = (int64_t) v364;
        // pto: %92
        ;
        int64_t v367 = (int64_t) v365;
        // pto: %91, %93, %94
        ;
        if (v366 >= v38 & v367 >= v38) {
          // pto: %96, %98
          ;
          int64_t v368 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v366 * (uint64_t) v50) + (uint64_t) v367);
          // pto: %kv_row_fp32_inline4729__tile
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v369 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
          // pto: %kv_row_fp32_inline4729__tile
          ;
          uint64_t v370 = (uint64_t) v22;
          TASSIGN(v369, v370);
          // pto: %99
          ;
          int64_t v371 = v354 < v38 ? v38 : v354;
          // pto: %normed_kv_inline4742__tile_pview
          ;
          __gm__ float* v372 = PTOAS__GLOBAL_TENSOR_DATA(v84);
          // pto: %normed_kv_inline4742__tile_pview
          ;
          const int64_t v373 = 0;
          // pto: %normed_kv_inline4742__tile_pview
          ;
          const int64_t v374 = 512;
          // pto: %normed_kv_inline4742__tile_pview
          ;
          pto::Shape<1, 1, 1, 1, 512> v375 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %normed_kv_inline4742__tile_pview
          ;
          pto::Stride<512, 512, 512, 512, 1> v376 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %normed_kv_inline4742__tile_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v377 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v372 + (v373 + v371 * v374), v375, v376);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
          TLOAD(v369, v377);
          set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
          // pto: %kv_flat_inline4777__iter_v1_pview
          ;
          __gm__ float* v378 = PTOAS__GLOBAL_TENSOR_DATA(v110);
          // pto: %kv_flat_inline4777__iter_v1_pview
          ;
          const int64_t v379 = 0;
          // pto: %kv_flat_inline4777__iter_v1_pview
          ;
          const int64_t v380 = 512;
          // pto: %kv_flat_inline4777__iter_v1_pview
          ;
          pto::Shape<1, 1, 1, 1, 512> v381 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %kv_flat_inline4777__iter_v1_pview
          ;
          pto::Stride<512, 512, 512, 512, 1> v382 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %kv_flat_inline4777__iter_v1_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v383 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v378 + (v379 + v371 * v380), v381, v382);
          wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
          TSTORE(v383, v369);
          set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
          // pto: %22
          ;
          Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v384 = Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
          // pto: %22
          ;
          uint64_t v385 = (uint64_t) v22;
          TASSIGN(v384, v385);
          wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
          RoundMode v386 = RoundMode::CAST_RINT;
          SaturationMode v387 = SaturationMode::ON;
          TCVT(v384, v369, v386, v387);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          // pto: %101
          ;
          int64_t v388 = v368 < v38 ? v38 : v368;
          // pto: %cmp_kv_cache_flat_inline4765__iter_v1_pview
          ;
          __gm__ bfloat16_t* v389 = PTOAS__GLOBAL_TENSOR_DATA(v101);
          // pto: %cmp_kv_cache_flat_inline4765__iter_v1_pview
          ;
          const int64_t v390 = 0;
          // pto: %cmp_kv_cache_flat_inline4765__iter_v1_pview
          ;
          const int64_t v391 = 512;
          // pto: %cmp_kv_cache_flat_inline4765__iter_v1_pview
          ;
          pto::Shape<1, 1, 1, 1, 512> v392 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %cmp_kv_cache_flat_inline4765__iter_v1_pview
          ;
          pto::Stride<512, 512, 512, 512, 1> v393 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %cmp_kv_cache_flat_inline4765__iter_v1_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v394 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v389 + (v390 + v388 * v391), v392, v393);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          TSTORE(v394, v384);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        };
      };
    };
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}