#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qr_proj_matmul_1(__gm__ float* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, int64_t v4, int64_t v5, int64_t v6, int64_t v7, int64_t v8, int64_t v9, int32_t v10, int32_t v11) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v12 = 0;
  // pto: %c32768_i64
  const int64_t v13 = 32768;
  // pto: %c49152_i64
  const int64_t v14 = 49152;
  // pto: %c81920_i64
  const int64_t v15 = 81920;
  // pto: %c16384_i64
  const int64_t v16 = 16384;
  // pto: %c1024_index
  const int64_t v17 = 1024;
  // pto: %c1_index
  const int64_t v18 = 1;
  // pto: %c4096_index
  const int64_t v19 = 4096;
  // pto: %c256_index
  const int64_t v20 = 256;
  // pto: %c64_index
  const int64_t v21 = 64;
  // pto: %c16_index
  const int64_t v22 = 16;
  // pto: %c4194304_index
  const int64_t v23 = 4194304;
  // pto: %c16384_index
  const int64_t v24 = 16384;
  // pto: %c32_index
  const int64_t v25 = 32;
  // pto: %c96_index
  const int64_t v26 = 96;
  // pto: %c0_index
  const int64_t v27 = 0;
  // pto: %c2_index
  const int64_t v28 = 2;
  // pto: %c240_index
  const int64_t v29 = 240;
  // pto: %c48_index
  const int64_t v30 = 48;
  // pto: %c9_index
  const int64_t v31 = 9;
  // pto: %c15_index
  const int64_t v32 = 15;
  // pto: %c3_index
  const int64_t v33 = 3;
  // pto: %c14_index
  const int64_t v34 = 14;
  // pto: %cn1_index
  const int64_t v35 = -1;
  // pto: %qr_fp32_inline0_inline4577__rv_v24_view
  const int64_t v36 = 1;
  // pto: %qr_fp32_inline0_inline4577__rv_v24_view
  const int64_t v37 = 1;
  // pto: %qr_fp32_inline0_inline4577__rv_v24_view
  const int64_t v38 = 1;
  // pto: %qr_fp32_inline0_inline4577__rv_v24_view
  int64_t v39 = (int64_t) v8;
  // pto: %qr_fp32_inline0_inline4577__rv_v24_view
  int64_t v40 = v39 * v17;
  // pto: %qr_fp32_inline0_inline4577__rv_v24_view
  int64_t v41 = v38 * v40;
  // pto: %qr_fp32_inline0_inline4577__rv_v24_view
  pto::Shape<1, 1, 1, -1, -1> v42 = pto::Shape<1, 1, 1, -1, -1>(v36, v37, v38, v39, v17);
  // pto: %qr_fp32_inline0_inline4577__rv_v24_view
  pto::Stride<-1, -1, -1, -1, -1> v43 = pto::Stride<-1, -1, -1, -1, -1>(v37 * v41, v41, v40, v17, v18);
  // pto: %qr_fp32_inline0_inline4577__rv_v24_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v44 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v42, v43);
  // pto: %x_view_inline8142__ssa_v0_view
  const int64_t v45 = 1;
  // pto: %x_view_inline8142__ssa_v0_view
  const int64_t v46 = 1;
  // pto: %x_view_inline8142__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %x_view_inline8142__ssa_v0_view
  int64_t v48 = (int64_t) v9;
  // pto: %x_view_inline8142__ssa_v0_view
  int64_t v49 = v48 * v19;
  // pto: %x_view_inline8142__ssa_v0_view
  int64_t v50 = v47 * v49;
  // pto: %x_view_inline8142__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v51 = pto::Shape<1, 1, 1, -1, -1>(v45, v46, v47, v48, v19);
  // pto: %x_view_inline8142__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v52 = pto::Stride<-1, -1, -1, -1, -1>(v46 * v50, v50, v49, v19, v18);
  // pto: %x_view_inline8142__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v53 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v51, v52);
  // pto: %wq_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v54 = pto::Shape<-1, -1, -1, -1, -1>(v18, v20, v21, v22, v22);
  // pto: %wq_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v55 = pto::Stride<-1, -1, -1, -1, -1>(v23, v24, v20, v22, v18);
  // pto: %wq_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v56 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v3, v54, v55);
  // pto: %qbg_idx_inline8130__ssa_v0, %14
  int64_t v57 = (int64_t) ((uint64_t) ((int64_t) v10) * (uint64_t) v25);
  // pto: %15
  int64_t v58 = v57 / v26;
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  for (int64_t v59 = v27; v59 < v4; v59 += v21) {
    // pto: %16
    ;
    int64_t v60 = (int64_t) ((uint64_t) v5 + (uint64_t) v59);
    // pto: %dense_acc_inline8150__tile
    ;
    Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v61 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v21, v25);
    // pto: %dense_acc_inline8150__tile
    ;
    uint64_t v62 = (uint64_t) v12;
    TASSIGN(v61, v62);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    for (int64_t v63 = v27; v63 < v22; v63 += v28) {
      // pto: %17
      ;
      int64_t v64 = (int64_t) ((uint64_t) v63 + (uint64_t) v18);
      // pto: %21
      ;
      int64_t v65 = v6 % v30;
      // pto: %22, %23, %24
      ;
      int64_t v66 = v65 < v27 ? (int64_t) ((uint64_t) v65 + (uint64_t) v30) : v65;
      // pto: %18, %19, %20, %25, %26, %27, %28
      ;
      bool v67 = (v6 >= v26 & v6 <= v29 & v66 == v27) & v58 < v31;
      // pto: %dense_k_order_inline8129__phi_v2
      ;
      int64_t v68;
      if (v67) {
        // pto: %29
        ;
        int64_t v69 = v58 % v28;
        // pto: %30, %31, %32
        ;
        int64_t v70 = v69 < v27 ? (int64_t) ((uint64_t) v69 + (uint64_t) v28) : v69;
        // pto: %33
        ;
        // pto: %dense_k_direction_inline8143__phi_v2
        ;
        int64_t v71;
        if (v70 == v18) {
          // pto: %34
          ;
          v71 = (int64_t) ((uint64_t) v32 - (uint64_t) v63);
        } else {
          v71 = v63;
        };
        // pto: %37
        ;
        uint64_t v72 = (uint64_t) v71;
        // pto: %35, %36, %37, %38
        ;
        int64_t v73 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) (v58 / v28) * (uint64_t) v33) + v72) % v22;
        // pto: %39, %40, %41
        ;
        v68 = v73 < v27 ? (int64_t) ((uint64_t) v73 + (uint64_t) v22) : v73;
      } else {
        v68 = v63;
      };
      // pto: %42
      ;
      bool v74 = v68 < v27;
      // pto: %42
      ;
      int64_t v75 = v74 ? v27 : v68;
      // pto: %43
      ;
      int64_t v76 = (int64_t) ((uint64_t) v75 * (uint64_t) v20);
      // pto: %dense_x_inline8144__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v77 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v21, v20);
      // pto: %dense_x_inline8144__tile
      ;
      uint64_t v78 = (uint64_t) v12;
      TASSIGN(v77, v78);
      // pto: %44
      ;
      int64_t v79 = v60 < v27 ? v27 : v60;
      // pto: %45
      ;
      int64_t v80 = v76 < v27 ? v27 : v76;
      // pto: %x_view_inline8142__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v81 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %x_view_inline8142__ssa_v0_pview
      ;
      const int64_t v82 = 0;
      // pto: %x_view_inline8142__ssa_v0_pview
      ;
      const int64_t v83 = 4096;
      // pto: %x_view_inline8142__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 64, 256> v84 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %x_view_inline8142__ssa_v0_pview
      ;
      pto::Stride<262144, 262144, 262144, 4096, 1> v85 = pto::Stride<262144, 262144, 262144, 4096, 1>();
      // pto: %x_view_inline8142__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND> v86 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND>(v81 + (v82 + v79 * v83 + v80), v84, v85);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v77, v86);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %dense_w_inline8145__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v87 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v20);
      // pto: %dense_w_inline8145__tile
      ;
      uint64_t v88 = (uint64_t) v13;
      TASSIGN(v87, v88);
      // pto: %46
      ;
      int64_t v89 = v76 / v22;
      // pto: %47
      ;
      int64_t v90 = v89 < v27 ? v27 : v89;
      // pto: %48
      ;
      int64_t v91 = v57 / v22;
      // pto: %49
      ;
      int64_t v92 = v91 < v27 ? v27 : v91;
      // pto: %wq_a__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v93 = PTOAS__GLOBAL_TENSOR_DATA(v56);
      // pto: %wq_a__ssa_v0_pview
      ;
      const int64_t v94 = 0;
      // pto: %wq_a__ssa_v0_pview
      ;
      const int64_t v95 = 16384;
      // pto: %wq_a__ssa_v0_pview
      ;
      const int64_t v96 = 256;
      // pto: %wq_a__ssa_v0_pview
      ;
      pto::Shape<1, 16, 2, 16, 16> v97 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %wq_a__ssa_v0_pview
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v98 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %wq_a__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v99 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v93 + (v94 + v90 * v95 + v92 * v96), v97, v98);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v87, v99);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %61
      ;
      int64_t v100;
      if (v67) {
        // pto: %63
        ;
        int64_t v101 = v58 % v28;
        // pto: %64, %65, %66
        ;
        int64_t v102 = v101 < v27 ? (int64_t) ((uint64_t) v101 + (uint64_t) v28) : v101;
        // pto: %67
        ;
        // pto: %68
        ;
        int64_t v103;
        if (v102 == v18) {
          // pto: %69
          ;
          v103 = (int64_t) ((uint64_t) v34 - (uint64_t) v63);
        } else {
          v103 = v64;
        };
        // pto: %72
        ;
        uint64_t v104 = (uint64_t) v103;
        // pto: %70, %71, %72, %73
        ;
        int64_t v105 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) (v58 / v28) * (uint64_t) v33) + v104) % v22;
        // pto: %74, %75, %76
        ;
        v100 = v105 < v27 ? (int64_t) ((uint64_t) v105 + (uint64_t) v22) : v105;
      } else {
        v100 = v64;
      };
      // pto: %77
      ;
      bool v106 = v100 < v27;
      // pto: %77
      ;
      int64_t v107 = v106 ? v27 : v100;
      // pto: %78
      ;
      int64_t v108 = (int64_t) ((uint64_t) v107 * (uint64_t) v20);
      // pto: %0
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v109 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v21, v20);
      // pto: %0
      ;
      uint64_t v110 = (uint64_t) v14;
      TASSIGN(v109, v110);
      // pto: %80
      ;
      int64_t v111 = v108 < v27 ? v27 : v108;
      // pto: %81
      ;
      __gm__ bfloat16_t* v112 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %81
      ;
      const int64_t v113 = 0;
      // pto: %81
      ;
      const int64_t v114 = 4096;
      // pto: %81
      ;
      pto::Shape<1, 1, 1, 64, 256> v115 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %81
      ;
      pto::Stride<262144, 262144, 262144, 4096, 1> v116 = pto::Stride<262144, 262144, 262144, 4096, 1>();
      // pto: %81
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND> v117 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND>(v112 + (v113 + v79 * v114 + v111), v115, v116);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v109, v117);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      // pto: %1
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v118 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v20);
      // pto: %1
      ;
      uint64_t v119 = (uint64_t) v15;
      TASSIGN(v118, v119);
      // pto: %82
      ;
      int64_t v120 = v108 / v22;
      // pto: %83
      ;
      int64_t v121 = v120 < v27 ? v27 : v120;
      // pto: %86
      ;
      __gm__ bfloat16_t* v122 = PTOAS__GLOBAL_TENSOR_DATA(v56);
      // pto: %86
      ;
      const int64_t v123 = 0;
      // pto: %86
      ;
      const int64_t v124 = 16384;
      // pto: %86
      ;
      const int64_t v125 = 256;
      // pto: %86
      ;
      pto::Shape<1, 16, 2, 16, 16> v126 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %86
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v127 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %86
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v128 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v122 + (v123 + v121 * v124 + v92 * v125), v126, v127);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v118, v128);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %dense_w_inline8145__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %dense_w_inline8145__tile_t
      ;
      uint64_t v130 = (uint64_t) v13;
      TASSIGN(v129, v130);
      // pto: %dense_x_inline8144__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v21, v20);
      // pto: %dense_x_inline8144__tile_Left
      ;
      uint64_t v132 = (uint64_t) v13;
      TASSIGN(v131, v132);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      TMOV(v131, v77);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %dense_w_inline8145__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %dense_w_inline8145__tile_t_Right
      ;
      uint64_t v134 = (uint64_t) v16;
      TASSIGN(v133, v134);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      TMOV(v133, v129);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %87
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (v63 == v27) {
        pipe_barrier(PIPE_M);
        TMATMUL(v61, v131, v133);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v61, v61, v131, v133);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      // pto: %3
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v135 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %3
      ;
      uint64_t v136 = (uint64_t) v15;
      TASSIGN(v135, v136);
      // pto: %4
      ;
      Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v21, v20);
      // pto: %4
      ;
      uint64_t v138 = (uint64_t) v12;
      TASSIGN(v137, v138);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      TMOV(v137, v109);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      // pto: %5
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v139 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %5
      ;
      uint64_t v140 = (uint64_t) v12;
      TASSIGN(v139, v140);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      TMOV(v139, v135);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      // pto: %88
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      if (v63 == v35) {
        pipe_barrier(PIPE_M);
        TMATMUL(v61, v137, v139);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v61, v61, v137, v139);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    };
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %89
    ;
    int64_t v141 = v59 < v27 ? v27 : v59;
    // pto: %90
    ;
    int64_t v142 = v57 < v27 ? v27 : v57;
    // pto: %qr_fp32_inline0_inline4577__iter_v28_pview
    ;
    __gm__ float* v143 = PTOAS__GLOBAL_TENSOR_DATA(v44);
    // pto: %qr_fp32_inline0_inline4577__iter_v28_pview
    ;
    const int64_t v144 = 0;
    // pto: %qr_fp32_inline0_inline4577__iter_v28_pview
    ;
    const int64_t v145 = 1024;
    // pto: %qr_fp32_inline0_inline4577__iter_v28_pview
    ;
    pto::Shape<1, 1, 1, 64, 32> v146 = pto::Shape<1, 1, 1, 64, 32>();
    // pto: %qr_fp32_inline0_inline4577__iter_v28_pview
    ;
    pto::Stride<65536, 65536, 65536, 1024, 1> v147 = pto::Stride<65536, 65536, 65536, 1024, 1>();
    // pto: %qr_fp32_inline0_inline4577__iter_v28_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 64, 32>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND> v148 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 32>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND>(v143 + (v144 + v141 * v145 + v142), v146, v147);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE(v148, v61);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  for (int64_t v149 = v4; v149 < v7; v149 += v22) {
    // pto: %q_acc_inline8149__tile
    ;
    Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v150 = Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %q_acc_inline8149__tile
    ;
    uint64_t v151 = (uint64_t) v12;
    TASSIGN(v150, v151);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    for (int64_t v152 = v27; v152 < v22; v152 += v28) {
      // pto: %91
      ;
      int64_t v153 = (int64_t) ((uint64_t) v6 - (uint64_t) v149);
      // pto: %92
      ;
      int64_t v154 = v153 < v22 ? v153 : v22;
      // pto: %93
      ;
      int64_t v155 = (int64_t) ((uint64_t) v5 + (uint64_t) v149);
      // pto: %94
      ;
      int64_t v156 = (int64_t) ((uint64_t) v152 + (uint64_t) v18);
      // pto: %101
      ;
      int64_t v157 = v6 % v30;
      // pto: %102, %103, %104
      ;
      int64_t v158 = v157 < v27 ? (int64_t) ((uint64_t) v157 + (uint64_t) v30) : v157;
      // pto: %98, %99, %100, %105, %106, %107, %108
      ;
      bool v159 = (v6 >= v26 & v6 <= v29 & v158 == v27) & v58 < v31;
      // pto: %qr_k_order_inline8153__phi_v2
      ;
      int64_t v160;
      if (v159) {
        // pto: %109
        ;
        int64_t v161 = v58 % v28;
        // pto: %110, %111, %112
        ;
        int64_t v162 = v161 < v27 ? (int64_t) ((uint64_t) v161 + (uint64_t) v28) : v161;
        // pto: %113
        ;
        // pto: %qr_k_direction_inline8154__phi_v2
        ;
        int64_t v163;
        if (v162 == v18) {
          // pto: %114
          ;
          v163 = (int64_t) ((uint64_t) v32 - (uint64_t) v152);
        } else {
          v163 = v152;
        };
        // pto: %117
        ;
        uint64_t v164 = (uint64_t) v163;
        // pto: %115, %116, %117, %118
        ;
        int64_t v165 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) (v58 / v28) * (uint64_t) v33) + v164) % v22;
        // pto: %119, %120, %121
        ;
        v160 = v165 < v27 ? (int64_t) ((uint64_t) v165 + (uint64_t) v22) : v165;
      } else {
        v160 = v152;
      };
      // pto: %122
      ;
      bool v166 = v160 < v27;
      // pto: %122
      ;
      int64_t v167 = v166 ? v27 : v160;
      // pto: %123
      ;
      int64_t v168 = (int64_t) ((uint64_t) v167 * (uint64_t) v20);
      // pto: %q_x_chunk_bf16_inline8126__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v154, v20);
      // pto: %q_x_chunk_bf16_inline8126__tile
      ;
      uint64_t v170 = (uint64_t) v13;
      TASSIGN(v169, v170);
      // pto: %124
      ;
      int64_t v171 = v155 < v27 ? v27 : v155;
      // pto: %125
      ;
      int64_t v172 = v168 < v27 ? v27 : v168;
      // pto: %126
      ;
      const int64_t v173 = 0;
      // pto: %126
      ;
      __gm__ bfloat16_t* v174 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %126
      ;
      const int64_t v175 = 1;
      // pto: %126
      ;
      const int64_t v176 = 1;
      // pto: %126
      ;
      const int64_t v177 = 1;
      // pto: %126
      ;
      int64_t v178 = v154 * v19;
      // pto: %126
      ;
      int64_t v179 = v177 * v178;
      // pto: %126
      ;
      pto::Shape<1, 1, 1, -1, 256> v180 = pto::Shape<1, 1, 1, -1, 256>(v175, v176, v177, v154, v20);
      // pto: %126
      ;
      pto::Stride<-1, -1, -1, -1, -1> v181 = pto::Stride<-1, -1, -1, -1, -1>(v176 * v179, v179, v178, v19, v18);
      // pto: %126
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v182 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v174 + (v173 + v171 * v19 + v172 * v18), v180, v181);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      TLOAD(v169, v182);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      // pto: %w_chunk_inline8125__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v20);
      // pto: %w_chunk_inline8125__tile
      ;
      uint64_t v184 = (uint64_t) v12;
      TASSIGN(v183, v184);
      // pto: %127
      ;
      int64_t v185 = v168 / v22;
      // pto: %128
      ;
      int64_t v186 = v185 < v27 ? v27 : v185;
      // pto: %129
      ;
      int64_t v187 = v57 / v22;
      // pto: %130
      ;
      int64_t v188 = v187 < v27 ? v27 : v187;
      // pto: %131
      ;
      __gm__ bfloat16_t* v189 = PTOAS__GLOBAL_TENSOR_DATA(v56);
      // pto: %131
      ;
      const int64_t v190 = 0;
      // pto: %131
      ;
      const int64_t v191 = 16384;
      // pto: %131
      ;
      const int64_t v192 = 256;
      // pto: %131
      ;
      pto::Shape<1, 16, 2, 16, 16> v193 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %131
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v194 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %131
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v195 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v189 + (v190 + v186 * v191 + v188 * v192), v193, v194);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      TLOAD(v183, v195);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      // pto: %143
      ;
      int64_t v196;
      if (v159) {
        // pto: %145
        ;
        int64_t v197 = v58 % v28;
        // pto: %146, %147, %148
        ;
        int64_t v198 = v197 < v27 ? (int64_t) ((uint64_t) v197 + (uint64_t) v28) : v197;
        // pto: %149
        ;
        // pto: %150
        ;
        int64_t v199;
        if (v198 == v18) {
          // pto: %151
          ;
          v199 = (int64_t) ((uint64_t) v34 - (uint64_t) v152);
        } else {
          v199 = v156;
        };
        // pto: %154
        ;
        uint64_t v200 = (uint64_t) v199;
        // pto: %152, %153, %154, %155
        ;
        int64_t v201 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) (v58 / v28) * (uint64_t) v33) + v200) % v22;
        // pto: %156, %157, %158
        ;
        v196 = v201 < v27 ? (int64_t) ((uint64_t) v201 + (uint64_t) v22) : v201;
      } else {
        v196 = v156;
      };
      // pto: %159
      ;
      bool v202 = v196 < v27;
      // pto: %159
      ;
      int64_t v203 = v202 ? v27 : v196;
      // pto: %160
      ;
      int64_t v204 = (int64_t) ((uint64_t) v203 * (uint64_t) v20);
      // pto: %7
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v205 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v154, v20);
      // pto: %7
      ;
      uint64_t v206 = (uint64_t) v15;
      TASSIGN(v205, v206);
      // pto: %162
      ;
      int64_t v207 = v204 < v27 ? v27 : v204;
      // pto: %163
      ;
      const int64_t v208 = 0;
      // pto: %163
      ;
      __gm__ bfloat16_t* v209 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %163
      ;
      const int64_t v210 = 1;
      // pto: %163
      ;
      const int64_t v211 = 1;
      // pto: %163
      ;
      const int64_t v212 = 1;
      // pto: %163
      ;
      int64_t v213 = v154 * v19;
      // pto: %163
      ;
      int64_t v214 = v212 * v213;
      // pto: %163
      ;
      pto::Shape<1, 1, 1, -1, 256> v215 = pto::Shape<1, 1, 1, -1, 256>(v210, v211, v212, v154, v20);
      // pto: %163
      ;
      pto::Stride<-1, -1, -1, -1, -1> v216 = pto::Stride<-1, -1, -1, -1, -1>(v211 * v214, v214, v213, v19, v18);
      // pto: %163
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v217 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v209 + (v208 + v171 * v19 + v207 * v18), v215, v216);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      TLOAD(v205, v217);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
      // pto: %8
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v20);
      // pto: %8
      ;
      uint64_t v219 = (uint64_t) v14;
      TASSIGN(v218, v219);
      // pto: %164
      ;
      int64_t v220 = v204 / v22;
      // pto: %165
      ;
      int64_t v221 = v220 < v27 ? v27 : v220;
      // pto: %168
      ;
      __gm__ bfloat16_t* v222 = PTOAS__GLOBAL_TENSOR_DATA(v56);
      // pto: %168
      ;
      const int64_t v223 = 0;
      // pto: %168
      ;
      const int64_t v224 = 16384;
      // pto: %168
      ;
      const int64_t v225 = 256;
      // pto: %168
      ;
      pto::Shape<1, 16, 2, 16, 16> v226 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %168
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v227 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %168
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v228 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v222 + (v223 + v221 * v224 + v188 * v225), v226, v227);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v218, v228);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
      // pto: %w_chunk_inline8125__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v229 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %w_chunk_inline8125__tile_t
      ;
      uint64_t v230 = (uint64_t) v12;
      TASSIGN(v229, v230);
      // pto: %q_x_chunk_bf16_inline8126__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v231 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v154, v20);
      // pto: %q_x_chunk_bf16_inline8126__tile_Left
      ;
      uint64_t v232 = (uint64_t) v13;
      TASSIGN(v231, v232);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      TMOV(v231, v169);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      // pto: %w_chunk_inline8125__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v233 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %w_chunk_inline8125__tile_t_Right
      ;
      uint64_t v234 = (uint64_t) v16;
      TASSIGN(v233, v234);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      TMOV(v233, v229);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      // pto: %169
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      if (v152 == v27) {
        pipe_barrier(PIPE_M);
        TMATMUL(v150, v231, v233);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v150, v150, v231, v233);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      // pto: %10
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v235 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %10
      ;
      uint64_t v236 = (uint64_t) v14;
      TASSIGN(v235, v236);
      // pto: %11
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v237 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v154, v20);
      // pto: %11
      ;
      uint64_t v238 = (uint64_t) v12;
      TASSIGN(v237, v238);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      TMOV(v237, v205);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      // pto: %12
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v239 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %12
      ;
      uint64_t v240 = (uint64_t) v12;
      TASSIGN(v239, v240);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
      TMOV(v239, v235);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %170
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      if (v152 == v35) {
        pipe_barrier(PIPE_M);
        TMATMUL(v150, v237, v239);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v150, v150, v237, v239);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    };
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
    // pto: %172
    ;
    int64_t v241 = v149 < v27 ? v27 : v149;
    // pto: %173
    ;
    int64_t v242 = v57 < v27 ? v27 : v57;
    // pto: %qr_fp32_inline0_inline4577__iter_v31_pview
    ;
    __gm__ float* v243 = PTOAS__GLOBAL_TENSOR_DATA(v44);
    // pto: %qr_fp32_inline0_inline4577__iter_v31_pview
    ;
    const int64_t v244 = 0;
    // pto: %qr_fp32_inline0_inline4577__iter_v31_pview
    ;
    const int64_t v245 = 1024;
    // pto: %qr_fp32_inline0_inline4577__iter_v31_pview
    ;
    pto::Shape<1, 1, 1, 16, 32> v246 = pto::Shape<1, 1, 1, 16, 32>();
    // pto: %qr_fp32_inline0_inline4577__iter_v31_pview
    ;
    pto::Stride<16384, 16384, 16384, 1024, 1> v247 = pto::Stride<16384, 16384, 16384, 1024, 1>();
    // pto: %qr_fp32_inline0_inline4577__iter_v31_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND> v248 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND>(v243 + (v244 + v241 * v245 + v242), v246, v247);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
    pipe_barrier(PIPE_FIX);
    TSTORE(v248, v150);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}