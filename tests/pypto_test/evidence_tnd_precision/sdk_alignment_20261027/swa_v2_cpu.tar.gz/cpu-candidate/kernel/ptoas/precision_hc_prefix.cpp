#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void packed_prefix_indexer_cube(__gm__ float* v1, __gm__ float* v2, __gm__ bfloat16_t* v3, __gm__ bfloat16_t* v4, __gm__ float* v5, __gm__ bfloat16_t* v6, __gm__ bfloat16_t* v7, __gm__ int32_t* v8, __gm__ float* v9, __gm__ int64_t* v10, __gm__ bfloat16_t* v11, __gm__ int32_t* v12, __gm__ float* v13, __gm__ bfloat16_t* v14, __gm__ float* v15, __gm__ float* v16, __gm__ float* v17, __gm__ float* v18, __gm__ float* v19, __gm__ float* v20, __gm__ float* v21, __gm__ float* v22, __gm__ bfloat16_t* v23, __gm__ bfloat16_t* v24, __gm__ bfloat16_t* v25, __gm__ float* v26, __gm__ bfloat16_t* v27, __gm__ float* v28, __gm__ bfloat16_t* v29, __gm__ bfloat16_t* v30, __gm__ half* v31, int64_t v32, int64_t v33, int64_t v34, int64_t v35, int64_t v36, int32_t v37, int32_t v38) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v39 = 0;
  // pto: %c32768_i64
  const int64_t v40 = 32768;
  // pto: %c2048_i64
  const int64_t v41 = 2048;
  // pto: %c16384_index
  const int64_t v42 = 16384;
  // pto: %c1_index
  const int64_t v43 = 1;
  // pto: %c16_index
  const int64_t v44 = 16;
  // pto: %c32768_index
  const int64_t v45 = 32768;
  const int64_t v46 = 32;
  // pto: %c4096_index
  const int64_t v47 = 4096;
  // pto: %c512_index
  const int64_t v48 = 512;
  const int64_t v49 = 64;
  // pto: %c4_index
  const int64_t v50 = 4;
  // pto: %c24_index
  const int64_t v51 = 24;
  // pto: %c22_index
  const int64_t v52 = 22;
  // pto: %c21_index
  const int64_t v53 = 21;
  // pto: %c0_index
  const int64_t v54 = 0;
  // pto: %c768_index
  const int64_t v55 = 768;
  // pto: %c2_index
  const int64_t v56 = 2;
  // pto: %cn1_index
  const int64_t v57 = -1;
  // pto: %c63_index
  const int64_t v58 = 63;
  // pto: %c1536_index
  const int64_t v59 = 1536;
  // pto: %c128_index
  const int64_t v60 = 128;
  // pto: %c15_index
  const int64_t v61 = 15;
  // pto: %c256_index
  const int64_t v62 = 256;
  // pto: %wide__ssa_v0_view
  const int64_t v63 = 1;
  // pto: %wide__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %wide__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %wide__ssa_v0_view
  int64_t v66 = (int64_t) v32;
  // pto: %wide__ssa_v0_view
  int64_t v67 = v66 * v42;
  // pto: %wide__ssa_v0_view
  int64_t v68 = v65 * v67;
  // pto: %wide__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v69 = pto::Shape<1, 1, 1, -1, -1>(v63, v64, v65, v66, v42);
  // pto: %wide__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v70 = pto::Stride<-1, -1, -1, -1, -1>(v64 * v68, v68, v67, v42, v43);
  // pto: %wide__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v71 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v69, v70);
  // pto: %spmd_square__ssa_v0_view
  const int64_t v72 = 1;
  // pto: %spmd_square__ssa_v0_view
  const int64_t v73 = 1;
  // pto: %spmd_square__ssa_v0_view
  const int64_t v74 = 1;
  // pto: %spmd_square__ssa_v0_view
  int64_t v75 = (int64_t) v33;
  // pto: %spmd_square__ssa_v0_view
  int64_t v76 = v75 * v44;
  // pto: %spmd_square__ssa_v0_view
  int64_t v77 = v74 * v76;
  // pto: %spmd_square__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v78 = pto::Shape<1, 1, 1, -1, -1>(v72, v73, v74, v75, v44);
  // pto: %spmd_square__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v79 = pto::Stride<-1, -1, -1, -1, -1>(v73 * v77, v77, v76, v44, v43);
  // pto: %spmd_square__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v80 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v78, v79);
  // pto: %hc_packed_weight__ssa_v0_view
  const int64_t v81 = 1;
  // pto: %hc_packed_weight__ssa_v0_view
  const int64_t v82 = 1;
  // pto: %hc_packed_weight__ssa_v0_view
  const int64_t v83 = 1;
  // pto: %hc_packed_weight__ssa_v0_view
  int64_t v84 = v45 * v46;
  // pto: %hc_packed_weight__ssa_v0_view
  int64_t v85 = v83 * v84;
  // pto: %hc_packed_weight__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v86 = pto::Shape<1, 1, 1, -1, -1>(v81, v82, v83, v45, v46);
  // pto: %hc_packed_weight__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v87 = pto::Stride<-1, -1, -1, -1, -1>(v82 * v85, v85, v84, v46, v43);
  // pto: %hc_packed_weight__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v88 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v86, v87);
  // pto: %packed_flat__ssa_v0_view
  const int64_t v89 = 1;
  // pto: %packed_flat__ssa_v0_view
  const int64_t v90 = 1;
  // pto: %packed_flat__ssa_v0_view
  const int64_t v91 = 1;
  // pto: %packed_flat__ssa_v0_view
  int64_t v92 = (int64_t) v34;
  // pto: %packed_flat__ssa_v0_view
  int64_t v93 = v92 * v45;
  // pto: %packed_flat__ssa_v0_view
  int64_t v94 = v91 * v93;
  // pto: %packed_flat__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v95 = pto::Shape<1, 1, 1, -1, -1>(v89, v90, v91, v92, v45);
  // pto: %packed_flat__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v96 = pto::Stride<-1, -1, -1, -1, -1>(v90 * v94, v94, v93, v45, v43);
  // pto: %packed_flat__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v97 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v95, v96);
  // pto: %spmd_linear__ssa_v0_view
  const int64_t v98 = 1;
  // pto: %spmd_linear__ssa_v0_view
  const int64_t v99 = 1;
  // pto: %spmd_linear__ssa_v0_view
  const int64_t v100 = 1;
  // pto: %spmd_linear__ssa_v0_view
  int64_t v101 = (int64_t) v33;
  // pto: %spmd_linear__ssa_v0_view
  int64_t v102 = v101 * v46;
  // pto: %spmd_linear__ssa_v0_view
  int64_t v103 = v100 * v102;
  // pto: %spmd_linear__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v104 = pto::Shape<1, 1, 1, -1, -1>(v98, v99, v100, v101, v46);
  // pto: %spmd_linear__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v105 = pto::Stride<-1, -1, -1, -1, -1>(v99 * v103, v103, v102, v46, v43);
  // pto: %spmd_linear__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v106 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v104, v105);
  // pto: %normed__ssa_v0_view
  const int64_t v107 = 1;
  // pto: %normed__ssa_v0_view
  const int64_t v108 = 1;
  // pto: %normed__ssa_v0_view
  const int64_t v109 = 1;
  // pto: %normed__ssa_v0_view
  int64_t v110 = (int64_t) v32;
  // pto: %normed__ssa_v0_view
  int64_t v111 = v110 * v47;
  // pto: %normed__ssa_v0_view
  int64_t v112 = v109 * v111;
  // pto: %normed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v113 = pto::Shape<1, 1, 1, -1, -1>(v107, v108, v109, v110, v47);
  // pto: %normed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v114 = pto::Stride<-1, -1, -1, -1, -1>(v108 * v112, v112, v111, v47, v43);
  // pto: %normed__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v115 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v113, v114);
  // pto: %wkv__ssa_v0_view
  const int64_t v116 = 1;
  // pto: %wkv__ssa_v0_view
  const int64_t v117 = 1;
  // pto: %wkv__ssa_v0_view
  const int64_t v118 = 1;
  // pto: %wkv__ssa_v0_view
  int64_t v119 = v48 * v47;
  // pto: %wkv__ssa_v0_view
  int64_t v120 = v118 * v119;
  // pto: %wkv__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v121 = pto::Shape<1, 1, 1, -1, -1>(v116, v117, v118, v48, v47);
  // pto: %wkv__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v122 = pto::Stride<-1, -1, -1, -1, -1>(v117 * v120, v120, v119, v47, v43);
  // pto: %wkv__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v123 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v121, v122);
  // pto: %spmd_accum__ssa_v0_view
  const int64_t v124 = 1;
  // pto: %spmd_accum__ssa_v0_view
  const int64_t v125 = 1;
  // pto: %spmd_accum__ssa_v0_view
  const int64_t v126 = 1;
  // pto: %spmd_accum__ssa_v0_view
  int64_t v127 = (int64_t) v35;
  // pto: %spmd_accum__ssa_v0_view
  int64_t v128 = v127 * v48;
  // pto: %spmd_accum__ssa_v0_view
  int64_t v129 = v126 * v128;
  // pto: %spmd_accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v130 = pto::Shape<1, 1, 1, -1, -1>(v124, v125, v126, v127, v48);
  // pto: %spmd_accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v131 = pto::Stride<-1, -1, -1, -1, -1>(v125 * v129, v129, v128, v48, v43);
  // pto: %spmd_accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v132 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v130, v131);
  // pto: %weights_proj__ssa_v0_view
  const int64_t v133 = 1;
  // pto: %weights_proj__ssa_v0_view
  const int64_t v134 = 1;
  // pto: %weights_proj__ssa_v0_view
  const int64_t v135 = 1;
  // pto: %weights_proj__ssa_v0_view
  int64_t v136 = v49 * v47;
  // pto: %weights_proj__ssa_v0_view
  int64_t v137 = v135 * v136;
  // pto: %weights_proj__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v138 = pto::Shape<1, 1, 1, -1, -1>(v133, v134, v135, v49, v47);
  // pto: %weights_proj__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v139 = pto::Stride<-1, -1, -1, -1, -1>(v134 * v137, v137, v136, v47, v43);
  // pto: %weights_proj__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v140 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v11, v138, v139);
  // pto: %spmd_idx_accum__ssa_v0_view
  const int64_t v141 = 1;
  // pto: %spmd_idx_accum__ssa_v0_view
  const int64_t v142 = 1;
  // pto: %spmd_idx_accum__ssa_v0_view
  const int64_t v143 = 1;
  // pto: %spmd_idx_accum__ssa_v0_view
  int64_t v144 = (int64_t) v34;
  // pto: %spmd_idx_accum__ssa_v0_view
  int64_t v145 = v144 * v49;
  // pto: %spmd_idx_accum__ssa_v0_view
  int64_t v146 = v143 * v145;
  // pto: %spmd_idx_accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v147 = pto::Shape<1, 1, 1, -1, -1>(v141, v142, v143, v144, v49);
  // pto: %spmd_idx_accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v148 = pto::Stride<-1, -1, -1, -1, -1>(v142 * v146, v146, v145, v49, v43);
  // pto: %spmd_idx_accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v149 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v147, v148);
  // pto: %native_sq_acc_inline1266__rv_v2
  Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v150 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v44);
  // pto: %native_sq_acc_inline1266__rv_v2
  uint64_t v151 = (uint64_t) v39;
  TASSIGN(v150, v151);
  uint64_t v152 = reinterpret_cast<uint64_t>(v10);
  set_ffts_base_addr(v152);
  // pto: %worker__ssa_v0
  int64_t v153 = (int64_t) v37;
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %17
  int64_t v154 = v33 / v52;
  // pto: %18
  bool v155 = v32 >= v49;
  // pto: %sq_group_inline1259__phi_v2
  int64_t v156 = v155 ? v50 : v43;
  // pto: %19, %20
  int64_t v157 = (int64_t) ((uint64_t) v156 + (uint64_t) v53) / v156;
  // pto: %21, %22
  for (int64_t v158 = v153; v158 < ((int64_t) ((uint64_t) (v154 / v44) * (uint64_t) v157)); v158 += v51) {
    // pto: %23, %24
    ;
    int64_t v159 = (int64_t) ((uint64_t) (v158 / v157) * (uint64_t) v44);
    // pto: %25
    ;
    int64_t v160 = v158 % v157;
    // pto: %29, %26, %27, %28, %30, %31, %32
    ;
    int64_t v161 = v160 != v54 & (v160 < v54 ^ v157 < v54) ? (int64_t) ((uint64_t) v160 + (uint64_t) v157) : v160;
    // pto: %33
    ;
    int64_t v162 = (int64_t) ((uint64_t) v161 * (uint64_t) v156);
    // pto: %34
    ;
    int64_t v163 = (int64_t) ((uint64_t) v32 - (uint64_t) v159);
    // pto: %35
    ;
    int64_t v164 = v163 < v44 ? v163 : v44;
    // pto: %36
    ;
    int64_t v165 = (int64_t) ((uint64_t) v52 - (uint64_t) v162);
    // pto: %37
    ;
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    for (int64_t v166 = v54; v166 < (v156 < v165 ? v156 : v165); v166 += v43) {
      // pto: %38
      ;
      int64_t v167 = (int64_t) ((uint64_t) v162 + (uint64_t) v166);
      // pto: %39
      ;
      int64_t v168 = (int64_t) ((uint64_t) v167 * (uint64_t) v55);
      // pto: %40
      ;
      int64_t v169 = (int64_t) ((uint64_t) v42 - (uint64_t) v168);
      // pto: %41
      ;
      int64_t v170 = v169 < v55 ? v169 : v55;
      // pto: %42
      ;
      int64_t v171 = v170 / v46;
      // pto: %native_sq_acc_inline1266__tile
      ;
      Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v172 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v44);
      // pto: %native_sq_acc_inline1266__tile
      ;
      uint64_t v173 = (uint64_t) v39;
      TASSIGN(v172, v173);
      // pto: %43
      ;
      int64_t v174 = v171 / v56;
      // pto: %44
      ;
      int64_t v175 = (int64_t) ((uint64_t) v174 * (uint64_t) v56);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      for (int64_t v176 = v54; v176 < v175; v176 += v56) {
        // pto: %46
        ;
        int64_t v177 = (int64_t) ((uint64_t) v176 * (uint64_t) v46);
        // pto: %47
        ;
        int64_t v178 = (int64_t) ((uint64_t) v168 + (uint64_t) v177);
        // pto: %51, %50
        ;
        int64_t v179 = (int64_t) ((uint64_t) v168 + (uint64_t) ((int64_t) (uint64_t) v177 + (uint64_t) v46));
        // pto: %sq_lhs_inline1253__tile
        ;
        Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v180 = Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v164, v46);
        // pto: %sq_lhs_inline1253__tile
        ;
        uint64_t v181 = (uint64_t) v39;
        TASSIGN(v180, v181);
        // pto: %52
        ;
        int64_t v182 = v159 < v54 ? v54 : v159;
        // pto: %53
        ;
        int64_t v183 = v178 < v54 ? v54 : v178;
        // pto: %wide__ssa_v0_pview
        ;
        const int64_t v184 = 0;
        // pto: %wide__ssa_v0_pview
        ;
        __gm__ float* v185 = PTOAS__GLOBAL_TENSOR_DATA(v71);
        // pto: %wide__ssa_v0_pview
        ;
        const int64_t v186 = 1;
        // pto: %wide__ssa_v0_pview
        ;
        const int64_t v187 = 1;
        // pto: %wide__ssa_v0_pview
        ;
        const int64_t v188 = 1;
        // pto: %wide__ssa_v0_pview
        ;
        int64_t v189 = v164 * v42;
        // pto: %wide__ssa_v0_pview
        ;
        int64_t v190 = v188 * v189;
        // pto: %wide__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 32> v191 = pto::Shape<1, 1, 1, -1, 32>(v186, v187, v188, v164, v46);
        // pto: %wide__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v192 = pto::Stride<-1, -1, -1, -1, -1>(v187 * v190, v190, v189, v42, v43);
        // pto: %wide__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v193 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v185 + (v184 + v182 * v42 + v183 * v43), v191, v192);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v180, v193);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %0
        ;
        Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v194 = Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v164, v46);
        // pto: %0
        ;
        uint64_t v195 = (uint64_t) v40;
        TASSIGN(v194, v195);
        // pto: %55
        ;
        int64_t v196 = v179 < v54 ? v54 : v179;
        // pto: %56
        ;
        const int64_t v197 = 0;
        // pto: %56
        ;
        __gm__ float* v198 = PTOAS__GLOBAL_TENSOR_DATA(v71);
        // pto: %56
        ;
        const int64_t v199 = 1;
        // pto: %56
        ;
        const int64_t v200 = 1;
        // pto: %56
        ;
        const int64_t v201 = 1;
        // pto: %56
        ;
        int64_t v202 = v164 * v42;
        // pto: %56
        ;
        int64_t v203 = v201 * v202;
        // pto: %56
        ;
        pto::Shape<1, 1, 1, -1, 32> v204 = pto::Shape<1, 1, 1, -1, 32>(v199, v200, v201, v164, v46);
        // pto: %56
        ;
        pto::Stride<-1, -1, -1, -1, -1> v205 = pto::Stride<-1, -1, -1, -1, -1>(v200 * v203, v203, v202, v42, v43);
        // pto: %56
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v206 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v198 + (v197 + v182 * v42 + v196 * v43), v204, v205);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        TLOAD(v194, v206);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %sq_lhs_inline1253__tile_t
        ;
        Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v164);
        // pto: %sq_lhs_inline1253__tile_t
        ;
        uint64_t v208 = (uint64_t) v39;
        TASSIGN(v207, v208);
        // pto: %sq_lhs_inline1253__tile_Left
        ;
        Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v209 = Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v164, v46);
        // pto: %sq_lhs_inline1253__tile_Left
        ;
        uint64_t v210 = (uint64_t) v41;
        TASSIGN(v209, v210);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        TMOV(v209, v180);
        // pto: %sq_lhs_inline1253__tile_t_Right
        ;
        Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v164);
        // pto: %sq_lhs_inline1253__tile_t_Right
        ;
        uint64_t v212 = (uint64_t) v41;
        TASSIGN(v211, v212);
        TMOV(v211, v207);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %57
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        if (v176 == v54) {
          pipe_barrier(PIPE_M);
          TMATMUL(v172, v209, v211);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v172, v172, v209, v211);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        // pto: %2
        ;
        Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v213 = Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v164);
        // pto: %2
        ;
        uint64_t v214 = (uint64_t) v40;
        TASSIGN(v213, v214);
        // pto: %3
        ;
        Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v164, v46);
        // pto: %3
        ;
        uint64_t v216 = (uint64_t) v39;
        TASSIGN(v215, v216);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        TMOV(v215, v194);
        // pto: %4
        ;
        Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v164);
        // pto: %4
        ;
        uint64_t v218 = (uint64_t) v39;
        TASSIGN(v217, v218);
        TMOV(v217, v213);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %58
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        if (v176 == v57) {
          pipe_barrier(PIPE_M);
          TMATMUL(v172, v215, v217);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v172, v172, v215, v217);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      // pto: %59, %60
      ;
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      if ((int64_t) ((uint64_t) v171 - (uint64_t) v175) == v43) {
        // pto: %63
        ;
        int64_t v219 = (int64_t) ((uint64_t) v168 + (uint64_t) ((int64_t) (uint64_t) v174 * (uint64_t) v49));
        // pto: %6
        ;
        Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v164, v46);
        // pto: %6
        ;
        uint64_t v221 = (uint64_t) v39;
        TASSIGN(v220, v221);
        // pto: %64
        ;
        int64_t v222 = v159 < v54 ? v54 : v159;
        // pto: %65
        ;
        int64_t v223 = v219 < v54 ? v54 : v219;
        // pto: %66
        ;
        const int64_t v224 = 0;
        // pto: %66
        ;
        __gm__ float* v225 = PTOAS__GLOBAL_TENSOR_DATA(v71);
        // pto: %66
        ;
        const int64_t v226 = 1;
        // pto: %66
        ;
        const int64_t v227 = 1;
        // pto: %66
        ;
        const int64_t v228 = 1;
        // pto: %66
        ;
        int64_t v229 = v164 * v42;
        // pto: %66
        ;
        int64_t v230 = v228 * v229;
        // pto: %66
        ;
        pto::Shape<1, 1, 1, -1, 32> v231 = pto::Shape<1, 1, 1, -1, 32>(v226, v227, v228, v164, v46);
        // pto: %66
        ;
        pto::Stride<-1, -1, -1, -1, -1> v232 = pto::Stride<-1, -1, -1, -1, -1>(v227 * v230, v230, v229, v42, v43);
        // pto: %66
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v233 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v225 + (v224 + v222 * v42 + v223 * v43), v231, v232);
        TLOAD(v220, v233);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        // pto: %7
        ;
        Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v234 = Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v164);
        // pto: %7
        ;
        uint64_t v235 = (uint64_t) v39;
        TASSIGN(v234, v235);
        // pto: %8
        ;
        Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v236 = Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v164, v46);
        // pto: %8
        ;
        uint64_t v237 = (uint64_t) v41;
        TASSIGN(v236, v237);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        TMOV(v236, v220);
        // pto: %9
        ;
        Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v238 = Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v164);
        // pto: %9
        ;
        uint64_t v239 = (uint64_t) v41;
        TASSIGN(v238, v239);
        TMOV(v238, v234);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %67
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        if (v175 == v54) {
          pipe_barrier(PIPE_M);
          TMATMUL(v172, v236, v238);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v172, v172, v236, v238);
        };
      };
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %68, %69
      ;
      int64_t v240 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v167 * (uint64_t) v154) + (uint64_t) v159);
      // pto: %70
      ;
      int64_t v241 = v240 < v54 ? v54 : v240;
      // pto: %square__iter_v3_pview
      ;
      __gm__ float* v242 = PTOAS__GLOBAL_TENSOR_DATA(v80);
      // pto: %square__iter_v3_pview
      ;
      const int64_t v243 = 0;
      // pto: %square__iter_v3_pview
      ;
      const int64_t v244 = 16;
      // pto: %square__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, 16, 16> v245 = pto::Shape<1, 1, 1, 16, 16>();
      // pto: %square__iter_v3_pview
      ;
      pto::Stride<256, 256, 256, 16, 1> v246 = pto::Stride<256, 256, 256, 16, 1>();
      // pto: %square__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<256, 256, 256, 16, 1>, pto::Layout::ND> v247 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<256, 256, 256, 16, 1>, pto::Layout::ND>(v242 + (v243 + v241 * v244), v245, v246);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      pipe_barrier(PIPE_FIX);
      TSTORE(v247, v150);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    };
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  if (v155) {
    // pto: %72, %73
    ;
    int64_t v248 = (int64_t) ((uint64_t) v34 + (uint64_t) v58) / v49;
    // pto: %74
    ;
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    for (int64_t v249 = v153; v249 < ((int64_t) ((uint64_t) v248 * (uint64_t) v52)); v249 += v51) {
      // pto: %77
      ;
      int64_t v250 = v249 / v248;
      // pto: %80
      ;
      int64_t v251 = v249 % v248;
      // pto: %84, %81, %82, %83, %85, %86, %87
      ;
      int64_t v252 = v251 != v54 & (v251 < v54 ^ v248 < v54) ? (int64_t) ((uint64_t) v251 + (uint64_t) v248) : v251;
      // pto: %88
      ;
      int64_t v253 = (int64_t) ((uint64_t) v252 * (uint64_t) v49);
      // pto: %89
      ;
      int64_t v254 = (int64_t) ((uint64_t) v34 - (uint64_t) v253);
      // pto: %90
      ;
      int64_t v255 = v254 < v49 ? v254 : v49;
      // pto: %92, %91
      ;
      int64_t v256 = (int64_t) ((uint64_t) v42 - (uint64_t) ((int64_t) (uint64_t) v250 * (uint64_t) v55));
      // pto: %93
      ;
      int64_t v257 = v256 < v55 ? v256 : v55;
      // pto: %94
      ;
      // pto: %95
      ;
      int64_t v258 = (int64_t) ((uint64_t) v250 * (uint64_t) v59);
      // pto: %panel64_wide_first_x_inline1290__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v259 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v255, v60);
      // pto: %panel64_wide_first_x_inline1290__tile
      ;
      uint64_t v260 = (uint64_t) v39;
      TASSIGN(v259, v260);
      // pto: %96
      ;
      int64_t v261 = v253 < v54 ? v54 : v253;
      // pto: %97
      ;
      int64_t v262 = v258 < v54 ? v54 : v258;
      // pto: %packed_flat__ssa_v0_pview
      ;
      const int64_t v263 = 0;
      // pto: %packed_flat__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v264 = PTOAS__GLOBAL_TENSOR_DATA(v97);
      // pto: %packed_flat__ssa_v0_pview
      ;
      const int64_t v265 = 1;
      // pto: %packed_flat__ssa_v0_pview
      ;
      const int64_t v266 = 1;
      // pto: %packed_flat__ssa_v0_pview
      ;
      const int64_t v267 = 1;
      // pto: %packed_flat__ssa_v0_pview
      ;
      int64_t v268 = v255 * v45;
      // pto: %packed_flat__ssa_v0_pview
      ;
      int64_t v269 = v267 * v268;
      // pto: %packed_flat__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 128> v270 = pto::Shape<1, 1, 1, -1, 128>(v265, v266, v267, v255, v60);
      // pto: %packed_flat__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v271 = pto::Stride<-1, -1, -1, -1, -1>(v266 * v269, v269, v268, v45, v43);
      // pto: %packed_flat__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v272 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v264 + (v263 + v261 * v45 + v262 * v43), v270, v271);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      TLOAD(v259, v272);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %panel64_wide_first_w_inline1292__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v273 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
      // pto: %panel64_wide_first_w_inline1292__tile
      ;
      uint64_t v274 = (uint64_t) v40;
      TASSIGN(v273, v274);
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v275 = PTOAS__GLOBAL_TENSOR_DATA(v88);
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      const int64_t v276 = 0;
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      const int64_t v277 = 32;
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 128, 32> v278 = pto::Shape<1, 1, 1, 128, 32>();
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      pto::Stride<4096, 4096, 4096, 32, 1> v279 = pto::Stride<4096, 4096, 4096, 32, 1>();
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND> v280 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND>(v275 + (v276 + v262 * v277), v278, v279);
      TLOAD(v273, v280);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      // pto: %panel64_wide_first_x_inline1290__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v281 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v255, v60);
      // pto: %panel64_wide_first_x_inline1290__tile_Left
      ;
      uint64_t v282 = (uint64_t) v41;
      TASSIGN(v281, v282);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      TMOV(v281, v259);
      // pto: %panel64_wide_first_w_inline1292__tile_Right
      ;
      Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v283 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
      // pto: %panel64_wide_first_w_inline1292__tile_Right
      ;
      uint64_t v284 = (uint64_t) v41;
      TASSIGN(v283, v284);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      TMOV(v283, v273);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      // pto: %panel64_wide_accumulator_inline1282__tile
      ;
      Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v285 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v255, v46);
      // pto: %panel64_wide_accumulator_inline1282__tile
      ;
      uint64_t v286 = (uint64_t) v39;
      TASSIGN(v285, v286);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
      TMATMUL(v285, v281, v283);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      for (int64_t v287 = v43; v287 < (v257 / v49); v287 += v43) {
        // pto: %101, %100
        ;
        int64_t v288 = (int64_t) ((uint64_t) v258 + (uint64_t) ((int64_t) (uint64_t) v287 * (uint64_t) v60));
        // pto: %panel64_wide_x_inline1277__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v289 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v255, v60);
        // pto: %panel64_wide_x_inline1277__tile
        ;
        uint64_t v290 = (uint64_t) v39;
        TASSIGN(v289, v290);
        // pto: %103
        ;
        int64_t v291 = v288 < v54 ? v54 : v288;
        // pto: %104
        ;
        const int64_t v292 = 0;
        // pto: %104
        ;
        __gm__ bfloat16_t* v293 = PTOAS__GLOBAL_TENSOR_DATA(v97);
        // pto: %104
        ;
        const int64_t v294 = 1;
        // pto: %104
        ;
        const int64_t v295 = 1;
        // pto: %104
        ;
        const int64_t v296 = 1;
        // pto: %104
        ;
        int64_t v297 = v255 * v45;
        // pto: %104
        ;
        int64_t v298 = v296 * v297;
        // pto: %104
        ;
        pto::Shape<1, 1, 1, -1, 128> v299 = pto::Shape<1, 1, 1, -1, 128>(v294, v295, v296, v255, v60);
        // pto: %104
        ;
        pto::Stride<-1, -1, -1, -1, -1> v300 = pto::Stride<-1, -1, -1, -1, -1>(v295 * v298, v298, v297, v45, v43);
        // pto: %104
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v301 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v293 + (v292 + v261 * v45 + v291 * v43), v299, v300);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
        TLOAD(v289, v301);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        // pto: %panel64_wide_w_inline1276__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v302 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
        // pto: %panel64_wide_w_inline1276__tile
        ;
        uint64_t v303 = (uint64_t) v40;
        TASSIGN(v302, v303);
        // pto: %106
        ;
        __gm__ bfloat16_t* v304 = PTOAS__GLOBAL_TENSOR_DATA(v88);
        // pto: %106
        ;
        const int64_t v305 = 0;
        // pto: %106
        ;
        const int64_t v306 = 32;
        // pto: %106
        ;
        pto::Shape<1, 1, 1, 128, 32> v307 = pto::Shape<1, 1, 1, 128, 32>();
        // pto: %106
        ;
        pto::Stride<4096, 4096, 4096, 32, 1> v308 = pto::Stride<4096, 4096, 4096, 32, 1>();
        // pto: %106
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND> v309 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND>(v304 + (v305 + v291 * v306), v307, v308);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        TLOAD(v302, v309);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
        // pto: %panel64_wide_x_inline1277__tile_Left
        ;
        Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v310 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v255, v60);
        // pto: %panel64_wide_x_inline1277__tile_Left
        ;
        uint64_t v311 = (uint64_t) v41;
        TASSIGN(v310, v311);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        TMOV(v310, v289);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
        // pto: %panel64_wide_w_inline1276__tile_Right
        ;
        Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v312 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
        // pto: %panel64_wide_w_inline1276__tile_Right
        ;
        uint64_t v313 = (uint64_t) v41;
        TASSIGN(v312, v313);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
        TMOV(v312, v302);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        TMATMUL_ACC(v285, v285, v310, v312);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      };
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      v285.SetValidShape(v255, v46);
      // pto: %107, %108
      ;
      int64_t v314 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v250 * (uint64_t) v34) + (uint64_t) v253);
      // pto: %109
      ;
      int64_t v315 = v314 < v54 ? v54 : v314;
      // pto: %linear__iter_v1_pview
      ;
      const int64_t v316 = 0;
      // pto: %linear__iter_v1_pview
      ;
      __gm__ float* v317 = PTOAS__GLOBAL_TENSOR_DATA(v106);
      // pto: %linear__iter_v1_pview
      ;
      const int64_t v318 = 1;
      // pto: %linear__iter_v1_pview
      ;
      const int64_t v319 = 1;
      // pto: %linear__iter_v1_pview
      ;
      const int64_t v320 = 1;
      // pto: %linear__iter_v1_pview
      ;
      int64_t v321 = v255 * v46;
      // pto: %linear__iter_v1_pview
      ;
      int64_t v322 = v320 * v321;
      // pto: %linear__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, -1, 32> v323 = pto::Shape<1, 1, 1, -1, 32>(v318, v319, v320, v255, v46);
      // pto: %linear__iter_v1_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v324 = pto::Stride<-1, -1, -1, -1, -1>(v319 * v322, v322, v321, v46, v43);
      // pto: %linear__iter_v1_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v325 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v317 + (v316 + v315 * v46 + v54 * v43), v323, v324);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      TSTORE(v325, v285);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
    };
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  } else {
    // pto: %110
    ;
    int64_t v326 = v34 / v44;
    // pto: %111
    ;
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
    for (int64_t v327 = v153; v327 < ((int64_t) ((uint64_t) v326 * (uint64_t) v52)); v327 += v51) {
      // pto: %113
      ;
      int64_t v328 = v327 / v326;
      // pto: %115
      ;
      int64_t v329 = v327 % v326;
      // pto: %119, %116, %117, %118, %120, %121, %122
      ;
      int64_t v330 = v329 != v54 & (v329 < v54 ^ v326 < v54) ? (int64_t) ((uint64_t) v329 + (uint64_t) v326) : v329;
      // pto: %123
      ;
      int64_t v331 = (int64_t) ((uint64_t) v330 * (uint64_t) v44);
      // pto: %125, %124
      ;
      int64_t v332 = (int64_t) ((uint64_t) v42 - (uint64_t) ((int64_t) (uint64_t) v328 * (uint64_t) v55));
      // pto: %126
      ;
      int64_t v333 = v332 < v55 ? v332 : v55;
      // pto: %127
      ;
      // pto: %panel64_accumulator_inline1274__tile
      ;
      Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v334 = Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v46);
      // pto: %panel64_accumulator_inline1274__tile
      ;
      uint64_t v335 = (uint64_t) v39;
      TASSIGN(v334, v335);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v336 = v54; v336 < (v333 / v49); v336 += v43) {
        // pto: %128, %130, %129
        ;
        int64_t v337 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v328 * (uint64_t) v59) + (uint64_t) ((int64_t) (uint64_t) v336 * (uint64_t) v60));
        // pto: %panel64_x16_inline1270__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v338 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v60);
        // pto: %panel64_x16_inline1270__tile
        ;
        uint64_t v339 = (uint64_t) v40;
        TASSIGN(v338, v339);
        // pto: %131
        ;
        int64_t v340 = v331 < v54 ? v54 : v331;
        // pto: %132
        ;
        int64_t v341 = v337 < v54 ? v54 : v337;
        // pto: %133
        ;
        __gm__ bfloat16_t* v342 = PTOAS__GLOBAL_TENSOR_DATA(v97);
        // pto: %133
        ;
        const int64_t v343 = 0;
        // pto: %133
        ;
        const int64_t v344 = 32768;
        // pto: %133
        ;
        pto::Shape<1, 1, 1, 16, 128> v345 = pto::Shape<1, 1, 1, 16, 128>();
        // pto: %133
        ;
        pto::Stride<524288, 524288, 524288, 32768, 1> v346 = pto::Stride<524288, 524288, 524288, 32768, 1>();
        // pto: %133
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND> v347 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND>(v342 + (v343 + v340 * v344 + v341), v345, v346);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        TLOAD(v338, v347);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
        // pto: %panel64_w16_inline1271__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v348 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
        // pto: %panel64_w16_inline1271__tile
        ;
        uint64_t v349 = (uint64_t) v39;
        TASSIGN(v348, v349);
        // pto: %135
        ;
        __gm__ bfloat16_t* v350 = PTOAS__GLOBAL_TENSOR_DATA(v88);
        // pto: %135
        ;
        const int64_t v351 = 0;
        // pto: %135
        ;
        const int64_t v352 = 32;
        // pto: %135
        ;
        pto::Shape<1, 1, 1, 128, 32> v353 = pto::Shape<1, 1, 1, 128, 32>();
        // pto: %135
        ;
        pto::Stride<4096, 4096, 4096, 32, 1> v354 = pto::Stride<4096, 4096, 4096, 32, 1>();
        // pto: %135
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND> v355 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND>(v350 + (v351 + v341 * v352), v353, v354);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v348, v355);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %panel64_x16_inline1270__tile_Left
        ;
        Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v356 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v60);
        // pto: %panel64_x16_inline1270__tile_Left
        ;
        uint64_t v357 = (uint64_t) v41;
        TASSIGN(v356, v357);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
        pipe_barrier(PIPE_MTE1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        TMOV(v356, v338);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        // pto: %panel64_w16_inline1271__tile_Right
        ;
        Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v358 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
        // pto: %panel64_w16_inline1271__tile_Right
        ;
        uint64_t v359 = (uint64_t) v41;
        TASSIGN(v358, v359);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        TMOV(v358, v348);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        // pto: %136
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        if (v336 == v54) {
          TMATMUL(v334, v356, v358);
        } else {
          TMATMUL_ACC(v334, v334, v356, v358);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
      // pto: %138, %139
      ;
      int64_t v360 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v328 * (uint64_t) v34) + (uint64_t) v331);
      // pto: %140
      ;
      int64_t v361 = v360 < v54 ? v54 : v360;
      // pto: %linear__iter_v4_pview
      ;
      __gm__ float* v362 = PTOAS__GLOBAL_TENSOR_DATA(v106);
      // pto: %linear__iter_v4_pview
      ;
      const int64_t v363 = 0;
      // pto: %linear__iter_v4_pview
      ;
      const int64_t v364 = 32;
      // pto: %linear__iter_v4_pview
      ;
      pto::Shape<1, 1, 1, 16, 32> v365 = pto::Shape<1, 1, 1, 16, 32>();
      // pto: %linear__iter_v4_pview
      ;
      pto::Stride<512, 512, 512, 32, 1> v366 = pto::Stride<512, 512, 512, 32, 1>();
      // pto: %linear__iter_v4_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND> v367 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND>(v362 + (v363 + v361 * v364), v365, v366);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
      pipe_barrier(PIPE_FIX);
      TSTORE(v367, v334);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
    };
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %141, %142
  int64_t v368 = (int64_t) ((uint64_t) v32 + (uint64_t) v61) / v44;
  // pto: %145
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
  if (v32 <= v44) {
    // pto: %146
    ;
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
    for (int64_t v369 = v153; v369 < ((int64_t) ((uint64_t) v368 * (uint64_t) v46)); v369 += v51) {
      // pto: %147, %148
      ;
      int64_t v370 = (int64_t) ((uint64_t) (v369 / v46) * (uint64_t) v44);
      // pto: %149
      ;
      int64_t v371 = v369 % v46;
      // pto: %150, %151, %152
      ;
      int64_t v372 = v371 < v54 ? (int64_t) ((uint64_t) v371 + (uint64_t) v46) : v371;
      // pto: %153
      ;
      int64_t v373 = (int64_t) ((uint64_t) v372 * (uint64_t) v44);
      // pto: %154
      ;
      int64_t v374 = (int64_t) ((uint64_t) v32 - (uint64_t) v370);
      // pto: %155
      ;
      int64_t v375 = v374 < v44 ? v374 : v44;
      // pto: %m16_tile_inline1307__tile
      ;
      Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v376 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v44);
      // pto: %m16_tile_inline1307__tile
      ;
      uint64_t v377 = (uint64_t) v39;
      TASSIGN(v376, v377);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v378 = v54; v378 < v44; v378 += v43) {
        // pto: %flat_offset, %m16_k_block_inline1335__tile
        ;
        int32_t v379 = (v8)[(int64_t) ((uint64_t) v373 + (uint64_t) v378)];
        // pto: %156
        ;
        int64_t v380 = (int64_t) v379;
        // pto: %157
        ;
        int64_t v381 = v380 < v54 ? v54 : v380;
        // pto: %158
        ;
        int64_t v382 = (int64_t) ((uint64_t) v381 * (uint64_t) v62);
        // pto: %m16_a_inline1306__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v383 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v375, v62);
        // pto: %m16_a_inline1306__tile
        ;
        uint64_t v384 = (uint64_t) v39;
        TASSIGN(v383, v384);
        // pto: %159
        ;
        int64_t v385 = v370 < v54 ? v54 : v370;
        // pto: %160
        ;
        int64_t v386 = v382 < v54 ? v54 : v382;
        // pto: %normed__ssa_v0_pview
        ;
        const int64_t v387 = 0;
        // pto: %normed__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v388 = PTOAS__GLOBAL_TENSOR_DATA(v115);
        // pto: %normed__ssa_v0_pview
        ;
        const int64_t v389 = 1;
        // pto: %normed__ssa_v0_pview
        ;
        const int64_t v390 = 1;
        // pto: %normed__ssa_v0_pview
        ;
        const int64_t v391 = 1;
        // pto: %normed__ssa_v0_pview
        ;
        int64_t v392 = v375 * v47;
        // pto: %normed__ssa_v0_pview
        ;
        int64_t v393 = v391 * v392;
        // pto: %normed__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v394 = pto::Shape<1, 1, 1, -1, 256>(v389, v390, v391, v375, v62);
        // pto: %normed__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v395 = pto::Stride<-1, -1, -1, -1, -1>(v390 * v393, v393, v392, v47, v43);
        // pto: %normed__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v396 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v388 + (v387 + v385 * v47 + v386 * v43), v394, v395);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        TLOAD(v383, v396);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %m16_b_inline1319__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v397 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v62);
        // pto: %m16_b_inline1319__tile
        ;
        uint64_t v398 = (uint64_t) v40;
        TASSIGN(v397, v398);
        // pto: %161
        ;
        int64_t v399 = v373 < v54 ? v54 : v373;
        // pto: %wkv__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v400 = PTOAS__GLOBAL_TENSOR_DATA(v123);
        // pto: %wkv__ssa_v0_pview
        ;
        const int64_t v401 = 0;
        // pto: %wkv__ssa_v0_pview
        ;
        const int64_t v402 = 4096;
        // pto: %wkv__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 16, 256> v403 = pto::Shape<1, 1, 1, 16, 256>();
        // pto: %wkv__ssa_v0_pview
        ;
        pto::Stride<65536, 65536, 65536, 4096, 1> v404 = pto::Stride<65536, 65536, 65536, 4096, 1>();
        // pto: %wkv__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v405 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v400 + (v401 + v399 * v402 + v386), v403, v404);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v397, v405);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %m16_b_inline1319__tile_t
        ;
        Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v406 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
        // pto: %m16_b_inline1319__tile_t
        ;
        uint64_t v407 = (uint64_t) v40;
        TASSIGN(v406, v407);
        // pto: %m16_a_inline1306__tile_Left
        ;
        Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v408 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v375, v62);
        // pto: %m16_a_inline1306__tile_Left
        ;
        uint64_t v409 = (uint64_t) v41;
        TASSIGN(v408, v409);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        TMOV(v408, v383);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        // pto: %m16_b_inline1319__tile_t_Right
        ;
        Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v410 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
        // pto: %m16_b_inline1319__tile_t_Right
        ;
        uint64_t v411 = (uint64_t) v41;
        TASSIGN(v410, v411);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        TMOV(v410, v406);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
        // pto: %163
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
        if (v378 == v54) {
          TMATMUL(v376, v408, v410);
        } else {
          TMATMUL_ACC(v376, v376, v408, v410);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
      // pto: %164
      ;
      int64_t v412 = v370 < v54 ? v54 : v370;
      // pto: %165
      ;
      int64_t v413 = v373 < v54 ? v54 : v373;
      // pto: %accum__iter_v1_pview
      ;
      __gm__ float* v414 = PTOAS__GLOBAL_TENSOR_DATA(v132);
      // pto: %accum__iter_v1_pview
      ;
      const int64_t v415 = 0;
      // pto: %accum__iter_v1_pview
      ;
      const int64_t v416 = 512;
      // pto: %accum__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, 16, 16> v417 = pto::Shape<1, 1, 1, 16, 16>();
      // pto: %accum__iter_v1_pview
      ;
      pto::Stride<8192, 8192, 8192, 512, 1> v418 = pto::Stride<8192, 8192, 8192, 512, 1>();
      // pto: %accum__iter_v1_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v419 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v414 + (v415 + v412 * v416 + v413), v417, v418);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
      pipe_barrier(PIPE_FIX);
      TSTORE(v419, v376);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
    };
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
  } else {
    // pto: %143, %144, %166
    ;
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
    for (int64_t v420 = v153; v420 < ((int64_t) ((uint64_t) ((int64_t) ((uint64_t) v32 + (uint64_t) v58) / v49) * (uint64_t) v44)); v420 += v51) {
      // pto: %167, %168
      ;
      int64_t v421 = (int64_t) ((uint64_t) (v420 / v44) * (uint64_t) v49);
      // pto: %169
      ;
      int64_t v422 = v420 % v44;
      // pto: %170, %171, %172
      ;
      int64_t v423 = v422 < v54 ? (int64_t) ((uint64_t) v422 + (uint64_t) v44) : v422;
      // pto: %173
      ;
      int64_t v424 = (int64_t) ((uint64_t) v423 * (uint64_t) v56);
      int64_t v425 = (int64_t) ((uint64_t) v423 * (uint64_t) v46);
      // pto: %175
      ;
      int64_t v426 = (int64_t) ((uint64_t) v32 - (uint64_t) v421);
      // pto: %176
      ;
      int64_t v427 = v426 < v49 ? v426 : v49;
      // pto: %same_order_inline1328__rv_v2
      ;
      int64_t v428;
      v428 = v43;
      for (int64_t v429 = v54; v429 < v44; v429 += v43) {
        // pto: %178, %t__tile
        ;
        int32_t v430 = (v8)[(int64_t) ((uint64_t) v425 + (uint64_t) v429)];
        // pto: %180, %181, %182, %179
        ;
        int32_t v431 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v424 + (uint64_t) v43) * (uint64_t) v44) + (uint64_t) v429)];
        // pto: %183, %same_order_inline1328__phi_v4
        ;
        int64_t v432 = v430 != v431 ? v54 : v428;
        v428 = v432;
      };
      // pto: %184
      ;
      bool v433 = v428 == v43;
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
      if (v433) {
        // pto: %first_block_inline1327__tile
        ;
        int32_t v434 = (v8)[v425];
        // pto: %187
        ;
        int64_t v435 = (int64_t) v434;
        // pto: %188
        ;
        int64_t v436 = v435 < v54 ? v54 : v435;
        // pto: %189
        ;
        int64_t v437 = (int64_t) ((uint64_t) v436 * (uint64_t) v62);
        // pto: %first_a_inline1311__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v438 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v427, v62);
        // pto: %first_a_inline1311__tile
        ;
        uint64_t v439 = (uint64_t) v39;
        TASSIGN(v438, v439);
        // pto: %190
        ;
        int64_t v440 = v421 < v54 ? v54 : v421;
        // pto: %191
        ;
        int64_t v441 = v437 < v54 ? v54 : v437;
        // pto: %192
        ;
        const int64_t v442 = 0;
        // pto: %192
        ;
        __gm__ bfloat16_t* v443 = PTOAS__GLOBAL_TENSOR_DATA(v115);
        // pto: %192
        ;
        const int64_t v444 = 1;
        // pto: %192
        ;
        const int64_t v445 = 1;
        // pto: %192
        ;
        const int64_t v446 = 1;
        // pto: %192
        ;
        int64_t v447 = v427 * v47;
        // pto: %192
        ;
        int64_t v448 = v446 * v447;
        // pto: %192
        ;
        pto::Shape<1, 1, 1, -1, 256> v449 = pto::Shape<1, 1, 1, -1, 256>(v444, v445, v446, v427, v62);
        // pto: %192
        ;
        pto::Stride<-1, -1, -1, -1, -1> v450 = pto::Stride<-1, -1, -1, -1, -1>(v445 * v448, v448, v447, v47, v43);
        // pto: %192
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v451 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v443 + (v442 + v440 * v47 + v441 * v43), v449, v450);
        TLOAD(v438, v451);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %first_b_inline1336__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v452 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %first_b_inline1336__tile
        ;
        uint64_t v453 = (uint64_t) v40;
        TASSIGN(v452, v453);
        // pto: %193
        ;
        int64_t v454 = v425 < v54 ? v54 : v425;
        // pto: %195
        ;
        __gm__ bfloat16_t* v455 = PTOAS__GLOBAL_TENSOR_DATA(v123);
        // pto: %195
        ;
        const int64_t v456 = 0;
        // pto: %195
        ;
        const int64_t v457 = 4096;
        // pto: %195
        ;
        pto::Shape<1, 1, 1, 32, 256> v458 = pto::Shape<1, 1, 1, 32, 256>();
        // pto: %195
        ;
        pto::Stride<131072, 131072, 131072, 4096, 1> v459 = pto::Stride<131072, 131072, 131072, 4096, 1>();
        // pto: %195
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND> v460 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND>(v455 + (v456 + v454 * v457 + v441), v458, v459);
        TLOAD(v452, v460);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %first_b_inline1336__tile_t
        ;
        Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v461 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v46);
        // pto: %first_b_inline1336__tile_t
        ;
        uint64_t v462 = (uint64_t) v40;
        TASSIGN(v461, v462);
        // pto: %first_a_inline1311__tile_Left
        ;
        Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v463 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v427, v62);
        // pto: %first_a_inline1311__tile_Left
        ;
        uint64_t v464 = (uint64_t) v41;
        TASSIGN(v463, v464);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        TMOV(v463, v438);
        // pto: %first_b_inline1336__tile_t_Right
        ;
        Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v465 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v46);
        // pto: %first_b_inline1336__tile_t_Right
        ;
        uint64_t v466 = (uint64_t) v41;
        TASSIGN(v465, v466);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        TMOV(v465, v461);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        // pto: %wide_tile_inline1316__tile
        ;
        Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v467 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v427, v46);
        // pto: %wide_tile_inline1316__tile
        ;
        uint64_t v468 = (uint64_t) v39;
        TASSIGN(v467, v468);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        TMATMUL(v467, v463, v465);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        for (int64_t v469 = v43; v469 < v44; v469 += v43) {
          // pto: %197, %k_block_inline1337__tile
          ;
          int32_t v470 = (v8)[(int64_t) ((uint64_t) v425 + (uint64_t) v469)];
          // pto: %198
          ;
          int64_t v471 = (int64_t) v470;
          // pto: %199
          ;
          int64_t v472 = v471 < v54 ? v54 : v471;
          // pto: %200
          ;
          int64_t v473 = (int64_t) ((uint64_t) v472 * (uint64_t) v62);
          // pto: %a_inline1303__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v474 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v427, v62);
          // pto: %a_inline1303__tile
          ;
          uint64_t v475 = (uint64_t) v39;
          TASSIGN(v474, v475);
          // pto: %202
          ;
          int64_t v476 = v473 < v54 ? v54 : v473;
          // pto: %203
          ;
          const int64_t v477 = 0;
          // pto: %203
          ;
          __gm__ bfloat16_t* v478 = PTOAS__GLOBAL_TENSOR_DATA(v115);
          // pto: %203
          ;
          const int64_t v479 = 1;
          // pto: %203
          ;
          const int64_t v480 = 1;
          // pto: %203
          ;
          const int64_t v481 = 1;
          // pto: %203
          ;
          int64_t v482 = v427 * v47;
          // pto: %203
          ;
          int64_t v483 = v481 * v482;
          // pto: %203
          ;
          pto::Shape<1, 1, 1, -1, 256> v484 = pto::Shape<1, 1, 1, -1, 256>(v479, v480, v481, v427, v62);
          // pto: %203
          ;
          pto::Stride<-1, -1, -1, -1, -1> v485 = pto::Stride<-1, -1, -1, -1, -1>(v480 * v483, v483, v482, v47, v43);
          // pto: %203
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v486 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v478 + (v477 + v440 * v47 + v476 * v43), v484, v485);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          TLOAD(v474, v486);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %b_inline1300__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v487 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v46, v62);
          // pto: %b_inline1300__tile
          ;
          uint64_t v488 = (uint64_t) v40;
          TASSIGN(v487, v488);
          // pto: %206
          ;
          __gm__ bfloat16_t* v489 = PTOAS__GLOBAL_TENSOR_DATA(v123);
          // pto: %206
          ;
          const int64_t v490 = 0;
          // pto: %206
          ;
          const int64_t v491 = 4096;
          // pto: %206
          ;
          pto::Shape<1, 1, 1, 32, 256> v492 = pto::Shape<1, 1, 1, 32, 256>();
          // pto: %206
          ;
          pto::Stride<131072, 131072, 131072, 4096, 1> v493 = pto::Stride<131072, 131072, 131072, 4096, 1>();
          // pto: %206
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND> v494 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND>(v489 + (v490 + v454 * v491 + v476), v492, v493);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          TLOAD(v487, v494);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %b_inline1300__tile_t
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v495 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v46);
          // pto: %b_inline1300__tile_t
          ;
          uint64_t v496 = (uint64_t) v40;
          TASSIGN(v495, v496);
          // pto: %a_inline1303__tile_Left
          ;
          Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v497 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v427, v62);
          // pto: %a_inline1303__tile_Left
          ;
          uint64_t v498 = (uint64_t) v41;
          TASSIGN(v497, v498);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          TMOV(v497, v474);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %b_inline1300__tile_t_Right
          ;
          Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v499 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v46);
          // pto: %b_inline1300__tile_t_Right
          ;
          uint64_t v500 = (uint64_t) v41;
          TASSIGN(v499, v500);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          TMOV(v499, v495);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          TMATMUL_ACC(v467, v467, v497, v499);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        };
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
        // pto: %accum__iter_v4_pview
        ;
        const int64_t v501 = 0;
        // pto: %accum__iter_v4_pview
        ;
        __gm__ float* v502 = PTOAS__GLOBAL_TENSOR_DATA(v132);
        // pto: %accum__iter_v4_pview
        ;
        const int64_t v503 = 1;
        // pto: %accum__iter_v4_pview
        ;
        const int64_t v504 = 1;
        // pto: %accum__iter_v4_pview
        ;
        const int64_t v505 = 1;
        // pto: %accum__iter_v4_pview
        ;
        int64_t v506 = v427 * v48;
        // pto: %accum__iter_v4_pview
        ;
        int64_t v507 = v505 * v506;
        // pto: %accum__iter_v4_pview
        ;
        pto::Shape<1, 1, 1, -1, 32> v508 = pto::Shape<1, 1, 1, -1, 32>(v503, v504, v505, v427, v46);
        // pto: %accum__iter_v4_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v509 = pto::Stride<-1, -1, -1, -1, -1>(v504 * v507, v507, v506, v48, v43);
        // pto: %accum__iter_v4_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v510 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v502 + (v501 + v440 * v48 + v454 * v43), v508, v509);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
        TSTORE(v510, v467);
      } else {
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
        for (int64_t v511 = v54; v511 < v56; v511 += v43) {
          // pto: %210, %211
          ;
          int64_t v512 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v424 + (uint64_t) v511) * (uint64_t) v44);
          // pto: %narrow_first_block_inline1318__tile
          ;
          int32_t v513 = (v8)[v512];
          // pto: %214
          ;
          int64_t v514 = (int64_t) v513;
          // pto: %215
          ;
          int64_t v515 = v514 < v54 ? v54 : v514;
          // pto: %216
          ;
          int64_t v516 = (int64_t) ((uint64_t) v515 * (uint64_t) v62);
          // pto: %narrow_first_a_inline1298__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v517 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v427, v62);
          // pto: %narrow_first_a_inline1298__tile
          ;
          uint64_t v518 = (uint64_t) v39;
          TASSIGN(v517, v518);
          // pto: %217
          ;
          int64_t v519 = v421 < v54 ? v54 : v421;
          // pto: %218
          ;
          int64_t v520 = v516 < v54 ? v54 : v516;
          // pto: %219
          ;
          const int64_t v521 = 0;
          // pto: %219
          ;
          __gm__ bfloat16_t* v522 = PTOAS__GLOBAL_TENSOR_DATA(v115);
          // pto: %219
          ;
          const int64_t v523 = 1;
          // pto: %219
          ;
          const int64_t v524 = 1;
          // pto: %219
          ;
          const int64_t v525 = 1;
          // pto: %219
          ;
          int64_t v526 = v427 * v47;
          // pto: %219
          ;
          int64_t v527 = v525 * v526;
          // pto: %219
          ;
          pto::Shape<1, 1, 1, -1, 256> v528 = pto::Shape<1, 1, 1, -1, 256>(v523, v524, v525, v427, v62);
          // pto: %219
          ;
          pto::Stride<-1, -1, -1, -1, -1> v529 = pto::Stride<-1, -1, -1, -1, -1>(v524 * v527, v527, v526, v47, v43);
          // pto: %219
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v530 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v522 + (v521 + v519 * v47 + v520 * v43), v528, v529);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          TLOAD(v517, v530);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %narrow_first_b_inline1314__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v531 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v62);
          // pto: %narrow_first_b_inline1314__tile
          ;
          uint64_t v532 = (uint64_t) v40;
          TASSIGN(v531, v532);
          // pto: %220
          ;
          int64_t v533 = v512 < v54 ? v54 : v512;
          // pto: %222
          ;
          __gm__ bfloat16_t* v534 = PTOAS__GLOBAL_TENSOR_DATA(v123);
          // pto: %222
          ;
          const int64_t v535 = 0;
          // pto: %222
          ;
          const int64_t v536 = 4096;
          // pto: %222
          ;
          pto::Shape<1, 1, 1, 16, 256> v537 = pto::Shape<1, 1, 1, 16, 256>();
          // pto: %222
          ;
          pto::Stride<65536, 65536, 65536, 4096, 1> v538 = pto::Stride<65536, 65536, 65536, 4096, 1>();
          // pto: %222
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v539 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v534 + (v535 + v533 * v536 + v520), v537, v538);
          TLOAD(v531, v539);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %narrow_first_b_inline1314__tile_t
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v540 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
          // pto: %narrow_first_b_inline1314__tile_t
          ;
          uint64_t v541 = (uint64_t) v40;
          TASSIGN(v540, v541);
          // pto: %narrow_first_a_inline1298__tile_Left
          ;
          Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v542 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v427, v62);
          // pto: %narrow_first_a_inline1298__tile_Left
          ;
          uint64_t v543 = (uint64_t) v41;
          TASSIGN(v542, v543);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          TMOV(v542, v517);
          // pto: %narrow_first_b_inline1314__tile_t_Right
          ;
          Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v544 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
          // pto: %narrow_first_b_inline1314__tile_t_Right
          ;
          uint64_t v545 = (uint64_t) v41;
          TASSIGN(v544, v545);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          TMOV(v544, v540);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          // pto: %narrow_tile_inline1329__tile
          ;
          Tile<TileType::Acc, float, 64, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v546 = Tile<TileType::Acc, float, 64, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v427, v44);
          // pto: %narrow_tile_inline1329__tile
          ;
          uint64_t v547 = (uint64_t) v39;
          TASSIGN(v546, v547);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          wait_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
          TMATMUL(v546, v542, v544);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          for (int64_t v548 = v43; v548 < v44; v548 += v43) {
            // pto: %224, %narrow_block_inline1301__tile
            ;
            int32_t v549 = (v8)[(int64_t) ((uint64_t) v512 + (uint64_t) v548)];
            // pto: %225
            ;
            int64_t v550 = (int64_t) v549;
            // pto: %226
            ;
            int64_t v551 = v550 < v54 ? v54 : v550;
            // pto: %227
            ;
            int64_t v552 = (int64_t) ((uint64_t) v551 * (uint64_t) v62);
            // pto: %narrow_a_inline1295__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v553 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v427, v62);
            // pto: %narrow_a_inline1295__tile
            ;
            uint64_t v554 = (uint64_t) v39;
            TASSIGN(v553, v554);
            // pto: %229
            ;
            int64_t v555 = v552 < v54 ? v54 : v552;
            // pto: %230
            ;
            const int64_t v556 = 0;
            // pto: %230
            ;
            __gm__ bfloat16_t* v557 = PTOAS__GLOBAL_TENSOR_DATA(v115);
            // pto: %230
            ;
            const int64_t v558 = 1;
            // pto: %230
            ;
            const int64_t v559 = 1;
            // pto: %230
            ;
            const int64_t v560 = 1;
            // pto: %230
            ;
            int64_t v561 = v427 * v47;
            // pto: %230
            ;
            int64_t v562 = v560 * v561;
            // pto: %230
            ;
            pto::Shape<1, 1, 1, -1, 256> v563 = pto::Shape<1, 1, 1, -1, 256>(v558, v559, v560, v427, v62);
            // pto: %230
            ;
            pto::Stride<-1, -1, -1, -1, -1> v564 = pto::Stride<-1, -1, -1, -1, -1>(v559 * v562, v562, v561, v47, v43);
            // pto: %230
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v565 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v557 + (v556 + v519 * v47 + v555 * v43), v563, v564);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            TLOAD(v553, v565);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %narrow_b_inline1308__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v566 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v62);
            // pto: %narrow_b_inline1308__tile
            ;
            uint64_t v567 = (uint64_t) v40;
            TASSIGN(v566, v567);
            // pto: %233
            ;
            __gm__ bfloat16_t* v568 = PTOAS__GLOBAL_TENSOR_DATA(v123);
            // pto: %233
            ;
            const int64_t v569 = 0;
            // pto: %233
            ;
            const int64_t v570 = 4096;
            // pto: %233
            ;
            pto::Shape<1, 1, 1, 16, 256> v571 = pto::Shape<1, 1, 1, 16, 256>();
            // pto: %233
            ;
            pto::Stride<65536, 65536, 65536, 4096, 1> v572 = pto::Stride<65536, 65536, 65536, 4096, 1>();
            // pto: %233
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v573 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v568 + (v569 + v533 * v570 + v555), v571, v572);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            TLOAD(v566, v573);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %narrow_b_inline1308__tile_t
            ;
            Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v574 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
            // pto: %narrow_b_inline1308__tile_t
            ;
            uint64_t v575 = (uint64_t) v40;
            TASSIGN(v574, v575);
            // pto: %narrow_a_inline1295__tile_Left
            ;
            Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v576 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v427, v62);
            // pto: %narrow_a_inline1295__tile_Left
            ;
            uint64_t v577 = (uint64_t) v41;
            TASSIGN(v576, v577);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
            TMOV(v576, v553);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            // pto: %narrow_b_inline1308__tile_t_Right
            ;
            Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v578 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
            // pto: %narrow_b_inline1308__tile_t_Right
            ;
            uint64_t v579 = (uint64_t) v41;
            TASSIGN(v578, v579);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            TMOV(v578, v574);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            TMATMUL_ACC(v546, v546, v576, v578);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %accum__iter_v7_pview
          ;
          const int64_t v580 = 0;
          // pto: %accum__iter_v7_pview
          ;
          __gm__ float* v581 = PTOAS__GLOBAL_TENSOR_DATA(v132);
          // pto: %accum__iter_v7_pview
          ;
          const int64_t v582 = 1;
          // pto: %accum__iter_v7_pview
          ;
          const int64_t v583 = 1;
          // pto: %accum__iter_v7_pview
          ;
          const int64_t v584 = 1;
          // pto: %accum__iter_v7_pview
          ;
          int64_t v585 = v427 * v48;
          // pto: %accum__iter_v7_pview
          ;
          int64_t v586 = v584 * v585;
          // pto: %accum__iter_v7_pview
          ;
          pto::Shape<1, 1, 1, -1, 16> v587 = pto::Shape<1, 1, 1, -1, 16>(v582, v583, v584, v427, v44);
          // pto: %accum__iter_v7_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v588 = pto::Stride<-1, -1, -1, -1, -1>(v583 * v586, v586, v585, v48, v43);
          // pto: %accum__iter_v7_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v589 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v581 + (v580 + v519 * v48 + v533 * v43), v587, v588);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
          TSTORE(v589, v546);
          set_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
        };
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
    };
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  // pto: %239
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  for (int64_t v590 = v153; v590 < ((int64_t) ((uint64_t) v368 * (uint64_t) v50)); v590 += v51) {
    // pto: %240
    ;
    int64_t v591 = v590 / v50;
    // pto: %241
    ;
    int64_t v592 = v590 % v50;
    // pto: %242, %243, %244
    ;
    int64_t v593 = v592 < v54 ? (int64_t) ((uint64_t) v592 + (uint64_t) v50) : v592;
    // pto: %245
    ;
    int64_t v594 = (int64_t) ((uint64_t) v591 * (uint64_t) v44);
    // pto: %246
    ;
    int64_t v595 = (int64_t) ((uint64_t) v593 * (uint64_t) v44);
    // pto: %247
    ;
    int64_t v596 = (int64_t) ((uint64_t) v32 - (uint64_t) v594);
    // pto: %248
    ;
    int64_t v597 = v596 < v44 ? v596 : v44;
    // pto: %tile_inline1350__tile
    ;
    Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v598 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v44);
    // pto: %tile_inline1350__tile
    ;
    uint64_t v599 = (uint64_t) v39;
    TASSIGN(v598, v599);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    for (int64_t v600 = v54; v600 < v44; v600 += v43) {
      // pto: %249, %250, %251, %252, %k_block_inline1342__tile
      ;
      int32_t v601 = (v12)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v591 * (uint64_t) v50) + (uint64_t) v593) * (uint64_t) v44) + (uint64_t) v600)];
      // pto: %253
      ;
      int64_t v602 = (int64_t) v601;
      // pto: %254
      ;
      int64_t v603 = v602 < v54 ? v54 : v602;
      // pto: %255
      ;
      int64_t v604 = (int64_t) ((uint64_t) v603 * (uint64_t) v62);
      // pto: %a_inline1352__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v605 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v597, v62);
      // pto: %a_inline1352__tile
      ;
      uint64_t v606 = (uint64_t) v39;
      TASSIGN(v605, v606);
      // pto: %256
      ;
      int64_t v607 = v594 < v54 ? v54 : v594;
      // pto: %257
      ;
      int64_t v608 = v604 < v54 ? v54 : v604;
      // pto: %258
      ;
      const int64_t v609 = 0;
      // pto: %258
      ;
      __gm__ bfloat16_t* v610 = PTOAS__GLOBAL_TENSOR_DATA(v115);
      // pto: %258
      ;
      const int64_t v611 = 1;
      // pto: %258
      ;
      const int64_t v612 = 1;
      // pto: %258
      ;
      const int64_t v613 = 1;
      // pto: %258
      ;
      int64_t v614 = v597 * v47;
      // pto: %258
      ;
      int64_t v615 = v613 * v614;
      // pto: %258
      ;
      pto::Shape<1, 1, 1, -1, 256> v616 = pto::Shape<1, 1, 1, -1, 256>(v611, v612, v613, v597, v62);
      // pto: %258
      ;
      pto::Stride<-1, -1, -1, -1, -1> v617 = pto::Stride<-1, -1, -1, -1, -1>(v612 * v615, v615, v614, v47, v43);
      // pto: %258
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v618 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v610 + (v609 + v607 * v47 + v608 * v43), v616, v617);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v605, v618);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %b_inline1339__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v619 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v62);
      // pto: %b_inline1339__tile
      ;
      uint64_t v620 = (uint64_t) v40;
      TASSIGN(v619, v620);
      // pto: %259
      ;
      int64_t v621 = v595 < v54 ? v54 : v595;
      // pto: %weights_proj__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v622 = PTOAS__GLOBAL_TENSOR_DATA(v140);
      // pto: %weights_proj__ssa_v0_pview
      ;
      const int64_t v623 = 0;
      // pto: %weights_proj__ssa_v0_pview
      ;
      const int64_t v624 = 4096;
      // pto: %weights_proj__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 256> v625 = pto::Shape<1, 1, 1, 16, 256>();
      // pto: %weights_proj__ssa_v0_pview
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v626 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %weights_proj__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v627 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v622 + (v623 + v621 * v624 + v608), v625, v626);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v619, v627);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %b_inline1339__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v628 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
      // pto: %b_inline1339__tile_t
      ;
      uint64_t v629 = (uint64_t) v40;
      TASSIGN(v628, v629);
      // pto: %a_inline1352__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v630 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v597, v62);
      // pto: %a_inline1352__tile_Left
      ;
      uint64_t v631 = (uint64_t) v41;
      TASSIGN(v630, v631);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      TMOV(v630, v605);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %b_inline1339__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v632 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
      // pto: %b_inline1339__tile_t_Right
      ;
      uint64_t v633 = (uint64_t) v41;
      TASSIGN(v632, v633);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      TMOV(v632, v628);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %261
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (v600 == v54) {
        TMATMUL(v598, v630, v632);
      } else {
        TMATMUL_ACC(v598, v598, v630, v632);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    };
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID6);
    // pto: %262
    ;
    int64_t v634 = v594 < v54 ? v54 : v594;
    // pto: %263
    ;
    int64_t v635 = v595 < v54 ? v54 : v595;
    // pto: %idx_accum__iter_v1_pview
    ;
    __gm__ float* v636 = PTOAS__GLOBAL_TENSOR_DATA(v149);
    // pto: %idx_accum__iter_v1_pview
    ;
    const int64_t v637 = 0;
    // pto: %idx_accum__iter_v1_pview
    ;
    const int64_t v638 = 64;
    // pto: %idx_accum__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 16> v639 = pto::Shape<1, 1, 1, 16, 16>();
    // pto: %idx_accum__iter_v1_pview
    ;
    pto::Stride<1024, 1024, 1024, 64, 1> v640 = pto::Stride<1024, 1024, 1024, 64, 1>();
    // pto: %idx_accum__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<1024, 1024, 1024, 64, 1>, pto::Layout::ND> v641 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<1024, 1024, 1024, 64, 1>, pto::Layout::ND>(v636 + (v637 + v634 * v638 + v635), v639, v640);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID6);
    pipe_barrier(PIPE_FIX);
    TSTORE(v641, v598);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void prepacked_prefix_indexer_vector(__gm__ float* v1, __gm__ float* v2, __gm__ bfloat16_t* v3, __gm__ bfloat16_t* v4, __gm__ float* v5, __gm__ bfloat16_t* v6, __gm__ bfloat16_t* v7, __gm__ int32_t* v8, __gm__ float* v9, __gm__ int64_t* v10, __gm__ bfloat16_t* v11, __gm__ int32_t* v12, __gm__ float* v13, __gm__ bfloat16_t* v14, __gm__ float* v15, __gm__ float* v16, __gm__ float* v17, __gm__ float* v18, __gm__ float* v19, __gm__ float* v20, __gm__ float* v21, __gm__ float* v22, __gm__ bfloat16_t* v23, __gm__ bfloat16_t* v24, __gm__ bfloat16_t* v25, __gm__ float* v26, __gm__ bfloat16_t* v27, __gm__ float* v28, __gm__ bfloat16_t* v29, __gm__ bfloat16_t* v30, __gm__ half* v31, int64_t v32, int64_t v33, int64_t v34, int64_t v35, int64_t v36, int32_t v37, int32_t v38, int32_t v39) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v40 = 12544;
  const int64_t v41 = 8448;
  const int64_t v42 = 4352;
  const int64_t v43 = 20;
  const int64_t v44 = 8388608;
  // pto: %c108288_i64
  const int64_t v45 = 108288;
  // pto: %c256_i64
  const int64_t v46 = 256;
  // pto: %c42752_i64
  const int64_t v47 = 42752;
  // pto: %c75520_i64
  const int64_t v48 = 75520;
  // pto: %c0_i64
  const int64_t v49 = 0;
  const int64_t v50 = 32;
  const int64_t v51 = 64;
  // pto: %c96_i64
  const int64_t v52 = 96;
  // pto: %c8448_i64
  const int64_t v53 = 8448;
  // pto: %c16640_i64
  const int64_t v54 = 16640;
  // pto: %c24832_i64
  const int64_t v55 = 24832;
  // pto: %c33024_i64
  const int64_t v56 = 33024;
  const int64_t v57 = 83712;
  const int64_t v58 = 79616;
  const int64_t v59 = 77568;
  const int64_t v60 = 76544;
  const int64_t v61 = 76032;
  const int64_t v62 = 75776;
  // pto: %c41216_i64
  const int64_t v63 = 41216;
  // pto: %c41472_i64
  const int64_t v64 = 41472;
  // pto: %c41728_i64
  const int64_t v65 = 41728;
  // pto: %c41984_i64
  const int64_t v66 = 41984;
  // pto: %c42240_i64
  const int64_t v67 = 42240;
  // pto: %c42496_i64
  const int64_t v68 = 42496;
  // pto: %c16384_index
  const int64_t v69 = 16384;
  // pto: %c1_index
  const int64_t v70 = 1;
  const int64_t v71 = 16;
  // pto: %c32768_index
  const int64_t v72 = 32768;
  // pto: %c32_index
  const int64_t v73 = 32;
  // pto: %c4096_index
  const int64_t v74 = 4096;
  const int64_t v75 = 512;
  // pto: %c64_index
  const int64_t v76 = 64;
  // pto: %c4_index
  const int64_t v77 = 4;
  // pto: %c24_index
  const int64_t v78 = 24;
  const int64_t v79 = 8;
  // pto: %c2_index
  const int64_t v80 = 2;
  // pto: %c48_index
  const int64_t v81 = 48;
  // pto: %c0_index
  const int64_t v82 = 0;
  // pto: %c256_index
  const int64_t v83 = 256;
  // pto: %cst_40
  const float v84 = 0.0f;
  // pto: %cst_41
  const bfloat16_t v85 = 0.0f;
  // pto: %c7_index
  const int64_t v86 = 7;
  // pto: %c192_index
  const int64_t v87 = 192;
  // pto: %c0_i32
  const int32_t v88 = 0;
  // pto: %c16_i32
  const int32_t v89 = 16;
  // pto: %c22_index
  const int64_t v90 = 22;
  // pto: %cst_47
  const float v91 = 6.10351563E-5f;
  // pto: %cst_48
  const float v92 = 9.99999997E-7f;
  // pto: %cst_49
  const float v93 = 1.0f;
  // pto: %cst_51
  const float v94 = 2.0f;
  // pto: %c8192_index
  const int64_t v95 = 8192;
  // pto: %c12288_index
  const int64_t v96 = 12288;
  // pto: %c2048_index
  const int64_t v97 = 2048;
  // pto: %c1024_index
  const int64_t v98 = 1024;
  // pto: %c128_index
  const int64_t v99 = 128;
  // pto: %cst_57
  const float v100 = 2.44140625E-4f;
  // pto: %c8388608_index
  const int64_t v101 = 8388608;
  // pto: %c2139095040_i64
  const int64_t v102 = 2139095040;
  // pto: %c2_i64
  const int64_t v103 = 2;
  // pto: %c152_i64
  const int64_t v104 = 152;
  // pto: %c1_i64
  const int64_t v105 = 1;
  const int64_t v106 = 12;
  // pto: %c18_index
  const int64_t v107 = 18;
  // pto: %c15_index
  const int64_t v108 = 15;
  // pto: %cst_66
  const float v109 = 0.0110485433f;
  // pto: %wide__ssa_v0_view
  const int64_t v110 = 1;
  // pto: %wide__ssa_v0_view
  const int64_t v111 = 1;
  // pto: %wide__ssa_v0_view
  const int64_t v112 = 1;
  // pto: %wide__ssa_v0_view
  int64_t v113 = (int64_t) v32;
  // pto: %wide__ssa_v0_view
  int64_t v114 = v113 * v69;
  // pto: %wide__ssa_v0_view
  int64_t v115 = v112 * v114;
  // pto: %wide__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v116 = pto::Shape<1, 1, 1, -1, -1>(v110, v111, v112, v113, v69);
  // pto: %wide__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v117 = pto::Stride<-1, -1, -1, -1, -1>(v111 * v115, v115, v114, v69, v70);
  // pto: %wide__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v118 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v116, v117);
  // pto: %packed_flat__ssa_v0_view
  const int64_t v119 = 1;
  // pto: %packed_flat__ssa_v0_view
  const int64_t v120 = 1;
  // pto: %packed_flat__ssa_v0_view
  const int64_t v121 = 1;
  // pto: %packed_flat__ssa_v0_view
  int64_t v122 = (int64_t) v34;
  // pto: %packed_flat__ssa_v0_view
  int64_t v123 = v122 * v72;
  // pto: %packed_flat__ssa_v0_view
  int64_t v124 = v121 * v123;
  // pto: %packed_flat__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v125 = pto::Shape<1, 1, 1, -1, -1>(v119, v120, v121, v122, v72);
  // pto: %packed_flat__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v126 = pto::Stride<-1, -1, -1, -1, -1>(v120 * v124, v124, v123, v72, v70);
  // pto: %packed_flat__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v127 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v125, v126);
  // pto: %normed__ssa_v0_view
  const int64_t v128 = 1;
  // pto: %normed__ssa_v0_view
  const int64_t v129 = 1;
  // pto: %normed__ssa_v0_view
  const int64_t v130 = 1;
  // pto: %normed__ssa_v0_view
  int64_t v131 = (int64_t) v32;
  // pto: %normed__ssa_v0_view
  int64_t v132 = v131 * v74;
  // pto: %normed__ssa_v0_view
  int64_t v133 = v130 * v132;
  // pto: %normed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v134 = pto::Shape<1, 1, 1, -1, -1>(v128, v129, v130, v131, v74);
  // pto: %normed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v135 = pto::Stride<-1, -1, -1, -1, -1>(v129 * v133, v133, v132, v74, v70);
  // pto: %normed__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v136 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v134, v135);
  // pto: %flat_hc__ssa_v0_view
  const int64_t v137 = 1;
  // pto: %flat_hc__ssa_v0_view
  const int64_t v138 = 1;
  // pto: %flat_hc__ssa_v0_view
  const int64_t v139 = 1;
  // pto: %flat_hc__ssa_v0_view
  int64_t v140 = (int64_t) v32;
  // pto: %flat_hc__ssa_v0_view
  int64_t v141 = v140 * v69;
  // pto: %flat_hc__ssa_v0_view
  int64_t v142 = v139 * v141;
  // pto: %flat_hc__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v143 = pto::Shape<1, 1, 1, -1, -1>(v137, v138, v139, v140, v69);
  // pto: %flat_hc__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v144 = pto::Stride<-1, -1, -1, -1, -1>(v138 * v142, v142, v141, v69, v70);
  // pto: %flat_hc__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v145 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v143, v144);
  // pto: %spmd_square_read__ssa_v0_view
  const int64_t v146 = 1;
  // pto: %spmd_square_read__ssa_v0_view
  const int64_t v147 = 1;
  // pto: %spmd_square_read__ssa_v0_view
  const int64_t v148 = 1;
  // pto: %spmd_square_read__ssa_v0_view
  int64_t v149 = (int64_t) v33;
  // pto: %spmd_square_read__ssa_v0_view
  int64_t v150 = v149 * v71;
  // pto: %spmd_square_read__ssa_v0_view
  int64_t v151 = v148 * v150;
  // pto: %spmd_square_read__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v152 = pto::Shape<1, 1, 1, -1, -1>(v146, v147, v148, v149, v71);
  // pto: %spmd_square_read__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v153 = pto::Stride<-1, -1, -1, -1, -1>(v147 * v151, v151, v150, v71, v70);
  // pto: %spmd_square_read__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v154 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v152, v153);
  // pto: %vec_ws__ssa_v0_view
  const int64_t v155 = 1;
  // pto: %vec_ws__ssa_v0_view
  const int64_t v156 = 1;
  // pto: %vec_ws__ssa_v0_view
  const int64_t v157 = 1;
  // pto: %vec_ws__ssa_v0_view
  int64_t v158 = (int64_t) v36;
  // pto: %vec_ws__ssa_v0_view
  int64_t v159 = v158 * v76;
  // pto: %vec_ws__ssa_v0_view
  int64_t v160 = v157 * v159;
  // pto: %vec_ws__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v161 = pto::Shape<1, 1, 1, -1, -1>(v155, v156, v157, v158, v76);
  // pto: %vec_ws__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v162 = pto::Stride<-1, -1, -1, -1, -1>(v156 * v160, v160, v159, v76, v70);
  // pto: %vec_ws__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v163 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v161, v162);
  // pto: %spmd_linear_read__ssa_v0_view
  const int64_t v164 = 1;
  // pto: %spmd_linear_read__ssa_v0_view
  const int64_t v165 = 1;
  // pto: %spmd_linear_read__ssa_v0_view
  const int64_t v166 = 1;
  // pto: %spmd_linear_read__ssa_v0_view
  int64_t v167 = (int64_t) v33;
  // pto: %spmd_linear_read__ssa_v0_view
  int64_t v168 = v167 * v73;
  // pto: %spmd_linear_read__ssa_v0_view
  int64_t v169 = v166 * v168;
  // pto: %spmd_linear_read__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v170 = pto::Shape<1, 1, 1, -1, -1>(v164, v165, v166, v167, v73);
  // pto: %spmd_linear_read__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v171 = pto::Stride<-1, -1, -1, -1, -1>(v165 * v169, v169, v168, v73, v70);
  // pto: %spmd_linear_read__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v172 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v17, v170, v171);
  // pto: %hc_attn_base__ssa_v0_view
  const int64_t v173 = 1;
  // pto: %hc_attn_base__ssa_v0_view
  const int64_t v174 = 1;
  // pto: %hc_attn_base__ssa_v0_view
  const int64_t v175 = 1;
  // pto: %hc_attn_base__ssa_v0_view
  const int64_t v176 = 1;
  // pto: %hc_attn_base__ssa_v0_view
  int64_t v177 = v78 * v70;
  // pto: %hc_attn_base__ssa_v0_view
  int64_t v178 = v176 * v177;
  // pto: %hc_attn_base__ssa_v0_view
  int64_t v179 = v175 * v178;
  // pto: %hc_attn_base__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v180 = pto::Shape<1, 1, 1, 1, -1>(v173, v174, v175, v176, v78);
  // pto: %hc_attn_base__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v181 = pto::Stride<-1, -1, -1, -1, -1>(v174 * v179, v179, v178, v177, v70);
  // pto: %hc_attn_base__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v182 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v19, v180, v181);
  // pto: %hc_base_2d__ssa_v0_view
  const int64_t v183 = 1;
  // pto: %hc_base_2d__ssa_v0_view
  const int64_t v184 = 1;
  // pto: %hc_base_2d__ssa_v0_view
  const int64_t v185 = 1;
  // pto: %hc_base_2d__ssa_v0_view
  int64_t v186 = v70 * v78;
  // pto: %hc_base_2d__ssa_v0_view
  int64_t v187 = v185 * v186;
  // pto: %hc_base_2d__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v188 = pto::Shape<1, 1, 1, -1, -1>(v183, v184, v185, v70, v78);
  // pto: %hc_base_2d__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v189 = pto::Stride<-1, -1, -1, -1, -1>(v184 * v187, v187, v186, v78, v70);
  // pto: %hc_base_2d__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v190 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v20, v188, v189);
  // pto: %post__ssa_v0_view
  const int64_t v191 = 1;
  // pto: %post__ssa_v0_view
  const int64_t v192 = 1;
  // pto: %post__ssa_v0_view
  const int64_t v193 = 1;
  // pto: %post__ssa_v0_view
  int64_t v194 = (int64_t) v32;
  // pto: %post__ssa_v0_view
  int64_t v195 = v194 * v77;
  // pto: %post__ssa_v0_view
  int64_t v196 = v193 * v195;
  // pto: %post__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v197 = pto::Shape<1, 1, 1, -1, -1>(v191, v192, v193, v194, v77);
  // pto: %post__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v198 = pto::Stride<-1, -1, -1, -1, -1>(v192 * v196, v196, v195, v77, v70);
  // pto: %post__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v199 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v21, v197, v198);
  // pto: %comb__ssa_v0_view
  const int64_t v200 = 1;
  // pto: %comb__ssa_v0_view
  const int64_t v201 = 1;
  // pto: %comb__ssa_v0_view
  const int64_t v202 = 1;
  // pto: %comb__ssa_v0_view
  int64_t v203 = (int64_t) v32;
  // pto: %comb__ssa_v0_view
  int64_t v204 = v203 * v71;
  // pto: %comb__ssa_v0_view
  int64_t v205 = v202 * v204;
  // pto: %comb__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v206 = pto::Shape<1, 1, 1, -1, -1>(v200, v201, v202, v203, v71);
  // pto: %comb__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v207 = pto::Stride<-1, -1, -1, -1, -1>(v201 * v205, v205, v204, v71, v70);
  // pto: %comb__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v208 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v22, v206, v207);
  // pto: %mixed__ssa_v0_view
  const int64_t v209 = 1;
  // pto: %mixed__ssa_v0_view
  const int64_t v210 = 1;
  // pto: %mixed__ssa_v0_view
  const int64_t v211 = 1;
  // pto: %mixed__ssa_v0_view
  int64_t v212 = (int64_t) v32;
  // pto: %mixed__ssa_v0_view
  int64_t v213 = v212 * v74;
  // pto: %mixed__ssa_v0_view
  int64_t v214 = v211 * v213;
  // pto: %mixed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v215 = pto::Shape<1, 1, 1, -1, -1>(v209, v210, v211, v212, v74);
  // pto: %mixed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v216 = pto::Stride<-1, -1, -1, -1, -1>(v210 * v214, v214, v213, v74, v70);
  // pto: %mixed__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v217 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v23, v215, v216);
  // pto: %mixed_tail__ssa_v0_view
  const int64_t v218 = 1;
  // pto: %mixed_tail__ssa_v0_view
  const int64_t v219 = 1;
  // pto: %mixed_tail__ssa_v0_view
  const int64_t v220 = 1;
  // pto: %mixed_tail__ssa_v0_view
  int64_t v221 = v79 * v74;
  // pto: %mixed_tail__ssa_v0_view
  int64_t v222 = v220 * v221;
  // pto: %mixed_tail__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v223 = pto::Shape<1, 1, 1, -1, -1>(v218, v219, v220, v79, v74);
  // pto: %mixed_tail__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v224 = pto::Stride<-1, -1, -1, -1, -1>(v219 * v222, v222, v221, v74, v70);
  // pto: %mixed_tail__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v225 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v24, v223, v224);
  // pto: %attn_norm_w__ssa_v0_view
  const int64_t v226 = 1;
  // pto: %attn_norm_w__ssa_v0_view
  const int64_t v227 = 1;
  // pto: %attn_norm_w__ssa_v0_view
  const int64_t v228 = 1;
  // pto: %attn_norm_w__ssa_v0_view
  const int64_t v229 = 1;
  // pto: %attn_norm_w__ssa_v0_view
  int64_t v230 = v74 * v70;
  // pto: %attn_norm_w__ssa_v0_view
  int64_t v231 = v229 * v230;
  // pto: %attn_norm_w__ssa_v0_view
  int64_t v232 = v228 * v231;
  // pto: %attn_norm_w__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v233 = pto::Shape<1, 1, 1, 1, -1>(v226, v227, v228, v229, v74);
  // pto: %attn_norm_w__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v234 = pto::Stride<-1, -1, -1, -1, -1>(v227 * v232, v232, v231, v230, v70);
  // pto: %attn_norm_w__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v235 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v25, v233, v234);
  // pto: %spmd_accum_read__ssa_v0_view
  const int64_t v236 = 1;
  // pto: %spmd_accum_read__ssa_v0_view
  const int64_t v237 = 1;
  // pto: %spmd_accum_read__ssa_v0_view
  const int64_t v238 = 1;
  // pto: %spmd_accum_read__ssa_v0_view
  int64_t v239 = (int64_t) v35;
  // pto: %spmd_accum_read__ssa_v0_view
  int64_t v240 = v239 * v75;
  // pto: %spmd_accum_read__ssa_v0_view
  int64_t v241 = v238 * v240;
  // pto: %spmd_accum_read__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v242 = pto::Shape<1, 1, 1, -1, -1>(v236, v237, v238, v239, v75);
  // pto: %spmd_accum_read__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v243 = pto::Stride<-1, -1, -1, -1, -1>(v237 * v241, v241, v240, v75, v70);
  // pto: %spmd_accum_read__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v244 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v26, v242, v243);
  // pto: %projected_kv__ssa_v0_view
  const int64_t v245 = 1;
  // pto: %projected_kv__ssa_v0_view
  const int64_t v246 = 1;
  // pto: %projected_kv__ssa_v0_view
  const int64_t v247 = 1;
  // pto: %projected_kv__ssa_v0_view
  int64_t v248 = (int64_t) v32;
  // pto: %projected_kv__ssa_v0_view
  int64_t v249 = v248 * v75;
  // pto: %projected_kv__ssa_v0_view
  int64_t v250 = v247 * v249;
  // pto: %projected_kv__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v251 = pto::Shape<1, 1, 1, -1, -1>(v245, v246, v247, v248, v75);
  // pto: %projected_kv__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v252 = pto::Stride<-1, -1, -1, -1, -1>(v246 * v250, v250, v249, v75, v70);
  // pto: %projected_kv__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v253 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v27, v251, v252);
  // pto: %spmd_idx_accum_read__ssa_v0_view
  const int64_t v254 = 1;
  // pto: %spmd_idx_accum_read__ssa_v0_view
  const int64_t v255 = 1;
  // pto: %spmd_idx_accum_read__ssa_v0_view
  const int64_t v256 = 1;
  // pto: %spmd_idx_accum_read__ssa_v0_view
  int64_t v257 = (int64_t) v34;
  // pto: %spmd_idx_accum_read__ssa_v0_view
  int64_t v258 = v257 * v76;
  // pto: %spmd_idx_accum_read__ssa_v0_view
  int64_t v259 = v256 * v258;
  // pto: %spmd_idx_accum_read__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v260 = pto::Shape<1, 1, 1, -1, -1>(v254, v255, v256, v257, v76);
  // pto: %spmd_idx_accum_read__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v261 = pto::Stride<-1, -1, -1, -1, -1>(v255 * v259, v259, v258, v76, v70);
  // pto: %spmd_idx_accum_read__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v262 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v28, v260, v261);
  // pto: %indexer_raw__ssa_v0_view
  const int64_t v263 = 1;
  // pto: %indexer_raw__ssa_v0_view
  const int64_t v264 = 1;
  // pto: %indexer_raw__ssa_v0_view
  const int64_t v265 = 1;
  // pto: %indexer_raw__ssa_v0_view
  int64_t v266 = (int64_t) v32;
  // pto: %indexer_raw__ssa_v0_view
  int64_t v267 = v266 * v76;
  // pto: %indexer_raw__ssa_v0_view
  int64_t v268 = v265 * v267;
  // pto: %indexer_raw__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v269 = pto::Shape<1, 1, 1, -1, -1>(v263, v264, v265, v266, v76);
  // pto: %indexer_raw__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v270 = pto::Stride<-1, -1, -1, -1, -1>(v264 * v268, v268, v267, v76, v70);
  // pto: %indexer_raw__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v271 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v29, v269, v270);
  // pto: %indexer_scaled__ssa_v0_view
  const int64_t v272 = 1;
  // pto: %indexer_scaled__ssa_v0_view
  const int64_t v273 = 1;
  // pto: %indexer_scaled__ssa_v0_view
  const int64_t v274 = 1;
  // pto: %indexer_scaled__ssa_v0_view
  int64_t v275 = (int64_t) v32;
  // pto: %indexer_scaled__ssa_v0_view
  int64_t v276 = v275 * v76;
  // pto: %indexer_scaled__ssa_v0_view
  int64_t v277 = v274 * v276;
  // pto: %indexer_scaled__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v278 = pto::Shape<1, 1, 1, -1, -1>(v272, v273, v274, v275, v76);
  // pto: %indexer_scaled__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v279 = pto::Stride<-1, -1, -1, -1, -1>(v273 * v277, v277, v276, v76, v70);
  // pto: %indexer_scaled__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v280 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v30, v278, v279);
  // pto: %indexer_weights__ssa_v0_view
  const int64_t v281 = 1;
  // pto: %indexer_weights__ssa_v0_view
  const int64_t v282 = 1;
  // pto: %indexer_weights__ssa_v0_view
  const int64_t v283 = 1;
  // pto: %indexer_weights__ssa_v0_view
  int64_t v284 = (int64_t) v32;
  // pto: %indexer_weights__ssa_v0_view
  int64_t v285 = v284 * v76;
  // pto: %indexer_weights__ssa_v0_view
  int64_t v286 = v283 * v285;
  // pto: %indexer_weights__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v287 = pto::Shape<1, 1, 1, -1, -1>(v281, v282, v283, v284, v76);
  // pto: %indexer_weights__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v288 = pto::Stride<-1, -1, -1, -1, -1>(v282 * v286, v286, v285, v76, v70);
  // pto: %indexer_weights__ssa_v0_view
  GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v289 = GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v31, v287, v288);
  uint64_t v290 = reinterpret_cast<uint64_t>(v10);
  set_ffts_base_addr(v290);
  // pto: %t__tmp_v0, %90, %91, %t__tmp_v1
  int64_t v291 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v37) * (uint64_t) v80) + (uint64_t) ((int64_t) v39));
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  set_flag(PIPE_S, PIPE_V, EVENT_ID5);
  for (int64_t v292 = v291; v292 < v32; v292 += v81) {
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    for (int64_t v293 = v82; v293 < v73; v293 += v80) {
      // pto: %92
      ;
      int64_t v294 = (int64_t) ((uint64_t) v293 * (uint64_t) v75);
      // pto: %94
      ;
      int64_t v295 = (int64_t) ((uint64_t) v294 + (uint64_t) v75);
      // pto: %t__tile
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v296 = Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
      // pto: %t__tile
      ;
      uint64_t v297 = (uint64_t) v45;
      TASSIGN(v296, v297);
      // pto: %95
      ;
      int64_t v298 = v292 < v82 ? v82 : v292;
      // pto: %96
      ;
      int64_t v299 = v294 < v82 ? v82 : v294;
      // pto: %flat_hc__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v300 = PTOAS__GLOBAL_TENSOR_DATA(v145);
      // pto: %flat_hc__ssa_v0_pview
      ;
      const int64_t v301 = 0;
      // pto: %flat_hc__ssa_v0_pview
      ;
      const int64_t v302 = 16384;
      // pto: %flat_hc__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v303 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %flat_hc__ssa_v0_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v304 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %flat_hc__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v305 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v300 + (v301 + v298 * v302 + v299), v303, v304);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      TLOAD(v296, v305);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %0
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v306 = Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
      // pto: %0
      ;
      uint64_t v307 = (uint64_t) v46;
      TASSIGN(v306, v307);
      // pto: %98
      ;
      int64_t v308 = v295 < v82 ? v82 : v295;
      // pto: %99
      ;
      __gm__ bfloat16_t* v309 = PTOAS__GLOBAL_TENSOR_DATA(v145);
      // pto: %99
      ;
      const int64_t v310 = 0;
      // pto: %99
      ;
      const int64_t v311 = 16384;
      // pto: %99
      ;
      pto::Shape<1, 1, 1, 1, 512> v312 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %99
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v313 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %99
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v314 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v309 + (v310 + v298 * v311 + v308), v312, v313);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      TLOAD(v306, v314);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %value_inline407__tile
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
      // pto: %value_inline407__tile
      ;
      uint64_t v316 = (uint64_t) v47;
      TASSIGN(v315, v316);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      RoundMode v317 = RoundMode::CAST_ROUND;
      SaturationMode v318 = SaturationMode::ON;
      TCVT(v315, v296, v317, v318);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      // pto: %wide__iter_v3_pview
      ;
      __gm__ float* v319 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %wide__iter_v3_pview
      ;
      const int64_t v320 = 0;
      // pto: %wide__iter_v3_pview
      ;
      const int64_t v321 = 16384;
      // pto: %wide__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v322 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %wide__iter_v3_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v323 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %wide__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v324 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v319 + (v320 + v298 * v321 + v299), v322, v323);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v324, v315);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      // pto: %1
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v325 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
      // pto: %1
      ;
      uint64_t v326 = (uint64_t) v48;
      TASSIGN(v325, v326);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      RoundMode v327 = RoundMode::CAST_ROUND;
      SaturationMode v328 = SaturationMode::ON;
      TCVT(v325, v306, v327, v328);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      // pto: %wide__tile_pview
      ;
      __gm__ float* v329 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %wide__tile_pview
      ;
      const int64_t v330 = 0;
      // pto: %wide__tile_pview
      ;
      const int64_t v331 = 16384;
      // pto: %wide__tile_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v332 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %wide__tile_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v333 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %wide__tile_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v334 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v329 + (v330 + v298 * v331 + v308), v332, v333);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v334, v325);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    };
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %105
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  if (v32 >= v76) {
    // pto: %107, %108, %109
    ;
    for (int64_t v335 = v291; v335 < ((int64_t) ((uint64_t) (v34 / v71) * (uint64_t) v76) / v77); v335 += v81) {
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      for (int64_t v336 = v82; v336 < v77; v336 += v70) {
        // pto: %110, %111
        ;
        int64_t v337 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v335 * (uint64_t) v77) + (uint64_t) v336);
        // pto: %112, %113
        ;
        int64_t v338 = (int64_t) ((uint64_t) (v337 / v76) * (uint64_t) v71);
        // pto: %114
        ;
        int64_t v339 = v337 % v76;
        // pto: %115, %116, %117
        ;
        int64_t v340 = v339 < v82 ? (int64_t) ((uint64_t) v339 + (uint64_t) v76) : v339;
        // pto: %118
        ;
        int64_t v341 = (int64_t) ((uint64_t) v340 * (uint64_t) v83);
        // pto: %119
        ;
        int64_t v342 = (int64_t) ((uint64_t) v32 - (uint64_t) v338);
        // pto: %120
        ;
        int64_t v343 = v342 < v71 ? v342 : v71;
        // pto: %panel64_values_inline426__ssa_v0
        ;
        Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v344 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v343, v83);
        // pto: %panel64_values_inline426__ssa_v0
        ;
        uint64_t v345 = (uint64_t) v47;
        TASSIGN(v344, v345);
        // pto: %121
        ;
        int64_t v346 = v338 < v82 ? v82 : v338;
        // pto: %122
        ;
        int64_t v347 = v341 < v82 ? v82 : v341;
        // pto: %wide_v1__ssa_v0_pview
        ;
        const int64_t v348 = 0;
        // pto: %wide_v1__ssa_v0_pview
        ;
        __gm__ float* v349 = PTOAS__GLOBAL_TENSOR_DATA(v118);
        // pto: %wide_v1__ssa_v0_pview
        ;
        const int64_t v350 = 1;
        // pto: %wide_v1__ssa_v0_pview
        ;
        const int64_t v351 = 1;
        // pto: %wide_v1__ssa_v0_pview
        ;
        const int64_t v352 = 1;
        // pto: %wide_v1__ssa_v0_pview
        ;
        int64_t v353 = v343 * v69;
        // pto: %wide_v1__ssa_v0_pview
        ;
        int64_t v354 = v352 * v353;
        // pto: %wide_v1__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v355 = pto::Shape<1, 1, 1, -1, 256>(v350, v351, v352, v343, v83);
        // pto: %wide_v1__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v356 = pto::Stride<-1, -1, -1, -1, -1>(v351 * v354, v354, v353, v69, v70);
        // pto: %wide_v1__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v357 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v349 + (v348 + v346 * v69 + v347 * v70), v355, v356);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        TLOAD(v344, v357);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        set_flag(PIPE_MTE2, PIPE_S, EVENT_ID1);
        wait_flag(PIPE_MTE2, PIPE_S, EVENT_ID1);
        for (int64_t v358 = v343; v358 < v71; v358 += v70) {
          for (int64_t v359 = v82; v359 < v83; v359 += v70) {
            // pto: %flat_offset_mul, %flat_offset
            ;
            int64_t v360 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v358 * (uint64_t) v83) + (uint64_t) v359);
            v344.SetValue(v360, v84);
          };
        };
        set_flag(PIPE_S, PIPE_V, EVENT_ID1);
        v344.SetValidShape(v71, v83);
        // pto: %panel64_values_v2_inline429__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v361 = Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v83);
        // pto: %panel64_values_v2_inline429__ssa_v0
        ;
        uint64_t v362 = (uint64_t) v47;
        TASSIGN(v361, v362);
        wait_flag(PIPE_S, PIPE_V, EVENT_ID1);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v363 = RoundMode::CAST_ROUND;
        SaturationMode v364 = SaturationMode::ON;
        TCVT(v361, v344, v363, v364);
        // pto: %transpose_tmp
        ;
        Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v365 = Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v83);
        // pto: %transpose_tmp
        ;
        uint64_t v366 = (uint64_t) v48;
        TASSIGN(v365, v366);
        // pto: %panel64_transposed_values_inline414__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v367 = Tile<TileType::Vec, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v71);
        // pto: %panel64_transposed_values_inline414__ssa_v0
        ;
        uint64_t v368 = (uint64_t) v45;
        TASSIGN(v367, v368);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
        TTRANS(v367, v361, v365);
        // pto: %panel64_packed_transposed_inline425__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v369 = Tile<TileType::Vec, bfloat16_t, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v75, v71);
        // pto: %panel64_packed_transposed_inline425__ssa_v0
        ;
        uint64_t v370 = (uint64_t) v47;
        TASSIGN(v369, v370);
        pipe_barrier(PIPE_V);
        TEXPANDS(v369, v85);
        for (int64_t v371 = v82; v371 < v73; v371 += v70) {
          // pto: %panel64_input8_inline419__ssa_v0
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v372 = Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v71);
          // pto: %panel64_input8_inline419__ssa_v0
          ;
          uint64_t v373 = (uint64_t) v45;
          TASSIGN(v372, v373);
          // pto: %slice_view
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v374;
          // pto: %127, %slice_view
          ;
          uint64_t v375 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v371 * (uint64_t) v79) * (uint64_t) v50) + (uint64_t) v45);
          TASSIGN(v374, v375);
          // pto: %128
          ;
          int64_t v376 = (int64_t) ((uint64_t) v371 * (uint64_t) v71);
          // pto: %assemble_view
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v377;
          // pto: %assemble_view
          ;
          uint64_t v378 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v376 * (uint64_t) v50) + (uint64_t) v47);
          TASSIGN(v377, v378);
          pipe_barrier(PIPE_V);
          TMOV(v377, v374);
          // pto: %131
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v379;
          // pto: %130, %131
          ;
          uint64_t v380 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v376 + (uint64_t) v79) * (uint64_t) v50) + (uint64_t) v47);
          TASSIGN(v379, v380);
          pipe_barrier(PIPE_V);
          TMOV(v379, v374);
        };
        // pto: %2
        ;
        Tile<TileType::Vec, bfloat16_t, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v381 = Tile<TileType::Vec, bfloat16_t, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v75, v71);
        // pto: %2
        ;
        uint64_t v382 = (uint64_t) v48;
        TASSIGN(v381, v382);
        // pto: %panel64_packed_values_inline412__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v383 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v75);
        // pto: %panel64_packed_values_inline412__ssa_v0
        ;
        uint64_t v384 = (uint64_t) v45;
        TASSIGN(v383, v384);
        pipe_barrier(PIPE_V);
        TTRANS(v383, v369, v381);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        int64_t v385 = (int64_t) ((uint64_t) v340 * (uint64_t) v75);
        // pto: %134
        ;
        int64_t v386 = v385 < v82 ? v82 : v385;
        // pto: %packed_flat__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v387 = PTOAS__GLOBAL_TENSOR_DATA(v127);
        // pto: %packed_flat__ssa_v0_pview
        ;
        const int64_t v388 = 0;
        // pto: %packed_flat__ssa_v0_pview
        ;
        const int64_t v389 = 32768;
        // pto: %packed_flat__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 16, 512> v390 = pto::Shape<1, 1, 1, 16, 512>();
        // pto: %packed_flat__ssa_v0_pview
        ;
        pto::Stride<524288, 524288, 524288, 32768, 1> v391 = pto::Stride<524288, 524288, 524288, 32768, 1>();
        // pto: %packed_flat__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND> v392 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND>(v387 + (v388 + v346 * v389 + v386), v390, v391);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        TSTORE(v392, v383);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      };
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    };
  } else {
    // pto: %136, %137
    ;
    for (int64_t v393 = v291; v393 < ((int64_t) ((uint64_t) (v34 / v71) * (uint64_t) v76)); v393 += v81) {
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      // pto: %141, %142
      ;
      int64_t v394 = (int64_t) ((uint64_t) (v393 / v76) * (uint64_t) v71);
      // pto: %143
      ;
      int64_t v395 = v393 % v76;
      // pto: %144, %145, %146
      ;
      int64_t v396 = v395 < v82 ? (int64_t) ((uint64_t) v395 + (uint64_t) v76) : v395;
      // pto: %147
      ;
      int64_t v397 = (int64_t) ((uint64_t) v396 * (uint64_t) v83);
      // pto: %148
      ;
      int64_t v398 = (int64_t) ((uint64_t) v32 - (uint64_t) v394);
      // pto: %149
      ;
      int64_t v399 = v398 < v71 ? v398 : v71;
      // pto: %panel64_values_inline444__ssa_v0
      ;
      Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v400 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v399, v83);
      // pto: %panel64_values_inline444__ssa_v0
      ;
      uint64_t v401 = (uint64_t) v47;
      TASSIGN(v400, v401);
      // pto: %150
      ;
      int64_t v402 = v394 < v82 ? v82 : v394;
      // pto: %151
      ;
      int64_t v403 = v397 < v82 ? v82 : v397;
      // pto: %154
      ;
      const int64_t v404 = 0;
      // pto: %154
      ;
      __gm__ float* v405 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %154
      ;
      const int64_t v406 = 1;
      // pto: %154
      ;
      const int64_t v407 = 1;
      // pto: %154
      ;
      const int64_t v408 = 1;
      // pto: %154
      ;
      int64_t v409 = v399 * v69;
      // pto: %154
      ;
      int64_t v410 = v408 * v409;
      // pto: %154
      ;
      pto::Shape<1, 1, 1, -1, 256> v411 = pto::Shape<1, 1, 1, -1, 256>(v406, v407, v408, v399, v83);
      // pto: %154
      ;
      pto::Stride<-1, -1, -1, -1, -1> v412 = pto::Stride<-1, -1, -1, -1, -1>(v407 * v410, v410, v409, v69, v70);
      // pto: %154
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v413 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v405 + (v404 + v402 * v69 + v403 * v70), v411, v412);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      TLOAD(v400, v413);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      set_flag(PIPE_MTE2, PIPE_S, EVENT_ID2);
      wait_flag(PIPE_MTE2, PIPE_S, EVENT_ID2);
      for (int64_t v414 = v399; v414 < v71; v414 += v70) {
        for (int64_t v415 = v82; v415 < v83; v415 += v70) {
          // pto: %157, %158
          ;
          int64_t v416 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v414 * (uint64_t) v83) + (uint64_t) v415);
          v400.SetValue(v416, v84);
        };
      };
      set_flag(PIPE_S, PIPE_V, EVENT_ID2);
      v400.SetValidShape(v71, v83);
      // pto: %3
      ;
      Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v417 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v83);
      // pto: %3
      ;
      uint64_t v418 = (uint64_t) v48;
      TASSIGN(v417, v418);
      // pto: %panel64_transposed_values_inline446__ssa_v0
      ;
      Tile<TileType::Vec, float, 256, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v419 = Tile<TileType::Vec, float, 256, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v71);
      // pto: %panel64_transposed_values_inline446__ssa_v0
      ;
      uint64_t v420 = (uint64_t) v45;
      TASSIGN(v419, v420);
      wait_flag(PIPE_S, PIPE_V, EVENT_ID2);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      TTRANS(v419, v400, v417);
      // pto: %panel64_packed_transposed_inline432__ssa_v0
      ;
      Tile<TileType::Vec, float, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v421 = Tile<TileType::Vec, float, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v75, v71);
      // pto: %panel64_packed_transposed_inline432__ssa_v0
      ;
      uint64_t v422 = (uint64_t) v47;
      TASSIGN(v421, v422);
      pipe_barrier(PIPE_V);
      TEXPANDS(v421, v84);
      for (int64_t v423 = v82; v423 < v73; v423 += v70) {
        // pto: %panel64_input8_inline438__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v424 = Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v71);
        // pto: %panel64_input8_inline438__ssa_v0
        ;
        uint64_t v425 = (uint64_t) v45;
        TASSIGN(v424, v425);
        // pto: %160
        ;
        Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v426;
        // pto: %159, %160
        ;
        uint64_t v427 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v423 * (uint64_t) v79) * (uint64_t) v51) + (uint64_t) v45);
        TASSIGN(v426, v427);
        // pto: %161
        ;
        int64_t v428 = (int64_t) ((uint64_t) v423 * (uint64_t) v71);
        // pto: %162
        ;
        Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v429;
        // pto: %162
        ;
        uint64_t v430 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v428 * (uint64_t) v51) + (uint64_t) v47);
        TASSIGN(v429, v430);
        pipe_barrier(PIPE_V);
        TMOV(v429, v426);
        // pto: %165
        ;
        Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v431;
        // pto: %164, %165
        ;
        uint64_t v432 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v428 + (uint64_t) v79) * (uint64_t) v51) + (uint64_t) v47);
        TASSIGN(v431, v432);
        pipe_barrier(PIPE_V);
        TMOV(v431, v426);
      };
      // pto: %4
      ;
      Tile<TileType::Vec, float, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v433 = Tile<TileType::Vec, float, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v75, v71);
      // pto: %4
      ;
      uint64_t v434 = (uint64_t) v48;
      TASSIGN(v433, v434);
      // pto: %panel64_packed_values_inline430__ssa_v0
      ;
      Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v435 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v75);
      // pto: %panel64_packed_values_inline430__ssa_v0
      ;
      uint64_t v436 = (uint64_t) v45;
      TASSIGN(v435, v436);
      pipe_barrier(PIPE_V);
      TTRANS(v435, v421, v433);
      // pto: %t__tmp_v4
      ;
      Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v437 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v75);
      // pto: %t__tmp_v4
      ;
      uint64_t v438 = (uint64_t) v47;
      TASSIGN(v437, v438);
      pipe_barrier(PIPE_V);
      RoundMode v439 = RoundMode::CAST_ROUND;
      SaturationMode v440 = SaturationMode::ON;
      TCVT(v437, v435, v439, v440);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      int64_t v441 = (int64_t) ((uint64_t) v396 * (uint64_t) v75);
      // pto: %168
      ;
      int64_t v442 = v441 < v82 ? v82 : v441;
      // pto: %169
      ;
      __gm__ bfloat16_t* v443 = PTOAS__GLOBAL_TENSOR_DATA(v127);
      // pto: %169
      ;
      const int64_t v444 = 0;
      // pto: %169
      ;
      const int64_t v445 = 32768;
      // pto: %169
      ;
      pto::Shape<1, 1, 1, 16, 512> v446 = pto::Shape<1, 1, 1, 16, 512>();
      // pto: %169
      ;
      pto::Stride<524288, 524288, 524288, 32768, 1> v447 = pto::Stride<524288, 524288, 524288, 32768, 1>();
      // pto: %169
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND> v448 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND>(v443 + (v444 + v402 * v445 + v442), v446, v447);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      TSTORE(v448, v437);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    };
  }
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %170
  int64_t v449 = (int64_t) ((uint64_t) v36 - (uint64_t) v79);
  // pto: %171, %172
  int64_t v450 = (int64_t) ((uint64_t) v32 + (uint64_t) v86) / v79;
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  for (int64_t v451 = v291; v451 < v450; v451 += v81) {
    // pto: %173
    ;
    int64_t v452 = (int64_t) ((uint64_t) v451 * (uint64_t) v79);
    // pto: %rms_lanes_inline452__ci_tmp_v0
    ;
    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v453 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v87);
    // pto: %rms_lanes_inline452__ci_tmp_v0
    ;
    uint64_t v454 = (uint64_t) v47;
    TASSIGN(v453, v454);
    // pto: %rms_lanes_inline452__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v455 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_lanes_inline452__tile
    ;
    uint64_t v456 = (uint64_t) v48;
    TASSIGN(v455, v456);
    // pto: %ci_tmp_view
    ;
    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v457;
    TRESHAPE(v457, v453);
    // pto: %ci_dst_view
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v458;
    TRESHAPE(v458, v455);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    TCI<Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v458, v88, v457);
    // pto: %rms_rows_inline458__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v459 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_rows_inline458__tile
    ;
    uint64_t v460 = (uint64_t) v47;
    TASSIGN(v459, v460);
    // pto: %174
    ;
    int32_t v461 = (int32_t) v452;
    pipe_barrier(PIPE_V);
    TADDS(v459, v455, v461);
    // pto: %rms_local_inline461__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v462 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_local_inline461__tile
    ;
    uint64_t v463 = (uint64_t) v48;
    TASSIGN(v462, v463);
    // pto: %175
    ;
    int64_t v464 = v452 % v71;
    // pto: %176, %177, %178
    ;
    int64_t v465 = v464 < v82 ? (int64_t) ((uint64_t) v464 + (uint64_t) v71) : v464;
    // pto: %179
    ;
    int32_t v466 = (int32_t) v465;
    pipe_barrier(PIPE_V);
    TADDS(v462, v455, v466);
    // pto: %5
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v467 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %5
    ;
    uint64_t v468 = (uint64_t) v47;
    TASSIGN(v467, v468);
    TMULS(v467, v459, v89);
    // pto: %rms_index_inline454__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v469 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_index_inline454__tile
    ;
    uint64_t v470 = (uint64_t) v47;
    TASSIGN(v469, v470);
    pipe_barrier(PIPE_V);
    TADD(v469, v467, v462);
    set_flag(PIPE_V, PIPE_S, EVENT_ID1);
    // pto: %rms_total_inline457__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v471 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_total_inline457__tile
    ;
    uint64_t v472 = (uint64_t) v48;
    TASSIGN(v471, v472);
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    const int64_t v473 = 0;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    __gm__ float* v474 = PTOAS__GLOBAL_TENSOR_DATA(v154);
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    const int64_t v475 = 1;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    const int64_t v476 = 1;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    const int64_t v477 = 1;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    int64_t v478 = (int64_t) v33;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    int64_t v479 = v478 * v71;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    int64_t v480 = v477 * v479;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 16> v481 = pto::Shape<1, 1, 1, -1, 16>(v475, v476, v477, v478, v71);
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v482 = pto::Stride<-1, -1, -1, -1, -1>(v476 * v480, v480, v479, v71, v70);
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v483 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v474 + (v473 + v82 * v71 + v82 * v70), v481, v482);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID1);
    MGATHER<pto::Coalesce::Elem>(v471, v483, v469);
    set_flag(PIPE_S, PIPE_V, EVENT_ID4);
    for (int64_t v484 = v70; v484 < v90; v484 += v70) {
      // pto: %rms_part_index_inline455__tile
      ;
      Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v485 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %rms_part_index_inline455__tile
      ;
      uint64_t v486 = (uint64_t) v45;
      TASSIGN(v485, v486);
      // pto: %180, %181, %182
      ;
      int32_t v487 = (int32_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v484 * (uint64_t) v449) * (uint64_t) v71);
      pipe_barrier(PIPE_V);
      TADDS(v485, v469, v487);
      set_flag(PIPE_V, PIPE_S, EVENT_ID2);
      // pto: %rms_value_inline462__tile
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v488 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %rms_value_inline462__tile
      ;
      uint64_t v489 = (uint64_t) v46;
      TASSIGN(v488, v489);
      wait_flag(PIPE_V, PIPE_S, EVENT_ID2);
      MGATHER<pto::Coalesce::Elem>(v488, v483, v485);
      set_flag(PIPE_S, PIPE_V, EVENT_ID3);
      // pto: %6
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v490 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %6
      ;
      uint64_t v491 = (uint64_t) v48;
      TASSIGN(v490, v491);
      wait_flag(PIPE_S, PIPE_V, EVENT_ID3);
      TADD(v490, v471, v488);
    };
    // pto: %7
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v492 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %7
    ;
    uint64_t v493 = (uint64_t) v47;
    TASSIGN(v492, v493);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID4);
    TMULS(v492, v471, v91);
    // pto: %rms_variance_inline448__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v494 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_variance_inline448__tile
    ;
    uint64_t v495 = (uint64_t) v47;
    TASSIGN(v494, v495);
    pipe_barrier(PIPE_V);
    TADDS(v494, v492, v92);
    // pto: %rms_root_inline460__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v496 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_root_inline460__tile
    ;
    uint64_t v497 = (uint64_t) v47;
    TASSIGN(v496, v497);
    pipe_barrier(PIPE_V);
    TSQRT(v496, v494);
    // pto: %8
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v498 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %8
    ;
    uint64_t v499 = (uint64_t) v48;
    TASSIGN(v498, v499);
    TEXPANDS(v498, v93);
    // pto: %native_inverse_inline447__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v500 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %native_inverse_inline447__tile
    ;
    uint64_t v501 = (uint64_t) v47;
    TASSIGN(v500, v501);
    pipe_barrier(PIPE_V);
    TDIV(v500, v498, v496);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
    // pto: %184
    ;
    int64_t v502 = v452 < v82 ? v82 : v452;
    // pto: %vec_ws__iter_v1_pview
    ;
    __gm__ float* v503 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %vec_ws__iter_v1_pview
    ;
    const int64_t v504 = 40;
    // pto: %vec_ws__iter_v1_pview
    ;
    const int64_t v505 = 64;
    // pto: %vec_ws__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v506 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %vec_ws__iter_v1_pview
    ;
    pto::Stride<64, 64, 64, 64, 1> v507 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %vec_ws__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v508 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v503 + (v504 + v502 * v505), v506, v507);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
    TSTORE(v508, v500);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %186
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  for (int64_t v509 = v291; v509 < (v449 / v71); v509 += v81) {
    // pto: %187
    ;
    int64_t v510 = (int64_t) ((uint64_t) v509 * (uint64_t) v71);
    // pto: %mixes_total_inline466__tile
    ;
    Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v511 = Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v73);
    // pto: %mixes_total_inline466__tile
    ;
    uint64_t v512 = (uint64_t) v47;
    TASSIGN(v511, v512);
    // pto: %188
    ;
    int64_t v513 = v510 < v82 ? v82 : v510;
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    __gm__ float* v514 = PTOAS__GLOBAL_TENSOR_DATA(v172);
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    const int64_t v515 = 0;
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    const int64_t v516 = 32;
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 16, 32> v517 = pto::Shape<1, 1, 1, 16, 32>();
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    pto::Stride<512, 512, 512, 32, 1> v518 = pto::Stride<512, 512, 512, 32, 1>();
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND> v519 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND>(v514 + (v515 + v513 * v516), v517, v518);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
    TLOAD(v511, v519);
    set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    for (int64_t v520 = v70; v520 < v90; v520 += v70) {
      // pto: %189, %190
      ;
      int64_t v521 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v520 * (uint64_t) v449) + (uint64_t) v510);
      // pto: %partial_tile_inline463__tile
      ;
      Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v522 = Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v73);
      // pto: %partial_tile_inline463__tile
      ;
      uint64_t v523 = (uint64_t) v48;
      TASSIGN(v522, v523);
      // pto: %191
      ;
      int64_t v524 = v521 < v82 ? v82 : v521;
      // pto: %192
      ;
      __gm__ float* v525 = PTOAS__GLOBAL_TENSOR_DATA(v172);
      // pto: %192
      ;
      const int64_t v526 = 0;
      // pto: %192
      ;
      const int64_t v527 = 32;
      // pto: %192
      ;
      pto::Shape<1, 1, 1, 16, 32> v528 = pto::Shape<1, 1, 1, 16, 32>();
      // pto: %192
      ;
      pto::Stride<512, 512, 512, 32, 1> v529 = pto::Stride<512, 512, 512, 32, 1>();
      // pto: %192
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND> v530 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND>(v525 + (v526 + v524 * v527), v528, v529);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      TLOAD(v522, v530);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      // pto: %9
      ;
      Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v531 = Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v73);
      // pto: %9
      ;
      uint64_t v532 = (uint64_t) v47;
      TASSIGN(v531, v532);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      TADD(v531, v511, v522);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    };
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    __gm__ float* v533 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    const int64_t v534 = 0;
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    const int64_t v535 = 64;
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 32> v536 = pto::Shape<1, 1, 1, 16, 32>();
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    pto::Stride<1024, 1024, 1024, 64, 1> v537 = pto::Stride<1024, 1024, 1024, 64, 1>();
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<1024, 1024, 1024, 64, 1>, pto::Layout::ND> v538 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<1024, 1024, 1024, 64, 1>, pto::Layout::ND>(v533 + (v534 + v513 * v535), v536, v537);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
    wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    TSTORE(v538, v511);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %scale0_inline476__tile
  float v539 = (v18)[v82];
  // pto: %scale1_inline478__tile
  float v540 = (v18)[v70];
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  for (int64_t v541 = v291; v541 < v450; v541 += v81) {
    // pto: %196
    ;
    int64_t v542 = (int64_t) ((uint64_t) v541 * (uint64_t) v79);
    // pto: %197
    ;
    int64_t v543 = (int64_t) ((uint64_t) v32 - (uint64_t) v542);
    // pto: %198
    ;
    int64_t v544 = v543 < v79 ? v543 : v79;
    // pto: %t__tmp_v10
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v545 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %t__tmp_v10
    ;
    uint64_t v546 = (uint64_t) v45;
    TASSIGN(v545, v546);
    // pto: %199
    ;
    int64_t v547 = v542 < v82 ? v82 : v542;
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    __gm__ float* v548 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    const int64_t v549 = 40;
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    const int64_t v550 = 64;
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v551 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    pto::Stride<64, 64, 64, 64, 1> v552 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v553 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v548 + (v549 + v547 * v550), v551, v552);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    TLOAD(v545, v553);
    // pto: %inv_col_inline483__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v554 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %inv_col_inline483__ssa_v0
    ;
    uint64_t v555 = (uint64_t) v45;
    TASSIGN(v554, v555);
    // pto: %t__tmp_v11
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v556 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %t__tmp_v11
    ;
    uint64_t v557 = (uint64_t) v46;
    TASSIGN(v556, v557);
    // pto: %hc_attn_base__ssa_v0_pview
    ;
    __gm__ float* v558 = PTOAS__GLOBAL_TENSOR_DATA(v182);
    // pto: %hc_attn_base__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v559 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %hc_attn_base__ssa_v0_pview
    ;
    pto::Stride<8, 8, 8, 8, 1> v560 = pto::Stride<8, 8, 8, 8, 1>();
    // pto: %hc_attn_base__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND> v561 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND>(v558, v559, v560);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    TLOAD(v556, v561);
    // pto: %pre_base_inline485__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v562 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %pre_base_inline485__ssa_v0
    ;
    uint64_t v563 = (uint64_t) v46;
    TASSIGN(v562, v563);
    // pto: %t__tmp_v12
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v564 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v12
    ;
    uint64_t v565 = (uint64_t) v47;
    TASSIGN(v564, v565);
    // pto: %201
    ;
    __gm__ float* v566 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %201
    ;
    const int64_t v567 = 0;
    // pto: %201
    ;
    const int64_t v568 = 64;
    // pto: %201
    ;
    pto::Shape<1, 1, 1, 8, 8> v569 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %201
    ;
    pto::Stride<512, 512, 512, 64, 1> v570 = pto::Stride<512, 512, 512, 64, 1>();
    // pto: %201
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v571 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v566 + (v567 + v547 * v568), v569, v570);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    TLOAD(v564, v571);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    // pto: %t__tmp_v13
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v572 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v13
    ;
    uint64_t v573 = (uint64_t) v47;
    TASSIGN(v572, v573);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    TROWEXPANDMUL(v572, v564, v554);
    // pto: %pre_scaled_inline486__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v574 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %pre_scaled_inline486__ssa_v0
    ;
    uint64_t v575 = (uint64_t) v47;
    TASSIGN(v574, v575);
    pipe_barrier(PIPE_V);
    TMULS(v574, v572, v539);
    // pto: %t__tmp_v14
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v576 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v14
    ;
    uint64_t v577 = (uint64_t) v48;
    TASSIGN(v576, v577);
    TCOLEXPAND(v576, v562);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %pre_logits_inline479__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v578 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %pre_logits_inline479__ssa_v0
    ;
    uint64_t v579 = (uint64_t) v47;
    TASSIGN(v578, v579);
    pipe_barrier(PIPE_V);
    TADD(v578, v574, v576);
    // pto: %t__tmp_v15
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v580 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v15
    ;
    uint64_t v581 = (uint64_t) v48;
    TASSIGN(v580, v581);
    pipe_barrier(PIPE_V);
    TEXPANDS(v580, v93);
    // pto: %t__tmp_v16
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v582 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v16
    ;
    uint64_t v583 = (uint64_t) v47;
    TASSIGN(v582, v583);
    TNEG(v582, v578);
    // pto: %t__tmp_v17
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v584 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v17
    ;
    uint64_t v585 = (uint64_t) v47;
    TASSIGN(v584, v585);
    pipe_barrier(PIPE_V);
    TEXP(v584, v582);
    // pto: %t__tmp_v18
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v586 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v18
    ;
    uint64_t v587 = (uint64_t) v47;
    TASSIGN(v586, v587);
    pipe_barrier(PIPE_V);
    TADDS(v586, v584, v93);
    // pto: %pre_sig_inline480__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v588 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %pre_sig_inline480__ssa_v0
    ;
    uint64_t v589 = (uint64_t) v47;
    TASSIGN(v588, v589);
    pipe_barrier(PIPE_V);
    TDIV(v588, v580, v586);
    // pto: %pre_val_inline488__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v590 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %pre_val_inline488__ssa_v0
    ;
    uint64_t v591 = (uint64_t) v47;
    TASSIGN(v590, v591);
    pipe_barrier(PIPE_V);
    TADDS(v590, v588, v92);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
    // pto: %203
    ;
    __gm__ float* v592 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %203
    ;
    const int64_t v593 = 32;
    // pto: %203
    ;
    const int64_t v594 = 64;
    // pto: %203
    ;
    pto::Shape<1, 1, 1, 8, 8> v595 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %203
    ;
    pto::Stride<512, 512, 512, 64, 1> v596 = pto::Stride<512, 512, 512, 64, 1>();
    // pto: %203
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v597 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v592 + (v593 + v547 * v594), v595, v596);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
    TSTORE(v597, v590);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    // pto: %t__tmp_v19
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v598 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %t__tmp_v19
    ;
    uint64_t v599 = (uint64_t) v46;
    TASSIGN(v598, v599);
    // pto: %204
    ;
    __gm__ float* v600 = PTOAS__GLOBAL_TENSOR_DATA(v182);
    // pto: %204
    ;
    unsigned v601 = 4;
    // pto: %204
    ;
    pto::Shape<1, 1, 1, 1, 8> v602 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %204
    ;
    pto::Stride<8, 8, 8, 8, 1> v603 = pto::Stride<8, 8, 8, 8, 1>();
    // pto: %204
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND> v604 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND>(v600 + v601, v602, v603);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v598, v604);
    // pto: %post_base_inline473__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v605 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %post_base_inline473__ssa_v0
    ;
    uint64_t v606 = (uint64_t) v46;
    TASSIGN(v605, v606);
    // pto: %t__tmp_v20
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v607 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v20
    ;
    uint64_t v608 = (uint64_t) v47;
    TASSIGN(v607, v608);
    // pto: %206
    ;
    __gm__ float* v609 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %206
    ;
    const int64_t v610 = 4;
    // pto: %206
    ;
    const int64_t v611 = 64;
    // pto: %206
    ;
    pto::Shape<1, 1, 1, 8, 8> v612 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %206
    ;
    pto::Stride<512, 512, 512, 64, 1> v613 = pto::Stride<512, 512, 512, 64, 1>();
    // pto: %206
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v614 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v609 + (v610 + v547 * v611), v612, v613);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    TLOAD(v607, v614);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
    // pto: %t__tmp_v21
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v615 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v21
    ;
    uint64_t v616 = (uint64_t) v47;
    TASSIGN(v615, v616);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
    TROWEXPANDMUL(v615, v607, v554);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    // pto: %post_scaled_inline475__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v617 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %post_scaled_inline475__ssa_v0
    ;
    uint64_t v618 = (uint64_t) v47;
    TASSIGN(v617, v618);
    pipe_barrier(PIPE_V);
    TMULS(v617, v615, v540);
    // pto: %t__tmp_v22
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v619 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v22
    ;
    uint64_t v620 = (uint64_t) v48;
    TASSIGN(v619, v620);
    TCOLEXPAND(v619, v605);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    // pto: %post_logits_inline472__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v621 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %post_logits_inline472__ssa_v0
    ;
    uint64_t v622 = (uint64_t) v47;
    TASSIGN(v621, v622);
    pipe_barrier(PIPE_V);
    TADD(v621, v617, v619);
    // pto: %t__tmp_v23
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v623 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v23
    ;
    uint64_t v624 = (uint64_t) v48;
    TASSIGN(v623, v624);
    pipe_barrier(PIPE_V);
    TEXPANDS(v623, v93);
    // pto: %t__tmp_v24
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v625 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v24
    ;
    uint64_t v626 = (uint64_t) v47;
    TASSIGN(v625, v626);
    TNEG(v625, v621);
    // pto: %t__tmp_v25
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v627 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v25
    ;
    uint64_t v628 = (uint64_t) v47;
    TASSIGN(v627, v628);
    pipe_barrier(PIPE_V);
    TEXP(v627, v625);
    // pto: %t__tmp_v26
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v629 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v26
    ;
    uint64_t v630 = (uint64_t) v47;
    TASSIGN(v629, v630);
    pipe_barrier(PIPE_V);
    TADDS(v629, v627, v93);
    // pto: %post_sig_inline470__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v631 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %post_sig_inline470__ssa_v0
    ;
    uint64_t v632 = (uint64_t) v47;
    TASSIGN(v631, v632);
    pipe_barrier(PIPE_V);
    TDIV(v631, v623, v629);
    // pto: %post_pad_inline484__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v633 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %post_pad_inline484__ssa_v0
    ;
    uint64_t v634 = (uint64_t) v47;
    TASSIGN(v633, v634);
    pipe_barrier(PIPE_V);
    TMULS(v633, v631, v94);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
    // pto: %207
    ;
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    if (v544 == v79) {
      // pto: %t__tmp_v27
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v635 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v77);
      // pto: %t__tmp_v27
      ;
      uint64_t v636 = (uint64_t) v47;
      TASSIGN(v635, v636);
      // pto: %208
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, 8, 4, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v637;
      // pto: %208
      ;
      uint64_t v638 = (uint64_t) v47;
      TASSIGN(v637, v638);
      // pto: %post__ssa_v0_pview
      ;
      __gm__ float* v639 = PTOAS__GLOBAL_TENSOR_DATA(v199);
      // pto: %post__ssa_v0_pview
      ;
      const int64_t v640 = 0;
      // pto: %post__ssa_v0_pview
      ;
      const int64_t v641 = 4;
      // pto: %post__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 4> v642 = pto::Shape<1, 1, 1, 8, 4>();
      // pto: %post__ssa_v0_pview
      ;
      pto::Stride<32, 32, 32, 4, 1> v643 = pto::Stride<32, 32, 32, 4, 1>();
      // pto: %post__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<32, 32, 32, 4, 1>, pto::Layout::ND> v644 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<32, 32, 32, 4, 1>, pto::Layout::ND>(v639 + (v640 + v547 * v641), v642, v643);
      TSTORE(v644, v637);
    } else {
      // pto: %211
      ;
      int64_t v645 = v449 < v82 ? v82 : v449;
      // pto: %212
      ;
      __gm__ float* v646 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %212
      ;
      const int64_t v647 = 0;
      // pto: %212
      ;
      const int64_t v648 = 64;
      // pto: %212
      ;
      pto::Shape<1, 1, 1, 8, 8> v649 = pto::Shape<1, 1, 1, 8, 8>();
      // pto: %212
      ;
      pto::Stride<512, 512, 512, 64, 1> v650 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %212
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v651 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v646 + (v647 + v645 * v648), v649, v650);
      TSTORE(v651, v633);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      // pto: %post_tile_inline471__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v652 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v544, v77);
      // pto: %post_tile_inline471__ssa_v0
      ;
      uint64_t v653 = (uint64_t) v47;
      TASSIGN(v652, v653);
      // pto: %215
      ;
      const int64_t v654 = 0;
      // pto: %215
      ;
      __gm__ float* v655 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %215
      ;
      const int64_t v656 = 1;
      // pto: %215
      ;
      const int64_t v657 = 1;
      // pto: %215
      ;
      const int64_t v658 = 1;
      // pto: %215
      ;
      int64_t v659 = v544 * v76;
      // pto: %215
      ;
      int64_t v660 = v658 * v659;
      // pto: %215
      ;
      pto::Shape<1, 1, 1, -1, 4> v661 = pto::Shape<1, 1, 1, -1, 4>(v656, v657, v658, v544, v77);
      // pto: %215
      ;
      pto::Stride<-1, -1, -1, -1, -1> v662 = pto::Stride<-1, -1, -1, -1, -1>(v657 * v660, v660, v659, v76, v70);
      // pto: %215
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v663 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v655 + (v654 + v645 * v76 + v82 * v70), v661, v662);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      TLOAD(v652, v663);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
      // pto: %217
      ;
      const int64_t v664 = 0;
      // pto: %217
      ;
      __gm__ float* v665 = PTOAS__GLOBAL_TENSOR_DATA(v199);
      // pto: %217
      ;
      const int64_t v666 = 1;
      // pto: %217
      ;
      const int64_t v667 = 1;
      // pto: %217
      ;
      const int64_t v668 = 1;
      // pto: %217
      ;
      int64_t v669 = v544 * v77;
      // pto: %217
      ;
      int64_t v670 = v668 * v669;
      // pto: %217
      ;
      pto::Shape<1, 1, 1, -1, 4> v671 = pto::Shape<1, 1, 1, -1, 4>(v666, v667, v668, v544, v77);
      // pto: %217
      ;
      pto::Stride<-1, -1, -1, -1, -1> v672 = pto::Stride<-1, -1, -1, -1, -1>(v667 * v670, v670, v669, v77, v70);
      // pto: %217
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v673 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v665 + (v664 + v547 * v77 + v82 * v70), v671, v672);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
      TSTORE(v673, v652);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v674 = v291; v674 < v450; v674 += v81) {
    // pto: %220
    ;
    int64_t v675 = (int64_t) ((uint64_t) v674 * (uint64_t) v79);
    // pto: %221
    ;
    int64_t v676 = (int64_t) ((uint64_t) v32 - (uint64_t) v675);
    // pto: %222
    ;
    int64_t v677 = v676 < v79 ? v676 : v79;
    // pto: %10
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v678 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %10
    ;
    uint64_t v679 = (uint64_t) v47;
    TASSIGN(v678, v679);
    // pto: %223
    ;
    int64_t v680 = v675 < v82 ? v82 : v675;
    // pto: %224
    ;
    __gm__ float* v681 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %224
    ;
    const int64_t v682 = 32;
    // pto: %224
    ;
    const int64_t v683 = 64;
    // pto: %224
    ;
    pto::Shape<1, 1, 1, 8, 8> v684 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %224
    ;
    pto::Stride<512, 512, 512, 64, 1> v685 = pto::Stride<512, 512, 512, 64, 1>();
    // pto: %224
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v686 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v681 + (v682 + v680 * v683), v684, v685);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v678, v686);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
    // pto: %11
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v687 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %11
    ;
    uint64_t v688 = (uint64_t) v48;
    TASSIGN(v687, v688);
    // pto: %pre_tile_t_inline506__tile
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v689 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %pre_tile_t_inline506__tile
    ;
    uint64_t v690 = (uint64_t) v49;
    TASSIGN(v689, v690);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
    TTRANS(v689, v678, v687);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    // pto: %12
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v691 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %12
    ;
    uint64_t v692 = (uint64_t) v49;
    TASSIGN(v691, v692);
    // pto: %pre0_inline508__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v693 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %pre0_inline508__tile
    ;
    uint64_t v694 = (uint64_t) v49;
    TASSIGN(v693, v694);
    // pto: %13
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v695 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %13
    ;
    uint64_t v696 = (uint64_t) v50;
    TASSIGN(v695, v696);
    // pto: %pre1_inline510__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v697 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %pre1_inline510__tile
    ;
    uint64_t v698 = (uint64_t) v50;
    TASSIGN(v697, v698);
    // pto: %14
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v699 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %14
    ;
    uint64_t v700 = (uint64_t) v51;
    TASSIGN(v699, v700);
    // pto: %pre2_inline504__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v701 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %pre2_inline504__tile
    ;
    uint64_t v702 = (uint64_t) v51;
    TASSIGN(v701, v702);
    // pto: %15
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v703 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %15
    ;
    uint64_t v704 = (uint64_t) v52;
    TASSIGN(v703, v704);
    // pto: %pre3_inline511__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v705 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %pre3_inline511__tile
    ;
    uint64_t v706 = (uint64_t) v52;
    TASSIGN(v705, v706);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    for (int64_t v707 = v82; v707 < v71; v707 += v80) {
      // pto: %229
      ;
      int64_t v708 = (int64_t) ((uint64_t) v707 * (uint64_t) v83);
      // pto: %232
      ;
      int64_t v709 = (int64_t) ((uint64_t) v708 + (uint64_t) v83);
      // pto: %x0_inline495__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v710 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %x0_inline495__tile
      ;
      uint64_t v711 = (uint64_t) v47;
      TASSIGN(v710, v711);
      // pto: %235
      ;
      int64_t v712 = v708 < v82 ? v82 : v708;
      // pto: %236
      ;
      const int64_t v713 = 0;
      // pto: %236
      ;
      __gm__ float* v714 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %236
      ;
      const int64_t v715 = 1;
      // pto: %236
      ;
      const int64_t v716 = 1;
      // pto: %236
      ;
      const int64_t v717 = 1;
      // pto: %236
      ;
      int64_t v718 = v677 * v69;
      // pto: %236
      ;
      int64_t v719 = v717 * v718;
      // pto: %236
      ;
      pto::Shape<1, 1, 1, -1, 256> v720 = pto::Shape<1, 1, 1, -1, 256>(v715, v716, v717, v677, v83);
      // pto: %236
      ;
      pto::Stride<-1, -1, -1, -1, -1> v721 = pto::Stride<-1, -1, -1, -1, -1>(v716 * v719, v719, v718, v69, v70);
      // pto: %236
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v722 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v714 + (v713 + v680 * v69 + v712 * v70), v720, v721);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      TLOAD(v710, v722);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %x1_inline493__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v723 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %x1_inline493__tile
      ;
      uint64_t v724 = (uint64_t) v48;
      TASSIGN(v723, v724);
      // pto: %238
      ;
      int64_t v725 = (int64_t) ((uint64_t) v708 + (uint64_t) v74);
      // pto: %239
      ;
      int64_t v726 = v725 < v82 ? v82 : v725;
      // pto: %240
      ;
      const int64_t v727 = 0;
      // pto: %240
      ;
      __gm__ float* v728 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %240
      ;
      const int64_t v729 = 1;
      // pto: %240
      ;
      const int64_t v730 = 1;
      // pto: %240
      ;
      const int64_t v731 = 1;
      // pto: %240
      ;
      int64_t v732 = v677 * v69;
      // pto: %240
      ;
      int64_t v733 = v731 * v732;
      // pto: %240
      ;
      pto::Shape<1, 1, 1, -1, 256> v734 = pto::Shape<1, 1, 1, -1, 256>(v729, v730, v731, v677, v83);
      // pto: %240
      ;
      pto::Stride<-1, -1, -1, -1, -1> v735 = pto::Stride<-1, -1, -1, -1, -1>(v730 * v733, v733, v732, v69, v70);
      // pto: %240
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v736 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v728 + (v727 + v680 * v69 + v726 * v70), v734, v735);
      TLOAD(v723, v736);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %x2_inline496__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v737 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %x2_inline496__tile
      ;
      uint64_t v738 = (uint64_t) v45;
      TASSIGN(v737, v738);
      // pto: %242
      ;
      int64_t v739 = (int64_t) ((uint64_t) v708 + (uint64_t) v95);
      // pto: %243
      ;
      int64_t v740 = v739 < v82 ? v82 : v739;
      // pto: %244
      ;
      const int64_t v741 = 0;
      // pto: %244
      ;
      __gm__ float* v742 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %244
      ;
      const int64_t v743 = 1;
      // pto: %244
      ;
      const int64_t v744 = 1;
      // pto: %244
      ;
      const int64_t v745 = 1;
      // pto: %244
      ;
      int64_t v746 = v677 * v69;
      // pto: %244
      ;
      int64_t v747 = v745 * v746;
      // pto: %244
      ;
      pto::Shape<1, 1, 1, -1, 256> v748 = pto::Shape<1, 1, 1, -1, 256>(v743, v744, v745, v677, v83);
      // pto: %244
      ;
      pto::Stride<-1, -1, -1, -1, -1> v749 = pto::Stride<-1, -1, -1, -1, -1>(v744 * v747, v747, v746, v69, v70);
      // pto: %244
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v750 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v742 + (v741 + v680 * v69 + v740 * v70), v748, v749);
      TLOAD(v737, v750);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %x3_inline502__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v751 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %x3_inline502__tile
      ;
      uint64_t v752 = (uint64_t) v46;
      TASSIGN(v751, v752);
      // pto: %246
      ;
      int64_t v753 = (int64_t) ((uint64_t) v708 + (uint64_t) v96);
      // pto: %247
      ;
      int64_t v754 = v753 < v82 ? v82 : v753;
      // pto: %248
      ;
      const int64_t v755 = 0;
      // pto: %248
      ;
      __gm__ float* v756 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %248
      ;
      const int64_t v757 = 1;
      // pto: %248
      ;
      const int64_t v758 = 1;
      // pto: %248
      ;
      const int64_t v759 = 1;
      // pto: %248
      ;
      int64_t v760 = v677 * v69;
      // pto: %248
      ;
      int64_t v761 = v759 * v760;
      // pto: %248
      ;
      pto::Shape<1, 1, 1, -1, 256> v762 = pto::Shape<1, 1, 1, -1, 256>(v757, v758, v759, v677, v83);
      // pto: %248
      ;
      pto::Stride<-1, -1, -1, -1, -1> v763 = pto::Stride<-1, -1, -1, -1, -1>(v758 * v761, v761, v760, v69, v70);
      // pto: %248
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v764 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v756 + (v755 + v680 * v69 + v754 * v70), v762, v763);
      TLOAD(v751, v764);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %16
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v765 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %16
      ;
      uint64_t v766 = (uint64_t) v53;
      TASSIGN(v765, v766);
      // pto: %250
      ;
      int64_t v767 = v709 < v82 ? v82 : v709;
      // pto: %251
      ;
      const int64_t v768 = 0;
      // pto: %251
      ;
      __gm__ float* v769 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %251
      ;
      const int64_t v770 = 1;
      // pto: %251
      ;
      const int64_t v771 = 1;
      // pto: %251
      ;
      const int64_t v772 = 1;
      // pto: %251
      ;
      int64_t v773 = v677 * v69;
      // pto: %251
      ;
      int64_t v774 = v772 * v773;
      // pto: %251
      ;
      pto::Shape<1, 1, 1, -1, 256> v775 = pto::Shape<1, 1, 1, -1, 256>(v770, v771, v772, v677, v83);
      // pto: %251
      ;
      pto::Stride<-1, -1, -1, -1, -1> v776 = pto::Stride<-1, -1, -1, -1, -1>(v771 * v774, v774, v773, v69, v70);
      // pto: %251
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v777 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v769 + (v768 + v680 * v69 + v767 * v70), v775, v776);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      TLOAD(v765, v777);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      // pto: %17
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v778 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %17
      ;
      uint64_t v779 = (uint64_t) v54;
      TASSIGN(v778, v779);
      int64_t v780 = (int64_t) ((uint64_t) v708 + (uint64_t) v42);
      // pto: %254
      ;
      int64_t v781 = v780 < v82 ? v82 : v780;
      // pto: %255
      ;
      const int64_t v782 = 0;
      // pto: %255
      ;
      __gm__ float* v783 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %255
      ;
      const int64_t v784 = 1;
      // pto: %255
      ;
      const int64_t v785 = 1;
      // pto: %255
      ;
      const int64_t v786 = 1;
      // pto: %255
      ;
      int64_t v787 = v677 * v69;
      // pto: %255
      ;
      int64_t v788 = v786 * v787;
      // pto: %255
      ;
      pto::Shape<1, 1, 1, -1, 256> v789 = pto::Shape<1, 1, 1, -1, 256>(v784, v785, v786, v677, v83);
      // pto: %255
      ;
      pto::Stride<-1, -1, -1, -1, -1> v790 = pto::Stride<-1, -1, -1, -1, -1>(v785 * v788, v788, v787, v69, v70);
      // pto: %255
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v791 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v783 + (v782 + v680 * v69 + v781 * v70), v789, v790);
      TLOAD(v778, v791);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      // pto: %18
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v792 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %18
      ;
      uint64_t v793 = (uint64_t) v55;
      TASSIGN(v792, v793);
      int64_t v794 = (int64_t) ((uint64_t) v708 + (uint64_t) v41);
      // pto: %258
      ;
      int64_t v795 = v794 < v82 ? v82 : v794;
      // pto: %259
      ;
      const int64_t v796 = 0;
      // pto: %259
      ;
      __gm__ float* v797 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %259
      ;
      const int64_t v798 = 1;
      // pto: %259
      ;
      const int64_t v799 = 1;
      // pto: %259
      ;
      const int64_t v800 = 1;
      // pto: %259
      ;
      int64_t v801 = v677 * v69;
      // pto: %259
      ;
      int64_t v802 = v800 * v801;
      // pto: %259
      ;
      pto::Shape<1, 1, 1, -1, 256> v803 = pto::Shape<1, 1, 1, -1, 256>(v798, v799, v800, v677, v83);
      // pto: %259
      ;
      pto::Stride<-1, -1, -1, -1, -1> v804 = pto::Stride<-1, -1, -1, -1, -1>(v799 * v802, v802, v801, v69, v70);
      // pto: %259
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v805 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v797 + (v796 + v680 * v69 + v795 * v70), v803, v804);
      TLOAD(v792, v805);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
      // pto: %19
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v806 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %19
      ;
      uint64_t v807 = (uint64_t) v56;
      TASSIGN(v806, v807);
      int64_t v808 = (int64_t) ((uint64_t) v708 + (uint64_t) v40);
      // pto: %262
      ;
      int64_t v809 = v808 < v82 ? v82 : v808;
      // pto: %263
      ;
      const int64_t v810 = 0;
      // pto: %263
      ;
      __gm__ float* v811 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %263
      ;
      const int64_t v812 = 1;
      // pto: %263
      ;
      const int64_t v813 = 1;
      // pto: %263
      ;
      const int64_t v814 = 1;
      // pto: %263
      ;
      int64_t v815 = v677 * v69;
      // pto: %263
      ;
      int64_t v816 = v814 * v815;
      // pto: %263
      ;
      pto::Shape<1, 1, 1, -1, 256> v817 = pto::Shape<1, 1, 1, -1, 256>(v812, v813, v814, v677, v83);
      // pto: %263
      ;
      pto::Stride<-1, -1, -1, -1, -1> v818 = pto::Stride<-1, -1, -1, -1, -1>(v813 * v816, v816, v815, v69, v70);
      // pto: %263
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v819 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v811 + (v810 + v680 * v69 + v809 * v70), v817, v818);
      TLOAD(v806, v819);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
      // pto: %y0_inline494__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v820 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %y0_inline494__tile
      ;
      uint64_t v821 = (uint64_t) v47;
      TASSIGN(v820, v821);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      TROWEXPANDMUL(v820, v710, v693);
      // pto: %y1_inline499__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v822 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %y1_inline499__tile
      ;
      uint64_t v823 = (uint64_t) v48;
      TASSIGN(v822, v823);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      TROWEXPANDMUL(v822, v723, v697);
      // pto: %y2_inline491__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v824 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %y2_inline491__tile
      ;
      uint64_t v825 = (uint64_t) v45;
      TASSIGN(v824, v825);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      TROWEXPANDMUL(v824, v737, v701);
      // pto: %y3_inline490__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v826 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %y3_inline490__tile
      ;
      uint64_t v827 = (uint64_t) v46;
      TASSIGN(v826, v827);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      TROWEXPANDMUL(v826, v751, v705);
      // pto: %20
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v828 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %20
      ;
      uint64_t v829 = (uint64_t) v47;
      TASSIGN(v828, v829);
      pipe_barrier(PIPE_V);
      TADD(v828, v820, v822);
      // pto: %21
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v830 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %21
      ;
      uint64_t v831 = (uint64_t) v47;
      TASSIGN(v830, v831);
      pipe_barrier(PIPE_V);
      TADD(v830, v828, v824);
      // pto: %y_tile_inline492__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v832 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %y_tile_inline492__tile
      ;
      uint64_t v833 = (uint64_t) v47;
      TASSIGN(v832, v833);
      pipe_barrier(PIPE_V);
      TADD(v832, v830, v826);
      // pto: %y_bf16_inline498__tile
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v834 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %y_bf16_inline498__tile
      ;
      uint64_t v835 = (uint64_t) v47;
      TASSIGN(v834, v835);
      pipe_barrier(PIPE_V);
      RoundMode v836 = RoundMode::CAST_RINT;
      SaturationMode v837 = SaturationMode::ON;
      TCVT(v834, v832, v836, v837);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      // pto: %264
      ;
      bool v838 = v677 == v79;
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      if (v838) {
        // pto: %mixed__iter_v3_pview
        ;
        const int64_t v839 = 0;
        // pto: %mixed__iter_v3_pview
        ;
        __gm__ bfloat16_t* v840 = PTOAS__GLOBAL_TENSOR_DATA(v217);
        // pto: %mixed__iter_v3_pview
        ;
        const int64_t v841 = 1;
        // pto: %mixed__iter_v3_pview
        ;
        const int64_t v842 = 1;
        // pto: %mixed__iter_v3_pview
        ;
        const int64_t v843 = 1;
        // pto: %mixed__iter_v3_pview
        ;
        int64_t v844 = v677 * v74;
        // pto: %mixed__iter_v3_pview
        ;
        int64_t v845 = v843 * v844;
        // pto: %mixed__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v846 = pto::Shape<1, 1, 1, -1, 256>(v841, v842, v843, v677, v83);
        // pto: %mixed__iter_v3_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v847 = pto::Stride<-1, -1, -1, -1, -1>(v842 * v845, v845, v844, v74, v70);
        // pto: %mixed__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v848 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v840 + (v839 + v680 * v74 + v712 * v70), v846, v847);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v848, v834);
      } else {
        // pto: %mixed_tail__iter_v3_pview
        ;
        const int64_t v849 = 0;
        // pto: %mixed_tail__iter_v3_pview
        ;
        __gm__ bfloat16_t* v850 = PTOAS__GLOBAL_TENSOR_DATA(v225);
        // pto: %mixed_tail__iter_v3_pview
        ;
        const int64_t v851 = 1;
        // pto: %mixed_tail__iter_v3_pview
        ;
        const int64_t v852 = 1;
        // pto: %mixed_tail__iter_v3_pview
        ;
        const int64_t v853 = 1;
        // pto: %mixed_tail__iter_v3_pview
        ;
        int64_t v854 = v677 * v74;
        // pto: %mixed_tail__iter_v3_pview
        ;
        int64_t v855 = v853 * v854;
        // pto: %mixed_tail__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v856 = pto::Shape<1, 1, 1, -1, 256>(v851, v852, v853, v677, v83);
        // pto: %mixed_tail__iter_v3_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v857 = pto::Stride<-1, -1, -1, -1, -1>(v852 * v855, v855, v854, v74, v70);
        // pto: %mixed_tail__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v858 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v850 + (v849 + v82 * v74 + v712 * v70), v856, v857);
        TSTORE(v858, v834);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        // pto: %y_out_inline489__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v859 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
        // pto: %y_out_inline489__ssa_v0
        ;
        uint64_t v860 = (uint64_t) v47;
        TASSIGN(v859, v860);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        TLOAD(v859, v858);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
        // pto: %271
        ;
        const int64_t v861 = 0;
        // pto: %271
        ;
        __gm__ bfloat16_t* v862 = PTOAS__GLOBAL_TENSOR_DATA(v217);
        // pto: %271
        ;
        const int64_t v863 = 1;
        // pto: %271
        ;
        const int64_t v864 = 1;
        // pto: %271
        ;
        const int64_t v865 = 1;
        // pto: %271
        ;
        int64_t v866 = v677 * v74;
        // pto: %271
        ;
        int64_t v867 = v865 * v866;
        // pto: %271
        ;
        pto::Shape<1, 1, 1, -1, 256> v868 = pto::Shape<1, 1, 1, -1, 256>(v863, v864, v865, v677, v83);
        // pto: %271
        ;
        pto::Stride<-1, -1, -1, -1, -1> v869 = pto::Stride<-1, -1, -1, -1, -1>(v864 * v867, v867, v866, v74, v70);
        // pto: %271
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v870 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v862 + (v861 + v680 * v74 + v712 * v70), v868, v869);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
        TSTORE(v870, v859);
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      // pto: %22
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v871 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %22
      ;
      uint64_t v872 = (uint64_t) v53;
      TASSIGN(v871, v872);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      TROWEXPANDMUL(v871, v765, v693);
      // pto: %23
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v873 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %23
      ;
      uint64_t v874 = (uint64_t) v54;
      TASSIGN(v873, v874);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      TROWEXPANDMUL(v873, v778, v697);
      // pto: %24
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v875 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %24
      ;
      uint64_t v876 = (uint64_t) v55;
      TASSIGN(v875, v876);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
      TROWEXPANDMUL(v875, v792, v701);
      // pto: %25
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v877 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %25
      ;
      uint64_t v878 = (uint64_t) v56;
      TASSIGN(v877, v878);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
      TROWEXPANDMUL(v877, v806, v705);
      // pto: %26
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v879 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %26
      ;
      uint64_t v880 = (uint64_t) v53;
      TASSIGN(v879, v880);
      pipe_barrier(PIPE_V);
      TADD(v879, v871, v873);
      // pto: %27
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v881 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %27
      ;
      uint64_t v882 = (uint64_t) v53;
      TASSIGN(v881, v882);
      pipe_barrier(PIPE_V);
      TADD(v881, v879, v875);
      // pto: %28
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v883 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %28
      ;
      uint64_t v884 = (uint64_t) v53;
      TASSIGN(v883, v884);
      pipe_barrier(PIPE_V);
      TADD(v883, v881, v877);
      // pto: %29
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v885 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
      // pto: %29
      ;
      uint64_t v886 = (uint64_t) v53;
      TASSIGN(v885, v886);
      pipe_barrier(PIPE_V);
      RoundMode v887 = RoundMode::CAST_RINT;
      SaturationMode v888 = SaturationMode::ON;
      TCVT(v885, v883, v887, v888);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      if (v838) {
        // pto: %mixed__phi_v6_pview
        ;
        const int64_t v889 = 0;
        // pto: %mixed__phi_v6_pview
        ;
        __gm__ bfloat16_t* v890 = PTOAS__GLOBAL_TENSOR_DATA(v217);
        // pto: %mixed__phi_v6_pview
        ;
        const int64_t v891 = 1;
        // pto: %mixed__phi_v6_pview
        ;
        const int64_t v892 = 1;
        // pto: %mixed__phi_v6_pview
        ;
        const int64_t v893 = 1;
        // pto: %mixed__phi_v6_pview
        ;
        int64_t v894 = v677 * v74;
        // pto: %mixed__phi_v6_pview
        ;
        int64_t v895 = v893 * v894;
        // pto: %mixed__phi_v6_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v896 = pto::Shape<1, 1, 1, -1, 256>(v891, v892, v893, v677, v83);
        // pto: %mixed__phi_v6_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v897 = pto::Stride<-1, -1, -1, -1, -1>(v892 * v895, v895, v894, v74, v70);
        // pto: %mixed__phi_v6_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v898 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v890 + (v889 + v680 * v74 + v767 * v70), v896, v897);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v898, v885);
      } else {
        // pto: %mixed_tail__phi_v6_pview
        ;
        const int64_t v899 = 0;
        // pto: %mixed_tail__phi_v6_pview
        ;
        __gm__ bfloat16_t* v900 = PTOAS__GLOBAL_TENSOR_DATA(v225);
        // pto: %mixed_tail__phi_v6_pview
        ;
        const int64_t v901 = 1;
        // pto: %mixed_tail__phi_v6_pview
        ;
        const int64_t v902 = 1;
        // pto: %mixed_tail__phi_v6_pview
        ;
        const int64_t v903 = 1;
        // pto: %mixed_tail__phi_v6_pview
        ;
        int64_t v904 = v677 * v74;
        // pto: %mixed_tail__phi_v6_pview
        ;
        int64_t v905 = v903 * v904;
        // pto: %mixed_tail__phi_v6_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v906 = pto::Shape<1, 1, 1, -1, 256>(v901, v902, v903, v677, v83);
        // pto: %mixed_tail__phi_v6_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v907 = pto::Stride<-1, -1, -1, -1, -1>(v902 * v905, v905, v904, v74, v70);
        // pto: %mixed_tail__phi_v6_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v908 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v900 + (v899 + v82 * v74 + v767 * v70), v906, v907);
        TSTORE(v908, v885);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        // pto: %30
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v909 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v677, v83);
        // pto: %30
        ;
        uint64_t v910 = (uint64_t) v53;
        TASSIGN(v909, v910);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        TLOAD(v909, v908);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID3);
        // pto: %282
        ;
        const int64_t v911 = 0;
        // pto: %282
        ;
        __gm__ bfloat16_t* v912 = PTOAS__GLOBAL_TENSOR_DATA(v217);
        // pto: %282
        ;
        const int64_t v913 = 1;
        // pto: %282
        ;
        const int64_t v914 = 1;
        // pto: %282
        ;
        const int64_t v915 = 1;
        // pto: %282
        ;
        int64_t v916 = v677 * v74;
        // pto: %282
        ;
        int64_t v917 = v915 * v916;
        // pto: %282
        ;
        pto::Shape<1, 1, 1, -1, 256> v918 = pto::Shape<1, 1, 1, -1, 256>(v913, v914, v915, v677, v83);
        // pto: %282
        ;
        pto::Stride<-1, -1, -1, -1, -1> v919 = pto::Stride<-1, -1, -1, -1, -1>(v914 * v917, v917, v916, v74, v70);
        // pto: %282
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v920 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v912 + (v911 + v680 * v74 + v767 * v70), v918, v919);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID3);
        TSTORE(v920, v909);
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    };
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v921 = v291; v921 < v32; v921 += v81) {
    // pto: %raw_inline539__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v922 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %raw_inline539__ssa_v0
    ;
    uint64_t v923 = (uint64_t) v48;
    TASSIGN(v922, v923);
    // pto: %283
    ;
    int64_t v924 = v921 < v82 ? v82 : v921;
    // pto: %mixed__ssa_v7_pview
    ;
    __gm__ bfloat16_t* v925 = PTOAS__GLOBAL_TENSOR_DATA(v217);
    // pto: %mixed__ssa_v7_pview
    ;
    const int64_t v926 = 0;
    // pto: %mixed__ssa_v7_pview
    ;
    const int64_t v927 = 4096;
    // pto: %mixed__ssa_v7_pview
    ;
    pto::Shape<1, 1, 1, 1, 4096> v928 = pto::Shape<1, 1, 1, 1, 4096>();
    // pto: %mixed__ssa_v7_pview
    ;
    pto::Stride<4096, 4096, 4096, 4096, 1> v929 = pto::Stride<4096, 4096, 4096, 4096, 1>();
    // pto: %mixed__ssa_v7_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v930 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v925 + (v926 + v924 * v927), v928, v929);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v922, v930);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %wide_inline533__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v931 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %wide_inline533__ssa_v0
    ;
    uint64_t v932 = (uint64_t) v47;
    TASSIGN(v931, v932);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
    RoundMode v933 = RoundMode::CAST_ROUND;
    SaturationMode v934 = SaturationMode::ON;
    TCVT(v931, v922, v933, v934);
    // pto: %square_inline536__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v935 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %square_inline536__ssa_v0
    ;
    uint64_t v936 = (uint64_t) v48;
    TASSIGN(v935, v936);
    pipe_barrier(PIPE_V);
    TMUL(v935, v931, v931);
    // pto: %t__tmp_v37
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v937 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v97);
    // pto: %t__tmp_v37
    ;
    uint64_t v938 = (uint64_t) v48;
    TASSIGN(v937, v938);
    // pto: %284
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v939;
    // pto: %284
    ;
    uint64_t v940 = (uint64_t) v48;
    TASSIGN(v939, v940);
    // pto: %t__tmp_v38
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v941 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v97);
    // pto: %t__tmp_v38
    ;
    uint64_t v942 = (uint64_t) v57;
    TASSIGN(v941, v942);
    // pto: %285
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v943;
    // pto: %285
    ;
    uint64_t v944 = (uint64_t) v57;
    TASSIGN(v943, v944);
    // pto: %fold2048_inline546__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v945 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v97);
    // pto: %fold2048_inline546__ssa_v0
    ;
    uint64_t v946 = (uint64_t) v48;
    TASSIGN(v945, v946);
    pipe_barrier(PIPE_V);
    TADD(v945, v939, v943);
    // pto: %t__tmp_v39
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v947 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v98);
    // pto: %t__tmp_v39
    ;
    uint64_t v948 = (uint64_t) v48;
    TASSIGN(v947, v948);
    // pto: %286
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v949;
    // pto: %286
    ;
    uint64_t v950 = (uint64_t) v48;
    TASSIGN(v949, v950);
    // pto: %t__tmp_v40
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v951 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v98);
    // pto: %t__tmp_v40
    ;
    uint64_t v952 = (uint64_t) v58;
    TASSIGN(v951, v952);
    // pto: %287
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v953;
    // pto: %287
    ;
    uint64_t v954 = (uint64_t) v58;
    TASSIGN(v953, v954);
    // pto: %fold1024_inline540__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v955 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v98);
    // pto: %fold1024_inline540__ssa_v0
    ;
    uint64_t v956 = (uint64_t) v48;
    TASSIGN(v955, v956);
    pipe_barrier(PIPE_V);
    TADD(v955, v949, v953);
    // pto: %t__tmp_v41
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v957 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
    // pto: %t__tmp_v41
    ;
    uint64_t v958 = (uint64_t) v48;
    TASSIGN(v957, v958);
    // pto: %288
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v959;
    // pto: %288
    ;
    uint64_t v960 = (uint64_t) v48;
    TASSIGN(v959, v960);
    // pto: %t__tmp_v42
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v961 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
    // pto: %t__tmp_v42
    ;
    uint64_t v962 = (uint64_t) v59;
    TASSIGN(v961, v962);
    // pto: %289
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v963;
    // pto: %289
    ;
    uint64_t v964 = (uint64_t) v59;
    TASSIGN(v963, v964);
    // pto: %fold512_inline530__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v965 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
    // pto: %fold512_inline530__ssa_v0
    ;
    uint64_t v966 = (uint64_t) v48;
    TASSIGN(v965, v966);
    pipe_barrier(PIPE_V);
    TADD(v965, v959, v963);
    // pto: %t__tmp_v43
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v967 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
    // pto: %t__tmp_v43
    ;
    uint64_t v968 = (uint64_t) v48;
    TASSIGN(v967, v968);
    // pto: %290
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v969;
    // pto: %290
    ;
    uint64_t v970 = (uint64_t) v48;
    TASSIGN(v969, v970);
    // pto: %t__tmp_v44
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v971 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
    // pto: %t__tmp_v44
    ;
    uint64_t v972 = (uint64_t) v60;
    TASSIGN(v971, v972);
    // pto: %291
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v973;
    // pto: %291
    ;
    uint64_t v974 = (uint64_t) v60;
    TASSIGN(v973, v974);
    // pto: %fold256_inline524__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v975 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
    // pto: %fold256_inline524__ssa_v0
    ;
    uint64_t v976 = (uint64_t) v48;
    TASSIGN(v975, v976);
    pipe_barrier(PIPE_V);
    TADD(v975, v969, v973);
    // pto: %t__tmp_v45
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v977 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v99);
    // pto: %t__tmp_v45
    ;
    uint64_t v978 = (uint64_t) v48;
    TASSIGN(v977, v978);
    // pto: %292
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v979;
    // pto: %292
    ;
    uint64_t v980 = (uint64_t) v48;
    TASSIGN(v979, v980);
    // pto: %t__tmp_v46
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v981 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v99);
    // pto: %t__tmp_v46
    ;
    uint64_t v982 = (uint64_t) v61;
    TASSIGN(v981, v982);
    // pto: %293
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v983;
    // pto: %293
    ;
    uint64_t v984 = (uint64_t) v61;
    TASSIGN(v983, v984);
    // pto: %fold128_inline532__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v985 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v99);
    // pto: %fold128_inline532__ssa_v0
    ;
    uint64_t v986 = (uint64_t) v48;
    TASSIGN(v985, v986);
    pipe_barrier(PIPE_V);
    TADD(v985, v979, v983);
    // pto: %t__tmp_v47
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v987 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v76);
    // pto: %t__tmp_v47
    ;
    uint64_t v988 = (uint64_t) v48;
    TASSIGN(v987, v988);
    // pto: %294
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v989;
    // pto: %294
    ;
    uint64_t v990 = (uint64_t) v48;
    TASSIGN(v989, v990);
    // pto: %t__tmp_v48
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v991 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v76);
    // pto: %t__tmp_v48
    ;
    uint64_t v992 = (uint64_t) v62;
    TASSIGN(v991, v992);
    // pto: %295
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v993;
    // pto: %295
    ;
    uint64_t v994 = (uint64_t) v62;
    TASSIGN(v993, v994);
    // pto: %fold64_inline520__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v995 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v76);
    // pto: %fold64_inline520__ssa_v0
    ;
    uint64_t v996 = (uint64_t) v45;
    TASSIGN(v995, v996);
    pipe_barrier(PIPE_V);
    TADD(v995, v989, v993);
    // pto: %t__tmp_v49
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v997 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v76);
    // pto: %t__tmp_v49
    ;
    uint64_t v998 = (uint64_t) v48;
    TASSIGN(v997, v998);
    // pto: %repeated_inline531__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v999 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v76);
    // pto: %repeated_inline531__ssa_v0
    ;
    uint64_t v1000 = (uint64_t) v48;
    TASSIGN(v999, v1000);
    pipe_barrier(PIPE_V);
    TCOLEXPAND(v999, v995);
    // pto: %t__tmp_v50
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1001 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v76);
    // pto: %t__tmp_v50
    ;
    uint64_t v1002 = (uint64_t) v45;
    TASSIGN(v1001, v1002);
    // pto: %total_inline545__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1003 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %total_inline545__ssa_v0
    ;
    uint64_t v1004 = (uint64_t) v46;
    TASSIGN(v1003, v1004);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID5);
    TROWSUM(v1003, v999, v1001);
    set_flag(PIPE_V, PIPE_S, EVENT_ID3);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID3);
    // pto: %total_scalar_inline547__ssa_v0
    ;
    float v1005 = v1003.GetValue(v82);
    // pto: %31
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1006 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %31
    ;
    uint64_t v1007 = (uint64_t) v48;
    TASSIGN(v1006, v1007);
    pipe_barrier(PIPE_V);
    TEXPANDS(v1006, v93);
    // pto: %total_vector_inline522__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1008 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %total_vector_inline522__tile
    ;
    uint64_t v1009 = (uint64_t) v48;
    TASSIGN(v1008, v1009);
    pipe_barrier(PIPE_V);
    TMULS(v1008, v1006, v1005);
    // pto: %32
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1010 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %32
    ;
    uint64_t v1011 = (uint64_t) v48;
    TASSIGN(v1010, v1011);
    pipe_barrier(PIPE_V);
    TMULS(v1010, v1008, v100);
    // pto: %variance_inline535__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1012 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %variance_inline535__tile
    ;
    uint64_t v1013 = (uint64_t) v48;
    TASSIGN(v1012, v1013);
    pipe_barrier(PIPE_V);
    TADDS(v1012, v1010, v92);
    set_flag(PIPE_V, PIPE_S, EVENT_ID4);
    // pto: %root_value_inline550__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1014 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %root_value_inline550__tile
    ;
    uint64_t v1015 = (uint64_t) v45;
    TASSIGN(v1014, v1015);
    pipe_barrier(PIPE_V);
    TSQRT(v1014, v1012);
    set_flag(PIPE_V, PIPE_S, EVENT_ID5);
    // pto: %variance_bits_inline538__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1016 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %variance_bits_inline538__tile
    ;
    uint64_t v1017 = (uint64_t) v48;
    TASSIGN(v1016, v1017);
    // pto: %approx_bits_inline553__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1018 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %approx_bits_inline553__tile
    ;
    uint64_t v1019 = (uint64_t) v45;
    TASSIGN(v1018, v1019);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID4);
    // pto: %296
    ;
    int32_t v1020 = v1016.GetValue(v82);
    set_flag(PIPE_S, PIPE_V, EVENT_ID6);
    // pto: %297
    ;
    int64_t v1021 = (int64_t) v1020;
    wait_flag(PIPE_V, PIPE_S, EVENT_ID5);
    // pto: %298
    ;
    int32_t v1022 = v1018.GetValue(v82);
    set_flag(PIPE_S, PIPE_MTE2, EVENT_ID1);
    // pto: %299
    ;
    int64_t v1023 = (int64_t) v1022;
    // pto: %301, %302, %303
    ;
    // pto: %y_bits_inline548__phi_v7
    ;
    int64_t v1024;
    if ((int64_t) v1020 >= v101 & v1021 < v102) {
      // pto: %305
      ;
      int64_t v1025 = v1021 / v44;
      // pto: %307
      ;
      int64_t v1026 = v1021 % v44;
      // pto: %311, %308, %312, %313, %314
      ;
      int64_t v1027 = v1026 != v49 & v1026 < v49 ? (int64_t) ((uint64_t) v1026 + (uint64_t) v44) : v1026;
      // pto: %316
      ;
      int64_t v1028 = (int64_t) ((uint64_t) v1027 + (uint64_t) v44);
      // pto: %y_bits_inline548__rv_v2
      ;
      int64_t v1029;
      v1029 = v1023;
      for (int64_t v1030 = v82; v1030 < v80; v1030 += v70) {
        // pto: %318
        ;
        int64_t v1031 = v1029 / v44;
        // pto: %320
        ;
        int64_t v1032 = v1029 % v44;
        // pto: %324, %321, %325, %326, %327
        ;
        int64_t v1033 = v1032 != v49 & v1032 < v49 ? (int64_t) ((uint64_t) v1032 + (uint64_t) v44) : v1032;
        // pto: %329, %330, %332
        ;
        int64_t v1034 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v1033 + (uint64_t) v44) * (uint64_t) v103) + (uint64_t) v70);
        // pto: %333
        ;
        int64_t v1035 = (int64_t) ((uint64_t) v1034 * (uint64_t) v1034);
        // pto: %337, %335, %334, %336
        ;
        int64_t v1036 = (int64_t) ((uint64_t) v1028 << (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v1025 - (uint64_t) ((int64_t) (uint64_t) v1031 * (uint64_t) v103)) + (uint64_t) v104));
        // pto: %338
        ;
        uint64_t v1037 = (uint64_t) v1029;
        // pto: %338
        ;
        int64_t v1038 = (int64_t) (v1037 - (uint64_t) v105);
        // pto: %342
        ;
        int64_t v1039 = v1038 % v44;
        // pto: %346, %343, %347, %348, %349
        ;
        int64_t v1040 = v1039 != v49 & v1039 < v49 ? (int64_t) ((uint64_t) v1039 + (uint64_t) v44) : v1039;
        // pto: %351, %352, %354
        ;
        int64_t v1041 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v1040 + (uint64_t) v44) * (uint64_t) v103) + (uint64_t) v70);
        // pto: %355
        ;
        int64_t v1042 = (int64_t) ((uint64_t) v1041 * (uint64_t) v1041);
        // pto: %359, %357, %340, %356, %358
        ;
        int64_t v1043 = (int64_t) ((uint64_t) v1028 << (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v1025 - (uint64_t) ((int64_t) (uint64_t) (v1038 / v44) * (uint64_t) v103)) + (uint64_t) v104));
        // pto: %364
        ;
        int64_t v1044 = v1029 % v103;
        // pto: %365, %366, %367
        ;
        int64_t v1045 = v1044 < v49 ? (int64_t) ((uint64_t) v1044 + (uint64_t) v103) : v1044;
        // pto: %368
        ;
        bool v1046 = v1045 == v105;
        // pto: %361, %363, %369, %370
        ;
        // pto: %y_bits_inline548__phi_v6
        ;
        int64_t v1047;
        if (v1035 < v1036 | v1036 == v1035 & v1046) {
          // pto: %371
          ;
          uint64_t v1048 = (uint64_t) v1029;
          // pto: %371
          ;
          v1047 = (int64_t) (v1048 + (uint64_t) v105);
        } else {
          // pto: %373, %375, %381, %382, %y_bits_inline548__phi_v5
          ;
          int64_t v1049 = v1043 < v1042 | v1043 == v1042 & v1046 ? v1038 : v1029;
          v1047 = v1049;
        };
        v1029 = v1047;
      };
      v1024 = v1029;
    } else {
      v1024 = v1023;
    };
    // pto: %rounded_bits_inline534__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1050 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rounded_bits_inline534__tile
    ;
    uint64_t v1051 = (uint64_t) v48;
    TASSIGN(v1050, v1051);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID6);
    pipe_barrier(PIPE_V);
    TEXPANDS(v1050, v88);
    set_flag(PIPE_V, PIPE_S, EVENT_ID6);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID6);
    for (int64_t v1052 = v82; v1052 < v79; v1052 += v70) {
      // pto: %384
      ;
      int32_t v1053 = (int32_t) v1024;
      v1050.SetValue(v1052, v1053);
    };
    // pto: %rounded_root_inline516__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1054 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rounded_root_inline516__tile
    ;
    uint64_t v1055 = (uint64_t) v48;
    TASSIGN(v1054, v1055);
    // pto: %scalar_root_value_inline525__tile
    ;
    float v1056 = v1054.GetValue(v82);
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
    // pto: %387
    ;
    float v1057 = v93 / v1056;
    // pto: %33
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1058 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %33
    ;
    uint64_t v1059 = (uint64_t) v48;
    TASSIGN(v1058, v1059);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    TEXPANDS(v1058, v93);
    // pto: %inverse_inline515__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1060 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %inverse_inline515__tile
    ;
    uint64_t v1061 = (uint64_t) v46;
    TASSIGN(v1060, v1061);
    pipe_barrier(PIPE_V);
    TMULS(v1060, v1058, v1057);
    set_flag(PIPE_V, PIPE_S, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    __gm__ float* v1062 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    const int64_t v1063 = 48;
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    const int64_t v1064 = 64;
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v1065 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    pto::Stride<64, 64, 64, 64, 1> v1066 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v1067 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v1062 + (v1063 + v924 * v1064), v1065, v1066);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1067, v1060);
    // pto: %apply_value_inline523__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1068 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %apply_value_inline523__ssa_v0
    ;
    uint64_t v1069 = (uint64_t) v47;
    TASSIGN(v1068, v1069);
    // pto: %t__tmp_v56
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1070 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %t__tmp_v56
    ;
    uint64_t v1071 = (uint64_t) v45;
    TASSIGN(v1070, v1071);
    // pto: %attn_norm_w__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v1072 = PTOAS__GLOBAL_TENSOR_DATA(v235);
    // pto: %attn_norm_w__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 4096> v1073 = pto::Shape<1, 1, 1, 1, 4096>();
    // pto: %attn_norm_w__ssa_v0_pview
    ;
    pto::Stride<4096, 4096, 4096, 4096, 1> v1074 = pto::Stride<4096, 4096, 4096, 4096, 1>();
    // pto: %attn_norm_w__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v1075 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v1072, v1073, v1074);
    wait_flag(PIPE_S, PIPE_MTE2, EVENT_ID1);
    TLOAD(v1070, v1075);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %w_raw_inline528__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1076 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %w_raw_inline528__ssa_v0
    ;
    uint64_t v1077 = (uint64_t) v45;
    TASSIGN(v1076, v1077);
    // pto: %w_inline514__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1078 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %w_inline514__ssa_v0
    ;
    uint64_t v1079 = (uint64_t) v48;
    TASSIGN(v1078, v1079);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    pipe_barrier(PIPE_V);
    RoundMode v1080 = RoundMode::CAST_ROUND;
    SaturationMode v1081 = SaturationMode::ON;
    TCVT(v1078, v1076, v1080, v1081);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
    // pto: %inv_inline552__tile
    ;
    float v1082 = v1060.GetValue(v82);
    set_flag(PIPE_S, PIPE_V, EVENT_ID5);
    // pto: %scaled_inline513__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1083 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %scaled_inline513__ssa_v0
    ;
    uint64_t v1084 = (uint64_t) v47;
    TASSIGN(v1083, v1084);
    TMULS(v1083, v1068, v1082);
    // pto: %result_inline558__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1085 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %result_inline558__ssa_v0
    ;
    uint64_t v1086 = (uint64_t) v47;
    TASSIGN(v1085, v1086);
    pipe_barrier(PIPE_V);
    TCOLEXPANDMUL(v1085, v1083, v1078);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %t__tmp_v57
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1087 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %t__tmp_v57
    ;
    uint64_t v1088 = (uint64_t) v47;
    TASSIGN(v1087, v1088);
    pipe_barrier(PIPE_V);
    RoundMode v1089 = RoundMode::CAST_RINT;
    SaturationMode v1090 = SaturationMode::ON;
    TCVT(v1087, v1085, v1089, v1090);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %normed__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v1091 = PTOAS__GLOBAL_TENSOR_DATA(v136);
    // pto: %normed__ssa_v0_pview
    ;
    const int64_t v1092 = 0;
    // pto: %normed__ssa_v0_pview
    ;
    const int64_t v1093 = 4096;
    // pto: %normed__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 4096> v1094 = pto::Shape<1, 1, 1, 1, 4096>();
    // pto: %normed__ssa_v0_pview
    ;
    pto::Stride<4096, 4096, 4096, 4096, 1> v1095 = pto::Stride<4096, 4096, 4096, 4096, 1>();
    // pto: %normed__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v1096 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v1091 + (v1092 + v924 * v1093), v1094, v1095);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1096, v1087);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_S, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_S, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  for (int64_t v1097 = v291; v1097 < v450; v1097 += v81) {
    // pto: %scale2_inline602__tile
    ;
    float v1098 = (v18)[v80];
    // pto: %392
    ;
    int64_t v1099 = (int64_t) ((uint64_t) v1097 * (uint64_t) v79);
    // pto: %393
    ;
    int64_t v1100 = (int64_t) ((uint64_t) v32 - (uint64_t) v1099);
    // pto: %394
    ;
    int64_t v1101 = v1100 < v79 ? v1100 : v79;
    // pto: %t__tmp_v58
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1102 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %t__tmp_v58
    ;
    uint64_t v1103 = (uint64_t) v54;
    TASSIGN(v1102, v1103);
    // pto: %395
    ;
    int64_t v1104 = v1099 < v82 ? v82 : v1099;
    // pto: %vec_ws_v2__rv_v2_pview
    ;
    __gm__ float* v1105 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %vec_ws_v2__rv_v2_pview
    ;
    const int64_t v1106 = 40;
    // pto: %vec_ws_v2__rv_v2_pview
    ;
    const int64_t v1107 = 64;
    // pto: %vec_ws_v2__rv_v2_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v1108 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %vec_ws_v2__rv_v2_pview
    ;
    pto::Stride<64, 64, 64, 64, 1> v1109 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %vec_ws_v2__rv_v2_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v1110 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v1105 + (v1106 + v1104 * v1107), v1108, v1109);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v1102, v1110);
    // pto: %t__tmp_v59
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1111 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %t__tmp_v59
    ;
    uint64_t v1112 = (uint64_t) v54;
    TASSIGN(v1111, v1112);
    v1111.SetValidShape(v1101, v70);
    // pto: %mix_g0_inline604__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1113 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
    // pto: %mix_g0_inline604__ssa_v0
    ;
    uint64_t v1114 = (uint64_t) v47;
    TASSIGN(v1113, v1114);
    // pto: %398
    ;
    const int64_t v1115 = 0;
    // pto: %398
    ;
    __gm__ float* v1116 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %398
    ;
    const int64_t v1117 = 1;
    // pto: %398
    ;
    const int64_t v1118 = 1;
    // pto: %398
    ;
    const int64_t v1119 = 1;
    // pto: %398
    ;
    int64_t v1120 = v1101 * v76;
    // pto: %398
    ;
    int64_t v1121 = v1119 * v1120;
    // pto: %398
    ;
    pto::Shape<1, 1, 1, -1, 4> v1122 = pto::Shape<1, 1, 1, -1, 4>(v1117, v1118, v1119, v1101, v77);
    // pto: %398
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1123 = pto::Stride<-1, -1, -1, -1, -1>(v1118 * v1121, v1121, v1120, v76, v70);
    // pto: %398
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1124 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1116 + (v1115 + v1104 * v76 + v79 * v70), v1122, v1123);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    TLOAD(v1113, v1124);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %mix_g1_inline633__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1125 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
    // pto: %mix_g1_inline633__ssa_v0
    ;
    uint64_t v1126 = (uint64_t) v48;
    TASSIGN(v1125, v1126);
    // pto: %402
    ;
    const int64_t v1127 = 0;
    // pto: %402
    ;
    __gm__ float* v1128 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %402
    ;
    const int64_t v1129 = 1;
    // pto: %402
    ;
    const int64_t v1130 = 1;
    // pto: %402
    ;
    const int64_t v1131 = 1;
    // pto: %402
    ;
    int64_t v1132 = v1101 * v76;
    // pto: %402
    ;
    int64_t v1133 = v1131 * v1132;
    // pto: %402
    ;
    pto::Shape<1, 1, 1, -1, 4> v1134 = pto::Shape<1, 1, 1, -1, 4>(v1129, v1130, v1131, v1101, v77);
    // pto: %402
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1135 = pto::Stride<-1, -1, -1, -1, -1>(v1130 * v1133, v1133, v1132, v76, v70);
    // pto: %402
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1136 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1128 + (v1127 + v1104 * v76 + v106 * v70), v1134, v1135);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    TLOAD(v1125, v1136);
    // pto: %mix_g2_inline605__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1137 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
    // pto: %mix_g2_inline605__ssa_v0
    ;
    uint64_t v1138 = (uint64_t) v45;
    TASSIGN(v1137, v1138);
    // pto: %406
    ;
    const int64_t v1139 = 0;
    // pto: %406
    ;
    __gm__ float* v1140 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %406
    ;
    const int64_t v1141 = 1;
    // pto: %406
    ;
    const int64_t v1142 = 1;
    // pto: %406
    ;
    const int64_t v1143 = 1;
    // pto: %406
    ;
    int64_t v1144 = v1101 * v76;
    // pto: %406
    ;
    int64_t v1145 = v1143 * v1144;
    // pto: %406
    ;
    pto::Shape<1, 1, 1, -1, 4> v1146 = pto::Shape<1, 1, 1, -1, 4>(v1141, v1142, v1143, v1101, v77);
    // pto: %406
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1147 = pto::Stride<-1, -1, -1, -1, -1>(v1142 * v1145, v1145, v1144, v76, v70);
    // pto: %406
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1148 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1140 + (v1139 + v1104 * v76 + v71 * v70), v1146, v1147);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    TLOAD(v1137, v1148);
    // pto: %mix_g3_inline594__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1149 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
    // pto: %mix_g3_inline594__ssa_v0
    ;
    uint64_t v1150 = (uint64_t) v46;
    TASSIGN(v1149, v1150);
    // pto: %410
    ;
    const int64_t v1151 = 0;
    // pto: %410
    ;
    __gm__ float* v1152 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %410
    ;
    const int64_t v1153 = 1;
    // pto: %410
    ;
    const int64_t v1154 = 1;
    // pto: %410
    ;
    const int64_t v1155 = 1;
    // pto: %410
    ;
    int64_t v1156 = v1101 * v76;
    // pto: %410
    ;
    int64_t v1157 = v1155 * v1156;
    // pto: %410
    ;
    pto::Shape<1, 1, 1, -1, 4> v1158 = pto::Shape<1, 1, 1, -1, 4>(v1153, v1154, v1155, v1101, v77);
    // pto: %410
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1159 = pto::Stride<-1, -1, -1, -1, -1>(v1154 * v1157, v1157, v1156, v76, v70);
    // pto: %410
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1160 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1152 + (v1151 + v1104 * v76 + v43 * v70), v1158, v1159);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    TLOAD(v1149, v1160);
    // pto: %cb0_inline608__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1161 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v77);
    // pto: %cb0_inline608__ssa_v0
    ;
    uint64_t v1162 = (uint64_t) v55;
    TASSIGN(v1161, v1162);
    // pto: %hc_base_2d__ssa_v0_pview
    ;
    __gm__ float* v1163 = PTOAS__GLOBAL_TENSOR_DATA(v190);
    // pto: %hc_base_2d__ssa_v0_pview
    ;
    unsigned v1164 = 8;
    // pto: %hc_base_2d__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 4> v1165 = pto::Shape<1, 1, 1, 1, 4>();
    // pto: %hc_base_2d__ssa_v0_pview
    ;
    pto::Stride<24, 24, 24, 24, 1> v1166 = pto::Stride<24, 24, 24, 24, 1>();
    // pto: %hc_base_2d__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND> v1167 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND>(v1163 + v1164, v1165, v1166);
    TLOAD(v1161, v1167);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %cb1_inline618__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1168 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v77);
    // pto: %cb1_inline618__ssa_v0
    ;
    uint64_t v1169 = (uint64_t) v56;
    TASSIGN(v1168, v1169);
    // pto: %414
    ;
    __gm__ float* v1170 = PTOAS__GLOBAL_TENSOR_DATA(v190);
    // pto: %414
    ;
    unsigned v1171 = 12;
    // pto: %414
    ;
    pto::Shape<1, 1, 1, 1, 4> v1172 = pto::Shape<1, 1, 1, 1, 4>();
    // pto: %414
    ;
    pto::Stride<24, 24, 24, 24, 1> v1173 = pto::Stride<24, 24, 24, 24, 1>();
    // pto: %414
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND> v1174 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND>(v1170 + v1171, v1172, v1173);
    TLOAD(v1168, v1174);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    // pto: %cb2_inline610__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1175 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v77);
    // pto: %cb2_inline610__ssa_v0
    ;
    uint64_t v1176 = (uint64_t) v49;
    TASSIGN(v1175, v1176);
    // pto: %417
    ;
    __gm__ float* v1177 = PTOAS__GLOBAL_TENSOR_DATA(v190);
    // pto: %417
    ;
    unsigned v1178 = 16;
    // pto: %417
    ;
    pto::Shape<1, 1, 1, 1, 4> v1179 = pto::Shape<1, 1, 1, 1, 4>();
    // pto: %417
    ;
    pto::Stride<24, 24, 24, 24, 1> v1180 = pto::Stride<24, 24, 24, 24, 1>();
    // pto: %417
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND> v1181 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND>(v1177 + v1178, v1179, v1180);
    TLOAD(v1175, v1181);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    // pto: %cb3_inline596__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1182 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v77);
    // pto: %cb3_inline596__ssa_v0
    ;
    uint64_t v1183 = (uint64_t) v63;
    TASSIGN(v1182, v1183);
    // pto: %420
    ;
    __gm__ float* v1184 = PTOAS__GLOBAL_TENSOR_DATA(v190);
    // pto: %420
    ;
    unsigned v1185 = 20;
    // pto: %420
    ;
    pto::Shape<1, 1, 1, 1, 4> v1186 = pto::Shape<1, 1, 1, 1, 4>();
    // pto: %420
    ;
    pto::Stride<24, 24, 24, 24, 1> v1187 = pto::Stride<24, 24, 24, 24, 1>();
    // pto: %420
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND> v1188 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND>(v1184 + v1185, v1186, v1187);
    TLOAD(v1182, v1188);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    // pto: %t__tmp_v60
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1189 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
    // pto: %t__tmp_v60
    ;
    uint64_t v1190 = (uint64_t) v53;
    TASSIGN(v1189, v1190);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v1189, v1113, v1111);
    // pto: %t__tmp_v61
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1191 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
    // pto: %t__tmp_v61
    ;
    uint64_t v1192 = (uint64_t) v53;
    TASSIGN(v1191, v1192);
    pipe_barrier(PIPE_V);
    TMULS(v1191, v1189, v1098);
    // pto: %t__tmp_v62
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1193 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
    // pto: %t__tmp_v62
    ;
    uint64_t v1194 = (uint64_t) v47;
    TASSIGN(v1193, v1194);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    TCOLEXPAND(v1193, v1161);
    // pto: %row0_inline625__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1195 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
    // pto: %row0_inline625__ssa_v0
    ;
    uint64_t v1196 = (uint64_t) v47;
    TASSIGN(v1195, v1196);
    pipe_barrier(PIPE_V);
    TADD(v1195, v1191, v1193);
    // pto: %t__tmp_v63
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1197 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
    // pto: %t__tmp_v63
    ;
    uint64_t v1198 = (uint64_t) v53;
    TASSIGN(v1197, v1198);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v1197, v1125, v1111);
    // pto: %t__tmp_v64
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1199 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
    // pto: %t__tmp_v64
    ;
    uint64_t v1200 = (uint64_t) v53;
    TASSIGN(v1199, v1200);
    pipe_barrier(PIPE_V);
    TMULS(v1199, v1197, v1098);
    // pto: %t__tmp_v65
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1201 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
    // pto: %t__tmp_v65
    ;
    uint64_t v1202 = (uint64_t) v48;
    TASSIGN(v1201, v1202);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    TCOLEXPAND(v1201, v1168);
    // pto: %row1_inline589__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1203 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
    // pto: %row1_inline589__ssa_v0
    ;
    uint64_t v1204 = (uint64_t) v48;
    TASSIGN(v1203, v1204);
    pipe_barrier(PIPE_V);
    TADD(v1203, v1199, v1201);
    // pto: %t__tmp_v66
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1205 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
    // pto: %t__tmp_v66
    ;
    uint64_t v1206 = (uint64_t) v53;
    TASSIGN(v1205, v1206);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v1205, v1137, v1111);
    // pto: %t__tmp_v67
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1207 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
    // pto: %t__tmp_v67
    ;
    uint64_t v1208 = (uint64_t) v53;
    TASSIGN(v1207, v1208);
    pipe_barrier(PIPE_V);
    TMULS(v1207, v1205, v1098);
    // pto: %t__tmp_v68
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1209 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
    // pto: %t__tmp_v68
    ;
    uint64_t v1210 = (uint64_t) v45;
    TASSIGN(v1209, v1210);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    TCOLEXPAND(v1209, v1175);
    // pto: %row2_inline606__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1211 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
    // pto: %row2_inline606__ssa_v0
    ;
    uint64_t v1212 = (uint64_t) v45;
    TASSIGN(v1211, v1212);
    pipe_barrier(PIPE_V);
    TADD(v1211, v1207, v1209);
    // pto: %t__tmp_v69
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1213 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
    // pto: %t__tmp_v69
    ;
    uint64_t v1214 = (uint64_t) v53;
    TASSIGN(v1213, v1214);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v1213, v1149, v1111);
    // pto: %t__tmp_v70
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1215 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
    // pto: %t__tmp_v70
    ;
    uint64_t v1216 = (uint64_t) v53;
    TASSIGN(v1215, v1216);
    pipe_barrier(PIPE_V);
    TMULS(v1215, v1213, v1098);
    // pto: %t__tmp_v71
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1217 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
    // pto: %t__tmp_v71
    ;
    uint64_t v1218 = (uint64_t) v46;
    TASSIGN(v1217, v1218);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    TCOLEXPAND(v1217, v1182);
    // pto: %row3_inline603__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1219 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
    // pto: %row3_inline603__ssa_v0
    ;
    uint64_t v1220 = (uint64_t) v46;
    TASSIGN(v1219, v1220);
    pipe_barrier(PIPE_V);
    TADD(v1219, v1215, v1217);
    // pto: %row0_p_inline626__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1221 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row0_p_inline626__ssa_v0
    ;
    uint64_t v1222 = (uint64_t) v47;
    TASSIGN(v1221, v1222);
    TFILLPAD<pto::TFillPadMode::InPlace>(v1221, v1195);
    // pto: %row1_p_inline586__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1223 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row1_p_inline586__ssa_v0
    ;
    uint64_t v1224 = (uint64_t) v48;
    TASSIGN(v1223, v1224);
    TFILLPAD<pto::TFillPadMode::InPlace>(v1223, v1203);
    // pto: %row2_p_inline585__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1225 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row2_p_inline585__ssa_v0
    ;
    uint64_t v1226 = (uint64_t) v45;
    TASSIGN(v1225, v1226);
    TFILLPAD<pto::TFillPadMode::InPlace>(v1225, v1211);
    // pto: %row3_p_inline583__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1227 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row3_p_inline583__ssa_v0
    ;
    uint64_t v1228 = (uint64_t) v46;
    TASSIGN(v1227, v1228);
    pipe_barrier(PIPE_V);
    TFILLPAD<pto::TFillPadMode::InPlace>(v1227, v1219);
    // pto: %row_max_tmp_inline580__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1229 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %row_max_tmp_inline580__ssa_v0
    ;
    uint64_t v1230 = (uint64_t) v53;
    TASSIGN(v1229, v1230);
    // pto: %row_sum_tmp_inline577__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1231 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %row_sum_tmp_inline577__ssa_v0
    ;
    uint64_t v1232 = (uint64_t) v54;
    TASSIGN(v1231, v1232);
    // pto: %row0_max_inline615__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1233 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row0_max_inline615__ssa_v0
    ;
    uint64_t v1234 = (uint64_t) v55;
    TASSIGN(v1233, v1234);
    TROWMAX(v1233, v1221, v1229);
    // pto: %row1_max_inline591__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1235 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row1_max_inline591__ssa_v0
    ;
    uint64_t v1236 = (uint64_t) v56;
    TASSIGN(v1235, v1236);
    pipe_barrier(PIPE_V);
    TROWMAX(v1235, v1223, v1229);
    // pto: %row2_max_inline611__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1237 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row2_max_inline611__ssa_v0
    ;
    uint64_t v1238 = (uint64_t) v49;
    TASSIGN(v1237, v1238);
    pipe_barrier(PIPE_V);
    TROWMAX(v1237, v1225, v1229);
    // pto: %row3_max_inline619__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1239 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row3_max_inline619__ssa_v0
    ;
    uint64_t v1240 = (uint64_t) v63;
    TASSIGN(v1239, v1240);
    pipe_barrier(PIPE_V);
    TROWMAX(v1239, v1227, v1229);
    // pto: %t__tmp_v72
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1241 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v72
    ;
    uint64_t v1242 = (uint64_t) v47;
    TASSIGN(v1241, v1242);
    TROWEXPANDSUB(v1241, v1221, v1233);
    // pto: %row0_exp_inline607__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1243 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row0_exp_inline607__ssa_v0
    ;
    uint64_t v1244 = (uint64_t) v47;
    TASSIGN(v1243, v1244);
    pipe_barrier(PIPE_V);
    TEXP(v1243, v1241);
    // pto: %t__tmp_v73
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1245 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v73
    ;
    uint64_t v1246 = (uint64_t) v48;
    TASSIGN(v1245, v1246);
    TROWEXPANDSUB(v1245, v1223, v1235);
    // pto: %row1_exp_inline621__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1247 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row1_exp_inline621__ssa_v0
    ;
    uint64_t v1248 = (uint64_t) v48;
    TASSIGN(v1247, v1248);
    pipe_barrier(PIPE_V);
    TEXP(v1247, v1245);
    // pto: %t__tmp_v74
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1249 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v74
    ;
    uint64_t v1250 = (uint64_t) v45;
    TASSIGN(v1249, v1250);
    TROWEXPANDSUB(v1249, v1225, v1237);
    // pto: %row2_exp_inline631__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1251 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row2_exp_inline631__ssa_v0
    ;
    uint64_t v1252 = (uint64_t) v45;
    TASSIGN(v1251, v1252);
    pipe_barrier(PIPE_V);
    TEXP(v1251, v1249);
    // pto: %t__tmp_v75
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1253 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v75
    ;
    uint64_t v1254 = (uint64_t) v46;
    TASSIGN(v1253, v1254);
    TROWEXPANDSUB(v1253, v1227, v1239);
    // pto: %row3_exp_inline601__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1255 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row3_exp_inline601__ssa_v0
    ;
    uint64_t v1256 = (uint64_t) v46;
    TASSIGN(v1255, v1256);
    pipe_barrier(PIPE_V);
    TEXP(v1255, v1253);
    // pto: %row0_sum_inline578__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1257 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row0_sum_inline578__ssa_v0
    ;
    uint64_t v1258 = (uint64_t) v53;
    TASSIGN(v1257, v1258);
    TROWSUM(v1257, v1243, v1231);
    // pto: %row1_sum_inline627__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1259 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row1_sum_inline627__ssa_v0
    ;
    uint64_t v1260 = (uint64_t) v55;
    TASSIGN(v1259, v1260);
    pipe_barrier(PIPE_V);
    TROWSUM(v1259, v1247, v1231);
    // pto: %row2_sum_inline588__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1261 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row2_sum_inline588__ssa_v0
    ;
    uint64_t v1262 = (uint64_t) v56;
    TASSIGN(v1261, v1262);
    pipe_barrier(PIPE_V);
    TROWSUM(v1261, v1251, v1231);
    // pto: %row3_sum_inline620__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1263 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row3_sum_inline620__ssa_v0
    ;
    uint64_t v1264 = (uint64_t) v49;
    TASSIGN(v1263, v1264);
    pipe_barrier(PIPE_V);
    TROWSUM(v1263, v1255, v1231);
    // pto: %t__tmp_v76
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1265 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v76
    ;
    uint64_t v1266 = (uint64_t) v47;
    TASSIGN(v1265, v1266);
    TROWEXPANDDIV(v1265, v1243, v1257);
    // pto: %row0_soft_inline629__ssa_v1
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1267 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row0_soft_inline629__ssa_v1
    ;
    uint64_t v1268 = (uint64_t) v47;
    TASSIGN(v1267, v1268);
    pipe_barrier(PIPE_V);
    TADDS(v1267, v1265, v92);
    // pto: %t__tmp_v77
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1269 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v77
    ;
    uint64_t v1270 = (uint64_t) v48;
    TASSIGN(v1269, v1270);
    TROWEXPANDDIV(v1269, v1247, v1259);
    // pto: %row1_soft_inline623__ssa_v1
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1271 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row1_soft_inline623__ssa_v1
    ;
    uint64_t v1272 = (uint64_t) v48;
    TASSIGN(v1271, v1272);
    pipe_barrier(PIPE_V);
    TADDS(v1271, v1269, v92);
    // pto: %t__tmp_v78
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1273 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v78
    ;
    uint64_t v1274 = (uint64_t) v45;
    TASSIGN(v1273, v1274);
    TROWEXPANDDIV(v1273, v1251, v1261);
    // pto: %row2_soft_inline616__ssa_v1
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1275 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row2_soft_inline616__ssa_v1
    ;
    uint64_t v1276 = (uint64_t) v45;
    TASSIGN(v1275, v1276);
    pipe_barrier(PIPE_V);
    TADDS(v1275, v1273, v92);
    // pto: %t__tmp_v79
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1277 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v79
    ;
    uint64_t v1278 = (uint64_t) v46;
    TASSIGN(v1277, v1278);
    TROWEXPANDDIV(v1277, v1255, v1263);
    // pto: %row3_soft_inline624__ssa_v1
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1279 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row3_soft_inline624__ssa_v1
    ;
    uint64_t v1280 = (uint64_t) v46;
    TASSIGN(v1279, v1280);
    pipe_barrier(PIPE_V);
    TADDS(v1279, v1277, v92);
    v1267.SetValidShape(v79, v77);
    v1271.SetValidShape(v79, v77);
    v1275.SetValidShape(v79, v77);
    v1279.SetValidShape(v79, v77);
    // pto: %row0_eff_inline609__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1281 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row0_eff_inline609__ssa_v0
    ;
    uint64_t v1282 = (uint64_t) v47;
    TASSIGN(v1281, v1282);
    TFILLPAD<pto::TFillPadMode::InPlace>(v1281, v1267);
    // pto: %row1_eff_inline638__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1283 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row1_eff_inline638__ssa_v0
    ;
    uint64_t v1284 = (uint64_t) v48;
    TASSIGN(v1283, v1284);
    TFILLPAD<pto::TFillPadMode::InPlace>(v1283, v1271);
    // pto: %row2_eff_inline640__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1285 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row2_eff_inline640__ssa_v0
    ;
    uint64_t v1286 = (uint64_t) v45;
    TASSIGN(v1285, v1286);
    TFILLPAD<pto::TFillPadMode::InPlace>(v1285, v1275);
    // pto: %row3_eff_inline641__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1287 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row3_eff_inline641__ssa_v0
    ;
    uint64_t v1288 = (uint64_t) v46;
    TASSIGN(v1287, v1288);
    pipe_barrier(PIPE_V);
    TFILLPAD<pto::TFillPadMode::InPlace>(v1287, v1279);
    // pto: %row_sum_tmp_iter_inline642__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1289 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %row_sum_tmp_iter_inline642__ssa_v0
    ;
    uint64_t v1290 = (uint64_t) v53;
    TASSIGN(v1289, v1290);
    // pto: %t__tmp_v80
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1291 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v80
    ;
    uint64_t v1292 = (uint64_t) v54;
    TASSIGN(v1291, v1292);
    TADD(v1291, v1281, v1283);
    // pto: %t__tmp_v81
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1293 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v81
    ;
    uint64_t v1294 = (uint64_t) v54;
    TASSIGN(v1293, v1294);
    pipe_barrier(PIPE_V);
    TADD(v1293, v1291, v1285);
    // pto: %col_sum_inline576__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1295 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %col_sum_inline576__ssa_v0
    ;
    uint64_t v1296 = (uint64_t) v54;
    TASSIGN(v1295, v1296);
    pipe_barrier(PIPE_V);
    TADD(v1295, v1293, v1287);
    // pto: %col_sum_v1_inline575__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1297 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %col_sum_v1_inline575__ssa_v0
    ;
    uint64_t v1298 = (uint64_t) v54;
    TASSIGN(v1297, v1298);
    pipe_barrier(PIPE_V);
    TADDS(v1297, v1295, v92);
    // pto: %row0_cur_inline573__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1299 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row0_cur_inline573__ssa_v0
    ;
    uint64_t v1300 = (uint64_t) v47;
    TASSIGN(v1299, v1300);
    pipe_barrier(PIPE_V);
    TDIV(v1299, v1281, v1297);
    // pto: %row1_cur_inline572__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1301 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row1_cur_inline572__ssa_v0
    ;
    uint64_t v1302 = (uint64_t) v48;
    TASSIGN(v1301, v1302);
    TDIV(v1301, v1283, v1297);
    // pto: %row2_cur_inline574__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1303 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row2_cur_inline574__ssa_v0
    ;
    uint64_t v1304 = (uint64_t) v45;
    TASSIGN(v1303, v1304);
    TDIV(v1303, v1285, v1297);
    // pto: %row3_cur_inline590__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1305 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row3_cur_inline590__ssa_v0
    ;
    uint64_t v1306 = (uint64_t) v46;
    TASSIGN(v1305, v1306);
    TDIV(v1305, v1287, v1297);
    for (int64_t v1307 = v82; v1307 < v107; v1307 += v80) {
      // pto: %t__tmp_v82
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1308 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %t__tmp_v82
      ;
      uint64_t v1309 = (uint64_t) v54;
      TASSIGN(v1308, v1309);
      pipe_barrier(PIPE_V);
      TROWSUM(v1308, v1299, v1289);
      // pto: %row0_rowsum_inline587__rm_a0_tmp_v0
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1310 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row0_rowsum_inline587__rm_a0_tmp_v0
      ;
      uint64_t v1311 = (uint64_t) v54;
      TASSIGN(v1310, v1311);
      // pto: %row0_rowsum_inline587__row_major_tmp_v1
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1312 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row0_rowsum_inline587__row_major_tmp_v1
      ;
      uint64_t v1313 = (uint64_t) v55;
      TASSIGN(v1312, v1313);
      pipe_barrier(PIPE_V);
      TADDS(v1312, v1310, v92);
      // pto: %row0_rowsum_inline587__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1314 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %row0_rowsum_inline587__ssa_v0
      ;
      uint64_t v1315 = (uint64_t) v55;
      TASSIGN(v1314, v1315);
      // pto: %t__tmp_v83
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1316 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %t__tmp_v83
      ;
      uint64_t v1317 = (uint64_t) v54;
      TASSIGN(v1316, v1317);
      pipe_barrier(PIPE_V);
      TROWSUM(v1316, v1301, v1289);
      // pto: %row1_rowsum_inline579__rm_a0_tmp_v2
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1318 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row1_rowsum_inline579__rm_a0_tmp_v2
      ;
      uint64_t v1319 = (uint64_t) v54;
      TASSIGN(v1318, v1319);
      // pto: %row1_rowsum_inline579__row_major_tmp_v3
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1320 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row1_rowsum_inline579__row_major_tmp_v3
      ;
      uint64_t v1321 = (uint64_t) v56;
      TASSIGN(v1320, v1321);
      pipe_barrier(PIPE_V);
      TADDS(v1320, v1318, v92);
      // pto: %row1_rowsum_inline579__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1322 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %row1_rowsum_inline579__ssa_v0
      ;
      uint64_t v1323 = (uint64_t) v56;
      TASSIGN(v1322, v1323);
      // pto: %t__tmp_v84
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1324 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %t__tmp_v84
      ;
      uint64_t v1325 = (uint64_t) v54;
      TASSIGN(v1324, v1325);
      pipe_barrier(PIPE_V);
      TROWSUM(v1324, v1303, v1289);
      // pto: %row2_rowsum_inline570__rm_a0_tmp_v4
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1326 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row2_rowsum_inline570__rm_a0_tmp_v4
      ;
      uint64_t v1327 = (uint64_t) v54;
      TASSIGN(v1326, v1327);
      // pto: %row2_rowsum_inline570__row_major_tmp_v5
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1328 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row2_rowsum_inline570__row_major_tmp_v5
      ;
      uint64_t v1329 = (uint64_t) v49;
      TASSIGN(v1328, v1329);
      pipe_barrier(PIPE_V);
      TADDS(v1328, v1326, v92);
      // pto: %row2_rowsum_inline570__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1330 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %row2_rowsum_inline570__ssa_v0
      ;
      uint64_t v1331 = (uint64_t) v49;
      TASSIGN(v1330, v1331);
      // pto: %t__tmp_v85
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1332 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %t__tmp_v85
      ;
      uint64_t v1333 = (uint64_t) v54;
      TASSIGN(v1332, v1333);
      pipe_barrier(PIPE_V);
      TROWSUM(v1332, v1305, v1289);
      // pto: %row3_rowsum_inline569__rm_a0_tmp_v6
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1334 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row3_rowsum_inline569__rm_a0_tmp_v6
      ;
      uint64_t v1335 = (uint64_t) v54;
      TASSIGN(v1334, v1335);
      // pto: %row3_rowsum_inline569__row_major_tmp_v7
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1336 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row3_rowsum_inline569__row_major_tmp_v7
      ;
      uint64_t v1337 = (uint64_t) v63;
      TASSIGN(v1336, v1337);
      pipe_barrier(PIPE_V);
      TADDS(v1336, v1334, v92);
      // pto: %row3_rowsum_inline569__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1338 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %row3_rowsum_inline569__ssa_v0
      ;
      uint64_t v1339 = (uint64_t) v63;
      TASSIGN(v1338, v1339);
      // pto: %row0_norm_inline568__ssa_v1
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1340 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row0_norm_inline568__ssa_v1
      ;
      uint64_t v1341 = (uint64_t) v54;
      TASSIGN(v1340, v1341);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v1340, v1299, v1314);
      // pto: %row1_norm_inline567__ssa_v1
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1342 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row1_norm_inline567__ssa_v1
      ;
      uint64_t v1343 = (uint64_t) v55;
      TASSIGN(v1342, v1343);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v1342, v1301, v1322);
      // pto: %row2_norm_inline566__ssa_v1
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1344 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row2_norm_inline566__ssa_v1
      ;
      uint64_t v1345 = (uint64_t) v56;
      TASSIGN(v1344, v1345);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v1344, v1303, v1330);
      // pto: %row3_norm_inline612__ssa_v1
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1346 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row3_norm_inline612__ssa_v1
      ;
      uint64_t v1347 = (uint64_t) v49;
      TASSIGN(v1346, v1347);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v1346, v1305, v1338);
      // pto: %t__tmp_v86
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1348 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %t__tmp_v86
      ;
      uint64_t v1349 = (uint64_t) v63;
      TASSIGN(v1348, v1349);
      pipe_barrier(PIPE_V);
      TADD(v1348, v1340, v1342);
      // pto: %t__tmp_v87
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1350 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %t__tmp_v87
      ;
      uint64_t v1351 = (uint64_t) v63;
      TASSIGN(v1350, v1351);
      pipe_barrier(PIPE_V);
      TADD(v1350, v1348, v1344);
      // pto: %col_sum_v1_inline575__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1352 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %col_sum_v1_inline575__ssa_v3
      ;
      uint64_t v1353 = (uint64_t) v63;
      TASSIGN(v1352, v1353);
      pipe_barrier(PIPE_V);
      TADD(v1352, v1350, v1346);
      // pto: %col_sum_v1_inline575__ssa_v4
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1354 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %col_sum_v1_inline575__ssa_v4
      ;
      uint64_t v1355 = (uint64_t) v63;
      TASSIGN(v1354, v1355);
      pipe_barrier(PIPE_V);
      TADDS(v1354, v1352, v92);
      // pto: %row0_cur_inline573__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1356 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row0_cur_inline573__ssa_v3
      ;
      uint64_t v1357 = (uint64_t) v54;
      TASSIGN(v1356, v1357);
      pipe_barrier(PIPE_V);
      TDIV(v1356, v1340, v1354);
      // pto: %row1_cur_inline572__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1358 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row1_cur_inline572__ssa_v3
      ;
      uint64_t v1359 = (uint64_t) v55;
      TASSIGN(v1358, v1359);
      TDIV(v1358, v1342, v1354);
      // pto: %row2_cur_inline574__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1360 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row2_cur_inline574__ssa_v3
      ;
      uint64_t v1361 = (uint64_t) v56;
      TASSIGN(v1360, v1361);
      TDIV(v1360, v1344, v1354);
      // pto: %row3_cur_inline590__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1362 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row3_cur_inline590__ssa_v3
      ;
      uint64_t v1363 = (uint64_t) v49;
      TASSIGN(v1362, v1363);
      TDIV(v1362, v1346, v1354);
      // pto: %34
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1364 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %34
      ;
      uint64_t v1365 = (uint64_t) v64;
      TASSIGN(v1364, v1365);
      pipe_barrier(PIPE_V);
      TROWSUM(v1364, v1356, v1289);
      // pto: %35
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1366 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %35
      ;
      uint64_t v1367 = (uint64_t) v64;
      TASSIGN(v1366, v1367);
      // pto: %36
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1368 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %36
      ;
      uint64_t v1369 = (uint64_t) v65;
      TASSIGN(v1368, v1369);
      pipe_barrier(PIPE_V);
      TADDS(v1368, v1366, v92);
      // pto: %37
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1370 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %37
      ;
      uint64_t v1371 = (uint64_t) v65;
      TASSIGN(v1370, v1371);
      // pto: %38
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1372 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %38
      ;
      uint64_t v1373 = (uint64_t) v64;
      TASSIGN(v1372, v1373);
      pipe_barrier(PIPE_V);
      TROWSUM(v1372, v1358, v1289);
      // pto: %39
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1374 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %39
      ;
      uint64_t v1375 = (uint64_t) v64;
      TASSIGN(v1374, v1375);
      // pto: %40
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1376 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %40
      ;
      uint64_t v1377 = (uint64_t) v66;
      TASSIGN(v1376, v1377);
      pipe_barrier(PIPE_V);
      TADDS(v1376, v1374, v92);
      // pto: %41
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1378 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %41
      ;
      uint64_t v1379 = (uint64_t) v66;
      TASSIGN(v1378, v1379);
      // pto: %42
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1380 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %42
      ;
      uint64_t v1381 = (uint64_t) v64;
      TASSIGN(v1380, v1381);
      pipe_barrier(PIPE_V);
      TROWSUM(v1380, v1360, v1289);
      // pto: %43
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1382 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %43
      ;
      uint64_t v1383 = (uint64_t) v64;
      TASSIGN(v1382, v1383);
      // pto: %44
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1384 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %44
      ;
      uint64_t v1385 = (uint64_t) v67;
      TASSIGN(v1384, v1385);
      pipe_barrier(PIPE_V);
      TADDS(v1384, v1382, v92);
      // pto: %45
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1386 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %45
      ;
      uint64_t v1387 = (uint64_t) v67;
      TASSIGN(v1386, v1387);
      // pto: %46
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1388 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %46
      ;
      uint64_t v1389 = (uint64_t) v64;
      TASSIGN(v1388, v1389);
      pipe_barrier(PIPE_V);
      TROWSUM(v1388, v1362, v1289);
      // pto: %47
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1390 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %47
      ;
      uint64_t v1391 = (uint64_t) v64;
      TASSIGN(v1390, v1391);
      // pto: %48
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1392 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %48
      ;
      uint64_t v1393 = (uint64_t) v68;
      TASSIGN(v1392, v1393);
      pipe_barrier(PIPE_V);
      TADDS(v1392, v1390, v92);
      // pto: %49
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1394 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %49
      ;
      uint64_t v1395 = (uint64_t) v68;
      TASSIGN(v1394, v1395);
      // pto: %50
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1396 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %50
      ;
      uint64_t v1397 = (uint64_t) v64;
      TASSIGN(v1396, v1397);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v1396, v1356, v1370);
      // pto: %51
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1398 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %51
      ;
      uint64_t v1399 = (uint64_t) v65;
      TASSIGN(v1398, v1399);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v1398, v1358, v1378);
      // pto: %52
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1400 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %52
      ;
      uint64_t v1401 = (uint64_t) v66;
      TASSIGN(v1400, v1401);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v1400, v1360, v1386);
      // pto: %53
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1402 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %53
      ;
      uint64_t v1403 = (uint64_t) v67;
      TASSIGN(v1402, v1403);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v1402, v1362, v1394);
      // pto: %54
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1404 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %54
      ;
      uint64_t v1405 = (uint64_t) v68;
      TASSIGN(v1404, v1405);
      pipe_barrier(PIPE_V);
      TADD(v1404, v1396, v1398);
      // pto: %55
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1406 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %55
      ;
      uint64_t v1407 = (uint64_t) v68;
      TASSIGN(v1406, v1407);
      pipe_barrier(PIPE_V);
      TADD(v1406, v1404, v1400);
      // pto: %56
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1408 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %56
      ;
      uint64_t v1409 = (uint64_t) v68;
      TASSIGN(v1408, v1409);
      pipe_barrier(PIPE_V);
      TADD(v1408, v1406, v1402);
      // pto: %57
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1410 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %57
      ;
      uint64_t v1411 = (uint64_t) v68;
      TASSIGN(v1410, v1411);
      pipe_barrier(PIPE_V);
      TADDS(v1410, v1408, v92);
      // pto: %58
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1412 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %58
      ;
      uint64_t v1413 = (uint64_t) v47;
      TASSIGN(v1412, v1413);
      pipe_barrier(PIPE_V);
      TDIV(v1412, v1396, v1410);
      // pto: %59
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1414 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %59
      ;
      uint64_t v1415 = (uint64_t) v48;
      TASSIGN(v1414, v1415);
      TDIV(v1414, v1398, v1410);
      // pto: %60
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1416 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %60
      ;
      uint64_t v1417 = (uint64_t) v45;
      TASSIGN(v1416, v1417);
      TDIV(v1416, v1400, v1410);
      // pto: %61
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1418 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %61
      ;
      uint64_t v1419 = (uint64_t) v46;
      TASSIGN(v1418, v1419);
      TDIV(v1418, v1402, v1410);
    };
    // pto: %62
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1420 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %62
    ;
    uint64_t v1421 = (uint64_t) v54;
    TASSIGN(v1420, v1421);
    pipe_barrier(PIPE_V);
    TROWSUM(v1420, v1299, v1289);
    // pto: %63
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1422 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %63
    ;
    uint64_t v1423 = (uint64_t) v54;
    TASSIGN(v1422, v1423);
    // pto: %64
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1424 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %64
    ;
    uint64_t v1425 = (uint64_t) v54;
    TASSIGN(v1424, v1425);
    pipe_barrier(PIPE_V);
    TADDS(v1424, v1422, v92);
    // pto: %65
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1426 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %65
    ;
    uint64_t v1427 = (uint64_t) v54;
    TASSIGN(v1426, v1427);
    // pto: %66
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1428 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %66
    ;
    uint64_t v1429 = (uint64_t) v55;
    TASSIGN(v1428, v1429);
    TROWSUM(v1428, v1301, v1289);
    // pto: %67
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1430 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %67
    ;
    uint64_t v1431 = (uint64_t) v55;
    TASSIGN(v1430, v1431);
    // pto: %68
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1432 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %68
    ;
    uint64_t v1433 = (uint64_t) v55;
    TASSIGN(v1432, v1433);
    pipe_barrier(PIPE_V);
    TADDS(v1432, v1430, v92);
    // pto: %69
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1434 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %69
    ;
    uint64_t v1435 = (uint64_t) v55;
    TASSIGN(v1434, v1435);
    // pto: %70
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1436 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %70
    ;
    uint64_t v1437 = (uint64_t) v56;
    TASSIGN(v1436, v1437);
    TROWSUM(v1436, v1303, v1289);
    // pto: %71
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1438 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %71
    ;
    uint64_t v1439 = (uint64_t) v56;
    TASSIGN(v1438, v1439);
    // pto: %72
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1440 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %72
    ;
    uint64_t v1441 = (uint64_t) v56;
    TASSIGN(v1440, v1441);
    pipe_barrier(PIPE_V);
    TADDS(v1440, v1438, v92);
    // pto: %73
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1442 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %73
    ;
    uint64_t v1443 = (uint64_t) v56;
    TASSIGN(v1442, v1443);
    // pto: %74
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1444 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %74
    ;
    uint64_t v1445 = (uint64_t) v49;
    TASSIGN(v1444, v1445);
    TROWSUM(v1444, v1305, v1289);
    // pto: %75
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1446 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %75
    ;
    uint64_t v1447 = (uint64_t) v49;
    TASSIGN(v1446, v1447);
    // pto: %76
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1448 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %76
    ;
    uint64_t v1449 = (uint64_t) v53;
    TASSIGN(v1448, v1449);
    pipe_barrier(PIPE_V);
    TADDS(v1448, v1446, v92);
    // pto: %77
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1450 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %77
    ;
    uint64_t v1451 = (uint64_t) v53;
    TASSIGN(v1450, v1451);
    // pto: %78
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1452 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %78
    ;
    uint64_t v1453 = (uint64_t) v47;
    TASSIGN(v1452, v1453);
    TROWEXPANDDIV(v1452, v1299, v1426);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %79
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1454 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %79
    ;
    uint64_t v1455 = (uint64_t) v48;
    TASSIGN(v1454, v1455);
    TROWEXPANDDIV(v1454, v1301, v1434);
    // pto: %80
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1456 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %80
    ;
    uint64_t v1457 = (uint64_t) v45;
    TASSIGN(v1456, v1457);
    TROWEXPANDDIV(v1456, v1303, v1442);
    // pto: %81
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1458 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %81
    ;
    uint64_t v1459 = (uint64_t) v46;
    TASSIGN(v1458, v1459);
    pipe_barrier(PIPE_V);
    TROWEXPANDDIV(v1458, v1305, v1450);
    // pto: %82
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1460 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %82
    ;
    uint64_t v1461 = (uint64_t) v53;
    TASSIGN(v1460, v1461);
    pipe_barrier(PIPE_V);
    TADD(v1460, v1452, v1454);
    // pto: %83
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1462 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %83
    ;
    uint64_t v1463 = (uint64_t) v53;
    TASSIGN(v1462, v1463);
    pipe_barrier(PIPE_V);
    TADD(v1462, v1460, v1456);
    // pto: %84
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1464 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %84
    ;
    uint64_t v1465 = (uint64_t) v53;
    TASSIGN(v1464, v1465);
    pipe_barrier(PIPE_V);
    TADD(v1464, v1462, v1458);
    // pto: %85
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1466 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %85
    ;
    uint64_t v1467 = (uint64_t) v53;
    TASSIGN(v1466, v1467);
    pipe_barrier(PIPE_V);
    TADDS(v1466, v1464, v92);
    // pto: %86
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1468 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %86
    ;
    uint64_t v1469 = (uint64_t) v47;
    TASSIGN(v1468, v1469);
    pipe_barrier(PIPE_V);
    TDIV(v1468, v1452, v1466);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %87
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1470 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %87
    ;
    uint64_t v1471 = (uint64_t) v48;
    TASSIGN(v1470, v1471);
    TDIV(v1470, v1454, v1466);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %88
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1472 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %88
    ;
    uint64_t v1473 = (uint64_t) v45;
    TASSIGN(v1472, v1473);
    TDIV(v1472, v1456, v1466);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
    // pto: %89
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1474 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %89
    ;
    uint64_t v1475 = (uint64_t) v46;
    TASSIGN(v1474, v1475);
    TDIV(v1474, v1458, v1466);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    // pto: %row0_cur_inline573__rv_v2
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1476 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row0_cur_inline573__rv_v2
    ;
    uint64_t v1477 = (uint64_t) v47;
    TASSIGN(v1476, v1477);
    // pto: %row1_cur_inline572__rv_v2
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1478 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row1_cur_inline572__rv_v2
    ;
    uint64_t v1479 = (uint64_t) v48;
    TASSIGN(v1478, v1479);
    // pto: %row2_cur_inline574__rv_v2
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1480 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row2_cur_inline574__rv_v2
    ;
    uint64_t v1481 = (uint64_t) v45;
    TASSIGN(v1480, v1481);
    // pto: %row3_cur_inline590__rv_v2
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1482 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row3_cur_inline590__rv_v2
    ;
    uint64_t v1483 = (uint64_t) v46;
    TASSIGN(v1482, v1483);
    // pto: %421
    ;
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
    if (v1101 == v79) {
      v1476.SetValidShape(v79, v77);
      v1478.SetValidShape(v79, v77);
      v1480.SetValidShape(v79, v77);
      v1482.SetValidShape(v79, v77);
      // pto: %comb__ssa_v0_pview
      ;
      __gm__ float* v1484 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %comb__ssa_v0_pview
      ;
      const int64_t v1485 = 0;
      // pto: %comb__ssa_v0_pview
      ;
      const int64_t v1486 = 16;
      // pto: %comb__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 4> v1487 = pto::Shape<1, 1, 1, 8, 4>();
      // pto: %comb__ssa_v0_pview
      ;
      pto::Stride<128, 128, 128, 16, 1> v1488 = pto::Stride<128, 128, 128, 16, 1>();
      // pto: %comb__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND> v1489 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND>(v1484 + (v1485 + v1104 * v1486), v1487, v1488);
      TSTORE(v1489, v1476);
      // pto: %424
      ;
      __gm__ float* v1490 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %424
      ;
      const int64_t v1491 = 4;
      // pto: %424
      ;
      const int64_t v1492 = 16;
      // pto: %424
      ;
      pto::Shape<1, 1, 1, 8, 4> v1493 = pto::Shape<1, 1, 1, 8, 4>();
      // pto: %424
      ;
      pto::Stride<128, 128, 128, 16, 1> v1494 = pto::Stride<128, 128, 128, 16, 1>();
      // pto: %424
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND> v1495 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND>(v1490 + (v1491 + v1104 * v1492), v1493, v1494);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1495, v1478);
      // pto: %426
      ;
      __gm__ float* v1496 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %426
      ;
      const int64_t v1497 = 8;
      // pto: %426
      ;
      const int64_t v1498 = 16;
      // pto: %426
      ;
      pto::Shape<1, 1, 1, 8, 4> v1499 = pto::Shape<1, 1, 1, 8, 4>();
      // pto: %426
      ;
      pto::Stride<128, 128, 128, 16, 1> v1500 = pto::Stride<128, 128, 128, 16, 1>();
      // pto: %426
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND> v1501 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND>(v1496 + (v1497 + v1104 * v1498), v1499, v1500);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1501, v1480);
      // pto: %428
      ;
      __gm__ float* v1502 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %428
      ;
      const int64_t v1503 = 12;
      // pto: %428
      ;
      const int64_t v1504 = 16;
      // pto: %428
      ;
      pto::Shape<1, 1, 1, 8, 4> v1505 = pto::Shape<1, 1, 1, 8, 4>();
      // pto: %428
      ;
      pto::Stride<128, 128, 128, 16, 1> v1506 = pto::Stride<128, 128, 128, 16, 1>();
      // pto: %428
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND> v1507 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND>(v1502 + (v1503 + v1104 * v1504), v1505, v1506);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1507, v1482);
    } else {
      // pto: %430
      ;
      int64_t v1508 = v449 < v82 ? v82 : v449;
      // pto: %431
      ;
      __gm__ float* v1509 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %431
      ;
      const int64_t v1510 = 8;
      // pto: %431
      ;
      const int64_t v1511 = 64;
      // pto: %431
      ;
      pto::Shape<1, 1, 1, 8, 8> v1512 = pto::Shape<1, 1, 1, 8, 8>();
      // pto: %431
      ;
      pto::Stride<512, 512, 512, 64, 1> v1513 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %431
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v1514 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v1509 + (v1510 + v1508 * v1511), v1512, v1513);
      TSTORE(v1514, v1476);
      // pto: %434
      ;
      __gm__ float* v1515 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %434
      ;
      const int64_t v1516 = 16;
      // pto: %434
      ;
      const int64_t v1517 = 64;
      // pto: %434
      ;
      pto::Shape<1, 1, 1, 8, 8> v1518 = pto::Shape<1, 1, 1, 8, 8>();
      // pto: %434
      ;
      pto::Stride<512, 512, 512, 64, 1> v1519 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %434
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v1520 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v1515 + (v1516 + v1508 * v1517), v1518, v1519);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1520, v1478);
      // pto: %437
      ;
      __gm__ float* v1521 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %437
      ;
      const int64_t v1522 = 24;
      // pto: %437
      ;
      const int64_t v1523 = 64;
      // pto: %437
      ;
      pto::Shape<1, 1, 1, 8, 8> v1524 = pto::Shape<1, 1, 1, 8, 8>();
      // pto: %437
      ;
      pto::Stride<512, 512, 512, 64, 1> v1525 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %437
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v1526 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v1521 + (v1522 + v1508 * v1523), v1524, v1525);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1526, v1480);
      // pto: %440
      ;
      __gm__ float* v1527 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %440
      ;
      const int64_t v1528 = 32;
      // pto: %440
      ;
      const int64_t v1529 = 64;
      // pto: %440
      ;
      pto::Shape<1, 1, 1, 8, 8> v1530 = pto::Shape<1, 1, 1, 8, 8>();
      // pto: %440
      ;
      pto::Stride<512, 512, 512, 64, 1> v1531 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %440
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v1532 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v1527 + (v1528 + v1508 * v1529), v1530, v1531);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1532, v1482);
      // pto: %row0_tail_inline582__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1533 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
      // pto: %row0_tail_inline582__ssa_v0
      ;
      uint64_t v1534 = (uint64_t) v47;
      TASSIGN(v1533, v1534);
      // pto: %443
      ;
      const int64_t v1535 = 0;
      // pto: %443
      ;
      __gm__ float* v1536 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %443
      ;
      const int64_t v1537 = 1;
      // pto: %443
      ;
      const int64_t v1538 = 1;
      // pto: %443
      ;
      const int64_t v1539 = 1;
      // pto: %443
      ;
      int64_t v1540 = v1101 * v76;
      // pto: %443
      ;
      int64_t v1541 = v1539 * v1540;
      // pto: %443
      ;
      pto::Shape<1, 1, 1, -1, 4> v1542 = pto::Shape<1, 1, 1, -1, 4>(v1537, v1538, v1539, v1101, v77);
      // pto: %443
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1543 = pto::Stride<-1, -1, -1, -1, -1>(v1538 * v1541, v1541, v1540, v76, v70);
      // pto: %443
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1544 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1536 + (v1535 + v1508 * v76 + v79 * v70), v1542, v1543);
      pipe_barrier(PIPE_ALL);
      TLOAD(v1533, v1544);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID4);
      // pto: %row1_tail_inline562__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1545 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
      // pto: %row1_tail_inline562__ssa_v0
      ;
      uint64_t v1546 = (uint64_t) v48;
      TASSIGN(v1545, v1546);
      // pto: %446
      ;
      const int64_t v1547 = 0;
      // pto: %446
      ;
      __gm__ float* v1548 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %446
      ;
      const int64_t v1549 = 1;
      // pto: %446
      ;
      const int64_t v1550 = 1;
      // pto: %446
      ;
      const int64_t v1551 = 1;
      // pto: %446
      ;
      int64_t v1552 = v1101 * v76;
      // pto: %446
      ;
      int64_t v1553 = v1551 * v1552;
      // pto: %446
      ;
      pto::Shape<1, 1, 1, -1, 4> v1554 = pto::Shape<1, 1, 1, -1, 4>(v1549, v1550, v1551, v1101, v77);
      // pto: %446
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1555 = pto::Stride<-1, -1, -1, -1, -1>(v1550 * v1553, v1553, v1552, v76, v70);
      // pto: %446
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1556 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1548 + (v1547 + v1508 * v76 + v71 * v70), v1554, v1555);
      TLOAD(v1545, v1556);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID5);
      // pto: %row2_tail_inline622__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1557 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
      // pto: %row2_tail_inline622__ssa_v0
      ;
      uint64_t v1558 = (uint64_t) v45;
      TASSIGN(v1557, v1558);
      // pto: %449
      ;
      const int64_t v1559 = 0;
      // pto: %449
      ;
      __gm__ float* v1560 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %449
      ;
      const int64_t v1561 = 1;
      // pto: %449
      ;
      const int64_t v1562 = 1;
      // pto: %449
      ;
      const int64_t v1563 = 1;
      // pto: %449
      ;
      int64_t v1564 = v1101 * v76;
      // pto: %449
      ;
      int64_t v1565 = v1563 * v1564;
      // pto: %449
      ;
      pto::Shape<1, 1, 1, -1, 4> v1566 = pto::Shape<1, 1, 1, -1, 4>(v1561, v1562, v1563, v1101, v77);
      // pto: %449
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1567 = pto::Stride<-1, -1, -1, -1, -1>(v1562 * v1565, v1565, v1564, v76, v70);
      // pto: %449
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1568 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1560 + (v1559 + v1508 * v76 + v78 * v70), v1566, v1567);
      TLOAD(v1557, v1568);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID6);
      // pto: %row3_tail_inline561__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1569 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1101, v77);
      // pto: %row3_tail_inline561__ssa_v0
      ;
      uint64_t v1570 = (uint64_t) v46;
      TASSIGN(v1569, v1570);
      // pto: %452
      ;
      const int64_t v1571 = 0;
      // pto: %452
      ;
      __gm__ float* v1572 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %452
      ;
      const int64_t v1573 = 1;
      // pto: %452
      ;
      const int64_t v1574 = 1;
      // pto: %452
      ;
      const int64_t v1575 = 1;
      // pto: %452
      ;
      int64_t v1576 = v1101 * v76;
      // pto: %452
      ;
      int64_t v1577 = v1575 * v1576;
      // pto: %452
      ;
      pto::Shape<1, 1, 1, -1, 4> v1578 = pto::Shape<1, 1, 1, -1, 4>(v1573, v1574, v1575, v1101, v77);
      // pto: %452
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1579 = pto::Stride<-1, -1, -1, -1, -1>(v1574 * v1577, v1577, v1576, v76, v70);
      // pto: %452
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1580 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1572 + (v1571 + v1508 * v76 + v73 * v70), v1578, v1579);
      TLOAD(v1569, v1580);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID7);
      // pto: %454
      ;
      const int64_t v1581 = 0;
      // pto: %454
      ;
      __gm__ float* v1582 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %454
      ;
      const int64_t v1583 = 1;
      // pto: %454
      ;
      const int64_t v1584 = 1;
      // pto: %454
      ;
      const int64_t v1585 = 1;
      // pto: %454
      ;
      int64_t v1586 = v1101 * v71;
      // pto: %454
      ;
      int64_t v1587 = v1585 * v1586;
      // pto: %454
      ;
      pto::Shape<1, 1, 1, -1, 4> v1588 = pto::Shape<1, 1, 1, -1, 4>(v1583, v1584, v1585, v1101, v77);
      // pto: %454
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1589 = pto::Stride<-1, -1, -1, -1, -1>(v1584 * v1587, v1587, v1586, v71, v70);
      // pto: %454
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1590 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1582 + (v1581 + v1104 * v71 + v82 * v70), v1588, v1589);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID4);
      TSTORE(v1590, v1533);
      // pto: %456
      ;
      const int64_t v1591 = 0;
      // pto: %456
      ;
      __gm__ float* v1592 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %456
      ;
      const int64_t v1593 = 1;
      // pto: %456
      ;
      const int64_t v1594 = 1;
      // pto: %456
      ;
      const int64_t v1595 = 1;
      // pto: %456
      ;
      int64_t v1596 = v1101 * v71;
      // pto: %456
      ;
      int64_t v1597 = v1595 * v1596;
      // pto: %456
      ;
      pto::Shape<1, 1, 1, -1, 4> v1598 = pto::Shape<1, 1, 1, -1, 4>(v1593, v1594, v1595, v1101, v77);
      // pto: %456
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1599 = pto::Stride<-1, -1, -1, -1, -1>(v1594 * v1597, v1597, v1596, v71, v70);
      // pto: %456
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1600 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1592 + (v1591 + v1104 * v71 + v77 * v70), v1598, v1599);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID5);
      TSTORE(v1600, v1545);
      // pto: %458
      ;
      const int64_t v1601 = 0;
      // pto: %458
      ;
      __gm__ float* v1602 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %458
      ;
      const int64_t v1603 = 1;
      // pto: %458
      ;
      const int64_t v1604 = 1;
      // pto: %458
      ;
      const int64_t v1605 = 1;
      // pto: %458
      ;
      int64_t v1606 = v1101 * v71;
      // pto: %458
      ;
      int64_t v1607 = v1605 * v1606;
      // pto: %458
      ;
      pto::Shape<1, 1, 1, -1, 4> v1608 = pto::Shape<1, 1, 1, -1, 4>(v1603, v1604, v1605, v1101, v77);
      // pto: %458
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1609 = pto::Stride<-1, -1, -1, -1, -1>(v1604 * v1607, v1607, v1606, v71, v70);
      // pto: %458
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1610 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1602 + (v1601 + v1104 * v71 + v79 * v70), v1608, v1609);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID6);
      TSTORE(v1610, v1557);
      // pto: %460
      ;
      const int64_t v1611 = 0;
      // pto: %460
      ;
      __gm__ float* v1612 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %460
      ;
      const int64_t v1613 = 1;
      // pto: %460
      ;
      const int64_t v1614 = 1;
      // pto: %460
      ;
      const int64_t v1615 = 1;
      // pto: %460
      ;
      int64_t v1616 = v1101 * v71;
      // pto: %460
      ;
      int64_t v1617 = v1615 * v1616;
      // pto: %460
      ;
      pto::Shape<1, 1, 1, -1, 4> v1618 = pto::Shape<1, 1, 1, -1, 4>(v1613, v1614, v1615, v1101, v77);
      // pto: %460
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1619 = pto::Stride<-1, -1, -1, -1, -1>(v1614 * v1617, v1617, v1616, v71, v70);
      // pto: %460
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1620 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1612 + (v1611 + v1104 * v71 + v106 * v70), v1618, v1619);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID7);
      TSTORE(v1620, v1569);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %461, %462
  int64_t v1621 = (int64_t) ((uint64_t) v32 + (uint64_t) v108) / v71;
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v1622 = v291; v1622 < v1621; v1622 += v81) {
    // pto: %463
    ;
    int64_t v1623 = (int64_t) ((uint64_t) v1622 * (uint64_t) v71);
    // pto: %464
    ;
    int64_t v1624 = (int64_t) ((uint64_t) v32 - (uint64_t) v1623);
    // pto: %465
    ;
    int64_t v1625 = v1624 < v71 ? v1624 : v71;
    // pto: %projected_inline644__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1626 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1625, v75);
    // pto: %projected_inline644__ssa_v0
    ;
    uint64_t v1627 = (uint64_t) v47;
    TASSIGN(v1626, v1627);
    // pto: %466
    ;
    int64_t v1628 = v1623 < v82 ? v82 : v1623;
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    const int64_t v1629 = 0;
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    __gm__ float* v1630 = PTOAS__GLOBAL_TENSOR_DATA(v244);
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    const int64_t v1631 = 1;
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    const int64_t v1632 = 1;
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    const int64_t v1633 = 1;
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    int64_t v1634 = v1625 * v75;
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    int64_t v1635 = v1633 * v1634;
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v1636 = pto::Shape<1, 1, 1, -1, 512>(v1631, v1632, v1633, v1625, v75);
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1637 = pto::Stride<-1, -1, -1, -1, -1>(v1632 * v1635, v1635, v1634, v75, v70);
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1638 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1630 + (v1629 + v1628 * v75 + v82 * v70), v1636, v1637);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v1626, v1638);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %rounded_inline643__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1639 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1625, v75);
    // pto: %rounded_inline643__ssa_v0
    ;
    uint64_t v1640 = (uint64_t) v47;
    TASSIGN(v1639, v1640);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v1641 = RoundMode::CAST_RINT;
    SaturationMode v1642 = SaturationMode::ON;
    TCVT(v1639, v1626, v1641, v1642);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %projected_kv__ssa_v0_pview
    ;
    const int64_t v1643 = 0;
    // pto: %projected_kv__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v1644 = PTOAS__GLOBAL_TENSOR_DATA(v253);
    // pto: %projected_kv__ssa_v0_pview
    ;
    const int64_t v1645 = 1;
    // pto: %projected_kv__ssa_v0_pview
    ;
    const int64_t v1646 = 1;
    // pto: %projected_kv__ssa_v0_pview
    ;
    const int64_t v1647 = 1;
    // pto: %projected_kv__ssa_v0_pview
    ;
    int64_t v1648 = v1625 * v75;
    // pto: %projected_kv__ssa_v0_pview
    ;
    int64_t v1649 = v1647 * v1648;
    // pto: %projected_kv__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v1650 = pto::Shape<1, 1, 1, -1, 512>(v1645, v1646, v1647, v1625, v75);
    // pto: %projected_kv__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1651 = pto::Stride<-1, -1, -1, -1, -1>(v1646 * v1649, v1649, v1648, v75, v70);
    // pto: %projected_kv__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1652 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1644 + (v1643 + v1628 * v75 + v82 * v70), v1650, v1651);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1652, v1639);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v1653 = v291; v1653 < v1621; v1653 += v81) {
    // pto: %470
    ;
    int64_t v1654 = (int64_t) ((uint64_t) v1653 * (uint64_t) v71);
    // pto: %471
    ;
    int64_t v1655 = (int64_t) ((uint64_t) v32 - (uint64_t) v1654);
    // pto: %472
    ;
    int64_t v1656 = v1655 < v71 ? v1655 : v71;
    // pto: %value_inline658__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1657 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1656, v76);
    // pto: %value_inline658__ssa_v0
    ;
    uint64_t v1658 = (uint64_t) v47;
    TASSIGN(v1657, v1658);
    // pto: %473
    ;
    int64_t v1659 = v1654 < v82 ? v82 : v1654;
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    const int64_t v1660 = 0;
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    __gm__ float* v1661 = PTOAS__GLOBAL_TENSOR_DATA(v262);
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    const int64_t v1662 = 1;
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    const int64_t v1663 = 1;
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    const int64_t v1664 = 1;
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    int64_t v1665 = v1656 * v76;
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    int64_t v1666 = v1664 * v1665;
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 64> v1667 = pto::Shape<1, 1, 1, -1, 64>(v1662, v1663, v1664, v1656, v76);
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1668 = pto::Stride<-1, -1, -1, -1, -1>(v1663 * v1666, v1666, v1665, v76, v70);
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1669 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1661 + (v1660 + v1659 * v76 + v82 * v70), v1667, v1668);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v1657, v1669);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %projected_inline653__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1670 = Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1656, v76);
    // pto: %projected_inline653__ssa_v0
    ;
    uint64_t v1671 = (uint64_t) v48;
    TASSIGN(v1670, v1671);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    pipe_barrier(PIPE_V);
    RoundMode v1672 = RoundMode::CAST_RINT;
    SaturationMode v1673 = SaturationMode::ON;
    TCVT(v1670, v1657, v1672, v1673);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %indexer_raw__ssa_v0_pview
    ;
    const int64_t v1674 = 0;
    // pto: %indexer_raw__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v1675 = PTOAS__GLOBAL_TENSOR_DATA(v271);
    // pto: %indexer_raw__ssa_v0_pview
    ;
    const int64_t v1676 = 1;
    // pto: %indexer_raw__ssa_v0_pview
    ;
    const int64_t v1677 = 1;
    // pto: %indexer_raw__ssa_v0_pview
    ;
    const int64_t v1678 = 1;
    // pto: %indexer_raw__ssa_v0_pview
    ;
    int64_t v1679 = v1656 * v76;
    // pto: %indexer_raw__ssa_v0_pview
    ;
    int64_t v1680 = v1678 * v1679;
    // pto: %indexer_raw__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 64> v1681 = pto::Shape<1, 1, 1, -1, 64>(v1676, v1677, v1678, v1656, v76);
    // pto: %indexer_raw__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1682 = pto::Stride<-1, -1, -1, -1, -1>(v1677 * v1680, v1680, v1679, v76, v70);
    // pto: %indexer_raw__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1683 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1675 + (v1674 + v1659 * v76 + v82 * v70), v1681, v1682);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1683, v1670);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    // pto: %value_v1_inline651__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1684 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1656, v76);
    // pto: %value_v1_inline651__ssa_v0
    ;
    uint64_t v1685 = (uint64_t) v47;
    TASSIGN(v1684, v1685);
    pipe_barrier(PIPE_V);
    RoundMode v1686 = RoundMode::CAST_ROUND;
    SaturationMode v1687 = SaturationMode::ON;
    TCVT(v1684, v1670, v1686, v1687);
    // pto: %value_v2_inline652__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1688 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1656, v76);
    // pto: %value_v2_inline652__ssa_v0
    ;
    uint64_t v1689 = (uint64_t) v47;
    TASSIGN(v1688, v1689);
    pipe_barrier(PIPE_V);
    TMULS(v1688, v1684, v109);
    // pto: %weighted_inline654__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1690 = Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1656, v76);
    // pto: %weighted_inline654__ssa_v0
    ;
    uint64_t v1691 = (uint64_t) v48;
    TASSIGN(v1690, v1691);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    RoundMode v1692 = RoundMode::CAST_RINT;
    SaturationMode v1693 = SaturationMode::ON;
    TCVT(v1690, v1688, v1692, v1693);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    const int64_t v1694 = 0;
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v1695 = PTOAS__GLOBAL_TENSOR_DATA(v280);
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    const int64_t v1696 = 1;
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    const int64_t v1697 = 1;
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    const int64_t v1698 = 1;
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    int64_t v1699 = v1656 * v76;
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    int64_t v1700 = v1698 * v1699;
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 64> v1701 = pto::Shape<1, 1, 1, -1, 64>(v1696, v1697, v1698, v1656, v76);
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1702 = pto::Stride<-1, -1, -1, -1, -1>(v1697 * v1700, v1700, v1699, v76, v70);
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1703 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1695 + (v1694 + v1659 * v76 + v82 * v70), v1701, v1702);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1703, v1690);
    // pto: %result_inline650__cast_fp32_tmp_v0
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1704 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1656, v76);
    // pto: %result_inline650__cast_fp32_tmp_v0
    ;
    uint64_t v1705 = (uint64_t) v47;
    TASSIGN(v1704, v1705);
    pipe_barrier(PIPE_V);
    RoundMode v1706 = RoundMode::CAST_RINT;
    SaturationMode v1707 = SaturationMode::ON;
    TCVT(v1704, v1690, v1706, v1707);
    // pto: %result_inline650__ssa_v0
    ;
    Tile<TileType::Vec, half, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1708 = Tile<TileType::Vec, half, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1656, v76);
    // pto: %result_inline650__ssa_v0
    ;
    uint64_t v1709 = (uint64_t) v47;
    TASSIGN(v1708, v1709);
    pipe_barrier(PIPE_V);
    RoundMode v1710 = RoundMode::CAST_RINT;
    SaturationMode v1711 = SaturationMode::ON;
    TCVT(v1708, v1704, v1710, v1711);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %indexer_weights__ssa_v0_pview
    ;
    const int64_t v1712 = 0;
    // pto: %indexer_weights__ssa_v0_pview
    ;
    __gm__ half* v1713 = PTOAS__GLOBAL_TENSOR_DATA(v289);
    // pto: %indexer_weights__ssa_v0_pview
    ;
    const int64_t v1714 = 1;
    // pto: %indexer_weights__ssa_v0_pview
    ;
    const int64_t v1715 = 1;
    // pto: %indexer_weights__ssa_v0_pview
    ;
    const int64_t v1716 = 1;
    // pto: %indexer_weights__ssa_v0_pview
    ;
    int64_t v1717 = v1656 * v76;
    // pto: %indexer_weights__ssa_v0_pview
    ;
    int64_t v1718 = v1716 * v1717;
    // pto: %indexer_weights__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 64> v1719 = pto::Shape<1, 1, 1, -1, 64>(v1714, v1715, v1716, v1656, v76);
    // pto: %indexer_weights__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1720 = pto::Stride<-1, -1, -1, -1, -1>(v1715 * v1718, v1718, v1717, v76, v70);
    // pto: %indexer_weights__ssa_v0_pview
    ;
    GlobalTensor<half, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1721 = GlobalTensor<half, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1713 + (v1712 + v1659 * v76 + v82 * v70), v1719, v1720);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1721, v1708);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID5);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}