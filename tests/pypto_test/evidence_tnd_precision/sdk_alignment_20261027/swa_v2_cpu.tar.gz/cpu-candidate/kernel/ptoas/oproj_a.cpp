#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_a(__gm__ float* v1, __gm__ int32_t* v2, __gm__ bfloat16_t* v3, __gm__ bfloat16_t* v4, int64_t v5, int64_t v6, int64_t v7, int64_t v8, int64_t v9, int32_t v10, int32_t v11) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c131072_i64
  const int64_t v12 = 131072;
  // pto: %c196608_i64
  const int64_t v13 = 196608;
  // pto: %c0_i64
  const int64_t v14 = 0;
  // pto: %c32768_i64
  const int64_t v15 = 32768;
  // pto: %c65536_i64
  const int64_t v16 = 65536;
  // pto: %c8192_index
  const int64_t v17 = 8192;
  // pto: %c1_index
  const int64_t v18 = 1;
  // pto: %c16_index
  const int64_t v19 = 16;
  // pto: %c8_index
  const int64_t v20 = 8;
  // pto: %c32768_index
  const int64_t v21 = 32768;
  const int64_t v22 = 64;
  // pto: %c256_index
  const int64_t v23 = 256;
  // pto: %c4194304_index
  const int64_t v24 = 4194304;
  // pto: %c65536_index
  const int64_t v25 = 65536;
  const int64_t v26 = 128;
  // pto: %c0_index
  const int64_t v27 = 0;
  // pto: %c7_index
  const int64_t v28 = 7;
  // pto: %c2_index
  const int64_t v29 = 2;
  // pto: %c3_index
  const int64_t v30 = 3;
  // pto: %c4_index
  const int64_t v31 = 4;
  // pto: %c5_index
  const int64_t v32 = 5;
  // pto: %c6_index
  const int64_t v33 = 6;
  // pto: %c240_index
  const int64_t v34 = 240;
  // pto: %c4096_index
  const int64_t v35 = 4096;
  // pto: %c15_index
  const int64_t v36 = 15;
  // pto: %c1024_index
  const int64_t v37 = 1024;
  // pto: %c127_index
  const int64_t v38 = 127;
  // pto: %313
  int64_t v39 = (int64_t) ((uint64_t) v8 + (uint64_t) v38);
  // pto: %accum_inline1060__iter_v1_view
  const int64_t v40 = 1;
  // pto: %accum_inline1060__iter_v1_view
  const int64_t v41 = 1;
  // pto: %accum_inline1060__iter_v1_view
  const int64_t v42 = 1;
  // pto: %accum_inline1060__iter_v1_view
  int64_t v43 = v39 * v17;
  // pto: %accum_inline1060__iter_v1_view
  int64_t v44 = v42 * v43;
  // pto: %accum_inline1060__iter_v1_view
  pto::Shape<1, 1, 1, -1, -1> v45 = pto::Shape<1, 1, 1, -1, -1>(v40, v41, v42, v39, v17);
  // pto: %accum_inline1060__iter_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v46 = pto::Stride<-1, -1, -1, -1, -1>(v41 * v44, v44, v43, v17, v18);
  // pto: %accum_inline1060__iter_v1_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v47 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v45, v46);
  // pto: %heads__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %heads__ssa_v0_view
  int64_t v51 = (int64_t) v9;
  // pto: %heads__ssa_v0_view
  int64_t v52 = v51 * v21;
  // pto: %heads__ssa_v0_view
  int64_t v53 = v50 * v52;
  // pto: %heads__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v54 = pto::Shape<1, 1, 1, -1, -1>(v48, v49, v50, v51, v21);
  // pto: %heads__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v55 = pto::Stride<-1, -1, -1, -1, -1>(v49 * v53, v53, v52, v21, v18);
  // pto: %heads__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v56 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v54, v55);
  // pto: %wo_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v57 = pto::Shape<-1, -1, -1, -1, -1>(v20, v22, v23, v19, v19);
  // pto: %wo_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v58 = pto::Stride<-1, -1, -1, -1, -1>(v24, v25, v23, v19, v18);
  // pto: %wo_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v59 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v4, v57, v58);
  // pto: %seed_fast_acc_inline1037__phi_v7
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v60 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v26);
  // pto: %seed_fast_acc_inline1037__phi_v7
  uint64_t v61 = (uint64_t) v14;
  TASSIGN(v60, v61);
  // pto: %183
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v62 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v26);
  // pto: %183
  uint64_t v63 = (uint64_t) v14;
  TASSIGN(v62, v63);
  // pto: %221
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v64 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v26);
  // pto: %221
  uint64_t v65 = (uint64_t) v14;
  TASSIGN(v64, v65);
  // pto: %seed_narrow_acc_inline1031__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v66 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v19, v26);
  // pto: %seed_narrow_acc_inline1031__phi_v7
  uint64_t v67 = (uint64_t) v14;
  TASSIGN(v66, v67);
  // pto: %seed_block_inline1056__ssa_v0
  int64_t v68 = (int64_t) v10;
  // pto: %37
  int64_t v69 = (int64_t) ((uint64_t) v68 * (uint64_t) v26);
  // pto: %38, %39
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  for (int64_t v70 = v27; v70 < ((int64_t) ((uint64_t) v5 + (uint64_t) v28) / v20); v70 += v18) {
    // pto: %40
    ;
    int64_t v71 = (int64_t) ((uint64_t) v70 * (uint64_t) v20);
    // pto: %flat_offset, %41, %42, %t__tile
    ;
    int32_t v72 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v70 * (uint64_t) v22) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
    // pto: %43
    ;
    int64_t v73 = (int64_t) v72;
    // pto: %44
    ;
    int64_t v74 = v73 < v27 ? v27 : v73;
    // pto: %45
    ;
    int64_t v75 = (int64_t) ((uint64_t) v71 + (uint64_t) v18);
    // pto: %46
    ;
    // pto: %seed_same_start_inline1045__phi_v3
    ;
    int64_t v76;
    if (v75 < v5) {
      // pto: %49, %50, %51, %52, %47
      ;
      int32_t v77 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v75 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
      // pto: %53
      ;
      int64_t v78 = (int64_t) v77;
      // pto: %54
      ;
      int64_t v79 = v78 < v27 ? v27 : v78;
      // pto: %55, %seed_same_start_inline1045__phi_v2
      ;
      v76 = v79 != v74 ? v27 : v18;
    } else {
      v76 = v18;
    };
    // pto: %56
    ;
    int64_t v80 = (int64_t) ((uint64_t) v71 + (uint64_t) v29);
    // pto: %57
    ;
    // pto: %seed_same_start_inline1045__phi_v6
    ;
    int64_t v81;
    if (v80 < v5) {
      // pto: %60, %61, %62, %63, %58
      ;
      int32_t v82 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v80 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
      // pto: %64
      ;
      int64_t v83 = (int64_t) v82;
      // pto: %65
      ;
      int64_t v84 = v83 < v27 ? v27 : v83;
      // pto: %66, %seed_same_start_inline1045__phi_v5
      ;
      int64_t v85 = v84 != v74 ? v27 : v76;
      v81 = v85;
    } else {
      v81 = v76;
    };
    // pto: %67
    ;
    int64_t v86 = (int64_t) ((uint64_t) v71 + (uint64_t) v30);
    // pto: %68
    ;
    // pto: %seed_same_start_inline1045__phi_v9
    ;
    int64_t v87;
    if (v86 < v5) {
      // pto: %71, %72, %73, %74, %69
      ;
      int32_t v88 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v86 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
      // pto: %75
      ;
      int64_t v89 = (int64_t) v88;
      // pto: %76
      ;
      int64_t v90 = v89 < v27 ? v27 : v89;
      // pto: %77, %seed_same_start_inline1045__phi_v8
      ;
      int64_t v91 = v90 != v74 ? v27 : v81;
      v87 = v91;
    } else {
      v87 = v81;
    };
    // pto: %78
    ;
    int64_t v92 = (int64_t) ((uint64_t) v71 + (uint64_t) v31);
    // pto: %79
    ;
    // pto: %seed_same_start_inline1045__phi_v12
    ;
    int64_t v93;
    if (v92 < v5) {
      // pto: %82, %83, %84, %85, %80
      ;
      int32_t v94 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v92 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
      // pto: %86
      ;
      int64_t v95 = (int64_t) v94;
      // pto: %87
      ;
      int64_t v96 = v95 < v27 ? v27 : v95;
      // pto: %88, %seed_same_start_inline1045__phi_v11
      ;
      int64_t v97 = v96 != v74 ? v27 : v87;
      v93 = v97;
    } else {
      v93 = v87;
    };
    // pto: %89
    ;
    int64_t v98 = (int64_t) ((uint64_t) v71 + (uint64_t) v32);
    // pto: %90
    ;
    // pto: %seed_same_start_inline1045__phi_v15
    ;
    int64_t v99;
    if (v98 < v5) {
      // pto: %93, %94, %95, %96, %91
      ;
      int32_t v100 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v98 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
      // pto: %97
      ;
      int64_t v101 = (int64_t) v100;
      // pto: %98
      ;
      int64_t v102 = v101 < v27 ? v27 : v101;
      // pto: %99, %seed_same_start_inline1045__phi_v14
      ;
      int64_t v103 = v102 != v74 ? v27 : v93;
      v99 = v103;
    } else {
      v99 = v93;
    };
    // pto: %100
    ;
    int64_t v104 = (int64_t) ((uint64_t) v71 + (uint64_t) v33);
    // pto: %101
    ;
    // pto: %seed_same_start_inline1045__phi_v18
    ;
    int64_t v105;
    if (v104 < v5) {
      // pto: %104, %105, %106, %107, %102
      ;
      int32_t v106 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v104 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
      // pto: %108
      ;
      int64_t v107 = (int64_t) v106;
      // pto: %109
      ;
      int64_t v108 = v107 < v27 ? v27 : v107;
      // pto: %110, %seed_same_start_inline1045__phi_v17
      ;
      int64_t v109 = v108 != v74 ? v27 : v99;
      v105 = v109;
    } else {
      v105 = v99;
    };
    // pto: %111
    ;
    int64_t v110 = (int64_t) ((uint64_t) v71 + (uint64_t) v28);
    // pto: %112
    ;
    // pto: %seed_same_start_inline1045__phi_v21
    ;
    int64_t v111;
    if (v110 < v5) {
      // pto: %115, %116, %117, %118, %113
      ;
      int32_t v112 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v110 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
      // pto: %119
      ;
      int64_t v113 = (int64_t) v112;
      // pto: %120
      ;
      int64_t v114 = v113 < v27 ? v27 : v113;
      // pto: %121, %seed_same_start_inline1045__phi_v20
      ;
      int64_t v115 = v114 != v74 ? v27 : v105;
      v111 = v115;
    } else {
      v111 = v105;
    };
    // pto: %122, %seed_same_start_inline1045__phi_v25
    ;
    int64_t v116 = v74 > v34 ? v27 : v111;
    // pto: %123
    ;
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    if (v116 == v18) {
      int64_t v117 = (int64_t) ((uint64_t) v70 * (uint64_t) v26);
      // pto: %125
      ;
      int64_t v118 = (int64_t) ((uint64_t) v8 - (uint64_t) v117);
      // pto: %126
      ;
      int64_t v119 = v118 < v26 ? v118 : v26;
      // pto: %127
      ;
      int64_t v120 = (int64_t) ((uint64_t) v74 * (uint64_t) v19);
      // pto: %seed_fast_seed_x_inline1094__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v119, v23);
      // pto: %seed_fast_seed_x_inline1094__tile
      ;
      uint64_t v122 = (uint64_t) v12;
      TASSIGN(v121, v122);
      // pto: %128
      ;
      int64_t v123 = v117 < v27 ? v27 : v117;
      // pto: %129
      ;
      int64_t v124 = (int64_t) ((uint64_t) v6 * (uint64_t) v35);
      // pto: %130
      ;
      int64_t v125 = (int64_t) ((uint64_t) v124 + (uint64_t) v120);
      // pto: %131
      ;
      int64_t v126 = v125 < v27 ? v27 : v125;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v127 = 0;
      // pto: %heads__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v128 = PTOAS__GLOBAL_TENSOR_DATA(v56);
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v129 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v130 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v131 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      int64_t v132 = v119 * v21;
      // pto: %heads__ssa_v0_pview
      ;
      int64_t v133 = v131 * v132;
      // pto: %heads__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 256> v134 = pto::Shape<1, 1, 1, -1, 256>(v129, v130, v131, v119, v23);
      // pto: %heads__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v135 = pto::Stride<-1, -1, -1, -1, -1>(v130 * v133, v133, v132, v21, v18);
      // pto: %heads__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v136 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v128 + (v127 + v123 * v21 + v126 * v18), v134, v135);
      TLOAD(v121, v136);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %seed_fast_seed_w_inline1107__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
      // pto: %seed_fast_seed_w_inline1107__tile
      ;
      uint64_t v138 = (uint64_t) v13;
      TASSIGN(v137, v138);
      // pto: %132
      ;
      int64_t v139 = v6 < v27 ? v27 : v6;
      // pto: %133
      ;
      int64_t v140 = v69 / v19;
      // pto: %134
      ;
      int64_t v141 = v140 < v27 ? v27 : v140;
      // pto: %135
      ;
      int64_t v142 = v120 / v19;
      // pto: %136
      ;
      int64_t v143 = v142 < v27 ? v27 : v142;
      // pto: %wo_a__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v144 = PTOAS__GLOBAL_TENSOR_DATA(v59);
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v145 = 0;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v146 = 4194304;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v147 = 65536;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v148 = 256;
      // pto: %wo_a__ssa_v0_pview
      ;
      pto::Shape<1, 8, 16, 16, 16> v149 = pto::Shape<1, 8, 16, 16, 16>();
      // pto: %wo_a__ssa_v0_pview
      ;
      pto::Stride<4194304, 65536, 256, 16, 1> v150 = pto::Stride<4194304, 65536, 256, 16, 1>();
      // pto: %wo_a__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v151 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v144 + ((v145 + v139 * v146) + v141 * v147 + v143 * v148), v149, v150);
      TLOAD(v137, v151);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %seed_fast_acc_inline1037__tile_l0_init_storage
      ;
      Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v152 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v26);
      // pto: %seed_fast_acc_inline1037__tile_l0_init_storage
      ;
      uint64_t v153 = (uint64_t) v14;
      TASSIGN(v152, v153);
      v152.SetValidShape(v119, v26);
      // pto: %seed_fast_acc_inline1037__tile_l0_a
      ;
      Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v154 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v119, v26);
      // pto: %seed_fast_acc_inline1037__tile_l0_a
      ;
      uint64_t v155 = (uint64_t) v14;
      TASSIGN(v154, v155);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      uint16_t v156 = static_cast<uint16_t>(v27);
      uint16_t v157 = static_cast<uint16_t>(v27);
      TEXTRACT(v154, v121, v156, v157);
      // pto: %seed_fast_acc_inline1037__tile_l0_b
      ;
      Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v158 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
      // pto: %seed_fast_acc_inline1037__tile_l0_b
      ;
      uint64_t v159 = (uint64_t) v15;
      TASSIGN(v158, v159);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      uint16_t v160 = static_cast<uint16_t>(v27);
      uint16_t v161 = static_cast<uint16_t>(v27);
      TEXTRACT(v158, v137, v160, v161);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %0
      ;
      Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v162 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v119, v26);
      // pto: %0
      ;
      uint64_t v163 = (uint64_t) v15;
      TASSIGN(v162, v163);
      uint16_t v164 = static_cast<uint16_t>(v27);
      uint16_t v165 = static_cast<uint16_t>(v26);
      TEXTRACT(v162, v121, v164, v165);
      // pto: %1
      ;
      Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v166 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
      // pto: %1
      ;
      uint64_t v167 = (uint64_t) v14;
      TASSIGN(v166, v167);
      uint16_t v168 = static_cast<uint16_t>(v26);
      uint16_t v169 = static_cast<uint16_t>(v27);
      TEXTRACT(v166, v137, v168, v169);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      TMATMUL(v152, v154, v158);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v152, v152, v162, v166);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      for (int64_t v170 = v18; v170 < v36; v170 += v29) {
        // pto: %137
        ;
        int64_t v171 = (int64_t) ((uint64_t) v170 * (uint64_t) v19);
        // pto: %138, %139
        ;
        int64_t v172 = (int64_t) ((uint64_t) v74 + (uint64_t) v171) % v23;
        // pto: %140, %141, %142
        ;
        int64_t v173 = v172 < v27 ? (int64_t) ((uint64_t) v172 + (uint64_t) v23) : v172;
        // pto: %145, %144, %146
        ;
        int64_t v174 = (int64_t) ((uint64_t) v74 + (uint64_t) ((int64_t) (uint64_t) v171 + (uint64_t) v19)) % v23;
        // pto: %147, %148, %149
        ;
        int64_t v175 = v174 < v27 ? (int64_t) ((uint64_t) v174 + (uint64_t) v23) : v174;
        // pto: %150
        ;
        // pto: %151
        ;
        int64_t v176 = v119 < v26 ? v119 : v26;
        v60.SetValidShape(v176, v26);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        if (v173 <= v34) {
          // pto: %152
          ;
          int64_t v177 = (int64_t) ((uint64_t) v173 * (uint64_t) v19);
          // pto: %seed_fast_packet_x_inline1066__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v178 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v119, v23);
          // pto: %seed_fast_packet_x_inline1066__tile
          ;
          uint64_t v179 = (uint64_t) v12;
          TASSIGN(v178, v179);
          // pto: %155
          ;
          int64_t v180 = (int64_t) ((uint64_t) v124 + (uint64_t) v177);
          // pto: %156
          ;
          int64_t v181 = v180 < v27 ? v27 : v180;
          // pto: %157
          ;
          const int64_t v182 = 0;
          // pto: %157
          ;
          __gm__ bfloat16_t* v183 = PTOAS__GLOBAL_TENSOR_DATA(v56);
          // pto: %157
          ;
          const int64_t v184 = 1;
          // pto: %157
          ;
          const int64_t v185 = 1;
          // pto: %157
          ;
          const int64_t v186 = 1;
          // pto: %157
          ;
          int64_t v187 = v119 * v21;
          // pto: %157
          ;
          int64_t v188 = v186 * v187;
          // pto: %157
          ;
          pto::Shape<1, 1, 1, -1, 256> v189 = pto::Shape<1, 1, 1, -1, 256>(v184, v185, v186, v119, v23);
          // pto: %157
          ;
          pto::Stride<-1, -1, -1, -1, -1> v190 = pto::Stride<-1, -1, -1, -1, -1>(v185 * v188, v188, v187, v21, v18);
          // pto: %157
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v191 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v183 + (v182 + v123 * v21 + v181 * v18), v189, v190);
          TLOAD(v178, v191);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
          // pto: %seed_fast_packet_w_inline1068__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v192 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
          // pto: %seed_fast_packet_w_inline1068__tile
          ;
          uint64_t v193 = (uint64_t) v13;
          TASSIGN(v192, v193);
          // pto: %161
          ;
          int64_t v194 = v177 / v19;
          // pto: %162
          ;
          int64_t v195 = v194 < v27 ? v27 : v194;
          // pto: %163
          ;
          __gm__ bfloat16_t* v196 = PTOAS__GLOBAL_TENSOR_DATA(v59);
          // pto: %163
          ;
          const int64_t v197 = 0;
          // pto: %163
          ;
          const int64_t v198 = 4194304;
          // pto: %163
          ;
          const int64_t v199 = 65536;
          // pto: %163
          ;
          const int64_t v200 = 256;
          // pto: %163
          ;
          pto::Shape<1, 8, 16, 16, 16> v201 = pto::Shape<1, 8, 16, 16, 16>();
          // pto: %163
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v202 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %163
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v203 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v196 + ((v197 + v139 * v198) + v141 * v199 + v195 * v200), v201, v202);
          TLOAD(v192, v203);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
          // pto: %seed_fast_acc_inline1037__iter_v1_l0_a
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v204 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v119, v26);
          // pto: %seed_fast_acc_inline1037__iter_v1_l0_a
          ;
          uint64_t v205 = (uint64_t) v14;
          TASSIGN(v204, v205);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
          uint16_t v206 = static_cast<uint16_t>(v27);
          uint16_t v207 = static_cast<uint16_t>(v27);
          TEXTRACT(v204, v178, v206, v207);
          // pto: %seed_fast_acc_inline1037__iter_v1_l0_b
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v208 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %seed_fast_acc_inline1037__iter_v1_l0_b
          ;
          uint64_t v209 = (uint64_t) v15;
          TASSIGN(v208, v209);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
          uint16_t v210 = static_cast<uint16_t>(v27);
          uint16_t v211 = static_cast<uint16_t>(v27);
          TEXTRACT(v208, v192, v210, v211);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
          // pto: %3
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v212 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v119, v26);
          // pto: %3
          ;
          uint64_t v213 = (uint64_t) v15;
          TASSIGN(v212, v213);
          uint16_t v214 = static_cast<uint16_t>(v27);
          uint16_t v215 = static_cast<uint16_t>(v26);
          TEXTRACT(v212, v178, v214, v215);
          // pto: %4
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v216 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %4
          ;
          uint64_t v217 = (uint64_t) v14;
          TASSIGN(v216, v217);
          uint16_t v218 = static_cast<uint16_t>(v26);
          uint16_t v219 = static_cast<uint16_t>(v27);
          TEXTRACT(v216, v192, v218, v219);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v152, v152, v204, v208);
          pipe_barrier(PIPE_M);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
          TMATMUL_ACC(v152, v152, v212, v216);
        } else {
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
          for (int64_t v220 = v27; v220 < v19; v220 += v18) {
            // pto: %164, %165
            ;
            int64_t v221 = (int64_t) ((uint64_t) v173 + (uint64_t) v220) % v23;
            // pto: %166, %167, %168
            ;
            int64_t v222 = v221 < v27 ? (int64_t) ((uint64_t) v221 + (uint64_t) v23) : v221;
            // pto: %169
            ;
            int64_t v223 = (int64_t) ((uint64_t) v222 * (uint64_t) v19);
            // pto: %seed_fast_wrap_x_inline1064__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v224 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v119, v19);
            // pto: %seed_fast_wrap_x_inline1064__tile
            ;
            uint64_t v225 = (uint64_t) v12;
            TASSIGN(v224, v225);
            // pto: %172
            ;
            int64_t v226 = (int64_t) ((uint64_t) v124 + (uint64_t) v223);
            // pto: %173
            ;
            int64_t v227 = v226 < v27 ? v27 : v226;
            // pto: %174
            ;
            const int64_t v228 = 0;
            // pto: %174
            ;
            __gm__ bfloat16_t* v229 = PTOAS__GLOBAL_TENSOR_DATA(v56);
            // pto: %174
            ;
            const int64_t v230 = 1;
            // pto: %174
            ;
            const int64_t v231 = 1;
            // pto: %174
            ;
            const int64_t v232 = 1;
            // pto: %174
            ;
            int64_t v233 = v119 * v21;
            // pto: %174
            ;
            int64_t v234 = v232 * v233;
            // pto: %174
            ;
            pto::Shape<1, 1, 1, -1, 16> v235 = pto::Shape<1, 1, 1, -1, 16>(v230, v231, v232, v119, v19);
            // pto: %174
            ;
            pto::Stride<-1, -1, -1, -1, -1> v236 = pto::Stride<-1, -1, -1, -1, -1>(v231 * v234, v234, v233, v21, v18);
            // pto: %174
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v237 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v229 + (v228 + v123 * v21 + v227 * v18), v235, v236);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            TLOAD(v224, v237);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
            // pto: %seed_fast_wrap_w_inline1071__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v238 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %seed_fast_wrap_w_inline1071__tile
            ;
            uint64_t v239 = (uint64_t) v13;
            TASSIGN(v238, v239);
            // pto: %178
            ;
            int64_t v240 = v223 / v19;
            // pto: %179
            ;
            int64_t v241 = v240 < v27 ? v27 : v240;
            // pto: %180
            ;
            __gm__ bfloat16_t* v242 = PTOAS__GLOBAL_TENSOR_DATA(v59);
            // pto: %180
            ;
            const int64_t v243 = 0;
            // pto: %180
            ;
            const int64_t v244 = 4194304;
            // pto: %180
            ;
            const int64_t v245 = 65536;
            // pto: %180
            ;
            const int64_t v246 = 256;
            // pto: %180
            ;
            pto::Shape<1, 8, 1, 16, 16> v247 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %180
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v248 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %180
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v249 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v242 + ((v243 + v139 * v244) + v141 * v245 + v241 * v246), v247, v248);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
            TLOAD(v238, v249);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
            // pto: %lhs_slice_0_textract
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v250 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v119, v19);
            // pto: %lhs_slice_0_textract
            ;
            uint64_t v251 = (uint64_t) v14;
            TASSIGN(v250, v251);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
            uint16_t v252 = static_cast<uint16_t>(v27);
            uint16_t v253 = static_cast<uint16_t>(v27);
            TEXTRACT(v250, v224, v252, v253);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            // pto: %rhs_slice_0_textract
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v254 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %rhs_slice_0_textract
            ;
            uint64_t v255 = (uint64_t) v15;
            TASSIGN(v254, v255);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
            uint16_t v256 = static_cast<uint16_t>(v27);
            uint16_t v257 = static_cast<uint16_t>(v27);
            TEXTRACT(v254, v238, v256, v257);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v152, v152, v250, v254);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          };
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        };
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        // pto: %181
        ;
        v62.SetValidShape(v176, v26);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        if (v175 <= v34) {
          // pto: %184
          ;
          int64_t v258 = (int64_t) ((uint64_t) v175 * (uint64_t) v19);
          // pto: %6
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v259 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v119, v23);
          // pto: %6
          ;
          uint64_t v260 = (uint64_t) v14;
          TASSIGN(v259, v260);
          // pto: %187
          ;
          int64_t v261 = (int64_t) ((uint64_t) v124 + (uint64_t) v258);
          // pto: %188
          ;
          int64_t v262 = v261 < v27 ? v27 : v261;
          // pto: %189
          ;
          const int64_t v263 = 0;
          // pto: %189
          ;
          __gm__ bfloat16_t* v264 = PTOAS__GLOBAL_TENSOR_DATA(v56);
          // pto: %189
          ;
          const int64_t v265 = 1;
          // pto: %189
          ;
          const int64_t v266 = 1;
          // pto: %189
          ;
          const int64_t v267 = 1;
          // pto: %189
          ;
          int64_t v268 = v119 * v21;
          // pto: %189
          ;
          int64_t v269 = v267 * v268;
          // pto: %189
          ;
          pto::Shape<1, 1, 1, -1, 256> v270 = pto::Shape<1, 1, 1, -1, 256>(v265, v266, v267, v119, v23);
          // pto: %189
          ;
          pto::Stride<-1, -1, -1, -1, -1> v271 = pto::Stride<-1, -1, -1, -1, -1>(v266 * v269, v269, v268, v21, v18);
          // pto: %189
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v272 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v264 + (v263 + v123 * v21 + v262 * v18), v270, v271);
          TLOAD(v259, v272);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
          // pto: %7
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v273 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
          // pto: %7
          ;
          uint64_t v274 = (uint64_t) v16;
          TASSIGN(v273, v274);
          // pto: %193
          ;
          int64_t v275 = v258 / v19;
          // pto: %194
          ;
          int64_t v276 = v275 < v27 ? v27 : v275;
          // pto: %195
          ;
          __gm__ bfloat16_t* v277 = PTOAS__GLOBAL_TENSOR_DATA(v59);
          // pto: %195
          ;
          const int64_t v278 = 0;
          // pto: %195
          ;
          const int64_t v279 = 4194304;
          // pto: %195
          ;
          const int64_t v280 = 65536;
          // pto: %195
          ;
          const int64_t v281 = 256;
          // pto: %195
          ;
          pto::Shape<1, 8, 16, 16, 16> v282 = pto::Shape<1, 8, 16, 16, 16>();
          // pto: %195
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v283 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %195
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v284 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v277 + ((v278 + v139 * v279) + v141 * v280 + v276 * v281), v282, v283);
          TLOAD(v273, v284);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
          // pto: %8
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v285 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v119, v26);
          // pto: %8
          ;
          uint64_t v286 = (uint64_t) v14;
          TASSIGN(v285, v286);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
          uint16_t v287 = static_cast<uint16_t>(v27);
          uint16_t v288 = static_cast<uint16_t>(v27);
          TEXTRACT(v285, v259, v287, v288);
          // pto: %9
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v289 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %9
          ;
          uint64_t v290 = (uint64_t) v15;
          TASSIGN(v289, v290);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
          uint16_t v291 = static_cast<uint16_t>(v27);
          uint16_t v292 = static_cast<uint16_t>(v27);
          TEXTRACT(v289, v273, v291, v292);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
          // pto: %10
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v293 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v119, v26);
          // pto: %10
          ;
          uint64_t v294 = (uint64_t) v15;
          TASSIGN(v293, v294);
          uint16_t v295 = static_cast<uint16_t>(v27);
          uint16_t v296 = static_cast<uint16_t>(v26);
          TEXTRACT(v293, v259, v295, v296);
          // pto: %11
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v297 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %11
          ;
          uint64_t v298 = (uint64_t) v14;
          TASSIGN(v297, v298);
          uint16_t v299 = static_cast<uint16_t>(v26);
          uint16_t v300 = static_cast<uint16_t>(v27);
          TEXTRACT(v297, v273, v299, v300);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v60, v60, v285, v289);
          pipe_barrier(PIPE_M);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
          TMATMUL_ACC(v60, v60, v293, v297);
        } else {
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
          for (int64_t v301 = v27; v301 < v19; v301 += v18) {
            // pto: %197, %198
            ;
            int64_t v302 = (int64_t) ((uint64_t) v175 + (uint64_t) v301) % v23;
            // pto: %199, %200, %201
            ;
            int64_t v303 = v302 < v27 ? (int64_t) ((uint64_t) v302 + (uint64_t) v23) : v302;
            // pto: %202
            ;
            int64_t v304 = (int64_t) ((uint64_t) v303 * (uint64_t) v19);
            // pto: %14
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v305 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v119, v19);
            // pto: %14
            ;
            uint64_t v306 = (uint64_t) v14;
            TASSIGN(v305, v306);
            // pto: %205
            ;
            int64_t v307 = (int64_t) ((uint64_t) v124 + (uint64_t) v304);
            // pto: %206
            ;
            int64_t v308 = v307 < v27 ? v27 : v307;
            // pto: %207
            ;
            const int64_t v309 = 0;
            // pto: %207
            ;
            __gm__ bfloat16_t* v310 = PTOAS__GLOBAL_TENSOR_DATA(v56);
            // pto: %207
            ;
            const int64_t v311 = 1;
            // pto: %207
            ;
            const int64_t v312 = 1;
            // pto: %207
            ;
            const int64_t v313 = 1;
            // pto: %207
            ;
            int64_t v314 = v119 * v21;
            // pto: %207
            ;
            int64_t v315 = v313 * v314;
            // pto: %207
            ;
            pto::Shape<1, 1, 1, -1, 16> v316 = pto::Shape<1, 1, 1, -1, 16>(v311, v312, v313, v119, v19);
            // pto: %207
            ;
            pto::Stride<-1, -1, -1, -1, -1> v317 = pto::Stride<-1, -1, -1, -1, -1>(v312 * v315, v315, v314, v21, v18);
            // pto: %207
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v318 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v310 + (v309 + v123 * v21 + v308 * v18), v316, v317);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
            TLOAD(v305, v318);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %15
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v319 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %15
            ;
            uint64_t v320 = (uint64_t) v16;
            TASSIGN(v319, v320);
            // pto: %211
            ;
            int64_t v321 = v304 / v19;
            // pto: %212
            ;
            int64_t v322 = v321 < v27 ? v27 : v321;
            // pto: %213
            ;
            __gm__ bfloat16_t* v323 = PTOAS__GLOBAL_TENSOR_DATA(v59);
            // pto: %213
            ;
            const int64_t v324 = 0;
            // pto: %213
            ;
            const int64_t v325 = 4194304;
            // pto: %213
            ;
            const int64_t v326 = 65536;
            // pto: %213
            ;
            const int64_t v327 = 256;
            // pto: %213
            ;
            pto::Shape<1, 8, 1, 16, 16> v328 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %213
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v329 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %213
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v330 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v323 + ((v324 + v139 * v325) + v141 * v326 + v322 * v327), v328, v329);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
            TLOAD(v319, v330);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %16
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v331 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v119, v19);
            // pto: %16
            ;
            uint64_t v332 = (uint64_t) v14;
            TASSIGN(v331, v332);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
            uint16_t v333 = static_cast<uint16_t>(v27);
            uint16_t v334 = static_cast<uint16_t>(v27);
            TEXTRACT(v331, v305, v333, v334);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
            // pto: %17
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v335 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %17
            ;
            uint64_t v336 = (uint64_t) v15;
            TASSIGN(v335, v336);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            uint16_t v337 = static_cast<uint16_t>(v27);
            uint16_t v338 = static_cast<uint16_t>(v27);
            TEXTRACT(v335, v319, v337, v338);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v60, v60, v331, v335);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
          };
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        };
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      // pto: %214, %215
      ;
      int64_t v339 = (int64_t) ((uint64_t) v74 + (uint64_t) v34) % v23;
      // pto: %216, %217, %218
      ;
      int64_t v340 = v339 < v27 ? (int64_t) ((uint64_t) v339 + (uint64_t) v23) : v339;
      // pto: %219
      ;
      // pto: %220
      ;
      int64_t v341 = v119 < v26 ? v119 : v26;
      v64.SetValidShape(v341, v26);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      if (v340 <= v34) {
        // pto: %222
        ;
        int64_t v342 = (int64_t) ((uint64_t) v340 * (uint64_t) v19);
        // pto: %19
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v343 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v119, v23);
        // pto: %19
        ;
        uint64_t v344 = (uint64_t) v12;
        TASSIGN(v343, v344);
        // pto: %225
        ;
        int64_t v345 = (int64_t) ((uint64_t) v124 + (uint64_t) v342);
        // pto: %226
        ;
        int64_t v346 = v345 < v27 ? v27 : v345;
        // pto: %227
        ;
        const int64_t v347 = 0;
        // pto: %227
        ;
        __gm__ bfloat16_t* v348 = PTOAS__GLOBAL_TENSOR_DATA(v56);
        // pto: %227
        ;
        const int64_t v349 = 1;
        // pto: %227
        ;
        const int64_t v350 = 1;
        // pto: %227
        ;
        const int64_t v351 = 1;
        // pto: %227
        ;
        int64_t v352 = v119 * v21;
        // pto: %227
        ;
        int64_t v353 = v351 * v352;
        // pto: %227
        ;
        pto::Shape<1, 1, 1, -1, 256> v354 = pto::Shape<1, 1, 1, -1, 256>(v349, v350, v351, v119, v23);
        // pto: %227
        ;
        pto::Stride<-1, -1, -1, -1, -1> v355 = pto::Stride<-1, -1, -1, -1, -1>(v350 * v353, v353, v352, v21, v18);
        // pto: %227
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v356 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v348 + (v347 + v123 * v21 + v346 * v18), v354, v355);
        TLOAD(v343, v356);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %20
        ;
        Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v357 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
        // pto: %20
        ;
        uint64_t v358 = (uint64_t) v13;
        TASSIGN(v357, v358);
        // pto: %231
        ;
        int64_t v359 = v342 / v19;
        // pto: %232
        ;
        int64_t v360 = v359 < v27 ? v27 : v359;
        // pto: %233
        ;
        __gm__ bfloat16_t* v361 = PTOAS__GLOBAL_TENSOR_DATA(v59);
        // pto: %233
        ;
        const int64_t v362 = 0;
        // pto: %233
        ;
        const int64_t v363 = 4194304;
        // pto: %233
        ;
        const int64_t v364 = 65536;
        // pto: %233
        ;
        const int64_t v365 = 256;
        // pto: %233
        ;
        pto::Shape<1, 8, 16, 16, 16> v366 = pto::Shape<1, 8, 16, 16, 16>();
        // pto: %233
        ;
        pto::Stride<4194304, 65536, 256, 16, 1> v367 = pto::Stride<4194304, 65536, 256, 16, 1>();
        // pto: %233
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v368 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v361 + ((v362 + v139 * v363) + v141 * v364 + v360 * v365), v366, v367);
        TLOAD(v357, v368);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %21
        ;
        Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v369 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v119, v26);
        // pto: %21
        ;
        uint64_t v370 = (uint64_t) v14;
        TASSIGN(v369, v370);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        uint16_t v371 = static_cast<uint16_t>(v27);
        uint16_t v372 = static_cast<uint16_t>(v27);
        TEXTRACT(v369, v343, v371, v372);
        // pto: %22
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v373 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
        // pto: %22
        ;
        uint64_t v374 = (uint64_t) v15;
        TASSIGN(v373, v374);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v375 = static_cast<uint16_t>(v27);
        uint16_t v376 = static_cast<uint16_t>(v27);
        TEXTRACT(v373, v357, v375, v376);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %23
        ;
        Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v377 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v119, v26);
        // pto: %23
        ;
        uint64_t v378 = (uint64_t) v15;
        TASSIGN(v377, v378);
        uint16_t v379 = static_cast<uint16_t>(v27);
        uint16_t v380 = static_cast<uint16_t>(v26);
        TEXTRACT(v377, v343, v379, v380);
        // pto: %24
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v381 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
        // pto: %24
        ;
        uint64_t v382 = (uint64_t) v14;
        TASSIGN(v381, v382);
        uint16_t v383 = static_cast<uint16_t>(v26);
        uint16_t v384 = static_cast<uint16_t>(v27);
        TEXTRACT(v381, v357, v383, v384);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v152, v152, v369, v373);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v152, v152, v377, v381);
      } else {
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        for (int64_t v385 = v27; v385 < v19; v385 += v18) {
          // pto: %235, %236
          ;
          int64_t v386 = (int64_t) ((uint64_t) v340 + (uint64_t) v385) % v23;
          // pto: %237, %238, %239
          ;
          int64_t v387 = v386 < v27 ? (int64_t) ((uint64_t) v386 + (uint64_t) v23) : v386;
          // pto: %240
          ;
          int64_t v388 = (int64_t) ((uint64_t) v387 * (uint64_t) v19);
          // pto: %27
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v389 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v119, v19);
          // pto: %27
          ;
          uint64_t v390 = (uint64_t) v12;
          TASSIGN(v389, v390);
          // pto: %243
          ;
          int64_t v391 = (int64_t) ((uint64_t) v124 + (uint64_t) v388);
          // pto: %244
          ;
          int64_t v392 = v391 < v27 ? v27 : v391;
          // pto: %245
          ;
          const int64_t v393 = 0;
          // pto: %245
          ;
          __gm__ bfloat16_t* v394 = PTOAS__GLOBAL_TENSOR_DATA(v56);
          // pto: %245
          ;
          const int64_t v395 = 1;
          // pto: %245
          ;
          const int64_t v396 = 1;
          // pto: %245
          ;
          const int64_t v397 = 1;
          // pto: %245
          ;
          int64_t v398 = v119 * v21;
          // pto: %245
          ;
          int64_t v399 = v397 * v398;
          // pto: %245
          ;
          pto::Shape<1, 1, 1, -1, 16> v400 = pto::Shape<1, 1, 1, -1, 16>(v395, v396, v397, v119, v19);
          // pto: %245
          ;
          pto::Stride<-1, -1, -1, -1, -1> v401 = pto::Stride<-1, -1, -1, -1, -1>(v396 * v399, v399, v398, v21, v18);
          // pto: %245
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v402 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v394 + (v393 + v123 * v21 + v392 * v18), v400, v401);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          TLOAD(v389, v402);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %28
          ;
          Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v403 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
          // pto: %28
          ;
          uint64_t v404 = (uint64_t) v13;
          TASSIGN(v403, v404);
          // pto: %249
          ;
          int64_t v405 = v388 / v19;
          // pto: %250
          ;
          int64_t v406 = v405 < v27 ? v27 : v405;
          // pto: %251
          ;
          __gm__ bfloat16_t* v407 = PTOAS__GLOBAL_TENSOR_DATA(v59);
          // pto: %251
          ;
          const int64_t v408 = 0;
          // pto: %251
          ;
          const int64_t v409 = 4194304;
          // pto: %251
          ;
          const int64_t v410 = 65536;
          // pto: %251
          ;
          const int64_t v411 = 256;
          // pto: %251
          ;
          pto::Shape<1, 8, 1, 16, 16> v412 = pto::Shape<1, 8, 1, 16, 16>();
          // pto: %251
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v413 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %251
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v414 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v407 + ((v408 + v139 * v409) + v141 * v410 + v406 * v411), v412, v413);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          TLOAD(v403, v414);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %29
          ;
          Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v415 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v119, v19);
          // pto: %29
          ;
          uint64_t v416 = (uint64_t) v14;
          TASSIGN(v415, v416);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
          uint16_t v417 = static_cast<uint16_t>(v27);
          uint16_t v418 = static_cast<uint16_t>(v27);
          TEXTRACT(v415, v389, v417, v418);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %30
          ;
          Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v419 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
          // pto: %30
          ;
          uint64_t v420 = (uint64_t) v15;
          TASSIGN(v419, v420);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          uint16_t v421 = static_cast<uint16_t>(v27);
          uint16_t v422 = static_cast<uint16_t>(v27);
          TEXTRACT(v419, v403, v421, v422);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v152, v152, v415, v419);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        };
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      };
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      // pto: %seed_fast_acc_inline1037__rv_v2
      ;
      Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v423 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v119, v26);
      // pto: %seed_fast_acc_inline1037__rv_v2
      ;
      uint64_t v424 = (uint64_t) v14;
      TASSIGN(v423, v424);
      // pto: %253, %254
      ;
      int64_t v425 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v37) + (uint64_t) v69);
      // pto: %255
      ;
      int64_t v426 = v425 < v27 ? v27 : v425;
      // pto: %accum_inline1060__iter_v3_pview
      ;
      const int64_t v427 = 0;
      // pto: %accum_inline1060__iter_v3_pview
      ;
      __gm__ float* v428 = PTOAS__GLOBAL_TENSOR_DATA(v47);
      // pto: %accum_inline1060__iter_v3_pview
      ;
      const int64_t v429 = 1;
      // pto: %accum_inline1060__iter_v3_pview
      ;
      const int64_t v430 = 1;
      // pto: %accum_inline1060__iter_v3_pview
      ;
      const int64_t v431 = 1;
      // pto: %accum_inline1060__iter_v3_pview
      ;
      int64_t v432 = v119 * v17;
      // pto: %accum_inline1060__iter_v3_pview
      ;
      int64_t v433 = v431 * v432;
      // pto: %accum_inline1060__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, -1, 128> v434 = pto::Shape<1, 1, 1, -1, 128>(v429, v430, v431, v119, v26);
      // pto: %accum_inline1060__iter_v3_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v435 = pto::Stride<-1, -1, -1, -1, -1>(v430 * v433, v433, v432, v17, v18);
      // pto: %accum_inline1060__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v436 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v428 + (v427 + v123 * v17 + v426 * v18), v434, v435);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      TSTORE(v436, v423);
    } else {
      for (int64_t v437 = v27; v437 < v20; v437 += v18) {
        // pto: %256
        ;
        int64_t v438 = (int64_t) ((uint64_t) v71 + (uint64_t) v437);
        // pto: %257
        ;
        if (v438 < v5) {
          // pto: %258
          ;
          int64_t v439 = (int64_t) ((uint64_t) v438 * (uint64_t) v19);
          // pto: %259
          ;
          int64_t v440 = (int64_t) ((uint64_t) v8 - (uint64_t) v439);
          // pto: %260
          ;
          int64_t v441 = v440 < v19 ? v440 : v19;
          // pto: %262, %263, %264, %265, %261
          ;
          int32_t v442 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v438 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
          // pto: %266
          ;
          int64_t v443 = (int64_t) v442;
          // pto: %267
          ;
          int64_t v444 = v443 < v27 ? v27 : v443;
          // pto: %seed_narrow_acc_inline1031__tile
          ;
          Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v445 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v19, v26);
          // pto: %seed_narrow_acc_inline1031__tile
          ;
          uint64_t v446 = (uint64_t) v14;
          TASSIGN(v445, v446);
          wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          for (int64_t v447 = v27; v447 < v19; v447 += v18) {
            // pto: %268
            ;
            int64_t v448 = (int64_t) ((uint64_t) v447 * (uint64_t) v19);
            // pto: %269, %270
            ;
            int64_t v449 = (int64_t) ((uint64_t) v444 + (uint64_t) v448) % v23;
            // pto: %271, %272, %273
            ;
            int64_t v450 = v449 < v27 ? (int64_t) ((uint64_t) v449 + (uint64_t) v23) : v449;
            // pto: %274
            ;
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            if (v450 <= v34) {
              // pto: %275
              ;
              int64_t v451 = (int64_t) ((uint64_t) v450 * (uint64_t) v19);
              // pto: %seed_narrow_packet_x_inline1029__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v452 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v441, v23);
              // pto: %seed_narrow_packet_x_inline1029__tile
              ;
              uint64_t v453 = (uint64_t) v13;
              TASSIGN(v452, v453);
              // pto: %276
              ;
              int64_t v454 = v439 < v27 ? v27 : v439;
              // pto: %277, %278
              ;
              int64_t v455 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v35) + (uint64_t) v451);
              // pto: %279
              ;
              int64_t v456 = v455 < v27 ? v27 : v455;
              // pto: %280
              ;
              const int64_t v457 = 0;
              // pto: %280
              ;
              __gm__ bfloat16_t* v458 = PTOAS__GLOBAL_TENSOR_DATA(v56);
              // pto: %280
              ;
              const int64_t v459 = 1;
              // pto: %280
              ;
              const int64_t v460 = 1;
              // pto: %280
              ;
              const int64_t v461 = 1;
              // pto: %280
              ;
              int64_t v462 = v441 * v21;
              // pto: %280
              ;
              int64_t v463 = v461 * v462;
              // pto: %280
              ;
              pto::Shape<1, 1, 1, -1, 256> v464 = pto::Shape<1, 1, 1, -1, 256>(v459, v460, v461, v441, v23);
              // pto: %280
              ;
              pto::Stride<-1, -1, -1, -1, -1> v465 = pto::Stride<-1, -1, -1, -1, -1>(v460 * v463, v463, v462, v21, v18);
              // pto: %280
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v466 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v458 + (v457 + v454 * v21 + v456 * v18), v464, v465);
              TLOAD(v452, v466);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              // pto: %seed_narrow_packet_w_inline1016__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v467 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
              // pto: %seed_narrow_packet_w_inline1016__tile
              ;
              uint64_t v468 = (uint64_t) v12;
              TASSIGN(v467, v468);
              // pto: %281
              ;
              int64_t v469 = v6 < v27 ? v27 : v6;
              // pto: %282
              ;
              int64_t v470 = v69 / v19;
              // pto: %283
              ;
              int64_t v471 = v470 < v27 ? v27 : v470;
              // pto: %284
              ;
              int64_t v472 = v451 / v19;
              // pto: %285
              ;
              int64_t v473 = v472 < v27 ? v27 : v472;
              // pto: %286
              ;
              __gm__ bfloat16_t* v474 = PTOAS__GLOBAL_TENSOR_DATA(v59);
              // pto: %286
              ;
              const int64_t v475 = 0;
              // pto: %286
              ;
              const int64_t v476 = 4194304;
              // pto: %286
              ;
              const int64_t v477 = 65536;
              // pto: %286
              ;
              const int64_t v478 = 256;
              // pto: %286
              ;
              pto::Shape<1, 8, 16, 16, 16> v479 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %286
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v480 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %286
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v481 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v474 + ((v475 + v469 * v476) + v471 * v477 + v473 * v478), v479, v480);
              TLOAD(v467, v481);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              // pto: %seed_narrow_acc_inline1031__iter_v1_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v482 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v441, v26);
              // pto: %seed_narrow_acc_inline1031__iter_v1_l0_a
              ;
              uint64_t v483 = (uint64_t) v14;
              TASSIGN(v482, v483);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              uint16_t v484 = static_cast<uint16_t>(v27);
              uint16_t v485 = static_cast<uint16_t>(v27);
              TEXTRACT(v482, v452, v484, v485);
              // pto: %seed_narrow_acc_inline1031__iter_v1_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v486 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
              // pto: %seed_narrow_acc_inline1031__iter_v1_l0_b
              ;
              uint64_t v487 = (uint64_t) v15;
              TASSIGN(v486, v487);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              uint16_t v488 = static_cast<uint16_t>(v27);
              uint16_t v489 = static_cast<uint16_t>(v27);
              TEXTRACT(v486, v467, v488, v489);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              // pto: %32
              ;
              Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v490 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v441, v26);
              // pto: %32
              ;
              uint64_t v491 = (uint64_t) v15;
              TASSIGN(v490, v491);
              uint16_t v492 = static_cast<uint16_t>(v27);
              uint16_t v493 = static_cast<uint16_t>(v26);
              TEXTRACT(v490, v452, v492, v493);
              // pto: %33
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v494 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
              // pto: %33
              ;
              uint64_t v495 = (uint64_t) v14;
              TASSIGN(v494, v495);
              uint16_t v496 = static_cast<uint16_t>(v26);
              uint16_t v497 = static_cast<uint16_t>(v27);
              TEXTRACT(v494, v467, v496, v497);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              // pto: %287
              ;
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              if (v447 == v27) {
                pipe_barrier(PIPE_M);
                TMATMUL(v445, v482, v486);
              } else {
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v445, v445, v482, v486);
              };
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              TMATMUL_ACC(v445, v445, v490, v494);
            } else {
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              for (int64_t v498 = v27; v498 < v19; v498 += v18) {
                // pto: %288, %289
                ;
                int64_t v499 = (int64_t) ((uint64_t) v450 + (uint64_t) v498) % v23;
                // pto: %290, %291, %292
                ;
                int64_t v500 = v499 < v27 ? (int64_t) ((uint64_t) v499 + (uint64_t) v23) : v499;
                // pto: %293
                ;
                int64_t v501 = (int64_t) ((uint64_t) v500 * (uint64_t) v19);
                // pto: %seed_narrow_wrap_x_inline1036__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v502 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v441, v19);
                // pto: %seed_narrow_wrap_x_inline1036__tile
                ;
                uint64_t v503 = (uint64_t) v13;
                TASSIGN(v502, v503);
                // pto: %294
                ;
                int64_t v504 = v439 < v27 ? v27 : v439;
                // pto: %295, %296
                ;
                int64_t v505 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v35) + (uint64_t) v501);
                // pto: %297
                ;
                int64_t v506 = v505 < v27 ? v27 : v505;
                // pto: %298
                ;
                const int64_t v507 = 0;
                // pto: %298
                ;
                __gm__ bfloat16_t* v508 = PTOAS__GLOBAL_TENSOR_DATA(v56);
                // pto: %298
                ;
                const int64_t v509 = 1;
                // pto: %298
                ;
                const int64_t v510 = 1;
                // pto: %298
                ;
                const int64_t v511 = 1;
                // pto: %298
                ;
                int64_t v512 = v441 * v21;
                // pto: %298
                ;
                int64_t v513 = v511 * v512;
                // pto: %298
                ;
                pto::Shape<1, 1, 1, -1, 16> v514 = pto::Shape<1, 1, 1, -1, 16>(v509, v510, v511, v441, v19);
                // pto: %298
                ;
                pto::Stride<-1, -1, -1, -1, -1> v515 = pto::Stride<-1, -1, -1, -1, -1>(v510 * v513, v513, v512, v21, v18);
                // pto: %298
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v516 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v508 + (v507 + v504 * v21 + v506 * v18), v514, v515);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                TLOAD(v502, v516);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                // pto: %seed_narrow_wrap_w_inline1014__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v517 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
                // pto: %seed_narrow_wrap_w_inline1014__tile
                ;
                uint64_t v518 = (uint64_t) v12;
                TASSIGN(v517, v518);
                // pto: %299
                ;
                int64_t v519 = v6 < v27 ? v27 : v6;
                // pto: %300
                ;
                int64_t v520 = v69 / v19;
                // pto: %301
                ;
                int64_t v521 = v520 < v27 ? v27 : v520;
                // pto: %302
                ;
                int64_t v522 = v501 / v19;
                // pto: %303
                ;
                int64_t v523 = v522 < v27 ? v27 : v522;
                // pto: %304
                ;
                __gm__ bfloat16_t* v524 = PTOAS__GLOBAL_TENSOR_DATA(v59);
                // pto: %304
                ;
                const int64_t v525 = 0;
                // pto: %304
                ;
                const int64_t v526 = 4194304;
                // pto: %304
                ;
                const int64_t v527 = 65536;
                // pto: %304
                ;
                const int64_t v528 = 256;
                // pto: %304
                ;
                pto::Shape<1, 8, 1, 16, 16> v529 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %304
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v530 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %304
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v531 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v524 + ((v525 + v519 * v526) + v521 * v527 + v523 * v528), v529, v530);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                TLOAD(v517, v531);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                // pto: %35
                ;
                Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v532 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v441, v19);
                // pto: %35
                ;
                uint64_t v533 = (uint64_t) v14;
                TASSIGN(v532, v533);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                uint16_t v534 = static_cast<uint16_t>(v27);
                uint16_t v535 = static_cast<uint16_t>(v27);
                TEXTRACT(v532, v502, v534, v535);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                // pto: %36
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v536 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
                // pto: %36
                ;
                uint64_t v537 = (uint64_t) v15;
                TASSIGN(v536, v537);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                uint16_t v538 = static_cast<uint16_t>(v27);
                uint16_t v539 = static_cast<uint16_t>(v27);
                TEXTRACT(v536, v517, v538, v539);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                // pto: %306, %307
                ;
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                if ((int64_t) ((uint64_t) v448 + (uint64_t) v498) == v27) {
                  pipe_barrier(PIPE_M);
                  TMATMUL(v445, v532, v536);
                } else {
                  pipe_barrier(PIPE_M);
                  TMATMUL_ACC(v445, v445, v532, v536);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            };
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
          // pto: %309
          ;
          int64_t v540 = v439 < v27 ? v27 : v439;
          // pto: %310, %311
          ;
          int64_t v541 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v37) + (uint64_t) v69);
          // pto: %312
          ;
          int64_t v542 = v541 < v27 ? v27 : v541;
          // pto: %accum_inline1060__iter_v6_pview
          ;
          __gm__ float* v543 = PTOAS__GLOBAL_TENSOR_DATA(v47);
          // pto: %accum_inline1060__iter_v6_pview
          ;
          const int64_t v544 = 0;
          // pto: %accum_inline1060__iter_v6_pview
          ;
          const int64_t v545 = 8192;
          // pto: %accum_inline1060__iter_v6_pview
          ;
          pto::Shape<1, 1, 1, 16, 128> v546 = pto::Shape<1, 1, 1, 16, 128>();
          // pto: %accum_inline1060__iter_v6_pview
          ;
          pto::Stride<131072, 131072, 131072, 8192, 1> v547 = pto::Stride<131072, 131072, 131072, 8192, 1>();
          // pto: %accum_inline1060__iter_v6_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v548 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v543 + (v544 + v540 * v545 + v542), v546, v547);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
          pipe_barrier(PIPE_FIX);
          TSTORE(v548, v445);
          set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        };
      };
    };
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}