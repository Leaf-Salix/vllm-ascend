#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_a_0(__gm__ float* v1, __gm__ int32_t* v2, __gm__ bfloat16_t* v3, __gm__ bfloat16_t* v4, int64_t v5, int64_t v6, int64_t v7, int64_t v8, int64_t v9, int32_t v10, int32_t v11) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c196608_i64
  const int64_t v12 = 196608;
  // pto: %c0_i64
  const int64_t v13 = 0;
  // pto: %c32768_i64
  const int64_t v14 = 32768;
  // pto: %c65536_i64
  const int64_t v15 = 65536;
  // pto: %c131072_i64
  const int64_t v16 = 131072;
  // pto: %c8192_index
  const int64_t v17 = 8192;
  // pto: %c1_index
  const int64_t v18 = 1;
  // pto: %c16_index
  const int64_t v19 = 16;
  // pto: %c8_index
  const int64_t v20 = 8;
  // pto: %c32768_index
  const int64_t v21 = 32768;
  const int64_t v22 = 64;
  // pto: %c256_index
  const int64_t v23 = 256;
  // pto: %c4194304_index
  const int64_t v24 = 4194304;
  // pto: %c65536_index
  const int64_t v25 = 65536;
  const int64_t v26 = 128;
  // pto: %c0_index
  const int64_t v27 = 0;
  // pto: %c7_index
  const int64_t v28 = 7;
  // pto: %c2_index
  const int64_t v29 = 2;
  // pto: %c3_index
  const int64_t v30 = 3;
  // pto: %c4_index
  const int64_t v31 = 4;
  // pto: %c5_index
  const int64_t v32 = 5;
  // pto: %c6_index
  const int64_t v33 = 6;
  // pto: %c4096_index
  const int64_t v34 = 4096;
  // pto: %c14_index
  const int64_t v35 = 14;
  // pto: %c240_index
  const int64_t v36 = 240;
  // pto: %c225_index
  const int64_t v37 = 225;
  // pto: %c241_index
  const int64_t v38 = 241;
  // pto: %c1024_index
  const int64_t v39 = 1024;
  // pto: %c127_index
  const int64_t v40 = 127;
  // pto: %337
  int64_t v41 = (int64_t) ((uint64_t) v8 + (uint64_t) v40);
  // pto: %accum_inline1110__iter_v11_view
  const int64_t v42 = 1;
  // pto: %accum_inline1110__iter_v11_view
  const int64_t v43 = 1;
  // pto: %accum_inline1110__iter_v11_view
  const int64_t v44 = 1;
  // pto: %accum_inline1110__iter_v11_view
  int64_t v45 = v41 * v17;
  // pto: %accum_inline1110__iter_v11_view
  int64_t v46 = v44 * v45;
  // pto: %accum_inline1110__iter_v11_view
  pto::Shape<1, 1, 1, -1, -1> v47 = pto::Shape<1, 1, 1, -1, -1>(v42, v43, v44, v41, v17);
  // pto: %accum_inline1110__iter_v11_view
  pto::Stride<-1, -1, -1, -1, -1> v48 = pto::Stride<-1, -1, -1, -1, -1>(v43 * v46, v46, v45, v17, v18);
  // pto: %accum_inline1110__iter_v11_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v49 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v47, v48);
  // pto: %heads__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v51 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v52 = 1;
  // pto: %heads__ssa_v0_view
  int64_t v53 = (int64_t) v9;
  // pto: %heads__ssa_v0_view
  int64_t v54 = v53 * v21;
  // pto: %heads__ssa_v0_view
  int64_t v55 = v52 * v54;
  // pto: %heads__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v56 = pto::Shape<1, 1, 1, -1, -1>(v50, v51, v52, v53, v21);
  // pto: %heads__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v57 = pto::Stride<-1, -1, -1, -1, -1>(v51 * v55, v55, v54, v21, v18);
  // pto: %heads__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v58 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v56, v57);
  // pto: %wo_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v59 = pto::Shape<-1, -1, -1, -1, -1>(v20, v22, v23, v19, v19);
  // pto: %wo_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v60 = pto::Stride<-1, -1, -1, -1, -1>(v24, v25, v23, v19, v18);
  // pto: %wo_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v61 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v4, v59, v60);
  // pto: %v4_wide_acc_inline1075__phi_v7
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v62 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v26);
  // pto: %v4_wide_acc_inline1075__phi_v7
  uint64_t v63 = (uint64_t) v13;
  TASSIGN(v62, v63);
  // pto: %190
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v64 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v26);
  // pto: %190
  uint64_t v65 = (uint64_t) v13;
  TASSIGN(v64, v65);
  // pto: %228
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v66 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v26);
  // pto: %228
  uint64_t v67 = (uint64_t) v13;
  TASSIGN(v66, v67);
  // pto: %v4_narrow_acc_inline1093__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v68 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v19, v26);
  // pto: %v4_narrow_acc_inline1093__phi_v7
  uint64_t v69 = (uint64_t) v13;
  TASSIGN(v68, v69);
  // pto: %v4_block_inline1066__ssa_v0
  int64_t v70 = (int64_t) v10;
  // pto: %38
  int64_t v71 = (int64_t) ((uint64_t) v70 * (uint64_t) v26);
  // pto: %39, %40
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  for (int64_t v72 = v27; v72 < ((int64_t) ((uint64_t) v5 + (uint64_t) v28) / v20); v72 += v18) {
    // pto: %41
    ;
    int64_t v73 = (int64_t) ((uint64_t) v72 * (uint64_t) v20);
    // pto: %flat_offset, %42, %43, %t__tile
    ;
    int32_t v74 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v72 * (uint64_t) v22) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
    // pto: %44
    ;
    int64_t v75 = (int64_t) v74;
    // pto: %45
    ;
    int64_t v76 = v75 < v27 ? v27 : v75;
    // pto: %46
    ;
    int64_t v77 = (int64_t) ((uint64_t) v73 + (uint64_t) v18);
    // pto: %47
    ;
    // pto: %v4_same_start_inline1070__phi_v3
    ;
    int64_t v78;
    if (v77 < v5) {
      // pto: %50, %51, %52, %53, %48
      ;
      int32_t v79 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v77 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
      // pto: %54
      ;
      int64_t v80 = (int64_t) v79;
      // pto: %55
      ;
      int64_t v81 = v80 < v27 ? v27 : v80;
      // pto: %56, %v4_same_start_inline1070__phi_v2
      ;
      v78 = v81 != v76 ? v27 : v18;
    } else {
      v78 = v18;
    };
    // pto: %57
    ;
    int64_t v82 = (int64_t) ((uint64_t) v73 + (uint64_t) v29);
    // pto: %58
    ;
    // pto: %v4_same_start_inline1070__phi_v6
    ;
    int64_t v83;
    if (v82 < v5) {
      // pto: %61, %62, %63, %64, %59
      ;
      int32_t v84 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v82 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
      // pto: %65
      ;
      int64_t v85 = (int64_t) v84;
      // pto: %66
      ;
      int64_t v86 = v85 < v27 ? v27 : v85;
      // pto: %67, %v4_same_start_inline1070__phi_v5
      ;
      int64_t v87 = v86 != v76 ? v27 : v78;
      v83 = v87;
    } else {
      v83 = v78;
    };
    // pto: %68
    ;
    int64_t v88 = (int64_t) ((uint64_t) v73 + (uint64_t) v30);
    // pto: %69
    ;
    // pto: %v4_same_start_inline1070__phi_v9
    ;
    int64_t v89;
    if (v88 < v5) {
      // pto: %72, %73, %74, %75, %70
      ;
      int32_t v90 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v88 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
      // pto: %76
      ;
      int64_t v91 = (int64_t) v90;
      // pto: %77
      ;
      int64_t v92 = v91 < v27 ? v27 : v91;
      // pto: %78, %v4_same_start_inline1070__phi_v8
      ;
      int64_t v93 = v92 != v76 ? v27 : v83;
      v89 = v93;
    } else {
      v89 = v83;
    };
    // pto: %79
    ;
    int64_t v94 = (int64_t) ((uint64_t) v73 + (uint64_t) v31);
    // pto: %80
    ;
    // pto: %v4_same_start_inline1070__phi_v12
    ;
    int64_t v95;
    if (v94 < v5) {
      // pto: %83, %84, %85, %86, %81
      ;
      int32_t v96 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v94 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
      // pto: %87
      ;
      int64_t v97 = (int64_t) v96;
      // pto: %88
      ;
      int64_t v98 = v97 < v27 ? v27 : v97;
      // pto: %89, %v4_same_start_inline1070__phi_v11
      ;
      int64_t v99 = v98 != v76 ? v27 : v89;
      v95 = v99;
    } else {
      v95 = v89;
    };
    // pto: %90
    ;
    int64_t v100 = (int64_t) ((uint64_t) v73 + (uint64_t) v32);
    // pto: %91
    ;
    // pto: %v4_same_start_inline1070__phi_v15
    ;
    int64_t v101;
    if (v100 < v5) {
      // pto: %94, %95, %96, %97, %92
      ;
      int32_t v102 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v100 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
      // pto: %98
      ;
      int64_t v103 = (int64_t) v102;
      // pto: %99
      ;
      int64_t v104 = v103 < v27 ? v27 : v103;
      // pto: %100, %v4_same_start_inline1070__phi_v14
      ;
      int64_t v105 = v104 != v76 ? v27 : v95;
      v101 = v105;
    } else {
      v101 = v95;
    };
    // pto: %101
    ;
    int64_t v106 = (int64_t) ((uint64_t) v73 + (uint64_t) v33);
    // pto: %102
    ;
    // pto: %v4_same_start_inline1070__phi_v18
    ;
    int64_t v107;
    if (v106 < v5) {
      // pto: %105, %106, %107, %108, %103
      ;
      int32_t v108 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
      // pto: %109
      ;
      int64_t v109 = (int64_t) v108;
      // pto: %110
      ;
      int64_t v110 = v109 < v27 ? v27 : v109;
      // pto: %111, %v4_same_start_inline1070__phi_v17
      ;
      int64_t v111 = v110 != v76 ? v27 : v101;
      v107 = v111;
    } else {
      v107 = v101;
    };
    // pto: %112
    ;
    int64_t v112 = (int64_t) ((uint64_t) v73 + (uint64_t) v28);
    // pto: %113
    ;
    // pto: %v4_same_start_inline1070__phi_v21
    ;
    int64_t v113;
    if (v112 < v5) {
      // pto: %116, %117, %118, %119, %114
      ;
      int32_t v114 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v112 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
      // pto: %120
      ;
      int64_t v115 = (int64_t) v114;
      // pto: %121
      ;
      int64_t v116 = v115 < v27 ? v27 : v115;
      // pto: %122, %v4_same_start_inline1070__phi_v20
      ;
      int64_t v117 = v116 != v76 ? v27 : v107;
      v113 = v117;
    } else {
      v113 = v107;
    };
    // pto: %123, %v4_same_start_inline1070__phi_v23
    ;
    int64_t v118 = v8 <= v19 ? v27 : v113;
    // pto: %124
    ;
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    if (v118 == v18) {
      int64_t v119 = (int64_t) ((uint64_t) v72 * (uint64_t) v26);
      // pto: %126
      ;
      int64_t v120 = (int64_t) ((uint64_t) v8 - (uint64_t) v119);
      // pto: %127
      ;
      int64_t v121 = v120 < v26 ? v120 : v26;
      // pto: %128
      ;
      int64_t v122 = v76 % v23;
      // pto: %129, %130, %131
      ;
      int64_t v123 = v122 < v27 ? (int64_t) ((uint64_t) v122 + (uint64_t) v23) : v122;
      // pto: %132
      ;
      int64_t v124 = (int64_t) ((uint64_t) v123 * (uint64_t) v19);
      // pto: %v4_wide_seed_x_inline1007__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v125 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v121, v19);
      // pto: %v4_wide_seed_x_inline1007__tile
      ;
      uint64_t v126 = (uint64_t) v12;
      TASSIGN(v125, v126);
      // pto: %133
      ;
      int64_t v127 = v119 < v27 ? v27 : v119;
      // pto: %134
      ;
      int64_t v128 = (int64_t) ((uint64_t) v6 * (uint64_t) v34);
      // pto: %135
      ;
      int64_t v129 = (int64_t) ((uint64_t) v128 + (uint64_t) v124);
      // pto: %136
      ;
      int64_t v130 = v129 < v27 ? v27 : v129;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v131 = 0;
      // pto: %heads__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v132 = PTOAS__GLOBAL_TENSOR_DATA(v58);
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v133 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v134 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v135 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      int64_t v136 = v121 * v21;
      // pto: %heads__ssa_v0_pview
      ;
      int64_t v137 = v135 * v136;
      // pto: %heads__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 16> v138 = pto::Shape<1, 1, 1, -1, 16>(v133, v134, v135, v121, v19);
      // pto: %heads__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v139 = pto::Stride<-1, -1, -1, -1, -1>(v134 * v137, v137, v136, v21, v18);
      // pto: %heads__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v140 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v132 + (v131 + v127 * v21 + v130 * v18), v138, v139);
      TLOAD(v125, v140);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %v4_wide_seed_w_inline1065__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v141 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
      // pto: %v4_wide_seed_w_inline1065__tile
      ;
      uint64_t v142 = (uint64_t) v13;
      TASSIGN(v141, v142);
      // pto: %137
      ;
      int64_t v143 = v6 < v27 ? v27 : v6;
      // pto: %138
      ;
      int64_t v144 = v71 / v19;
      // pto: %139
      ;
      int64_t v145 = v144 < v27 ? v27 : v144;
      // pto: %140
      ;
      int64_t v146 = v124 / v19;
      // pto: %141
      ;
      int64_t v147 = v146 < v27 ? v27 : v146;
      // pto: %wo_a__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v148 = PTOAS__GLOBAL_TENSOR_DATA(v61);
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v149 = 0;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v150 = 4194304;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v151 = 65536;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v152 = 256;
      // pto: %wo_a__ssa_v0_pview
      ;
      pto::Shape<1, 8, 1, 16, 16> v153 = pto::Shape<1, 8, 1, 16, 16>();
      // pto: %wo_a__ssa_v0_pview
      ;
      pto::Stride<4194304, 65536, 256, 16, 1> v154 = pto::Stride<4194304, 65536, 256, 16, 1>();
      // pto: %wo_a__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v155 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v148 + ((v149 + v143 * v150) + v145 * v151 + v147 * v152), v153, v154);
      TLOAD(v141, v155);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %lhs_slice_0_textract
      ;
      Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v156 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v121, v19);
      // pto: %lhs_slice_0_textract
      ;
      uint64_t v157 = (uint64_t) v13;
      TASSIGN(v156, v157);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      uint16_t v158 = static_cast<uint16_t>(v27);
      uint16_t v159 = static_cast<uint16_t>(v27);
      TEXTRACT(v156, v125, v158, v159);
      // pto: %rhs_slice_0_textract
      ;
      Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v160 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
      // pto: %rhs_slice_0_textract
      ;
      uint64_t v161 = (uint64_t) v13;
      TASSIGN(v160, v161);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      uint16_t v162 = static_cast<uint16_t>(v27);
      uint16_t v163 = static_cast<uint16_t>(v27);
      TEXTRACT(v160, v141, v162, v163);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %v4_wide_acc_inline1075__tile
      ;
      Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v164 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v121, v26);
      // pto: %v4_wide_acc_inline1075__tile
      ;
      uint64_t v165 = (uint64_t) v13;
      TASSIGN(v164, v165);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      TMATMUL(v164, v156, v160);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      for (int64_t v166 = v27; v166 < v35; v166 += v29) {
        // pto: %142
        ;
        int64_t v167 = (int64_t) ((uint64_t) v166 * (uint64_t) v19);
        // pto: %143, %144, %145
        ;
        int64_t v168 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v76 + (uint64_t) v167) + (uint64_t) v18) % v23;
        // pto: %146, %147, %148
        ;
        int64_t v169 = v168 < v27 ? (int64_t) ((uint64_t) v168 + (uint64_t) v23) : v168;
        // pto: %151, %150, %152, %153
        ;
        int64_t v170 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v76 + (uint64_t) ((int64_t) (uint64_t) v167 + (uint64_t) v19)) + (uint64_t) v18) % v23;
        // pto: %154, %155, %156
        ;
        int64_t v171 = v170 < v27 ? (int64_t) ((uint64_t) v170 + (uint64_t) v23) : v170;
        // pto: %157
        ;
        // pto: %158
        ;
        int64_t v172 = v121 < v26 ? v121 : v26;
        v62.SetValidShape(v172, v26);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        if (v169 <= v36) {
          // pto: %159
          ;
          int64_t v173 = (int64_t) ((uint64_t) v169 * (uint64_t) v19);
          // pto: %v4_wide_packet_x_inline1040__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v174 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v121, v23);
          // pto: %v4_wide_packet_x_inline1040__tile
          ;
          uint64_t v175 = (uint64_t) v12;
          TASSIGN(v174, v175);
          // pto: %162
          ;
          int64_t v176 = (int64_t) ((uint64_t) v128 + (uint64_t) v173);
          // pto: %163
          ;
          int64_t v177 = v176 < v27 ? v27 : v176;
          // pto: %164
          ;
          const int64_t v178 = 0;
          // pto: %164
          ;
          __gm__ bfloat16_t* v179 = PTOAS__GLOBAL_TENSOR_DATA(v58);
          // pto: %164
          ;
          const int64_t v180 = 1;
          // pto: %164
          ;
          const int64_t v181 = 1;
          // pto: %164
          ;
          const int64_t v182 = 1;
          // pto: %164
          ;
          int64_t v183 = v121 * v21;
          // pto: %164
          ;
          int64_t v184 = v182 * v183;
          // pto: %164
          ;
          pto::Shape<1, 1, 1, -1, 256> v185 = pto::Shape<1, 1, 1, -1, 256>(v180, v181, v182, v121, v23);
          // pto: %164
          ;
          pto::Stride<-1, -1, -1, -1, -1> v186 = pto::Stride<-1, -1, -1, -1, -1>(v181 * v184, v184, v183, v21, v18);
          // pto: %164
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v187 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v179 + (v178 + v127 * v21 + v177 * v18), v185, v186);
          TLOAD(v174, v187);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
          // pto: %v4_wide_packet_w_inline1130__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v188 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
          // pto: %v4_wide_packet_w_inline1130__tile
          ;
          uint64_t v189 = (uint64_t) v13;
          TASSIGN(v188, v189);
          // pto: %168
          ;
          int64_t v190 = v173 / v19;
          // pto: %169
          ;
          int64_t v191 = v190 < v27 ? v27 : v190;
          // pto: %170
          ;
          __gm__ bfloat16_t* v192 = PTOAS__GLOBAL_TENSOR_DATA(v61);
          // pto: %170
          ;
          const int64_t v193 = 0;
          // pto: %170
          ;
          const int64_t v194 = 4194304;
          // pto: %170
          ;
          const int64_t v195 = 65536;
          // pto: %170
          ;
          const int64_t v196 = 256;
          // pto: %170
          ;
          pto::Shape<1, 8, 16, 16, 16> v197 = pto::Shape<1, 8, 16, 16, 16>();
          // pto: %170
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v198 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %170
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v199 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v192 + ((v193 + v143 * v194) + v145 * v195 + v191 * v196), v197, v198);
          TLOAD(v188, v199);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
          // pto: %v4_wide_acc_inline1075__iter_v1_l0_a
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v200 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v121, v26);
          // pto: %v4_wide_acc_inline1075__iter_v1_l0_a
          ;
          uint64_t v201 = (uint64_t) v13;
          TASSIGN(v200, v201);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
          uint16_t v202 = static_cast<uint16_t>(v27);
          uint16_t v203 = static_cast<uint16_t>(v27);
          TEXTRACT(v200, v174, v202, v203);
          // pto: %v4_wide_acc_inline1075__iter_v1_l0_b
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v204 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %v4_wide_acc_inline1075__iter_v1_l0_b
          ;
          uint64_t v205 = (uint64_t) v13;
          TASSIGN(v204, v205);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
          uint16_t v206 = static_cast<uint16_t>(v27);
          uint16_t v207 = static_cast<uint16_t>(v27);
          TEXTRACT(v204, v188, v206, v207);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
          // pto: %0
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v208 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v121, v26);
          // pto: %0
          ;
          uint64_t v209 = (uint64_t) v14;
          TASSIGN(v208, v209);
          uint16_t v210 = static_cast<uint16_t>(v27);
          uint16_t v211 = static_cast<uint16_t>(v26);
          TEXTRACT(v208, v174, v210, v211);
          // pto: %1
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v212 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %1
          ;
          uint64_t v213 = (uint64_t) v14;
          TASSIGN(v212, v213);
          uint16_t v214 = static_cast<uint16_t>(v26);
          uint16_t v215 = static_cast<uint16_t>(v27);
          TEXTRACT(v212, v188, v214, v215);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v164, v164, v200, v204);
          pipe_barrier(PIPE_M);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
          TMATMUL_ACC(v164, v164, v208, v212);
        } else {
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
          for (int64_t v216 = v27; v216 < v19; v216 += v18) {
            // pto: %171, %172
            ;
            int64_t v217 = (int64_t) ((uint64_t) v169 + (uint64_t) v216) % v23;
            // pto: %173, %174, %175
            ;
            int64_t v218 = v217 < v27 ? (int64_t) ((uint64_t) v217 + (uint64_t) v23) : v217;
            // pto: %176
            ;
            int64_t v219 = (int64_t) ((uint64_t) v218 * (uint64_t) v19);
            // pto: %v4_wide_wrap_x_inline1082__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v121, v19);
            // pto: %v4_wide_wrap_x_inline1082__tile
            ;
            uint64_t v221 = (uint64_t) v12;
            TASSIGN(v220, v221);
            // pto: %179
            ;
            int64_t v222 = (int64_t) ((uint64_t) v128 + (uint64_t) v219);
            // pto: %180
            ;
            int64_t v223 = v222 < v27 ? v27 : v222;
            // pto: %181
            ;
            const int64_t v224 = 0;
            // pto: %181
            ;
            __gm__ bfloat16_t* v225 = PTOAS__GLOBAL_TENSOR_DATA(v58);
            // pto: %181
            ;
            const int64_t v226 = 1;
            // pto: %181
            ;
            const int64_t v227 = 1;
            // pto: %181
            ;
            const int64_t v228 = 1;
            // pto: %181
            ;
            int64_t v229 = v121 * v21;
            // pto: %181
            ;
            int64_t v230 = v228 * v229;
            // pto: %181
            ;
            pto::Shape<1, 1, 1, -1, 16> v231 = pto::Shape<1, 1, 1, -1, 16>(v226, v227, v228, v121, v19);
            // pto: %181
            ;
            pto::Stride<-1, -1, -1, -1, -1> v232 = pto::Stride<-1, -1, -1, -1, -1>(v227 * v230, v230, v229, v21, v18);
            // pto: %181
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v233 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v225 + (v224 + v127 * v21 + v223 * v18), v231, v232);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            TLOAD(v220, v233);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
            // pto: %v4_wide_wrap_w_inline1136__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v234 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %v4_wide_wrap_w_inline1136__tile
            ;
            uint64_t v235 = (uint64_t) v13;
            TASSIGN(v234, v235);
            // pto: %185
            ;
            int64_t v236 = v219 / v19;
            // pto: %186
            ;
            int64_t v237 = v236 < v27 ? v27 : v236;
            // pto: %187
            ;
            __gm__ bfloat16_t* v238 = PTOAS__GLOBAL_TENSOR_DATA(v61);
            // pto: %187
            ;
            const int64_t v239 = 0;
            // pto: %187
            ;
            const int64_t v240 = 4194304;
            // pto: %187
            ;
            const int64_t v241 = 65536;
            // pto: %187
            ;
            const int64_t v242 = 256;
            // pto: %187
            ;
            pto::Shape<1, 8, 1, 16, 16> v243 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %187
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v244 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %187
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v245 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v238 + ((v239 + v143 * v240) + v145 * v241 + v237 * v242), v243, v244);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
            TLOAD(v234, v245);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
            // pto: %3
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v246 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v121, v19);
            // pto: %3
            ;
            uint64_t v247 = (uint64_t) v13;
            TASSIGN(v246, v247);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
            uint16_t v248 = static_cast<uint16_t>(v27);
            uint16_t v249 = static_cast<uint16_t>(v27);
            TEXTRACT(v246, v220, v248, v249);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            // pto: %4
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v250 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %4
            ;
            uint64_t v251 = (uint64_t) v13;
            TASSIGN(v250, v251);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
            uint16_t v252 = static_cast<uint16_t>(v27);
            uint16_t v253 = static_cast<uint16_t>(v27);
            TEXTRACT(v250, v234, v252, v253);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v164, v164, v246, v250);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          };
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        };
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        // pto: %188
        ;
        v64.SetValidShape(v172, v26);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        if (v171 <= v36) {
          // pto: %191
          ;
          int64_t v254 = (int64_t) ((uint64_t) v171 * (uint64_t) v19);
          // pto: %5
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v255 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v121, v23);
          // pto: %5
          ;
          uint64_t v256 = (uint64_t) v15;
          TASSIGN(v255, v256);
          // pto: %194
          ;
          int64_t v257 = (int64_t) ((uint64_t) v128 + (uint64_t) v254);
          // pto: %195
          ;
          int64_t v258 = v257 < v27 ? v27 : v257;
          // pto: %196
          ;
          const int64_t v259 = 0;
          // pto: %196
          ;
          __gm__ bfloat16_t* v260 = PTOAS__GLOBAL_TENSOR_DATA(v58);
          // pto: %196
          ;
          const int64_t v261 = 1;
          // pto: %196
          ;
          const int64_t v262 = 1;
          // pto: %196
          ;
          const int64_t v263 = 1;
          // pto: %196
          ;
          int64_t v264 = v121 * v21;
          // pto: %196
          ;
          int64_t v265 = v263 * v264;
          // pto: %196
          ;
          pto::Shape<1, 1, 1, -1, 256> v266 = pto::Shape<1, 1, 1, -1, 256>(v261, v262, v263, v121, v23);
          // pto: %196
          ;
          pto::Stride<-1, -1, -1, -1, -1> v267 = pto::Stride<-1, -1, -1, -1, -1>(v262 * v265, v265, v264, v21, v18);
          // pto: %196
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v268 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v260 + (v259 + v127 * v21 + v258 * v18), v266, v267);
          TLOAD(v255, v268);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
          // pto: %6
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v269 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
          // pto: %6
          ;
          uint64_t v270 = (uint64_t) v16;
          TASSIGN(v269, v270);
          // pto: %200
          ;
          int64_t v271 = v254 / v19;
          // pto: %201
          ;
          int64_t v272 = v271 < v27 ? v27 : v271;
          // pto: %202
          ;
          __gm__ bfloat16_t* v273 = PTOAS__GLOBAL_TENSOR_DATA(v61);
          // pto: %202
          ;
          const int64_t v274 = 0;
          // pto: %202
          ;
          const int64_t v275 = 4194304;
          // pto: %202
          ;
          const int64_t v276 = 65536;
          // pto: %202
          ;
          const int64_t v277 = 256;
          // pto: %202
          ;
          pto::Shape<1, 8, 16, 16, 16> v278 = pto::Shape<1, 8, 16, 16, 16>();
          // pto: %202
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v279 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %202
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v280 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v273 + ((v274 + v143 * v275) + v145 * v276 + v272 * v277), v278, v279);
          TLOAD(v269, v280);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
          // pto: %7
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v281 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v121, v26);
          // pto: %7
          ;
          uint64_t v282 = (uint64_t) v13;
          TASSIGN(v281, v282);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
          uint16_t v283 = static_cast<uint16_t>(v27);
          uint16_t v284 = static_cast<uint16_t>(v27);
          TEXTRACT(v281, v255, v283, v284);
          // pto: %8
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v285 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %8
          ;
          uint64_t v286 = (uint64_t) v13;
          TASSIGN(v285, v286);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
          uint16_t v287 = static_cast<uint16_t>(v27);
          uint16_t v288 = static_cast<uint16_t>(v27);
          TEXTRACT(v285, v269, v287, v288);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
          // pto: %9
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v289 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v121, v26);
          // pto: %9
          ;
          uint64_t v290 = (uint64_t) v14;
          TASSIGN(v289, v290);
          uint16_t v291 = static_cast<uint16_t>(v27);
          uint16_t v292 = static_cast<uint16_t>(v26);
          TEXTRACT(v289, v255, v291, v292);
          // pto: %10
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v293 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %10
          ;
          uint64_t v294 = (uint64_t) v14;
          TASSIGN(v293, v294);
          uint16_t v295 = static_cast<uint16_t>(v26);
          uint16_t v296 = static_cast<uint16_t>(v27);
          TEXTRACT(v293, v269, v295, v296);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v62, v62, v281, v285);
          pipe_barrier(PIPE_M);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
          TMATMUL_ACC(v62, v62, v289, v293);
        } else {
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
          for (int64_t v297 = v27; v297 < v19; v297 += v18) {
            // pto: %204, %205
            ;
            int64_t v298 = (int64_t) ((uint64_t) v171 + (uint64_t) v297) % v23;
            // pto: %206, %207, %208
            ;
            int64_t v299 = v298 < v27 ? (int64_t) ((uint64_t) v298 + (uint64_t) v23) : v298;
            // pto: %209
            ;
            int64_t v300 = (int64_t) ((uint64_t) v299 * (uint64_t) v19);
            // pto: %13
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v301 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v121, v19);
            // pto: %13
            ;
            uint64_t v302 = (uint64_t) v15;
            TASSIGN(v301, v302);
            // pto: %212
            ;
            int64_t v303 = (int64_t) ((uint64_t) v128 + (uint64_t) v300);
            // pto: %213
            ;
            int64_t v304 = v303 < v27 ? v27 : v303;
            // pto: %214
            ;
            const int64_t v305 = 0;
            // pto: %214
            ;
            __gm__ bfloat16_t* v306 = PTOAS__GLOBAL_TENSOR_DATA(v58);
            // pto: %214
            ;
            const int64_t v307 = 1;
            // pto: %214
            ;
            const int64_t v308 = 1;
            // pto: %214
            ;
            const int64_t v309 = 1;
            // pto: %214
            ;
            int64_t v310 = v121 * v21;
            // pto: %214
            ;
            int64_t v311 = v309 * v310;
            // pto: %214
            ;
            pto::Shape<1, 1, 1, -1, 16> v312 = pto::Shape<1, 1, 1, -1, 16>(v307, v308, v309, v121, v19);
            // pto: %214
            ;
            pto::Stride<-1, -1, -1, -1, -1> v313 = pto::Stride<-1, -1, -1, -1, -1>(v308 * v311, v311, v310, v21, v18);
            // pto: %214
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v314 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v306 + (v305 + v127 * v21 + v304 * v18), v312, v313);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
            TLOAD(v301, v314);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %14
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %14
            ;
            uint64_t v316 = (uint64_t) v16;
            TASSIGN(v315, v316);
            // pto: %218
            ;
            int64_t v317 = v300 / v19;
            // pto: %219
            ;
            int64_t v318 = v317 < v27 ? v27 : v317;
            // pto: %220
            ;
            __gm__ bfloat16_t* v319 = PTOAS__GLOBAL_TENSOR_DATA(v61);
            // pto: %220
            ;
            const int64_t v320 = 0;
            // pto: %220
            ;
            const int64_t v321 = 4194304;
            // pto: %220
            ;
            const int64_t v322 = 65536;
            // pto: %220
            ;
            const int64_t v323 = 256;
            // pto: %220
            ;
            pto::Shape<1, 8, 1, 16, 16> v324 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %220
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v325 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %220
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v326 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v319 + ((v320 + v143 * v321) + v145 * v322 + v318 * v323), v324, v325);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
            TLOAD(v315, v326);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %15
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v327 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v121, v19);
            // pto: %15
            ;
            uint64_t v328 = (uint64_t) v13;
            TASSIGN(v327, v328);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
            uint16_t v329 = static_cast<uint16_t>(v27);
            uint16_t v330 = static_cast<uint16_t>(v27);
            TEXTRACT(v327, v301, v329, v330);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
            // pto: %16
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v331 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %16
            ;
            uint64_t v332 = (uint64_t) v13;
            TASSIGN(v331, v332);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            uint16_t v333 = static_cast<uint16_t>(v27);
            uint16_t v334 = static_cast<uint16_t>(v27);
            TEXTRACT(v331, v315, v333, v334);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v62, v62, v327, v331);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
          };
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        };
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      // pto: %221, %222
      ;
      int64_t v335 = (int64_t) ((uint64_t) v76 + (uint64_t) v37) % v23;
      // pto: %223, %224, %225
      ;
      int64_t v336 = v335 < v27 ? (int64_t) ((uint64_t) v335 + (uint64_t) v23) : v335;
      // pto: %226
      ;
      // pto: %227
      ;
      int64_t v337 = v121 < v26 ? v121 : v26;
      v66.SetValidShape(v337, v26);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      if (v336 <= v36) {
        // pto: %229
        ;
        int64_t v338 = (int64_t) ((uint64_t) v336 * (uint64_t) v19);
        // pto: %18
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v339 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v121, v23);
        // pto: %18
        ;
        uint64_t v340 = (uint64_t) v12;
        TASSIGN(v339, v340);
        // pto: %232
        ;
        int64_t v341 = (int64_t) ((uint64_t) v128 + (uint64_t) v338);
        // pto: %233
        ;
        int64_t v342 = v341 < v27 ? v27 : v341;
        // pto: %234
        ;
        const int64_t v343 = 0;
        // pto: %234
        ;
        __gm__ bfloat16_t* v344 = PTOAS__GLOBAL_TENSOR_DATA(v58);
        // pto: %234
        ;
        const int64_t v345 = 1;
        // pto: %234
        ;
        const int64_t v346 = 1;
        // pto: %234
        ;
        const int64_t v347 = 1;
        // pto: %234
        ;
        int64_t v348 = v121 * v21;
        // pto: %234
        ;
        int64_t v349 = v347 * v348;
        // pto: %234
        ;
        pto::Shape<1, 1, 1, -1, 256> v350 = pto::Shape<1, 1, 1, -1, 256>(v345, v346, v347, v121, v23);
        // pto: %234
        ;
        pto::Stride<-1, -1, -1, -1, -1> v351 = pto::Stride<-1, -1, -1, -1, -1>(v346 * v349, v349, v348, v21, v18);
        // pto: %234
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v352 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v344 + (v343 + v127 * v21 + v342 * v18), v350, v351);
        TLOAD(v339, v352);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %19
        ;
        Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v353 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
        // pto: %19
        ;
        uint64_t v354 = (uint64_t) v13;
        TASSIGN(v353, v354);
        // pto: %238
        ;
        int64_t v355 = v338 / v19;
        // pto: %239
        ;
        int64_t v356 = v355 < v27 ? v27 : v355;
        // pto: %240
        ;
        __gm__ bfloat16_t* v357 = PTOAS__GLOBAL_TENSOR_DATA(v61);
        // pto: %240
        ;
        const int64_t v358 = 0;
        // pto: %240
        ;
        const int64_t v359 = 4194304;
        // pto: %240
        ;
        const int64_t v360 = 65536;
        // pto: %240
        ;
        const int64_t v361 = 256;
        // pto: %240
        ;
        pto::Shape<1, 8, 16, 16, 16> v362 = pto::Shape<1, 8, 16, 16, 16>();
        // pto: %240
        ;
        pto::Stride<4194304, 65536, 256, 16, 1> v363 = pto::Stride<4194304, 65536, 256, 16, 1>();
        // pto: %240
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v364 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v357 + ((v358 + v143 * v359) + v145 * v360 + v356 * v361), v362, v363);
        TLOAD(v353, v364);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %20
        ;
        Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v365 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v121, v26);
        // pto: %20
        ;
        uint64_t v366 = (uint64_t) v13;
        TASSIGN(v365, v366);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        uint16_t v367 = static_cast<uint16_t>(v27);
        uint16_t v368 = static_cast<uint16_t>(v27);
        TEXTRACT(v365, v339, v367, v368);
        // pto: %21
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v369 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
        // pto: %21
        ;
        uint64_t v370 = (uint64_t) v13;
        TASSIGN(v369, v370);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v371 = static_cast<uint16_t>(v27);
        uint16_t v372 = static_cast<uint16_t>(v27);
        TEXTRACT(v369, v353, v371, v372);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        // pto: %22
        ;
        Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v373 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v121, v26);
        // pto: %22
        ;
        uint64_t v374 = (uint64_t) v14;
        TASSIGN(v373, v374);
        uint16_t v375 = static_cast<uint16_t>(v27);
        uint16_t v376 = static_cast<uint16_t>(v26);
        TEXTRACT(v373, v339, v375, v376);
        // pto: %23
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v377 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
        // pto: %23
        ;
        uint64_t v378 = (uint64_t) v14;
        TASSIGN(v377, v378);
        uint16_t v379 = static_cast<uint16_t>(v26);
        uint16_t v380 = static_cast<uint16_t>(v27);
        TEXTRACT(v377, v353, v379, v380);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v164, v164, v365, v369);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        TMATMUL_ACC(v164, v164, v373, v377);
      } else {
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        for (int64_t v381 = v27; v381 < v19; v381 += v18) {
          // pto: %242, %243
          ;
          int64_t v382 = (int64_t) ((uint64_t) v336 + (uint64_t) v381) % v23;
          // pto: %244, %245, %246
          ;
          int64_t v383 = v382 < v27 ? (int64_t) ((uint64_t) v382 + (uint64_t) v23) : v382;
          // pto: %247
          ;
          int64_t v384 = (int64_t) ((uint64_t) v383 * (uint64_t) v19);
          // pto: %26
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v385 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v121, v19);
          // pto: %26
          ;
          uint64_t v386 = (uint64_t) v12;
          TASSIGN(v385, v386);
          // pto: %250
          ;
          int64_t v387 = (int64_t) ((uint64_t) v128 + (uint64_t) v384);
          // pto: %251
          ;
          int64_t v388 = v387 < v27 ? v27 : v387;
          // pto: %252
          ;
          const int64_t v389 = 0;
          // pto: %252
          ;
          __gm__ bfloat16_t* v390 = PTOAS__GLOBAL_TENSOR_DATA(v58);
          // pto: %252
          ;
          const int64_t v391 = 1;
          // pto: %252
          ;
          const int64_t v392 = 1;
          // pto: %252
          ;
          const int64_t v393 = 1;
          // pto: %252
          ;
          int64_t v394 = v121 * v21;
          // pto: %252
          ;
          int64_t v395 = v393 * v394;
          // pto: %252
          ;
          pto::Shape<1, 1, 1, -1, 16> v396 = pto::Shape<1, 1, 1, -1, 16>(v391, v392, v393, v121, v19);
          // pto: %252
          ;
          pto::Stride<-1, -1, -1, -1, -1> v397 = pto::Stride<-1, -1, -1, -1, -1>(v392 * v395, v395, v394, v21, v18);
          // pto: %252
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v398 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v390 + (v389 + v127 * v21 + v388 * v18), v396, v397);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          TLOAD(v385, v398);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %27
          ;
          Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v399 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
          // pto: %27
          ;
          uint64_t v400 = (uint64_t) v13;
          TASSIGN(v399, v400);
          // pto: %256
          ;
          int64_t v401 = v384 / v19;
          // pto: %257
          ;
          int64_t v402 = v401 < v27 ? v27 : v401;
          // pto: %258
          ;
          __gm__ bfloat16_t* v403 = PTOAS__GLOBAL_TENSOR_DATA(v61);
          // pto: %258
          ;
          const int64_t v404 = 0;
          // pto: %258
          ;
          const int64_t v405 = 4194304;
          // pto: %258
          ;
          const int64_t v406 = 65536;
          // pto: %258
          ;
          const int64_t v407 = 256;
          // pto: %258
          ;
          pto::Shape<1, 8, 1, 16, 16> v408 = pto::Shape<1, 8, 1, 16, 16>();
          // pto: %258
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v409 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %258
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v410 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v403 + ((v404 + v143 * v405) + v145 * v406 + v402 * v407), v408, v409);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          TLOAD(v399, v410);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %28
          ;
          Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v411 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v121, v19);
          // pto: %28
          ;
          uint64_t v412 = (uint64_t) v13;
          TASSIGN(v411, v412);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
          uint16_t v413 = static_cast<uint16_t>(v27);
          uint16_t v414 = static_cast<uint16_t>(v27);
          TEXTRACT(v411, v385, v413, v414);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %29
          ;
          Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v415 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
          // pto: %29
          ;
          uint64_t v416 = (uint64_t) v13;
          TASSIGN(v415, v416);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          uint16_t v417 = static_cast<uint16_t>(v27);
          uint16_t v418 = static_cast<uint16_t>(v27);
          TEXTRACT(v415, v399, v417, v418);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v164, v164, v411, v415);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        };
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %v4_wide_acc_inline1075__rv_v2
      ;
      Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v419 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v121, v26);
      // pto: %v4_wide_acc_inline1075__rv_v2
      ;
      uint64_t v420 = (uint64_t) v13;
      TASSIGN(v419, v420);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      for (int64_t v421 = v38; v421 < v23; v421 += v18) {
        // pto: %259, %260
        ;
        int64_t v422 = (int64_t) ((uint64_t) v76 + (uint64_t) v421) % v23;
        // pto: %261, %262, %263
        ;
        int64_t v423 = v422 < v27 ? (int64_t) ((uint64_t) v422 + (uint64_t) v23) : v422;
        // pto: %264
        ;
        int64_t v424 = (int64_t) ((uint64_t) v423 * (uint64_t) v19);
        // pto: %v4_wide_tail_x_inline1086__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v425 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v121, v19);
        // pto: %v4_wide_tail_x_inline1086__tile
        ;
        uint64_t v426 = (uint64_t) v12;
        TASSIGN(v425, v426);
        // pto: %267
        ;
        int64_t v427 = (int64_t) ((uint64_t) v128 + (uint64_t) v424);
        // pto: %268
        ;
        int64_t v428 = v427 < v27 ? v27 : v427;
        // pto: %269
        ;
        const int64_t v429 = 0;
        // pto: %269
        ;
        __gm__ bfloat16_t* v430 = PTOAS__GLOBAL_TENSOR_DATA(v58);
        // pto: %269
        ;
        const int64_t v431 = 1;
        // pto: %269
        ;
        const int64_t v432 = 1;
        // pto: %269
        ;
        const int64_t v433 = 1;
        // pto: %269
        ;
        int64_t v434 = v121 * v21;
        // pto: %269
        ;
        int64_t v435 = v433 * v434;
        // pto: %269
        ;
        pto::Shape<1, 1, 1, -1, 16> v436 = pto::Shape<1, 1, 1, -1, 16>(v431, v432, v433, v121, v19);
        // pto: %269
        ;
        pto::Stride<-1, -1, -1, -1, -1> v437 = pto::Stride<-1, -1, -1, -1, -1>(v432 * v435, v435, v434, v21, v18);
        // pto: %269
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v438 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v430 + (v429 + v127 * v21 + v428 * v18), v436, v437);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v425, v438);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %v4_wide_tail_w_inline1088__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v439 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
        // pto: %v4_wide_tail_w_inline1088__tile
        ;
        uint64_t v440 = (uint64_t) v13;
        TASSIGN(v439, v440);
        // pto: %273
        ;
        int64_t v441 = v424 / v19;
        // pto: %274
        ;
        int64_t v442 = v441 < v27 ? v27 : v441;
        // pto: %275
        ;
        __gm__ bfloat16_t* v443 = PTOAS__GLOBAL_TENSOR_DATA(v61);
        // pto: %275
        ;
        const int64_t v444 = 0;
        // pto: %275
        ;
        const int64_t v445 = 4194304;
        // pto: %275
        ;
        const int64_t v446 = 65536;
        // pto: %275
        ;
        const int64_t v447 = 256;
        // pto: %275
        ;
        pto::Shape<1, 8, 1, 16, 16> v448 = pto::Shape<1, 8, 1, 16, 16>();
        // pto: %275
        ;
        pto::Stride<4194304, 65536, 256, 16, 1> v449 = pto::Stride<4194304, 65536, 256, 16, 1>();
        // pto: %275
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v450 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v443 + ((v444 + v143 * v445) + v145 * v446 + v442 * v447), v448, v449);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        TLOAD(v439, v450);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %31
        ;
        Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v451 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v121, v19);
        // pto: %31
        ;
        uint64_t v452 = (uint64_t) v13;
        TASSIGN(v451, v452);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v453 = static_cast<uint16_t>(v27);
        uint16_t v454 = static_cast<uint16_t>(v27);
        TEXTRACT(v451, v425, v453, v454);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        // pto: %32
        ;
        Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v455 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
        // pto: %32
        ;
        uint64_t v456 = (uint64_t) v13;
        TASSIGN(v455, v456);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v457 = static_cast<uint16_t>(v27);
        uint16_t v458 = static_cast<uint16_t>(v27);
        TEXTRACT(v455, v439, v457, v458);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v419, v419, v451, v455);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      // pto: %277, %278
      ;
      int64_t v459 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v39) + (uint64_t) v71);
      // pto: %279
      ;
      int64_t v460 = v459 < v27 ? v27 : v459;
      // pto: %accum_inline1110__iter_v13_pview
      ;
      const int64_t v461 = 0;
      // pto: %accum_inline1110__iter_v13_pview
      ;
      __gm__ float* v462 = PTOAS__GLOBAL_TENSOR_DATA(v49);
      // pto: %accum_inline1110__iter_v13_pview
      ;
      const int64_t v463 = 1;
      // pto: %accum_inline1110__iter_v13_pview
      ;
      const int64_t v464 = 1;
      // pto: %accum_inline1110__iter_v13_pview
      ;
      const int64_t v465 = 1;
      // pto: %accum_inline1110__iter_v13_pview
      ;
      int64_t v466 = v121 * v17;
      // pto: %accum_inline1110__iter_v13_pview
      ;
      int64_t v467 = v465 * v466;
      // pto: %accum_inline1110__iter_v13_pview
      ;
      pto::Shape<1, 1, 1, -1, 128> v468 = pto::Shape<1, 1, 1, -1, 128>(v463, v464, v465, v121, v26);
      // pto: %accum_inline1110__iter_v13_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v469 = pto::Stride<-1, -1, -1, -1, -1>(v464 * v467, v467, v466, v17, v18);
      // pto: %accum_inline1110__iter_v13_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v470 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v462 + (v461 + v127 * v17 + v460 * v18), v468, v469);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      TSTORE(v470, v419);
    } else {
      for (int64_t v471 = v27; v471 < v20; v471 += v18) {
        // pto: %280
        ;
        int64_t v472 = (int64_t) ((uint64_t) v73 + (uint64_t) v471);
        // pto: %281
        ;
        if (v472 < v5) {
          // pto: %282
          ;
          int64_t v473 = (int64_t) ((uint64_t) v472 * (uint64_t) v19);
          // pto: %283
          ;
          int64_t v474 = (int64_t) ((uint64_t) v8 - (uint64_t) v473);
          // pto: %284
          ;
          int64_t v475 = v474 < v19 ? v474 : v19;
          // pto: %286, %287, %288, %289, %285
          ;
          int32_t v476 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v472 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
          // pto: %290
          ;
          int64_t v477 = (int64_t) v476;
          // pto: %291
          ;
          int64_t v478 = v477 < v27 ? v27 : v477;
          // pto: %v4_narrow_acc_inline1093__tile
          ;
          Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v479 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v19, v26);
          // pto: %v4_narrow_acc_inline1093__tile
          ;
          uint64_t v480 = (uint64_t) v13;
          TASSIGN(v479, v480);
          wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          for (int64_t v481 = v27; v481 < v19; v481 += v18) {
            // pto: %292
            ;
            int64_t v482 = (int64_t) ((uint64_t) v481 * (uint64_t) v19);
            // pto: %293, %294
            ;
            int64_t v483 = (int64_t) ((uint64_t) v478 + (uint64_t) v482) % v23;
            // pto: %295, %296, %297
            ;
            int64_t v484 = v483 < v27 ? (int64_t) ((uint64_t) v483 + (uint64_t) v23) : v483;
            // pto: %298
            ;
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            if (v484 <= v36) {
              // pto: %299
              ;
              int64_t v485 = (int64_t) ((uint64_t) v484 * (uint64_t) v19);
              // pto: %v4_narrow_packet_x_inline1024__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v486 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v475, v23);
              // pto: %v4_narrow_packet_x_inline1024__tile
              ;
              uint64_t v487 = (uint64_t) v13;
              TASSIGN(v486, v487);
              // pto: %300
              ;
              int64_t v488 = v473 < v27 ? v27 : v473;
              // pto: %301, %302
              ;
              int64_t v489 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v34) + (uint64_t) v485);
              // pto: %303
              ;
              int64_t v490 = v489 < v27 ? v27 : v489;
              // pto: %304
              ;
              const int64_t v491 = 0;
              // pto: %304
              ;
              __gm__ bfloat16_t* v492 = PTOAS__GLOBAL_TENSOR_DATA(v58);
              // pto: %304
              ;
              const int64_t v493 = 1;
              // pto: %304
              ;
              const int64_t v494 = 1;
              // pto: %304
              ;
              const int64_t v495 = 1;
              // pto: %304
              ;
              int64_t v496 = v475 * v21;
              // pto: %304
              ;
              int64_t v497 = v495 * v496;
              // pto: %304
              ;
              pto::Shape<1, 1, 1, -1, 256> v498 = pto::Shape<1, 1, 1, -1, 256>(v493, v494, v495, v475, v23);
              // pto: %304
              ;
              pto::Stride<-1, -1, -1, -1, -1> v499 = pto::Stride<-1, -1, -1, -1, -1>(v494 * v497, v497, v496, v21, v18);
              // pto: %304
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v500 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v492 + (v491 + v488 * v21 + v490 * v18), v498, v499);
              TLOAD(v486, v500);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              // pto: %v4_narrow_packet_w_inline1049__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v501 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
              // pto: %v4_narrow_packet_w_inline1049__tile
              ;
              uint64_t v502 = (uint64_t) v12;
              TASSIGN(v501, v502);
              // pto: %305
              ;
              int64_t v503 = v6 < v27 ? v27 : v6;
              // pto: %306
              ;
              int64_t v504 = v71 / v19;
              // pto: %307
              ;
              int64_t v505 = v504 < v27 ? v27 : v504;
              // pto: %308
              ;
              int64_t v506 = v485 / v19;
              // pto: %309
              ;
              int64_t v507 = v506 < v27 ? v27 : v506;
              // pto: %310
              ;
              __gm__ bfloat16_t* v508 = PTOAS__GLOBAL_TENSOR_DATA(v61);
              // pto: %310
              ;
              const int64_t v509 = 0;
              // pto: %310
              ;
              const int64_t v510 = 4194304;
              // pto: %310
              ;
              const int64_t v511 = 65536;
              // pto: %310
              ;
              const int64_t v512 = 256;
              // pto: %310
              ;
              pto::Shape<1, 8, 16, 16, 16> v513 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %310
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v514 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %310
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v515 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v508 + ((v509 + v503 * v510) + v505 * v511 + v507 * v512), v513, v514);
              TLOAD(v501, v515);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              // pto: %v4_narrow_acc_inline1093__iter_v1_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v516 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v475, v26);
              // pto: %v4_narrow_acc_inline1093__iter_v1_l0_a
              ;
              uint64_t v517 = (uint64_t) v13;
              TASSIGN(v516, v517);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              uint16_t v518 = static_cast<uint16_t>(v27);
              uint16_t v519 = static_cast<uint16_t>(v27);
              TEXTRACT(v516, v486, v518, v519);
              // pto: %v4_narrow_acc_inline1093__iter_v1_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v520 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
              // pto: %v4_narrow_acc_inline1093__iter_v1_l0_b
              ;
              uint64_t v521 = (uint64_t) v13;
              TASSIGN(v520, v521);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              uint16_t v522 = static_cast<uint16_t>(v27);
              uint16_t v523 = static_cast<uint16_t>(v27);
              TEXTRACT(v520, v501, v522, v523);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              // pto: %33
              ;
              Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v524 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v475, v26);
              // pto: %33
              ;
              uint64_t v525 = (uint64_t) v14;
              TASSIGN(v524, v525);
              uint16_t v526 = static_cast<uint16_t>(v27);
              uint16_t v527 = static_cast<uint16_t>(v26);
              TEXTRACT(v524, v486, v526, v527);
              // pto: %34
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v528 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
              // pto: %34
              ;
              uint64_t v529 = (uint64_t) v14;
              TASSIGN(v528, v529);
              uint16_t v530 = static_cast<uint16_t>(v26);
              uint16_t v531 = static_cast<uint16_t>(v27);
              TEXTRACT(v528, v501, v530, v531);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              // pto: %311
              ;
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              if (v481 == v27) {
                pipe_barrier(PIPE_M);
                TMATMUL(v479, v516, v520);
              } else {
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v479, v479, v516, v520);
              };
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              TMATMUL_ACC(v479, v479, v524, v528);
            } else {
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              for (int64_t v532 = v27; v532 < v19; v532 += v18) {
                // pto: %312, %313
                ;
                int64_t v533 = (int64_t) ((uint64_t) v484 + (uint64_t) v532) % v23;
                // pto: %314, %315, %316
                ;
                int64_t v534 = v533 < v27 ? (int64_t) ((uint64_t) v533 + (uint64_t) v23) : v533;
                // pto: %317
                ;
                int64_t v535 = (int64_t) ((uint64_t) v534 * (uint64_t) v19);
                // pto: %v4_narrow_wrap_x_inline1099__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v536 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v475, v19);
                // pto: %v4_narrow_wrap_x_inline1099__tile
                ;
                uint64_t v537 = (uint64_t) v13;
                TASSIGN(v536, v537);
                // pto: %318
                ;
                int64_t v538 = v473 < v27 ? v27 : v473;
                // pto: %319, %320
                ;
                int64_t v539 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v34) + (uint64_t) v535);
                // pto: %321
                ;
                int64_t v540 = v539 < v27 ? v27 : v539;
                // pto: %322
                ;
                const int64_t v541 = 0;
                // pto: %322
                ;
                __gm__ bfloat16_t* v542 = PTOAS__GLOBAL_TENSOR_DATA(v58);
                // pto: %322
                ;
                const int64_t v543 = 1;
                // pto: %322
                ;
                const int64_t v544 = 1;
                // pto: %322
                ;
                const int64_t v545 = 1;
                // pto: %322
                ;
                int64_t v546 = v475 * v21;
                // pto: %322
                ;
                int64_t v547 = v545 * v546;
                // pto: %322
                ;
                pto::Shape<1, 1, 1, -1, 16> v548 = pto::Shape<1, 1, 1, -1, 16>(v543, v544, v545, v475, v19);
                // pto: %322
                ;
                pto::Stride<-1, -1, -1, -1, -1> v549 = pto::Stride<-1, -1, -1, -1, -1>(v544 * v547, v547, v546, v21, v18);
                // pto: %322
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v550 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v542 + (v541 + v538 * v21 + v540 * v18), v548, v549);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                TLOAD(v536, v550);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                // pto: %v4_narrow_wrap_w_inline1102__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v551 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
                // pto: %v4_narrow_wrap_w_inline1102__tile
                ;
                uint64_t v552 = (uint64_t) v12;
                TASSIGN(v551, v552);
                // pto: %323
                ;
                int64_t v553 = v6 < v27 ? v27 : v6;
                // pto: %324
                ;
                int64_t v554 = v71 / v19;
                // pto: %325
                ;
                int64_t v555 = v554 < v27 ? v27 : v554;
                // pto: %326
                ;
                int64_t v556 = v535 / v19;
                // pto: %327
                ;
                int64_t v557 = v556 < v27 ? v27 : v556;
                // pto: %328
                ;
                __gm__ bfloat16_t* v558 = PTOAS__GLOBAL_TENSOR_DATA(v61);
                // pto: %328
                ;
                const int64_t v559 = 0;
                // pto: %328
                ;
                const int64_t v560 = 4194304;
                // pto: %328
                ;
                const int64_t v561 = 65536;
                // pto: %328
                ;
                const int64_t v562 = 256;
                // pto: %328
                ;
                pto::Shape<1, 8, 1, 16, 16> v563 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %328
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v564 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %328
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v565 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v558 + ((v559 + v553 * v560) + v555 * v561 + v557 * v562), v563, v564);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                TLOAD(v551, v565);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                // pto: %36
                ;
                Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v566 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v475, v19);
                // pto: %36
                ;
                uint64_t v567 = (uint64_t) v13;
                TASSIGN(v566, v567);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                uint16_t v568 = static_cast<uint16_t>(v27);
                uint16_t v569 = static_cast<uint16_t>(v27);
                TEXTRACT(v566, v536, v568, v569);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                // pto: %37
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v570 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
                // pto: %37
                ;
                uint64_t v571 = (uint64_t) v13;
                TASSIGN(v570, v571);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                uint16_t v572 = static_cast<uint16_t>(v27);
                uint16_t v573 = static_cast<uint16_t>(v27);
                TEXTRACT(v570, v551, v572, v573);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                // pto: %330, %331
                ;
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                if ((int64_t) ((uint64_t) v482 + (uint64_t) v532) == v27) {
                  pipe_barrier(PIPE_M);
                  TMATMUL(v479, v566, v570);
                } else {
                  pipe_barrier(PIPE_M);
                  TMATMUL_ACC(v479, v479, v566, v570);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            };
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
          // pto: %333
          ;
          int64_t v574 = v473 < v27 ? v27 : v473;
          // pto: %334, %335
          ;
          int64_t v575 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v39) + (uint64_t) v71);
          // pto: %336
          ;
          int64_t v576 = v575 < v27 ? v27 : v575;
          // pto: %accum_inline1110__iter_v16_pview
          ;
          __gm__ float* v577 = PTOAS__GLOBAL_TENSOR_DATA(v49);
          // pto: %accum_inline1110__iter_v16_pview
          ;
          const int64_t v578 = 0;
          // pto: %accum_inline1110__iter_v16_pview
          ;
          const int64_t v579 = 8192;
          // pto: %accum_inline1110__iter_v16_pview
          ;
          pto::Shape<1, 1, 1, 16, 128> v580 = pto::Shape<1, 1, 1, 16, 128>();
          // pto: %accum_inline1110__iter_v16_pview
          ;
          pto::Stride<131072, 131072, 131072, 8192, 1> v581 = pto::Stride<131072, 131072, 131072, 8192, 1>();
          // pto: %accum_inline1110__iter_v16_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v582 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v577 + (v578 + v574 * v579 + v576), v580, v581);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
          pipe_barrier(PIPE_FIX);
          TSTORE(v582, v479);
          set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        };
      };
    };
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}