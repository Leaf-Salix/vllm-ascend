#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void csa_checked_indices(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ int32_t* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, int64_t v7, int64_t v8, int64_t v9, int64_t v10, int64_t v11, int32_t v12, int32_t v13) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c14400_i64
  const int64_t v14 = 14400;
  // pto: %c0_i64
  const int64_t v15 = 0;
  // pto: %c16448_i64
  const int64_t v16 = 16448;
  // pto: %c18496_i64
  const int64_t v17 = 18496;
  // pto: %c8192_i64
  const int64_t v18 = 8192;
  // pto: %c10240_i64
  const int64_t v19 = 10240;
  // pto: %c12288_i64
  const int64_t v20 = 12288;
  // pto: %c12352_i64
  const int64_t v21 = 12352;
  // pto: %c13376_i64
  const int64_t v22 = 13376;
  // pto: %c1_index
  const int64_t v23 = 1;
  // pto: %c512_index
  const int64_t v24 = 512;
  // pto: %c48_index
  const int64_t v25 = 48;
  // pto: %c0_index
  const int64_t v26 = 0;
  // pto: %c4_index
  const int64_t v27 = 4;
  // pto: %c2147483647_index
  const int64_t v28 = 2147483647;
  // pto: %c2048_index
  const int64_t v29 = 2048;
  const int32_t v30 = 0;
  // pto: %c5_i32
  const int32_t v31 = 5;
  // pto: %c8_index
  const int64_t v32 = 8;
  // pto: %c64_index
  const int64_t v33 = 64;
  // pto: %cst_20
  const float v34 = 16777216.0f;
  // pto: %c16_index
  const int64_t v35 = 16;
  const int32_t v36 = -1;
  // pto: %cst_23
  const float v37 = 0.0f;
  // pto: %c192_index
  const int64_t v38 = 192;
  // pto: %c256_index
  const int64_t v39 = 256;
  // pto: %c2_i32
  const int32_t v40 = 2;
  const int32_t v41 = 1;
  // pto: %c32_index
  const int64_t v42 = 32;
  // pto: %cst_29
  const float v43 = 2097152.0f;
  // pto: %c2_index
  const int64_t v44 = 2;
  // pto: %c1024_index
  const int64_t v45 = 1024;
  // pto: %cmp_block_table__ssa_v0_view
  const int64_t v46 = 1;
  // pto: %cmp_block_table__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %cmp_block_table__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %cmp_block_table__ssa_v0_view
  int64_t v49 = (int64_t) v9;
  // pto: %cmp_block_table__ssa_v0_view
  int64_t v50 = (int64_t) v10;
  // pto: %cmp_block_table__ssa_v0_view
  int64_t v51 = v49 * v50;
  // pto: %cmp_block_table__ssa_v0_view
  int64_t v52 = v48 * v51;
  // pto: %cmp_block_table__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v53 = pto::Shape<1, 1, 1, -1, -1>(v46, v47, v48, v49, (int64_t) v10);
  // pto: %cmp_block_table__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v54 = pto::Stride<-1, -1, -1, -1, -1>(v47 * v52, v52, v51, v50, v23);
  // pto: %cmp_block_table__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v55 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v53, v54);
  // pto: %attention_topk__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %attention_topk__ssa_v0_view
  const int64_t v57 = 1;
  // pto: %attention_topk__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %attention_topk__ssa_v0_view
  int64_t v59 = (int64_t) v8;
  // pto: %attention_topk__ssa_v0_view
  int64_t v60 = v59 * v24;
  // pto: %attention_topk__ssa_v0_view
  int64_t v61 = v58 * v60;
  // pto: %attention_topk__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v62 = pto::Shape<1, 1, 1, -1, -1>(v56, v57, v58, v59, v24);
  // pto: %attention_topk__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v63 = pto::Stride<-1, -1, -1, -1, -1>(v57 * v61, v61, v60, v24, v23);
  // pto: %attention_topk__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v64 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v62, v63);
  // pto: %cmp_sparse_indices_inline5265__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %cmp_sparse_indices_inline5265__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %cmp_sparse_indices_inline5265__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %cmp_sparse_indices_inline5265__ssa_v0_view
  int64_t v68 = (int64_t) v11;
  // pto: %cmp_sparse_indices_inline5265__ssa_v0_view
  int64_t v69 = v68 * v24;
  // pto: %cmp_sparse_indices_inline5265__ssa_v0_view
  int64_t v70 = v67 * v69;
  // pto: %cmp_sparse_indices_inline5265__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v71 = pto::Shape<1, 1, 1, -1, -1>(v65, v66, v67, v68, v24);
  // pto: %cmp_sparse_indices_inline5265__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v66 * v70, v70, v69, v24, v23);
  // pto: %cmp_sparse_indices_inline5265__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v73 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v71, v72);
  // pto: %checked_worker_inline5271__ssa_v0
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_S, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  for (int64_t v74 = (int64_t) v12; v74 < v11; v74 += v25) {
    // pto: %t__tile
    ;
    int64_t v75 = (v1)[v74];
    // pto: %c_request_inline5262__tile
    ;
    int32_t v76 = (v2)[v74];
    // pto: %1
    ;
    int64_t v77 = (int64_t) v76;
    // pto: %2, %4, %5
    ;
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    if (v77 >= v26 & v77 < v9) {
      // pto: %6
      ;
      int32_t v78 = (v3)[v77];
      // pto: %7, %8
      ;
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
      if ((int64_t) v78 > v26) {
        // pto: %9, %10
        ;
        int64_t v79 = (int64_t) ((uint64_t) v75 + (uint64_t) v23) / v27;
        // pto: %12, %13, %14, %15, %16, %17, %18
        ;
        pipe_barrier(PIPE_ALL);
        // pto: %c_vector_done_inline5237__phi_v3
        ;
        int32_t v80;
        if ((v79 >= v26 & v79 <= v28 & v10 > v26) & v10 <= v29) {
          // pto: %c_raw_tile_inline5350__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v81 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
          // pto: %c_raw_tile_inline5350__ssa_v0
          ;
          uint64_t v82 = (uint64_t) v14;
          TASSIGN(v81, v82);
          // pto: %19
          ;
          int64_t v83 = v74 < v26 ? v26 : v74;
          // pto: %attention_topk__ssa_v0_pview
          ;
          __gm__ int32_t* v84 = PTOAS__GLOBAL_TENSOR_DATA(v64);
          // pto: %attention_topk__ssa_v0_pview
          ;
          const int64_t v85 = 0;
          // pto: %attention_topk__ssa_v0_pview
          ;
          const int64_t v86 = 512;
          // pto: %attention_topk__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 1, 512> v87 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %attention_topk__ssa_v0_pview
          ;
          pto::Stride<512, 512, 512, 512, 1> v88 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %attention_topk__ssa_v0_pview
          ;
          GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v89 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v84 + (v85 + v83 * v86), v87, v88);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
          TLOAD(v81, v89);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
          // pto: %c_safe_raw_inline5303__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v90 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
          // pto: %c_safe_raw_inline5303__ssa_v0
          ;
          uint64_t v91 = (uint64_t) v15;
          TASSIGN(v90, v91);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
          pipe_barrier(PIPE_V);
          TMAXS(v90, v81, v30);
          // pto: %c_raw_columns_inline5233__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v92 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
          // pto: %c_raw_columns_inline5233__ssa_v0
          ;
          uint64_t v93 = (uint64_t) v16;
          TASSIGN(v92, v93);
          pipe_barrier(PIPE_V);
          pipe_barrier(PIPE_ALL);
          TSHRS(v92, v90, v31);
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
          // pto: %c_safe_columns_inline5247__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
          // pto: %c_safe_columns_inline5247__ssa_v0
          ;
          uint64_t v95 = (uint64_t) v17;
          TASSIGN(v94, v95);
          // pto: %20, %21
          ;
          int32_t v96 = (int32_t) ((int64_t) (uint64_t) v10 - (uint64_t) v23);
          pipe_barrier(PIPE_V);
          TMINS(v94, v92, v96);
          // pto: %c_table_tile_inline5226__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v10);
          // pto: %c_table_tile_inline5226__ssa_v0
          ;
          uint64_t v98 = (uint64_t) v15;
          TASSIGN(v97, v98);
          // pto: %23
          ;
          int64_t v99 = v77 < v26 ? v26 : v77;
          // pto: %cmp_block_table__ssa_v0_pview
          ;
          int64_t v100 = (int64_t) v10;
          // pto: %cmp_block_table__ssa_v0_pview
          ;
          const int64_t v101 = 0;
          // pto: %cmp_block_table__ssa_v0_pview
          ;
          __gm__ int32_t* v102 = PTOAS__GLOBAL_TENSOR_DATA(v55);
          // pto: %cmp_block_table__ssa_v0_pview
          ;
          const int64_t v103 = 1;
          // pto: %cmp_block_table__ssa_v0_pview
          ;
          const int64_t v104 = 1;
          // pto: %cmp_block_table__ssa_v0_pview
          ;
          const int64_t v105 = 1;
          // pto: %cmp_block_table__ssa_v0_pview
          ;
          int64_t v106 = v23 * v100;
          // pto: %cmp_block_table__ssa_v0_pview
          ;
          int64_t v107 = v105 * v106;
          // pto: %cmp_block_table__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 1, -1> v108 = pto::Shape<1, 1, 1, 1, -1>(v103, v104, v105, v23, (int64_t) v10);
          // pto: %cmp_block_table__ssa_v0_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v109 = pto::Stride<-1, -1, -1, -1, -1>(v104 * v107, v107, v106, v100, v23);
          // pto: %cmp_block_table__ssa_v0_pview
          ;
          GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v110 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v102 + (v101 + v99 * v100 + v26 * v23), v108, v109);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
          TLOAD(v97, v110);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
          // pto: %t__tmp_v869
          ;
          Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
          // pto: %t__tmp_v869
          ;
          uint64_t v112 = (uint64_t) v18;
          TASSIGN(v111, v112);
          // pto: %c_page_tile_inline5225__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
          // pto: %c_page_tile_inline5225__ssa_v0
          ;
          uint64_t v114 = (uint64_t) v19;
          TASSIGN(v113, v114);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
          pipe_barrier(PIPE_V);
          wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
          TGATHER(v113, v97, v94, v111);
          // pto: %c_pages_f32_inline5218__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v115 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
          // pto: %c_pages_f32_inline5218__ssa_v0
          ;
          uint64_t v116 = (uint64_t) v15;
          TASSIGN(v115, v116);
          pipe_barrier(PIPE_V);
          RoundMode v117 = RoundMode::CAST_ROUND;
          SaturationMode v118 = SaturationMode::ON;
          TCVT(v115, v113, v117, v118);
          // pto: %t__tmp_v870
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v119 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
          // pto: %t__tmp_v870
          ;
          uint64_t v120 = (uint64_t) v15;
          TASSIGN(v119, v120);
          // pto: %t__tmp_v871
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
          // pto: %t__tmp_v871
          ;
          uint64_t v122 = (uint64_t) v17;
          TASSIGN(v121, v122);
          // pto: %c_max_pages_inline5228__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v123 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v23);
          // pto: %c_max_pages_inline5228__ssa_v0
          ;
          uint64_t v124 = (uint64_t) v18;
          TASSIGN(v123, v124);
          pipe_barrier(PIPE_V);
          TROWMAX(v123, v119, v121);
          set_flag(PIPE_V, PIPE_S, EVENT_ID0);
          wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
          // pto: %c_pages_safe_inline5320__rv_v2
          ;
          int32_t v125;
          v125 = v41;
          for (int64_t v126 = v26; v126 < v32; v126 += v23) {
            // pto: %t__tmp_v872
            ;
            float v127 = v123.GetValue(v126);
            // pto: %27
            ;
            bool v128 = v34 != v34 || v127 != v127;
            // pto: %27, %c_pages_safe_inline5320__phi_v4
            ;
            int32_t v129 = (v34 == v34 && v127 == v127) && v34 <= v127 ? v30 : v125;
            v125 = v129;
          };
          set_flag(PIPE_S, PIPE_V, EVENT_ID1);
          set_flag(PIPE_S, PIPE_V, EVENT_ID0);
          // pto: %29
          ;
          int64_t v130 = (int64_t) v125;
          // pto: %30
          ;
          bool v131 = v130 > v26;
          wait_flag(PIPE_S, PIPE_V, EVENT_ID1);
          // pto: %c_vector_done_inline5237__phi_v2
          ;
          if (v131) {
            // pto: %scratch_inline1587_inline5241__ssa_v0
            ;
            Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v132 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v35);
            // pto: %scratch_inline1587_inline5241__ssa_v0
            ;
            uint64_t v133 = (uint64_t) v20;
            TASSIGN(v132, v133);
            // pto: %missing_inline1570_inline5282__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v134 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %missing_inline1570_inline5282__ssa_v0
            ;
            uint64_t v135 = (uint64_t) v15;
            TASSIGN(v134, v135);
            pipe_barrier(PIPE_V);
            TEXPANDS(v134, v36);
            // pto: %t__tmp_v873
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v136 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v873
            ;
            uint64_t v137 = (uint64_t) v17;
            TASSIGN(v136, v137);
            RoundMode v138 = RoundMode::CAST_ROUND;
            SaturationMode v139 = SaturationMode::ON;
            TCVT(v136, v81, v138, v139);
            // pto: %t__tmp_v874
            ;
            Tile<TileType::Vec, uint8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v140 = Tile<TileType::Vec, uint8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v33);
            // pto: %t__tmp_v874
            ;
            uint64_t v141 = (uint64_t) v18;
            TASSIGN(v140, v141);
            pipe_barrier(PIPE_V);
            CmpMode v142 = CmpMode::GE;
            TCMPS(v140, v136, v37, v142);
            // pto: %checked_inline1568_inline5373__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v143 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %checked_inline1568_inline5373__ssa_v0
            ;
            uint64_t v144 = (uint64_t) v17;
            TASSIGN(v143, v144);
            pipe_barrier(PIPE_V);
            TSEL(v143, v140, v81, v134, v132);
            // pto: %t__tmp_v875
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v145 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v875
            ;
            uint64_t v146 = (uint64_t) v18;
            TASSIGN(v145, v146);
            pipe_barrier(PIPE_V);
            TMAXS(v145, v81, v30);
            // pto: %t__tmp_v876
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v147 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v876
            ;
            uint64_t v148 = (uint64_t) v18;
            TASSIGN(v147, v148);
            // pto: %32, %31
            ;
            int32_t v149 = (int32_t) ((uint32_t) v30 - (uint32_t) ((int32_t) v79));
            pipe_barrier(PIPE_V);
            TADDS(v147, v145, v149);
            // pto: %t__tmp_v877
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v150 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v877
            ;
            uint64_t v151 = (uint64_t) v18;
            TASSIGN(v150, v151);
            pipe_barrier(PIPE_V);
            RoundMode v152 = RoundMode::CAST_ROUND;
            SaturationMode v153 = SaturationMode::ON;
            TCVT(v150, v147, v152, v153);
            // pto: %t__tmp_v878
            ;
            Tile<TileType::Vec, uint8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v154 = Tile<TileType::Vec, uint8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v33);
            // pto: %t__tmp_v878
            ;
            uint64_t v155 = (uint64_t) v18;
            TASSIGN(v154, v155);
            pipe_barrier(PIPE_V);
            CmpMode v156 = CmpMode::LT;
            TCMPS(v154, v150, v37, v156);
            // pto: %checked_v1_inline1567_inline5220__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %checked_v1_inline1567_inline5220__ssa_v0
            ;
            uint64_t v158 = (uint64_t) v17;
            TASSIGN(v157, v158);
            pipe_barrier(PIPE_V);
            TSEL(v157, v154, v143, v134, v132);
            // pto: %t__tmp_v879
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v159 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v879
            ;
            uint64_t v160 = (uint64_t) v16;
            TASSIGN(v159, v160);
            // pto: %36, %35
            ;
            int32_t v161 = (int32_t) ((uint32_t) v30 - (uint32_t) ((int32_t) v10));
            TADDS(v159, v92, v161);
            // pto: %t__tmp_v880
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v162 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v880
            ;
            uint64_t v163 = (uint64_t) v16;
            TASSIGN(v162, v163);
            pipe_barrier(PIPE_V);
            RoundMode v164 = RoundMode::CAST_ROUND;
            SaturationMode v165 = SaturationMode::ON;
            TCVT(v162, v159, v164, v165);
            // pto: %t__tmp_v881
            ;
            Tile<TileType::Vec, uint8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v166 = Tile<TileType::Vec, uint8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v33);
            // pto: %t__tmp_v881
            ;
            uint64_t v167 = (uint64_t) v18;
            TASSIGN(v166, v167);
            pipe_barrier(PIPE_V);
            CmpMode v168 = CmpMode::LT;
            TCMPS(v166, v162, v37, v168);
            // pto: %checked_v2_inline1566_inline5332__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %checked_v2_inline1566_inline5332__ssa_v0
            ;
            uint64_t v170 = (uint64_t) v16;
            TASSIGN(v169, v170);
            pipe_barrier(PIPE_V);
            TSEL(v169, v166, v157, v134, v132);
            // pto: %t__tmp_v882
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v171 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v882
            ;
            uint64_t v172 = (uint64_t) v17;
            TASSIGN(v171, v172);
            pipe_barrier(PIPE_V);
            RoundMode v173 = RoundMode::CAST_ROUND;
            SaturationMode v174 = SaturationMode::ON;
            TCVT(v171, v113, v173, v174);
            // pto: %t__tmp_v883
            ;
            Tile<TileType::Vec, uint8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Vec, uint8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v33);
            // pto: %t__tmp_v883
            ;
            uint64_t v176 = (uint64_t) v17;
            TASSIGN(v175, v176);
            pipe_barrier(PIPE_V);
            CmpMode v177 = CmpMode::GE;
            TCMPS(v175, v171, v37, v177);
            // pto: %checked_v3_inline1565_inline5423__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v178 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %checked_v3_inline1565_inline5423__ssa_v0
            ;
            uint64_t v179 = (uint64_t) v15;
            TASSIGN(v178, v179);
            pipe_barrier(PIPE_V);
            TSEL(v178, v175, v169, v134, v132);
            // pto: %safe_raw_inline1563_inline5290__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v180 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %safe_raw_inline1563_inline5290__ssa_v0
            ;
            uint64_t v181 = (uint64_t) v14;
            TASSIGN(v180, v181);
            TMAXS(v180, v81, v30);
            // pto: %t__tmp_v884
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v182 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v884
            ;
            uint64_t v183 = (uint64_t) v16;
            TASSIGN(v182, v183);
            pipe_barrier(PIPE_V);
            TMAXS(v182, v113, v30);
            // pto: %t__tmp_v885
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v184 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v885
            ;
            uint64_t v185 = (uint64_t) v16;
            TASSIGN(v184, v185);
            pipe_barrier(PIPE_V);
            TSHLS(v184, v182, v31);
            // pto: %t__tmp_v886
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v186 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v886
            ;
            uint64_t v187 = (uint64_t) v17;
            TASSIGN(v186, v187);
            TSHRS(v186, v180, v31);
            // pto: %t__tmp_v887
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v188 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v887
            ;
            uint64_t v189 = (uint64_t) v17;
            TASSIGN(v188, v189);
            pipe_barrier(PIPE_V);
            TSHLS(v188, v186, v31);
            // pto: %t__tmp_v888
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v190 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v888
            ;
            uint64_t v191 = (uint64_t) v14;
            TASSIGN(v190, v191);
            pipe_barrier(PIPE_V);
            TSUB(v190, v180, v188);
            // pto: %physical_inline1562_inline5274__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v192 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %physical_inline1562_inline5274__ssa_v0
            ;
            uint64_t v193 = (uint64_t) v14;
            TASSIGN(v192, v193);
            pipe_barrier(PIPE_V);
            TADD(v192, v184, v190);
            // pto: %t__ci_tmp_v0
            ;
            Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v194 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v38);
            // pto: %t__ci_tmp_v0
            ;
            uint64_t v195 = (uint64_t) v17;
            TASSIGN(v194, v195);
            // pto: %t__tmp_v889
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v196 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %t__tmp_v889
            ;
            uint64_t v197 = (uint64_t) v16;
            TASSIGN(v196, v197);
            // pto: %ci_tmp_view
            ;
            Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v198;
            TRESHAPE(v198, v194);
            // pto: %ci_dst_view
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, 1, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v199;
            TRESHAPE(v199, v196);
            pipe_barrier(PIPE_V);
            TCI<Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, 1, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v199, v30, v198);
            // pto: %pair_columns_inline1560_inline5267__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v200 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %pair_columns_inline1560_inline5267__ssa_v0
            ;
            uint64_t v201 = (uint64_t) v16;
            TASSIGN(v200, v201);
            pipe_barrier(PIPE_V);
            TMULS(v200, v196, v40);
            // pto: %odd_columns_inline1571_inline5292__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v202 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %odd_columns_inline1571_inline5292__ssa_v0
            ;
            uint64_t v203 = (uint64_t) v17;
            TASSIGN(v202, v203);
            pipe_barrier(PIPE_V);
            TADDS(v202, v200, v41);
            // pto: %gather_tmp_inline1564_inline5322__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v204 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %gather_tmp_inline1564_inline5322__ssa_v0
            ;
            uint64_t v205 = (uint64_t) v18;
            TASSIGN(v204, v205);
            // pto: %first_inline1569_inline5382__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v206 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %first_inline1569_inline5382__ssa_v0
            ;
            uint64_t v207 = (uint64_t) v19;
            TASSIGN(v206, v207);
            TGATHER(v206, v178, v200, v204);
            // pto: %second_inline1561_inline5421__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v208 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %second_inline1561_inline5421__ssa_v0
            ;
            uint64_t v209 = (uint64_t) v21;
            TASSIGN(v208, v209);
            pipe_barrier(PIPE_V);
            TGATHER(v208, v178, v202, v204);
            // pto: %first_row_inline1572_inline5407__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v210 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %first_row_inline1572_inline5407__ssa_v0
            ;
            uint64_t v211 = (uint64_t) v22;
            TASSIGN(v210, v211);
            pipe_barrier(PIPE_V);
            TGATHER(v210, v192, v200, v204);
            // pto: %second_row_inline1578_inline5277__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v212 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %second_row_inline1578_inline5277__ssa_v0
            ;
            uint64_t v213 = (uint64_t) v16;
            TASSIGN(v212, v213);
            pipe_barrier(PIPE_V);
            TGATHER(v212, v192, v202, v204);
            // pto: %difference_inline1575_inline5302__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v214 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %difference_inline1575_inline5302__ssa_v0
            ;
            uint64_t v215 = (uint64_t) v14;
            TASSIGN(v214, v215);
            pipe_barrier(PIPE_V);
            TSUB(v214, v210, v212);
            // pto: %zero_inline1576_inline5345__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v216 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %zero_inline1576_inline5345__ssa_v0
            ;
            uint64_t v217 = (uint64_t) v16;
            TASSIGN(v216, v217);
            pipe_barrier(PIPE_V);
            TEXPANDS(v216, v30);
            // pto: %swap_inline1579_inline5306__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %swap_inline1579_inline5306__ssa_v0
            ;
            uint64_t v219 = (uint64_t) v17;
            TASSIGN(v218, v219);
            TEXPANDS(v218, v41);
            // pto: %t__tmp_v890
            ;
            Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %t__tmp_v890
            ;
            uint64_t v221 = (uint64_t) v18;
            TASSIGN(v220, v221);
            RoundMode v222 = RoundMode::CAST_ROUND;
            SaturationMode v223 = SaturationMode::ON;
            TCVT(v220, v206, v222, v223);
            // pto: %t__tmp_v891
            ;
            Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v224 = Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v42);
            // pto: %t__tmp_v891
            ;
            uint64_t v225 = (uint64_t) v18;
            TASSIGN(v224, v225);
            pipe_barrier(PIPE_V);
            CmpMode v226 = CmpMode::GE;
            TCMPS(v224, v220, v37, v226);
            // pto: %swap_v1_inline1577_inline5231__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v227 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %swap_v1_inline1577_inline5231__ssa_v0
            ;
            uint64_t v228 = (uint64_t) v17;
            TASSIGN(v227, v228);
            pipe_barrier(PIPE_V);
            TSEL(v227, v224, v218, v216, v132);
            // pto: %t__tmp_v892
            ;
            Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v229 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %t__tmp_v892
            ;
            uint64_t v230 = (uint64_t) v18;
            TASSIGN(v229, v230);
            pipe_barrier(PIPE_V);
            RoundMode v231 = RoundMode::CAST_ROUND;
            SaturationMode v232 = SaturationMode::ON;
            TCVT(v229, v208, v231, v232);
            // pto: %t__tmp_v893
            ;
            Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v233 = Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v42);
            // pto: %t__tmp_v893
            ;
            uint64_t v234 = (uint64_t) v18;
            TASSIGN(v233, v234);
            pipe_barrier(PIPE_V);
            CmpMode v235 = CmpMode::GE;
            TCMPS(v233, v229, v37, v235);
            // pto: %swap_v2_inline1573_inline5287__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v236 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %swap_v2_inline1573_inline5287__ssa_v0
            ;
            uint64_t v237 = (uint64_t) v17;
            TASSIGN(v236, v237);
            pipe_barrier(PIPE_V);
            TSEL(v236, v233, v227, v216, v132);
            // pto: %t__tmp_v894
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v238 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %t__tmp_v894
            ;
            uint64_t v239 = (uint64_t) v18;
            TASSIGN(v238, v239);
            // pto: %41, %42
            ;
            int32_t v240 = (int32_t) ((int64_t) (uint64_t) v23 - (uint64_t) v79);
            pipe_barrier(PIPE_V);
            TADDS(v238, v206, v240);
            // pto: %t__tmp_v895
            ;
            Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v241 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %t__tmp_v895
            ;
            uint64_t v242 = (uint64_t) v18;
            TASSIGN(v241, v242);
            pipe_barrier(PIPE_V);
            RoundMode v243 = RoundMode::CAST_ROUND;
            SaturationMode v244 = SaturationMode::ON;
            TCVT(v241, v238, v243, v244);
            // pto: %t__tmp_v896
            ;
            Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v245 = Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v42);
            // pto: %t__tmp_v896
            ;
            uint64_t v246 = (uint64_t) v18;
            TASSIGN(v245, v246);
            pipe_barrier(PIPE_V);
            CmpMode v247 = CmpMode::LT;
            TCMPS(v245, v241, v37, v247);
            // pto: %swap_v3_inline1583_inline5286__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v248 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %swap_v3_inline1583_inline5286__ssa_v0
            ;
            uint64_t v249 = (uint64_t) v17;
            TASSIGN(v248, v249);
            pipe_barrier(PIPE_V);
            TSEL(v248, v245, v236, v216, v132);
            // pto: %t__tmp_v897
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v250 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %t__tmp_v897
            ;
            uint64_t v251 = (uint64_t) v18;
            TASSIGN(v250, v251);
            pipe_barrier(PIPE_V);
            TADDS(v250, v208, v240);
            // pto: %t__tmp_v898
            ;
            Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v252 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %t__tmp_v898
            ;
            uint64_t v253 = (uint64_t) v18;
            TASSIGN(v252, v253);
            pipe_barrier(PIPE_V);
            RoundMode v254 = RoundMode::CAST_ROUND;
            SaturationMode v255 = SaturationMode::ON;
            TCVT(v252, v250, v254, v255);
            // pto: %t__tmp_v899
            ;
            Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v256 = Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v42);
            // pto: %t__tmp_v899
            ;
            uint64_t v257 = (uint64_t) v18;
            TASSIGN(v256, v257);
            pipe_barrier(PIPE_V);
            CmpMode v258 = CmpMode::LT;
            TCMPS(v256, v252, v37, v258);
            // pto: %swap_v4_inline1580_inline5208__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v259 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %swap_v4_inline1580_inline5208__ssa_v0
            ;
            uint64_t v260 = (uint64_t) v17;
            TASSIGN(v259, v260);
            pipe_barrier(PIPE_V);
            TSEL(v259, v256, v248, v216, v132);
            // pto: %t__tmp_v900
            ;
            Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v261 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %t__tmp_v900
            ;
            uint64_t v262 = (uint64_t) v18;
            TASSIGN(v261, v262);
            pipe_barrier(PIPE_V);
            RoundMode v263 = RoundMode::CAST_ROUND;
            SaturationMode v264 = SaturationMode::ON;
            TCVT(v261, v214, v263, v264);
            // pto: %t__tmp_v901
            ;
            Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v265 = Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v42);
            // pto: %t__tmp_v901
            ;
            uint64_t v266 = (uint64_t) v18;
            TASSIGN(v265, v266);
            pipe_barrier(PIPE_V);
            CmpMode v267 = CmpMode::GT;
            TCMPS(v265, v261, v37, v267);
            // pto: %swap_v5_inline1582_inline5214__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v268 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %swap_v5_inline1582_inline5214__ssa_v0
            ;
            uint64_t v269 = (uint64_t) v17;
            TASSIGN(v268, v269);
            pipe_barrier(PIPE_V);
            TSEL(v268, v265, v259, v216, v132);
            // pto: %t__tmp_v902
            ;
            Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v270 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %t__tmp_v902
            ;
            uint64_t v271 = (uint64_t) v14;
            TASSIGN(v270, v271);
            RoundMode v272 = RoundMode::CAST_ROUND;
            SaturationMode v273 = SaturationMode::ON;
            TCVT(v270, v214, v272, v273);
            // pto: %t__tmp_v903
            ;
            Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v274 = Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v42);
            // pto: %t__tmp_v903
            ;
            uint64_t v275 = (uint64_t) v14;
            TASSIGN(v274, v275);
            pipe_barrier(PIPE_V);
            CmpMode v276 = CmpMode::LE;
            TCMPS(v274, v270, v43, v276);
            // pto: %swap_v6_inline1574_inline5204__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v277 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %swap_v6_inline1574_inline5204__ssa_v0
            ;
            uint64_t v278 = (uint64_t) v19;
            TASSIGN(v277, v278);
            pipe_barrier(PIPE_V);
            TSEL(v277, v274, v268, v216, v132);
            // pto: %output_columns_inline1584_inline5313__ci_tmp_v1
            ;
            Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v279 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v38);
            // pto: %output_columns_inline1584_inline5313__ci_tmp_v1
            ;
            uint64_t v280 = (uint64_t) v16;
            TASSIGN(v279, v280);
            // pto: %output_columns_inline1584_inline5313__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v281 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %output_columns_inline1584_inline5313__ssa_v0
            ;
            uint64_t v282 = (uint64_t) v14;
            TASSIGN(v281, v282);
            // pto: %47
            ;
            Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v283;
            TRESHAPE(v283, v279);
            // pto: %48
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v284;
            TRESHAPE(v284, v281);
            pipe_barrier(PIPE_V);
            TCI<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v284, v30, v283);
            // pto: %pair_ids_inline1585_inline5260__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v285 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %pair_ids_inline1585_inline5260__ssa_v0
            ;
            uint64_t v286 = (uint64_t) v16;
            TASSIGN(v285, v286);
            pipe_barrier(PIPE_V);
            TSHRS(v285, v281, v41);
            // pto: %output_tmp_inline1581_inline5248__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v287 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %output_tmp_inline1581_inline5248__ssa_v0
            ;
            uint64_t v288 = (uint64_t) v17;
            TASSIGN(v287, v288);
            // pto: %duplicate_swap_inline1586_inline5264__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v289 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %duplicate_swap_inline1586_inline5264__ssa_v0
            ;
            uint64_t v290 = (uint64_t) v18;
            TASSIGN(v289, v290);
            pipe_barrier(PIPE_V);
            TGATHER(v289, v277, v285, v287);
            // pto: %t__tmp_v904
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v291 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v904
            ;
            uint64_t v292 = (uint64_t) v16;
            TASSIGN(v291, v292);
            pipe_barrier(PIPE_V);
            TEXPANDS(v291, v41);
            // pto: %t__tmp_v905
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v293 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v905
            ;
            uint64_t v294 = (uint64_t) v19;
            TASSIGN(v293, v294);
            TSHRS(v293, v281, v41);
            // pto: %t__tmp_v906
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v295 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v906
            ;
            uint64_t v296 = (uint64_t) v19;
            TASSIGN(v295, v296);
            pipe_barrier(PIPE_V);
            TSHLS(v295, v293, v41);
            // pto: %t__tmp_v907
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v297 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v907
            ;
            uint64_t v298 = (uint64_t) v19;
            TASSIGN(v297, v298);
            pipe_barrier(PIPE_V);
            TSUB(v297, v281, v295);
            // pto: %t__tmp_v908
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v299 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v908
            ;
            uint64_t v300 = (uint64_t) v19;
            TASSIGN(v299, v300);
            pipe_barrier(PIPE_V);
            TMULS(v299, v297, v40);
            // pto: %offset_inline1588_inline5314__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v301 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %offset_inline1588_inline5314__ssa_v0
            ;
            uint64_t v302 = (uint64_t) v16;
            TASSIGN(v301, v302);
            pipe_barrier(PIPE_V);
            TSUB(v301, v291, v299);
            // pto: %t__tmp_v909
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v303 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v909
            ;
            uint64_t v304 = (uint64_t) v16;
            TASSIGN(v303, v304);
            pipe_barrier(PIPE_V);
            TMUL(v303, v289, v301);
            // pto: %order_inline1559_inline5256__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v305 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %order_inline1559_inline5256__ssa_v0
            ;
            uint64_t v306 = (uint64_t) v14;
            TASSIGN(v305, v306);
            pipe_barrier(PIPE_V);
            TADD(v305, v281, v303);
            // pto: %c_reordered_inline5278__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v307 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %c_reordered_inline5278__ssa_v0
            ;
            uint64_t v308 = (uint64_t) v16;
            TASSIGN(v307, v308);
            pipe_barrier(PIPE_V);
            TGATHER(v307, v178, v305, v287);
            set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
            // pto: %cmp_sparse_indices_inline5265__ssa_v0_pview
            ;
            __gm__ int32_t* v309 = PTOAS__GLOBAL_TENSOR_DATA(v73);
            // pto: %cmp_sparse_indices_inline5265__ssa_v0_pview
            ;
            const int64_t v310 = 0;
            // pto: %cmp_sparse_indices_inline5265__ssa_v0_pview
            ;
            const int64_t v311 = 512;
            // pto: %cmp_sparse_indices_inline5265__ssa_v0_pview
            ;
            pto::Shape<1, 1, 1, 1, 512> v312 = pto::Shape<1, 1, 1, 1, 512>();
            // pto: %cmp_sparse_indices_inline5265__ssa_v0_pview
            ;
            pto::Stride<512, 512, 512, 512, 1> v313 = pto::Stride<512, 512, 512, 512, 1>();
            // pto: %cmp_sparse_indices_inline5265__ssa_v0_pview
            ;
            GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v314 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v309 + (v310 + v83 * v311), v312, v313);
            wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
            TSTORE(v314, v307);
          };
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
          v80 = (int32_t) v131;
        } else {
          v80 = v30;
        };
        // pto: %51
        ;
        int64_t v315 = (int64_t) v80;
        // pto: %52
        ;
        if (v315 == v26) {
          // pto: %c_scalar_output_inline5323__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v316 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
          // pto: %c_scalar_output_inline5323__ssa_v0
          ;
          uint64_t v317 = (uint64_t) v15;
          TASSIGN(v316, v317);
          pipe_barrier(PIPE_V);
          pipe_barrier(PIPE_ALL);
          TEXPANDS(v316, v36);
          set_flag(PIPE_V, PIPE_S, EVENT_ID1);
          set_flag(PIPE_V, PIPE_S, EVENT_ID2);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
          wait_flag(PIPE_V, PIPE_S, EVENT_ID1);
          wait_flag(PIPE_V, PIPE_S, EVENT_ID2);
          for (int64_t v318 = v26; v318 < v39; v318 += v23) {
            // pto: %53
            ;
            int64_t v319 = (int64_t) ((uint64_t) v318 * (uint64_t) v44);
            // pto: %54
            ;
            int64_t v320 = (int64_t) ((uint64_t) v74 * (uint64_t) v24);
            // pto: %55, %c_first_inline5261__tile
            ;
            int32_t v321 = (v5)[(int64_t) ((uint64_t) v320 + (uint64_t) v319)];
            // pto: %56
            ;
            int64_t v322 = (int64_t) ((uint64_t) v319 + (uint64_t) v23);
            // pto: %58, %c_second_inline5222__tile
            ;
            int32_t v323 = (v5)[(int64_t) ((uint64_t) v320 + (uint64_t) v322)];
            // pto: %61
            ;
            int64_t v324 = (int64_t) v321;
            // pto: %62, %64, %65
            ;
            // pto: %c_first_page_inline5300__phi_v3
            ;
            int32_t v325;
            if (v324 >= v26 & v324 < v79) {
              // pto: %67
              ;
              int64_t v326 = v324 / v42;
              // pto: %68
              ;
              // pto: %c_first_page_inline5300__phi_v2
              ;
              int32_t v327;
              if (v326 < v10) {
                // pto: %70, %71, %c_first_page_inline5300__tile
                ;
                int32_t v328 = (v4)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v77 * (uint64_t) v10) + (uint64_t) v326)];
                v327 = v328;
              } else {
                v327 = v36;
              };
              v325 = v327;
            } else {
              v325 = v36;
            };
            // pto: %72
            ;
            int64_t v329 = (int64_t) v323;
            // pto: %73, %75, %76
            ;
            // pto: %c_second_page_inline5212__phi_v3
            ;
            int32_t v330;
            if (v329 >= v26 & v329 < v79) {
              // pto: %78
              ;
              int64_t v331 = v329 / v42;
              // pto: %79
              ;
              // pto: %c_second_page_inline5212__phi_v2
              ;
              int32_t v332;
              if (v331 < v10) {
                // pto: %81, %82, %c_second_page_inline5212__tile
                ;
                int32_t v333 = (v4)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v77 * (uint64_t) v10) + (uint64_t) v331)];
                v332 = v333;
              } else {
                v332 = v36;
              };
              v330 = v332;
            } else {
              v330 = v36;
            };
            // pto: %83
            ;
            int64_t v334 = (int64_t) v325;
            // pto: %84, %c_first_inline5261__phi_v2
            ;
            int32_t v335 = v334 < v26 ? v36 : v321;
            // pto: %86
            ;
            int64_t v336 = (int64_t) v330;
            // pto: %87, %c_second_inline5222__phi_v2
            ;
            int32_t v337 = v336 < v26 ? v36 : v323;
            // pto: %89
            ;
            int64_t v338 = (int64_t) v335;
            // pto: %90
            ;
            int64_t v339 = (int64_t) v337;
            // pto: %93, %95, %96
            ;
            // pto: %c_swap_inline5203__phi_v5
            ;
            int32_t v340;
            if (v338 >= v26 & v339 >= v26) {
              // pto: %97, %98, %99, %100, %101
              ;
              // pto: %c_swap_inline5203__phi_v4
              ;
              int32_t v341;
              if ((int64_t) ((uint64_t) v338 + (uint64_t) v23) < v79 & (int64_t) ((uint64_t) v339 + (uint64_t) v23) < v79) {
                // pto: %83
                ;
                int64_t v342 = (int64_t) v325;
                // pto: %104
                ;
                int64_t v343 = v338 % v42;
                // pto: %105, %106, %107
                ;
                int64_t v344 = v343 < v26 ? (int64_t) ((uint64_t) v343 + (uint64_t) v42) : v343;
                // pto: %103, %108
                ;
                int64_t v345 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v342 * (uint64_t) v42) + (uint64_t) v344);
                // pto: %86
                ;
                int64_t v346 = (int64_t) v330;
                // pto: %111
                ;
                int64_t v347 = v339 % v42;
                // pto: %112, %113, %114
                ;
                int64_t v348 = v347 < v26 ? (int64_t) ((uint64_t) v347 + (uint64_t) v42) : v347;
                // pto: %110, %115
                ;
                int64_t v349 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v346 * (uint64_t) v42) + (uint64_t) v348);
                // pto: %116
                ;
                // pto: %c_swap_inline5203__phi_v3
                ;
                int32_t v350;
                if (v349 < v345) {
                  // pto: %117, %118, %119, %120, %c_swap_inline5203__phi_v2
                  ;
                  v350 = (int32_t) ((int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v345 - (uint64_t) v349) - (uint64_t) v23) * (uint64_t) v45) < v28);
                } else {
                  v350 = v30;
                };
                v341 = v350;
              } else {
                v341 = v30;
              };
              v340 = v341;
            } else {
              v340 = v30;
            };
            // pto: %122
            ;
            int64_t v351 = (int64_t) v340;
            // pto: %123
            ;
            if (v351 > v26) {
              v316.SetValue(v319, v337);
              v316.SetValue(v322, v335);
            } else {
              v316.SetValue(v319, v335);
              v316.SetValue(v322, v337);
            };
          };
          set_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
          set_flag(PIPE_S, PIPE_MTE3, EVENT_ID1);
          // pto: %134
          ;
          int64_t v352 = v74 < v26 ? v26 : v74;
          // pto: %135
          ;
          __gm__ int32_t* v353 = PTOAS__GLOBAL_TENSOR_DATA(v73);
          // pto: %135
          ;
          const int64_t v354 = 0;
          // pto: %135
          ;
          const int64_t v355 = 512;
          // pto: %135
          ;
          pto::Shape<1, 1, 1, 1, 512> v356 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %135
          ;
          pto::Stride<512, 512, 512, 512, 1> v357 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %135
          ;
          GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v358 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v353 + (v354 + v352 * v355), v356, v357);
          wait_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
          wait_flag(PIPE_S, PIPE_MTE3, EVENT_ID1);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
          pipe_barrier(PIPE_MTE3);
          TSTORE(v358, v316);
        };
      } else {
        // pto: %c_inactive_inline5280__ssa_v0
        ;
        Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v359 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
        // pto: %c_inactive_inline5280__ssa_v0
        ;
        uint64_t v360 = (uint64_t) v15;
        TASSIGN(v359, v360);
        pipe_barrier(PIPE_V);
        pipe_barrier(PIPE_ALL);
        TEXPANDS(v359, v36);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        // pto: %136
        ;
        int64_t v361 = v74 < v26 ? v26 : v74;
        // pto: %137
        ;
        __gm__ int32_t* v362 = PTOAS__GLOBAL_TENSOR_DATA(v73);
        // pto: %137
        ;
        const int64_t v363 = 0;
        // pto: %137
        ;
        const int64_t v364 = 512;
        // pto: %137
        ;
        pto::Shape<1, 1, 1, 1, 512> v365 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %137
        ;
        pto::Stride<512, 512, 512, 512, 1> v366 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %137
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v367 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v362 + (v363 + v361 * v364), v365, v366);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v367, v359);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    } else {
      // pto: %c_missing_inline5276__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v368 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
      // pto: %c_missing_inline5276__ssa_v0
      ;
      uint64_t v369 = (uint64_t) v15;
      TASSIGN(v368, v369);
      pipe_barrier(PIPE_V);
      pipe_barrier(PIPE_ALL);
      TEXPANDS(v368, v36);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      // pto: %138
      ;
      int64_t v370 = v74 < v26 ? v26 : v74;
      // pto: %139
      ;
      __gm__ int32_t* v371 = PTOAS__GLOBAL_TENSOR_DATA(v73);
      // pto: %139
      ;
      const int64_t v372 = 0;
      // pto: %139
      ;
      const int64_t v373 = 512;
      // pto: %139
      ;
      pto::Shape<1, 1, 1, 1, 512> v374 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %139
      ;
      pto::Stride<512, 512, 512, 512, 1> v375 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %139
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v376 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v371 + (v372 + v370 * v373), v374, v375);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v376, v368);
    };
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}