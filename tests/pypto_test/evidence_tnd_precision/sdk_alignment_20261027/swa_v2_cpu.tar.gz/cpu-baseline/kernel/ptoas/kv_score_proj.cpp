#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void kv_score_proj(__gm__ int32_t* v1, __gm__ float* v2, __gm__ float* v3, __gm__ bfloat16_t* v4, __gm__ bfloat16_t* v5, __gm__ bfloat16_t* v6, int64_t v7, int64_t v8, int64_t v9, int64_t v10, int32_t v11, int32_t v12) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int32_t v13 = 0;
  // pto: %c0_i64
  const int64_t v14 = 0;
  // pto: %c8192_i64
  const int64_t v15 = 8192;
  // pto: %c16384_i64
  const int64_t v16 = 16384;
  // pto: %c24576_i64
  const int64_t v17 = 24576;
  // pto: %c32768_i64
  const int64_t v18 = 32768;
  // pto: %c49152_i64
  const int64_t v19 = 49152;
  // pto: %c57344_i64
  const int64_t v20 = 57344;
  // pto: %c1_index
  const int64_t v21 = 1;
  // pto: %c384_index
  const int64_t v22 = 384;
  // pto: %c1024_index
  const int64_t v23 = 1024;
  // pto: %c4096_index
  const int64_t v24 = 4096;
  // pto: %c0_index
  const int64_t v25 = 0;
  // pto: %c64_index
  const int64_t v26 = 64;
  // pto: %c32_index
  const int64_t v27 = 32;
  // pto: %c2_index
  const int64_t v28 = 2;
  // pto: %c24_index
  const int64_t v29 = 24;
  // pto: %c128_index
  const int64_t v30 = 128;
  // pto: %c512_index
  const int64_t v31 = 512;
  // pto: %c256_index
  const int64_t v32 = 256;
  // pto: %cmp4_kv_proj_pad_inline792_inline4663__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %cmp4_kv_proj_pad_inline792_inline4663__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %cmp4_kv_proj_pad_inline792_inline4663__ssa_v0_view
  const int64_t v35 = 1;
  // pto: %cmp4_kv_proj_pad_inline792_inline4663__ssa_v0_view
  int64_t v36 = v22 * v23;
  // pto: %cmp4_kv_proj_pad_inline792_inline4663__ssa_v0_view
  int64_t v37 = v35 * v36;
  // pto: %cmp4_kv_proj_pad_inline792_inline4663__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v38 = pto::Shape<1, 1, 1, -1, -1>(v33, v34, v35, v22, v23);
  // pto: %cmp4_kv_proj_pad_inline792_inline4663__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v39 = pto::Stride<-1, -1, -1, -1, -1>(v34 * v37, v37, v36, v23, v21);
  // pto: %cmp4_kv_proj_pad_inline792_inline4663__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v40 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v38, v39);
  // pto: %cmp4_score_proj_pad_inline793_inline4704__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %cmp4_score_proj_pad_inline793_inline4704__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %cmp4_score_proj_pad_inline793_inline4704__ssa_v0_view
  const int64_t v43 = 1;
  // pto: %cmp4_score_proj_pad_inline793_inline4704__ssa_v0_view
  int64_t v44 = v22 * v23;
  // pto: %cmp4_score_proj_pad_inline793_inline4704__ssa_v0_view
  int64_t v45 = v43 * v44;
  // pto: %cmp4_score_proj_pad_inline793_inline4704__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v46 = pto::Shape<1, 1, 1, -1, -1>(v41, v42, v43, v22, v23);
  // pto: %cmp4_score_proj_pad_inline793_inline4704__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v47 = pto::Stride<-1, -1, -1, -1, -1>(v42 * v45, v45, v44, v23, v21);
  // pto: %cmp4_score_proj_pad_inline793_inline4704__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v48 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v46, v47);
  // pto: %x_flat_inline789_inline4666__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %x_flat_inline789_inline4666__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %x_flat_inline789_inline4666__ssa_v0_view
  const int64_t v51 = 1;
  // pto: %x_flat_inline789_inline4666__ssa_v0_view
  int64_t v52 = (int64_t) v10;
  // pto: %x_flat_inline789_inline4666__ssa_v0_view
  int64_t v53 = v52 * v24;
  // pto: %x_flat_inline789_inline4666__ssa_v0_view
  int64_t v54 = v51 * v53;
  // pto: %x_flat_inline789_inline4666__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v55 = pto::Shape<1, 1, 1, -1, -1>(v49, v50, v51, v52, v24);
  // pto: %x_flat_inline789_inline4666__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v56 = pto::Stride<-1, -1, -1, -1, -1>(v50 * v54, v54, v53, v24, v21);
  // pto: %x_flat_inline789_inline4666__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v57 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v55, v56);
  // pto: %cmp_wkv__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %cmp_wkv__ssa_v0_view
  const int64_t v59 = 1;
  // pto: %cmp_wkv__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %cmp_wkv__ssa_v0_view
  int64_t v61 = v23 * v24;
  // pto: %cmp_wkv__ssa_v0_view
  int64_t v62 = v60 * v61;
  // pto: %cmp_wkv__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v63 = pto::Shape<1, 1, 1, -1, -1>(v58, v59, v60, v23, v24);
  // pto: %cmp_wkv__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v64 = pto::Stride<-1, -1, -1, -1, -1>(v59 * v62, v62, v61, v24, v21);
  // pto: %cmp_wkv__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v65 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v63, v64);
  // pto: %cmp_wgate__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %cmp_wgate__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %cmp_wgate__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %cmp_wgate__ssa_v0_view
  int64_t v69 = v23 * v24;
  // pto: %cmp_wgate__ssa_v0_view
  int64_t v70 = v68 * v69;
  // pto: %cmp_wgate__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v71 = pto::Shape<1, 1, 1, -1, -1>(v66, v67, v68, v23, v24);
  // pto: %cmp_wgate__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v67 * v70, v70, v69, v24, v21);
  // pto: %cmp_wgate__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v73 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v71, v72);
  // pto: %kv_acc_inline800_inline4693__phi_v5
  Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v74 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v27);
  // pto: %kv_acc_inline800_inline4693__phi_v5
  uint64_t v75 = (uint64_t) v14;
  TASSIGN(v74, v75);
  // pto: %score_acc_inline798_inline4668__phi_v5
  Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v76 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v27);
  // pto: %score_acc_inline798_inline4668__phi_v5
  uint64_t v77 = (uint64_t) v15;
  TASSIGN(v76, v77);
  // pto: %kv_worker_inline788_inline4676__ssa_v0
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  // pto: %t__tile
  int32_t v78 = (v1)[v21];
  // pto: %17
  int32_t v79 = (v1)[v25];
  // pto: %20
  // pto: %deviation_inline8306__rv_v2
  int32_t v80;
  v80 = v13;
  for (int64_t v81 = v21; v81 < ((int64_t) ((uint64_t) v9 - (uint64_t) v21)); v81 += v21) {
    // pto: %22, %21
    ;
    int32_t v82 = (v1)[(int64_t) ((uint64_t) v81 + (uint64_t) v21)];
    // pto: %23
    ;
    int32_t v83 = (v1)[v81];
    // pto: %24, %25, %18
    ;
    int32_t v84 = (int32_t) ((uint32_t) ((int32_t) (uint32_t) v82 - (uint32_t) v83) - (uint32_t) ((int32_t) (uint32_t) v78 - (uint32_t) v79));
    // pto: %27
    ;
    uint32_t v85 = (uint32_t) v80;
    // pto: %26, %27
    ;
    v80 = (int32_t) (v85 + (uint32_t) ((int32_t) (uint32_t) v84 * (uint32_t) v84));
  }
  // pto: %29
  int64_t v86 = (int64_t) v80;
  // pto: %30, %31, %32, %group_inline8302__phi_v4
  int64_t v87 = v86 == v25 & v7 <= v22 ? v27 : v26;
  // pto: %34
  for (int64_t v88 = (int64_t) v11; v88 < (v8 / v28); v88 += v29) {
    // pto: %35, %36
    ;
    int64_t v89 = (int64_t) ((uint64_t) (v88 / v27) * (uint64_t) v26);
    // pto: %37
    ;
    int64_t v90 = v88 % v27;
    // pto: %38, %39, %40
    ;
    int64_t v91 = v90 < v25 ? (int64_t) ((uint64_t) v90 + (uint64_t) v27) : v90;
    // pto: %41
    ;
    int64_t v92 = (int64_t) ((uint64_t) v91 * (uint64_t) v27);
    // pto: %42
    ;
    int64_t v93 = (int64_t) ((uint64_t) v7 - (uint64_t) v89);
    // pto: %43
    ;
    int64_t v94 = v93 < v26 ? v93 : v26;
    // pto: %kv_acc_inline800_inline4693__tile_narrowed_storage
    ;
    Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v95 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v27);
    // pto: %kv_acc_inline800_inline4693__tile_narrowed_storage
    ;
    uint64_t v96 = (uint64_t) v14;
    TASSIGN(v95, v96);
    v95.SetValidShape(v94, v27);
    // pto: %score_acc_inline798_inline4668__tile_narrowed_storage
    ;
    Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v97 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v27);
    // pto: %score_acc_inline798_inline4668__tile_narrowed_storage
    ;
    uint64_t v98 = (uint64_t) v15;
    TASSIGN(v97, v98);
    v97.SetValidShape(v94, v27);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    for (int64_t v99 = v25; v99 < v27; v99 += v28) {
      // pto: %45
      ;
      int64_t v100 = v92 % v31;
      // pto: %46, %47, %48
      ;
      int64_t v101 = v100 < v25 ? (int64_t) ((uint64_t) v100 + (uint64_t) v31) : v100;
      // pto: %44, %51, %49, %50
      ;
      int64_t v102 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v99 * (uint64_t) v30) + (uint64_t) ((int64_t) (uint64_t) (v101 / v87) * (uint64_t) v32));
      // pto: %52
      ;
      int64_t v103 = v102 % v24;
      // pto: %53, %54, %55
      ;
      int64_t v104 = v103 < v25 ? (int64_t) ((uint64_t) v103 + (uint64_t) v24) : v103;
      // pto: %64, %65
      ;
      int64_t v105 = (int64_t) ((uint64_t) v102 + (uint64_t) v30) % v24;
      // pto: %66, %67, %68
      ;
      int64_t v106 = v105 < v25 ? (int64_t) ((uint64_t) v105 + (uint64_t) v24) : v105;
      // pto: %x_tile_inline782_inline4665__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v107 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v94, v30);
      // pto: %x_tile_inline782_inline4665__tile
      ;
      uint64_t v108 = (uint64_t) v14;
      TASSIGN(v107, v108);
      // pto: %69
      ;
      int64_t v109 = v89 < v25 ? v25 : v89;
      // pto: %70
      ;
      int64_t v110 = v104 < v25 ? v25 : v104;
      // pto: %x_flat_inline789_inline4666__ssa_v0_pview
      ;
      const int64_t v111 = 0;
      // pto: %x_flat_inline789_inline4666__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v112 = PTOAS__GLOBAL_TENSOR_DATA(v57);
      // pto: %x_flat_inline789_inline4666__ssa_v0_pview
      ;
      const int64_t v113 = 1;
      // pto: %x_flat_inline789_inline4666__ssa_v0_pview
      ;
      const int64_t v114 = 1;
      // pto: %x_flat_inline789_inline4666__ssa_v0_pview
      ;
      const int64_t v115 = 1;
      // pto: %x_flat_inline789_inline4666__ssa_v0_pview
      ;
      int64_t v116 = v94 * v24;
      // pto: %x_flat_inline789_inline4666__ssa_v0_pview
      ;
      int64_t v117 = v115 * v116;
      // pto: %x_flat_inline789_inline4666__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 128> v118 = pto::Shape<1, 1, 1, -1, 128>(v113, v114, v115, v94, v30);
      // pto: %x_flat_inline789_inline4666__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v119 = pto::Stride<-1, -1, -1, -1, -1>(v114 * v117, v117, v116, v24, v21);
      // pto: %x_flat_inline789_inline4666__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v120 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v112 + (v111 + v109 * v24 + v110 * v21), v118, v119);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v107, v120);
      // pto: %wkv_tile_inline790_inline4655__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v27, v30);
      // pto: %wkv_tile_inline790_inline4655__tile
      ;
      uint64_t v122 = (uint64_t) v16;
      TASSIGN(v121, v122);
      // pto: %71
      ;
      int64_t v123 = v92 < v25 ? v25 : v92;
      // pto: %cmp_wkv__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v124 = PTOAS__GLOBAL_TENSOR_DATA(v65);
      // pto: %cmp_wkv__ssa_v0_pview
      ;
      const int64_t v125 = 0;
      // pto: %cmp_wkv__ssa_v0_pview
      ;
      const int64_t v126 = 4096;
      // pto: %cmp_wkv__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 32, 128> v127 = pto::Shape<1, 1, 1, 32, 128>();
      // pto: %cmp_wkv__ssa_v0_pview
      ;
      pto::Stride<131072, 131072, 131072, 4096, 1> v128 = pto::Stride<131072, 131072, 131072, 4096, 1>();
      // pto: %cmp_wkv__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND> v129 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND>(v124 + (v125 + v123 * v126 + v110), v127, v128);
      TLOAD(v121, v129);
      // pto: %wgate_tile_inline784_inline4654__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v27, v30);
      // pto: %wgate_tile_inline784_inline4654__tile
      ;
      uint64_t v131 = (uint64_t) v17;
      TASSIGN(v130, v131);
      // pto: %cmp_wgate__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v132 = PTOAS__GLOBAL_TENSOR_DATA(v73);
      // pto: %cmp_wgate__ssa_v0_pview
      ;
      const int64_t v133 = 0;
      // pto: %cmp_wgate__ssa_v0_pview
      ;
      const int64_t v134 = 4096;
      // pto: %cmp_wgate__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 32, 128> v135 = pto::Shape<1, 1, 1, 32, 128>();
      // pto: %cmp_wgate__ssa_v0_pview
      ;
      pto::Stride<131072, 131072, 131072, 4096, 1> v136 = pto::Stride<131072, 131072, 131072, 4096, 1>();
      // pto: %cmp_wgate__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND> v137 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND>(v132 + (v133 + v123 * v134 + v110), v135, v136);
      TLOAD(v130, v137);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %0
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v138 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v94, v30);
      // pto: %0
      ;
      uint64_t v139 = (uint64_t) v18;
      TASSIGN(v138, v139);
      // pto: %76
      ;
      int64_t v140 = v106 < v25 ? v25 : v106;
      // pto: %77
      ;
      const int64_t v141 = 0;
      // pto: %77
      ;
      __gm__ bfloat16_t* v142 = PTOAS__GLOBAL_TENSOR_DATA(v57);
      // pto: %77
      ;
      const int64_t v143 = 1;
      // pto: %77
      ;
      const int64_t v144 = 1;
      // pto: %77
      ;
      const int64_t v145 = 1;
      // pto: %77
      ;
      int64_t v146 = v94 * v24;
      // pto: %77
      ;
      int64_t v147 = v145 * v146;
      // pto: %77
      ;
      pto::Shape<1, 1, 1, -1, 128> v148 = pto::Shape<1, 1, 1, -1, 128>(v143, v144, v145, v94, v30);
      // pto: %77
      ;
      pto::Stride<-1, -1, -1, -1, -1> v149 = pto::Stride<-1, -1, -1, -1, -1>(v144 * v147, v147, v146, v24, v21);
      // pto: %77
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v150 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v142 + (v141 + v109 * v24 + v140 * v21), v148, v149);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v138, v150);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %1
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v151 = Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v27, v30);
      // pto: %1
      ;
      uint64_t v152 = (uint64_t) v19;
      TASSIGN(v151, v152);
      // pto: %80
      ;
      __gm__ bfloat16_t* v153 = PTOAS__GLOBAL_TENSOR_DATA(v65);
      // pto: %80
      ;
      const int64_t v154 = 0;
      // pto: %80
      ;
      const int64_t v155 = 4096;
      // pto: %80
      ;
      pto::Shape<1, 1, 1, 32, 128> v156 = pto::Shape<1, 1, 1, 32, 128>();
      // pto: %80
      ;
      pto::Stride<131072, 131072, 131072, 4096, 1> v157 = pto::Stride<131072, 131072, 131072, 4096, 1>();
      // pto: %80
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND> v158 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND>(v153 + (v154 + v123 * v155 + v140), v156, v157);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v151, v158);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      // pto: %2
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v159 = Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v27, v30);
      // pto: %2
      ;
      uint64_t v160 = (uint64_t) v20;
      TASSIGN(v159, v160);
      // pto: %83
      ;
      __gm__ bfloat16_t* v161 = PTOAS__GLOBAL_TENSOR_DATA(v73);
      // pto: %83
      ;
      const int64_t v162 = 0;
      // pto: %83
      ;
      const int64_t v163 = 4096;
      // pto: %83
      ;
      pto::Shape<1, 1, 1, 32, 128> v164 = pto::Shape<1, 1, 1, 32, 128>();
      // pto: %83
      ;
      pto::Stride<131072, 131072, 131072, 4096, 1> v165 = pto::Stride<131072, 131072, 131072, 4096, 1>();
      // pto: %83
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND> v166 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND>(v161 + (v162 + v123 * v163 + v140), v164, v165);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v159, v166);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %84
      ;
      v74.SetValidShape(v94, v27);
      v76.SetValidShape(v94, v27);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      if (v99 == v25) {
        // pto: %wkv_tile_inline790_inline4655__tile_t
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v167 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
        // pto: %wkv_tile_inline790_inline4655__tile_t
        ;
        uint64_t v168 = (uint64_t) v16;
        TASSIGN(v167, v168);
        // pto: %x_tile_inline782_inline4665__tile_Left
        ;
        Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v94, v30);
        // pto: %x_tile_inline782_inline4665__tile_Left
        ;
        uint64_t v170 = (uint64_t) v14;
        TASSIGN(v169, v170);
        TMOV(v169, v107);
        // pto: %wkv_tile_inline790_inline4655__tile_t_Right
        ;
        Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v171 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
        // pto: %wkv_tile_inline790_inline4655__tile_t_Right
        ;
        uint64_t v172 = (uint64_t) v14;
        TASSIGN(v171, v172);
        TMOV(v171, v167);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %kv_acc_inline800_inline4693__tile
        ;
        Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v173 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v94, v27);
        // pto: %kv_acc_inline800_inline4693__tile
        ;
        uint64_t v174 = (uint64_t) v14;
        TASSIGN(v173, v174);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        TMATMUL(v173, v169, v171);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        // pto: %wgate_tile_inline784_inline4654__tile_t
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
        // pto: %wgate_tile_inline784_inline4654__tile_t
        ;
        uint64_t v176 = (uint64_t) v17;
        TASSIGN(v175, v176);
        // pto: %wgate_tile_inline784_inline4654__tile_t_Right
        ;
        Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
        // pto: %wgate_tile_inline784_inline4654__tile_t_Right
        ;
        uint64_t v178 = (uint64_t) v14;
        TASSIGN(v177, v178);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        TMOV(v177, v175);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %score_acc_inline798_inline4668__tile
        ;
        Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v179 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v94, v27);
        // pto: %score_acc_inline798_inline4668__tile
        ;
        uint64_t v180 = (uint64_t) v15;
        TASSIGN(v179, v180);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL(v179, v169, v177);
      } else {
        // pto: %3
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
        // pto: %3
        ;
        uint64_t v182 = (uint64_t) v16;
        TASSIGN(v181, v182);
        // pto: %4
        ;
        Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v94, v30);
        // pto: %4
        ;
        uint64_t v184 = (uint64_t) v14;
        TASSIGN(v183, v184);
        TMOV(v183, v107);
        // pto: %5
        ;
        Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v185 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
        // pto: %5
        ;
        uint64_t v186 = (uint64_t) v14;
        TASSIGN(v185, v186);
        TMOV(v185, v181);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        TMATMUL_ACC(v95, v95, v183, v185);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        // pto: %7
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v187 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
        // pto: %7
        ;
        uint64_t v188 = (uint64_t) v17;
        TASSIGN(v187, v188);
        // pto: %8
        ;
        Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v189 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
        // pto: %8
        ;
        uint64_t v190 = (uint64_t) v14;
        TASSIGN(v189, v190);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        TMOV(v189, v187);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        TMATMUL_ACC(v97, v97, v183, v189);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %10
      ;
      Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v191 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
      // pto: %10
      ;
      uint64_t v192 = (uint64_t) v19;
      TASSIGN(v191, v192);
      // pto: %11
      ;
      Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v193 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v94, v30);
      // pto: %11
      ;
      uint64_t v194 = (uint64_t) v16;
      TASSIGN(v193, v194);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      TMOV(v193, v138);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %12
      ;
      Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v195 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
      // pto: %12
      ;
      uint64_t v196 = (uint64_t) v15;
      TASSIGN(v195, v196);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      TMOV(v195, v191);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
      TMATMUL_ACC(v74, v74, v193, v195);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      // pto: %14
      ;
      Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v197 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
      // pto: %14
      ;
      uint64_t v198 = (uint64_t) v20;
      TASSIGN(v197, v198);
      // pto: %15
      ;
      Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v199 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
      // pto: %15
      ;
      uint64_t v200 = (uint64_t) v15;
      TASSIGN(v199, v200);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      TMOV(v199, v197);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
      TMATMUL_ACC(v76, v76, v193, v199);
    };
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %85
    ;
    int64_t v201 = v89 < v25 ? v25 : v89;
    // pto: %86
    ;
    int64_t v202 = v92 < v25 ? v25 : v92;
    // pto: %cmp4_kv_proj_pad_inline792_inline4663__iter_v1_pview
    ;
    const int64_t v203 = 0;
    // pto: %cmp4_kv_proj_pad_inline792_inline4663__iter_v1_pview
    ;
    __gm__ float* v204 = PTOAS__GLOBAL_TENSOR_DATA(v40);
    // pto: %cmp4_kv_proj_pad_inline792_inline4663__iter_v1_pview
    ;
    const int64_t v205 = 1;
    // pto: %cmp4_kv_proj_pad_inline792_inline4663__iter_v1_pview
    ;
    const int64_t v206 = 1;
    // pto: %cmp4_kv_proj_pad_inline792_inline4663__iter_v1_pview
    ;
    const int64_t v207 = 1;
    // pto: %cmp4_kv_proj_pad_inline792_inline4663__iter_v1_pview
    ;
    int64_t v208 = v94 * v23;
    // pto: %cmp4_kv_proj_pad_inline792_inline4663__iter_v1_pview
    ;
    int64_t v209 = v207 * v208;
    // pto: %cmp4_kv_proj_pad_inline792_inline4663__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, -1, 32> v210 = pto::Shape<1, 1, 1, -1, 32>(v205, v206, v207, v94, v27);
    // pto: %cmp4_kv_proj_pad_inline792_inline4663__iter_v1_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v211 = pto::Stride<-1, -1, -1, -1, -1>(v206 * v209, v209, v208, v23, v21);
    // pto: %cmp4_kv_proj_pad_inline792_inline4663__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v212 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v204 + (v203 + v201 * v23 + v202 * v21), v210, v211);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE(v212, v95);
    // pto: %cmp4_score_proj_pad_inline793_inline4704__iter_v1_pview
    ;
    const int64_t v213 = 0;
    // pto: %cmp4_score_proj_pad_inline793_inline4704__iter_v1_pview
    ;
    __gm__ float* v214 = PTOAS__GLOBAL_TENSOR_DATA(v48);
    // pto: %cmp4_score_proj_pad_inline793_inline4704__iter_v1_pview
    ;
    const int64_t v215 = 1;
    // pto: %cmp4_score_proj_pad_inline793_inline4704__iter_v1_pview
    ;
    const int64_t v216 = 1;
    // pto: %cmp4_score_proj_pad_inline793_inline4704__iter_v1_pview
    ;
    const int64_t v217 = 1;
    // pto: %cmp4_score_proj_pad_inline793_inline4704__iter_v1_pview
    ;
    int64_t v218 = v94 * v23;
    // pto: %cmp4_score_proj_pad_inline793_inline4704__iter_v1_pview
    ;
    int64_t v219 = v217 * v218;
    // pto: %cmp4_score_proj_pad_inline793_inline4704__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, -1, 32> v220 = pto::Shape<1, 1, 1, -1, 32>(v215, v216, v217, v94, v27);
    // pto: %cmp4_score_proj_pad_inline793_inline4704__iter_v1_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v221 = pto::Stride<-1, -1, -1, -1, -1>(v216 * v219, v219, v218, v23, v21);
    // pto: %cmp4_score_proj_pad_inline793_inline4704__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v222 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v214 + (v213 + v201 * v23 + v202 * v21), v220, v221);
    TSTORE(v222, v97);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}