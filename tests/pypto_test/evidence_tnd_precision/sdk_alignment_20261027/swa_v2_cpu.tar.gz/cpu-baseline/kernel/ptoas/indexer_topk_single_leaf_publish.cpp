#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void indexer_topk_single_leaf_publish(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ int32_t* v3, __gm__ float* v4, __gm__ float* v5, __gm__ int32_t* v6, int64_t v7, int64_t v8, int32_t v9, int32_t v10) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  pto::MrgSortExecutedNumList v11 = pto::MrgSortExecutedNumList{0, 0, 0, 0};
  // pto: %c32768_i64
  const int64_t v12 = 32768;
  // pto: %c98304_i64
  const int64_t v13 = 98304;
  // pto: %c0_i64
  const int64_t v14 = 0;
  const int64_t v15 = 114688;
  const int64_t v16 = 131072;
  const int64_t v17 = 147456;
  // pto: %c1_index
  const int64_t v18 = 1;
  // pto: %c432_index
  const int64_t v19 = 432;
  // pto: %c8192_index
  const int64_t v20 = 8192;
  // pto: %c512_index
  const int64_t v21 = 512;
  // pto: %c48_index
  const int64_t v22 = 48;
  // pto: %c0_index
  const int64_t v23 = 0;
  // pto: %c4_index
  const int64_t v24 = 4;
  // pto: %c1_i64
  const int64_t v25 = 1;
  // pto: %c4_i64
  const int64_t v26 = 4;
  // pto: %c2048_index
  const int64_t v27 = 2048;
  // pto: %c192_index
  const int64_t v28 = 192;
  // pto: %c0_i32
  const int32_t v29 = 0;
  // pto: %cst_18
  const float v30 = -3.40282347E+38f;
  // pto: %c4096_index
  const int64_t v31 = 4096;
  // pto: %c64_i32
  const int32_t v32 = 64;
  // pto: %c256_i32
  const int32_t v33 = 256;
  // pto: %c1024_i32
  const int32_t v34 = 1024;
  // pto: %c1024_index
  const int64_t v35 = 1024;
  // pto: %cn1_i32
  const int32_t v36 = -1;
  // pto: %c16384_index
  const int64_t v37 = 16384;
  // pto: %score_arena__ssa_v0_view
  const int64_t v38 = 1;
  // pto: %score_arena__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %score_arena__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %score_arena__ssa_v0_view
  int64_t v41 = v19 * v20;
  // pto: %score_arena__ssa_v0_view
  int64_t v42 = v40 * v41;
  // pto: %score_arena__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v43 = pto::Shape<1, 1, 1, -1, -1>(v38, v39, v40, v19, v20);
  // pto: %score_arena__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v44 = pto::Stride<-1, -1, -1, -1, -1>(v39 * v42, v42, v41, v20, v18);
  // pto: %score_arena__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v45 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v43, v44);
  // pto: %topk_scores__ssa_v0_view
  const int64_t v46 = 1;
  // pto: %topk_scores__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %topk_scores__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %topk_scores__ssa_v0_view
  int64_t v49 = (int64_t) v7;
  // pto: %topk_scores__ssa_v0_view
  int64_t v50 = v49 * v21;
  // pto: %topk_scores__ssa_v0_view
  int64_t v51 = v48 * v50;
  // pto: %topk_scores__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v52 = pto::Shape<1, 1, 1, -1, -1>(v46, v47, v48, v49, v21);
  // pto: %topk_scores__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v53 = pto::Stride<-1, -1, -1, -1, -1>(v47 * v51, v51, v50, v21, v18);
  // pto: %topk_scores__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v54 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v52, v53);
  // pto: %topk_indices__ssa_v0_view
  const int64_t v55 = 1;
  // pto: %topk_indices__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %topk_indices__ssa_v0_view
  const int64_t v57 = 1;
  // pto: %topk_indices__ssa_v0_view
  int64_t v58 = (int64_t) v7;
  // pto: %topk_indices__ssa_v0_view
  int64_t v59 = v58 * v21;
  // pto: %topk_indices__ssa_v0_view
  int64_t v60 = v57 * v59;
  // pto: %topk_indices__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v61 = pto::Shape<1, 1, 1, -1, -1>(v55, v56, v57, v58, v21);
  // pto: %topk_indices__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v62 = pto::Stride<-1, -1, -1, -1, -1>(v56 * v60, v60, v59, v21, v18);
  // pto: %topk_indices__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v63 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v61, v62);
  // pto: %worker__ssa_v0
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  for (int64_t v64 = (int64_t) v9; v64 < v7; v64 += v22) {
    // pto: %position__tile
    ;
    int64_t v65 = (v1)[v64];
    // pto: %t__tile
    ;
    int32_t v66 = (v3)[v64];
    // pto: %0
    ;
    int64_t v67 = (int64_t) v66;
    // pto: %2
    ;
    int64_t v68 = v67 < v23 ? v23 : v67;
    // pto: %1
    ;
    int32_t v69 = (v2)[v68];
    // pto: %5, %3, %4, %cache_len__phi_v2
    ;
    int64_t v70 = v67 < v23 ? v23 : (int64_t) v69 / v24;
    // pto: %6, %7
    ;
    int64_t v71 = (int64_t) ((uint64_t) v65 + (uint64_t) v25) / v26;
    // pto: %9
    ;
    int64_t v72 = v70 < v71 ? v70 : v71;
    // pto: %10
    ;
    int64_t v73 = v72 < v23 ? v23 : v72;
    // pto: %11
    ;
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    if (v73 > v23) {
      // pto: %12
      ;
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
      pipe_barrier(PIPE_ALL);
      if (v73 <= v27) {
        // pto: %short_indices_inline1822__ci_tmp_v0
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v74 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v28);
        // pto: %short_indices_inline1822__ci_tmp_v0
        ;
        uint64_t v75 = (uint64_t) v12;
        TASSIGN(v74, v75);
        // pto: %short_indices_inline1822__ssa_v0
        ;
        Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v76 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v27);
        // pto: %short_indices_inline1822__ssa_v0
        ;
        uint64_t v77 = (uint64_t) v13;
        TASSIGN(v76, v77);
        // pto: %ci_tmp_view
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v78;
        TRESHAPE(v78, v74);
        // pto: %ci_dst_view
        ;
        Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v79;
        TRESHAPE(v79, v76);
        pipe_barrier(PIPE_ALL);
        pipe_barrier(PIPE_V);
        TCI<Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v79, v29, v78);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
        // pto: %short_raw_inline1839__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v80 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v73);
        // pto: %short_raw_inline1839__ssa_v0
        ;
        uint64_t v81 = (uint64_t) v12;
        TASSIGN(v80, v81);
        // pto: %13
        ;
        int64_t v82 = v64 < v23 ? v23 : v64;
        // pto: %score_arena__ssa_v0_pview
        ;
        const int64_t v83 = 0;
        // pto: %score_arena__ssa_v0_pview
        ;
        __gm__ float* v84 = PTOAS__GLOBAL_TENSOR_DATA(v45);
        // pto: %score_arena__ssa_v0_pview
        ;
        const int64_t v85 = 1;
        // pto: %score_arena__ssa_v0_pview
        ;
        const int64_t v86 = 1;
        // pto: %score_arena__ssa_v0_pview
        ;
        const int64_t v87 = 1;
        // pto: %score_arena__ssa_v0_pview
        ;
        int64_t v88 = v18 * v20;
        // pto: %score_arena__ssa_v0_pview
        ;
        int64_t v89 = v87 * v88;
        // pto: %score_arena__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, -1> v90 = pto::Shape<1, 1, 1, 1, -1>(v85, v86, v87, v18, v73);
        // pto: %score_arena__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v91 = pto::Stride<-1, -1, -1, -1, -1>(v86 * v89, v89, v88, v20, v18);
        // pto: %score_arena__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v92 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v84 + (v83 + v82 * v20 + v23 * v18), v90, v91);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
        TLOAD(v80, v92);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %short_scores_inline1808__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v93 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v27);
        // pto: %short_scores_inline1808__ssa_v0
        ;
        uint64_t v94 = (uint64_t) v12;
        TASSIGN(v93, v94);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        TFILLPAD<pto::TFillPadMode::InPlace>(v93, v80);
        // pto: %short_scores_v1_inline1809__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v95 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v27);
        // pto: %short_scores_v1_inline1809__ssa_v0
        ;
        uint64_t v96 = (uint64_t) v14;
        TASSIGN(v95, v96);
        pipe_barrier(PIPE_V);
        pipe_barrier(PIPE_ALL);
        TMAXS(v95, v93, v30);
        // pto: %t__tmp_v2
        ;
        Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v27);
        // pto: %t__tmp_v2
        ;
        uint64_t v98 = (uint64_t) v13;
        TASSIGN(v97, v98);
        // pto: %short_pairs_inline1818__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v99 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v31);
        // pto: %short_pairs_inline1818__ssa_v0
        ;
        uint64_t v100 = (uint64_t) v12;
        TASSIGN(v99, v100);
        // pto: %sort32_src_view
        ;
        Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v101;
        TRESHAPE(v101, v95);
        // pto: %sort32_idx_view
        ;
        Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v102;
        TRESHAPE(v102, v97);
        // pto: %sort32_dst_view
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v103;
        TRESHAPE(v103, v99);
        pipe_barrier(PIPE_V);
        TSORT32(v103, v101, v102);
        // pto: %short_pairs_v1_inline1817__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v104 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v31);
        // pto: %short_pairs_v1_inline1817__ssa_v0
        ;
        uint64_t v105 = (uint64_t) v13;
        TASSIGN(v104, v105);
        pipe_barrier(PIPE_V);
        TMRGSORT(v104, v99, v32);
        // pto: %short_pairs_v2_inline1836__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v106 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v31);
        // pto: %short_pairs_v2_inline1836__ssa_v0
        ;
        uint64_t v107 = (uint64_t) v12;
        TASSIGN(v106, v107);
        pipe_barrier(PIPE_V);
        TMRGSORT(v106, v104, v33);
        // pto: %short_pairs_v3_inline1812__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v108 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v31);
        // pto: %short_pairs_v3_inline1812__ssa_v0
        ;
        uint64_t v109 = (uint64_t) v13;
        TASSIGN(v108, v109);
        pipe_barrier(PIPE_V);
        TMRGSORT(v108, v106, v34);
        // pto: %short_top_inline1810__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v110 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v35);
        // pto: %short_top_inline1810__ssa_v0
        ;
        uint64_t v111 = (uint64_t) v13;
        TASSIGN(v110, v111);
        // pto: %slice_view
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v112;
        // pto: %slice_view
        ;
        uint64_t v113 = (uint64_t) v13;
        TASSIGN(v112, v113);
        // pto: %short_values_inline1814__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v114 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v21);
        // pto: %short_values_inline1814__ssa_v0
        ;
        uint64_t v115 = (uint64_t) v12;
        TASSIGN(v114, v115);
        pipe_barrier(PIPE_V);
        TGATHER<Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, MaskPattern::P0101>(v114, v112);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %short_selected_inline1806__ssa_v0
        ;
        Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v116 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v21);
        // pto: %short_selected_inline1806__ssa_v0
        ;
        uint64_t v117 = (uint64_t) v14;
        TASSIGN(v116, v117);
        TGATHER<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, MaskPattern::P1010>(v116, v112);
        set_flag(PIPE_V, PIPE_S, EVENT_ID0);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        // pto: %topk_scores__ssa_v0_pview
        ;
        __gm__ float* v118 = PTOAS__GLOBAL_TENSOR_DATA(v54);
        // pto: %topk_scores__ssa_v0_pview
        ;
        const int64_t v119 = 0;
        // pto: %topk_scores__ssa_v0_pview
        ;
        const int64_t v120 = 512;
        // pto: %topk_scores__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 512> v121 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %topk_scores__ssa_v0_pview
        ;
        pto::Stride<512, 512, 512, 512, 1> v122 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %topk_scores__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v123 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v118 + (v119 + v82 * v120), v121, v122);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v123, v114);
        // pto: %15
        ;
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        pipe_barrier(PIPE_ALL);
        wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
        if (v73 >= v21) {
          // pto: %topk_indices__ssa_v0_pview
          ;
          __gm__ int32_t* v124 = PTOAS__GLOBAL_TENSOR_DATA(v63);
          // pto: %topk_indices__ssa_v0_pview
          ;
          const int64_t v125 = 0;
          // pto: %topk_indices__ssa_v0_pview
          ;
          const int64_t v126 = 512;
          // pto: %topk_indices__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 1, 512> v127 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %topk_indices__ssa_v0_pview
          ;
          pto::Stride<512, 512, 512, 512, 1> v128 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %topk_indices__ssa_v0_pview
          ;
          GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v129 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v124 + (v125 + v82 * v126), v127, v128);
          TSTORE(v129, v116);
        } else {
          // pto: %short_output_inline1826__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v21);
          // pto: %short_output_inline1826__ssa_v0
          ;
          uint64_t v131 = (uint64_t) v12;
          TASSIGN(v130, v131);
          TEXPANDS(v130, v36);
          set_flag(PIPE_V, PIPE_S, EVENT_ID1);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          wait_flag(PIPE_V, PIPE_S, EVENT_ID1);
          for (int64_t v132 = v23; v132 < v73; v132 += v18) {
            // pto: %t__tmp_v3
            ;
            int32_t v133 = v116.GetValue(v132);
            v130.SetValue(v132, v133);
          };
          set_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
          // pto: %20
          ;
          __gm__ int32_t* v134 = PTOAS__GLOBAL_TENSOR_DATA(v63);
          // pto: %20
          ;
          const int64_t v135 = 0;
          // pto: %20
          ;
          const int64_t v136 = 512;
          // pto: %20
          ;
          pto::Shape<1, 1, 1, 1, 512> v137 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %20
          ;
          pto::Stride<512, 512, 512, 512, 1> v138 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %20
          ;
          GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v139 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v134 + (v135 + v82 * v136), v137, v138);
          wait_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          TSTORE(v139, v130);
        };
      } else {
        // pto: %21
        ;
        pipe_barrier(PIPE_ALL);
        if (v73 <= v31) {
          // pto: %medium_indices_inline1824__ci_tmp_v1
          ;
          Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v140 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v28);
          // pto: %medium_indices_inline1824__ci_tmp_v1
          ;
          uint64_t v141 = (uint64_t) v12;
          TASSIGN(v140, v141);
          // pto: %medium_indices_inline1824__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v142 = Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v31);
          // pto: %medium_indices_inline1824__ssa_v0
          ;
          uint64_t v143 = (uint64_t) v13;
          TASSIGN(v142, v143);
          // pto: %22
          ;
          Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v144;
          TRESHAPE(v144, v140);
          // pto: %23
          ;
          Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v145;
          TRESHAPE(v145, v142);
          pipe_barrier(PIPE_V);
          pipe_barrier(PIPE_ALL);
          TCI<Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v145, v29, v144);
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
          // pto: %medium_raw_inline1825__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v146 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v73);
          // pto: %medium_raw_inline1825__ssa_v0
          ;
          uint64_t v147 = (uint64_t) v12;
          TASSIGN(v146, v147);
          // pto: %24
          ;
          int64_t v148 = v64 < v23 ? v23 : v64;
          // pto: %25
          ;
          const int64_t v149 = 0;
          // pto: %25
          ;
          __gm__ float* v150 = PTOAS__GLOBAL_TENSOR_DATA(v45);
          // pto: %25
          ;
          const int64_t v151 = 1;
          // pto: %25
          ;
          const int64_t v152 = 1;
          // pto: %25
          ;
          const int64_t v153 = 1;
          // pto: %25
          ;
          int64_t v154 = v18 * v20;
          // pto: %25
          ;
          int64_t v155 = v153 * v154;
          // pto: %25
          ;
          pto::Shape<1, 1, 1, 1, -1> v156 = pto::Shape<1, 1, 1, 1, -1>(v151, v152, v153, v18, v73);
          // pto: %25
          ;
          pto::Stride<-1, -1, -1, -1, -1> v157 = pto::Stride<-1, -1, -1, -1, -1>(v152 * v155, v155, v154, v20, v18);
          // pto: %25
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v158 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v150 + (v149 + v148 * v20 + v23 * v18), v156, v157);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
          TLOAD(v146, v158);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
          // pto: %medium_scores_inline1827__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v159 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v31);
          // pto: %medium_scores_inline1827__ssa_v0
          ;
          uint64_t v160 = (uint64_t) v12;
          TASSIGN(v159, v160);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
          TFILLPAD<pto::TFillPadMode::InPlace>(v159, v146);
          // pto: %medium_scores_v1_inline1828__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v161 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v31);
          // pto: %medium_scores_v1_inline1828__ssa_v0
          ;
          uint64_t v162 = (uint64_t) v14;
          TASSIGN(v161, v162);
          pipe_barrier(PIPE_V);
          TMAXS(v161, v159, v30);
          // pto: %t__tmp_v4
          ;
          Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v163 = Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v31);
          // pto: %t__tmp_v4
          ;
          uint64_t v164 = (uint64_t) v13;
          TASSIGN(v163, v164);
          // pto: %medium_pairs_inline1829__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v165 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v20);
          // pto: %medium_pairs_inline1829__ssa_v0
          ;
          uint64_t v166 = (uint64_t) v12;
          TASSIGN(v165, v166);
          // pto: %26
          ;
          Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v167;
          TRESHAPE(v167, v161);
          // pto: %27
          ;
          Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v168;
          TRESHAPE(v168, v163);
          // pto: %28
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 8192, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v169;
          TRESHAPE(v169, v165);
          pipe_barrier(PIPE_V);
          TSORT32(v169, v167, v168);
          // pto: %medium_pairs_v1_inline1816__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v170 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v20);
          // pto: %medium_pairs_v1_inline1816__ssa_v0
          ;
          uint64_t v171 = (uint64_t) v13;
          TASSIGN(v170, v171);
          pipe_barrier(PIPE_V);
          TMRGSORT(v170, v165, v32);
          // pto: %medium_pairs_v2_inline1823__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v172 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v20);
          // pto: %medium_pairs_v2_inline1823__ssa_v0
          ;
          uint64_t v173 = (uint64_t) v12;
          TASSIGN(v172, v173);
          pipe_barrier(PIPE_V);
          TMRGSORT(v172, v170, v33);
          // pto: %medium_pairs_v3_inline1831__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v174 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v20);
          // pto: %medium_pairs_v3_inline1831__ssa_v0
          ;
          uint64_t v175 = (uint64_t) v13;
          TASSIGN(v174, v175);
          pipe_barrier(PIPE_V);
          TMRGSORT(v174, v172, v34);
          // pto: %medium_left_inline1832__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v176 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v35);
          // pto: %medium_left_inline1832__ssa_v0
          ;
          uint64_t v177 = (uint64_t) v13;
          TASSIGN(v176, v177);
          // pto: %29
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v178;
          // pto: %29
          ;
          uint64_t v179 = (uint64_t) v13;
          TASSIGN(v178, v179);
          // pto: %medium_right_inline1813__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v180 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v35);
          // pto: %medium_right_inline1813__ssa_v0
          ;
          uint64_t v181 = (uint64_t) v15;
          TASSIGN(v180, v181);
          // pto: %30
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v182;
          // pto: %30
          ;
          uint64_t v183 = (uint64_t) v15;
          TASSIGN(v182, v183);
          // pto: %medium_tmp_inline1838__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v184 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v27);
          // pto: %medium_tmp_inline1838__ssa_v0
          ;
          uint64_t v185 = (uint64_t) v12;
          TASSIGN(v184, v185);
          // pto: %medium_merged_inline1819__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v186 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v27);
          // pto: %medium_merged_inline1819__ssa_v0
          ;
          uint64_t v187 = (uint64_t) v14;
          TASSIGN(v186, v187);
          pipe_barrier(PIPE_V);
          TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v186, v11, v184, v182, v178);
          // pto: %medium_top_inline1835__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v188 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v35);
          // pto: %medium_top_inline1835__ssa_v0
          ;
          uint64_t v189 = (uint64_t) v14;
          TASSIGN(v188, v189);
          // pto: %31
          ;
          Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v190;
          // pto: %31
          ;
          uint64_t v191 = (uint64_t) v14;
          TASSIGN(v190, v191);
          // pto: %medium_values_inline1840__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v192 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v21);
          // pto: %medium_values_inline1840__ssa_v0
          ;
          uint64_t v193 = (uint64_t) v12;
          TASSIGN(v192, v193);
          pipe_barrier(PIPE_V);
          TGATHER<Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, MaskPattern::P0101>(v192, v190);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
          // pto: %medium_selected_inline1834__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v194 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v21);
          // pto: %medium_selected_inline1834__ssa_v0
          ;
          uint64_t v195 = (uint64_t) v13;
          TASSIGN(v194, v195);
          TGATHER<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, MaskPattern::P1010>(v194, v190);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
          // pto: %33
          ;
          __gm__ float* v196 = PTOAS__GLOBAL_TENSOR_DATA(v54);
          // pto: %33
          ;
          const int64_t v197 = 0;
          // pto: %33
          ;
          const int64_t v198 = 512;
          // pto: %33
          ;
          pto::Shape<1, 1, 1, 1, 512> v199 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %33
          ;
          pto::Stride<512, 512, 512, 512, 1> v200 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %33
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v201 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v196 + (v197 + v148 * v198), v199, v200);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
          TSTORE(v201, v192);
          // pto: %35
          ;
          __gm__ int32_t* v202 = PTOAS__GLOBAL_TENSOR_DATA(v63);
          // pto: %35
          ;
          const int64_t v203 = 0;
          // pto: %35
          ;
          const int64_t v204 = 512;
          // pto: %35
          ;
          pto::Shape<1, 1, 1, 1, 512> v205 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %35
          ;
          pto::Stride<512, 512, 512, 512, 1> v206 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %35
          ;
          GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v207 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v202 + (v203 + v148 * v204), v205, v206);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
          TSTORE(v207, v194);
        } else {
          // pto: %full_indices_inline1837__ci_tmp_v2
          ;
          Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v208 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v28);
          // pto: %full_indices_inline1837__ci_tmp_v2
          ;
          uint64_t v209 = (uint64_t) v12;
          TASSIGN(v208, v209);
          // pto: %full_indices_inline1837__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v210 = Tile<TileType::Vec, int32_t, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v20);
          // pto: %full_indices_inline1837__ssa_v0
          ;
          uint64_t v211 = (uint64_t) v13;
          TASSIGN(v210, v211);
          // pto: %36
          ;
          Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v212;
          TRESHAPE(v212, v208);
          // pto: %37
          ;
          Tile<TileType::Vec, int32_t, 1, 8192, BLayout::RowMajor, 1, 8192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v213;
          TRESHAPE(v213, v210);
          pipe_barrier(PIPE_V);
          pipe_barrier(PIPE_ALL);
          TCI<Tile<TileType::Vec, int32_t, 1, 8192, BLayout::RowMajor, 1, 8192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v213, v29, v212);
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
          // pto: %full_raw_inline1820__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v214 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v73);
          // pto: %full_raw_inline1820__ssa_v0
          ;
          uint64_t v215 = (uint64_t) v12;
          TASSIGN(v214, v215);
          // pto: %38
          ;
          int64_t v216 = v64 < v23 ? v23 : v64;
          // pto: %39
          ;
          const int64_t v217 = 0;
          // pto: %39
          ;
          __gm__ float* v218 = PTOAS__GLOBAL_TENSOR_DATA(v45);
          // pto: %39
          ;
          const int64_t v219 = 1;
          // pto: %39
          ;
          const int64_t v220 = 1;
          // pto: %39
          ;
          const int64_t v221 = 1;
          // pto: %39
          ;
          int64_t v222 = v18 * v20;
          // pto: %39
          ;
          int64_t v223 = v221 * v222;
          // pto: %39
          ;
          pto::Shape<1, 1, 1, 1, -1> v224 = pto::Shape<1, 1, 1, 1, -1>(v219, v220, v221, v18, v73);
          // pto: %39
          ;
          pto::Stride<-1, -1, -1, -1, -1> v225 = pto::Stride<-1, -1, -1, -1, -1>(v220 * v223, v223, v222, v20, v18);
          // pto: %39
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v226 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v218 + (v217 + v216 * v20 + v23 * v18), v224, v225);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
          TLOAD(v214, v226);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          // pto: %full_scores_inline1805__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v227 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v20);
          // pto: %full_scores_inline1805__ssa_v0
          ;
          uint64_t v228 = (uint64_t) v12;
          TASSIGN(v227, v228);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          TFILLPAD<pto::TFillPadMode::InPlace>(v227, v214);
          // pto: %full_min_inline1815__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v229 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v20);
          // pto: %full_min_inline1815__ssa_v0
          ;
          uint64_t v230 = (uint64_t) v14;
          TASSIGN(v229, v230);
          TEXPANDS(v229, v30);
          // pto: %full_scores_v1_inline1803__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v231 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v20);
          // pto: %full_scores_v1_inline1803__ssa_v0
          ;
          uint64_t v232 = (uint64_t) v14;
          TASSIGN(v231, v232);
          pipe_barrier(PIPE_V);
          TMAX(v231, v227, v229);
          // pto: %t__tmp_v5
          ;
          Tile<TileType::Vec, uint32_t, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v233 = Tile<TileType::Vec, uint32_t, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v20);
          // pto: %t__tmp_v5
          ;
          uint64_t v234 = (uint64_t) v13;
          TASSIGN(v233, v234);
          // pto: %full_pairs_inline1833__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v235 = Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v37);
          // pto: %full_pairs_inline1833__ssa_v0
          ;
          uint64_t v236 = (uint64_t) v12;
          TASSIGN(v235, v236);
          // pto: %40
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 8192, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v237;
          TRESHAPE(v237, v231);
          // pto: %41
          ;
          Tile<TileType::Vec, uint32_t, 1, 8192, BLayout::RowMajor, 1, 8192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v238;
          TRESHAPE(v238, v233);
          // pto: %42
          ;
          Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, 1, 16384, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v239;
          TRESHAPE(v239, v235);
          pipe_barrier(PIPE_V);
          TSORT32(v239, v237, v238);
          // pto: %full_pairs_v1_inline1811__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v240 = Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v37);
          // pto: %full_pairs_v1_inline1811__ssa_v0
          ;
          uint64_t v241 = (uint64_t) v13;
          TASSIGN(v240, v241);
          pipe_barrier(PIPE_V);
          TMRGSORT(v240, v235, v32);
          // pto: %full_pairs_v2_inline1801__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v242 = Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v37);
          // pto: %full_pairs_v2_inline1801__ssa_v0
          ;
          uint64_t v243 = (uint64_t) v12;
          TASSIGN(v242, v243);
          pipe_barrier(PIPE_V);
          TMRGSORT(v242, v240, v33);
          // pto: %full_pairs_v3_inline1800__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v244 = Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v37);
          // pto: %full_pairs_v3_inline1800__ssa_v0
          ;
          uint64_t v245 = (uint64_t) v13;
          TASSIGN(v244, v245);
          pipe_barrier(PIPE_V);
          TMRGSORT(v244, v242, v34);
          // pto: %full_first_inline1807__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v246 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v35);
          // pto: %full_first_inline1807__ssa_v0
          ;
          uint64_t v247 = (uint64_t) v13;
          TASSIGN(v246, v247);
          // pto: %43
          ;
          Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v248;
          // pto: %43
          ;
          uint64_t v249 = (uint64_t) v13;
          TASSIGN(v248, v249);
          // pto: %full_second_inline1830__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v250 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v35);
          // pto: %full_second_inline1830__ssa_v0
          ;
          uint64_t v251 = (uint64_t) v15;
          TASSIGN(v250, v251);
          // pto: %44
          ;
          Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v252;
          // pto: %44
          ;
          uint64_t v253 = (uint64_t) v15;
          TASSIGN(v252, v253);
          // pto: %full_third_inline1799__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v254 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v35);
          // pto: %full_third_inline1799__ssa_v0
          ;
          uint64_t v255 = (uint64_t) v16;
          TASSIGN(v254, v255);
          // pto: %45
          ;
          Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v256;
          // pto: %45
          ;
          uint64_t v257 = (uint64_t) v16;
          TASSIGN(v256, v257);
          // pto: %full_fourth_inline1798__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v258 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v35);
          // pto: %full_fourth_inline1798__ssa_v0
          ;
          uint64_t v259 = (uint64_t) v17;
          TASSIGN(v258, v259);
          // pto: %46
          ;
          Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v260;
          // pto: %46
          ;
          uint64_t v261 = (uint64_t) v17;
          TASSIGN(v260, v261);
          // pto: %full_tmp_inline1797__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v262 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v31);
          // pto: %full_tmp_inline1797__ssa_v0
          ;
          uint64_t v263 = (uint64_t) v12;
          TASSIGN(v262, v263);
          // pto: %full_merged_inline1796__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v264 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v31);
          // pto: %full_merged_inline1796__ssa_v0
          ;
          uint64_t v265 = (uint64_t) v14;
          TASSIGN(v264, v265);
          pipe_barrier(PIPE_V);
          TMRGSORT<Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v264, v11, v262, v260, v256, v252, v248);
          // pto: %full_top_inline1804__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v266 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v35);
          // pto: %full_top_inline1804__ssa_v0
          ;
          uint64_t v267 = (uint64_t) v14;
          TASSIGN(v266, v267);
          // pto: %48
          ;
          Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v268;
          // pto: %48
          ;
          uint64_t v269 = (uint64_t) v14;
          TASSIGN(v268, v269);
          // pto: %full_values_inline1795__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v270 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v21);
          // pto: %full_values_inline1795__ssa_v0
          ;
          uint64_t v271 = (uint64_t) v12;
          TASSIGN(v270, v271);
          pipe_barrier(PIPE_V);
          TGATHER<Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, MaskPattern::P0101>(v270, v268);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
          // pto: %full_selected_inline1802__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v272 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v21);
          // pto: %full_selected_inline1802__ssa_v0
          ;
          uint64_t v273 = (uint64_t) v13;
          TASSIGN(v272, v273);
          TGATHER<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, MaskPattern::P1010>(v272, v268);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
          // pto: %50
          ;
          __gm__ float* v274 = PTOAS__GLOBAL_TENSOR_DATA(v54);
          // pto: %50
          ;
          const int64_t v275 = 0;
          // pto: %50
          ;
          const int64_t v276 = 512;
          // pto: %50
          ;
          pto::Shape<1, 1, 1, 1, 512> v277 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %50
          ;
          pto::Stride<512, 512, 512, 512, 1> v278 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %50
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v279 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v274 + (v275 + v216 * v276), v277, v278);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
          TSTORE(v279, v270);
          // pto: %52
          ;
          __gm__ int32_t* v280 = PTOAS__GLOBAL_TENSOR_DATA(v63);
          // pto: %52
          ;
          const int64_t v281 = 0;
          // pto: %52
          ;
          const int64_t v282 = 512;
          // pto: %52
          ;
          pto::Shape<1, 1, 1, 1, 512> v283 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %52
          ;
          pto::Stride<512, 512, 512, 512, 1> v284 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %52
          ;
          GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v285 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v280 + (v281 + v216 * v282), v283, v284);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
          TSTORE(v285, v272);
        };
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
    } else {
      // pto: %t__tmp_v6
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v286 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v21);
      // pto: %t__tmp_v6
      ;
      uint64_t v287 = (uint64_t) v12;
      TASSIGN(v286, v287);
      pipe_barrier(PIPE_ALL);
      TEXPANDS(v286, v30);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
      // pto: %53
      ;
      int64_t v288 = v64 < v23 ? v23 : v64;
      // pto: %54
      ;
      __gm__ float* v289 = PTOAS__GLOBAL_TENSOR_DATA(v54);
      // pto: %54
      ;
      const int64_t v290 = 0;
      // pto: %54
      ;
      const int64_t v291 = 512;
      // pto: %54
      ;
      pto::Shape<1, 1, 1, 1, 512> v292 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %54
      ;
      pto::Stride<512, 512, 512, 512, 1> v293 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %54
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v294 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v289 + (v290 + v288 * v291), v292, v293);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
      TSTORE(v294, v286);
      // pto: %t__tmp_v7
      ;
      Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v295 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v21);
      // pto: %t__tmp_v7
      ;
      uint64_t v296 = (uint64_t) v12;
      TASSIGN(v295, v296);
      pipe_barrier(PIPE_ALL);
      TEXPANDS(v295, v36);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      // pto: %56
      ;
      __gm__ int32_t* v297 = PTOAS__GLOBAL_TENSOR_DATA(v63);
      // pto: %56
      ;
      const int64_t v298 = 0;
      // pto: %56
      ;
      const int64_t v299 = 512;
      // pto: %56
      ;
      pto::Shape<1, 1, 1, 1, 512> v300 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %56
      ;
      pto::Stride<512, 512, 512, 512, 1> v301 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %56
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v302 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v297 + (v298 + v288 * v299), v300, v301);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v302, v295);
    };
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}