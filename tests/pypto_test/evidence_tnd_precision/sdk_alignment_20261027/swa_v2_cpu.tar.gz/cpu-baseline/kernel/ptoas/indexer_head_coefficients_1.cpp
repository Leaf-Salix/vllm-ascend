#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void indexer_head_coefficients_1(__gm__ int32_t* v1, __gm__ int32_t* v2, __gm__ float* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ half* v6, int32_t v7, int32_t v8) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v9 = 4480;
  const int64_t v10 = 3584;
  const int64_t v11 = 2688;
  const int64_t v12 = 1792;
  const int64_t v13 = 896;
  // pto: %c0_i64
  const int64_t v14 = 0;
  // pto: %c12288_i64
  const int64_t v15 = 12288;
  // pto: %c13824_i64
  const int64_t v16 = 13824;
  // pto: %c1_index
  const int64_t v17 = 1;
  // pto: %c432_index
  const int64_t v18 = 432;
  // pto: %c64_index
  const int64_t v19 = 64;
  // pto: %c1152_index
  const int64_t v20 = 1152;
  // pto: %c384_index
  const int64_t v21 = 384;
  // pto: %c0_index
  const int64_t v22 = 0;
  // pto: %c48_index
  const int64_t v23 = 48;
  // pto: %c96_index
  const int64_t v24 = 96;
  // pto: %cst_11
  const half v25 = 0.0f;
  // pto: %c6_index
  const int64_t v26 = 6;
  // pto: %c2_index
  const int64_t v27 = 2;
  // pto: %c3_index
  const int64_t v28 = 3;
  // pto: %c4_index
  const int64_t v29 = 4;
  // pto: %c5_index
  const int64_t v30 = 5;
  // pto: %c16_index
  const int64_t v31 = 16;
  // pto: %coefficient_scales_inline170_inline9140__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %coefficient_scales_inline170_inline9140__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %coefficient_scales_inline170_inline9140__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %coefficient_scales_inline170_inline9140__ssa_v0_view
  int64_t v35 = v18 * v19;
  // pto: %coefficient_scales_inline170_inline9140__ssa_v0_view
  int64_t v36 = v34 * v35;
  // pto: %coefficient_scales_inline170_inline9140__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v37 = pto::Shape<1, 1, 1, -1, -1>(v32, v33, v34, v18, v19);
  // pto: %coefficient_scales_inline170_inline9140__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v38 = pto::Stride<-1, -1, -1, -1, -1>(v33 * v36, v36, v35, v19, v17);
  // pto: %coefficient_scales_inline170_inline9140__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v39 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v37, v38);
  // pto: %weights_inline5081__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %weights_inline5081__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %weights_inline5081__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %weights_inline5081__ssa_v0_view
  int64_t v43 = v18 * v19;
  // pto: %weights_inline5081__ssa_v0_view
  int64_t v44 = v42 * v43;
  // pto: %weights_inline5081__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v45 = pto::Shape<1, 1, 1, -1, -1>(v40, v41, v42, v18, v19);
  // pto: %weights_inline5081__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v46 = pto::Stride<-1, -1, -1, -1, -1>(v41 * v44, v44, v43, v19, v17);
  // pto: %weights_inline5081__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v47 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v45, v46);
  // pto: %coefficients_inline160_inline9061__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %coefficients_inline160_inline9061__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %coefficients_inline160_inline9061__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %coefficients_inline160_inline9061__ssa_v0_view
  int64_t v51 = v20 * v21;
  // pto: %coefficients_inline160_inline9061__ssa_v0_view
  int64_t v52 = v50 * v51;
  // pto: %coefficients_inline160_inline9061__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v53 = pto::Shape<1, 1, 1, -1, -1>(v48, v49, v50, v20, v21);
  // pto: %coefficients_inline160_inline9061__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v54 = pto::Stride<-1, -1, -1, -1, -1>(v49 * v52, v52, v51, v21, v17);
  // pto: %coefficients_inline160_inline9061__ssa_v0_view
  GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v55 = GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v53, v54);
  // pto: %coefficient_rows_inline158_inline9020__phi_v2
  Tile<TileType::Vec, half, 96, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v56 = Tile<TileType::Vec, half, 96, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v19);
  // pto: %coefficient_rows_inline158_inline9020__phi_v2
  uint64_t v57 = (uint64_t) v14;
  TASSIGN(v56, v57);
  // pto: %coefficient_rows_inline158_inline9020__phi_v4
  Tile<TileType::Vec, half, 96, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v58 = Tile<TileType::Vec, half, 96, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v19);
  // pto: %coefficient_rows_inline158_inline9020__phi_v4
  uint64_t v59 = (uint64_t) v14;
  TASSIGN(v58, v59);
  // pto: %coefficient_rows_inline158_inline9020__phi_v6
  Tile<TileType::Vec, half, 96, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v60 = Tile<TileType::Vec, half, 96, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v19);
  // pto: %coefficient_rows_inline158_inline9020__phi_v6
  uint64_t v61 = (uint64_t) v14;
  TASSIGN(v60, v61);
  // pto: %coefficient_rows_inline158_inline9020__phi_v8
  Tile<TileType::Vec, half, 96, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v62 = Tile<TileType::Vec, half, 96, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v19);
  // pto: %coefficient_rows_inline158_inline9020__phi_v8
  uint64_t v63 = (uint64_t) v14;
  TASSIGN(v62, v63);
  // pto: %coefficient_rows_inline158_inline9020__phi_v10
  Tile<TileType::Vec, half, 96, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v64 = Tile<TileType::Vec, half, 96, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v19);
  // pto: %coefficient_rows_inline158_inline9020__phi_v10
  uint64_t v65 = (uint64_t) v14;
  TASSIGN(v64, v65);
  // pto: %coefficient_rows_inline158_inline9020__phi_v12
  Tile<TileType::Vec, half, 96, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v66 = Tile<TileType::Vec, half, 96, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v19);
  // pto: %coefficient_rows_inline158_inline9020__phi_v12
  uint64_t v67 = (uint64_t) v14;
  TASSIGN(v66, v67);
  // pto: %coefficient_worker_inline162_inline9156__ssa_v0
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  // pto: %t__tile
  int32_t v68 = (v1)[v22];
  // pto: %0
  for (int64_t v69 = (int64_t) v7; v69 < ((int64_t) v68); v69 += v23) {
    // pto: %coefficient_rows_inline158_inline9020__ssa_v0
    ;
    Tile<TileType::Vec, half, 96, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v70 = Tile<TileType::Vec, half, 96, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v19);
    // pto: %coefficient_rows_inline158_inline9020__ssa_v0
    ;
    uint64_t v71 = (uint64_t) v14;
    TASSIGN(v70, v71);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    TEXPANDS(v70, v25);
    // pto: %1
    ;
    int32_t v72 = (v2)[v69];
    // pto: %2
    ;
    int64_t v73 = (int64_t) v72;
    // pto: %query_scales_inline161_inline9014__ssa_v0
    ;
    Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v74 = Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v19);
    // pto: %query_scales_inline161_inline9014__ssa_v0
    ;
    uint64_t v75 = (uint64_t) v15;
    TASSIGN(v74, v75);
    // pto: %3
    ;
    int64_t v76 = v73 < v22 ? v22 : v73;
    // pto: %coefficient_scales_inline170_inline9140__ssa_v0_pview
    ;
    __gm__ float* v77 = PTOAS__GLOBAL_TENSOR_DATA(v39);
    // pto: %coefficient_scales_inline170_inline9140__ssa_v0_pview
    ;
    const int64_t v78 = 0;
    // pto: %coefficient_scales_inline170_inline9140__ssa_v0_pview
    ;
    const int64_t v79 = 64;
    // pto: %coefficient_scales_inline170_inline9140__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 6, 64> v80 = pto::Shape<1, 1, 1, 6, 64>();
    // pto: %coefficient_scales_inline170_inline9140__ssa_v0_pview
    ;
    pto::Stride<384, 384, 384, 64, 1> v81 = pto::Stride<384, 384, 384, 64, 1>();
    // pto: %coefficient_scales_inline170_inline9140__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<384, 384, 384, 64, 1>, pto::Layout::ND> v82 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<384, 384, 384, 64, 1>, pto::Layout::ND>(v77 + (v78 + v76 * v79), v80, v81);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v74, v82);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %query_weights_inline169_inline9031__ssa_v0
    ;
    Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v83 = Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v19);
    // pto: %query_weights_inline169_inline9031__ssa_v0
    ;
    uint64_t v84 = (uint64_t) v16;
    TASSIGN(v83, v84);
    // pto: %weights_inline5081__ssa_v0_pview
    ;
    __gm__ float* v85 = PTOAS__GLOBAL_TENSOR_DATA(v47);
    // pto: %weights_inline5081__ssa_v0_pview
    ;
    const int64_t v86 = 0;
    // pto: %weights_inline5081__ssa_v0_pview
    ;
    const int64_t v87 = 64;
    // pto: %weights_inline5081__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 6, 64> v88 = pto::Shape<1, 1, 1, 6, 64>();
    // pto: %weights_inline5081__ssa_v0_pview
    ;
    pto::Stride<384, 384, 384, 64, 1> v89 = pto::Stride<384, 384, 384, 64, 1>();
    // pto: %weights_inline5081__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<384, 384, 384, 64, 1>, pto::Layout::ND> v90 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<384, 384, 384, 64, 1>, pto::Layout::ND>(v85 + (v86 + v76 * v87), v88, v89);
    TLOAD(v83, v90);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %query_scale_half_inline171_inline9042__ssa_v0
    ;
    Tile<TileType::Vec, half, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v91 = Tile<TileType::Vec, half, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v19);
    // pto: %query_scale_half_inline171_inline9042__ssa_v0
    ;
    uint64_t v92 = (uint64_t) v15;
    TASSIGN(v91, v92);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v93 = RoundMode::CAST_RINT;
    SaturationMode v94 = SaturationMode::ON;
    TCVT(v91, v74, v93, v94);
    // pto: %query_weight_half_inline163_inline9009__ssa_v0
    ;
    Tile<TileType::Vec, half, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v95 = Tile<TileType::Vec, half, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v19);
    // pto: %query_weight_half_inline163_inline9009__ssa_v0
    ;
    uint64_t v96 = (uint64_t) v16;
    TASSIGN(v95, v96);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    RoundMode v97 = RoundMode::CAST_RINT;
    SaturationMode v98 = SaturationMode::ON;
    TCVT(v95, v83, v97, v98);
    // pto: %head_coefficients_inline157_inline9003__ssa_v0
    ;
    Tile<TileType::Vec, half, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Vec, half, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v19);
    // pto: %head_coefficients_inline157_inline9003__ssa_v0
    ;
    uint64_t v100 = (uint64_t) v15;
    TASSIGN(v99, v100);
    pipe_barrier(PIPE_V);
    TMUL(v99, v91, v95);
    // pto: %5
    ;
    int32_t v101 = (v5)[v69];
    // pto: %6, %7
    ;
    if ((int64_t) v101 > v22) {
      // pto: %head_coefficient_inline155_inline9096__ssa_v0
      ;
      Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v19);
      // pto: %head_coefficient_inline155_inline9096__ssa_v0
      ;
      uint64_t v103 = (uint64_t) v16;
      TASSIGN(v102, v103);
      pipe_barrier(PIPE_V);
      uint16_t v104 = static_cast<uint16_t>(v22);
      uint16_t v105 = static_cast<uint16_t>(v22);
      TEXTRACT(v102, v99, v104, v105);
      // pto: %assemble_view
      ;
      Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v106;
      // pto: %assemble_view
      ;
      uint64_t v107 = (uint64_t) v14;
      TASSIGN(v106, v107);
      pipe_barrier(PIPE_V);
      TMOV(v106, v102);
    };
    // pto: %8
    ;
    int32_t v108 = (v5)[v69];
    // pto: %9, %10
    ;
    if ((int64_t) v108 > v17) {
      // pto: %head_coefficient_inline155_inline9096__ssa_v1
      ;
      Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v109 = Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v19);
      // pto: %head_coefficient_inline155_inline9096__ssa_v1
      ;
      uint64_t v110 = (uint64_t) v16;
      TASSIGN(v109, v110);
      pipe_barrier(PIPE_V);
      uint16_t v111 = static_cast<uint16_t>(v17);
      uint16_t v112 = static_cast<uint16_t>(v22);
      TEXTRACT(v109, v99, v111, v112);
      // pto: %11
      ;
      Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v113;
      // pto: %11
      ;
      uint64_t v114 = (uint64_t) v13;
      TASSIGN(v113, v114);
      pipe_barrier(PIPE_V);
      TMOV(v113, v109);
    };
    // pto: %12
    ;
    int32_t v115 = (v5)[v69];
    // pto: %13, %14
    ;
    if ((int64_t) v115 > v27) {
      // pto: %head_coefficient_inline155_inline9096__ssa_v2
      ;
      Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v19);
      // pto: %head_coefficient_inline155_inline9096__ssa_v2
      ;
      uint64_t v117 = (uint64_t) v16;
      TASSIGN(v116, v117);
      pipe_barrier(PIPE_V);
      uint16_t v118 = static_cast<uint16_t>(v27);
      uint16_t v119 = static_cast<uint16_t>(v22);
      TEXTRACT(v116, v99, v118, v119);
      // pto: %15
      ;
      Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v120;
      // pto: %15
      ;
      uint64_t v121 = (uint64_t) v12;
      TASSIGN(v120, v121);
      pipe_barrier(PIPE_V);
      TMOV(v120, v116);
    };
    // pto: %16
    ;
    int32_t v122 = (v5)[v69];
    // pto: %17, %18
    ;
    if ((int64_t) v122 > v28) {
      // pto: %head_coefficient_inline155_inline9096__ssa_v3
      ;
      Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v123 = Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v19);
      // pto: %head_coefficient_inline155_inline9096__ssa_v3
      ;
      uint64_t v124 = (uint64_t) v16;
      TASSIGN(v123, v124);
      pipe_barrier(PIPE_V);
      uint16_t v125 = static_cast<uint16_t>(v28);
      uint16_t v126 = static_cast<uint16_t>(v22);
      TEXTRACT(v123, v99, v125, v126);
      // pto: %19
      ;
      Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v127;
      // pto: %19
      ;
      uint64_t v128 = (uint64_t) v11;
      TASSIGN(v127, v128);
      pipe_barrier(PIPE_V);
      TMOV(v127, v123);
    };
    // pto: %20
    ;
    int32_t v129 = (v5)[v69];
    // pto: %21, %22
    ;
    if ((int64_t) v129 > v29) {
      // pto: %head_coefficient_inline155_inline9096__ssa_v4
      ;
      Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v19);
      // pto: %head_coefficient_inline155_inline9096__ssa_v4
      ;
      uint64_t v131 = (uint64_t) v16;
      TASSIGN(v130, v131);
      pipe_barrier(PIPE_V);
      uint16_t v132 = static_cast<uint16_t>(v29);
      uint16_t v133 = static_cast<uint16_t>(v22);
      TEXTRACT(v130, v99, v132, v133);
      // pto: %23
      ;
      Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v134;
      // pto: %23
      ;
      uint64_t v135 = (uint64_t) v10;
      TASSIGN(v134, v135);
      pipe_barrier(PIPE_V);
      TMOV(v134, v130);
    };
    // pto: %24
    ;
    int32_t v136 = (v5)[v69];
    // pto: %25, %26
    ;
    if ((int64_t) v136 > v30) {
      // pto: %head_coefficient_inline155_inline9096__ssa_v5
      ;
      Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v19);
      // pto: %head_coefficient_inline155_inline9096__ssa_v5
      ;
      uint64_t v138 = (uint64_t) v16;
      TASSIGN(v137, v138);
      pipe_barrier(PIPE_V);
      uint16_t v139 = static_cast<uint16_t>(v30);
      uint16_t v140 = static_cast<uint16_t>(v22);
      TEXTRACT(v137, v99, v139, v140);
      // pto: %27
      ;
      Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v141;
      // pto: %27
      ;
      uint64_t v142 = (uint64_t) v9;
      TASSIGN(v141, v142);
      pipe_barrier(PIPE_V);
      TMOV(v141, v137);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %coefficient_matrix_inline165_inline8995__ssa_v0
    ;
    Tile<TileType::Vec, half, 16, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v143 = Tile<TileType::Vec, half, 16, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v21);
    // pto: %coefficient_matrix_inline165_inline8995__ssa_v0
    ;
    uint64_t v144 = (uint64_t) v14;
    TASSIGN(v143, v144);
    // pto: %28
    ;
    int64_t v145 = (int64_t) ((uint64_t) v69 * (uint64_t) v31);
    // pto: %29
    ;
    int64_t v146 = v145 < v22 ? v22 : v145;
    // pto: %coefficients_inline160_inline9061__ssa_v0_pview
    ;
    __gm__ half* v147 = PTOAS__GLOBAL_TENSOR_DATA(v55);
    // pto: %coefficients_inline160_inline9061__ssa_v0_pview
    ;
    const int64_t v148 = 0;
    // pto: %coefficients_inline160_inline9061__ssa_v0_pview
    ;
    const int64_t v149 = 384;
    // pto: %coefficients_inline160_inline9061__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 16, 384> v150 = pto::Shape<1, 1, 1, 16, 384>();
    // pto: %coefficients_inline160_inline9061__ssa_v0_pview
    ;
    pto::Stride<6144, 6144, 6144, 384, 1> v151 = pto::Stride<6144, 6144, 6144, 384, 1>();
    // pto: %coefficients_inline160_inline9061__ssa_v0_pview
    ;
    GlobalTensor<half, pto::Shape<1, 1, 1, 16, 384>, pto::Stride<6144, 6144, 6144, 384, 1>, pto::Layout::ND> v152 = GlobalTensor<half, pto::Shape<1, 1, 1, 16, 384>, pto::Stride<6144, 6144, 6144, 384, 1>, pto::Layout::ND>(v147 + (v148 + v146 * v149), v150, v151);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v152, v143);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}