#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void scatter_softmax_pool_0(__gm__ float* v1, __gm__ float* v2, __gm__ float* v3, __gm__ int32_t* v4, __gm__ int64_t* v5, __gm__ int32_t* v6, __gm__ int32_t* v7, __gm__ float* v8, __gm__ float* v9, __gm__ float* v10, __gm__ float* v11, int64_t v12, int64_t v13, int64_t v14, int64_t v15, int64_t v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v22 = -7;
  // pto: %c768_i64
  const int64_t v23 = 768;
  // pto: %c2816_i64
  const int64_t v24 = 2816;
  // pto: %c0_i64
  const int64_t v25 = 0;
  // pto: %c256_i64
  const int64_t v26 = 256;
  // pto: %c512_i64
  const int64_t v27 = 512;
  const int64_t v28 = 1792;
  const int64_t v29 = 3328;
  const int64_t v30 = 3072;
  const int64_t v31 = 1280;
  const int64_t v32 = 1024;
  // pto: %c384_index
  const int64_t v33 = 384;
  // pto: %c128_index
  const int64_t v34 = 128;
  // pto: %c1_index
  const int64_t v35 = 1;
  // pto: %c256_index
  const int64_t v36 = 256;
  // pto: %c4_index
  const int64_t v37 = 4;
  // pto: %c0_index
  const int64_t v38 = 0;
  // pto: %cst_16
  const float v39 = 0.0f;
  // pto: %c1_i64
  const int64_t v40 = 1;
  // pto: %c4_i64
  const int64_t v41 = 4;
  // pto: %c64_index
  const int64_t v42 = 64;
  // pto: %c8_index
  const int64_t v43 = 8;
  // pto: %cst_22
  const float v44 = -3.40282347E+38f;
  // pto: %c2_i64
  const int64_t v45 = 2;
  // pto: %c512_index
  const int64_t v46 = 512;
  // pto: %c2_index
  const int64_t v47 = 2;
  // pto: %pooled_kv_inline4840__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %pooled_kv_inline4840__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %pooled_kv_inline4840__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %pooled_kv_inline4840__ssa_v0_view
  int64_t v51 = v33 * v34;
  // pto: %pooled_kv_inline4840__ssa_v0_view
  int64_t v52 = v50 * v51;
  // pto: %pooled_kv_inline4840__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v53 = pto::Shape<1, 1, 1, -1, -1>(v48, v49, v50, v33, v34);
  // pto: %pooled_kv_inline4840__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v54 = pto::Stride<-1, -1, -1, -1, -1>(v49 * v52, v52, v51, v34, v35);
  // pto: %pooled_kv_inline4840__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v55 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v53, v54);
  // pto: %window_scores_inline719_inline4849__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %window_scores_inline719_inline4849__ssa_v0_view
  const int64_t v57 = 1;
  // pto: %window_scores_inline719_inline4849__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %window_scores_inline719_inline4849__ssa_v0_view
  int64_t v59 = v33 * v34;
  // pto: %window_scores_inline719_inline4849__ssa_v0_view
  int64_t v60 = v58 * v59;
  // pto: %window_scores_inline719_inline4849__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v61 = pto::Shape<1, 1, 1, -1, -1>(v56, v57, v58, v33, v34);
  // pto: %window_scores_inline719_inline4849__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v62 = pto::Stride<-1, -1, -1, -1, -1>(v57 * v60, v60, v59, v34, v35);
  // pto: %window_scores_inline719_inline4849__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v63 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v61, v62);
  // pto: %window_values_inline732_inline4819__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %window_values_inline732_inline4819__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %window_values_inline732_inline4819__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %window_values_inline732_inline4819__ssa_v0_view
  int64_t v67 = v33 * v34;
  // pto: %window_values_inline732_inline4819__ssa_v0_view
  int64_t v68 = v66 * v67;
  // pto: %window_values_inline732_inline4819__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v69 = pto::Shape<1, 1, 1, -1, -1>(v64, v65, v66, v33, v34);
  // pto: %window_values_inline732_inline4819__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v70 = pto::Stride<-1, -1, -1, -1, -1>(v65 * v68, v68, v67, v34, v35);
  // pto: %window_values_inline732_inline4819__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v71 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v69, v70);
  // pto: %inner_compress_state__ssa_v0_view
  const int64_t v72 = 1;
  // pto: %inner_compress_state__ssa_v0_view
  const int64_t v73 = 1;
  // pto: %inner_compress_state__ssa_v0_view
  const int64_t v74 = 1;
  // pto: %inner_compress_state__ssa_v0_view
  int64_t v75 = (int64_t) v18;
  // pto: %inner_compress_state__ssa_v0_view
  int64_t v76 = (int64_t) v19;
  // pto: %inner_compress_state__ssa_v0_view
  int64_t v77 = v75 * v76;
  // pto: %inner_compress_state__ssa_v0_view
  int64_t v78 = v74 * v77;
  // pto: %inner_compress_state__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v79 = pto::Shape<1, 1, 1, -1, -1>(v72, v73, v74, v75, (int64_t) v19);
  // pto: %inner_compress_state__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v80 = pto::Stride<-1, -1, -1, -1, -1>(v73 * v78, v78, v77, v76, v35);
  // pto: %inner_compress_state__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v81 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v79, v80);
  // pto: %kv_proj_pad_inline4846__rv_v2_view
  const int64_t v82 = 1;
  // pto: %kv_proj_pad_inline4846__rv_v2_view
  const int64_t v83 = 1;
  // pto: %kv_proj_pad_inline4846__rv_v2_view
  const int64_t v84 = 1;
  // pto: %kv_proj_pad_inline4846__rv_v2_view
  int64_t v85 = v33 * v36;
  // pto: %kv_proj_pad_inline4846__rv_v2_view
  int64_t v86 = v84 * v85;
  // pto: %kv_proj_pad_inline4846__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v87 = pto::Shape<1, 1, 1, -1, -1>(v82, v83, v84, v33, v36);
  // pto: %kv_proj_pad_inline4846__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v88 = pto::Stride<-1, -1, -1, -1, -1>(v83 * v86, v86, v85, v36, v35);
  // pto: %kv_proj_pad_inline4846__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v89 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v87, v88);
  // pto: %score_proj_pad_inline4850__rv_v2_view
  const int64_t v90 = 1;
  // pto: %score_proj_pad_inline4850__rv_v2_view
  const int64_t v91 = 1;
  // pto: %score_proj_pad_inline4850__rv_v2_view
  const int64_t v92 = 1;
  // pto: %score_proj_pad_inline4850__rv_v2_view
  int64_t v93 = v33 * v36;
  // pto: %score_proj_pad_inline4850__rv_v2_view
  int64_t v94 = v92 * v93;
  // pto: %score_proj_pad_inline4850__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v95 = pto::Shape<1, 1, 1, -1, -1>(v90, v91, v92, v33, v36);
  // pto: %score_proj_pad_inline4850__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v96 = pto::Stride<-1, -1, -1, -1, -1>(v91 * v94, v94, v93, v36, v35);
  // pto: %score_proj_pad_inline4850__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v97 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v10, v95, v96);
  // pto: %inner_ape__ssa_v0_view
  const int64_t v98 = 1;
  // pto: %inner_ape__ssa_v0_view
  const int64_t v99 = 1;
  // pto: %inner_ape__ssa_v0_view
  const int64_t v100 = 1;
  // pto: %inner_ape__ssa_v0_view
  int64_t v101 = v37 * v36;
  // pto: %inner_ape__ssa_v0_view
  int64_t v102 = v100 * v101;
  // pto: %inner_ape__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v103 = pto::Shape<1, 1, 1, -1, -1>(v98, v99, v100, v37, v36);
  // pto: %inner_ape__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v104 = pto::Stride<-1, -1, -1, -1, -1>(v99 * v102, v102, v101, v36, v35);
  // pto: %inner_ape__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v105 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v11, v103, v104);
  // pto: %score_inline720_inline4888__phi_v4
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %score_inline720_inline4888__phi_v4
  uint64_t v107 = (uint64_t) v27;
  TASSIGN(v106, v107);
  // pto: %value_inline753_inline4886__phi_v3
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %value_inline753_inline4886__phi_v3
  uint64_t v109 = (uint64_t) v26;
  TASSIGN(v108, v109);
  // pto: %score_inline720_inline4888__phi_v3
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %score_inline720_inline4888__phi_v3
  uint64_t v111 = (uint64_t) v27;
  TASSIGN(v110, v111);
  // pto: %value_inline753_inline4886__phi_v2
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v112 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %value_inline753_inline4886__phi_v2
  uint64_t v113 = (uint64_t) v26;
  TASSIGN(v112, v113);
  // pto: %score_inline720_inline4888__phi_v7
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v114 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %score_inline720_inline4888__phi_v7
  uint64_t v115 = (uint64_t) v24;
  TASSIGN(v114, v115);
  // pto: %value_inline753_inline4886__phi_v6
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %value_inline753_inline4886__phi_v6
  uint64_t v117 = (uint64_t) v23;
  TASSIGN(v116, v117);
  // pto: %score_inline720_inline4888__phi_v6
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v118 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %score_inline720_inline4888__phi_v6
  uint64_t v119 = (uint64_t) v24;
  TASSIGN(v118, v119);
  // pto: %value_inline753_inline4886__phi_v5
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %value_inline753_inline4886__phi_v5
  uint64_t v121 = (uint64_t) v23;
  TASSIGN(v120, v121);
  // pto: %pool_worker_inline721_inline4872__ssa_v0
  int64_t v122 = (int64_t) v20;
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v123 = v122; v123 < v12; v123 += v13) {
    // pto: %31
    ;
    int32_t v124 = (v4)[v123];
    // pto: %32
    ;
    int64_t v125 = (int64_t) v124;
    // pto: %34, %33
    ;
    int32_t v126 = (v4)[(int64_t) ((uint64_t) v123 + (uint64_t) v35)];
    // pto: %35
    ;
    int64_t v127 = (int64_t) v126;
    // pto: %37
    ;
    // pto: %first_pos_b_inline736_inline4852__phi_v2
    ;
    int64_t v128;
    if (v125 < v127) {
      // pto: %38
      ;
      int64_t v129 = (v5)[v125];
      v128 = v129;
    } else {
      v128 = v38;
    };
    for (int64_t v130 = v125; v130 < v127; v130 += v35) {
      // pto: %token_pos_inline715_inline4853__tile
      ;
      int64_t v131 = (v5)[v130];
      // pto: %t__tile
      ;
      Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v132 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v34);
      // pto: %t__tile
      ;
      uint64_t v133 = (uint64_t) v23;
      TASSIGN(v132, v133);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      TEXPANDS(v132, v39);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      // pto: %45
      ;
      int64_t v134 = v130 < v38 ? v38 : v130;
      // pto: %pooled_kv_inline4840__iter_v3_pview
      ;
      __gm__ float* v135 = PTOAS__GLOBAL_TENSOR_DATA(v55);
      // pto: %pooled_kv_inline4840__iter_v3_pview
      ;
      const int64_t v136 = 0;
      // pto: %pooled_kv_inline4840__iter_v3_pview
      ;
      const int64_t v137 = 128;
      // pto: %pooled_kv_inline4840__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, 1, 128> v138 = pto::Shape<1, 1, 1, 1, 128>();
      // pto: %pooled_kv_inline4840__iter_v3_pview
      ;
      pto::Stride<128, 128, 128, 128, 1> v139 = pto::Stride<128, 128, 128, 128, 1>();
      // pto: %pooled_kv_inline4840__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v140 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v135 + (v136 + v134 * v137), v138, v139);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v140, v132);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      // pto: %46
      ;
      int32_t v141 = (v6)[v130];
      // pto: %49, %50
      ;
      int64_t v142 = (int64_t) ((uint64_t) v131 + (uint64_t) v40) % v41;
      // pto: %51, %52, %53
      ;
      int64_t v143 = v142 < v25 ? (int64_t) ((uint64_t) v142 + (uint64_t) v41) : v142;
      // pto: %47, %48, %54, %55
      ;
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      if ((int64_t) v141 >= v38 & v143 == v25) {
        for (int64_t v144 = v38; v144 < v34; v144 += v42) {
          // pto: %58
          ;
          int64_t v145 = (int64_t) ((uint64_t) v122 * (uint64_t) v43);
          wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
          for (int64_t v146 = v38; v146 < v43; v146 += v35) {
            // pto: %60
            ;
            int64_t v147 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v131 + (uint64_t) v22) + (uint64_t) v146);
            // pto: %value_inline753_inline4886__tile
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v148 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
            // pto: %value_inline753_inline4886__tile
            ;
            uint64_t v149 = (uint64_t) v23;
            TASSIGN(v148, v149);
            wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
            pipe_barrier(PIPE_V);
            TEXPANDS(v148, v39);
            // pto: %score_inline720_inline4888__tile
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v150 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
            // pto: %score_inline720_inline4888__tile
            ;
            uint64_t v151 = (uint64_t) v24;
            TASSIGN(v150, v151);
            wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
            TEXPANDS(v150, v44);
            // pto: %61, %state_half_inline727_inline4890__phi_v2
            ;
            int64_t v152 = v146 >= v37 ? v34 : v38;
            // pto: %65
            ;
            bool v153 = v147 < v128;
            // pto: %63, %66
            ;
            wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
            if (v147 >= v38 & v153) {
              // pto: %0
              ;
              Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v154 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
              // pto: %0
              ;
              uint64_t v155 = (uint64_t) v25;
              TASSIGN(v154, v155);
              TEXPANDS(v154, v39);
              // pto: %flat_offset_mul, %flat_offset, %68, %67
              ;
              int32_t v156 = (v7)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v17) + (uint64_t) (v147 / v45))];
              // pto: %70
              ;
              int64_t v157 = (int64_t) v156;
              // pto: %71
              ;
              if (v157 >= v38) {
                // pto: %72
                ;
                int64_t v158 = v147 % v45;
                // pto: %73, %74, %75
                ;
                int64_t v159 = v158 < v25 ? (int64_t) ((uint64_t) v158 + (uint64_t) v45) : v158;
                // pto: %77, %78, %79
                ;
                int64_t v160 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v159 * (uint64_t) v46) + (uint64_t) v152) + (uint64_t) v144);
                // pto: %1
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v161 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %1
                ;
                uint64_t v162 = (uint64_t) v26;
                TASSIGN(v161, v162);
                // pto: %80
                ;
                int64_t v163 = v157 < v38 ? v38 : v157;
                // pto: %81
                ;
                int64_t v164 = v160 < v38 ? v38 : v160;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                int64_t v165 = (int64_t) v19;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                const int64_t v166 = 0;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                __gm__ float* v167 = PTOAS__GLOBAL_TENSOR_DATA(v81);
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                const int64_t v168 = 1;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                const int64_t v169 = 1;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                const int64_t v170 = 1;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                int64_t v171 = v35 * v165;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                int64_t v172 = v170 * v171;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                pto::Shape<1, 1, 1, 1, 64> v173 = pto::Shape<1, 1, 1, 1, 64>(v168, v169, v170, v35, v42);
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                pto::Stride<-1, -1, -1, -1, -1> v174 = pto::Stride<-1, -1, -1, -1, -1>(v169 * v172, v172, v171, v165, v35);
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v175 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v167 + (v166 + v163 * v165 + v164 * v35), v173, v174);
                TLOAD(v161, v175);
                // pto: %2
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v176 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %2
                ;
                uint64_t v177 = (uint64_t) v27;
                TASSIGN(v176, v177);
                // pto: %83
                ;
                int64_t v178 = (int64_t) ((uint64_t) v160 + (uint64_t) v36);
                // pto: %84
                ;
                int64_t v179 = v178 < v38 ? v38 : v178;
                // pto: %85
                ;
                int64_t v180 = (int64_t) v19;
                // pto: %85
                ;
                const int64_t v181 = 0;
                // pto: %85
                ;
                __gm__ float* v182 = PTOAS__GLOBAL_TENSOR_DATA(v81);
                // pto: %85
                ;
                const int64_t v183 = 1;
                // pto: %85
                ;
                const int64_t v184 = 1;
                // pto: %85
                ;
                const int64_t v185 = 1;
                // pto: %85
                ;
                int64_t v186 = v35 * v180;
                // pto: %85
                ;
                int64_t v187 = v185 * v186;
                // pto: %85
                ;
                pto::Shape<1, 1, 1, 1, 64> v188 = pto::Shape<1, 1, 1, 1, 64>(v183, v184, v185, v35, v42);
                // pto: %85
                ;
                pto::Stride<-1, -1, -1, -1, -1> v189 = pto::Stride<-1, -1, -1, -1, -1>(v184 * v187, v187, v186, v180, v35);
                // pto: %85
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v190 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v182 + (v181 + v163 * v180 + v179 * v35), v188, v189);
                TLOAD(v176, v190);
              } else {
                // pto: %score_inline720_inline4888__tile_mv
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v191 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %score_inline720_inline4888__tile_mv
                ;
                uint64_t v192 = (uint64_t) v27;
                TASSIGN(v191, v192);
                pipe_barrier(PIPE_V);
                TMOV(v191, v154);
                // pto: %value_inline753_inline4886__tile_mv
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v193 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %value_inline753_inline4886__tile_mv
                ;
                uint64_t v194 = (uint64_t) v26;
                TASSIGN(v193, v194);
                TMOV(v193, v148);
              };
            } else {
              // pto: %3
              ;
              Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v195 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
              // pto: %3
              ;
              uint64_t v196 = (uint64_t) v27;
              TASSIGN(v195, v196);
              pipe_barrier(PIPE_V);
              TMOV(v195, v150);
              // pto: %4
              ;
              Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v197 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
              // pto: %4
              ;
              uint64_t v198 = (uint64_t) v26;
              TASSIGN(v197, v198);
              TMOV(v197, v148);
            };
            set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
            // pto: %87
            ;
            bool v199 = v128 <= v147;
            wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
            wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
            if (v199) {
              // pto: %88
              ;
              if (v147 <= v131) {
                // pto: %91
                ;
                uint64_t v200 = (uint64_t) v128;
                // pto: %90, %91
                ;
                int64_t v201 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v125 + (uint64_t) v147) - v200);
                // pto: %92
                ;
                int64_t v202 = v147 % v41;
                // pto: %93, %94, %95
                ;
                int64_t v203 = v202 < v25 ? (int64_t) ((uint64_t) v202 + (uint64_t) v41) : v202;
                // pto: %5
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v204 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %5
                ;
                uint64_t v205 = (uint64_t) v23;
                TASSIGN(v204, v205);
                // pto: %97
                ;
                int64_t v206 = v201 < v38 ? v38 : v201;
                // pto: %98
                ;
                int64_t v207 = (int64_t) ((uint64_t) v152 + (uint64_t) v144);
                // pto: %99
                ;
                int64_t v208 = v207 < v38 ? v38 : v207;
                // pto: %kv_proj_pad_inline4846__rv_v2_pview
                ;
                __gm__ float* v209 = PTOAS__GLOBAL_TENSOR_DATA(v89);
                // pto: %kv_proj_pad_inline4846__rv_v2_pview
                ;
                const int64_t v210 = 0;
                // pto: %kv_proj_pad_inline4846__rv_v2_pview
                ;
                const int64_t v211 = 256;
                // pto: %kv_proj_pad_inline4846__rv_v2_pview
                ;
                pto::Shape<1, 1, 1, 1, 64> v212 = pto::Shape<1, 1, 1, 1, 64>();
                // pto: %kv_proj_pad_inline4846__rv_v2_pview
                ;
                pto::Stride<256, 256, 256, 256, 1> v213 = pto::Stride<256, 256, 256, 256, 1>();
                // pto: %kv_proj_pad_inline4846__rv_v2_pview
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND> v214 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND>(v209 + (v210 + v206 * v211 + v208), v212, v213);
                TLOAD(v204, v214);
                // pto: %6
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %6
                ;
                uint64_t v216 = (uint64_t) v24;
                TASSIGN(v215, v216);
                // pto: %score_proj_pad_inline4850__rv_v2_pview
                ;
                __gm__ float* v217 = PTOAS__GLOBAL_TENSOR_DATA(v97);
                // pto: %score_proj_pad_inline4850__rv_v2_pview
                ;
                const int64_t v218 = 0;
                // pto: %score_proj_pad_inline4850__rv_v2_pview
                ;
                const int64_t v219 = 256;
                // pto: %score_proj_pad_inline4850__rv_v2_pview
                ;
                pto::Shape<1, 1, 1, 1, 64> v220 = pto::Shape<1, 1, 1, 1, 64>();
                // pto: %score_proj_pad_inline4850__rv_v2_pview
                ;
                pto::Stride<256, 256, 256, 256, 1> v221 = pto::Stride<256, 256, 256, 256, 1>();
                // pto: %score_proj_pad_inline4850__rv_v2_pview
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND> v222 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND>(v217 + (v218 + v206 * v219 + v208), v220, v221);
                TLOAD(v215, v222);
                // pto: %7
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v223 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %7
                ;
                uint64_t v224 = (uint64_t) v25;
                TASSIGN(v223, v224);
                // pto: %103
                ;
                int64_t v225 = v203 < v38 ? v38 : v203;
                // pto: %inner_ape__ssa_v0_pview
                ;
                __gm__ float* v226 = PTOAS__GLOBAL_TENSOR_DATA(v105);
                // pto: %inner_ape__ssa_v0_pview
                ;
                const int64_t v227 = 0;
                // pto: %inner_ape__ssa_v0_pview
                ;
                const int64_t v228 = 256;
                // pto: %inner_ape__ssa_v0_pview
                ;
                pto::Shape<1, 1, 1, 1, 64> v229 = pto::Shape<1, 1, 1, 1, 64>();
                // pto: %inner_ape__ssa_v0_pview
                ;
                pto::Stride<256, 256, 256, 256, 1> v230 = pto::Stride<256, 256, 256, 256, 1>();
                // pto: %inner_ape__ssa_v0_pview
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND> v231 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND>(v226 + (v227 + v225 * v228 + v208), v229, v230);
                TLOAD(v223, v231);
                set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
                // pto: %8
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v232 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %8
                ;
                uint64_t v233 = (uint64_t) v24;
                TASSIGN(v232, v233);
                wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
                TADD(v232, v215, v223);
              } else {
                // pto: %score_inline720_inline4888__phi_v4_mv
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v234 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %score_inline720_inline4888__phi_v4_mv
                ;
                uint64_t v235 = (uint64_t) v24;
                TASSIGN(v234, v235);
                pipe_barrier(PIPE_V);
                TMOV(v234, v106);
                // pto: %value_inline753_inline4886__phi_v3_mv
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v236 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %value_inline753_inline4886__phi_v3_mv
                ;
                uint64_t v237 = (uint64_t) v23;
                TASSIGN(v236, v237);
                TMOV(v236, v108);
              };
            } else {
              // pto: %9
              ;
              Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v238 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
              // pto: %9
              ;
              uint64_t v239 = (uint64_t) v24;
              TASSIGN(v238, v239);
              pipe_barrier(PIPE_V);
              TMOV(v238, v106);
              // pto: %10
              ;
              Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v240 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
              // pto: %10
              ;
              uint64_t v241 = (uint64_t) v23;
              TASSIGN(v240, v241);
              TMOV(v240, v108);
            };
            set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
            set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
            set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
            // pto: %106
            ;
            int64_t v242 = v146 % v37;
            // pto: %107, %108, %109
            ;
            int64_t v243 = v242 < v38 ? (int64_t) ((uint64_t) v242 + (uint64_t) v37) : v242;
            // pto: %113, %110, %112, %111
            ;
            int64_t v244 = (int64_t) ((uint64_t) v145 + (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v243 * (uint64_t) v47) + (uint64_t) (v146 / v37)));
            // pto: %114
            ;
            int64_t v245 = v244 < v38 ? v38 : v244;
            // pto: %115
            ;
            int64_t v246 = v144 < v38 ? v38 : v144;
            // pto: %window_values_inline732_inline4819__iter_v7_pview
            ;
            __gm__ float* v247 = PTOAS__GLOBAL_TENSOR_DATA(v71);
            // pto: %window_values_inline732_inline4819__iter_v7_pview
            ;
            const int64_t v248 = 0;
            // pto: %window_values_inline732_inline4819__iter_v7_pview
            ;
            const int64_t v249 = 128;
            // pto: %window_values_inline732_inline4819__iter_v7_pview
            ;
            pto::Shape<1, 1, 1, 1, 64> v250 = pto::Shape<1, 1, 1, 1, 64>();
            // pto: %window_values_inline732_inline4819__iter_v7_pview
            ;
            pto::Stride<128, 128, 128, 128, 1> v251 = pto::Stride<128, 128, 128, 128, 1>();
            // pto: %window_values_inline732_inline4819__iter_v7_pview
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v252 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v247 + (v248 + v245 * v249 + v246), v250, v251);
            wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
            wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
            TSTORE(v252, v116);
            set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
            // pto: %window_scores_inline719_inline4849__iter_v7_pview
            ;
            __gm__ float* v253 = PTOAS__GLOBAL_TENSOR_DATA(v63);
            // pto: %window_scores_inline719_inline4849__iter_v7_pview
            ;
            const int64_t v254 = 0;
            // pto: %window_scores_inline719_inline4849__iter_v7_pview
            ;
            const int64_t v255 = 128;
            // pto: %window_scores_inline719_inline4849__iter_v7_pview
            ;
            pto::Shape<1, 1, 1, 1, 64> v256 = pto::Shape<1, 1, 1, 1, 64>();
            // pto: %window_scores_inline719_inline4849__iter_v7_pview
            ;
            pto::Stride<128, 128, 128, 128, 1> v257 = pto::Stride<128, 128, 128, 128, 1>();
            // pto: %window_scores_inline719_inline4849__iter_v7_pview
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v258 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v253 + (v254 + v245 * v255 + v246), v256, v257);
            TSTORE(v258, v114);
            set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
          };
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
          // pto: %score_rows_inline743_inline4830__tile
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v259 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v42);
          // pto: %score_rows_inline743_inline4830__tile
          ;
          uint64_t v260 = (uint64_t) v23;
          TASSIGN(v259, v260);
          // pto: %118
          ;
          int64_t v261 = v145 < v38 ? v38 : v145;
          // pto: %119
          ;
          int64_t v262 = v144 < v38 ? v38 : v144;
          // pto: %window_scores_inline719_inline4849__rv_v8_pview
          ;
          __gm__ float* v263 = PTOAS__GLOBAL_TENSOR_DATA(v63);
          // pto: %window_scores_inline719_inline4849__rv_v8_pview
          ;
          const int64_t v264 = 0;
          // pto: %window_scores_inline719_inline4849__rv_v8_pview
          ;
          const int64_t v265 = 128;
          // pto: %window_scores_inline719_inline4849__rv_v8_pview
          ;
          pto::Shape<1, 1, 1, 8, 64> v266 = pto::Shape<1, 1, 1, 8, 64>();
          // pto: %window_scores_inline719_inline4849__rv_v8_pview
          ;
          pto::Stride<1024, 1024, 1024, 128, 1> v267 = pto::Stride<1024, 1024, 1024, 128, 1>();
          // pto: %window_scores_inline719_inline4849__rv_v8_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<1024, 1024, 1024, 128, 1>, pto::Layout::ND> v268 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<1024, 1024, 1024, 128, 1>, pto::Layout::ND>(v263 + (v264 + v261 * v265 + v262), v266, v267);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
          TLOAD(v259, v268);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          // pto: %11
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v269 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %11
          ;
          uint64_t v270 = (uint64_t) v23;
          TASSIGN(v269, v270);
          // pto: %slice_view
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, 4, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v271;
          // pto: %slice_view
          ;
          uint64_t v272 = (uint64_t) v23;
          TASSIGN(v271, v272);
          // pto: %12
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v273 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %12
          ;
          uint64_t v274 = (uint64_t) v28;
          TASSIGN(v273, v274);
          // pto: %120
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, 4, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v275;
          // pto: %120
          ;
          uint64_t v276 = (uint64_t) v28;
          TASSIGN(v275, v276);
          // pto: %max4_inline745_inline4857__tile
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v277 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %max4_inline745_inline4857__tile
          ;
          uint64_t v278 = (uint64_t) v24;
          TASSIGN(v277, v278);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          TMAX(v277, v271, v275);
          // pto: %13
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v279 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %13
          ;
          uint64_t v280 = (uint64_t) v24;
          TASSIGN(v279, v280);
          // pto: %121
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, 2, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v281;
          // pto: %121
          ;
          uint64_t v282 = (uint64_t) v24;
          TASSIGN(v281, v282);
          // pto: %14
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v283 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %14
          ;
          uint64_t v284 = (uint64_t) v29;
          TASSIGN(v283, v284);
          // pto: %122
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, 2, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v285;
          // pto: %122
          ;
          uint64_t v286 = (uint64_t) v29;
          TASSIGN(v285, v286);
          // pto: %max2_inline747_inline4881__tile
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v287 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %max2_inline747_inline4881__tile
          ;
          uint64_t v288 = (uint64_t) v24;
          TASSIGN(v287, v288);
          pipe_barrier(PIPE_V);
          TMAX(v287, v281, v285);
          // pto: %15
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v289 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %15
          ;
          uint64_t v290 = (uint64_t) v24;
          TASSIGN(v289, v290);
          // pto: %123
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v291;
          // pto: %123
          ;
          uint64_t v292 = (uint64_t) v24;
          TASSIGN(v291, v292);
          // pto: %16
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v293 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %16
          ;
          uint64_t v294 = (uint64_t) v30;
          TASSIGN(v293, v294);
          // pto: %124
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v295;
          // pto: %124
          ;
          uint64_t v296 = (uint64_t) v30;
          TASSIGN(v295, v296);
          // pto: %maximum_inline749_inline4833__tile
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v297 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %maximum_inline749_inline4833__tile
          ;
          uint64_t v298 = (uint64_t) v24;
          TASSIGN(v297, v298);
          pipe_barrier(PIPE_V);
          TMAX(v297, v291, v295);
          // pto: %17
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v299 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v42);
          // pto: %17
          ;
          uint64_t v300 = (uint64_t) v23;
          TASSIGN(v299, v300);
          pipe_barrier(PIPE_V);
          TCOLEXPANDSUB(v299, v259, v297);
          // pto: %probability_inline750_inline4841__tile
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v301 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v42);
          // pto: %probability_inline750_inline4841__tile
          ;
          uint64_t v302 = (uint64_t) v23;
          TASSIGN(v301, v302);
          pipe_barrier(PIPE_V);
          TEXP(v301, v299);
          // pto: %18
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v303 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %18
          ;
          uint64_t v304 = (uint64_t) v23;
          TASSIGN(v303, v304);
          // pto: %125
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, 4, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v305;
          // pto: %125
          ;
          uint64_t v306 = (uint64_t) v23;
          TASSIGN(v305, v306);
          // pto: %19
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v307 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %19
          ;
          uint64_t v308 = (uint64_t) v28;
          TASSIGN(v307, v308);
          // pto: %126
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, 4, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309;
          // pto: %126
          ;
          uint64_t v310 = (uint64_t) v28;
          TASSIGN(v309, v310);
          // pto: %sum4_inline700_inline4887__tile
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v311 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %sum4_inline700_inline4887__tile
          ;
          uint64_t v312 = (uint64_t) v24;
          TASSIGN(v311, v312);
          pipe_barrier(PIPE_V);
          TADD(v311, v305, v309);
          // pto: %20
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %20
          ;
          uint64_t v314 = (uint64_t) v24;
          TASSIGN(v313, v314);
          // pto: %127
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, 2, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315;
          // pto: %127
          ;
          uint64_t v316 = (uint64_t) v24;
          TASSIGN(v315, v316);
          // pto: %21
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v317 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %21
          ;
          uint64_t v318 = (uint64_t) v29;
          TASSIGN(v317, v318);
          // pto: %128
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, 2, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v319;
          // pto: %128
          ;
          uint64_t v320 = (uint64_t) v29;
          TASSIGN(v319, v320);
          // pto: %sum2_inline754_inline4895__tile
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v321 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %sum2_inline754_inline4895__tile
          ;
          uint64_t v322 = (uint64_t) v24;
          TASSIGN(v321, v322);
          pipe_barrier(PIPE_V);
          TADD(v321, v315, v319);
          // pto: %22
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v323 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %22
          ;
          uint64_t v324 = (uint64_t) v24;
          TASSIGN(v323, v324);
          // pto: %129
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v325;
          // pto: %129
          ;
          uint64_t v326 = (uint64_t) v24;
          TASSIGN(v325, v326);
          // pto: %23
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v327 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %23
          ;
          uint64_t v328 = (uint64_t) v30;
          TASSIGN(v327, v328);
          // pto: %130
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v329;
          // pto: %130
          ;
          uint64_t v330 = (uint64_t) v30;
          TASSIGN(v329, v330);
          // pto: %total_inline755_inline4817__tile
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v331 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %total_inline755_inline4817__tile
          ;
          uint64_t v332 = (uint64_t) v24;
          TASSIGN(v331, v332);
          pipe_barrier(PIPE_V);
          TADD(v331, v325, v329);
          // pto: %probability_v1_inline726_inline4834__tile
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v333 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v42);
          // pto: %probability_v1_inline726_inline4834__tile
          ;
          uint64_t v334 = (uint64_t) v23;
          TASSIGN(v333, v334);
          pipe_barrier(PIPE_V);
          TCOLEXPANDDIV(v333, v301, v331);
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
          // pto: %value_rows_inline723_inline4816__tile
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v335 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v42);
          // pto: %value_rows_inline723_inline4816__tile
          ;
          uint64_t v336 = (uint64_t) v24;
          TASSIGN(v335, v336);
          // pto: %window_values_inline732_inline4819__rv_v8_pview
          ;
          __gm__ float* v337 = PTOAS__GLOBAL_TENSOR_DATA(v71);
          // pto: %window_values_inline732_inline4819__rv_v8_pview
          ;
          const int64_t v338 = 0;
          // pto: %window_values_inline732_inline4819__rv_v8_pview
          ;
          const int64_t v339 = 128;
          // pto: %window_values_inline732_inline4819__rv_v8_pview
          ;
          pto::Shape<1, 1, 1, 8, 64> v340 = pto::Shape<1, 1, 1, 8, 64>();
          // pto: %window_values_inline732_inline4819__rv_v8_pview
          ;
          pto::Stride<1024, 1024, 1024, 128, 1> v341 = pto::Stride<1024, 1024, 1024, 128, 1>();
          // pto: %window_values_inline732_inline4819__rv_v8_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<1024, 1024, 1024, 128, 1>, pto::Layout::ND> v342 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<1024, 1024, 1024, 128, 1>, pto::Layout::ND>(v337 + (v338 + v261 * v339 + v262), v340, v341);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
          TLOAD(v335, v342);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
          // pto: %weighted_inline740_inline4815__tile
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v343 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v42);
          // pto: %weighted_inline740_inline4815__tile
          ;
          uint64_t v344 = (uint64_t) v23;
          TASSIGN(v343, v344);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
          TMUL(v343, v335, v333);
          // pto: %24
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v345 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %24
          ;
          uint64_t v346 = (uint64_t) v23;
          TASSIGN(v345, v346);
          // pto: %133
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, 4, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v347;
          // pto: %133
          ;
          uint64_t v348 = (uint64_t) v23;
          TASSIGN(v347, v348);
          // pto: %25
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v349 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %25
          ;
          uint64_t v350 = (uint64_t) v28;
          TASSIGN(v349, v350);
          // pto: %134
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, 4, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v351;
          // pto: %134
          ;
          uint64_t v352 = (uint64_t) v28;
          TASSIGN(v351, v352);
          // pto: %weighted4_inline757_inline4874__tile
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v353 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %weighted4_inline757_inline4874__tile
          ;
          uint64_t v354 = (uint64_t) v23;
          TASSIGN(v353, v354);
          pipe_barrier(PIPE_V);
          TADD(v353, v347, v351);
          // pto: %26
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v355 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %26
          ;
          uint64_t v356 = (uint64_t) v23;
          TASSIGN(v355, v356);
          // pto: %135
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, 2, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v357;
          // pto: %135
          ;
          uint64_t v358 = (uint64_t) v23;
          TASSIGN(v357, v358);
          // pto: %27
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v359 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %27
          ;
          uint64_t v360 = (uint64_t) v31;
          TASSIGN(v359, v360);
          // pto: %136
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, 2, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v361;
          // pto: %136
          ;
          uint64_t v362 = (uint64_t) v31;
          TASSIGN(v361, v362);
          // pto: %weighted2_inline758_inline4813__tile
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v363 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %weighted2_inline758_inline4813__tile
          ;
          uint64_t v364 = (uint64_t) v23;
          TASSIGN(v363, v364);
          pipe_barrier(PIPE_V);
          TADD(v363, v357, v361);
          // pto: %28
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v365 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %28
          ;
          uint64_t v366 = (uint64_t) v23;
          TASSIGN(v365, v366);
          // pto: %137
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v367;
          // pto: %137
          ;
          uint64_t v368 = (uint64_t) v23;
          TASSIGN(v367, v368);
          // pto: %29
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v369 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %29
          ;
          uint64_t v370 = (uint64_t) v32;
          TASSIGN(v369, v370);
          // pto: %138
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v371;
          // pto: %138
          ;
          uint64_t v372 = (uint64_t) v32;
          TASSIGN(v371, v372);
          // pto: %30
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v373 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %30
          ;
          uint64_t v374 = (uint64_t) v23;
          TASSIGN(v373, v374);
          pipe_barrier(PIPE_V);
          TADD(v373, v367, v371);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          // pto: %pooled_kv_inline4840__iter_v6_pview
          ;
          __gm__ float* v375 = PTOAS__GLOBAL_TENSOR_DATA(v55);
          // pto: %pooled_kv_inline4840__iter_v6_pview
          ;
          const int64_t v376 = 0;
          // pto: %pooled_kv_inline4840__iter_v6_pview
          ;
          const int64_t v377 = 128;
          // pto: %pooled_kv_inline4840__iter_v6_pview
          ;
          pto::Shape<1, 1, 1, 1, 64> v378 = pto::Shape<1, 1, 1, 1, 64>();
          // pto: %pooled_kv_inline4840__iter_v6_pview
          ;
          pto::Stride<128, 128, 128, 128, 1> v379 = pto::Stride<128, 128, 128, 128, 1>();
          // pto: %pooled_kv_inline4840__iter_v6_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v380 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v375 + (v376 + v134 * v377 + v262), v378, v379);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          TSTORE(v380, v373);
          set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
        };
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    };
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}