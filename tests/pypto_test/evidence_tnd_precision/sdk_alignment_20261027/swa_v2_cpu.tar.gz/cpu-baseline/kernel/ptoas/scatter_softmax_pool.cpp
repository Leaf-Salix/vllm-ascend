#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void scatter_softmax_pool(__gm__ float* v1, __gm__ int32_t* v2, __gm__ int64_t* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ float* v6, __gm__ float* v7, __gm__ float* v8, __gm__ float* v9, int64_t v10, int64_t v11, int64_t v12, int64_t v13, int64_t v14, int64_t v15, int64_t v16, int64_t v17, int32_t v18, int32_t v19) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v20 = -7;
  // pto: %c0_i64
  const int64_t v21 = 0;
  // pto: %c16384_i64
  const int64_t v22 = 16384;
  // pto: %c40960_i64
  const int64_t v23 = 40960;
  // pto: %c32768_i64
  const int64_t v24 = 32768;
  // pto: %c34816_i64
  const int64_t v25 = 34816;
  // pto: %c36864_i64
  const int64_t v26 = 36864;
  // pto: %c38912_i64
  const int64_t v27 = 38912;
  const int64_t v28 = 24576;
  const int64_t v29 = 45056;
  const int64_t v30 = 43008;
  const int64_t v31 = 8192;
  const int64_t v32 = 4096;
  const int64_t v33 = 2048;
  // pto: %c384_index
  const int64_t v34 = 384;
  // pto: %c512_index
  const int64_t v35 = 512;
  // pto: %c1_index
  const int64_t v36 = 1;
  // pto: %c1024_index
  const int64_t v37 = 1024;
  // pto: %c4_index
  const int64_t v38 = 4;
  // pto: %c0_index
  const int64_t v39 = 0;
  // pto: %cst_19
  const float v40 = 0.0f;
  // pto: %c1_i64
  const int64_t v41 = 1;
  // pto: %c4_i64
  const int64_t v42 = 4;
  // pto: %c8_index
  const int64_t v43 = 8;
  // pto: %cst_24
  const float v44 = -3.40282347E+38f;
  // pto: %c2_i64
  const int64_t v45 = 2;
  // pto: %c2048_index
  const int64_t v46 = 2048;
  // pto: %c2_index
  const int64_t v47 = 2;
  // pto: %pooled_kv_inline963__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %pooled_kv_inline963__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %pooled_kv_inline963__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %pooled_kv_inline963__ssa_v0_view
  int64_t v51 = v34 * v35;
  // pto: %pooled_kv_inline963__ssa_v0_view
  int64_t v52 = v50 * v51;
  // pto: %pooled_kv_inline963__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v53 = pto::Shape<1, 1, 1, -1, -1>(v48, v49, v50, v34, v35);
  // pto: %pooled_kv_inline963__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v54 = pto::Stride<-1, -1, -1, -1, -1>(v49 * v52, v52, v51, v35, v36);
  // pto: %pooled_kv_inline963__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v55 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v53, v54);
  // pto: %compress_state__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %compress_state__ssa_v0_view
  const int64_t v57 = 1;
  // pto: %compress_state__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %compress_state__ssa_v0_view
  int64_t v59 = (int64_t) v16;
  // pto: %compress_state__ssa_v0_view
  int64_t v60 = (int64_t) v17;
  // pto: %compress_state__ssa_v0_view
  int64_t v61 = v59 * v60;
  // pto: %compress_state__ssa_v0_view
  int64_t v62 = v58 * v61;
  // pto: %compress_state__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v63 = pto::Shape<1, 1, 1, -1, -1>(v56, v57, v58, v59, (int64_t) v17);
  // pto: %compress_state__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v64 = pto::Stride<-1, -1, -1, -1, -1>(v57 * v62, v62, v61, v60, v36);
  // pto: %compress_state__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v65 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v63, v64);
  // pto: %cmp4_kv_proj_pad_inline821_inline4684__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %cmp4_kv_proj_pad_inline821_inline4684__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %cmp4_kv_proj_pad_inline821_inline4684__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %cmp4_kv_proj_pad_inline821_inline4684__ssa_v0_view
  int64_t v69 = v34 * v37;
  // pto: %cmp4_kv_proj_pad_inline821_inline4684__ssa_v0_view
  int64_t v70 = v68 * v69;
  // pto: %cmp4_kv_proj_pad_inline821_inline4684__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v71 = pto::Shape<1, 1, 1, -1, -1>(v66, v67, v68, v34, v37);
  // pto: %cmp4_kv_proj_pad_inline821_inline4684__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v67 * v70, v70, v69, v37, v36);
  // pto: %cmp4_kv_proj_pad_inline821_inline4684__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v73 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v71, v72);
  // pto: %cmp4_score_proj_pad_inline824_inline4656__ssa_v0_view
  const int64_t v74 = 1;
  // pto: %cmp4_score_proj_pad_inline824_inline4656__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %cmp4_score_proj_pad_inline824_inline4656__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %cmp4_score_proj_pad_inline824_inline4656__ssa_v0_view
  int64_t v77 = v34 * v37;
  // pto: %cmp4_score_proj_pad_inline824_inline4656__ssa_v0_view
  int64_t v78 = v76 * v77;
  // pto: %cmp4_score_proj_pad_inline824_inline4656__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v79 = pto::Shape<1, 1, 1, -1, -1>(v74, v75, v76, v34, v37);
  // pto: %cmp4_score_proj_pad_inline824_inline4656__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v80 = pto::Stride<-1, -1, -1, -1, -1>(v75 * v78, v78, v77, v37, v36);
  // pto: %cmp4_score_proj_pad_inline824_inline4656__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v81 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v79, v80);
  // pto: %cmp_ape__ssa_v0_view
  const int64_t v82 = 1;
  // pto: %cmp_ape__ssa_v0_view
  const int64_t v83 = 1;
  // pto: %cmp_ape__ssa_v0_view
  const int64_t v84 = 1;
  // pto: %cmp_ape__ssa_v0_view
  int64_t v85 = v38 * v37;
  // pto: %cmp_ape__ssa_v0_view
  int64_t v86 = v84 * v85;
  // pto: %cmp_ape__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v87 = pto::Shape<1, 1, 1, -1, -1>(v82, v83, v84, v38, v37);
  // pto: %cmp_ape__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v88 = pto::Stride<-1, -1, -1, -1, -1>(v83 * v86, v86, v85, v37, v36);
  // pto: %cmp_ape__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v89 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v87, v88);
  // pto: %score_inline841_inline4700__phi_v4
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v90 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %score_inline841_inline4700__phi_v4
  uint64_t v91 = (uint64_t) v27;
  TASSIGN(v90, v91);
  // pto: %value_inline839_inline4691__phi_v3
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v92 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %value_inline839_inline4691__phi_v3
  uint64_t v93 = (uint64_t) v26;
  TASSIGN(v92, v93);
  // pto: %score_inline841_inline4700__phi_v3
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %score_inline841_inline4700__phi_v3
  uint64_t v95 = (uint64_t) v27;
  TASSIGN(v94, v95);
  // pto: %value_inline839_inline4691__phi_v2
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v96 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %value_inline839_inline4691__phi_v2
  uint64_t v97 = (uint64_t) v26;
  TASSIGN(v96, v97);
  // pto: %score_inline841_inline4700__phi_v7
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v98 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %score_inline841_inline4700__phi_v7
  uint64_t v99 = (uint64_t) v24;
  TASSIGN(v98, v99);
  // pto: %value_inline839_inline4691__phi_v6
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v100 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %value_inline839_inline4691__phi_v6
  uint64_t v101 = (uint64_t) v23;
  TASSIGN(v100, v101);
  // pto: %score_inline841_inline4700__phi_v6
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %score_inline841_inline4700__phi_v6
  uint64_t v103 = (uint64_t) v24;
  TASSIGN(v102, v103);
  // pto: %value_inline839_inline4691__phi_v5
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v104 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %value_inline839_inline4691__phi_v5
  uint64_t v105 = (uint64_t) v23;
  TASSIGN(v104, v105);
  // pto: %pool_worker_inline833_inline4664__ssa_v0
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v106 = (int64_t) v18; v106 < v10; v106 += v11) {
    // pto: %3
    ;
    int32_t v107 = (v2)[v106];
    // pto: %4
    ;
    int64_t v108 = (int64_t) v107;
    // pto: %6, %5
    ;
    int32_t v109 = (v2)[(int64_t) ((uint64_t) v106 + (uint64_t) v36)];
    // pto: %7
    ;
    int64_t v110 = (int64_t) v109;
    // pto: %9
    ;
    // pto: %first_pos_b_inline811_inline4692__phi_v2
    ;
    int64_t v111;
    if (v108 < v110) {
      // pto: %10
      ;
      int64_t v112 = (v3)[v108];
      v111 = v112;
    } else {
      v111 = v39;
    };
    // pto: %c_len_inline809_inline4694__tile
    ;
    int32_t v113 = (v4)[v106];
    for (int64_t v114 = v108; v114 < v110; v114 += v36) {
      // pto: %token_pos_inline816_inline4690__tile
      ;
      int64_t v115 = (v3)[v114];
      // pto: %t__tile
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
      // pto: %t__tile
      ;
      uint64_t v117 = (uint64_t) v21;
      TASSIGN(v116, v117);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      TEXPANDS(v116, v40);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      // pto: %17
      ;
      int64_t v118 = v114 < v39 ? v39 : v114;
      // pto: %pooled_kv_inline963__iter_v3_pview
      ;
      __gm__ float* v119 = PTOAS__GLOBAL_TENSOR_DATA(v55);
      // pto: %pooled_kv_inline963__iter_v3_pview
      ;
      const int64_t v120 = 0;
      // pto: %pooled_kv_inline963__iter_v3_pview
      ;
      const int64_t v121 = 512;
      // pto: %pooled_kv_inline963__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v122 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %pooled_kv_inline963__iter_v3_pview
      ;
      pto::Stride<512, 512, 512, 512, 1> v123 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %pooled_kv_inline963__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v124 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v119 + (v120 + v118 * v121), v122, v123);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v124, v116);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      // pto: %20, %21
      ;
      int64_t v125 = (int64_t) ((uint64_t) v115 + (uint64_t) v41) % v42;
      // pto: %22, %23, %24
      ;
      int64_t v126 = v125 < v21 ? (int64_t) ((uint64_t) v125 + (uint64_t) v42) : v125;
      // pto: %18, %19, %25, %26
      ;
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      if ((int64_t) v113 > v39 & v126 == v21) {
        // pto: %window_values_inline818_inline4701__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v35);
        // pto: %window_values_inline818_inline4701__ssa_v0
        ;
        uint64_t v128 = (uint64_t) v21;
        TASSIGN(v127, v128);
        TEXPANDS(v127, v40);
        // pto: %window_scores_inline827_inline4707__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v35);
        // pto: %window_scores_inline827_inline4707__ssa_v0
        ;
        uint64_t v130 = (uint64_t) v22;
        TASSIGN(v129, v130);
        TEXPANDS(v129, v44);
        for (int64_t v131 = v39; v131 < v43; v131 += v36) {
          // pto: %30
          ;
          int64_t v132 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v115 + (uint64_t) v20) + (uint64_t) v131);
          // pto: %value_inline839_inline4691__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
          // pto: %value_inline839_inline4691__ssa_v0
          ;
          uint64_t v134 = (uint64_t) v23;
          TASSIGN(v133, v134);
          pipe_barrier(PIPE_V);
          TEXPANDS(v133, v40);
          // pto: %score_inline841_inline4700__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v135 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
          // pto: %score_inline841_inline4700__ssa_v0
          ;
          uint64_t v136 = (uint64_t) v24;
          TASSIGN(v135, v136);
          TEXPANDS(v135, v44);
          // pto: %31, %state_half_inline842_inline4703__phi_v2
          ;
          int64_t v137 = v131 >= v38 ? v35 : v39;
          // pto: %35
          ;
          bool v138 = v132 < v111;
          // pto: %33, %36
          ;
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
          if (v132 >= v39 & v138) {
            // pto: %score_inline841_inline4700__ssa_v1
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v139 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
            // pto: %score_inline841_inline4700__ssa_v1
            ;
            uint64_t v140 = (uint64_t) v25;
            TASSIGN(v139, v140);
            TEXPANDS(v139, v40);
            // pto: %flat_offset_mul, %flat_offset, %38, %37
            ;
            int32_t v141 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v15) + (uint64_t) (v132 / v45))];
            // pto: %40
            ;
            int64_t v142 = (int64_t) v141;
            // pto: %41
            ;
            if (v142 >= v39) {
              // pto: %42
              ;
              int64_t v143 = v132 % v45;
              // pto: %43, %44, %45
              ;
              int64_t v144 = v143 < v21 ? (int64_t) ((uint64_t) v143 + (uint64_t) v45) : v143;
              // pto: %47, %48
              ;
              int64_t v145 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v144 * (uint64_t) v46) + (uint64_t) v137);
              // pto: %value_inline839_inline4691__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v146 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %value_inline839_inline4691__ssa_v1
              ;
              uint64_t v147 = (uint64_t) v26;
              TASSIGN(v146, v147);
              // pto: %49
              ;
              int64_t v148 = v142 < v39 ? v39 : v142;
              // pto: %50
              ;
              int64_t v149 = v145 < v39 ? v39 : v145;
              // pto: %compress_state__ssa_v0_pview
              ;
              int64_t v150 = (int64_t) v17;
              // pto: %compress_state__ssa_v0_pview
              ;
              const int64_t v151 = 0;
              // pto: %compress_state__ssa_v0_pview
              ;
              __gm__ float* v152 = PTOAS__GLOBAL_TENSOR_DATA(v65);
              // pto: %compress_state__ssa_v0_pview
              ;
              const int64_t v153 = 1;
              // pto: %compress_state__ssa_v0_pview
              ;
              const int64_t v154 = 1;
              // pto: %compress_state__ssa_v0_pview
              ;
              const int64_t v155 = 1;
              // pto: %compress_state__ssa_v0_pview
              ;
              int64_t v156 = v36 * v150;
              // pto: %compress_state__ssa_v0_pview
              ;
              int64_t v157 = v155 * v156;
              // pto: %compress_state__ssa_v0_pview
              ;
              pto::Shape<1, 1, 1, 1, 512> v158 = pto::Shape<1, 1, 1, 1, 512>(v153, v154, v155, v36, v35);
              // pto: %compress_state__ssa_v0_pview
              ;
              pto::Stride<-1, -1, -1, -1, -1> v159 = pto::Stride<-1, -1, -1, -1, -1>(v154 * v157, v157, v156, v150, v36);
              // pto: %compress_state__ssa_v0_pview
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v160 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v152 + (v151 + v148 * v150 + v149 * v36), v158, v159);
              TLOAD(v146, v160);
              // pto: %score_inline841_inline4700__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v161 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %score_inline841_inline4700__ssa_v2
              ;
              uint64_t v162 = (uint64_t) v27;
              TASSIGN(v161, v162);
              // pto: %52
              ;
              int64_t v163 = (int64_t) ((uint64_t) v145 + (uint64_t) v37);
              // pto: %53
              ;
              int64_t v164 = v163 < v39 ? v39 : v163;
              // pto: %54
              ;
              int64_t v165 = (int64_t) v17;
              // pto: %54
              ;
              const int64_t v166 = 0;
              // pto: %54
              ;
              __gm__ float* v167 = PTOAS__GLOBAL_TENSOR_DATA(v65);
              // pto: %54
              ;
              const int64_t v168 = 1;
              // pto: %54
              ;
              const int64_t v169 = 1;
              // pto: %54
              ;
              const int64_t v170 = 1;
              // pto: %54
              ;
              int64_t v171 = v36 * v165;
              // pto: %54
              ;
              int64_t v172 = v170 * v171;
              // pto: %54
              ;
              pto::Shape<1, 1, 1, 1, 512> v173 = pto::Shape<1, 1, 1, 1, 512>(v168, v169, v170, v36, v35);
              // pto: %54
              ;
              pto::Stride<-1, -1, -1, -1, -1> v174 = pto::Stride<-1, -1, -1, -1, -1>(v169 * v172, v172, v171, v165, v36);
              // pto: %54
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v175 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v167 + (v166 + v148 * v165 + v164 * v36), v173, v174);
              TLOAD(v161, v175);
            } else {
              // pto: %score_inline841_inline4700__ssa_v1_mv
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v176 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %score_inline841_inline4700__ssa_v1_mv
              ;
              uint64_t v177 = (uint64_t) v27;
              TASSIGN(v176, v177);
              pipe_barrier(PIPE_V);
              TMOV(v176, v139);
              // pto: %value_inline839_inline4691__ssa_v0_mv
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v178 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %value_inline839_inline4691__ssa_v0_mv
              ;
              uint64_t v179 = (uint64_t) v26;
              TASSIGN(v178, v179);
              TMOV(v178, v133);
            };
          } else {
            // pto: %score_inline841_inline4700__ssa_v0_mv
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v180 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
            // pto: %score_inline841_inline4700__ssa_v0_mv
            ;
            uint64_t v181 = (uint64_t) v27;
            TASSIGN(v180, v181);
            pipe_barrier(PIPE_V);
            TMOV(v180, v135);
            // pto: %0
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v182 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
            // pto: %0
            ;
            uint64_t v183 = (uint64_t) v26;
            TASSIGN(v182, v183);
            TMOV(v182, v133);
          };
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
          // pto: %56
          ;
          bool v184 = v111 <= v132;
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
          if (v184) {
            // pto: %57
            ;
            if (v132 <= v115) {
              // pto: %60
              ;
              uint64_t v185 = (uint64_t) v111;
              // pto: %59, %60
              ;
              int64_t v186 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v108 + (uint64_t) v132) - v185);
              // pto: %61
              ;
              int64_t v187 = v132 % v42;
              // pto: %62, %63, %64
              ;
              int64_t v188 = v187 < v21 ? (int64_t) ((uint64_t) v187 + (uint64_t) v42) : v187;
              // pto: %value_inline839_inline4691__ssa_v4
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v189 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %value_inline839_inline4691__ssa_v4
              ;
              uint64_t v190 = (uint64_t) v23;
              TASSIGN(v189, v190);
              // pto: %66
              ;
              int64_t v191 = v186 < v39 ? v39 : v186;
              // pto: %67
              ;
              int64_t v192 = v137 < v39 ? v39 : v137;
              // pto: %cmp4_kv_proj_pad_inline821_inline4684__ssa_v0_pview
              ;
              __gm__ float* v193 = PTOAS__GLOBAL_TENSOR_DATA(v73);
              // pto: %cmp4_kv_proj_pad_inline821_inline4684__ssa_v0_pview
              ;
              const int64_t v194 = 0;
              // pto: %cmp4_kv_proj_pad_inline821_inline4684__ssa_v0_pview
              ;
              const int64_t v195 = 1024;
              // pto: %cmp4_kv_proj_pad_inline821_inline4684__ssa_v0_pview
              ;
              pto::Shape<1, 1, 1, 1, 512> v196 = pto::Shape<1, 1, 1, 1, 512>();
              // pto: %cmp4_kv_proj_pad_inline821_inline4684__ssa_v0_pview
              ;
              pto::Stride<1024, 1024, 1024, 1024, 1> v197 = pto::Stride<1024, 1024, 1024, 1024, 1>();
              // pto: %cmp4_kv_proj_pad_inline821_inline4684__ssa_v0_pview
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v198 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v193 + (v194 + v191 * v195 + v192), v196, v197);
              TLOAD(v189, v198);
              // pto: %t__tmp_v147
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v199 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %t__tmp_v147
              ;
              uint64_t v200 = (uint64_t) v24;
              TASSIGN(v199, v200);
              // pto: %cmp4_score_proj_pad_inline824_inline4656__ssa_v0_pview
              ;
              __gm__ float* v201 = PTOAS__GLOBAL_TENSOR_DATA(v81);
              // pto: %cmp4_score_proj_pad_inline824_inline4656__ssa_v0_pview
              ;
              const int64_t v202 = 0;
              // pto: %cmp4_score_proj_pad_inline824_inline4656__ssa_v0_pview
              ;
              const int64_t v203 = 1024;
              // pto: %cmp4_score_proj_pad_inline824_inline4656__ssa_v0_pview
              ;
              pto::Shape<1, 1, 1, 1, 512> v204 = pto::Shape<1, 1, 1, 1, 512>();
              // pto: %cmp4_score_proj_pad_inline824_inline4656__ssa_v0_pview
              ;
              pto::Stride<1024, 1024, 1024, 1024, 1> v205 = pto::Stride<1024, 1024, 1024, 1024, 1>();
              // pto: %cmp4_score_proj_pad_inline824_inline4656__ssa_v0_pview
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v206 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v201 + (v202 + v191 * v203 + v192), v204, v205);
              TLOAD(v199, v206);
              // pto: %t__tmp_v148
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %t__tmp_v148
              ;
              uint64_t v208 = (uint64_t) v25;
              TASSIGN(v207, v208);
              // pto: %70
              ;
              int64_t v209 = v188 < v39 ? v39 : v188;
              // pto: %cmp_ape__ssa_v0_pview
              ;
              __gm__ float* v210 = PTOAS__GLOBAL_TENSOR_DATA(v89);
              // pto: %cmp_ape__ssa_v0_pview
              ;
              const int64_t v211 = 0;
              // pto: %cmp_ape__ssa_v0_pview
              ;
              const int64_t v212 = 1024;
              // pto: %cmp_ape__ssa_v0_pview
              ;
              pto::Shape<1, 1, 1, 1, 512> v213 = pto::Shape<1, 1, 1, 1, 512>();
              // pto: %cmp_ape__ssa_v0_pview
              ;
              pto::Stride<1024, 1024, 1024, 1024, 1> v214 = pto::Stride<1024, 1024, 1024, 1024, 1>();
              // pto: %cmp_ape__ssa_v0_pview
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v215 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v210 + (v211 + v209 * v212 + v192), v213, v214);
              TLOAD(v207, v215);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
              // pto: %score_inline841_inline4700__ssa_v5
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v216 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %score_inline841_inline4700__ssa_v5
              ;
              uint64_t v217 = (uint64_t) v24;
              TASSIGN(v216, v217);
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
              TADD(v216, v199, v207);
            } else {
              // pto: %score_inline841_inline4700__phi_v4_mv
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %score_inline841_inline4700__phi_v4_mv
              ;
              uint64_t v219 = (uint64_t) v24;
              TASSIGN(v218, v219);
              pipe_barrier(PIPE_V);
              TMOV(v218, v90);
              // pto: %value_inline839_inline4691__phi_v3_mv
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %value_inline839_inline4691__phi_v3_mv
              ;
              uint64_t v221 = (uint64_t) v23;
              TASSIGN(v220, v221);
              TMOV(v220, v92);
            };
          } else {
            // pto: %1
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v222 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
            // pto: %1
            ;
            uint64_t v223 = (uint64_t) v24;
            TASSIGN(v222, v223);
            pipe_barrier(PIPE_V);
            TMOV(v222, v90);
            // pto: %2
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v224 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
            // pto: %2
            ;
            uint64_t v225 = (uint64_t) v23;
            TASSIGN(v224, v225);
            TMOV(v224, v92);
          };
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
          // pto: %72
          ;
          int64_t v226 = v131 % v38;
          // pto: %73, %74, %75
          ;
          int64_t v227 = v226 < v39 ? (int64_t) ((uint64_t) v226 + (uint64_t) v38) : v226;
          // pto: %76, %78, %77, %assemble_view
          ;
          int64_t v228 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v227 * (uint64_t) v47) + (uint64_t) (v131 / v38)) * (uint64_t) v33);
          // pto: %assemble_view
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v229;
          // pto: %assemble_view
          ;
          uint64_t v230 = (uint64_t) v228;
          TASSIGN(v229, v230);
          pipe_barrier(PIPE_V);
          TMOV(v229, v100);
          // pto: %79
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v231;
          // pto: %79
          ;
          uint64_t v232 = (uint64_t) ((int64_t) (uint64_t) v228 + (uint64_t) v22);
          TASSIGN(v231, v232);
          TMOV(v231, v98);
        };
        // pto: %t__tmp_v149
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v233 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %t__tmp_v149
        ;
        uint64_t v234 = (uint64_t) v22;
        TASSIGN(v233, v234);
        // pto: %slice_view
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, 4, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v235;
        // pto: %slice_view
        ;
        uint64_t v236 = (uint64_t) v22;
        TASSIGN(v235, v236);
        // pto: %t__tmp_v150
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v237 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %t__tmp_v150
        ;
        uint64_t v238 = (uint64_t) v28;
        TASSIGN(v237, v238);
        // pto: %80
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, 4, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v239;
        // pto: %80
        ;
        uint64_t v240 = (uint64_t) v28;
        TASSIGN(v239, v240);
        // pto: %max4_inline806_inline4670__ssa_v0
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v241 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %max4_inline806_inline4670__ssa_v0
        ;
        uint64_t v242 = (uint64_t) v23;
        TASSIGN(v241, v242);
        pipe_barrier(PIPE_V);
        TMAX(v241, v235, v239);
        // pto: %t__tmp_v151
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v243 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %t__tmp_v151
        ;
        uint64_t v244 = (uint64_t) v23;
        TASSIGN(v243, v244);
        // pto: %81
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, 2, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v245;
        // pto: %81
        ;
        uint64_t v246 = (uint64_t) v23;
        TASSIGN(v245, v246);
        // pto: %t__tmp_v152
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v247 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %t__tmp_v152
        ;
        uint64_t v248 = (uint64_t) v29;
        TASSIGN(v247, v248);
        // pto: %82
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, 2, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v249;
        // pto: %82
        ;
        uint64_t v250 = (uint64_t) v29;
        TASSIGN(v249, v250);
        // pto: %max2_inline804_inline4679__ssa_v0
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v251 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %max2_inline804_inline4679__ssa_v0
        ;
        uint64_t v252 = (uint64_t) v23;
        TASSIGN(v251, v252);
        pipe_barrier(PIPE_V);
        TMAX(v251, v245, v249);
        // pto: %t__tmp_v153
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v253 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %t__tmp_v153
        ;
        uint64_t v254 = (uint64_t) v23;
        TASSIGN(v253, v254);
        // pto: %83
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v255;
        // pto: %83
        ;
        uint64_t v256 = (uint64_t) v23;
        TASSIGN(v255, v256);
        // pto: %t__tmp_v154
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v257 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %t__tmp_v154
        ;
        uint64_t v258 = (uint64_t) v30;
        TASSIGN(v257, v258);
        // pto: %84
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v259;
        // pto: %84
        ;
        uint64_t v260 = (uint64_t) v30;
        TASSIGN(v259, v260);
        // pto: %maximum_inline803_inline4667__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v261 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %maximum_inline803_inline4667__ssa_v0
        ;
        uint64_t v262 = (uint64_t) v23;
        TASSIGN(v261, v262);
        pipe_barrier(PIPE_V);
        TMAX(v261, v255, v259);
        // pto: %t__tmp_v155
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v263 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v35);
        // pto: %t__tmp_v155
        ;
        uint64_t v264 = (uint64_t) v22;
        TASSIGN(v263, v264);
        pipe_barrier(PIPE_V);
        TCOLEXPANDSUB(v263, v129, v261);
        // pto: %probability_inline814_inline4675__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v265 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v35);
        // pto: %probability_inline814_inline4675__ssa_v0
        ;
        uint64_t v266 = (uint64_t) v22;
        TASSIGN(v265, v266);
        pipe_barrier(PIPE_V);
        TEXP(v265, v263);
        // pto: %t__tmp_v156
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v267 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %t__tmp_v156
        ;
        uint64_t v268 = (uint64_t) v22;
        TASSIGN(v267, v268);
        // pto: %85
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, 4, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v269;
        // pto: %85
        ;
        uint64_t v270 = (uint64_t) v22;
        TASSIGN(v269, v270);
        // pto: %t__tmp_v157
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v271 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %t__tmp_v157
        ;
        uint64_t v272 = (uint64_t) v28;
        TASSIGN(v271, v272);
        // pto: %86
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, 4, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v273;
        // pto: %86
        ;
        uint64_t v274 = (uint64_t) v28;
        TASSIGN(v273, v274);
        // pto: %sum4_inline801_inline4683__ssa_v0
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v275 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %sum4_inline801_inline4683__ssa_v0
        ;
        uint64_t v276 = (uint64_t) v23;
        TASSIGN(v275, v276);
        pipe_barrier(PIPE_V);
        TADD(v275, v269, v273);
        // pto: %t__tmp_v158
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v277 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %t__tmp_v158
        ;
        uint64_t v278 = (uint64_t) v23;
        TASSIGN(v277, v278);
        // pto: %87
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, 2, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v279;
        // pto: %87
        ;
        uint64_t v280 = (uint64_t) v23;
        TASSIGN(v279, v280);
        // pto: %t__tmp_v159
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v281 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %t__tmp_v159
        ;
        uint64_t v282 = (uint64_t) v29;
        TASSIGN(v281, v282);
        // pto: %88
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, 2, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v283;
        // pto: %88
        ;
        uint64_t v284 = (uint64_t) v29;
        TASSIGN(v283, v284);
        // pto: %sum2_inline825_inline4651__ssa_v0
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v285 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %sum2_inline825_inline4651__ssa_v0
        ;
        uint64_t v286 = (uint64_t) v23;
        TASSIGN(v285, v286);
        pipe_barrier(PIPE_V);
        TADD(v285, v279, v283);
        // pto: %t__tmp_v160
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v287 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %t__tmp_v160
        ;
        uint64_t v288 = (uint64_t) v23;
        TASSIGN(v287, v288);
        // pto: %89
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v289;
        // pto: %89
        ;
        uint64_t v290 = (uint64_t) v23;
        TASSIGN(v289, v290);
        // pto: %t__tmp_v161
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v291 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %t__tmp_v161
        ;
        uint64_t v292 = (uint64_t) v30;
        TASSIGN(v291, v292);
        // pto: %90
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v293;
        // pto: %90
        ;
        uint64_t v294 = (uint64_t) v30;
        TASSIGN(v293, v294);
        // pto: %total_inline832_inline4657__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v295 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %total_inline832_inline4657__ssa_v0
        ;
        uint64_t v296 = (uint64_t) v23;
        TASSIGN(v295, v296);
        pipe_barrier(PIPE_V);
        TADD(v295, v289, v293);
        // pto: %probability_v1_inline802_inline4705__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v297 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v35);
        // pto: %probability_v1_inline802_inline4705__ssa_v0
        ;
        uint64_t v298 = (uint64_t) v22;
        TASSIGN(v297, v298);
        pipe_barrier(PIPE_V);
        TCOLEXPANDDIV(v297, v265, v295);
        // pto: %weighted_inline810_inline4650__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v299 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v35);
        // pto: %weighted_inline810_inline4650__ssa_v0
        ;
        uint64_t v300 = (uint64_t) v21;
        TASSIGN(v299, v300);
        pipe_barrier(PIPE_V);
        TMUL(v299, v127, v297);
        // pto: %t__tmp_v162
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v301 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %t__tmp_v162
        ;
        uint64_t v302 = (uint64_t) v21;
        TASSIGN(v301, v302);
        // pto: %91
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, 4, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v303;
        // pto: %91
        ;
        uint64_t v304 = (uint64_t) v21;
        TASSIGN(v303, v304);
        // pto: %t__tmp_v163
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v305 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %t__tmp_v163
        ;
        uint64_t v306 = (uint64_t) v31;
        TASSIGN(v305, v306);
        // pto: %92
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, 4, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v307;
        // pto: %92
        ;
        uint64_t v308 = (uint64_t) v31;
        TASSIGN(v307, v308);
        // pto: %weighted4_inline805_inline4661__ssa_v0
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %weighted4_inline805_inline4661__ssa_v0
        ;
        uint64_t v310 = (uint64_t) v21;
        TASSIGN(v309, v310);
        pipe_barrier(PIPE_V);
        TADD(v309, v303, v307);
        // pto: %t__tmp_v164
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v311 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %t__tmp_v164
        ;
        uint64_t v312 = (uint64_t) v21;
        TASSIGN(v311, v312);
        // pto: %93
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, 2, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v313;
        // pto: %93
        ;
        uint64_t v314 = (uint64_t) v21;
        TASSIGN(v313, v314);
        // pto: %t__tmp_v165
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %t__tmp_v165
        ;
        uint64_t v316 = (uint64_t) v32;
        TASSIGN(v315, v316);
        // pto: %94
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, 2, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v317;
        // pto: %94
        ;
        uint64_t v318 = (uint64_t) v32;
        TASSIGN(v317, v318);
        // pto: %weighted2_inline835_inline4649__ssa_v0
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v319 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %weighted2_inline835_inline4649__ssa_v0
        ;
        uint64_t v320 = (uint64_t) v21;
        TASSIGN(v319, v320);
        pipe_barrier(PIPE_V);
        TADD(v319, v313, v317);
        // pto: %t__tmp_v166
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v321 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %t__tmp_v166
        ;
        uint64_t v322 = (uint64_t) v21;
        TASSIGN(v321, v322);
        // pto: %95
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v323;
        // pto: %95
        ;
        uint64_t v324 = (uint64_t) v21;
        TASSIGN(v323, v324);
        // pto: %t__tmp_v167
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v325 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %t__tmp_v167
        ;
        uint64_t v326 = (uint64_t) v33;
        TASSIGN(v325, v326);
        // pto: %96
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v327;
        // pto: %96
        ;
        uint64_t v328 = (uint64_t) v33;
        TASSIGN(v327, v328);
        // pto: %pooled_row_inline822_inline4648__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v329 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %pooled_row_inline822_inline4648__ssa_v0
        ;
        uint64_t v330 = (uint64_t) v21;
        TASSIGN(v329, v330);
        pipe_barrier(PIPE_V);
        TADD(v329, v323, v327);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v124, v329);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    };
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}