#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_b64(__gm__ int8_t* v1, __gm__ int8_t* v2, __gm__ int32_t* v3, int64_t v4, int64_t v5, int64_t v6, int32_t v7, int32_t v8) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v9 = 0;
  // pto: %c32768_i64
  const int64_t v10 = 32768;
  // pto: %c16384_i64
  const int64_t v11 = 16384;
  // pto: %c8192_index
  const int64_t v12 = 8192;
  // pto: %c1_index
  const int64_t v13 = 1;
  // pto: %c128_index
  const int64_t v14 = 128;
  // pto: %c512_index
  const int64_t v15 = 512;
  // pto: %c16_index
  const int64_t v16 = 16;
  // pto: %c32_index
  const int64_t v17 = 32;
  // pto: %c33554432_index
  const int64_t v18 = 33554432;
  // pto: %c262144_index
  const int64_t v19 = 262144;
  // pto: %c4096_index
  const int64_t v20 = 4096;
  // pto: %c64_index
  const int64_t v21 = 64;
  // pto: %c0_index
  const int64_t v22 = 0;
  // pto: %c256_index
  const int64_t v23 = 256;
  // pto: %c63_index
  const int64_t v24 = 63;
  // pto: %quantized_o__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %quantized_o__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %quantized_o__ssa_v0_view
  const int64_t v27 = 1;
  // pto: %quantized_o__ssa_v0_view
  int64_t v28 = (int64_t) v5;
  // pto: %quantized_o__ssa_v0_view
  int64_t v29 = v28 * v12;
  // pto: %quantized_o__ssa_v0_view
  int64_t v30 = v27 * v29;
  // pto: %quantized_o__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v31 = pto::Shape<1, 1, 1, -1, -1>(v25, v26, v27, v28, v12);
  // pto: %quantized_o__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v32 = pto::Stride<-1, -1, -1, -1, -1>(v26 * v30, v30, v29, v12, v13);
  // pto: %quantized_o__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v33 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v31, v32);
  // pto: %wo_b__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v34 = pto::Shape<-1, -1, -1, -1, -1>(v13, v14, v15, v16, v17);
  // pto: %wo_b__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v35 = pto::Stride<-1, -1, -1, -1, -1>(v18, v19, v15, v17, v13);
  // pto: %wo_b__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v36 = GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v2, v34, v35);
  // pto: %32
  int64_t v37 = (int64_t) ((uint64_t) v6 + (uint64_t) v24);
  // pto: %integer_accum_inline1125__ssa_v0_view
  const int64_t v38 = 1;
  // pto: %integer_accum_inline1125__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %integer_accum_inline1125__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %integer_accum_inline1125__ssa_v0_view
  int64_t v41 = v37 * v20;
  // pto: %integer_accum_inline1125__ssa_v0_view
  int64_t v42 = v40 * v41;
  // pto: %integer_accum_inline1125__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v43 = pto::Shape<1, 1, 1, -1, -1>(v38, v39, v40, v37, v20);
  // pto: %integer_accum_inline1125__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v44 = pto::Stride<-1, -1, -1, -1, -1>(v39 * v42, v42, v41, v20, v13);
  // pto: %integer_accum_inline1125__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v45 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v43, v44);
  // pto: %wide_block_inline1031__ssa_v0
  int64_t v46 = (int64_t) v7;
  // pto: %9, %10
  int64_t v47 = (int64_t) ((uint64_t) (v46 / v17) * (uint64_t) v21);
  // pto: %11
  int64_t v48 = v46 % v17;
  // pto: %12, %13, %14
  int64_t v49 = v48 < v22 ? (int64_t) ((uint64_t) v48 + (uint64_t) v17) : v48;
  // pto: %15
  int64_t v50 = (int64_t) ((uint64_t) v49 * (uint64_t) v14);
  // pto: %16
  int64_t v51 = (int64_t) ((uint64_t) v6 - (uint64_t) v47);
  // pto: %17
  int64_t v52 = v51 < v21 ? v51 : v21;
  // pto: %wide_first_input_inline1132__tile
  Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v53 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v52, v15);
  // pto: %wide_first_input_inline1132__tile
  uint64_t v54 = (uint64_t) v9;
  TASSIGN(v53, v54);
  // pto: %18
  int64_t v55 = v47 < v22 ? v22 : v47;
  // pto: %quantized_o__ssa_v0_pview
  const int64_t v56 = 0;
  // pto: %quantized_o__ssa_v0_pview
  __gm__ int8_t* v57 = PTOAS__GLOBAL_TENSOR_DATA(v33);
  // pto: %quantized_o__ssa_v0_pview
  const int64_t v58 = 1;
  // pto: %quantized_o__ssa_v0_pview
  const int64_t v59 = 1;
  // pto: %quantized_o__ssa_v0_pview
  const int64_t v60 = 1;
  // pto: %quantized_o__ssa_v0_pview
  int64_t v61 = v52 * v12;
  // pto: %quantized_o__ssa_v0_pview
  int64_t v62 = v60 * v61;
  // pto: %quantized_o__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 512> v63 = pto::Shape<1, 1, 1, -1, 512>(v58, v59, v60, v52, v15);
  // pto: %quantized_o__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v64 = pto::Stride<-1, -1, -1, -1, -1>(v59 * v62, v62, v61, v12, v13);
  // pto: %quantized_o__ssa_v0_pview
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v65 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v57 + (v56 + v55 * v12 + v22 * v13), v63, v64);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  TLOAD(v53, v65);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
  // pto: %wide_first_weight_inline1135__tile
  Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v66 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v14);
  // pto: %wide_first_weight_inline1135__tile
  uint64_t v67 = (uint64_t) v10;
  TASSIGN(v66, v67);
  // pto: %19
  int64_t v68 = v50 / v17;
  // pto: %20
  int64_t v69 = v68 < v22 ? v22 : v68;
  // pto: %wo_b__ssa_v0_pview
  __gm__ int8_t* v70 = PTOAS__GLOBAL_TENSOR_DATA(v36);
  // pto: %wo_b__ssa_v0_pview
  const int64_t v71 = 0;
  // pto: %wo_b__ssa_v0_pview
  const int64_t v72 = 262144;
  // pto: %wo_b__ssa_v0_pview
  pto::Shape<1, 4, 32, 16, 32> v73 = pto::Shape<1, 4, 32, 16, 32>();
  // pto: %wo_b__ssa_v0_pview
  pto::Stride<33554432, 262144, 512, 32, 1> v74 = pto::Stride<33554432, 262144, 512, 32, 1>();
  // pto: %wo_b__ssa_v0_pview
  GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v75 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v70 + (v71 + v69 * v72), v73, v74);
  TLOAD(v66, v75);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
  // pto: %wide_b_acc_inline1021__tile_l0_init_storage
  Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v76 = Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v21, v14);
  // pto: %wide_b_acc_inline1021__tile_l0_init_storage
  uint64_t v77 = (uint64_t) v9;
  TASSIGN(v76, v77);
  v76.SetValidShape(v52, v14);
  // pto: %wide_b_acc_inline1021__tile_l0_a
  Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v78 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v52, v23);
  // pto: %wide_b_acc_inline1021__tile_l0_a
  uint64_t v79 = (uint64_t) v9;
  TASSIGN(v78, v79);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
  uint16_t v80 = static_cast<uint16_t>(v22);
  uint16_t v81 = static_cast<uint16_t>(v22);
  TEXTRACT(v78, v53, v80, v81);
  // pto: %wide_b_acc_inline1021__tile_l0_b
  Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v82 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v14);
  // pto: %wide_b_acc_inline1021__tile_l0_b
  uint64_t v83 = (uint64_t) v9;
  TASSIGN(v82, v83);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
  uint16_t v84 = static_cast<uint16_t>(v22);
  uint16_t v85 = static_cast<uint16_t>(v22);
  TEXTRACT(v82, v66, v84, v85);
  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
  // pto: %0
  Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v86 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v52, v23);
  // pto: %0
  uint64_t v87 = (uint64_t) v11;
  TASSIGN(v86, v87);
  uint16_t v88 = static_cast<uint16_t>(v22);
  uint16_t v89 = static_cast<uint16_t>(v23);
  TEXTRACT(v86, v53, v88, v89);
  // pto: %1
  Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v90 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v14);
  // pto: %1
  uint64_t v91 = (uint64_t) v10;
  TASSIGN(v90, v91);
  uint16_t v92 = static_cast<uint16_t>(v23);
  uint16_t v93 = static_cast<uint16_t>(v22);
  TEXTRACT(v90, v66, v92, v93);
  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
  TMATMUL(v76, v78, v82);
  pipe_barrier(PIPE_M);
  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
  TMATMUL_ACC(v76, v76, v86, v90);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  for (int64_t v94 = v13; v94 < v16; v94 += v13) {
    // pto: %21
    ;
    int64_t v95 = (int64_t) ((uint64_t) v94 * (uint64_t) v15);
    // pto: %wide_b_input_inline1138__tile
    ;
    Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v96 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v52, v15);
    // pto: %wide_b_input_inline1138__tile
    ;
    uint64_t v97 = (uint64_t) v9;
    TASSIGN(v96, v97);
    // pto: %23
    ;
    int64_t v98 = v95 < v22 ? v22 : v95;
    // pto: %24
    ;
    const int64_t v99 = 0;
    // pto: %24
    ;
    __gm__ int8_t* v100 = PTOAS__GLOBAL_TENSOR_DATA(v33);
    // pto: %24
    ;
    const int64_t v101 = 1;
    // pto: %24
    ;
    const int64_t v102 = 1;
    // pto: %24
    ;
    const int64_t v103 = 1;
    // pto: %24
    ;
    int64_t v104 = v52 * v12;
    // pto: %24
    ;
    int64_t v105 = v103 * v104;
    // pto: %24
    ;
    pto::Shape<1, 1, 1, -1, 512> v106 = pto::Shape<1, 1, 1, -1, 512>(v101, v102, v103, v52, v15);
    // pto: %24
    ;
    pto::Stride<-1, -1, -1, -1, -1> v107 = pto::Stride<-1, -1, -1, -1, -1>(v102 * v105, v105, v104, v12, v13);
    // pto: %24
    ;
    GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v108 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v100 + (v99 + v55 * v12 + v98 * v13), v106, v107);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    TLOAD(v96, v108);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    // pto: %wide_b_weight_inline1119__tile
    ;
    Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v109 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v14);
    // pto: %wide_b_weight_inline1119__tile
    ;
    uint64_t v110 = (uint64_t) v10;
    TASSIGN(v109, v110);
    // pto: %27
    ;
    int64_t v111 = v95 / v16;
    // pto: %28
    ;
    int64_t v112 = v111 < v22 ? v22 : v111;
    // pto: %29
    ;
    __gm__ int8_t* v113 = PTOAS__GLOBAL_TENSOR_DATA(v36);
    // pto: %29
    ;
    const int64_t v114 = 0;
    // pto: %29
    ;
    const int64_t v115 = 262144;
    // pto: %29
    ;
    const int64_t v116 = 512;
    // pto: %29
    ;
    pto::Shape<1, 4, 32, 16, 32> v117 = pto::Shape<1, 4, 32, 16, 32>();
    // pto: %29
    ;
    pto::Stride<33554432, 262144, 512, 32, 1> v118 = pto::Stride<33554432, 262144, 512, 32, 1>();
    // pto: %29
    ;
    GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v119 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v113 + (v114 + v69 * v115 + v112 * v116), v117, v118);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    TLOAD(v109, v119);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    // pto: %3
    ;
    Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v120 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v52, v23);
    // pto: %3
    ;
    uint64_t v121 = (uint64_t) v9;
    TASSIGN(v120, v121);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    uint16_t v122 = static_cast<uint16_t>(v22);
    uint16_t v123 = static_cast<uint16_t>(v22);
    TEXTRACT(v120, v96, v122, v123);
    // pto: %4
    ;
    Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v14);
    // pto: %4
    ;
    uint64_t v125 = (uint64_t) v9;
    TASSIGN(v124, v125);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    uint16_t v126 = static_cast<uint16_t>(v22);
    uint16_t v127 = static_cast<uint16_t>(v22);
    TEXTRACT(v124, v109, v126, v127);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
    // pto: %5
    ;
    Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v128 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v52, v23);
    // pto: %5
    ;
    uint64_t v129 = (uint64_t) v11;
    TASSIGN(v128, v129);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    uint16_t v130 = static_cast<uint16_t>(v22);
    uint16_t v131 = static_cast<uint16_t>(v23);
    TEXTRACT(v128, v96, v130, v131);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    // pto: %6
    ;
    Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v132 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v14);
    // pto: %6
    ;
    uint64_t v133 = (uint64_t) v10;
    TASSIGN(v132, v133);
    uint16_t v134 = static_cast<uint16_t>(v23);
    uint16_t v135 = static_cast<uint16_t>(v22);
    TEXTRACT(v132, v109, v134, v135);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
    pipe_barrier(PIPE_M);
    TMATMUL_ACC(v76, v76, v120, v124);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    pipe_barrier(PIPE_M);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
    TMATMUL_ACC(v76, v76, v128, v132);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  }
  set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  // pto: %31
  int64_t v136 = v50 < v22 ? v22 : v50;
  // pto: %integer_accum_inline1125__ssa_v0_pview
  const int64_t v137 = 0;
  // pto: %integer_accum_inline1125__ssa_v0_pview
  __gm__ int32_t* v138 = PTOAS__GLOBAL_TENSOR_DATA(v45);
  // pto: %integer_accum_inline1125__ssa_v0_pview
  const int64_t v139 = 1;
  // pto: %integer_accum_inline1125__ssa_v0_pview
  const int64_t v140 = 1;
  // pto: %integer_accum_inline1125__ssa_v0_pview
  const int64_t v141 = 1;
  // pto: %integer_accum_inline1125__ssa_v0_pview
  int64_t v142 = v52 * v20;
  // pto: %integer_accum_inline1125__ssa_v0_pview
  int64_t v143 = v141 * v142;
  // pto: %integer_accum_inline1125__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 128> v144 = pto::Shape<1, 1, 1, -1, 128>(v139, v140, v141, v52, v14);
  // pto: %integer_accum_inline1125__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v145 = pto::Stride<-1, -1, -1, -1, -1>(v140 * v143, v143, v142, v20, v13);
  // pto: %integer_accum_inline1125__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v146 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v138 + (v137 + v55 * v20 + v136 * v13), v144, v145);
  wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  TSTORE(v146, v76);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}