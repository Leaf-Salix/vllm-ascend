#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void idx_kv_scale_commit(__gm__ int32_t* v1, __gm__ int64_t* v2, __gm__ int32_t* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ float* v6, __gm__ int8_t* v7, int64_t v8, int64_t v9, int64_t v10, int64_t v11, int64_t v12, int64_t v13, int64_t v14) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v15 = 0;
  // pto: %c1_index
  const int64_t v16 = 1;
  // pto: %c2_index
  const int64_t v17 = 2;
  // pto: %c0_index
  const int64_t v18 = 0;
  // pto: %c4_index
  const int64_t v19 = 4;
  // pto: %c3_index
  const int64_t v20 = 3;
  // pto: %c1_i64
  const int64_t v21 = 1;
  // pto: %c4_i64
  const int64_t v22 = 4;
  // pto: %c64_index
  const int64_t v23 = 64;
  // pto: %c4096_index
  const int64_t v24 = 4096;
  // pto: %c32_index
  const int64_t v25 = 32;
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v26 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v27 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v28 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v29 = (int64_t) v13;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v30 = (int64_t) v14;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v31 = v29 * v30;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v32 = v28 * v31;
  // pto: %idx_native_kv_cache__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v33 = pto::Shape<1, 1, 1, -1, -1>(v26, v27, v28, v29, (int64_t) v14);
  // pto: %idx_native_kv_cache__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v34 = pto::Stride<-1, -1, -1, -1, -1>(v27 * v32, v32, v31, v30, v16);
  // pto: %idx_native_kv_cache__rv_v2_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v35 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v33, v34);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v36 = v18; v36 < v8; v36 += v16) {
    // pto: %0
    ;
    int64_t v37 = v36 / v17;
    // pto: %t__tile
    ;
    int32_t v38 = (v1)[v37];
    // pto: %1
    ;
    int64_t v39 = (int64_t) v38;
    // pto: %3, %2
    ;
    int32_t v40 = (v1)[(int64_t) ((uint64_t) v37 + (uint64_t) v16)];
    // pto: %4
    ;
    int64_t v41 = (int64_t) v40;
    // pto: %6
    ;
    // pto: %first_pos_inline4911__phi_v5
    ;
    int64_t v42;
    if (v39 < v41) {
      // pto: %7
      ;
      int64_t v43 = (v2)[v39];
      v42 = v43;
    } else {
      v42 = v18;
    };
    // pto: %9
    ;
    int64_t v44 = v36 % v17;
    // pto: %10, %11, %12
    ;
    int64_t v45 = v44 < v18 ? (int64_t) ((uint64_t) v44 + (uint64_t) v17) : v44;
    // pto: %14
    ;
    int64_t v46 = v42 % v19;
    // pto: %15, %16, %17
    ;
    int64_t v47 = v46 < v18 ? (int64_t) ((uint64_t) v46 + (uint64_t) v19) : v46;
    // pto: %13, %18, %19
    ;
    int64_t v48 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v45 * (uint64_t) v19) - (uint64_t) v47) + (uint64_t) v20);
    // pto: %20
    ;
    int32_t v49 = (v3)[v37];
    // pto: %21, %22, %23, %24, %25
    ;
    if ((int64_t) v49 > v18 & v48 < (int64_t) ((uint64_t) v41 - (uint64_t) v39)) {
      // pto: %26, %token_pos_v1_inline4900__tile
      ;
      int64_t v50 = (v2)[(int64_t) ((uint64_t) v39 + (uint64_t) v48)];
      // pto: %27
      ;
      int32_t v51 = (v4)[v37];
      // pto: %28, %32, %29, %30
      ;
      int64_t v52 = (int64_t) ((uint64_t) ((int64_t) v51) + (uint64_t) ((int64_t) ((uint64_t) v50 + (uint64_t) v21) / v22));
      // pto: %33
      ;
      int64_t v53 = (int64_t) ((uint64_t) v12 - (uint64_t) v16);
      // pto: %34
      ;
      int64_t v54 = v52 < v53 ? v52 : v53;
      // pto: %flat_offset_mul
      ;
      int64_t v55 = (int64_t) ((uint64_t) v54 * (uint64_t) v17);
      // pto: %native_page_v1_inline4913__tile
      ;
      int32_t v56 = (v5)[v55];
      // pto: %36, %native_offset_v1_inline4907__tile
      ;
      int32_t v57 = (v5)[(int64_t) ((uint64_t) v55 + (uint64_t) v16)];
      // pto: %38
      ;
      int64_t v58 = (int64_t) v56;
      // pto: %41
      ;
      int64_t v59 = (int64_t) v57;
      // pto: %37, %39, %40, %42, %43
      ;
      if ((v52 < v12 & v58 >= v18) & v59 >= v18) {
        // pto: %44
        ;
        float v60 = (v6)[v36];
        // pto: %47
        ;
        half v61 = (half) v60;
        // pto: %native_scale_bytes_inline4905__ssa_v0
        ;
        Tile<TileType::Vec, int8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v62 = Tile<TileType::Vec, int8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v23);
        // pto: %native_scale_bytes_inline4905__ssa_v0
        ;
        uint64_t v63 = (uint64_t) v15;
        TASSIGN(v62, v63);
        // pto: %49
        ;
        int64_t v64 = v58 < v18 ? v18 : v58;
        // pto: %idx_native_kv_cache__rv_v2_pview
        ;
        int64_t v65 = (int64_t) v14;
        // pto: %idx_native_kv_cache__rv_v2_pview
        ;
        const int64_t v66 = 0;
        // pto: %idx_native_kv_cache__rv_v2_pview
        ;
        __gm__ int8_t* v67 = PTOAS__GLOBAL_TENSOR_DATA(v35);
        // pto: %idx_native_kv_cache__rv_v2_pview
        ;
        const int64_t v68 = 1;
        // pto: %idx_native_kv_cache__rv_v2_pview
        ;
        const int64_t v69 = 1;
        // pto: %idx_native_kv_cache__rv_v2_pview
        ;
        const int64_t v70 = 1;
        // pto: %idx_native_kv_cache__rv_v2_pview
        ;
        int64_t v71 = v16 * v65;
        // pto: %idx_native_kv_cache__rv_v2_pview
        ;
        int64_t v72 = v70 * v71;
        // pto: %idx_native_kv_cache__rv_v2_pview
        ;
        pto::Shape<1, 1, 1, 1, 64> v73 = pto::Shape<1, 1, 1, 1, 64>(v68, v69, v70, v16, v23);
        // pto: %idx_native_kv_cache__rv_v2_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v74 = pto::Stride<-1, -1, -1, -1, -1>(v69 * v72, v72, v71, v65, v16);
        // pto: %idx_native_kv_cache__rv_v2_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v75 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v67 + (v66 + v64 * v65 + v24 * v16), v73, v74);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
        TLOAD(v62, v75);
        set_flag(PIPE_MTE2, PIPE_S, EVENT_ID0);
        // pto: %native_scale_half_inline4897__ssa_v0
        ;
        Tile<TileType::Vec, half, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v76 = Tile<TileType::Vec, half, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v25);
        // pto: %native_scale_half_inline4897__ssa_v0
        ;
        uint64_t v77 = (uint64_t) v15;
        TASSIGN(v76, v77);
        wait_flag(PIPE_MTE2, PIPE_S, EVENT_ID0);
        v76.SetValue(v59, v61);
        set_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
        // pto: %native_updated_bytes_inline4896__ssa_v0
        ;
        Tile<TileType::Vec, int8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v78 = Tile<TileType::Vec, int8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v23);
        // pto: %native_updated_bytes_inline4896__ssa_v0
        ;
        uint64_t v79 = (uint64_t) v15;
        TASSIGN(v78, v79);
        wait_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
        TSTORE(v75, v78);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      };
    };
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}