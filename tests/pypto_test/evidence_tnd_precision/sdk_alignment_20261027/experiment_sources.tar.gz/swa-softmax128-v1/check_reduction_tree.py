"""验证K128工作分片仍表达同一个Native K512三层F8树。"""
import ast
import json
from pathlib import Path


def f8(values):
    assert len(values) == 8
    # Keep F8 opaque: proof must not assume any reassociation inside hardware F8.
    return ('F8', tuple(values))


def main():
    root = Path(__file__).resolve().parent
    base = (root / 'baseline_sparse.py').read_text()
    candidate = (root / 'candidate_sparse.py').read_text()
    native = f8([f8([f8(list(range(g * 64 + j * 8, g * 64 + j * 8 + 8)))
                      for j in range(8)]) for g in range(8)])
    parts = []
    for part in range(4):
        first = [f8(list(range(part * 128 + j * 8, part * 128 + j * 8 + 8))) for j in range(16)]
        parts.extend([f8(first[:8]), f8(first[8:])])
    assert native == f8(parts)
    for head in range(32):
        for col in range(8):
            idx = head * 2 + (col // 2) * 64 + col % 2
            assert 0 <= idx < 256
            assert (idx // 64, (idx % 64) // 2, idx % 2) == (col // 2, head, col % 2)
    # All source outside softmax and its moved scratch declaration remains identical.
    begin = '                        for sm_part in'
    end = '                        pl.system.sync_set(\n                            QK_PROB_READY_EVENT'
    ba, bb = base.index(begin), base.index(end)
    ca = candidate.index('                        wide_position =')
    cb = candidate.index(end, ca)
    scratch = '''                qk_reduce_tmp = pl.create_tile(
                    [SOFTMAX_HEAD_TILE, ATTN_K_TILE], dtype=pl.FP32, target_memory=pl.MemorySpace.Vec
                )
'''
    assert base[:ba].replace(scratch, '') == candidate[:ca]
    assert base[bb:] == candidate[cb:]
    a = next(n for n in ast.walk(ast.parse(base)) if isinstance(n, ast.For)
             and isinstance(n.target, ast.Name) and n.target.id == 'sm_part')
    b = next(n for n in ast.walk(ast.parse(candidate)) if isinstance(n, ast.For)
             and isinstance(n.target, ast.Name) and n.target.id == 'sm_part')
    assert ast.dump(a, include_attributes=False) == ast.dump(b, include_attributes=False)
    report = {'pass': True, 'full512_F8_tree_exact_symbolically': True,
              'assumes_reassociation_inside_F8': False, 'partial_gather_indices': 256,
              'all_nonsoftmax_source_unchanged_except_scratch_lifetime': True,
              'short_compressed_fallback_AST_equal': True,
              'hardware_precision_proved': False,
              'pending_checks': ['global max signedzero ties', 'actual row_sum lowering',
                                 'UB lifetime', 'Native hardware A/B only after performance win']}
    (root / 'REDUCTION_TREE.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
