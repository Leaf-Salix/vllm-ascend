#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void cube_quant_idle(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ bfloat16_t* v6, __gm__ int8_t* v7, __gm__ float* v8, __gm__ bfloat16_t* v9, __gm__ bfloat16_t* v10, __gm__ float* v11, __gm__ float* v12, __gm__ bfloat16_t* v13, __gm__ float* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c1_index
  const int64_t v22 = 1;
  // pto: %c128_index
  const int64_t v23 = 128;
  // pto: %c55296_index
  const int64_t v24 = 55296;
  // pto: %c0_index
  const int64_t v25 = 0;
  // pto: %signals__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v27 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v28 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v29 = 1;
  // pto: %signals__ssa_v0_view
  int64_t v30 = v24 * v22;
  // pto: %signals__ssa_v0_view
  int64_t v31 = v29 * v30;
  // pto: %signals__ssa_v0_view
  int64_t v32 = v28 * v31;
  // pto: %signals__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v33 = pto::Shape<1, 1, 1, 1, -1>(v26, v27, v28, v29, v24);
  // pto: %signals__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v34 = pto::Stride<-1, -1, -1, -1, -1>(v27 * v32, v32, v31, v30, v22);
  // pto: %signals__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v35 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v33, v34);
  // pto: %worker__ssa_v0, %0
  int64_t v36 = (int64_t) ((uint64_t) ((int64_t) v20) * (uint64_t) v23);
  // pto: %1
  int64_t v37 = v36 < v25 ? v25 : v36;
  // pto: %signals__ssa_v0_pview
  __gm__ int32_t* v38 = PTOAS__GLOBAL_TENSOR_DATA(v35);
  // pto: %signals__ssa_v0_pview
  const int64_t v39 = 0;
  // pto: %signals__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 1> v40 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  pto::Stride<1, 1, 1, 1, 1> v41 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v42 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v38 + (v39 + v37), v40, v41);
  __gm__ int32_t* v43 = PTOAS__GLOBAL_TENSOR_DATA(v42);
  PTOAS__DCCI_SINGLE_CACHE_LINE(v43);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  #endif // __DAV_VEC__

  return;
}

AICORE void vector_quant(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ bfloat16_t* v6, __gm__ int8_t* v7, __gm__ float* v8, __gm__ bfloat16_t* v9, __gm__ bfloat16_t* v10, __gm__ float* v11, __gm__ float* v12, __gm__ bfloat16_t* v13, __gm__ float* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21, int32_t v22) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v23 = 0;
  // pto: %c65536_i64
  const int64_t v24 = 65536;
  // pto: %c98304_i64
  const int64_t v25 = 98304;
  // pto: %c98336_i64
  const int64_t v26 = 98336;
  // pto: %c1_index
  const int64_t v27 = 1;
  // pto: %c8_index
  const int64_t v28 = 8;
  // pto: %c16_index
  const int64_t v29 = 16;
  // pto: %c128_index
  const int64_t v30 = 128;
  // pto: %c8192_index
  const int64_t v31 = 8192;
  // pto: %c55296_index
  const int64_t v32 = 55296;
  // pto: %c2_index
  const int64_t v33 = 2;
  // pto: %c24_index
  const int64_t v34 = 24;
  // pto: %c0_index
  const int64_t v35 = 0;
  // pto: %c15_index
  const int64_t v36 = 15;
  // pto: %c48_index
  const int64_t v37 = 48;
  // pto: %c1024_index
  const int64_t v38 = 1024;
  // pto: %c18432_index
  const int64_t v39 = 18432;
  // pto: %c7_index
  const int64_t v40 = 7;
  // pto: %c21504_index
  const int64_t v41 = 21504;
  // pto: %cst_31
  const float v42 = 0.00787401571f;
  // pto: %cst_32
  const float v43 = 0.0f;
  // pto: %cst_33
  const float v44 = 1.0f;
  // pto: %cst_34
  const float v45 = 127.0f;
  // pto: %c27648_index
  const int64_t v46 = 27648;
  // pto: %projected__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %projected__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %projected__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %projected__ssa_v0_view
  int64_t v50 = (int64_t) v17;
  // pto: %projected__ssa_v0_view
  int64_t v51 = v50 * v31;
  // pto: %projected__ssa_v0_view
  int64_t v52 = v49 * v51;
  // pto: %projected__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v53 = pto::Shape<1, 1, 1, -1, -1>(v47, v48, v49, v50, v31);
  // pto: %projected__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v54 = pto::Stride<-1, -1, -1, -1, -1>(v48 * v52, v52, v51, v31, v27);
  // pto: %projected__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v55 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v53, v54);
  // pto: %quantized__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v57 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %quantized__ssa_v0_view
  int64_t v59 = (int64_t) v17;
  // pto: %quantized__ssa_v0_view
  int64_t v60 = v59 * v31;
  // pto: %quantized__ssa_v0_view
  int64_t v61 = v58 * v60;
  // pto: %quantized__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v62 = pto::Shape<1, 1, 1, -1, -1>(v56, v57, v58, v59, v31);
  // pto: %quantized__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v63 = pto::Stride<-1, -1, -1, -1, -1>(v57 * v61, v61, v60, v31, v27);
  // pto: %quantized__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v64 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v62, v63);
  // pto: %token_scale__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %token_scale__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %token_scale__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %token_scale__ssa_v0_view
  int64_t v68 = (int64_t) v17;
  // pto: %token_scale__ssa_v0_view
  int64_t v69 = v68 * v27;
  // pto: %token_scale__ssa_v0_view
  int64_t v70 = v67 * v69;
  // pto: %token_scale__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v71 = pto::Shape<1, 1, 1, -1, -1>(v65, v66, v67, v68, v27);
  // pto: %token_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v66 * v70, v70, v69, v27, (int64_t) v17);
  // pto: %token_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v73 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v8, v71, v72);
  // pto: %accum__ssa_v0_view
  const int64_t v74 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %accum__ssa_v0_view
  int64_t v77 = (int64_t) v18;
  // pto: %accum__ssa_v0_view
  int64_t v78 = v77 * v31;
  // pto: %accum__ssa_v0_view
  int64_t v79 = v76 * v78;
  // pto: %accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v80 = pto::Shape<1, 1, 1, -1, -1>(v74, v75, v76, v77, v31);
  // pto: %accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v81 = pto::Stride<-1, -1, -1, -1, -1>(v75 * v79, v79, v78, v31, v27);
  // pto: %accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v82 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v80, v81);
  // pto: %signals__ssa_v0_view
  const int64_t v83 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v84 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v85 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %signals__ssa_v0_view
  int64_t v87 = v32 * v27;
  // pto: %signals__ssa_v0_view
  int64_t v88 = v86 * v87;
  // pto: %signals__ssa_v0_view
  int64_t v89 = v85 * v88;
  // pto: %signals__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v90 = pto::Shape<1, 1, 1, 1, -1>(v83, v84, v85, v86, v32);
  // pto: %signals__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v91 = pto::Stride<-1, -1, -1, -1, -1>(v84 * v89, v89, v88, v87, v27);
  // pto: %signals__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v92 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v90, v91);
  // pto: %t__tmp_v0, %0, %1, %t__tmp_v1
  int64_t v93 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v20) * (uint64_t) v33) + (uint64_t) ((int64_t) v22));
  // pto: %2, %3
  int64_t v94 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v93 + (uint64_t) v34) * (uint64_t) v30);
  // pto: %4
  int64_t v95 = v94 < v35 ? v35 : v94;
  // pto: %signals__ssa_v0_pview
  __gm__ int32_t* v96 = PTOAS__GLOBAL_TENSOR_DATA(v92);
  // pto: %signals__ssa_v0_pview
  const int64_t v97 = 0;
  // pto: %signals__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 1> v98 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  pto::Stride<1, 1, 1, 1, 1> v99 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v100 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v96 + (v97 + v95), v98, v99);
  __gm__ int32_t* v101 = PTOAS__GLOBAL_TENSOR_DATA(v100);
  PTOAS__DCCI_SINGLE_CACHE_LINE(v101);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  // pto: %generation_inline18__tile
  int32_t v102 = (v16)[v94];
  // pto: %5, %6, %7
  int64_t v103 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v17 + (uint64_t) v36) / v29) * (uint64_t) v28);
  // pto: %8
  if (v93 < v103) {
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
  }
  for (int64_t v104 = v93; v104 < v103; v104 += v37) {
    // pto: %10, %11
    ;
    int64_t v105 = (int64_t) ((uint64_t) (v104 / v28) * (uint64_t) v29);
    // pto: %12
    ;
    int64_t v106 = v104 % v28;
    // pto: %13, %14, %15
    ;
    int64_t v107 = v106 < v35 ? (int64_t) ((uint64_t) v106 + (uint64_t) v28) : v106;
    // pto: %16
    ;
    int64_t v108 = (int64_t) ((uint64_t) v107 * (uint64_t) v38);
    // pto: %17
    ;
    int64_t v109 = (int64_t) ((uint64_t) v17 - (uint64_t) v105);
    // pto: %18
    ;
    int64_t v110 = v109 < v29 ? v109 : v29;
    // pto: %oa_value__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v110, v38);
    // pto: %oa_value__ssa_v0
    ;
    uint64_t v112 = (uint64_t) v23;
    TASSIGN(v111, v112);
    // pto: %19
    ;
    int64_t v113 = v105 < v35 ? v35 : v105;
    // pto: %20
    ;
    int64_t v114 = v108 < v35 ? v35 : v108;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v115 = 0;
    // pto: %accum__ssa_v0_pview
    ;
    __gm__ float* v116 = PTOAS__GLOBAL_TENSOR_DATA(v82);
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v117 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v118 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v119 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    int64_t v120 = v110 * v31;
    // pto: %accum__ssa_v0_pview
    ;
    int64_t v121 = v119 * v120;
    // pto: %accum__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1024> v122 = pto::Shape<1, 1, 1, -1, 1024>(v117, v118, v119, v110, v38);
    // pto: %accum__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v123 = pto::Stride<-1, -1, -1, -1, -1>(v118 * v121, v121, v120, v31, v27);
    // pto: %accum__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v124 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v116 + (v115 + v113 * v31 + v114 * v27), v122, v123);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v111, v124);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %t__tmp_v2
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v125 = Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v110, v38);
    // pto: %t__tmp_v2
    ;
    uint64_t v126 = (uint64_t) v23;
    TASSIGN(v125, v126);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v127 = RoundMode::CAST_RINT;
    SaturationMode v128 = SaturationMode::ON;
    TCVT(v125, v111, v127, v128);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v129 = 0;
    // pto: %projected__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v130 = PTOAS__GLOBAL_TENSOR_DATA(v55);
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v131 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v132 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v133 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    int64_t v134 = v110 * v31;
    // pto: %projected__ssa_v0_pview
    ;
    int64_t v135 = v133 * v134;
    // pto: %projected__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1024> v136 = pto::Shape<1, 1, 1, -1, 1024>(v131, v132, v133, v110, v38);
    // pto: %projected__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v137 = pto::Stride<-1, -1, -1, -1, -1>(v132 * v135, v135, v134, v31, v27);
    // pto: %projected__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v138 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v130 + (v129 + v113 * v31 + v114 * v27), v136, v137);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v138, v125);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %24
  int64_t v139 = (int64_t) ((uint64_t) v94 + (uint64_t) v39);
  // pto: %25
  int64_t v140 = v139 < v35 ? v35 : v139;
  // pto: %signals__ssa_v1_signal_pview
  __gm__ int32_t* v141 = PTOAS__GLOBAL_TENSOR_DATA(v92);
  // pto: %signals__ssa_v1_signal_pview
  const int64_t v142 = 0;
  // pto: %signals__ssa_v1_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v143 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v144 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v145 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v141 + (v142 + v140), v143, v144);
  pto::comm::NotifyOp v146 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v145, v102, v146);
  // pto: %26, %27
  int64_t v147 = (int64_t) ((uint64_t) v17 + (uint64_t) v40) / v28;
  // pto: %28
  if (v93 < v147) {
    for (int64_t v148 = v35; v148 < v28; v148 += v27) {
      // pto: %29, %30, %31, %32
      ;
      int64_t v149 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) (v93 / v33) * (uint64_t) v28) + (uint64_t) v148) % v37;
      // pto: %33, %34, %35
      ;
      int64_t v150 = v149 < v35 ? (int64_t) ((uint64_t) v149 + (uint64_t) v37) : v149;
      // pto: %36, %37
      ;
      int64_t v151 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v150 * (uint64_t) v30) + (uint64_t) v41);
      // pto: %38
      ;
      int64_t v152 = v151 < v35 ? v35 : v151;
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      __gm__ int32_t* v153 = PTOAS__GLOBAL_TENSOR_DATA(v92);
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      const int64_t v154 = 0;
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      pto::Shape<1, 1, 1, 1, 1> v155 = pto::Shape<1, 1, 1, 1, 1>();
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      pto::Stride<1, 1, 1, 1, 1> v156 = pto::Stride<1, 1, 1, 1, 1>();
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v157 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v153 + (v154 + v152), v155, v156);
      pto::comm::WaitCmp v158 = pto::comm::WaitCmp::GE;
      pto::comm::TWAIT(v157, v102, v158);
    };
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  for (int64_t v159 = v93; v159 < v147; v159 += v37) {
    // pto: %40
    ;
    int64_t v160 = (int64_t) ((uint64_t) v159 * (uint64_t) v28);
    // pto: %41
    ;
    int64_t v161 = (int64_t) ((uint64_t) v17 - (uint64_t) v160);
    // pto: %42
    ;
    int64_t v162 = v161 < v28 ? v161 : v28;
    // pto: %first_quant__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v163 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v162, v38);
    // pto: %first_quant__ssa_v0
    ;
    uint64_t v164 = (uint64_t) v24;
    TASSIGN(v163, v164);
    // pto: %43
    ;
    int64_t v165 = v160 < v35 ? v35 : v160;
    // pto: %44
    ;
    const int64_t v166 = 0;
    // pto: %44
    ;
    __gm__ bfloat16_t* v167 = PTOAS__GLOBAL_TENSOR_DATA(v55);
    // pto: %44
    ;
    const int64_t v168 = 1;
    // pto: %44
    ;
    const int64_t v169 = 1;
    // pto: %44
    ;
    const int64_t v170 = 1;
    // pto: %44
    ;
    int64_t v171 = v162 * v31;
    // pto: %44
    ;
    int64_t v172 = v170 * v171;
    // pto: %44
    ;
    pto::Shape<1, 1, 1, -1, 1024> v173 = pto::Shape<1, 1, 1, -1, 1024>(v168, v169, v170, v162, v38);
    // pto: %44
    ;
    pto::Stride<-1, -1, -1, -1, -1> v174 = pto::Stride<-1, -1, -1, -1, -1>(v169 * v172, v172, v171, v31, v27);
    // pto: %44
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v175 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v167 + (v166 + v165 * v31 + v35 * v27), v173, v174);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v163, v175);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %t__tmp_v3
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v176 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v162, v38);
    // pto: %t__tmp_v3
    ;
    uint64_t v177 = (uint64_t) v23;
    TASSIGN(v176, v177);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    RoundMode v178 = RoundMode::CAST_ROUND;
    SaturationMode v179 = SaturationMode::ON;
    TCVT(v176, v163, v178, v179);
    // pto: %first_abs__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v180 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v162, v38);
    // pto: %first_abs__ssa_v0
    ;
    uint64_t v181 = (uint64_t) v23;
    TASSIGN(v180, v181);
    pipe_barrier(PIPE_V);
    TABS(v180, v176);
    // pto: %t__tmp_v4
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v182 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v28, v38);
    // pto: %t__tmp_v4
    ;
    uint64_t v183 = (uint64_t) v24;
    TASSIGN(v182, v183);
    // pto: %amax__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v184 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v162, v27);
    // pto: %amax__ssa_v0
    ;
    uint64_t v185 = (uint64_t) v25;
    TASSIGN(v184, v185);
    pipe_barrier(PIPE_V);
    TROWMAX(v184, v180, v182);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    for (int64_t v186 = v27; v186 < v28; v186 += v27) {
      // pto: %q_bf16__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v187 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v162, v38);
      // pto: %q_bf16__ssa_v0
      ;
      uint64_t v188 = (uint64_t) v24;
      TASSIGN(v187, v188);
      // pto: %46
      ;
      int64_t v189 = (int64_t) ((uint64_t) v186 * (uint64_t) v38);
      // pto: %47
      ;
      int64_t v190 = v189 < v35 ? v35 : v189;
      // pto: %48
      ;
      const int64_t v191 = 0;
      // pto: %48
      ;
      __gm__ bfloat16_t* v192 = PTOAS__GLOBAL_TENSOR_DATA(v55);
      // pto: %48
      ;
      const int64_t v193 = 1;
      // pto: %48
      ;
      const int64_t v194 = 1;
      // pto: %48
      ;
      const int64_t v195 = 1;
      // pto: %48
      ;
      int64_t v196 = v162 * v31;
      // pto: %48
      ;
      int64_t v197 = v195 * v196;
      // pto: %48
      ;
      pto::Shape<1, 1, 1, -1, 1024> v198 = pto::Shape<1, 1, 1, -1, 1024>(v193, v194, v195, v162, v38);
      // pto: %48
      ;
      pto::Stride<-1, -1, -1, -1, -1> v199 = pto::Stride<-1, -1, -1, -1, -1>(v194 * v197, v197, v196, v31, v27);
      // pto: %48
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v200 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v192 + (v191 + v165 * v31 + v190 * v27), v198, v199);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      TLOAD(v187, v200);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %q_fp32__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v201 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v162, v38);
      // pto: %q_fp32__ssa_v0
      ;
      uint64_t v202 = (uint64_t) v23;
      TASSIGN(v201, v202);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      pipe_barrier(PIPE_V);
      RoundMode v203 = RoundMode::CAST_ROUND;
      SaturationMode v204 = SaturationMode::ON;
      TCVT(v201, v187, v203, v204);
      // pto: %t__tmp_v5
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v205 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v162, v38);
      // pto: %t__tmp_v5
      ;
      uint64_t v206 = (uint64_t) v23;
      TASSIGN(v205, v206);
      pipe_barrier(PIPE_V);
      TABS(v205, v201);
      // pto: %t__tmp_v6
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v28, v38);
      // pto: %t__tmp_v6
      ;
      uint64_t v208 = (uint64_t) v24;
      TASSIGN(v207, v208);
      // pto: %t__tmp_v7
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v209 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v162, v27);
      // pto: %t__tmp_v7
      ;
      uint64_t v210 = (uint64_t) v26;
      TASSIGN(v209, v210);
      pipe_barrier(PIPE_V);
      TROWMAX(v209, v205, v207);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      // pto: %amax__rm_a0_tmp_v0
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v162);
      // pto: %amax__rm_a0_tmp_v0
      ;
      uint64_t v212 = (uint64_t) v25;
      TASSIGN(v211, v212);
      // pto: %amax__rm_a1_tmp_v1
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v213 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v162);
      // pto: %amax__rm_a1_tmp_v1
      ;
      uint64_t v214 = (uint64_t) v26;
      TASSIGN(v213, v214);
      // pto: %amax__row_major_tmp_v2
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v162);
      // pto: %amax__row_major_tmp_v2
      ;
      uint64_t v216 = (uint64_t) v23;
      TASSIGN(v215, v216);
      pipe_barrier(PIPE_V);
      TMAX(v215, v211, v213);
      // pto: %amax__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v162, v27);
      // pto: %amax__ssa_v3
      ;
      uint64_t v218 = (uint64_t) v23;
      TASSIGN(v217, v218);
      // pto: %amax__ssa_v3_mv
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v219 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v162, v27);
      // pto: %amax__ssa_v3_mv
      ;
      uint64_t v220 = (uint64_t) v25;
      TASSIGN(v219, v220);
      pipe_barrier(PIPE_V);
      TMOV(v219, v217);
    };
    // pto: %dequant__rm_a0_tmp_v3
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v221 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v162);
    // pto: %dequant__rm_a0_tmp_v3
    ;
    uint64_t v222 = (uint64_t) v25;
    TASSIGN(v221, v222);
    // pto: %dequant__row_major_tmp_v4
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v223 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v162);
    // pto: %dequant__row_major_tmp_v4
    ;
    uint64_t v224 = (uint64_t) v23;
    TASSIGN(v223, v224);
    pipe_barrier(PIPE_V);
    TMULS(v223, v221, v42);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %dequant__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v225 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v162, v27);
    // pto: %dequant__ssa_v0
    ;
    uint64_t v226 = (uint64_t) v23;
    TASSIGN(v225, v226);
    // pto: %denominator__rm_a0_tmp_v5
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v227 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v162);
    // pto: %denominator__rm_a0_tmp_v5
    ;
    uint64_t v228 = (uint64_t) v25;
    TASSIGN(v227, v228);
    // pto: %denominator__row_major_tmp_v6
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v229 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v162);
    // pto: %denominator__row_major_tmp_v6
    ;
    uint64_t v230 = (uint64_t) v24;
    TASSIGN(v229, v230);
    TADDS(v229, v227, v43);
    set_flag(PIPE_V, PIPE_S, EVENT_ID0);
    // pto: %denominator__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v231 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v162, v27);
    // pto: %denominator__ssa_v0
    ;
    uint64_t v232 = (uint64_t) v24;
    TASSIGN(v231, v232);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
    for (int64_t v233 = v35; v233 < v162; v233 += v27) {
      // pto: %magnitude__ssa_v0
      ;
      float v234 = v231.GetValue(v233);
      // pto: %49
      ;
      bool v235 = v234 != v234 || v43 != v43;
      // pto: %49
      ;
      if ((v234 == v234 && v43 == v43) && v234 == v43) {
        v231.SetValue(v233, v44);
      };
    };
    set_flag(PIPE_S, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
    // pto: %t__rm_a0_tmp_v7
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v236 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v162);
    // pto: %t__rm_a0_tmp_v7
    ;
    uint64_t v237 = (uint64_t) v25;
    TASSIGN(v236, v237);
    // pto: %t__row_major_tmp_v8
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v238 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v162);
    // pto: %t__row_major_tmp_v8
    ;
    uint64_t v239 = (uint64_t) v25;
    TASSIGN(v238, v239);
    pipe_barrier(PIPE_V);
    TMULS(v238, v236, v43);
    // pto: %t__tmp_v8
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v240 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v162, v27);
    // pto: %t__tmp_v8
    ;
    uint64_t v241 = (uint64_t) v25;
    TASSIGN(v240, v241);
    // pto: %t__rm_a0_tmp_v9
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v242 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v162);
    // pto: %t__rm_a0_tmp_v9
    ;
    uint64_t v243 = (uint64_t) v25;
    TASSIGN(v242, v243);
    // pto: %t__row_major_tmp_v10
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v244 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v162);
    // pto: %t__row_major_tmp_v10
    ;
    uint64_t v245 = (uint64_t) v25;
    TASSIGN(v244, v245);
    pipe_barrier(PIPE_V);
    TADDS(v244, v242, v45);
    // pto: %t__tmp_v9
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v246 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v162, v27);
    // pto: %t__tmp_v9
    ;
    uint64_t v247 = (uint64_t) v25;
    TASSIGN(v246, v247);
    // pto: %multiplier__rm_a0_tmp_v11
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v248 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v162);
    // pto: %multiplier__rm_a0_tmp_v11
    ;
    uint64_t v249 = (uint64_t) v25;
    TASSIGN(v248, v249);
    // pto: %multiplier__rm_a1_tmp_v12
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v250 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v162);
    // pto: %multiplier__rm_a1_tmp_v12
    ;
    uint64_t v251 = (uint64_t) v24;
    TASSIGN(v250, v251);
    // pto: %multiplier__row_major_tmp_v13
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v252 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v162);
    // pto: %multiplier__row_major_tmp_v13
    ;
    uint64_t v253 = (uint64_t) v25;
    TASSIGN(v252, v253);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    TDIV(v252, v248, v250);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    // pto: %multiplier__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v254 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v162, v27);
    // pto: %multiplier__ssa_v0
    ;
    uint64_t v255 = (uint64_t) v25;
    TASSIGN(v254, v255);
    v225.SetValidShape(v162, v27);
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v256 = (int64_t) v17;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v257 = 0;
    // pto: %token_scale__ssa_v0_pview
    ;
    __gm__ float* v258 = PTOAS__GLOBAL_TENSOR_DATA(v73);
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v259 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v260 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v261 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v262 = v162 * v27;
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v263 = v261 * v262;
    // pto: %token_scale__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1> v264 = pto::Shape<1, 1, 1, -1, 1>(v259, v260, v261, v162, v27);
    // pto: %token_scale__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v265 = pto::Stride<-1, -1, -1, -1, -1>(v260 * v263, v263, v262, v27, v256);
    // pto: %token_scale__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v266 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v258 + (v257 + v165 * v27 + v35 * v256), v264, v265);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    TSTORE(v266, v225);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_S, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    for (int64_t v267 = v35; v267 < v28; v267 += v27) {
      // pto: %54
      ;
      int64_t v268 = (int64_t) ((uint64_t) v267 * (uint64_t) v38);
      // pto: %quant_bf16__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v269 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v162, v38);
      // pto: %quant_bf16__ssa_v0
      ;
      uint64_t v270 = (uint64_t) v24;
      TASSIGN(v269, v270);
      // pto: %56
      ;
      int64_t v271 = v268 < v35 ? v35 : v268;
      // pto: %57
      ;
      const int64_t v272 = 0;
      // pto: %57
      ;
      __gm__ bfloat16_t* v273 = PTOAS__GLOBAL_TENSOR_DATA(v55);
      // pto: %57
      ;
      const int64_t v274 = 1;
      // pto: %57
      ;
      const int64_t v275 = 1;
      // pto: %57
      ;
      const int64_t v276 = 1;
      // pto: %57
      ;
      int64_t v277 = v162 * v31;
      // pto: %57
      ;
      int64_t v278 = v276 * v277;
      // pto: %57
      ;
      pto::Shape<1, 1, 1, -1, 1024> v279 = pto::Shape<1, 1, 1, -1, 1024>(v274, v275, v276, v162, v38);
      // pto: %57
      ;
      pto::Stride<-1, -1, -1, -1, -1> v280 = pto::Stride<-1, -1, -1, -1, -1>(v275 * v278, v278, v277, v31, v27);
      // pto: %57
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v281 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v273 + (v272 + v165 * v31 + v271 * v27), v279, v280);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      TLOAD(v269, v281);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %t__tmp_v11
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v282 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v162, v38);
      // pto: %t__tmp_v11
      ;
      uint64_t v283 = (uint64_t) v23;
      TASSIGN(v282, v283);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      RoundMode v284 = RoundMode::CAST_ROUND;
      SaturationMode v285 = SaturationMode::ON;
      TCVT(v282, v269, v284, v285);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      // pto: %quant_scaled__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v286 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v162, v38);
      // pto: %quant_scaled__ssa_v0
      ;
      uint64_t v287 = (uint64_t) v23;
      TASSIGN(v286, v287);
      pipe_barrier(PIPE_V);
      TROWEXPANDMUL(v286, v282, v254);
      // pto: %integer__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v288 = Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v162, v38);
      // pto: %integer__ssa_v0
      ;
      uint64_t v289 = (uint64_t) v23;
      TASSIGN(v288, v289);
      pipe_barrier(PIPE_V);
      RoundMode v290 = RoundMode::CAST_RINT;
      SaturationMode v291 = SaturationMode::ON;
      TCVT(v288, v286, v290, v291);
      // pto: %half__ssa_v0
      ;
      Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v292 = Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v162, v38);
      // pto: %half__ssa_v0
      ;
      uint64_t v293 = (uint64_t) v23;
      TASSIGN(v292, v293);
      pipe_barrier(PIPE_V);
      RoundMode v294 = RoundMode::CAST_ROUND;
      SaturationMode v295 = SaturationMode::ON;
      TCVT(v292, v288, v294, v295);
      // pto: %result__ssa_v0
      ;
      Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v296 = Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v162, v38);
      // pto: %result__ssa_v0
      ;
      uint64_t v297 = (uint64_t) v23;
      TASSIGN(v296, v297);
      pipe_barrier(PIPE_V);
      RoundMode v298 = RoundMode::CAST_TRUNC;
      SaturationMode v299 = SaturationMode::ON;
      TCVT(v296, v292, v298, v299);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      v296.SetValidShape(v162, v38);
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v300 = 0;
      // pto: %quantized__ssa_v0_pview
      ;
      __gm__ int8_t* v301 = PTOAS__GLOBAL_TENSOR_DATA(v64);
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v302 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v303 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v304 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      int64_t v305 = v162 * v31;
      // pto: %quantized__ssa_v0_pview
      ;
      int64_t v306 = v304 * v305;
      // pto: %quantized__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 1024> v307 = pto::Shape<1, 1, 1, -1, 1024>(v302, v303, v304, v162, v38);
      // pto: %quantized__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v308 = pto::Stride<-1, -1, -1, -1, -1>(v303 * v306, v306, v305, v31, v27);
      // pto: %quantized__ssa_v0_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v309 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v301 + (v300 + v165 * v31 + v271 * v27), v307, v308);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      TSTORE(v309, v296);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %61
  int64_t v310 = (int64_t) ((uint64_t) v94 + (uint64_t) v46);
  // pto: %62
  int64_t v311 = v310 < v35 ? v35 : v310;
  // pto: %63
  __gm__ int32_t* v312 = PTOAS__GLOBAL_TENSOR_DATA(v92);
  // pto: %63
  const int64_t v313 = 0;
  // pto: %63
  pto::Shape<1, 1, 1, 1, 1> v314 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %63
  pto::Stride<1, 1, 1, 1, 1> v315 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %63
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v316 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v312 + (v313 + v311), v314, v315);
  pto::comm::NotifyOp v317 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v316, v102, v317);
  pipe_barrier(PIPE_ALL);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}