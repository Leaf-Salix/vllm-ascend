#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void cube_wob(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ bfloat16_t* v6, __gm__ int8_t* v7, __gm__ float* v8, __gm__ bfloat16_t* v9, __gm__ bfloat16_t* v10, __gm__ float* v11, __gm__ float* v12, __gm__ bfloat16_t* v13, __gm__ float* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v22 = 0;
  // pto: %c65536_i64
  const int64_t v23 = 65536;
  // pto: %c16384_i64
  const int64_t v24 = 16384;
  // pto: %c32768_i64
  const int64_t v25 = 32768;
  // pto: %c1_index
  const int64_t v26 = 1;
  // pto: %c64_index
  const int64_t v27 = 64;
  // pto: %c256_index
  const int64_t v28 = 256;
  // pto: %c16_index
  const int64_t v29 = 16;
  // pto: %c128_index
  const int64_t v30 = 128;
  // pto: %c512_index
  const int64_t v31 = 512;
  // pto: %c32_index
  const int64_t v32 = 32;
  // pto: %c33554432_index
  const int64_t v33 = 33554432;
  // pto: %c262144_index
  const int64_t v34 = 262144;
  // pto: %c4096_index
  const int64_t v35 = 4096;
  // pto: %c8192_index
  const int64_t v36 = 8192;
  // pto: %c55296_index
  const int64_t v37 = 55296;
  // pto: %c0_index
  const int64_t v38 = 0;
  // pto: %c15_index
  const int64_t v39 = 15;
  // pto: %c24_index
  const int64_t v40 = 24;
  // pto: %c63_index
  const int64_t v41 = 63;
  // pto: %c36864_index
  const int64_t v42 = 36864;
  // pto: %wo_b__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v43 = pto::Shape<-1, -1, -1, -1, -1>(v26, v30, v31, v29, v32);
  // pto: %wo_b__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v44 = pto::Stride<-1, -1, -1, -1, -1>(v33, v34, v31, v32, v26);
  // pto: %wo_b__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v45 = GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v3, v43, v44);
  // pto: %quantized__ssa_v6_view
  const int64_t v46 = 1;
  // pto: %quantized__ssa_v6_view
  const int64_t v47 = 1;
  // pto: %quantized__ssa_v6_view
  const int64_t v48 = 1;
  // pto: %quantized__ssa_v6_view
  int64_t v49 = (int64_t) v17;
  // pto: %quantized__ssa_v6_view
  int64_t v50 = v49 * v36;
  // pto: %quantized__ssa_v6_view
  int64_t v51 = v48 * v50;
  // pto: %quantized__ssa_v6_view
  pto::Shape<1, 1, 1, -1, -1> v52 = pto::Shape<1, 1, 1, -1, -1>(v46, v47, v48, v49, v36);
  // pto: %quantized__ssa_v6_view
  pto::Stride<-1, -1, -1, -1, -1> v53 = pto::Stride<-1, -1, -1, -1, -1>(v47 * v51, v51, v50, v36, v26);
  // pto: %quantized__ssa_v6_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v54 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v52, v53);
  // pto: %integer_accum__ssa_v6_view
  const int64_t v55 = 1;
  // pto: %integer_accum__ssa_v6_view
  const int64_t v56 = 1;
  // pto: %integer_accum__ssa_v6_view
  const int64_t v57 = 1;
  // pto: %integer_accum__ssa_v6_view
  int64_t v58 = (int64_t) v19;
  // pto: %integer_accum__ssa_v6_view
  int64_t v59 = v58 * v35;
  // pto: %integer_accum__ssa_v6_view
  int64_t v60 = v57 * v59;
  // pto: %integer_accum__ssa_v6_view
  pto::Shape<1, 1, 1, -1, -1> v61 = pto::Shape<1, 1, 1, -1, -1>(v55, v56, v57, v58, v35);
  // pto: %integer_accum__ssa_v6_view
  pto::Stride<-1, -1, -1, -1, -1> v62 = pto::Stride<-1, -1, -1, -1, -1>(v56 * v60, v60, v59, v35, v26);
  // pto: %integer_accum__ssa_v6_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v63 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v61, v62);
  // pto: %signals__ssa_v6_view
  const int64_t v64 = 1;
  // pto: %signals__ssa_v6_view
  const int64_t v65 = 1;
  // pto: %signals__ssa_v6_view
  const int64_t v66 = 1;
  // pto: %signals__ssa_v6_view
  const int64_t v67 = 1;
  // pto: %signals__ssa_v6_view
  int64_t v68 = v37 * v26;
  // pto: %signals__ssa_v6_view
  int64_t v69 = v67 * v68;
  // pto: %signals__ssa_v6_view
  int64_t v70 = v66 * v69;
  // pto: %signals__ssa_v6_view
  pto::Shape<1, 1, 1, 1, -1> v71 = pto::Shape<1, 1, 1, 1, -1>(v64, v65, v66, v67, v37);
  // pto: %signals__ssa_v6_view
  pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v65 * v70, v70, v69, v68, v26);
  // pto: %signals__ssa_v6_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v73 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v71, v72);
  // pto: %worker__ssa_v0
  int64_t v74 = (int64_t) v20;
  // pto: %12
  int64_t v75 = (int64_t) ((uint64_t) v74 * (uint64_t) v30);
  // pto: %13
  int64_t v76 = v75 < v38 ? v38 : v75;
  // pto: %signals__ssa_v6_pview
  __gm__ int32_t* v77 = PTOAS__GLOBAL_TENSOR_DATA(v73);
  // pto: %signals__ssa_v6_pview
  const int64_t v78 = 0;
  // pto: %signals__ssa_v6_pview
  pto::Shape<1, 1, 1, 1, 1> v79 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v6_pview
  pto::Stride<1, 1, 1, 1, 1> v80 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v6_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v81 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v77 + (v78 + v76), v79, v80);
  __gm__ int32_t* v82 = PTOAS__GLOBAL_TENSOR_DATA(v81);
  PTOAS__DCCI_SINGLE_CACHE_LINE(v82);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  // pto: %generation_inline0__tile
  int32_t v83 = (v16)[v75];
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %16
  if (v17 <= v29) {
    // pto: %14, %15, %17
    ;
    for (int64_t v84 = v74; v84 < ((int64_t) ((uint64_t) ((int64_t) ((uint64_t) v17 + (uint64_t) v39) / v29) * (uint64_t) v32)); v84 += v40) {
      // pto: %18, %19
      ;
      int64_t v85 = (int64_t) ((uint64_t) (v84 / v32) * (uint64_t) v29);
      // pto: %20
      ;
      int64_t v86 = v84 % v32;
      // pto: %21, %22, %23
      ;
      int64_t v87 = v86 < v38 ? (int64_t) ((uint64_t) v86 + (uint64_t) v32) : v86;
      // pto: %24
      ;
      int64_t v88 = (int64_t) ((uint64_t) v87 * (uint64_t) v30);
      // pto: %25
      ;
      int64_t v89 = (int64_t) ((uint64_t) v17 - (uint64_t) v85);
      // pto: %26
      ;
      int64_t v90 = v89 < v29 ? v89 : v29;
      // pto: %b_acc__tile
      ;
      Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v91 = Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v29, v30);
      // pto: %b_acc__tile
      ;
      uint64_t v92 = (uint64_t) v22;
      TASSIGN(v91, v92);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
      for (int64_t v93 = v38; v93 < v29; v93 += v26) {
        // pto: %27
        ;
        int64_t v94 = (int64_t) ((uint64_t) v93 * (uint64_t) v31);
        // pto: %b_input__tile
        ;
        Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v95 = Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v90, v31);
        // pto: %b_input__tile
        ;
        uint64_t v96 = (uint64_t) v23;
        TASSIGN(v95, v96);
        // pto: %28
        ;
        int64_t v97 = v85 < v38 ? v38 : v85;
        // pto: %29
        ;
        int64_t v98 = v94 < v38 ? v38 : v94;
        // pto: %quantized__ssa_v6_pview
        ;
        const int64_t v99 = 0;
        // pto: %quantized__ssa_v6_pview
        ;
        __gm__ int8_t* v100 = PTOAS__GLOBAL_TENSOR_DATA(v54);
        // pto: %quantized__ssa_v6_pview
        ;
        const int64_t v101 = 1;
        // pto: %quantized__ssa_v6_pview
        ;
        const int64_t v102 = 1;
        // pto: %quantized__ssa_v6_pview
        ;
        const int64_t v103 = 1;
        // pto: %quantized__ssa_v6_pview
        ;
        int64_t v104 = v90 * v36;
        // pto: %quantized__ssa_v6_pview
        ;
        int64_t v105 = v103 * v104;
        // pto: %quantized__ssa_v6_pview
        ;
        pto::Shape<1, 1, 1, -1, 512> v106 = pto::Shape<1, 1, 1, -1, 512>(v101, v102, v103, v90, v31);
        // pto: %quantized__ssa_v6_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v107 = pto::Stride<-1, -1, -1, -1, -1>(v102 * v105, v105, v104, v36, v26);
        // pto: %quantized__ssa_v6_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v108 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v100 + (v99 + v97 * v36 + v98 * v26), v106, v107);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        TLOAD(v95, v108);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %b_weight__tile
        ;
        Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v109 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v31, v30);
        // pto: %b_weight__tile
        ;
        uint64_t v110 = (uint64_t) v22;
        TASSIGN(v109, v110);
        // pto: %30
        ;
        int64_t v111 = v88 / v32;
        // pto: %31
        ;
        int64_t v112 = v111 < v38 ? v38 : v111;
        // pto: %32
        ;
        int64_t v113 = v94 / v29;
        // pto: %33
        ;
        int64_t v114 = v113 < v38 ? v38 : v113;
        // pto: %wo_b__ssa_v0_pview
        ;
        __gm__ int8_t* v115 = PTOAS__GLOBAL_TENSOR_DATA(v45);
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v116 = 0;
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v117 = 262144;
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v118 = 512;
        // pto: %wo_b__ssa_v0_pview
        ;
        pto::Shape<1, 4, 32, 16, 32> v119 = pto::Shape<1, 4, 32, 16, 32>();
        // pto: %wo_b__ssa_v0_pview
        ;
        pto::Stride<33554432, 262144, 512, 32, 1> v120 = pto::Stride<33554432, 262144, 512, 32, 1>();
        // pto: %wo_b__ssa_v0_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v121 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v115 + (v116 + v112 * v117 + v114 * v118), v119, v120);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v109, v121);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %b_acc__tile_l0_a
        ;
        Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v122 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v90, v28);
        // pto: %b_acc__tile_l0_a
        ;
        uint64_t v123 = (uint64_t) v22;
        TASSIGN(v122, v123);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        uint16_t v124 = static_cast<uint16_t>(v38);
        uint16_t v125 = static_cast<uint16_t>(v38);
        TEXTRACT(v122, v95, v124, v125);
        // pto: %b_acc__tile_l0_b
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v126 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v28, v30);
        // pto: %b_acc__tile_l0_b
        ;
        uint64_t v127 = (uint64_t) v22;
        TASSIGN(v126, v127);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v128 = static_cast<uint16_t>(v38);
        uint16_t v129 = static_cast<uint16_t>(v38);
        TEXTRACT(v126, v109, v128, v129);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %0
        ;
        Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v130 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v90, v28);
        // pto: %0
        ;
        uint64_t v131 = (uint64_t) v24;
        TASSIGN(v130, v131);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v132 = static_cast<uint16_t>(v38);
        uint16_t v133 = static_cast<uint16_t>(v28);
        TEXTRACT(v130, v95, v132, v133);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        // pto: %1
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v134 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v28, v30);
        // pto: %1
        ;
        uint64_t v135 = (uint64_t) v25;
        TASSIGN(v134, v135);
        uint16_t v136 = static_cast<uint16_t>(v28);
        uint16_t v137 = static_cast<uint16_t>(v38);
        TEXTRACT(v134, v109, v136, v137);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %34
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        if (v93 == v38) {
          pipe_barrier(PIPE_M);
          TMATMUL(v91, v122, v126);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v91, v91, v122, v126);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v91, v91, v130, v134);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      };
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      // pto: %35
      ;
      int64_t v138 = v85 < v38 ? v38 : v85;
      // pto: %36
      ;
      int64_t v139 = v88 < v38 ? v38 : v88;
      // pto: %integer_accum__ssa_v6_pview
      ;
      __gm__ int32_t* v140 = PTOAS__GLOBAL_TENSOR_DATA(v63);
      // pto: %integer_accum__ssa_v6_pview
      ;
      const int64_t v141 = 0;
      // pto: %integer_accum__ssa_v6_pview
      ;
      const int64_t v142 = 4096;
      // pto: %integer_accum__ssa_v6_pview
      ;
      pto::Shape<1, 1, 1, 16, 128> v143 = pto::Shape<1, 1, 1, 16, 128>();
      // pto: %integer_accum__ssa_v6_pview
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v144 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %integer_accum__ssa_v6_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v145 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v140 + (v141 + v138 * v142 + v139), v143, v144);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      pipe_barrier(PIPE_FIX);
      TSTORE(v145, v91);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    };
  } else {
    // pto: %37, %38, %39
    ;
    for (int64_t v146 = v74; v146 < ((int64_t) ((uint64_t) ((int64_t) ((uint64_t) v17 + (uint64_t) v41) / v27) * (uint64_t) v32)); v146 += v40) {
      // pto: %40, %41
      ;
      int64_t v147 = (int64_t) ((uint64_t) (v146 / v32) * (uint64_t) v27);
      // pto: %42
      ;
      int64_t v148 = v146 % v32;
      // pto: %43, %44, %45
      ;
      int64_t v149 = v148 < v38 ? (int64_t) ((uint64_t) v148 + (uint64_t) v32) : v148;
      // pto: %46
      ;
      int64_t v150 = (int64_t) ((uint64_t) v149 * (uint64_t) v30);
      // pto: %47
      ;
      int64_t v151 = (int64_t) ((uint64_t) v17 - (uint64_t) v147);
      // pto: %48
      ;
      int64_t v152 = v151 < v27 ? v151 : v27;
      // pto: %wide_first_input__tile
      ;
      Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v153 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v152, v31);
      // pto: %wide_first_input__tile
      ;
      uint64_t v154 = (uint64_t) v23;
      TASSIGN(v153, v154);
      // pto: %49
      ;
      int64_t v155 = v147 < v38 ? v38 : v147;
      // pto: %50
      ;
      const int64_t v156 = 0;
      // pto: %50
      ;
      __gm__ int8_t* v157 = PTOAS__GLOBAL_TENSOR_DATA(v54);
      // pto: %50
      ;
      const int64_t v158 = 1;
      // pto: %50
      ;
      const int64_t v159 = 1;
      // pto: %50
      ;
      const int64_t v160 = 1;
      // pto: %50
      ;
      int64_t v161 = v152 * v36;
      // pto: %50
      ;
      int64_t v162 = v160 * v161;
      // pto: %50
      ;
      pto::Shape<1, 1, 1, -1, 512> v163 = pto::Shape<1, 1, 1, -1, 512>(v158, v159, v160, v152, v31);
      // pto: %50
      ;
      pto::Stride<-1, -1, -1, -1, -1> v164 = pto::Stride<-1, -1, -1, -1, -1>(v159 * v162, v162, v161, v36, v26);
      // pto: %50
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v165 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v157 + (v156 + v155 * v36 + v38 * v26), v163, v164);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v153, v165);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      // pto: %wide_first_weight__tile
      ;
      Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v166 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v31, v30);
      // pto: %wide_first_weight__tile
      ;
      uint64_t v167 = (uint64_t) v22;
      TASSIGN(v166, v167);
      // pto: %51
      ;
      int64_t v168 = v150 / v32;
      // pto: %52
      ;
      int64_t v169 = v168 < v38 ? v38 : v168;
      // pto: %53
      ;
      __gm__ int8_t* v170 = PTOAS__GLOBAL_TENSOR_DATA(v45);
      // pto: %53
      ;
      const int64_t v171 = 0;
      // pto: %53
      ;
      const int64_t v172 = 262144;
      // pto: %53
      ;
      pto::Shape<1, 4, 32, 16, 32> v173 = pto::Shape<1, 4, 32, 16, 32>();
      // pto: %53
      ;
      pto::Stride<33554432, 262144, 512, 32, 1> v174 = pto::Stride<33554432, 262144, 512, 32, 1>();
      // pto: %53
      ;
      GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v175 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v170 + (v171 + v169 * v172), v173, v174);
      TLOAD(v166, v175);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %wide_b_acc__tile_l0_init_storage
      ;
      Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v176 = Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v27, v30);
      // pto: %wide_b_acc__tile_l0_init_storage
      ;
      uint64_t v177 = (uint64_t) v22;
      TASSIGN(v176, v177);
      v176.SetValidShape(v152, v30);
      // pto: %wide_b_acc__tile_l0_a
      ;
      Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v178 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v152, v28);
      // pto: %wide_b_acc__tile_l0_a
      ;
      uint64_t v179 = (uint64_t) v22;
      TASSIGN(v178, v179);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      uint16_t v180 = static_cast<uint16_t>(v38);
      uint16_t v181 = static_cast<uint16_t>(v38);
      TEXTRACT(v178, v153, v180, v181);
      // pto: %wide_b_acc__tile_l0_b
      ;
      Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v182 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v28, v30);
      // pto: %wide_b_acc__tile_l0_b
      ;
      uint64_t v183 = (uint64_t) v22;
      TASSIGN(v182, v183);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      uint16_t v184 = static_cast<uint16_t>(v38);
      uint16_t v185 = static_cast<uint16_t>(v38);
      TEXTRACT(v182, v166, v184, v185);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      // pto: %3
      ;
      Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v186 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v152, v28);
      // pto: %3
      ;
      uint64_t v187 = (uint64_t) v24;
      TASSIGN(v186, v187);
      uint16_t v188 = static_cast<uint16_t>(v38);
      uint16_t v189 = static_cast<uint16_t>(v28);
      TEXTRACT(v186, v153, v188, v189);
      // pto: %4
      ;
      Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v190 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v28, v30);
      // pto: %4
      ;
      uint64_t v191 = (uint64_t) v25;
      TASSIGN(v190, v191);
      uint16_t v192 = static_cast<uint16_t>(v28);
      uint16_t v193 = static_cast<uint16_t>(v38);
      TEXTRACT(v190, v166, v192, v193);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
      TMATMUL(v176, v178, v182);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      TMATMUL_ACC(v176, v176, v186, v190);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      for (int64_t v194 = v26; v194 < v29; v194 += v26) {
        // pto: %54
        ;
        int64_t v195 = (int64_t) ((uint64_t) v194 * (uint64_t) v31);
        // pto: %wide_b_input__tile
        ;
        Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v196 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v152, v31);
        // pto: %wide_b_input__tile
        ;
        uint64_t v197 = (uint64_t) v23;
        TASSIGN(v196, v197);
        // pto: %56
        ;
        int64_t v198 = v195 < v38 ? v38 : v195;
        // pto: %57
        ;
        const int64_t v199 = 0;
        // pto: %57
        ;
        __gm__ int8_t* v200 = PTOAS__GLOBAL_TENSOR_DATA(v54);
        // pto: %57
        ;
        const int64_t v201 = 1;
        // pto: %57
        ;
        const int64_t v202 = 1;
        // pto: %57
        ;
        const int64_t v203 = 1;
        // pto: %57
        ;
        int64_t v204 = v152 * v36;
        // pto: %57
        ;
        int64_t v205 = v203 * v204;
        // pto: %57
        ;
        pto::Shape<1, 1, 1, -1, 512> v206 = pto::Shape<1, 1, 1, -1, 512>(v201, v202, v203, v152, v31);
        // pto: %57
        ;
        pto::Stride<-1, -1, -1, -1, -1> v207 = pto::Stride<-1, -1, -1, -1, -1>(v202 * v205, v205, v204, v36, v26);
        // pto: %57
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v208 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v200 + (v199 + v155 * v36 + v198 * v26), v206, v207);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        TLOAD(v196, v208);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
        // pto: %wide_b_weight__tile
        ;
        Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v209 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v31, v30);
        // pto: %wide_b_weight__tile
        ;
        uint64_t v210 = (uint64_t) v22;
        TASSIGN(v209, v210);
        // pto: %60
        ;
        int64_t v211 = v195 / v29;
        // pto: %61
        ;
        int64_t v212 = v211 < v38 ? v38 : v211;
        // pto: %62
        ;
        __gm__ int8_t* v213 = PTOAS__GLOBAL_TENSOR_DATA(v45);
        // pto: %62
        ;
        const int64_t v214 = 0;
        // pto: %62
        ;
        const int64_t v215 = 262144;
        // pto: %62
        ;
        const int64_t v216 = 512;
        // pto: %62
        ;
        pto::Shape<1, 4, 32, 16, 32> v217 = pto::Shape<1, 4, 32, 16, 32>();
        // pto: %62
        ;
        pto::Stride<33554432, 262144, 512, 32, 1> v218 = pto::Stride<33554432, 262144, 512, 32, 1>();
        // pto: %62
        ;
        GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v219 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v213 + (v214 + v169 * v215 + v212 * v216), v217, v218);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        TLOAD(v209, v219);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        // pto: %6
        ;
        Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v220 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v152, v28);
        // pto: %6
        ;
        uint64_t v221 = (uint64_t) v22;
        TASSIGN(v220, v221);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        uint16_t v222 = static_cast<uint16_t>(v38);
        uint16_t v223 = static_cast<uint16_t>(v38);
        TEXTRACT(v220, v196, v222, v223);
        // pto: %7
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v224 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v28, v30);
        // pto: %7
        ;
        uint64_t v225 = (uint64_t) v22;
        TASSIGN(v224, v225);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        uint16_t v226 = static_cast<uint16_t>(v38);
        uint16_t v227 = static_cast<uint16_t>(v38);
        TEXTRACT(v224, v209, v226, v227);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        // pto: %8
        ;
        Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v228 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v152, v28);
        // pto: %8
        ;
        uint64_t v229 = (uint64_t) v24;
        TASSIGN(v228, v229);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        uint16_t v230 = static_cast<uint16_t>(v38);
        uint16_t v231 = static_cast<uint16_t>(v28);
        TEXTRACT(v228, v196, v230, v231);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        // pto: %9
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v232 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v28, v30);
        // pto: %9
        ;
        uint64_t v233 = (uint64_t) v25;
        TASSIGN(v232, v233);
        uint16_t v234 = static_cast<uint16_t>(v28);
        uint16_t v235 = static_cast<uint16_t>(v38);
        TEXTRACT(v232, v209, v234, v235);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v176, v176, v220, v224);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        TMATMUL_ACC(v176, v176, v228, v232);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      // pto: %64
      ;
      int64_t v236 = v150 < v38 ? v38 : v150;
      // pto: %65
      ;
      const int64_t v237 = 0;
      // pto: %65
      ;
      __gm__ int32_t* v238 = PTOAS__GLOBAL_TENSOR_DATA(v63);
      // pto: %65
      ;
      const int64_t v239 = 1;
      // pto: %65
      ;
      const int64_t v240 = 1;
      // pto: %65
      ;
      const int64_t v241 = 1;
      // pto: %65
      ;
      int64_t v242 = v152 * v35;
      // pto: %65
      ;
      int64_t v243 = v241 * v242;
      // pto: %65
      ;
      pto::Shape<1, 1, 1, -1, 128> v244 = pto::Shape<1, 1, 1, -1, 128>(v239, v240, v241, v152, v30);
      // pto: %65
      ;
      pto::Stride<-1, -1, -1, -1, -1> v245 = pto::Stride<-1, -1, -1, -1, -1>(v240 * v243, v243, v242, v35, v26);
      // pto: %65
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v246 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v238 + (v237 + v155 * v35 + v236 * v26), v244, v245);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      TSTORE(v246, v176);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
    };
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %67
  int64_t v247 = (int64_t) ((uint64_t) v75 + (uint64_t) v42);
  // pto: %68
  int64_t v248 = v247 < v38 ? v38 : v247;
  // pto: %signals__ssa_v1_signal_pview
  __gm__ int32_t* v249 = PTOAS__GLOBAL_TENSOR_DATA(v73);
  // pto: %signals__ssa_v1_signal_pview
  const int64_t v250 = 0;
  // pto: %signals__ssa_v1_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v251 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v252 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v253 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v249 + (v250 + v248), v251, v252);
  pto::comm::NotifyOp v254 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v253, v83, v254);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void vector_post(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ bfloat16_t* v6, __gm__ int8_t* v7, __gm__ float* v8, __gm__ bfloat16_t* v9, __gm__ bfloat16_t* v10, __gm__ float* v11, __gm__ float* v12, __gm__ bfloat16_t* v13, __gm__ float* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21, int32_t v22) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v23 = 0;
  // pto: %c65536_i64
  const int64_t v24 = 65536;
  // pto: %c81920_i64
  const int64_t v25 = 81920;
  // pto: %c32768_i64
  const int64_t v26 = 32768;
  // pto: %c98304_i64
  const int64_t v27 = 98304;
  // pto: %c114688_i64
  const int64_t v28 = 114688;
  // pto: %c131072_i64
  const int64_t v29 = 131072;
  // pto: %c147456_i64
  const int64_t v30 = 147456;
  // pto: %c155648_i64
  const int64_t v31 = 155648;
  // pto: %c1_index
  const int64_t v32 = 1;
  // pto: %c8_index
  const int64_t v33 = 8;
  // pto: %c16_index
  const int64_t v34 = 16;
  // pto: %c128_index
  const int64_t v35 = 128;
  // pto: %c512_index
  const int64_t v36 = 512;
  // pto: %c4096_index
  const int64_t v37 = 4096;
  // pto: %c8192_index
  const int64_t v38 = 8192;
  // pto: %c16384_index
  const int64_t v39 = 16384;
  // pto: %c4_index
  const int64_t v40 = 4;
  // pto: %c55296_index
  const int64_t v41 = 55296;
  // pto: %c2_index
  const int64_t v42 = 2;
  // pto: %c24_index
  const int64_t v43 = 24;
  // pto: %c0_index
  const int64_t v44 = 0;
  // pto: %c15_index
  const int64_t v45 = 15;
  // pto: %c36864_index
  const int64_t v46 = 36864;
  // pto: %c48_index
  const int64_t v47 = 48;
  // pto: %cst_33
  const float v48 = 1.0f;
  // pto: %c46080_index
  const int64_t v49 = 46080;
  // pto: %c72_index
  const int64_t v50 = 72;
  // pto: %c3_index
  const int64_t v51 = 3;
  // pto: %c12_index
  const int64_t v52 = 12;
  // pto: %c5_index
  const int64_t v53 = 5;
  // pto: %c9_index
  const int64_t v54 = 9;
  // pto: %c13_index
  const int64_t v55 = 13;
  // pto: %c6_index
  const int64_t v56 = 6;
  // pto: %c10_index
  const int64_t v57 = 10;
  // pto: %c14_index
  const int64_t v58 = 14;
  // pto: %c7_index
  const int64_t v59 = 7;
  // pto: %c11_index
  const int64_t v60 = 11;
  // pto: %c12288_index
  const int64_t v61 = 12288;
  // pto: %cn1_index
  const int64_t v62 = -1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v63 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v67 = v37 * v32;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v68 = v66 * v67;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v69 = v65 * v68;
  // pto: %wo_b_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v70 = pto::Shape<1, 1, 1, 1, -1>(v63, v64, v65, v66, v37);
  // pto: %wo_b_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v71 = pto::Stride<-1, -1, -1, -1, -1>(v64 * v69, v69, v68, v67, v32);
  // pto: %wo_b_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v72 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v70, v71);
  // pto: %token_scale__ssa_v6_view
  const int64_t v73 = 1;
  // pto: %token_scale__ssa_v6_view
  const int64_t v74 = 1;
  // pto: %token_scale__ssa_v6_view
  const int64_t v75 = 1;
  // pto: %token_scale__ssa_v6_view
  int64_t v76 = (int64_t) v17;
  // pto: %token_scale__ssa_v6_view
  int64_t v77 = v76 * v32;
  // pto: %token_scale__ssa_v6_view
  int64_t v78 = v75 * v77;
  // pto: %token_scale__ssa_v6_view
  pto::Shape<1, 1, 1, -1, -1> v79 = pto::Shape<1, 1, 1, -1, -1>(v73, v74, v75, v76, v32);
  // pto: %token_scale__ssa_v6_view
  pto::Stride<-1, -1, -1, -1, -1> v80 = pto::Stride<-1, -1, -1, -1, -1>(v74 * v78, v78, v77, v32, (int64_t) v17);
  // pto: %token_scale__ssa_v6_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v81 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v8, v79, v80);
  // pto: %attended__ssa_v6_view
  const int64_t v82 = 1;
  // pto: %attended__ssa_v6_view
  const int64_t v83 = 1;
  // pto: %attended__ssa_v6_view
  const int64_t v84 = 1;
  // pto: %attended__ssa_v6_view
  int64_t v85 = (int64_t) v17;
  // pto: %attended__ssa_v6_view
  int64_t v86 = v85 * v37;
  // pto: %attended__ssa_v6_view
  int64_t v87 = v84 * v86;
  // pto: %attended__ssa_v6_view
  pto::Shape<1, 1, 1, -1, -1> v88 = pto::Shape<1, 1, 1, -1, -1>(v82, v83, v84, v85, v37);
  // pto: %attended__ssa_v6_view
  pto::Stride<-1, -1, -1, -1, -1> v89 = pto::Stride<-1, -1, -1, -1, -1>(v83 * v87, v87, v86, v37, v32);
  // pto: %attended__ssa_v6_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v90 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v88, v89);
  // pto: %residual__ssa_v0_view
  const int64_t v91 = 1;
  // pto: %residual__ssa_v0_view
  const int64_t v92 = 1;
  // pto: %residual__ssa_v0_view
  const int64_t v93 = 1;
  // pto: %residual__ssa_v0_view
  int64_t v94 = (int64_t) v17;
  // pto: %residual__ssa_v0_view
  int64_t v95 = v94 * v39;
  // pto: %residual__ssa_v0_view
  int64_t v96 = v93 * v95;
  // pto: %residual__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v97 = pto::Shape<1, 1, 1, -1, -1>(v91, v92, v93, v94, v39);
  // pto: %residual__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v98 = pto::Stride<-1, -1, -1, -1, -1>(v92 * v96, v96, v95, v39, v32);
  // pto: %residual__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v99 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v10, v97, v98);
  // pto: %output__ssa_v6_view
  const int64_t v100 = 1;
  // pto: %output__ssa_v6_view
  const int64_t v101 = 1;
  // pto: %output__ssa_v6_view
  const int64_t v102 = 1;
  // pto: %output__ssa_v6_view
  int64_t v103 = (int64_t) v17;
  // pto: %output__ssa_v6_view
  int64_t v104 = v103 * v39;
  // pto: %output__ssa_v6_view
  int64_t v105 = v102 * v104;
  // pto: %output__ssa_v6_view
  pto::Shape<1, 1, 1, -1, -1> v106 = pto::Shape<1, 1, 1, -1, -1>(v100, v101, v102, v103, v39);
  // pto: %output__ssa_v6_view
  pto::Stride<-1, -1, -1, -1, -1> v107 = pto::Stride<-1, -1, -1, -1, -1>(v101 * v105, v105, v104, v39, v32);
  // pto: %output__ssa_v6_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v108 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v106, v107);
  // pto: %integer_accum__ssa_v6_view
  const int64_t v109 = 1;
  // pto: %integer_accum__ssa_v6_view
  const int64_t v110 = 1;
  // pto: %integer_accum__ssa_v6_view
  const int64_t v111 = 1;
  // pto: %integer_accum__ssa_v6_view
  int64_t v112 = (int64_t) v19;
  // pto: %integer_accum__ssa_v6_view
  int64_t v113 = v112 * v37;
  // pto: %integer_accum__ssa_v6_view
  int64_t v114 = v111 * v113;
  // pto: %integer_accum__ssa_v6_view
  pto::Shape<1, 1, 1, -1, -1> v115 = pto::Shape<1, 1, 1, -1, -1>(v109, v110, v111, v112, v37);
  // pto: %integer_accum__ssa_v6_view
  pto::Stride<-1, -1, -1, -1, -1> v116 = pto::Stride<-1, -1, -1, -1, -1>(v110 * v114, v114, v113, v37, v32);
  // pto: %integer_accum__ssa_v6_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v117 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v115, v116);
  // pto: %signals__ssa_v6_view
  const int64_t v118 = 1;
  // pto: %signals__ssa_v6_view
  const int64_t v119 = 1;
  // pto: %signals__ssa_v6_view
  const int64_t v120 = 1;
  // pto: %signals__ssa_v6_view
  const int64_t v121 = 1;
  // pto: %signals__ssa_v6_view
  int64_t v122 = v41 * v32;
  // pto: %signals__ssa_v6_view
  int64_t v123 = v121 * v122;
  // pto: %signals__ssa_v6_view
  int64_t v124 = v120 * v123;
  // pto: %signals__ssa_v6_view
  pto::Shape<1, 1, 1, 1, -1> v125 = pto::Shape<1, 1, 1, 1, -1>(v118, v119, v120, v121, v41);
  // pto: %signals__ssa_v6_view
  pto::Stride<-1, -1, -1, -1, -1> v126 = pto::Stride<-1, -1, -1, -1, -1>(v119 * v124, v124, v123, v122, v32);
  // pto: %signals__ssa_v6_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v127 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v125, v126);
  // pto: %t__tmp_v0, %145, %146, %t__tmp_v1
  int64_t v128 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v20) * (uint64_t) v42) + (uint64_t) ((int64_t) v22));
  // pto: %147, %148
  int64_t v129 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v128 + (uint64_t) v43) * (uint64_t) v35);
  // pto: %149
  int64_t v130 = v129 < v44 ? v44 : v129;
  // pto: %signals__ssa_v6_pview
  __gm__ int32_t* v131 = PTOAS__GLOBAL_TENSOR_DATA(v127);
  // pto: %signals__ssa_v6_pview
  const int64_t v132 = 0;
  // pto: %signals__ssa_v6_pview
  pto::Shape<1, 1, 1, 1, 1> v133 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v6_pview
  pto::Stride<1, 1, 1, 1, 1> v134 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v6_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v135 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v131 + (v132 + v130), v133, v134);
  __gm__ int32_t* v136 = PTOAS__GLOBAL_TENSOR_DATA(v135);
  PTOAS__DCCI_SINGLE_CACHE_LINE(v136);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  // pto: %generation_inline12__tile
  int32_t v137 = (v16)[v129];
  for (int64_t v138 = v44; v138 < v43; v138 += v32) {
    // pto: %152, %153
    ;
    int64_t v139 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v138 * (uint64_t) v35) + (uint64_t) v46);
    // pto: %154
    ;
    int64_t v140 = v139 < v44 ? v44 : v139;
    // pto: %signals__ssa_v1_signal_pview
    ;
    __gm__ int32_t* v141 = PTOAS__GLOBAL_TENSOR_DATA(v127);
    // pto: %signals__ssa_v1_signal_pview
    ;
    const int64_t v142 = 0;
    // pto: %signals__ssa_v1_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v143 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals__ssa_v1_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v144 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals__ssa_v1_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v145 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v141 + (v142 + v140), v143, v144);
    pto::comm::WaitCmp v146 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v145, v137, v146);
  }
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %150, %151, %155
  for (int64_t v147 = v128; v147 < ((int64_t) ((uint64_t) ((int64_t) ((uint64_t) v17 + (uint64_t) v45) / v34) * (uint64_t) v33)); v147 += v47) {
    // pto: %156, %157
    ;
    int64_t v148 = (int64_t) ((uint64_t) (v147 / v33) * (uint64_t) v34);
    // pto: %158
    ;
    int64_t v149 = v147 % v33;
    // pto: %159, %160, %161
    ;
    int64_t v150 = v149 < v44 ? (int64_t) ((uint64_t) v149 + (uint64_t) v33) : v149;
    // pto: %162
    ;
    int64_t v151 = (int64_t) ((uint64_t) v150 * (uint64_t) v36);
    // pto: %163
    ;
    int64_t v152 = (int64_t) ((uint64_t) v17 - (uint64_t) v148);
    // pto: %164
    ;
    int64_t v153 = v152 < v34 ? v152 : v34;
    // pto: %ob_integer__ssa_v0
    ;
    Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v154 = Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v153, v36);
    // pto: %ob_integer__ssa_v0
    ;
    uint64_t v155 = (uint64_t) v23;
    TASSIGN(v154, v155);
    // pto: %165
    ;
    int64_t v156 = v148 < v44 ? v44 : v148;
    // pto: %166
    ;
    int64_t v157 = v151 < v44 ? v44 : v151;
    // pto: %integer_accum__ssa_v6_pview
    ;
    const int64_t v158 = 0;
    // pto: %integer_accum__ssa_v6_pview
    ;
    __gm__ int32_t* v159 = PTOAS__GLOBAL_TENSOR_DATA(v117);
    // pto: %integer_accum__ssa_v6_pview
    ;
    const int64_t v160 = 1;
    // pto: %integer_accum__ssa_v6_pview
    ;
    const int64_t v161 = 1;
    // pto: %integer_accum__ssa_v6_pview
    ;
    const int64_t v162 = 1;
    // pto: %integer_accum__ssa_v6_pview
    ;
    int64_t v163 = v153 * v37;
    // pto: %integer_accum__ssa_v6_pview
    ;
    int64_t v164 = v162 * v163;
    // pto: %integer_accum__ssa_v6_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v165 = pto::Shape<1, 1, 1, -1, 512>(v160, v161, v162, v153, v36);
    // pto: %integer_accum__ssa_v6_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v166 = pto::Stride<-1, -1, -1, -1, -1>(v161 * v164, v164, v163, v37, v32);
    // pto: %integer_accum__ssa_v6_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v167 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v159 + (v158 + v156 * v37 + v157 * v32), v165, v166);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v154, v167);
    // pto: %t__tmp_v2
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v168 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v36);
    // pto: %t__tmp_v2
    ;
    uint64_t v169 = (uint64_t) v24;
    TASSIGN(v168, v169);
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    __gm__ float* v170 = PTOAS__GLOBAL_TENSOR_DATA(v72);
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    const int64_t v171 = 0;
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 512> v172 = pto::Shape<1, 1, 1, 1, 512>();
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    pto::Stride<512, 512, 512, 512, 1> v173 = pto::Stride<512, 512, 512, 512, 1>();
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v174 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v170 + (v171 + v157), v172, v173);
    TLOAD(v168, v174);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %channel__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v36);
    // pto: %channel__ssa_v0
    ;
    uint64_t v176 = (uint64_t) v24;
    TASSIGN(v175, v176);
    // pto: %scale__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v153, v32);
    // pto: %scale__ssa_v0
    ;
    uint64_t v178 = (uint64_t) v25;
    TASSIGN(v177, v178);
    // pto: %token_scale__ssa_v6_pview
    ;
    int64_t v179 = (int64_t) v17;
    // pto: %token_scale__ssa_v6_pview
    ;
    const int64_t v180 = 0;
    // pto: %token_scale__ssa_v6_pview
    ;
    __gm__ float* v181 = PTOAS__GLOBAL_TENSOR_DATA(v81);
    // pto: %token_scale__ssa_v6_pview
    ;
    const int64_t v182 = 1;
    // pto: %token_scale__ssa_v6_pview
    ;
    const int64_t v183 = 1;
    // pto: %token_scale__ssa_v6_pview
    ;
    const int64_t v184 = 1;
    // pto: %token_scale__ssa_v6_pview
    ;
    int64_t v185 = v153 * v32;
    // pto: %token_scale__ssa_v6_pview
    ;
    int64_t v186 = v184 * v185;
    // pto: %token_scale__ssa_v6_pview
    ;
    pto::Shape<1, 1, 1, -1, 1> v187 = pto::Shape<1, 1, 1, -1, 1>(v182, v183, v184, v153, v32);
    // pto: %token_scale__ssa_v6_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v188 = pto::Stride<-1, -1, -1, -1, -1>(v183 * v186, v186, v185, v32, v179);
    // pto: %token_scale__ssa_v6_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v189 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v181 + (v180 + v156 * v32 + v44 * v179), v187, v188);
    TLOAD(v177, v189);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %coefficient_one__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v190 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v36);
    // pto: %coefficient_one__ssa_v0
    ;
    uint64_t v191 = (uint64_t) v26;
    TASSIGN(v190, v191);
    TEXPANDS(v190, v48);
    // pto: %coefficient_channel__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v192 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v36);
    // pto: %coefficient_channel__ssa_v0
    ;
    uint64_t v193 = (uint64_t) v26;
    TASSIGN(v192, v193);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TCOLEXPANDMUL(v192, v190, v175);
    // pto: %coefficient__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v194 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v36);
    // pto: %coefficient__ssa_v0
    ;
    uint64_t v195 = (uint64_t) v26;
    TASSIGN(v194, v195);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    TROWEXPANDMUL(v194, v192, v177);
    // pto: %t__tmp_v3
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v196 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v153, v36);
    // pto: %t__tmp_v3
    ;
    uint64_t v197 = (uint64_t) v23;
    TASSIGN(v196, v197);
    RoundMode v198 = RoundMode::CAST_ROUND;
    SaturationMode v199 = SaturationMode::ON;
    TCVT(v196, v154, v198, v199);
    // pto: %ob_scaled__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v200 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v153, v36);
    // pto: %ob_scaled__ssa_v0
    ;
    uint64_t v201 = (uint64_t) v23;
    TASSIGN(v200, v201);
    pipe_barrier(PIPE_V);
    TMUL(v200, v196, v194);
    // pto: %t__tmp_v4
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v202 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v153, v36);
    // pto: %t__tmp_v4
    ;
    uint64_t v203 = (uint64_t) v23;
    TASSIGN(v202, v203);
    pipe_barrier(PIPE_V);
    RoundMode v204 = RoundMode::CAST_RINT;
    SaturationMode v205 = SaturationMode::ON;
    TCVT(v202, v200, v204, v205);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %attended__ssa_v6_pview
    ;
    const int64_t v206 = 0;
    // pto: %attended__ssa_v6_pview
    ;
    __gm__ bfloat16_t* v207 = PTOAS__GLOBAL_TENSOR_DATA(v90);
    // pto: %attended__ssa_v6_pview
    ;
    const int64_t v208 = 1;
    // pto: %attended__ssa_v6_pview
    ;
    const int64_t v209 = 1;
    // pto: %attended__ssa_v6_pview
    ;
    const int64_t v210 = 1;
    // pto: %attended__ssa_v6_pview
    ;
    int64_t v211 = v153 * v37;
    // pto: %attended__ssa_v6_pview
    ;
    int64_t v212 = v210 * v211;
    // pto: %attended__ssa_v6_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v213 = pto::Shape<1, 1, 1, -1, 512>(v208, v209, v210, v153, v36);
    // pto: %attended__ssa_v6_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v214 = pto::Stride<-1, -1, -1, -1, -1>(v209 * v212, v212, v211, v37, v32);
    // pto: %attended__ssa_v6_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v215 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v207 + (v206 + v156 * v37 + v157 * v32), v213, v214);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v215, v202);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %172
  int64_t v216 = (int64_t) ((uint64_t) v129 + (uint64_t) v49);
  // pto: %173
  int64_t v217 = v216 < v44 ? v44 : v216;
  // pto: %signals_v1__ssa_v0_signal_pview
  __gm__ int32_t* v218 = PTOAS__GLOBAL_TENSOR_DATA(v127);
  // pto: %signals_v1__ssa_v0_signal_pview
  const int64_t v219 = 0;
  // pto: %signals_v1__ssa_v0_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v220 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals_v1__ssa_v0_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v221 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals_v1__ssa_v0_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v222 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v218 + (v219 + v217), v220, v221);
  pto::comm::NotifyOp v223 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v222, v137, v223);
  for (int64_t v224 = v43; v224 < v50; v224 += v32) {
    // pto: %174, %175
    ;
    int64_t v225 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v224 * (uint64_t) v35) + (uint64_t) v49);
    // pto: %176
    ;
    int64_t v226 = v225 < v44 ? v44 : v225;
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v227 = PTOAS__GLOBAL_TENSOR_DATA(v127);
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    const int64_t v228 = 0;
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v229 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v230 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v231 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v227 + (v228 + v226), v229, v230);
    pto::comm::WaitCmp v232 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v231, v137, v232);
  }
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %177, %178
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  for (int64_t v233 = v128; v233 < ((int64_t) ((uint64_t) v17 + (uint64_t) v51) / v40); v233 += v47) {
    // pto: %179
    ;
    int64_t v234 = (int64_t) ((uint64_t) v233 * (uint64_t) v40);
    // pto: %180
    ;
    int64_t v235 = (int64_t) ((uint64_t) v234 + (uint64_t) v40);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    for (int64_t v236 = v234; v236 < v235; v236 += v42) {
      // pto: %181
      ;
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      if (v236 < v17) {
        // pto: %flat_offset_mul
        ;
        int64_t v237 = (int64_t) ((uint64_t) v236 * (uint64_t) v40);
        // pto: %post_scalar__tile
        ;
        float v238 = (v11)[v237];
        // pto: %182
        ;
        int64_t v239 = (int64_t) ((uint64_t) v236 * (uint64_t) v34);
        // pto: %comb_scalar_0__tile
        ;
        float v240 = (v12)[v239];
        // pto: %185, %comb_scalar_1__tile
        ;
        float v241 = (v12)[(int64_t) ((uint64_t) v239 + (uint64_t) v40)];
        // pto: %187, %comb_scalar_2__tile
        ;
        float v242 = (v12)[(int64_t) ((uint64_t) v239 + (uint64_t) v33)];
        // pto: %189, %comb_scalar_3__tile
        ;
        float v243 = (v12)[(int64_t) ((uint64_t) v239 + (uint64_t) v52)];
        // pto: %192, %190
        ;
        float v244 = (v11)[(int64_t) ((uint64_t) v237 + (uint64_t) v32)];
        // pto: %195, %193
        ;
        float v245 = (v12)[(int64_t) ((uint64_t) v239 + (uint64_t) v32)];
        // pto: %198, %196
        ;
        float v246 = (v12)[(int64_t) ((uint64_t) v239 + (uint64_t) v53)];
        // pto: %201, %199
        ;
        float v247 = (v12)[(int64_t) ((uint64_t) v239 + (uint64_t) v54)];
        // pto: %204, %202
        ;
        float v248 = (v12)[(int64_t) ((uint64_t) v239 + (uint64_t) v55)];
        // pto: %207, %205
        ;
        float v249 = (v11)[(int64_t) ((uint64_t) v237 + (uint64_t) v42)];
        // pto: %210, %208
        ;
        float v250 = (v12)[(int64_t) ((uint64_t) v239 + (uint64_t) v42)];
        // pto: %213, %211
        ;
        float v251 = (v12)[(int64_t) ((uint64_t) v239 + (uint64_t) v56)];
        // pto: %216, %214
        ;
        float v252 = (v12)[(int64_t) ((uint64_t) v239 + (uint64_t) v57)];
        // pto: %219, %217
        ;
        float v253 = (v12)[(int64_t) ((uint64_t) v239 + (uint64_t) v58)];
        // pto: %222, %220
        ;
        float v254 = (v11)[(int64_t) ((uint64_t) v237 + (uint64_t) v51)];
        // pto: %225, %223
        ;
        float v255 = (v12)[(int64_t) ((uint64_t) v239 + (uint64_t) v51)];
        // pto: %228, %226
        ;
        float v256 = (v12)[(int64_t) ((uint64_t) v239 + (uint64_t) v59)];
        // pto: %231, %229
        ;
        float v257 = (v12)[(int64_t) ((uint64_t) v239 + (uint64_t) v60)];
        // pto: %234, %232
        ;
        float v258 = (v12)[(int64_t) ((uint64_t) v239 + (uint64_t) v45)];
        // pto: %x_block__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v259 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %x_block__tile
        ;
        uint64_t v260 = (uint64_t) v26;
        TASSIGN(v259, v260);
        // pto: %235
        ;
        int64_t v261 = v236 < v44 ? v44 : v236;
        // pto: %x__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v262 = PTOAS__GLOBAL_TENSOR_DATA(v90);
        // pto: %x__ssa_v0_pview
        ;
        const int64_t v263 = 0;
        // pto: %x__ssa_v0_pview
        ;
        const int64_t v264 = 4096;
        // pto: %x__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v265 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %x__ssa_v0_pview
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v266 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %x__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v267 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v262 + (v263 + v261 * v264), v265, v266);
        TLOAD(v259, v267);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %236
        ;
        int64_t v268 = (int64_t) ((uint64_t) v17 - (uint64_t) v236);
        // pto: %237
        ;
        int64_t v269 = v268 < v44 ? v44 : v268;
        // pto: %238
        ;
        int64_t v270 = v269 < v32 ? v269 : v32;
        // pto: %t__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v271 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %t__tile
        ;
        uint64_t v272 = (uint64_t) v24;
        TASSIGN(v271, v272);
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v273 = 0;
        // pto: %residual_flat__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v274 = PTOAS__GLOBAL_TENSOR_DATA(v99);
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v275 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v276 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v277 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        int64_t v278 = v270 * v39;
        // pto: %residual_flat__ssa_v0_pview
        ;
        int64_t v279 = v277 * v278;
        // pto: %residual_flat__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 4096> v280 = pto::Shape<1, 1, 1, -1, 4096>(v275, v276, v277, v270, v37);
        // pto: %residual_flat__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v281 = pto::Stride<-1, -1, -1, -1, -1>(v276 * v279, v279, v278, v39, v32);
        // pto: %residual_flat__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v282 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v274 + (v273 + v261 * v39 + v44 * v32), v280, v281);
        TLOAD(v271, v282);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        // pto: %0
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v283 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %0
        ;
        uint64_t v284 = (uint64_t) v25;
        TASSIGN(v283, v284);
        // pto: %250
        ;
        const int64_t v285 = 0;
        // pto: %250
        ;
        __gm__ bfloat16_t* v286 = PTOAS__GLOBAL_TENSOR_DATA(v99);
        // pto: %250
        ;
        const int64_t v287 = 1;
        // pto: %250
        ;
        const int64_t v288 = 1;
        // pto: %250
        ;
        const int64_t v289 = 1;
        // pto: %250
        ;
        int64_t v290 = v270 * v39;
        // pto: %250
        ;
        int64_t v291 = v289 * v290;
        // pto: %250
        ;
        pto::Shape<1, 1, 1, -1, 4096> v292 = pto::Shape<1, 1, 1, -1, 4096>(v287, v288, v289, v270, v37);
        // pto: %250
        ;
        pto::Stride<-1, -1, -1, -1, -1> v293 = pto::Stride<-1, -1, -1, -1, -1>(v288 * v291, v291, v290, v39, v32);
        // pto: %250
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v294 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v286 + (v285 + v261 * v39 + v37 * v32), v292, v293);
        TLOAD(v283, v294);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        // pto: %1
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v295 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %1
        ;
        uint64_t v296 = (uint64_t) v27;
        TASSIGN(v295, v296);
        // pto: %258
        ;
        const int64_t v297 = 0;
        // pto: %258
        ;
        __gm__ bfloat16_t* v298 = PTOAS__GLOBAL_TENSOR_DATA(v99);
        // pto: %258
        ;
        const int64_t v299 = 1;
        // pto: %258
        ;
        const int64_t v300 = 1;
        // pto: %258
        ;
        const int64_t v301 = 1;
        // pto: %258
        ;
        int64_t v302 = v270 * v39;
        // pto: %258
        ;
        int64_t v303 = v301 * v302;
        // pto: %258
        ;
        pto::Shape<1, 1, 1, -1, 4096> v304 = pto::Shape<1, 1, 1, -1, 4096>(v299, v300, v301, v270, v37);
        // pto: %258
        ;
        pto::Stride<-1, -1, -1, -1, -1> v305 = pto::Stride<-1, -1, -1, -1, -1>(v300 * v303, v303, v302, v39, v32);
        // pto: %258
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v306 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v298 + (v297 + v261 * v39 + v38 * v32), v304, v305);
        TLOAD(v295, v306);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
        // pto: %2
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v307 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %2
        ;
        uint64_t v308 = (uint64_t) v28;
        TASSIGN(v307, v308);
        // pto: %266
        ;
        const int64_t v309 = 0;
        // pto: %266
        ;
        __gm__ bfloat16_t* v310 = PTOAS__GLOBAL_TENSOR_DATA(v99);
        // pto: %266
        ;
        const int64_t v311 = 1;
        // pto: %266
        ;
        const int64_t v312 = 1;
        // pto: %266
        ;
        const int64_t v313 = 1;
        // pto: %266
        ;
        int64_t v314 = v270 * v39;
        // pto: %266
        ;
        int64_t v315 = v313 * v314;
        // pto: %266
        ;
        pto::Shape<1, 1, 1, -1, 4096> v316 = pto::Shape<1, 1, 1, -1, 4096>(v311, v312, v313, v270, v37);
        // pto: %266
        ;
        pto::Stride<-1, -1, -1, -1, -1> v317 = pto::Stride<-1, -1, -1, -1, -1>(v312 * v315, v315, v314, v39, v32);
        // pto: %266
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v318 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v310 + (v309 + v261 * v39 + v61 * v32), v316, v317);
        TLOAD(v307, v318);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        // pto: %x_f32__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v319 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %x_f32__tile
        ;
        uint64_t v320 = (uint64_t) v23;
        TASSIGN(v319, v320);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v321 = RoundMode::CAST_ROUND;
        SaturationMode v322 = SaturationMode::ON;
        TCVT(v319, v259, v321, v322);
        // pto: %res_0__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v323 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %res_0__tile
        ;
        uint64_t v324 = (uint64_t) v26;
        TASSIGN(v323, v324);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        RoundMode v325 = RoundMode::CAST_ROUND;
        SaturationMode v326 = SaturationMode::ON;
        TCVT(v323, v271, v325, v326);
        // pto: %res_1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v327 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %res_1__tile
        ;
        uint64_t v328 = (uint64_t) v24;
        TASSIGN(v327, v328);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        RoundMode v329 = RoundMode::CAST_ROUND;
        SaturationMode v330 = SaturationMode::ON;
        TCVT(v327, v283, v329, v330);
        // pto: %res_2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v331 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %res_2__tile
        ;
        uint64_t v332 = (uint64_t) v25;
        TASSIGN(v331, v332);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
        RoundMode v333 = RoundMode::CAST_ROUND;
        SaturationMode v334 = SaturationMode::ON;
        TCVT(v331, v295, v333, v334);
        // pto: %res_3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v335 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %res_3__tile
        ;
        uint64_t v336 = (uint64_t) v27;
        TASSIGN(v335, v336);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        RoundMode v337 = RoundMode::CAST_ROUND;
        SaturationMode v338 = SaturationMode::ON;
        TCVT(v335, v307, v337, v338);
        // pto: %single_y__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v339 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %single_y__tile
        ;
        uint64_t v340 = (uint64_t) v28;
        TASSIGN(v339, v340);
        pipe_barrier(PIPE_V);
        TMULS(v339, v319, v238);
        // pto: %single_weighted_0__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v341 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %single_weighted_0__tile
        ;
        uint64_t v342 = (uint64_t) v29;
        TASSIGN(v341, v342);
        TMULS(v341, v323, v240);
        // pto: %single_y_v1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v343 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %single_y_v1__tile
        ;
        uint64_t v344 = (uint64_t) v28;
        TASSIGN(v343, v344);
        pipe_barrier(PIPE_V);
        TADD(v343, v339, v341);
        // pto: %single_weighted_1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v345 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %single_weighted_1__tile
        ;
        uint64_t v346 = (uint64_t) v29;
        TASSIGN(v345, v346);
        pipe_barrier(PIPE_V);
        TMULS(v345, v327, v241);
        // pto: %single_y_v2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v347 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %single_y_v2__tile
        ;
        uint64_t v348 = (uint64_t) v28;
        TASSIGN(v347, v348);
        pipe_barrier(PIPE_V);
        TADD(v347, v343, v345);
        // pto: %single_weighted_2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v349 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %single_weighted_2__tile
        ;
        uint64_t v350 = (uint64_t) v29;
        TASSIGN(v349, v350);
        pipe_barrier(PIPE_V);
        TMULS(v349, v331, v242);
        // pto: %single_y_v3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v351 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %single_y_v3__tile
        ;
        uint64_t v352 = (uint64_t) v28;
        TASSIGN(v351, v352);
        pipe_barrier(PIPE_V);
        TADD(v351, v347, v349);
        // pto: %single_weighted_3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v353 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %single_weighted_3__tile
        ;
        uint64_t v354 = (uint64_t) v29;
        TASSIGN(v353, v354);
        pipe_barrier(PIPE_V);
        TMULS(v353, v335, v243);
        // pto: %single_y_v4__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v355 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %single_y_v4__tile
        ;
        uint64_t v356 = (uint64_t) v28;
        TASSIGN(v355, v356);
        pipe_barrier(PIPE_V);
        TADD(v355, v351, v353);
        // pto: %single_result__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v357 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %single_result__tile
        ;
        uint64_t v358 = (uint64_t) v30;
        TASSIGN(v357, v358);
        pipe_barrier(PIPE_V);
        RoundMode v359 = RoundMode::CAST_RINT;
        SaturationMode v360 = SaturationMode::ON;
        TCVT(v357, v355, v359, v360);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        v357.SetValidShape(v32, v37);
        // pto: %4
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v361 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %4
        ;
        uint64_t v362 = (uint64_t) v28;
        TASSIGN(v361, v362);
        pipe_barrier(PIPE_V);
        TMULS(v361, v319, v244);
        // pto: %5
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v363 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %5
        ;
        uint64_t v364 = (uint64_t) v29;
        TASSIGN(v363, v364);
        TMULS(v363, v323, v245);
        // pto: %6
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v365 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %6
        ;
        uint64_t v366 = (uint64_t) v28;
        TASSIGN(v365, v366);
        pipe_barrier(PIPE_V);
        TADD(v365, v361, v363);
        // pto: %7
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v367 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %7
        ;
        uint64_t v368 = (uint64_t) v29;
        TASSIGN(v367, v368);
        pipe_barrier(PIPE_V);
        TMULS(v367, v327, v246);
        // pto: %8
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v369 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %8
        ;
        uint64_t v370 = (uint64_t) v28;
        TASSIGN(v369, v370);
        pipe_barrier(PIPE_V);
        TADD(v369, v365, v367);
        // pto: %9
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v371 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %9
        ;
        uint64_t v372 = (uint64_t) v29;
        TASSIGN(v371, v372);
        pipe_barrier(PIPE_V);
        TMULS(v371, v331, v247);
        // pto: %10
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v373 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %10
        ;
        uint64_t v374 = (uint64_t) v28;
        TASSIGN(v373, v374);
        pipe_barrier(PIPE_V);
        TADD(v373, v369, v371);
        // pto: %11
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v375 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %11
        ;
        uint64_t v376 = (uint64_t) v29;
        TASSIGN(v375, v376);
        pipe_barrier(PIPE_V);
        TMULS(v375, v335, v248);
        // pto: %12
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v377 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %12
        ;
        uint64_t v378 = (uint64_t) v28;
        TASSIGN(v377, v378);
        pipe_barrier(PIPE_V);
        TADD(v377, v373, v375);
        // pto: %13
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v379 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %13
        ;
        uint64_t v380 = (uint64_t) v31;
        TASSIGN(v379, v380);
        pipe_barrier(PIPE_V);
        RoundMode v381 = RoundMode::CAST_RINT;
        SaturationMode v382 = SaturationMode::ON;
        TCVT(v379, v377, v381, v382);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        v379.SetValidShape(v32, v37);
        // pto: %15
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v383 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %15
        ;
        uint64_t v384 = (uint64_t) v28;
        TASSIGN(v383, v384);
        pipe_barrier(PIPE_V);
        TMULS(v383, v319, v249);
        // pto: %16
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v385 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %16
        ;
        uint64_t v386 = (uint64_t) v29;
        TASSIGN(v385, v386);
        TMULS(v385, v323, v250);
        // pto: %17
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v387 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %17
        ;
        uint64_t v388 = (uint64_t) v28;
        TASSIGN(v387, v388);
        pipe_barrier(PIPE_V);
        TADD(v387, v383, v385);
        // pto: %18
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v389 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %18
        ;
        uint64_t v390 = (uint64_t) v29;
        TASSIGN(v389, v390);
        pipe_barrier(PIPE_V);
        TMULS(v389, v327, v251);
        // pto: %19
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v391 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %19
        ;
        uint64_t v392 = (uint64_t) v28;
        TASSIGN(v391, v392);
        pipe_barrier(PIPE_V);
        TADD(v391, v387, v389);
        // pto: %20
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v393 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %20
        ;
        uint64_t v394 = (uint64_t) v29;
        TASSIGN(v393, v394);
        pipe_barrier(PIPE_V);
        TMULS(v393, v331, v252);
        // pto: %21
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v395 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %21
        ;
        uint64_t v396 = (uint64_t) v28;
        TASSIGN(v395, v396);
        pipe_barrier(PIPE_V);
        TADD(v395, v391, v393);
        // pto: %22
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v397 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %22
        ;
        uint64_t v398 = (uint64_t) v29;
        TASSIGN(v397, v398);
        pipe_barrier(PIPE_V);
        TMULS(v397, v335, v253);
        // pto: %23
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v399 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %23
        ;
        uint64_t v400 = (uint64_t) v28;
        TASSIGN(v399, v400);
        pipe_barrier(PIPE_V);
        TADD(v399, v395, v397);
        // pto: %24
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v401 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %24
        ;
        uint64_t v402 = (uint64_t) v28;
        TASSIGN(v401, v402);
        pipe_barrier(PIPE_V);
        RoundMode v403 = RoundMode::CAST_RINT;
        SaturationMode v404 = SaturationMode::ON;
        TCVT(v401, v399, v403, v404);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        v401.SetValidShape(v32, v37);
        // pto: %26
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v405 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %26
        ;
        uint64_t v406 = (uint64_t) v23;
        TASSIGN(v405, v406);
        TMULS(v405, v319, v254);
        // pto: %27
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v407 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %27
        ;
        uint64_t v408 = (uint64_t) v26;
        TASSIGN(v407, v408);
        TMULS(v407, v323, v255);
        // pto: %28
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v409 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %28
        ;
        uint64_t v410 = (uint64_t) v23;
        TASSIGN(v409, v410);
        pipe_barrier(PIPE_V);
        TADD(v409, v405, v407);
        // pto: %29
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v411 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %29
        ;
        uint64_t v412 = (uint64_t) v26;
        TASSIGN(v411, v412);
        pipe_barrier(PIPE_V);
        TMULS(v411, v327, v256);
        // pto: %30
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v413 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %30
        ;
        uint64_t v414 = (uint64_t) v23;
        TASSIGN(v413, v414);
        pipe_barrier(PIPE_V);
        TADD(v413, v409, v411);
        // pto: %31
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v415 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %31
        ;
        uint64_t v416 = (uint64_t) v26;
        TASSIGN(v415, v416);
        pipe_barrier(PIPE_V);
        TMULS(v415, v331, v257);
        // pto: %32
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v417 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %32
        ;
        uint64_t v418 = (uint64_t) v23;
        TASSIGN(v417, v418);
        pipe_barrier(PIPE_V);
        TADD(v417, v413, v415);
        // pto: %33
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v419 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v270, v37);
        // pto: %33
        ;
        uint64_t v420 = (uint64_t) v26;
        TASSIGN(v419, v420);
        pipe_barrier(PIPE_V);
        TMULS(v419, v335, v258);
        // pto: %34
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v421 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %34
        ;
        uint64_t v422 = (uint64_t) v23;
        TASSIGN(v421, v422);
        pipe_barrier(PIPE_V);
        TADD(v421, v417, v419);
        // pto: %35
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v423 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %35
        ;
        uint64_t v424 = (uint64_t) v23;
        TASSIGN(v423, v424);
        pipe_barrier(PIPE_V);
        RoundMode v425 = RoundMode::CAST_RINT;
        SaturationMode v426 = SaturationMode::ON;
        TCVT(v423, v421, v425, v426);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        v423.SetValidShape(v32, v37);
        // pto: %y_flat__iter_v3_pview
        ;
        __gm__ bfloat16_t* v427 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %y_flat__iter_v3_pview
        ;
        const int64_t v428 = 0;
        // pto: %y_flat__iter_v3_pview
        ;
        const int64_t v429 = 16384;
        // pto: %y_flat__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v430 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__iter_v3_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v431 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v432 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v427 + (v428 + v261 * v429), v430, v431);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v432, v357);
        // pto: %y_flat__tile_pview
        ;
        __gm__ bfloat16_t* v433 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %y_flat__tile_pview
        ;
        const int64_t v434 = 4096;
        // pto: %y_flat__tile_pview
        ;
        const int64_t v435 = 16384;
        // pto: %y_flat__tile_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v436 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__tile_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v437 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__tile_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v438 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v433 + (v434 + v261 * v435), v436, v437);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        TSTORE(v438, v379);
        // pto: %332
        ;
        __gm__ bfloat16_t* v439 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %332
        ;
        const int64_t v440 = 8192;
        // pto: %332
        ;
        const int64_t v441 = 16384;
        // pto: %332
        ;
        pto::Shape<1, 1, 1, 1, 4096> v442 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %332
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v443 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %332
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v444 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v439 + (v440 + v261 * v441), v442, v443);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        TSTORE(v444, v401);
        // pto: %335
        ;
        __gm__ bfloat16_t* v445 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %335
        ;
        const int64_t v446 = 12288;
        // pto: %335
        ;
        const int64_t v447 = 16384;
        // pto: %335
        ;
        pto::Shape<1, 1, 1, 1, 4096> v448 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %335
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v449 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %335
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v450 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v445 + (v446 + v261 * v447), v448, v449);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        TSTORE(v450, v423);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      // pto: %336
      ;
      int64_t v451 = (int64_t) ((uint64_t) v236 + (uint64_t) v32);
      // pto: %337
      ;
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      if (v451 < v17) {
        // pto: %340
        ;
        int64_t v452 = (int64_t) ((uint64_t) v451 * (uint64_t) v40);
        // pto: %338
        ;
        float v453 = (v11)[v452];
        // pto: %344
        ;
        int64_t v454 = (int64_t) ((uint64_t) v451 * (uint64_t) v34);
        // pto: %342
        ;
        float v455 = (v12)[v454];
        // pto: %349, %346
        ;
        float v456 = (v12)[(int64_t) ((uint64_t) v454 + (uint64_t) v40)];
        // pto: %353, %350
        ;
        float v457 = (v12)[(int64_t) ((uint64_t) v454 + (uint64_t) v33)];
        // pto: %357, %354
        ;
        float v458 = (v12)[(int64_t) ((uint64_t) v454 + (uint64_t) v52)];
        // pto: %361, %358
        ;
        float v459 = (v11)[(int64_t) ((uint64_t) v452 + (uint64_t) v32)];
        // pto: %365, %362
        ;
        float v460 = (v12)[(int64_t) ((uint64_t) v454 + (uint64_t) v32)];
        // pto: %369, %366
        ;
        float v461 = (v12)[(int64_t) ((uint64_t) v454 + (uint64_t) v53)];
        // pto: %373, %370
        ;
        float v462 = (v12)[(int64_t) ((uint64_t) v454 + (uint64_t) v54)];
        // pto: %377, %374
        ;
        float v463 = (v12)[(int64_t) ((uint64_t) v454 + (uint64_t) v55)];
        // pto: %381, %378
        ;
        float v464 = (v11)[(int64_t) ((uint64_t) v452 + (uint64_t) v42)];
        // pto: %385, %382
        ;
        float v465 = (v12)[(int64_t) ((uint64_t) v454 + (uint64_t) v42)];
        // pto: %389, %386
        ;
        float v466 = (v12)[(int64_t) ((uint64_t) v454 + (uint64_t) v56)];
        // pto: %393, %390
        ;
        float v467 = (v12)[(int64_t) ((uint64_t) v454 + (uint64_t) v57)];
        // pto: %397, %394
        ;
        float v468 = (v12)[(int64_t) ((uint64_t) v454 + (uint64_t) v58)];
        // pto: %401, %398
        ;
        float v469 = (v11)[(int64_t) ((uint64_t) v452 + (uint64_t) v51)];
        // pto: %405, %402
        ;
        float v470 = (v12)[(int64_t) ((uint64_t) v454 + (uint64_t) v51)];
        // pto: %409, %406
        ;
        float v471 = (v12)[(int64_t) ((uint64_t) v454 + (uint64_t) v59)];
        // pto: %413, %410
        ;
        float v472 = (v12)[(int64_t) ((uint64_t) v454 + (uint64_t) v60)];
        // pto: %417, %414
        ;
        float v473 = (v12)[(int64_t) ((uint64_t) v454 + (uint64_t) v45)];
        // pto: %37
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v474 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %37
        ;
        uint64_t v475 = (uint64_t) v26;
        TASSIGN(v474, v475);
        // pto: %419
        ;
        int64_t v476 = v451 < v44 ? v44 : v451;
        // pto: %420
        ;
        __gm__ bfloat16_t* v477 = PTOAS__GLOBAL_TENSOR_DATA(v90);
        // pto: %420
        ;
        const int64_t v478 = 0;
        // pto: %420
        ;
        const int64_t v479 = 4096;
        // pto: %420
        ;
        pto::Shape<1, 1, 1, 1, 4096> v480 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %420
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v481 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %420
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v482 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v477 + (v478 + v476 * v479), v480, v481);
        TLOAD(v474, v482);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        // pto: %421, %422
        ;
        int64_t v483 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v17 - (uint64_t) v236) + (uint64_t) v62);
        // pto: %423
        ;
        int64_t v484 = v483 < v44 ? v44 : v483;
        // pto: %424
        ;
        int64_t v485 = v484 < v32 ? v484 : v32;
        // pto: %38
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v486 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %38
        ;
        uint64_t v487 = (uint64_t) v24;
        TASSIGN(v486, v487);
        // pto: %431
        ;
        const int64_t v488 = 0;
        // pto: %431
        ;
        __gm__ bfloat16_t* v489 = PTOAS__GLOBAL_TENSOR_DATA(v99);
        // pto: %431
        ;
        const int64_t v490 = 1;
        // pto: %431
        ;
        const int64_t v491 = 1;
        // pto: %431
        ;
        const int64_t v492 = 1;
        // pto: %431
        ;
        int64_t v493 = v485 * v39;
        // pto: %431
        ;
        int64_t v494 = v492 * v493;
        // pto: %431
        ;
        pto::Shape<1, 1, 1, -1, 4096> v495 = pto::Shape<1, 1, 1, -1, 4096>(v490, v491, v492, v485, v37);
        // pto: %431
        ;
        pto::Stride<-1, -1, -1, -1, -1> v496 = pto::Stride<-1, -1, -1, -1, -1>(v491 * v494, v494, v493, v39, v32);
        // pto: %431
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v497 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v489 + (v488 + v476 * v39 + v44 * v32), v495, v496);
        TLOAD(v486, v497);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %39
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v498 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %39
        ;
        uint64_t v499 = (uint64_t) v25;
        TASSIGN(v498, v499);
        // pto: %442
        ;
        const int64_t v500 = 0;
        // pto: %442
        ;
        __gm__ bfloat16_t* v501 = PTOAS__GLOBAL_TENSOR_DATA(v99);
        // pto: %442
        ;
        const int64_t v502 = 1;
        // pto: %442
        ;
        const int64_t v503 = 1;
        // pto: %442
        ;
        const int64_t v504 = 1;
        // pto: %442
        ;
        int64_t v505 = v485 * v39;
        // pto: %442
        ;
        int64_t v506 = v504 * v505;
        // pto: %442
        ;
        pto::Shape<1, 1, 1, -1, 4096> v507 = pto::Shape<1, 1, 1, -1, 4096>(v502, v503, v504, v485, v37);
        // pto: %442
        ;
        pto::Stride<-1, -1, -1, -1, -1> v508 = pto::Stride<-1, -1, -1, -1, -1>(v503 * v506, v506, v505, v39, v32);
        // pto: %442
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v509 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v501 + (v500 + v476 * v39 + v37 * v32), v507, v508);
        TLOAD(v498, v509);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %40
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v510 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %40
        ;
        uint64_t v511 = (uint64_t) v27;
        TASSIGN(v510, v511);
        // pto: %453
        ;
        const int64_t v512 = 0;
        // pto: %453
        ;
        __gm__ bfloat16_t* v513 = PTOAS__GLOBAL_TENSOR_DATA(v99);
        // pto: %453
        ;
        const int64_t v514 = 1;
        // pto: %453
        ;
        const int64_t v515 = 1;
        // pto: %453
        ;
        const int64_t v516 = 1;
        // pto: %453
        ;
        int64_t v517 = v485 * v39;
        // pto: %453
        ;
        int64_t v518 = v516 * v517;
        // pto: %453
        ;
        pto::Shape<1, 1, 1, -1, 4096> v519 = pto::Shape<1, 1, 1, -1, 4096>(v514, v515, v516, v485, v37);
        // pto: %453
        ;
        pto::Stride<-1, -1, -1, -1, -1> v520 = pto::Stride<-1, -1, -1, -1, -1>(v515 * v518, v518, v517, v39, v32);
        // pto: %453
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v521 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v513 + (v512 + v476 * v39 + v38 * v32), v519, v520);
        TLOAD(v510, v521);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %41
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v522 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %41
        ;
        uint64_t v523 = (uint64_t) v28;
        TASSIGN(v522, v523);
        // pto: %464
        ;
        const int64_t v524 = 0;
        // pto: %464
        ;
        __gm__ bfloat16_t* v525 = PTOAS__GLOBAL_TENSOR_DATA(v99);
        // pto: %464
        ;
        const int64_t v526 = 1;
        // pto: %464
        ;
        const int64_t v527 = 1;
        // pto: %464
        ;
        const int64_t v528 = 1;
        // pto: %464
        ;
        int64_t v529 = v485 * v39;
        // pto: %464
        ;
        int64_t v530 = v528 * v529;
        // pto: %464
        ;
        pto::Shape<1, 1, 1, -1, 4096> v531 = pto::Shape<1, 1, 1, -1, 4096>(v526, v527, v528, v485, v37);
        // pto: %464
        ;
        pto::Stride<-1, -1, -1, -1, -1> v532 = pto::Stride<-1, -1, -1, -1, -1>(v527 * v530, v530, v529, v39, v32);
        // pto: %464
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v533 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v525 + (v524 + v476 * v39 + v61 * v32), v531, v532);
        TLOAD(v522, v533);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        // pto: %42
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v534 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %42
        ;
        uint64_t v535 = (uint64_t) v23;
        TASSIGN(v534, v535);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        RoundMode v536 = RoundMode::CAST_ROUND;
        SaturationMode v537 = SaturationMode::ON;
        TCVT(v534, v474, v536, v537);
        // pto: %43
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v538 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %43
        ;
        uint64_t v539 = (uint64_t) v26;
        TASSIGN(v538, v539);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v540 = RoundMode::CAST_ROUND;
        SaturationMode v541 = SaturationMode::ON;
        TCVT(v538, v486, v540, v541);
        // pto: %44
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v542 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %44
        ;
        uint64_t v543 = (uint64_t) v24;
        TASSIGN(v542, v543);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        RoundMode v544 = RoundMode::CAST_ROUND;
        SaturationMode v545 = SaturationMode::ON;
        TCVT(v542, v498, v544, v545);
        // pto: %45
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v546 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %45
        ;
        uint64_t v547 = (uint64_t) v25;
        TASSIGN(v546, v547);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v548 = RoundMode::CAST_ROUND;
        SaturationMode v549 = SaturationMode::ON;
        TCVT(v546, v510, v548, v549);
        // pto: %46
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v550 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %46
        ;
        uint64_t v551 = (uint64_t) v27;
        TASSIGN(v550, v551);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        RoundMode v552 = RoundMode::CAST_ROUND;
        SaturationMode v553 = SaturationMode::ON;
        TCVT(v550, v522, v552, v553);
        // pto: %47
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v554 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %47
        ;
        uint64_t v555 = (uint64_t) v28;
        TASSIGN(v554, v555);
        pipe_barrier(PIPE_V);
        TMULS(v554, v534, v453);
        // pto: %48
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v556 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %48
        ;
        uint64_t v557 = (uint64_t) v29;
        TASSIGN(v556, v557);
        TMULS(v556, v538, v455);
        // pto: %49
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v558 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %49
        ;
        uint64_t v559 = (uint64_t) v28;
        TASSIGN(v558, v559);
        pipe_barrier(PIPE_V);
        TADD(v558, v554, v556);
        // pto: %50
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v560 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %50
        ;
        uint64_t v561 = (uint64_t) v29;
        TASSIGN(v560, v561);
        pipe_barrier(PIPE_V);
        TMULS(v560, v542, v456);
        // pto: %51
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v562 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %51
        ;
        uint64_t v563 = (uint64_t) v28;
        TASSIGN(v562, v563);
        pipe_barrier(PIPE_V);
        TADD(v562, v558, v560);
        // pto: %52
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v564 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %52
        ;
        uint64_t v565 = (uint64_t) v29;
        TASSIGN(v564, v565);
        pipe_barrier(PIPE_V);
        TMULS(v564, v546, v457);
        // pto: %53
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v566 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %53
        ;
        uint64_t v567 = (uint64_t) v28;
        TASSIGN(v566, v567);
        pipe_barrier(PIPE_V);
        TADD(v566, v562, v564);
        // pto: %54
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v568 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %54
        ;
        uint64_t v569 = (uint64_t) v29;
        TASSIGN(v568, v569);
        pipe_barrier(PIPE_V);
        TMULS(v568, v550, v458);
        // pto: %55
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v570 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %55
        ;
        uint64_t v571 = (uint64_t) v28;
        TASSIGN(v570, v571);
        pipe_barrier(PIPE_V);
        TADD(v570, v566, v568);
        // pto: %56
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v572 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %56
        ;
        uint64_t v573 = (uint64_t) v30;
        TASSIGN(v572, v573);
        pipe_barrier(PIPE_V);
        RoundMode v574 = RoundMode::CAST_RINT;
        SaturationMode v575 = SaturationMode::ON;
        TCVT(v572, v570, v574, v575);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        v572.SetValidShape(v32, v37);
        // pto: %58
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v576 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %58
        ;
        uint64_t v577 = (uint64_t) v28;
        TASSIGN(v576, v577);
        pipe_barrier(PIPE_V);
        TMULS(v576, v534, v459);
        // pto: %59
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v578 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %59
        ;
        uint64_t v579 = (uint64_t) v29;
        TASSIGN(v578, v579);
        TMULS(v578, v538, v460);
        // pto: %60
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v580 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %60
        ;
        uint64_t v581 = (uint64_t) v28;
        TASSIGN(v580, v581);
        pipe_barrier(PIPE_V);
        TADD(v580, v576, v578);
        // pto: %61
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v582 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %61
        ;
        uint64_t v583 = (uint64_t) v29;
        TASSIGN(v582, v583);
        pipe_barrier(PIPE_V);
        TMULS(v582, v542, v461);
        // pto: %62
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v584 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %62
        ;
        uint64_t v585 = (uint64_t) v28;
        TASSIGN(v584, v585);
        pipe_barrier(PIPE_V);
        TADD(v584, v580, v582);
        // pto: %63
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v586 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %63
        ;
        uint64_t v587 = (uint64_t) v29;
        TASSIGN(v586, v587);
        pipe_barrier(PIPE_V);
        TMULS(v586, v546, v462);
        // pto: %64
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v588 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %64
        ;
        uint64_t v589 = (uint64_t) v28;
        TASSIGN(v588, v589);
        pipe_barrier(PIPE_V);
        TADD(v588, v584, v586);
        // pto: %65
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v590 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %65
        ;
        uint64_t v591 = (uint64_t) v29;
        TASSIGN(v590, v591);
        pipe_barrier(PIPE_V);
        TMULS(v590, v550, v463);
        // pto: %66
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v592 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %66
        ;
        uint64_t v593 = (uint64_t) v28;
        TASSIGN(v592, v593);
        pipe_barrier(PIPE_V);
        TADD(v592, v588, v590);
        // pto: %67
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v594 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %67
        ;
        uint64_t v595 = (uint64_t) v31;
        TASSIGN(v594, v595);
        pipe_barrier(PIPE_V);
        RoundMode v596 = RoundMode::CAST_RINT;
        SaturationMode v597 = SaturationMode::ON;
        TCVT(v594, v592, v596, v597);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        v594.SetValidShape(v32, v37);
        // pto: %69
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v598 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %69
        ;
        uint64_t v599 = (uint64_t) v28;
        TASSIGN(v598, v599);
        pipe_barrier(PIPE_V);
        TMULS(v598, v534, v464);
        // pto: %70
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v600 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %70
        ;
        uint64_t v601 = (uint64_t) v29;
        TASSIGN(v600, v601);
        TMULS(v600, v538, v465);
        // pto: %71
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v602 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %71
        ;
        uint64_t v603 = (uint64_t) v28;
        TASSIGN(v602, v603);
        pipe_barrier(PIPE_V);
        TADD(v602, v598, v600);
        // pto: %72
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v604 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %72
        ;
        uint64_t v605 = (uint64_t) v29;
        TASSIGN(v604, v605);
        pipe_barrier(PIPE_V);
        TMULS(v604, v542, v466);
        // pto: %73
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v606 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %73
        ;
        uint64_t v607 = (uint64_t) v28;
        TASSIGN(v606, v607);
        pipe_barrier(PIPE_V);
        TADD(v606, v602, v604);
        // pto: %74
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v608 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %74
        ;
        uint64_t v609 = (uint64_t) v29;
        TASSIGN(v608, v609);
        pipe_barrier(PIPE_V);
        TMULS(v608, v546, v467);
        // pto: %75
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v610 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %75
        ;
        uint64_t v611 = (uint64_t) v28;
        TASSIGN(v610, v611);
        pipe_barrier(PIPE_V);
        TADD(v610, v606, v608);
        // pto: %76
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v612 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %76
        ;
        uint64_t v613 = (uint64_t) v29;
        TASSIGN(v612, v613);
        pipe_barrier(PIPE_V);
        TMULS(v612, v550, v468);
        // pto: %77
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v614 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %77
        ;
        uint64_t v615 = (uint64_t) v28;
        TASSIGN(v614, v615);
        pipe_barrier(PIPE_V);
        TADD(v614, v610, v612);
        // pto: %78
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v616 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %78
        ;
        uint64_t v617 = (uint64_t) v28;
        TASSIGN(v616, v617);
        pipe_barrier(PIPE_V);
        RoundMode v618 = RoundMode::CAST_RINT;
        SaturationMode v619 = SaturationMode::ON;
        TCVT(v616, v614, v618, v619);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        v616.SetValidShape(v32, v37);
        // pto: %80
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v620 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %80
        ;
        uint64_t v621 = (uint64_t) v23;
        TASSIGN(v620, v621);
        TMULS(v620, v534, v469);
        // pto: %81
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v622 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %81
        ;
        uint64_t v623 = (uint64_t) v26;
        TASSIGN(v622, v623);
        TMULS(v622, v538, v470);
        // pto: %82
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v624 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %82
        ;
        uint64_t v625 = (uint64_t) v23;
        TASSIGN(v624, v625);
        pipe_barrier(PIPE_V);
        TADD(v624, v620, v622);
        // pto: %83
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v626 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %83
        ;
        uint64_t v627 = (uint64_t) v26;
        TASSIGN(v626, v627);
        pipe_barrier(PIPE_V);
        TMULS(v626, v542, v471);
        // pto: %84
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v628 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %84
        ;
        uint64_t v629 = (uint64_t) v23;
        TASSIGN(v628, v629);
        pipe_barrier(PIPE_V);
        TADD(v628, v624, v626);
        // pto: %85
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v630 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %85
        ;
        uint64_t v631 = (uint64_t) v26;
        TASSIGN(v630, v631);
        pipe_barrier(PIPE_V);
        TMULS(v630, v546, v472);
        // pto: %86
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v632 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %86
        ;
        uint64_t v633 = (uint64_t) v23;
        TASSIGN(v632, v633);
        pipe_barrier(PIPE_V);
        TADD(v632, v628, v630);
        // pto: %87
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v634 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v485, v37);
        // pto: %87
        ;
        uint64_t v635 = (uint64_t) v26;
        TASSIGN(v634, v635);
        pipe_barrier(PIPE_V);
        TMULS(v634, v550, v473);
        // pto: %88
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v636 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %88
        ;
        uint64_t v637 = (uint64_t) v23;
        TASSIGN(v636, v637);
        pipe_barrier(PIPE_V);
        TADD(v636, v632, v634);
        // pto: %89
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v638 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %89
        ;
        uint64_t v639 = (uint64_t) v23;
        TASSIGN(v638, v639);
        pipe_barrier(PIPE_V);
        RoundMode v640 = RoundMode::CAST_RINT;
        SaturationMode v641 = SaturationMode::ON;
        TCVT(v638, v636, v640, v641);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v638.SetValidShape(v32, v37);
        // pto: %y_flat__phi_v9_pview
        ;
        __gm__ bfloat16_t* v642 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %y_flat__phi_v9_pview
        ;
        const int64_t v643 = 0;
        // pto: %y_flat__phi_v9_pview
        ;
        const int64_t v644 = 16384;
        // pto: %y_flat__phi_v9_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v645 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__phi_v9_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v646 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__phi_v9_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v647 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v642 + (v643 + v476 * v644), v645, v646);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        TSTORE(v647, v572);
        // pto: %551
        ;
        __gm__ bfloat16_t* v648 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %551
        ;
        const int64_t v649 = 4096;
        // pto: %551
        ;
        const int64_t v650 = 16384;
        // pto: %551
        ;
        pto::Shape<1, 1, 1, 1, 4096> v651 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %551
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v652 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %551
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v653 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v648 + (v649 + v476 * v650), v651, v652);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        TSTORE(v653, v594);
        // pto: %555
        ;
        __gm__ bfloat16_t* v654 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %555
        ;
        const int64_t v655 = 8192;
        // pto: %555
        ;
        const int64_t v656 = 16384;
        // pto: %555
        ;
        pto::Shape<1, 1, 1, 1, 4096> v657 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %555
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v658 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %555
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v659 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v654 + (v655 + v476 * v656), v657, v658);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        TSTORE(v659, v616);
        // pto: %559
        ;
        __gm__ bfloat16_t* v660 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %559
        ;
        const int64_t v661 = 12288;
        // pto: %559
        ;
        const int64_t v662 = 16384;
        // pto: %559
        ;
        pto::Shape<1, 1, 1, 1, 4096> v663 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %559
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v664 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %559
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v665 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v660 + (v661 + v476 * v662), v663, v664);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v665, v638);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    // pto: %560, %561, %562
    ;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    if ((int64_t) ((uint64_t) ((int64_t) (uint64_t) v234 - (uint64_t) v235) + (uint64_t) v40) == v32) {
      // pto: %563
      ;
      if (v235 < v17) {
        // pto: %91
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v666 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %91
        ;
        uint64_t v667 = (uint64_t) v26;
        TASSIGN(v666, v667);
        // pto: %564
        ;
        int64_t v668 = v235 < v44 ? v44 : v235;
        // pto: %565
        ;
        __gm__ bfloat16_t* v669 = PTOAS__GLOBAL_TENSOR_DATA(v90);
        // pto: %565
        ;
        const int64_t v670 = 0;
        // pto: %565
        ;
        const int64_t v671 = 4096;
        // pto: %565
        ;
        pto::Shape<1, 1, 1, 1, 4096> v672 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %565
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v673 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %565
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v674 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v669 + (v670 + v668 * v671), v672, v673);
        TLOAD(v666, v674);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %92
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v675 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %92
        ;
        uint64_t v676 = (uint64_t) v23;
        TASSIGN(v675, v676);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v677 = RoundMode::CAST_ROUND;
        SaturationMode v678 = SaturationMode::ON;
        TCVT(v675, v666, v677, v678);
        // pto: %566
        ;
        int64_t v679 = (int64_t) ((uint64_t) v17 - (uint64_t) v235);
        // pto: %567
        ;
        int64_t v680 = v679 < v44 ? v44 : v679;
        // pto: %568
        ;
        int64_t v681 = v680 < v32 ? v680 : v32;
        // pto: %93
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v682 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %93
        ;
        uint64_t v683 = (uint64_t) v24;
        TASSIGN(v682, v683);
        // pto: %573
        ;
        const int64_t v684 = 0;
        // pto: %573
        ;
        __gm__ bfloat16_t* v685 = PTOAS__GLOBAL_TENSOR_DATA(v99);
        // pto: %573
        ;
        const int64_t v686 = 1;
        // pto: %573
        ;
        const int64_t v687 = 1;
        // pto: %573
        ;
        const int64_t v688 = 1;
        // pto: %573
        ;
        int64_t v689 = v681 * v39;
        // pto: %573
        ;
        int64_t v690 = v688 * v689;
        // pto: %573
        ;
        pto::Shape<1, 1, 1, -1, 4096> v691 = pto::Shape<1, 1, 1, -1, 4096>(v686, v687, v688, v681, v37);
        // pto: %573
        ;
        pto::Stride<-1, -1, -1, -1, -1> v692 = pto::Stride<-1, -1, -1, -1, -1>(v687 * v690, v690, v689, v39, v32);
        // pto: %573
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v693 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v685 + (v684 + v668 * v39 + v44 * v32), v691, v692);
        TLOAD(v682, v693);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %94
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v694 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %94
        ;
        uint64_t v695 = (uint64_t) v26;
        TASSIGN(v694, v695);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v696 = RoundMode::CAST_ROUND;
        SaturationMode v697 = SaturationMode::ON;
        TCVT(v694, v682, v696, v697);
        // pto: %95
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v698 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %95
        ;
        uint64_t v699 = (uint64_t) v25;
        TASSIGN(v698, v699);
        // pto: %584
        ;
        const int64_t v700 = 0;
        // pto: %584
        ;
        __gm__ bfloat16_t* v701 = PTOAS__GLOBAL_TENSOR_DATA(v99);
        // pto: %584
        ;
        const int64_t v702 = 1;
        // pto: %584
        ;
        const int64_t v703 = 1;
        // pto: %584
        ;
        const int64_t v704 = 1;
        // pto: %584
        ;
        int64_t v705 = v681 * v39;
        // pto: %584
        ;
        int64_t v706 = v704 * v705;
        // pto: %584
        ;
        pto::Shape<1, 1, 1, -1, 4096> v707 = pto::Shape<1, 1, 1, -1, 4096>(v702, v703, v704, v681, v37);
        // pto: %584
        ;
        pto::Stride<-1, -1, -1, -1, -1> v708 = pto::Stride<-1, -1, -1, -1, -1>(v703 * v706, v706, v705, v39, v32);
        // pto: %584
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v709 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v701 + (v700 + v668 * v39 + v37 * v32), v707, v708);
        TLOAD(v698, v709);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %96
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v710 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %96
        ;
        uint64_t v711 = (uint64_t) v24;
        TASSIGN(v710, v711);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v712 = RoundMode::CAST_ROUND;
        SaturationMode v713 = SaturationMode::ON;
        TCVT(v710, v698, v712, v713);
        // pto: %97
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v714 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %97
        ;
        uint64_t v715 = (uint64_t) v27;
        TASSIGN(v714, v715);
        // pto: %595
        ;
        const int64_t v716 = 0;
        // pto: %595
        ;
        __gm__ bfloat16_t* v717 = PTOAS__GLOBAL_TENSOR_DATA(v99);
        // pto: %595
        ;
        const int64_t v718 = 1;
        // pto: %595
        ;
        const int64_t v719 = 1;
        // pto: %595
        ;
        const int64_t v720 = 1;
        // pto: %595
        ;
        int64_t v721 = v681 * v39;
        // pto: %595
        ;
        int64_t v722 = v720 * v721;
        // pto: %595
        ;
        pto::Shape<1, 1, 1, -1, 4096> v723 = pto::Shape<1, 1, 1, -1, 4096>(v718, v719, v720, v681, v37);
        // pto: %595
        ;
        pto::Stride<-1, -1, -1, -1, -1> v724 = pto::Stride<-1, -1, -1, -1, -1>(v719 * v722, v722, v721, v39, v32);
        // pto: %595
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v725 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v717 + (v716 + v668 * v39 + v38 * v32), v723, v724);
        TLOAD(v714, v725);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %98
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v726 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %98
        ;
        uint64_t v727 = (uint64_t) v25;
        TASSIGN(v726, v727);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v728 = RoundMode::CAST_ROUND;
        SaturationMode v729 = SaturationMode::ON;
        TCVT(v726, v714, v728, v729);
        // pto: %99
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v730 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %99
        ;
        uint64_t v731 = (uint64_t) v28;
        TASSIGN(v730, v731);
        // pto: %606
        ;
        const int64_t v732 = 0;
        // pto: %606
        ;
        __gm__ bfloat16_t* v733 = PTOAS__GLOBAL_TENSOR_DATA(v99);
        // pto: %606
        ;
        const int64_t v734 = 1;
        // pto: %606
        ;
        const int64_t v735 = 1;
        // pto: %606
        ;
        const int64_t v736 = 1;
        // pto: %606
        ;
        int64_t v737 = v681 * v39;
        // pto: %606
        ;
        int64_t v738 = v736 * v737;
        // pto: %606
        ;
        pto::Shape<1, 1, 1, -1, 4096> v739 = pto::Shape<1, 1, 1, -1, 4096>(v734, v735, v736, v681, v37);
        // pto: %606
        ;
        pto::Stride<-1, -1, -1, -1, -1> v740 = pto::Stride<-1, -1, -1, -1, -1>(v735 * v738, v738, v737, v39, v32);
        // pto: %606
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v741 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v733 + (v732 + v668 * v39 + v61 * v32), v739, v740);
        TLOAD(v730, v741);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %100
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v742 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %100
        ;
        uint64_t v743 = (uint64_t) v27;
        TASSIGN(v742, v743);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v744 = RoundMode::CAST_ROUND;
        SaturationMode v745 = SaturationMode::ON;
        TCVT(v742, v730, v744, v745);
        // pto: %611
        ;
        int64_t v746 = (int64_t) ((uint64_t) v235 * (uint64_t) v40);
        // pto: %610
        ;
        float v747 = (v11)[v746];
        // pto: %101
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v748 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %101
        ;
        uint64_t v749 = (uint64_t) v28;
        TASSIGN(v748, v749);
        pipe_barrier(PIPE_V);
        TMULS(v748, v675, v747);
        // pto: %614
        ;
        int64_t v750 = (int64_t) ((uint64_t) v235 * (uint64_t) v34);
        // pto: %613
        ;
        float v751 = (v12)[v750];
        // pto: %102
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v752 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %102
        ;
        uint64_t v753 = (uint64_t) v29;
        TASSIGN(v752, v753);
        TMULS(v752, v694, v751);
        // pto: %103
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v754 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %103
        ;
        uint64_t v755 = (uint64_t) v28;
        TASSIGN(v754, v755);
        pipe_barrier(PIPE_V);
        TADD(v754, v748, v752);
        // pto: %621, %619
        ;
        float v756 = (v12)[(int64_t) ((uint64_t) v750 + (uint64_t) v40)];
        // pto: %104
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v757 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %104
        ;
        uint64_t v758 = (uint64_t) v29;
        TASSIGN(v757, v758);
        pipe_barrier(PIPE_V);
        TMULS(v757, v710, v756);
        // pto: %105
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v759 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %105
        ;
        uint64_t v760 = (uint64_t) v28;
        TASSIGN(v759, v760);
        pipe_barrier(PIPE_V);
        TADD(v759, v754, v757);
        // pto: %627, %625
        ;
        float v761 = (v12)[(int64_t) ((uint64_t) v750 + (uint64_t) v33)];
        // pto: %106
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v762 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %106
        ;
        uint64_t v763 = (uint64_t) v29;
        TASSIGN(v762, v763);
        pipe_barrier(PIPE_V);
        TMULS(v762, v726, v761);
        // pto: %107
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v764 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %107
        ;
        uint64_t v765 = (uint64_t) v28;
        TASSIGN(v764, v765);
        pipe_barrier(PIPE_V);
        TADD(v764, v759, v762);
        // pto: %633, %631
        ;
        float v766 = (v12)[(int64_t) ((uint64_t) v750 + (uint64_t) v52)];
        // pto: %108
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v767 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %108
        ;
        uint64_t v768 = (uint64_t) v29;
        TASSIGN(v767, v768);
        pipe_barrier(PIPE_V);
        TMULS(v767, v742, v766);
        // pto: %109
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v769 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %109
        ;
        uint64_t v770 = (uint64_t) v28;
        TASSIGN(v769, v770);
        pipe_barrier(PIPE_V);
        TADD(v769, v764, v767);
        // pto: %110
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v771 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %110
        ;
        uint64_t v772 = (uint64_t) v28;
        TASSIGN(v771, v772);
        pipe_barrier(PIPE_V);
        RoundMode v773 = RoundMode::CAST_RINT;
        SaturationMode v774 = SaturationMode::ON;
        TCVT(v771, v769, v773, v774);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v771.SetValidShape(v32, v37);
        // pto: %y_flat__rv_v4_main_pview
        ;
        __gm__ bfloat16_t* v775 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %y_flat__rv_v4_main_pview
        ;
        const int64_t v776 = 0;
        // pto: %y_flat__rv_v4_main_pview
        ;
        const int64_t v777 = 16384;
        // pto: %y_flat__rv_v4_main_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v778 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__rv_v4_main_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v779 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__rv_v4_main_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v780 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v775 + (v776 + v668 * v777), v778, v779);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v780, v771);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
        // pto: %641, %639
        ;
        float v781 = (v11)[(int64_t) ((uint64_t) v746 + (uint64_t) v32)];
        // pto: %112
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v782 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %112
        ;
        uint64_t v783 = (uint64_t) v28;
        TASSIGN(v782, v783);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
        TMULS(v782, v675, v781);
        // pto: %644, %642
        ;
        float v784 = (v12)[(int64_t) ((uint64_t) v750 + (uint64_t) v32)];
        // pto: %113
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v785 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %113
        ;
        uint64_t v786 = (uint64_t) v29;
        TASSIGN(v785, v786);
        TMULS(v785, v694, v784);
        // pto: %114
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v787 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %114
        ;
        uint64_t v788 = (uint64_t) v28;
        TASSIGN(v787, v788);
        pipe_barrier(PIPE_V);
        TADD(v787, v782, v785);
        // pto: %650, %648
        ;
        float v789 = (v12)[(int64_t) ((uint64_t) v750 + (uint64_t) v53)];
        // pto: %115
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v790 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %115
        ;
        uint64_t v791 = (uint64_t) v29;
        TASSIGN(v790, v791);
        pipe_barrier(PIPE_V);
        TMULS(v790, v710, v789);
        // pto: %116
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v792 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %116
        ;
        uint64_t v793 = (uint64_t) v28;
        TASSIGN(v792, v793);
        pipe_barrier(PIPE_V);
        TADD(v792, v787, v790);
        // pto: %656, %654
        ;
        float v794 = (v12)[(int64_t) ((uint64_t) v750 + (uint64_t) v54)];
        // pto: %117
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v795 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %117
        ;
        uint64_t v796 = (uint64_t) v29;
        TASSIGN(v795, v796);
        pipe_barrier(PIPE_V);
        TMULS(v795, v726, v794);
        // pto: %118
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v797 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %118
        ;
        uint64_t v798 = (uint64_t) v28;
        TASSIGN(v797, v798);
        pipe_barrier(PIPE_V);
        TADD(v797, v792, v795);
        // pto: %662, %660
        ;
        float v799 = (v12)[(int64_t) ((uint64_t) v750 + (uint64_t) v55)];
        // pto: %119
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v800 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %119
        ;
        uint64_t v801 = (uint64_t) v29;
        TASSIGN(v800, v801);
        pipe_barrier(PIPE_V);
        TMULS(v800, v742, v799);
        // pto: %120
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v802 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %120
        ;
        uint64_t v803 = (uint64_t) v28;
        TASSIGN(v802, v803);
        pipe_barrier(PIPE_V);
        TADD(v802, v797, v800);
        // pto: %121
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v804 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %121
        ;
        uint64_t v805 = (uint64_t) v28;
        TASSIGN(v804, v805);
        pipe_barrier(PIPE_V);
        RoundMode v806 = RoundMode::CAST_RINT;
        SaturationMode v807 = SaturationMode::ON;
        TCVT(v804, v802, v806, v807);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v804.SetValidShape(v32, v37);
        // pto: %668
        ;
        __gm__ bfloat16_t* v808 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %668
        ;
        const int64_t v809 = 4096;
        // pto: %668
        ;
        const int64_t v810 = 16384;
        // pto: %668
        ;
        pto::Shape<1, 1, 1, 1, 4096> v811 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %668
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v812 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %668
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v813 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v808 + (v809 + v668 * v810), v811, v812);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v813, v804);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
        // pto: %671, %669
        ;
        float v814 = (v11)[(int64_t) ((uint64_t) v746 + (uint64_t) v42)];
        // pto: %123
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v815 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %123
        ;
        uint64_t v816 = (uint64_t) v28;
        TASSIGN(v815, v816);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
        TMULS(v815, v675, v814);
        // pto: %674, %672
        ;
        float v817 = (v12)[(int64_t) ((uint64_t) v750 + (uint64_t) v42)];
        // pto: %124
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v818 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %124
        ;
        uint64_t v819 = (uint64_t) v29;
        TASSIGN(v818, v819);
        TMULS(v818, v694, v817);
        // pto: %125
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v820 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %125
        ;
        uint64_t v821 = (uint64_t) v28;
        TASSIGN(v820, v821);
        pipe_barrier(PIPE_V);
        TADD(v820, v815, v818);
        // pto: %680, %678
        ;
        float v822 = (v12)[(int64_t) ((uint64_t) v750 + (uint64_t) v56)];
        // pto: %126
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v823 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %126
        ;
        uint64_t v824 = (uint64_t) v29;
        TASSIGN(v823, v824);
        pipe_barrier(PIPE_V);
        TMULS(v823, v710, v822);
        // pto: %127
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v825 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %127
        ;
        uint64_t v826 = (uint64_t) v28;
        TASSIGN(v825, v826);
        pipe_barrier(PIPE_V);
        TADD(v825, v820, v823);
        // pto: %686, %684
        ;
        float v827 = (v12)[(int64_t) ((uint64_t) v750 + (uint64_t) v57)];
        // pto: %128
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v828 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %128
        ;
        uint64_t v829 = (uint64_t) v29;
        TASSIGN(v828, v829);
        pipe_barrier(PIPE_V);
        TMULS(v828, v726, v827);
        // pto: %129
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v830 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %129
        ;
        uint64_t v831 = (uint64_t) v28;
        TASSIGN(v830, v831);
        pipe_barrier(PIPE_V);
        TADD(v830, v825, v828);
        // pto: %692, %690
        ;
        float v832 = (v12)[(int64_t) ((uint64_t) v750 + (uint64_t) v58)];
        // pto: %130
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v833 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %130
        ;
        uint64_t v834 = (uint64_t) v29;
        TASSIGN(v833, v834);
        pipe_barrier(PIPE_V);
        TMULS(v833, v742, v832);
        // pto: %131
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v835 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %131
        ;
        uint64_t v836 = (uint64_t) v28;
        TASSIGN(v835, v836);
        pipe_barrier(PIPE_V);
        TADD(v835, v830, v833);
        // pto: %132
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v837 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %132
        ;
        uint64_t v838 = (uint64_t) v28;
        TASSIGN(v837, v838);
        pipe_barrier(PIPE_V);
        RoundMode v839 = RoundMode::CAST_RINT;
        SaturationMode v840 = SaturationMode::ON;
        TCVT(v837, v835, v839, v840);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v837.SetValidShape(v32, v37);
        // pto: %698
        ;
        __gm__ bfloat16_t* v841 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %698
        ;
        const int64_t v842 = 8192;
        // pto: %698
        ;
        const int64_t v843 = 16384;
        // pto: %698
        ;
        pto::Shape<1, 1, 1, 1, 4096> v844 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %698
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v845 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %698
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v846 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v841 + (v842 + v668 * v843), v844, v845);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v846, v837);
        // pto: %701, %699
        ;
        float v847 = (v11)[(int64_t) ((uint64_t) v746 + (uint64_t) v51)];
        // pto: %134
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v848 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %134
        ;
        uint64_t v849 = (uint64_t) v23;
        TASSIGN(v848, v849);
        TMULS(v848, v675, v847);
        // pto: %704, %702
        ;
        float v850 = (v12)[(int64_t) ((uint64_t) v750 + (uint64_t) v51)];
        // pto: %135
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v851 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %135
        ;
        uint64_t v852 = (uint64_t) v26;
        TASSIGN(v851, v852);
        TMULS(v851, v694, v850);
        // pto: %136
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v853 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %136
        ;
        uint64_t v854 = (uint64_t) v23;
        TASSIGN(v853, v854);
        pipe_barrier(PIPE_V);
        TADD(v853, v848, v851);
        // pto: %710, %708
        ;
        float v855 = (v12)[(int64_t) ((uint64_t) v750 + (uint64_t) v59)];
        // pto: %137
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v856 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %137
        ;
        uint64_t v857 = (uint64_t) v26;
        TASSIGN(v856, v857);
        pipe_barrier(PIPE_V);
        TMULS(v856, v710, v855);
        // pto: %138
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v858 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %138
        ;
        uint64_t v859 = (uint64_t) v23;
        TASSIGN(v858, v859);
        pipe_barrier(PIPE_V);
        TADD(v858, v853, v856);
        // pto: %716, %714
        ;
        float v860 = (v12)[(int64_t) ((uint64_t) v750 + (uint64_t) v60)];
        // pto: %139
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v861 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %139
        ;
        uint64_t v862 = (uint64_t) v26;
        TASSIGN(v861, v862);
        pipe_barrier(PIPE_V);
        TMULS(v861, v726, v860);
        // pto: %140
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v863 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %140
        ;
        uint64_t v864 = (uint64_t) v23;
        TASSIGN(v863, v864);
        pipe_barrier(PIPE_V);
        TADD(v863, v858, v861);
        // pto: %722, %720
        ;
        float v865 = (v12)[(int64_t) ((uint64_t) v750 + (uint64_t) v45)];
        // pto: %141
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v866 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v681, v37);
        // pto: %141
        ;
        uint64_t v867 = (uint64_t) v26;
        TASSIGN(v866, v867);
        pipe_barrier(PIPE_V);
        TMULS(v866, v742, v865);
        // pto: %142
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v868 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %142
        ;
        uint64_t v869 = (uint64_t) v23;
        TASSIGN(v868, v869);
        pipe_barrier(PIPE_V);
        TADD(v868, v863, v866);
        // pto: %143
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v870 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v37);
        // pto: %143
        ;
        uint64_t v871 = (uint64_t) v23;
        TASSIGN(v870, v871);
        pipe_barrier(PIPE_V);
        RoundMode v872 = RoundMode::CAST_RINT;
        SaturationMode v873 = SaturationMode::ON;
        TCVT(v870, v868, v872, v873);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v870.SetValidShape(v32, v37);
        // pto: %728
        ;
        __gm__ bfloat16_t* v874 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %728
        ;
        const int64_t v875 = 12288;
        // pto: %728
        ;
        const int64_t v876 = 16384;
        // pto: %728
        ;
        pto::Shape<1, 1, 1, 1, 4096> v877 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %728
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v878 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %728
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v879 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v874 + (v875 + v668 * v876), v877, v878);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v879, v870);
      };
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  pipe_barrier(PIPE_ALL);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}