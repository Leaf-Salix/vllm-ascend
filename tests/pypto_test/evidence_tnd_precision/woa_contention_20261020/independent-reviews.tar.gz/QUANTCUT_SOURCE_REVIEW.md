# Quant-cut：源与对拍独立审查

## 结论

**源级和现有对拍助手未发现阻断；实际生成码/完整编译/设备资格尚待核验。** 本次 parent 明确为 `phasecut-acquire`（两 MIX），candidate 为同一公开根内三 MIX；不能与 owner2 的跨任务数据直接计算新增切点收益。

本报告没有修改正式源码或 SDK，没有提交设备任务。

## 单因素范围

通过解析实际 parent/candidate AST，独立确认：

1. `begin/publish/wait_group/current_generation`、prefix AIC/AIV、prefix group 全部相同。
2. middle AIV 的原始 setup、有效 cast worker 的 payload acquire、BF16 cast、publish2、八 owner wait2、全8192列共同 amax/scale/量化、publish3，全为 parent 节点原样复制。没有把量化拆为局部列量化。
3. middle AIC 只有原 current-generation setup 和本地 bar_all，不读未就绪 quantized，不等待第三段事件。
4. third AIC 将原 wait3 替换成 `fence → cacheinvalid(all) → fence`，其后的 WO-B 所有分支、K512×16累加和 publish4 节点相同。去掉 wait3 只有在**实际 task 完成依赖**成立时才正确；不能用 scopeexit、submit源顺序或 cluster 名字替代。
5. third AIV 原 setup/current-generation 后直接从原 wait4 开始，dequant、publish5、wait5、HC-post、返回全相同。其读取 integer/token_scale 的 acquire 路径仍在，不借用 phase0 单行刷新充当 payload acquire。
6. 仍是16 Tensor ABI、8个 InOut，无新增工作区；FP32 accum `[T+127,8192]`、integer `[T+63,4096]` 沿用父版。真实 TND/有效行边界不变。

原始 publish mask 未删：所有72个 core 只在 prefix begin 一次；middle/third 仅 current-generation 读取。phase2/3仍由所有48 AIV发布，phase4由24 AIC发布，phase5由48 AIV发布。中间空闲 AIC 不等 third；third AIV等本段AIC phase4，不构成反向环。middle 内 cast→owner2量化依赖仍完整。

新增一个完成切点会消除原本 AIC wait3 与 AIV 量化的共时执行，但也增加一次24组 MIX调度、sync-start、current-generation/cache动作。它是待测的执行组织因素，不能预先称为更快；事件级耗时差也不能全解释为固定 wait 指令成本。

## Harness 与门禁

`quantcut_probe.py` 相对已审 `phasecut_acquire_probe.py` 仅修改 CLI variant、parent 和对应合法组合断言。原有：

- 实际模块路径/SHA、候选proof及有界祖先链验证；parent必须是 aa1fa9…，不是默认 ambient 模块。
- 三臂 frozen / phasecut parent / quantcut，独立输出、工作区和 signals；同输入五边界逐字节，浮点 finite，eager + FULL A/B/A，首差抛错。
- NaN/整数反码毒化、外层 guard、只读输入SHA、完整信号槽/未用槽mask、双臂代际一致及每窗各+100。
- FULL 12窗×100回放、平衡轮转/反序，同一 graph stream，所有检查在事件外。预期最终1204代，而不是三段各增代。
- 一任务一T（126或240），内部timeout750s，设备任务外界限由提交者保持780s。

门禁观测为五个公开边界，并未新增每元素内部FP32 accum/INT32 accumulator hook；不能把通过结论扩大为“所有内部比特均已观测”。

## 设备前尚需的实际生成码核验

必须核对：三次且仅三次 MIX，均24block/sync-start；middle和third `add_inout` 关联相同 quantized/signals（及原其余InOut），没有开启early resolve；middle完成才能运行third；没有新增rt_alloc。核实际PTO中的三条payload acquire仍在third首个quantized tload之前，prefix/WO-B/quant数学指令与已验收parent分别alpha相同。CPU specializer通过不能代替这些核验，本报告目前不宣告设备资格。

## 源身份

```json
{
  "prepare_quantcut.py": "baa1280dc001f88c586f3445c635ba11a8d02692aaba3ee954a4b4db8c90e787",
  "candidate-quantcut.py": "88c32aae9e65f5d63122b0b53a87ac6be81aab9688c1db8a5e0758be1f26fac9",
  "candidate-quantcut.json": "d584ad2e2e12302a17d1ea5ecb3255e9d1dfd3aa548fe8e715db4527eb04095a",
  "quantcut_probe.py": "e0eb4e96f811f9a36b1e98ce27e6a11e8fb549ace7702896d5acf09ed91c6816",
  "run-quantcut.sh": "01d5caeeeb14802539ab2870bcc64cb6919520554b0df809a9131fc98b3b7bcb",
  "check_quantcut.py": "77638799c08c2ec55edabe6b55870cf2f4f083e0e40fa7f14501b56d173a079d"
}
```
