# WO-A 纯等待前缀设备前独立审查

## 结论

**通过，无阻断。** 本次读实际prefix源码、prefix_probe.py、run-prefix.sh及CPU v1/v2的PTO/C++生成物；未运行设备、未改源码或SDK。可先T126逐位门禁/无插桩计时，通过后再独立采DFX。

这是同一WO-A生产者旁的AIV等待干预，不是完整后缀或新的Native资格。旧ascending wait24只保留历史，本次运行臂确为idle、wait8、wait24aligned。

## 实际AIC与AIV代码

独立提取三个actual PTO cube函数，去loc定位后按首次出现将SSA作双射改名；另对C++ cube去pto注释/空白，将v变量作双射改名。保持全部常量、类型、指令、layout、地址、控制结构不变。结果：

```text
idle.AIC PTO == wait8.AIC PTO == wait24aligned.AIC PTO
idle.AIC C++ == wait8.AIC C++ == wait24aligned.AIC C++
```

因此三臂没有编译出不同MMA/K序、不同搬运或不同buffer/event代码来混杂等待效果。源码抽取仍含原完整WO-A与最终publish1，没有把store/publish顺序提前。

源码vector均没有业务load/store/cast/matmul、没有读accum。AIV仍执行相同begin与共同尾fence/cacheinvalid/fence/bar_all，root保持MIX、24组/split48AIV与sync_start。idle不会被误当成包含cast的臂。

wait24aligned使用与wait8相同的base和前8个owner顺序，之后覆盖其余16个，避免同时更改首热点。共同尾维护次数相同但发生时刻不同，因此结论仍限定等待协议及随后的维护并发效应，不能称差值为纯TWAIT成本。

## 身份绑定与金值

probe实际硬pin phase1父文件f22d7d8d，三个prefix文件分别检查PREFIX_SOURCE_PROOF的actual SHA。冻结O-proj/HC-post的真实import路径及SHA也检查，并保留隔离SDK/PTOAS收据。

gold通过完整phase1在**独立accum**运行，取有效`[:T,:8192]`的FP32 CPU clone作字节金值；完整后缀后续只读该FP32accum，WO-B写独立integer。不是用BF16结果掩盖低位差。

四臂gold/idle/wait8/wait24aligned各自8个缓冲地址唯一、共32个地址；各信号数组独立。A/B/A中先用gold重新计算B并确认A/B不相同，再比三个前缀；恢复A后按原gold_a严格比字节。final readonly要求heads已恢复到A。

## guard与有效行

- 前缀只毒化有效accum为NaN，结果要求finite且逐bit等gold，不能沿用旧输出假通过。
- 所有buffer两端16行guard及signal首尾128项guard保留。
- 每个arm的accum padded区域`[T:]`必须一直为-91；实际AIC GM store使用动态valid rows，仅写真实T，因此该断言与生成物一致。
- 三前缀的projected、quantized、token_scale、attended、output、integer全部保持-91，证明没有意外执行其它阶段；gold不受该“未用业务输出”约束。
- signal unused phase/槽必须为0，line内其余127项必须为0。业务占位输出未执行不能写成五边界数学通过，report的scope当前正确。

字节比较可捕获有符号零差异；即使different_elements按浮点比较对此计0，bit_equal仍会失败并停，不会放宽门禁。

## generation核算与无早读

三个前缀只使用phase0全72核与phase1的24个AIC发布槽。generation函数采用该专用mask，未误用完整后缀phase2…5。每次图完成后才读accum；idle的AIV先结束不是整个MIX完成，probe用整图stream/设备同步保证读取时机。

预期最终值正确：

```text
timing = eager1 + FULL A/B/A三次 + 12*(单次1 + 连续100) = 1216
DFX    = eager1 + FULL A/B/A三次 + 每arm三次单回放        = 7
```

捕获前后会检查实际generation，若框架语义额外执行导致计数不同，硬断言会失败，而非静默接受。正式timing每小窗所有arm各增加count，并在比较时要求三者相等。

DFX每个arm只要求当前方+1、其它方+0，整轮三臂均完成后再compare并恢复三者generation相等；每臂工作区独立，比较前不会由该臂下一次回放覆盖首差。guards在每个arm后检查，不存在遗漏idle输出的提前结束。

## init、计时与DFX schema

init仅在mode条件的if/else中二选一：timing无插桩，DFX启用swimlane1且dep-gen=False。没有第二次无参init，也没有旧PMU footer引用未定义samples的问题。

单次/100次各12个窗口分开保存；每窗轮换先测哪种count，arm rotate/reverse保持位置均衡。每次事件对只包所选prefix graph回放，gold/poison/CPU检查均在外；同一stream录制、回放及事件同步。单次结果包含入口/调度，不能命名为纯核内时间。

DFX独立分支不执行正式timing循环。每窗严格验证level1、50MHz、24AIC+48AIV、72条且core集合0…71、6列schema、start≤end、1个root boundary、dropped=0。总span及AIC/AIV span直接取该窗记录，不能相加或与正式时间相减求wait。

## 已核SHA256

| 对象 | SHA256 |
| --- | --- |
| prefix-idle.py | 3886c200f94b3bf8c1193a409111601957e1d79edd431a0843b6f7d0bd195c21 |
| prefix-wait8.py | 6427785090edfc678a375e9545490eb1e29e71debe56f0f71ed5e8fac712b5d3 |
| prefix-wait24aligned.py | cda78a013d32c76a988ba2f736c7504467d857bb73ff1e55ac2d8073e9555faa |
| prefix_probe.py | 698ff22a24d0b5f94abdc23cfbdb9cb70962451a558ff0e3d08f41234bc158d5 |
| run-prefix.sh | d80c4b5559a2ed69c22302117e521c2f5febe3abe0d6703bd3e7e16fcad3f37e |
| idle PTO | c6154cd6439d91bfc202eb3e5437435dfbd0a69b4fdb82790b582127e26afab1 |
| idle C++ | 362f53bf0824d30713d364d932f51bc228db01f832abfc69e8b224ba5a78d7f2 |
| wait8 PTO | a90278a7268cce1cf04710f87e3566115fcf46307e6865efb83a87aa2c35d93a |
| wait8 C++ | 5c3566d1cbd0db97db561511ab916dcfec888347a0e7c371adee1920dd00f126 |
| wait24aligned PTO | e3d93916f60c188c517f3a7da6f68fbbd22acd3e1d9551976c7546e144861dc6 |
| wait24aligned C++ | d9d70beeecfec39e00d64bbd7e251df6e3eee21ed653962c36bb62d9715a56c7 |

后续硬件FP32或协议首差即停；没有首差才解释性能。即使前缀显示并发等待影响，也不能直接宣布完整后缀变快或进入整模型，需另做实际优化及完整范围门禁。
