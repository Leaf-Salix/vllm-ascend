# WO-A 后单切点、单顶层两 MIX 设计独立审查

## 结论

**设计可行，有两项必须作为实现门禁：真实任务切分与第二段的payload acquire。** 当前仅设计审查，不代表新源码、实际编译或硬件资格；未改正式源/SDK，未提交设备。

第一MIX保留已审idle前缀，第二MIX复用同代际并执行cast/quant/WOB/dequant/HCpost，可以去掉WO-A旁的AIV等待，同时保留单PTO注册入口。是否抵消更多任务切换及失去的WO-A/cast重叠，必须用完整后缀总延迟验证，不从纯等待探针差值预测。

## 阶段和依赖

```text
单PTO顶层
  MIX1
    AIC: begin(g+1) → 原WO-A → publish1(g)
    AIV: begin(g+1) → idle原公共维护
    返回accum、signals等必要InOut
             │ 真实producer→consumer任务依赖
  MIX2
    每core: 获取自己的phase0 current g（不递增、不notify0）
    AIV: payload acquire → cast → publish2 → 原owner2 wait2
         → quant → publish3 → wait4 → dequant → publish5 → wait5 → HCpost
    AIC: 原wait3 → WOB → publish4
```

第二段不再有人等待phase1，保留第一段publish1可作为固定基线和协议核验。没有必要让MIX2再次publish1；也不能把publish2/3/4/5当冗余删除。

## 真实切分不能靠命名

cluster name不同只是源码提示，不能代替实际设备边界。必须在生成物确认：

1. 顶层仍一个注册根、既定Tensor ABI；生成两个独立MIX任务/提交，每个24AIC+48AIV。
2. MIX1返回的实际accum、signals SSA值被MIX2传入，不是原始别名变量绕过返回链。
3. orchestration/runtime TaskArgs方向及依赖记录，使MIX2等待整个MIX1完成；不能只等待某个AIV早结束，也不能靠scope exit。
4. 两MIX没有被重新融合成同一个无全局phase屏障的MIX。若融合，第二段AIV可能在AIC未完成WO-A时cast，违背本设计。
5. accum和signals的父owner在第二段完成前存活，无scope释放/复用；私有实验使用外部持有workspace，不应新增GM alloc或Tensor ABI。

若一个spmd区间中的两个cluster未生成两个任务，可用同顶层中两个顺序spmd区间表达切点；这是DSL结构选择，仍须actual任务图证明，不建议改SDK调度器。

## current generation获取

MIX1已有全部72个core的begin，分别将自己的phase0从g-1推进到g。MIX1完整结束后，MIX2用同一core编号读取自己的phase0即可：AIC core=worker，AIV core=24+worker。

保留原begin的“invalidate本signal行→fence→read”顺序，仅去掉+1及notify0；可以保守保留本核bar_all。不得读取别core代际、重复递增、沿用host常量1或读取phase1当作全体代际。

后续所有wait/notify都用此current g。MIX1完整完成这一前提保证72个phase0已同代际；根结束后仍严格核全used槽同g及unused为0，不能将不一致normalize掉。原全后缀每调用只推进一次generation：两MIX不是两代，若最终计数变成双倍应停下来定位。

独立workspace和同stream顺序graph回放约束不变；允许并发的多调用必须有各自workspace/signals，不能在无ACK条件下复用上一代。

## 第二段仍需获取accum payload

**删除原phase1等待时，保留其末尾fence/cacheinvalid ALL/fence，再进行cast。** 第二段current-g helper只invalidate自己的phase0 signal行，并不等价于获取accum的缓存内容。

第一MIX AIV的公共维护可能早于WO-A写回完成，不能单凭它宣称consumer payload已获取。跨任务完成依赖解决执行先后，但这不构成删除已验收payload维护的理由；先保留原维护可以避免同时引入缓存协议因素和潜在跨回放陈旧读取。

第二段AIC的原wait3及其payload acquire，AIV的owner2 wait2、wait4、wait5及各自维护全部原样；本次只删除跨MIX已由任务边界保证的phase1 signal轮询。

## 无新增环与正确性边界

MIX1没有等待第二段发布，因此可以独立完成。MIX2中AIC先wait3，AIV有已完成的accum可执行cast/quant并publish3，随后AIC执行WOB/publish4，AIV继续后段。没有AIC等AIV同时AIV又等MIX1 AIC发布的闭环。

即使部分AIV没有cast/quant工作，原publish2/3仍保留。owner2的必要8owner等待不能误限制producer发布，否则会出现缺signal或死锁。

跨段只保留原FP32 accum，没有cast/拷贝重算中间值。真实TND行数、Native校准K序、每次BF16舍入、全8192共同量化、INT32 WO-B、HCpost顺序均保持。先比较FP32 accum，再五个最终边界，首差停止。

## alpha/生成物应检查什么

- MIX1 AIC与已审idle前缀的数学、MMA宽度/init/K轨迹、load/store及publish1一致；确认是否因切开资源共存而改变buffer布局，若变化应记录，不能说唯一变化是等待。
- MIX1 AIV与idle前缀相同，未残留cast或phase1wait。
- MIX2 AIC从原wait3开始至WOB/publish4的数学与顺序一致；只把begin替换为current-g helper。
- MIX2 AIV去掉原phase1轮询但保留acquire，cast之后到HCpost的math AST及实际指令/dtype/舍入/归约顺序一致，owner2等待与全部publish不变。
- actual L0C owner、L1/L0槽及复用事件、真实valid rows/GM store和根InOut方向合法，不把SSA改名或不同cluster标签当作物理正确性证据。
- 顶层编排真实两个MIX及producer依赖、无额外GM alloc；原workspace容量足够，第一段输出在第二段不会提前释放。

alpha比较必须保留常量、地址、layout、控制和算术顺序，只移除源定位/生成变量名；对原必须删除的等待/替换的helper先界定明确区域，不通过大范围删除差异来制造一致。

## 最小验证顺序

先CPU完整PTOAS/CCEC与任务图审查，纯等待结果不足以支持干预时不急着上卡。若推进，只做T126小任务：旧owner2完整根、两MIX新根、冻结后缀同任务同输入，五边界/FP32 accum、FULL A/B/A、poison、guard、readonly、signal代际严格对拍。

无插桩连续和单次分别测，记录两MIX内部调度成本。DFX另任务，不能从两个role包络相加或从前缀差值扣除同步得到收益。新根若仍慢冻结，不进入完整CSA/整模型；不把切段控制升级为默认实现。
