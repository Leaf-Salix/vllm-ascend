# WO-A 生产者与 AIV 等待并发的独立设计审查

## 结论

**方向合理，先用不含 cast 的三个前缀控制更有识别力，再考虑完整后缀切段。** 原冻结实现及前轮候选保留。本文是设计/初步源结构审查，不给新实现编译或设备资格；未改运行源码/SDK、未提交设备。

从phase1抽取同一WO-A计算、load/store和同一phase1发布，AIV分别空闲、等必要8 owner、等全部24 owner，能检测“等待协议并发是否改变该WO-A生产者的表现”。它不能直接分解为纯计算、纯搬运、纯wait，也不能唯一判定signal导致DDR争用。

若wait8/wait24臂同时执行cast，而idle臂把cast移到图外，AIC跨度差还含cast DMA/缓存竞争。第一轮应三臂都不读accum、都不做cast，只在整个图结束后对有效FP32 accum逐bit；必要BF16检查使用相同的独立cast入口，置于该轮计时之外。

## 最小控制矩阵

| 臂 | AIC | AIV | 业务输出与主要比较 |
| --- | --- | --- | --- |
| idle | 同一WO-A+publish1 | 相同begin，无等待 | 图完成后比FP32 accum |
| wait8 | 完全相同 | 只等原cast所需8个owner | 同上 |
| wait24 | 完全相同 | 等全部24 owner | 同上 |

三臂同为24AIC/48AIV、同一sync_start、同一根ABI、独立同容量工作区/信号。保留AIV begin等可见副作用，避免idle被编译器优化成不同类型的纯AIC根。

共有fence/cacheinvalid/bar_all若保留，三臂应次数/指令相同。当前prepare_prefix的共同尾部维护符合这个控制；但其执行时刻随wait不同，因此最终差异仍是**等待及随后的协议维护并发效应**，不能专称TWAIT单条指令成本。若以后需要更窄定位，可另做不读payload的bare-wait控制，不能混到本轮结果里。

### 等待顺序这一额外因素

必要8 owner按 `base=8*(worker%8)`，再`(base+dep)%24`产生；不同AIV首个等待热点为0/8/16。旧全24升序始终先等owner0。

因此当前ascending wait24与wait8不仅改变集合大小，也改变首热点/轮询顺序。最小匹配对照可让wait24也用`(base+dep)%24,dep=0…23`：首8项与wait8相同，随后覆盖其余16个owner。这样仍是全24合法等待，却更接近“只扩集合”的实验。

若保留旧ascending24以复现历史协议，也可以，但必须明确其差异含热点分布，不把全部改善归因于少16次调用。两种24顺序不要事后换标签或挑有利结果。

## 信号与生命周期

当前phase1必要集合为：

```text
active_cast = worker < ceil(T/16)*8
AIC_owner[dep] = (8*(worker%8)+dep)%24, dep=0…7
signal_index = (CORES + AIC_owner)*STRIDE
```

Cube的logical=group*8+N128block，owner=logical%24；cast worker的全部工作保持group=worker%8。因此8个producer发布完成足以覆盖该worker原本会读取的全部accum，包含M128/M16回退和所有行panel。第一轮虽不实际cast，也应沿同一active谓词定义8/24控制。T126/T240全部48AIV都有原cast工作，不混入小T空核数量差。

- 所有24AIC必须在WO-A有效store完成后按同一publish1执行bar/fence/cache维护并notify；不要把信号提前到计算完成但GM写尚未可见。
- AIV只等当前generation；独立signal数组、初始清零、每次各自begin推进，phase0的72个槽与phase1的24AIC槽严格核对。不要沿用完整后缀“所有phase2…5必须使用”的校验mask，因为本探针没有这些阶段。
- idle臂AIV可以先结束，但这不是Cube已结束。必须等整个MIX/graph完成，才读取accum或运行独立cast。bar_all是本核pipeline屏障，不能用它替代跨核完成。
- graph连续回放使用同一stream顺序独占对应scratch/signals，不允许下一代覆盖上一代仍在使用的accum。AIV notify并不是对Cube的消费ACK。
- wait依赖只有AIC→AIV；Cube发布phase1不依赖AIV，省去后续WOB/quant等待后没有新增环。所有根应仍完整返回必要InOut，不能在idle分支丢掉signal写回的编译语义。

## 精度金值应优先使用FP32

已验收的完整phase1/owner2后缀在同输入下会保留WO-A FP32 accum，后续只读它，WO-B写另一个integer_accum。可先用该根的独立工作区产生gold，再比较三种前缀的`accum[:T,:8192]`原始字节；这比只看BF16 cast结果更能发现低位变化。

不要把前缀未执行的projected/quantized/attended/output冒称为五边界通过。这些ABI占位输出应保持原sentinel，证明没有意外写入。各arm先NaN毒化有效accum、检查guard，A/B/A改变heads后必须改变gold且恢复逐bit；权重/start/input与缓冲只读范围独立核SHA。

如追加BF16 cast，三臂都在前缀图完成后通过**同一**独立cast根，相同grid与舍入；不把一个臂的图外cast成本算入前缀延迟、另两臂却排除。第一轮直接FP32验证已足够，无需为了观测引入新的数学。

## 必须核实际生成物

当前prepare_prefix从原cube前6条语句（含完整WO-A分支及publish1）抽取，三臂cube AST相同；vector不含业务load/cast。这个抽取思路合理。

但移除WO-B可能改变WO-A的片上共存、缓冲或事件推导。必须对三臂实际AIC PTO/C++做独立alpha等价检查：保留常量、地址、layout、MMA宽度/init/K轨迹、有效行、store及publish指令比较。仅证明AST数学相同不够；若实际AIC代码不同，应先修控制，不能把差异全部归因于AIV等待。

前缀与原完整后缀的actual代码也要记录是否发生资源变化。三前缀之间等价可支持本探针内的因果判断，但不能自动把变化量等比例搬回完整后缀。

## 计时与结论范围

无插桩单次回放与100次连续回放分开：先充分预热/首差门禁，再同任务按位置平衡轮换三臂，分别保存所有窗口。单次事件区间含入口/调度，不能与核内DFX直接相减算等待。图中不要夹cast、CPU同步、张量拷贝或清零。

DFX另任务、dep-gen关闭。比较同一AIC生产者的完整span/逐core分布、AIV span及root总跨度，核core_types、记录数、时钟、run_boundaries。AIC span含begin、WO-A、publish及尾同步，不是纯MAC时长；忙等若使其变长，也可能作用在load、cache维护、信号发布等不同环节。

可以下的结论例子是“相同实际AIC程序在该等待协议并发下span变长/不变”；不能下“差值全为wait”“每次dcci必到DDR”或“全部减去就是计算时间”。若三前缀没有明显差异，不应继续把等待当已证唯一瓶颈。

## 完整后缀切两段的后续实验

这属于实际性能方案，不是第一轮纯等待探针。可保留同一WO-A根作为第一段，第二段执行原cast→quant→WOB→dequant→HC-post，省掉第二段对上一根WO-A信号的轮询：同一ACL stream中第一根完成及accum的明确Out→Input依赖提供可见性。

两段必须在同一个graph按实际stream顺序捕获；不能仅靠Python调用顺序让第二段在其它stream提前读accum。新的root应逐位保持全部五外部边界和原全8192统一量化。信号最好按各根自己的协议明确分区/重置，不能对未发布的旧phase1 generation继续wait，也不能把第一根独立generation错误当第二根的begin值。

第一段可先复用已测MIX-idle而不是同时改成纯Cube，以减少新因素；若改纯Cube，另立控制。第二段内部AIV quant→AIC WOB、AIC WOB→AIV dequant等依赖仍必须保留，不能因切段删除全部signal。

切段会增加入口、root尾同步与调度，减少原先可有的cast/WO-A重叠；也会改变物理资源复用。因此它只能以完整后缀的无插桩总延迟决定是否有效，不能从纯wait差值预测收益。必须同任务对原完整phase1/owner2及冻结后缀，最终先取得对冻结的稳定净收益，再考虑完整CSA和8K/128K整模型。

## 建议的最小顺序

1. 固定一个WO-A数学版本，不混入K128/M256改动，完成纯idle/8/24控制的源码、实际AIC等价和FP32门禁。
2. 先T126一个小任务，采无插桩单次/连续；DFX另采。若结果不足以定位，不急着做更多形状/大模型。
3. 确认并发协议影响后，再做完整后缀两段单因素，原数学逐bit优先、每任务<15分钟；不是将诊断探针当优化交付。

初审读取的prefix-wait24当前为旧ascending24。本报告提出匹配首8项的建议；若之后调整控制，须冻结新SHA并据实记录，不将本份设计审查当作未读新版实际生成物已通过。
