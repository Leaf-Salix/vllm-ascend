# 两 MIX 后缀切分：设备前独立审查及首档结果

## 结论

当前 `phasecut-acquire` 未发现阻断。这里的先后关系来自实际生成编排中两个 task 对同一 Tensor 的 `InOut` 依赖，不能用 `scope` 退出或两个 cluster 的名字替代这一证明。v1 缺少 payload acquire 的版本仅留档；v2 注册名称失败不是数值通过；本报告绑定完成完整编译/Artifact load 的 v3，以及随后独立读取的 T126 实测。

本审查只写 reports，未改正式实现、SDK，也未提交设备任务。

## 实际编排与可见性

实际文件为 `generated/woa-phasecut-cpu-v3/phasecut-acquire/orchestration/resident_suffix.cpp`：

- 单个公开顶层，16 Tensor 参数；两次 `rt_submit_task`，分别为 `MixedKernels{0,1,1}` 和 `{2,3,3}`，均 24 block、`require_sync_start=true`。没有新增 `rt_alloc`。
- 两 task 使用同一 `ext_accum`、`ext_signals` 以及其余输出的 `add_inout`。Simpler 当前 A2/A3 TensorMap 将 InOut 建立为生产者；`CoreTaskArgs::allow_early_resolve_` 默认为 false，本编排未设置 early resolve。因此第二 task 具有第一 task 完成的实际依赖，不依赖隐含核内 barrier。
- 第一段 AIC 数学及 publish1 与 owner2 原 WO-A 相同；第一段 AIV 只有 begin 和原 cache/fence 动作，没有业务读取/转型。第一段不能形成等待第二段的环。
- 第二段在自己 phase0 槽上执行 `cacheinvalid(singleline) → fence → read`，不递增、不重新 notify phase0。所有 72 个 core 的 begin 只执行一次。
- 第二段 AIV 在读取 accum 前保留原有效 worker 条件下的 `fence → cacheinvalid(all) → fence`。实际 tail PTO 的第276–278行仍有三条 acquire，之后第295行才是 accum `tload`。只刷新 phase0 信号行不能替代此 payload acquire。
- 第二段 AIV cast/publish2、八 owner 量化等待/publish3、AIC wait3/WO-B/publish4、后续 dequant/publish5/HC-post 均保留。非活跃计算 worker 的 publish 仍存在，不因短 query 少发通知。

## 数学与容量

直接解析两份实际源码 AST，以下全部相同：原三个同步 helper；整个 WO-A 分支及 publish1；原 cube 从 wait3 到 WO-B/publish4 的节点；原 vector 从 cast 到返回的全部节点；payload acquire 的条件及三条操作。没有重写 K 次序、MMA 分组、全8192列量化、scale 或 BF16 舍入边界。另独立比较实际 prefix PTO 的 Cube 函数与已验收 idle prefix：去除位置、函数名及双射 SSA 命名后相同，保留全部指令、常量、布局与地址。

工作区仍是父版本容量：FP32 accum `[T+127,8192]`、INT32 integer `[T+63,4096]`；公开输出真 T。两段都使用同一父级 GM descriptor，不额外跨 scope 分配临时 GM，不改真实 TND 语义。这里只测试 T126，不能把其结果自动作为任意 T/任意 start 的新增硬件资格。

## Harness

- 三臂为冻结 O-proj+HC-post、owner2、phasecut；parent SHA 链和两个实际冻结模块路径/SHA 均检查，候选与其 proof 的 SHA 匹配。
- FULL 图每臂使用独立输出、accum、integer、signal；16个关键地址不重复；共有只读输入有运行前后 SHA。
- 五边界为 projected BF16、quantized INT8、token_scale FP32、attended BF16、output BF16；每次比较浮点有限且逐字节一致。eager、FULL A/B/A、12窗后逐次检查；首差抛错。
- NaN/整数按位取反毒化、外层 guard、信号 unused 槽和完整 publish mask、每窗各自 generation+100 均保留。最终代际为1204，而非两 MIX 各递增一次。
- 计时为同一 graph stream 上12窗×100连续回放，三臂位置轮转/反序；检查与 poison 在事件区间外。额外 MIX 的实际调度成本包含在候选计时内。
- 此 harness 没有将内部有效 FP32 accum 单独纳入五边界逐bit比较。该中间数学有上述 source/实际 prefix alpha 证明；不要把五边界通过表述为观测过全部内部 FP32 比特。

## 已独立读取的 T126 首档结果

`task_20261020_215049_28019839922` 经只读 `task-submit --status` 确认 completed(exit=0)。本地 JSON 的 harness SHA 与当前源匹配；pass/complete、actual_acl_graph、guards、readonly 均为 true。16轮×2候选×5边界 = 160项逐bit通过，parent/new generation均1204。

| FULL后缀，T126 | mean (µs) | 口径 |
|---|---:|---|
| 冻结 O-proj+HC-post | 403.616616 | 同任务 |
| owner2 单 MIX | 496.625001 | 同任务 parent |
| phasecut-acquire 两 MIX | 456.526931 | 同任务 candidate |

候选相对 parent -8.074114%，12/12窗改善；相对冻结 13.109053%，仍较慢。没有剔除样本。它只证明此档后缀切分效果，不能推出整层/整模型提升，也不能仅凭耗时差判定全部差异来自 AIV 忙等。

## 身份

```json
{
  "candidate-phasecut-acquire.py": "aa1fa9285f4036bc06380e35866f1244ca61450d12b1da372141f01a191e7700",
  "candidate-phasecut-acquire.json": "30ed39a1482c331cc148e7e83ea7ad0b920b9404baf82099447ed6df7ac6daac",
  "phasecut_acquire_probe.py": "82f0f65d5e026e506b2f05525de165858005ed166482f4361de6a2b6545a0dfb",
  "run-phasecut-acquire.sh": "03b05b9a5b3e730c15f96764fbaecae26da2040ddd18f33cf907fe3a46db9c63",
  "woa-contention-cut-t126-v1.json": "ba27bc367dae8fc2b9bbb35dc7f5b337315bc906e38978411da308f1da4469c6",
  "generated/woa-phasecut-cpu-v3/result.json": "cbe8496b815c490d3e3962af9cc3bd969065aac73d13e17f93b6394cf476adca",
  "generated/woa-phasecut-cpu-v3/phasecut-acquire/orchestration/resident_suffix.cpp": "639ed2304745fc78b908a7d2f9e88a6ca3b8e68248bc50ac82ed5461b5cae3f1",
  "generated/woa-phasecut-cpu-v3/phasecut-acquire/ptoas/suffix_prefix.pto": "0eaca48fd4114d5b3df366f9acc78c450fa62303d89d40b6da53d7edfd0b8764",
  "generated/woa-phasecut-cpu-v3/phasecut-acquire/ptoas/suffix_tail.pto": "510b917f987ab4ce37ce319d18e9836684803fbebdcf9ebdf524ee95455d1c1a"
}
```
