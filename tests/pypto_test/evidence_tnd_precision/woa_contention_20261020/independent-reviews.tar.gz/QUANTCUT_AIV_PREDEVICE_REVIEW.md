# Quant-cut AIV48：实际设备前独立审查

## 结论与版本界限

**当前显式 AIV48 v2 未发现设备前阻断，可进行计划的一项 T126 五边界首差停止对拍。** 这只是源码、实际生成物及调度接口资格，不是 NPU 数值或性能通过。本审查未提交任务、未修改候选、SDK或正式源码。

前一版 quantcut-v1 虽然完整CPU编译成功，但 middle实际ID2为无业务的 `cube_quant_idle`；两个函数均被判AIV后，所需 `vector_quant` 没有进入注册表。其“三MIX”源级设计没有转化为实际执行，明确**未获设备资格、不上卡**。此前 `QUANTCUT_SOURCE_REVIEW` 已明确 actual review pending，不能借该源级PASS给v1补数值资格；本报告不改写该失败历史。

## 实际角色和调度

实际 `kernel_config.py` 五项为：

| ID | 角色 | 函数 |
|---:|---|---|
|0|AIC|cube_prefix|
|1|AIV|vector_prefix|
|2|AIV|vector_quant|
|3|AIC|cube_wob|
|4|AIV|vector_post|

实际 `orchestration/resident_suffix.cpp` 为：

1. prefix `MixedKernels{0,1,1}`、24block、sync_start。
2. middle `rt_submit_aiv_task(2)`、48block、sync_start。
3. post `MixedKernels{3,4,4}`、24block、sync_start。

中段不再声称MIX，也没有假AIC占位。actual wrapper 解包16 Tensor以及三个动态维度，从 `get_block_idx(args)` 读logical worker；无 subblock 参数/读取，传给 vector_quant 的就是同一逻辑worker。

独立核对固定 Simpler 57e499… 的当前 A2/A3 runtime：`rt_submit_aiv_task`设置AIV0函数槽；当ResourceShape=AIV时，scheduler每个logical block提交一个AIV subtask，使用整个AIV资源池；sync_start容量上限是 `total_aiv_count`，不是24个cluster。`build_payload`将logical block index写入LocalContext，wrapper通过它读取编号。因此48block对应完整0…47逻辑worker，不能误解为只运行每cluster的物理AIV0共24核。具体物理core可以重排，业务ownership只由logical worker决定。

## 数学、ownership与可见性

- prefix、三个原同步helper、current-generation、prefix group逐AST与两MIX父版相同；实际prefix Cube PTO在仅移除位置和双射SSA命名后也与父版相同。
- 中段只移除split_aiv属性，将 `2*block+subblock` 改成 flat block index；其后 `core=24+worker`、cast acquire、cast、publish2、八owner wait2、全8192列统一amax/量化、publish3的AST与原quantcut-v1逐节点相同。
- CPU枚举T=1…256：旧24×2编号与新48编号均为0…47；cast task、8行量化task覆盖各真实block恰一次；每量化worker仍等待其16行cast块的8个列owner。core signal槽仍为24…71，无物理ID假设。
- third WO-B和vector post与已审源逐AST相同；WO-B仍按原K512×16顺序。wait3被实际前一task完成依赖替代，`fence/cacheinvalid(all)/fence`保留在业务读取前；没有删除payload acquire。
- 三task均 `add_inout` 同一 projected/quantized/token_scale/attended/output/accum/integer/signals。编排未开启early resolve，当前runtime默认false。因此middle业务完成后才能进入post，依赖不是scopeexit或同源码先后顺序。
- 16 Tensor根ABI、原8InOut/return aliases、原工作区容量均不变，没有rt_alloc。只在prefix begin递增一次；middle/post读本core phase0代际，不额外递增。publish mask和所有非活跃worker通知仍保持。

## 对拍与风险限制

`quantcut_aiv_probe.py`相对已审quantcut助手只改变variant与合法组合断言；parent仍显式两MIX `phasecut-acquire`，不拿owner2跨任务结果作为增量收益。保留真实L4权重、frozen/parent/new三臂、独立工作区、FULL A/B/A、160项五边界逐bit/finite、毒化/guards/只读SHA、信号完整mask及最终1204代、12×100同stream轮换计时、首差停止。750秒内timeout由脚本保持，外层设备时限由提交者保持780秒。

五边界通过不等于逐元素观测了内部FP32 accum。第三段切分还会增加一次AIV48 task和同步启动成本，去掉中段AIC并发轮询是否有净收益只能由实测决定。不能将变化单独归因于DDR字节、固定wait开销，不能外推完整CSA/整模型性能。

## 固定身份

```json
{
  "candidate-quantcut-aiv.py": "9b55b2da48544c30895b834b4497e13675b56867b1e0a06823aa09be9a9ba994",
  "candidate-quantcut-aiv.json": "545a70366a6d049490d681c31d694b07e3d1d910e1381e842f8773e1e64f4035",
  "quantcut_aiv_probe.py": "33d12cc1bd6c7e30077902e19b1a7e994ffd5b35345b906cc1777c06243f4e5f",
  "run-quantcut-aiv.sh": "81d92f3e46c79408545992f15f498031d547b6fee96e01e0c9b712c78690ae22",
  "generated/woa-quantcut-cpu-v2/quantcut-aiv/kernel_config.py": "3970f6af1f586a90f296553e15c36cfb2ae1baddc8ebeba5a4d21463ceb60711",
  "generated/woa-quantcut-cpu-v2/quantcut-aiv/compiled_meta.json": "2c40ae42e31bba8ec4d598e02b037292bd42e4841e170d974d7723e6ca9936c2",
  "generated/woa-quantcut-cpu-v2/quantcut-aiv/orchestration/resident_suffix.cpp": "d8debd6048c44c20cefed708aa4d87afeed4419c2ae570b69636440769ca744e",
  "generated/woa-quantcut-cpu-v2/quantcut-aiv/ptoas/suffix_prefix.pto": "ca89ed92ecbb6c9842d0400058eb707930c6c3543165c2f78eac353f3ca95969",
  "generated/woa-quantcut-cpu-v2/quantcut-aiv/ptoas/suffix_quant.pto": "f621677e2aa047ea42af521e60260fab2917211c8f9e50da4ed50800e1980505",
  "generated/woa-quantcut-cpu-v2/quantcut-aiv/ptoas/suffix_post.pto": "e4cec55284be33b0a177f52ee3660fc2dddcbb038882eafeea41516f7ea54de1",
  "generated/woa-quantcut-cpu-v2/quantcut-aiv/kernels/aiv/vector_quant.cpp": "890d06dba7b21bcf831c16cf7909bfa0754824894c169384bd787b234de37fcd",
  "generated/woa-quantcut-cpu-v2/result.json": "4749fef83e70f6a744211509b1afd93813f2269350a978888de198ed0bc3e0d2"
}
```
