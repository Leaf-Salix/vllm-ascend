#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void cube(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ bfloat16_t* v6, __gm__ int8_t* v7, __gm__ float* v8, __gm__ bfloat16_t* v9, __gm__ bfloat16_t* v10, __gm__ float* v11, __gm__ float* v12, __gm__ bfloat16_t* v13, __gm__ float* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int32_t v22 = 1;
  // pto: %c0_i64
  const int64_t v23 = 0;
  // pto: %c65536_i64
  const int64_t v24 = 65536;
  // pto: %c32768_i64
  const int64_t v25 = 32768;
  // pto: %c131072_i64
  const int64_t v26 = 131072;
  // pto: %c196608_i64
  const int64_t v27 = 196608;
  // pto: %c32768_index
  const int64_t v28 = 32768;
  // pto: %c1_index
  const int64_t v29 = 1;
  // pto: %c8_index
  const int64_t v30 = 8;
  const int64_t v31 = 64;
  // pto: %c256_index
  const int64_t v32 = 256;
  // pto: %c16_index
  const int64_t v33 = 16;
  // pto: %c4194304_index
  const int64_t v34 = 4194304;
  // pto: %c65536_index
  const int64_t v35 = 65536;
  const int64_t v36 = 128;
  // pto: %c4096_index
  const int64_t v37 = 4096;
  // pto: %c8192_index
  const int64_t v38 = 8192;
  // pto: %c4_index
  const int64_t v39 = 4;
  // pto: %c55296_index
  const int64_t v40 = 55296;
  // pto: %c0_index
  const int64_t v41 = 0;
  // pto: %c15_index
  const int64_t v42 = 15;
  // pto: %c192_index
  const int64_t v43 = 192;
  // pto: %c24_index
  const int64_t v44 = 24;
  // pto: %c7_index
  const int64_t v45 = 7;
  // pto: %c2_index
  const int64_t v46 = 2;
  // pto: %c3_index
  const int64_t v47 = 3;
  // pto: %c5_index
  const int64_t v48 = 5;
  // pto: %c6_index
  const int64_t v49 = 6;
  // pto: %c240_index
  const int64_t v50 = 240;
  // pto: %c1024_index
  const int64_t v51 = 1024;
  // pto: %c241_index
  const int64_t v52 = 241;
  // pto: %c9216_index
  const int64_t v53 = 9216;
  // pto: %heads__ssa_v0_view
  const int64_t v54 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v55 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %heads__ssa_v0_view
  int64_t v57 = (int64_t) v17;
  // pto: %heads__ssa_v0_view
  int64_t v58 = v57 * v28;
  // pto: %heads__ssa_v0_view
  int64_t v59 = v56 * v58;
  // pto: %heads__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v60 = pto::Shape<1, 1, 1, -1, -1>(v54, v55, v56, v57, v28);
  // pto: %heads__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v61 = pto::Stride<-1, -1, -1, -1, -1>(v55 * v59, v59, v58, v28, v29);
  // pto: %heads__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v62 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v60, v61);
  // pto: %wo_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v63 = pto::Shape<-1, -1, -1, -1, -1>(v30, v31, v32, v33, v33);
  // pto: %wo_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v64 = pto::Stride<-1, -1, -1, -1, -1>(v34, v35, v32, v33, v29);
  // pto: %wo_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v65 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v2, v63, v64);
  // pto: %accum__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %accum__ssa_v0_view
  int64_t v69 = (int64_t) v18;
  // pto: %accum__ssa_v0_view
  int64_t v70 = v69 * v38;
  // pto: %accum__ssa_v0_view
  int64_t v71 = v68 * v70;
  // pto: %accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v72 = pto::Shape<1, 1, 1, -1, -1>(v66, v67, v68, v69, v38);
  // pto: %accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v73 = pto::Stride<-1, -1, -1, -1, -1>(v67 * v71, v71, v70, v38, v29);
  // pto: %accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v74 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v72, v73);
  // pto: %signals__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v78 = 1;
  // pto: %signals__ssa_v0_view
  int64_t v79 = v40 * v29;
  // pto: %signals__ssa_v0_view
  int64_t v80 = v78 * v79;
  // pto: %signals__ssa_v0_view
  int64_t v81 = v77 * v80;
  // pto: %signals__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v82 = pto::Shape<1, 1, 1, 1, -1>(v75, v76, v77, v78, v40);
  // pto: %signals__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v83 = pto::Stride<-1, -1, -1, -1, -1>(v76 * v81, v81, v80, v79, v29);
  // pto: %signals__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v84 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v82, v83);
  // pto: %seed_fast_acc__phi_v7
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v85 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
  // pto: %seed_fast_acc__phi_v7
  uint64_t v86 = (uint64_t) v23;
  TASSIGN(v85, v86);
  // pto: %211
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v87 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
  // pto: %211
  uint64_t v88 = (uint64_t) v23;
  TASSIGN(v87, v88);
  // pto: %249
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v89 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
  // pto: %249
  uint64_t v90 = (uint64_t) v23;
  TASSIGN(v89, v90);
  // pto: %seed_narrow_acc__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v91 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
  // pto: %seed_narrow_acc__phi_v7
  uint64_t v92 = (uint64_t) v23;
  TASSIGN(v91, v92);
  // pto: %v4_wide_acc__phi_v7
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v93 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
  // pto: %v4_wide_acc__phi_v7
  uint64_t v94 = (uint64_t) v23;
  TASSIGN(v93, v94);
  // pto: %v4_narrow_acc__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v95 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
  // pto: %v4_narrow_acc__phi_v7
  uint64_t v96 = (uint64_t) v23;
  TASSIGN(v95, v96);
  // pto: %worker__ssa_v0
  int64_t v97 = (int64_t) v20;
  // pto: %51
  int64_t v98 = (int64_t) ((uint64_t) v97 * (uint64_t) v36);
  // pto: %52
  int64_t v99 = v98 < v41 ? v41 : v98;
  // pto: %signals__ssa_v0_pview
  __gm__ int32_t* v100 = PTOAS__GLOBAL_TENSOR_DATA(v84);
  // pto: %signals__ssa_v0_pview
  const int64_t v101 = 0;
  // pto: %signals__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 1> v102 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  pto::Stride<1, 1, 1, 1, 1> v103 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v104 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v100 + (v101 + v99), v102, v103);
  __gm__ int32_t* v105 = PTOAS__GLOBAL_TENSOR_DATA(v104);
  PTOAS__DCCI_SINGLE_CACHE_LINE(v105);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  // pto: %t__tile
  int32_t v106 = (v16)[v98];
  // pto: %54
  int32_t v107 = (int32_t) ((uint32_t) v106 + (uint32_t) v22);
  pipe_barrier(PIPE_ALL);
  pto::comm::NotifyOp v108 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v104, v107, v108);
  // pto: %56, %57
  int64_t v109 = (int64_t) ((uint64_t) v17 + (uint64_t) v42) / v33;
  // pto: %58
  if (v17 >= v43) {
    for (int64_t v110 = v97; v110 < v31; v110 += v44) {
      // pto: %59
      ;
      int64_t v111 = v110 / v30;
      // pto: %60
      ;
      int64_t v112 = v110 % v30;
      // pto: %61, %62, %63
      ;
      int64_t v113 = v112 < v41 ? (int64_t) ((uint64_t) v112 + (uint64_t) v30) : v112;
      // pto: %64
      ;
      int64_t v114 = (int64_t) ((uint64_t) v113 * (uint64_t) v36);
      // pto: %65, %66
      ;
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v115 = v41; v115 < ((int64_t) ((uint64_t) v109 + (uint64_t) v45) / v30); v115 += v29) {
        // pto: %67
        ;
        int64_t v116 = (int64_t) ((uint64_t) v115 * (uint64_t) v30);
        // pto: %flat_offset, %69, %70, %68
        ;
        int32_t v117 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v115 * (uint64_t) v31) + (uint64_t) v111) * (uint64_t) v30) + (uint64_t) v113)];
        // pto: %71
        ;
        int64_t v118 = (int64_t) v117;
        // pto: %72
        ;
        int64_t v119 = v118 < v41 ? v41 : v118;
        // pto: %73
        ;
        int64_t v120 = (int64_t) ((uint64_t) v116 + (uint64_t) v29);
        // pto: %74
        ;
        // pto: %seed_same_start__phi_v3
        ;
        int64_t v121;
        if (v120 < v109) {
          // pto: %77, %78, %79, %80, %75
          ;
          int32_t v122 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v120 * (uint64_t) v30) + (uint64_t) v111) * (uint64_t) v30) + (uint64_t) v113)];
          // pto: %81
          ;
          int64_t v123 = (int64_t) v122;
          // pto: %82
          ;
          int64_t v124 = v123 < v41 ? v41 : v123;
          // pto: %83, %seed_same_start__phi_v2
          ;
          v121 = v124 != v119 ? v41 : v29;
        } else {
          v121 = v29;
        };
        // pto: %84
        ;
        int64_t v125 = (int64_t) ((uint64_t) v116 + (uint64_t) v46);
        // pto: %85
        ;
        // pto: %seed_same_start__phi_v6
        ;
        int64_t v126;
        if (v125 < v109) {
          // pto: %88, %89, %90, %91, %86
          ;
          int32_t v127 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v125 * (uint64_t) v30) + (uint64_t) v111) * (uint64_t) v30) + (uint64_t) v113)];
          // pto: %92
          ;
          int64_t v128 = (int64_t) v127;
          // pto: %93
          ;
          int64_t v129 = v128 < v41 ? v41 : v128;
          // pto: %94, %seed_same_start__phi_v5
          ;
          int64_t v130 = v129 != v119 ? v41 : v121;
          v126 = v130;
        } else {
          v126 = v121;
        };
        // pto: %95
        ;
        int64_t v131 = (int64_t) ((uint64_t) v116 + (uint64_t) v47);
        // pto: %96
        ;
        // pto: %seed_same_start__phi_v9
        ;
        int64_t v132;
        if (v131 < v109) {
          // pto: %99, %100, %101, %102, %97
          ;
          int32_t v133 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v131 * (uint64_t) v30) + (uint64_t) v111) * (uint64_t) v30) + (uint64_t) v113)];
          // pto: %103
          ;
          int64_t v134 = (int64_t) v133;
          // pto: %104
          ;
          int64_t v135 = v134 < v41 ? v41 : v134;
          // pto: %105, %seed_same_start__phi_v8
          ;
          int64_t v136 = v135 != v119 ? v41 : v126;
          v132 = v136;
        } else {
          v132 = v126;
        };
        // pto: %106
        ;
        int64_t v137 = (int64_t) ((uint64_t) v116 + (uint64_t) v39);
        // pto: %107
        ;
        // pto: %seed_same_start__phi_v12
        ;
        int64_t v138;
        if (v137 < v109) {
          // pto: %110, %111, %112, %113, %108
          ;
          int32_t v139 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v137 * (uint64_t) v30) + (uint64_t) v111) * (uint64_t) v30) + (uint64_t) v113)];
          // pto: %114
          ;
          int64_t v140 = (int64_t) v139;
          // pto: %115
          ;
          int64_t v141 = v140 < v41 ? v41 : v140;
          // pto: %116, %seed_same_start__phi_v11
          ;
          int64_t v142 = v141 != v119 ? v41 : v132;
          v138 = v142;
        } else {
          v138 = v132;
        };
        // pto: %117
        ;
        int64_t v143 = (int64_t) ((uint64_t) v116 + (uint64_t) v48);
        // pto: %118
        ;
        // pto: %seed_same_start__phi_v15
        ;
        int64_t v144;
        if (v143 < v109) {
          // pto: %121, %122, %123, %124, %119
          ;
          int32_t v145 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v143 * (uint64_t) v30) + (uint64_t) v111) * (uint64_t) v30) + (uint64_t) v113)];
          // pto: %125
          ;
          int64_t v146 = (int64_t) v145;
          // pto: %126
          ;
          int64_t v147 = v146 < v41 ? v41 : v146;
          // pto: %127, %seed_same_start__phi_v14
          ;
          int64_t v148 = v147 != v119 ? v41 : v138;
          v144 = v148;
        } else {
          v144 = v138;
        };
        // pto: %128
        ;
        int64_t v149 = (int64_t) ((uint64_t) v116 + (uint64_t) v49);
        // pto: %129
        ;
        // pto: %seed_same_start__phi_v18
        ;
        int64_t v150;
        if (v149 < v109) {
          // pto: %132, %133, %134, %135, %130
          ;
          int32_t v151 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v149 * (uint64_t) v30) + (uint64_t) v111) * (uint64_t) v30) + (uint64_t) v113)];
          // pto: %136
          ;
          int64_t v152 = (int64_t) v151;
          // pto: %137
          ;
          int64_t v153 = v152 < v41 ? v41 : v152;
          // pto: %138, %seed_same_start__phi_v17
          ;
          int64_t v154 = v153 != v119 ? v41 : v144;
          v150 = v154;
        } else {
          v150 = v144;
        };
        // pto: %139
        ;
        int64_t v155 = (int64_t) ((uint64_t) v116 + (uint64_t) v45);
        // pto: %140
        ;
        // pto: %seed_same_start__phi_v21
        ;
        int64_t v156;
        if (v155 < v109) {
          // pto: %143, %144, %145, %146, %141
          ;
          int32_t v157 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v155 * (uint64_t) v30) + (uint64_t) v111) * (uint64_t) v30) + (uint64_t) v113)];
          // pto: %147
          ;
          int64_t v158 = (int64_t) v157;
          // pto: %148
          ;
          int64_t v159 = v158 < v41 ? v41 : v158;
          // pto: %149, %seed_same_start__phi_v20
          ;
          int64_t v160 = v159 != v119 ? v41 : v150;
          v156 = v160;
        } else {
          v156 = v150;
        };
        // pto: %150, %seed_same_start__phi_v25
        ;
        int64_t v161 = v119 > v50 ? v41 : v156;
        // pto: %151
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        if (v161 == v29) {
          int64_t v162 = (int64_t) ((uint64_t) v115 * (uint64_t) v36);
          // pto: %153
          ;
          int64_t v163 = (int64_t) ((uint64_t) v17 - (uint64_t) v162);
          // pto: %154
          ;
          int64_t v164 = v163 < v36 ? v163 : v36;
          // pto: %155
          ;
          int64_t v165 = (int64_t) ((uint64_t) v119 * (uint64_t) v33);
          // pto: %seed_fast_seed_x__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v166 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v164, v32);
          // pto: %seed_fast_seed_x__tile
          ;
          uint64_t v167 = (uint64_t) v23;
          TASSIGN(v166, v167);
          // pto: %156
          ;
          int64_t v168 = v162 < v41 ? v41 : v162;
          // pto: %157
          ;
          int64_t v169 = (int64_t) ((uint64_t) v111 * (uint64_t) v37);
          // pto: %158
          ;
          int64_t v170 = (int64_t) ((uint64_t) v169 + (uint64_t) v165);
          // pto: %159
          ;
          int64_t v171 = v170 < v41 ? v41 : v170;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v172 = 0;
          // pto: %heads__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v173 = PTOAS__GLOBAL_TENSOR_DATA(v62);
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v174 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v175 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v176 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          int64_t v177 = v164 * v28;
          // pto: %heads__ssa_v0_pview
          ;
          int64_t v178 = v176 * v177;
          // pto: %heads__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, -1, 256> v179 = pto::Shape<1, 1, 1, -1, 256>(v174, v175, v176, v164, v32);
          // pto: %heads__ssa_v0_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v180 = pto::Stride<-1, -1, -1, -1, -1>(v175 * v178, v178, v177, v28, v29);
          // pto: %heads__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v181 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v173 + (v172 + v168 * v28 + v171 * v29), v179, v180);
          TLOAD(v166, v181);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %seed_fast_seed_w__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v182 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
          // pto: %seed_fast_seed_w__tile
          ;
          uint64_t v183 = (uint64_t) v24;
          TASSIGN(v182, v183);
          // pto: %160
          ;
          int64_t v184 = v111 < v41 ? v41 : v111;
          // pto: %161
          ;
          int64_t v185 = v114 / v33;
          // pto: %162
          ;
          int64_t v186 = v185 < v41 ? v41 : v185;
          // pto: %163
          ;
          int64_t v187 = v165 / v33;
          // pto: %164
          ;
          int64_t v188 = v187 < v41 ? v41 : v187;
          // pto: %wo_a__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v189 = PTOAS__GLOBAL_TENSOR_DATA(v65);
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v190 = 0;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v191 = 4194304;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v192 = 65536;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v193 = 256;
          // pto: %wo_a__ssa_v0_pview
          ;
          pto::Shape<1, 8, 16, 16, 16> v194 = pto::Shape<1, 8, 16, 16, 16>();
          // pto: %wo_a__ssa_v0_pview
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v195 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %wo_a__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v196 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v189 + ((v190 + v184 * v191) + v186 * v192 + v188 * v193), v194, v195);
          TLOAD(v182, v196);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %seed_fast_acc__tile_l0_init_storage
          ;
          Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v197 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
          // pto: %seed_fast_acc__tile_l0_init_storage
          ;
          uint64_t v198 = (uint64_t) v23;
          TASSIGN(v197, v198);
          v197.SetValidShape(v164, v36);
          // pto: %seed_fast_acc__tile_l0_a
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v199 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v164, v36);
          // pto: %seed_fast_acc__tile_l0_a
          ;
          uint64_t v200 = (uint64_t) v23;
          TASSIGN(v199, v200);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          uint16_t v201 = static_cast<uint16_t>(v41);
          uint16_t v202 = static_cast<uint16_t>(v41);
          TEXTRACT(v199, v166, v201, v202);
          // pto: %seed_fast_acc__tile_l0_b
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v203 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
          // pto: %seed_fast_acc__tile_l0_b
          ;
          uint64_t v204 = (uint64_t) v23;
          TASSIGN(v203, v204);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          uint16_t v205 = static_cast<uint16_t>(v41);
          uint16_t v206 = static_cast<uint16_t>(v41);
          TEXTRACT(v203, v182, v205, v206);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          // pto: %0
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v207 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v164, v36);
          // pto: %0
          ;
          uint64_t v208 = (uint64_t) v25;
          TASSIGN(v207, v208);
          uint16_t v209 = static_cast<uint16_t>(v41);
          uint16_t v210 = static_cast<uint16_t>(v36);
          TEXTRACT(v207, v166, v209, v210);
          // pto: %1
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
          // pto: %1
          ;
          uint64_t v212 = (uint64_t) v25;
          TASSIGN(v211, v212);
          uint16_t v213 = static_cast<uint16_t>(v36);
          uint16_t v214 = static_cast<uint16_t>(v41);
          TEXTRACT(v211, v182, v213, v214);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          TMATMUL(v197, v199, v203);
          pipe_barrier(PIPE_M);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
          TMATMUL_ACC(v197, v197, v207, v211);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
          for (int64_t v215 = v29; v215 < v42; v215 += v46) {
            // pto: %165
            ;
            int64_t v216 = (int64_t) ((uint64_t) v215 * (uint64_t) v33);
            // pto: %166, %167
            ;
            int64_t v217 = (int64_t) ((uint64_t) v119 + (uint64_t) v216) % v32;
            // pto: %168, %169, %170
            ;
            int64_t v218 = v217 < v41 ? (int64_t) ((uint64_t) v217 + (uint64_t) v32) : v217;
            // pto: %173, %172, %174
            ;
            int64_t v219 = (int64_t) ((uint64_t) v119 + (uint64_t) ((int64_t) (uint64_t) v216 + (uint64_t) v33)) % v32;
            // pto: %175, %176, %177
            ;
            int64_t v220 = v219 < v41 ? (int64_t) ((uint64_t) v219 + (uint64_t) v32) : v219;
            // pto: %178
            ;
            // pto: %179
            ;
            int64_t v221 = v164 < v36 ? v164 : v36;
            v85.SetValidShape(v221, v36);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
            if (v218 <= v50) {
              // pto: %180
              ;
              int64_t v222 = (int64_t) ((uint64_t) v218 * (uint64_t) v33);
              // pto: %seed_fast_packet_x__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v223 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v164, v32);
              // pto: %seed_fast_packet_x__tile
              ;
              uint64_t v224 = (uint64_t) v23;
              TASSIGN(v223, v224);
              // pto: %183
              ;
              int64_t v225 = (int64_t) ((uint64_t) v169 + (uint64_t) v222);
              // pto: %184
              ;
              int64_t v226 = v225 < v41 ? v41 : v225;
              // pto: %185
              ;
              const int64_t v227 = 0;
              // pto: %185
              ;
              __gm__ bfloat16_t* v228 = PTOAS__GLOBAL_TENSOR_DATA(v62);
              // pto: %185
              ;
              const int64_t v229 = 1;
              // pto: %185
              ;
              const int64_t v230 = 1;
              // pto: %185
              ;
              const int64_t v231 = 1;
              // pto: %185
              ;
              int64_t v232 = v164 * v28;
              // pto: %185
              ;
              int64_t v233 = v231 * v232;
              // pto: %185
              ;
              pto::Shape<1, 1, 1, -1, 256> v234 = pto::Shape<1, 1, 1, -1, 256>(v229, v230, v231, v164, v32);
              // pto: %185
              ;
              pto::Stride<-1, -1, -1, -1, -1> v235 = pto::Stride<-1, -1, -1, -1, -1>(v230 * v233, v233, v232, v28, v29);
              // pto: %185
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v236 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v228 + (v227 + v168 * v28 + v226 * v29), v234, v235);
              TLOAD(v223, v236);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
              // pto: %seed_fast_packet_w__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v237 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
              // pto: %seed_fast_packet_w__tile
              ;
              uint64_t v238 = (uint64_t) v24;
              TASSIGN(v237, v238);
              // pto: %189
              ;
              int64_t v239 = v222 / v33;
              // pto: %190
              ;
              int64_t v240 = v239 < v41 ? v41 : v239;
              // pto: %191
              ;
              __gm__ bfloat16_t* v241 = PTOAS__GLOBAL_TENSOR_DATA(v65);
              // pto: %191
              ;
              const int64_t v242 = 0;
              // pto: %191
              ;
              const int64_t v243 = 4194304;
              // pto: %191
              ;
              const int64_t v244 = 65536;
              // pto: %191
              ;
              const int64_t v245 = 256;
              // pto: %191
              ;
              pto::Shape<1, 8, 16, 16, 16> v246 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %191
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v247 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %191
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v248 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v241 + ((v242 + v184 * v243) + v186 * v244 + v240 * v245), v246, v247);
              TLOAD(v237, v248);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
              // pto: %seed_fast_acc__iter_v1_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v249 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v164, v36);
              // pto: %seed_fast_acc__iter_v1_l0_a
              ;
              uint64_t v250 = (uint64_t) v23;
              TASSIGN(v249, v250);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
              uint16_t v251 = static_cast<uint16_t>(v41);
              uint16_t v252 = static_cast<uint16_t>(v41);
              TEXTRACT(v249, v223, v251, v252);
              // pto: %seed_fast_acc__iter_v1_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v253 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %seed_fast_acc__iter_v1_l0_b
              ;
              uint64_t v254 = (uint64_t) v23;
              TASSIGN(v253, v254);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
              uint16_t v255 = static_cast<uint16_t>(v41);
              uint16_t v256 = static_cast<uint16_t>(v41);
              TEXTRACT(v253, v237, v255, v256);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
              // pto: %3
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v257 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v164, v36);
              // pto: %3
              ;
              uint64_t v258 = (uint64_t) v25;
              TASSIGN(v257, v258);
              uint16_t v259 = static_cast<uint16_t>(v41);
              uint16_t v260 = static_cast<uint16_t>(v36);
              TEXTRACT(v257, v223, v259, v260);
              // pto: %4
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v261 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %4
              ;
              uint64_t v262 = (uint64_t) v25;
              TASSIGN(v261, v262);
              uint16_t v263 = static_cast<uint16_t>(v36);
              uint16_t v264 = static_cast<uint16_t>(v41);
              TEXTRACT(v261, v237, v263, v264);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v197, v197, v249, v253);
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
              TMATMUL_ACC(v197, v197, v257, v261);
            } else {
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
              for (int64_t v265 = v41; v265 < v33; v265 += v29) {
                // pto: %192, %193
                ;
                int64_t v266 = (int64_t) ((uint64_t) v218 + (uint64_t) v265) % v32;
                // pto: %194, %195, %196
                ;
                int64_t v267 = v266 < v41 ? (int64_t) ((uint64_t) v266 + (uint64_t) v32) : v266;
                // pto: %197
                ;
                int64_t v268 = (int64_t) ((uint64_t) v267 * (uint64_t) v33);
                // pto: %seed_fast_wrap_x__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v269 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v164, v33);
                // pto: %seed_fast_wrap_x__tile
                ;
                uint64_t v270 = (uint64_t) v23;
                TASSIGN(v269, v270);
                // pto: %200
                ;
                int64_t v271 = (int64_t) ((uint64_t) v169 + (uint64_t) v268);
                // pto: %201
                ;
                int64_t v272 = v271 < v41 ? v41 : v271;
                // pto: %202
                ;
                const int64_t v273 = 0;
                // pto: %202
                ;
                __gm__ bfloat16_t* v274 = PTOAS__GLOBAL_TENSOR_DATA(v62);
                // pto: %202
                ;
                const int64_t v275 = 1;
                // pto: %202
                ;
                const int64_t v276 = 1;
                // pto: %202
                ;
                const int64_t v277 = 1;
                // pto: %202
                ;
                int64_t v278 = v164 * v28;
                // pto: %202
                ;
                int64_t v279 = v277 * v278;
                // pto: %202
                ;
                pto::Shape<1, 1, 1, -1, 16> v280 = pto::Shape<1, 1, 1, -1, 16>(v275, v276, v277, v164, v33);
                // pto: %202
                ;
                pto::Stride<-1, -1, -1, -1, -1> v281 = pto::Stride<-1, -1, -1, -1, -1>(v276 * v279, v279, v278, v28, v29);
                // pto: %202
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v282 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v274 + (v273 + v168 * v28 + v272 * v29), v280, v281);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                TLOAD(v269, v282);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
                // pto: %seed_fast_wrap_w__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v283 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %seed_fast_wrap_w__tile
                ;
                uint64_t v284 = (uint64_t) v24;
                TASSIGN(v283, v284);
                // pto: %206
                ;
                int64_t v285 = v268 / v33;
                // pto: %207
                ;
                int64_t v286 = v285 < v41 ? v41 : v285;
                // pto: %208
                ;
                __gm__ bfloat16_t* v287 = PTOAS__GLOBAL_TENSOR_DATA(v65);
                // pto: %208
                ;
                const int64_t v288 = 0;
                // pto: %208
                ;
                const int64_t v289 = 4194304;
                // pto: %208
                ;
                const int64_t v290 = 65536;
                // pto: %208
                ;
                const int64_t v291 = 256;
                // pto: %208
                ;
                pto::Shape<1, 8, 1, 16, 16> v292 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %208
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v293 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %208
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v294 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v287 + ((v288 + v184 * v289) + v186 * v290 + v286 * v291), v292, v293);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
                TLOAD(v283, v294);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
                // pto: %lhs_slice_0_textract
                ;
                Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v295 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v164, v33);
                // pto: %lhs_slice_0_textract
                ;
                uint64_t v296 = (uint64_t) v23;
                TASSIGN(v295, v296);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
                uint16_t v297 = static_cast<uint16_t>(v41);
                uint16_t v298 = static_cast<uint16_t>(v41);
                TEXTRACT(v295, v269, v297, v298);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                // pto: %rhs_slice_0_textract
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v299 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %rhs_slice_0_textract
                ;
                uint64_t v300 = (uint64_t) v23;
                TASSIGN(v299, v300);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
                uint16_t v301 = static_cast<uint16_t>(v41);
                uint16_t v302 = static_cast<uint16_t>(v41);
                TEXTRACT(v299, v283, v301, v302);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v197, v197, v295, v299);
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
              };
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            };
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            // pto: %209
            ;
            v87.SetValidShape(v221, v36);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
            if (v220 <= v50) {
              // pto: %212
              ;
              int64_t v303 = (int64_t) ((uint64_t) v220 * (uint64_t) v33);
              // pto: %6
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v304 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v164, v32);
              // pto: %6
              ;
              uint64_t v305 = (uint64_t) v26;
              TASSIGN(v304, v305);
              // pto: %215
              ;
              int64_t v306 = (int64_t) ((uint64_t) v169 + (uint64_t) v303);
              // pto: %216
              ;
              int64_t v307 = v306 < v41 ? v41 : v306;
              // pto: %217
              ;
              const int64_t v308 = 0;
              // pto: %217
              ;
              __gm__ bfloat16_t* v309 = PTOAS__GLOBAL_TENSOR_DATA(v62);
              // pto: %217
              ;
              const int64_t v310 = 1;
              // pto: %217
              ;
              const int64_t v311 = 1;
              // pto: %217
              ;
              const int64_t v312 = 1;
              // pto: %217
              ;
              int64_t v313 = v164 * v28;
              // pto: %217
              ;
              int64_t v314 = v312 * v313;
              // pto: %217
              ;
              pto::Shape<1, 1, 1, -1, 256> v315 = pto::Shape<1, 1, 1, -1, 256>(v310, v311, v312, v164, v32);
              // pto: %217
              ;
              pto::Stride<-1, -1, -1, -1, -1> v316 = pto::Stride<-1, -1, -1, -1, -1>(v311 * v314, v314, v313, v28, v29);
              // pto: %217
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v317 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v309 + (v308 + v168 * v28 + v307 * v29), v315, v316);
              TLOAD(v304, v317);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
              // pto: %7
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v318 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
              // pto: %7
              ;
              uint64_t v319 = (uint64_t) v27;
              TASSIGN(v318, v319);
              // pto: %221
              ;
              int64_t v320 = v303 / v33;
              // pto: %222
              ;
              int64_t v321 = v320 < v41 ? v41 : v320;
              // pto: %223
              ;
              __gm__ bfloat16_t* v322 = PTOAS__GLOBAL_TENSOR_DATA(v65);
              // pto: %223
              ;
              const int64_t v323 = 0;
              // pto: %223
              ;
              const int64_t v324 = 4194304;
              // pto: %223
              ;
              const int64_t v325 = 65536;
              // pto: %223
              ;
              const int64_t v326 = 256;
              // pto: %223
              ;
              pto::Shape<1, 8, 16, 16, 16> v327 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %223
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v328 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %223
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v329 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v322 + ((v323 + v184 * v324) + v186 * v325 + v321 * v326), v327, v328);
              TLOAD(v318, v329);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
              // pto: %8
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v330 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v164, v36);
              // pto: %8
              ;
              uint64_t v331 = (uint64_t) v23;
              TASSIGN(v330, v331);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
              uint16_t v332 = static_cast<uint16_t>(v41);
              uint16_t v333 = static_cast<uint16_t>(v41);
              TEXTRACT(v330, v304, v332, v333);
              // pto: %9
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v334 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %9
              ;
              uint64_t v335 = (uint64_t) v23;
              TASSIGN(v334, v335);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
              uint16_t v336 = static_cast<uint16_t>(v41);
              uint16_t v337 = static_cast<uint16_t>(v41);
              TEXTRACT(v334, v318, v336, v337);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
              // pto: %10
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v338 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v164, v36);
              // pto: %10
              ;
              uint64_t v339 = (uint64_t) v25;
              TASSIGN(v338, v339);
              uint16_t v340 = static_cast<uint16_t>(v41);
              uint16_t v341 = static_cast<uint16_t>(v36);
              TEXTRACT(v338, v304, v340, v341);
              // pto: %11
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v342 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %11
              ;
              uint64_t v343 = (uint64_t) v25;
              TASSIGN(v342, v343);
              uint16_t v344 = static_cast<uint16_t>(v36);
              uint16_t v345 = static_cast<uint16_t>(v41);
              TEXTRACT(v342, v318, v344, v345);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v85, v85, v330, v334);
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
              TMATMUL_ACC(v85, v85, v338, v342);
            } else {
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
              for (int64_t v346 = v41; v346 < v33; v346 += v29) {
                // pto: %225, %226
                ;
                int64_t v347 = (int64_t) ((uint64_t) v220 + (uint64_t) v346) % v32;
                // pto: %227, %228, %229
                ;
                int64_t v348 = v347 < v41 ? (int64_t) ((uint64_t) v347 + (uint64_t) v32) : v347;
                // pto: %230
                ;
                int64_t v349 = (int64_t) ((uint64_t) v348 * (uint64_t) v33);
                // pto: %14
                ;
                Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v350 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v164, v33);
                // pto: %14
                ;
                uint64_t v351 = (uint64_t) v26;
                TASSIGN(v350, v351);
                // pto: %233
                ;
                int64_t v352 = (int64_t) ((uint64_t) v169 + (uint64_t) v349);
                // pto: %234
                ;
                int64_t v353 = v352 < v41 ? v41 : v352;
                // pto: %235
                ;
                const int64_t v354 = 0;
                // pto: %235
                ;
                __gm__ bfloat16_t* v355 = PTOAS__GLOBAL_TENSOR_DATA(v62);
                // pto: %235
                ;
                const int64_t v356 = 1;
                // pto: %235
                ;
                const int64_t v357 = 1;
                // pto: %235
                ;
                const int64_t v358 = 1;
                // pto: %235
                ;
                int64_t v359 = v164 * v28;
                // pto: %235
                ;
                int64_t v360 = v358 * v359;
                // pto: %235
                ;
                pto::Shape<1, 1, 1, -1, 16> v361 = pto::Shape<1, 1, 1, -1, 16>(v356, v357, v358, v164, v33);
                // pto: %235
                ;
                pto::Stride<-1, -1, -1, -1, -1> v362 = pto::Stride<-1, -1, -1, -1, -1>(v357 * v360, v360, v359, v28, v29);
                // pto: %235
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v363 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v355 + (v354 + v168 * v28 + v353 * v29), v361, v362);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
                TLOAD(v350, v363);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                // pto: %15
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v364 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %15
                ;
                uint64_t v365 = (uint64_t) v27;
                TASSIGN(v364, v365);
                // pto: %239
                ;
                int64_t v366 = v349 / v33;
                // pto: %240
                ;
                int64_t v367 = v366 < v41 ? v41 : v366;
                // pto: %241
                ;
                __gm__ bfloat16_t* v368 = PTOAS__GLOBAL_TENSOR_DATA(v65);
                // pto: %241
                ;
                const int64_t v369 = 0;
                // pto: %241
                ;
                const int64_t v370 = 4194304;
                // pto: %241
                ;
                const int64_t v371 = 65536;
                // pto: %241
                ;
                const int64_t v372 = 256;
                // pto: %241
                ;
                pto::Shape<1, 8, 1, 16, 16> v373 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %241
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v374 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %241
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v375 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v368 + ((v369 + v184 * v370) + v186 * v371 + v367 * v372), v373, v374);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
                TLOAD(v364, v375);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                // pto: %16
                ;
                Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v376 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v164, v33);
                // pto: %16
                ;
                uint64_t v377 = (uint64_t) v23;
                TASSIGN(v376, v377);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
                uint16_t v378 = static_cast<uint16_t>(v41);
                uint16_t v379 = static_cast<uint16_t>(v41);
                TEXTRACT(v376, v350, v378, v379);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
                // pto: %17
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v380 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %17
                ;
                uint64_t v381 = (uint64_t) v23;
                TASSIGN(v380, v381);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                uint16_t v382 = static_cast<uint16_t>(v41);
                uint16_t v383 = static_cast<uint16_t>(v41);
                TEXTRACT(v380, v364, v382, v383);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v85, v85, v376, v380);
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
              };
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
            };
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
          };
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %242, %243
          ;
          int64_t v384 = (int64_t) ((uint64_t) v119 + (uint64_t) v50) % v32;
          // pto: %244, %245, %246
          ;
          int64_t v385 = v384 < v41 ? (int64_t) ((uint64_t) v384 + (uint64_t) v32) : v384;
          // pto: %247
          ;
          // pto: %248
          ;
          int64_t v386 = v164 < v36 ? v164 : v36;
          v89.SetValidShape(v386, v36);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
          if (v385 <= v50) {
            // pto: %250
            ;
            int64_t v387 = (int64_t) ((uint64_t) v385 * (uint64_t) v33);
            // pto: %19
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v388 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v164, v32);
            // pto: %19
            ;
            uint64_t v389 = (uint64_t) v23;
            TASSIGN(v388, v389);
            // pto: %253
            ;
            int64_t v390 = (int64_t) ((uint64_t) v169 + (uint64_t) v387);
            // pto: %254
            ;
            int64_t v391 = v390 < v41 ? v41 : v390;
            // pto: %255
            ;
            const int64_t v392 = 0;
            // pto: %255
            ;
            __gm__ bfloat16_t* v393 = PTOAS__GLOBAL_TENSOR_DATA(v62);
            // pto: %255
            ;
            const int64_t v394 = 1;
            // pto: %255
            ;
            const int64_t v395 = 1;
            // pto: %255
            ;
            const int64_t v396 = 1;
            // pto: %255
            ;
            int64_t v397 = v164 * v28;
            // pto: %255
            ;
            int64_t v398 = v396 * v397;
            // pto: %255
            ;
            pto::Shape<1, 1, 1, -1, 256> v399 = pto::Shape<1, 1, 1, -1, 256>(v394, v395, v396, v164, v32);
            // pto: %255
            ;
            pto::Stride<-1, -1, -1, -1, -1> v400 = pto::Stride<-1, -1, -1, -1, -1>(v395 * v398, v398, v397, v28, v29);
            // pto: %255
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v401 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v393 + (v392 + v168 * v28 + v391 * v29), v399, v400);
            TLOAD(v388, v401);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %20
            ;
            Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v402 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
            // pto: %20
            ;
            uint64_t v403 = (uint64_t) v24;
            TASSIGN(v402, v403);
            // pto: %259
            ;
            int64_t v404 = v387 / v33;
            // pto: %260
            ;
            int64_t v405 = v404 < v41 ? v41 : v404;
            // pto: %261
            ;
            __gm__ bfloat16_t* v406 = PTOAS__GLOBAL_TENSOR_DATA(v65);
            // pto: %261
            ;
            const int64_t v407 = 0;
            // pto: %261
            ;
            const int64_t v408 = 4194304;
            // pto: %261
            ;
            const int64_t v409 = 65536;
            // pto: %261
            ;
            const int64_t v410 = 256;
            // pto: %261
            ;
            pto::Shape<1, 8, 16, 16, 16> v411 = pto::Shape<1, 8, 16, 16, 16>();
            // pto: %261
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v412 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %261
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v413 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v406 + ((v407 + v184 * v408) + v186 * v409 + v405 * v410), v411, v412);
            TLOAD(v402, v413);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %21
            ;
            Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v414 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v164, v36);
            // pto: %21
            ;
            uint64_t v415 = (uint64_t) v23;
            TASSIGN(v414, v415);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            uint16_t v416 = static_cast<uint16_t>(v41);
            uint16_t v417 = static_cast<uint16_t>(v41);
            TEXTRACT(v414, v388, v416, v417);
            // pto: %22
            ;
            Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v418 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
            // pto: %22
            ;
            uint64_t v419 = (uint64_t) v23;
            TASSIGN(v418, v419);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            uint16_t v420 = static_cast<uint16_t>(v41);
            uint16_t v421 = static_cast<uint16_t>(v41);
            TEXTRACT(v418, v402, v420, v421);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            // pto: %23
            ;
            Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v422 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v164, v36);
            // pto: %23
            ;
            uint64_t v423 = (uint64_t) v25;
            TASSIGN(v422, v423);
            uint16_t v424 = static_cast<uint16_t>(v41);
            uint16_t v425 = static_cast<uint16_t>(v36);
            TEXTRACT(v422, v388, v424, v425);
            // pto: %24
            ;
            Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v426 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
            // pto: %24
            ;
            uint64_t v427 = (uint64_t) v25;
            TASSIGN(v426, v427);
            uint16_t v428 = static_cast<uint16_t>(v36);
            uint16_t v429 = static_cast<uint16_t>(v41);
            TEXTRACT(v426, v402, v428, v429);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v197, v197, v414, v418);
            pipe_barrier(PIPE_M);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
            TMATMUL_ACC(v197, v197, v422, v426);
          } else {
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
            for (int64_t v430 = v41; v430 < v33; v430 += v29) {
              // pto: %263, %264
              ;
              int64_t v431 = (int64_t) ((uint64_t) v385 + (uint64_t) v430) % v32;
              // pto: %265, %266, %267
              ;
              int64_t v432 = v431 < v41 ? (int64_t) ((uint64_t) v431 + (uint64_t) v32) : v431;
              // pto: %268
              ;
              int64_t v433 = (int64_t) ((uint64_t) v432 * (uint64_t) v33);
              // pto: %27
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v434 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v164, v33);
              // pto: %27
              ;
              uint64_t v435 = (uint64_t) v23;
              TASSIGN(v434, v435);
              // pto: %271
              ;
              int64_t v436 = (int64_t) ((uint64_t) v169 + (uint64_t) v433);
              // pto: %272
              ;
              int64_t v437 = v436 < v41 ? v41 : v436;
              // pto: %273
              ;
              const int64_t v438 = 0;
              // pto: %273
              ;
              __gm__ bfloat16_t* v439 = PTOAS__GLOBAL_TENSOR_DATA(v62);
              // pto: %273
              ;
              const int64_t v440 = 1;
              // pto: %273
              ;
              const int64_t v441 = 1;
              // pto: %273
              ;
              const int64_t v442 = 1;
              // pto: %273
              ;
              int64_t v443 = v164 * v28;
              // pto: %273
              ;
              int64_t v444 = v442 * v443;
              // pto: %273
              ;
              pto::Shape<1, 1, 1, -1, 16> v445 = pto::Shape<1, 1, 1, -1, 16>(v440, v441, v442, v164, v33);
              // pto: %273
              ;
              pto::Stride<-1, -1, -1, -1, -1> v446 = pto::Stride<-1, -1, -1, -1, -1>(v441 * v444, v444, v443, v28, v29);
              // pto: %273
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v447 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v439 + (v438 + v168 * v28 + v437 * v29), v445, v446);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              TLOAD(v434, v447);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              // pto: %28
              ;
              Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v448 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
              // pto: %28
              ;
              uint64_t v449 = (uint64_t) v24;
              TASSIGN(v448, v449);
              // pto: %277
              ;
              int64_t v450 = v433 / v33;
              // pto: %278
              ;
              int64_t v451 = v450 < v41 ? v41 : v450;
              // pto: %279
              ;
              __gm__ bfloat16_t* v452 = PTOAS__GLOBAL_TENSOR_DATA(v65);
              // pto: %279
              ;
              const int64_t v453 = 0;
              // pto: %279
              ;
              const int64_t v454 = 4194304;
              // pto: %279
              ;
              const int64_t v455 = 65536;
              // pto: %279
              ;
              const int64_t v456 = 256;
              // pto: %279
              ;
              pto::Shape<1, 8, 1, 16, 16> v457 = pto::Shape<1, 8, 1, 16, 16>();
              // pto: %279
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v458 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %279
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v459 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v452 + ((v453 + v184 * v454) + v186 * v455 + v451 * v456), v457, v458);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              TLOAD(v448, v459);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              // pto: %29
              ;
              Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v460 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v164, v33);
              // pto: %29
              ;
              uint64_t v461 = (uint64_t) v23;
              TASSIGN(v460, v461);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
              uint16_t v462 = static_cast<uint16_t>(v41);
              uint16_t v463 = static_cast<uint16_t>(v41);
              TEXTRACT(v460, v434, v462, v463);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              // pto: %30
              ;
              Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v464 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
              // pto: %30
              ;
              uint64_t v465 = (uint64_t) v23;
              TASSIGN(v464, v465);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              uint16_t v466 = static_cast<uint16_t>(v41);
              uint16_t v467 = static_cast<uint16_t>(v41);
              TEXTRACT(v464, v448, v466, v467);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v197, v197, v460, v464);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
            };
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          };
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
          // pto: %seed_fast_acc__rv_v2
          ;
          Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v468 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v164, v36);
          // pto: %seed_fast_acc__rv_v2
          ;
          uint64_t v469 = (uint64_t) v23;
          TASSIGN(v468, v469);
          // pto: %281, %282
          ;
          int64_t v470 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v111 * (uint64_t) v51) + (uint64_t) v114);
          // pto: %283
          ;
          int64_t v471 = v470 < v41 ? v41 : v470;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v472 = 0;
          // pto: %accum__ssa_v0_pview
          ;
          __gm__ float* v473 = PTOAS__GLOBAL_TENSOR_DATA(v74);
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v474 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v475 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v476 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          int64_t v477 = v164 * v38;
          // pto: %accum__ssa_v0_pview
          ;
          int64_t v478 = v476 * v477;
          // pto: %accum__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, -1, 128> v479 = pto::Shape<1, 1, 1, -1, 128>(v474, v475, v476, v164, v36);
          // pto: %accum__ssa_v0_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v480 = pto::Stride<-1, -1, -1, -1, -1>(v475 * v478, v478, v477, v38, v29);
          // pto: %accum__ssa_v0_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v481 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v473 + (v472 + v168 * v38 + v471 * v29), v479, v480);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
          TSTORE(v481, v468);
        } else {
          for (int64_t v482 = v41; v482 < v30; v482 += v29) {
            // pto: %284
            ;
            int64_t v483 = (int64_t) ((uint64_t) v116 + (uint64_t) v482);
            // pto: %285
            ;
            if (v483 < v109) {
              // pto: %286
              ;
              int64_t v484 = (int64_t) ((uint64_t) v483 * (uint64_t) v33);
              // pto: %287
              ;
              int64_t v485 = (int64_t) ((uint64_t) v17 - (uint64_t) v484);
              // pto: %288
              ;
              int64_t v486 = v485 < v33 ? v485 : v33;
              // pto: %290, %291, %292, %293, %289
              ;
              int32_t v487 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v483 * (uint64_t) v30) + (uint64_t) v111) * (uint64_t) v30) + (uint64_t) v113)];
              // pto: %294
              ;
              int64_t v488 = (int64_t) v487;
              // pto: %295
              ;
              int64_t v489 = v488 < v41 ? v41 : v488;
              // pto: %seed_narrow_acc__tile
              ;
              Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v490 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
              // pto: %seed_narrow_acc__tile
              ;
              uint64_t v491 = (uint64_t) v23;
              TASSIGN(v490, v491);
              wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              for (int64_t v492 = v41; v492 < v33; v492 += v29) {
                // pto: %296
                ;
                int64_t v493 = (int64_t) ((uint64_t) v492 * (uint64_t) v33);
                // pto: %297, %298
                ;
                int64_t v494 = (int64_t) ((uint64_t) v489 + (uint64_t) v493) % v32;
                // pto: %299, %300, %301
                ;
                int64_t v495 = v494 < v41 ? (int64_t) ((uint64_t) v494 + (uint64_t) v32) : v494;
                // pto: %302
                ;
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                if (v495 <= v50) {
                  // pto: %303
                  ;
                  int64_t v496 = (int64_t) ((uint64_t) v495 * (uint64_t) v33);
                  // pto: %seed_narrow_packet_x__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v497 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v486, v32);
                  // pto: %seed_narrow_packet_x__tile
                  ;
                  uint64_t v498 = (uint64_t) v24;
                  TASSIGN(v497, v498);
                  // pto: %304
                  ;
                  int64_t v499 = v484 < v41 ? v41 : v484;
                  // pto: %305, %306
                  ;
                  int64_t v500 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v111 * (uint64_t) v37) + (uint64_t) v496);
                  // pto: %307
                  ;
                  int64_t v501 = v500 < v41 ? v41 : v500;
                  // pto: %308
                  ;
                  const int64_t v502 = 0;
                  // pto: %308
                  ;
                  __gm__ bfloat16_t* v503 = PTOAS__GLOBAL_TENSOR_DATA(v62);
                  // pto: %308
                  ;
                  const int64_t v504 = 1;
                  // pto: %308
                  ;
                  const int64_t v505 = 1;
                  // pto: %308
                  ;
                  const int64_t v506 = 1;
                  // pto: %308
                  ;
                  int64_t v507 = v486 * v28;
                  // pto: %308
                  ;
                  int64_t v508 = v506 * v507;
                  // pto: %308
                  ;
                  pto::Shape<1, 1, 1, -1, 256> v509 = pto::Shape<1, 1, 1, -1, 256>(v504, v505, v506, v486, v32);
                  // pto: %308
                  ;
                  pto::Stride<-1, -1, -1, -1, -1> v510 = pto::Stride<-1, -1, -1, -1, -1>(v505 * v508, v508, v507, v28, v29);
                  // pto: %308
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v511 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v503 + (v502 + v499 * v28 + v501 * v29), v509, v510);
                  TLOAD(v497, v511);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  // pto: %seed_narrow_packet_w__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v512 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
                  // pto: %seed_narrow_packet_w__tile
                  ;
                  uint64_t v513 = (uint64_t) v23;
                  TASSIGN(v512, v513);
                  // pto: %309
                  ;
                  int64_t v514 = v111 < v41 ? v41 : v111;
                  // pto: %310
                  ;
                  int64_t v515 = v114 / v33;
                  // pto: %311
                  ;
                  int64_t v516 = v515 < v41 ? v41 : v515;
                  // pto: %312
                  ;
                  int64_t v517 = v496 / v33;
                  // pto: %313
                  ;
                  int64_t v518 = v517 < v41 ? v41 : v517;
                  // pto: %314
                  ;
                  __gm__ bfloat16_t* v519 = PTOAS__GLOBAL_TENSOR_DATA(v65);
                  // pto: %314
                  ;
                  const int64_t v520 = 0;
                  // pto: %314
                  ;
                  const int64_t v521 = 4194304;
                  // pto: %314
                  ;
                  const int64_t v522 = 65536;
                  // pto: %314
                  ;
                  const int64_t v523 = 256;
                  // pto: %314
                  ;
                  pto::Shape<1, 8, 16, 16, 16> v524 = pto::Shape<1, 8, 16, 16, 16>();
                  // pto: %314
                  ;
                  pto::Stride<4194304, 65536, 256, 16, 1> v525 = pto::Stride<4194304, 65536, 256, 16, 1>();
                  // pto: %314
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v526 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v519 + ((v520 + v514 * v521) + v516 * v522 + v518 * v523), v524, v525);
                  TLOAD(v512, v526);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  // pto: %seed_narrow_acc__iter_v1_l0_a
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v527 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v486, v36);
                  // pto: %seed_narrow_acc__iter_v1_l0_a
                  ;
                  uint64_t v528 = (uint64_t) v23;
                  TASSIGN(v527, v528);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  uint16_t v529 = static_cast<uint16_t>(v41);
                  uint16_t v530 = static_cast<uint16_t>(v41);
                  TEXTRACT(v527, v497, v529, v530);
                  // pto: %seed_narrow_acc__iter_v1_l0_b
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v531 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %seed_narrow_acc__iter_v1_l0_b
                  ;
                  uint64_t v532 = (uint64_t) v23;
                  TASSIGN(v531, v532);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  uint16_t v533 = static_cast<uint16_t>(v41);
                  uint16_t v534 = static_cast<uint16_t>(v41);
                  TEXTRACT(v531, v512, v533, v534);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  // pto: %32
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v535 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v486, v36);
                  // pto: %32
                  ;
                  uint64_t v536 = (uint64_t) v25;
                  TASSIGN(v535, v536);
                  uint16_t v537 = static_cast<uint16_t>(v41);
                  uint16_t v538 = static_cast<uint16_t>(v36);
                  TEXTRACT(v535, v497, v537, v538);
                  // pto: %33
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v539 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %33
                  ;
                  uint64_t v540 = (uint64_t) v25;
                  TASSIGN(v539, v540);
                  uint16_t v541 = static_cast<uint16_t>(v36);
                  uint16_t v542 = static_cast<uint16_t>(v41);
                  TEXTRACT(v539, v512, v541, v542);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  // pto: %315
                  ;
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  if (v492 == v41) {
                    pipe_barrier(PIPE_M);
                    TMATMUL(v490, v527, v531);
                  } else {
                    pipe_barrier(PIPE_M);
                    TMATMUL_ACC(v490, v490, v527, v531);
                  };
                  pipe_barrier(PIPE_M);
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  TMATMUL_ACC(v490, v490, v535, v539);
                } else {
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  for (int64_t v543 = v41; v543 < v33; v543 += v29) {
                    // pto: %316, %317
                    ;
                    int64_t v544 = (int64_t) ((uint64_t) v495 + (uint64_t) v543) % v32;
                    // pto: %318, %319, %320
                    ;
                    int64_t v545 = v544 < v41 ? (int64_t) ((uint64_t) v544 + (uint64_t) v32) : v544;
                    // pto: %321
                    ;
                    int64_t v546 = (int64_t) ((uint64_t) v545 * (uint64_t) v33);
                    // pto: %seed_narrow_wrap_x__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v547 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v486, v33);
                    // pto: %seed_narrow_wrap_x__tile
                    ;
                    uint64_t v548 = (uint64_t) v24;
                    TASSIGN(v547, v548);
                    // pto: %322
                    ;
                    int64_t v549 = v484 < v41 ? v41 : v484;
                    // pto: %323, %324
                    ;
                    int64_t v550 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v111 * (uint64_t) v37) + (uint64_t) v546);
                    // pto: %325
                    ;
                    int64_t v551 = v550 < v41 ? v41 : v550;
                    // pto: %326
                    ;
                    const int64_t v552 = 0;
                    // pto: %326
                    ;
                    __gm__ bfloat16_t* v553 = PTOAS__GLOBAL_TENSOR_DATA(v62);
                    // pto: %326
                    ;
                    const int64_t v554 = 1;
                    // pto: %326
                    ;
                    const int64_t v555 = 1;
                    // pto: %326
                    ;
                    const int64_t v556 = 1;
                    // pto: %326
                    ;
                    int64_t v557 = v486 * v28;
                    // pto: %326
                    ;
                    int64_t v558 = v556 * v557;
                    // pto: %326
                    ;
                    pto::Shape<1, 1, 1, -1, 16> v559 = pto::Shape<1, 1, 1, -1, 16>(v554, v555, v556, v486, v33);
                    // pto: %326
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v560 = pto::Stride<-1, -1, -1, -1, -1>(v555 * v558, v558, v557, v28, v29);
                    // pto: %326
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v561 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v553 + (v552 + v549 * v28 + v551 * v29), v559, v560);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    TLOAD(v547, v561);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    // pto: %seed_narrow_wrap_w__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v562 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %seed_narrow_wrap_w__tile
                    ;
                    uint64_t v563 = (uint64_t) v23;
                    TASSIGN(v562, v563);
                    // pto: %327
                    ;
                    int64_t v564 = v111 < v41 ? v41 : v111;
                    // pto: %328
                    ;
                    int64_t v565 = v114 / v33;
                    // pto: %329
                    ;
                    int64_t v566 = v565 < v41 ? v41 : v565;
                    // pto: %330
                    ;
                    int64_t v567 = v546 / v33;
                    // pto: %331
                    ;
                    int64_t v568 = v567 < v41 ? v41 : v567;
                    // pto: %332
                    ;
                    __gm__ bfloat16_t* v569 = PTOAS__GLOBAL_TENSOR_DATA(v65);
                    // pto: %332
                    ;
                    const int64_t v570 = 0;
                    // pto: %332
                    ;
                    const int64_t v571 = 4194304;
                    // pto: %332
                    ;
                    const int64_t v572 = 65536;
                    // pto: %332
                    ;
                    const int64_t v573 = 256;
                    // pto: %332
                    ;
                    pto::Shape<1, 8, 1, 16, 16> v574 = pto::Shape<1, 8, 1, 16, 16>();
                    // pto: %332
                    ;
                    pto::Stride<4194304, 65536, 256, 16, 1> v575 = pto::Stride<4194304, 65536, 256, 16, 1>();
                    // pto: %332
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v576 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v569 + ((v570 + v564 * v571) + v566 * v572 + v568 * v573), v574, v575);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                    TLOAD(v562, v576);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    // pto: %35
                    ;
                    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v577 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v486, v33);
                    // pto: %35
                    ;
                    uint64_t v578 = (uint64_t) v23;
                    TASSIGN(v577, v578);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                    uint16_t v579 = static_cast<uint16_t>(v41);
                    uint16_t v580 = static_cast<uint16_t>(v41);
                    TEXTRACT(v577, v547, v579, v580);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    // pto: %36
                    ;
                    Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v581 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %36
                    ;
                    uint64_t v582 = (uint64_t) v23;
                    TASSIGN(v581, v582);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    uint16_t v583 = static_cast<uint16_t>(v41);
                    uint16_t v584 = static_cast<uint16_t>(v41);
                    TEXTRACT(v581, v562, v583, v584);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    // pto: %334, %335
                    ;
                    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    if ((int64_t) ((uint64_t) v493 + (uint64_t) v543) == v41) {
                      pipe_barrier(PIPE_M);
                      TMATMUL(v490, v577, v581);
                    } else {
                      pipe_barrier(PIPE_M);
                      TMATMUL_ACC(v490, v490, v577, v581);
                    };
                    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  };
                  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
              // pto: %336
              ;
              int64_t v585 = v484 < v41 ? v41 : v484;
              // pto: %337, %338
              ;
              int64_t v586 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v111 * (uint64_t) v51) + (uint64_t) v114);
              // pto: %339
              ;
              int64_t v587 = v586 < v41 ? v41 : v586;
              // pto: %340
              ;
              __gm__ float* v588 = PTOAS__GLOBAL_TENSOR_DATA(v74);
              // pto: %340
              ;
              const int64_t v589 = 0;
              // pto: %340
              ;
              const int64_t v590 = 8192;
              // pto: %340
              ;
              pto::Shape<1, 1, 1, 16, 128> v591 = pto::Shape<1, 1, 1, 16, 128>();
              // pto: %340
              ;
              pto::Stride<131072, 131072, 131072, 8192, 1> v592 = pto::Stride<131072, 131072, 131072, 8192, 1>();
              // pto: %340
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v593 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v588 + (v589 + v585 * v590 + v587), v591, v592);
              wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
              pipe_barrier(PIPE_FIX);
              TSTORE(v593, v490);
              set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
            };
          };
        };
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    };
  } else {
    for (int64_t v594 = v97; v594 < v31; v594 += v44) {
      // pto: %342
      ;
      int64_t v595 = v594 / v30;
      // pto: %343
      ;
      int64_t v596 = v594 % v30;
      // pto: %344, %345, %346
      ;
      int64_t v597 = v596 < v41 ? (int64_t) ((uint64_t) v596 + (uint64_t) v30) : v596;
      // pto: %347
      ;
      int64_t v598 = (int64_t) ((uint64_t) v597 * (uint64_t) v36);
      // pto: %348, %349
      ;
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v599 = v41; v599 < ((int64_t) ((uint64_t) v109 + (uint64_t) v45) / v30); v599 += v29) {
        // pto: %350
        ;
        int64_t v600 = (int64_t) ((uint64_t) v599 * (uint64_t) v30);
        // pto: %353, %354, %355, %351
        ;
        int32_t v601 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v599 * (uint64_t) v31) + (uint64_t) v595) * (uint64_t) v30) + (uint64_t) v597)];
        // pto: %356
        ;
        int64_t v602 = (int64_t) v601;
        // pto: %357
        ;
        int64_t v603 = v602 < v41 ? v41 : v602;
        // pto: %358
        ;
        int64_t v604 = (int64_t) ((uint64_t) v600 + (uint64_t) v29);
        // pto: %359
        ;
        // pto: %v4_same_start__phi_v3
        ;
        int64_t v605;
        if (v604 < v109) {
          // pto: %362, %363, %364, %365, %360
          ;
          int32_t v606 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v604 * (uint64_t) v30) + (uint64_t) v595) * (uint64_t) v30) + (uint64_t) v597)];
          // pto: %366
          ;
          int64_t v607 = (int64_t) v606;
          // pto: %367
          ;
          int64_t v608 = v607 < v41 ? v41 : v607;
          // pto: %368, %v4_same_start__phi_v2
          ;
          v605 = v608 != v603 ? v41 : v29;
        } else {
          v605 = v29;
        };
        // pto: %369
        ;
        int64_t v609 = (int64_t) ((uint64_t) v600 + (uint64_t) v46);
        // pto: %370
        ;
        // pto: %v4_same_start__phi_v6
        ;
        int64_t v610;
        if (v609 < v109) {
          // pto: %373, %374, %375, %376, %371
          ;
          int32_t v611 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v609 * (uint64_t) v30) + (uint64_t) v595) * (uint64_t) v30) + (uint64_t) v597)];
          // pto: %377
          ;
          int64_t v612 = (int64_t) v611;
          // pto: %378
          ;
          int64_t v613 = v612 < v41 ? v41 : v612;
          // pto: %379, %v4_same_start__phi_v5
          ;
          int64_t v614 = v613 != v603 ? v41 : v605;
          v610 = v614;
        } else {
          v610 = v605;
        };
        // pto: %380
        ;
        int64_t v615 = (int64_t) ((uint64_t) v600 + (uint64_t) v47);
        // pto: %381
        ;
        // pto: %v4_same_start__phi_v9
        ;
        int64_t v616;
        if (v615 < v109) {
          // pto: %384, %385, %386, %387, %382
          ;
          int32_t v617 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v615 * (uint64_t) v30) + (uint64_t) v595) * (uint64_t) v30) + (uint64_t) v597)];
          // pto: %388
          ;
          int64_t v618 = (int64_t) v617;
          // pto: %389
          ;
          int64_t v619 = v618 < v41 ? v41 : v618;
          // pto: %390, %v4_same_start__phi_v8
          ;
          int64_t v620 = v619 != v603 ? v41 : v610;
          v616 = v620;
        } else {
          v616 = v610;
        };
        // pto: %391
        ;
        int64_t v621 = (int64_t) ((uint64_t) v600 + (uint64_t) v39);
        // pto: %392
        ;
        // pto: %v4_same_start__phi_v12
        ;
        int64_t v622;
        if (v621 < v109) {
          // pto: %395, %396, %397, %398, %393
          ;
          int32_t v623 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v621 * (uint64_t) v30) + (uint64_t) v595) * (uint64_t) v30) + (uint64_t) v597)];
          // pto: %399
          ;
          int64_t v624 = (int64_t) v623;
          // pto: %400
          ;
          int64_t v625 = v624 < v41 ? v41 : v624;
          // pto: %401, %v4_same_start__phi_v11
          ;
          int64_t v626 = v625 != v603 ? v41 : v616;
          v622 = v626;
        } else {
          v622 = v616;
        };
        // pto: %402
        ;
        int64_t v627 = (int64_t) ((uint64_t) v600 + (uint64_t) v48);
        // pto: %403
        ;
        // pto: %v4_same_start__phi_v15
        ;
        int64_t v628;
        if (v627 < v109) {
          // pto: %406, %407, %408, %409, %404
          ;
          int32_t v629 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v627 * (uint64_t) v30) + (uint64_t) v595) * (uint64_t) v30) + (uint64_t) v597)];
          // pto: %410
          ;
          int64_t v630 = (int64_t) v629;
          // pto: %411
          ;
          int64_t v631 = v630 < v41 ? v41 : v630;
          // pto: %412, %v4_same_start__phi_v14
          ;
          int64_t v632 = v631 != v603 ? v41 : v622;
          v628 = v632;
        } else {
          v628 = v622;
        };
        // pto: %413
        ;
        int64_t v633 = (int64_t) ((uint64_t) v600 + (uint64_t) v49);
        // pto: %414
        ;
        // pto: %v4_same_start__phi_v18
        ;
        int64_t v634;
        if (v633 < v109) {
          // pto: %417, %418, %419, %420, %415
          ;
          int32_t v635 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v633 * (uint64_t) v30) + (uint64_t) v595) * (uint64_t) v30) + (uint64_t) v597)];
          // pto: %421
          ;
          int64_t v636 = (int64_t) v635;
          // pto: %422
          ;
          int64_t v637 = v636 < v41 ? v41 : v636;
          // pto: %423, %v4_same_start__phi_v17
          ;
          int64_t v638 = v637 != v603 ? v41 : v628;
          v634 = v638;
        } else {
          v634 = v628;
        };
        // pto: %424
        ;
        int64_t v639 = (int64_t) ((uint64_t) v600 + (uint64_t) v45);
        // pto: %425
        ;
        // pto: %v4_same_start__phi_v21
        ;
        int64_t v640;
        if (v639 < v109) {
          // pto: %428, %429, %430, %431, %426
          ;
          int32_t v641 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v639 * (uint64_t) v30) + (uint64_t) v595) * (uint64_t) v30) + (uint64_t) v597)];
          // pto: %432
          ;
          int64_t v642 = (int64_t) v641;
          // pto: %433
          ;
          int64_t v643 = v642 < v41 ? v41 : v642;
          // pto: %434, %v4_same_start__phi_v20
          ;
          int64_t v644 = v643 != v603 ? v41 : v634;
          v640 = v644;
        } else {
          v640 = v634;
        };
        // pto: %435, %v4_same_start__phi_v23
        ;
        int64_t v645 = v17 <= v33 ? v41 : v640;
        // pto: %436
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        if (v645 == v29) {
          int64_t v646 = (int64_t) ((uint64_t) v599 * (uint64_t) v36);
          // pto: %438
          ;
          int64_t v647 = (int64_t) ((uint64_t) v17 - (uint64_t) v646);
          // pto: %439
          ;
          int64_t v648 = v647 < v36 ? v647 : v36;
          // pto: %440
          ;
          int64_t v649 = v603 % v32;
          // pto: %441, %442, %443
          ;
          int64_t v650 = v649 < v41 ? (int64_t) ((uint64_t) v649 + (uint64_t) v32) : v649;
          // pto: %444
          ;
          int64_t v651 = (int64_t) ((uint64_t) v650 * (uint64_t) v33);
          // pto: %v4_wide_seed_x__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v652 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v648, v33);
          // pto: %v4_wide_seed_x__tile
          ;
          uint64_t v653 = (uint64_t) v23;
          TASSIGN(v652, v653);
          // pto: %445
          ;
          int64_t v654 = v646 < v41 ? v41 : v646;
          // pto: %446
          ;
          int64_t v655 = (int64_t) ((uint64_t) v595 * (uint64_t) v37);
          // pto: %447
          ;
          int64_t v656 = (int64_t) ((uint64_t) v655 + (uint64_t) v651);
          // pto: %448
          ;
          int64_t v657 = v656 < v41 ? v41 : v656;
          // pto: %449
          ;
          const int64_t v658 = 0;
          // pto: %449
          ;
          __gm__ bfloat16_t* v659 = PTOAS__GLOBAL_TENSOR_DATA(v62);
          // pto: %449
          ;
          const int64_t v660 = 1;
          // pto: %449
          ;
          const int64_t v661 = 1;
          // pto: %449
          ;
          const int64_t v662 = 1;
          // pto: %449
          ;
          int64_t v663 = v648 * v28;
          // pto: %449
          ;
          int64_t v664 = v662 * v663;
          // pto: %449
          ;
          pto::Shape<1, 1, 1, -1, 16> v665 = pto::Shape<1, 1, 1, -1, 16>(v660, v661, v662, v648, v33);
          // pto: %449
          ;
          pto::Stride<-1, -1, -1, -1, -1> v666 = pto::Stride<-1, -1, -1, -1, -1>(v661 * v664, v664, v663, v28, v29);
          // pto: %449
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v667 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v659 + (v658 + v654 * v28 + v657 * v29), v665, v666);
          TLOAD(v652, v667);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %v4_wide_seed_w__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v668 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
          // pto: %v4_wide_seed_w__tile
          ;
          uint64_t v669 = (uint64_t) v24;
          TASSIGN(v668, v669);
          // pto: %450
          ;
          int64_t v670 = v595 < v41 ? v41 : v595;
          // pto: %451
          ;
          int64_t v671 = v598 / v33;
          // pto: %452
          ;
          int64_t v672 = v671 < v41 ? v41 : v671;
          // pto: %453
          ;
          int64_t v673 = v651 / v33;
          // pto: %454
          ;
          int64_t v674 = v673 < v41 ? v41 : v673;
          // pto: %455
          ;
          __gm__ bfloat16_t* v675 = PTOAS__GLOBAL_TENSOR_DATA(v65);
          // pto: %455
          ;
          const int64_t v676 = 0;
          // pto: %455
          ;
          const int64_t v677 = 4194304;
          // pto: %455
          ;
          const int64_t v678 = 65536;
          // pto: %455
          ;
          const int64_t v679 = 256;
          // pto: %455
          ;
          pto::Shape<1, 8, 1, 16, 16> v680 = pto::Shape<1, 8, 1, 16, 16>();
          // pto: %455
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v681 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %455
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v682 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v675 + ((v676 + v670 * v677) + v672 * v678 + v674 * v679), v680, v681);
          TLOAD(v668, v682);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %37
          ;
          Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v683 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v648, v33);
          // pto: %37
          ;
          uint64_t v684 = (uint64_t) v23;
          TASSIGN(v683, v684);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          uint16_t v685 = static_cast<uint16_t>(v41);
          uint16_t v686 = static_cast<uint16_t>(v41);
          TEXTRACT(v683, v652, v685, v686);
          // pto: %38
          ;
          Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v687 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
          // pto: %38
          ;
          uint64_t v688 = (uint64_t) v23;
          TASSIGN(v687, v688);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          uint16_t v689 = static_cast<uint16_t>(v41);
          uint16_t v690 = static_cast<uint16_t>(v41);
          TEXTRACT(v687, v668, v689, v690);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %v4_wide_acc__tile
          ;
          Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v691 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v648, v36);
          // pto: %v4_wide_acc__tile
          ;
          uint64_t v692 = (uint64_t) v23;
          TASSIGN(v691, v692);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          TMATMUL(v691, v683, v687);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          for (int64_t v693 = v41; v693 < v42; v693 += v29) {
            // pto: %457, %456, %458, %459
            ;
            int64_t v694 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v603 + (uint64_t) ((int64_t) (uint64_t) v693 * (uint64_t) v33)) + (uint64_t) v29) % v32;
            // pto: %460, %461, %462
            ;
            int64_t v695 = v694 < v41 ? (int64_t) ((uint64_t) v694 + (uint64_t) v32) : v694;
            // pto: %463
            ;
            // pto: %464
            ;
            int64_t v696 = v648 < v36 ? v648 : v36;
            v93.SetValidShape(v696, v36);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            if (v695 <= v50) {
              // pto: %465
              ;
              int64_t v697 = (int64_t) ((uint64_t) v695 * (uint64_t) v33);
              // pto: %v4_wide_packet_x__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v698 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v648, v32);
              // pto: %v4_wide_packet_x__tile
              ;
              uint64_t v699 = (uint64_t) v23;
              TASSIGN(v698, v699);
              // pto: %468
              ;
              int64_t v700 = (int64_t) ((uint64_t) v655 + (uint64_t) v697);
              // pto: %469
              ;
              int64_t v701 = v700 < v41 ? v41 : v700;
              // pto: %470
              ;
              const int64_t v702 = 0;
              // pto: %470
              ;
              __gm__ bfloat16_t* v703 = PTOAS__GLOBAL_TENSOR_DATA(v62);
              // pto: %470
              ;
              const int64_t v704 = 1;
              // pto: %470
              ;
              const int64_t v705 = 1;
              // pto: %470
              ;
              const int64_t v706 = 1;
              // pto: %470
              ;
              int64_t v707 = v648 * v28;
              // pto: %470
              ;
              int64_t v708 = v706 * v707;
              // pto: %470
              ;
              pto::Shape<1, 1, 1, -1, 256> v709 = pto::Shape<1, 1, 1, -1, 256>(v704, v705, v706, v648, v32);
              // pto: %470
              ;
              pto::Stride<-1, -1, -1, -1, -1> v710 = pto::Stride<-1, -1, -1, -1, -1>(v705 * v708, v708, v707, v28, v29);
              // pto: %470
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v711 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v703 + (v702 + v654 * v28 + v701 * v29), v709, v710);
              TLOAD(v698, v711);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              // pto: %v4_wide_packet_w__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v712 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
              // pto: %v4_wide_packet_w__tile
              ;
              uint64_t v713 = (uint64_t) v24;
              TASSIGN(v712, v713);
              // pto: %474
              ;
              int64_t v714 = v697 / v33;
              // pto: %475
              ;
              int64_t v715 = v714 < v41 ? v41 : v714;
              // pto: %476
              ;
              __gm__ bfloat16_t* v716 = PTOAS__GLOBAL_TENSOR_DATA(v65);
              // pto: %476
              ;
              const int64_t v717 = 0;
              // pto: %476
              ;
              const int64_t v718 = 4194304;
              // pto: %476
              ;
              const int64_t v719 = 65536;
              // pto: %476
              ;
              const int64_t v720 = 256;
              // pto: %476
              ;
              pto::Shape<1, 8, 16, 16, 16> v721 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %476
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v722 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %476
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v723 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v716 + ((v717 + v670 * v718) + v672 * v719 + v715 * v720), v721, v722);
              TLOAD(v712, v723);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              // pto: %v4_wide_acc__iter_v1_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v724 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v648, v36);
              // pto: %v4_wide_acc__iter_v1_l0_a
              ;
              uint64_t v725 = (uint64_t) v23;
              TASSIGN(v724, v725);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              uint16_t v726 = static_cast<uint16_t>(v41);
              uint16_t v727 = static_cast<uint16_t>(v41);
              TEXTRACT(v724, v698, v726, v727);
              // pto: %v4_wide_acc__iter_v1_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v728 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %v4_wide_acc__iter_v1_l0_b
              ;
              uint64_t v729 = (uint64_t) v23;
              TASSIGN(v728, v729);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              uint16_t v730 = static_cast<uint16_t>(v41);
              uint16_t v731 = static_cast<uint16_t>(v41);
              TEXTRACT(v728, v712, v730, v731);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              // pto: %39
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v732 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v648, v36);
              // pto: %39
              ;
              uint64_t v733 = (uint64_t) v25;
              TASSIGN(v732, v733);
              uint16_t v734 = static_cast<uint16_t>(v41);
              uint16_t v735 = static_cast<uint16_t>(v36);
              TEXTRACT(v732, v698, v734, v735);
              // pto: %40
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v736 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %40
              ;
              uint64_t v737 = (uint64_t) v25;
              TASSIGN(v736, v737);
              uint16_t v738 = static_cast<uint16_t>(v36);
              uint16_t v739 = static_cast<uint16_t>(v41);
              TEXTRACT(v736, v712, v738, v739);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v691, v691, v724, v728);
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              TMATMUL_ACC(v691, v691, v732, v736);
            } else {
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              for (int64_t v740 = v41; v740 < v33; v740 += v29) {
                // pto: %477, %478
                ;
                int64_t v741 = (int64_t) ((uint64_t) v695 + (uint64_t) v740) % v32;
                // pto: %479, %480, %481
                ;
                int64_t v742 = v741 < v41 ? (int64_t) ((uint64_t) v741 + (uint64_t) v32) : v741;
                // pto: %482
                ;
                int64_t v743 = (int64_t) ((uint64_t) v742 * (uint64_t) v33);
                // pto: %v4_wide_wrap_x__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v744 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v648, v33);
                // pto: %v4_wide_wrap_x__tile
                ;
                uint64_t v745 = (uint64_t) v23;
                TASSIGN(v744, v745);
                // pto: %485
                ;
                int64_t v746 = (int64_t) ((uint64_t) v655 + (uint64_t) v743);
                // pto: %486
                ;
                int64_t v747 = v746 < v41 ? v41 : v746;
                // pto: %487
                ;
                const int64_t v748 = 0;
                // pto: %487
                ;
                __gm__ bfloat16_t* v749 = PTOAS__GLOBAL_TENSOR_DATA(v62);
                // pto: %487
                ;
                const int64_t v750 = 1;
                // pto: %487
                ;
                const int64_t v751 = 1;
                // pto: %487
                ;
                const int64_t v752 = 1;
                // pto: %487
                ;
                int64_t v753 = v648 * v28;
                // pto: %487
                ;
                int64_t v754 = v752 * v753;
                // pto: %487
                ;
                pto::Shape<1, 1, 1, -1, 16> v755 = pto::Shape<1, 1, 1, -1, 16>(v750, v751, v752, v648, v33);
                // pto: %487
                ;
                pto::Stride<-1, -1, -1, -1, -1> v756 = pto::Stride<-1, -1, -1, -1, -1>(v751 * v754, v754, v753, v28, v29);
                // pto: %487
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v757 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v749 + (v748 + v654 * v28 + v747 * v29), v755, v756);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                TLOAD(v744, v757);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                // pto: %v4_wide_wrap_w__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v758 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %v4_wide_wrap_w__tile
                ;
                uint64_t v759 = (uint64_t) v24;
                TASSIGN(v758, v759);
                // pto: %491
                ;
                int64_t v760 = v743 / v33;
                // pto: %492
                ;
                int64_t v761 = v760 < v41 ? v41 : v760;
                // pto: %493
                ;
                __gm__ bfloat16_t* v762 = PTOAS__GLOBAL_TENSOR_DATA(v65);
                // pto: %493
                ;
                const int64_t v763 = 0;
                // pto: %493
                ;
                const int64_t v764 = 4194304;
                // pto: %493
                ;
                const int64_t v765 = 65536;
                // pto: %493
                ;
                const int64_t v766 = 256;
                // pto: %493
                ;
                pto::Shape<1, 8, 1, 16, 16> v767 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %493
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v768 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %493
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v769 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v762 + ((v763 + v670 * v764) + v672 * v765 + v761 * v766), v767, v768);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                TLOAD(v758, v769);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                // pto: %42
                ;
                Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v770 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v648, v33);
                // pto: %42
                ;
                uint64_t v771 = (uint64_t) v23;
                TASSIGN(v770, v771);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                uint16_t v772 = static_cast<uint16_t>(v41);
                uint16_t v773 = static_cast<uint16_t>(v41);
                TEXTRACT(v770, v744, v772, v773);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                // pto: %43
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v774 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %43
                ;
                uint64_t v775 = (uint64_t) v23;
                TASSIGN(v774, v775);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                uint16_t v776 = static_cast<uint16_t>(v41);
                uint16_t v777 = static_cast<uint16_t>(v41);
                TEXTRACT(v774, v758, v776, v777);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v691, v691, v770, v774);
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            };
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          for (int64_t v778 = v52; v778 < v32; v778 += v29) {
            // pto: %494, %495
            ;
            int64_t v779 = (int64_t) ((uint64_t) v603 + (uint64_t) v778) % v32;
            // pto: %496, %497, %498
            ;
            int64_t v780 = v779 < v41 ? (int64_t) ((uint64_t) v779 + (uint64_t) v32) : v779;
            // pto: %499
            ;
            int64_t v781 = (int64_t) ((uint64_t) v780 * (uint64_t) v33);
            // pto: %v4_wide_tail_x__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v782 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v648, v33);
            // pto: %v4_wide_tail_x__tile
            ;
            uint64_t v783 = (uint64_t) v23;
            TASSIGN(v782, v783);
            // pto: %502
            ;
            int64_t v784 = (int64_t) ((uint64_t) v655 + (uint64_t) v781);
            // pto: %503
            ;
            int64_t v785 = v784 < v41 ? v41 : v784;
            // pto: %504
            ;
            const int64_t v786 = 0;
            // pto: %504
            ;
            __gm__ bfloat16_t* v787 = PTOAS__GLOBAL_TENSOR_DATA(v62);
            // pto: %504
            ;
            const int64_t v788 = 1;
            // pto: %504
            ;
            const int64_t v789 = 1;
            // pto: %504
            ;
            const int64_t v790 = 1;
            // pto: %504
            ;
            int64_t v791 = v648 * v28;
            // pto: %504
            ;
            int64_t v792 = v790 * v791;
            // pto: %504
            ;
            pto::Shape<1, 1, 1, -1, 16> v793 = pto::Shape<1, 1, 1, -1, 16>(v788, v789, v790, v648, v33);
            // pto: %504
            ;
            pto::Stride<-1, -1, -1, -1, -1> v794 = pto::Stride<-1, -1, -1, -1, -1>(v789 * v792, v792, v791, v28, v29);
            // pto: %504
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v795 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v787 + (v786 + v654 * v28 + v785 * v29), v793, v794);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            TLOAD(v782, v795);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %v4_wide_tail_w__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v796 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
            // pto: %v4_wide_tail_w__tile
            ;
            uint64_t v797 = (uint64_t) v24;
            TASSIGN(v796, v797);
            // pto: %508
            ;
            int64_t v798 = v781 / v33;
            // pto: %509
            ;
            int64_t v799 = v798 < v41 ? v41 : v798;
            // pto: %510
            ;
            __gm__ bfloat16_t* v800 = PTOAS__GLOBAL_TENSOR_DATA(v65);
            // pto: %510
            ;
            const int64_t v801 = 0;
            // pto: %510
            ;
            const int64_t v802 = 4194304;
            // pto: %510
            ;
            const int64_t v803 = 65536;
            // pto: %510
            ;
            const int64_t v804 = 256;
            // pto: %510
            ;
            pto::Shape<1, 8, 1, 16, 16> v805 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %510
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v806 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %510
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v807 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v800 + ((v801 + v670 * v802) + v672 * v803 + v799 * v804), v805, v806);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            TLOAD(v796, v807);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %44
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v808 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v648, v33);
            // pto: %44
            ;
            uint64_t v809 = (uint64_t) v23;
            TASSIGN(v808, v809);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            uint16_t v810 = static_cast<uint16_t>(v41);
            uint16_t v811 = static_cast<uint16_t>(v41);
            TEXTRACT(v808, v782, v810, v811);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            // pto: %45
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v812 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
            // pto: %45
            ;
            uint64_t v813 = (uint64_t) v23;
            TASSIGN(v812, v813);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            uint16_t v814 = static_cast<uint16_t>(v41);
            uint16_t v815 = static_cast<uint16_t>(v41);
            TEXTRACT(v812, v796, v814, v815);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v691, v691, v808, v812);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
          // pto: %512, %513
          ;
          int64_t v816 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v595 * (uint64_t) v51) + (uint64_t) v598);
          // pto: %514
          ;
          int64_t v817 = v816 < v41 ? v41 : v816;
          // pto: %515
          ;
          const int64_t v818 = 0;
          // pto: %515
          ;
          __gm__ float* v819 = PTOAS__GLOBAL_TENSOR_DATA(v74);
          // pto: %515
          ;
          const int64_t v820 = 1;
          // pto: %515
          ;
          const int64_t v821 = 1;
          // pto: %515
          ;
          const int64_t v822 = 1;
          // pto: %515
          ;
          int64_t v823 = v648 * v38;
          // pto: %515
          ;
          int64_t v824 = v822 * v823;
          // pto: %515
          ;
          pto::Shape<1, 1, 1, -1, 128> v825 = pto::Shape<1, 1, 1, -1, 128>(v820, v821, v822, v648, v36);
          // pto: %515
          ;
          pto::Stride<-1, -1, -1, -1, -1> v826 = pto::Stride<-1, -1, -1, -1, -1>(v821 * v824, v824, v823, v38, v29);
          // pto: %515
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v827 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v819 + (v818 + v654 * v38 + v817 * v29), v825, v826);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
          TSTORE(v827, v691);
        } else {
          for (int64_t v828 = v41; v828 < v30; v828 += v29) {
            // pto: %516
            ;
            int64_t v829 = (int64_t) ((uint64_t) v600 + (uint64_t) v828);
            // pto: %517
            ;
            if (v829 < v109) {
              // pto: %518
              ;
              int64_t v830 = (int64_t) ((uint64_t) v829 * (uint64_t) v33);
              // pto: %519
              ;
              int64_t v831 = (int64_t) ((uint64_t) v17 - (uint64_t) v830);
              // pto: %520
              ;
              int64_t v832 = v831 < v33 ? v831 : v33;
              // pto: %522, %523, %524, %525, %521
              ;
              int32_t v833 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v829 * (uint64_t) v30) + (uint64_t) v595) * (uint64_t) v30) + (uint64_t) v597)];
              // pto: %526
              ;
              int64_t v834 = (int64_t) v833;
              // pto: %527
              ;
              int64_t v835 = v834 < v41 ? v41 : v834;
              // pto: %v4_narrow_acc__tile
              ;
              Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v836 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
              // pto: %v4_narrow_acc__tile
              ;
              uint64_t v837 = (uint64_t) v23;
              TASSIGN(v836, v837);
              wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              for (int64_t v838 = v41; v838 < v33; v838 += v29) {
                // pto: %528
                ;
                int64_t v839 = (int64_t) ((uint64_t) v838 * (uint64_t) v33);
                // pto: %529, %530
                ;
                int64_t v840 = (int64_t) ((uint64_t) v835 + (uint64_t) v839) % v32;
                // pto: %531, %532, %533
                ;
                int64_t v841 = v840 < v41 ? (int64_t) ((uint64_t) v840 + (uint64_t) v32) : v840;
                // pto: %534
                ;
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                if (v841 <= v50) {
                  // pto: %535
                  ;
                  int64_t v842 = (int64_t) ((uint64_t) v841 * (uint64_t) v33);
                  // pto: %v4_narrow_packet_x__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v843 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v832, v32);
                  // pto: %v4_narrow_packet_x__tile
                  ;
                  uint64_t v844 = (uint64_t) v24;
                  TASSIGN(v843, v844);
                  // pto: %536
                  ;
                  int64_t v845 = v830 < v41 ? v41 : v830;
                  // pto: %537, %538
                  ;
                  int64_t v846 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v595 * (uint64_t) v37) + (uint64_t) v842);
                  // pto: %539
                  ;
                  int64_t v847 = v846 < v41 ? v41 : v846;
                  // pto: %540
                  ;
                  const int64_t v848 = 0;
                  // pto: %540
                  ;
                  __gm__ bfloat16_t* v849 = PTOAS__GLOBAL_TENSOR_DATA(v62);
                  // pto: %540
                  ;
                  const int64_t v850 = 1;
                  // pto: %540
                  ;
                  const int64_t v851 = 1;
                  // pto: %540
                  ;
                  const int64_t v852 = 1;
                  // pto: %540
                  ;
                  int64_t v853 = v832 * v28;
                  // pto: %540
                  ;
                  int64_t v854 = v852 * v853;
                  // pto: %540
                  ;
                  pto::Shape<1, 1, 1, -1, 256> v855 = pto::Shape<1, 1, 1, -1, 256>(v850, v851, v852, v832, v32);
                  // pto: %540
                  ;
                  pto::Stride<-1, -1, -1, -1, -1> v856 = pto::Stride<-1, -1, -1, -1, -1>(v851 * v854, v854, v853, v28, v29);
                  // pto: %540
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v857 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v849 + (v848 + v845 * v28 + v847 * v29), v855, v856);
                  TLOAD(v843, v857);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  // pto: %v4_narrow_packet_w__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v858 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
                  // pto: %v4_narrow_packet_w__tile
                  ;
                  uint64_t v859 = (uint64_t) v23;
                  TASSIGN(v858, v859);
                  // pto: %541
                  ;
                  int64_t v860 = v595 < v41 ? v41 : v595;
                  // pto: %542
                  ;
                  int64_t v861 = v598 / v33;
                  // pto: %543
                  ;
                  int64_t v862 = v861 < v41 ? v41 : v861;
                  // pto: %544
                  ;
                  int64_t v863 = v842 / v33;
                  // pto: %545
                  ;
                  int64_t v864 = v863 < v41 ? v41 : v863;
                  // pto: %546
                  ;
                  __gm__ bfloat16_t* v865 = PTOAS__GLOBAL_TENSOR_DATA(v65);
                  // pto: %546
                  ;
                  const int64_t v866 = 0;
                  // pto: %546
                  ;
                  const int64_t v867 = 4194304;
                  // pto: %546
                  ;
                  const int64_t v868 = 65536;
                  // pto: %546
                  ;
                  const int64_t v869 = 256;
                  // pto: %546
                  ;
                  pto::Shape<1, 8, 16, 16, 16> v870 = pto::Shape<1, 8, 16, 16, 16>();
                  // pto: %546
                  ;
                  pto::Stride<4194304, 65536, 256, 16, 1> v871 = pto::Stride<4194304, 65536, 256, 16, 1>();
                  // pto: %546
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v872 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v865 + ((v866 + v860 * v867) + v862 * v868 + v864 * v869), v870, v871);
                  TLOAD(v858, v872);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  // pto: %v4_narrow_acc__iter_v1_l0_a
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v873 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v832, v36);
                  // pto: %v4_narrow_acc__iter_v1_l0_a
                  ;
                  uint64_t v874 = (uint64_t) v23;
                  TASSIGN(v873, v874);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  uint16_t v875 = static_cast<uint16_t>(v41);
                  uint16_t v876 = static_cast<uint16_t>(v41);
                  TEXTRACT(v873, v843, v875, v876);
                  // pto: %v4_narrow_acc__iter_v1_l0_b
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v877 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %v4_narrow_acc__iter_v1_l0_b
                  ;
                  uint64_t v878 = (uint64_t) v23;
                  TASSIGN(v877, v878);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  uint16_t v879 = static_cast<uint16_t>(v41);
                  uint16_t v880 = static_cast<uint16_t>(v41);
                  TEXTRACT(v877, v858, v879, v880);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  // pto: %46
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v881 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v832, v36);
                  // pto: %46
                  ;
                  uint64_t v882 = (uint64_t) v25;
                  TASSIGN(v881, v882);
                  uint16_t v883 = static_cast<uint16_t>(v41);
                  uint16_t v884 = static_cast<uint16_t>(v36);
                  TEXTRACT(v881, v843, v883, v884);
                  // pto: %47
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v885 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %47
                  ;
                  uint64_t v886 = (uint64_t) v25;
                  TASSIGN(v885, v886);
                  uint16_t v887 = static_cast<uint16_t>(v36);
                  uint16_t v888 = static_cast<uint16_t>(v41);
                  TEXTRACT(v885, v858, v887, v888);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  // pto: %547
                  ;
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  if (v838 == v41) {
                    pipe_barrier(PIPE_M);
                    TMATMUL(v836, v873, v877);
                  } else {
                    pipe_barrier(PIPE_M);
                    TMATMUL_ACC(v836, v836, v873, v877);
                  };
                  pipe_barrier(PIPE_M);
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  TMATMUL_ACC(v836, v836, v881, v885);
                } else {
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  for (int64_t v889 = v41; v889 < v33; v889 += v29) {
                    // pto: %548, %549
                    ;
                    int64_t v890 = (int64_t) ((uint64_t) v841 + (uint64_t) v889) % v32;
                    // pto: %550, %551, %552
                    ;
                    int64_t v891 = v890 < v41 ? (int64_t) ((uint64_t) v890 + (uint64_t) v32) : v890;
                    // pto: %553
                    ;
                    int64_t v892 = (int64_t) ((uint64_t) v891 * (uint64_t) v33);
                    // pto: %v4_narrow_wrap_x__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v893 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v832, v33);
                    // pto: %v4_narrow_wrap_x__tile
                    ;
                    uint64_t v894 = (uint64_t) v24;
                    TASSIGN(v893, v894);
                    // pto: %554
                    ;
                    int64_t v895 = v830 < v41 ? v41 : v830;
                    // pto: %555, %556
                    ;
                    int64_t v896 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v595 * (uint64_t) v37) + (uint64_t) v892);
                    // pto: %557
                    ;
                    int64_t v897 = v896 < v41 ? v41 : v896;
                    // pto: %558
                    ;
                    const int64_t v898 = 0;
                    // pto: %558
                    ;
                    __gm__ bfloat16_t* v899 = PTOAS__GLOBAL_TENSOR_DATA(v62);
                    // pto: %558
                    ;
                    const int64_t v900 = 1;
                    // pto: %558
                    ;
                    const int64_t v901 = 1;
                    // pto: %558
                    ;
                    const int64_t v902 = 1;
                    // pto: %558
                    ;
                    int64_t v903 = v832 * v28;
                    // pto: %558
                    ;
                    int64_t v904 = v902 * v903;
                    // pto: %558
                    ;
                    pto::Shape<1, 1, 1, -1, 16> v905 = pto::Shape<1, 1, 1, -1, 16>(v900, v901, v902, v832, v33);
                    // pto: %558
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v906 = pto::Stride<-1, -1, -1, -1, -1>(v901 * v904, v904, v903, v28, v29);
                    // pto: %558
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v907 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v899 + (v898 + v895 * v28 + v897 * v29), v905, v906);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    TLOAD(v893, v907);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    // pto: %v4_narrow_wrap_w__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v908 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %v4_narrow_wrap_w__tile
                    ;
                    uint64_t v909 = (uint64_t) v23;
                    TASSIGN(v908, v909);
                    // pto: %559
                    ;
                    int64_t v910 = v595 < v41 ? v41 : v595;
                    // pto: %560
                    ;
                    int64_t v911 = v598 / v33;
                    // pto: %561
                    ;
                    int64_t v912 = v911 < v41 ? v41 : v911;
                    // pto: %562
                    ;
                    int64_t v913 = v892 / v33;
                    // pto: %563
                    ;
                    int64_t v914 = v913 < v41 ? v41 : v913;
                    // pto: %564
                    ;
                    __gm__ bfloat16_t* v915 = PTOAS__GLOBAL_TENSOR_DATA(v65);
                    // pto: %564
                    ;
                    const int64_t v916 = 0;
                    // pto: %564
                    ;
                    const int64_t v917 = 4194304;
                    // pto: %564
                    ;
                    const int64_t v918 = 65536;
                    // pto: %564
                    ;
                    const int64_t v919 = 256;
                    // pto: %564
                    ;
                    pto::Shape<1, 8, 1, 16, 16> v920 = pto::Shape<1, 8, 1, 16, 16>();
                    // pto: %564
                    ;
                    pto::Stride<4194304, 65536, 256, 16, 1> v921 = pto::Stride<4194304, 65536, 256, 16, 1>();
                    // pto: %564
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v922 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v915 + ((v916 + v910 * v917) + v912 * v918 + v914 * v919), v920, v921);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                    TLOAD(v908, v922);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    // pto: %49
                    ;
                    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v923 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v832, v33);
                    // pto: %49
                    ;
                    uint64_t v924 = (uint64_t) v23;
                    TASSIGN(v923, v924);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                    uint16_t v925 = static_cast<uint16_t>(v41);
                    uint16_t v926 = static_cast<uint16_t>(v41);
                    TEXTRACT(v923, v893, v925, v926);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    // pto: %50
                    ;
                    Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v927 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %50
                    ;
                    uint64_t v928 = (uint64_t) v23;
                    TASSIGN(v927, v928);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    uint16_t v929 = static_cast<uint16_t>(v41);
                    uint16_t v930 = static_cast<uint16_t>(v41);
                    TEXTRACT(v927, v908, v929, v930);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    // pto: %566, %567
                    ;
                    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    if ((int64_t) ((uint64_t) v839 + (uint64_t) v889) == v41) {
                      pipe_barrier(PIPE_M);
                      TMATMUL(v836, v923, v927);
                    } else {
                      pipe_barrier(PIPE_M);
                      TMATMUL_ACC(v836, v836, v923, v927);
                    };
                    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  };
                  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
              // pto: %568
              ;
              int64_t v931 = v830 < v41 ? v41 : v830;
              // pto: %569, %570
              ;
              int64_t v932 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v595 * (uint64_t) v51) + (uint64_t) v598);
              // pto: %571
              ;
              int64_t v933 = v932 < v41 ? v41 : v932;
              // pto: %572
              ;
              __gm__ float* v934 = PTOAS__GLOBAL_TENSOR_DATA(v74);
              // pto: %572
              ;
              const int64_t v935 = 0;
              // pto: %572
              ;
              const int64_t v936 = 8192;
              // pto: %572
              ;
              pto::Shape<1, 1, 1, 16, 128> v937 = pto::Shape<1, 1, 1, 16, 128>();
              // pto: %572
              ;
              pto::Stride<131072, 131072, 131072, 8192, 1> v938 = pto::Stride<131072, 131072, 131072, 8192, 1>();
              // pto: %572
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v939 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v934 + (v935 + v931 * v936 + v933), v937, v938);
              wait_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
              pipe_barrier(PIPE_FIX);
              TSTORE(v939, v836);
              set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
            };
          };
        };
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    };
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %574
  int64_t v940 = (int64_t) ((uint64_t) v98 + (uint64_t) v53);
  // pto: %575
  int64_t v941 = v940 < v41 ? v41 : v940;
  // pto: %signals__ssa_v1_signal_pview
  __gm__ int32_t* v942 = PTOAS__GLOBAL_TENSOR_DATA(v84);
  // pto: %signals__ssa_v1_signal_pview
  const int64_t v943 = 0;
  // pto: %signals__ssa_v1_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v944 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v945 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v946 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v942 + (v943 + v941), v944, v945);
  pto::comm::NotifyOp v947 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v946, v107, v947);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void vector(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ bfloat16_t* v6, __gm__ int8_t* v7, __gm__ float* v8, __gm__ bfloat16_t* v9, __gm__ bfloat16_t* v10, __gm__ float* v11, __gm__ float* v12, __gm__ bfloat16_t* v13, __gm__ float* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21, int32_t v22) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int32_t v23 = 1;
  // pto: %c1_index
  const int64_t v24 = 1;
  // pto: %c128_index
  const int64_t v25 = 128;
  // pto: %c55296_index
  const int64_t v26 = 55296;
  // pto: %c2_index
  const int64_t v27 = 2;
  // pto: %c24_index
  const int64_t v28 = 24;
  // pto: %c0_index
  const int64_t v29 = 0;
  // pto: %signals__ssa_v0_view
  const int64_t v30 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v31 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %signals__ssa_v0_view
  int64_t v34 = v26 * v24;
  // pto: %signals__ssa_v0_view
  int64_t v35 = v33 * v34;
  // pto: %signals__ssa_v0_view
  int64_t v36 = v32 * v35;
  // pto: %signals__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v37 = pto::Shape<1, 1, 1, 1, -1>(v30, v31, v32, v33, v26);
  // pto: %signals__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v38 = pto::Stride<-1, -1, -1, -1, -1>(v31 * v36, v36, v35, v34, v24);
  // pto: %signals__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v39 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v37, v38);
  // pto: %t__tmp_v0, %0, %1, %t__tmp_v1, %2, %3
  int64_t v40 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) v20) * (uint64_t) v27) + (uint64_t) ((int64_t) v22)) + (uint64_t) v28) * (uint64_t) v25);
  // pto: %4
  int64_t v41 = v40 < v29 ? v29 : v40;
  // pto: %signals__ssa_v0_pview
  __gm__ int32_t* v42 = PTOAS__GLOBAL_TENSOR_DATA(v39);
  // pto: %signals__ssa_v0_pview
  const int64_t v43 = 0;
  // pto: %signals__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 1> v44 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  pto::Stride<1, 1, 1, 1, 1> v45 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v46 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v42 + (v43 + v41), v44, v45);
  __gm__ int32_t* v47 = PTOAS__GLOBAL_TENSOR_DATA(v46);
  PTOAS__DCCI_SINGLE_CACHE_LINE(v47);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %t__tile
  int32_t v48 = (v16)[v40];
  // pto: %6
  int32_t v49 = (int32_t) ((uint32_t) v48 + (uint32_t) v23);
  pipe_barrier(PIPE_ALL);
  pto::comm::NotifyOp v50 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v46, v49, v50);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  #endif // __DAV_VEC__

  return;
}