#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void cube_tail(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ bfloat16_t* v6, __gm__ int8_t* v7, __gm__ float* v8, __gm__ bfloat16_t* v9, __gm__ bfloat16_t* v10, __gm__ float* v11, __gm__ float* v12, __gm__ bfloat16_t* v13, __gm__ float* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v22 = 0;
  // pto: %c65536_i64
  const int64_t v23 = 65536;
  // pto: %c16384_i64
  const int64_t v24 = 16384;
  // pto: %c32768_i64
  const int64_t v25 = 32768;
  // pto: %c1_index
  const int64_t v26 = 1;
  // pto: %c64_index
  const int64_t v27 = 64;
  // pto: %c256_index
  const int64_t v28 = 256;
  // pto: %c16_index
  const int64_t v29 = 16;
  // pto: %c128_index
  const int64_t v30 = 128;
  // pto: %c512_index
  const int64_t v31 = 512;
  // pto: %c32_index
  const int64_t v32 = 32;
  // pto: %c33554432_index
  const int64_t v33 = 33554432;
  // pto: %c262144_index
  const int64_t v34 = 262144;
  // pto: %c4096_index
  const int64_t v35 = 4096;
  // pto: %c8192_index
  const int64_t v36 = 8192;
  // pto: %c55296_index
  const int64_t v37 = 55296;
  // pto: %c0_index
  const int64_t v38 = 0;
  // pto: %c15_index
  const int64_t v39 = 15;
  // pto: %c24_index
  const int64_t v40 = 24;
  // pto: %c72_index
  const int64_t v41 = 72;
  // pto: %c27648_index
  const int64_t v42 = 27648;
  // pto: %c63_index
  const int64_t v43 = 63;
  // pto: %c36864_index
  const int64_t v44 = 36864;
  // pto: %wo_b__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v45 = pto::Shape<-1, -1, -1, -1, -1>(v26, v30, v31, v29, v32);
  // pto: %wo_b__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v46 = pto::Stride<-1, -1, -1, -1, -1>(v33, v34, v31, v32, v26);
  // pto: %wo_b__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v47 = GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v3, v45, v46);
  // pto: %quantized__ssa_v3_view
  const int64_t v48 = 1;
  // pto: %quantized__ssa_v3_view
  const int64_t v49 = 1;
  // pto: %quantized__ssa_v3_view
  const int64_t v50 = 1;
  // pto: %quantized__ssa_v3_view
  int64_t v51 = (int64_t) v17;
  // pto: %quantized__ssa_v3_view
  int64_t v52 = v51 * v36;
  // pto: %quantized__ssa_v3_view
  int64_t v53 = v50 * v52;
  // pto: %quantized__ssa_v3_view
  pto::Shape<1, 1, 1, -1, -1> v54 = pto::Shape<1, 1, 1, -1, -1>(v48, v49, v50, v51, v36);
  // pto: %quantized__ssa_v3_view
  pto::Stride<-1, -1, -1, -1, -1> v55 = pto::Stride<-1, -1, -1, -1, -1>(v49 * v53, v53, v52, v36, v26);
  // pto: %quantized__ssa_v3_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v56 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v54, v55);
  // pto: %integer_accum__ssa_v3_view
  const int64_t v57 = 1;
  // pto: %integer_accum__ssa_v3_view
  const int64_t v58 = 1;
  // pto: %integer_accum__ssa_v3_view
  const int64_t v59 = 1;
  // pto: %integer_accum__ssa_v3_view
  int64_t v60 = (int64_t) v19;
  // pto: %integer_accum__ssa_v3_view
  int64_t v61 = v60 * v35;
  // pto: %integer_accum__ssa_v3_view
  int64_t v62 = v59 * v61;
  // pto: %integer_accum__ssa_v3_view
  pto::Shape<1, 1, 1, -1, -1> v63 = pto::Shape<1, 1, 1, -1, -1>(v57, v58, v59, v60, v35);
  // pto: %integer_accum__ssa_v3_view
  pto::Stride<-1, -1, -1, -1, -1> v64 = pto::Stride<-1, -1, -1, -1, -1>(v58 * v62, v62, v61, v35, v26);
  // pto: %integer_accum__ssa_v3_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v65 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v63, v64);
  // pto: %signals__ssa_v3_view
  const int64_t v66 = 1;
  // pto: %signals__ssa_v3_view
  const int64_t v67 = 1;
  // pto: %signals__ssa_v3_view
  const int64_t v68 = 1;
  // pto: %signals__ssa_v3_view
  const int64_t v69 = 1;
  // pto: %signals__ssa_v3_view
  int64_t v70 = v37 * v26;
  // pto: %signals__ssa_v3_view
  int64_t v71 = v69 * v70;
  // pto: %signals__ssa_v3_view
  int64_t v72 = v68 * v71;
  // pto: %signals__ssa_v3_view
  pto::Shape<1, 1, 1, 1, -1> v73 = pto::Shape<1, 1, 1, 1, -1>(v66, v67, v68, v69, v37);
  // pto: %signals__ssa_v3_view
  pto::Stride<-1, -1, -1, -1, -1> v74 = pto::Stride<-1, -1, -1, -1, -1>(v67 * v72, v72, v71, v70, v26);
  // pto: %signals__ssa_v3_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v75 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v73, v74);
  // pto: %worker__ssa_v0
  int64_t v76 = (int64_t) v20;
  // pto: %12
  int64_t v77 = (int64_t) ((uint64_t) v76 * (uint64_t) v30);
  // pto: %13
  int64_t v78 = v77 < v38 ? v38 : v77;
  // pto: %signals__ssa_v3_pview
  __gm__ int32_t* v79 = PTOAS__GLOBAL_TENSOR_DATA(v75);
  // pto: %signals__ssa_v3_pview
  const int64_t v80 = 0;
  // pto: %signals__ssa_v3_pview
  pto::Shape<1, 1, 1, 1, 1> v81 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v3_pview
  pto::Stride<1, 1, 1, 1, 1> v82 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v3_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v83 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v79 + (v80 + v78), v81, v82);
  __gm__ int32_t* v84 = PTOAS__GLOBAL_TENSOR_DATA(v83);
  PTOAS__DCCI_SINGLE_CACHE_LINE(v84);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  // pto: %generation_inline10__tile
  int32_t v85 = (v16)[v77];
  for (int64_t v86 = v40; v86 < v41; v86 += v26) {
    // pto: %16, %17
    ;
    int64_t v87 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v86 * (uint64_t) v30) + (uint64_t) v42);
    // pto: %18
    ;
    int64_t v88 = v87 < v38 ? v38 : v87;
    // pto: %signals__ssa_v1_signal_pview
    ;
    __gm__ int32_t* v89 = PTOAS__GLOBAL_TENSOR_DATA(v75);
    // pto: %signals__ssa_v1_signal_pview
    ;
    const int64_t v90 = 0;
    // pto: %signals__ssa_v1_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v91 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals__ssa_v1_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v92 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals__ssa_v1_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v93 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v89 + (v90 + v88), v91, v92);
    pto::comm::WaitCmp v94 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v93, v85, v94);
  }
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %19
  if (v17 <= v29) {
    // pto: %14, %15, %20
    ;
    for (int64_t v95 = v76; v95 < ((int64_t) ((uint64_t) ((int64_t) ((uint64_t) v17 + (uint64_t) v39) / v29) * (uint64_t) v32)); v95 += v40) {
      // pto: %21, %22
      ;
      int64_t v96 = (int64_t) ((uint64_t) (v95 / v32) * (uint64_t) v29);
      // pto: %23
      ;
      int64_t v97 = v95 % v32;
      // pto: %24, %25, %26
      ;
      int64_t v98 = v97 < v38 ? (int64_t) ((uint64_t) v97 + (uint64_t) v32) : v97;
      // pto: %27
      ;
      int64_t v99 = (int64_t) ((uint64_t) v98 * (uint64_t) v30);
      // pto: %28
      ;
      int64_t v100 = (int64_t) ((uint64_t) v17 - (uint64_t) v96);
      // pto: %29
      ;
      int64_t v101 = v100 < v29 ? v100 : v29;
      // pto: %b_acc__tile
      ;
      Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v29, v30);
      // pto: %b_acc__tile
      ;
      uint64_t v103 = (uint64_t) v22;
      TASSIGN(v102, v103);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
      for (int64_t v104 = v38; v104 < v29; v104 += v26) {
        // pto: %30
        ;
        int64_t v105 = (int64_t) ((uint64_t) v104 * (uint64_t) v31);
        // pto: %b_input__tile
        ;
        Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v101, v31);
        // pto: %b_input__tile
        ;
        uint64_t v107 = (uint64_t) v23;
        TASSIGN(v106, v107);
        // pto: %31
        ;
        int64_t v108 = v96 < v38 ? v38 : v96;
        // pto: %32
        ;
        int64_t v109 = v105 < v38 ? v38 : v105;
        // pto: %quantized__ssa_v3_pview
        ;
        const int64_t v110 = 0;
        // pto: %quantized__ssa_v3_pview
        ;
        __gm__ int8_t* v111 = PTOAS__GLOBAL_TENSOR_DATA(v56);
        // pto: %quantized__ssa_v3_pview
        ;
        const int64_t v112 = 1;
        // pto: %quantized__ssa_v3_pview
        ;
        const int64_t v113 = 1;
        // pto: %quantized__ssa_v3_pview
        ;
        const int64_t v114 = 1;
        // pto: %quantized__ssa_v3_pview
        ;
        int64_t v115 = v101 * v36;
        // pto: %quantized__ssa_v3_pview
        ;
        int64_t v116 = v114 * v115;
        // pto: %quantized__ssa_v3_pview
        ;
        pto::Shape<1, 1, 1, -1, 512> v117 = pto::Shape<1, 1, 1, -1, 512>(v112, v113, v114, v101, v31);
        // pto: %quantized__ssa_v3_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v118 = pto::Stride<-1, -1, -1, -1, -1>(v113 * v116, v116, v115, v36, v26);
        // pto: %quantized__ssa_v3_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v119 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v111 + (v110 + v108 * v36 + v109 * v26), v117, v118);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        TLOAD(v106, v119);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %b_weight__tile
        ;
        Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v31, v30);
        // pto: %b_weight__tile
        ;
        uint64_t v121 = (uint64_t) v22;
        TASSIGN(v120, v121);
        // pto: %33
        ;
        int64_t v122 = v99 / v32;
        // pto: %34
        ;
        int64_t v123 = v122 < v38 ? v38 : v122;
        // pto: %35
        ;
        int64_t v124 = v105 / v29;
        // pto: %36
        ;
        int64_t v125 = v124 < v38 ? v38 : v124;
        // pto: %wo_b__ssa_v0_pview
        ;
        __gm__ int8_t* v126 = PTOAS__GLOBAL_TENSOR_DATA(v47);
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v127 = 0;
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v128 = 262144;
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v129 = 512;
        // pto: %wo_b__ssa_v0_pview
        ;
        pto::Shape<1, 4, 32, 16, 32> v130 = pto::Shape<1, 4, 32, 16, 32>();
        // pto: %wo_b__ssa_v0_pview
        ;
        pto::Stride<33554432, 262144, 512, 32, 1> v131 = pto::Stride<33554432, 262144, 512, 32, 1>();
        // pto: %wo_b__ssa_v0_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v132 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v126 + (v127 + v123 * v128 + v125 * v129), v130, v131);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v120, v132);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %b_acc__tile_l0_a
        ;
        Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v133 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v101, v28);
        // pto: %b_acc__tile_l0_a
        ;
        uint64_t v134 = (uint64_t) v22;
        TASSIGN(v133, v134);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        uint16_t v135 = static_cast<uint16_t>(v38);
        uint16_t v136 = static_cast<uint16_t>(v38);
        TEXTRACT(v133, v106, v135, v136);
        // pto: %b_acc__tile_l0_b
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v28, v30);
        // pto: %b_acc__tile_l0_b
        ;
        uint64_t v138 = (uint64_t) v22;
        TASSIGN(v137, v138);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v139 = static_cast<uint16_t>(v38);
        uint16_t v140 = static_cast<uint16_t>(v38);
        TEXTRACT(v137, v120, v139, v140);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %0
        ;
        Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v141 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v101, v28);
        // pto: %0
        ;
        uint64_t v142 = (uint64_t) v24;
        TASSIGN(v141, v142);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v143 = static_cast<uint16_t>(v38);
        uint16_t v144 = static_cast<uint16_t>(v28);
        TEXTRACT(v141, v106, v143, v144);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        // pto: %1
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v145 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v28, v30);
        // pto: %1
        ;
        uint64_t v146 = (uint64_t) v25;
        TASSIGN(v145, v146);
        uint16_t v147 = static_cast<uint16_t>(v28);
        uint16_t v148 = static_cast<uint16_t>(v38);
        TEXTRACT(v145, v120, v147, v148);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %37
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        if (v104 == v38) {
          pipe_barrier(PIPE_M);
          TMATMUL(v102, v133, v137);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v102, v102, v133, v137);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v102, v102, v141, v145);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      };
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      // pto: %38
      ;
      int64_t v149 = v96 < v38 ? v38 : v96;
      // pto: %39
      ;
      int64_t v150 = v99 < v38 ? v38 : v99;
      // pto: %integer_accum__ssa_v3_pview
      ;
      __gm__ int32_t* v151 = PTOAS__GLOBAL_TENSOR_DATA(v65);
      // pto: %integer_accum__ssa_v3_pview
      ;
      const int64_t v152 = 0;
      // pto: %integer_accum__ssa_v3_pview
      ;
      const int64_t v153 = 4096;
      // pto: %integer_accum__ssa_v3_pview
      ;
      pto::Shape<1, 1, 1, 16, 128> v154 = pto::Shape<1, 1, 1, 16, 128>();
      // pto: %integer_accum__ssa_v3_pview
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v155 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %integer_accum__ssa_v3_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v156 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v151 + (v152 + v149 * v153 + v150), v154, v155);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      pipe_barrier(PIPE_FIX);
      TSTORE(v156, v102);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    };
  } else {
    // pto: %40, %41, %42
    ;
    for (int64_t v157 = v76; v157 < ((int64_t) ((uint64_t) ((int64_t) ((uint64_t) v17 + (uint64_t) v43) / v27) * (uint64_t) v32)); v157 += v40) {
      // pto: %43, %44
      ;
      int64_t v158 = (int64_t) ((uint64_t) (v157 / v32) * (uint64_t) v27);
      // pto: %45
      ;
      int64_t v159 = v157 % v32;
      // pto: %46, %47, %48
      ;
      int64_t v160 = v159 < v38 ? (int64_t) ((uint64_t) v159 + (uint64_t) v32) : v159;
      // pto: %49
      ;
      int64_t v161 = (int64_t) ((uint64_t) v160 * (uint64_t) v30);
      // pto: %50
      ;
      int64_t v162 = (int64_t) ((uint64_t) v17 - (uint64_t) v158);
      // pto: %51
      ;
      int64_t v163 = v162 < v27 ? v162 : v27;
      // pto: %wide_first_input__tile
      ;
      Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v164 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v163, v31);
      // pto: %wide_first_input__tile
      ;
      uint64_t v165 = (uint64_t) v23;
      TASSIGN(v164, v165);
      // pto: %52
      ;
      int64_t v166 = v158 < v38 ? v38 : v158;
      // pto: %53
      ;
      const int64_t v167 = 0;
      // pto: %53
      ;
      __gm__ int8_t* v168 = PTOAS__GLOBAL_TENSOR_DATA(v56);
      // pto: %53
      ;
      const int64_t v169 = 1;
      // pto: %53
      ;
      const int64_t v170 = 1;
      // pto: %53
      ;
      const int64_t v171 = 1;
      // pto: %53
      ;
      int64_t v172 = v163 * v36;
      // pto: %53
      ;
      int64_t v173 = v171 * v172;
      // pto: %53
      ;
      pto::Shape<1, 1, 1, -1, 512> v174 = pto::Shape<1, 1, 1, -1, 512>(v169, v170, v171, v163, v31);
      // pto: %53
      ;
      pto::Stride<-1, -1, -1, -1, -1> v175 = pto::Stride<-1, -1, -1, -1, -1>(v170 * v173, v173, v172, v36, v26);
      // pto: %53
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v176 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v168 + (v167 + v166 * v36 + v38 * v26), v174, v175);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v164, v176);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      // pto: %wide_first_weight__tile
      ;
      Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v31, v30);
      // pto: %wide_first_weight__tile
      ;
      uint64_t v178 = (uint64_t) v22;
      TASSIGN(v177, v178);
      // pto: %54
      ;
      int64_t v179 = v161 / v32;
      // pto: %55
      ;
      int64_t v180 = v179 < v38 ? v38 : v179;
      // pto: %56
      ;
      __gm__ int8_t* v181 = PTOAS__GLOBAL_TENSOR_DATA(v47);
      // pto: %56
      ;
      const int64_t v182 = 0;
      // pto: %56
      ;
      const int64_t v183 = 262144;
      // pto: %56
      ;
      pto::Shape<1, 4, 32, 16, 32> v184 = pto::Shape<1, 4, 32, 16, 32>();
      // pto: %56
      ;
      pto::Stride<33554432, 262144, 512, 32, 1> v185 = pto::Stride<33554432, 262144, 512, 32, 1>();
      // pto: %56
      ;
      GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v186 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v181 + (v182 + v180 * v183), v184, v185);
      TLOAD(v177, v186);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %wide_b_acc__tile_l0_init_storage
      ;
      Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v187 = Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v27, v30);
      // pto: %wide_b_acc__tile_l0_init_storage
      ;
      uint64_t v188 = (uint64_t) v22;
      TASSIGN(v187, v188);
      v187.SetValidShape(v163, v30);
      // pto: %wide_b_acc__tile_l0_a
      ;
      Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v189 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v163, v28);
      // pto: %wide_b_acc__tile_l0_a
      ;
      uint64_t v190 = (uint64_t) v22;
      TASSIGN(v189, v190);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      uint16_t v191 = static_cast<uint16_t>(v38);
      uint16_t v192 = static_cast<uint16_t>(v38);
      TEXTRACT(v189, v164, v191, v192);
      // pto: %wide_b_acc__tile_l0_b
      ;
      Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v193 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v28, v30);
      // pto: %wide_b_acc__tile_l0_b
      ;
      uint64_t v194 = (uint64_t) v22;
      TASSIGN(v193, v194);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      uint16_t v195 = static_cast<uint16_t>(v38);
      uint16_t v196 = static_cast<uint16_t>(v38);
      TEXTRACT(v193, v177, v195, v196);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      // pto: %3
      ;
      Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v197 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v163, v28);
      // pto: %3
      ;
      uint64_t v198 = (uint64_t) v24;
      TASSIGN(v197, v198);
      uint16_t v199 = static_cast<uint16_t>(v38);
      uint16_t v200 = static_cast<uint16_t>(v28);
      TEXTRACT(v197, v164, v199, v200);
      // pto: %4
      ;
      Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v201 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v28, v30);
      // pto: %4
      ;
      uint64_t v202 = (uint64_t) v25;
      TASSIGN(v201, v202);
      uint16_t v203 = static_cast<uint16_t>(v28);
      uint16_t v204 = static_cast<uint16_t>(v38);
      TEXTRACT(v201, v177, v203, v204);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
      TMATMUL(v187, v189, v193);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      TMATMUL_ACC(v187, v187, v197, v201);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      for (int64_t v205 = v26; v205 < v29; v205 += v26) {
        // pto: %57
        ;
        int64_t v206 = (int64_t) ((uint64_t) v205 * (uint64_t) v31);
        // pto: %wide_b_input__tile
        ;
        Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v163, v31);
        // pto: %wide_b_input__tile
        ;
        uint64_t v208 = (uint64_t) v23;
        TASSIGN(v207, v208);
        // pto: %59
        ;
        int64_t v209 = v206 < v38 ? v38 : v206;
        // pto: %60
        ;
        const int64_t v210 = 0;
        // pto: %60
        ;
        __gm__ int8_t* v211 = PTOAS__GLOBAL_TENSOR_DATA(v56);
        // pto: %60
        ;
        const int64_t v212 = 1;
        // pto: %60
        ;
        const int64_t v213 = 1;
        // pto: %60
        ;
        const int64_t v214 = 1;
        // pto: %60
        ;
        int64_t v215 = v163 * v36;
        // pto: %60
        ;
        int64_t v216 = v214 * v215;
        // pto: %60
        ;
        pto::Shape<1, 1, 1, -1, 512> v217 = pto::Shape<1, 1, 1, -1, 512>(v212, v213, v214, v163, v31);
        // pto: %60
        ;
        pto::Stride<-1, -1, -1, -1, -1> v218 = pto::Stride<-1, -1, -1, -1, -1>(v213 * v216, v216, v215, v36, v26);
        // pto: %60
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v219 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v211 + (v210 + v166 * v36 + v209 * v26), v217, v218);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        TLOAD(v207, v219);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
        // pto: %wide_b_weight__tile
        ;
        Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v31, v30);
        // pto: %wide_b_weight__tile
        ;
        uint64_t v221 = (uint64_t) v22;
        TASSIGN(v220, v221);
        // pto: %63
        ;
        int64_t v222 = v206 / v29;
        // pto: %64
        ;
        int64_t v223 = v222 < v38 ? v38 : v222;
        // pto: %65
        ;
        __gm__ int8_t* v224 = PTOAS__GLOBAL_TENSOR_DATA(v47);
        // pto: %65
        ;
        const int64_t v225 = 0;
        // pto: %65
        ;
        const int64_t v226 = 262144;
        // pto: %65
        ;
        const int64_t v227 = 512;
        // pto: %65
        ;
        pto::Shape<1, 4, 32, 16, 32> v228 = pto::Shape<1, 4, 32, 16, 32>();
        // pto: %65
        ;
        pto::Stride<33554432, 262144, 512, 32, 1> v229 = pto::Stride<33554432, 262144, 512, 32, 1>();
        // pto: %65
        ;
        GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v230 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v224 + (v225 + v180 * v226 + v223 * v227), v228, v229);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        TLOAD(v220, v230);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        // pto: %6
        ;
        Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v231 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v163, v28);
        // pto: %6
        ;
        uint64_t v232 = (uint64_t) v22;
        TASSIGN(v231, v232);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        uint16_t v233 = static_cast<uint16_t>(v38);
        uint16_t v234 = static_cast<uint16_t>(v38);
        TEXTRACT(v231, v207, v233, v234);
        // pto: %7
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v235 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v28, v30);
        // pto: %7
        ;
        uint64_t v236 = (uint64_t) v22;
        TASSIGN(v235, v236);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        uint16_t v237 = static_cast<uint16_t>(v38);
        uint16_t v238 = static_cast<uint16_t>(v38);
        TEXTRACT(v235, v220, v237, v238);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        // pto: %8
        ;
        Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v239 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v163, v28);
        // pto: %8
        ;
        uint64_t v240 = (uint64_t) v24;
        TASSIGN(v239, v240);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        uint16_t v241 = static_cast<uint16_t>(v38);
        uint16_t v242 = static_cast<uint16_t>(v28);
        TEXTRACT(v239, v207, v241, v242);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        // pto: %9
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v243 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v28, v30);
        // pto: %9
        ;
        uint64_t v244 = (uint64_t) v25;
        TASSIGN(v243, v244);
        uint16_t v245 = static_cast<uint16_t>(v28);
        uint16_t v246 = static_cast<uint16_t>(v38);
        TEXTRACT(v243, v220, v245, v246);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v187, v187, v231, v235);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        TMATMUL_ACC(v187, v187, v239, v243);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      // pto: %67
      ;
      int64_t v247 = v161 < v38 ? v38 : v161;
      // pto: %68
      ;
      const int64_t v248 = 0;
      // pto: %68
      ;
      __gm__ int32_t* v249 = PTOAS__GLOBAL_TENSOR_DATA(v65);
      // pto: %68
      ;
      const int64_t v250 = 1;
      // pto: %68
      ;
      const int64_t v251 = 1;
      // pto: %68
      ;
      const int64_t v252 = 1;
      // pto: %68
      ;
      int64_t v253 = v163 * v35;
      // pto: %68
      ;
      int64_t v254 = v252 * v253;
      // pto: %68
      ;
      pto::Shape<1, 1, 1, -1, 128> v255 = pto::Shape<1, 1, 1, -1, 128>(v250, v251, v252, v163, v30);
      // pto: %68
      ;
      pto::Stride<-1, -1, -1, -1, -1> v256 = pto::Stride<-1, -1, -1, -1, -1>(v251 * v254, v254, v253, v35, v26);
      // pto: %68
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v257 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v249 + (v248 + v166 * v35 + v247 * v26), v255, v256);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      TSTORE(v257, v187);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
    };
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %70
  int64_t v258 = (int64_t) ((uint64_t) v77 + (uint64_t) v44);
  // pto: %71
  int64_t v259 = v258 < v38 ? v38 : v258;
  // pto: %signals_v1__ssa_v0_signal_pview
  __gm__ int32_t* v260 = PTOAS__GLOBAL_TENSOR_DATA(v75);
  // pto: %signals_v1__ssa_v0_signal_pview
  const int64_t v261 = 0;
  // pto: %signals_v1__ssa_v0_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v262 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals_v1__ssa_v0_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v263 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals_v1__ssa_v0_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v264 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v260 + (v261 + v259), v262, v263);
  pto::comm::NotifyOp v265 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v264, v85, v265);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void vector_tail(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ bfloat16_t* v6, __gm__ int8_t* v7, __gm__ float* v8, __gm__ bfloat16_t* v9, __gm__ bfloat16_t* v10, __gm__ float* v11, __gm__ float* v12, __gm__ bfloat16_t* v13, __gm__ float* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21, int32_t v22) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v23 = 0;
  // pto: %c32768_i64
  const int64_t v24 = 32768;
  // pto: %c65536_i64
  const int64_t v25 = 65536;
  // pto: %c65568_i64
  const int64_t v26 = 65568;
  // pto: %c32_i64
  const int64_t v27 = 32;
  // pto: %c64_i64
  const int64_t v28 = 64;
  // pto: %c49152_i64
  const int64_t v29 = 49152;
  // pto: %c67584_i64
  const int64_t v30 = 67584;
  // pto: %c16384_i64
  const int64_t v31 = 16384;
  // pto: %c81920_i64
  const int64_t v32 = 81920;
  // pto: %c98304_i64
  const int64_t v33 = 98304;
  // pto: %c114688_i64
  const int64_t v34 = 114688;
  // pto: %c122880_i64
  const int64_t v35 = 122880;
  // pto: %c1_index
  const int64_t v36 = 1;
  // pto: %c8_index
  const int64_t v37 = 8;
  // pto: %c16_index
  const int64_t v38 = 16;
  // pto: %c128_index
  const int64_t v39 = 128;
  // pto: %c512_index
  const int64_t v40 = 512;
  // pto: %c4096_index
  const int64_t v41 = 4096;
  // pto: %c8192_index
  const int64_t v42 = 8192;
  // pto: %c16384_index
  const int64_t v43 = 16384;
  // pto: %c4_index
  const int64_t v44 = 4;
  // pto: %c55296_index
  const int64_t v45 = 55296;
  // pto: %c2_index
  const int64_t v46 = 2;
  // pto: %c24_index
  const int64_t v47 = 24;
  // pto: %c0_index
  const int64_t v48 = 0;
  // pto: %c15_index
  const int64_t v49 = 15;
  // pto: %c48_index
  const int64_t v50 = 48;
  // pto: %c1024_index
  const int64_t v51 = 1024;
  // pto: %c18432_index
  const int64_t v52 = 18432;
  // pto: %c7_index
  const int64_t v53 = 7;
  // pto: %c21504_index
  const int64_t v54 = 21504;
  // pto: %cst_40
  const float v55 = 0.00787401571f;
  // pto: %cst_41
  const float v56 = 0.0f;
  // pto: %cst_42
  const float v57 = 1.0f;
  // pto: %cst_43
  const float v58 = 127.0f;
  // pto: %c27648_index
  const int64_t v59 = 27648;
  // pto: %c36864_index
  const int64_t v60 = 36864;
  // pto: %c46080_index
  const int64_t v61 = 46080;
  // pto: %c72_index
  const int64_t v62 = 72;
  // pto: %c3_index
  const int64_t v63 = 3;
  // pto: %c12_index
  const int64_t v64 = 12;
  // pto: %c5_index
  const int64_t v65 = 5;
  // pto: %c9_index
  const int64_t v66 = 9;
  // pto: %c13_index
  const int64_t v67 = 13;
  // pto: %c6_index
  const int64_t v68 = 6;
  // pto: %c10_index
  const int64_t v69 = 10;
  // pto: %c14_index
  const int64_t v70 = 14;
  // pto: %c11_index
  const int64_t v71 = 11;
  // pto: %c12288_index
  const int64_t v72 = 12288;
  // pto: %cn1_index
  const int64_t v73 = -1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v74 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v78 = v41 * v36;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v79 = v77 * v78;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v80 = v76 * v79;
  // pto: %wo_b_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v81 = pto::Shape<1, 1, 1, 1, -1>(v74, v75, v76, v77, v41);
  // pto: %wo_b_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v82 = pto::Stride<-1, -1, -1, -1, -1>(v75 * v80, v80, v79, v78, v36);
  // pto: %wo_b_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v83 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v81, v82);
  // pto: %projected__ssa_v3_view
  const int64_t v84 = 1;
  // pto: %projected__ssa_v3_view
  const int64_t v85 = 1;
  // pto: %projected__ssa_v3_view
  const int64_t v86 = 1;
  // pto: %projected__ssa_v3_view
  int64_t v87 = (int64_t) v17;
  // pto: %projected__ssa_v3_view
  int64_t v88 = v87 * v42;
  // pto: %projected__ssa_v3_view
  int64_t v89 = v86 * v88;
  // pto: %projected__ssa_v3_view
  pto::Shape<1, 1, 1, -1, -1> v90 = pto::Shape<1, 1, 1, -1, -1>(v84, v85, v86, v87, v42);
  // pto: %projected__ssa_v3_view
  pto::Stride<-1, -1, -1, -1, -1> v91 = pto::Stride<-1, -1, -1, -1, -1>(v85 * v89, v89, v88, v42, v36);
  // pto: %projected__ssa_v3_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v92 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v90, v91);
  // pto: %quantized__ssa_v3_view
  const int64_t v93 = 1;
  // pto: %quantized__ssa_v3_view
  const int64_t v94 = 1;
  // pto: %quantized__ssa_v3_view
  const int64_t v95 = 1;
  // pto: %quantized__ssa_v3_view
  int64_t v96 = (int64_t) v17;
  // pto: %quantized__ssa_v3_view
  int64_t v97 = v96 * v42;
  // pto: %quantized__ssa_v3_view
  int64_t v98 = v95 * v97;
  // pto: %quantized__ssa_v3_view
  pto::Shape<1, 1, 1, -1, -1> v99 = pto::Shape<1, 1, 1, -1, -1>(v93, v94, v95, v96, v42);
  // pto: %quantized__ssa_v3_view
  pto::Stride<-1, -1, -1, -1, -1> v100 = pto::Stride<-1, -1, -1, -1, -1>(v94 * v98, v98, v97, v42, v36);
  // pto: %quantized__ssa_v3_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v101 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v99, v100);
  // pto: %token_scale__ssa_v3_view
  const int64_t v102 = 1;
  // pto: %token_scale__ssa_v3_view
  const int64_t v103 = 1;
  // pto: %token_scale__ssa_v3_view
  const int64_t v104 = 1;
  // pto: %token_scale__ssa_v3_view
  int64_t v105 = (int64_t) v17;
  // pto: %token_scale__ssa_v3_view
  int64_t v106 = v105 * v36;
  // pto: %token_scale__ssa_v3_view
  int64_t v107 = v104 * v106;
  // pto: %token_scale__ssa_v3_view
  pto::Shape<1, 1, 1, -1, -1> v108 = pto::Shape<1, 1, 1, -1, -1>(v102, v103, v104, v105, v36);
  // pto: %token_scale__ssa_v3_view
  pto::Stride<-1, -1, -1, -1, -1> v109 = pto::Stride<-1, -1, -1, -1, -1>(v103 * v107, v107, v106, v36, (int64_t) v17);
  // pto: %token_scale__ssa_v3_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v110 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v8, v108, v109);
  // pto: %attended__ssa_v3_view
  const int64_t v111 = 1;
  // pto: %attended__ssa_v3_view
  const int64_t v112 = 1;
  // pto: %attended__ssa_v3_view
  const int64_t v113 = 1;
  // pto: %attended__ssa_v3_view
  int64_t v114 = (int64_t) v17;
  // pto: %attended__ssa_v3_view
  int64_t v115 = v114 * v41;
  // pto: %attended__ssa_v3_view
  int64_t v116 = v113 * v115;
  // pto: %attended__ssa_v3_view
  pto::Shape<1, 1, 1, -1, -1> v117 = pto::Shape<1, 1, 1, -1, -1>(v111, v112, v113, v114, v41);
  // pto: %attended__ssa_v3_view
  pto::Stride<-1, -1, -1, -1, -1> v118 = pto::Stride<-1, -1, -1, -1, -1>(v112 * v116, v116, v115, v41, v36);
  // pto: %attended__ssa_v3_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v119 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v117, v118);
  // pto: %residual__ssa_v0_view
  const int64_t v120 = 1;
  // pto: %residual__ssa_v0_view
  const int64_t v121 = 1;
  // pto: %residual__ssa_v0_view
  const int64_t v122 = 1;
  // pto: %residual__ssa_v0_view
  int64_t v123 = (int64_t) v17;
  // pto: %residual__ssa_v0_view
  int64_t v124 = v123 * v43;
  // pto: %residual__ssa_v0_view
  int64_t v125 = v122 * v124;
  // pto: %residual__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v126 = pto::Shape<1, 1, 1, -1, -1>(v120, v121, v122, v123, v43);
  // pto: %residual__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v127 = pto::Stride<-1, -1, -1, -1, -1>(v121 * v125, v125, v124, v43, v36);
  // pto: %residual__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v128 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v10, v126, v127);
  // pto: %output__ssa_v3_view
  const int64_t v129 = 1;
  // pto: %output__ssa_v3_view
  const int64_t v130 = 1;
  // pto: %output__ssa_v3_view
  const int64_t v131 = 1;
  // pto: %output__ssa_v3_view
  int64_t v132 = (int64_t) v17;
  // pto: %output__ssa_v3_view
  int64_t v133 = v132 * v43;
  // pto: %output__ssa_v3_view
  int64_t v134 = v131 * v133;
  // pto: %output__ssa_v3_view
  pto::Shape<1, 1, 1, -1, -1> v135 = pto::Shape<1, 1, 1, -1, -1>(v129, v130, v131, v132, v43);
  // pto: %output__ssa_v3_view
  pto::Stride<-1, -1, -1, -1, -1> v136 = pto::Stride<-1, -1, -1, -1, -1>(v130 * v134, v134, v133, v43, v36);
  // pto: %output__ssa_v3_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v137 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v135, v136);
  // pto: %accum__ssa_v3_view
  const int64_t v138 = 1;
  // pto: %accum__ssa_v3_view
  const int64_t v139 = 1;
  // pto: %accum__ssa_v3_view
  const int64_t v140 = 1;
  // pto: %accum__ssa_v3_view
  int64_t v141 = (int64_t) v18;
  // pto: %accum__ssa_v3_view
  int64_t v142 = v141 * v42;
  // pto: %accum__ssa_v3_view
  int64_t v143 = v140 * v142;
  // pto: %accum__ssa_v3_view
  pto::Shape<1, 1, 1, -1, -1> v144 = pto::Shape<1, 1, 1, -1, -1>(v138, v139, v140, v141, v42);
  // pto: %accum__ssa_v3_view
  pto::Stride<-1, -1, -1, -1, -1> v145 = pto::Stride<-1, -1, -1, -1, -1>(v139 * v143, v143, v142, v42, v36);
  // pto: %accum__ssa_v3_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v146 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v144, v145);
  // pto: %integer_accum__ssa_v3_view
  const int64_t v147 = 1;
  // pto: %integer_accum__ssa_v3_view
  const int64_t v148 = 1;
  // pto: %integer_accum__ssa_v3_view
  const int64_t v149 = 1;
  // pto: %integer_accum__ssa_v3_view
  int64_t v150 = (int64_t) v19;
  // pto: %integer_accum__ssa_v3_view
  int64_t v151 = v150 * v41;
  // pto: %integer_accum__ssa_v3_view
  int64_t v152 = v149 * v151;
  // pto: %integer_accum__ssa_v3_view
  pto::Shape<1, 1, 1, -1, -1> v153 = pto::Shape<1, 1, 1, -1, -1>(v147, v148, v149, v150, v41);
  // pto: %integer_accum__ssa_v3_view
  pto::Stride<-1, -1, -1, -1, -1> v154 = pto::Stride<-1, -1, -1, -1, -1>(v148 * v152, v152, v151, v41, v36);
  // pto: %integer_accum__ssa_v3_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v155 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v153, v154);
  // pto: %signals__ssa_v3_view
  const int64_t v156 = 1;
  // pto: %signals__ssa_v3_view
  const int64_t v157 = 1;
  // pto: %signals__ssa_v3_view
  const int64_t v158 = 1;
  // pto: %signals__ssa_v3_view
  const int64_t v159 = 1;
  // pto: %signals__ssa_v3_view
  int64_t v160 = v45 * v36;
  // pto: %signals__ssa_v3_view
  int64_t v161 = v159 * v160;
  // pto: %signals__ssa_v3_view
  int64_t v162 = v158 * v161;
  // pto: %signals__ssa_v3_view
  pto::Shape<1, 1, 1, 1, -1> v163 = pto::Shape<1, 1, 1, 1, -1>(v156, v157, v158, v159, v45);
  // pto: %signals__ssa_v3_view
  pto::Stride<-1, -1, -1, -1, -1> v164 = pto::Stride<-1, -1, -1, -1, -1>(v157 * v162, v162, v161, v160, v36);
  // pto: %signals__ssa_v3_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v165 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v163, v164);
  // pto: %t__tmp_v0, %145, %146, %t__tmp_v1
  int64_t v166 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v20) * (uint64_t) v46) + (uint64_t) ((int64_t) v22));
  // pto: %147, %148
  int64_t v167 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v166 + (uint64_t) v47) * (uint64_t) v39);
  // pto: %149
  int64_t v168 = v167 < v48 ? v48 : v167;
  // pto: %signals__ssa_v3_pview
  __gm__ int32_t* v169 = PTOAS__GLOBAL_TENSOR_DATA(v165);
  // pto: %signals__ssa_v3_pview
  const int64_t v170 = 0;
  // pto: %signals__ssa_v3_pview
  pto::Shape<1, 1, 1, 1, 1> v171 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v3_pview
  pto::Stride<1, 1, 1, 1, 1> v172 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v3_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v173 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v169 + (v170 + v168), v171, v172);
  __gm__ int32_t* v174 = PTOAS__GLOBAL_TENSOR_DATA(v173);
  PTOAS__DCCI_SINGLE_CACHE_LINE(v174);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  // pto: %generation_inline6__tile
  int32_t v175 = (v16)[v167];
  // pto: %150, %151, %152
  int64_t v176 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v17 + (uint64_t) v49) / v38) * (uint64_t) v37);
  for (int64_t v177 = v166; v177 < v176; v177 += v50) {
    // pto: %153, %154
    ;
    int64_t v178 = (int64_t) ((uint64_t) (v177 / v37) * (uint64_t) v38);
    // pto: %155
    ;
    int64_t v179 = v177 % v37;
    // pto: %156, %157, %158
    ;
    int64_t v180 = v179 < v48 ? (int64_t) ((uint64_t) v179 + (uint64_t) v37) : v179;
    // pto: %159
    ;
    int64_t v181 = (int64_t) ((uint64_t) v180 * (uint64_t) v51);
    // pto: %160
    ;
    int64_t v182 = (int64_t) ((uint64_t) v17 - (uint64_t) v178);
    // pto: %161
    ;
    int64_t v183 = v182 < v38 ? v182 : v38;
    // pto: %oa_value__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v184 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v183, v51);
    // pto: %oa_value__ssa_v0
    ;
    uint64_t v185 = (uint64_t) v23;
    TASSIGN(v184, v185);
    // pto: %162
    ;
    int64_t v186 = v178 < v48 ? v48 : v178;
    // pto: %163
    ;
    int64_t v187 = v181 < v48 ? v48 : v181;
    // pto: %accum__ssa_v3_pview
    ;
    const int64_t v188 = 0;
    // pto: %accum__ssa_v3_pview
    ;
    __gm__ float* v189 = PTOAS__GLOBAL_TENSOR_DATA(v146);
    // pto: %accum__ssa_v3_pview
    ;
    const int64_t v190 = 1;
    // pto: %accum__ssa_v3_pview
    ;
    const int64_t v191 = 1;
    // pto: %accum__ssa_v3_pview
    ;
    const int64_t v192 = 1;
    // pto: %accum__ssa_v3_pview
    ;
    int64_t v193 = v183 * v42;
    // pto: %accum__ssa_v3_pview
    ;
    int64_t v194 = v192 * v193;
    // pto: %accum__ssa_v3_pview
    ;
    pto::Shape<1, 1, 1, -1, 1024> v195 = pto::Shape<1, 1, 1, -1, 1024>(v190, v191, v192, v183, v51);
    // pto: %accum__ssa_v3_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v196 = pto::Stride<-1, -1, -1, -1, -1>(v191 * v194, v194, v193, v42, v36);
    // pto: %accum__ssa_v3_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v197 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v189 + (v188 + v186 * v42 + v187 * v36), v195, v196);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v184, v197);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %t__tmp_v2
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v198 = Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v183, v51);
    // pto: %t__tmp_v2
    ;
    uint64_t v199 = (uint64_t) v23;
    TASSIGN(v198, v199);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v200 = RoundMode::CAST_RINT;
    SaturationMode v201 = SaturationMode::ON;
    TCVT(v198, v184, v200, v201);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %projected__ssa_v3_pview
    ;
    const int64_t v202 = 0;
    // pto: %projected__ssa_v3_pview
    ;
    __gm__ bfloat16_t* v203 = PTOAS__GLOBAL_TENSOR_DATA(v92);
    // pto: %projected__ssa_v3_pview
    ;
    const int64_t v204 = 1;
    // pto: %projected__ssa_v3_pview
    ;
    const int64_t v205 = 1;
    // pto: %projected__ssa_v3_pview
    ;
    const int64_t v206 = 1;
    // pto: %projected__ssa_v3_pview
    ;
    int64_t v207 = v183 * v42;
    // pto: %projected__ssa_v3_pview
    ;
    int64_t v208 = v206 * v207;
    // pto: %projected__ssa_v3_pview
    ;
    pto::Shape<1, 1, 1, -1, 1024> v209 = pto::Shape<1, 1, 1, -1, 1024>(v204, v205, v206, v183, v51);
    // pto: %projected__ssa_v3_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v210 = pto::Stride<-1, -1, -1, -1, -1>(v205 * v208, v208, v207, v42, v36);
    // pto: %projected__ssa_v3_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v211 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v203 + (v202 + v186 * v42 + v187 * v36), v209, v210);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v211, v198);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %167
  int64_t v212 = (int64_t) ((uint64_t) v167 + (uint64_t) v52);
  // pto: %168
  int64_t v213 = v212 < v48 ? v48 : v212;
  // pto: %signals__ssa_v1_signal_pview
  __gm__ int32_t* v214 = PTOAS__GLOBAL_TENSOR_DATA(v165);
  // pto: %signals__ssa_v1_signal_pview
  const int64_t v215 = 0;
  // pto: %signals__ssa_v1_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v216 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v217 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v218 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v214 + (v215 + v213), v216, v217);
  pto::comm::NotifyOp v219 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v218, v175, v219);
  // pto: %169, %170
  int64_t v220 = (int64_t) ((uint64_t) v17 + (uint64_t) v53) / v37;
  // pto: %171
  if (v166 < v220) {
    for (int64_t v221 = v48; v221 < v37; v221 += v36) {
      // pto: %172, %173, %174, %175
      ;
      int64_t v222 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) (v166 / v46) * (uint64_t) v37) + (uint64_t) v221) % v50;
      // pto: %176, %177, %178
      ;
      int64_t v223 = v222 < v48 ? (int64_t) ((uint64_t) v222 + (uint64_t) v50) : v222;
      // pto: %179, %180
      ;
      int64_t v224 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v223 * (uint64_t) v39) + (uint64_t) v54);
      // pto: %181
      ;
      int64_t v225 = v224 < v48 ? v48 : v224;
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      __gm__ int32_t* v226 = PTOAS__GLOBAL_TENSOR_DATA(v165);
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      const int64_t v227 = 0;
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      pto::Shape<1, 1, 1, 1, 1> v228 = pto::Shape<1, 1, 1, 1, 1>();
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      pto::Stride<1, 1, 1, 1, 1> v229 = pto::Stride<1, 1, 1, 1, 1>();
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v230 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v226 + (v227 + v225), v228, v229);
      pto::comm::WaitCmp v231 = pto::comm::WaitCmp::GE;
      pto::comm::TWAIT(v230, v175, v231);
    };
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  for (int64_t v232 = v166; v232 < v220; v232 += v50) {
    // pto: %183
    ;
    int64_t v233 = (int64_t) ((uint64_t) v232 * (uint64_t) v37);
    // pto: %184
    ;
    int64_t v234 = (int64_t) ((uint64_t) v17 - (uint64_t) v233);
    // pto: %185
    ;
    int64_t v235 = v234 < v37 ? v234 : v37;
    // pto: %first_quant__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v236 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v235, v51);
    // pto: %first_quant__ssa_v0
    ;
    uint64_t v237 = (uint64_t) v24;
    TASSIGN(v236, v237);
    // pto: %186
    ;
    int64_t v238 = v233 < v48 ? v48 : v233;
    // pto: %187
    ;
    const int64_t v239 = 0;
    // pto: %187
    ;
    __gm__ bfloat16_t* v240 = PTOAS__GLOBAL_TENSOR_DATA(v92);
    // pto: %187
    ;
    const int64_t v241 = 1;
    // pto: %187
    ;
    const int64_t v242 = 1;
    // pto: %187
    ;
    const int64_t v243 = 1;
    // pto: %187
    ;
    int64_t v244 = v235 * v42;
    // pto: %187
    ;
    int64_t v245 = v243 * v244;
    // pto: %187
    ;
    pto::Shape<1, 1, 1, -1, 1024> v246 = pto::Shape<1, 1, 1, -1, 1024>(v241, v242, v243, v235, v51);
    // pto: %187
    ;
    pto::Stride<-1, -1, -1, -1, -1> v247 = pto::Stride<-1, -1, -1, -1, -1>(v242 * v245, v245, v244, v42, v36);
    // pto: %187
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v248 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v240 + (v239 + v238 * v42 + v48 * v36), v246, v247);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v236, v248);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %t__tmp_v3
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v249 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v235, v51);
    // pto: %t__tmp_v3
    ;
    uint64_t v250 = (uint64_t) v23;
    TASSIGN(v249, v250);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    pipe_barrier(PIPE_V);
    RoundMode v251 = RoundMode::CAST_ROUND;
    SaturationMode v252 = SaturationMode::ON;
    TCVT(v249, v236, v251, v252);
    // pto: %first_abs__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v253 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v235, v51);
    // pto: %first_abs__ssa_v0
    ;
    uint64_t v254 = (uint64_t) v23;
    TASSIGN(v253, v254);
    pipe_barrier(PIPE_V);
    TABS(v253, v249);
    // pto: %t__tmp_v4
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v255 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v51);
    // pto: %t__tmp_v4
    ;
    uint64_t v256 = (uint64_t) v24;
    TASSIGN(v255, v256);
    // pto: %amax__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v257 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v235, v36);
    // pto: %amax__ssa_v0
    ;
    uint64_t v258 = (uint64_t) v25;
    TASSIGN(v257, v258);
    pipe_barrier(PIPE_V);
    TROWMAX(v257, v253, v255);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    for (int64_t v259 = v36; v259 < v37; v259 += v36) {
      // pto: %q_bf16__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v260 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v235, v51);
      // pto: %q_bf16__ssa_v0
      ;
      uint64_t v261 = (uint64_t) v24;
      TASSIGN(v260, v261);
      // pto: %189
      ;
      int64_t v262 = (int64_t) ((uint64_t) v259 * (uint64_t) v51);
      // pto: %190
      ;
      int64_t v263 = v262 < v48 ? v48 : v262;
      // pto: %191
      ;
      const int64_t v264 = 0;
      // pto: %191
      ;
      __gm__ bfloat16_t* v265 = PTOAS__GLOBAL_TENSOR_DATA(v92);
      // pto: %191
      ;
      const int64_t v266 = 1;
      // pto: %191
      ;
      const int64_t v267 = 1;
      // pto: %191
      ;
      const int64_t v268 = 1;
      // pto: %191
      ;
      int64_t v269 = v235 * v42;
      // pto: %191
      ;
      int64_t v270 = v268 * v269;
      // pto: %191
      ;
      pto::Shape<1, 1, 1, -1, 1024> v271 = pto::Shape<1, 1, 1, -1, 1024>(v266, v267, v268, v235, v51);
      // pto: %191
      ;
      pto::Stride<-1, -1, -1, -1, -1> v272 = pto::Stride<-1, -1, -1, -1, -1>(v267 * v270, v270, v269, v42, v36);
      // pto: %191
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v273 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v265 + (v264 + v238 * v42 + v263 * v36), v271, v272);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      TLOAD(v260, v273);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %q_fp32__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v274 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v235, v51);
      // pto: %q_fp32__ssa_v0
      ;
      uint64_t v275 = (uint64_t) v23;
      TASSIGN(v274, v275);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      pipe_barrier(PIPE_V);
      RoundMode v276 = RoundMode::CAST_ROUND;
      SaturationMode v277 = SaturationMode::ON;
      TCVT(v274, v260, v276, v277);
      // pto: %t__tmp_v5
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v278 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v235, v51);
      // pto: %t__tmp_v5
      ;
      uint64_t v279 = (uint64_t) v23;
      TASSIGN(v278, v279);
      pipe_barrier(PIPE_V);
      TABS(v278, v274);
      // pto: %t__tmp_v6
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v280 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v51);
      // pto: %t__tmp_v6
      ;
      uint64_t v281 = (uint64_t) v24;
      TASSIGN(v280, v281);
      // pto: %t__tmp_v7
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v282 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v235, v36);
      // pto: %t__tmp_v7
      ;
      uint64_t v283 = (uint64_t) v26;
      TASSIGN(v282, v283);
      pipe_barrier(PIPE_V);
      TROWMAX(v282, v278, v280);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      // pto: %amax__rm_a0_tmp_v0
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v284 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v235);
      // pto: %amax__rm_a0_tmp_v0
      ;
      uint64_t v285 = (uint64_t) v25;
      TASSIGN(v284, v285);
      // pto: %amax__rm_a1_tmp_v1
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v286 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v235);
      // pto: %amax__rm_a1_tmp_v1
      ;
      uint64_t v287 = (uint64_t) v26;
      TASSIGN(v286, v287);
      // pto: %amax__row_major_tmp_v2
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v288 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v235);
      // pto: %amax__row_major_tmp_v2
      ;
      uint64_t v289 = (uint64_t) v23;
      TASSIGN(v288, v289);
      pipe_barrier(PIPE_V);
      TMAX(v288, v284, v286);
      // pto: %amax__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v290 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v235, v36);
      // pto: %amax__ssa_v3
      ;
      uint64_t v291 = (uint64_t) v23;
      TASSIGN(v290, v291);
      // pto: %amax__ssa_v3_mv
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v292 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v235, v36);
      // pto: %amax__ssa_v3_mv
      ;
      uint64_t v293 = (uint64_t) v25;
      TASSIGN(v292, v293);
      pipe_barrier(PIPE_V);
      TMOV(v292, v290);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    // pto: %dequant__rm_a0_tmp_v3
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v294 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v235);
    // pto: %dequant__rm_a0_tmp_v3
    ;
    uint64_t v295 = (uint64_t) v25;
    TASSIGN(v294, v295);
    // pto: %dequant__row_major_tmp_v4
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v296 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v235);
    // pto: %dequant__row_major_tmp_v4
    ;
    uint64_t v297 = (uint64_t) v23;
    TASSIGN(v296, v297);
    pipe_barrier(PIPE_V);
    TMULS(v296, v294, v55);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %dequant__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v235, v36);
    // pto: %dequant__ssa_v0
    ;
    uint64_t v299 = (uint64_t) v23;
    TASSIGN(v298, v299);
    // pto: %denominator__rm_a0_tmp_v5
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v300 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v235);
    // pto: %denominator__rm_a0_tmp_v5
    ;
    uint64_t v301 = (uint64_t) v25;
    TASSIGN(v300, v301);
    // pto: %denominator__row_major_tmp_v6
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v302 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v235);
    // pto: %denominator__row_major_tmp_v6
    ;
    uint64_t v303 = (uint64_t) v27;
    TASSIGN(v302, v303);
    TADDS(v302, v300, v56);
    set_flag(PIPE_V, PIPE_S, EVENT_ID0);
    // pto: %denominator__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v304 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v235, v36);
    // pto: %denominator__ssa_v0
    ;
    uint64_t v305 = (uint64_t) v27;
    TASSIGN(v304, v305);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
    for (int64_t v306 = v48; v306 < v235; v306 += v36) {
      // pto: %magnitude__ssa_v0
      ;
      float v307 = v304.GetValue(v306);
      // pto: %192
      ;
      bool v308 = v307 != v307 || v56 != v56;
      // pto: %192
      ;
      if ((v307 == v307 && v56 == v56) && v307 == v56) {
        v304.SetValue(v306, v57);
      };
    };
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
    // pto: %t__rm_a0_tmp_v7
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v235);
    // pto: %t__rm_a0_tmp_v7
    ;
    uint64_t v310 = (uint64_t) v25;
    TASSIGN(v309, v310);
    // pto: %t__row_major_tmp_v8
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v311 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v235);
    // pto: %t__row_major_tmp_v8
    ;
    uint64_t v312 = (uint64_t) v28;
    TASSIGN(v311, v312);
    TMULS(v311, v309, v56);
    // pto: %t__tmp_v8
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v235, v36);
    // pto: %t__tmp_v8
    ;
    uint64_t v314 = (uint64_t) v28;
    TASSIGN(v313, v314);
    // pto: %t__rm_a0_tmp_v9
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v235);
    // pto: %t__rm_a0_tmp_v9
    ;
    uint64_t v316 = (uint64_t) v28;
    TASSIGN(v315, v316);
    // pto: %t__row_major_tmp_v10
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v317 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v235);
    // pto: %t__row_major_tmp_v10
    ;
    uint64_t v318 = (uint64_t) v28;
    TASSIGN(v317, v318);
    pipe_barrier(PIPE_V);
    TADDS(v317, v315, v58);
    // pto: %t__tmp_v9
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v319 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v235, v36);
    // pto: %t__tmp_v9
    ;
    uint64_t v320 = (uint64_t) v28;
    TASSIGN(v319, v320);
    // pto: %multiplier__rm_a0_tmp_v11
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v321 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v235);
    // pto: %multiplier__rm_a0_tmp_v11
    ;
    uint64_t v322 = (uint64_t) v28;
    TASSIGN(v321, v322);
    // pto: %multiplier__rm_a1_tmp_v12
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v323 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v235);
    // pto: %multiplier__rm_a1_tmp_v12
    ;
    uint64_t v324 = (uint64_t) v27;
    TASSIGN(v323, v324);
    // pto: %multiplier__row_major_tmp_v13
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v325 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v235);
    // pto: %multiplier__row_major_tmp_v13
    ;
    uint64_t v326 = (uint64_t) v29;
    TASSIGN(v325, v326);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    TDIV(v325, v321, v323);
    // pto: %multiplier__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v327 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v235, v36);
    // pto: %multiplier__ssa_v0
    ;
    uint64_t v328 = (uint64_t) v29;
    TASSIGN(v327, v328);
    v298.SetValidShape(v235, v36);
    // pto: %token_scale__ssa_v3_pview
    ;
    int64_t v329 = (int64_t) v17;
    // pto: %token_scale__ssa_v3_pview
    ;
    const int64_t v330 = 0;
    // pto: %token_scale__ssa_v3_pview
    ;
    __gm__ float* v331 = PTOAS__GLOBAL_TENSOR_DATA(v110);
    // pto: %token_scale__ssa_v3_pview
    ;
    const int64_t v332 = 1;
    // pto: %token_scale__ssa_v3_pview
    ;
    const int64_t v333 = 1;
    // pto: %token_scale__ssa_v3_pview
    ;
    const int64_t v334 = 1;
    // pto: %token_scale__ssa_v3_pview
    ;
    int64_t v335 = v235 * v36;
    // pto: %token_scale__ssa_v3_pview
    ;
    int64_t v336 = v334 * v335;
    // pto: %token_scale__ssa_v3_pview
    ;
    pto::Shape<1, 1, 1, -1, 1> v337 = pto::Shape<1, 1, 1, -1, 1>(v332, v333, v334, v235, v36);
    // pto: %token_scale__ssa_v3_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v338 = pto::Stride<-1, -1, -1, -1, -1>(v333 * v336, v336, v335, v36, v329);
    // pto: %token_scale__ssa_v3_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v339 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v331 + (v330 + v238 * v36 + v48 * v329), v337, v338);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    TSTORE(v339, v298);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    for (int64_t v340 = v48; v340 < v37; v340 += v36) {
      // pto: %197
      ;
      int64_t v341 = (int64_t) ((uint64_t) v340 * (uint64_t) v51);
      // pto: %quant_bf16__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v342 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v235, v51);
      // pto: %quant_bf16__ssa_v0
      ;
      uint64_t v343 = (uint64_t) v24;
      TASSIGN(v342, v343);
      // pto: %199
      ;
      int64_t v344 = v341 < v48 ? v48 : v341;
      // pto: %200
      ;
      const int64_t v345 = 0;
      // pto: %200
      ;
      __gm__ bfloat16_t* v346 = PTOAS__GLOBAL_TENSOR_DATA(v92);
      // pto: %200
      ;
      const int64_t v347 = 1;
      // pto: %200
      ;
      const int64_t v348 = 1;
      // pto: %200
      ;
      const int64_t v349 = 1;
      // pto: %200
      ;
      int64_t v350 = v235 * v42;
      // pto: %200
      ;
      int64_t v351 = v349 * v350;
      // pto: %200
      ;
      pto::Shape<1, 1, 1, -1, 1024> v352 = pto::Shape<1, 1, 1, -1, 1024>(v347, v348, v349, v235, v51);
      // pto: %200
      ;
      pto::Stride<-1, -1, -1, -1, -1> v353 = pto::Stride<-1, -1, -1, -1, -1>(v348 * v351, v351, v350, v42, v36);
      // pto: %200
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v354 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v346 + (v345 + v238 * v42 + v344 * v36), v352, v353);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      TLOAD(v342, v354);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %t__tmp_v11
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v355 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v235, v51);
      // pto: %t__tmp_v11
      ;
      uint64_t v356 = (uint64_t) v23;
      TASSIGN(v355, v356);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      RoundMode v357 = RoundMode::CAST_ROUND;
      SaturationMode v358 = SaturationMode::ON;
      TCVT(v355, v342, v357, v358);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      // pto: %quant_scaled__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v359 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v235, v51);
      // pto: %quant_scaled__ssa_v0
      ;
      uint64_t v360 = (uint64_t) v23;
      TASSIGN(v359, v360);
      pipe_barrier(PIPE_V);
      TROWEXPANDMUL(v359, v355, v327);
      // pto: %integer__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v361 = Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v235, v51);
      // pto: %integer__ssa_v0
      ;
      uint64_t v362 = (uint64_t) v23;
      TASSIGN(v361, v362);
      pipe_barrier(PIPE_V);
      RoundMode v363 = RoundMode::CAST_RINT;
      SaturationMode v364 = SaturationMode::ON;
      TCVT(v361, v359, v363, v364);
      // pto: %half__ssa_v0
      ;
      Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v365 = Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v235, v51);
      // pto: %half__ssa_v0
      ;
      uint64_t v366 = (uint64_t) v23;
      TASSIGN(v365, v366);
      pipe_barrier(PIPE_V);
      RoundMode v367 = RoundMode::CAST_ROUND;
      SaturationMode v368 = SaturationMode::ON;
      TCVT(v365, v361, v367, v368);
      // pto: %result__ssa_v0
      ;
      Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v369 = Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v235, v51);
      // pto: %result__ssa_v0
      ;
      uint64_t v370 = (uint64_t) v23;
      TASSIGN(v369, v370);
      pipe_barrier(PIPE_V);
      RoundMode v371 = RoundMode::CAST_TRUNC;
      SaturationMode v372 = SaturationMode::ON;
      TCVT(v369, v365, v371, v372);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      v369.SetValidShape(v235, v51);
      // pto: %quantized__ssa_v3_pview
      ;
      const int64_t v373 = 0;
      // pto: %quantized__ssa_v3_pview
      ;
      __gm__ int8_t* v374 = PTOAS__GLOBAL_TENSOR_DATA(v101);
      // pto: %quantized__ssa_v3_pview
      ;
      const int64_t v375 = 1;
      // pto: %quantized__ssa_v3_pview
      ;
      const int64_t v376 = 1;
      // pto: %quantized__ssa_v3_pview
      ;
      const int64_t v377 = 1;
      // pto: %quantized__ssa_v3_pview
      ;
      int64_t v378 = v235 * v42;
      // pto: %quantized__ssa_v3_pview
      ;
      int64_t v379 = v377 * v378;
      // pto: %quantized__ssa_v3_pview
      ;
      pto::Shape<1, 1, 1, -1, 1024> v380 = pto::Shape<1, 1, 1, -1, 1024>(v375, v376, v377, v235, v51);
      // pto: %quantized__ssa_v3_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v381 = pto::Stride<-1, -1, -1, -1, -1>(v376 * v379, v379, v378, v42, v36);
      // pto: %quantized__ssa_v3_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v382 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v374 + (v373 + v238 * v42 + v344 * v36), v380, v381);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      TSTORE(v382, v369);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %204
  int64_t v383 = (int64_t) ((uint64_t) v167 + (uint64_t) v59);
  // pto: %205
  int64_t v384 = v383 < v48 ? v48 : v383;
  // pto: %206
  __gm__ int32_t* v385 = PTOAS__GLOBAL_TENSOR_DATA(v165);
  // pto: %206
  const int64_t v386 = 0;
  // pto: %206
  pto::Shape<1, 1, 1, 1, 1> v387 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %206
  pto::Stride<1, 1, 1, 1, 1> v388 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %206
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v389 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v385 + (v386 + v384), v387, v388);
  pto::comm::NotifyOp v390 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v389, v175, v390);
  for (int64_t v391 = v48; v391 < v47; v391 += v36) {
    // pto: %207, %208
    ;
    int64_t v392 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v391 * (uint64_t) v39) + (uint64_t) v60);
    // pto: %209
    ;
    int64_t v393 = v392 < v48 ? v48 : v392;
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v394 = PTOAS__GLOBAL_TENSOR_DATA(v165);
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    const int64_t v395 = 0;
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v396 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v397 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v398 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v394 + (v395 + v393), v396, v397);
    pto::comm::WaitCmp v399 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v398, v175, v399);
  }
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  for (int64_t v400 = v166; v400 < v176; v400 += v50) {
    // pto: %212, %213
    ;
    int64_t v401 = (int64_t) ((uint64_t) (v400 / v37) * (uint64_t) v38);
    // pto: %214
    ;
    int64_t v402 = v400 % v37;
    // pto: %215, %216, %217
    ;
    int64_t v403 = v402 < v48 ? (int64_t) ((uint64_t) v402 + (uint64_t) v37) : v402;
    // pto: %218
    ;
    int64_t v404 = (int64_t) ((uint64_t) v403 * (uint64_t) v40);
    // pto: %219
    ;
    int64_t v405 = (int64_t) ((uint64_t) v17 - (uint64_t) v401);
    // pto: %220
    ;
    int64_t v406 = v405 < v38 ? v405 : v38;
    // pto: %ob_integer__ssa_v0
    ;
    Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v407 = Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v406, v40);
    // pto: %ob_integer__ssa_v0
    ;
    uint64_t v408 = (uint64_t) v23;
    TASSIGN(v407, v408);
    // pto: %221
    ;
    int64_t v409 = v401 < v48 ? v48 : v401;
    // pto: %222
    ;
    int64_t v410 = v404 < v48 ? v48 : v404;
    // pto: %integer_accum__ssa_v3_pview
    ;
    const int64_t v411 = 0;
    // pto: %integer_accum__ssa_v3_pview
    ;
    __gm__ int32_t* v412 = PTOAS__GLOBAL_TENSOR_DATA(v155);
    // pto: %integer_accum__ssa_v3_pview
    ;
    const int64_t v413 = 1;
    // pto: %integer_accum__ssa_v3_pview
    ;
    const int64_t v414 = 1;
    // pto: %integer_accum__ssa_v3_pview
    ;
    const int64_t v415 = 1;
    // pto: %integer_accum__ssa_v3_pview
    ;
    int64_t v416 = v406 * v41;
    // pto: %integer_accum__ssa_v3_pview
    ;
    int64_t v417 = v415 * v416;
    // pto: %integer_accum__ssa_v3_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v418 = pto::Shape<1, 1, 1, -1, 512>(v413, v414, v415, v406, v40);
    // pto: %integer_accum__ssa_v3_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v419 = pto::Stride<-1, -1, -1, -1, -1>(v414 * v417, v417, v416, v41, v36);
    // pto: %integer_accum__ssa_v3_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v420 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v412 + (v411 + v409 * v41 + v410 * v36), v418, v419);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    TLOAD(v407, v420);
    // pto: %t__tmp_v13
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v421 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v40);
    // pto: %t__tmp_v13
    ;
    uint64_t v422 = (uint64_t) v25;
    TASSIGN(v421, v422);
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    __gm__ float* v423 = PTOAS__GLOBAL_TENSOR_DATA(v83);
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    const int64_t v424 = 0;
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 512> v425 = pto::Shape<1, 1, 1, 1, 512>();
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    pto::Stride<512, 512, 512, 512, 1> v426 = pto::Stride<512, 512, 512, 512, 1>();
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v427 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v423 + (v424 + v410), v425, v426);
    TLOAD(v421, v427);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    // pto: %channel__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v428 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v40);
    // pto: %channel__ssa_v0
    ;
    uint64_t v429 = (uint64_t) v25;
    TASSIGN(v428, v429);
    // pto: %scale__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v430 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v406, v36);
    // pto: %scale__ssa_v0
    ;
    uint64_t v431 = (uint64_t) v30;
    TASSIGN(v430, v431);
    // pto: %225
    ;
    int64_t v432 = (int64_t) v17;
    // pto: %225
    ;
    const int64_t v433 = 0;
    // pto: %225
    ;
    __gm__ float* v434 = PTOAS__GLOBAL_TENSOR_DATA(v110);
    // pto: %225
    ;
    const int64_t v435 = 1;
    // pto: %225
    ;
    const int64_t v436 = 1;
    // pto: %225
    ;
    const int64_t v437 = 1;
    // pto: %225
    ;
    int64_t v438 = v406 * v36;
    // pto: %225
    ;
    int64_t v439 = v437 * v438;
    // pto: %225
    ;
    pto::Shape<1, 1, 1, -1, 1> v440 = pto::Shape<1, 1, 1, -1, 1>(v435, v436, v437, v406, v36);
    // pto: %225
    ;
    pto::Stride<-1, -1, -1, -1, -1> v441 = pto::Stride<-1, -1, -1, -1, -1>(v436 * v439, v439, v438, v36, v432);
    // pto: %225
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v442 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v434 + (v433 + v409 * v36 + v48 * v432), v440, v441);
    TLOAD(v430, v442);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    // pto: %coefficient_one__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v443 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v40);
    // pto: %coefficient_one__ssa_v0
    ;
    uint64_t v444 = (uint64_t) v24;
    TASSIGN(v443, v444);
    pipe_barrier(PIPE_V);
    TEXPANDS(v443, v57);
    // pto: %coefficient_channel__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v445 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v40);
    // pto: %coefficient_channel__ssa_v0
    ;
    uint64_t v446 = (uint64_t) v24;
    TASSIGN(v445, v446);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    TCOLEXPANDMUL(v445, v443, v428);
    // pto: %coefficient__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v447 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v40);
    // pto: %coefficient__ssa_v0
    ;
    uint64_t v448 = (uint64_t) v24;
    TASSIGN(v447, v448);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    TROWEXPANDMUL(v447, v445, v430);
    // pto: %t__tmp_v14
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v449 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v406, v40);
    // pto: %t__tmp_v14
    ;
    uint64_t v450 = (uint64_t) v23;
    TASSIGN(v449, v450);
    RoundMode v451 = RoundMode::CAST_ROUND;
    SaturationMode v452 = SaturationMode::ON;
    TCVT(v449, v407, v451, v452);
    // pto: %ob_scaled__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v453 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v406, v40);
    // pto: %ob_scaled__ssa_v0
    ;
    uint64_t v454 = (uint64_t) v23;
    TASSIGN(v453, v454);
    pipe_barrier(PIPE_V);
    TMUL(v453, v449, v447);
    // pto: %t__tmp_v15
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v455 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v406, v40);
    // pto: %t__tmp_v15
    ;
    uint64_t v456 = (uint64_t) v23;
    TASSIGN(v455, v456);
    pipe_barrier(PIPE_V);
    RoundMode v457 = RoundMode::CAST_RINT;
    SaturationMode v458 = SaturationMode::ON;
    TCVT(v455, v453, v457, v458);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    // pto: %attended__ssa_v3_pview
    ;
    const int64_t v459 = 0;
    // pto: %attended__ssa_v3_pview
    ;
    __gm__ bfloat16_t* v460 = PTOAS__GLOBAL_TENSOR_DATA(v119);
    // pto: %attended__ssa_v3_pview
    ;
    const int64_t v461 = 1;
    // pto: %attended__ssa_v3_pview
    ;
    const int64_t v462 = 1;
    // pto: %attended__ssa_v3_pview
    ;
    const int64_t v463 = 1;
    // pto: %attended__ssa_v3_pview
    ;
    int64_t v464 = v406 * v41;
    // pto: %attended__ssa_v3_pview
    ;
    int64_t v465 = v463 * v464;
    // pto: %attended__ssa_v3_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v466 = pto::Shape<1, 1, 1, -1, 512>(v461, v462, v463, v406, v40);
    // pto: %attended__ssa_v3_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v467 = pto::Stride<-1, -1, -1, -1, -1>(v462 * v465, v465, v464, v41, v36);
    // pto: %attended__ssa_v3_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v468 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v460 + (v459 + v409 * v41 + v410 * v36), v466, v467);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    TSTORE(v468, v455);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %229
  int64_t v469 = (int64_t) ((uint64_t) v167 + (uint64_t) v61);
  // pto: %230
  int64_t v470 = v469 < v48 ? v48 : v469;
  // pto: %signals_v3__ssa_v0_signal_pview
  __gm__ int32_t* v471 = PTOAS__GLOBAL_TENSOR_DATA(v165);
  // pto: %signals_v3__ssa_v0_signal_pview
  const int64_t v472 = 0;
  // pto: %signals_v3__ssa_v0_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v473 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals_v3__ssa_v0_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v474 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals_v3__ssa_v0_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v475 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v471 + (v472 + v470), v473, v474);
  pto::comm::NotifyOp v476 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v475, v175, v476);
  for (int64_t v477 = v47; v477 < v62; v477 += v36) {
    // pto: %231, %232
    ;
    int64_t v478 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v477 * (uint64_t) v39) + (uint64_t) v61);
    // pto: %233
    ;
    int64_t v479 = v478 < v48 ? v48 : v478;
    // pto: %signals_v4__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v480 = PTOAS__GLOBAL_TENSOR_DATA(v165);
    // pto: %signals_v4__ssa_v0_signal_pview
    ;
    const int64_t v481 = 0;
    // pto: %signals_v4__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v482 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v4__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v483 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v4__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v484 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v480 + (v481 + v479), v482, v483);
    pto::comm::WaitCmp v485 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v484, v175, v485);
  }
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %234, %235
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  for (int64_t v486 = v166; v486 < ((int64_t) ((uint64_t) v17 + (uint64_t) v63) / v44); v486 += v50) {
    // pto: %236
    ;
    int64_t v487 = (int64_t) ((uint64_t) v486 * (uint64_t) v44);
    // pto: %237
    ;
    int64_t v488 = (int64_t) ((uint64_t) v487 + (uint64_t) v44);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    for (int64_t v489 = v487; v489 < v488; v489 += v46) {
      // pto: %238
      ;
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      if (v489 < v17) {
        // pto: %239
        ;
        int64_t v490 = (int64_t) ((uint64_t) v489 * (uint64_t) v44);
        // pto: %post_scalar__tile
        ;
        float v491 = (v11)[v490];
        // pto: %241
        ;
        int64_t v492 = (int64_t) ((uint64_t) v489 * (uint64_t) v38);
        // pto: %comb_scalar_0__tile
        ;
        float v493 = (v12)[v492];
        // pto: %244, %comb_scalar_1__tile
        ;
        float v494 = (v12)[(int64_t) ((uint64_t) v492 + (uint64_t) v44)];
        // pto: %246, %comb_scalar_2__tile
        ;
        float v495 = (v12)[(int64_t) ((uint64_t) v492 + (uint64_t) v37)];
        // pto: %248, %comb_scalar_3__tile
        ;
        float v496 = (v12)[(int64_t) ((uint64_t) v492 + (uint64_t) v64)];
        // pto: %251, %249
        ;
        float v497 = (v11)[(int64_t) ((uint64_t) v490 + (uint64_t) v36)];
        // pto: %254, %252
        ;
        float v498 = (v12)[(int64_t) ((uint64_t) v492 + (uint64_t) v36)];
        // pto: %257, %255
        ;
        float v499 = (v12)[(int64_t) ((uint64_t) v492 + (uint64_t) v65)];
        // pto: %260, %258
        ;
        float v500 = (v12)[(int64_t) ((uint64_t) v492 + (uint64_t) v66)];
        // pto: %263, %261
        ;
        float v501 = (v12)[(int64_t) ((uint64_t) v492 + (uint64_t) v67)];
        // pto: %266, %264
        ;
        float v502 = (v11)[(int64_t) ((uint64_t) v490 + (uint64_t) v46)];
        // pto: %269, %267
        ;
        float v503 = (v12)[(int64_t) ((uint64_t) v492 + (uint64_t) v46)];
        // pto: %272, %270
        ;
        float v504 = (v12)[(int64_t) ((uint64_t) v492 + (uint64_t) v68)];
        // pto: %275, %273
        ;
        float v505 = (v12)[(int64_t) ((uint64_t) v492 + (uint64_t) v69)];
        // pto: %278, %276
        ;
        float v506 = (v12)[(int64_t) ((uint64_t) v492 + (uint64_t) v70)];
        // pto: %281, %279
        ;
        float v507 = (v11)[(int64_t) ((uint64_t) v490 + (uint64_t) v63)];
        // pto: %284, %282
        ;
        float v508 = (v12)[(int64_t) ((uint64_t) v492 + (uint64_t) v63)];
        // pto: %287, %285
        ;
        float v509 = (v12)[(int64_t) ((uint64_t) v492 + (uint64_t) v53)];
        // pto: %290, %288
        ;
        float v510 = (v12)[(int64_t) ((uint64_t) v492 + (uint64_t) v71)];
        // pto: %293, %291
        ;
        float v511 = (v12)[(int64_t) ((uint64_t) v492 + (uint64_t) v49)];
        // pto: %x_block__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v512 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %x_block__tile
        ;
        uint64_t v513 = (uint64_t) v31;
        TASSIGN(v512, v513);
        // pto: %294
        ;
        int64_t v514 = v489 < v48 ? v48 : v489;
        // pto: %x__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v515 = PTOAS__GLOBAL_TENSOR_DATA(v119);
        // pto: %x__ssa_v0_pview
        ;
        const int64_t v516 = 0;
        // pto: %x__ssa_v0_pview
        ;
        const int64_t v517 = 4096;
        // pto: %x__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v518 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %x__ssa_v0_pview
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v519 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %x__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v520 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v515 + (v516 + v514 * v517), v518, v519);
        TLOAD(v512, v520);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        // pto: %295
        ;
        int64_t v521 = (int64_t) ((uint64_t) v17 - (uint64_t) v489);
        // pto: %296
        ;
        int64_t v522 = v521 < v48 ? v48 : v521;
        // pto: %297
        ;
        int64_t v523 = v522 < v36 ? v522 : v36;
        // pto: %t__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v524 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %t__tile
        ;
        uint64_t v525 = (uint64_t) v24;
        TASSIGN(v524, v525);
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v526 = 0;
        // pto: %residual_flat__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v527 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v528 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v529 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v530 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        int64_t v531 = v523 * v43;
        // pto: %residual_flat__ssa_v0_pview
        ;
        int64_t v532 = v530 * v531;
        // pto: %residual_flat__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 4096> v533 = pto::Shape<1, 1, 1, -1, 4096>(v528, v529, v530, v523, v41);
        // pto: %residual_flat__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v534 = pto::Stride<-1, -1, -1, -1, -1>(v529 * v532, v532, v531, v43, v36);
        // pto: %residual_flat__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v535 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v527 + (v526 + v514 * v43 + v48 * v36), v533, v534);
        TLOAD(v524, v535);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        // pto: %0
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v536 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %0
        ;
        uint64_t v537 = (uint64_t) v29;
        TASSIGN(v536, v537);
        // pto: %309
        ;
        const int64_t v538 = 0;
        // pto: %309
        ;
        __gm__ bfloat16_t* v539 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %309
        ;
        const int64_t v540 = 1;
        // pto: %309
        ;
        const int64_t v541 = 1;
        // pto: %309
        ;
        const int64_t v542 = 1;
        // pto: %309
        ;
        int64_t v543 = v523 * v43;
        // pto: %309
        ;
        int64_t v544 = v542 * v543;
        // pto: %309
        ;
        pto::Shape<1, 1, 1, -1, 4096> v545 = pto::Shape<1, 1, 1, -1, 4096>(v540, v541, v542, v523, v41);
        // pto: %309
        ;
        pto::Stride<-1, -1, -1, -1, -1> v546 = pto::Stride<-1, -1, -1, -1, -1>(v541 * v544, v544, v543, v43, v36);
        // pto: %309
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v547 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v539 + (v538 + v514 * v43 + v41 * v36), v545, v546);
        TLOAD(v536, v547);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %1
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v548 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %1
        ;
        uint64_t v549 = (uint64_t) v25;
        TASSIGN(v548, v549);
        // pto: %317
        ;
        const int64_t v550 = 0;
        // pto: %317
        ;
        __gm__ bfloat16_t* v551 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %317
        ;
        const int64_t v552 = 1;
        // pto: %317
        ;
        const int64_t v553 = 1;
        // pto: %317
        ;
        const int64_t v554 = 1;
        // pto: %317
        ;
        int64_t v555 = v523 * v43;
        // pto: %317
        ;
        int64_t v556 = v554 * v555;
        // pto: %317
        ;
        pto::Shape<1, 1, 1, -1, 4096> v557 = pto::Shape<1, 1, 1, -1, 4096>(v552, v553, v554, v523, v41);
        // pto: %317
        ;
        pto::Stride<-1, -1, -1, -1, -1> v558 = pto::Stride<-1, -1, -1, -1, -1>(v553 * v556, v556, v555, v43, v36);
        // pto: %317
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v559 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v551 + (v550 + v514 * v43 + v42 * v36), v557, v558);
        TLOAD(v548, v559);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %2
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v560 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %2
        ;
        uint64_t v561 = (uint64_t) v32;
        TASSIGN(v560, v561);
        // pto: %325
        ;
        const int64_t v562 = 0;
        // pto: %325
        ;
        __gm__ bfloat16_t* v563 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %325
        ;
        const int64_t v564 = 1;
        // pto: %325
        ;
        const int64_t v565 = 1;
        // pto: %325
        ;
        const int64_t v566 = 1;
        // pto: %325
        ;
        int64_t v567 = v523 * v43;
        // pto: %325
        ;
        int64_t v568 = v566 * v567;
        // pto: %325
        ;
        pto::Shape<1, 1, 1, -1, 4096> v569 = pto::Shape<1, 1, 1, -1, 4096>(v564, v565, v566, v523, v41);
        // pto: %325
        ;
        pto::Stride<-1, -1, -1, -1, -1> v570 = pto::Stride<-1, -1, -1, -1, -1>(v565 * v568, v568, v567, v43, v36);
        // pto: %325
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v571 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v563 + (v562 + v514 * v43 + v72 * v36), v569, v570);
        TLOAD(v560, v571);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %x_f32__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v572 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %x_f32__tile
        ;
        uint64_t v573 = (uint64_t) v23;
        TASSIGN(v572, v573);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        RoundMode v574 = RoundMode::CAST_ROUND;
        SaturationMode v575 = SaturationMode::ON;
        TCVT(v572, v512, v574, v575);
        // pto: %res_0__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v576 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %res_0__tile
        ;
        uint64_t v577 = (uint64_t) v31;
        TASSIGN(v576, v577);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        RoundMode v578 = RoundMode::CAST_ROUND;
        SaturationMode v579 = SaturationMode::ON;
        TCVT(v576, v524, v578, v579);
        // pto: %res_1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v580 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %res_1__tile
        ;
        uint64_t v581 = (uint64_t) v24;
        TASSIGN(v580, v581);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v582 = RoundMode::CAST_ROUND;
        SaturationMode v583 = SaturationMode::ON;
        TCVT(v580, v536, v582, v583);
        // pto: %res_2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v584 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %res_2__tile
        ;
        uint64_t v585 = (uint64_t) v29;
        TASSIGN(v584, v585);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        RoundMode v586 = RoundMode::CAST_ROUND;
        SaturationMode v587 = SaturationMode::ON;
        TCVT(v584, v548, v586, v587);
        // pto: %res_3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v588 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %res_3__tile
        ;
        uint64_t v589 = (uint64_t) v25;
        TASSIGN(v588, v589);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v590 = RoundMode::CAST_ROUND;
        SaturationMode v591 = SaturationMode::ON;
        TCVT(v588, v560, v590, v591);
        // pto: %single_y__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v592 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %single_y__tile
        ;
        uint64_t v593 = (uint64_t) v32;
        TASSIGN(v592, v593);
        pipe_barrier(PIPE_V);
        TMULS(v592, v572, v491);
        // pto: %single_weighted_0__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v594 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %single_weighted_0__tile
        ;
        uint64_t v595 = (uint64_t) v33;
        TASSIGN(v594, v595);
        TMULS(v594, v576, v493);
        // pto: %single_y_v1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v596 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %single_y_v1__tile
        ;
        uint64_t v597 = (uint64_t) v32;
        TASSIGN(v596, v597);
        pipe_barrier(PIPE_V);
        TADD(v596, v592, v594);
        // pto: %single_weighted_1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v598 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %single_weighted_1__tile
        ;
        uint64_t v599 = (uint64_t) v33;
        TASSIGN(v598, v599);
        pipe_barrier(PIPE_V);
        TMULS(v598, v580, v494);
        // pto: %single_y_v2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v600 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %single_y_v2__tile
        ;
        uint64_t v601 = (uint64_t) v32;
        TASSIGN(v600, v601);
        pipe_barrier(PIPE_V);
        TADD(v600, v596, v598);
        // pto: %single_weighted_2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v602 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %single_weighted_2__tile
        ;
        uint64_t v603 = (uint64_t) v33;
        TASSIGN(v602, v603);
        pipe_barrier(PIPE_V);
        TMULS(v602, v584, v495);
        // pto: %single_y_v3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v604 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %single_y_v3__tile
        ;
        uint64_t v605 = (uint64_t) v32;
        TASSIGN(v604, v605);
        pipe_barrier(PIPE_V);
        TADD(v604, v600, v602);
        // pto: %single_weighted_3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v606 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %single_weighted_3__tile
        ;
        uint64_t v607 = (uint64_t) v33;
        TASSIGN(v606, v607);
        pipe_barrier(PIPE_V);
        TMULS(v606, v588, v496);
        // pto: %single_y_v4__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v608 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %single_y_v4__tile
        ;
        uint64_t v609 = (uint64_t) v32;
        TASSIGN(v608, v609);
        pipe_barrier(PIPE_V);
        TADD(v608, v604, v606);
        // pto: %single_result__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v610 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %single_result__tile
        ;
        uint64_t v611 = (uint64_t) v34;
        TASSIGN(v610, v611);
        pipe_barrier(PIPE_V);
        RoundMode v612 = RoundMode::CAST_RINT;
        SaturationMode v613 = SaturationMode::ON;
        TCVT(v610, v608, v612, v613);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        v610.SetValidShape(v36, v41);
        // pto: %4
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v614 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %4
        ;
        uint64_t v615 = (uint64_t) v32;
        TASSIGN(v614, v615);
        pipe_barrier(PIPE_V);
        TMULS(v614, v572, v497);
        // pto: %5
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v616 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %5
        ;
        uint64_t v617 = (uint64_t) v33;
        TASSIGN(v616, v617);
        TMULS(v616, v576, v498);
        // pto: %6
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v618 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %6
        ;
        uint64_t v619 = (uint64_t) v32;
        TASSIGN(v618, v619);
        pipe_barrier(PIPE_V);
        TADD(v618, v614, v616);
        // pto: %7
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v620 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %7
        ;
        uint64_t v621 = (uint64_t) v33;
        TASSIGN(v620, v621);
        pipe_barrier(PIPE_V);
        TMULS(v620, v580, v499);
        // pto: %8
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v622 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %8
        ;
        uint64_t v623 = (uint64_t) v32;
        TASSIGN(v622, v623);
        pipe_barrier(PIPE_V);
        TADD(v622, v618, v620);
        // pto: %9
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v624 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %9
        ;
        uint64_t v625 = (uint64_t) v33;
        TASSIGN(v624, v625);
        pipe_barrier(PIPE_V);
        TMULS(v624, v584, v500);
        // pto: %10
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v626 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %10
        ;
        uint64_t v627 = (uint64_t) v32;
        TASSIGN(v626, v627);
        pipe_barrier(PIPE_V);
        TADD(v626, v622, v624);
        // pto: %11
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v628 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %11
        ;
        uint64_t v629 = (uint64_t) v33;
        TASSIGN(v628, v629);
        pipe_barrier(PIPE_V);
        TMULS(v628, v588, v501);
        // pto: %12
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v630 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %12
        ;
        uint64_t v631 = (uint64_t) v32;
        TASSIGN(v630, v631);
        pipe_barrier(PIPE_V);
        TADD(v630, v626, v628);
        // pto: %13
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v632 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %13
        ;
        uint64_t v633 = (uint64_t) v35;
        TASSIGN(v632, v633);
        pipe_barrier(PIPE_V);
        RoundMode v634 = RoundMode::CAST_RINT;
        SaturationMode v635 = SaturationMode::ON;
        TCVT(v632, v630, v634, v635);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        v632.SetValidShape(v36, v41);
        // pto: %15
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v636 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %15
        ;
        uint64_t v637 = (uint64_t) v32;
        TASSIGN(v636, v637);
        pipe_barrier(PIPE_V);
        TMULS(v636, v572, v502);
        // pto: %16
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v638 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %16
        ;
        uint64_t v639 = (uint64_t) v33;
        TASSIGN(v638, v639);
        TMULS(v638, v576, v503);
        // pto: %17
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v640 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %17
        ;
        uint64_t v641 = (uint64_t) v32;
        TASSIGN(v640, v641);
        pipe_barrier(PIPE_V);
        TADD(v640, v636, v638);
        // pto: %18
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v642 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %18
        ;
        uint64_t v643 = (uint64_t) v33;
        TASSIGN(v642, v643);
        pipe_barrier(PIPE_V);
        TMULS(v642, v580, v504);
        // pto: %19
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v644 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %19
        ;
        uint64_t v645 = (uint64_t) v32;
        TASSIGN(v644, v645);
        pipe_barrier(PIPE_V);
        TADD(v644, v640, v642);
        // pto: %20
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v646 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %20
        ;
        uint64_t v647 = (uint64_t) v33;
        TASSIGN(v646, v647);
        pipe_barrier(PIPE_V);
        TMULS(v646, v584, v505);
        // pto: %21
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v648 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %21
        ;
        uint64_t v649 = (uint64_t) v32;
        TASSIGN(v648, v649);
        pipe_barrier(PIPE_V);
        TADD(v648, v644, v646);
        // pto: %22
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v650 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %22
        ;
        uint64_t v651 = (uint64_t) v33;
        TASSIGN(v650, v651);
        pipe_barrier(PIPE_V);
        TMULS(v650, v588, v506);
        // pto: %23
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v652 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %23
        ;
        uint64_t v653 = (uint64_t) v32;
        TASSIGN(v652, v653);
        pipe_barrier(PIPE_V);
        TADD(v652, v648, v650);
        // pto: %24
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v654 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %24
        ;
        uint64_t v655 = (uint64_t) v32;
        TASSIGN(v654, v655);
        pipe_barrier(PIPE_V);
        RoundMode v656 = RoundMode::CAST_RINT;
        SaturationMode v657 = SaturationMode::ON;
        TCVT(v654, v652, v656, v657);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        v654.SetValidShape(v36, v41);
        // pto: %26
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v658 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %26
        ;
        uint64_t v659 = (uint64_t) v23;
        TASSIGN(v658, v659);
        TMULS(v658, v572, v507);
        // pto: %27
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v660 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %27
        ;
        uint64_t v661 = (uint64_t) v31;
        TASSIGN(v660, v661);
        TMULS(v660, v576, v508);
        // pto: %28
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v662 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %28
        ;
        uint64_t v663 = (uint64_t) v23;
        TASSIGN(v662, v663);
        pipe_barrier(PIPE_V);
        TADD(v662, v658, v660);
        // pto: %29
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v664 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %29
        ;
        uint64_t v665 = (uint64_t) v31;
        TASSIGN(v664, v665);
        pipe_barrier(PIPE_V);
        TMULS(v664, v580, v509);
        // pto: %30
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v666 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %30
        ;
        uint64_t v667 = (uint64_t) v23;
        TASSIGN(v666, v667);
        pipe_barrier(PIPE_V);
        TADD(v666, v662, v664);
        // pto: %31
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v668 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %31
        ;
        uint64_t v669 = (uint64_t) v31;
        TASSIGN(v668, v669);
        pipe_barrier(PIPE_V);
        TMULS(v668, v584, v510);
        // pto: %32
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v670 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %32
        ;
        uint64_t v671 = (uint64_t) v23;
        TASSIGN(v670, v671);
        pipe_barrier(PIPE_V);
        TADD(v670, v666, v668);
        // pto: %33
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v672 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v523, v41);
        // pto: %33
        ;
        uint64_t v673 = (uint64_t) v31;
        TASSIGN(v672, v673);
        pipe_barrier(PIPE_V);
        TMULS(v672, v588, v511);
        // pto: %34
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v674 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %34
        ;
        uint64_t v675 = (uint64_t) v23;
        TASSIGN(v674, v675);
        pipe_barrier(PIPE_V);
        TADD(v674, v670, v672);
        // pto: %35
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v676 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %35
        ;
        uint64_t v677 = (uint64_t) v23;
        TASSIGN(v676, v677);
        pipe_barrier(PIPE_V);
        RoundMode v678 = RoundMode::CAST_RINT;
        SaturationMode v679 = SaturationMode::ON;
        TCVT(v676, v674, v678, v679);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        v676.SetValidShape(v36, v41);
        // pto: %y_flat__iter_v3_pview
        ;
        __gm__ bfloat16_t* v680 = PTOAS__GLOBAL_TENSOR_DATA(v137);
        // pto: %y_flat__iter_v3_pview
        ;
        const int64_t v681 = 0;
        // pto: %y_flat__iter_v3_pview
        ;
        const int64_t v682 = 16384;
        // pto: %y_flat__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v683 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__iter_v3_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v684 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v685 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v680 + (v681 + v514 * v682), v683, v684);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        TSTORE(v685, v610);
        // pto: %y_flat__tile_pview
        ;
        __gm__ bfloat16_t* v686 = PTOAS__GLOBAL_TENSOR_DATA(v137);
        // pto: %y_flat__tile_pview
        ;
        const int64_t v687 = 4096;
        // pto: %y_flat__tile_pview
        ;
        const int64_t v688 = 16384;
        // pto: %y_flat__tile_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v689 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__tile_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v690 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__tile_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v691 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v686 + (v687 + v514 * v688), v689, v690);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        TSTORE(v691, v632);
        // pto: %391
        ;
        __gm__ bfloat16_t* v692 = PTOAS__GLOBAL_TENSOR_DATA(v137);
        // pto: %391
        ;
        const int64_t v693 = 8192;
        // pto: %391
        ;
        const int64_t v694 = 16384;
        // pto: %391
        ;
        pto::Shape<1, 1, 1, 1, 4096> v695 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %391
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v696 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %391
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v697 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v692 + (v693 + v514 * v694), v695, v696);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        TSTORE(v697, v654);
        // pto: %394
        ;
        __gm__ bfloat16_t* v698 = PTOAS__GLOBAL_TENSOR_DATA(v137);
        // pto: %394
        ;
        const int64_t v699 = 12288;
        // pto: %394
        ;
        const int64_t v700 = 16384;
        // pto: %394
        ;
        pto::Shape<1, 1, 1, 1, 4096> v701 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %394
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v702 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %394
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v703 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v698 + (v699 + v514 * v700), v701, v702);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        TSTORE(v703, v676);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      // pto: %395
      ;
      int64_t v704 = (int64_t) ((uint64_t) v489 + (uint64_t) v36);
      // pto: %396
      ;
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      if (v704 < v17) {
        // pto: %399
        ;
        int64_t v705 = (int64_t) ((uint64_t) v704 * (uint64_t) v44);
        // pto: %397
        ;
        float v706 = (v11)[v705];
        // pto: %403
        ;
        int64_t v707 = (int64_t) ((uint64_t) v704 * (uint64_t) v38);
        // pto: %401
        ;
        float v708 = (v12)[v707];
        // pto: %408, %405
        ;
        float v709 = (v12)[(int64_t) ((uint64_t) v707 + (uint64_t) v44)];
        // pto: %412, %409
        ;
        float v710 = (v12)[(int64_t) ((uint64_t) v707 + (uint64_t) v37)];
        // pto: %416, %413
        ;
        float v711 = (v12)[(int64_t) ((uint64_t) v707 + (uint64_t) v64)];
        // pto: %420, %417
        ;
        float v712 = (v11)[(int64_t) ((uint64_t) v705 + (uint64_t) v36)];
        // pto: %424, %421
        ;
        float v713 = (v12)[(int64_t) ((uint64_t) v707 + (uint64_t) v36)];
        // pto: %428, %425
        ;
        float v714 = (v12)[(int64_t) ((uint64_t) v707 + (uint64_t) v65)];
        // pto: %432, %429
        ;
        float v715 = (v12)[(int64_t) ((uint64_t) v707 + (uint64_t) v66)];
        // pto: %436, %433
        ;
        float v716 = (v12)[(int64_t) ((uint64_t) v707 + (uint64_t) v67)];
        // pto: %440, %437
        ;
        float v717 = (v11)[(int64_t) ((uint64_t) v705 + (uint64_t) v46)];
        // pto: %444, %441
        ;
        float v718 = (v12)[(int64_t) ((uint64_t) v707 + (uint64_t) v46)];
        // pto: %448, %445
        ;
        float v719 = (v12)[(int64_t) ((uint64_t) v707 + (uint64_t) v68)];
        // pto: %452, %449
        ;
        float v720 = (v12)[(int64_t) ((uint64_t) v707 + (uint64_t) v69)];
        // pto: %456, %453
        ;
        float v721 = (v12)[(int64_t) ((uint64_t) v707 + (uint64_t) v70)];
        // pto: %460, %457
        ;
        float v722 = (v11)[(int64_t) ((uint64_t) v705 + (uint64_t) v63)];
        // pto: %464, %461
        ;
        float v723 = (v12)[(int64_t) ((uint64_t) v707 + (uint64_t) v63)];
        // pto: %468, %465
        ;
        float v724 = (v12)[(int64_t) ((uint64_t) v707 + (uint64_t) v53)];
        // pto: %472, %469
        ;
        float v725 = (v12)[(int64_t) ((uint64_t) v707 + (uint64_t) v71)];
        // pto: %476, %473
        ;
        float v726 = (v12)[(int64_t) ((uint64_t) v707 + (uint64_t) v49)];
        // pto: %37
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v727 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %37
        ;
        uint64_t v728 = (uint64_t) v31;
        TASSIGN(v727, v728);
        // pto: %478
        ;
        int64_t v729 = v704 < v48 ? v48 : v704;
        // pto: %479
        ;
        __gm__ bfloat16_t* v730 = PTOAS__GLOBAL_TENSOR_DATA(v119);
        // pto: %479
        ;
        const int64_t v731 = 0;
        // pto: %479
        ;
        const int64_t v732 = 4096;
        // pto: %479
        ;
        pto::Shape<1, 1, 1, 1, 4096> v733 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %479
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v734 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %479
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v735 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v730 + (v731 + v729 * v732), v733, v734);
        TLOAD(v727, v735);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %480, %481
        ;
        int64_t v736 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v17 - (uint64_t) v489) + (uint64_t) v73);
        // pto: %482
        ;
        int64_t v737 = v736 < v48 ? v48 : v736;
        // pto: %483
        ;
        int64_t v738 = v737 < v36 ? v737 : v36;
        // pto: %38
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v739 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %38
        ;
        uint64_t v740 = (uint64_t) v24;
        TASSIGN(v739, v740);
        // pto: %490
        ;
        const int64_t v741 = 0;
        // pto: %490
        ;
        __gm__ bfloat16_t* v742 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %490
        ;
        const int64_t v743 = 1;
        // pto: %490
        ;
        const int64_t v744 = 1;
        // pto: %490
        ;
        const int64_t v745 = 1;
        // pto: %490
        ;
        int64_t v746 = v738 * v43;
        // pto: %490
        ;
        int64_t v747 = v745 * v746;
        // pto: %490
        ;
        pto::Shape<1, 1, 1, -1, 4096> v748 = pto::Shape<1, 1, 1, -1, 4096>(v743, v744, v745, v738, v41);
        // pto: %490
        ;
        pto::Stride<-1, -1, -1, -1, -1> v749 = pto::Stride<-1, -1, -1, -1, -1>(v744 * v747, v747, v746, v43, v36);
        // pto: %490
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v750 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v742 + (v741 + v729 * v43 + v48 * v36), v748, v749);
        TLOAD(v739, v750);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %39
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v751 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %39
        ;
        uint64_t v752 = (uint64_t) v29;
        TASSIGN(v751, v752);
        // pto: %501
        ;
        const int64_t v753 = 0;
        // pto: %501
        ;
        __gm__ bfloat16_t* v754 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %501
        ;
        const int64_t v755 = 1;
        // pto: %501
        ;
        const int64_t v756 = 1;
        // pto: %501
        ;
        const int64_t v757 = 1;
        // pto: %501
        ;
        int64_t v758 = v738 * v43;
        // pto: %501
        ;
        int64_t v759 = v757 * v758;
        // pto: %501
        ;
        pto::Shape<1, 1, 1, -1, 4096> v760 = pto::Shape<1, 1, 1, -1, 4096>(v755, v756, v757, v738, v41);
        // pto: %501
        ;
        pto::Stride<-1, -1, -1, -1, -1> v761 = pto::Stride<-1, -1, -1, -1, -1>(v756 * v759, v759, v758, v43, v36);
        // pto: %501
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v762 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v754 + (v753 + v729 * v43 + v41 * v36), v760, v761);
        TLOAD(v751, v762);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %40
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v763 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %40
        ;
        uint64_t v764 = (uint64_t) v25;
        TASSIGN(v763, v764);
        // pto: %512
        ;
        const int64_t v765 = 0;
        // pto: %512
        ;
        __gm__ bfloat16_t* v766 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %512
        ;
        const int64_t v767 = 1;
        // pto: %512
        ;
        const int64_t v768 = 1;
        // pto: %512
        ;
        const int64_t v769 = 1;
        // pto: %512
        ;
        int64_t v770 = v738 * v43;
        // pto: %512
        ;
        int64_t v771 = v769 * v770;
        // pto: %512
        ;
        pto::Shape<1, 1, 1, -1, 4096> v772 = pto::Shape<1, 1, 1, -1, 4096>(v767, v768, v769, v738, v41);
        // pto: %512
        ;
        pto::Stride<-1, -1, -1, -1, -1> v773 = pto::Stride<-1, -1, -1, -1, -1>(v768 * v771, v771, v770, v43, v36);
        // pto: %512
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v774 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v766 + (v765 + v729 * v43 + v42 * v36), v772, v773);
        TLOAD(v763, v774);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        // pto: %41
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v775 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %41
        ;
        uint64_t v776 = (uint64_t) v32;
        TASSIGN(v775, v776);
        // pto: %523
        ;
        const int64_t v777 = 0;
        // pto: %523
        ;
        __gm__ bfloat16_t* v778 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %523
        ;
        const int64_t v779 = 1;
        // pto: %523
        ;
        const int64_t v780 = 1;
        // pto: %523
        ;
        const int64_t v781 = 1;
        // pto: %523
        ;
        int64_t v782 = v738 * v43;
        // pto: %523
        ;
        int64_t v783 = v781 * v782;
        // pto: %523
        ;
        pto::Shape<1, 1, 1, -1, 4096> v784 = pto::Shape<1, 1, 1, -1, 4096>(v779, v780, v781, v738, v41);
        // pto: %523
        ;
        pto::Stride<-1, -1, -1, -1, -1> v785 = pto::Stride<-1, -1, -1, -1, -1>(v780 * v783, v783, v782, v43, v36);
        // pto: %523
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v786 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v778 + (v777 + v729 * v43 + v72 * v36), v784, v785);
        TLOAD(v775, v786);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        // pto: %42
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v787 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %42
        ;
        uint64_t v788 = (uint64_t) v23;
        TASSIGN(v787, v788);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v789 = RoundMode::CAST_ROUND;
        SaturationMode v790 = SaturationMode::ON;
        TCVT(v787, v727, v789, v790);
        // pto: %43
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v791 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %43
        ;
        uint64_t v792 = (uint64_t) v31;
        TASSIGN(v791, v792);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        RoundMode v793 = RoundMode::CAST_ROUND;
        SaturationMode v794 = SaturationMode::ON;
        TCVT(v791, v739, v793, v794);
        // pto: %44
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v795 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %44
        ;
        uint64_t v796 = (uint64_t) v24;
        TASSIGN(v795, v796);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v797 = RoundMode::CAST_ROUND;
        SaturationMode v798 = SaturationMode::ON;
        TCVT(v795, v751, v797, v798);
        // pto: %45
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v799 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %45
        ;
        uint64_t v800 = (uint64_t) v29;
        TASSIGN(v799, v800);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        RoundMode v801 = RoundMode::CAST_ROUND;
        SaturationMode v802 = SaturationMode::ON;
        TCVT(v799, v763, v801, v802);
        // pto: %46
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v803 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %46
        ;
        uint64_t v804 = (uint64_t) v25;
        TASSIGN(v803, v804);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        RoundMode v805 = RoundMode::CAST_ROUND;
        SaturationMode v806 = SaturationMode::ON;
        TCVT(v803, v775, v805, v806);
        // pto: %47
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v807 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %47
        ;
        uint64_t v808 = (uint64_t) v32;
        TASSIGN(v807, v808);
        pipe_barrier(PIPE_V);
        TMULS(v807, v787, v706);
        // pto: %48
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v809 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %48
        ;
        uint64_t v810 = (uint64_t) v33;
        TASSIGN(v809, v810);
        TMULS(v809, v791, v708);
        // pto: %49
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v811 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %49
        ;
        uint64_t v812 = (uint64_t) v32;
        TASSIGN(v811, v812);
        pipe_barrier(PIPE_V);
        TADD(v811, v807, v809);
        // pto: %50
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v813 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %50
        ;
        uint64_t v814 = (uint64_t) v33;
        TASSIGN(v813, v814);
        pipe_barrier(PIPE_V);
        TMULS(v813, v795, v709);
        // pto: %51
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v815 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %51
        ;
        uint64_t v816 = (uint64_t) v32;
        TASSIGN(v815, v816);
        pipe_barrier(PIPE_V);
        TADD(v815, v811, v813);
        // pto: %52
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v817 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %52
        ;
        uint64_t v818 = (uint64_t) v33;
        TASSIGN(v817, v818);
        pipe_barrier(PIPE_V);
        TMULS(v817, v799, v710);
        // pto: %53
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v819 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %53
        ;
        uint64_t v820 = (uint64_t) v32;
        TASSIGN(v819, v820);
        pipe_barrier(PIPE_V);
        TADD(v819, v815, v817);
        // pto: %54
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v821 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %54
        ;
        uint64_t v822 = (uint64_t) v33;
        TASSIGN(v821, v822);
        pipe_barrier(PIPE_V);
        TMULS(v821, v803, v711);
        // pto: %55
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v823 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %55
        ;
        uint64_t v824 = (uint64_t) v32;
        TASSIGN(v823, v824);
        pipe_barrier(PIPE_V);
        TADD(v823, v819, v821);
        // pto: %56
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v825 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %56
        ;
        uint64_t v826 = (uint64_t) v34;
        TASSIGN(v825, v826);
        pipe_barrier(PIPE_V);
        RoundMode v827 = RoundMode::CAST_RINT;
        SaturationMode v828 = SaturationMode::ON;
        TCVT(v825, v823, v827, v828);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v825.SetValidShape(v36, v41);
        // pto: %58
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v829 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %58
        ;
        uint64_t v830 = (uint64_t) v32;
        TASSIGN(v829, v830);
        pipe_barrier(PIPE_V);
        TMULS(v829, v787, v712);
        // pto: %59
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v831 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %59
        ;
        uint64_t v832 = (uint64_t) v33;
        TASSIGN(v831, v832);
        TMULS(v831, v791, v713);
        // pto: %60
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v833 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %60
        ;
        uint64_t v834 = (uint64_t) v32;
        TASSIGN(v833, v834);
        pipe_barrier(PIPE_V);
        TADD(v833, v829, v831);
        // pto: %61
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v835 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %61
        ;
        uint64_t v836 = (uint64_t) v33;
        TASSIGN(v835, v836);
        pipe_barrier(PIPE_V);
        TMULS(v835, v795, v714);
        // pto: %62
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v837 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %62
        ;
        uint64_t v838 = (uint64_t) v32;
        TASSIGN(v837, v838);
        pipe_barrier(PIPE_V);
        TADD(v837, v833, v835);
        // pto: %63
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v839 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %63
        ;
        uint64_t v840 = (uint64_t) v33;
        TASSIGN(v839, v840);
        pipe_barrier(PIPE_V);
        TMULS(v839, v799, v715);
        // pto: %64
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v841 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %64
        ;
        uint64_t v842 = (uint64_t) v32;
        TASSIGN(v841, v842);
        pipe_barrier(PIPE_V);
        TADD(v841, v837, v839);
        // pto: %65
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v843 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %65
        ;
        uint64_t v844 = (uint64_t) v33;
        TASSIGN(v843, v844);
        pipe_barrier(PIPE_V);
        TMULS(v843, v803, v716);
        // pto: %66
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v845 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %66
        ;
        uint64_t v846 = (uint64_t) v32;
        TASSIGN(v845, v846);
        pipe_barrier(PIPE_V);
        TADD(v845, v841, v843);
        // pto: %67
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v847 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %67
        ;
        uint64_t v848 = (uint64_t) v35;
        TASSIGN(v847, v848);
        pipe_barrier(PIPE_V);
        RoundMode v849 = RoundMode::CAST_RINT;
        SaturationMode v850 = SaturationMode::ON;
        TCVT(v847, v845, v849, v850);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        v847.SetValidShape(v36, v41);
        // pto: %69
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v851 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %69
        ;
        uint64_t v852 = (uint64_t) v32;
        TASSIGN(v851, v852);
        pipe_barrier(PIPE_V);
        TMULS(v851, v787, v717);
        // pto: %70
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v853 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %70
        ;
        uint64_t v854 = (uint64_t) v33;
        TASSIGN(v853, v854);
        TMULS(v853, v791, v718);
        // pto: %71
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v855 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %71
        ;
        uint64_t v856 = (uint64_t) v32;
        TASSIGN(v855, v856);
        pipe_barrier(PIPE_V);
        TADD(v855, v851, v853);
        // pto: %72
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v857 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %72
        ;
        uint64_t v858 = (uint64_t) v33;
        TASSIGN(v857, v858);
        pipe_barrier(PIPE_V);
        TMULS(v857, v795, v719);
        // pto: %73
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v859 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %73
        ;
        uint64_t v860 = (uint64_t) v32;
        TASSIGN(v859, v860);
        pipe_barrier(PIPE_V);
        TADD(v859, v855, v857);
        // pto: %74
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v861 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %74
        ;
        uint64_t v862 = (uint64_t) v33;
        TASSIGN(v861, v862);
        pipe_barrier(PIPE_V);
        TMULS(v861, v799, v720);
        // pto: %75
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v863 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %75
        ;
        uint64_t v864 = (uint64_t) v32;
        TASSIGN(v863, v864);
        pipe_barrier(PIPE_V);
        TADD(v863, v859, v861);
        // pto: %76
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v865 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %76
        ;
        uint64_t v866 = (uint64_t) v33;
        TASSIGN(v865, v866);
        pipe_barrier(PIPE_V);
        TMULS(v865, v803, v721);
        // pto: %77
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v867 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %77
        ;
        uint64_t v868 = (uint64_t) v32;
        TASSIGN(v867, v868);
        pipe_barrier(PIPE_V);
        TADD(v867, v863, v865);
        // pto: %78
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v869 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %78
        ;
        uint64_t v870 = (uint64_t) v32;
        TASSIGN(v869, v870);
        pipe_barrier(PIPE_V);
        RoundMode v871 = RoundMode::CAST_RINT;
        SaturationMode v872 = SaturationMode::ON;
        TCVT(v869, v867, v871, v872);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        v869.SetValidShape(v36, v41);
        // pto: %80
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v873 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %80
        ;
        uint64_t v874 = (uint64_t) v23;
        TASSIGN(v873, v874);
        TMULS(v873, v787, v722);
        // pto: %81
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v875 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %81
        ;
        uint64_t v876 = (uint64_t) v31;
        TASSIGN(v875, v876);
        TMULS(v875, v791, v723);
        // pto: %82
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v877 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %82
        ;
        uint64_t v878 = (uint64_t) v23;
        TASSIGN(v877, v878);
        pipe_barrier(PIPE_V);
        TADD(v877, v873, v875);
        // pto: %83
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v879 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %83
        ;
        uint64_t v880 = (uint64_t) v31;
        TASSIGN(v879, v880);
        pipe_barrier(PIPE_V);
        TMULS(v879, v795, v724);
        // pto: %84
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v881 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %84
        ;
        uint64_t v882 = (uint64_t) v23;
        TASSIGN(v881, v882);
        pipe_barrier(PIPE_V);
        TADD(v881, v877, v879);
        // pto: %85
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v883 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %85
        ;
        uint64_t v884 = (uint64_t) v31;
        TASSIGN(v883, v884);
        pipe_barrier(PIPE_V);
        TMULS(v883, v799, v725);
        // pto: %86
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v885 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %86
        ;
        uint64_t v886 = (uint64_t) v23;
        TASSIGN(v885, v886);
        pipe_barrier(PIPE_V);
        TADD(v885, v881, v883);
        // pto: %87
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v887 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v738, v41);
        // pto: %87
        ;
        uint64_t v888 = (uint64_t) v31;
        TASSIGN(v887, v888);
        pipe_barrier(PIPE_V);
        TMULS(v887, v803, v726);
        // pto: %88
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v889 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %88
        ;
        uint64_t v890 = (uint64_t) v23;
        TASSIGN(v889, v890);
        pipe_barrier(PIPE_V);
        TADD(v889, v885, v887);
        // pto: %89
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v891 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %89
        ;
        uint64_t v892 = (uint64_t) v23;
        TASSIGN(v891, v892);
        pipe_barrier(PIPE_V);
        RoundMode v893 = RoundMode::CAST_RINT;
        SaturationMode v894 = SaturationMode::ON;
        TCVT(v891, v889, v893, v894);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        v891.SetValidShape(v36, v41);
        // pto: %y_flat__phi_v9_pview
        ;
        __gm__ bfloat16_t* v895 = PTOAS__GLOBAL_TENSOR_DATA(v137);
        // pto: %y_flat__phi_v9_pview
        ;
        const int64_t v896 = 0;
        // pto: %y_flat__phi_v9_pview
        ;
        const int64_t v897 = 16384;
        // pto: %y_flat__phi_v9_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v898 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__phi_v9_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v899 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__phi_v9_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v900 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v895 + (v896 + v729 * v897), v898, v899);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v900, v825);
        // pto: %610
        ;
        __gm__ bfloat16_t* v901 = PTOAS__GLOBAL_TENSOR_DATA(v137);
        // pto: %610
        ;
        const int64_t v902 = 4096;
        // pto: %610
        ;
        const int64_t v903 = 16384;
        // pto: %610
        ;
        pto::Shape<1, 1, 1, 1, 4096> v904 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %610
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v905 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %610
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v906 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v901 + (v902 + v729 * v903), v904, v905);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v906, v847);
        // pto: %614
        ;
        __gm__ bfloat16_t* v907 = PTOAS__GLOBAL_TENSOR_DATA(v137);
        // pto: %614
        ;
        const int64_t v908 = 8192;
        // pto: %614
        ;
        const int64_t v909 = 16384;
        // pto: %614
        ;
        pto::Shape<1, 1, 1, 1, 4096> v910 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %614
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v911 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %614
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v912 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v907 + (v908 + v729 * v909), v910, v911);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        TSTORE(v912, v869);
        // pto: %618
        ;
        __gm__ bfloat16_t* v913 = PTOAS__GLOBAL_TENSOR_DATA(v137);
        // pto: %618
        ;
        const int64_t v914 = 12288;
        // pto: %618
        ;
        const int64_t v915 = 16384;
        // pto: %618
        ;
        pto::Shape<1, 1, 1, 1, 4096> v916 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %618
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v917 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %618
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v918 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v913 + (v914 + v729 * v915), v916, v917);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        TSTORE(v918, v891);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    // pto: %619, %620, %621
    ;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    if ((int64_t) ((uint64_t) ((int64_t) (uint64_t) v487 - (uint64_t) v488) + (uint64_t) v44) == v36) {
      // pto: %622
      ;
      if (v488 < v17) {
        // pto: %91
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v919 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %91
        ;
        uint64_t v920 = (uint64_t) v31;
        TASSIGN(v919, v920);
        // pto: %623
        ;
        int64_t v921 = v488 < v48 ? v48 : v488;
        // pto: %624
        ;
        __gm__ bfloat16_t* v922 = PTOAS__GLOBAL_TENSOR_DATA(v119);
        // pto: %624
        ;
        const int64_t v923 = 0;
        // pto: %624
        ;
        const int64_t v924 = 4096;
        // pto: %624
        ;
        pto::Shape<1, 1, 1, 1, 4096> v925 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %624
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v926 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %624
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v927 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v922 + (v923 + v921 * v924), v925, v926);
        TLOAD(v919, v927);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %92
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v928 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %92
        ;
        uint64_t v929 = (uint64_t) v23;
        TASSIGN(v928, v929);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v930 = RoundMode::CAST_ROUND;
        SaturationMode v931 = SaturationMode::ON;
        TCVT(v928, v919, v930, v931);
        // pto: %625
        ;
        int64_t v932 = (int64_t) ((uint64_t) v17 - (uint64_t) v488);
        // pto: %626
        ;
        int64_t v933 = v932 < v48 ? v48 : v932;
        // pto: %627
        ;
        int64_t v934 = v933 < v36 ? v933 : v36;
        // pto: %93
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v935 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %93
        ;
        uint64_t v936 = (uint64_t) v24;
        TASSIGN(v935, v936);
        // pto: %632
        ;
        const int64_t v937 = 0;
        // pto: %632
        ;
        __gm__ bfloat16_t* v938 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %632
        ;
        const int64_t v939 = 1;
        // pto: %632
        ;
        const int64_t v940 = 1;
        // pto: %632
        ;
        const int64_t v941 = 1;
        // pto: %632
        ;
        int64_t v942 = v934 * v43;
        // pto: %632
        ;
        int64_t v943 = v941 * v942;
        // pto: %632
        ;
        pto::Shape<1, 1, 1, -1, 4096> v944 = pto::Shape<1, 1, 1, -1, 4096>(v939, v940, v941, v934, v41);
        // pto: %632
        ;
        pto::Stride<-1, -1, -1, -1, -1> v945 = pto::Stride<-1, -1, -1, -1, -1>(v940 * v943, v943, v942, v43, v36);
        // pto: %632
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v946 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v938 + (v937 + v921 * v43 + v48 * v36), v944, v945);
        TLOAD(v935, v946);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %94
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v947 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %94
        ;
        uint64_t v948 = (uint64_t) v31;
        TASSIGN(v947, v948);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v949 = RoundMode::CAST_ROUND;
        SaturationMode v950 = SaturationMode::ON;
        TCVT(v947, v935, v949, v950);
        // pto: %95
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v951 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %95
        ;
        uint64_t v952 = (uint64_t) v29;
        TASSIGN(v951, v952);
        // pto: %643
        ;
        const int64_t v953 = 0;
        // pto: %643
        ;
        __gm__ bfloat16_t* v954 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %643
        ;
        const int64_t v955 = 1;
        // pto: %643
        ;
        const int64_t v956 = 1;
        // pto: %643
        ;
        const int64_t v957 = 1;
        // pto: %643
        ;
        int64_t v958 = v934 * v43;
        // pto: %643
        ;
        int64_t v959 = v957 * v958;
        // pto: %643
        ;
        pto::Shape<1, 1, 1, -1, 4096> v960 = pto::Shape<1, 1, 1, -1, 4096>(v955, v956, v957, v934, v41);
        // pto: %643
        ;
        pto::Stride<-1, -1, -1, -1, -1> v961 = pto::Stride<-1, -1, -1, -1, -1>(v956 * v959, v959, v958, v43, v36);
        // pto: %643
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v962 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v954 + (v953 + v921 * v43 + v41 * v36), v960, v961);
        TLOAD(v951, v962);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %96
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v963 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %96
        ;
        uint64_t v964 = (uint64_t) v24;
        TASSIGN(v963, v964);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v965 = RoundMode::CAST_ROUND;
        SaturationMode v966 = SaturationMode::ON;
        TCVT(v963, v951, v965, v966);
        // pto: %97
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v967 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %97
        ;
        uint64_t v968 = (uint64_t) v25;
        TASSIGN(v967, v968);
        // pto: %654
        ;
        const int64_t v969 = 0;
        // pto: %654
        ;
        __gm__ bfloat16_t* v970 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %654
        ;
        const int64_t v971 = 1;
        // pto: %654
        ;
        const int64_t v972 = 1;
        // pto: %654
        ;
        const int64_t v973 = 1;
        // pto: %654
        ;
        int64_t v974 = v934 * v43;
        // pto: %654
        ;
        int64_t v975 = v973 * v974;
        // pto: %654
        ;
        pto::Shape<1, 1, 1, -1, 4096> v976 = pto::Shape<1, 1, 1, -1, 4096>(v971, v972, v973, v934, v41);
        // pto: %654
        ;
        pto::Stride<-1, -1, -1, -1, -1> v977 = pto::Stride<-1, -1, -1, -1, -1>(v972 * v975, v975, v974, v43, v36);
        // pto: %654
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v978 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v970 + (v969 + v921 * v43 + v42 * v36), v976, v977);
        TLOAD(v967, v978);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %98
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v979 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %98
        ;
        uint64_t v980 = (uint64_t) v29;
        TASSIGN(v979, v980);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v981 = RoundMode::CAST_ROUND;
        SaturationMode v982 = SaturationMode::ON;
        TCVT(v979, v967, v981, v982);
        // pto: %99
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v983 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %99
        ;
        uint64_t v984 = (uint64_t) v32;
        TASSIGN(v983, v984);
        // pto: %665
        ;
        const int64_t v985 = 0;
        // pto: %665
        ;
        __gm__ bfloat16_t* v986 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %665
        ;
        const int64_t v987 = 1;
        // pto: %665
        ;
        const int64_t v988 = 1;
        // pto: %665
        ;
        const int64_t v989 = 1;
        // pto: %665
        ;
        int64_t v990 = v934 * v43;
        // pto: %665
        ;
        int64_t v991 = v989 * v990;
        // pto: %665
        ;
        pto::Shape<1, 1, 1, -1, 4096> v992 = pto::Shape<1, 1, 1, -1, 4096>(v987, v988, v989, v934, v41);
        // pto: %665
        ;
        pto::Stride<-1, -1, -1, -1, -1> v993 = pto::Stride<-1, -1, -1, -1, -1>(v988 * v991, v991, v990, v43, v36);
        // pto: %665
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v994 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v986 + (v985 + v921 * v43 + v72 * v36), v992, v993);
        TLOAD(v983, v994);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %100
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v995 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %100
        ;
        uint64_t v996 = (uint64_t) v25;
        TASSIGN(v995, v996);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v997 = RoundMode::CAST_ROUND;
        SaturationMode v998 = SaturationMode::ON;
        TCVT(v995, v983, v997, v998);
        // pto: %670
        ;
        int64_t v999 = (int64_t) ((uint64_t) v488 * (uint64_t) v44);
        // pto: %669
        ;
        float v1000 = (v11)[v999];
        // pto: %101
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1001 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %101
        ;
        uint64_t v1002 = (uint64_t) v32;
        TASSIGN(v1001, v1002);
        pipe_barrier(PIPE_V);
        TMULS(v1001, v928, v1000);
        // pto: %673
        ;
        int64_t v1003 = (int64_t) ((uint64_t) v488 * (uint64_t) v38);
        // pto: %672
        ;
        float v1004 = (v12)[v1003];
        // pto: %102
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1005 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %102
        ;
        uint64_t v1006 = (uint64_t) v33;
        TASSIGN(v1005, v1006);
        TMULS(v1005, v947, v1004);
        // pto: %103
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1007 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %103
        ;
        uint64_t v1008 = (uint64_t) v32;
        TASSIGN(v1007, v1008);
        pipe_barrier(PIPE_V);
        TADD(v1007, v1001, v1005);
        // pto: %680, %678
        ;
        float v1009 = (v12)[(int64_t) ((uint64_t) v1003 + (uint64_t) v44)];
        // pto: %104
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1010 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %104
        ;
        uint64_t v1011 = (uint64_t) v33;
        TASSIGN(v1010, v1011);
        pipe_barrier(PIPE_V);
        TMULS(v1010, v963, v1009);
        // pto: %105
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1012 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %105
        ;
        uint64_t v1013 = (uint64_t) v32;
        TASSIGN(v1012, v1013);
        pipe_barrier(PIPE_V);
        TADD(v1012, v1007, v1010);
        // pto: %686, %684
        ;
        float v1014 = (v12)[(int64_t) ((uint64_t) v1003 + (uint64_t) v37)];
        // pto: %106
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1015 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %106
        ;
        uint64_t v1016 = (uint64_t) v33;
        TASSIGN(v1015, v1016);
        pipe_barrier(PIPE_V);
        TMULS(v1015, v979, v1014);
        // pto: %107
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1017 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %107
        ;
        uint64_t v1018 = (uint64_t) v32;
        TASSIGN(v1017, v1018);
        pipe_barrier(PIPE_V);
        TADD(v1017, v1012, v1015);
        // pto: %692, %690
        ;
        float v1019 = (v12)[(int64_t) ((uint64_t) v1003 + (uint64_t) v64)];
        // pto: %108
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1020 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %108
        ;
        uint64_t v1021 = (uint64_t) v33;
        TASSIGN(v1020, v1021);
        pipe_barrier(PIPE_V);
        TMULS(v1020, v995, v1019);
        // pto: %109
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1022 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %109
        ;
        uint64_t v1023 = (uint64_t) v32;
        TASSIGN(v1022, v1023);
        pipe_barrier(PIPE_V);
        TADD(v1022, v1017, v1020);
        // pto: %110
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1024 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %110
        ;
        uint64_t v1025 = (uint64_t) v32;
        TASSIGN(v1024, v1025);
        pipe_barrier(PIPE_V);
        RoundMode v1026 = RoundMode::CAST_RINT;
        SaturationMode v1027 = SaturationMode::ON;
        TCVT(v1024, v1022, v1026, v1027);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1024.SetValidShape(v36, v41);
        // pto: %y_flat__rv_v4_main_pview
        ;
        __gm__ bfloat16_t* v1028 = PTOAS__GLOBAL_TENSOR_DATA(v137);
        // pto: %y_flat__rv_v4_main_pview
        ;
        const int64_t v1029 = 0;
        // pto: %y_flat__rv_v4_main_pview
        ;
        const int64_t v1030 = 16384;
        // pto: %y_flat__rv_v4_main_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1031 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__rv_v4_main_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1032 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__rv_v4_main_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1033 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1028 + (v1029 + v921 * v1030), v1031, v1032);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1033, v1024);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
        // pto: %700, %698
        ;
        float v1034 = (v11)[(int64_t) ((uint64_t) v999 + (uint64_t) v36)];
        // pto: %112
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1035 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %112
        ;
        uint64_t v1036 = (uint64_t) v32;
        TASSIGN(v1035, v1036);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
        TMULS(v1035, v928, v1034);
        // pto: %703, %701
        ;
        float v1037 = (v12)[(int64_t) ((uint64_t) v1003 + (uint64_t) v36)];
        // pto: %113
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1038 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %113
        ;
        uint64_t v1039 = (uint64_t) v33;
        TASSIGN(v1038, v1039);
        TMULS(v1038, v947, v1037);
        // pto: %114
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1040 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %114
        ;
        uint64_t v1041 = (uint64_t) v32;
        TASSIGN(v1040, v1041);
        pipe_barrier(PIPE_V);
        TADD(v1040, v1035, v1038);
        // pto: %709, %707
        ;
        float v1042 = (v12)[(int64_t) ((uint64_t) v1003 + (uint64_t) v65)];
        // pto: %115
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1043 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %115
        ;
        uint64_t v1044 = (uint64_t) v33;
        TASSIGN(v1043, v1044);
        pipe_barrier(PIPE_V);
        TMULS(v1043, v963, v1042);
        // pto: %116
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1045 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %116
        ;
        uint64_t v1046 = (uint64_t) v32;
        TASSIGN(v1045, v1046);
        pipe_barrier(PIPE_V);
        TADD(v1045, v1040, v1043);
        // pto: %715, %713
        ;
        float v1047 = (v12)[(int64_t) ((uint64_t) v1003 + (uint64_t) v66)];
        // pto: %117
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1048 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %117
        ;
        uint64_t v1049 = (uint64_t) v33;
        TASSIGN(v1048, v1049);
        pipe_barrier(PIPE_V);
        TMULS(v1048, v979, v1047);
        // pto: %118
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1050 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %118
        ;
        uint64_t v1051 = (uint64_t) v32;
        TASSIGN(v1050, v1051);
        pipe_barrier(PIPE_V);
        TADD(v1050, v1045, v1048);
        // pto: %721, %719
        ;
        float v1052 = (v12)[(int64_t) ((uint64_t) v1003 + (uint64_t) v67)];
        // pto: %119
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1053 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %119
        ;
        uint64_t v1054 = (uint64_t) v33;
        TASSIGN(v1053, v1054);
        pipe_barrier(PIPE_V);
        TMULS(v1053, v995, v1052);
        // pto: %120
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1055 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %120
        ;
        uint64_t v1056 = (uint64_t) v32;
        TASSIGN(v1055, v1056);
        pipe_barrier(PIPE_V);
        TADD(v1055, v1050, v1053);
        // pto: %121
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1057 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %121
        ;
        uint64_t v1058 = (uint64_t) v32;
        TASSIGN(v1057, v1058);
        pipe_barrier(PIPE_V);
        RoundMode v1059 = RoundMode::CAST_RINT;
        SaturationMode v1060 = SaturationMode::ON;
        TCVT(v1057, v1055, v1059, v1060);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1057.SetValidShape(v36, v41);
        // pto: %727
        ;
        __gm__ bfloat16_t* v1061 = PTOAS__GLOBAL_TENSOR_DATA(v137);
        // pto: %727
        ;
        const int64_t v1062 = 4096;
        // pto: %727
        ;
        const int64_t v1063 = 16384;
        // pto: %727
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1064 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %727
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1065 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %727
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1066 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1061 + (v1062 + v921 * v1063), v1064, v1065);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1066, v1057);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        // pto: %730, %728
        ;
        float v1067 = (v11)[(int64_t) ((uint64_t) v999 + (uint64_t) v46)];
        // pto: %123
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1068 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %123
        ;
        uint64_t v1069 = (uint64_t) v32;
        TASSIGN(v1068, v1069);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        TMULS(v1068, v928, v1067);
        // pto: %733, %731
        ;
        float v1070 = (v12)[(int64_t) ((uint64_t) v1003 + (uint64_t) v46)];
        // pto: %124
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1071 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %124
        ;
        uint64_t v1072 = (uint64_t) v33;
        TASSIGN(v1071, v1072);
        TMULS(v1071, v947, v1070);
        // pto: %125
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1073 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %125
        ;
        uint64_t v1074 = (uint64_t) v32;
        TASSIGN(v1073, v1074);
        pipe_barrier(PIPE_V);
        TADD(v1073, v1068, v1071);
        // pto: %739, %737
        ;
        float v1075 = (v12)[(int64_t) ((uint64_t) v1003 + (uint64_t) v68)];
        // pto: %126
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1076 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %126
        ;
        uint64_t v1077 = (uint64_t) v33;
        TASSIGN(v1076, v1077);
        pipe_barrier(PIPE_V);
        TMULS(v1076, v963, v1075);
        // pto: %127
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1078 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %127
        ;
        uint64_t v1079 = (uint64_t) v32;
        TASSIGN(v1078, v1079);
        pipe_barrier(PIPE_V);
        TADD(v1078, v1073, v1076);
        // pto: %745, %743
        ;
        float v1080 = (v12)[(int64_t) ((uint64_t) v1003 + (uint64_t) v69)];
        // pto: %128
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1081 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %128
        ;
        uint64_t v1082 = (uint64_t) v33;
        TASSIGN(v1081, v1082);
        pipe_barrier(PIPE_V);
        TMULS(v1081, v979, v1080);
        // pto: %129
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1083 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %129
        ;
        uint64_t v1084 = (uint64_t) v32;
        TASSIGN(v1083, v1084);
        pipe_barrier(PIPE_V);
        TADD(v1083, v1078, v1081);
        // pto: %751, %749
        ;
        float v1085 = (v12)[(int64_t) ((uint64_t) v1003 + (uint64_t) v70)];
        // pto: %130
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1086 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %130
        ;
        uint64_t v1087 = (uint64_t) v33;
        TASSIGN(v1086, v1087);
        pipe_barrier(PIPE_V);
        TMULS(v1086, v995, v1085);
        // pto: %131
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1088 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %131
        ;
        uint64_t v1089 = (uint64_t) v32;
        TASSIGN(v1088, v1089);
        pipe_barrier(PIPE_V);
        TADD(v1088, v1083, v1086);
        // pto: %132
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1090 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %132
        ;
        uint64_t v1091 = (uint64_t) v32;
        TASSIGN(v1090, v1091);
        pipe_barrier(PIPE_V);
        RoundMode v1092 = RoundMode::CAST_RINT;
        SaturationMode v1093 = SaturationMode::ON;
        TCVT(v1090, v1088, v1092, v1093);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1090.SetValidShape(v36, v41);
        // pto: %757
        ;
        __gm__ bfloat16_t* v1094 = PTOAS__GLOBAL_TENSOR_DATA(v137);
        // pto: %757
        ;
        const int64_t v1095 = 8192;
        // pto: %757
        ;
        const int64_t v1096 = 16384;
        // pto: %757
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1097 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %757
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1098 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %757
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1099 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1094 + (v1095 + v921 * v1096), v1097, v1098);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1099, v1090);
        // pto: %760, %758
        ;
        float v1100 = (v11)[(int64_t) ((uint64_t) v999 + (uint64_t) v63)];
        // pto: %134
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1101 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %134
        ;
        uint64_t v1102 = (uint64_t) v23;
        TASSIGN(v1101, v1102);
        TMULS(v1101, v928, v1100);
        // pto: %763, %761
        ;
        float v1103 = (v12)[(int64_t) ((uint64_t) v1003 + (uint64_t) v63)];
        // pto: %135
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1104 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %135
        ;
        uint64_t v1105 = (uint64_t) v31;
        TASSIGN(v1104, v1105);
        TMULS(v1104, v947, v1103);
        // pto: %136
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1106 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %136
        ;
        uint64_t v1107 = (uint64_t) v23;
        TASSIGN(v1106, v1107);
        pipe_barrier(PIPE_V);
        TADD(v1106, v1101, v1104);
        // pto: %769, %767
        ;
        float v1108 = (v12)[(int64_t) ((uint64_t) v1003 + (uint64_t) v53)];
        // pto: %137
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1109 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %137
        ;
        uint64_t v1110 = (uint64_t) v31;
        TASSIGN(v1109, v1110);
        pipe_barrier(PIPE_V);
        TMULS(v1109, v963, v1108);
        // pto: %138
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1111 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %138
        ;
        uint64_t v1112 = (uint64_t) v23;
        TASSIGN(v1111, v1112);
        pipe_barrier(PIPE_V);
        TADD(v1111, v1106, v1109);
        // pto: %775, %773
        ;
        float v1113 = (v12)[(int64_t) ((uint64_t) v1003 + (uint64_t) v71)];
        // pto: %139
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1114 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %139
        ;
        uint64_t v1115 = (uint64_t) v31;
        TASSIGN(v1114, v1115);
        pipe_barrier(PIPE_V);
        TMULS(v1114, v979, v1113);
        // pto: %140
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1116 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %140
        ;
        uint64_t v1117 = (uint64_t) v23;
        TASSIGN(v1116, v1117);
        pipe_barrier(PIPE_V);
        TADD(v1116, v1111, v1114);
        // pto: %781, %779
        ;
        float v1118 = (v12)[(int64_t) ((uint64_t) v1003 + (uint64_t) v49)];
        // pto: %141
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1119 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v934, v41);
        // pto: %141
        ;
        uint64_t v1120 = (uint64_t) v31;
        TASSIGN(v1119, v1120);
        pipe_barrier(PIPE_V);
        TMULS(v1119, v995, v1118);
        // pto: %142
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1121 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %142
        ;
        uint64_t v1122 = (uint64_t) v23;
        TASSIGN(v1121, v1122);
        pipe_barrier(PIPE_V);
        TADD(v1121, v1116, v1119);
        // pto: %143
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1123 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %143
        ;
        uint64_t v1124 = (uint64_t) v23;
        TASSIGN(v1123, v1124);
        pipe_barrier(PIPE_V);
        RoundMode v1125 = RoundMode::CAST_RINT;
        SaturationMode v1126 = SaturationMode::ON;
        TCVT(v1123, v1121, v1125, v1126);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1123.SetValidShape(v36, v41);
        // pto: %787
        ;
        __gm__ bfloat16_t* v1127 = PTOAS__GLOBAL_TENSOR_DATA(v137);
        // pto: %787
        ;
        const int64_t v1128 = 12288;
        // pto: %787
        ;
        const int64_t v1129 = 16384;
        // pto: %787
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1130 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %787
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1131 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %787
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1132 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1127 + (v1128 + v921 * v1129), v1130, v1131);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v1132, v1123);
      };
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  pipe_barrier(PIPE_ALL);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}