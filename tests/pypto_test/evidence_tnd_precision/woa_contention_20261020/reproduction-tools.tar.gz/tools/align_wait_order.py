"""保持wait8的前八项顺序，只扩等待集合到24；原ascending24留档。"""
import ast
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
source = (root/'prefix-wait24.py').read_text()
old = 'for owner in pl.range(24):\n            pl.system.signal_wait'
new = 'for dep in pl.range(24):\n            owner = (8 * (worker % 8) + dep) % 24\n            pl.system.signal_wait'
assert source.count(old) == 1
out = source.replace(old, new)
path = root/'prefix-wait24aligned.py';path.write_text(out);ast.parse(out)
proof = json.loads((root/'PREFIX_SOURCE_PROOF.json').read_text())
proof['arms']['wait24aligned'] = {**proof['arms']['wait24'], 'sha256':hashlib.sha256(path.read_bytes()).hexdigest(), 'wait_order':'first 8 exactly identical to wait8; rotated all24'}
(root/'PREFIX_SOURCE_PROOF.json').write_text(json.dumps(proof,indent=2)+'\n')
for worker in range(48):
 expected=[(8*(worker%8)+i)%24 for i in range(8)]
 actual=[(8*(worker%8)+i)%24 for i in range(24)]
 assert actual[:8]==expected and len(set(actual))==24
(root/'check_prefix_v2.py').write_text((root/'check_prefix.py').read_text().replace("('idle','wait8','wait24')", "('wait24aligned',)").replace('cpu-v1','cpu-v2'))
(root/'check-prefix-v2.sh').write_text((root/'check-prefix.sh').read_text().replace('check_prefix.py','check_prefix_v2.py').replace('cpu-v1','cpu-v2'))
print('new aligned24 source, old wait24 preserved')
