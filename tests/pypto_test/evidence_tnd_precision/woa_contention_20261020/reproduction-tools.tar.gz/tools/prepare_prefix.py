"""纯等待控制：各臂WO-A AST完全相同，AIV不消费业务数据。"""
import ast
import copy
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
parent = root.parent / 'woa-pipeline-20261020/parent-phase1.py'
assert hashlib.sha256(parent.read_bytes()).hexdigest() == 'f22d7d8dd6ef2a48f640b88511c6c32c672ade0b116fa922f18c6a6a23237fe6'
source = ast.parse(parent.read_text())
functions = {n.name: n for n in source.body if isinstance(n, ast.FunctionDef)}
header = [copy.deepcopy(n) for n in source.body if not isinstance(n, ast.FunctionDef)]
helpers = [copy.deepcopy(functions[n]) for n in ('begin', 'publish', 'wait_group')]
proof = {'parent_sha256': hashlib.sha256(parent.read_bytes()).hexdigest(), 'scope': 'WO-A prefix with no business AIV work; not full suffix; no new Native qualification', 'arms': {}}
for name in ('idle', 'wait8', 'wait24'):
    cube = copy.deepcopy(functions['cube'])
    cube.body = copy.deepcopy(cube.body[:6] + [cube.body[-1]])
    assert ast.dump(cube.body[4]) == ast.dump(functions['cube'].body[4])
    vec = copy.deepcopy(functions['vector'])
    vec.body = copy.deepcopy(vec.body[:6])
    if name == 'wait8':
        wait = copy.deepcopy(functions['vector'].body[6])
        wait.body = wait.body[:1]
        vec.body.append(wait)
    elif name == 'wait24':
        vec.body.extend(ast.parse('''if worker < row_tiles * 8:
    for owner in pl.range(24):
        pl.system.signal_wait(signals, [(CORES + owner) * STRIDE], generation)
''').body)
    vec.body.extend(ast.parse('''pl.system.fence()
pl.system.cacheinvalid()
pl.system.fence()
pl.system.bar_all()
''').body)
    vec.body.append(copy.deepcopy(functions['vector'].body[-1]))
    module = ast.Module(body=[*copy.deepcopy(header), *copy.deepcopy(helpers), cube, vec, copy.deepcopy(functions['group']), copy.deepcopy(functions['resident_suffix'])], type_ignores=[])
    path = root / ('prefix-' + name + '.py')
    path.write_text(ast.unparse(ast.fix_missing_locations(module)) + '\n')
    proof['arms'][name] = {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'cube_ast_sha256': hashlib.sha256(ast.dump(cube, include_attributes=False).encode()).hexdigest(), 'vector_business_loads': False, 'wait_owners': {'idle': 0, 'wait8': 8, 'wait24': 24}[name]}
assert len({v['cube_ast_sha256'] for v in proof['arms'].values()}) == 1
(root/'PREFIX_SOURCE_PROOF.json').write_text(json.dumps(proof, indent=2) + '\n')
(root/'parent-phase1.py').write_bytes(parent.read_bytes())
(root/'parent-phase1.json').write_bytes(parent.with_suffix('.json').read_bytes())
print('three identical Cube AST controls prepared')
