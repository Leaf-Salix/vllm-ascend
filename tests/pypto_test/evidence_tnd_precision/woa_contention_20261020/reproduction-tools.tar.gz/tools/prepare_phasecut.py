"""WO-A后单切点：一个PTO顶层内两MIX，保留owner2数学与所有后续依赖。"""
import ast
import copy
import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parent
old=root.parent/'woa-pipeline-20261020'
parent=old/'candidate-owner2.py'
assert hashlib.sha256(parent.read_bytes()).hexdigest()=='399dbc67a1709a5e2fda636afb245d6e6478a5f1cec20763471caae6fd98e54b'
(root/parent.name).write_bytes(parent.read_bytes());(root/parent.with_suffix('.json').name).write_bytes(parent.with_suffix('.json').read_bytes())
tree=ast.parse(parent.read_text());functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
header=[copy.deepcopy(n) for n in tree.body if not isinstance(n,ast.FunctionDef)]
helpers=[copy.deepcopy(functions[n]) for n in ('begin','publish','wait_group')]
current=copy.deepcopy(functions['begin']);current.name='current_generation'
current.body=ast.parse('''offset = core * STRIDE
pl.system.cacheinvalid(signals, [1], [offset])
pl.system.fence()
generation = pl.read(signals, [offset])
return signals, generation
''').body
cube_prefix=copy.deepcopy(functions['cube']);cube_prefix.name='cube_prefix'
cube_prefix.body=copy.deepcopy(cube_prefix.body[:6]+[cube_prefix.body[-1]])
vec_prefix=copy.deepcopy(functions['vector']);vec_prefix.name='vector_prefix'
vec_prefix.body=copy.deepcopy(vec_prefix.body[:6])+ast.parse('''pl.system.fence()
pl.system.cacheinvalid()
pl.system.fence()
pl.system.bar_all()
''').body+[copy.deepcopy(vec_prefix.body[-1])]
cube_tail=copy.deepcopy(functions['cube']);cube_tail.name='cube_tail'
cube_tail.body=copy.deepcopy([cube_tail.body[0],cube_tail.body[1],cube_tail.body[2],cube_tail.body[3],*cube_tail.body[6:]])
cube_tail.body[1].value.func.id='current_generation'
vec_tail=copy.deepcopy(functions['vector']);vec_tail.name='vector_tail'
vec_tail.body=copy.deepcopy([*vec_tail.body[:6],*vec_tail.body[7:]])
vec_tail.body[3].value.func.id='current_generation'
groups=[]
for name in ('prefix','tail'):
 group=copy.deepcopy(functions['group']);group.name='group_'+name
 cluster=group.body[0];cluster.items[0].context_expr.keywords[0].value.value='suffix_'+name
 cluster.body[0].value.func.id='cube_'+name;cluster.body[1].value.func.id='vector_'+name
 groups.append(group)
entry=copy.deepcopy(functions['resident_suffix'])
entry.body=[copy.deepcopy(entry.body[0]),copy.deepcopy(entry.body[0]),copy.deepcopy(entry.body[-1])]
entry.body[0].body[0].value.func.id='group_prefix';entry.body[1].body[0].value.func.id='group_tail'
out=ast.Module(body=[*header,*helpers,current,cube_prefix,vec_prefix,cube_tail,vec_tail,*groups,entry],type_ignores=[])
path=root/'candidate-phasecut.py';path.write_text(ast.unparse(ast.fix_missing_locations(out))+'\n')
# Every arithmetic subtree is copied verbatim; source AST eligibility is not a hardware claim.
assert ast.dump(cube_prefix.body[4])==ast.dump(functions['cube'].body[4])
assert ast.dump(cube_tail.body[5])==ast.dump(functions['cube'].body[7])
assert [ast.dump(n) for n in vec_tail.body[6:]]==[ast.dump(n) for n in functions['vector'].body[7:]]
path.with_suffix('.json').write_text(json.dumps({'parent':'owner2','parent_sha256':hashlib.sha256(parent.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'change':'one orchestration cut after WO-A; one top entry/two MIX with real accum+signals DAG; no AIV polls while WO-A; original math copied AST','scope':'CPU and real task DAG qualification before NPU; not installed','formal_baseline':'48c58ce7c467dfce63d5cb5c41afd225488d6012'},indent=2)+'\n')
probe=(old/'ab_probe_v3.py').read_text().replace("choices=('tailboth','tailowner2','k128owner2')","choices=('phasecut',)").replace("choices=('tailpreload','owner2')","choices=('owner2',)")
a=probe.index("assert (args.variant=='k128owner2'");b=probe.index('sdk=Path(',a)
probe=probe[:a]+"assert args.variant=='phasecut' and args.parent=='owner2' and args.tokens in (126,240)\n"+probe[b:]
probe=probe.replace("experiment=sdk/'woa-pipeline-20261020'","experiment=sdk/'woa-contention-20261020'")
(root/'phasecut_probe.py').write_text(probe)
launcher=(old/'run-v3.sh').read_text().replace('woa-pipeline-20261020/ab_probe_v3.py','woa-contention-20261020/phasecut_probe.py');(root/'run-phasecut.sh').write_text(launcher)
checker=(old/'check_candidates_v11.py').read_text().replace("('m128range','m256range')","('phasecut',)").replace("'woa-pipeline-20261020'/f'candidate-{name}.py'","'woa-contention-20261020'/f'candidate-{name}.py'").replace('woa-pipeline-cpu-v11','woa-phasecut-cpu-v1')
(root/'check_phasecut.py').write_text(checker)
launcher=(root/'check-prefix.sh').read_text().replace('check_prefix.py','check_phasecut.py').replace('woa-contention-cpu-v1','woa-phasecut-cpu-v1');(root/'check-phasecut.sh').write_text(launcher)
print('single-cut candidate prepared; hardware pending')
