"""独立重算18个L1窗口及9份PMU CSV；比例/时间不可加总为stall。"""
import csv
import io
import json
from pathlib import Path
import statistics
import tarfile

root=Path(__file__).resolve().parent
l1=[];pmu={}
with tarfile.open(root/'woa-contention-instruments-v1.tar.gz') as archive:
 for tokens in (126,240):
  case=f'woa-contention-dfx-t{tokens}-v1'
  result=json.loads((root/(case+'.json')).read_text());assert result['pass']
  for entry in result['DFX']['records']:
   window=entry['window'];middle='' if window==0 else f'window_{window}/'
   raw=json.load(archive.extractfile(case+'/dfx/'+middle+'chip_swimlane_records.json'))
   m=raw['metadata'];items=raw['aicore_tasks']
   assert raw['chip_swimlane_level']==1 and m['clock_freq_hz']==50_000_000
   assert m['core_types']==['aic']*24+['aiv']*48 and m['dropped_run_boundaries']==0 and len(m['run_boundaries'])==1
   assert len(items)==72 and {x[0] for x in items}==set(range(72)) and all(len(x)==6 and x[3]<=x[4] for x in items)
   for name,rows in [('total',items),('AIC',[x for x in items if x[0]<24]),('AIV',[x for x in items if x[0]>=24])]:
    expected=entry['total'] if name=='total' else entry['roles'][name]
    assert (max(x[4] for x in rows)-min(x[3] for x in rows))/50==expected['span_us']
   l1.append({'tokens':tokens,**entry})
 keys=('Duration(us)','aicore_time(us)','aic_mac_time(us)','aic_mte1_time(us)','aic_mte2_time(us)','aic_scalar_ratio','aiv_scalar_ratio','aic_mac_ratio','aic_mte2_ratio')
 for side in ('idle','wait8','wait24aligned'):
  members=sorted((m for m in archive.getmembers() if '/'+side+'-pmu-r' in m.name and m.name.endswith('kernel_details.csv')),key=lambda m:m.name)
  assert len(members)==3;samples=[]
  for member in members:
   rows=list(csv.DictReader(io.StringIO(archive.extractfile(member).read().decode())))
   selected=[r for r in rows if r['Name']=='aicore_kernel_mode_0'];assert len(selected)==1
   samples.append({key:float(selected[0][key]) for key in keys})
  pmu[side]={'samples':samples,'median':{key:statistics.median(x[key] for x in samples) for key in keys}}
assert len(l1)==18
(root/'INSTRUMENT_VALIDATION.json').write_text(json.dumps({'pass':True,'scope':'schema/span and device-counter verification; no additive pure-wait/DDR attribution','L1':l1,'PMU':pmu},indent=2)+'\n')
print('18 L1 windows and 9 CSVs independently verified')
