"""各臂AIC实际PTO按SSA双射归一化；保留类型、地址、常量和控制。"""
import hashlib
import json
from pathlib import Path
import re

root=Path(__file__).resolve().parent
paths={name:root/'generated'/('woa-contention-cpu-v2' if name=='wait24aligned' else 'woa-contention-cpu-v1')/name/'ptoas/resident_precision_suffix.pto' for name in ('idle','wait8','wait24aligned')}
def alpha(text):
 # PTO source locations refer only to diagnostics paths; remove the balanced loc("...") spelling.
 text=re.sub(r' loc\("[^"\n]*"(?::[0-9]+(?::[0-9]+)?)?\)', '', text)
 start=text.index('func.func @cube')
 end=text.index('\n  func.func ',start+1)
 text=text[start:end]
 names={}
 def rename(match):
  v=match.group();names.setdefault(v,'%v'+str(len(names)));return names[v]
 return re.sub(r'%[A-Za-z_0-9]+',rename,text)
values={k:alpha(p.read_text()) for k,p in paths.items()}
assert len(set(values.values()))==1
(root/'PREFIX_CODEGEN_PROOF.json').write_text(json.dumps({'pass':True,'scope':'actual AIC PTO alpha-identical with source locations removed; constants/layout/addresses/control preserved','arms':{k:hashlib.sha256(v.encode()).hexdigest() for k,v in values.items()}},indent=2)+'\n')
print('three actual AIC PTO bodies identical')
