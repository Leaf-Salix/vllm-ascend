"""收集本轮8项自有任务最终回执及7个CPU检查身份/失败。"""
import io
import json
from pathlib import Path
import subprocess
import tarfile

sdk=Path('/data/pyptouser/yejia/csa-spmd-sdk-20261020')
root=sdk/'woa-contention-20261020'
runs=json.loads((root/'RUNS.json').read_text())
statuses={}
with tarfile.open(sdk/'woa-contention-run-receipts-v1.tar.gz','w:gz') as archive:
 def blob(name,value):
  data=value.encode();info=tarfile.TarInfo(name);info.size=len(data);archive.addfile(info,io.BytesIO(data))
 for case,item in runs['runs'].items():
  status=subprocess.run(['task-submit','--status',item['task']],capture_output=True,text=True,timeout=30)
  assert status.returncode==0 and f"completed (exit={item['exit_code']})" in status.stdout,(case,status.stdout)
  statuses[case]={'task':item['task'],'status':status.stdout.strip()}
  blob(case+'/task-status.txt',status.stdout+status.stderr)
  log=subprocess.run(['task-submit','--log',item['task']],capture_output=True,text=True,timeout=30)
  blob(case+'/task.log',log.stdout+log.stderr)
  for path in (sdk/'results'/case/'result.json',sdk/'results'/(case+'-run.log')):
   assert path.is_file();archive.add(path,arcname=case+'/'+path.name)
 for case in ('woa-contention-cpu-v1','woa-contention-cpu-v2','woa-phasecut-cpu-v1','woa-phasecut-cpu-v2','woa-phasecut-cpu-v3','woa-quantcut-cpu-v1','woa-quantcut-cpu-v2'):
  path=sdk/'results'/case
  for p in (path/'result.json',sdk/'logs'/(case+'.log')):
   assert p.is_file();archive.add(p,arcname='cpu/'+case+'/'+p.name)
  for p in path.glob('*/kernel_config.py'):
   archive.add(p,arcname='cpu/'+case+'/'+str(p.relative_to(path)))
  for p in path.glob('*/compiled_meta.json'):
   archive.add(p,arcname='cpu/'+case+'/'+str(p.relative_to(path)))
 blob('FINAL_STATUSES.json',json.dumps(statuses,indent=2)+'\n')
print('all own tasks ended:',len(statuses))
