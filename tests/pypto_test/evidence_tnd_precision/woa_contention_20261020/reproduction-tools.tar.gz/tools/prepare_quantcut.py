"""在两MIX父版上仅再切cast/quant到WO-B，数学逐AST复制。"""
import ast
import copy
import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parent
parent=root/'candidate-phasecut-acquire.py'
tree=ast.parse(parent.read_text());f={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
head=[copy.deepcopy(n) for n in tree.body if not isinstance(n,ast.FunctionDef)]
helpers=[copy.deepcopy(f[n]) for n in ('begin','publish','wait_group','current_generation')]
ca=copy.deepcopy(f['cube_prefix']);va=copy.deepcopy(f['vector_prefix'])
ci=copy.deepcopy(f['cube_tail']);ci.name='cube_quant_idle';ci.body=copy.deepcopy(ci.body[:4])+ast.parse('pl.system.bar_all()').body+[copy.deepcopy(ci.body[-1])]
vq=copy.deepcopy(f['vector_tail']);vq.name='vector_quant';vq.body=copy.deepcopy(vq.body[:13])+ast.parse('pl.system.bar_all()').body+[copy.deepcopy(vq.body[-1])]
cb=copy.deepcopy(f['cube_tail']);cb.name='cube_wob';cb.body[4:5]=ast.parse('''pl.system.fence()
pl.system.cacheinvalid()
pl.system.fence()
''').body
vp=copy.deepcopy(f['vector_tail']);vp.name='vector_post';vp.body=copy.deepcopy(vp.body[:6]+vp.body[13:])
assert [ast.dump(n) for n in vq.body[6:13]]==[ast.dump(n) for n in f['vector_tail'].body[6:13]]
assert ast.dump(cb.body[7])==ast.dump(f['cube_tail'].body[5])
assert [ast.dump(n) for n in vp.body[6:]]==[ast.dump(n) for n in f['vector_tail'].body[13:]]
groups=[copy.deepcopy(f['group_prefix'])]
for name,cube,vec in [('quant','cube_quant_idle','vector_quant'),('post','cube_wob','vector_post')]:
 g=copy.deepcopy(f['group_tail']);g.name='group_'+name;cluster=g.body[0];cluster.items[0].context_expr.keywords[0].value.value='suffix_'+name
 cluster.body[0].value.func.id=cube;cluster.body[1].value.func.id=vec;groups.append(g)
entry=copy.deepcopy(f['resident_suffix']);entry.body=[copy.deepcopy(entry.body[0]),copy.deepcopy(entry.body[1]),copy.deepcopy(entry.body[1]),copy.deepcopy(entry.body[-1])]
entry.body[1].body[0].value.func.id='group_quant';entry.body[2].body[0].value.func.id='group_post'
module=ast.Module(body=[*head,*helpers,ca,va,ci,vq,cb,vp,*groups,entry],type_ignores=[])
out=root/'candidate-quantcut.py';out.write_text(ast.unparse(ast.fix_missing_locations(module))+'\n')
out.with_suffix('.json').write_text(json.dumps({'parent':'phasecut-acquire','parent_sha256':hashlib.sha256(parent.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'change':'one extra task cut after original BF16 cast/global8192 quant; middle AIC idle; final WOB uses completed quant via DAG with payload acquire; no math changes','scope':'one top entry/three MIX; CPU/DAG/NPU qualification required, not installed','formal_baseline':'48c58ce7c467dfce63d5cb5c41afd225488d6012'},indent=2)+'\n')
s=(root/'phasecut_acquire_probe.py').read_text().replace("choices=('phasecut-acquire',)","choices=('quantcut',)").replace("choices=('owner2',)","choices=('phasecut-acquire',)").replace("args.variant=='phasecut-acquire' and args.parent=='owner2'","args.variant=='quantcut' and args.parent=='phasecut-acquire'")
(root/'quantcut_probe.py').write_text(s)
(root/'run-quantcut.sh').write_text((root/'run-phasecut-acquire.sh').read_text().replace('phasecut_acquire_probe.py','quantcut_probe.py'))
(root/'check_quantcut.py').write_text((root/'check_phasecut_v3.py').read_text().replace("('phasecut-acquire',)","('quantcut',)").replace('woa-phasecut-cpu-v3','woa-quantcut-cpu-v1'))
(root/'check-quantcut.sh').write_text((root/'check-phasecut-v3.sh').read_text().replace('check_phasecut_v3.py','check_quantcut.py').replace('woa-phasecut-cpu-v3','woa-quantcut-cpu-v1'))
print('three-MIX incremental cut prepared')
