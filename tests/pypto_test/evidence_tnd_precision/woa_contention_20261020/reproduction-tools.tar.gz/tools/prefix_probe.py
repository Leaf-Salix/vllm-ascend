"""常驻后缀对冻结PTO数学的FULL graph逐位与交替性能；非整层/整模型结论。"""
import argparse
import hashlib
import importlib
import importlib.util
import json
import os
from pathlib import Path
import runpy
import statistics
import sys
import time
import traceback

parser=argparse.ArgumentParser()
parser.add_argument('--tokens',type=int,required=True)
parser.add_argument('--out',type=Path,required=True)
parser.add_argument('--mode',choices=('timing','dfx'),required=True)
args=parser.parse_args()
assert args.tokens in (126,240)
sdk=Path('/data/pyptouser/yejia/csa-spmd-sdk-20261020')
sys.argv=[str(sdk/'sdk-preflight.py')]
runpy.run_path(sys.argv[0],run_name='__main__')
import torch
import torch_npu
import pypto.torch
from vllm.engine.arg_utils import EngineArgs
from vllm.platforms import current_platform
from dsv4_csa_native_case import native_session
from dsv4_csa_single_layer import make_layer

args.out.mkdir(exist_ok=False)
report={'pass':False,'complete':False,'tokens':args.tokens,'scope':'pure AIV waiting intervention beside identical WO-A; real L4 weights, synthetic heads; gold full phase1 valid FP32 accum; not new Native qualification','source_baseline':'48c58ce7c467dfce63d5cb5c41afd225488d6012','layout_scope':'token-row suffix only; no request metadata, not a full TND admission test','started_unix':time.time()}
def save():
 (args.out/'result.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
def sha(t):
 c=t.detach().cpu().contiguous();return hashlib.sha256(c.view(torch.uint8).numpy().tobytes()).hexdigest()
def bit_equal(a,b):
 return a.shape==b.shape and a.dtype==b.dtype and torch.equal(a.contiguous().view(torch.uint8),b.contiguous().view(torch.uint8))
current_platform.pre_register_and_update()
torch.npu.set_device(0)
torch.npu.config.allow_internal_format=True
torch.use_deterministic_algorithms(True)
torch_npu.npu.set_deterministic_level(1)
torch.set_num_threads(4)
from vllm_ascend.utils import enable_custom_op
assert enable_custom_op()
import vllm_ascend.ops.pypto as namespace
source_root=Path(os.environ['SOURCE_ROOT'])
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.o_proj import o_proj_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.hc_post import hc_post_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.oproj_order_data import OPROJ_TILE_STARTS,OPROJ_TOKEN_MODES
spec=importlib.util.spec_from_file_location('private_resident_suffix_device',sdk/'woa-contention-20261020/parent-phase1.py')
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
proof=json.loads((sdk/'RESIDENT_SUFFIX_SOURCE_PROOF.json').read_text())
assert hashlib.sha256((sdk/'woa-contention-20261020/parent-phase1.py').read_bytes()).hexdigest()=='f22d7d8dd6ef2a48f640b88511c6c32c672ade0b116fa922f18c6a6a23237fe6'
assert all(hashlib.sha256((source_root/n).read_bytes()).hexdigest()==h for n,h in proof['sources'].items())
assert proof['candidate_sha256']=='a31a78f89e1ed71c007de2b692434cc0a0f1bc35626b22188418b3e715edd022'
actual_modules={}
for name,relative in (
 ('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.o_proj','vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision/o_proj.py'),
 ('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.hc_post','vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision/hc_post.py')):
 imported=importlib.import_module(name)
 actual=Path(imported.__file__).resolve()
 assert actual==(source_root/relative).resolve(),(name,str(actual))
 assert hashlib.sha256(actual.read_bytes()).hexdigest()==proof['sources'][relative]
 actual_modules[name]={'path':str(actual),'sha256':proof['sources'][relative]}
report['baseline_actual_modules']=actual_modules
report['harness_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
report['PTOAS_ROOT']=os.environ['PTOAS_ROOT']
assert Path(report['PTOAS_ROOT']).resolve()==sdk/'toolchain-wheel'
report['sdk_preflight']=json.loads((sdk/'results/pypto-import-preflight.json').read_text())
report['source_proof']=proof
experiment=sdk/'woa-contention-20261020'
prefix_proof=json.loads((experiment/'PREFIX_SOURCE_PROOF.json').read_text())
assert prefix_proof['parent_sha256']=='f22d7d8dd6ef2a48f640b88511c6c32c672ade0b116fa922f18c6a6a23237fe6'
report['prefix_proof']=prefix_proof
report['mode']=args.mode
checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
tokens=args.tokens
config=EngineArgs(model=str(checkpoint),tokenizer_mode='deepseek_v4',trust_remote_code=True,
 tensor_parallel_size=1,dtype='bfloat16',quantization='ascend',hf_overrides={'sliding_window':128},
 max_model_len=16384,max_num_seqs=40,max_num_batched_tokens=256,enable_prefix_caching=False,
 enforce_eager=False,block_size=32,speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},
 compilation_config={'cudagraph_mode':'FULL_DECODE_ONLY','cudagraph_capture_sizes':[tokens],'cache_dir':str(args.out/'vllm-cache')},
 additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,'fuse_norm_quant':True,'align_decode_capture_sizes':False},
 'enable_cpu_binding':False,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False}).create_engine_config()
save()
try:
 with native_session(config,0),torch.inference_mode():
  layer,details=make_layer(config,checkpoint,torch.device('npu:0'),4)
  report['weight_details']=details
  wo_a=layer.self_attn.wo_a.weight.detach();wo_b=layer.self_attn.wo_b.weight.detach()
  channel=layer.self_attn.wo_b.weight_scale.detach().reshape(-1).float().contiguous()
  assert wo_a.shape==(8,4096,1024) and wo_a.dtype==torch.bfloat16 and torch_npu.get_npu_format(wo_a)==29
  assert wo_b.shape==(8192,4096) and wo_b.dtype==torch.int8 and torch_npu.get_npu_format(wo_b)==29
  assert torch.count_nonzero(layer.self_attn.wo_b.weight_offset).cpu()==0
  start=torch.tensor(OPROJ_TILE_STARTS[OPROJ_TOKEN_MODES[tokens-1]],device='npu',dtype=torch.int32)
  torch.manual_seed(4190+tokens);torch.npu.manual_seed(4190+tokens)
  guarded=[]
  def buffer(shape,dtype,fill=-91):
   owner=torch.full((shape[0]+32,*shape[1:]),fill,dtype=dtype,device='npu')
   value=owner[16:16+shape[0]];guarded.append((owner,shape[0],fill));return value
  heads=buffer((tokens,32768),torch.bfloat16);heads.normal_(0,0.03)
  residual=buffer((tokens,16384),torch.bfloat16);residual.normal_(0,0.1)
  post=buffer((tokens,4),torch.float32);post.uniform_(0,1)
  comb=buffer((tokens,16),torch.float32);comb.uniform_(0,0.25)
  original_heads=heads.clone()
  bundles={};signal_owners={};ops={}
  for side in ('gold','idle','wait8','wait24aligned'):
   b={
    'projected':buffer((tokens,8192),torch.bfloat16),
    'quantized':buffer((tokens,8192),torch.int8),
    'token_scale':buffer((tokens,1),torch.float32),
    'attended':buffer((tokens,4096),torch.bfloat16),
    'output':buffer((tokens,16384),torch.bfloat16),
    'accum':buffer((tokens+127,8192),torch.float32),
    'integer':buffer((tokens+63,4096),torch.int32)}
   owner=torch.full((module.WORDS+256,),-91,device='npu',dtype=torch.int32)
   signal_owners[side]=owner;b['signals']=owner[128:-128];b['signals'].zero_()
   bundles[side]=b
  addresses=[v.data_ptr() for b in bundles.values() for v in b.values()]
  assert len(set(addresses))==len(addresses)==32
  readonly_tensors={'heads':heads,'wo_a':wo_a,'wo_b':wo_b,'channel':channel,'start':start,'residual':residual,'post':post,'comb':comb}
  readonly={n:sha(v) for n,v in readonly_tensors.items()}
  report['readonly_sha256']=readonly
  if args.mode=='dfx':
   pypto.torch.init(enable_chip_swimlane=1,enable_dep_gen=False,output_dir=str(args.out/'dfx'))
  else:pypto.torch.init()
  ops['gold']=pypto.torch.register(module.resident_suffix,'woa_wait_test::gold_phase1')
  for side in ('idle','wait8','wait24aligned'):
   path=experiment/('prefix-'+side+'.py')
   assert hashlib.sha256(path.read_bytes()).hexdigest()==prefix_proof['arms'][side]['sha256']
   spec=importlib.util.spec_from_file_location('woa_wait_'+side,path)
   current=importlib.util.module_from_spec(spec);sys.modules[spec.name]=current;spec.loader.exec_module(current)
   ops[side]=pypto.torch.register(current.resident_suffix,'woa_wait_test::'+side)
  arms=('idle','wait8','wait24aligned')
  def launch(side):
   b=bundles[side]
   ops[side](heads,wo_a,wo_b,channel,start,b['projected'],b['quantized'],b['token_scale'],b['attended'],residual,post,comb,b['output'],b['accum'],b['integer'],b['signals'])
  def guards():
   for owner,rows,fill in guarded:
    assert torch.all(owner[:16].cpu()==fill) and torch.all(owner[16+rows:].cpu()==fill),'outer guard modified'
   for side,owner in signal_owners.items():
    assert torch.all(owner[:128].cpu()==-91) and torch.all(owner[-128:].cpu()==-91),'signal guard modified'
    assert torch.all(bundles[side]['accum'][tokens:].cpu()==-91),'accum padded rows modified'
   for side in arms:
    for key in ('projected','quantized','token_scale','attended','output','integer'):
     assert torch.all(bundles[side][key].cpu()==-91),'unexpected business stage executed: '+side+'.'+key
  def generation(side):
   words=bundles[side]['signals'].cpu().reshape(6,72,128)
   assert torch.count_nonzero(words[:,:,1:])==0
   g=int(words[0,0,0]);assert g>0
   used=torch.zeros((6,72),dtype=torch.bool);used[0,:]=True;used[1,:24]=True
   assert torch.all(words[:,:,0][used]==g) and torch.count_nonzero(words[:,:,0][~used])==0
   return g
  def poison():
   for side in arms:bundles[side]['accum'][:tokens].fill_(float('nan'))
  def compare(label,golden):
   results={}
   for side in arms:
    actual=bundles[side]['accum'][:tokens].cpu();assert torch.isfinite(actual).all()
    equal=bit_equal(actual,golden)
    results[side]={'bit_equal':equal,'different_elements':int((actual!=golden).sum()),'max_abs':float((actual-golden).abs().max()),'first':(actual!=golden).nonzero()[:4].tolist()}
   report.setdefault('comparisons',{})[label]=results;save();guards()
   assert len({generation(s) for s in arms})==1
   if not all(v['bit_equal'] for v in results.values()):
    torch.save({'gold':golden,**{s:bundles[s]['accum'][:tokens].cpu() for s in arms}},args.out/'first-difference.pt')
    raise RuntimeError('first prefix difference '+label)
  launch('gold');torch.npu.synchronize()
  gold_a=bundles['gold']['accum'][:tokens].cpu().clone()
  assert torch.isfinite(gold_a).all()
  poison()
  for side in arms:launch(side)
  torch.npu.synchronize();compare('eager_A',gold_a)
  graphs={};stream=torch.npu.Stream();stream.wait_stream(torch.npu.current_stream())
  with torch.npu.stream(stream):
   for side in arms:
    graph=torch.npu.NPUGraph()
    with torch.npu.graph(graph,stream=stream):launch(side)
    graphs[side]=graph
   torch.npu.synchronize()
   before={s:generation(s) for s in arms};poison()
   for side in arms:graphs[side].replay()
   torch.npu.synchronize()
   assert all(generation(s)==before[s]+1 for s in arms);compare('FULL_A',gold_a)
   heads.add_(0.03125);launch('gold');torch.npu.synchronize()
   gold_b=bundles['gold']['accum'][:tokens].cpu().clone();assert not bit_equal(gold_a,gold_b)
   poison()
   for side in arms:graphs[side].replay()
   torch.npu.synchronize();compare('FULL_B',gold_b)
   heads.copy_(original_heads);poison()
   for side in arms:graphs[side].replay()
   torch.npu.synchronize();compare('FULL_A_restore',gold_a)
   if args.mode=='timing':
    samples={str(count):{s:[] for s in arms} for count in (1,100)}
    for window in range(12):
     counts=(1,100) if window%2==0 else (100,1)
     for count in counts:
      order=list(arms);shift=window%3;order=order[shift:]+order[:shift]
      if window%2:order.reverse()
      before={s:generation(s) for s in arms}
      for side in order:
       begin,end=torch.npu.Event(enable_timing=True),torch.npu.Event(enable_timing=True)
       begin.record()
       for _ in range(count):graphs[side].replay()
       end.record();end.synchronize()
       samples[str(count)][side].append(begin.elapsed_time(end)*1000/count)
      assert all(generation(s)==before[s]+count for s in arms)
      compare('window_'+str(window)+'_replays_'+str(count),gold_a)
    report['timings']={'unit':'us/WO-A prefix FULL replay','windows':12,'counts':[1,100],'outliers_removed':False,'samples':samples,'summary':{count:{s:{'min':min(v),'median':statistics.median(v),'mean':statistics.mean(v),'max':max(v)} for s,v in values.items()} for count,values in samples.items()}}
   else:
    records=[];counter=0
    for repeat in range(3):
     order=list(arms);shift=repeat%3;order=order[shift:]+order[:shift]
     if repeat%2:order.reverse()
     for side in order:
      before={s:generation(s) for s in arms}
      pypto.torch.begin_dfx();graphs[side].replay();pypto.torch.end_dfx()
      assert all(generation(s)==before[s]+int(s==side) for s in arms)
      guards()
      path=args.out/'dfx'
      if counter:path=path/('window_'+str(counter))
      raw=json.loads((path/'chip_swimlane_records.json').read_text());meta=raw['metadata'];items=raw['aicore_tasks']
      assert raw['chip_swimlane_level']==1 and meta['core_types']==['aic']*24+['aiv']*48
      assert meta['clock_freq_hz']==50000000 and meta['dropped_run_boundaries']==0 and len(meta['run_boundaries'])==1
      assert len(items)==72 and all(len(x)==6 and x[3]<=x[4] for x in items) and {x[0] for x in items}==set(range(72))
      def span(rows):return {'span_us':(max(x[4] for x in rows)-min(x[3] for x in rows))/50,'max_core_us':max(x[4]-x[3] for x in rows)/50,'records':len(rows)}
      records.append({'side':side,'repeat':repeat,'window':counter,'total':span(items),'roles':{'AIC':span([x for x in items if x[0]<24]),'AIV':span([x for x in items if x[0]>=24])}});counter+=1
     compare('post_dfx_'+str(repeat),gold_a)
    report['DFX']={'records':records,'scope':'identical AIC WO-A with different pure AIV waiting; role spans not pure transfer stall'}
  assert readonly=={n:sha(v) for n,v in readonly_tensors.items()}
  report['final_generation']={s:generation(s) for s in arms}
  expected=1216 if args.mode=='timing' else 7
  assert set(report['final_generation'].values())=={expected}
  report['actual_acl_graph']=True;report['guards']=True;report['readonly']=True
  report['pass']=report['complete']=True;save()
except BaseException:
 report['error']=traceback.format_exc();save();raise
finally:
 report['finished_unix']=time.time();save()
