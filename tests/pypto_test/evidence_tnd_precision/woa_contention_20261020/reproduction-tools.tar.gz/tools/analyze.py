"""重算同任务对照及逐位/代际门禁，原始JSON不改写。"""
import json
import statistics
from pathlib import Path

root=Path(__file__).resolve().parent
rows=[]
for path in sorted(root.glob('woa-contention-*.json')):
 r=json.loads(path.read_text())
 if 'comparisons' not in r:continue
 assert r['pass'] and r['complete'] and r['guards'] and r['readonly'] and r['actual_acl_graph']
 checks=[v for g in r['comparisons'].values() for v in g.values()]
 assert all(v['bit_equal'] and v['different_elements']==0 for v in checks)
 row={'case':path.stem,'tokens':r['tokens'],'checks':len(checks),'probe_seconds':r['finished_unix']-r['started_unix']}
 if 'timings' in r and r['timings'].get('counts'):
  assert len(checks)==84 and set(r['final_generation'].values())=={1216}
  result={}
  for count,arms in r['timings']['samples'].items():
   assert all(len(v)==12 for v in arms.values())
   med={s:statistics.median(v) for s,v in arms.items()}
   assert all(med[s]==r['timings']['summary'][count][s]['median'] for s in arms)
   result[count]={'median_us':med,'wait8_vs_idle_percent':100*(med['wait8']/med['idle']-1),'wait24_vs_idle_percent':100*(med['wait24aligned']/med['idle']-1),'wait8_slower_windows':sum(a>b for a,b in zip(arms['wait8'],arms['idle'])),'wait24_slower_windows':sum(a>b for a,b in zip(arms['wait24aligned'],arms['idle']))}
  row['scope']='pure AIV-wait control, valid FP32 accum';row['timings']=result
 elif 'timings' in r:
  assert len(checks)==160 and set(r['final_generation'].values())=={1204}
  samples=r['timings']['samples'];med={s:statistics.median(v) for s,v in samples.items()}
  assert all(med[s]==r['timings']['summary'][s]['median'] for s in samples)
  row['scope']='complete suffix five boundaries, frozen PTO gold'
  row['timings']={'median_us':med,'new_vs_parent_percent':100*(med['new']/med['resident']-1),'new_vs_frozen_percent':100*(med['new']/med['frozen']-1),'new_faster_parent_windows':sum(a<b for a,b in zip(samples['new'],samples['resident'])),'new_faster_frozen_windows':sum(a<b for a,b in zip(samples['new'],samples['frozen']))}
 else:
  assert len(checks)==21 and set(r['final_generation'].values())=={7}
  row['scope']='independent pure-wait instrument task; not formal timing'
 rows.append(row)
(root/'RESULT_VALIDATION.json').write_text(json.dumps({'pass':True,'rows':rows},indent=2)+'\n')
for row in rows:print(row['case'],row['checks'],row.get('timings','instrument'))
