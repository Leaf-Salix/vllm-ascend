"""修复同cluster两个AIV入口歧义：中段单AIV函数、显式48个逻辑worker。"""
import ast
import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parent
tree=ast.parse((root/'candidate-quantcut.py').read_text())
f={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
quant=f['vector_quant']
assert ast.unparse(quant.body[0]).startswith('pl.func_attr')
quant.body=quant.body[1:]
quant.body[0]=ast.parse('worker = pl.tile.get_block_idx()').body[0]
group=f['group_quant'];cluster=group.body[0]
assert len(cluster.body)==2 and cluster.body[0].value.func.id=='cube_quant_idle'
cluster.body=cluster.body[1:]
entry=f['resident_suffix'];middle=entry.body[1]
assert middle.items[0].context_expr.args[0].value==24
middle.items[0].context_expr.args[0].value=48
tree.body=[n for n in tree.body if not isinstance(n,ast.FunctionDef) or n.name!='cube_quant_idle']
path=root/'candidate-quantcut-aiv.py';path.write_text(ast.unparse(ast.fix_missing_locations(tree))+'\n')
proof=json.loads((root/'candidate-quantcut.json').read_text());proof['candidate_sha256']=hashlib.sha256(path.read_bytes()).hexdigest();proof['change']='one extra task cut after cast/global8192 quant; middle only one AIV kernel with 48 flat workers instead of split24; no math/ownership change; third WOB via completed quant DAG with original payload acquire';proof['scope']='one root: MIX24/AIV48/MIX24; full CPU/actual role map/NPU qualification required';path.with_suffix('.json').write_text(json.dumps(proof,indent=2)+'\n')
(root/'quantcut_aiv_probe.py').write_text((root/'quantcut_probe.py').read_text().replace("choices=('quantcut',)","choices=('quantcut-aiv',)").replace("args.variant=='quantcut'","args.variant=='quantcut-aiv'"))
(root/'run-quantcut-aiv.sh').write_text((root/'run-quantcut.sh').read_text().replace('quantcut_probe.py','quantcut_aiv_probe.py'))
(root/'check_quantcut_v2.py').write_text((root/'check_quantcut.py').read_text().replace("('quantcut',)","('quantcut-aiv',)").replace('woa-quantcut-cpu-v1','woa-quantcut-cpu-v2'))
(root/'check-quantcut-v2.sh').write_text((root/'check-quantcut.sh').read_text().replace('check_quantcut.py','check_quantcut_v2.py').replace('cpu-v1','cpu-v2'))
print('explicit AIV48 variant prepared')
