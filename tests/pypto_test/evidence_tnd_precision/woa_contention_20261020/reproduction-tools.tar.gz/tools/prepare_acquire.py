"""保留首稿，单独派生带原业务payload acquire的两MIX候选。"""
import ast
import copy
import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parent
source=ast.parse((root/'candidate-phasecut.py').read_text())
parent=ast.parse((root/'candidate-owner2.py').read_text())
vector=next(n for n in parent.body if isinstance(n,ast.FunctionDef) and n.name=='vector')
tail=next(n for n in source.body if isinstance(n,ast.FunctionDef) and n.name=='vector_tail')
acquire=copy.deepcopy(vector.body[6]);acquire.body=acquire.body[1:];assert len(acquire.body)==3
tail.body.insert(6,acquire)
path=root/'candidate-phasecut-acquire.py'
code=ast.unparse(ast.fix_missing_locations(source))+'\n'
assert not path.exists() or path.read_text()==code
path.write_text(code)
proof=json.loads((root/'candidate-phasecut.json').read_text())
proof['candidate_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
proof['change']+='; preserve original payload acquire after task completion, separate from phase0 signal acquire'
path.with_suffix('.json').write_text(json.dumps(proof,indent=2)+'\n')
