#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void vector_quant(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ bfloat16_t* v6, __gm__ int8_t* v7, __gm__ float* v8, __gm__ bfloat16_t* v9, __gm__ bfloat16_t* v10, __gm__ float* v11, __gm__ float* v12, __gm__ bfloat16_t* v13, __gm__ float* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v22 = 0;
  // pto: %c65536_i64
  const int64_t v23 = 65536;
  // pto: %c98304_i64
  const int64_t v24 = 98304;
  // pto: %c98336_i64
  const int64_t v25 = 98336;
  // pto: %c1_index
  const int64_t v26 = 1;
  // pto: %c8_index
  const int64_t v27 = 8;
  // pto: %c16_index
  const int64_t v28 = 16;
  // pto: %c128_index
  const int64_t v29 = 128;
  // pto: %c8192_index
  const int64_t v30 = 8192;
  // pto: %c55296_index
  const int64_t v31 = 55296;
  // pto: %c24_index
  const int64_t v32 = 24;
  // pto: %c0_index
  const int64_t v33 = 0;
  // pto: %c15_index
  const int64_t v34 = 15;
  // pto: %c48_index
  const int64_t v35 = 48;
  // pto: %c1024_index
  const int64_t v36 = 1024;
  // pto: %c18432_index
  const int64_t v37 = 18432;
  // pto: %c7_index
  const int64_t v38 = 7;
  // pto: %c2_index
  const int64_t v39 = 2;
  // pto: %c21504_index
  const int64_t v40 = 21504;
  // pto: %cst_31
  const float v41 = 0.00787401571f;
  // pto: %cst_32
  const float v42 = 0.0f;
  // pto: %cst_33
  const float v43 = 1.0f;
  // pto: %cst_34
  const float v44 = 127.0f;
  // pto: %c27648_index
  const int64_t v45 = 27648;
  // pto: %projected__ssa_v0_view
  const int64_t v46 = 1;
  // pto: %projected__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %projected__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %projected__ssa_v0_view
  int64_t v49 = (int64_t) v17;
  // pto: %projected__ssa_v0_view
  int64_t v50 = v49 * v30;
  // pto: %projected__ssa_v0_view
  int64_t v51 = v48 * v50;
  // pto: %projected__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v52 = pto::Shape<1, 1, 1, -1, -1>(v46, v47, v48, v49, v30);
  // pto: %projected__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v53 = pto::Stride<-1, -1, -1, -1, -1>(v47 * v51, v51, v50, v30, v26);
  // pto: %projected__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v54 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v52, v53);
  // pto: %quantized__ssa_v0_view
  const int64_t v55 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v57 = 1;
  // pto: %quantized__ssa_v0_view
  int64_t v58 = (int64_t) v17;
  // pto: %quantized__ssa_v0_view
  int64_t v59 = v58 * v30;
  // pto: %quantized__ssa_v0_view
  int64_t v60 = v57 * v59;
  // pto: %quantized__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v61 = pto::Shape<1, 1, 1, -1, -1>(v55, v56, v57, v58, v30);
  // pto: %quantized__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v62 = pto::Stride<-1, -1, -1, -1, -1>(v56 * v60, v60, v59, v30, v26);
  // pto: %quantized__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v63 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v61, v62);
  // pto: %token_scale__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %token_scale__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %token_scale__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %token_scale__ssa_v0_view
  int64_t v67 = (int64_t) v17;
  // pto: %token_scale__ssa_v0_view
  int64_t v68 = v67 * v26;
  // pto: %token_scale__ssa_v0_view
  int64_t v69 = v66 * v68;
  // pto: %token_scale__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v70 = pto::Shape<1, 1, 1, -1, -1>(v64, v65, v66, v67, v26);
  // pto: %token_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v71 = pto::Stride<-1, -1, -1, -1, -1>(v65 * v69, v69, v68, v26, (int64_t) v17);
  // pto: %token_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v72 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v8, v70, v71);
  // pto: %accum__ssa_v0_view
  const int64_t v73 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v74 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %accum__ssa_v0_view
  int64_t v76 = (int64_t) v18;
  // pto: %accum__ssa_v0_view
  int64_t v77 = v76 * v30;
  // pto: %accum__ssa_v0_view
  int64_t v78 = v75 * v77;
  // pto: %accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v79 = pto::Shape<1, 1, 1, -1, -1>(v73, v74, v75, v76, v30);
  // pto: %accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v80 = pto::Stride<-1, -1, -1, -1, -1>(v74 * v78, v78, v77, v30, v26);
  // pto: %accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v81 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v79, v80);
  // pto: %signals__ssa_v0_view
  const int64_t v82 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v83 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v84 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v85 = 1;
  // pto: %signals__ssa_v0_view
  int64_t v86 = v31 * v26;
  // pto: %signals__ssa_v0_view
  int64_t v87 = v85 * v86;
  // pto: %signals__ssa_v0_view
  int64_t v88 = v84 * v87;
  // pto: %signals__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v89 = pto::Shape<1, 1, 1, 1, -1>(v82, v83, v84, v85, v31);
  // pto: %signals__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v90 = pto::Stride<-1, -1, -1, -1, -1>(v83 * v88, v88, v87, v86, v26);
  // pto: %signals__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v91 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v89, v90);
  // pto: %worker__ssa_v0
  int64_t v92 = (int64_t) v20;
  // pto: %0, %1
  int64_t v93 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v92 + (uint64_t) v32) * (uint64_t) v29);
  // pto: %2
  int64_t v94 = v93 < v33 ? v33 : v93;
  // pto: %signals__ssa_v0_pview
  __gm__ int32_t* v95 = PTOAS__GLOBAL_TENSOR_DATA(v91);
  // pto: %signals__ssa_v0_pview
  const int64_t v96 = 0;
  // pto: %signals__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 1> v97 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  pto::Stride<1, 1, 1, 1, 1> v98 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v99 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v95 + (v96 + v94), v97, v98);
  __gm__ int32_t* v100 = PTOAS__GLOBAL_TENSOR_DATA(v99);
  PTOAS__DCCI_SINGLE_CACHE_LINE(v100);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  // pto: %generation_inline0__tile
  int32_t v101 = (v16)[v93];
  // pto: %3, %4, %5
  int64_t v102 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v17 + (uint64_t) v34) / v28) * (uint64_t) v27);
  // pto: %6
  if (v92 < v102) {
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
  }
  for (int64_t v103 = v92; v103 < v102; v103 += v35) {
    // pto: %8, %9
    ;
    int64_t v104 = (int64_t) ((uint64_t) (v103 / v27) * (uint64_t) v28);
    // pto: %10
    ;
    int64_t v105 = v103 % v27;
    // pto: %11, %12, %13
    ;
    int64_t v106 = v105 < v33 ? (int64_t) ((uint64_t) v105 + (uint64_t) v27) : v105;
    // pto: %14
    ;
    int64_t v107 = (int64_t) ((uint64_t) v106 * (uint64_t) v36);
    // pto: %15
    ;
    int64_t v108 = (int64_t) ((uint64_t) v17 - (uint64_t) v104);
    // pto: %16
    ;
    int64_t v109 = v108 < v28 ? v108 : v28;
    // pto: %oa_value__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v109, v36);
    // pto: %oa_value__ssa_v0
    ;
    uint64_t v111 = (uint64_t) v22;
    TASSIGN(v110, v111);
    // pto: %17
    ;
    int64_t v112 = v104 < v33 ? v33 : v104;
    // pto: %18
    ;
    int64_t v113 = v107 < v33 ? v33 : v107;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v114 = 0;
    // pto: %accum__ssa_v0_pview
    ;
    __gm__ float* v115 = PTOAS__GLOBAL_TENSOR_DATA(v81);
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v116 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v117 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v118 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    int64_t v119 = v109 * v30;
    // pto: %accum__ssa_v0_pview
    ;
    int64_t v120 = v118 * v119;
    // pto: %accum__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1024> v121 = pto::Shape<1, 1, 1, -1, 1024>(v116, v117, v118, v109, v36);
    // pto: %accum__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v122 = pto::Stride<-1, -1, -1, -1, -1>(v117 * v120, v120, v119, v30, v26);
    // pto: %accum__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v123 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v115 + (v114 + v112 * v30 + v113 * v26), v121, v122);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v110, v123);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %t__tmp_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v109, v36);
    // pto: %t__tmp_v0
    ;
    uint64_t v125 = (uint64_t) v22;
    TASSIGN(v124, v125);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v126 = RoundMode::CAST_RINT;
    SaturationMode v127 = SaturationMode::ON;
    TCVT(v124, v110, v126, v127);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v128 = 0;
    // pto: %projected__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v129 = PTOAS__GLOBAL_TENSOR_DATA(v54);
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v130 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v131 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v132 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    int64_t v133 = v109 * v30;
    // pto: %projected__ssa_v0_pview
    ;
    int64_t v134 = v132 * v133;
    // pto: %projected__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1024> v135 = pto::Shape<1, 1, 1, -1, 1024>(v130, v131, v132, v109, v36);
    // pto: %projected__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v136 = pto::Stride<-1, -1, -1, -1, -1>(v131 * v134, v134, v133, v30, v26);
    // pto: %projected__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v137 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v129 + (v128 + v112 * v30 + v113 * v26), v135, v136);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v137, v124);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %22
  int64_t v138 = (int64_t) ((uint64_t) v93 + (uint64_t) v37);
  // pto: %23
  int64_t v139 = v138 < v33 ? v33 : v138;
  // pto: %signals__ssa_v1_signal_pview
  __gm__ int32_t* v140 = PTOAS__GLOBAL_TENSOR_DATA(v91);
  // pto: %signals__ssa_v1_signal_pview
  const int64_t v141 = 0;
  // pto: %signals__ssa_v1_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v142 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v143 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v144 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v140 + (v141 + v139), v142, v143);
  pto::comm::NotifyOp v145 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v144, v101, v145);
  // pto: %24, %25
  int64_t v146 = (int64_t) ((uint64_t) v17 + (uint64_t) v38) / v27;
  // pto: %26
  if (v92 < v146) {
    for (int64_t v147 = v33; v147 < v27; v147 += v26) {
      // pto: %27, %28, %29, %30
      ;
      int64_t v148 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) (v92 / v39) * (uint64_t) v27) + (uint64_t) v147) % v35;
      // pto: %31, %32, %33
      ;
      int64_t v149 = v148 < v33 ? (int64_t) ((uint64_t) v148 + (uint64_t) v35) : v148;
      // pto: %34, %35
      ;
      int64_t v150 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v149 * (uint64_t) v29) + (uint64_t) v40);
      // pto: %36
      ;
      int64_t v151 = v150 < v33 ? v33 : v150;
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      __gm__ int32_t* v152 = PTOAS__GLOBAL_TENSOR_DATA(v91);
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      const int64_t v153 = 0;
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      pto::Shape<1, 1, 1, 1, 1> v154 = pto::Shape<1, 1, 1, 1, 1>();
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      pto::Stride<1, 1, 1, 1, 1> v155 = pto::Stride<1, 1, 1, 1, 1>();
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v156 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v152 + (v153 + v151), v154, v155);
      pto::comm::WaitCmp v157 = pto::comm::WaitCmp::GE;
      pto::comm::TWAIT(v156, v101, v157);
    };
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  for (int64_t v158 = v92; v158 < v146; v158 += v35) {
    // pto: %38
    ;
    int64_t v159 = (int64_t) ((uint64_t) v158 * (uint64_t) v27);
    // pto: %39
    ;
    int64_t v160 = (int64_t) ((uint64_t) v17 - (uint64_t) v159);
    // pto: %40
    ;
    int64_t v161 = v160 < v27 ? v160 : v27;
    // pto: %first_quant__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v162 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v161, v36);
    // pto: %first_quant__ssa_v0
    ;
    uint64_t v163 = (uint64_t) v23;
    TASSIGN(v162, v163);
    // pto: %41
    ;
    int64_t v164 = v159 < v33 ? v33 : v159;
    // pto: %42
    ;
    const int64_t v165 = 0;
    // pto: %42
    ;
    __gm__ bfloat16_t* v166 = PTOAS__GLOBAL_TENSOR_DATA(v54);
    // pto: %42
    ;
    const int64_t v167 = 1;
    // pto: %42
    ;
    const int64_t v168 = 1;
    // pto: %42
    ;
    const int64_t v169 = 1;
    // pto: %42
    ;
    int64_t v170 = v161 * v30;
    // pto: %42
    ;
    int64_t v171 = v169 * v170;
    // pto: %42
    ;
    pto::Shape<1, 1, 1, -1, 1024> v172 = pto::Shape<1, 1, 1, -1, 1024>(v167, v168, v169, v161, v36);
    // pto: %42
    ;
    pto::Stride<-1, -1, -1, -1, -1> v173 = pto::Stride<-1, -1, -1, -1, -1>(v168 * v171, v171, v170, v30, v26);
    // pto: %42
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v174 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v166 + (v165 + v164 * v30 + v33 * v26), v172, v173);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v162, v174);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %t__tmp_v1
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v161, v36);
    // pto: %t__tmp_v1
    ;
    uint64_t v176 = (uint64_t) v22;
    TASSIGN(v175, v176);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    RoundMode v177 = RoundMode::CAST_ROUND;
    SaturationMode v178 = SaturationMode::ON;
    TCVT(v175, v162, v177, v178);
    // pto: %first_abs__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v179 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v161, v36);
    // pto: %first_abs__ssa_v0
    ;
    uint64_t v180 = (uint64_t) v22;
    TASSIGN(v179, v180);
    pipe_barrier(PIPE_V);
    TABS(v179, v175);
    // pto: %t__tmp_v2
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v36);
    // pto: %t__tmp_v2
    ;
    uint64_t v182 = (uint64_t) v23;
    TASSIGN(v181, v182);
    // pto: %amax__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v161, v26);
    // pto: %amax__ssa_v0
    ;
    uint64_t v184 = (uint64_t) v24;
    TASSIGN(v183, v184);
    pipe_barrier(PIPE_V);
    TROWMAX(v183, v179, v181);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    for (int64_t v185 = v26; v185 < v27; v185 += v26) {
      // pto: %q_bf16__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v186 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v161, v36);
      // pto: %q_bf16__ssa_v0
      ;
      uint64_t v187 = (uint64_t) v23;
      TASSIGN(v186, v187);
      // pto: %44
      ;
      int64_t v188 = (int64_t) ((uint64_t) v185 * (uint64_t) v36);
      // pto: %45
      ;
      int64_t v189 = v188 < v33 ? v33 : v188;
      // pto: %46
      ;
      const int64_t v190 = 0;
      // pto: %46
      ;
      __gm__ bfloat16_t* v191 = PTOAS__GLOBAL_TENSOR_DATA(v54);
      // pto: %46
      ;
      const int64_t v192 = 1;
      // pto: %46
      ;
      const int64_t v193 = 1;
      // pto: %46
      ;
      const int64_t v194 = 1;
      // pto: %46
      ;
      int64_t v195 = v161 * v30;
      // pto: %46
      ;
      int64_t v196 = v194 * v195;
      // pto: %46
      ;
      pto::Shape<1, 1, 1, -1, 1024> v197 = pto::Shape<1, 1, 1, -1, 1024>(v192, v193, v194, v161, v36);
      // pto: %46
      ;
      pto::Stride<-1, -1, -1, -1, -1> v198 = pto::Stride<-1, -1, -1, -1, -1>(v193 * v196, v196, v195, v30, v26);
      // pto: %46
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v199 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v191 + (v190 + v164 * v30 + v189 * v26), v197, v198);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      TLOAD(v186, v199);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %q_fp32__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v200 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v161, v36);
      // pto: %q_fp32__ssa_v0
      ;
      uint64_t v201 = (uint64_t) v22;
      TASSIGN(v200, v201);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      pipe_barrier(PIPE_V);
      RoundMode v202 = RoundMode::CAST_ROUND;
      SaturationMode v203 = SaturationMode::ON;
      TCVT(v200, v186, v202, v203);
      // pto: %t__tmp_v3
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v204 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v161, v36);
      // pto: %t__tmp_v3
      ;
      uint64_t v205 = (uint64_t) v22;
      TASSIGN(v204, v205);
      pipe_barrier(PIPE_V);
      TABS(v204, v200);
      // pto: %t__tmp_v4
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v206 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v36);
      // pto: %t__tmp_v4
      ;
      uint64_t v207 = (uint64_t) v23;
      TASSIGN(v206, v207);
      // pto: %t__tmp_v5
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v208 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v161, v26);
      // pto: %t__tmp_v5
      ;
      uint64_t v209 = (uint64_t) v25;
      TASSIGN(v208, v209);
      pipe_barrier(PIPE_V);
      TROWMAX(v208, v204, v206);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      // pto: %amax__rm_a0_tmp_v0
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v210 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v161);
      // pto: %amax__rm_a0_tmp_v0
      ;
      uint64_t v211 = (uint64_t) v24;
      TASSIGN(v210, v211);
      // pto: %amax__rm_a1_tmp_v1
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v212 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v161);
      // pto: %amax__rm_a1_tmp_v1
      ;
      uint64_t v213 = (uint64_t) v25;
      TASSIGN(v212, v213);
      // pto: %amax__row_major_tmp_v2
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v214 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v161);
      // pto: %amax__row_major_tmp_v2
      ;
      uint64_t v215 = (uint64_t) v22;
      TASSIGN(v214, v215);
      pipe_barrier(PIPE_V);
      TMAX(v214, v210, v212);
      // pto: %amax__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v216 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v161, v26);
      // pto: %amax__ssa_v3
      ;
      uint64_t v217 = (uint64_t) v22;
      TASSIGN(v216, v217);
      // pto: %amax__ssa_v3_mv
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v161, v26);
      // pto: %amax__ssa_v3_mv
      ;
      uint64_t v219 = (uint64_t) v24;
      TASSIGN(v218, v219);
      pipe_barrier(PIPE_V);
      TMOV(v218, v216);
    };
    // pto: %dequant__rm_a0_tmp_v3
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v161);
    // pto: %dequant__rm_a0_tmp_v3
    ;
    uint64_t v221 = (uint64_t) v24;
    TASSIGN(v220, v221);
    // pto: %dequant__row_major_tmp_v4
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v222 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v161);
    // pto: %dequant__row_major_tmp_v4
    ;
    uint64_t v223 = (uint64_t) v22;
    TASSIGN(v222, v223);
    pipe_barrier(PIPE_V);
    TMULS(v222, v220, v41);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %dequant__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v224 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v161, v26);
    // pto: %dequant__ssa_v0
    ;
    uint64_t v225 = (uint64_t) v22;
    TASSIGN(v224, v225);
    // pto: %denominator__rm_a0_tmp_v5
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v226 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v161);
    // pto: %denominator__rm_a0_tmp_v5
    ;
    uint64_t v227 = (uint64_t) v24;
    TASSIGN(v226, v227);
    // pto: %denominator__row_major_tmp_v6
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v228 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v161);
    // pto: %denominator__row_major_tmp_v6
    ;
    uint64_t v229 = (uint64_t) v23;
    TASSIGN(v228, v229);
    TADDS(v228, v226, v42);
    set_flag(PIPE_V, PIPE_S, EVENT_ID0);
    // pto: %denominator__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v230 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v161, v26);
    // pto: %denominator__ssa_v0
    ;
    uint64_t v231 = (uint64_t) v23;
    TASSIGN(v230, v231);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
    for (int64_t v232 = v33; v232 < v161; v232 += v26) {
      // pto: %magnitude__ssa_v0
      ;
      float v233 = v230.GetValue(v232);
      // pto: %47
      ;
      bool v234 = v233 != v233 || v42 != v42;
      // pto: %47
      ;
      if ((v233 == v233 && v42 == v42) && v233 == v42) {
        v230.SetValue(v232, v43);
      };
    };
    set_flag(PIPE_S, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
    // pto: %t__rm_a0_tmp_v7
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v235 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v161);
    // pto: %t__rm_a0_tmp_v7
    ;
    uint64_t v236 = (uint64_t) v24;
    TASSIGN(v235, v236);
    // pto: %t__row_major_tmp_v8
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v237 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v161);
    // pto: %t__row_major_tmp_v8
    ;
    uint64_t v238 = (uint64_t) v24;
    TASSIGN(v237, v238);
    pipe_barrier(PIPE_V);
    TMULS(v237, v235, v42);
    // pto: %t__tmp_v6
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v239 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v161, v26);
    // pto: %t__tmp_v6
    ;
    uint64_t v240 = (uint64_t) v24;
    TASSIGN(v239, v240);
    // pto: %t__rm_a0_tmp_v9
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v241 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v161);
    // pto: %t__rm_a0_tmp_v9
    ;
    uint64_t v242 = (uint64_t) v24;
    TASSIGN(v241, v242);
    // pto: %t__row_major_tmp_v10
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v243 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v161);
    // pto: %t__row_major_tmp_v10
    ;
    uint64_t v244 = (uint64_t) v24;
    TASSIGN(v243, v244);
    pipe_barrier(PIPE_V);
    TADDS(v243, v241, v44);
    // pto: %t__tmp_v7
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v245 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v161, v26);
    // pto: %t__tmp_v7
    ;
    uint64_t v246 = (uint64_t) v24;
    TASSIGN(v245, v246);
    // pto: %multiplier__rm_a0_tmp_v11
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v247 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v161);
    // pto: %multiplier__rm_a0_tmp_v11
    ;
    uint64_t v248 = (uint64_t) v24;
    TASSIGN(v247, v248);
    // pto: %multiplier__rm_a1_tmp_v12
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v249 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v161);
    // pto: %multiplier__rm_a1_tmp_v12
    ;
    uint64_t v250 = (uint64_t) v23;
    TASSIGN(v249, v250);
    // pto: %multiplier__row_major_tmp_v13
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v251 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v161);
    // pto: %multiplier__row_major_tmp_v13
    ;
    uint64_t v252 = (uint64_t) v24;
    TASSIGN(v251, v252);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    TDIV(v251, v247, v249);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    // pto: %multiplier__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v253 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v161, v26);
    // pto: %multiplier__ssa_v0
    ;
    uint64_t v254 = (uint64_t) v24;
    TASSIGN(v253, v254);
    v224.SetValidShape(v161, v26);
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v255 = (int64_t) v17;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v256 = 0;
    // pto: %token_scale__ssa_v0_pview
    ;
    __gm__ float* v257 = PTOAS__GLOBAL_TENSOR_DATA(v72);
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v258 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v259 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v260 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v261 = v161 * v26;
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v262 = v260 * v261;
    // pto: %token_scale__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1> v263 = pto::Shape<1, 1, 1, -1, 1>(v258, v259, v260, v161, v26);
    // pto: %token_scale__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v264 = pto::Stride<-1, -1, -1, -1, -1>(v259 * v262, v262, v261, v26, v255);
    // pto: %token_scale__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v265 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v257 + (v256 + v164 * v26 + v33 * v255), v263, v264);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    TSTORE(v265, v224);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_S, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    for (int64_t v266 = v33; v266 < v27; v266 += v26) {
      // pto: %52
      ;
      int64_t v267 = (int64_t) ((uint64_t) v266 * (uint64_t) v36);
      // pto: %quant_bf16__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v268 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v161, v36);
      // pto: %quant_bf16__ssa_v0
      ;
      uint64_t v269 = (uint64_t) v23;
      TASSIGN(v268, v269);
      // pto: %54
      ;
      int64_t v270 = v267 < v33 ? v33 : v267;
      // pto: %55
      ;
      const int64_t v271 = 0;
      // pto: %55
      ;
      __gm__ bfloat16_t* v272 = PTOAS__GLOBAL_TENSOR_DATA(v54);
      // pto: %55
      ;
      const int64_t v273 = 1;
      // pto: %55
      ;
      const int64_t v274 = 1;
      // pto: %55
      ;
      const int64_t v275 = 1;
      // pto: %55
      ;
      int64_t v276 = v161 * v30;
      // pto: %55
      ;
      int64_t v277 = v275 * v276;
      // pto: %55
      ;
      pto::Shape<1, 1, 1, -1, 1024> v278 = pto::Shape<1, 1, 1, -1, 1024>(v273, v274, v275, v161, v36);
      // pto: %55
      ;
      pto::Stride<-1, -1, -1, -1, -1> v279 = pto::Stride<-1, -1, -1, -1, -1>(v274 * v277, v277, v276, v30, v26);
      // pto: %55
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v280 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v272 + (v271 + v164 * v30 + v270 * v26), v278, v279);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      TLOAD(v268, v280);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %t__tmp_v9
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v281 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v161, v36);
      // pto: %t__tmp_v9
      ;
      uint64_t v282 = (uint64_t) v22;
      TASSIGN(v281, v282);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      RoundMode v283 = RoundMode::CAST_ROUND;
      SaturationMode v284 = SaturationMode::ON;
      TCVT(v281, v268, v283, v284);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      // pto: %quant_scaled__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v285 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v161, v36);
      // pto: %quant_scaled__ssa_v0
      ;
      uint64_t v286 = (uint64_t) v22;
      TASSIGN(v285, v286);
      pipe_barrier(PIPE_V);
      TROWEXPANDMUL(v285, v281, v253);
      // pto: %integer__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v287 = Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v161, v36);
      // pto: %integer__ssa_v0
      ;
      uint64_t v288 = (uint64_t) v22;
      TASSIGN(v287, v288);
      pipe_barrier(PIPE_V);
      RoundMode v289 = RoundMode::CAST_RINT;
      SaturationMode v290 = SaturationMode::ON;
      TCVT(v287, v285, v289, v290);
      // pto: %half__ssa_v0
      ;
      Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v291 = Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v161, v36);
      // pto: %half__ssa_v0
      ;
      uint64_t v292 = (uint64_t) v22;
      TASSIGN(v291, v292);
      pipe_barrier(PIPE_V);
      RoundMode v293 = RoundMode::CAST_ROUND;
      SaturationMode v294 = SaturationMode::ON;
      TCVT(v291, v287, v293, v294);
      // pto: %result__ssa_v0
      ;
      Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v295 = Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v161, v36);
      // pto: %result__ssa_v0
      ;
      uint64_t v296 = (uint64_t) v22;
      TASSIGN(v295, v296);
      pipe_barrier(PIPE_V);
      RoundMode v297 = RoundMode::CAST_TRUNC;
      SaturationMode v298 = SaturationMode::ON;
      TCVT(v295, v291, v297, v298);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      v295.SetValidShape(v161, v36);
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v299 = 0;
      // pto: %quantized__ssa_v0_pview
      ;
      __gm__ int8_t* v300 = PTOAS__GLOBAL_TENSOR_DATA(v63);
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v301 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v302 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v303 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      int64_t v304 = v161 * v30;
      // pto: %quantized__ssa_v0_pview
      ;
      int64_t v305 = v303 * v304;
      // pto: %quantized__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 1024> v306 = pto::Shape<1, 1, 1, -1, 1024>(v301, v302, v303, v161, v36);
      // pto: %quantized__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v307 = pto::Stride<-1, -1, -1, -1, -1>(v302 * v305, v305, v304, v30, v26);
      // pto: %quantized__ssa_v0_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v308 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v300 + (v299 + v164 * v30 + v270 * v26), v306, v307);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      TSTORE(v308, v295);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %59
  int64_t v309 = (int64_t) ((uint64_t) v93 + (uint64_t) v45);
  // pto: %60
  int64_t v310 = v309 < v33 ? v33 : v309;
  // pto: %61
  __gm__ int32_t* v311 = PTOAS__GLOBAL_TENSOR_DATA(v91);
  // pto: %61
  const int64_t v312 = 0;
  // pto: %61
  pto::Shape<1, 1, 1, 1, 1> v313 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %61
  pto::Stride<1, 1, 1, 1, 1> v314 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %61
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v315 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v311 + (v312 + v310), v313, v314);
  pto::comm::NotifyOp v316 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v315, v101, v316);
  pipe_barrier(PIPE_ALL);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}