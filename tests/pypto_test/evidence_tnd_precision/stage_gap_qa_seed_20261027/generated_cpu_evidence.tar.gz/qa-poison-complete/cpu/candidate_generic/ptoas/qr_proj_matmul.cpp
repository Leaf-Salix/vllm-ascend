#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qr_proj_matmul(__gm__ float* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, int64_t v4, int64_t v5, int64_t v6, int64_t v7, int64_t v8, int32_t v9, int32_t v10) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v11 = 0;
  // pto: %c32768_i64
  const int64_t v12 = 32768;
  // pto: %c49152_i64
  const int64_t v13 = 49152;
  // pto: %c81920_i64
  const int64_t v14 = 81920;
  // pto: %c16384_i64
  const int64_t v15 = 16384;
  // pto: %c1024_index
  const int64_t v16 = 1024;
  // pto: %c1_index
  const int64_t v17 = 1;
  // pto: %c4096_index
  const int64_t v18 = 4096;
  // pto: %c256_index
  const int64_t v19 = 256;
  // pto: %c64_index
  const int64_t v20 = 64;
  // pto: %c16_index
  const int64_t v21 = 16;
  // pto: %c4194304_index
  const int64_t v22 = 4194304;
  // pto: %c16384_index
  const int64_t v23 = 16384;
  // pto: %c32_index
  const int64_t v24 = 32;
  // pto: %c96_index
  const int64_t v25 = 96;
  // pto: %c0_index
  const int64_t v26 = 0;
  // pto: %c2_index
  const int64_t v27 = 2;
  // pto: %c240_index
  const int64_t v28 = 240;
  // pto: %c48_index
  const int64_t v29 = 48;
  // pto: %c9_index
  const int64_t v30 = 9;
  // pto: %c15_index
  const int64_t v31 = 15;
  // pto: %c3_index
  const int64_t v32 = 3;
  // pto: %c14_index
  const int64_t v33 = 14;
  // pto: %cn1_index
  const int64_t v34 = -1;
  // pto: %out__ssa_v0_view
  const int64_t v35 = 1;
  // pto: %out__ssa_v0_view
  const int64_t v36 = 1;
  // pto: %out__ssa_v0_view
  const int64_t v37 = 1;
  // pto: %out__ssa_v0_view
  int64_t v38 = (int64_t) v7;
  // pto: %out__ssa_v0_view
  int64_t v39 = v38 * v16;
  // pto: %out__ssa_v0_view
  int64_t v40 = v37 * v39;
  // pto: %out__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v41 = pto::Shape<1, 1, 1, -1, -1>(v35, v36, v37, v38, v16);
  // pto: %out__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v42 = pto::Stride<-1, -1, -1, -1, -1>(v36 * v40, v40, v39, v16, v17);
  // pto: %out__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v43 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v41, v42);
  // pto: %x_view_inline61__ssa_v0_view
  const int64_t v44 = 1;
  // pto: %x_view_inline61__ssa_v0_view
  const int64_t v45 = 1;
  // pto: %x_view_inline61__ssa_v0_view
  const int64_t v46 = 1;
  // pto: %x_view_inline61__ssa_v0_view
  int64_t v47 = (int64_t) v8;
  // pto: %x_view_inline61__ssa_v0_view
  int64_t v48 = v47 * v18;
  // pto: %x_view_inline61__ssa_v0_view
  int64_t v49 = v46 * v48;
  // pto: %x_view_inline61__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v50 = pto::Shape<1, 1, 1, -1, -1>(v44, v45, v46, v47, v18);
  // pto: %x_view_inline61__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v51 = pto::Stride<-1, -1, -1, -1, -1>(v45 * v49, v49, v48, v18, v17);
  // pto: %x_view_inline61__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v52 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v50, v51);
  // pto: %w__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v53 = pto::Shape<-1, -1, -1, -1, -1>(v17, v19, v20, v21, v21);
  // pto: %w__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v54 = pto::Stride<-1, -1, -1, -1, -1>(v22, v23, v19, v21, v17);
  // pto: %w__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v55 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v3, v53, v54);
  // pto: %qbg_idx_inline64__ssa_v0, %14
  int64_t v56 = (int64_t) ((uint64_t) ((int64_t) v9) * (uint64_t) v24);
  // pto: %15
  const int64_t v57 = 1;
  // pto: %15
  const int64_t v58 = 0;
  // pto: %15
  int64_t v59 = v56 / v25;
  // pto: %15
  bool v60 = v56 < v58;
  // pto: %15
  bool v61 = v25 < v58;
  // pto: %15
  bool v62 = v60 == v61;
  // pto: %15
  bool v63 = v56 % v25 != v58 && v60 != v61;
  // pto: %15
  int64_t v64 = v63 ? v59 - v57 : v59;
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  for (int64_t v65 = v26; v65 < v4; v65 += v20) {
    // pto: %dense_acc_inline70__tile
    ;
    Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v66 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v24);
    // pto: %dense_acc_inline70__tile
    ;
    uint64_t v67 = (uint64_t) v11;
    TASSIGN(v66, v67);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    for (int64_t v68 = v26; v68 < v21; v68 += v27) {
      // pto: %16
      ;
      int64_t v69 = (int64_t) ((uint64_t) v68 + (uint64_t) v17);
      // pto: %20
      ;
      int64_t v70 = v5 % v29;
      // pto: %21, %22, %23
      ;
      int64_t v71 = v70 < v26 ? (int64_t) ((uint64_t) v70 + (uint64_t) v29) : v70;
      // pto: %17, %18, %19, %24, %25, %26, %27
      ;
      bool v72 = (v5 >= v25 & v5 <= v28 & v71 == v26) & v64 < v30;
      // pto: %dense_k_order_inline72__phi_v2
      ;
      int64_t v73;
      if (v72) {
        // pto: %28
        ;
        int64_t v74 = v64 % v27;
        // pto: %29, %30, %31
        ;
        int64_t v75 = v74 < v26 ? (int64_t) ((uint64_t) v74 + (uint64_t) v27) : v74;
        // pto: %32
        ;
        // pto: %dense_k_direction_inline73__phi_v2
        ;
        int64_t v76;
        if (v75 == v17) {
          // pto: %33
          ;
          v76 = (int64_t) ((uint64_t) v31 - (uint64_t) v68);
        } else {
          v76 = v68;
        };
        // pto: %34
        ;
        const int64_t v77 = 1;
        // pto: %34
        ;
        const int64_t v78 = 0;
        // pto: %34
        ;
        int64_t v79 = v64 / v27;
        // pto: %34
        ;
        bool v80 = v64 < v78;
        // pto: %34
        ;
        bool v81 = v27 < v78;
        // pto: %34
        ;
        bool v82 = v80 == v81;
        // pto: %34
        ;
        bool v83 = v64 % v27 != v78 && v80 != v81;
        // pto: %34
        ;
        int64_t v84 = v83 ? v79 - v77 : v79;
        // pto: %36
        ;
        uint64_t v85 = (uint64_t) v76;
        // pto: %35, %36, %37
        ;
        int64_t v86 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v84 * (uint64_t) v32) + v85) % v21;
        // pto: %38, %39, %40
        ;
        v73 = v86 < v26 ? (int64_t) ((uint64_t) v86 + (uint64_t) v21) : v86;
      } else {
        v73 = v68;
      };
      // pto: %41
      ;
      bool v87 = v73 < v26;
      // pto: %41
      ;
      int64_t v88 = v87 ? v26 : v73;
      // pto: %42
      ;
      int64_t v89 = (int64_t) ((uint64_t) v88 * (uint64_t) v19);
      // pto: %dense_x_inline75__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v90 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v19);
      // pto: %dense_x_inline75__tile
      ;
      uint64_t v91 = (uint64_t) v11;
      TASSIGN(v90, v91);
      // pto: %43
      ;
      int64_t v92 = v65 < v26 ? v26 : v65;
      // pto: %44
      ;
      int64_t v93 = v89 < v26 ? v26 : v89;
      // pto: %x_view_inline61__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v94 = PTOAS__GLOBAL_TENSOR_DATA(v52);
      // pto: %x_view_inline61__ssa_v0_pview
      ;
      const int64_t v95 = 0;
      // pto: %x_view_inline61__ssa_v0_pview
      ;
      const int64_t v96 = 4096;
      // pto: %x_view_inline61__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 64, 256> v97 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %x_view_inline61__ssa_v0_pview
      ;
      pto::Stride<262144, 262144, 262144, 4096, 1> v98 = pto::Stride<262144, 262144, 262144, 4096, 1>();
      // pto: %x_view_inline61__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND> v99 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND>(v94 + (v95 + v92 * v96 + v93), v97, v98);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v90, v99);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %dense_w_inline76__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v100 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
      // pto: %dense_w_inline76__tile
      ;
      uint64_t v101 = (uint64_t) v12;
      TASSIGN(v100, v101);
      // pto: %45
      ;
      const int64_t v102 = 1;
      // pto: %45
      ;
      const int64_t v103 = 0;
      // pto: %45
      ;
      int64_t v104 = v89 / v21;
      // pto: %45
      ;
      bool v105 = v89 < v103;
      // pto: %45
      ;
      bool v106 = v21 < v103;
      // pto: %45
      ;
      bool v107 = v105 == v106;
      // pto: %45
      ;
      bool v108 = v89 % v21 != v103 && v105 != v106;
      // pto: %45
      ;
      int64_t v109 = v108 ? v104 - v102 : v104;
      // pto: %46
      ;
      int64_t v110 = v109 < v26 ? v26 : v109;
      // pto: %47
      ;
      const int64_t v111 = 1;
      // pto: %47
      ;
      const int64_t v112 = 0;
      // pto: %47
      ;
      int64_t v113 = v56 / v21;
      // pto: %47
      ;
      bool v114 = v56 < v112;
      // pto: %47
      ;
      bool v115 = v21 < v112;
      // pto: %47
      ;
      bool v116 = v114 == v115;
      // pto: %47
      ;
      bool v117 = v56 % v21 != v112 && v114 != v115;
      // pto: %47
      ;
      int64_t v118 = v117 ? v113 - v111 : v113;
      // pto: %48
      ;
      int64_t v119 = v118 < v26 ? v26 : v118;
      // pto: %w__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v120 = PTOAS__GLOBAL_TENSOR_DATA(v55);
      // pto: %w__ssa_v0_pview
      ;
      const int64_t v121 = 0;
      // pto: %w__ssa_v0_pview
      ;
      const int64_t v122 = 16384;
      // pto: %w__ssa_v0_pview
      ;
      const int64_t v123 = 256;
      // pto: %w__ssa_v0_pview
      ;
      pto::Shape<1, 16, 2, 16, 16> v124 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %w__ssa_v0_pview
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v125 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %w__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v126 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v120 + (v121 + v110 * v122 + v119 * v123), v124, v125);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v100, v126);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %60
      ;
      int64_t v127;
      if (v72) {
        // pto: %62
        ;
        int64_t v128 = v64 % v27;
        // pto: %63, %64, %65
        ;
        int64_t v129 = v128 < v26 ? (int64_t) ((uint64_t) v128 + (uint64_t) v27) : v128;
        // pto: %66
        ;
        // pto: %67
        ;
        int64_t v130;
        if (v129 == v17) {
          // pto: %68
          ;
          v130 = (int64_t) ((uint64_t) v33 - (uint64_t) v68);
        } else {
          v130 = v69;
        };
        // pto: %69
        ;
        const int64_t v131 = 1;
        // pto: %69
        ;
        const int64_t v132 = 0;
        // pto: %69
        ;
        int64_t v133 = v64 / v27;
        // pto: %69
        ;
        bool v134 = v64 < v132;
        // pto: %69
        ;
        bool v135 = v27 < v132;
        // pto: %69
        ;
        bool v136 = v134 == v135;
        // pto: %69
        ;
        bool v137 = v64 % v27 != v132 && v134 != v135;
        // pto: %69
        ;
        int64_t v138 = v137 ? v133 - v131 : v133;
        // pto: %71
        ;
        uint64_t v139 = (uint64_t) v130;
        // pto: %70, %71, %72
        ;
        int64_t v140 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v138 * (uint64_t) v32) + v139) % v21;
        // pto: %73, %74, %75
        ;
        v127 = v140 < v26 ? (int64_t) ((uint64_t) v140 + (uint64_t) v21) : v140;
      } else {
        v127 = v69;
      };
      // pto: %76
      ;
      bool v141 = v127 < v26;
      // pto: %76
      ;
      int64_t v142 = v141 ? v26 : v127;
      // pto: %77
      ;
      int64_t v143 = (int64_t) ((uint64_t) v142 * (uint64_t) v19);
      // pto: %0
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v144 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v19);
      // pto: %0
      ;
      uint64_t v145 = (uint64_t) v13;
      TASSIGN(v144, v145);
      // pto: %79
      ;
      int64_t v146 = v143 < v26 ? v26 : v143;
      // pto: %80
      ;
      __gm__ bfloat16_t* v147 = PTOAS__GLOBAL_TENSOR_DATA(v52);
      // pto: %80
      ;
      const int64_t v148 = 0;
      // pto: %80
      ;
      const int64_t v149 = 4096;
      // pto: %80
      ;
      pto::Shape<1, 1, 1, 64, 256> v150 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %80
      ;
      pto::Stride<262144, 262144, 262144, 4096, 1> v151 = pto::Stride<262144, 262144, 262144, 4096, 1>();
      // pto: %80
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND> v152 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND>(v147 + (v148 + v92 * v149 + v146), v150, v151);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v144, v152);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      // pto: %1
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v153 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
      // pto: %1
      ;
      uint64_t v154 = (uint64_t) v14;
      TASSIGN(v153, v154);
      // pto: %81
      ;
      const int64_t v155 = 1;
      // pto: %81
      ;
      const int64_t v156 = 0;
      // pto: %81
      ;
      int64_t v157 = v143 / v21;
      // pto: %81
      ;
      bool v158 = v143 < v156;
      // pto: %81
      ;
      bool v159 = v21 < v156;
      // pto: %81
      ;
      bool v160 = v158 == v159;
      // pto: %81
      ;
      bool v161 = v143 % v21 != v156 && v158 != v159;
      // pto: %81
      ;
      int64_t v162 = v161 ? v157 - v155 : v157;
      // pto: %82
      ;
      int64_t v163 = v162 < v26 ? v26 : v162;
      // pto: %85
      ;
      __gm__ bfloat16_t* v164 = PTOAS__GLOBAL_TENSOR_DATA(v55);
      // pto: %85
      ;
      const int64_t v165 = 0;
      // pto: %85
      ;
      const int64_t v166 = 16384;
      // pto: %85
      ;
      const int64_t v167 = 256;
      // pto: %85
      ;
      pto::Shape<1, 16, 2, 16, 16> v168 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %85
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v169 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %85
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v170 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v164 + (v165 + v163 * v166 + v119 * v167), v168, v169);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v153, v170);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %dense_w_inline76__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v171 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v24);
      // pto: %dense_w_inline76__tile_t
      ;
      uint64_t v172 = (uint64_t) v12;
      TASSIGN(v171, v172);
      // pto: %dense_x_inline75__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v173 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v19);
      // pto: %dense_x_inline75__tile_Left
      ;
      uint64_t v174 = (uint64_t) v12;
      TASSIGN(v173, v174);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      TMOV(v173, v90);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %dense_w_inline76__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v24);
      // pto: %dense_w_inline76__tile_t_Right
      ;
      uint64_t v176 = (uint64_t) v15;
      TASSIGN(v175, v176);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      TMOV(v175, v171);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %86
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (v68 == v26) {
        pipe_barrier(PIPE_M);
        TMATMUL(v66, v173, v175);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v66, v66, v173, v175);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      // pto: %3
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v24);
      // pto: %3
      ;
      uint64_t v178 = (uint64_t) v14;
      TASSIGN(v177, v178);
      // pto: %4
      ;
      Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v179 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v19);
      // pto: %4
      ;
      uint64_t v180 = (uint64_t) v11;
      TASSIGN(v179, v180);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      TMOV(v179, v144);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      // pto: %5
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v24);
      // pto: %5
      ;
      uint64_t v182 = (uint64_t) v11;
      TASSIGN(v181, v182);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      TMOV(v181, v177);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      // pto: %87
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      if (v68 == v34) {
        pipe_barrier(PIPE_M);
        TMATMUL(v66, v179, v181);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v66, v66, v179, v181);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    };
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %88
    ;
    int64_t v183 = v65 < v26 ? v26 : v65;
    // pto: %89
    ;
    int64_t v184 = v56 < v26 ? v26 : v56;
    // pto: %out__iter_v1_pview
    ;
    __gm__ float* v185 = PTOAS__GLOBAL_TENSOR_DATA(v43);
    // pto: %out__iter_v1_pview
    ;
    const int64_t v186 = 0;
    // pto: %out__iter_v1_pview
    ;
    const int64_t v187 = 1024;
    // pto: %out__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 64, 32> v188 = pto::Shape<1, 1, 1, 64, 32>();
    // pto: %out__iter_v1_pview
    ;
    pto::Stride<65536, 65536, 65536, 1024, 1> v189 = pto::Stride<65536, 65536, 65536, 1024, 1>();
    // pto: %out__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 64, 32>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND> v190 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 32>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND>(v185 + (v186 + v183 * v187 + v184), v188, v189);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE(v190, v66);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  for (int64_t v191 = v4; v191 < v6; v191 += v21) {
    // pto: %q_acc_inline78__tile
    ;
    Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v192 = Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v21, v24);
    // pto: %q_acc_inline78__tile
    ;
    uint64_t v193 = (uint64_t) v11;
    TASSIGN(v192, v193);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    for (int64_t v194 = v26; v194 < v21; v194 += v27) {
      // pto: %90
      ;
      int64_t v195 = (int64_t) ((uint64_t) v5 - (uint64_t) v191);
      // pto: %91
      ;
      int64_t v196 = v195 < v21 ? v195 : v21;
      // pto: %92
      ;
      int64_t v197 = (int64_t) ((uint64_t) v194 + (uint64_t) v17);
      // pto: %98
      ;
      int64_t v198 = v5 % v29;
      // pto: %99, %100, %101
      ;
      int64_t v199 = v198 < v26 ? (int64_t) ((uint64_t) v198 + (uint64_t) v29) : v198;
      // pto: %95, %96, %97, %102, %103, %104, %105
      ;
      bool v200 = (v5 >= v25 & v5 <= v28 & v199 == v26) & v64 < v30;
      // pto: %qr_k_order_inline80__phi_v2
      ;
      int64_t v201;
      if (v200) {
        // pto: %106
        ;
        int64_t v202 = v64 % v27;
        // pto: %107, %108, %109
        ;
        int64_t v203 = v202 < v26 ? (int64_t) ((uint64_t) v202 + (uint64_t) v27) : v202;
        // pto: %110
        ;
        // pto: %qr_k_direction_inline81__phi_v2
        ;
        int64_t v204;
        if (v203 == v17) {
          // pto: %111
          ;
          v204 = (int64_t) ((uint64_t) v31 - (uint64_t) v194);
        } else {
          v204 = v194;
        };
        // pto: %112
        ;
        const int64_t v205 = 1;
        // pto: %112
        ;
        const int64_t v206 = 0;
        // pto: %112
        ;
        int64_t v207 = v64 / v27;
        // pto: %112
        ;
        bool v208 = v64 < v206;
        // pto: %112
        ;
        bool v209 = v27 < v206;
        // pto: %112
        ;
        bool v210 = v208 == v209;
        // pto: %112
        ;
        bool v211 = v64 % v27 != v206 && v208 != v209;
        // pto: %112
        ;
        int64_t v212 = v211 ? v207 - v205 : v207;
        // pto: %114
        ;
        uint64_t v213 = (uint64_t) v204;
        // pto: %113, %114, %115
        ;
        int64_t v214 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v212 * (uint64_t) v32) + v213) % v21;
        // pto: %116, %117, %118
        ;
        v201 = v214 < v26 ? (int64_t) ((uint64_t) v214 + (uint64_t) v21) : v214;
      } else {
        v201 = v194;
      };
      // pto: %119
      ;
      bool v215 = v201 < v26;
      // pto: %119
      ;
      int64_t v216 = v215 ? v26 : v201;
      // pto: %120
      ;
      int64_t v217 = (int64_t) ((uint64_t) v216 * (uint64_t) v19);
      // pto: %q_x_chunk_bf16_inline85__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v196, v19);
      // pto: %q_x_chunk_bf16_inline85__tile
      ;
      uint64_t v219 = (uint64_t) v12;
      TASSIGN(v218, v219);
      // pto: %121
      ;
      int64_t v220 = v191 < v26 ? v26 : v191;
      // pto: %122
      ;
      int64_t v221 = v217 < v26 ? v26 : v217;
      // pto: %123
      ;
      const int64_t v222 = 0;
      // pto: %123
      ;
      __gm__ bfloat16_t* v223 = PTOAS__GLOBAL_TENSOR_DATA(v52);
      // pto: %123
      ;
      const int64_t v224 = 1;
      // pto: %123
      ;
      const int64_t v225 = 1;
      // pto: %123
      ;
      const int64_t v226 = 1;
      // pto: %123
      ;
      int64_t v227 = v196 * v18;
      // pto: %123
      ;
      int64_t v228 = v226 * v227;
      // pto: %123
      ;
      pto::Shape<1, 1, 1, -1, 256> v229 = pto::Shape<1, 1, 1, -1, 256>(v224, v225, v226, v196, v19);
      // pto: %123
      ;
      pto::Stride<-1, -1, -1, -1, -1> v230 = pto::Stride<-1, -1, -1, -1, -1>(v225 * v228, v228, v227, v18, v17);
      // pto: %123
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v231 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v223 + (v222 + v220 * v18 + v221 * v17), v229, v230);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      TLOAD(v218, v231);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      // pto: %w_chunk_inline86__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v232 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
      // pto: %w_chunk_inline86__tile
      ;
      uint64_t v233 = (uint64_t) v11;
      TASSIGN(v232, v233);
      // pto: %124
      ;
      const int64_t v234 = 1;
      // pto: %124
      ;
      const int64_t v235 = 0;
      // pto: %124
      ;
      int64_t v236 = v217 / v21;
      // pto: %124
      ;
      bool v237 = v217 < v235;
      // pto: %124
      ;
      bool v238 = v21 < v235;
      // pto: %124
      ;
      bool v239 = v237 == v238;
      // pto: %124
      ;
      bool v240 = v217 % v21 != v235 && v237 != v238;
      // pto: %124
      ;
      int64_t v241 = v240 ? v236 - v234 : v236;
      // pto: %125
      ;
      int64_t v242 = v241 < v26 ? v26 : v241;
      // pto: %126
      ;
      const int64_t v243 = 1;
      // pto: %126
      ;
      const int64_t v244 = 0;
      // pto: %126
      ;
      int64_t v245 = v56 / v21;
      // pto: %126
      ;
      bool v246 = v56 < v244;
      // pto: %126
      ;
      bool v247 = v21 < v244;
      // pto: %126
      ;
      bool v248 = v246 == v247;
      // pto: %126
      ;
      bool v249 = v56 % v21 != v244 && v246 != v247;
      // pto: %126
      ;
      int64_t v250 = v249 ? v245 - v243 : v245;
      // pto: %127
      ;
      int64_t v251 = v250 < v26 ? v26 : v250;
      // pto: %128
      ;
      __gm__ bfloat16_t* v252 = PTOAS__GLOBAL_TENSOR_DATA(v55);
      // pto: %128
      ;
      const int64_t v253 = 0;
      // pto: %128
      ;
      const int64_t v254 = 16384;
      // pto: %128
      ;
      const int64_t v255 = 256;
      // pto: %128
      ;
      pto::Shape<1, 16, 2, 16, 16> v256 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %128
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v257 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %128
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v258 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v252 + (v253 + v242 * v254 + v251 * v255), v256, v257);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      TLOAD(v232, v258);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      // pto: %140
      ;
      int64_t v259;
      if (v200) {
        // pto: %142
        ;
        int64_t v260 = v64 % v27;
        // pto: %143, %144, %145
        ;
        int64_t v261 = v260 < v26 ? (int64_t) ((uint64_t) v260 + (uint64_t) v27) : v260;
        // pto: %146
        ;
        // pto: %147
        ;
        int64_t v262;
        if (v261 == v17) {
          // pto: %148
          ;
          v262 = (int64_t) ((uint64_t) v33 - (uint64_t) v194);
        } else {
          v262 = v197;
        };
        // pto: %149
        ;
        const int64_t v263 = 1;
        // pto: %149
        ;
        const int64_t v264 = 0;
        // pto: %149
        ;
        int64_t v265 = v64 / v27;
        // pto: %149
        ;
        bool v266 = v64 < v264;
        // pto: %149
        ;
        bool v267 = v27 < v264;
        // pto: %149
        ;
        bool v268 = v266 == v267;
        // pto: %149
        ;
        bool v269 = v64 % v27 != v264 && v266 != v267;
        // pto: %149
        ;
        int64_t v270 = v269 ? v265 - v263 : v265;
        // pto: %151
        ;
        uint64_t v271 = (uint64_t) v262;
        // pto: %150, %151, %152
        ;
        int64_t v272 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v270 * (uint64_t) v32) + v271) % v21;
        // pto: %153, %154, %155
        ;
        v259 = v272 < v26 ? (int64_t) ((uint64_t) v272 + (uint64_t) v21) : v272;
      } else {
        v259 = v197;
      };
      // pto: %156
      ;
      bool v273 = v259 < v26;
      // pto: %156
      ;
      int64_t v274 = v273 ? v26 : v259;
      // pto: %157
      ;
      int64_t v275 = (int64_t) ((uint64_t) v274 * (uint64_t) v19);
      // pto: %7
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v276 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v196, v19);
      // pto: %7
      ;
      uint64_t v277 = (uint64_t) v14;
      TASSIGN(v276, v277);
      // pto: %159
      ;
      int64_t v278 = v275 < v26 ? v26 : v275;
      // pto: %160
      ;
      const int64_t v279 = 0;
      // pto: %160
      ;
      __gm__ bfloat16_t* v280 = PTOAS__GLOBAL_TENSOR_DATA(v52);
      // pto: %160
      ;
      const int64_t v281 = 1;
      // pto: %160
      ;
      const int64_t v282 = 1;
      // pto: %160
      ;
      const int64_t v283 = 1;
      // pto: %160
      ;
      int64_t v284 = v196 * v18;
      // pto: %160
      ;
      int64_t v285 = v283 * v284;
      // pto: %160
      ;
      pto::Shape<1, 1, 1, -1, 256> v286 = pto::Shape<1, 1, 1, -1, 256>(v281, v282, v283, v196, v19);
      // pto: %160
      ;
      pto::Stride<-1, -1, -1, -1, -1> v287 = pto::Stride<-1, -1, -1, -1, -1>(v282 * v285, v285, v284, v18, v17);
      // pto: %160
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v288 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v280 + (v279 + v220 * v18 + v278 * v17), v286, v287);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      TLOAD(v276, v288);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
      // pto: %8
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v289 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
      // pto: %8
      ;
      uint64_t v290 = (uint64_t) v13;
      TASSIGN(v289, v290);
      // pto: %161
      ;
      const int64_t v291 = 1;
      // pto: %161
      ;
      const int64_t v292 = 0;
      // pto: %161
      ;
      int64_t v293 = v275 / v21;
      // pto: %161
      ;
      bool v294 = v275 < v292;
      // pto: %161
      ;
      bool v295 = v21 < v292;
      // pto: %161
      ;
      bool v296 = v294 == v295;
      // pto: %161
      ;
      bool v297 = v275 % v21 != v292 && v294 != v295;
      // pto: %161
      ;
      int64_t v298 = v297 ? v293 - v291 : v293;
      // pto: %162
      ;
      int64_t v299 = v298 < v26 ? v26 : v298;
      // pto: %165
      ;
      __gm__ bfloat16_t* v300 = PTOAS__GLOBAL_TENSOR_DATA(v55);
      // pto: %165
      ;
      const int64_t v301 = 0;
      // pto: %165
      ;
      const int64_t v302 = 16384;
      // pto: %165
      ;
      const int64_t v303 = 256;
      // pto: %165
      ;
      pto::Shape<1, 16, 2, 16, 16> v304 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %165
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v305 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %165
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v306 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v300 + (v301 + v299 * v302 + v251 * v303), v304, v305);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v289, v306);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
      // pto: %w_chunk_inline86__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v307 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v24);
      // pto: %w_chunk_inline86__tile_t
      ;
      uint64_t v308 = (uint64_t) v11;
      TASSIGN(v307, v308);
      // pto: %q_x_chunk_bf16_inline85__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v196, v19);
      // pto: %q_x_chunk_bf16_inline85__tile_Left
      ;
      uint64_t v310 = (uint64_t) v12;
      TASSIGN(v309, v310);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      TMOV(v309, v218);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      // pto: %w_chunk_inline86__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v311 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v24);
      // pto: %w_chunk_inline86__tile_t_Right
      ;
      uint64_t v312 = (uint64_t) v15;
      TASSIGN(v311, v312);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      TMOV(v311, v307);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      // pto: %166
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      if (v194 == v26) {
        pipe_barrier(PIPE_M);
        TMATMUL(v192, v309, v311);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v192, v192, v309, v311);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      // pto: %10
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v24);
      // pto: %10
      ;
      uint64_t v314 = (uint64_t) v13;
      TASSIGN(v313, v314);
      // pto: %11
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v196, v19);
      // pto: %11
      ;
      uint64_t v316 = (uint64_t) v11;
      TASSIGN(v315, v316);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      TMOV(v315, v276);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      // pto: %12
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v317 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v24);
      // pto: %12
      ;
      uint64_t v318 = (uint64_t) v11;
      TASSIGN(v317, v318);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
      TMOV(v317, v313);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %167
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      if (v194 == v34) {
        pipe_barrier(PIPE_M);
        TMATMUL(v192, v315, v317);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v192, v192, v315, v317);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    };
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
    // pto: %169
    ;
    int64_t v319 = v191 < v26 ? v26 : v191;
    // pto: %170
    ;
    int64_t v320 = v56 < v26 ? v26 : v56;
    // pto: %out__iter_v4_pview
    ;
    __gm__ float* v321 = PTOAS__GLOBAL_TENSOR_DATA(v43);
    // pto: %out__iter_v4_pview
    ;
    const int64_t v322 = 0;
    // pto: %out__iter_v4_pview
    ;
    const int64_t v323 = 1024;
    // pto: %out__iter_v4_pview
    ;
    pto::Shape<1, 1, 1, 16, 32> v324 = pto::Shape<1, 1, 1, 16, 32>();
    // pto: %out__iter_v4_pview
    ;
    pto::Stride<16384, 16384, 16384, 1024, 1> v325 = pto::Stride<16384, 16384, 16384, 1024, 1>();
    // pto: %out__iter_v4_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND> v326 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND>(v321 + (v322 + v319 * v323 + v320), v324, v325);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
    pipe_barrier(PIPE_FIX);
    TSTORE(v326, v192);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}