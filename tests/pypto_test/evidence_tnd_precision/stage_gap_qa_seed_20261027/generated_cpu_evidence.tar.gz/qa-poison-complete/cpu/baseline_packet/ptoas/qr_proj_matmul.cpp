#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qr_proj_matmul(__gm__ float* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, int64_t v4, int64_t v5, int64_t v6, int64_t v7, int64_t v8, int32_t v9, int32_t v10) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v11 = 0;
  // pto: %c32768_i64
  const int64_t v12 = 32768;
  // pto: %c49152_i64
  const int64_t v13 = 49152;
  // pto: %c81920_i64
  const int64_t v14 = 81920;
  // pto: %c16384_i64
  const int64_t v15 = 16384;
  // pto: %c1024_index
  const int64_t v16 = 1024;
  // pto: %c1_index
  const int64_t v17 = 1;
  // pto: %c4096_index
  const int64_t v18 = 4096;
  // pto: %c256_index
  const int64_t v19 = 256;
  // pto: %c64_index
  const int64_t v20 = 64;
  // pto: %c16_index
  const int64_t v21 = 16;
  // pto: %c4194304_index
  const int64_t v22 = 4194304;
  // pto: %c16384_index
  const int64_t v23 = 16384;
  // pto: %c32_index
  const int64_t v24 = 32;
  // pto: %c96_index
  const int64_t v25 = 96;
  // pto: %c0_index
  const int64_t v26 = 0;
  // pto: %c2_index
  const int64_t v27 = 2;
  // pto: %c9_index
  const int64_t v28 = 9;
  // pto: %c7_index
  const int64_t v29 = 7;
  // pto: %c8_index
  const int64_t v30 = 8;
  // pto: %cn1_index
  const int64_t v31 = -1;
  // pto: %out__rv_v2_view
  const int64_t v32 = 1;
  // pto: %out__rv_v2_view
  const int64_t v33 = 1;
  // pto: %out__rv_v2_view
  const int64_t v34 = 1;
  // pto: %out__rv_v2_view
  int64_t v35 = (int64_t) v7;
  // pto: %out__rv_v2_view
  int64_t v36 = v35 * v16;
  // pto: %out__rv_v2_view
  int64_t v37 = v34 * v36;
  // pto: %out__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v38 = pto::Shape<1, 1, 1, -1, -1>(v32, v33, v34, v35, v16);
  // pto: %out__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v39 = pto::Stride<-1, -1, -1, -1, -1>(v33 * v37, v37, v36, v16, v17);
  // pto: %out__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v40 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v38, v39);
  // pto: %x_view_inline31__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %x_view_inline31__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %x_view_inline31__ssa_v0_view
  const int64_t v43 = 1;
  // pto: %x_view_inline31__ssa_v0_view
  int64_t v44 = (int64_t) v8;
  // pto: %x_view_inline31__ssa_v0_view
  int64_t v45 = v44 * v18;
  // pto: %x_view_inline31__ssa_v0_view
  int64_t v46 = v43 * v45;
  // pto: %x_view_inline31__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v47 = pto::Shape<1, 1, 1, -1, -1>(v41, v42, v43, v44, v18);
  // pto: %x_view_inline31__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v48 = pto::Stride<-1, -1, -1, -1, -1>(v42 * v46, v46, v45, v18, v17);
  // pto: %x_view_inline31__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v49 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v47, v48);
  // pto: %w__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v50 = pto::Shape<-1, -1, -1, -1, -1>(v17, v19, v20, v21, v21);
  // pto: %w__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v51 = pto::Stride<-1, -1, -1, -1, -1>(v22, v23, v19, v21, v17);
  // pto: %w__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v52 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v3, v50, v51);
  // pto: %qbg_idx_inline37__ssa_v0, %14
  int64_t v53 = (int64_t) ((uint64_t) ((int64_t) v9) * (uint64_t) v24);
  // pto: %15
  const int64_t v54 = 1;
  // pto: %15
  const int64_t v55 = 0;
  // pto: %15
  int64_t v56 = v53 / v25;
  // pto: %15
  bool v57 = v53 < v55;
  // pto: %15
  bool v58 = v25 < v55;
  // pto: %15
  bool v59 = v57 == v58;
  // pto: %15
  bool v60 = v53 % v25 != v55 && v57 != v58;
  // pto: %15
  int64_t v61 = v60 ? v56 - v54 : v56;
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  for (int64_t v62 = v26; v62 < v4; v62 += v20) {
    // pto: %dense_acc_inline43__tile
    ;
    Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v63 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v24);
    // pto: %dense_acc_inline43__tile
    ;
    uint64_t v64 = (uint64_t) v11;
    TASSIGN(v63, v64);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    for (int64_t v65 = v26; v65 < v21; v65 += v27) {
      // pto: %16
      ;
      int64_t v66 = (int64_t) ((uint64_t) v65 + (uint64_t) v17);
      // pto: %17
      ;
      bool v67 = v61 < v28;
      // pto: %dense_k_order_inline45__phi_v2
      ;
      int64_t v68;
      if (v67) {
        // pto: %18
        ;
        const int64_t v69 = 1;
        // pto: %18
        ;
        const int64_t v70 = 0;
        // pto: %18
        ;
        int64_t v71 = v65 / v27;
        // pto: %18
        ;
        bool v72 = v65 < v70;
        // pto: %18
        ;
        bool v73 = v27 < v70;
        // pto: %18
        ;
        bool v74 = v72 == v73;
        // pto: %18
        ;
        bool v75 = v65 % v27 != v70 && v72 != v73;
        // pto: %18
        ;
        int64_t v76 = v75 ? v71 - v69 : v71;
        // pto: %19
        ;
        int64_t v77 = v61 % v27;
        // pto: %20, %21, %22
        ;
        int64_t v78 = v77 < v26 ? (int64_t) ((uint64_t) v77 + (uint64_t) v27) : v77;
        // pto: %23
        ;
        // pto: %native_packet_inline46__phi_v2
        ;
        int64_t v79;
        if (v78 == v17) {
          // pto: %24
          ;
          v79 = (int64_t) ((uint64_t) v29 - (uint64_t) v76);
        } else {
          v79 = v76;
        };
        // pto: %25
        ;
        const int64_t v80 = 1;
        // pto: %25
        ;
        const int64_t v81 = 0;
        // pto: %25
        ;
        int64_t v82 = v61 / v27;
        // pto: %25
        ;
        bool v83 = v61 < v81;
        // pto: %25
        ;
        bool v84 = v27 < v81;
        // pto: %25
        ;
        bool v85 = v83 == v84;
        // pto: %25
        ;
        bool v86 = v61 % v27 != v81 && v83 != v84;
        // pto: %25
        ;
        int64_t v87 = v86 ? v82 - v80 : v82;
        // pto: %26
        ;
        uint64_t v88 = (uint64_t) v79;
        // pto: %26, %27
        ;
        int64_t v89 = (int64_t) ((uint64_t) v87 + v88) % v30;
        // pto: %28, %29, %30
        ;
        int64_t v90 = v89 < v26 ? (int64_t) ((uint64_t) v89 + (uint64_t) v30) : v89;
        // pto: %32
        ;
        int64_t v91 = v65 % v27;
        // pto: %33, %34, %35
        ;
        int64_t v92 = v91 < v26 ? (int64_t) ((uint64_t) v91 + (uint64_t) v27) : v91;
        // pto: %31, %36
        ;
        v68 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v90 * (uint64_t) v27) + (uint64_t) v92);
      } else {
        v68 = v65;
      };
      // pto: %37
      ;
      bool v93 = v68 < v26;
      // pto: %37
      ;
      int64_t v94 = v93 ? v26 : v68;
      // pto: %38
      ;
      int64_t v95 = (int64_t) ((uint64_t) v94 * (uint64_t) v19);
      // pto: %dense_x_inline48__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v96 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v19);
      // pto: %dense_x_inline48__tile
      ;
      uint64_t v97 = (uint64_t) v11;
      TASSIGN(v96, v97);
      // pto: %39
      ;
      int64_t v98 = v62 < v26 ? v26 : v62;
      // pto: %40
      ;
      int64_t v99 = v95 < v26 ? v26 : v95;
      // pto: %x_view_inline31__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v100 = PTOAS__GLOBAL_TENSOR_DATA(v49);
      // pto: %x_view_inline31__ssa_v0_pview
      ;
      const int64_t v101 = 0;
      // pto: %x_view_inline31__ssa_v0_pview
      ;
      const int64_t v102 = 4096;
      // pto: %x_view_inline31__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 64, 256> v103 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %x_view_inline31__ssa_v0_pview
      ;
      pto::Stride<262144, 262144, 262144, 4096, 1> v104 = pto::Stride<262144, 262144, 262144, 4096, 1>();
      // pto: %x_view_inline31__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND> v105 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND>(v100 + (v101 + v98 * v102 + v99), v103, v104);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v96, v105);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %dense_w_inline49__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
      // pto: %dense_w_inline49__tile
      ;
      uint64_t v107 = (uint64_t) v12;
      TASSIGN(v106, v107);
      // pto: %41
      ;
      const int64_t v108 = 1;
      // pto: %41
      ;
      const int64_t v109 = 0;
      // pto: %41
      ;
      int64_t v110 = v95 / v21;
      // pto: %41
      ;
      bool v111 = v95 < v109;
      // pto: %41
      ;
      bool v112 = v21 < v109;
      // pto: %41
      ;
      bool v113 = v111 == v112;
      // pto: %41
      ;
      bool v114 = v95 % v21 != v109 && v111 != v112;
      // pto: %41
      ;
      int64_t v115 = v114 ? v110 - v108 : v110;
      // pto: %42
      ;
      int64_t v116 = v115 < v26 ? v26 : v115;
      // pto: %43
      ;
      const int64_t v117 = 1;
      // pto: %43
      ;
      const int64_t v118 = 0;
      // pto: %43
      ;
      int64_t v119 = v53 / v21;
      // pto: %43
      ;
      bool v120 = v53 < v118;
      // pto: %43
      ;
      bool v121 = v21 < v118;
      // pto: %43
      ;
      bool v122 = v120 == v121;
      // pto: %43
      ;
      bool v123 = v53 % v21 != v118 && v120 != v121;
      // pto: %43
      ;
      int64_t v124 = v123 ? v119 - v117 : v119;
      // pto: %44
      ;
      int64_t v125 = v124 < v26 ? v26 : v124;
      // pto: %w__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v126 = PTOAS__GLOBAL_TENSOR_DATA(v52);
      // pto: %w__ssa_v0_pview
      ;
      const int64_t v127 = 0;
      // pto: %w__ssa_v0_pview
      ;
      const int64_t v128 = 16384;
      // pto: %w__ssa_v0_pview
      ;
      const int64_t v129 = 256;
      // pto: %w__ssa_v0_pview
      ;
      pto::Shape<1, 16, 2, 16, 16> v130 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %w__ssa_v0_pview
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v131 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %w__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v132 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v126 + (v127 + v116 * v128 + v125 * v129), v130, v131);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v106, v132);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %46
      ;
      int64_t v133;
      if (v67) {
        // pto: %48
        ;
        const int64_t v134 = 1;
        // pto: %48
        ;
        const int64_t v135 = 0;
        // pto: %48
        ;
        int64_t v136 = v66 / v27;
        // pto: %48
        ;
        bool v137 = v66 < v135;
        // pto: %48
        ;
        bool v138 = v27 < v135;
        // pto: %48
        ;
        bool v139 = v137 == v138;
        // pto: %48
        ;
        bool v140 = v66 % v27 != v135 && v137 != v138;
        // pto: %48
        ;
        int64_t v141 = v140 ? v136 - v134 : v136;
        // pto: %49
        ;
        int64_t v142 = v61 % v27;
        // pto: %50, %51, %52
        ;
        int64_t v143 = v142 < v26 ? (int64_t) ((uint64_t) v142 + (uint64_t) v27) : v142;
        // pto: %53
        ;
        // pto: %54
        ;
        int64_t v144;
        if (v143 == v17) {
          // pto: %55
          ;
          v144 = (int64_t) ((uint64_t) v29 - (uint64_t) v141);
        } else {
          v144 = v141;
        };
        // pto: %56
        ;
        const int64_t v145 = 1;
        // pto: %56
        ;
        const int64_t v146 = 0;
        // pto: %56
        ;
        int64_t v147 = v61 / v27;
        // pto: %56
        ;
        bool v148 = v61 < v146;
        // pto: %56
        ;
        bool v149 = v27 < v146;
        // pto: %56
        ;
        bool v150 = v148 == v149;
        // pto: %56
        ;
        bool v151 = v61 % v27 != v146 && v148 != v149;
        // pto: %56
        ;
        int64_t v152 = v151 ? v147 - v145 : v147;
        // pto: %57
        ;
        uint64_t v153 = (uint64_t) v144;
        // pto: %57, %58
        ;
        int64_t v154 = (int64_t) ((uint64_t) v152 + v153) % v30;
        // pto: %59, %60, %61
        ;
        int64_t v155 = v154 < v26 ? (int64_t) ((uint64_t) v154 + (uint64_t) v30) : v154;
        // pto: %64
        ;
        int64_t v156 = v66 % v27;
        // pto: %65, %66, %67
        ;
        int64_t v157 = v156 < v26 ? (int64_t) ((uint64_t) v156 + (uint64_t) v27) : v156;
        // pto: %62, %68
        ;
        v133 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v155 * (uint64_t) v27) + (uint64_t) v157);
      } else {
        v133 = v66;
      };
      // pto: %69
      ;
      bool v158 = v133 < v26;
      // pto: %69
      ;
      int64_t v159 = v158 ? v26 : v133;
      // pto: %70
      ;
      int64_t v160 = (int64_t) ((uint64_t) v159 * (uint64_t) v19);
      // pto: %0
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v161 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v19);
      // pto: %0
      ;
      uint64_t v162 = (uint64_t) v13;
      TASSIGN(v161, v162);
      // pto: %72
      ;
      int64_t v163 = v160 < v26 ? v26 : v160;
      // pto: %73
      ;
      __gm__ bfloat16_t* v164 = PTOAS__GLOBAL_TENSOR_DATA(v49);
      // pto: %73
      ;
      const int64_t v165 = 0;
      // pto: %73
      ;
      const int64_t v166 = 4096;
      // pto: %73
      ;
      pto::Shape<1, 1, 1, 64, 256> v167 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %73
      ;
      pto::Stride<262144, 262144, 262144, 4096, 1> v168 = pto::Stride<262144, 262144, 262144, 4096, 1>();
      // pto: %73
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND> v169 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND>(v164 + (v165 + v98 * v166 + v163), v167, v168);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v161, v169);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      // pto: %1
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v170 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
      // pto: %1
      ;
      uint64_t v171 = (uint64_t) v14;
      TASSIGN(v170, v171);
      // pto: %74
      ;
      const int64_t v172 = 1;
      // pto: %74
      ;
      const int64_t v173 = 0;
      // pto: %74
      ;
      int64_t v174 = v160 / v21;
      // pto: %74
      ;
      bool v175 = v160 < v173;
      // pto: %74
      ;
      bool v176 = v21 < v173;
      // pto: %74
      ;
      bool v177 = v175 == v176;
      // pto: %74
      ;
      bool v178 = v160 % v21 != v173 && v175 != v176;
      // pto: %74
      ;
      int64_t v179 = v178 ? v174 - v172 : v174;
      // pto: %75
      ;
      int64_t v180 = v179 < v26 ? v26 : v179;
      // pto: %78
      ;
      __gm__ bfloat16_t* v181 = PTOAS__GLOBAL_TENSOR_DATA(v52);
      // pto: %78
      ;
      const int64_t v182 = 0;
      // pto: %78
      ;
      const int64_t v183 = 16384;
      // pto: %78
      ;
      const int64_t v184 = 256;
      // pto: %78
      ;
      pto::Shape<1, 16, 2, 16, 16> v185 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %78
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v186 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %78
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v187 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v181 + (v182 + v180 * v183 + v125 * v184), v185, v186);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v170, v187);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %dense_w_inline49__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v188 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v24);
      // pto: %dense_w_inline49__tile_t
      ;
      uint64_t v189 = (uint64_t) v12;
      TASSIGN(v188, v189);
      // pto: %dense_x_inline48__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v190 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v19);
      // pto: %dense_x_inline48__tile_Left
      ;
      uint64_t v191 = (uint64_t) v12;
      TASSIGN(v190, v191);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      TMOV(v190, v96);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %dense_w_inline49__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v192 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v24);
      // pto: %dense_w_inline49__tile_t_Right
      ;
      uint64_t v193 = (uint64_t) v15;
      TASSIGN(v192, v193);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      TMOV(v192, v188);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %79
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (v65 == v26) {
        pipe_barrier(PIPE_M);
        TMATMUL(v63, v190, v192);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v63, v63, v190, v192);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      // pto: %3
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v194 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v24);
      // pto: %3
      ;
      uint64_t v195 = (uint64_t) v14;
      TASSIGN(v194, v195);
      // pto: %4
      ;
      Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v196 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v19);
      // pto: %4
      ;
      uint64_t v197 = (uint64_t) v11;
      TASSIGN(v196, v197);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      TMOV(v196, v161);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      // pto: %5
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v198 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v24);
      // pto: %5
      ;
      uint64_t v199 = (uint64_t) v11;
      TASSIGN(v198, v199);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      TMOV(v198, v194);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      // pto: %80
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      if (v65 == v31) {
        pipe_barrier(PIPE_M);
        TMATMUL(v63, v196, v198);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v63, v63, v196, v198);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    };
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %81
    ;
    int64_t v200 = v62 < v26 ? v26 : v62;
    // pto: %82
    ;
    int64_t v201 = v53 < v26 ? v26 : v53;
    // pto: %out__iter_v6_pview
    ;
    __gm__ float* v202 = PTOAS__GLOBAL_TENSOR_DATA(v40);
    // pto: %out__iter_v6_pview
    ;
    const int64_t v203 = 0;
    // pto: %out__iter_v6_pview
    ;
    const int64_t v204 = 1024;
    // pto: %out__iter_v6_pview
    ;
    pto::Shape<1, 1, 1, 64, 32> v205 = pto::Shape<1, 1, 1, 64, 32>();
    // pto: %out__iter_v6_pview
    ;
    pto::Stride<65536, 65536, 65536, 1024, 1> v206 = pto::Stride<65536, 65536, 65536, 1024, 1>();
    // pto: %out__iter_v6_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 64, 32>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND> v207 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 32>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND>(v202 + (v203 + v200 * v204 + v201), v205, v206);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE(v207, v63);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  for (int64_t v208 = v4; v208 < v5; v208 += v21) {
    // pto: %q_acc_inline51__tile
    ;
    Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v209 = Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v21, v24);
    // pto: %q_acc_inline51__tile
    ;
    uint64_t v210 = (uint64_t) v11;
    TASSIGN(v209, v210);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    for (int64_t v211 = v26; v211 < v21; v211 += v27) {
      // pto: %83
      ;
      int64_t v212 = (int64_t) ((uint64_t) v6 - (uint64_t) v208);
      // pto: %84
      ;
      int64_t v213 = v212 < v21 ? v212 : v21;
      // pto: %85
      ;
      int64_t v214 = (int64_t) ((uint64_t) v211 + (uint64_t) v17);
      // pto: %88
      ;
      bool v215 = v61 < v28;
      // pto: %qr_k_order_inline53__phi_v2
      ;
      int64_t v216;
      if (v215) {
        // pto: %89
        ;
        const int64_t v217 = 1;
        // pto: %89
        ;
        const int64_t v218 = 0;
        // pto: %89
        ;
        int64_t v219 = v211 / v27;
        // pto: %89
        ;
        bool v220 = v211 < v218;
        // pto: %89
        ;
        bool v221 = v27 < v218;
        // pto: %89
        ;
        bool v222 = v220 == v221;
        // pto: %89
        ;
        bool v223 = v211 % v27 != v218 && v220 != v221;
        // pto: %89
        ;
        int64_t v224 = v223 ? v219 - v217 : v219;
        // pto: %90
        ;
        int64_t v225 = v61 % v27;
        // pto: %91, %92, %93
        ;
        int64_t v226 = v225 < v26 ? (int64_t) ((uint64_t) v225 + (uint64_t) v27) : v225;
        // pto: %94
        ;
        // pto: %native_packet_v1_inline54__phi_v2
        ;
        int64_t v227;
        if (v226 == v17) {
          // pto: %95
          ;
          v227 = (int64_t) ((uint64_t) v29 - (uint64_t) v224);
        } else {
          v227 = v224;
        };
        // pto: %96
        ;
        const int64_t v228 = 1;
        // pto: %96
        ;
        const int64_t v229 = 0;
        // pto: %96
        ;
        int64_t v230 = v61 / v27;
        // pto: %96
        ;
        bool v231 = v61 < v229;
        // pto: %96
        ;
        bool v232 = v27 < v229;
        // pto: %96
        ;
        bool v233 = v231 == v232;
        // pto: %96
        ;
        bool v234 = v61 % v27 != v229 && v231 != v232;
        // pto: %96
        ;
        int64_t v235 = v234 ? v230 - v228 : v230;
        // pto: %97
        ;
        uint64_t v236 = (uint64_t) v227;
        // pto: %97, %98
        ;
        int64_t v237 = (int64_t) ((uint64_t) v235 + v236) % v30;
        // pto: %99, %100, %101
        ;
        int64_t v238 = v237 < v26 ? (int64_t) ((uint64_t) v237 + (uint64_t) v30) : v237;
        // pto: %103
        ;
        int64_t v239 = v211 % v27;
        // pto: %104, %105, %106
        ;
        int64_t v240 = v239 < v26 ? (int64_t) ((uint64_t) v239 + (uint64_t) v27) : v239;
        // pto: %102, %107
        ;
        v216 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v238 * (uint64_t) v27) + (uint64_t) v240);
      } else {
        v216 = v211;
      };
      // pto: %108
      ;
      bool v241 = v216 < v26;
      // pto: %108
      ;
      int64_t v242 = v241 ? v26 : v216;
      // pto: %109
      ;
      int64_t v243 = (int64_t) ((uint64_t) v242 * (uint64_t) v19);
      // pto: %q_x_chunk_bf16_inline58__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v244 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v213, v19);
      // pto: %q_x_chunk_bf16_inline58__tile
      ;
      uint64_t v245 = (uint64_t) v12;
      TASSIGN(v244, v245);
      // pto: %110
      ;
      int64_t v246 = v208 < v26 ? v26 : v208;
      // pto: %111
      ;
      int64_t v247 = v243 < v26 ? v26 : v243;
      // pto: %112
      ;
      const int64_t v248 = 0;
      // pto: %112
      ;
      __gm__ bfloat16_t* v249 = PTOAS__GLOBAL_TENSOR_DATA(v49);
      // pto: %112
      ;
      const int64_t v250 = 1;
      // pto: %112
      ;
      const int64_t v251 = 1;
      // pto: %112
      ;
      const int64_t v252 = 1;
      // pto: %112
      ;
      int64_t v253 = v213 * v18;
      // pto: %112
      ;
      int64_t v254 = v252 * v253;
      // pto: %112
      ;
      pto::Shape<1, 1, 1, -1, 256> v255 = pto::Shape<1, 1, 1, -1, 256>(v250, v251, v252, v213, v19);
      // pto: %112
      ;
      pto::Stride<-1, -1, -1, -1, -1> v256 = pto::Stride<-1, -1, -1, -1, -1>(v251 * v254, v254, v253, v18, v17);
      // pto: %112
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v257 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v249 + (v248 + v246 * v18 + v247 * v17), v255, v256);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      TLOAD(v244, v257);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      // pto: %w_chunk_inline59__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v258 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
      // pto: %w_chunk_inline59__tile
      ;
      uint64_t v259 = (uint64_t) v11;
      TASSIGN(v258, v259);
      // pto: %113
      ;
      const int64_t v260 = 1;
      // pto: %113
      ;
      const int64_t v261 = 0;
      // pto: %113
      ;
      int64_t v262 = v243 / v21;
      // pto: %113
      ;
      bool v263 = v243 < v261;
      // pto: %113
      ;
      bool v264 = v21 < v261;
      // pto: %113
      ;
      bool v265 = v263 == v264;
      // pto: %113
      ;
      bool v266 = v243 % v21 != v261 && v263 != v264;
      // pto: %113
      ;
      int64_t v267 = v266 ? v262 - v260 : v262;
      // pto: %114
      ;
      int64_t v268 = v267 < v26 ? v26 : v267;
      // pto: %115
      ;
      const int64_t v269 = 1;
      // pto: %115
      ;
      const int64_t v270 = 0;
      // pto: %115
      ;
      int64_t v271 = v53 / v21;
      // pto: %115
      ;
      bool v272 = v53 < v270;
      // pto: %115
      ;
      bool v273 = v21 < v270;
      // pto: %115
      ;
      bool v274 = v272 == v273;
      // pto: %115
      ;
      bool v275 = v53 % v21 != v270 && v272 != v273;
      // pto: %115
      ;
      int64_t v276 = v275 ? v271 - v269 : v271;
      // pto: %116
      ;
      int64_t v277 = v276 < v26 ? v26 : v276;
      // pto: %117
      ;
      __gm__ bfloat16_t* v278 = PTOAS__GLOBAL_TENSOR_DATA(v52);
      // pto: %117
      ;
      const int64_t v279 = 0;
      // pto: %117
      ;
      const int64_t v280 = 16384;
      // pto: %117
      ;
      const int64_t v281 = 256;
      // pto: %117
      ;
      pto::Shape<1, 16, 2, 16, 16> v282 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %117
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v283 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %117
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v284 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v278 + (v279 + v268 * v280 + v277 * v281), v282, v283);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      TLOAD(v258, v284);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      // pto: %119
      ;
      int64_t v285;
      if (v215) {
        // pto: %121
        ;
        const int64_t v286 = 1;
        // pto: %121
        ;
        const int64_t v287 = 0;
        // pto: %121
        ;
        int64_t v288 = v214 / v27;
        // pto: %121
        ;
        bool v289 = v214 < v287;
        // pto: %121
        ;
        bool v290 = v27 < v287;
        // pto: %121
        ;
        bool v291 = v289 == v290;
        // pto: %121
        ;
        bool v292 = v214 % v27 != v287 && v289 != v290;
        // pto: %121
        ;
        int64_t v293 = v292 ? v288 - v286 : v288;
        // pto: %122
        ;
        int64_t v294 = v61 % v27;
        // pto: %123, %124, %125
        ;
        int64_t v295 = v294 < v26 ? (int64_t) ((uint64_t) v294 + (uint64_t) v27) : v294;
        // pto: %126
        ;
        // pto: %127
        ;
        int64_t v296;
        if (v295 == v17) {
          // pto: %128
          ;
          v296 = (int64_t) ((uint64_t) v29 - (uint64_t) v293);
        } else {
          v296 = v293;
        };
        // pto: %129
        ;
        const int64_t v297 = 1;
        // pto: %129
        ;
        const int64_t v298 = 0;
        // pto: %129
        ;
        int64_t v299 = v61 / v27;
        // pto: %129
        ;
        bool v300 = v61 < v298;
        // pto: %129
        ;
        bool v301 = v27 < v298;
        // pto: %129
        ;
        bool v302 = v300 == v301;
        // pto: %129
        ;
        bool v303 = v61 % v27 != v298 && v300 != v301;
        // pto: %129
        ;
        int64_t v304 = v303 ? v299 - v297 : v299;
        // pto: %130
        ;
        uint64_t v305 = (uint64_t) v296;
        // pto: %130, %131
        ;
        int64_t v306 = (int64_t) ((uint64_t) v304 + v305) % v30;
        // pto: %132, %133, %134
        ;
        int64_t v307 = v306 < v26 ? (int64_t) ((uint64_t) v306 + (uint64_t) v30) : v306;
        // pto: %137
        ;
        int64_t v308 = v214 % v27;
        // pto: %138, %139, %140
        ;
        int64_t v309 = v308 < v26 ? (int64_t) ((uint64_t) v308 + (uint64_t) v27) : v308;
        // pto: %135, %141
        ;
        v285 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v307 * (uint64_t) v27) + (uint64_t) v309);
      } else {
        v285 = v214;
      };
      // pto: %142
      ;
      bool v310 = v285 < v26;
      // pto: %142
      ;
      int64_t v311 = v310 ? v26 : v285;
      // pto: %143
      ;
      int64_t v312 = (int64_t) ((uint64_t) v311 * (uint64_t) v19);
      // pto: %7
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v213, v19);
      // pto: %7
      ;
      uint64_t v314 = (uint64_t) v14;
      TASSIGN(v313, v314);
      // pto: %145
      ;
      int64_t v315 = v312 < v26 ? v26 : v312;
      // pto: %146
      ;
      const int64_t v316 = 0;
      // pto: %146
      ;
      __gm__ bfloat16_t* v317 = PTOAS__GLOBAL_TENSOR_DATA(v49);
      // pto: %146
      ;
      const int64_t v318 = 1;
      // pto: %146
      ;
      const int64_t v319 = 1;
      // pto: %146
      ;
      const int64_t v320 = 1;
      // pto: %146
      ;
      int64_t v321 = v213 * v18;
      // pto: %146
      ;
      int64_t v322 = v320 * v321;
      // pto: %146
      ;
      pto::Shape<1, 1, 1, -1, 256> v323 = pto::Shape<1, 1, 1, -1, 256>(v318, v319, v320, v213, v19);
      // pto: %146
      ;
      pto::Stride<-1, -1, -1, -1, -1> v324 = pto::Stride<-1, -1, -1, -1, -1>(v319 * v322, v322, v321, v18, v17);
      // pto: %146
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v325 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v317 + (v316 + v246 * v18 + v315 * v17), v323, v324);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      TLOAD(v313, v325);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
      // pto: %8
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v326 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v24, v19);
      // pto: %8
      ;
      uint64_t v327 = (uint64_t) v13;
      TASSIGN(v326, v327);
      // pto: %147
      ;
      const int64_t v328 = 1;
      // pto: %147
      ;
      const int64_t v329 = 0;
      // pto: %147
      ;
      int64_t v330 = v312 / v21;
      // pto: %147
      ;
      bool v331 = v312 < v329;
      // pto: %147
      ;
      bool v332 = v21 < v329;
      // pto: %147
      ;
      bool v333 = v331 == v332;
      // pto: %147
      ;
      bool v334 = v312 % v21 != v329 && v331 != v332;
      // pto: %147
      ;
      int64_t v335 = v334 ? v330 - v328 : v330;
      // pto: %148
      ;
      int64_t v336 = v335 < v26 ? v26 : v335;
      // pto: %151
      ;
      __gm__ bfloat16_t* v337 = PTOAS__GLOBAL_TENSOR_DATA(v52);
      // pto: %151
      ;
      const int64_t v338 = 0;
      // pto: %151
      ;
      const int64_t v339 = 16384;
      // pto: %151
      ;
      const int64_t v340 = 256;
      // pto: %151
      ;
      pto::Shape<1, 16, 2, 16, 16> v341 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %151
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v342 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %151
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v343 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v337 + (v338 + v336 * v339 + v277 * v340), v341, v342);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v326, v343);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
      // pto: %w_chunk_inline59__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v344 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v24);
      // pto: %w_chunk_inline59__tile_t
      ;
      uint64_t v345 = (uint64_t) v11;
      TASSIGN(v344, v345);
      // pto: %q_x_chunk_bf16_inline58__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v346 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v213, v19);
      // pto: %q_x_chunk_bf16_inline58__tile_Left
      ;
      uint64_t v347 = (uint64_t) v12;
      TASSIGN(v346, v347);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      TMOV(v346, v244);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      // pto: %w_chunk_inline59__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v348 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v24);
      // pto: %w_chunk_inline59__tile_t_Right
      ;
      uint64_t v349 = (uint64_t) v15;
      TASSIGN(v348, v349);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      TMOV(v348, v344);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      // pto: %152
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      if (v211 == v26) {
        pipe_barrier(PIPE_M);
        TMATMUL(v209, v346, v348);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v209, v209, v346, v348);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      // pto: %10
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v350 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v24);
      // pto: %10
      ;
      uint64_t v351 = (uint64_t) v13;
      TASSIGN(v350, v351);
      // pto: %11
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v352 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v213, v19);
      // pto: %11
      ;
      uint64_t v353 = (uint64_t) v11;
      TASSIGN(v352, v353);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      TMOV(v352, v313);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      // pto: %12
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v354 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v24);
      // pto: %12
      ;
      uint64_t v355 = (uint64_t) v11;
      TASSIGN(v354, v355);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
      TMOV(v354, v350);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %153
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      if (v211 == v31) {
        pipe_barrier(PIPE_M);
        TMATMUL(v209, v352, v354);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v209, v209, v352, v354);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    };
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
    // pto: %155
    ;
    int64_t v356 = v208 < v26 ? v26 : v208;
    // pto: %156
    ;
    int64_t v357 = v53 < v26 ? v26 : v53;
    // pto: %out__iter_v9_pview
    ;
    __gm__ float* v358 = PTOAS__GLOBAL_TENSOR_DATA(v40);
    // pto: %out__iter_v9_pview
    ;
    const int64_t v359 = 0;
    // pto: %out__iter_v9_pview
    ;
    const int64_t v360 = 1024;
    // pto: %out__iter_v9_pview
    ;
    pto::Shape<1, 1, 1, 16, 32> v361 = pto::Shape<1, 1, 1, 16, 32>();
    // pto: %out__iter_v9_pview
    ;
    pto::Stride<16384, 16384, 16384, 1024, 1> v362 = pto::Stride<16384, 16384, 16384, 1024, 1>();
    // pto: %out__iter_v9_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND> v363 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND>(v358 + (v359 + v356 * v360 + v357), v361, v362);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
    pipe_barrier(PIPE_FIX);
    TSTORE(v363, v209);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}