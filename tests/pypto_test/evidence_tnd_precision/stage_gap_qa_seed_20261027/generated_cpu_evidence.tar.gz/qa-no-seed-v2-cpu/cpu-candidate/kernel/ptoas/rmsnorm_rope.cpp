#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void rmsnorm_rope(__gm__ bfloat16_t* v1, __gm__ int64_t* v2, __gm__ int32_t* v3, __gm__ int32_t* v4, __gm__ float* v5, __gm__ float* v6, __gm__ float* v7, __gm__ bfloat16_t* v8, __gm__ int32_t* v9, int64_t v10, int64_t v11, int64_t v12, int64_t v13, int64_t v14, int64_t v15, int64_t v16, int32_t v17, int32_t v18) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v19 = 128;
  const int64_t v20 = 256;
  // pto: %c20480_i64
  const int64_t v21 = 20480;
  // pto: %c0_i64
  const int64_t v22 = 0;
  // pto: %c4096_i64
  const int64_t v23 = 4096;
  // pto: %c8192_i64
  const int64_t v24 = 8192;
  // pto: %c12288_i64
  const int64_t v25 = 12288;
  // pto: %c16384_i64
  const int64_t v26 = 16384;
  // pto: %c30976_i64
  const int64_t v27 = 30976;
  // pto: %c30720_i64
  const int64_t v28 = 30720;
  // pto: %c28672_i64
  const int64_t v29 = 28672;
  // pto: %c384_index
  const int64_t v30 = 384;
  // pto: %c128_index
  const int64_t v31 = 128;
  // pto: %c1_index
  const int64_t v32 = 1;
  // pto: %c64_index
  const int64_t v33 = 64;
  // pto: %c16_index
  const int64_t v34 = 16;
  // pto: %cst_14
  const float v35 = 1.0f;
  // pto: %c192_index
  const int64_t v36 = 192;
  // pto: %c0_i32
  const int32_t v37 = 0;
  // pto: %cst_17
  const float v38 = 0.5f;
  // pto: %cst_18
  const float v39 = 2.0f;
  // pto: %cst_19
  const float v40 = 0.0f;
  // pto: %c0_index
  const int64_t v41 = 0;
  // pto: %c1_i64
  const int64_t v42 = 1;
  // pto: %c4_i64
  const int64_t v43 = 4;
  // pto: %cst_23
  const float v44 = 0.0078125f;
  // pto: %cst_24
  const float v45 = 9.99999997E-7f;
  // pto: %c3_index
  const int64_t v46 = 3;
  // pto: %c2_index
  const int64_t v47 = 2;
  // pto: %c4_index
  const int64_t v48 = 4;
  // pto: %normed_kv_inline3323__ssa_v1_view
  const int64_t v49 = 1;
  // pto: %normed_kv_inline3323__ssa_v1_view
  const int64_t v50 = 1;
  // pto: %normed_kv_inline3323__ssa_v1_view
  const int64_t v51 = 1;
  // pto: %normed_kv_inline3323__ssa_v1_view
  int64_t v52 = v30 * v31;
  // pto: %normed_kv_inline3323__ssa_v1_view
  int64_t v53 = v51 * v52;
  // pto: %normed_kv_inline3323__ssa_v1_view
  pto::Shape<1, 1, 1, -1, -1> v54 = pto::Shape<1, 1, 1, -1, -1>(v49, v50, v51, v30, v31);
  // pto: %normed_kv_inline3323__ssa_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v55 = pto::Stride<-1, -1, -1, -1, -1>(v50 * v53, v53, v52, v31, v32);
  // pto: %normed_kv_inline3323__ssa_v1_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v56 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v54, v55);
  // pto: %inner_freqs_cos__ssa_v0_view
  const int64_t v57 = 1;
  // pto: %inner_freqs_cos__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %inner_freqs_cos__ssa_v0_view
  const int64_t v59 = 1;
  // pto: %inner_freqs_cos__ssa_v0_view
  int64_t v60 = (int64_t) v15;
  // pto: %inner_freqs_cos__ssa_v0_view
  int64_t v61 = v60 * v33;
  // pto: %inner_freqs_cos__ssa_v0_view
  int64_t v62 = v59 * v61;
  // pto: %inner_freqs_cos__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v63 = pto::Shape<1, 1, 1, -1, -1>(v57, v58, v59, v60, v33);
  // pto: %inner_freqs_cos__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v64 = pto::Stride<-1, -1, -1, -1, -1>(v58 * v62, v62, v61, v33, v32);
  // pto: %inner_freqs_cos__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v65 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v63, v64);
  // pto: %inner_freqs_sin__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %inner_freqs_sin__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %inner_freqs_sin__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %inner_freqs_sin__ssa_v0_view
  int64_t v69 = (int64_t) v15;
  // pto: %inner_freqs_sin__ssa_v0_view
  int64_t v70 = v69 * v33;
  // pto: %inner_freqs_sin__ssa_v0_view
  int64_t v71 = v68 * v70;
  // pto: %inner_freqs_sin__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v72 = pto::Shape<1, 1, 1, -1, -1>(v66, v67, v68, v69, v33);
  // pto: %inner_freqs_sin__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v73 = pto::Stride<-1, -1, -1, -1, -1>(v67 * v71, v71, v70, v33, v32);
  // pto: %inner_freqs_sin__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v74 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v72, v73);
  // pto: %pooled_kv_inline3332__rv_v2_view
  const int64_t v75 = 1;
  // pto: %pooled_kv_inline3332__rv_v2_view
  const int64_t v76 = 1;
  // pto: %pooled_kv_inline3332__rv_v2_view
  const int64_t v77 = 1;
  // pto: %pooled_kv_inline3332__rv_v2_view
  int64_t v78 = v30 * v31;
  // pto: %pooled_kv_inline3332__rv_v2_view
  int64_t v79 = v77 * v78;
  // pto: %pooled_kv_inline3332__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v80 = pto::Shape<1, 1, 1, -1, -1>(v75, v76, v77, v30, v31);
  // pto: %pooled_kv_inline3332__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v81 = pto::Stride<-1, -1, -1, -1, -1>(v76 * v79, v79, v78, v31, v32);
  // pto: %pooled_kv_inline3332__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v82 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v80, v81);
  // pto: %norm_w_2d_inline3413__ssa_v0_view
  const int64_t v83 = 1;
  // pto: %norm_w_2d_inline3413__ssa_v0_view
  const int64_t v84 = 1;
  // pto: %norm_w_2d_inline3413__ssa_v0_view
  const int64_t v85 = 1;
  // pto: %norm_w_2d_inline3413__ssa_v0_view
  int64_t v86 = v32 * v31;
  // pto: %norm_w_2d_inline3413__ssa_v0_view
  int64_t v87 = v85 * v86;
  // pto: %norm_w_2d_inline3413__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v88 = pto::Shape<1, 1, 1, -1, -1>(v83, v84, v85, v32, v31);
  // pto: %norm_w_2d_inline3413__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v89 = pto::Stride<-1, -1, -1, -1, -1>(v84 * v87, v87, v86, v31, v32);
  // pto: %norm_w_2d_inline3413__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v90 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v88, v89);
  // pto: %cosine_inline3455__phi_v5
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v91 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %cosine_inline3455__phi_v5
  uint64_t v92 = (uint64_t) v24;
  TASSIGN(v91, v92);
  // pto: %sine_inline3456__phi_v5
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %sine_inline3456__phi_v5
  uint64_t v94 = (uint64_t) v25;
  TASSIGN(v93, v94);
  // pto: %cosine_inline3455__phi_v4
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v95 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %cosine_inline3455__phi_v4
  uint64_t v96 = (uint64_t) v24;
  TASSIGN(v95, v96);
  // pto: %sine_inline3456__phi_v4
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %sine_inline3456__phi_v4
  uint64_t v98 = (uint64_t) v25;
  TASSIGN(v97, v98);
  // pto: %rms_worker_inline3419__ssa_v0
  // pto: %rope_ones_inline3420__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %rope_ones_inline3420__tile
  uint64_t v100 = (uint64_t) v21;
  TASSIGN(v99, v100);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  TEXPANDS(v99, v35);
  // pto: %rope_index_inline3421__ci_tmp_v0
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v36);
  // pto: %rope_index_inline3421__ci_tmp_v0
  uint64_t v102 = (uint64_t) v22;
  TASSIGN(v101, v102);
  // pto: %rope_index_inline3421__tile
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
  // pto: %rope_index_inline3421__tile
  uint64_t v104 = (uint64_t) v23;
  TASSIGN(v103, v104);
  // pto: %ci_tmp_view
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v105;
  TRESHAPE(v105, v101);
  // pto: %ci_dst_view
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v106;
  TRESHAPE(v106, v103);
  TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v106, v37, v105);
  // pto: %rope_index_f_inline3422__tile
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v107 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
  // pto: %rope_index_f_inline3422__tile
  uint64_t v108 = (uint64_t) v22;
  TASSIGN(v107, v108);
  pipe_barrier(PIPE_V);
  RoundMode v109 = RoundMode::CAST_ROUND;
  SaturationMode v110 = SaturationMode::ON;
  TCVT(v107, v103, v109, v110);
  // pto: %rope_col_inline3423__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %rope_col_inline3423__tile
  uint64_t v112 = (uint64_t) v21;
  TASSIGN(v111, v112);
  pipe_barrier(PIPE_V);
  TCOLEXPANDMUL(v111, v99, v107);
  // pto: %t__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %t__tile
  uint64_t v114 = (uint64_t) v22;
  TASSIGN(v113, v114);
  pipe_barrier(PIPE_V);
  TMULS(v113, v111, v38);
  // pto: %0
  Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v115 = Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %0
  uint64_t v116 = (uint64_t) v22;
  TASSIGN(v115, v116);
  pipe_barrier(PIPE_V);
  RoundMode v117 = RoundMode::CAST_TRUNC;
  SaturationMode v118 = SaturationMode::ON;
  TCVT(v115, v113, v117, v118);
  // pto: %rope_dup_f_inline3424__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v119 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %rope_dup_f_inline3424__tile
  uint64_t v120 = (uint64_t) v22;
  TASSIGN(v119, v120);
  pipe_barrier(PIPE_V);
  RoundMode v121 = RoundMode::CAST_ROUND;
  SaturationMode v122 = SaturationMode::ON;
  TCVT(v119, v115, v121, v122);
  // pto: %1
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v123 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %1
  uint64_t v124 = (uint64_t) v22;
  TASSIGN(v123, v124);
  pipe_barrier(PIPE_V);
  TMULS(v123, v119, v39);
  // pto: %rope_lane_inline3425__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v125 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %rope_lane_inline3425__tile
  uint64_t v126 = (uint64_t) v22;
  TASSIGN(v125, v126);
  pipe_barrier(PIPE_V);
  TSUB(v125, v111, v123);
  // pto: %2
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %2
  uint64_t v128 = (uint64_t) v21;
  TASSIGN(v127, v128);
  pipe_barrier(PIPE_V);
  TADDS(v127, v111, v35);
  // pto: %3
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %3
  uint64_t v130 = (uint64_t) v23;
  TASSIGN(v129, v130);
  TMULS(v129, v125, v39);
  // pto: %4
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %4
  uint64_t v132 = (uint64_t) v21;
  TASSIGN(v131, v132);
  pipe_barrier(PIPE_V);
  TSUB(v131, v127, v129);
  // pto: %rope_swap_idx_inline3426__tile
  Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
  // pto: %rope_swap_idx_inline3426__tile
  uint64_t v134 = (uint64_t) v23;
  TASSIGN(v133, v134);
  pipe_barrier(PIPE_V);
  RoundMode v135 = RoundMode::CAST_ROUND;
  SaturationMode v136 = SaturationMode::ON;
  TCVT(v133, v131, v135, v136);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v137 = (int64_t) v17; v137 < v10; v137 += v11) {
    // pto: %20
    ;
    int64_t v138 = (int64_t) ((uint64_t) v137 * (uint64_t) v34);
    // pto: %21
    ;
    int64_t v139 = (int64_t) ((uint64_t) v12 - (uint64_t) v138);
    // pto: %22
    ;
    int64_t v140 = v139 < v34 ? v139 : v34;
    // pto: %cosine_inline3455__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v141 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %cosine_inline3455__tile
    ;
    uint64_t v142 = (uint64_t) v24;
    TASSIGN(v141, v142);
    TEXPANDS(v141, v35);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    // pto: %sine_inline3456__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v143 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %sine_inline3456__tile
    ;
    uint64_t v144 = (uint64_t) v25;
    TASSIGN(v143, v144);
    TEXPANDS(v143, v40);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    for (int64_t v145 = v41; v145 < v140; v145 += v32) {
      // pto: %23
      ;
      int64_t v146 = (int64_t) ((uint64_t) v138 + (uint64_t) v145);
      // pto: %position_inline3459__tile
      ;
      int64_t v147 = (v2)[v146];
      // pto: %24
      ;
      int32_t v148 = (v3)[v146];
      // pto: %25
      ;
      int64_t v149 = (int64_t) v148;
      // pto: %27
      ;
      int64_t v150 = (int64_t) ((uint64_t) v147 + (uint64_t) v42);
      // pto: %28
      ;
      int64_t v151 = v150 % v43;
      // pto: %29, %30, %31
      ;
      int64_t v152 = v151 < v22 ? (int64_t) ((uint64_t) v151 + (uint64_t) v43) : v151;
      // pto: %26, %32, %33
      ;
      if (v149 >= v41 & v152 == v22) {
        // pto: %34
        ;
        int32_t v153 = (v4)[v149];
        // pto: %37
        ;
        const int64_t v154 = 1;
        // pto: %37
        ;
        const int64_t v155 = 0;
        // pto: %37
        ;
        int64_t v156 = v150 / v43;
        // pto: %37
        ;
        bool v157 = v150 < v155;
        // pto: %37
        ;
        bool v158 = v43 < v155;
        // pto: %37
        ;
        bool v159 = v157 == v158;
        // pto: %37
        ;
        bool v160 = v150 % v43 != v155 && v157 != v158;
        // pto: %37
        ;
        int64_t v161 = v160 ? v156 - v154 : v156;
        // pto: %35, %39
        ;
        int64_t v162 = (int64_t) ((uint64_t) ((int64_t) v153) + (uint64_t) v161);
        // pto: %40, %41, %42
        ;
        if (v162 >= v41 & v162 < v15) {
          // pto: %gather_row_view
          ;
          int64_t v163 = (int64_t) ((uint64_t) v145 * (uint64_t) v20);
          // pto: %gather_row_view
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v164;
          // pto: %gather_row_view
          ;
          uint64_t v165 = (uint64_t) ((int64_t) (uint64_t) v163 + (uint64_t) v24);
          TASSIGN(v164, v165);
          // pto: %43
          ;
          int64_t v166 = v162 < v41 ? v41 : v162;
          // pto: %inner_freqs_cos__ssa_v0_pview
          ;
          __gm__ float* v167 = PTOAS__GLOBAL_TENSOR_DATA(v65);
          // pto: %inner_freqs_cos__ssa_v0_pview
          ;
          const int64_t v168 = 0;
          // pto: %inner_freqs_cos__ssa_v0_pview
          ;
          const int64_t v169 = 64;
          // pto: %inner_freqs_cos__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 1, 64> v170 = pto::Shape<1, 1, 1, 1, 64>();
          // pto: %inner_freqs_cos__ssa_v0_pview
          ;
          pto::Stride<64, 64, 64, 64, 1> v171 = pto::Stride<64, 64, 64, 64, 1>();
          // pto: %inner_freqs_cos__ssa_v0_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v172 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v167 + (v168 + v166 * v169), v170, v171);
          TLOAD(v164, v172);
          // pto: %44
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v173;
          // pto: %44
          ;
          uint64_t v174 = (uint64_t) ((int64_t) (uint64_t) v163 + (uint64_t) v25);
          TASSIGN(v173, v174);
          // pto: %inner_freqs_sin__ssa_v0_pview
          ;
          __gm__ float* v175 = PTOAS__GLOBAL_TENSOR_DATA(v74);
          // pto: %inner_freqs_sin__ssa_v0_pview
          ;
          const int64_t v176 = 0;
          // pto: %inner_freqs_sin__ssa_v0_pview
          ;
          const int64_t v177 = 64;
          // pto: %inner_freqs_sin__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 1, 64> v178 = pto::Shape<1, 1, 1, 1, 64>();
          // pto: %inner_freqs_sin__ssa_v0_pview
          ;
          pto::Stride<64, 64, 64, 64, 1> v179 = pto::Stride<64, 64, 64, 64, 1>();
          // pto: %inner_freqs_sin__ssa_v0_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v180 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v175 + (v176 + v166 * v177), v178, v179);
          TLOAD(v173, v180);
        };
      };
    };
    // pto: %cos_b_inline3431__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %cos_b_inline3431__ssa_v0
    ;
    uint64_t v182 = (uint64_t) v24;
    TASSIGN(v181, v182);
    // pto: %sin_b_inline3432__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %sin_b_inline3432__ssa_v0
    ;
    uint64_t v184 = (uint64_t) v25;
    TASSIGN(v183, v184);
    // pto: %kv_rms_low_inline3433__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v185 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %kv_rms_low_inline3433__tile
    ;
    uint64_t v186 = (uint64_t) v21;
    TASSIGN(v185, v186);
    // pto: %46
    ;
    int64_t v187 = v138 < v41 ? v41 : v138;
    // pto: %pooled_kv_inline3332__rv_v2_pview
    ;
    __gm__ float* v188 = PTOAS__GLOBAL_TENSOR_DATA(v82);
    // pto: %pooled_kv_inline3332__rv_v2_pview
    ;
    const int64_t v189 = 0;
    // pto: %pooled_kv_inline3332__rv_v2_pview
    ;
    const int64_t v190 = 128;
    // pto: %pooled_kv_inline3332__rv_v2_pview
    ;
    pto::Shape<1, 1, 1, 16, 64> v191 = pto::Shape<1, 1, 1, 16, 64>();
    // pto: %pooled_kv_inline3332__rv_v2_pview
    ;
    pto::Stride<2048, 2048, 2048, 128, 1> v192 = pto::Stride<2048, 2048, 2048, 128, 1>();
    // pto: %pooled_kv_inline3332__rv_v2_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<2048, 2048, 2048, 128, 1>, pto::Layout::ND> v193 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<2048, 2048, 2048, 128, 1>, pto::Layout::ND>(v188 + (v189 + v187 * v190), v191, v192);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    TLOAD(v185, v193);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %kv_rms_high_inline3434__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v194 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %kv_rms_high_inline3434__tile
    ;
    uint64_t v195 = (uint64_t) v26;
    TASSIGN(v194, v195);
    // pto: %48
    ;
    __gm__ float* v196 = PTOAS__GLOBAL_TENSOR_DATA(v82);
    // pto: %48
    ;
    const int64_t v197 = 64;
    // pto: %48
    ;
    const int64_t v198 = 128;
    // pto: %48
    ;
    pto::Shape<1, 1, 1, 16, 64> v199 = pto::Shape<1, 1, 1, 16, 64>();
    // pto: %48
    ;
    pto::Stride<2048, 2048, 2048, 128, 1> v200 = pto::Stride<2048, 2048, 2048, 128, 1>();
    // pto: %48
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<2048, 2048, 2048, 128, 1>, pto::Layout::ND> v201 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<2048, 2048, 2048, 128, 1>, pto::Layout::ND>(v196 + (v197 + v187 * v198), v199, v200);
    TLOAD(v194, v201);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %7
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v202 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %7
    ;
    uint64_t v203 = (uint64_t) v21;
    TASSIGN(v202, v203);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TMUL(v202, v185, v185);
    // pto: %8
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v204 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %8
    ;
    uint64_t v205 = (uint64_t) v26;
    TASSIGN(v204, v205);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    TMUL(v204, v194, v194);
    // pto: %folded_sq_inline3435__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v206 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %folded_sq_inline3435__tile
    ;
    uint64_t v207 = (uint64_t) v26;
    TASSIGN(v206, v207);
    pipe_barrier(PIPE_V);
    TADD(v206, v202, v204);
    // pto: %tmp_tile
    ;
    Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v208 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v31);
    // pto: %tmp_tile
    ;
    uint64_t v209 = (uint64_t) v21;
    TASSIGN(v208, v209);
    // pto: %square_sum_inline3436__tile
    ;
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v210 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v32);
    // pto: %square_sum_inline3436__tile
    ;
    uint64_t v211 = (uint64_t) v27;
    TASSIGN(v210, v211);
    pipe_barrier(PIPE_V);
    TROWSUM(v210, v206, v208);
    // pto: %t__rm_a0_tmp_v0
    ;
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v212 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v34);
    // pto: %t__rm_a0_tmp_v0
    ;
    uint64_t v213 = (uint64_t) v27;
    TASSIGN(v212, v213);
    // pto: %t__row_major_tmp_v1
    ;
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v214 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v34);
    // pto: %t__row_major_tmp_v1
    ;
    uint64_t v215 = (uint64_t) v21;
    TASSIGN(v214, v215);
    pipe_barrier(PIPE_V);
    TMULS(v214, v212, v44);
    // pto: %9
    ;
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v216 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v32);
    // pto: %9
    ;
    uint64_t v217 = (uint64_t) v21;
    TASSIGN(v216, v217);
    // pto: %variance_inline3437__rm_a0_tmp_v2
    ;
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v34);
    // pto: %variance_inline3437__rm_a0_tmp_v2
    ;
    uint64_t v219 = (uint64_t) v21;
    TASSIGN(v218, v219);
    // pto: %variance_inline3437__row_major_tmp_v3
    ;
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v34);
    // pto: %variance_inline3437__row_major_tmp_v3
    ;
    uint64_t v221 = (uint64_t) v21;
    TASSIGN(v220, v221);
    pipe_barrier(PIPE_V);
    TADDS(v220, v218, v45);
    // pto: %variance_inline3437__tile
    ;
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v222 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v32);
    // pto: %variance_inline3437__tile
    ;
    uint64_t v223 = (uint64_t) v21;
    TASSIGN(v222, v223);
    // pto: %rms_inline3438__rm_a0_tmp_v4
    ;
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v224 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v34);
    // pto: %rms_inline3438__rm_a0_tmp_v4
    ;
    uint64_t v225 = (uint64_t) v21;
    TASSIGN(v224, v225);
    // pto: %rms_inline3438__row_major_tmp_v5
    ;
    Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v226 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v34);
    // pto: %rms_inline3438__row_major_tmp_v5
    ;
    uint64_t v227 = (uint64_t) v28;
    TASSIGN(v226, v227);
    pipe_barrier(PIPE_V);
    TSQRT(v226, v224);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    // pto: %rms_inline3438__tile
    ;
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v228 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v32);
    // pto: %rms_inline3438__tile
    ;
    uint64_t v229 = (uint64_t) v28;
    TASSIGN(v228, v229);
    // pto: %kv_norm_chunk_inline3439__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v230 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %kv_norm_chunk_inline3439__tile
    ;
    uint64_t v231 = (uint64_t) v21;
    TASSIGN(v230, v231);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    TLOAD(v230, v193);
    // pto: %10
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v232 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
    // pto: %10
    ;
    uint64_t v233 = (uint64_t) v27;
    TASSIGN(v232, v233);
    // pto: %norm_w_2d_inline3413__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v234 = PTOAS__GLOBAL_TENSOR_DATA(v90);
    // pto: %norm_w_2d_inline3413__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 64> v235 = pto::Shape<1, 1, 1, 1, 64>();
    // pto: %norm_w_2d_inline3413__ssa_v0_pview
    ;
    pto::Stride<128, 128, 128, 128, 1> v236 = pto::Stride<128, 128, 128, 128, 1>();
    // pto: %norm_w_2d_inline3413__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v237 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v234, v235, v236);
    TLOAD(v232, v237);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    // pto: %gamma_inline3440__tile
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v238 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
    // pto: %gamma_inline3440__tile
    ;
    uint64_t v239 = (uint64_t) v26;
    TASSIGN(v238, v239);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    RoundMode v240 = RoundMode::CAST_ROUND;
    SaturationMode v241 = SaturationMode::ON;
    TCVT(v238, v232, v240, v241);
    // pto: %11
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v242 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %11
    ;
    uint64_t v243 = (uint64_t) v21;
    TASSIGN(v242, v243);
    TROWEXPANDDIV(v242, v230, v228);
    // pto: %normed_chunk_inline3441__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v244 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %normed_chunk_inline3441__tile
    ;
    uint64_t v245 = (uint64_t) v21;
    TASSIGN(v244, v245);
    pipe_barrier(PIPE_V);
    TCOLEXPANDMUL(v244, v242, v238);
    // pto: %normed_nope_inline3442__tile
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v246 = Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %normed_nope_inline3442__tile
    ;
    uint64_t v247 = (uint64_t) v29;
    TASSIGN(v246, v247);
    pipe_barrier(PIPE_V);
    RoundMode v248 = RoundMode::CAST_RINT;
    SaturationMode v249 = SaturationMode::ON;
    TCVT(v246, v244, v248, v249);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    // pto: %kv_rope_norm_inline3443__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v250 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %kv_rope_norm_inline3443__tile
    ;
    uint64_t v251 = (uint64_t) v21;
    TASSIGN(v250, v251);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    TLOAD(v250, v201);
    // pto: %12
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v252 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
    // pto: %12
    ;
    uint64_t v253 = (uint64_t) v27;
    TASSIGN(v252, v253);
    // pto: %53
    ;
    __gm__ bfloat16_t* v254 = PTOAS__GLOBAL_TENSOR_DATA(v90);
    // pto: %53
    ;
    unsigned v255 = 64;
    // pto: %53
    ;
    pto::Shape<1, 1, 1, 1, 64> v256 = pto::Shape<1, 1, 1, 1, 64>();
    // pto: %53
    ;
    pto::Stride<128, 128, 128, 128, 1> v257 = pto::Stride<128, 128, 128, 128, 1>();
    // pto: %53
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v258 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v254 + v255, v256, v257);
    TLOAD(v252, v258);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    // pto: %gamma_rope_inline3444__tile
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v259 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
    // pto: %gamma_rope_inline3444__tile
    ;
    uint64_t v260 = (uint64_t) v26;
    TASSIGN(v259, v260);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    RoundMode v261 = RoundMode::CAST_ROUND;
    SaturationMode v262 = SaturationMode::ON;
    TCVT(v259, v252, v261, v262);
    // pto: %13
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v263 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %13
    ;
    uint64_t v264 = (uint64_t) v21;
    TASSIGN(v263, v264);
    TROWEXPANDDIV(v263, v250, v228);
    // pto: %rope_normed_inline3445__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v265 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %rope_normed_inline3445__tile
    ;
    uint64_t v266 = (uint64_t) v21;
    TASSIGN(v265, v266);
    pipe_barrier(PIPE_V);
    TCOLEXPANDMUL(v265, v263, v259);
    // pto: %gather_acc_init
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v267 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %gather_acc_init
    ;
    uint64_t v268 = (uint64_t) v26;
    TASSIGN(v267, v268);
    for (int64_t v269 = v41; v269 < v34; v269 += v32) {
      // pto: %gather_inp_row
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v270 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
      // pto: %gather_inp_row
      ;
      uint64_t v271 = (uint64_t) v21;
      TASSIGN(v270, v271);
      // pto: %slice_view
      ;
      int64_t v272 = (int64_t) ((uint64_t) v269 * (uint64_t) v20);
      // pto: %slice_view
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v273;
      // pto: %slice_view
      ;
      uint64_t v274 = (uint64_t) ((int64_t) (uint64_t) v272 + (uint64_t) v21);
      TASSIGN(v273, v274);
      // pto: %gather_idx_row
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v275 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
      // pto: %gather_idx_row
      ;
      uint64_t v276 = (uint64_t) v23;
      TASSIGN(v275, v276);
      // pto: %54
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v277;
      // pto: %54
      ;
      uint64_t v278 = (uint64_t) ((int64_t) (uint64_t) v272 + (uint64_t) v23);
      TASSIGN(v277, v278);
      // pto: %gather_row_tmp
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v279 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
      // pto: %gather_row_tmp
      ;
      uint64_t v280 = (uint64_t) v27;
      TASSIGN(v279, v280);
      // pto: %gather_row
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v281 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
      // pto: %gather_row
      ;
      uint64_t v282 = (uint64_t) v28;
      TASSIGN(v281, v282);
      pipe_barrier(PIPE_V);
      TGATHER(v281, v273, v277, v279);
      // pto: %assemble_view
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v283;
      // pto: %assemble_view
      ;
      uint64_t v284 = (uint64_t) ((int64_t) (uint64_t) v272 + (uint64_t) v26);
      TASSIGN(v283, v284);
      pipe_barrier(PIPE_V);
      TMOV(v283, v281);
    };
    // pto: %swapped_inline3446__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v285 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %swapped_inline3446__tile
    ;
    uint64_t v286 = (uint64_t) v26;
    TASSIGN(v285, v286);
    // pto: %14
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v287 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %14
    ;
    uint64_t v288 = (uint64_t) v27;
    TASSIGN(v287, v288);
    TMULS(v287, v125, v39);
    // pto: %15
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v289 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %15
    ;
    uint64_t v290 = (uint64_t) v27;
    TASSIGN(v289, v290);
    pipe_barrier(PIPE_V);
    TSUBS(v289, v287, v35);
    // pto: %sin_signed_inline3447__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v291 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %sin_signed_inline3447__tile
    ;
    uint64_t v292 = (uint64_t) v25;
    TASSIGN(v291, v292);
    pipe_barrier(PIPE_V);
    TMUL(v291, v183, v289);
    // pto: %16
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v293 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %16
    ;
    uint64_t v294 = (uint64_t) v21;
    TASSIGN(v293, v294);
    TMUL(v293, v265, v181);
    // pto: %17
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v295 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %17
    ;
    uint64_t v296 = (uint64_t) v24;
    TASSIGN(v295, v296);
    pipe_barrier(PIPE_V);
    TMUL(v295, v285, v291);
    // pto: %rope_rot_inline3448__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v297 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %rope_rot_inline3448__tile
    ;
    uint64_t v298 = (uint64_t) v21;
    TASSIGN(v297, v298);
    pipe_barrier(PIPE_V);
    TADD(v297, v293, v295);
    // pto: %normed_rope_inline3449__tile
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v299 = Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v33);
    // pto: %normed_rope_inline3449__tile
    ;
    uint64_t v300 = (uint64_t) v21;
    TASSIGN(v299, v300);
    pipe_barrier(PIPE_V);
    RoundMode v301 = RoundMode::CAST_RINT;
    SaturationMode v302 = SaturationMode::ON;
    TCVT(v299, v297, v301, v302);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    for (int64_t v303 = v41; v303 < v140; v303 += v32) {
      // pto: %55
      ;
      int64_t v304 = (int64_t) ((uint64_t) v138 + (uint64_t) v303);
      // pto: %token_pos_inline3377__tile
      ;
      int64_t v305 = (v2)[v304];
      // pto: %56
      ;
      int32_t v306 = (v3)[v304];
      // pto: %59, %60
      ;
      int64_t v307 = (int64_t) ((uint64_t) v305 + (uint64_t) v42) % v43;
      // pto: %61, %62, %63
      ;
      int64_t v308 = v307 < v22 ? (int64_t) ((uint64_t) v307 + (uint64_t) v43) : v307;
      // pto: %57, %58, %64, %65
      ;
      if ((int64_t) v306 >= v41 & v308 == v22) {
        // pto: %66
        ;
        int32_t v309 = (v3)[v304];
        // pto: %67
        ;
        int64_t v310 = (int64_t) v309;
        // pto: %68
        ;
        int32_t v311 = (v9)[v310];
        // pto: %69
        ;
        int64_t v312 = (int64_t) v311;
        // pto: %first_pos_inline3452__tile
        ;
        int64_t v313 = (v2)[v312];
        // pto: %70
        ;
        int64_t v314 = v313 % v43;
        // pto: %71, %72, %73
        ;
        int64_t v315 = v314 < v22 ? (int64_t) ((uint64_t) v314 + (uint64_t) v43) : v314;
        // pto: %77, %78, %75
        ;
        int64_t v316 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v304 - (uint64_t) v312) - (uint64_t) ((int64_t) (uint64_t) v46 - (uint64_t) v315));
        // pto: %79
        ;
        const int64_t v317 = 1;
        // pto: %79
        ;
        const int64_t v318 = 0;
        // pto: %79
        ;
        int64_t v319 = v316 / v48;
        // pto: %79
        ;
        bool v320 = v316 < v318;
        // pto: %79
        ;
        bool v321 = v48 < v318;
        // pto: %79
        ;
        bool v322 = v320 == v321;
        // pto: %79
        ;
        bool v323 = v316 % v48 != v318 && v320 != v321;
        // pto: %79
        ;
        int64_t v324 = v323 ? v319 - v317 : v319;
        // pto: %76, %80
        ;
        int64_t v325 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v310 * (uint64_t) v47) + (uint64_t) v324);
        // pto: %18
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v326 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
        // pto: %18
        ;
        uint64_t v327 = (uint64_t) v29;
        TASSIGN(v326, v327);
        // pto: %81
        ;
        int64_t v328 = (int64_t) ((uint64_t) v303 * (uint64_t) v19);
        // pto: %81
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v329;
        // pto: %81
        ;
        uint64_t v330 = (uint64_t) ((int64_t) (uint64_t) v328 + (uint64_t) v29);
        TASSIGN(v329, v330);
        // pto: %82
        ;
        int64_t v331 = v325 < v41 ? v41 : v325;
        // pto: %normed_kv_inline3323__iter_v4_pview
        ;
        __gm__ bfloat16_t* v332 = PTOAS__GLOBAL_TENSOR_DATA(v56);
        // pto: %normed_kv_inline3323__iter_v4_pview
        ;
        const int64_t v333 = 0;
        // pto: %normed_kv_inline3323__iter_v4_pview
        ;
        const int64_t v334 = 128;
        // pto: %normed_kv_inline3323__iter_v4_pview
        ;
        pto::Shape<1, 1, 1, 1, 64> v335 = pto::Shape<1, 1, 1, 1, 64>();
        // pto: %normed_kv_inline3323__iter_v4_pview
        ;
        pto::Stride<128, 128, 128, 128, 1> v336 = pto::Stride<128, 128, 128, 128, 1>();
        // pto: %normed_kv_inline3323__iter_v4_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v337 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v332 + (v333 + v331 * v334), v335, v336);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v337, v329);
        // pto: %19
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v338 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
        // pto: %19
        ;
        uint64_t v339 = (uint64_t) v21;
        TASSIGN(v338, v339);
        // pto: %83
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v340;
        // pto: %83
        ;
        uint64_t v341 = (uint64_t) ((int64_t) (uint64_t) v328 + (uint64_t) v21);
        TASSIGN(v340, v341);
        // pto: %normed_kv_inline3323__tile_pview
        ;
        __gm__ bfloat16_t* v342 = PTOAS__GLOBAL_TENSOR_DATA(v56);
        // pto: %normed_kv_inline3323__tile_pview
        ;
        const int64_t v343 = 64;
        // pto: %normed_kv_inline3323__tile_pview
        ;
        const int64_t v344 = 128;
        // pto: %normed_kv_inline3323__tile_pview
        ;
        pto::Shape<1, 1, 1, 1, 64> v345 = pto::Shape<1, 1, 1, 1, 64>();
        // pto: %normed_kv_inline3323__tile_pview
        ;
        pto::Stride<128, 128, 128, 128, 1> v346 = pto::Stride<128, 128, 128, 128, 1>();
        // pto: %normed_kv_inline3323__tile_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v347 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v342 + (v343 + v331 * v344), v345, v346);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v347, v340);
      };
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}