#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void q_rope_prepare(__gm__ float* v1, __gm__ int32_t* v2, __gm__ float* v3, int64_t v4, int64_t v5, int64_t v6, int32_t v7, int32_t v8) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c6144_i64
  const int64_t v9 = 6144;
  // pto: %c10240_i64
  const int64_t v10 = 10240;
  // pto: %c0_i64
  const int64_t v11 = 0;
  // pto: %c2048_i64
  const int64_t v12 = 2048;
  // pto: %c4096_i64
  const int64_t v13 = 4096;
  // pto: %c8192_i64
  const int64_t v14 = 8192;
  // pto: %c64_index
  const int64_t v15 = 64;
  // pto: %c1_index
  const int64_t v16 = 1;
  // pto: %c8_index
  const int64_t v17 = 8;
  // pto: %cst_9
  const float v18 = 1.0f;
  // pto: %c192_index
  const int64_t v19 = 192;
  // pto: %c0_i32
  const int32_t v20 = 0;
  // pto: %cst_12
  const float v21 = 0.5f;
  // pto: %cst_13
  const float v22 = 2.0f;
  // pto: %c48_index
  const int64_t v23 = 48;
  // pto: %c0_index
  const int64_t v24 = 0;
  // pto: %rope_sin_signed_view_inline2784__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %rope_sin_signed_view_inline2784__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %rope_sin_signed_view_inline2784__ssa_v0_view
  const int64_t v27 = 1;
  // pto: %rope_sin_signed_view_inline2784__ssa_v0_view
  int64_t v28 = (int64_t) v6;
  // pto: %rope_sin_signed_view_inline2784__ssa_v0_view
  int64_t v29 = v28 * v15;
  // pto: %rope_sin_signed_view_inline2784__ssa_v0_view
  int64_t v30 = v27 * v29;
  // pto: %rope_sin_signed_view_inline2784__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v31 = pto::Shape<1, 1, 1, -1, -1>(v25, v26, v27, v28, v15);
  // pto: %rope_sin_signed_view_inline2784__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v32 = pto::Stride<-1, -1, -1, -1, -1>(v26 * v30, v30, v29, v15, v16);
  // pto: %rope_sin_signed_view_inline2784__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v33 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v31, v32);
  // pto: %rope_swap_idx_view_inline2785__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %rope_swap_idx_view_inline2785__ssa_v0_view
  const int64_t v35 = 1;
  // pto: %rope_swap_idx_view_inline2785__ssa_v0_view
  const int64_t v36 = 1;
  // pto: %rope_swap_idx_view_inline2785__ssa_v0_view
  int64_t v37 = (int64_t) v6;
  // pto: %rope_swap_idx_view_inline2785__ssa_v0_view
  int64_t v38 = v37 * v15;
  // pto: %rope_swap_idx_view_inline2785__ssa_v0_view
  int64_t v39 = v36 * v38;
  // pto: %rope_swap_idx_view_inline2785__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v40 = pto::Shape<1, 1, 1, -1, -1>(v34, v35, v36, v37, v15);
  // pto: %rope_swap_idx_view_inline2785__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v41 = pto::Stride<-1, -1, -1, -1, -1>(v35 * v39, v39, v38, v15, v16);
  // pto: %rope_swap_idx_view_inline2785__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v42 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v40, v41);
  // pto: %rope_sin_view_inline2783__ssa_v0_view
  const int64_t v43 = 1;
  // pto: %rope_sin_view_inline2783__ssa_v0_view
  const int64_t v44 = 1;
  // pto: %rope_sin_view_inline2783__ssa_v0_view
  const int64_t v45 = 1;
  // pto: %rope_sin_view_inline2783__ssa_v0_view
  int64_t v46 = (int64_t) v6;
  // pto: %rope_sin_view_inline2783__ssa_v0_view
  int64_t v47 = v46 * v15;
  // pto: %rope_sin_view_inline2783__ssa_v0_view
  int64_t v48 = v45 * v47;
  // pto: %rope_sin_view_inline2783__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v49 = pto::Shape<1, 1, 1, -1, -1>(v43, v44, v45, v46, v15);
  // pto: %rope_sin_view_inline2783__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v50 = pto::Stride<-1, -1, -1, -1, -1>(v44 * v48, v48, v47, v15, v16);
  // pto: %rope_sin_view_inline2783__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v51 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v49, v50);
  // pto: %qrp_worker_inline2787__ssa_v0
  // pto: %qrp_ones_inline2788__tile
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v52 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
  // pto: %qrp_ones_inline2788__tile
  uint64_t v53 = (uint64_t) v9;
  TASSIGN(v52, v53);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  TEXPANDS(v52, v18);
  // pto: %qrp_idx_i32_inline2789__ci_tmp_v0
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v54 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v19);
  // pto: %qrp_idx_i32_inline2789__ci_tmp_v0
  uint64_t v55 = (uint64_t) v10;
  TASSIGN(v54, v55);
  // pto: %qrp_idx_i32_inline2789__tile
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v56 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v15);
  // pto: %qrp_idx_i32_inline2789__tile
  uint64_t v57 = (uint64_t) v11;
  TASSIGN(v56, v57);
  // pto: %ci_tmp_view
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v58;
  TRESHAPE(v58, v54);
  // pto: %ci_dst_view
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v59;
  TRESHAPE(v59, v56);
  TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v59, v20, v58);
  // pto: %qrp_idx_fp32_inline2790__tile
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v60 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v15);
  // pto: %qrp_idx_fp32_inline2790__tile
  uint64_t v61 = (uint64_t) v10;
  TASSIGN(v60, v61);
  pipe_barrier(PIPE_V);
  RoundMode v62 = RoundMode::CAST_ROUND;
  SaturationMode v63 = SaturationMode::ON;
  TCVT(v60, v56, v62, v63);
  // pto: %qrp_col_inline2791__tile
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v64 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
  // pto: %qrp_col_inline2791__tile
  uint64_t v65 = (uint64_t) v9;
  TASSIGN(v64, v65);
  pipe_barrier(PIPE_V);
  TCOLEXPANDMUL(v64, v52, v60);
  // pto: %qrp_half_inline2792__tile
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v66 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
  // pto: %qrp_half_inline2792__tile
  uint64_t v67 = (uint64_t) v10;
  TASSIGN(v66, v67);
  pipe_barrier(PIPE_V);
  TMULS(v66, v64, v21);
  // pto: %qrp_dup_i32_inline2793__tile
  Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v68 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
  // pto: %qrp_dup_i32_inline2793__tile
  uint64_t v69 = (uint64_t) v10;
  TASSIGN(v68, v69);
  pipe_barrier(PIPE_V);
  RoundMode v70 = RoundMode::CAST_TRUNC;
  SaturationMode v71 = SaturationMode::ON;
  TCVT(v68, v66, v70, v71);
  // pto: %qrp_dup_f_inline2794__tile
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v72 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
  // pto: %qrp_dup_f_inline2794__tile
  uint64_t v73 = (uint64_t) v10;
  TASSIGN(v72, v73);
  pipe_barrier(PIPE_V);
  RoundMode v74 = RoundMode::CAST_ROUND;
  SaturationMode v75 = SaturationMode::ON;
  TCVT(v72, v68, v74, v75);
  // pto: %t__tile
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v76 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
  // pto: %t__tile
  uint64_t v77 = (uint64_t) v10;
  TASSIGN(v76, v77);
  pipe_barrier(PIPE_V);
  TMULS(v76, v72, v22);
  // pto: %qrp_lane_inline2795__tile
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v78 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
  // pto: %qrp_lane_inline2795__tile
  uint64_t v79 = (uint64_t) v10;
  TASSIGN(v78, v79);
  pipe_barrier(PIPE_V);
  TSUB(v78, v64, v76);
  // pto: %qrp_next_col_inline2796__tile
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v80 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
  // pto: %qrp_next_col_inline2796__tile
  uint64_t v81 = (uint64_t) v9;
  TASSIGN(v80, v81);
  pipe_barrier(PIPE_V);
  TADDS(v80, v64, v18);
  // pto: %qrp_lane_offset_inline2797__tile
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v82 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
  // pto: %qrp_lane_offset_inline2797__tile
  uint64_t v83 = (uint64_t) v11;
  TASSIGN(v82, v83);
  TMULS(v82, v78, v22);
  // pto: %qrp_swap_f_inline2798__tile
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v84 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
  // pto: %qrp_swap_f_inline2798__tile
  uint64_t v85 = (uint64_t) v9;
  TASSIGN(v84, v85);
  pipe_barrier(PIPE_V);
  TSUB(v84, v80, v82);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  // pto: %qrp_swap_idx_inline2799__tile
  Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v86 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
  // pto: %qrp_swap_idx_inline2799__tile
  uint64_t v87 = (uint64_t) v9;
  TASSIGN(v86, v87);
  pipe_barrier(PIPE_V);
  RoundMode v88 = RoundMode::CAST_ROUND;
  SaturationMode v89 = SaturationMode::ON;
  TCVT(v86, v84, v88, v89);
  // pto: %0
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v90 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
  // pto: %0
  uint64_t v91 = (uint64_t) v10;
  TASSIGN(v90, v91);
  TMULS(v90, v78, v22);
  // pto: %qrp_sign_inline2800__tile
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v92 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
  // pto: %qrp_sign_inline2800__tile
  uint64_t v93 = (uint64_t) v10;
  TASSIGN(v92, v93);
  pipe_barrier(PIPE_V);
  TSUBS(v92, v90, v18);
  // pto: %1
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v94 = (int64_t) v7; v94 < v4; v94 += v4 < v23 ? v4 : v23) {
    // pto: %2
    ;
    int64_t v95 = (int64_t) ((uint64_t) v94 * (uint64_t) v17);
    // pto: %3
    ;
    int64_t v96 = (int64_t) ((uint64_t) v6 - (uint64_t) v95);
    // pto: %4
    ;
    int64_t v97 = v96 < v17 ? v96 : v17;
    // pto: %5
    ;
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    if (v97 == v17) {
      // pto: %qrp_sin_rows_full_inline2804__tile
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v98 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
      // pto: %qrp_sin_rows_full_inline2804__tile
      ;
      uint64_t v99 = (uint64_t) v11;
      TASSIGN(v98, v99);
      // pto: %6
      ;
      int64_t v100 = v95 < v24 ? v24 : v95;
      // pto: %rope_sin_view_inline2783__ssa_v0_pview
      ;
      __gm__ float* v101 = PTOAS__GLOBAL_TENSOR_DATA(v51);
      // pto: %rope_sin_view_inline2783__ssa_v0_pview
      ;
      const int64_t v102 = 0;
      // pto: %rope_sin_view_inline2783__ssa_v0_pview
      ;
      const int64_t v103 = 64;
      // pto: %rope_sin_view_inline2783__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 64> v104 = pto::Shape<1, 1, 1, 8, 64>();
      // pto: %rope_sin_view_inline2783__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 64, 1> v105 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %rope_sin_view_inline2783__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v106 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v101 + (v102 + v100 * v103), v104, v105);
      TLOAD(v98, v106);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %qrp_sin_signed_full_inline2805__tile
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v107 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
      // pto: %qrp_sin_signed_full_inline2805__tile
      ;
      uint64_t v108 = (uint64_t) v11;
      TASSIGN(v107, v108);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      pipe_barrier(PIPE_V);
      TMUL(v107, v98, v92);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      // pto: %rope_sin_signed_view_inline2784__iter_v1_pview
      ;
      __gm__ float* v109 = PTOAS__GLOBAL_TENSOR_DATA(v33);
      // pto: %rope_sin_signed_view_inline2784__iter_v1_pview
      ;
      const int64_t v110 = 0;
      // pto: %rope_sin_signed_view_inline2784__iter_v1_pview
      ;
      const int64_t v111 = 64;
      // pto: %rope_sin_signed_view_inline2784__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, 8, 64> v112 = pto::Shape<1, 1, 1, 8, 64>();
      // pto: %rope_sin_signed_view_inline2784__iter_v1_pview
      ;
      pto::Stride<512, 512, 512, 64, 1> v113 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %rope_sin_signed_view_inline2784__iter_v1_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v114 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v109 + (v110 + v100 * v111), v112, v113);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v114, v107);
      // pto: %rope_swap_idx_view_inline2785__iter_v1_pview
      ;
      __gm__ int32_t* v115 = PTOAS__GLOBAL_TENSOR_DATA(v42);
      // pto: %rope_swap_idx_view_inline2785__iter_v1_pview
      ;
      const int64_t v116 = 0;
      // pto: %rope_swap_idx_view_inline2785__iter_v1_pview
      ;
      const int64_t v117 = 64;
      // pto: %rope_swap_idx_view_inline2785__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, 8, 64> v118 = pto::Shape<1, 1, 1, 8, 64>();
      // pto: %rope_swap_idx_view_inline2785__iter_v1_pview
      ;
      pto::Stride<512, 512, 512, 64, 1> v119 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %rope_swap_idx_view_inline2785__iter_v1_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v120 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v115 + (v116 + v100 * v117), v118, v119);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v120, v86);
    } else {
      // pto: %qrp_sin_rows_tail_inline2806__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v97, v15);
      // pto: %qrp_sin_rows_tail_inline2806__ssa_v0
      ;
      uint64_t v122 = (uint64_t) v11;
      TASSIGN(v121, v122);
      // pto: %9
      ;
      int64_t v123 = v95 < v24 ? v24 : v95;
      // pto: %10
      ;
      const int64_t v124 = 0;
      // pto: %10
      ;
      __gm__ float* v125 = PTOAS__GLOBAL_TENSOR_DATA(v51);
      // pto: %10
      ;
      const int64_t v126 = 1;
      // pto: %10
      ;
      const int64_t v127 = 1;
      // pto: %10
      ;
      const int64_t v128 = 1;
      // pto: %10
      ;
      int64_t v129 = v97 * v15;
      // pto: %10
      ;
      int64_t v130 = v128 * v129;
      // pto: %10
      ;
      pto::Shape<1, 1, 1, -1, 64> v131 = pto::Shape<1, 1, 1, -1, 64>(v126, v127, v128, v97, v15);
      // pto: %10
      ;
      pto::Stride<-1, -1, -1, -1, -1> v132 = pto::Stride<-1, -1, -1, -1, -1>(v127 * v130, v130, v129, v15, v16);
      // pto: %10
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v133 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v125 + (v124 + v123 * v15 + v24 * v16), v131, v132);
      TLOAD(v121, v133);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %t__tmp_v18
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v134 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
      // pto: %t__tmp_v18
      ;
      uint64_t v135 = (uint64_t) v12;
      TASSIGN(v134, v135);
      pipe_barrier(PIPE_V);
      TEXPANDS(v134, v18);
      // pto: %t__ci_tmp_v1
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v136 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v19);
      // pto: %t__ci_tmp_v1
      ;
      uint64_t v137 = (uint64_t) v13;
      TASSIGN(v136, v137);
      // pto: %t__tmp_v19
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v138 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v15);
      // pto: %t__tmp_v19
      ;
      uint64_t v139 = (uint64_t) v14;
      TASSIGN(v138, v139);
      // pto: %11
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v140;
      TRESHAPE(v140, v136);
      // pto: %12
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v141;
      TRESHAPE(v141, v138);
      TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v141, v20, v140);
      // pto: %t__tmp_v20
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v142 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v15);
      // pto: %t__tmp_v20
      ;
      uint64_t v143 = (uint64_t) v13;
      TASSIGN(v142, v143);
      pipe_barrier(PIPE_V);
      RoundMode v144 = RoundMode::CAST_ROUND;
      SaturationMode v145 = SaturationMode::ON;
      TCVT(v142, v138, v144, v145);
      // pto: %qrp_tail_col_inline2807__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v146 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
      // pto: %qrp_tail_col_inline2807__ssa_v0
      ;
      uint64_t v147 = (uint64_t) v12;
      TASSIGN(v146, v147);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v146, v134, v142);
      // pto: %t__tmp_v21
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v148 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
      // pto: %t__tmp_v21
      ;
      uint64_t v149 = (uint64_t) v13;
      TASSIGN(v148, v149);
      pipe_barrier(PIPE_V);
      TMULS(v148, v146, v21);
      // pto: %t__tmp_v22
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v150 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
      // pto: %t__tmp_v22
      ;
      uint64_t v151 = (uint64_t) v13;
      TASSIGN(v150, v151);
      pipe_barrier(PIPE_V);
      RoundMode v152 = RoundMode::CAST_TRUNC;
      SaturationMode v153 = SaturationMode::ON;
      TCVT(v150, v148, v152, v153);
      // pto: %qrp_tail_dup_f_inline2808__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v154 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
      // pto: %qrp_tail_dup_f_inline2808__ssa_v0
      ;
      uint64_t v155 = (uint64_t) v13;
      TASSIGN(v154, v155);
      pipe_barrier(PIPE_V);
      RoundMode v156 = RoundMode::CAST_ROUND;
      SaturationMode v157 = SaturationMode::ON;
      TCVT(v154, v150, v156, v157);
      // pto: %t__tmp_v23
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v158 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
      // pto: %t__tmp_v23
      ;
      uint64_t v159 = (uint64_t) v13;
      TASSIGN(v158, v159);
      pipe_barrier(PIPE_V);
      TMULS(v158, v154, v22);
      // pto: %qrp_tail_lane_inline2809__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v160 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
      // pto: %qrp_tail_lane_inline2809__ssa_v0
      ;
      uint64_t v161 = (uint64_t) v13;
      TASSIGN(v160, v161);
      pipe_barrier(PIPE_V);
      TSUB(v160, v146, v158);
      // pto: %t__tmp_v24
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v162 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
      // pto: %t__tmp_v24
      ;
      uint64_t v163 = (uint64_t) v12;
      TASSIGN(v162, v163);
      pipe_barrier(PIPE_V);
      TADDS(v162, v146, v18);
      // pto: %t__tmp_v25
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v164 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
      // pto: %t__tmp_v25
      ;
      uint64_t v165 = (uint64_t) v14;
      TASSIGN(v164, v165);
      TMULS(v164, v160, v22);
      // pto: %qrp_tail_swap_f_inline2810__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v166 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
      // pto: %qrp_tail_swap_f_inline2810__ssa_v0
      ;
      uint64_t v167 = (uint64_t) v12;
      TASSIGN(v166, v167);
      pipe_barrier(PIPE_V);
      TSUB(v166, v162, v164);
      // pto: %t__tmp_v26
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v168 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
      // pto: %t__tmp_v26
      ;
      uint64_t v169 = (uint64_t) v13;
      TASSIGN(v168, v169);
      TMULS(v168, v160, v22);
      // pto: %qrp_tail_sign_inline2811__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v170 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
      // pto: %qrp_tail_sign_inline2811__ssa_v0
      ;
      uint64_t v171 = (uint64_t) v13;
      TASSIGN(v170, v171);
      pipe_barrier(PIPE_V);
      TSUBS(v170, v168, v18);
      v170.SetValidShape(v97, v15);
      // pto: %qrp_sin_signed_tail_inline2813__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v172 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v97, v15);
      // pto: %qrp_sin_signed_tail_inline2813__ssa_v0
      ;
      uint64_t v173 = (uint64_t) v11;
      TASSIGN(v172, v173);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      TMUL(v172, v121, v170);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      v172.SetValidShape(v97, v15);
      // pto: %14
      ;
      const int64_t v174 = 0;
      // pto: %14
      ;
      __gm__ float* v175 = PTOAS__GLOBAL_TENSOR_DATA(v33);
      // pto: %14
      ;
      const int64_t v176 = 1;
      // pto: %14
      ;
      const int64_t v177 = 1;
      // pto: %14
      ;
      const int64_t v178 = 1;
      // pto: %14
      ;
      int64_t v179 = v97 * v15;
      // pto: %14
      ;
      int64_t v180 = v178 * v179;
      // pto: %14
      ;
      pto::Shape<1, 1, 1, -1, 64> v181 = pto::Shape<1, 1, 1, -1, 64>(v176, v177, v178, v97, v15);
      // pto: %14
      ;
      pto::Stride<-1, -1, -1, -1, -1> v182 = pto::Stride<-1, -1, -1, -1, -1>(v177 * v180, v180, v179, v15, v16);
      // pto: %14
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v183 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v175 + (v174 + v123 * v15 + v24 * v16), v181, v182);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      TSTORE(v183, v172);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      // pto: %t__tmp_v28
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v184 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v15);
      // pto: %t__tmp_v28
      ;
      uint64_t v185 = (uint64_t) v11;
      TASSIGN(v184, v185);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      RoundMode v186 = RoundMode::CAST_ROUND;
      SaturationMode v187 = SaturationMode::ON;
      TCVT(v184, v166, v186, v187);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      v184.SetValidShape(v97, v15);
      // pto: %16
      ;
      const int64_t v188 = 0;
      // pto: %16
      ;
      __gm__ int32_t* v189 = PTOAS__GLOBAL_TENSOR_DATA(v42);
      // pto: %16
      ;
      const int64_t v190 = 1;
      // pto: %16
      ;
      const int64_t v191 = 1;
      // pto: %16
      ;
      const int64_t v192 = 1;
      // pto: %16
      ;
      int64_t v193 = v97 * v15;
      // pto: %16
      ;
      int64_t v194 = v192 * v193;
      // pto: %16
      ;
      pto::Shape<1, 1, 1, -1, 64> v195 = pto::Shape<1, 1, 1, -1, 64>(v190, v191, v192, v97, v15);
      // pto: %16
      ;
      pto::Stride<-1, -1, -1, -1, -1> v196 = pto::Stride<-1, -1, -1, -1, -1>(v191 * v194, v194, v193, v15, v16);
      // pto: %16
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v197 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v189 + (v188 + v123 * v15 + v24 * v16), v195, v196);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      TSTORE(v197, v184);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}