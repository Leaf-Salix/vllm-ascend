#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qr_hadamard_matmul(__gm__ bfloat16_t* v1, __gm__ float* v2, __gm__ bfloat16_t* v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v8 = 0;
  // pto: %c32768_i64
  const int64_t v9 = 32768;
  // pto: %c128_index
  const int64_t v10 = 128;
  // pto: %c1_index
  const int64_t v11 = 1;
  // pto: %c27648_index
  const int64_t v12 = 27648;
  // pto: %c0_index
  const int64_t v13 = 0;
  // pto: %c64_index
  const int64_t v14 = 64;
  // pto: %c24_index
  const int64_t v15 = 24;
  // pto: %hadamard_idx__ssa_v0_view
  const int64_t v16 = 1;
  // pto: %hadamard_idx__ssa_v0_view
  const int64_t v17 = 1;
  // pto: %hadamard_idx__ssa_v0_view
  const int64_t v18 = 1;
  // pto: %hadamard_idx__ssa_v0_view
  int64_t v19 = v10 * v10;
  // pto: %hadamard_idx__ssa_v0_view
  int64_t v20 = v18 * v19;
  // pto: %hadamard_idx__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v21 = pto::Shape<1, 1, 1, -1, -1>(v16, v17, v18, v10, v10);
  // pto: %hadamard_idx__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v22 = pto::Stride<-1, -1, -1, -1, -1>(v17 * v20, v20, v19, v10, v11);
  // pto: %hadamard_idx__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v23 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v21, v22);
  // pto: %qh_acc_gm_inline3594__ssa_v0_view
  const int64_t v24 = 1;
  // pto: %qh_acc_gm_inline3594__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %qh_acc_gm_inline3594__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %qh_acc_gm_inline3594__ssa_v0_view
  int64_t v27 = (int64_t) v5;
  // pto: %qh_acc_gm_inline3594__ssa_v0_view
  int64_t v28 = v27 * v10;
  // pto: %qh_acc_gm_inline3594__ssa_v0_view
  int64_t v29 = v26 * v28;
  // pto: %qh_acc_gm_inline3594__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v30 = pto::Shape<1, 1, 1, -1, -1>(v24, v25, v26, v27, v10);
  // pto: %qh_acc_gm_inline3594__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v31 = pto::Stride<-1, -1, -1, -1, -1>(v25 * v29, v29, v28, v10, v11);
  // pto: %qh_acc_gm_inline3594__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v32 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v30, v31);
  // pto: %qr_bf16_inline3529__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %qr_bf16_inline3529__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %qr_bf16_inline3529__ssa_v0_view
  const int64_t v35 = 1;
  // pto: %qr_bf16_inline3529__ssa_v0_view
  int64_t v36 = v12 * v10;
  // pto: %qr_bf16_inline3529__ssa_v0_view
  int64_t v37 = v35 * v36;
  // pto: %qr_bf16_inline3529__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v38 = pto::Shape<1, 1, 1, -1, -1>(v33, v34, v35, v12, v10);
  // pto: %qr_bf16_inline3529__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v39 = pto::Stride<-1, -1, -1, -1, -1>(v34 * v37, v37, v36, v10, v11);
  // pto: %qr_bf16_inline3529__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v40 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v38, v39);
  // pto: %qh_worker_inline3596__ssa_v0
  // pto: %qh_hadamard_inline3597__tile
  Tile<TileType::Mat, bfloat16_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v41 = Tile<TileType::Mat, bfloat16_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v10, v10);
  // pto: %qh_hadamard_inline3597__tile
  uint64_t v42 = (uint64_t) v8;
  TASSIGN(v41, v42);
  // pto: %hadamard_idx__ssa_v0_pview
  __gm__ bfloat16_t* v43 = PTOAS__GLOBAL_TENSOR_DATA(v23);
  // pto: %hadamard_idx__ssa_v0_pview
  pto::Shape<1, 1, 1, 128, 128> v44 = pto::Shape<1, 1, 1, 128, 128>();
  // pto: %hadamard_idx__ssa_v0_pview
  pto::Stride<16384, 16384, 16384, 128, 1> v45 = pto::Stride<16384, 16384, 16384, 128, 1>();
  // pto: %hadamard_idx__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 128>, pto::Stride<16384, 16384, 16384, 128, 1>, pto::Layout::ND> v46 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 128>, pto::Stride<16384, 16384, 16384, 128, 1>, pto::Layout::ND>(v43, v44, v45);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  TLOAD(v41, v46);
  // pto: %0
  const int64_t v47 = 1;
  // pto: %0
  const int64_t v48 = 0;
  // pto: %0
  int64_t v49 = v5 / v14;
  // pto: %0
  bool v50 = v5 < v48;
  // pto: %0
  bool v51 = v14 < v48;
  // pto: %0
  bool v52 = v50 == v51;
  // pto: %0
  bool v53 = v5 % v14 != v48 && v50 != v51;
  // pto: %0
  for (int64_t v54 = (int64_t) v6; v54 < (v53 ? v49 - v47 : v49); v54 += v15) {
    // pto: %1
    ;
    int64_t v55 = (int64_t) ((uint64_t) v54 * (uint64_t) v14);
    // pto: %t__tile
    ;
    Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v56 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %t__tile
    ;
    uint64_t v57 = (uint64_t) v9;
    TASSIGN(v56, v57);
    // pto: %2
    ;
    int64_t v58 = v55 < v13 ? v13 : v55;
    // pto: %qr_bf16_inline3529__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v59 = PTOAS__GLOBAL_TENSOR_DATA(v40);
    // pto: %qr_bf16_inline3529__ssa_v0_pview
    ;
    const int64_t v60 = 0;
    // pto: %qr_bf16_inline3529__ssa_v0_pview
    ;
    const int64_t v61 = 128;
    // pto: %qr_bf16_inline3529__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 64, 128> v62 = pto::Shape<1, 1, 1, 64, 128>();
    // pto: %qr_bf16_inline3529__ssa_v0_pview
    ;
    pto::Stride<8192, 8192, 8192, 128, 1> v63 = pto::Stride<8192, 8192, 8192, 128, 1>();
    // pto: %qr_bf16_inline3529__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND> v64 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND>(v59 + (v60 + v58 * v61), v62, v63);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v56, v64);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    // pto: %t__tile_Left
    ;
    Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v65 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %t__tile_Left
    ;
    uint64_t v66 = (uint64_t) v8;
    TASSIGN(v65, v66);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    TMOV(v65, v56);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    // pto: %qh_hadamard_inline3597__tile_Right
    ;
    Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v67 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v10, v10);
    // pto: %qh_hadamard_inline3597__tile_Right
    ;
    uint64_t v68 = (uint64_t) v8;
    TASSIGN(v67, v68);
    TMOV(v67, v41);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    // pto: %qh_acc_inline3600__tile
    ;
    Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v69 = Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %qh_acc_inline3600__tile
    ;
    uint64_t v70 = (uint64_t) v8;
    TASSIGN(v69, v70);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    TMATMUL(v69, v65, v67);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %qh_acc_gm_inline3594__iter_v1_pview
    ;
    __gm__ float* v71 = PTOAS__GLOBAL_TENSOR_DATA(v32);
    // pto: %qh_acc_gm_inline3594__iter_v1_pview
    ;
    const int64_t v72 = 0;
    // pto: %qh_acc_gm_inline3594__iter_v1_pview
    ;
    const int64_t v73 = 128;
    // pto: %qh_acc_gm_inline3594__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 64, 128> v74 = pto::Shape<1, 1, 1, 64, 128>();
    // pto: %qh_acc_gm_inline3594__iter_v1_pview
    ;
    pto::Stride<8192, 8192, 8192, 128, 1> v75 = pto::Stride<8192, 8192, 8192, 128, 1>();
    // pto: %qh_acc_gm_inline3594__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND> v76 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND>(v71 + (v72 + v58 * v73), v74, v75);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    TSTORE(v76, v69);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}