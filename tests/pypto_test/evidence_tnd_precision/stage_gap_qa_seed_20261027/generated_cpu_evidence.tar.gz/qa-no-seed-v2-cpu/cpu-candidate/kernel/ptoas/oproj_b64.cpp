#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_b64(__gm__ int8_t* v1, __gm__ int8_t* v2, __gm__ int32_t* v3, int64_t v4, int64_t v5, int64_t v6, int32_t v7, int32_t v8) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v9 = 0;
  // pto: %c32768_i64
  const int64_t v10 = 32768;
  // pto: %c16384_i64
  const int64_t v11 = 16384;
  // pto: %c8192_index
  const int64_t v12 = 8192;
  // pto: %c1_index
  const int64_t v13 = 1;
  // pto: %c128_index
  const int64_t v14 = 128;
  // pto: %c512_index
  const int64_t v15 = 512;
  // pto: %c16_index
  const int64_t v16 = 16;
  // pto: %c32_index
  const int64_t v17 = 32;
  // pto: %c33554432_index
  const int64_t v18 = 33554432;
  // pto: %c262144_index
  const int64_t v19 = 262144;
  // pto: %c4096_index
  const int64_t v20 = 4096;
  // pto: %c64_index
  const int64_t v21 = 64;
  // pto: %c0_index
  const int64_t v22 = 0;
  // pto: %c256_index
  const int64_t v23 = 256;
  // pto: %c63_index
  const int64_t v24 = 63;
  // pto: %quantized_o__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %quantized_o__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %quantized_o__ssa_v0_view
  const int64_t v27 = 1;
  // pto: %quantized_o__ssa_v0_view
  int64_t v28 = (int64_t) v5;
  // pto: %quantized_o__ssa_v0_view
  int64_t v29 = v28 * v12;
  // pto: %quantized_o__ssa_v0_view
  int64_t v30 = v27 * v29;
  // pto: %quantized_o__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v31 = pto::Shape<1, 1, 1, -1, -1>(v25, v26, v27, v28, v12);
  // pto: %quantized_o__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v32 = pto::Stride<-1, -1, -1, -1, -1>(v26 * v30, v30, v29, v12, v13);
  // pto: %quantized_o__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v33 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v31, v32);
  // pto: %wo_b__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v34 = pto::Shape<-1, -1, -1, -1, -1>(v13, v14, v15, v16, v17);
  // pto: %wo_b__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v35 = pto::Stride<-1, -1, -1, -1, -1>(v18, v19, v15, v17, v13);
  // pto: %wo_b__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v36 = GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v2, v34, v35);
  // pto: %32
  int64_t v37 = (int64_t) ((uint64_t) v6 + (uint64_t) v24);
  // pto: %integer_accum_inline5383__ssa_v0_view
  const int64_t v38 = 1;
  // pto: %integer_accum_inline5383__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %integer_accum_inline5383__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %integer_accum_inline5383__ssa_v0_view
  int64_t v41 = v37 * v20;
  // pto: %integer_accum_inline5383__ssa_v0_view
  int64_t v42 = v40 * v41;
  // pto: %integer_accum_inline5383__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v43 = pto::Shape<1, 1, 1, -1, -1>(v38, v39, v40, v37, v20);
  // pto: %integer_accum_inline5383__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v44 = pto::Stride<-1, -1, -1, -1, -1>(v39 * v42, v42, v41, v20, v13);
  // pto: %integer_accum_inline5383__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v45 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v43, v44);
  // pto: %wide_block_inline5390__ssa_v0
  int64_t v46 = (int64_t) v7;
  // pto: %9
  const int64_t v47 = 1;
  // pto: %9
  const int64_t v48 = 0;
  // pto: %9
  int64_t v49 = v46 / v17;
  // pto: %9
  bool v50 = v46 < v48;
  // pto: %9
  bool v51 = v17 < v48;
  // pto: %9
  bool v52 = v50 == v51;
  // pto: %9
  bool v53 = v46 % v17 != v48 && v50 != v51;
  // pto: %9
  int64_t v54 = v53 ? v49 - v47 : v49;
  // pto: %10
  int64_t v55 = (int64_t) ((uint64_t) v54 * (uint64_t) v21);
  // pto: %11
  int64_t v56 = v46 % v17;
  // pto: %12, %13, %14
  int64_t v57 = v56 < v22 ? (int64_t) ((uint64_t) v56 + (uint64_t) v17) : v56;
  // pto: %15
  int64_t v58 = (int64_t) ((uint64_t) v57 * (uint64_t) v14);
  // pto: %16
  int64_t v59 = (int64_t) ((uint64_t) v6 - (uint64_t) v55);
  // pto: %17
  int64_t v60 = v59 < v21 ? v59 : v21;
  // pto: %wide_first_input_inline5394__tile
  Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v61 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v60, v15);
  // pto: %wide_first_input_inline5394__tile
  uint64_t v62 = (uint64_t) v9;
  TASSIGN(v61, v62);
  // pto: %18
  int64_t v63 = v55 < v22 ? v22 : v55;
  // pto: %quantized_o__ssa_v0_pview
  const int64_t v64 = 0;
  // pto: %quantized_o__ssa_v0_pview
  __gm__ int8_t* v65 = PTOAS__GLOBAL_TENSOR_DATA(v33);
  // pto: %quantized_o__ssa_v0_pview
  const int64_t v66 = 1;
  // pto: %quantized_o__ssa_v0_pview
  const int64_t v67 = 1;
  // pto: %quantized_o__ssa_v0_pview
  const int64_t v68 = 1;
  // pto: %quantized_o__ssa_v0_pview
  int64_t v69 = v60 * v12;
  // pto: %quantized_o__ssa_v0_pview
  int64_t v70 = v68 * v69;
  // pto: %quantized_o__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 512> v71 = pto::Shape<1, 1, 1, -1, 512>(v66, v67, v68, v60, v15);
  // pto: %quantized_o__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v67 * v70, v70, v69, v12, v13);
  // pto: %quantized_o__ssa_v0_pview
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v73 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v65 + (v64 + v63 * v12 + v22 * v13), v71, v72);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  TLOAD(v61, v73);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
  // pto: %wide_first_weight_inline5395__tile
  Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v74 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v14);
  // pto: %wide_first_weight_inline5395__tile
  uint64_t v75 = (uint64_t) v10;
  TASSIGN(v74, v75);
  // pto: %19
  const int64_t v76 = 1;
  // pto: %19
  const int64_t v77 = 0;
  // pto: %19
  int64_t v78 = v58 / v17;
  // pto: %19
  bool v79 = v58 < v77;
  // pto: %19
  bool v80 = v17 < v77;
  // pto: %19
  bool v81 = v79 == v80;
  // pto: %19
  bool v82 = v58 % v17 != v77 && v79 != v80;
  // pto: %19
  int64_t v83 = v82 ? v78 - v76 : v78;
  // pto: %20
  int64_t v84 = v83 < v22 ? v22 : v83;
  // pto: %wo_b__ssa_v0_pview
  __gm__ int8_t* v85 = PTOAS__GLOBAL_TENSOR_DATA(v36);
  // pto: %wo_b__ssa_v0_pview
  const int64_t v86 = 0;
  // pto: %wo_b__ssa_v0_pview
  const int64_t v87 = 262144;
  // pto: %wo_b__ssa_v0_pview
  pto::Shape<1, 4, 32, 16, 32> v88 = pto::Shape<1, 4, 32, 16, 32>();
  // pto: %wo_b__ssa_v0_pview
  pto::Stride<33554432, 262144, 512, 32, 1> v89 = pto::Stride<33554432, 262144, 512, 32, 1>();
  // pto: %wo_b__ssa_v0_pview
  GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v90 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v85 + (v86 + v84 * v87), v88, v89);
  TLOAD(v74, v90);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
  // pto: %wide_b_acc_inline5396__tile_l0_init_storage
  Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v91 = Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v21, v14);
  // pto: %wide_b_acc_inline5396__tile_l0_init_storage
  uint64_t v92 = (uint64_t) v9;
  TASSIGN(v91, v92);
  v91.SetValidShape(v60, v14);
  // pto: %wide_b_acc_inline5396__tile_l0_a
  Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v93 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v60, v23);
  // pto: %wide_b_acc_inline5396__tile_l0_a
  uint64_t v94 = (uint64_t) v9;
  TASSIGN(v93, v94);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
  uint16_t v95 = static_cast<uint16_t>(v22);
  uint16_t v96 = static_cast<uint16_t>(v22);
  TEXTRACT(v93, v61, v95, v96);
  // pto: %wide_b_acc_inline5396__tile_l0_b
  Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v14);
  // pto: %wide_b_acc_inline5396__tile_l0_b
  uint64_t v98 = (uint64_t) v9;
  TASSIGN(v97, v98);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
  uint16_t v99 = static_cast<uint16_t>(v22);
  uint16_t v100 = static_cast<uint16_t>(v22);
  TEXTRACT(v97, v74, v99, v100);
  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
  // pto: %0
  Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v101 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v60, v23);
  // pto: %0
  uint64_t v102 = (uint64_t) v11;
  TASSIGN(v101, v102);
  uint16_t v103 = static_cast<uint16_t>(v22);
  uint16_t v104 = static_cast<uint16_t>(v23);
  TEXTRACT(v101, v61, v103, v104);
  // pto: %1
  Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v105 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v14);
  // pto: %1
  uint64_t v106 = (uint64_t) v10;
  TASSIGN(v105, v106);
  uint16_t v107 = static_cast<uint16_t>(v23);
  uint16_t v108 = static_cast<uint16_t>(v22);
  TEXTRACT(v105, v74, v107, v108);
  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
  TMATMUL(v91, v93, v97);
  pipe_barrier(PIPE_M);
  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
  TMATMUL_ACC(v91, v91, v101, v105);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  for (int64_t v109 = v13; v109 < v16; v109 += v13) {
    // pto: %21
    ;
    int64_t v110 = (int64_t) ((uint64_t) v109 * (uint64_t) v15);
    // pto: %wide_b_input_inline5399__tile
    ;
    Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v60, v15);
    // pto: %wide_b_input_inline5399__tile
    ;
    uint64_t v112 = (uint64_t) v9;
    TASSIGN(v111, v112);
    // pto: %23
    ;
    int64_t v113 = v110 < v22 ? v22 : v110;
    // pto: %24
    ;
    const int64_t v114 = 0;
    // pto: %24
    ;
    __gm__ int8_t* v115 = PTOAS__GLOBAL_TENSOR_DATA(v33);
    // pto: %24
    ;
    const int64_t v116 = 1;
    // pto: %24
    ;
    const int64_t v117 = 1;
    // pto: %24
    ;
    const int64_t v118 = 1;
    // pto: %24
    ;
    int64_t v119 = v60 * v12;
    // pto: %24
    ;
    int64_t v120 = v118 * v119;
    // pto: %24
    ;
    pto::Shape<1, 1, 1, -1, 512> v121 = pto::Shape<1, 1, 1, -1, 512>(v116, v117, v118, v60, v15);
    // pto: %24
    ;
    pto::Stride<-1, -1, -1, -1, -1> v122 = pto::Stride<-1, -1, -1, -1, -1>(v117 * v120, v120, v119, v12, v13);
    // pto: %24
    ;
    GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v123 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v115 + (v114 + v63 * v12 + v113 * v13), v121, v122);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    TLOAD(v111, v123);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    // pto: %wide_b_weight_inline5400__tile
    ;
    Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v14);
    // pto: %wide_b_weight_inline5400__tile
    ;
    uint64_t v125 = (uint64_t) v10;
    TASSIGN(v124, v125);
    // pto: %27
    ;
    const int64_t v126 = 1;
    // pto: %27
    ;
    const int64_t v127 = 0;
    // pto: %27
    ;
    int64_t v128 = v110 / v16;
    // pto: %27
    ;
    bool v129 = v110 < v127;
    // pto: %27
    ;
    bool v130 = v16 < v127;
    // pto: %27
    ;
    bool v131 = v129 == v130;
    // pto: %27
    ;
    bool v132 = v110 % v16 != v127 && v129 != v130;
    // pto: %27
    ;
    int64_t v133 = v132 ? v128 - v126 : v128;
    // pto: %28
    ;
    int64_t v134 = v133 < v22 ? v22 : v133;
    // pto: %29
    ;
    __gm__ int8_t* v135 = PTOAS__GLOBAL_TENSOR_DATA(v36);
    // pto: %29
    ;
    const int64_t v136 = 0;
    // pto: %29
    ;
    const int64_t v137 = 262144;
    // pto: %29
    ;
    const int64_t v138 = 512;
    // pto: %29
    ;
    pto::Shape<1, 4, 32, 16, 32> v139 = pto::Shape<1, 4, 32, 16, 32>();
    // pto: %29
    ;
    pto::Stride<33554432, 262144, 512, 32, 1> v140 = pto::Stride<33554432, 262144, 512, 32, 1>();
    // pto: %29
    ;
    GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v141 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v135 + (v136 + v84 * v137 + v134 * v138), v139, v140);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    TLOAD(v124, v141);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    // pto: %3
    ;
    Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v142 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v60, v23);
    // pto: %3
    ;
    uint64_t v143 = (uint64_t) v9;
    TASSIGN(v142, v143);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    uint16_t v144 = static_cast<uint16_t>(v22);
    uint16_t v145 = static_cast<uint16_t>(v22);
    TEXTRACT(v142, v111, v144, v145);
    // pto: %4
    ;
    Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v146 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v14);
    // pto: %4
    ;
    uint64_t v147 = (uint64_t) v9;
    TASSIGN(v146, v147);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    uint16_t v148 = static_cast<uint16_t>(v22);
    uint16_t v149 = static_cast<uint16_t>(v22);
    TEXTRACT(v146, v124, v148, v149);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
    // pto: %5
    ;
    Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v150 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v60, v23);
    // pto: %5
    ;
    uint64_t v151 = (uint64_t) v11;
    TASSIGN(v150, v151);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    uint16_t v152 = static_cast<uint16_t>(v22);
    uint16_t v153 = static_cast<uint16_t>(v23);
    TEXTRACT(v150, v111, v152, v153);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    // pto: %6
    ;
    Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v154 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v14);
    // pto: %6
    ;
    uint64_t v155 = (uint64_t) v10;
    TASSIGN(v154, v155);
    uint16_t v156 = static_cast<uint16_t>(v23);
    uint16_t v157 = static_cast<uint16_t>(v22);
    TEXTRACT(v154, v124, v156, v157);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
    pipe_barrier(PIPE_M);
    TMATMUL_ACC(v91, v91, v142, v146);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    pipe_barrier(PIPE_M);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
    TMATMUL_ACC(v91, v91, v150, v154);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  }
  set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  // pto: %31
  int64_t v158 = v58 < v22 ? v22 : v58;
  // pto: %integer_accum_inline5383__ssa_v0_pview
  const int64_t v159 = 0;
  // pto: %integer_accum_inline5383__ssa_v0_pview
  __gm__ int32_t* v160 = PTOAS__GLOBAL_TENSOR_DATA(v45);
  // pto: %integer_accum_inline5383__ssa_v0_pview
  const int64_t v161 = 1;
  // pto: %integer_accum_inline5383__ssa_v0_pview
  const int64_t v162 = 1;
  // pto: %integer_accum_inline5383__ssa_v0_pview
  const int64_t v163 = 1;
  // pto: %integer_accum_inline5383__ssa_v0_pview
  int64_t v164 = v60 * v20;
  // pto: %integer_accum_inline5383__ssa_v0_pview
  int64_t v165 = v163 * v164;
  // pto: %integer_accum_inline5383__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 128> v166 = pto::Shape<1, 1, 1, -1, 128>(v161, v162, v163, v60, v14);
  // pto: %integer_accum_inline5383__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v167 = pto::Stride<-1, -1, -1, -1, -1>(v162 * v165, v165, v164, v20, v13);
  // pto: %integer_accum_inline5383__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v168 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v160 + (v159 + v63 * v20 + v158 * v13), v166, v167);
  wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  TSTORE(v168, v91);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}