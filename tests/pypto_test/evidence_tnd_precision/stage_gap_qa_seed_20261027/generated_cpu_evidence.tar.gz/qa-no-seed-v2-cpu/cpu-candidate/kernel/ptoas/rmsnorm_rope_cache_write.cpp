#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void rmsnorm_rope_cache_write(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ int32_t* v3, __gm__ float* v4, __gm__ float* v5, __gm__ float* v6, __gm__ float* v7, __gm__ bfloat16_t* v8, __gm__ bfloat16_t* v9, __gm__ float* v10, __gm__ int32_t* v11, int64_t v12, int64_t v13, int64_t v14, int64_t v15, int64_t v16, int32_t v17, int32_t v18) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v19 = 256;
  // pto: %c0_i64
  const int64_t v20 = 0;
  // pto: %c4096_i64
  const int64_t v21 = 4096;
  // pto: %c8192_i64
  const int64_t v22 = 8192;
  // pto: %c24576_i64
  const int64_t v23 = 24576;
  const int64_t v24 = 8704;
  const int64_t v25 = 8448;
  // pto: %c40960_i64
  const int64_t v26 = 40960;
  // pto: %c45056_i64
  const int64_t v27 = 45056;
  // pto: %c49152_i64
  const int64_t v28 = 49152;
  // pto: %c49408_i64
  const int64_t v29 = 49408;
  // pto: %c1_index
  const int64_t v30 = 1;
  // pto: %c64_index
  const int64_t v31 = 64;
  // pto: %c384_index
  const int64_t v32 = 384;
  // pto: %c512_index
  const int64_t v33 = 512;
  // pto: %c2_index
  const int64_t v34 = 2;
  // pto: %c16_index
  const int64_t v35 = 16;
  // pto: %cst_16
  const float v36 = 1.0f;
  // pto: %cst_17
  const float v37 = 0.0f;
  // pto: %c0_index
  const int64_t v38 = 0;
  // pto: %c1_i64
  const int64_t v39 = 1;
  // pto: %c4_i64
  const int64_t v40 = 4;
  // pto: %c256_index
  const int64_t v41 = 256;
  // pto: %c128_index
  const int64_t v42 = 128;
  // pto: %cst_23
  const float v43 = 0.001953125f;
  // pto: %cst_24
  const float v44 = 9.99999997E-7f;
  // pto: %c448_index
  const int64_t v45 = 448;
  // pto: %c192_index
  const int64_t v46 = 192;
  // pto: %c0_i32
  const int32_t v47 = 0;
  // pto: %cst_28
  const float v48 = 0.5f;
  // pto: %cst_29
  const float v49 = 2.0f;
  // pto: %c32_index
  const int64_t v50 = 32;
  // pto: %cmp_freqs_cos__ssa_v0_view
  const int64_t v51 = 1;
  // pto: %cmp_freqs_cos__ssa_v0_view
  const int64_t v52 = 1;
  // pto: %cmp_freqs_cos__ssa_v0_view
  const int64_t v53 = 1;
  // pto: %cmp_freqs_cos__ssa_v0_view
  int64_t v54 = (int64_t) v15;
  // pto: %cmp_freqs_cos__ssa_v0_view
  int64_t v55 = v54 * v31;
  // pto: %cmp_freqs_cos__ssa_v0_view
  int64_t v56 = v53 * v55;
  // pto: %cmp_freqs_cos__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v57 = pto::Shape<1, 1, 1, -1, -1>(v51, v52, v53, v54, v31);
  // pto: %cmp_freqs_cos__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v58 = pto::Stride<-1, -1, -1, -1, -1>(v52 * v56, v56, v55, v31, v30);
  // pto: %cmp_freqs_cos__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v59 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v57, v58);
  // pto: %cmp_freqs_sin__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %cmp_freqs_sin__ssa_v0_view
  const int64_t v61 = 1;
  // pto: %cmp_freqs_sin__ssa_v0_view
  const int64_t v62 = 1;
  // pto: %cmp_freqs_sin__ssa_v0_view
  int64_t v63 = (int64_t) v15;
  // pto: %cmp_freqs_sin__ssa_v0_view
  int64_t v64 = v63 * v31;
  // pto: %cmp_freqs_sin__ssa_v0_view
  int64_t v65 = v62 * v64;
  // pto: %cmp_freqs_sin__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v66 = pto::Shape<1, 1, 1, -1, -1>(v60, v61, v62, v63, v31);
  // pto: %cmp_freqs_sin__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v67 = pto::Stride<-1, -1, -1, -1, -1>(v61 * v65, v65, v64, v31, v30);
  // pto: %cmp_freqs_sin__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v68 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v66, v67);
  // pto: %pooled_kv_inline3175__rv_v2_view
  const int64_t v69 = 1;
  // pto: %pooled_kv_inline3175__rv_v2_view
  const int64_t v70 = 1;
  // pto: %pooled_kv_inline3175__rv_v2_view
  const int64_t v71 = 1;
  // pto: %pooled_kv_inline3175__rv_v2_view
  int64_t v72 = v32 * v33;
  // pto: %pooled_kv_inline3175__rv_v2_view
  int64_t v73 = v71 * v72;
  // pto: %pooled_kv_inline3175__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v74 = pto::Shape<1, 1, 1, -1, -1>(v69, v70, v71, v32, v33);
  // pto: %pooled_kv_inline3175__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v75 = pto::Stride<-1, -1, -1, -1, -1>(v70 * v73, v73, v72, v33, v30);
  // pto: %pooled_kv_inline3175__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v76 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v74, v75);
  // pto: %normed_kv_inline3274__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %normed_kv_inline3274__ssa_v0_view
  const int64_t v78 = 1;
  // pto: %normed_kv_inline3274__ssa_v0_view
  const int64_t v79 = 1;
  // pto: %normed_kv_inline3274__ssa_v0_view
  int64_t v80 = v32 * v33;
  // pto: %normed_kv_inline3274__ssa_v0_view
  int64_t v81 = v79 * v80;
  // pto: %normed_kv_inline3274__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v82 = pto::Shape<1, 1, 1, -1, -1>(v77, v78, v79, v32, v33);
  // pto: %normed_kv_inline3274__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v83 = pto::Stride<-1, -1, -1, -1, -1>(v78 * v81, v81, v80, v33, v30);
  // pto: %normed_kv_inline3274__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v84 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v82, v83);
  // pto: %norm_w_2d_inline3275__ssa_v0_view
  const int64_t v85 = 1;
  // pto: %norm_w_2d_inline3275__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %norm_w_2d_inline3275__ssa_v0_view
  const int64_t v87 = 1;
  // pto: %norm_w_2d_inline3275__ssa_v0_view
  int64_t v88 = v30 * v33;
  // pto: %norm_w_2d_inline3275__ssa_v0_view
  int64_t v89 = v87 * v88;
  // pto: %norm_w_2d_inline3275__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v90 = pto::Shape<1, 1, 1, -1, -1>(v85, v86, v87, v30, v33);
  // pto: %norm_w_2d_inline3275__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v91 = pto::Stride<-1, -1, -1, -1, -1>(v86 * v89, v89, v88, v33, v30);
  // pto: %norm_w_2d_inline3275__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v92 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v90, v91);
  // pto: %102
  int64_t v93 = (int64_t) ((uint64_t) v16 * (uint64_t) v50);
  // pto: %cmp_kv_cache_flat_inline3259__ssa_v0_view
  const int64_t v94 = 1;
  // pto: %cmp_kv_cache_flat_inline3259__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %cmp_kv_cache_flat_inline3259__ssa_v0_view
  const int64_t v96 = 1;
  // pto: %cmp_kv_cache_flat_inline3259__ssa_v0_view
  int64_t v97 = v93 * v33;
  // pto: %cmp_kv_cache_flat_inline3259__ssa_v0_view
  int64_t v98 = v96 * v97;
  // pto: %cmp_kv_cache_flat_inline3259__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v99 = pto::Shape<1, 1, 1, -1, -1>(v94, v95, v96, v93, v33);
  // pto: %cmp_kv_cache_flat_inline3259__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v100 = pto::Stride<-1, -1, -1, -1, -1>(v95 * v98, v98, v97, v33, v30);
  // pto: %cmp_kv_cache_flat_inline3259__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v101 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v99, v100);
  // pto: %kv_flat_inline3258__ssa_v0_view
  const int64_t v102 = 1;
  // pto: %kv_flat_inline3258__ssa_v0_view
  const int64_t v103 = 1;
  // pto: %kv_flat_inline3258__ssa_v0_view
  const int64_t v104 = 1;
  // pto: %kv_flat_inline3258__ssa_v0_view
  int64_t v105 = (int64_t) v13;
  // pto: %kv_flat_inline3258__ssa_v0_view
  int64_t v106 = v105 * v33;
  // pto: %kv_flat_inline3258__ssa_v0_view
  int64_t v107 = v104 * v106;
  // pto: %kv_flat_inline3258__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v108 = pto::Shape<1, 1, 1, -1, -1>(v102, v103, v104, v105, v33);
  // pto: %kv_flat_inline3258__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v109 = pto::Stride<-1, -1, -1, -1, -1>(v103 * v107, v107, v106, v33, v30);
  // pto: %kv_flat_inline3258__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v110 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v10, v108, v109);
  // pto: %cosine_inline3316__phi_v5
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %cosine_inline3316__phi_v5
  uint64_t v112 = (uint64_t) v20;
  TASSIGN(v111, v112);
  // pto: %sine_inline3317__phi_v5
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %sine_inline3317__phi_v5
  uint64_t v114 = (uint64_t) v21;
  TASSIGN(v113, v114);
  // pto: %cosine_inline3316__phi_v4
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v115 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %cosine_inline3316__phi_v4
  uint64_t v116 = (uint64_t) v20;
  TASSIGN(v115, v116);
  // pto: %sine_inline3317__phi_v4
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %sine_inline3317__phi_v4
  uint64_t v118 = (uint64_t) v21;
  TASSIGN(v117, v118);
  // pto: %rms_blk_inline3277__ssa_v0, %23
  int64_t v119 = (int64_t) ((uint64_t) ((int64_t) v17) * (uint64_t) v35);
  // pto: %24
  int64_t v120 = (int64_t) ((uint64_t) v12 - (uint64_t) v119);
  // pto: %25
  int64_t v121 = v120 < v35 ? v120 : v35;
  // pto: %cosine_inline3316__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v122 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %cosine_inline3316__tile
  uint64_t v123 = (uint64_t) v20;
  TASSIGN(v122, v123);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  TEXPANDS(v122, v36);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  // pto: %sine_inline3317__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %sine_inline3317__tile
  uint64_t v125 = (uint64_t) v21;
  TASSIGN(v124, v125);
  TEXPANDS(v124, v37);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  for (int64_t v126 = v38; v126 < v121; v126 += v30) {
    // pto: %26
    ;
    int64_t v127 = (int64_t) ((uint64_t) v119 + (uint64_t) v126);
    // pto: %position_inline3320__tile
    ;
    int64_t v128 = (v1)[v127];
    // pto: %27
    ;
    int32_t v129 = (v2)[v127];
    // pto: %28
    ;
    int64_t v130 = (int64_t) v129;
    // pto: %30
    ;
    int64_t v131 = (int64_t) ((uint64_t) v128 + (uint64_t) v39);
    // pto: %31
    ;
    int64_t v132 = v131 % v40;
    // pto: %32, %33, %34
    ;
    int64_t v133 = v132 < v20 ? (int64_t) ((uint64_t) v132 + (uint64_t) v40) : v132;
    // pto: %29, %35, %36
    ;
    if (v130 >= v38 & v133 == v20) {
      // pto: %37
      ;
      int32_t v134 = (v3)[v130];
      // pto: %40
      ;
      const int64_t v135 = 1;
      // pto: %40
      ;
      const int64_t v136 = 0;
      // pto: %40
      ;
      int64_t v137 = v131 / v40;
      // pto: %40
      ;
      bool v138 = v131 < v136;
      // pto: %40
      ;
      bool v139 = v40 < v136;
      // pto: %40
      ;
      bool v140 = v138 == v139;
      // pto: %40
      ;
      bool v141 = v131 % v40 != v136 && v138 != v139;
      // pto: %40
      ;
      int64_t v142 = v141 ? v137 - v135 : v137;
      // pto: %38, %42
      ;
      int64_t v143 = (int64_t) ((uint64_t) ((int64_t) v134) + (uint64_t) v142);
      // pto: %43, %44, %45
      ;
      if (v143 >= v38 & v143 < v15) {
        // pto: %gather_row_view
        ;
        int64_t v144 = (int64_t) ((uint64_t) v126 * (uint64_t) v19);
        // pto: %gather_row_view
        ;
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v145;
        // pto: %gather_row_view
        ;
        uint64_t v146 = (uint64_t) v144;
        TASSIGN(v145, v146);
        // pto: %46
        ;
        int64_t v147 = v143 < v38 ? v38 : v143;
        // pto: %cmp_freqs_cos__ssa_v0_pview
        ;
        __gm__ float* v148 = PTOAS__GLOBAL_TENSOR_DATA(v59);
        // pto: %cmp_freqs_cos__ssa_v0_pview
        ;
        const int64_t v149 = 0;
        // pto: %cmp_freqs_cos__ssa_v0_pview
        ;
        const int64_t v150 = 64;
        // pto: %cmp_freqs_cos__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 64> v151 = pto::Shape<1, 1, 1, 1, 64>();
        // pto: %cmp_freqs_cos__ssa_v0_pview
        ;
        pto::Stride<64, 64, 64, 64, 1> v152 = pto::Stride<64, 64, 64, 64, 1>();
        // pto: %cmp_freqs_cos__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v153 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v148 + (v149 + v147 * v150), v151, v152);
        TLOAD(v145, v153);
        // pto: %47
        ;
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v154;
        // pto: %47
        ;
        uint64_t v155 = (uint64_t) ((int64_t) (uint64_t) v144 + (uint64_t) v21);
        TASSIGN(v154, v155);
        // pto: %cmp_freqs_sin__ssa_v0_pview
        ;
        __gm__ float* v156 = PTOAS__GLOBAL_TENSOR_DATA(v68);
        // pto: %cmp_freqs_sin__ssa_v0_pview
        ;
        const int64_t v157 = 0;
        // pto: %cmp_freqs_sin__ssa_v0_pview
        ;
        const int64_t v158 = 64;
        // pto: %cmp_freqs_sin__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 64> v159 = pto::Shape<1, 1, 1, 1, 64>();
        // pto: %cmp_freqs_sin__ssa_v0_pview
        ;
        pto::Stride<64, 64, 64, 64, 1> v160 = pto::Stride<64, 64, 64, 64, 1>();
        // pto: %cmp_freqs_sin__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v161 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v156 + (v157 + v147 * v158), v159, v160);
        TLOAD(v154, v161);
      };
    };
  }
  // pto: %cos_b_inline3281__ssa_v0
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v162 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %cos_b_inline3281__ssa_v0
  uint64_t v163 = (uint64_t) v20;
  TASSIGN(v162, v163);
  // pto: %sin_b_inline3282__ssa_v0
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v164 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %sin_b_inline3282__ssa_v0
  uint64_t v165 = (uint64_t) v21;
  TASSIGN(v164, v165);
  // pto: %rms_low_inline3283__tile
  Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v166 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v41);
  // pto: %rms_low_inline3283__tile
  uint64_t v167 = (uint64_t) v22;
  TASSIGN(v166, v167);
  // pto: %49
  int64_t v168 = v119 < v38 ? v38 : v119;
  // pto: %pooled_kv_inline3175__rv_v2_pview
  __gm__ float* v169 = PTOAS__GLOBAL_TENSOR_DATA(v76);
  // pto: %pooled_kv_inline3175__rv_v2_pview
  const int64_t v170 = 0;
  // pto: %pooled_kv_inline3175__rv_v2_pview
  const int64_t v171 = 512;
  // pto: %pooled_kv_inline3175__rv_v2_pview
  pto::Shape<1, 1, 1, 16, 256> v172 = pto::Shape<1, 1, 1, 16, 256>();
  // pto: %pooled_kv_inline3175__rv_v2_pview
  pto::Stride<8192, 8192, 8192, 512, 1> v173 = pto::Stride<8192, 8192, 8192, 512, 1>();
  // pto: %pooled_kv_inline3175__rv_v2_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v174 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v169 + (v170 + v168 * v171), v172, v173);
  TLOAD(v166, v174);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %rms_high_inline3284__tile
  Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v41);
  // pto: %rms_high_inline3284__tile
  uint64_t v176 = (uint64_t) v23;
  TASSIGN(v175, v176);
  // pto: %51
  __gm__ float* v177 = PTOAS__GLOBAL_TENSOR_DATA(v76);
  // pto: %51
  const int64_t v178 = 256;
  // pto: %51
  const int64_t v179 = 512;
  // pto: %51
  pto::Shape<1, 1, 1, 16, 256> v180 = pto::Shape<1, 1, 1, 16, 256>();
  // pto: %51
  pto::Stride<8192, 8192, 8192, 512, 1> v181 = pto::Stride<8192, 8192, 8192, 512, 1>();
  // pto: %51
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v182 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v177 + (v178 + v168 * v179), v180, v181);
  TLOAD(v175, v182);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  // pto: %t__tile
  Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v41);
  // pto: %t__tile
  uint64_t v184 = (uint64_t) v22;
  TASSIGN(v183, v184);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  TMUL(v183, v166, v166);
  // pto: %2
  Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v185 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v41);
  // pto: %2
  uint64_t v186 = (uint64_t) v23;
  TASSIGN(v185, v186);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  TMUL(v185, v175, v175);
  // pto: %folded4_inline3285__tile
  Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v187 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v41);
  // pto: %folded4_inline3285__tile
  uint64_t v188 = (uint64_t) v22;
  TASSIGN(v187, v188);
  pipe_barrier(PIPE_V);
  TADD(v187, v183, v185);
  // pto: %3
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v189 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %3
  uint64_t v190 = (uint64_t) v22;
  TASSIGN(v189, v190);
  // pto: %slice_view
  Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, 16, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v191;
  // pto: %slice_view
  uint64_t v192 = (uint64_t) v22;
  TASSIGN(v191, v192);
  // pto: %4
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v193 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %4
  uint64_t v194 = (uint64_t) v24;
  TASSIGN(v193, v194);
  // pto: %52
  Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, 16, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v195;
  // pto: %52
  uint64_t v196 = (uint64_t) v24;
  TASSIGN(v195, v196);
  // pto: %folded2_inline3286__tile
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v197 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %folded2_inline3286__tile
  uint64_t v198 = (uint64_t) v22;
  TASSIGN(v197, v198);
  pipe_barrier(PIPE_V);
  TADD(v197, v191, v195);
  // pto: %5
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v199 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %5
  uint64_t v200 = (uint64_t) v22;
  TASSIGN(v199, v200);
  // pto: %53
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, 16, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v201;
  // pto: %53
  uint64_t v202 = (uint64_t) v22;
  TASSIGN(v201, v202);
  // pto: %6
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v203 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %6
  uint64_t v204 = (uint64_t) v25;
  TASSIGN(v203, v204);
  // pto: %54
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, 16, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v205;
  // pto: %54
  uint64_t v206 = (uint64_t) v25;
  TASSIGN(v205, v206);
  // pto: %folded1_inline3287__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %folded1_inline3287__tile
  uint64_t v208 = (uint64_t) v23;
  TASSIGN(v207, v208);
  pipe_barrier(PIPE_V);
  TADD(v207, v201, v205);
  // pto: %tmp_tile
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v209 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %tmp_tile
  uint64_t v210 = (uint64_t) v22;
  TASSIGN(v209, v210);
  // pto: %square_sum_inline3288__tile
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v30);
  // pto: %square_sum_inline3288__tile
  uint64_t v212 = (uint64_t) v26;
  TASSIGN(v211, v212);
  pipe_barrier(PIPE_V);
  TROWSUM(v211, v207, v209);
  // pto: %t__rm_a0_tmp_v0
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v213 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v35);
  // pto: %t__rm_a0_tmp_v0
  uint64_t v214 = (uint64_t) v26;
  TASSIGN(v213, v214);
  // pto: %t__row_major_tmp_v1
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v35);
  // pto: %t__row_major_tmp_v1
  uint64_t v216 = (uint64_t) v22;
  TASSIGN(v215, v216);
  pipe_barrier(PIPE_V);
  TMULS(v215, v213, v43);
  // pto: %7
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v30);
  // pto: %7
  uint64_t v218 = (uint64_t) v22;
  TASSIGN(v217, v218);
  // pto: %variance_inline3289__rm_a0_tmp_v2
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v219 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v35);
  // pto: %variance_inline3289__rm_a0_tmp_v2
  uint64_t v220 = (uint64_t) v22;
  TASSIGN(v219, v220);
  // pto: %variance_inline3289__row_major_tmp_v3
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v221 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v35);
  // pto: %variance_inline3289__row_major_tmp_v3
  uint64_t v222 = (uint64_t) v22;
  TASSIGN(v221, v222);
  pipe_barrier(PIPE_V);
  TADDS(v221, v219, v44);
  // pto: %variance_inline3289__tile
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v223 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v30);
  // pto: %variance_inline3289__tile
  uint64_t v224 = (uint64_t) v22;
  TASSIGN(v223, v224);
  // pto: %rms_inline3290__rm_a0_tmp_v4
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v225 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v35);
  // pto: %rms_inline3290__rm_a0_tmp_v4
  uint64_t v226 = (uint64_t) v22;
  TASSIGN(v225, v226);
  // pto: %rms_inline3290__row_major_tmp_v5
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v227 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v35);
  // pto: %rms_inline3290__row_major_tmp_v5
  uint64_t v228 = (uint64_t) v27;
  TASSIGN(v227, v228);
  pipe_barrier(PIPE_V);
  TSQRT(v227, v225);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  // pto: %rms_inline3290__tile
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v229 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v30);
  // pto: %rms_inline3290__tile
  uint64_t v230 = (uint64_t) v27;
  TASSIGN(v229, v230);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  for (int64_t v231 = v38; v231 < v45; v231 += v31) {
    // pto: %kv_norm_chunk_inline3292__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v232 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
    // pto: %kv_norm_chunk_inline3292__tile
    ;
    uint64_t v233 = (uint64_t) v22;
    TASSIGN(v232, v233);
    // pto: %56
    ;
    int64_t v234 = v231 < v38 ? v38 : v231;
    // pto: %57
    ;
    __gm__ float* v235 = PTOAS__GLOBAL_TENSOR_DATA(v76);
    // pto: %57
    ;
    const int64_t v236 = 0;
    // pto: %57
    ;
    const int64_t v237 = 512;
    // pto: %57
    ;
    pto::Shape<1, 1, 1, 16, 64> v238 = pto::Shape<1, 1, 1, 16, 64>();
    // pto: %57
    ;
    pto::Stride<8192, 8192, 8192, 512, 1> v239 = pto::Stride<8192, 8192, 8192, 512, 1>();
    // pto: %57
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v240 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v235 + (v236 + v168 * v237 + v234), v238, v239);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v232, v240);
    // pto: %8
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v241 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %8
    ;
    uint64_t v242 = (uint64_t) v26;
    TASSIGN(v241, v242);
    // pto: %norm_w_2d_inline3275__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v243 = PTOAS__GLOBAL_TENSOR_DATA(v92);
    // pto: %norm_w_2d_inline3275__ssa_v0_pview
    ;
    const int64_t v244 = 0;
    // pto: %norm_w_2d_inline3275__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 64> v245 = pto::Shape<1, 1, 1, 1, 64>();
    // pto: %norm_w_2d_inline3275__ssa_v0_pview
    ;
    pto::Stride<512, 512, 512, 512, 1> v246 = pto::Stride<512, 512, 512, 512, 1>();
    // pto: %norm_w_2d_inline3275__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v247 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v243 + (v244 + v234), v245, v246);
    TLOAD(v241, v247);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    // pto: %gamma_inline3293__tile
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v248 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %gamma_inline3293__tile
    ;
    uint64_t v249 = (uint64_t) v23;
    TASSIGN(v248, v249);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    RoundMode v250 = RoundMode::CAST_ROUND;
    SaturationMode v251 = SaturationMode::ON;
    TCVT(v248, v241, v250, v251);
    // pto: %9
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v252 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
    // pto: %9
    ;
    uint64_t v253 = (uint64_t) v22;
    TASSIGN(v252, v253);
    TROWEXPANDDIV(v252, v232, v229);
    // pto: %normed_chunk_inline3294__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v254 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
    // pto: %normed_chunk_inline3294__tile
    ;
    uint64_t v255 = (uint64_t) v22;
    TASSIGN(v254, v255);
    pipe_barrier(PIPE_V);
    TCOLEXPANDMUL(v254, v252, v248);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %normed_kv_inline3274__iter_v1_pview
    ;
    __gm__ float* v256 = PTOAS__GLOBAL_TENSOR_DATA(v84);
    // pto: %normed_kv_inline3274__iter_v1_pview
    ;
    const int64_t v257 = 0;
    // pto: %normed_kv_inline3274__iter_v1_pview
    ;
    const int64_t v258 = 512;
    // pto: %normed_kv_inline3274__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 64> v259 = pto::Shape<1, 1, 1, 16, 64>();
    // pto: %normed_kv_inline3274__iter_v1_pview
    ;
    pto::Stride<8192, 8192, 8192, 512, 1> v260 = pto::Stride<8192, 8192, 8192, 512, 1>();
    // pto: %normed_kv_inline3274__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v261 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v256 + (v257 + v168 * v258 + v234), v259, v260);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v261, v254);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  // pto: %kv_rope_norm_inline3295__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v262 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %kv_rope_norm_inline3295__tile
  uint64_t v263 = (uint64_t) v22;
  TASSIGN(v262, v263);
  // pto: %62
  __gm__ float* v264 = PTOAS__GLOBAL_TENSOR_DATA(v76);
  // pto: %62
  const int64_t v265 = 448;
  // pto: %62
  const int64_t v266 = 512;
  // pto: %62
  pto::Shape<1, 1, 1, 16, 64> v267 = pto::Shape<1, 1, 1, 16, 64>();
  // pto: %62
  pto::Stride<8192, 8192, 8192, 512, 1> v268 = pto::Stride<8192, 8192, 8192, 512, 1>();
  // pto: %62
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v269 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v264 + (v265 + v168 * v266), v267, v268);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  TLOAD(v262, v269);
  // pto: %10
  Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v270 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
  // pto: %10
  uint64_t v271 = (uint64_t) v26;
  TASSIGN(v270, v271);
  // pto: %63
  __gm__ bfloat16_t* v272 = PTOAS__GLOBAL_TENSOR_DATA(v92);
  // pto: %63
  unsigned v273 = 448;
  // pto: %63
  pto::Shape<1, 1, 1, 1, 64> v274 = pto::Shape<1, 1, 1, 1, 64>();
  // pto: %63
  pto::Stride<512, 512, 512, 512, 1> v275 = pto::Stride<512, 512, 512, 512, 1>();
  // pto: %63
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v276 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v272 + v273, v274, v275);
  TLOAD(v270, v276);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
  // pto: %gamma_rope_inline3296__tile
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v277 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
  // pto: %gamma_rope_inline3296__tile
  uint64_t v278 = (uint64_t) v23;
  TASSIGN(v277, v278);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
  RoundMode v279 = RoundMode::CAST_ROUND;
  SaturationMode v280 = SaturationMode::ON;
  TCVT(v277, v270, v279, v280);
  // pto: %11
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v281 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %11
  uint64_t v282 = (uint64_t) v22;
  TASSIGN(v281, v282);
  TROWEXPANDDIV(v281, v262, v229);
  // pto: %rope_normed_inline3297__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v283 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %rope_normed_inline3297__tile
  uint64_t v284 = (uint64_t) v22;
  TASSIGN(v283, v284);
  pipe_barrier(PIPE_V);
  TCOLEXPANDMUL(v283, v281, v277);
  // pto: %rope_ones_inline3298__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v285 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %rope_ones_inline3298__tile
  uint64_t v286 = (uint64_t) v23;
  TASSIGN(v285, v286);
  pipe_barrier(PIPE_V);
  TEXPANDS(v285, v36);
  // pto: %rope_index_inline3299__ci_tmp_v0
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v287 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v46);
  // pto: %rope_index_inline3299__ci_tmp_v0
  uint64_t v288 = (uint64_t) v26;
  TASSIGN(v287, v288);
  // pto: %rope_index_inline3299__tile
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v289 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
  // pto: %rope_index_inline3299__tile
  uint64_t v290 = (uint64_t) v27;
  TASSIGN(v289, v290);
  // pto: %ci_tmp_view
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v291;
  TRESHAPE(v291, v287);
  // pto: %ci_dst_view
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v292;
  TRESHAPE(v292, v289);
  TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v292, v47, v291);
  // pto: %rope_index_f_inline3300__tile
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v293 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
  // pto: %rope_index_f_inline3300__tile
  uint64_t v294 = (uint64_t) v26;
  TASSIGN(v293, v294);
  pipe_barrier(PIPE_V);
  RoundMode v295 = RoundMode::CAST_ROUND;
  SaturationMode v296 = SaturationMode::ON;
  TCVT(v293, v289, v295, v296);
  // pto: %rope_col_inline3301__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v297 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %rope_col_inline3301__tile
  uint64_t v298 = (uint64_t) v23;
  TASSIGN(v297, v298);
  pipe_barrier(PIPE_V);
  TCOLEXPANDMUL(v297, v285, v293);
  // pto: %12
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v299 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %12
  uint64_t v300 = (uint64_t) v26;
  TASSIGN(v299, v300);
  pipe_barrier(PIPE_V);
  TMULS(v299, v297, v48);
  // pto: %13
  Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v301 = Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %13
  uint64_t v302 = (uint64_t) v26;
  TASSIGN(v301, v302);
  pipe_barrier(PIPE_V);
  RoundMode v303 = RoundMode::CAST_TRUNC;
  SaturationMode v304 = SaturationMode::ON;
  TCVT(v301, v299, v303, v304);
  // pto: %rope_dup_f_inline3302__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v305 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %rope_dup_f_inline3302__tile
  uint64_t v306 = (uint64_t) v26;
  TASSIGN(v305, v306);
  pipe_barrier(PIPE_V);
  RoundMode v307 = RoundMode::CAST_ROUND;
  SaturationMode v308 = SaturationMode::ON;
  TCVT(v305, v301, v307, v308);
  // pto: %14
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %14
  uint64_t v310 = (uint64_t) v26;
  TASSIGN(v309, v310);
  pipe_barrier(PIPE_V);
  TMULS(v309, v305, v49);
  // pto: %rope_lane_inline3303__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v311 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %rope_lane_inline3303__tile
  uint64_t v312 = (uint64_t) v26;
  TASSIGN(v311, v312);
  pipe_barrier(PIPE_V);
  TSUB(v311, v297, v309);
  // pto: %15
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %15
  uint64_t v314 = (uint64_t) v23;
  TASSIGN(v313, v314);
  pipe_barrier(PIPE_V);
  TADDS(v313, v297, v36);
  // pto: %16
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %16
  uint64_t v316 = (uint64_t) v27;
  TASSIGN(v315, v316);
  TMULS(v315, v311, v49);
  // pto: %17
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v317 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %17
  uint64_t v318 = (uint64_t) v23;
  TASSIGN(v317, v318);
  pipe_barrier(PIPE_V);
  TSUB(v317, v313, v315);
  // pto: %rope_swap_idx_inline3304__tile
  Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v319 = Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %rope_swap_idx_inline3304__tile
  uint64_t v320 = (uint64_t) v23;
  TASSIGN(v319, v320);
  pipe_barrier(PIPE_V);
  RoundMode v321 = RoundMode::CAST_ROUND;
  SaturationMode v322 = SaturationMode::ON;
  TCVT(v319, v317, v321, v322);
  // pto: %gather_acc_init
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v323 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %gather_acc_init
  uint64_t v324 = (uint64_t) v27;
  TASSIGN(v323, v324);
  for (int64_t v325 = v38; v325 < v35; v325 += v30) {
    // pto: %gather_inp_row
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v326 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %gather_inp_row
    ;
    uint64_t v327 = (uint64_t) v22;
    TASSIGN(v326, v327);
    // pto: %64
    ;
    int64_t v328 = (int64_t) ((uint64_t) v325 * (uint64_t) v19);
    // pto: %64
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v329;
    // pto: %64
    ;
    uint64_t v330 = (uint64_t) ((int64_t) (uint64_t) v328 + (uint64_t) v22);
    TASSIGN(v329, v330);
    // pto: %gather_idx_row
    ;
    Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v331 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %gather_idx_row
    ;
    uint64_t v332 = (uint64_t) v23;
    TASSIGN(v331, v332);
    // pto: %65
    ;
    Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v333;
    // pto: %65
    ;
    uint64_t v334 = (uint64_t) ((int64_t) (uint64_t) v328 + (uint64_t) v23);
    TASSIGN(v333, v334);
    // pto: %gather_row_tmp
    ;
    Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v335 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %gather_row_tmp
    ;
    uint64_t v336 = (uint64_t) v28;
    TASSIGN(v335, v336);
    // pto: %gather_row
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v337 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %gather_row
    ;
    uint64_t v338 = (uint64_t) v29;
    TASSIGN(v337, v338);
    pipe_barrier(PIPE_V);
    TGATHER(v337, v329, v333, v335);
    // pto: %assemble_view
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v339;
    // pto: %assemble_view
    ;
    uint64_t v340 = (uint64_t) ((int64_t) (uint64_t) v328 + (uint64_t) v27);
    TASSIGN(v339, v340);
    pipe_barrier(PIPE_V);
    TMOV(v339, v337);
  }
  // pto: %swapped_inline3305__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v341 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %swapped_inline3305__tile
  uint64_t v342 = (uint64_t) v27;
  TASSIGN(v341, v342);
  // pto: %18
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v343 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %18
  uint64_t v344 = (uint64_t) v23;
  TASSIGN(v343, v344);
  pipe_barrier(PIPE_V);
  TMULS(v343, v311, v49);
  // pto: %19
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v345 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %19
  uint64_t v346 = (uint64_t) v23;
  TASSIGN(v345, v346);
  pipe_barrier(PIPE_V);
  TSUBS(v345, v343, v36);
  // pto: %sin_signed_inline3306__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v347 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %sin_signed_inline3306__tile
  uint64_t v348 = (uint64_t) v23;
  TASSIGN(v347, v348);
  pipe_barrier(PIPE_V);
  TMUL(v347, v164, v345);
  // pto: %20
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v349 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %20
  uint64_t v350 = (uint64_t) v22;
  TASSIGN(v349, v350);
  TMUL(v349, v283, v162);
  // pto: %21
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v351 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %21
  uint64_t v352 = (uint64_t) v23;
  TASSIGN(v351, v352);
  pipe_barrier(PIPE_V);
  TMUL(v351, v341, v347);
  // pto: %rope_rot_inline3307__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v353 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %rope_rot_inline3307__tile
  uint64_t v354 = (uint64_t) v22;
  TASSIGN(v353, v354);
  pipe_barrier(PIPE_V);
  TADD(v353, v349, v351);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
  // pto: %normed_kv_inline3274__rv_v2_pview
  __gm__ float* v355 = PTOAS__GLOBAL_TENSOR_DATA(v84);
  // pto: %normed_kv_inline3274__rv_v2_pview
  const int64_t v356 = 448;
  // pto: %normed_kv_inline3274__rv_v2_pview
  const int64_t v357 = 512;
  // pto: %normed_kv_inline3274__rv_v2_pview
  pto::Shape<1, 1, 1, 16, 64> v358 = pto::Shape<1, 1, 1, 16, 64>();
  // pto: %normed_kv_inline3274__rv_v2_pview
  pto::Stride<8192, 8192, 8192, 512, 1> v359 = pto::Stride<8192, 8192, 8192, 512, 1>();
  // pto: %normed_kv_inline3274__rv_v2_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v360 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v355 + (v356 + v168 * v357), v358, v359);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
  TSTORE(v360, v353);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  for (int64_t v361 = v38; v361 < v121; v361 += v30) {
    // pto: %68
    ;
    int64_t v362 = (int64_t) ((uint64_t) v119 + (uint64_t) v361);
    // pto: %token_pos_inline3270__tile
    ;
    int64_t v363 = (v1)[v362];
    // pto: %69
    ;
    int32_t v364 = (v2)[v362];
    // pto: %70
    ;
    int64_t v365 = (int64_t) v364;
    // pto: %72
    ;
    int64_t v366 = (int64_t) ((uint64_t) v363 + (uint64_t) v39);
    // pto: %73
    ;
    int64_t v367 = v366 % v40;
    // pto: %74, %75, %76
    ;
    int64_t v368 = v367 < v20 ? (int64_t) ((uint64_t) v367 + (uint64_t) v40) : v367;
    // pto: %71, %77, %78
    ;
    if (v365 >= v38 & v368 == v20) {
      // pto: %79
      ;
      int32_t v369 = (v3)[v365];
      // pto: %82
      ;
      const int64_t v370 = 1;
      // pto: %82
      ;
      const int64_t v371 = 0;
      // pto: %82
      ;
      int64_t v372 = v366 / v40;
      // pto: %82
      ;
      bool v373 = v366 < v371;
      // pto: %82
      ;
      bool v374 = v40 < v371;
      // pto: %82
      ;
      bool v375 = v373 == v374;
      // pto: %82
      ;
      bool v376 = v366 % v40 != v371 && v373 != v374;
      // pto: %82
      ;
      int64_t v377 = v376 ? v372 - v370 : v372;
      // pto: %80, %84
      ;
      int64_t v378 = (int64_t) ((uint64_t) ((int64_t) v369) + (uint64_t) v377);
      // pto: %85, %86, %87
      ;
      if (v378 >= v38 & v378 < v15) {
        // pto: %flat_offset_mul
        ;
        int64_t v379 = (int64_t) ((uint64_t) v378 * (uint64_t) v34);
        // pto: %cache_page_inline3312__tile
        ;
        int32_t v380 = (v11)[v379];
        // pto: %89, %cache_offset_inline3313__tile
        ;
        int32_t v381 = (v11)[(int64_t) ((uint64_t) v379 + (uint64_t) v30)];
        // pto: %90
        ;
        int64_t v382 = (int64_t) v380;
        // pto: %92
        ;
        int64_t v383 = (int64_t) v381;
        // pto: %91, %93, %94
        ;
        if (v382 >= v38 & v383 >= v38) {
          // pto: %96, %98
          ;
          int64_t v384 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v382 * (uint64_t) v50) + (uint64_t) v383);
          // pto: %kv_row_fp32_inline3315__tile
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v385 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
          // pto: %kv_row_fp32_inline3315__tile
          ;
          uint64_t v386 = (uint64_t) v22;
          TASSIGN(v385, v386);
          // pto: %99
          ;
          int64_t v387 = v362 < v38 ? v38 : v362;
          // pto: %normed_kv_inline3274__tile_pview
          ;
          __gm__ float* v388 = PTOAS__GLOBAL_TENSOR_DATA(v84);
          // pto: %normed_kv_inline3274__tile_pview
          ;
          const int64_t v389 = 0;
          // pto: %normed_kv_inline3274__tile_pview
          ;
          const int64_t v390 = 512;
          // pto: %normed_kv_inline3274__tile_pview
          ;
          pto::Shape<1, 1, 1, 1, 512> v391 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %normed_kv_inline3274__tile_pview
          ;
          pto::Stride<512, 512, 512, 512, 1> v392 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %normed_kv_inline3274__tile_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v393 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v388 + (v389 + v387 * v390), v391, v392);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
          TLOAD(v385, v393);
          set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
          // pto: %kv_flat_inline3258__iter_v1_pview
          ;
          __gm__ float* v394 = PTOAS__GLOBAL_TENSOR_DATA(v110);
          // pto: %kv_flat_inline3258__iter_v1_pview
          ;
          const int64_t v395 = 0;
          // pto: %kv_flat_inline3258__iter_v1_pview
          ;
          const int64_t v396 = 512;
          // pto: %kv_flat_inline3258__iter_v1_pview
          ;
          pto::Shape<1, 1, 1, 1, 512> v397 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %kv_flat_inline3258__iter_v1_pview
          ;
          pto::Stride<512, 512, 512, 512, 1> v398 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %kv_flat_inline3258__iter_v1_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v399 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v394 + (v395 + v387 * v396), v397, v398);
          wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
          TSTORE(v399, v385);
          set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
          // pto: %22
          ;
          Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v400 = Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
          // pto: %22
          ;
          uint64_t v401 = (uint64_t) v22;
          TASSIGN(v400, v401);
          wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
          RoundMode v402 = RoundMode::CAST_RINT;
          SaturationMode v403 = SaturationMode::ON;
          TCVT(v400, v385, v402, v403);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          // pto: %101
          ;
          int64_t v404 = v384 < v38 ? v38 : v384;
          // pto: %cmp_kv_cache_flat_inline3259__iter_v1_pview
          ;
          __gm__ bfloat16_t* v405 = PTOAS__GLOBAL_TENSOR_DATA(v101);
          // pto: %cmp_kv_cache_flat_inline3259__iter_v1_pview
          ;
          const int64_t v406 = 0;
          // pto: %cmp_kv_cache_flat_inline3259__iter_v1_pview
          ;
          const int64_t v407 = 512;
          // pto: %cmp_kv_cache_flat_inline3259__iter_v1_pview
          ;
          pto::Shape<1, 1, 1, 1, 512> v408 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %cmp_kv_cache_flat_inline3259__iter_v1_pview
          ;
          pto::Stride<512, 512, 512, 512, 1> v409 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %cmp_kv_cache_flat_inline3259__iter_v1_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v410 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v405 + (v406 + v404 * v407), v408, v409);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          TSTORE(v410, v400);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        };
      };
    };
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}