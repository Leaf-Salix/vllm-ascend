#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_quant(__gm__ bfloat16_t* v1, __gm__ float* v2, __gm__ int8_t* v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c32800_i64
  const int64_t v8 = 32800;
  // pto: %c32_i64
  const int64_t v9 = 32;
  // pto: %c65568_i64
  const int64_t v10 = 65568;
  // pto: %c0_i64
  const int64_t v11 = 0;
  // pto: %c8192_index
  const int64_t v12 = 8192;
  // pto: %c1_index
  const int64_t v13 = 1;
  // pto: %c8_index
  const int64_t v14 = 8;
  // pto: %c1024_index
  const int64_t v15 = 1024;
  // pto: %c0_index
  const int64_t v16 = 0;
  // pto: %cst_9
  const float v17 = 0.00787401571f;
  // pto: %cst_10
  const float v18 = 0.0f;
  // pto: %cst_11
  const float v19 = 1.0f;
  // pto: %cst_12
  const float v20 = 127.0f;
  // pto: %projected_o__ssa_v0_view
  const int64_t v21 = 1;
  // pto: %projected_o__ssa_v0_view
  const int64_t v22 = 1;
  // pto: %projected_o__ssa_v0_view
  const int64_t v23 = 1;
  // pto: %projected_o__ssa_v0_view
  int64_t v24 = (int64_t) v5;
  // pto: %projected_o__ssa_v0_view
  int64_t v25 = v24 * v12;
  // pto: %projected_o__ssa_v0_view
  int64_t v26 = v23 * v25;
  // pto: %projected_o__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v27 = pto::Shape<1, 1, 1, -1, -1>(v21, v22, v23, v24, v12);
  // pto: %projected_o__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v28 = pto::Stride<-1, -1, -1, -1, -1>(v22 * v26, v26, v25, v12, v13);
  // pto: %projected_o__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v29 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v27, v28);
  // pto: %scale_o__ssa_v0_view
  const int64_t v30 = 1;
  // pto: %scale_o__ssa_v0_view
  const int64_t v31 = 1;
  // pto: %scale_o__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %scale_o__ssa_v0_view
  int64_t v33 = (int64_t) v5;
  // pto: %scale_o__ssa_v0_view
  int64_t v34 = v33 * v13;
  // pto: %scale_o__ssa_v0_view
  int64_t v35 = v32 * v34;
  // pto: %scale_o__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v36 = pto::Shape<1, 1, 1, -1, -1>(v30, v31, v32, v33, v13);
  // pto: %scale_o__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v37 = pto::Stride<-1, -1, -1, -1, -1>(v31 * v35, v35, v34, v13, (int64_t) v5);
  // pto: %scale_o__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v38 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v2, v36, v37);
  // pto: %quantized_o__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %quantized_o__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %quantized_o__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %quantized_o__ssa_v0_view
  int64_t v42 = (int64_t) v5;
  // pto: %quantized_o__ssa_v0_view
  int64_t v43 = v42 * v12;
  // pto: %quantized_o__ssa_v0_view
  int64_t v44 = v41 * v43;
  // pto: %quantized_o__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v45 = pto::Shape<1, 1, 1, -1, -1>(v39, v40, v41, v42, v12);
  // pto: %quantized_o__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v46 = pto::Stride<-1, -1, -1, -1, -1>(v40 * v44, v44, v43, v12, v13);
  // pto: %quantized_o__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v47 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v45, v46);
  // pto: %block_inline5392__ssa_v0, %0
  int64_t v48 = (int64_t) ((uint64_t) ((int64_t) v6) * (uint64_t) v14);
  // pto: %1
  int64_t v49 = (int64_t) ((uint64_t) v4 - (uint64_t) v48);
  // pto: %2
  int64_t v50 = v49 < v14 ? v49 : v14;
  // pto: %first_quant_inline5393__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v51 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
  // pto: %first_quant_inline5393__ssa_v0
  uint64_t v52 = (uint64_t) v8;
  TASSIGN(v51, v52);
  // pto: %3
  int64_t v53 = v48 < v16 ? v16 : v48;
  // pto: %projected_o__ssa_v0_pview
  const int64_t v54 = 0;
  // pto: %projected_o__ssa_v0_pview
  __gm__ bfloat16_t* v55 = PTOAS__GLOBAL_TENSOR_DATA(v29);
  // pto: %projected_o__ssa_v0_pview
  const int64_t v56 = 1;
  // pto: %projected_o__ssa_v0_pview
  const int64_t v57 = 1;
  // pto: %projected_o__ssa_v0_pview
  const int64_t v58 = 1;
  // pto: %projected_o__ssa_v0_pview
  int64_t v59 = v50 * v12;
  // pto: %projected_o__ssa_v0_pview
  int64_t v60 = v58 * v59;
  // pto: %projected_o__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 1024> v61 = pto::Shape<1, 1, 1, -1, 1024>(v56, v57, v58, v50, v15);
  // pto: %projected_o__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v62 = pto::Stride<-1, -1, -1, -1, -1>(v57 * v60, v60, v59, v12, v13);
  // pto: %projected_o__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v63 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v55 + (v54 + v53 * v12 + v16 * v13), v61, v62);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  TLOAD(v51, v63);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %t__tmp_v1014
  Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v64 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
  // pto: %t__tmp_v1014
  uint64_t v65 = (uint64_t) v9;
  TASSIGN(v64, v65);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  RoundMode v66 = RoundMode::CAST_ROUND;
  SaturationMode v67 = SaturationMode::ON;
  TCVT(v64, v51, v66, v67);
  // pto: %first_abs_inline5394__ssa_v0
  Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v68 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
  // pto: %first_abs_inline5394__ssa_v0
  uint64_t v69 = (uint64_t) v9;
  TASSIGN(v68, v69);
  pipe_barrier(PIPE_V);
  TABS(v68, v64);
  // pto: %t__tmp_v1015
  Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v70 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v15);
  // pto: %t__tmp_v1015
  uint64_t v71 = (uint64_t) v8;
  TASSIGN(v70, v71);
  // pto: %amax_inline5395__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v72 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v13);
  // pto: %amax_inline5395__ssa_v0
  uint64_t v73 = (uint64_t) v10;
  TASSIGN(v72, v73);
  pipe_barrier(PIPE_V);
  TROWMAX(v72, v68, v70);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v74 = v13; v74 < v14; v74 += v13) {
    // pto: %q_bf16_inline5397__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v75 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
    // pto: %q_bf16_inline5397__ssa_v0
    ;
    uint64_t v76 = (uint64_t) v8;
    TASSIGN(v75, v76);
    // pto: %5
    ;
    int64_t v77 = (int64_t) ((uint64_t) v74 * (uint64_t) v15);
    // pto: %6
    ;
    int64_t v78 = v77 < v16 ? v16 : v77;
    // pto: %7
    ;
    const int64_t v79 = 0;
    // pto: %7
    ;
    __gm__ bfloat16_t* v80 = PTOAS__GLOBAL_TENSOR_DATA(v29);
    // pto: %7
    ;
    const int64_t v81 = 1;
    // pto: %7
    ;
    const int64_t v82 = 1;
    // pto: %7
    ;
    const int64_t v83 = 1;
    // pto: %7
    ;
    int64_t v84 = v50 * v12;
    // pto: %7
    ;
    int64_t v85 = v83 * v84;
    // pto: %7
    ;
    pto::Shape<1, 1, 1, -1, 1024> v86 = pto::Shape<1, 1, 1, -1, 1024>(v81, v82, v83, v50, v15);
    // pto: %7
    ;
    pto::Stride<-1, -1, -1, -1, -1> v87 = pto::Stride<-1, -1, -1, -1, -1>(v82 * v85, v85, v84, v12, v13);
    // pto: %7
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v88 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v80 + (v79 + v53 * v12 + v78 * v13), v86, v87);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    TLOAD(v75, v88);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %q_fp32_inline5398__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v89 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
    // pto: %q_fp32_inline5398__ssa_v0
    ;
    uint64_t v90 = (uint64_t) v9;
    TASSIGN(v89, v90);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    pipe_barrier(PIPE_V);
    RoundMode v91 = RoundMode::CAST_ROUND;
    SaturationMode v92 = SaturationMode::ON;
    TCVT(v89, v75, v91, v92);
    // pto: %t__tmp_v1016
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
    // pto: %t__tmp_v1016
    ;
    uint64_t v94 = (uint64_t) v9;
    TASSIGN(v93, v94);
    pipe_barrier(PIPE_V);
    TABS(v93, v89);
    // pto: %t__tmp_v1017
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v95 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v15);
    // pto: %t__tmp_v1017
    ;
    uint64_t v96 = (uint64_t) v8;
    TASSIGN(v95, v96);
    // pto: %t__tmp_v1018
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v13);
    // pto: %t__tmp_v1018
    ;
    uint64_t v98 = (uint64_t) v11;
    TASSIGN(v97, v98);
    pipe_barrier(PIPE_V);
    TROWMAX(v97, v93, v95);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    // pto: %amax_inline5395__rm_a0_tmp_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
    // pto: %amax_inline5395__rm_a0_tmp_v0
    ;
    uint64_t v100 = (uint64_t) v10;
    TASSIGN(v99, v100);
    // pto: %amax_inline5395__rm_a1_tmp_v1
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
    // pto: %amax_inline5395__rm_a1_tmp_v1
    ;
    uint64_t v102 = (uint64_t) v11;
    TASSIGN(v101, v102);
    // pto: %amax_inline5395__row_major_tmp_v2
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
    // pto: %amax_inline5395__row_major_tmp_v2
    ;
    uint64_t v104 = (uint64_t) v9;
    TASSIGN(v103, v104);
    pipe_barrier(PIPE_V);
    TMAX(v103, v99, v101);
    // pto: %amax_inline5395__ssa_v3
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v105 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v13);
    // pto: %amax_inline5395__ssa_v3
    ;
    uint64_t v106 = (uint64_t) v9;
    TASSIGN(v105, v106);
    // pto: %amax_inline5395__ssa_v3_mv
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v107 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v13);
    // pto: %amax_inline5395__ssa_v3_mv
    ;
    uint64_t v108 = (uint64_t) v10;
    TASSIGN(v107, v108);
    pipe_barrier(PIPE_V);
    TMOV(v107, v105);
  }
  // pto: %dequant_inline5399__rm_a0_tmp_v3
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v109 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
  // pto: %dequant_inline5399__rm_a0_tmp_v3
  uint64_t v110 = (uint64_t) v10;
  TASSIGN(v109, v110);
  // pto: %dequant_inline5399__row_major_tmp_v4
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
  // pto: %dequant_inline5399__row_major_tmp_v4
  uint64_t v112 = (uint64_t) v9;
  TASSIGN(v111, v112);
  pipe_barrier(PIPE_V);
  TMULS(v111, v109, v17);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %dequant_inline5399__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v13);
  // pto: %dequant_inline5399__ssa_v0
  uint64_t v114 = (uint64_t) v9;
  TASSIGN(v113, v114);
  // pto: %denominator_inline5400__rm_a0_tmp_v5
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v115 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
  // pto: %denominator_inline5400__rm_a0_tmp_v5
  uint64_t v116 = (uint64_t) v10;
  TASSIGN(v115, v116);
  // pto: %denominator_inline5400__row_major_tmp_v6
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
  // pto: %denominator_inline5400__row_major_tmp_v6
  uint64_t v118 = (uint64_t) v8;
  TASSIGN(v117, v118);
  TADDS(v117, v115, v18);
  set_flag(PIPE_V, PIPE_S, EVENT_ID0);
  // pto: %denominator_inline5400__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v119 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v13);
  // pto: %denominator_inline5400__ssa_v0
  uint64_t v120 = (uint64_t) v8;
  TASSIGN(v119, v120);
  wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
  for (int64_t v121 = v16; v121 < v50; v121 += v13) {
    // pto: %magnitude_inline5402__ssa_v0
    ;
    float v122 = v119.GetValue(v121);
    // pto: %8
    ;
    bool v123 = v122 != v122 || v18 != v18;
    // pto: %8
    ;
    bool v124 = v122 == v122 && v18 == v18;
    // pto: %8
    ;
    if (v124 && v122 == v18) {
      v119.SetValue(v121, v19);
    };
  }
  set_flag(PIPE_S, PIPE_V, EVENT_ID0);
  set_flag(PIPE_S, PIPE_MTE2, EVENT_ID0);
  // pto: %t__rm_a0_tmp_v7
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v125 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
  // pto: %t__rm_a0_tmp_v7
  uint64_t v126 = (uint64_t) v10;
  TASSIGN(v125, v126);
  // pto: %t__row_major_tmp_v8
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
  // pto: %t__row_major_tmp_v8
  uint64_t v128 = (uint64_t) v10;
  TASSIGN(v127, v128);
  pipe_barrier(PIPE_V);
  TMULS(v127, v125, v18);
  // pto: %t__tmp_v1019
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v13);
  // pto: %t__tmp_v1019
  uint64_t v130 = (uint64_t) v10;
  TASSIGN(v129, v130);
  // pto: %t__rm_a0_tmp_v9
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
  // pto: %t__rm_a0_tmp_v9
  uint64_t v132 = (uint64_t) v10;
  TASSIGN(v131, v132);
  // pto: %t__row_major_tmp_v10
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
  // pto: %t__row_major_tmp_v10
  uint64_t v134 = (uint64_t) v10;
  TASSIGN(v133, v134);
  pipe_barrier(PIPE_V);
  TADDS(v133, v131, v20);
  // pto: %t__tmp_v1020
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v135 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v13);
  // pto: %t__tmp_v1020
  uint64_t v136 = (uint64_t) v10;
  TASSIGN(v135, v136);
  // pto: %multiplier_inline5403__rm_a0_tmp_v11
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
  // pto: %multiplier_inline5403__rm_a0_tmp_v11
  uint64_t v138 = (uint64_t) v10;
  TASSIGN(v137, v138);
  // pto: %multiplier_inline5403__rm_a1_tmp_v12
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v139 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
  // pto: %multiplier_inline5403__rm_a1_tmp_v12
  uint64_t v140 = (uint64_t) v8;
  TASSIGN(v139, v140);
  // pto: %multiplier_inline5403__row_major_tmp_v13
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v141 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
  // pto: %multiplier_inline5403__row_major_tmp_v13
  uint64_t v142 = (uint64_t) v10;
  TASSIGN(v141, v142);
  pipe_barrier(PIPE_V);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
  TDIV(v141, v137, v139);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  // pto: %multiplier_inline5403__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v143 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v13);
  // pto: %multiplier_inline5403__ssa_v0
  uint64_t v144 = (uint64_t) v10;
  TASSIGN(v143, v144);
  v113.SetValidShape(v50, v13);
  // pto: %scale_o__ssa_v0_pview
  int64_t v145 = (int64_t) v5;
  // pto: %scale_o__ssa_v0_pview
  const int64_t v146 = 0;
  // pto: %scale_o__ssa_v0_pview
  __gm__ float* v147 = PTOAS__GLOBAL_TENSOR_DATA(v38);
  // pto: %scale_o__ssa_v0_pview
  const int64_t v148 = 1;
  // pto: %scale_o__ssa_v0_pview
  const int64_t v149 = 1;
  // pto: %scale_o__ssa_v0_pview
  const int64_t v150 = 1;
  // pto: %scale_o__ssa_v0_pview
  int64_t v151 = v50 * v13;
  // pto: %scale_o__ssa_v0_pview
  int64_t v152 = v150 * v151;
  // pto: %scale_o__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 1> v153 = pto::Shape<1, 1, 1, -1, 1>(v148, v149, v150, v50, v13);
  // pto: %scale_o__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v154 = pto::Stride<-1, -1, -1, -1, -1>(v149 * v152, v152, v151, v13, v145);
  // pto: %scale_o__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v155 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v147 + (v146 + v53 * v13 + v16 * v145), v153, v154);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v155, v113);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_S, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  for (int64_t v156 = v16; v156 < v14; v156 += v13) {
    // pto: %12
    ;
    int64_t v157 = (int64_t) ((uint64_t) v156 * (uint64_t) v15);
    // pto: %quant_bf16_inline5405__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v158 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
    // pto: %quant_bf16_inline5405__ssa_v0
    ;
    uint64_t v159 = (uint64_t) v8;
    TASSIGN(v158, v159);
    // pto: %14
    ;
    int64_t v160 = v157 < v16 ? v16 : v157;
    // pto: %15
    ;
    const int64_t v161 = 0;
    // pto: %15
    ;
    __gm__ bfloat16_t* v162 = PTOAS__GLOBAL_TENSOR_DATA(v29);
    // pto: %15
    ;
    const int64_t v163 = 1;
    // pto: %15
    ;
    const int64_t v164 = 1;
    // pto: %15
    ;
    const int64_t v165 = 1;
    // pto: %15
    ;
    int64_t v166 = v50 * v12;
    // pto: %15
    ;
    int64_t v167 = v165 * v166;
    // pto: %15
    ;
    pto::Shape<1, 1, 1, -1, 1024> v168 = pto::Shape<1, 1, 1, -1, 1024>(v163, v164, v165, v50, v15);
    // pto: %15
    ;
    pto::Stride<-1, -1, -1, -1, -1> v169 = pto::Stride<-1, -1, -1, -1, -1>(v164 * v167, v167, v166, v12, v13);
    // pto: %15
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v170 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v162 + (v161 + v53 * v12 + v160 * v13), v168, v169);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    TLOAD(v158, v170);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    // pto: %t__tmp_v1022
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v171 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
    // pto: %t__tmp_v1022
    ;
    uint64_t v172 = (uint64_t) v9;
    TASSIGN(v171, v172);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    RoundMode v173 = RoundMode::CAST_ROUND;
    SaturationMode v174 = SaturationMode::ON;
    TCVT(v171, v158, v173, v174);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    // pto: %quant_scaled_inline5406__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
    // pto: %quant_scaled_inline5406__ssa_v0
    ;
    uint64_t v176 = (uint64_t) v9;
    TASSIGN(v175, v176);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v175, v171, v143);
    // pto: %integer_inline5407__ssa_v0
    ;
    Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
    // pto: %integer_inline5407__ssa_v0
    ;
    uint64_t v178 = (uint64_t) v9;
    TASSIGN(v177, v178);
    pipe_barrier(PIPE_V);
    RoundMode v179 = RoundMode::CAST_RINT;
    SaturationMode v180 = SaturationMode::ON;
    TCVT(v177, v175, v179, v180);
    // pto: %half_inline5408__ssa_v0
    ;
    Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
    // pto: %half_inline5408__ssa_v0
    ;
    uint64_t v182 = (uint64_t) v9;
    TASSIGN(v181, v182);
    pipe_barrier(PIPE_V);
    RoundMode v183 = RoundMode::CAST_ROUND;
    SaturationMode v184 = SaturationMode::ON;
    TCVT(v181, v177, v183, v184);
    // pto: %result_inline5409__ssa_v0
    ;
    Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v185 = Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
    // pto: %result_inline5409__ssa_v0
    ;
    uint64_t v186 = (uint64_t) v9;
    TASSIGN(v185, v186);
    pipe_barrier(PIPE_V);
    RoundMode v187 = RoundMode::CAST_TRUNC;
    SaturationMode v188 = SaturationMode::ON;
    TCVT(v185, v181, v187, v188);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    v185.SetValidShape(v50, v15);
    // pto: %quantized_o__ssa_v0_pview
    ;
    const int64_t v189 = 0;
    // pto: %quantized_o__ssa_v0_pview
    ;
    __gm__ int8_t* v190 = PTOAS__GLOBAL_TENSOR_DATA(v47);
    // pto: %quantized_o__ssa_v0_pview
    ;
    const int64_t v191 = 1;
    // pto: %quantized_o__ssa_v0_pview
    ;
    const int64_t v192 = 1;
    // pto: %quantized_o__ssa_v0_pview
    ;
    const int64_t v193 = 1;
    // pto: %quantized_o__ssa_v0_pview
    ;
    int64_t v194 = v50 * v12;
    // pto: %quantized_o__ssa_v0_pview
    ;
    int64_t v195 = v193 * v194;
    // pto: %quantized_o__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1024> v196 = pto::Shape<1, 1, 1, -1, 1024>(v191, v192, v193, v50, v15);
    // pto: %quantized_o__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v197 = pto::Stride<-1, -1, -1, -1, -1>(v192 * v195, v195, v194, v12, v13);
    // pto: %quantized_o__ssa_v0_pview
    ;
    GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v198 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v190 + (v189 + v53 * v12 + v160 * v13), v196, v197);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    TSTORE(v198, v185);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}