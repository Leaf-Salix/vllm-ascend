#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qr_proj_matmul_1(__gm__ float* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, int64_t v4, int64_t v5, int64_t v6, int64_t v7, int64_t v8, int64_t v9, int32_t v10, int32_t v11) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v12 = 0;
  // pto: %c32768_i64
  const int64_t v13 = 32768;
  // pto: %c49152_i64
  const int64_t v14 = 49152;
  // pto: %c81920_i64
  const int64_t v15 = 81920;
  // pto: %c16384_i64
  const int64_t v16 = 16384;
  // pto: %c1024_index
  const int64_t v17 = 1024;
  // pto: %c1_index
  const int64_t v18 = 1;
  // pto: %c4096_index
  const int64_t v19 = 4096;
  // pto: %c256_index
  const int64_t v20 = 256;
  // pto: %c64_index
  const int64_t v21 = 64;
  // pto: %c16_index
  const int64_t v22 = 16;
  // pto: %c4194304_index
  const int64_t v23 = 4194304;
  // pto: %c16384_index
  const int64_t v24 = 16384;
  // pto: %c32_index
  const int64_t v25 = 32;
  // pto: %c96_index
  const int64_t v26 = 96;
  // pto: %c0_index
  const int64_t v27 = 0;
  // pto: %c2_index
  const int64_t v28 = 2;
  // pto: %c240_index
  const int64_t v29 = 240;
  // pto: %c48_index
  const int64_t v30 = 48;
  // pto: %c9_index
  const int64_t v31 = 9;
  // pto: %c15_index
  const int64_t v32 = 15;
  // pto: %c3_index
  const int64_t v33 = 3;
  // pto: %c14_index
  const int64_t v34 = 14;
  // pto: %cn1_index
  const int64_t v35 = -1;
  // pto: %qr_fp32_inline2839__rv_v24_view
  const int64_t v36 = 1;
  // pto: %qr_fp32_inline2839__rv_v24_view
  const int64_t v37 = 1;
  // pto: %qr_fp32_inline2839__rv_v24_view
  const int64_t v38 = 1;
  // pto: %qr_fp32_inline2839__rv_v24_view
  int64_t v39 = (int64_t) v8;
  // pto: %qr_fp32_inline2839__rv_v24_view
  int64_t v40 = v39 * v17;
  // pto: %qr_fp32_inline2839__rv_v24_view
  int64_t v41 = v38 * v40;
  // pto: %qr_fp32_inline2839__rv_v24_view
  pto::Shape<1, 1, 1, -1, -1> v42 = pto::Shape<1, 1, 1, -1, -1>(v36, v37, v38, v39, v17);
  // pto: %qr_fp32_inline2839__rv_v24_view
  pto::Stride<-1, -1, -1, -1, -1> v43 = pto::Stride<-1, -1, -1, -1, -1>(v37 * v41, v41, v40, v17, v18);
  // pto: %qr_fp32_inline2839__rv_v24_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v44 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v42, v43);
  // pto: %x_view_inline2901__ssa_v0_view
  const int64_t v45 = 1;
  // pto: %x_view_inline2901__ssa_v0_view
  const int64_t v46 = 1;
  // pto: %x_view_inline2901__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %x_view_inline2901__ssa_v0_view
  int64_t v48 = (int64_t) v9;
  // pto: %x_view_inline2901__ssa_v0_view
  int64_t v49 = v48 * v19;
  // pto: %x_view_inline2901__ssa_v0_view
  int64_t v50 = v47 * v49;
  // pto: %x_view_inline2901__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v51 = pto::Shape<1, 1, 1, -1, -1>(v45, v46, v47, v48, v19);
  // pto: %x_view_inline2901__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v52 = pto::Stride<-1, -1, -1, -1, -1>(v46 * v50, v50, v49, v19, v18);
  // pto: %x_view_inline2901__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v53 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v51, v52);
  // pto: %wq_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v54 = pto::Shape<-1, -1, -1, -1, -1>(v18, v20, v21, v22, v22);
  // pto: %wq_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v55 = pto::Stride<-1, -1, -1, -1, -1>(v23, v24, v20, v22, v18);
  // pto: %wq_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v56 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v3, v54, v55);
  // pto: %qbg_idx_inline2907__ssa_v0, %14
  int64_t v57 = (int64_t) ((uint64_t) ((int64_t) v10) * (uint64_t) v25);
  // pto: %15
  const int64_t v58 = 1;
  // pto: %15
  const int64_t v59 = 0;
  // pto: %15
  int64_t v60 = v57 / v26;
  // pto: %15
  bool v61 = v57 < v59;
  // pto: %15
  bool v62 = v26 < v59;
  // pto: %15
  bool v63 = v61 == v62;
  // pto: %15
  bool v64 = v57 % v26 != v59 && v61 != v62;
  // pto: %15
  int64_t v65 = v64 ? v60 - v58 : v60;
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  for (int64_t v66 = v27; v66 < v4; v66 += v21) {
    // pto: %16
    ;
    int64_t v67 = (int64_t) ((uint64_t) v5 + (uint64_t) v66);
    // pto: %dense_acc_inline2913__tile
    ;
    Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v68 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v21, v25);
    // pto: %dense_acc_inline2913__tile
    ;
    uint64_t v69 = (uint64_t) v12;
    TASSIGN(v68, v69);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    for (int64_t v70 = v27; v70 < v22; v70 += v28) {
      // pto: %17
      ;
      int64_t v71 = (int64_t) ((uint64_t) v70 + (uint64_t) v18);
      // pto: %21
      ;
      int64_t v72 = v6 % v30;
      // pto: %22, %23, %24
      ;
      int64_t v73 = v72 < v27 ? (int64_t) ((uint64_t) v72 + (uint64_t) v30) : v72;
      // pto: %18, %19, %20, %25, %26, %27, %28
      ;
      bool v74 = (v6 >= v26 & v6 <= v29 & v73 == v27) & v65 < v31;
      // pto: %dense_k_order_inline2915__phi_v2
      ;
      int64_t v75;
      if (v74) {
        // pto: %29
        ;
        int64_t v76 = v65 % v28;
        // pto: %30, %31, %32
        ;
        int64_t v77 = v76 < v27 ? (int64_t) ((uint64_t) v76 + (uint64_t) v28) : v76;
        // pto: %33
        ;
        // pto: %dense_k_direction_inline2916__phi_v2
        ;
        int64_t v78;
        if (v77 == v18) {
          // pto: %34
          ;
          v78 = (int64_t) ((uint64_t) v32 - (uint64_t) v70);
        } else {
          v78 = v70;
        };
        // pto: %35
        ;
        const int64_t v79 = 1;
        // pto: %35
        ;
        const int64_t v80 = 0;
        // pto: %35
        ;
        int64_t v81 = v65 / v28;
        // pto: %35
        ;
        bool v82 = v65 < v80;
        // pto: %35
        ;
        bool v83 = v28 < v80;
        // pto: %35
        ;
        bool v84 = v82 == v83;
        // pto: %35
        ;
        bool v85 = v65 % v28 != v80 && v82 != v83;
        // pto: %35
        ;
        int64_t v86 = v85 ? v81 - v79 : v81;
        // pto: %37
        ;
        uint64_t v87 = (uint64_t) v78;
        // pto: %36, %37, %38
        ;
        int64_t v88 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v86 * (uint64_t) v33) + v87) % v22;
        // pto: %39, %40, %41
        ;
        v75 = v88 < v27 ? (int64_t) ((uint64_t) v88 + (uint64_t) v22) : v88;
      } else {
        v75 = v70;
      };
      // pto: %42
      ;
      bool v89 = v75 < v27;
      // pto: %42
      ;
      int64_t v90 = v89 ? v27 : v75;
      // pto: %43
      ;
      int64_t v91 = (int64_t) ((uint64_t) v90 * (uint64_t) v20);
      // pto: %dense_x_inline2918__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v92 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v21, v20);
      // pto: %dense_x_inline2918__tile
      ;
      uint64_t v93 = (uint64_t) v12;
      TASSIGN(v92, v93);
      // pto: %44
      ;
      int64_t v94 = v67 < v27 ? v27 : v67;
      // pto: %45
      ;
      int64_t v95 = v91 < v27 ? v27 : v91;
      // pto: %x_view_inline2901__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v96 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %x_view_inline2901__ssa_v0_pview
      ;
      const int64_t v97 = 0;
      // pto: %x_view_inline2901__ssa_v0_pview
      ;
      const int64_t v98 = 4096;
      // pto: %x_view_inline2901__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 64, 256> v99 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %x_view_inline2901__ssa_v0_pview
      ;
      pto::Stride<262144, 262144, 262144, 4096, 1> v100 = pto::Stride<262144, 262144, 262144, 4096, 1>();
      // pto: %x_view_inline2901__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND> v101 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND>(v96 + (v97 + v94 * v98 + v95), v99, v100);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v92, v101);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %dense_w_inline2919__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v20);
      // pto: %dense_w_inline2919__tile
      ;
      uint64_t v103 = (uint64_t) v13;
      TASSIGN(v102, v103);
      // pto: %46
      ;
      const int64_t v104 = 1;
      // pto: %46
      ;
      const int64_t v105 = 0;
      // pto: %46
      ;
      int64_t v106 = v91 / v22;
      // pto: %46
      ;
      bool v107 = v91 < v105;
      // pto: %46
      ;
      bool v108 = v22 < v105;
      // pto: %46
      ;
      bool v109 = v107 == v108;
      // pto: %46
      ;
      bool v110 = v91 % v22 != v105 && v107 != v108;
      // pto: %46
      ;
      int64_t v111 = v110 ? v106 - v104 : v106;
      // pto: %47
      ;
      int64_t v112 = v111 < v27 ? v27 : v111;
      // pto: %48
      ;
      const int64_t v113 = 1;
      // pto: %48
      ;
      const int64_t v114 = 0;
      // pto: %48
      ;
      int64_t v115 = v57 / v22;
      // pto: %48
      ;
      bool v116 = v57 < v114;
      // pto: %48
      ;
      bool v117 = v22 < v114;
      // pto: %48
      ;
      bool v118 = v116 == v117;
      // pto: %48
      ;
      bool v119 = v57 % v22 != v114 && v116 != v117;
      // pto: %48
      ;
      int64_t v120 = v119 ? v115 - v113 : v115;
      // pto: %49
      ;
      int64_t v121 = v120 < v27 ? v27 : v120;
      // pto: %wq_a__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v122 = PTOAS__GLOBAL_TENSOR_DATA(v56);
      // pto: %wq_a__ssa_v0_pview
      ;
      const int64_t v123 = 0;
      // pto: %wq_a__ssa_v0_pview
      ;
      const int64_t v124 = 16384;
      // pto: %wq_a__ssa_v0_pview
      ;
      const int64_t v125 = 256;
      // pto: %wq_a__ssa_v0_pview
      ;
      pto::Shape<1, 16, 2, 16, 16> v126 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %wq_a__ssa_v0_pview
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v127 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %wq_a__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v128 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v122 + (v123 + v112 * v124 + v121 * v125), v126, v127);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v102, v128);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %61
      ;
      int64_t v129;
      if (v74) {
        // pto: %63
        ;
        int64_t v130 = v65 % v28;
        // pto: %64, %65, %66
        ;
        int64_t v131 = v130 < v27 ? (int64_t) ((uint64_t) v130 + (uint64_t) v28) : v130;
        // pto: %67
        ;
        // pto: %68
        ;
        int64_t v132;
        if (v131 == v18) {
          // pto: %69
          ;
          v132 = (int64_t) ((uint64_t) v34 - (uint64_t) v70);
        } else {
          v132 = v71;
        };
        // pto: %70
        ;
        const int64_t v133 = 1;
        // pto: %70
        ;
        const int64_t v134 = 0;
        // pto: %70
        ;
        int64_t v135 = v65 / v28;
        // pto: %70
        ;
        bool v136 = v65 < v134;
        // pto: %70
        ;
        bool v137 = v28 < v134;
        // pto: %70
        ;
        bool v138 = v136 == v137;
        // pto: %70
        ;
        bool v139 = v65 % v28 != v134 && v136 != v137;
        // pto: %70
        ;
        int64_t v140 = v139 ? v135 - v133 : v135;
        // pto: %72
        ;
        uint64_t v141 = (uint64_t) v132;
        // pto: %71, %72, %73
        ;
        int64_t v142 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v33) + v141) % v22;
        // pto: %74, %75, %76
        ;
        v129 = v142 < v27 ? (int64_t) ((uint64_t) v142 + (uint64_t) v22) : v142;
      } else {
        v129 = v71;
      };
      // pto: %77
      ;
      bool v143 = v129 < v27;
      // pto: %77
      ;
      int64_t v144 = v143 ? v27 : v129;
      // pto: %78
      ;
      int64_t v145 = (int64_t) ((uint64_t) v144 * (uint64_t) v20);
      // pto: %0
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v146 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v21, v20);
      // pto: %0
      ;
      uint64_t v147 = (uint64_t) v14;
      TASSIGN(v146, v147);
      // pto: %80
      ;
      int64_t v148 = v145 < v27 ? v27 : v145;
      // pto: %81
      ;
      __gm__ bfloat16_t* v149 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %81
      ;
      const int64_t v150 = 0;
      // pto: %81
      ;
      const int64_t v151 = 4096;
      // pto: %81
      ;
      pto::Shape<1, 1, 1, 64, 256> v152 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %81
      ;
      pto::Stride<262144, 262144, 262144, 4096, 1> v153 = pto::Stride<262144, 262144, 262144, 4096, 1>();
      // pto: %81
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND> v154 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND>(v149 + (v150 + v94 * v151 + v148), v152, v153);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v146, v154);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      // pto: %1
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v155 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v20);
      // pto: %1
      ;
      uint64_t v156 = (uint64_t) v15;
      TASSIGN(v155, v156);
      // pto: %82
      ;
      const int64_t v157 = 1;
      // pto: %82
      ;
      const int64_t v158 = 0;
      // pto: %82
      ;
      int64_t v159 = v145 / v22;
      // pto: %82
      ;
      bool v160 = v145 < v158;
      // pto: %82
      ;
      bool v161 = v22 < v158;
      // pto: %82
      ;
      bool v162 = v160 == v161;
      // pto: %82
      ;
      bool v163 = v145 % v22 != v158 && v160 != v161;
      // pto: %82
      ;
      int64_t v164 = v163 ? v159 - v157 : v159;
      // pto: %83
      ;
      int64_t v165 = v164 < v27 ? v27 : v164;
      // pto: %86
      ;
      __gm__ bfloat16_t* v166 = PTOAS__GLOBAL_TENSOR_DATA(v56);
      // pto: %86
      ;
      const int64_t v167 = 0;
      // pto: %86
      ;
      const int64_t v168 = 16384;
      // pto: %86
      ;
      const int64_t v169 = 256;
      // pto: %86
      ;
      pto::Shape<1, 16, 2, 16, 16> v170 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %86
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v171 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %86
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v172 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v166 + (v167 + v165 * v168 + v121 * v169), v170, v171);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v155, v172);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %dense_w_inline2919__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v173 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %dense_w_inline2919__tile_t
      ;
      uint64_t v174 = (uint64_t) v13;
      TASSIGN(v173, v174);
      // pto: %dense_x_inline2918__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v21, v20);
      // pto: %dense_x_inline2918__tile_Left
      ;
      uint64_t v176 = (uint64_t) v13;
      TASSIGN(v175, v176);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      TMOV(v175, v92);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %dense_w_inline2919__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %dense_w_inline2919__tile_t_Right
      ;
      uint64_t v178 = (uint64_t) v16;
      TASSIGN(v177, v178);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      TMOV(v177, v173);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %87
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (v70 == v27) {
        pipe_barrier(PIPE_M);
        TMATMUL(v68, v175, v177);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v68, v68, v175, v177);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      // pto: %3
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v179 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %3
      ;
      uint64_t v180 = (uint64_t) v15;
      TASSIGN(v179, v180);
      // pto: %4
      ;
      Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v21, v20);
      // pto: %4
      ;
      uint64_t v182 = (uint64_t) v12;
      TASSIGN(v181, v182);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      TMOV(v181, v146);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      // pto: %5
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %5
      ;
      uint64_t v184 = (uint64_t) v12;
      TASSIGN(v183, v184);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      TMOV(v183, v179);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      // pto: %88
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      if (v70 == v35) {
        pipe_barrier(PIPE_M);
        TMATMUL(v68, v181, v183);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v68, v68, v181, v183);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    };
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %89
    ;
    int64_t v185 = v66 < v27 ? v27 : v66;
    // pto: %90
    ;
    int64_t v186 = v57 < v27 ? v27 : v57;
    // pto: %qr_fp32_inline2839__iter_v28_pview
    ;
    __gm__ float* v187 = PTOAS__GLOBAL_TENSOR_DATA(v44);
    // pto: %qr_fp32_inline2839__iter_v28_pview
    ;
    const int64_t v188 = 0;
    // pto: %qr_fp32_inline2839__iter_v28_pview
    ;
    const int64_t v189 = 1024;
    // pto: %qr_fp32_inline2839__iter_v28_pview
    ;
    pto::Shape<1, 1, 1, 64, 32> v190 = pto::Shape<1, 1, 1, 64, 32>();
    // pto: %qr_fp32_inline2839__iter_v28_pview
    ;
    pto::Stride<65536, 65536, 65536, 1024, 1> v191 = pto::Stride<65536, 65536, 65536, 1024, 1>();
    // pto: %qr_fp32_inline2839__iter_v28_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 64, 32>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND> v192 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 32>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND>(v187 + (v188 + v185 * v189 + v186), v190, v191);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE(v192, v68);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  for (int64_t v193 = v4; v193 < v7; v193 += v22) {
    // pto: %q_acc_inline2921__tile
    ;
    Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v194 = Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %q_acc_inline2921__tile
    ;
    uint64_t v195 = (uint64_t) v12;
    TASSIGN(v194, v195);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    for (int64_t v196 = v27; v196 < v22; v196 += v28) {
      // pto: %91
      ;
      int64_t v197 = (int64_t) ((uint64_t) v6 - (uint64_t) v193);
      // pto: %92
      ;
      int64_t v198 = v197 < v22 ? v197 : v22;
      // pto: %93
      ;
      int64_t v199 = (int64_t) ((uint64_t) v5 + (uint64_t) v193);
      // pto: %94
      ;
      int64_t v200 = (int64_t) ((uint64_t) v196 + (uint64_t) v18);
      // pto: %101
      ;
      int64_t v201 = v6 % v30;
      // pto: %102, %103, %104
      ;
      int64_t v202 = v201 < v27 ? (int64_t) ((uint64_t) v201 + (uint64_t) v30) : v201;
      // pto: %98, %99, %100, %105, %106, %107, %108
      ;
      bool v203 = (v6 >= v26 & v6 <= v29 & v202 == v27) & v65 < v31;
      // pto: %qr_k_order_inline2923__phi_v2
      ;
      int64_t v204;
      if (v203) {
        // pto: %109
        ;
        int64_t v205 = v65 % v28;
        // pto: %110, %111, %112
        ;
        int64_t v206 = v205 < v27 ? (int64_t) ((uint64_t) v205 + (uint64_t) v28) : v205;
        // pto: %113
        ;
        // pto: %qr_k_direction_inline2924__phi_v2
        ;
        int64_t v207;
        if (v206 == v18) {
          // pto: %114
          ;
          v207 = (int64_t) ((uint64_t) v32 - (uint64_t) v196);
        } else {
          v207 = v196;
        };
        // pto: %115
        ;
        const int64_t v208 = 1;
        // pto: %115
        ;
        const int64_t v209 = 0;
        // pto: %115
        ;
        int64_t v210 = v65 / v28;
        // pto: %115
        ;
        bool v211 = v65 < v209;
        // pto: %115
        ;
        bool v212 = v28 < v209;
        // pto: %115
        ;
        bool v213 = v211 == v212;
        // pto: %115
        ;
        bool v214 = v65 % v28 != v209 && v211 != v212;
        // pto: %115
        ;
        int64_t v215 = v214 ? v210 - v208 : v210;
        // pto: %117
        ;
        uint64_t v216 = (uint64_t) v207;
        // pto: %116, %117, %118
        ;
        int64_t v217 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v215 * (uint64_t) v33) + v216) % v22;
        // pto: %119, %120, %121
        ;
        v204 = v217 < v27 ? (int64_t) ((uint64_t) v217 + (uint64_t) v22) : v217;
      } else {
        v204 = v196;
      };
      // pto: %122
      ;
      bool v218 = v204 < v27;
      // pto: %122
      ;
      int64_t v219 = v218 ? v27 : v204;
      // pto: %123
      ;
      int64_t v220 = (int64_t) ((uint64_t) v219 * (uint64_t) v20);
      // pto: %q_x_chunk_bf16_inline2928__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v221 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v198, v20);
      // pto: %q_x_chunk_bf16_inline2928__tile
      ;
      uint64_t v222 = (uint64_t) v13;
      TASSIGN(v221, v222);
      // pto: %124
      ;
      int64_t v223 = v199 < v27 ? v27 : v199;
      // pto: %125
      ;
      int64_t v224 = v220 < v27 ? v27 : v220;
      // pto: %126
      ;
      const int64_t v225 = 0;
      // pto: %126
      ;
      __gm__ bfloat16_t* v226 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %126
      ;
      const int64_t v227 = 1;
      // pto: %126
      ;
      const int64_t v228 = 1;
      // pto: %126
      ;
      const int64_t v229 = 1;
      // pto: %126
      ;
      int64_t v230 = v198 * v19;
      // pto: %126
      ;
      int64_t v231 = v229 * v230;
      // pto: %126
      ;
      pto::Shape<1, 1, 1, -1, 256> v232 = pto::Shape<1, 1, 1, -1, 256>(v227, v228, v229, v198, v20);
      // pto: %126
      ;
      pto::Stride<-1, -1, -1, -1, -1> v233 = pto::Stride<-1, -1, -1, -1, -1>(v228 * v231, v231, v230, v19, v18);
      // pto: %126
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v234 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v226 + (v225 + v223 * v19 + v224 * v18), v232, v233);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      TLOAD(v221, v234);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      // pto: %w_chunk_inline2929__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v235 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v20);
      // pto: %w_chunk_inline2929__tile
      ;
      uint64_t v236 = (uint64_t) v12;
      TASSIGN(v235, v236);
      // pto: %127
      ;
      const int64_t v237 = 1;
      // pto: %127
      ;
      const int64_t v238 = 0;
      // pto: %127
      ;
      int64_t v239 = v220 / v22;
      // pto: %127
      ;
      bool v240 = v220 < v238;
      // pto: %127
      ;
      bool v241 = v22 < v238;
      // pto: %127
      ;
      bool v242 = v240 == v241;
      // pto: %127
      ;
      bool v243 = v220 % v22 != v238 && v240 != v241;
      // pto: %127
      ;
      int64_t v244 = v243 ? v239 - v237 : v239;
      // pto: %128
      ;
      int64_t v245 = v244 < v27 ? v27 : v244;
      // pto: %129
      ;
      const int64_t v246 = 1;
      // pto: %129
      ;
      const int64_t v247 = 0;
      // pto: %129
      ;
      int64_t v248 = v57 / v22;
      // pto: %129
      ;
      bool v249 = v57 < v247;
      // pto: %129
      ;
      bool v250 = v22 < v247;
      // pto: %129
      ;
      bool v251 = v249 == v250;
      // pto: %129
      ;
      bool v252 = v57 % v22 != v247 && v249 != v250;
      // pto: %129
      ;
      int64_t v253 = v252 ? v248 - v246 : v248;
      // pto: %130
      ;
      int64_t v254 = v253 < v27 ? v27 : v253;
      // pto: %131
      ;
      __gm__ bfloat16_t* v255 = PTOAS__GLOBAL_TENSOR_DATA(v56);
      // pto: %131
      ;
      const int64_t v256 = 0;
      // pto: %131
      ;
      const int64_t v257 = 16384;
      // pto: %131
      ;
      const int64_t v258 = 256;
      // pto: %131
      ;
      pto::Shape<1, 16, 2, 16, 16> v259 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %131
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v260 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %131
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v261 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v255 + (v256 + v245 * v257 + v254 * v258), v259, v260);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      TLOAD(v235, v261);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      // pto: %143
      ;
      int64_t v262;
      if (v203) {
        // pto: %145
        ;
        int64_t v263 = v65 % v28;
        // pto: %146, %147, %148
        ;
        int64_t v264 = v263 < v27 ? (int64_t) ((uint64_t) v263 + (uint64_t) v28) : v263;
        // pto: %149
        ;
        // pto: %150
        ;
        int64_t v265;
        if (v264 == v18) {
          // pto: %151
          ;
          v265 = (int64_t) ((uint64_t) v34 - (uint64_t) v196);
        } else {
          v265 = v200;
        };
        // pto: %152
        ;
        const int64_t v266 = 1;
        // pto: %152
        ;
        const int64_t v267 = 0;
        // pto: %152
        ;
        int64_t v268 = v65 / v28;
        // pto: %152
        ;
        bool v269 = v65 < v267;
        // pto: %152
        ;
        bool v270 = v28 < v267;
        // pto: %152
        ;
        bool v271 = v269 == v270;
        // pto: %152
        ;
        bool v272 = v65 % v28 != v267 && v269 != v270;
        // pto: %152
        ;
        int64_t v273 = v272 ? v268 - v266 : v268;
        // pto: %154
        ;
        uint64_t v274 = (uint64_t) v265;
        // pto: %153, %154, %155
        ;
        int64_t v275 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v273 * (uint64_t) v33) + v274) % v22;
        // pto: %156, %157, %158
        ;
        v262 = v275 < v27 ? (int64_t) ((uint64_t) v275 + (uint64_t) v22) : v275;
      } else {
        v262 = v200;
      };
      // pto: %159
      ;
      bool v276 = v262 < v27;
      // pto: %159
      ;
      int64_t v277 = v276 ? v27 : v262;
      // pto: %160
      ;
      int64_t v278 = (int64_t) ((uint64_t) v277 * (uint64_t) v20);
      // pto: %7
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v279 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v198, v20);
      // pto: %7
      ;
      uint64_t v280 = (uint64_t) v15;
      TASSIGN(v279, v280);
      // pto: %162
      ;
      int64_t v281 = v278 < v27 ? v27 : v278;
      // pto: %163
      ;
      const int64_t v282 = 0;
      // pto: %163
      ;
      __gm__ bfloat16_t* v283 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %163
      ;
      const int64_t v284 = 1;
      // pto: %163
      ;
      const int64_t v285 = 1;
      // pto: %163
      ;
      const int64_t v286 = 1;
      // pto: %163
      ;
      int64_t v287 = v198 * v19;
      // pto: %163
      ;
      int64_t v288 = v286 * v287;
      // pto: %163
      ;
      pto::Shape<1, 1, 1, -1, 256> v289 = pto::Shape<1, 1, 1, -1, 256>(v284, v285, v286, v198, v20);
      // pto: %163
      ;
      pto::Stride<-1, -1, -1, -1, -1> v290 = pto::Stride<-1, -1, -1, -1, -1>(v285 * v288, v288, v287, v19, v18);
      // pto: %163
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v291 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v283 + (v282 + v223 * v19 + v281 * v18), v289, v290);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      TLOAD(v279, v291);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
      // pto: %8
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v292 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v20);
      // pto: %8
      ;
      uint64_t v293 = (uint64_t) v14;
      TASSIGN(v292, v293);
      // pto: %164
      ;
      const int64_t v294 = 1;
      // pto: %164
      ;
      const int64_t v295 = 0;
      // pto: %164
      ;
      int64_t v296 = v278 / v22;
      // pto: %164
      ;
      bool v297 = v278 < v295;
      // pto: %164
      ;
      bool v298 = v22 < v295;
      // pto: %164
      ;
      bool v299 = v297 == v298;
      // pto: %164
      ;
      bool v300 = v278 % v22 != v295 && v297 != v298;
      // pto: %164
      ;
      int64_t v301 = v300 ? v296 - v294 : v296;
      // pto: %165
      ;
      int64_t v302 = v301 < v27 ? v27 : v301;
      // pto: %168
      ;
      __gm__ bfloat16_t* v303 = PTOAS__GLOBAL_TENSOR_DATA(v56);
      // pto: %168
      ;
      const int64_t v304 = 0;
      // pto: %168
      ;
      const int64_t v305 = 16384;
      // pto: %168
      ;
      const int64_t v306 = 256;
      // pto: %168
      ;
      pto::Shape<1, 16, 2, 16, 16> v307 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %168
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v308 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %168
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v309 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v303 + (v304 + v302 * v305 + v254 * v306), v307, v308);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v292, v309);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
      // pto: %w_chunk_inline2929__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v310 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %w_chunk_inline2929__tile_t
      ;
      uint64_t v311 = (uint64_t) v12;
      TASSIGN(v310, v311);
      // pto: %q_x_chunk_bf16_inline2928__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v312 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v198, v20);
      // pto: %q_x_chunk_bf16_inline2928__tile_Left
      ;
      uint64_t v313 = (uint64_t) v13;
      TASSIGN(v312, v313);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      TMOV(v312, v221);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      // pto: %w_chunk_inline2929__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v314 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %w_chunk_inline2929__tile_t_Right
      ;
      uint64_t v315 = (uint64_t) v16;
      TASSIGN(v314, v315);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      TMOV(v314, v310);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      // pto: %169
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      if (v196 == v27) {
        pipe_barrier(PIPE_M);
        TMATMUL(v194, v312, v314);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v194, v194, v312, v314);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      // pto: %10
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v316 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %10
      ;
      uint64_t v317 = (uint64_t) v14;
      TASSIGN(v316, v317);
      // pto: %11
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v318 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v198, v20);
      // pto: %11
      ;
      uint64_t v319 = (uint64_t) v12;
      TASSIGN(v318, v319);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      TMOV(v318, v279);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      // pto: %12
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v320 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %12
      ;
      uint64_t v321 = (uint64_t) v12;
      TASSIGN(v320, v321);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
      TMOV(v320, v316);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %170
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      if (v196 == v35) {
        pipe_barrier(PIPE_M);
        TMATMUL(v194, v318, v320);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v194, v194, v318, v320);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    };
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
    // pto: %172
    ;
    int64_t v322 = v193 < v27 ? v27 : v193;
    // pto: %173
    ;
    int64_t v323 = v57 < v27 ? v27 : v57;
    // pto: %qr_fp32_inline2839__iter_v31_pview
    ;
    __gm__ float* v324 = PTOAS__GLOBAL_TENSOR_DATA(v44);
    // pto: %qr_fp32_inline2839__iter_v31_pview
    ;
    const int64_t v325 = 0;
    // pto: %qr_fp32_inline2839__iter_v31_pview
    ;
    const int64_t v326 = 1024;
    // pto: %qr_fp32_inline2839__iter_v31_pview
    ;
    pto::Shape<1, 1, 1, 16, 32> v327 = pto::Shape<1, 1, 1, 16, 32>();
    // pto: %qr_fp32_inline2839__iter_v31_pview
    ;
    pto::Stride<16384, 16384, 16384, 1024, 1> v328 = pto::Stride<16384, 16384, 16384, 1024, 1>();
    // pto: %qr_fp32_inline2839__iter_v31_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND> v329 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND>(v324 + (v325 + v322 * v326 + v323), v327, v328);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
    pipe_barrier(PIPE_FIX);
    TSTORE(v329, v194);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}