#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void indexer_score_topk_leaf_aic(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ float* v3, __gm__ int32_t* v4, __gm__ int8_t* v5, __gm__ float* v6, __gm__ float* v7, __gm__ int32_t* v8, __gm__ int8_t* v9, __gm__ int8_t* v10, __gm__ int8_t* v11, __gm__ float* v12, __gm__ float* v13, int64_t v14, int64_t v15, int64_t v16, int64_t v17, int64_t v18, int64_t v19, int64_t v20, int64_t v21, int32_t v22, int32_t v23) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int64_t v24 = 32;
  const int32_t v25 = 0;
  // pto: %c0_i64
  const int64_t v26 = 0;
  // pto: %c8192_i64
  const int64_t v27 = 8192;
  // pto: %c4096_i64
  const int64_t v28 = 4096;
  // pto: %c24576_i64
  const int64_t v29 = 24576;
  // pto: %c57344_i64
  const int64_t v30 = 57344;
  // pto: %c12288_i64
  const int64_t v31 = 12288;
  // pto: %c1_index
  const int64_t v32 = 1;
  // pto: %c8192_index
  const int64_t v33 = 8192;
  // pto: %c27648_index
  const int64_t v34 = 27648;
  // pto: %c128_index
  const int64_t v35 = 128;
  // pto: %c64_index
  const int64_t v36 = 64;
  // pto: %c0_index
  const int64_t v37 = 0;
  // pto: %c4_index
  const int64_t v38 = 4;
  // pto: %c262144_index
  const int64_t v39 = 262144;
  // pto: %c8191_index
  const int64_t v40 = 8191;
  // pto: %c24_index
  const int64_t v41 = 24;
  // pto: %c1_i64
  const int64_t v42 = 1;
  // pto: %c4_i64
  const int64_t v43 = 4;
  // pto: %c383_index
  const int64_t v44 = 383;
  // pto: %c384_index
  const int64_t v45 = 384;
  // pto: %c192_index
  const int64_t v46 = 192;
  // pto: %c4096_index
  const int64_t v47 = 4096;
  // pto: %c191_index
  const int64_t v48 = 191;
  // pto: %c6_index
  const int64_t v49 = 6;
  // pto: %c32_index
  const int64_t v50 = 32;
  // pto: %c2_index
  const int64_t v51 = 2;
  // pto: %qr_hadamard_i8_inline3547__rv_v2_view
  const int64_t v52 = 1;
  // pto: %qr_hadamard_i8_inline3547__rv_v2_view
  const int64_t v53 = 1;
  // pto: %qr_hadamard_i8_inline3547__rv_v2_view
  const int64_t v54 = 1;
  // pto: %qr_hadamard_i8_inline3547__rv_v2_view
  int64_t v55 = v34 * v35;
  // pto: %qr_hadamard_i8_inline3547__rv_v2_view
  int64_t v56 = v54 * v55;
  // pto: %qr_hadamard_i8_inline3547__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v57 = pto::Shape<1, 1, 1, -1, -1>(v52, v53, v54, v34, v35);
  // pto: %qr_hadamard_i8_inline3547__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v58 = pto::Stride<-1, -1, -1, -1, -1>(v53 * v56, v56, v55, v35, v32);
  // pto: %qr_hadamard_i8_inline3547__rv_v2_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v59 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v57, v58);
  // pto: %idx_kv_cache_inline3675__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %idx_kv_cache_inline3675__ssa_v0_view
  const int64_t v61 = 1;
  // pto: %idx_kv_cache_inline3675__ssa_v0_view
  const int64_t v62 = 1;
  // pto: %idx_kv_cache_inline3675__ssa_v0_view
  int64_t v63 = (int64_t) v18;
  // pto: %idx_kv_cache_inline3675__ssa_v0_view
  int64_t v64 = v63 * v35;
  // pto: %idx_kv_cache_inline3675__ssa_v0_view
  int64_t v65 = v62 * v64;
  // pto: %idx_kv_cache_inline3675__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v66 = pto::Shape<1, 1, 1, -1, -1>(v60, v61, v62, v63, v35);
  // pto: %idx_kv_cache_inline3675__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v67 = pto::Stride<-1, -1, -1, -1, -1>(v61 * v65, v65, v64, v35, v32);
  // pto: %idx_kv_cache_inline3675__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v68 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v66, v67);
  // pto: %idx_kv_cache_shift64_inline3676__ssa_v0_view
  const int64_t v69 = 1;
  // pto: %idx_kv_cache_shift64_inline3676__ssa_v0_view
  const int64_t v70 = 1;
  // pto: %idx_kv_cache_shift64_inline3676__ssa_v0_view
  const int64_t v71 = 1;
  // pto: %idx_kv_cache_shift64_inline3676__ssa_v0_view
  int64_t v72 = (int64_t) v19;
  // pto: %idx_kv_cache_shift64_inline3676__ssa_v0_view
  int64_t v73 = v72 * v35;
  // pto: %idx_kv_cache_shift64_inline3676__ssa_v0_view
  int64_t v74 = v71 * v73;
  // pto: %idx_kv_cache_shift64_inline3676__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v75 = pto::Shape<1, 1, 1, -1, -1>(v69, v70, v71, v72, v35);
  // pto: %idx_kv_cache_shift64_inline3676__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v76 = pto::Stride<-1, -1, -1, -1, -1>(v70 * v74, v74, v73, v35, v32);
  // pto: %idx_kv_cache_shift64_inline3676__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v77 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v10, v75, v76);
  // pto: %kv_i8_inline3715__phi_v5
  Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v78 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
  // pto: %kv_i8_inline3715__phi_v5
  uint64_t v79 = (uint64_t) v27;
  TASSIGN(v78, v79);
  // pto: %kv_i8_inline3715__phi_v10
  Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v80 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
  // pto: %kv_i8_inline3715__phi_v10
  uint64_t v81 = (uint64_t) v27;
  TASSIGN(v80, v81);
  // pto: %163
  Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v82 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
  // pto: %163
  uint64_t v83 = (uint64_t) v30;
  TASSIGN(v82, v83);
  // pto: %195
  Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v84 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
  // pto: %195
  uint64_t v85 = (uint64_t) v30;
  TASSIGN(v84, v85);
  // pto: %237
  Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v86 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
  // pto: %237
  uint64_t v87 = (uint64_t) v27;
  TASSIGN(v86, v87);
  // pto: %269
  Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v88 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
  // pto: %269
  uint64_t v89 = (uint64_t) v27;
  TASSIGN(v88, v89);
  const int32_t v90 = 0;
  auto v91 = TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>(v13, v25, v90);
  // pto: %worker_inline3688__ssa_v0
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  // pto: %max_cache_len_inline3690__rv_v2
  int64_t v92;
  v92 = v37;
  for (int64_t v93 = v37; v93 < v16; v93 += v32) {
    // pto: %t__tile
    ;
    int32_t v94 = (v2)[v93];
    // pto: %33
    ;
    int64_t v95 = (int64_t) v94;
    // pto: %34
    ;
    const int64_t v96 = 1;
    // pto: %34
    ;
    const int64_t v97 = 0;
    // pto: %34
    ;
    int64_t v98 = v95 / v38;
    // pto: %34
    ;
    bool v99 = v95 < v97;
    // pto: %34
    ;
    bool v100 = v38 < v97;
    // pto: %34
    ;
    bool v101 = v99 == v100;
    // pto: %34
    ;
    bool v102 = v95 % v38 != v97 && v99 != v100;
    // pto: %34
    ;
    int64_t v103 = v102 ? v98 - v96 : v98;
    // pto: %35
    ;
    bool v104 = v92 < v103;
    // pto: %35
    ;
    int64_t v105 = v104 ? v103 : v92;
    v92 = v105;
  }
  // pto: %36
  bool v106 = v92 < v39;
  // pto: %36
  int64_t v107 = v106 ? v92 : v39;
  // pto: %37
  int64_t v108 = (int64_t) ((uint64_t) v107 + (uint64_t) v40);
  // pto: %38
  const int64_t v109 = 1;
  // pto: %38
  const int64_t v110 = 0;
  // pto: %38
  int64_t v111 = v108 / v33;
  // pto: %38
  bool v112 = v108 < v110;
  // pto: %38
  bool v113 = v33 < v110;
  // pto: %38
  bool v114 = v112 == v113;
  // pto: %38
  bool v115 = v108 % v33 != v110 && v112 != v113;
  // pto: %38
  int64_t v116 = v115 ? v111 - v109 : v111;
  // pto: %39
  int64_t v117 = v116 < v32 ? v32 : v116;
  // pto: %40, %41
  int64_t v118 = (int64_t) (v117 == v32);
  // pto: %42
  for (int64_t v119 = (int64_t) v22; v119 < ((int64_t) ((uint64_t) v15 * (uint64_t) v117)); v119 += v41) {
    // pto: %43
    ;
    const int64_t v120 = 1;
    // pto: %43
    ;
    const int64_t v121 = 0;
    // pto: %43
    ;
    int64_t v122 = v119 / v117;
    // pto: %43
    ;
    bool v123 = v119 < v121;
    // pto: %43
    ;
    bool v124 = v117 < v121;
    // pto: %43
    ;
    bool v125 = v123 == v124;
    // pto: %43
    ;
    bool v126 = v119 % v117 != v121 && v123 != v124;
    // pto: %43
    ;
    int64_t v127 = v126 ? v122 - v120 : v122;
    // pto: %44
    ;
    int64_t v128 = v119 % v117;
    // pto: %45, %46, %47
    ;
    bool v129 = v128 < v37 ^ v117 < v37;
    // pto: %48, %49, %50, %51
    ;
    int64_t v130 = v128 != v37 & v129 ? (int64_t) ((uint64_t) v128 + (uint64_t) v117) : v128;
    // pto: %52
    ;
    int32_t v131 = (v4)[v127];
    // pto: %53
    ;
    int64_t v132 = (int64_t) v131;
    // pto: %position_inline3699__tile
    ;
    int64_t v133 = (v1)[v127];
    // pto: %55
    ;
    int64_t v134 = v132 < v37 ? v37 : v132;
    // pto: %54
    ;
    int32_t v135 = (v2)[v134];
    // pto: %56
    ;
    int64_t v136 = (int64_t) v135;
    // pto: %57
    ;
    const int64_t v137 = 1;
    // pto: %57
    ;
    const int64_t v138 = 0;
    // pto: %57
    ;
    int64_t v139 = v136 / v38;
    // pto: %57
    ;
    bool v140 = v136 < v138;
    // pto: %57
    ;
    bool v141 = v38 < v138;
    // pto: %57
    ;
    bool v142 = v140 == v141;
    // pto: %57
    ;
    bool v143 = v136 % v38 != v138 && v140 != v141;
    // pto: %57
    ;
    int64_t v144 = v143 ? v139 - v137 : v139;
    // pto: %58, %cache_len_inline3700__phi_v2
    ;
    int64_t v145 = v132 < v37 ? v37 : v144;
    // pto: %59
    ;
    int64_t v146 = (int64_t) ((uint64_t) v133 + (uint64_t) v42);
    // pto: %60
    ;
    const int64_t v147 = 1;
    // pto: %60
    ;
    const int64_t v148 = 0;
    // pto: %60
    ;
    int64_t v149 = v146 / v43;
    // pto: %60
    ;
    bool v150 = v146 < v148;
    // pto: %60
    ;
    bool v151 = v43 < v148;
    // pto: %60
    ;
    bool v152 = v150 == v151;
    // pto: %60
    ;
    bool v153 = v146 % v43 != v148 && v150 != v151;
    // pto: %60
    ;
    int64_t v154 = v153 ? v149 - v147 : v149;
    // pto: %62
    ;
    int64_t v155 = v145 < v154 ? v145 : v154;
    // pto: %63
    ;
    int64_t v156 = v155 < v39 ? v155 : v39;
    // pto: %64
    ;
    int64_t v157 = v156 < v37 ? v37 : v156;
    // pto: %65
    ;
    int64_t v158 = (int64_t) ((uint64_t) v130 * (uint64_t) v33);
    // pto: %66
    ;
    if (v158 < v157) {
      // pto: %67
      ;
      int64_t v159 = (int64_t) ((uint64_t) v157 - (uint64_t) v158);
      // pto: %68
      ;
      int64_t v160 = v159 < v33 ? v159 : v33;
      // pto: %69
      ;
      int64_t v161 = (int64_t) ((uint64_t) v160 + (uint64_t) v44);
      // pto: %70
      ;
      const int64_t v162 = 1;
      // pto: %70
      ;
      const int64_t v163 = 0;
      // pto: %70
      ;
      int64_t v164 = v161 / v45;
      // pto: %70
      ;
      bool v165 = v161 < v163;
      // pto: %70
      ;
      bool v166 = v45 < v163;
      // pto: %70
      ;
      bool v167 = v165 == v166;
      // pto: %70
      ;
      bool v168 = v161 % v45 != v163 && v165 != v166;
      // pto: %70
      ;
      int64_t v169 = v168 ? v164 - v162 : v164;
      // pto: %71
      ;
      int64_t v170 = (int64_t) ((uint64_t) v169 * (uint64_t) v46);
      // pto: %72
      ;
      int64_t v171 = v170 < v47 ? v170 : v47;
      // pto: %73, %76, %74, %75
      ;
      int64_t v172 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v118 * (uint64_t) v46) + (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v32 - (uint64_t) v118) * (uint64_t) v171));
      // pto: %77
      ;
      int64_t v173 = (int64_t) ((uint64_t) v127 * (uint64_t) v36);
      // pto: %query_vector_inline3708__tile
      ;
      Tile<TileType::Mat, int8_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v174 = Tile<TileType::Mat, int8_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v35);
      // pto: %query_vector_inline3708__tile
      ;
      uint64_t v175 = (uint64_t) v26;
      TASSIGN(v174, v175);
      // pto: %78
      ;
      int64_t v176 = v173 < v37 ? v37 : v173;
      // pto: %qr_hadamard_i8_inline3547__rv_v2_pview
      ;
      __gm__ int8_t* v177 = PTOAS__GLOBAL_TENSOR_DATA(v59);
      // pto: %qr_hadamard_i8_inline3547__rv_v2_pview
      ;
      const int64_t v178 = 0;
      // pto: %qr_hadamard_i8_inline3547__rv_v2_pview
      ;
      const int64_t v179 = 128;
      // pto: %qr_hadamard_i8_inline3547__rv_v2_pview
      ;
      pto::Shape<1, 1, 1, 64, 128> v180 = pto::Shape<1, 1, 1, 64, 128>();
      // pto: %qr_hadamard_i8_inline3547__rv_v2_pview
      ;
      pto::Stride<8192, 8192, 8192, 128, 1> v181 = pto::Stride<8192, 8192, 8192, 128, 1>();
      // pto: %qr_hadamard_i8_inline3547__rv_v2_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND> v182 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND>(v177 + (v178 + v176 * v179), v180, v181);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v174, v182);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %79
      ;
      int64_t v183 = (int64_t) ((uint64_t) v171 + (uint64_t) v48);
      // pto: %80
      ;
      const int64_t v184 = 1;
      // pto: %80
      ;
      const int64_t v185 = 0;
      // pto: %80
      ;
      int64_t v186 = v183 / v45;
      // pto: %80
      ;
      bool v187 = v183 < v185;
      // pto: %80
      ;
      bool v188 = v45 < v185;
      // pto: %80
      ;
      bool v189 = v187 == v188;
      // pto: %80
      ;
      bool v190 = v183 % v45 != v185 && v187 != v188;
      // pto: %80
      ;
      int64_t v191 = v190 ? v186 - v184 : v186;
      // pto: %81
      ;
      int64_t v192 = (int64_t) ((uint64_t) v191 * (uint64_t) v45);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
      for (int64_t v193 = v37; v193 < v192; v193 += v45) {
        // pto: %82
        ;
        int64_t v194 = (int64_t) ((uint64_t) v118 + (uint64_t) v32);
        // pto: %83
        ;
        int64_t v195 = (int64_t) ((uint64_t) v193 * (uint64_t) v194);
        // pto: %84, %86
        ;
        int64_t v196 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v193 + (uint64_t) v46) * (uint64_t) v194);
        // pto: %kv_i8_inline3715__tile
        ;
        Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v197 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
        // pto: %kv_i8_inline3715__tile
        ;
        uint64_t v198 = (uint64_t) v27;
        TASSIGN(v197, v198);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        for (int64_t v199 = v37; v199 < v49; v199 += v32) {
          // pto: %88
          ;
          int64_t v200 = (int64_t) ((uint64_t) v199 * (uint64_t) v50);
          // pto: %87, %89
          ;
          int64_t v201 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v158 + (uint64_t) v195) + (uint64_t) v200);
          // pto: %90
          ;
          const int64_t v202 = 1;
          // pto: %90
          ;
          const int64_t v203 = 0;
          // pto: %90
          ;
          int64_t v204 = v201 / v50;
          // pto: %90
          ;
          bool v205 = v201 < v203;
          // pto: %90
          ;
          bool v206 = v50 < v203;
          // pto: %90
          ;
          bool v207 = v205 == v206;
          // pto: %90
          ;
          bool v208 = v201 % v50 != v203 && v205 != v206;
          // pto: %90
          ;
          int64_t v209 = v208 ? v204 - v202 : v204;
          // pto: %91
          ;
          int64_t v210 = (int64_t) ((uint64_t) v145 - (uint64_t) v32);
          // pto: %92
          ;
          const int64_t v211 = 1;
          // pto: %92
          ;
          const int64_t v212 = 0;
          // pto: %92
          ;
          int64_t v213 = v210 / v50;
          // pto: %92
          ;
          bool v214 = v210 < v212;
          // pto: %92
          ;
          bool v215 = v50 < v212;
          // pto: %92
          ;
          bool v216 = v214 == v215;
          // pto: %92
          ;
          bool v217 = v210 % v50 != v212 && v214 != v215;
          // pto: %92
          ;
          int64_t v218 = v217 ? v213 - v211 : v213;
          // pto: %93
          ;
          int64_t v219 = v218 < v37 ? v37 : v218;
          // pto: %94
          ;
          int64_t v220 = v209 < v219 ? v209 : v219;
          // pto: %flat_offset_mul, %flat_offset, %95
          ;
          int32_t v221 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v132 * (uint64_t) v17) + (uint64_t) v220)];
          // pto: %96
          ;
          int64_t v222 = (int64_t) v221;
          // pto: %97
          ;
          int64_t v223 = v222 < v37 ? v37 : v222;
          // pto: %98
          ;
          int64_t v224 = (int64_t) ((uint64_t) v223 * (uint64_t) v14);
          // pto: %99
          ;
          int64_t v225 = v224 % v35;
          // pto: %100, %101, %102
          ;
          int64_t v226 = v225 < v37 ? (int64_t) ((uint64_t) v225 + (uint64_t) v35) : v225;
          // pto: %103
          ;
          if (v226 == v37) {
            // pto: %gather_row_view
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v227;
            // pto: %gather_row_view
            ;
            uint64_t v228 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v200 * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v227, v228);
            // pto: %105
            ;
            const int64_t v229 = 1;
            // pto: %105
            ;
            const int64_t v230 = 0;
            // pto: %105
            ;
            int64_t v231 = v224 / v35;
            // pto: %105
            ;
            bool v232 = v224 < v230;
            // pto: %105
            ;
            bool v233 = v35 < v230;
            // pto: %105
            ;
            bool v234 = v232 == v233;
            // pto: %105
            ;
            bool v235 = v224 % v35 != v230 && v232 != v233;
            // pto: %105
            ;
            int64_t v236 = v235 ? v231 - v229 : v231;
            // pto: %106
            ;
            int64_t v237 = v236 < v37 ? v37 : v236;
            // pto: %idx_kv_cache_inline3675__ssa_v0_pview
            ;
            __gm__ int8_t* v238 = PTOAS__GLOBAL_TENSOR_DATA(v68);
            // pto: %idx_kv_cache_inline3675__ssa_v0_pview
            ;
            const int64_t v239 = 0;
            // pto: %idx_kv_cache_inline3675__ssa_v0_pview
            ;
            const int64_t v240 = 128;
            // pto: %idx_kv_cache_inline3675__ssa_v0_pview
            ;
            pto::Shape<1, 1, 1, 32, 128> v241 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %idx_kv_cache_inline3675__ssa_v0_pview
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v242 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %idx_kv_cache_inline3675__ssa_v0_pview
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v243 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v238 + (v239 + v237 * v240), v241, v242);
            TLOAD(v227, v243);
          } else {
            // pto: %108
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v244;
            // pto: %108
            ;
            uint64_t v245 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v200 * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v244, v245);
            // pto: %109
            ;
            const int64_t v246 = 1;
            // pto: %109
            ;
            const int64_t v247 = 0;
            // pto: %109
            ;
            int64_t v248 = v224 / v35;
            // pto: %109
            ;
            bool v249 = v224 < v247;
            // pto: %109
            ;
            bool v250 = v35 < v247;
            // pto: %109
            ;
            bool v251 = v249 == v250;
            // pto: %109
            ;
            bool v252 = v224 % v35 != v247 && v249 != v250;
            // pto: %109
            ;
            int64_t v253 = v252 ? v248 - v246 : v248;
            // pto: %110
            ;
            int64_t v254 = v253 < v37 ? v37 : v253;
            // pto: %idx_kv_cache_shift64_inline3676__ssa_v0_pview
            ;
            __gm__ int8_t* v255 = PTOAS__GLOBAL_TENSOR_DATA(v77);
            // pto: %idx_kv_cache_shift64_inline3676__ssa_v0_pview
            ;
            const int64_t v256 = 0;
            // pto: %idx_kv_cache_shift64_inline3676__ssa_v0_pview
            ;
            const int64_t v257 = 128;
            // pto: %idx_kv_cache_shift64_inline3676__ssa_v0_pview
            ;
            pto::Shape<1, 1, 1, 32, 128> v258 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %idx_kv_cache_shift64_inline3676__ssa_v0_pview
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v259 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %idx_kv_cache_shift64_inline3676__ssa_v0_pview
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v260 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v255 + (v256 + v254 * v257), v258, v259);
            TLOAD(v244, v260);
          };
        };
        for (int64_t v261 = v37; v261 < v49; v261 += v32) {
          // pto: %113
          ;
          int64_t v262 = (int64_t) ((uint64_t) v261 * (uint64_t) v50);
          // pto: %111, %112, %114
          ;
          int64_t v263 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v158 + (uint64_t) v195) + (uint64_t) v172) + (uint64_t) v262);
          // pto: %115
          ;
          const int64_t v264 = 1;
          // pto: %115
          ;
          const int64_t v265 = 0;
          // pto: %115
          ;
          int64_t v266 = v263 / v50;
          // pto: %115
          ;
          bool v267 = v263 < v265;
          // pto: %115
          ;
          bool v268 = v50 < v265;
          // pto: %115
          ;
          bool v269 = v267 == v268;
          // pto: %115
          ;
          bool v270 = v263 % v50 != v265 && v267 != v268;
          // pto: %115
          ;
          int64_t v271 = v270 ? v266 - v264 : v266;
          // pto: %116
          ;
          int64_t v272 = (int64_t) ((uint64_t) v145 - (uint64_t) v32);
          // pto: %117
          ;
          const int64_t v273 = 1;
          // pto: %117
          ;
          const int64_t v274 = 0;
          // pto: %117
          ;
          int64_t v275 = v272 / v50;
          // pto: %117
          ;
          bool v276 = v272 < v274;
          // pto: %117
          ;
          bool v277 = v50 < v274;
          // pto: %117
          ;
          bool v278 = v276 == v277;
          // pto: %117
          ;
          bool v279 = v272 % v50 != v274 && v276 != v277;
          // pto: %117
          ;
          int64_t v280 = v279 ? v275 - v273 : v275;
          // pto: %118
          ;
          int64_t v281 = v280 < v37 ? v37 : v280;
          // pto: %119
          ;
          int64_t v282 = v271 < v281 ? v271 : v281;
          // pto: %121, %122, %120
          ;
          int32_t v283 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v132 * (uint64_t) v17) + (uint64_t) v282)];
          // pto: %123
          ;
          int64_t v284 = (int64_t) v283;
          // pto: %124
          ;
          int64_t v285 = v284 < v37 ? v37 : v284;
          // pto: %125
          ;
          int64_t v286 = (int64_t) ((uint64_t) v285 * (uint64_t) v14);
          // pto: %126
          ;
          int64_t v287 = v286 % v35;
          // pto: %127, %128, %129
          ;
          int64_t v288 = v287 < v37 ? (int64_t) ((uint64_t) v287 + (uint64_t) v35) : v287;
          // pto: %130
          ;
          if (v288 == v37) {
            // pto: %133
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v289;
            // pto: %132, %133
            ;
            uint64_t v290 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v262 + (uint64_t) v46) * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v289, v290);
            // pto: %134
            ;
            const int64_t v291 = 1;
            // pto: %134
            ;
            const int64_t v292 = 0;
            // pto: %134
            ;
            int64_t v293 = v286 / v35;
            // pto: %134
            ;
            bool v294 = v286 < v292;
            // pto: %134
            ;
            bool v295 = v35 < v292;
            // pto: %134
            ;
            bool v296 = v294 == v295;
            // pto: %134
            ;
            bool v297 = v286 % v35 != v292 && v294 != v295;
            // pto: %134
            ;
            int64_t v298 = v297 ? v293 - v291 : v293;
            // pto: %135
            ;
            int64_t v299 = v298 < v37 ? v37 : v298;
            // pto: %136
            ;
            __gm__ int8_t* v300 = PTOAS__GLOBAL_TENSOR_DATA(v68);
            // pto: %136
            ;
            const int64_t v301 = 0;
            // pto: %136
            ;
            const int64_t v302 = 128;
            // pto: %136
            ;
            pto::Shape<1, 1, 1, 32, 128> v303 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %136
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v304 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %136
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v305 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v300 + (v301 + v299 * v302), v303, v304);
            TLOAD(v289, v305);
          } else {
            // pto: %139
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v306;
            // pto: %138, %139
            ;
            uint64_t v307 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v262 + (uint64_t) v46) * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v306, v307);
            // pto: %140
            ;
            const int64_t v308 = 1;
            // pto: %140
            ;
            const int64_t v309 = 0;
            // pto: %140
            ;
            int64_t v310 = v286 / v35;
            // pto: %140
            ;
            bool v311 = v286 < v309;
            // pto: %140
            ;
            bool v312 = v35 < v309;
            // pto: %140
            ;
            bool v313 = v311 == v312;
            // pto: %140
            ;
            bool v314 = v286 % v35 != v309 && v311 != v312;
            // pto: %140
            ;
            int64_t v315 = v314 ? v310 - v308 : v310;
            // pto: %141
            ;
            int64_t v316 = v315 < v37 ? v37 : v315;
            // pto: %142
            ;
            __gm__ int8_t* v317 = PTOAS__GLOBAL_TENSOR_DATA(v77);
            // pto: %142
            ;
            const int64_t v318 = 0;
            // pto: %142
            ;
            const int64_t v319 = 128;
            // pto: %142
            ;
            pto::Shape<1, 1, 1, 32, 128> v320 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %142
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v321 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %142
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v322 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v317 + (v318 + v316 * v319), v320, v321);
            TLOAD(v306, v322);
          };
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %kv_i8_inline3715__rv_v7_t
        ;
        Tile<TileType::Mat, int8_t, 128, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v323 = Tile<TileType::Mat, int8_t, 128, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v35, v45);
        // pto: %kv_i8_inline3715__rv_v7_t
        ;
        uint64_t v324 = (uint64_t) v27;
        TASSIGN(v323, v324);
        // pto: %score_i32_inline3722__tile_l0_init
        ;
        Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v325 = Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %score_i32_inline3722__tile_l0_init
        ;
        uint64_t v326 = (uint64_t) v26;
        TASSIGN(v325, v326);
        // pto: %score_i32_inline3722__tile_l0_a
        ;
        Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v327 = Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
        // pto: %score_i32_inline3722__tile_l0_a
        ;
        uint64_t v328 = (uint64_t) v26;
        TASSIGN(v327, v328);
        uint16_t v329 = static_cast<uint16_t>(v37);
        uint16_t v330 = static_cast<uint16_t>(v37);
        TEXTRACT(v327, v174, v329, v330);
        // pto: %score_i32_inline3722__tile_l0_b
        ;
        Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v331 = Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %score_i32_inline3722__tile_l0_b
        ;
        uint64_t v332 = (uint64_t) v26;
        TASSIGN(v331, v332);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v333 = static_cast<uint16_t>(v37);
        uint16_t v334 = static_cast<uint16_t>(v37);
        TEXTRACT(v331, v323, v333, v334);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %4
        ;
        Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v335 = Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
        // pto: %4
        ;
        uint64_t v336 = (uint64_t) v28;
        TASSIGN(v335, v336);
        uint16_t v337 = static_cast<uint16_t>(v37);
        uint16_t v338 = static_cast<uint16_t>(v36);
        TEXTRACT(v335, v174, v337, v338);
        // pto: %5
        ;
        Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v339 = Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %5
        ;
        uint64_t v340 = (uint64_t) v29;
        TASSIGN(v339, v340);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v341 = static_cast<uint16_t>(v36);
        uint16_t v342 = static_cast<uint16_t>(v37);
        TEXTRACT(v339, v323, v341, v342);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v325, v327, v331);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v325, v325, v335, v339);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        TPUSH<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_LEFT_RIGHT>(v91, v325);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %7
        ;
        Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v343 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
        // pto: %7
        ;
        uint64_t v344 = (uint64_t) v30;
        TASSIGN(v343, v344);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        for (int64_t v345 = v37; v345 < v49; v345 += v32) {
          // pto: %145
          ;
          int64_t v346 = (int64_t) ((uint64_t) v345 * (uint64_t) v50);
          // pto: %144, %146
          ;
          int64_t v347 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v158 + (uint64_t) v196) + (uint64_t) v346);
          // pto: %147
          ;
          const int64_t v348 = 1;
          // pto: %147
          ;
          const int64_t v349 = 0;
          // pto: %147
          ;
          int64_t v350 = v347 / v50;
          // pto: %147
          ;
          bool v351 = v347 < v349;
          // pto: %147
          ;
          bool v352 = v50 < v349;
          // pto: %147
          ;
          bool v353 = v351 == v352;
          // pto: %147
          ;
          bool v354 = v347 % v50 != v349 && v351 != v352;
          // pto: %147
          ;
          int64_t v355 = v354 ? v350 - v348 : v350;
          // pto: %148
          ;
          int64_t v356 = (int64_t) ((uint64_t) v145 - (uint64_t) v32);
          // pto: %149
          ;
          const int64_t v357 = 1;
          // pto: %149
          ;
          const int64_t v358 = 0;
          // pto: %149
          ;
          int64_t v359 = v356 / v50;
          // pto: %149
          ;
          bool v360 = v356 < v358;
          // pto: %149
          ;
          bool v361 = v50 < v358;
          // pto: %149
          ;
          bool v362 = v360 == v361;
          // pto: %149
          ;
          bool v363 = v356 % v50 != v358 && v360 != v361;
          // pto: %149
          ;
          int64_t v364 = v363 ? v359 - v357 : v359;
          // pto: %150
          ;
          int64_t v365 = v364 < v37 ? v37 : v364;
          // pto: %151
          ;
          int64_t v366 = v355 < v365 ? v355 : v365;
          // pto: %153, %154, %152
          ;
          int32_t v367 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v132 * (uint64_t) v17) + (uint64_t) v366)];
          // pto: %155
          ;
          int64_t v368 = (int64_t) v367;
          // pto: %156
          ;
          int64_t v369 = v368 < v37 ? v37 : v368;
          // pto: %157
          ;
          int64_t v370 = (int64_t) ((uint64_t) v369 * (uint64_t) v14);
          // pto: %158
          ;
          int64_t v371 = v370 % v35;
          // pto: %159, %160, %161
          ;
          int64_t v372 = v371 < v37 ? (int64_t) ((uint64_t) v371 + (uint64_t) v35) : v371;
          // pto: %162
          ;
          if (v372 == v37) {
            // pto: %165
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v373;
            // pto: %165
            ;
            uint64_t v374 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v346 * (uint64_t) v24) + (uint64_t) v30);
            TASSIGN(v373, v374);
            // pto: %166
            ;
            const int64_t v375 = 1;
            // pto: %166
            ;
            const int64_t v376 = 0;
            // pto: %166
            ;
            int64_t v377 = v370 / v35;
            // pto: %166
            ;
            bool v378 = v370 < v376;
            // pto: %166
            ;
            bool v379 = v35 < v376;
            // pto: %166
            ;
            bool v380 = v378 == v379;
            // pto: %166
            ;
            bool v381 = v370 % v35 != v376 && v378 != v379;
            // pto: %166
            ;
            int64_t v382 = v381 ? v377 - v375 : v377;
            // pto: %167
            ;
            int64_t v383 = v382 < v37 ? v37 : v382;
            // pto: %168
            ;
            __gm__ int8_t* v384 = PTOAS__GLOBAL_TENSOR_DATA(v68);
            // pto: %168
            ;
            const int64_t v385 = 0;
            // pto: %168
            ;
            const int64_t v386 = 128;
            // pto: %168
            ;
            pto::Shape<1, 1, 1, 32, 128> v387 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %168
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v388 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %168
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v389 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v384 + (v385 + v383 * v386), v387, v388);
            TLOAD(v373, v389);
          } else {
            // pto: %170
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v390;
            // pto: %170
            ;
            uint64_t v391 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v346 * (uint64_t) v24) + (uint64_t) v30);
            TASSIGN(v390, v391);
            // pto: %171
            ;
            const int64_t v392 = 1;
            // pto: %171
            ;
            const int64_t v393 = 0;
            // pto: %171
            ;
            int64_t v394 = v370 / v35;
            // pto: %171
            ;
            bool v395 = v370 < v393;
            // pto: %171
            ;
            bool v396 = v35 < v393;
            // pto: %171
            ;
            bool v397 = v395 == v396;
            // pto: %171
            ;
            bool v398 = v370 % v35 != v393 && v395 != v396;
            // pto: %171
            ;
            int64_t v399 = v398 ? v394 - v392 : v394;
            // pto: %172
            ;
            int64_t v400 = v399 < v37 ? v37 : v399;
            // pto: %173
            ;
            __gm__ int8_t* v401 = PTOAS__GLOBAL_TENSOR_DATA(v77);
            // pto: %173
            ;
            const int64_t v402 = 0;
            // pto: %173
            ;
            const int64_t v403 = 128;
            // pto: %173
            ;
            pto::Shape<1, 1, 1, 32, 128> v404 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %173
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v405 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %173
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v406 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v401 + (v402 + v400 * v403), v404, v405);
            TLOAD(v390, v406);
          };
        };
        for (int64_t v407 = v37; v407 < v49; v407 += v32) {
          // pto: %177
          ;
          int64_t v408 = (int64_t) ((uint64_t) v407 * (uint64_t) v50);
          // pto: %175, %176, %178
          ;
          int64_t v409 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v158 + (uint64_t) v196) + (uint64_t) v172) + (uint64_t) v408);
          // pto: %179
          ;
          const int64_t v410 = 1;
          // pto: %179
          ;
          const int64_t v411 = 0;
          // pto: %179
          ;
          int64_t v412 = v409 / v50;
          // pto: %179
          ;
          bool v413 = v409 < v411;
          // pto: %179
          ;
          bool v414 = v50 < v411;
          // pto: %179
          ;
          bool v415 = v413 == v414;
          // pto: %179
          ;
          bool v416 = v409 % v50 != v411 && v413 != v414;
          // pto: %179
          ;
          int64_t v417 = v416 ? v412 - v410 : v412;
          // pto: %180
          ;
          int64_t v418 = (int64_t) ((uint64_t) v145 - (uint64_t) v32);
          // pto: %181
          ;
          const int64_t v419 = 1;
          // pto: %181
          ;
          const int64_t v420 = 0;
          // pto: %181
          ;
          int64_t v421 = v418 / v50;
          // pto: %181
          ;
          bool v422 = v418 < v420;
          // pto: %181
          ;
          bool v423 = v50 < v420;
          // pto: %181
          ;
          bool v424 = v422 == v423;
          // pto: %181
          ;
          bool v425 = v418 % v50 != v420 && v422 != v423;
          // pto: %181
          ;
          int64_t v426 = v425 ? v421 - v419 : v421;
          // pto: %182
          ;
          int64_t v427 = v426 < v37 ? v37 : v426;
          // pto: %183
          ;
          int64_t v428 = v417 < v427 ? v417 : v427;
          // pto: %185, %186, %184
          ;
          int32_t v429 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v132 * (uint64_t) v17) + (uint64_t) v428)];
          // pto: %187
          ;
          int64_t v430 = (int64_t) v429;
          // pto: %188
          ;
          int64_t v431 = v430 < v37 ? v37 : v430;
          // pto: %189
          ;
          int64_t v432 = (int64_t) ((uint64_t) v431 * (uint64_t) v14);
          // pto: %190
          ;
          int64_t v433 = v432 % v35;
          // pto: %191, %192, %193
          ;
          int64_t v434 = v433 < v37 ? (int64_t) ((uint64_t) v433 + (uint64_t) v35) : v433;
          // pto: %194
          ;
          if (v434 == v37) {
            // pto: %198
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v435;
            // pto: %197, %198
            ;
            uint64_t v436 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v408 + (uint64_t) v46) * (uint64_t) v24) + (uint64_t) v30);
            TASSIGN(v435, v436);
            // pto: %199
            ;
            const int64_t v437 = 1;
            // pto: %199
            ;
            const int64_t v438 = 0;
            // pto: %199
            ;
            int64_t v439 = v432 / v35;
            // pto: %199
            ;
            bool v440 = v432 < v438;
            // pto: %199
            ;
            bool v441 = v35 < v438;
            // pto: %199
            ;
            bool v442 = v440 == v441;
            // pto: %199
            ;
            bool v443 = v432 % v35 != v438 && v440 != v441;
            // pto: %199
            ;
            int64_t v444 = v443 ? v439 - v437 : v439;
            // pto: %200
            ;
            int64_t v445 = v444 < v37 ? v37 : v444;
            // pto: %201
            ;
            __gm__ int8_t* v446 = PTOAS__GLOBAL_TENSOR_DATA(v68);
            // pto: %201
            ;
            const int64_t v447 = 0;
            // pto: %201
            ;
            const int64_t v448 = 128;
            // pto: %201
            ;
            pto::Shape<1, 1, 1, 32, 128> v449 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %201
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v450 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %201
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v451 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v446 + (v447 + v445 * v448), v449, v450);
            TLOAD(v435, v451);
          } else {
            // pto: %204
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v452;
            // pto: %203, %204
            ;
            uint64_t v453 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v408 + (uint64_t) v46) * (uint64_t) v24) + (uint64_t) v30);
            TASSIGN(v452, v453);
            // pto: %205
            ;
            const int64_t v454 = 1;
            // pto: %205
            ;
            const int64_t v455 = 0;
            // pto: %205
            ;
            int64_t v456 = v432 / v35;
            // pto: %205
            ;
            bool v457 = v432 < v455;
            // pto: %205
            ;
            bool v458 = v35 < v455;
            // pto: %205
            ;
            bool v459 = v457 == v458;
            // pto: %205
            ;
            bool v460 = v432 % v35 != v455 && v457 != v458;
            // pto: %205
            ;
            int64_t v461 = v460 ? v456 - v454 : v456;
            // pto: %206
            ;
            int64_t v462 = v461 < v37 ? v37 : v461;
            // pto: %207
            ;
            __gm__ int8_t* v463 = PTOAS__GLOBAL_TENSOR_DATA(v77);
            // pto: %207
            ;
            const int64_t v464 = 0;
            // pto: %207
            ;
            const int64_t v465 = 128;
            // pto: %207
            ;
            pto::Shape<1, 1, 1, 32, 128> v466 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %207
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v467 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %207
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v468 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v463 + (v464 + v462 * v465), v466, v467);
            TLOAD(v452, v468);
          };
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        // pto: %12
        ;
        Tile<TileType::Mat, int8_t, 128, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v469 = Tile<TileType::Mat, int8_t, 128, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v35, v45);
        // pto: %12
        ;
        uint64_t v470 = (uint64_t) v30;
        TASSIGN(v469, v470);
        // pto: %13
        ;
        Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v471 = Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %13
        ;
        uint64_t v472 = (uint64_t) v26;
        TASSIGN(v471, v472);
        // pto: %14
        ;
        Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v473 = Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
        // pto: %14
        ;
        uint64_t v474 = (uint64_t) v27;
        TASSIGN(v473, v474);
        uint16_t v475 = static_cast<uint16_t>(v37);
        uint16_t v476 = static_cast<uint16_t>(v37);
        TEXTRACT(v473, v174, v475, v476);
        // pto: %15
        ;
        Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v477 = Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %15
        ;
        uint64_t v478 = (uint64_t) v26;
        TASSIGN(v477, v478);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v479 = static_cast<uint16_t>(v37);
        uint16_t v480 = static_cast<uint16_t>(v37);
        TEXTRACT(v477, v469, v479, v480);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %16
        ;
        Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v481 = Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
        // pto: %16
        ;
        uint64_t v482 = (uint64_t) v31;
        TASSIGN(v481, v482);
        uint16_t v483 = static_cast<uint16_t>(v37);
        uint16_t v484 = static_cast<uint16_t>(v36);
        TEXTRACT(v481, v174, v483, v484);
        // pto: %17
        ;
        Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v485 = Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %17
        ;
        uint64_t v486 = (uint64_t) v29;
        TASSIGN(v485, v486);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        uint16_t v487 = static_cast<uint16_t>(v36);
        uint16_t v488 = static_cast<uint16_t>(v37);
        TEXTRACT(v485, v469, v487, v488);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v471, v473, v477);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        TMATMUL_ACC(v471, v471, v481, v485);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TPUSH<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_LEFT_RIGHT>(v91, v471);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
      // pto: %209
      ;
      const int64_t v489 = 1;
      // pto: %209
      ;
      const int64_t v490 = 0;
      // pto: %209
      ;
      int64_t v491 = v183 / v46;
      // pto: %209
      ;
      bool v492 = v183 < v490;
      // pto: %209
      ;
      bool v493 = v46 < v490;
      // pto: %209
      ;
      bool v494 = v492 == v493;
      // pto: %209
      ;
      bool v495 = v183 % v46 != v490 && v492 != v493;
      // pto: %209
      ;
      int64_t v496 = v495 ? v491 - v489 : v491;
      // pto: %213, %212, %214
      ;
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
      if ((int64_t) ((uint64_t) v496 - (uint64_t) ((int64_t) (uint64_t) v191 * (uint64_t) v51)) == v32) {
        // pto: %216, %215
        ;
        int64_t v497 = (int64_t) ((uint64_t) v192 * (uint64_t) ((int64_t) (uint64_t) v118 + (uint64_t) v32));
        // pto: %20
        ;
        Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v498 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
        // pto: %20
        ;
        uint64_t v499 = (uint64_t) v27;
        TASSIGN(v498, v499);
        for (int64_t v500 = v37; v500 < v49; v500 += v32) {
          // pto: %219
          ;
          int64_t v501 = (int64_t) ((uint64_t) v500 * (uint64_t) v50);
          // pto: %218, %220
          ;
          int64_t v502 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v158 + (uint64_t) v497) + (uint64_t) v501);
          // pto: %221
          ;
          const int64_t v503 = 1;
          // pto: %221
          ;
          const int64_t v504 = 0;
          // pto: %221
          ;
          int64_t v505 = v502 / v50;
          // pto: %221
          ;
          bool v506 = v502 < v504;
          // pto: %221
          ;
          bool v507 = v50 < v504;
          // pto: %221
          ;
          bool v508 = v506 == v507;
          // pto: %221
          ;
          bool v509 = v502 % v50 != v504 && v506 != v507;
          // pto: %221
          ;
          int64_t v510 = v509 ? v505 - v503 : v505;
          // pto: %222
          ;
          int64_t v511 = (int64_t) ((uint64_t) v145 - (uint64_t) v32);
          // pto: %223
          ;
          const int64_t v512 = 1;
          // pto: %223
          ;
          const int64_t v513 = 0;
          // pto: %223
          ;
          int64_t v514 = v511 / v50;
          // pto: %223
          ;
          bool v515 = v511 < v513;
          // pto: %223
          ;
          bool v516 = v50 < v513;
          // pto: %223
          ;
          bool v517 = v515 == v516;
          // pto: %223
          ;
          bool v518 = v511 % v50 != v513 && v515 != v516;
          // pto: %223
          ;
          int64_t v519 = v518 ? v514 - v512 : v514;
          // pto: %224
          ;
          int64_t v520 = v519 < v37 ? v37 : v519;
          // pto: %225
          ;
          int64_t v521 = v510 < v520 ? v510 : v520;
          // pto: %227, %228, %226
          ;
          int32_t v522 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v132 * (uint64_t) v17) + (uint64_t) v521)];
          // pto: %229
          ;
          int64_t v523 = (int64_t) v522;
          // pto: %230
          ;
          int64_t v524 = v523 < v37 ? v37 : v523;
          // pto: %231
          ;
          int64_t v525 = (int64_t) ((uint64_t) v524 * (uint64_t) v14);
          // pto: %232
          ;
          int64_t v526 = v525 % v35;
          // pto: %233, %234, %235
          ;
          int64_t v527 = v526 < v37 ? (int64_t) ((uint64_t) v526 + (uint64_t) v35) : v526;
          // pto: %236
          ;
          if (v527 == v37) {
            // pto: %239
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v528;
            // pto: %239
            ;
            uint64_t v529 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v501 * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v528, v529);
            // pto: %240
            ;
            const int64_t v530 = 1;
            // pto: %240
            ;
            const int64_t v531 = 0;
            // pto: %240
            ;
            int64_t v532 = v525 / v35;
            // pto: %240
            ;
            bool v533 = v525 < v531;
            // pto: %240
            ;
            bool v534 = v35 < v531;
            // pto: %240
            ;
            bool v535 = v533 == v534;
            // pto: %240
            ;
            bool v536 = v525 % v35 != v531 && v533 != v534;
            // pto: %240
            ;
            int64_t v537 = v536 ? v532 - v530 : v532;
            // pto: %241
            ;
            int64_t v538 = v537 < v37 ? v37 : v537;
            // pto: %242
            ;
            __gm__ int8_t* v539 = PTOAS__GLOBAL_TENSOR_DATA(v68);
            // pto: %242
            ;
            const int64_t v540 = 0;
            // pto: %242
            ;
            const int64_t v541 = 128;
            // pto: %242
            ;
            pto::Shape<1, 1, 1, 32, 128> v542 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %242
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v543 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %242
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v544 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v539 + (v540 + v538 * v541), v542, v543);
            TLOAD(v528, v544);
          } else {
            // pto: %244
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v545;
            // pto: %244
            ;
            uint64_t v546 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v501 * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v545, v546);
            // pto: %245
            ;
            const int64_t v547 = 1;
            // pto: %245
            ;
            const int64_t v548 = 0;
            // pto: %245
            ;
            int64_t v549 = v525 / v35;
            // pto: %245
            ;
            bool v550 = v525 < v548;
            // pto: %245
            ;
            bool v551 = v35 < v548;
            // pto: %245
            ;
            bool v552 = v550 == v551;
            // pto: %245
            ;
            bool v553 = v525 % v35 != v548 && v550 != v551;
            // pto: %245
            ;
            int64_t v554 = v553 ? v549 - v547 : v549;
            // pto: %246
            ;
            int64_t v555 = v554 < v37 ? v37 : v554;
            // pto: %247
            ;
            __gm__ int8_t* v556 = PTOAS__GLOBAL_TENSOR_DATA(v77);
            // pto: %247
            ;
            const int64_t v557 = 0;
            // pto: %247
            ;
            const int64_t v558 = 128;
            // pto: %247
            ;
            pto::Shape<1, 1, 1, 32, 128> v559 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %247
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v560 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %247
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v561 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v556 + (v557 + v555 * v558), v559, v560);
            TLOAD(v545, v561);
          };
        };
        for (int64_t v562 = v37; v562 < v49; v562 += v32) {
          // pto: %251
          ;
          int64_t v563 = (int64_t) ((uint64_t) v562 * (uint64_t) v50);
          // pto: %249, %250, %252
          ;
          int64_t v564 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v158 + (uint64_t) v497) + (uint64_t) v172) + (uint64_t) v563);
          // pto: %253
          ;
          const int64_t v565 = 1;
          // pto: %253
          ;
          const int64_t v566 = 0;
          // pto: %253
          ;
          int64_t v567 = v564 / v50;
          // pto: %253
          ;
          bool v568 = v564 < v566;
          // pto: %253
          ;
          bool v569 = v50 < v566;
          // pto: %253
          ;
          bool v570 = v568 == v569;
          // pto: %253
          ;
          bool v571 = v564 % v50 != v566 && v568 != v569;
          // pto: %253
          ;
          int64_t v572 = v571 ? v567 - v565 : v567;
          // pto: %254
          ;
          int64_t v573 = (int64_t) ((uint64_t) v145 - (uint64_t) v32);
          // pto: %255
          ;
          const int64_t v574 = 1;
          // pto: %255
          ;
          const int64_t v575 = 0;
          // pto: %255
          ;
          int64_t v576 = v573 / v50;
          // pto: %255
          ;
          bool v577 = v573 < v575;
          // pto: %255
          ;
          bool v578 = v50 < v575;
          // pto: %255
          ;
          bool v579 = v577 == v578;
          // pto: %255
          ;
          bool v580 = v573 % v50 != v575 && v577 != v578;
          // pto: %255
          ;
          int64_t v581 = v580 ? v576 - v574 : v576;
          // pto: %256
          ;
          int64_t v582 = v581 < v37 ? v37 : v581;
          // pto: %257
          ;
          int64_t v583 = v572 < v582 ? v572 : v582;
          // pto: %259, %260, %258
          ;
          int32_t v584 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v132 * (uint64_t) v17) + (uint64_t) v583)];
          // pto: %261
          ;
          int64_t v585 = (int64_t) v584;
          // pto: %262
          ;
          int64_t v586 = v585 < v37 ? v37 : v585;
          // pto: %263
          ;
          int64_t v587 = (int64_t) ((uint64_t) v586 * (uint64_t) v14);
          // pto: %264
          ;
          int64_t v588 = v587 % v35;
          // pto: %265, %266, %267
          ;
          int64_t v589 = v588 < v37 ? (int64_t) ((uint64_t) v588 + (uint64_t) v35) : v588;
          // pto: %268
          ;
          if (v589 == v37) {
            // pto: %272
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v590;
            // pto: %271, %272
            ;
            uint64_t v591 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v563 + (uint64_t) v46) * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v590, v591);
            // pto: %273
            ;
            const int64_t v592 = 1;
            // pto: %273
            ;
            const int64_t v593 = 0;
            // pto: %273
            ;
            int64_t v594 = v587 / v35;
            // pto: %273
            ;
            bool v595 = v587 < v593;
            // pto: %273
            ;
            bool v596 = v35 < v593;
            // pto: %273
            ;
            bool v597 = v595 == v596;
            // pto: %273
            ;
            bool v598 = v587 % v35 != v593 && v595 != v596;
            // pto: %273
            ;
            int64_t v599 = v598 ? v594 - v592 : v594;
            // pto: %274
            ;
            int64_t v600 = v599 < v37 ? v37 : v599;
            // pto: %275
            ;
            __gm__ int8_t* v601 = PTOAS__GLOBAL_TENSOR_DATA(v68);
            // pto: %275
            ;
            const int64_t v602 = 0;
            // pto: %275
            ;
            const int64_t v603 = 128;
            // pto: %275
            ;
            pto::Shape<1, 1, 1, 32, 128> v604 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %275
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v605 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %275
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v606 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v601 + (v602 + v600 * v603), v604, v605);
            TLOAD(v590, v606);
          } else {
            // pto: %278
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v607;
            // pto: %277, %278
            ;
            uint64_t v608 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v563 + (uint64_t) v46) * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v607, v608);
            // pto: %279
            ;
            const int64_t v609 = 1;
            // pto: %279
            ;
            const int64_t v610 = 0;
            // pto: %279
            ;
            int64_t v611 = v587 / v35;
            // pto: %279
            ;
            bool v612 = v587 < v610;
            // pto: %279
            ;
            bool v613 = v35 < v610;
            // pto: %279
            ;
            bool v614 = v612 == v613;
            // pto: %279
            ;
            bool v615 = v587 % v35 != v610 && v612 != v613;
            // pto: %279
            ;
            int64_t v616 = v615 ? v611 - v609 : v611;
            // pto: %280
            ;
            int64_t v617 = v616 < v37 ? v37 : v616;
            // pto: %281
            ;
            __gm__ int8_t* v618 = PTOAS__GLOBAL_TENSOR_DATA(v77);
            // pto: %281
            ;
            const int64_t v619 = 0;
            // pto: %281
            ;
            const int64_t v620 = 128;
            // pto: %281
            ;
            pto::Shape<1, 1, 1, 32, 128> v621 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %281
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v622 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %281
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v623 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v618 + (v619 + v617 * v620), v621, v622);
            TLOAD(v607, v623);
          };
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
        // pto: %25
        ;
        Tile<TileType::Mat, int8_t, 128, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v624 = Tile<TileType::Mat, int8_t, 128, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v35, v45);
        // pto: %25
        ;
        uint64_t v625 = (uint64_t) v27;
        TASSIGN(v624, v625);
        // pto: %26
        ;
        Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v626 = Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %26
        ;
        uint64_t v627 = (uint64_t) v26;
        TASSIGN(v626, v627);
        // pto: %27
        ;
        Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v628 = Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
        // pto: %27
        ;
        uint64_t v629 = (uint64_t) v26;
        TASSIGN(v628, v629);
        uint16_t v630 = static_cast<uint16_t>(v37);
        uint16_t v631 = static_cast<uint16_t>(v37);
        TEXTRACT(v628, v174, v630, v631);
        // pto: %28
        ;
        Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v632 = Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %28
        ;
        uint64_t v633 = (uint64_t) v26;
        TASSIGN(v632, v633);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
        uint16_t v634 = static_cast<uint16_t>(v37);
        uint16_t v635 = static_cast<uint16_t>(v37);
        TEXTRACT(v632, v624, v634, v635);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        // pto: %29
        ;
        Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v636 = Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
        // pto: %29
        ;
        uint64_t v637 = (uint64_t) v28;
        TASSIGN(v636, v637);
        uint16_t v638 = static_cast<uint16_t>(v37);
        uint16_t v639 = static_cast<uint16_t>(v36);
        TEXTRACT(v636, v174, v638, v639);
        // pto: %30
        ;
        Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v640 = Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %30
        ;
        uint64_t v641 = (uint64_t) v29;
        TASSIGN(v640, v641);
        uint16_t v642 = static_cast<uint16_t>(v36);
        uint16_t v643 = static_cast<uint16_t>(v37);
        TEXTRACT(v640, v624, v642, v643);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        TMATMUL(v626, v628, v632);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        TMATMUL_ACC(v626, v626, v636, v640);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
        TPUSH<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_LEFT_RIGHT>(v91, v626);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    };
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void indexer_score_topk_leaf_aiv(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ float* v3, __gm__ int32_t* v4, __gm__ int8_t* v5, __gm__ float* v6, __gm__ float* v7, __gm__ int32_t* v8, __gm__ int8_t* v9, __gm__ int8_t* v10, __gm__ int8_t* v11, __gm__ float* v12, __gm__ float* v13, int64_t v14, int64_t v15, int64_t v16, int64_t v17, int64_t v18, int64_t v19, int64_t v20, int64_t v21, int32_t v22, int32_t v23, int32_t v24) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  pto::MrgSortExecutedNumList v25 = pto::MrgSortExecutedNumList{0, 0, 0, 0};
  // pto: %c131072_i64
  const int64_t v26 = 131072;
  // pto: %c131328_i64
  const int64_t v27 = 131328;
  // pto: %c98688_i64
  const int64_t v28 = 98688;
  // pto: %c98304_i64
  const int64_t v29 = 98304;
  // pto: %c131840_i64
  const int64_t v30 = 131840;
  // pto: %c133120_i64
  const int64_t v31 = 133120;
  const int64_t v32 = 135168;
  // pto: %c137216_i64
  const int64_t v33 = 137216;
  // pto: %c139264_i64
  const int64_t v34 = 139264;
  // pto: %c143360_i64
  const int64_t v35 = 143360;
  const int64_t v36 = 147456;
  // pto: %c155648_i64
  const int64_t v37 = 155648;
  // pto: %c141312_i64
  const int64_t v38 = 141312;
  const int64_t v39 = 151552;
  // pto: %c161792_i64
  const int64_t v40 = 161792;
  // pto: %c172032_i64
  const int64_t v41 = 172032;
  // pto: %c167936_i64
  const int64_t v42 = 167936;
  // pto: %c110592_i64
  const int64_t v43 = 110592;
  // pto: %c163840_i64
  const int64_t v44 = 163840;
  const int64_t v45 = 114688;
  // pto: %c1_index
  const int64_t v46 = 1;
  // pto: %c432_index
  const int64_t v47 = 432;
  // pto: %c8192_index
  const int64_t v48 = 8192;
  // pto: %c27648_index
  const int64_t v49 = 27648;
  // pto: %c64_index
  const int64_t v50 = 64;
  // pto: %c1024_index
  const int64_t v51 = 1024;
  // pto: %c0_i32
  const int32_t v52 = 0;
  // pto: %c0_index
  const int64_t v53 = 0;
  // pto: %c4_index
  const int64_t v54 = 4;
  // pto: %c262144_index
  const int64_t v55 = 262144;
  // pto: %c8191_index
  const int64_t v56 = 8191;
  // pto: %c24_index
  const int64_t v57 = 24;
  // pto: %c1_i64
  const int64_t v58 = 1;
  // pto: %c4_i64
  const int64_t v59 = 4;
  // pto: %c383_index
  const int64_t v60 = 383;
  // pto: %c384_index
  const int64_t v61 = 384;
  // pto: %c192_index
  const int64_t v62 = 192;
  // pto: %c4096_index
  const int64_t v63 = 4096;
  // pto: %c191_index
  const int64_t v64 = 191;
  // pto: %c2_index
  const int64_t v65 = 2;
  // pto: %c6_index
  const int64_t v66 = 6;
  // pto: %c32_index
  const int64_t v67 = 32;
  // pto: %cst_43
  const float v68 = 0.0f;
  // pto: %c512_index
  const int64_t v69 = 512;
  // pto: %cst_45
  const float v70 = -3.40282347E+38f;
  // pto: %c64_i32
  const int32_t v71 = 64;
  // pto: %c256_i32
  const int32_t v72 = 256;
  // pto: %c2048_index
  const int64_t v73 = 2048;
  // pto: %c1024_i32
  const int32_t v74 = 1024;
  // pto: %c2560_index
  const int64_t v75 = 2560;
  // pto: %c5120_index
  const int64_t v76 = 5120;
  // pto: %c3072_index
  const int64_t v77 = 3072;
  // pto: %c6144_index
  const int64_t v78 = 6144;
  // pto: %score_arena_inline3678__ssa_v0_view
  const int64_t v79 = 1;
  // pto: %score_arena_inline3678__ssa_v0_view
  const int64_t v80 = 1;
  // pto: %score_arena_inline3678__ssa_v0_view
  const int64_t v81 = 1;
  // pto: %score_arena_inline3678__ssa_v0_view
  int64_t v82 = v47 * v48;
  // pto: %score_arena_inline3678__ssa_v0_view
  int64_t v83 = v81 * v82;
  // pto: %score_arena_inline3678__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v84 = pto::Shape<1, 1, 1, -1, -1>(v79, v80, v81, v47, v48);
  // pto: %score_arena_inline3678__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v85 = pto::Stride<-1, -1, -1, -1, -1>(v80 * v83, v83, v82, v48, v46);
  // pto: %score_arena_inline3678__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v86 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v84, v85);
  // pto: %qr_hadamard_scale_dq_inline3548__rv_v2_view
  const int64_t v87 = 1;
  // pto: %qr_hadamard_scale_dq_inline3548__rv_v2_view
  const int64_t v88 = 1;
  // pto: %qr_hadamard_scale_dq_inline3548__rv_v2_view
  const int64_t v89 = 1;
  // pto: %qr_hadamard_scale_dq_inline3548__rv_v2_view
  int64_t v90 = v49 * v46;
  // pto: %qr_hadamard_scale_dq_inline3548__rv_v2_view
  int64_t v91 = v89 * v90;
  // pto: %qr_hadamard_scale_dq_inline3548__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v92 = pto::Shape<1, 1, 1, -1, -1>(v87, v88, v89, v49, v46);
  // pto: %qr_hadamard_scale_dq_inline3548__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v93 = pto::Stride<-1, -1, -1, -1, -1>(v88 * v91, v91, v90, v46, v49);
  // pto: %qr_hadamard_scale_dq_inline3548__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v94 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v6, v92, v93);
  // pto: %weights_inline3651__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %weights_inline3651__ssa_v0_view
  const int64_t v96 = 1;
  // pto: %weights_inline3651__ssa_v0_view
  const int64_t v97 = 1;
  // pto: %weights_inline3651__ssa_v0_view
  int64_t v98 = v47 * v50;
  // pto: %weights_inline3651__ssa_v0_view
  int64_t v99 = v97 * v98;
  // pto: %weights_inline3651__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v100 = pto::Shape<1, 1, 1, -1, -1>(v95, v96, v97, v47, v50);
  // pto: %weights_inline3651__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v101 = pto::Stride<-1, -1, -1, -1, -1>(v96 * v99, v99, v98, v50, v46);
  // pto: %weights_inline3651__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v102 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v100, v101);
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v103 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v104 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v105 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v106 = (int64_t) v20;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v107 = (int64_t) v21;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v108 = v106 * v107;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v109 = v105 * v108;
  // pto: %idx_native_kv_cache__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v110 = pto::Shape<1, 1, 1, -1, -1>(v103, v104, v105, v106, (int64_t) v21);
  // pto: %idx_native_kv_cache__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v111 = pto::Stride<-1, -1, -1, -1, -1>(v104 * v109, v109, v108, v107, v46);
  // pto: %idx_native_kv_cache__rv_v2_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v112 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v11, v110, v111);
  // pto: %pair_arena_inline3677__ssa_v0_view
  const int64_t v113 = 1;
  // pto: %pair_arena_inline3677__ssa_v0_view
  const int64_t v114 = 1;
  // pto: %pair_arena_inline3677__ssa_v0_view
  const int64_t v115 = 1;
  // pto: %pair_arena_inline3677__ssa_v0_view
  int64_t v116 = v49 * v51;
  // pto: %pair_arena_inline3677__ssa_v0_view
  int64_t v117 = v115 * v116;
  // pto: %pair_arena_inline3677__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v118 = pto::Shape<1, 1, 1, -1, -1>(v113, v114, v115, v49, v51);
  // pto: %pair_arena_inline3677__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v119 = pto::Stride<-1, -1, -1, -1, -1>(v114 * v117, v117, v116, v51, v46);
  // pto: %pair_arena_inline3677__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v120 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v12, v118, v119);
  const int32_t v121 = 0;
  auto v122 = TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>(v13, v52, v121);
  // pto: %worker_inline3688__ssa_v0
  int64_t v123 = (int64_t) v22;
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  // pto: %max_cache_len_inline3690__rv_v2
  int64_t v124;
  v124 = v53;
  for (int64_t v125 = v53; v125 < v16; v125 += v46) {
    // pto: %26
    ;
    int32_t v126 = (v2)[v125];
    // pto: %27
    ;
    int64_t v127 = (int64_t) v126;
    // pto: %28
    ;
    const int64_t v128 = 1;
    // pto: %28
    ;
    const int64_t v129 = 0;
    // pto: %28
    ;
    int64_t v130 = v127 / v54;
    // pto: %28
    ;
    bool v131 = v127 < v129;
    // pto: %28
    ;
    bool v132 = v54 < v129;
    // pto: %28
    ;
    bool v133 = v131 == v132;
    // pto: %28
    ;
    bool v134 = v127 % v54 != v129 && v131 != v132;
    // pto: %28
    ;
    int64_t v135 = v134 ? v130 - v128 : v130;
    // pto: %29
    ;
    bool v136 = v124 < v135;
    // pto: %29
    ;
    int64_t v137 = v136 ? v135 : v124;
    v124 = v137;
  }
  // pto: %30
  bool v138 = v124 < v55;
  // pto: %30
  int64_t v139 = v138 ? v124 : v55;
  // pto: %31
  int64_t v140 = (int64_t) ((uint64_t) v139 + (uint64_t) v56);
  // pto: %32
  const int64_t v141 = 1;
  // pto: %32
  const int64_t v142 = 0;
  // pto: %32
  int64_t v143 = v140 / v48;
  // pto: %32
  bool v144 = v140 < v142;
  // pto: %32
  bool v145 = v48 < v142;
  // pto: %32
  bool v146 = v144 == v145;
  // pto: %32
  bool v147 = v140 % v48 != v142 && v144 != v145;
  // pto: %32
  int64_t v148 = v147 ? v143 - v141 : v143;
  // pto: %33
  int64_t v149 = v148 < v46 ? v46 : v148;
  // pto: %34, %35
  int64_t v150 = (int64_t) (v149 == v46);
  // pto: %36
  for (int64_t v151 = v123; v151 < ((int64_t) ((uint64_t) v15 * (uint64_t) v149)); v151 += v57) {
    // pto: %37
    ;
    const int64_t v152 = 1;
    // pto: %37
    ;
    const int64_t v153 = 0;
    // pto: %37
    ;
    int64_t v154 = v151 / v149;
    // pto: %37
    ;
    bool v155 = v151 < v153;
    // pto: %37
    ;
    bool v156 = v149 < v153;
    // pto: %37
    ;
    bool v157 = v155 == v156;
    // pto: %37
    ;
    bool v158 = v151 % v149 != v153 && v155 != v156;
    // pto: %37
    ;
    int64_t v159 = v158 ? v154 - v152 : v154;
    // pto: %38
    ;
    int64_t v160 = v151 % v149;
    // pto: %39, %40, %41
    ;
    bool v161 = v160 < v53 ^ v149 < v53;
    // pto: %42, %43, %44, %45
    ;
    int64_t v162 = v160 != v53 & v161 ? (int64_t) ((uint64_t) v160 + (uint64_t) v149) : v160;
    // pto: %46
    ;
    int32_t v163 = (v4)[v159];
    // pto: %47
    ;
    int64_t v164 = (int64_t) v163;
    // pto: %position_inline3699__tile
    ;
    int64_t v165 = (v1)[v159];
    // pto: %49
    ;
    int64_t v166 = v164 < v53 ? v53 : v164;
    // pto: %48
    ;
    int32_t v167 = (v2)[v166];
    // pto: %50
    ;
    int64_t v168 = (int64_t) v167;
    // pto: %51
    ;
    const int64_t v169 = 1;
    // pto: %51
    ;
    const int64_t v170 = 0;
    // pto: %51
    ;
    int64_t v171 = v168 / v54;
    // pto: %51
    ;
    bool v172 = v168 < v170;
    // pto: %51
    ;
    bool v173 = v54 < v170;
    // pto: %51
    ;
    bool v174 = v172 == v173;
    // pto: %51
    ;
    bool v175 = v168 % v54 != v170 && v172 != v173;
    // pto: %51
    ;
    int64_t v176 = v175 ? v171 - v169 : v171;
    // pto: %52, %cache_len_inline3700__phi_v2
    ;
    int64_t v177 = v164 < v53 ? v53 : v176;
    // pto: %53
    ;
    int64_t v178 = (int64_t) ((uint64_t) v165 + (uint64_t) v58);
    // pto: %54
    ;
    const int64_t v179 = 1;
    // pto: %54
    ;
    const int64_t v180 = 0;
    // pto: %54
    ;
    int64_t v181 = v178 / v59;
    // pto: %54
    ;
    bool v182 = v178 < v180;
    // pto: %54
    ;
    bool v183 = v59 < v180;
    // pto: %54
    ;
    bool v184 = v182 == v183;
    // pto: %54
    ;
    bool v185 = v178 % v59 != v180 && v182 != v183;
    // pto: %54
    ;
    int64_t v186 = v185 ? v181 - v179 : v181;
    // pto: %56
    ;
    int64_t v187 = v177 < v186 ? v177 : v186;
    // pto: %57
    ;
    int64_t v188 = v187 < v55 ? v187 : v55;
    // pto: %58
    ;
    int64_t v189 = v188 < v53 ? v53 : v188;
    // pto: %59
    ;
    int64_t v190 = (int64_t) ((uint64_t) v162 * (uint64_t) v48);
    // pto: %60
    ;
    if (v190 < v189) {
      // pto: %61
      ;
      int64_t v191 = (int64_t) ((uint64_t) v189 - (uint64_t) v190);
      // pto: %62
      ;
      int64_t v192 = v191 < v48 ? v191 : v48;
      // pto: %63
      ;
      int64_t v193 = (int64_t) ((uint64_t) v192 + (uint64_t) v60);
      // pto: %64
      ;
      const int64_t v194 = 1;
      // pto: %64
      ;
      const int64_t v195 = 0;
      // pto: %64
      ;
      int64_t v196 = v193 / v61;
      // pto: %64
      ;
      bool v197 = v193 < v195;
      // pto: %64
      ;
      bool v198 = v61 < v195;
      // pto: %64
      ;
      bool v199 = v197 == v198;
      // pto: %64
      ;
      bool v200 = v193 % v61 != v195 && v197 != v198;
      // pto: %64
      ;
      int64_t v201 = v200 ? v196 - v194 : v196;
      // pto: %65
      ;
      int64_t v202 = (int64_t) ((uint64_t) v201 * (uint64_t) v62);
      // pto: %66
      ;
      int64_t v203 = v202 < v63 ? v202 : v63;
      // pto: %68
      ;
      int64_t v204 = (int64_t) ((uint64_t) v46 - (uint64_t) v150);
      // pto: %67, %70, %69
      ;
      int64_t v205 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v150 * (uint64_t) v62) + (uint64_t) ((int64_t) (uint64_t) v204 * (uint64_t) v203));
      // pto: %71
      ;
      int64_t v206 = (int64_t) ((uint64_t) v159 * (uint64_t) v50);
      // pto: %t__tile
      ;
      Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v46);
      // pto: %t__tile
      ;
      uint64_t v208 = (uint64_t) v26;
      TASSIGN(v207, v208);
      // pto: %72
      ;
      int64_t v209 = v206 < v53 ? v53 : v206;
      // pto: %qr_hadamard_scale_dq_inline3548__rv_v2_pview
      ;
      __gm__ float* v210 = PTOAS__GLOBAL_TENSOR_DATA(v94);
      // pto: %qr_hadamard_scale_dq_inline3548__rv_v2_pview
      ;
      const int64_t v211 = 0;
      // pto: %qr_hadamard_scale_dq_inline3548__rv_v2_pview
      ;
      pto::Shape<1, 1, 1, 64, 1> v212 = pto::Shape<1, 1, 1, 64, 1>();
      // pto: %qr_hadamard_scale_dq_inline3548__rv_v2_pview
      ;
      pto::Stride<64, 64, 64, 1, 27648> v213 = pto::Stride<64, 64, 64, 1, 27648>();
      // pto: %qr_hadamard_scale_dq_inline3548__rv_v2_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 64, 1>, pto::Stride<64, 64, 64, 1, 27648>, pto::Layout::DN> v214 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 1>, pto::Stride<64, 64, 64, 1, 27648>, pto::Layout::DN>(v210 + (v211 + v209), v212, v213);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      TLOAD(v207, v214);
      // pto: %query_scale_inline3710__tile
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v50);
      // pto: %query_scale_inline3710__tile
      ;
      uint64_t v216 = (uint64_t) v26;
      TASSIGN(v215, v216);
      // pto: %query_weight_inline3711__tile
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v50);
      // pto: %query_weight_inline3711__tile
      ;
      uint64_t v218 = (uint64_t) v27;
      TASSIGN(v217, v218);
      // pto: %73
      ;
      int64_t v219 = v159 < v53 ? v53 : v159;
      // pto: %weights_inline3651__ssa_v0_pview
      ;
      __gm__ float* v220 = PTOAS__GLOBAL_TENSOR_DATA(v102);
      // pto: %weights_inline3651__ssa_v0_pview
      ;
      const int64_t v221 = 0;
      // pto: %weights_inline3651__ssa_v0_pview
      ;
      const int64_t v222 = 64;
      // pto: %weights_inline3651__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 64> v223 = pto::Shape<1, 1, 1, 1, 64>();
      // pto: %weights_inline3651__ssa_v0_pview
      ;
      pto::Stride<64, 64, 64, 64, 1> v224 = pto::Stride<64, 64, 64, 64, 1>();
      // pto: %weights_inline3651__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v225 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v220 + (v221 + v219 * v222), v223, v224);
      TLOAD(v217, v225);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v226 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v50);
      // pto: %0
      ;
      uint64_t v227 = (uint64_t) v28;
      TASSIGN(v226, v227);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      pipe_barrier(PIPE_V);
      TMUL(v226, v215, v217);
      // pto: %head_coefficient_inline3712__tile
      ;
      Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v228 = Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v46);
      // pto: %head_coefficient_inline3712__tile
      ;
      uint64_t v229 = (uint64_t) v28;
      TASSIGN(v228, v229);
      // pto: %74
      ;
      int64_t v230 = (int64_t) ((uint64_t) v203 + (uint64_t) v64);
      // pto: %75
      ;
      const int64_t v231 = 1;
      // pto: %75
      ;
      const int64_t v232 = 0;
      // pto: %75
      ;
      int64_t v233 = v230 / v61;
      // pto: %75
      ;
      bool v234 = v230 < v232;
      // pto: %75
      ;
      bool v235 = v61 < v232;
      // pto: %75
      ;
      bool v236 = v234 == v235;
      // pto: %75
      ;
      bool v237 = v230 % v61 != v232 && v234 != v235;
      // pto: %75
      ;
      int64_t v238 = v237 ? v233 - v231 : v233;
      // pto: %76
      ;
      int64_t v239 = (int64_t) ((uint64_t) v238 * (uint64_t) v61);
      for (int64_t v240 = v53; v240 < v239; v240 += v61) {
        // pto: %77
        ;
        int64_t v241 = (int64_t) ((uint64_t) v150 + (uint64_t) v46);
        // pto: %78
        ;
        int64_t v242 = (int64_t) ((uint64_t) v240 * (uint64_t) v241);
        // pto: %aiv_id_inline3723__ssa_v0
        ;
        int64_t v243 = (int64_t) v24;
        // pto: %79
        ;
        int64_t v244 = (int64_t) ((uint64_t) v243 * (uint64_t) v205);
        // pto: %80, %81
        ;
        int64_t v245 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v192 - (uint64_t) v242) - (uint64_t) v244);
        // pto: %82
        ;
        int64_t v246 = v245 < v62 ? v245 : v62;
        // pto: %83
        ;
        int64_t v247 = v246 < v53 ? v53 : v246;
        // pto: %84, %85
        ;
        int64_t v248 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v190 + (uint64_t) v242) + (uint64_t) v244);
        // pto: %86, %91, %90, %88, %89
        ;
        int64_t v249 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v150 * (uint64_t) v159) + (uint64_t) ((int64_t) (uint64_t) v204 * (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v243)));
        // pto: %93, %92, %96, %95
        ;
        int64_t v250 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v150 * (uint64_t) ((int64_t) (uint64_t) v242 + (uint64_t) v244)) + (uint64_t) ((int64_t) (uint64_t) v204 * (uint64_t) v240));
        // pto: %97
        ;
        int64_t v251 = (int64_t) ((uint64_t) v240 + (uint64_t) v62);
        // pto: %99
        ;
        int64_t v252 = (int64_t) ((uint64_t) v251 * (uint64_t) v241);
        // pto: %102, %103
        ;
        int64_t v253 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v192 - (uint64_t) v252) - (uint64_t) v244);
        // pto: %104
        ;
        int64_t v254 = v253 < v62 ? v253 : v62;
        // pto: %105
        ;
        int64_t v255 = v254 < v53 ? v53 : v254;
        // pto: %106, %107
        ;
        int64_t v256 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v190 + (uint64_t) v252) + (uint64_t) v244);
        // pto: %115, %114, %119, %118
        ;
        int64_t v257 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v150 * (uint64_t) ((int64_t) (uint64_t) v252 + (uint64_t) v244)) + (uint64_t) ((int64_t) (uint64_t) v204 * (uint64_t) v251));
        // pto: %scale_bytes_inline3727__tile
        ;
        Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v258 = Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v61);
        // pto: %scale_bytes_inline3727__tile
        ;
        uint64_t v259 = (uint64_t) v29;
        TASSIGN(v258, v259);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        for (int64_t v260 = v53; v260 < v66; v260 += v46) {
          // pto: %120
          ;
          const int64_t v261 = 1;
          // pto: %120
          ;
          const int64_t v262 = 0;
          // pto: %120
          ;
          int64_t v263 = v248 / v67;
          // pto: %120
          ;
          bool v264 = v248 < v262;
          // pto: %120
          ;
          bool v265 = v67 < v262;
          // pto: %120
          ;
          bool v266 = v264 == v265;
          // pto: %120
          ;
          bool v267 = v248 % v67 != v262 && v264 != v265;
          // pto: %120
          ;
          int64_t v268 = v267 ? v263 - v261 : v263;
          // pto: %121
          ;
          int64_t v269 = (int64_t) ((uint64_t) v268 + (uint64_t) v260);
          // pto: %122
          ;
          int64_t v270 = (int64_t) ((uint64_t) v177 - (uint64_t) v46);
          // pto: %123
          ;
          const int64_t v271 = 1;
          // pto: %123
          ;
          const int64_t v272 = 0;
          // pto: %123
          ;
          int64_t v273 = v270 / v67;
          // pto: %123
          ;
          bool v274 = v270 < v272;
          // pto: %123
          ;
          bool v275 = v67 < v272;
          // pto: %123
          ;
          bool v276 = v274 == v275;
          // pto: %123
          ;
          bool v277 = v270 % v67 != v272 && v274 != v275;
          // pto: %123
          ;
          int64_t v278 = v277 ? v273 - v271 : v273;
          // pto: %124
          ;
          int64_t v279 = v278 < v53 ? v53 : v278;
          // pto: %125
          ;
          int64_t v280 = v269 < v279 ? v269 : v279;
          // pto: %flat_offset_mul, %flat_offset, %126
          ;
          int32_t v281 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v164 * (uint64_t) v17) + (uint64_t) v280)];
          // pto: %127
          ;
          int64_t v282 = (int64_t) v281;
          // pto: %128
          ;
          int64_t v283 = v282 < v53 ? v53 : v282;
          // pto: %gather_row_view
          ;
          Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v284;
          // pto: %129, %gather_row_view
          ;
          uint64_t v285 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v260 * (uint64_t) v50) + (uint64_t) v29);
          TASSIGN(v284, v285);
          // pto: %130
          ;
          int64_t v286 = v283 < v53 ? v53 : v283;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v287 = (int64_t) v21;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v288 = 0;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          __gm__ int8_t* v289 = PTOAS__GLOBAL_TENSOR_DATA(v112);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v290 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v291 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v292 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v293 = v46 * v287;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v294 = v292 * v293;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          pto::Shape<1, 1, 1, 1, 64> v295 = pto::Shape<1, 1, 1, 1, 64>(v290, v291, v292, v46, v50);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v296 = pto::Stride<-1, -1, -1, -1, -1>(v291 * v294, v294, v293, v287, v46);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v297 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v289 + (v288 + v286 * v287 + v63 * v46), v295, v296);
          TLOAD(v284, v297);
        };
        // pto: %kv_scale_inline3731__tile
        ;
        Tile<TileType::Vec, half, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Vec, half, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %kv_scale_inline3731__tile
        ;
        uint64_t v299 = (uint64_t) v29;
        TASSIGN(v298, v299);
        // pto: %score_shard_inline3732__tile
        ;
        const int32_t v300 = 64;
        // pto: %score_shard_inline3732__tile
        ;
        const int32_t v301 = 192;
        // pto: %score_shard_inline3732__tile
        ;
        Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v302 = Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v300, v301);
        TPOP<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_LEFT_RIGHT>(v122, v302);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %score_fp32_inline3733__tile
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v303 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %score_fp32_inline3733__tile
        ;
        uint64_t v304 = (uint64_t) v26;
        TASSIGN(v303, v304);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        RoundMode v305 = RoundMode::CAST_NONE;
        SaturationMode v306 = SaturationMode::ON;
        TCVT(v303, v302, v305, v306);
        TFREE<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, TileSplitAxis::TILE_LEFT_RIGHT>(v122);
        // pto: %score_fp32_v1_inline3734__tile
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v307 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %score_fp32_v1_inline3734__tile
        ;
        uint64_t v308 = (uint64_t) v26;
        TASSIGN(v307, v308);
        pipe_barrier(PIPE_V);
        TMAXS(v307, v303, v68);
        // pto: %score_fp32_v2_inline3735__tile
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %score_fp32_v2_inline3735__tile
        ;
        uint64_t v310 = (uint64_t) v26;
        TASSIGN(v309, v310);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v309, v307, v228);
        // pto: %2
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v311 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %2
        ;
        uint64_t v312 = (uint64_t) v26;
        TASSIGN(v311, v312);
        pipe_barrier(PIPE_V);
        TCOLSUM(v311, v309);
        // pto: %score_row_inline3736__tile
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %score_row_inline3736__tile
        ;
        uint64_t v314 = (uint64_t) v26;
        TASSIGN(v313, v314);
        // pto: %3
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %3
        ;
        uint64_t v316 = (uint64_t) v30;
        TASSIGN(v315, v316);
        pipe_barrier(PIPE_V);
        RoundMode v317 = RoundMode::CAST_ROUND;
        SaturationMode v318 = SaturationMode::ON;
        TCVT(v315, v298, v317, v318);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        // pto: %score_row_v1_inline3737__tile
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v319 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %score_row_v1_inline3737__tile
        ;
        uint64_t v320 = (uint64_t) v26;
        TASSIGN(v319, v320);
        pipe_barrier(PIPE_V);
        TMUL(v319, v313, v315);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %131
        ;
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        if (v247 > v53) {
          v319.SetValidShape(v46, v247);
          // pto: %132
          ;
          int64_t v321 = v249 < v53 ? v53 : v249;
          // pto: %133
          ;
          int64_t v322 = v250 < v53 ? v53 : v250;
          // pto: %score_arena_inline3678__iter_v3_pview
          ;
          const int64_t v323 = 0;
          // pto: %score_arena_inline3678__iter_v3_pview
          ;
          __gm__ float* v324 = PTOAS__GLOBAL_TENSOR_DATA(v86);
          // pto: %score_arena_inline3678__iter_v3_pview
          ;
          const int64_t v325 = 1;
          // pto: %score_arena_inline3678__iter_v3_pview
          ;
          const int64_t v326 = 1;
          // pto: %score_arena_inline3678__iter_v3_pview
          ;
          const int64_t v327 = 1;
          // pto: %score_arena_inline3678__iter_v3_pview
          ;
          int64_t v328 = v46 * v48;
          // pto: %score_arena_inline3678__iter_v3_pview
          ;
          int64_t v329 = v327 * v328;
          // pto: %score_arena_inline3678__iter_v3_pview
          ;
          pto::Shape<1, 1, 1, 1, -1> v330 = pto::Shape<1, 1, 1, 1, -1>(v325, v326, v327, v46, v247);
          // pto: %score_arena_inline3678__iter_v3_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v331 = pto::Stride<-1, -1, -1, -1, -1>(v326 * v329, v329, v328, v48, v46);
          // pto: %score_arena_inline3678__iter_v3_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v332 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v324 + (v323 + v321 * v48 + v322 * v46), v330, v331);
          TSTORE(v332, v319);
        };
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
        // pto: %4
        ;
        Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v333 = Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v61);
        // pto: %4
        ;
        uint64_t v334 = (uint64_t) v29;
        TASSIGN(v333, v334);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        for (int64_t v335 = v53; v335 < v66; v335 += v46) {
          // pto: %135
          ;
          const int64_t v336 = 1;
          // pto: %135
          ;
          const int64_t v337 = 0;
          // pto: %135
          ;
          int64_t v338 = v256 / v67;
          // pto: %135
          ;
          bool v339 = v256 < v337;
          // pto: %135
          ;
          bool v340 = v67 < v337;
          // pto: %135
          ;
          bool v341 = v339 == v340;
          // pto: %135
          ;
          bool v342 = v256 % v67 != v337 && v339 != v340;
          // pto: %135
          ;
          int64_t v343 = v342 ? v338 - v336 : v338;
          // pto: %136
          ;
          int64_t v344 = (int64_t) ((uint64_t) v343 + (uint64_t) v335);
          // pto: %137
          ;
          int64_t v345 = (int64_t) ((uint64_t) v177 - (uint64_t) v46);
          // pto: %138
          ;
          const int64_t v346 = 1;
          // pto: %138
          ;
          const int64_t v347 = 0;
          // pto: %138
          ;
          int64_t v348 = v345 / v67;
          // pto: %138
          ;
          bool v349 = v345 < v347;
          // pto: %138
          ;
          bool v350 = v67 < v347;
          // pto: %138
          ;
          bool v351 = v349 == v350;
          // pto: %138
          ;
          bool v352 = v345 % v67 != v347 && v349 != v350;
          // pto: %138
          ;
          int64_t v353 = v352 ? v348 - v346 : v348;
          // pto: %139
          ;
          int64_t v354 = v353 < v53 ? v53 : v353;
          // pto: %140
          ;
          int64_t v355 = v344 < v354 ? v344 : v354;
          // pto: %142, %143, %141
          ;
          int32_t v356 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v164 * (uint64_t) v17) + (uint64_t) v355)];
          // pto: %144
          ;
          int64_t v357 = (int64_t) v356;
          // pto: %145
          ;
          int64_t v358 = v357 < v53 ? v53 : v357;
          // pto: %147
          ;
          Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v359;
          // pto: %146, %147
          ;
          uint64_t v360 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v335 * (uint64_t) v50) + (uint64_t) v29);
          TASSIGN(v359, v360);
          // pto: %148
          ;
          int64_t v361 = v358 < v53 ? v53 : v358;
          // pto: %149
          ;
          int64_t v362 = (int64_t) v21;
          // pto: %149
          ;
          const int64_t v363 = 0;
          // pto: %149
          ;
          __gm__ int8_t* v364 = PTOAS__GLOBAL_TENSOR_DATA(v112);
          // pto: %149
          ;
          const int64_t v365 = 1;
          // pto: %149
          ;
          const int64_t v366 = 1;
          // pto: %149
          ;
          const int64_t v367 = 1;
          // pto: %149
          ;
          int64_t v368 = v46 * v362;
          // pto: %149
          ;
          int64_t v369 = v367 * v368;
          // pto: %149
          ;
          pto::Shape<1, 1, 1, 1, 64> v370 = pto::Shape<1, 1, 1, 1, 64>(v365, v366, v367, v46, v50);
          // pto: %149
          ;
          pto::Stride<-1, -1, -1, -1, -1> v371 = pto::Stride<-1, -1, -1, -1, -1>(v366 * v369, v369, v368, v362, v46);
          // pto: %149
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v372 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v364 + (v363 + v361 * v362 + v63 * v46), v370, v371);
          TLOAD(v359, v372);
        };
        // pto: %6
        ;
        Tile<TileType::Vec, half, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v373 = Tile<TileType::Vec, half, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %6
        ;
        uint64_t v374 = (uint64_t) v29;
        TASSIGN(v373, v374);
        // pto: %150
        ;
        const int32_t v375 = 64;
        // pto: %150
        ;
        const int32_t v376 = 192;
        // pto: %150
        ;
        Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v377 = Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v375, v376);
        TPOP<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_LEFT_RIGHT>(v122, v377);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %7
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v378 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %7
        ;
        uint64_t v379 = (uint64_t) v26;
        TASSIGN(v378, v379);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
        pipe_barrier(PIPE_V);
        RoundMode v380 = RoundMode::CAST_NONE;
        SaturationMode v381 = SaturationMode::ON;
        TCVT(v378, v377, v380, v381);
        TFREE<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, TileSplitAxis::TILE_LEFT_RIGHT>(v122);
        // pto: %8
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v382 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %8
        ;
        uint64_t v383 = (uint64_t) v26;
        TASSIGN(v382, v383);
        pipe_barrier(PIPE_V);
        TMAXS(v382, v378, v68);
        // pto: %9
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v384 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %9
        ;
        uint64_t v385 = (uint64_t) v26;
        TASSIGN(v384, v385);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v384, v382, v228);
        // pto: %10
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v386 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %10
        ;
        uint64_t v387 = (uint64_t) v26;
        TASSIGN(v386, v387);
        pipe_barrier(PIPE_V);
        TCOLSUM(v386, v384);
        // pto: %11
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v388 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %11
        ;
        uint64_t v389 = (uint64_t) v26;
        TASSIGN(v388, v389);
        // pto: %12
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v390 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %12
        ;
        uint64_t v391 = (uint64_t) v30;
        TASSIGN(v390, v391);
        pipe_barrier(PIPE_V);
        RoundMode v392 = RoundMode::CAST_ROUND;
        SaturationMode v393 = SaturationMode::ON;
        TCVT(v390, v373, v392, v393);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        // pto: %13
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v394 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %13
        ;
        uint64_t v395 = (uint64_t) v26;
        TASSIGN(v394, v395);
        pipe_barrier(PIPE_V);
        TMUL(v394, v388, v390);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        // pto: %151
        ;
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        if (v255 > v53) {
          v394.SetValidShape(v46, v255);
          // pto: %153
          ;
          int64_t v396 = v249 < v53 ? v53 : v249;
          // pto: %154
          ;
          int64_t v397 = v257 < v53 ? v53 : v257;
          // pto: %score_arena_inline3678__phi_v6_pview
          ;
          const int64_t v398 = 0;
          // pto: %score_arena_inline3678__phi_v6_pview
          ;
          __gm__ float* v399 = PTOAS__GLOBAL_TENSOR_DATA(v86);
          // pto: %score_arena_inline3678__phi_v6_pview
          ;
          const int64_t v400 = 1;
          // pto: %score_arena_inline3678__phi_v6_pview
          ;
          const int64_t v401 = 1;
          // pto: %score_arena_inline3678__phi_v6_pview
          ;
          const int64_t v402 = 1;
          // pto: %score_arena_inline3678__phi_v6_pview
          ;
          int64_t v403 = v46 * v48;
          // pto: %score_arena_inline3678__phi_v6_pview
          ;
          int64_t v404 = v402 * v403;
          // pto: %score_arena_inline3678__phi_v6_pview
          ;
          pto::Shape<1, 1, 1, 1, -1> v405 = pto::Shape<1, 1, 1, 1, -1>(v400, v401, v402, v46, v255);
          // pto: %score_arena_inline3678__phi_v6_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v406 = pto::Stride<-1, -1, -1, -1, -1>(v401 * v404, v404, v403, v48, v46);
          // pto: %score_arena_inline3678__phi_v6_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v407 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v399 + (v398 + v396 * v48 + v397 * v46), v405, v406);
          TSTORE(v407, v394);
        };
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      };
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
      // pto: %156
      ;
      const int64_t v408 = 1;
      // pto: %156
      ;
      const int64_t v409 = 0;
      // pto: %156
      ;
      int64_t v410 = v230 / v62;
      // pto: %156
      ;
      bool v411 = v230 < v409;
      // pto: %156
      ;
      bool v412 = v62 < v409;
      // pto: %156
      ;
      bool v413 = v411 == v412;
      // pto: %156
      ;
      bool v414 = v230 % v62 != v409 && v411 != v412;
      // pto: %156
      ;
      int64_t v415 = v414 ? v410 - v408 : v410;
      // pto: %160, %159, %161
      ;
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
      if ((int64_t) ((uint64_t) v415 - (uint64_t) ((int64_t) (uint64_t) v238 * (uint64_t) v65)) == v46) {
        // pto: %163, %162
        ;
        int64_t v416 = (int64_t) ((uint64_t) v239 * (uint64_t) ((int64_t) (uint64_t) v150 + (uint64_t) v46));
        // pto: %164
        ;
        int64_t v417 = (int64_t) v24;
        // pto: %165
        ;
        int64_t v418 = (int64_t) ((uint64_t) v417 * (uint64_t) v205);
        // pto: %166, %167
        ;
        int64_t v419 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v192 - (uint64_t) v416) - (uint64_t) v418);
        // pto: %168
        ;
        int64_t v420 = v419 < v62 ? v419 : v62;
        // pto: %169
        ;
        int64_t v421 = v420 < v53 ? v53 : v420;
        // pto: %170, %171
        ;
        int64_t v422 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v190 + (uint64_t) v416) + (uint64_t) v418);
        // pto: %15
        ;
        Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v423 = Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v61);
        // pto: %15
        ;
        uint64_t v424 = (uint64_t) v29;
        TASSIGN(v423, v424);
        for (int64_t v425 = v53; v425 < v66; v425 += v46) {
          // pto: %173
          ;
          const int64_t v426 = 1;
          // pto: %173
          ;
          const int64_t v427 = 0;
          // pto: %173
          ;
          int64_t v428 = v422 / v67;
          // pto: %173
          ;
          bool v429 = v422 < v427;
          // pto: %173
          ;
          bool v430 = v67 < v427;
          // pto: %173
          ;
          bool v431 = v429 == v430;
          // pto: %173
          ;
          bool v432 = v422 % v67 != v427 && v429 != v430;
          // pto: %173
          ;
          int64_t v433 = v432 ? v428 - v426 : v428;
          // pto: %174
          ;
          int64_t v434 = (int64_t) ((uint64_t) v433 + (uint64_t) v425);
          // pto: %175
          ;
          int64_t v435 = (int64_t) ((uint64_t) v177 - (uint64_t) v46);
          // pto: %176
          ;
          const int64_t v436 = 1;
          // pto: %176
          ;
          const int64_t v437 = 0;
          // pto: %176
          ;
          int64_t v438 = v435 / v67;
          // pto: %176
          ;
          bool v439 = v435 < v437;
          // pto: %176
          ;
          bool v440 = v67 < v437;
          // pto: %176
          ;
          bool v441 = v439 == v440;
          // pto: %176
          ;
          bool v442 = v435 % v67 != v437 && v439 != v440;
          // pto: %176
          ;
          int64_t v443 = v442 ? v438 - v436 : v438;
          // pto: %177
          ;
          int64_t v444 = v443 < v53 ? v53 : v443;
          // pto: %178
          ;
          int64_t v445 = v434 < v444 ? v434 : v444;
          // pto: %180, %181, %179
          ;
          int32_t v446 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v164 * (uint64_t) v17) + (uint64_t) v445)];
          // pto: %182
          ;
          int64_t v447 = (int64_t) v446;
          // pto: %183
          ;
          int64_t v448 = v447 < v53 ? v53 : v447;
          // pto: %185
          ;
          Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v449;
          // pto: %184, %185
          ;
          uint64_t v450 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v425 * (uint64_t) v50) + (uint64_t) v29);
          TASSIGN(v449, v450);
          // pto: %186
          ;
          int64_t v451 = v448 < v53 ? v53 : v448;
          // pto: %187
          ;
          int64_t v452 = (int64_t) v21;
          // pto: %187
          ;
          const int64_t v453 = 0;
          // pto: %187
          ;
          __gm__ int8_t* v454 = PTOAS__GLOBAL_TENSOR_DATA(v112);
          // pto: %187
          ;
          const int64_t v455 = 1;
          // pto: %187
          ;
          const int64_t v456 = 1;
          // pto: %187
          ;
          const int64_t v457 = 1;
          // pto: %187
          ;
          int64_t v458 = v46 * v452;
          // pto: %187
          ;
          int64_t v459 = v457 * v458;
          // pto: %187
          ;
          pto::Shape<1, 1, 1, 1, 64> v460 = pto::Shape<1, 1, 1, 1, 64>(v455, v456, v457, v46, v50);
          // pto: %187
          ;
          pto::Stride<-1, -1, -1, -1, -1> v461 = pto::Stride<-1, -1, -1, -1, -1>(v456 * v459, v459, v458, v452, v46);
          // pto: %187
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v462 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v454 + (v453 + v451 * v452 + v63 * v46), v460, v461);
          TLOAD(v449, v462);
        };
        // pto: %17
        ;
        Tile<TileType::Vec, half, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v463 = Tile<TileType::Vec, half, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %17
        ;
        uint64_t v464 = (uint64_t) v29;
        TASSIGN(v463, v464);
        // pto: %188
        ;
        const int32_t v465 = 64;
        // pto: %188
        ;
        const int32_t v466 = 192;
        // pto: %188
        ;
        Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v467 = Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v465, v466);
        TPOP<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_LEFT_RIGHT>(v122, v467);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        // pto: %18
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v468 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %18
        ;
        uint64_t v469 = (uint64_t) v26;
        TASSIGN(v468, v469);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        pipe_barrier(PIPE_V);
        RoundMode v470 = RoundMode::CAST_NONE;
        SaturationMode v471 = SaturationMode::ON;
        TCVT(v468, v467, v470, v471);
        TFREE<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, TileSplitAxis::TILE_LEFT_RIGHT>(v122);
        // pto: %19
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v472 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %19
        ;
        uint64_t v473 = (uint64_t) v26;
        TASSIGN(v472, v473);
        pipe_barrier(PIPE_V);
        TMAXS(v472, v468, v68);
        // pto: %20
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v474 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %20
        ;
        uint64_t v475 = (uint64_t) v26;
        TASSIGN(v474, v475);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v474, v472, v228);
        // pto: %21
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v476 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %21
        ;
        uint64_t v477 = (uint64_t) v26;
        TASSIGN(v476, v477);
        pipe_barrier(PIPE_V);
        TCOLSUM(v476, v474);
        // pto: %22
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v478 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %22
        ;
        uint64_t v479 = (uint64_t) v26;
        TASSIGN(v478, v479);
        // pto: %23
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v480 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %23
        ;
        uint64_t v481 = (uint64_t) v30;
        TASSIGN(v480, v481);
        pipe_barrier(PIPE_V);
        RoundMode v482 = RoundMode::CAST_ROUND;
        SaturationMode v483 = SaturationMode::ON;
        TCVT(v480, v463, v482, v483);
        // pto: %24
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v484 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %24
        ;
        uint64_t v485 = (uint64_t) v26;
        TASSIGN(v484, v485);
        pipe_barrier(PIPE_V);
        TMUL(v484, v478, v480);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        // pto: %189, %194, %193, %191, %192
        ;
        int64_t v486 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v150 * (uint64_t) v159) + (uint64_t) ((int64_t) (uint64_t) v204 * (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v417)));
        // pto: %196, %195, %199, %198
        ;
        int64_t v487 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v150 * (uint64_t) ((int64_t) (uint64_t) v416 + (uint64_t) v418)) + (uint64_t) ((int64_t) (uint64_t) v204 * (uint64_t) v239));
        // pto: %200
        ;
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        if (v421 > v53) {
          v484.SetValidShape(v46, v421);
          // pto: %202
          ;
          int64_t v488 = v486 < v53 ? v53 : v486;
          // pto: %203
          ;
          int64_t v489 = v487 < v53 ? v53 : v487;
          // pto: %score_arena_inline3678__rv_v4_main_pview
          ;
          const int64_t v490 = 0;
          // pto: %score_arena_inline3678__rv_v4_main_pview
          ;
          __gm__ float* v491 = PTOAS__GLOBAL_TENSOR_DATA(v86);
          // pto: %score_arena_inline3678__rv_v4_main_pview
          ;
          const int64_t v492 = 1;
          // pto: %score_arena_inline3678__rv_v4_main_pview
          ;
          const int64_t v493 = 1;
          // pto: %score_arena_inline3678__rv_v4_main_pview
          ;
          const int64_t v494 = 1;
          // pto: %score_arena_inline3678__rv_v4_main_pview
          ;
          int64_t v495 = v46 * v48;
          // pto: %score_arena_inline3678__rv_v4_main_pview
          ;
          int64_t v496 = v494 * v495;
          // pto: %score_arena_inline3678__rv_v4_main_pview
          ;
          pto::Shape<1, 1, 1, 1, -1> v497 = pto::Shape<1, 1, 1, 1, -1>(v492, v493, v494, v46, v421);
          // pto: %score_arena_inline3678__rv_v4_main_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v498 = pto::Stride<-1, -1, -1, -1, -1>(v493 * v496, v496, v495, v48, v46);
          // pto: %score_arena_inline3678__rv_v4_main_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v499 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v491 + (v490 + v488 * v48 + v489 * v46), v497, v498);
          TSTORE(v499, v484);
        };
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      // pto: %204
      ;
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      if (v150 == v53) {
        // pto: %sort_lane_inline3741__ssa_v0
        ;
        int64_t v500 = (int64_t) v24;
        // pto: %205
        ;
        int64_t v501 = (int64_t) ((uint64_t) v500 * (uint64_t) v203);
        // pto: %208
        ;
        int64_t v502 = (int64_t) ((uint64_t) v192 - (uint64_t) v501);
        // pto: %209
        ;
        int64_t v503 = v502 < v203 ? v502 : v203;
        // pto: %210
        ;
        int64_t v504 = v503 < v53 ? v53 : v503;
        // pto: %213, %212, %214
        ;
        int64_t v505 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v206 + (uint64_t) ((int64_t) (uint64_t) v162 * (uint64_t) v65)) + (uint64_t) v500);
        // pto: %215
        ;
        if (v504 > v53) {
          // pto: %206, %216
          ;
          int32_t v506 = (int32_t) ((int64_t) (uint64_t) v190 + (uint64_t) v501);
          // pto: %217
          ;
          if (v504 <= v69) {
            // pto: %t__ci_tmp_v0
            ;
            Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v507 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
            // pto: %t__ci_tmp_v0
            ;
            uint64_t v508 = (uint64_t) v31;
            TASSIGN(v507, v508);
            // pto: %t__tmp_v849
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v509 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v69);
            // pto: %t__tmp_v849
            ;
            uint64_t v510 = (uint64_t) v26;
            TASSIGN(v509, v510);
            // pto: %ci_tmp_view
            ;
            Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v511;
            TRESHAPE(v511, v507);
            // pto: %ci_dst_view
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v512;
            TRESHAPE(v512, v509);
            pipe_barrier(PIPE_V);
            TCI<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v512, v52, v511);
            // pto: %short_indices_inline4941__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v513 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v69);
            // pto: %short_indices_inline4941__ssa_v0
            ;
            uint64_t v514 = (uint64_t) v32;
            TASSIGN(v513, v514);
            pipe_barrier(PIPE_V);
            TADDS(v513, v509, v506);
            set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
            // pto: %short_raw_inline4942__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v515 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v504);
            // pto: %short_raw_inline4942__ssa_v0
            ;
            uint64_t v516 = (uint64_t) v26;
            TASSIGN(v515, v516);
            // pto: %218, %219
            ;
            int64_t v517 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v500);
            // pto: %220
            ;
            int64_t v518 = v517 < v53 ? v53 : v517;
            // pto: %score_arena_inline3678__rv_v4_pview
            ;
            const int64_t v519 = 0;
            // pto: %score_arena_inline3678__rv_v4_pview
            ;
            __gm__ float* v520 = PTOAS__GLOBAL_TENSOR_DATA(v86);
            // pto: %score_arena_inline3678__rv_v4_pview
            ;
            const int64_t v521 = 1;
            // pto: %score_arena_inline3678__rv_v4_pview
            ;
            const int64_t v522 = 1;
            // pto: %score_arena_inline3678__rv_v4_pview
            ;
            const int64_t v523 = 1;
            // pto: %score_arena_inline3678__rv_v4_pview
            ;
            int64_t v524 = v46 * v48;
            // pto: %score_arena_inline3678__rv_v4_pview
            ;
            int64_t v525 = v523 * v524;
            // pto: %score_arena_inline3678__rv_v4_pview
            ;
            pto::Shape<1, 1, 1, 1, -1> v526 = pto::Shape<1, 1, 1, 1, -1>(v521, v522, v523, v46, v504);
            // pto: %score_arena_inline3678__rv_v4_pview
            ;
            pto::Stride<-1, -1, -1, -1, -1> v527 = pto::Stride<-1, -1, -1, -1, -1>(v522 * v525, v525, v524, v48, v46);
            // pto: %score_arena_inline3678__rv_v4_pview
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v528 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v520 + (v519 + v518 * v48 + v53 * v46), v526, v527);
            wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
            TLOAD(v515, v528);
            set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
            // pto: %short_scores_inline4943__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v529 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v69);
            // pto: %short_scores_inline4943__ssa_v0
            ;
            uint64_t v530 = (uint64_t) v26;
            TASSIGN(v529, v530);
            wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
            TFILLPAD<pto::TFillPadMode::InPlace>(v529, v515);
            // pto: %short_scores_v1_inline4944__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v531 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v69);
            // pto: %short_scores_v1_inline4944__ssa_v0
            ;
            uint64_t v532 = (uint64_t) v33;
            TASSIGN(v531, v532);
            pipe_barrier(PIPE_V);
            TMAXS(v531, v529, v70);
            // pto: %t__tmp_v850
            ;
            Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v533 = Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v69);
            // pto: %t__tmp_v850
            ;
            uint64_t v534 = (uint64_t) v32;
            TASSIGN(v533, v534);
            // pto: %short_pairs_inline4945__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v535 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
            // pto: %short_pairs_inline4945__ssa_v0
            ;
            uint64_t v536 = (uint64_t) v26;
            TASSIGN(v535, v536);
            // pto: %sort32_src_view
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v537;
            TRESHAPE(v537, v531);
            // pto: %sort32_idx_view
            ;
            Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v538;
            TRESHAPE(v538, v533);
            // pto: %sort32_dst_view
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v539;
            TRESHAPE(v539, v535);
            pipe_barrier(PIPE_V);
            TSORT32(v539, v537, v538);
            // pto: %short_pairs_v1_inline4946__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v540 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
            // pto: %short_pairs_v1_inline4946__ssa_v0
            ;
            uint64_t v541 = (uint64_t) v32;
            TASSIGN(v540, v541);
            pipe_barrier(PIPE_V);
            TMRGSORT(v540, v535, v71);
            // pto: %short_pairs_v2_inline4947__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v542 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
            // pto: %short_pairs_v2_inline4947__ssa_v0
            ;
            uint64_t v543 = (uint64_t) v26;
            TASSIGN(v542, v543);
            pipe_barrier(PIPE_V);
            TMRGSORT(v542, v540, v72);
            set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
            // pto: %221
            ;
            int64_t v544 = v505 < v53 ? v53 : v505;
            // pto: %pair_arena_inline3677__ssa_v0_pview
            ;
            __gm__ float* v545 = PTOAS__GLOBAL_TENSOR_DATA(v120);
            // pto: %pair_arena_inline3677__ssa_v0_pview
            ;
            const int64_t v546 = 0;
            // pto: %pair_arena_inline3677__ssa_v0_pview
            ;
            const int64_t v547 = 1024;
            // pto: %pair_arena_inline3677__ssa_v0_pview
            ;
            pto::Shape<1, 1, 1, 1, 1024> v548 = pto::Shape<1, 1, 1, 1, 1024>();
            // pto: %pair_arena_inline3677__ssa_v0_pview
            ;
            pto::Stride<1024, 1024, 1024, 1024, 1> v549 = pto::Stride<1024, 1024, 1024, 1024, 1>();
            // pto: %pair_arena_inline3677__ssa_v0_pview
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v550 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v545 + (v546 + v544 * v547), v548, v549);
            wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
            pipe_barrier(PIPE_MTE3);
            TSTORE(v550, v542);
          } else {
            // pto: %222
            ;
            if (v504 <= v51) {
              // pto: %t__ci_tmp_v1
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v551 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
              // pto: %t__ci_tmp_v1
              ;
              uint64_t v552 = (uint64_t) v32;
              TASSIGN(v551, v552);
              // pto: %t__tmp_v851
              ;
              Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v553 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v51);
              // pto: %t__tmp_v851
              ;
              uint64_t v554 = (uint64_t) v26;
              TASSIGN(v553, v554);
              // pto: %223
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v555;
              TRESHAPE(v555, v551);
              // pto: %224
              ;
              Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v556;
              TRESHAPE(v556, v553);
              pipe_barrier(PIPE_V);
              TCI<Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v556, v52, v555);
              // pto: %small_indices_inline4948__ssa_v0
              ;
              Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v557 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v51);
              // pto: %small_indices_inline4948__ssa_v0
              ;
              uint64_t v558 = (uint64_t) v34;
              TASSIGN(v557, v558);
              pipe_barrier(PIPE_V);
              TADDS(v557, v553, v506);
              set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
              // pto: %small_raw_inline4949__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v559 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v504);
              // pto: %small_raw_inline4949__ssa_v0
              ;
              uint64_t v560 = (uint64_t) v26;
              TASSIGN(v559, v560);
              // pto: %225, %226
              ;
              int64_t v561 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v500);
              // pto: %227
              ;
              int64_t v562 = v561 < v53 ? v53 : v561;
              // pto: %228
              ;
              const int64_t v563 = 0;
              // pto: %228
              ;
              __gm__ float* v564 = PTOAS__GLOBAL_TENSOR_DATA(v86);
              // pto: %228
              ;
              const int64_t v565 = 1;
              // pto: %228
              ;
              const int64_t v566 = 1;
              // pto: %228
              ;
              const int64_t v567 = 1;
              // pto: %228
              ;
              int64_t v568 = v46 * v48;
              // pto: %228
              ;
              int64_t v569 = v567 * v568;
              // pto: %228
              ;
              pto::Shape<1, 1, 1, 1, -1> v570 = pto::Shape<1, 1, 1, 1, -1>(v565, v566, v567, v46, v504);
              // pto: %228
              ;
              pto::Stride<-1, -1, -1, -1, -1> v571 = pto::Stride<-1, -1, -1, -1, -1>(v566 * v569, v569, v568, v48, v46);
              // pto: %228
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v572 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v564 + (v563 + v562 * v48 + v53 * v46), v570, v571);
              wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
              TLOAD(v559, v572);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
              // pto: %small_scores_inline4950__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v573 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
              // pto: %small_scores_inline4950__ssa_v0
              ;
              uint64_t v574 = (uint64_t) v26;
              TASSIGN(v573, v574);
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
              TFILLPAD<pto::TFillPadMode::InPlace>(v573, v559);
              // pto: %small_scores_v1_inline4951__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v575 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
              // pto: %small_scores_v1_inline4951__ssa_v0
              ;
              uint64_t v576 = (uint64_t) v35;
              TASSIGN(v575, v576);
              pipe_barrier(PIPE_V);
              TMAXS(v575, v573, v70);
              // pto: %t__tmp_v852
              ;
              Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v577 = Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v51);
              // pto: %t__tmp_v852
              ;
              uint64_t v578 = (uint64_t) v34;
              TASSIGN(v577, v578);
              // pto: %small_pairs_inline4952__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v579 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
              // pto: %small_pairs_inline4952__ssa_v0
              ;
              uint64_t v580 = (uint64_t) v26;
              TASSIGN(v579, v580);
              // pto: %229
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v581;
              TRESHAPE(v581, v575);
              // pto: %230
              ;
              Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v582;
              TRESHAPE(v582, v577);
              // pto: %231
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v583;
              TRESHAPE(v583, v579);
              pipe_barrier(PIPE_V);
              TSORT32(v583, v581, v582);
              // pto: %small_pairs_v1_inline4953__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v584 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
              // pto: %small_pairs_v1_inline4953__ssa_v0
              ;
              uint64_t v585 = (uint64_t) v34;
              TASSIGN(v584, v585);
              pipe_barrier(PIPE_V);
              TMRGSORT(v584, v579, v71);
              // pto: %small_pairs_v2_inline4954__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v586 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
              // pto: %small_pairs_v2_inline4954__ssa_v0
              ;
              uint64_t v587 = (uint64_t) v26;
              TASSIGN(v586, v587);
              pipe_barrier(PIPE_V);
              TMRGSORT(v586, v584, v72);
              // pto: %small_left_inline4955__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v588 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
              // pto: %small_left_inline4955__ssa_v0
              ;
              uint64_t v589 = (uint64_t) v26;
              TASSIGN(v588, v589);
              // pto: %slice_view
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v590;
              // pto: %slice_view
              ;
              uint64_t v591 = (uint64_t) v26;
              TASSIGN(v590, v591);
              // pto: %small_right_inline4956__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v592 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
              // pto: %small_right_inline4956__ssa_v0
              ;
              uint64_t v593 = (uint64_t) v32;
              TASSIGN(v592, v593);
              // pto: %232
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v594;
              // pto: %232
              ;
              uint64_t v595 = (uint64_t) v32;
              TASSIGN(v594, v595);
              // pto: %small_tmp_inline4957__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v596 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v73);
              // pto: %small_tmp_inline4957__ssa_v0
              ;
              uint64_t v597 = (uint64_t) v34;
              TASSIGN(v596, v597);
              // pto: %small_merged_inline4958__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v598 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
              // pto: %small_merged_inline4958__ssa_v0
              ;
              uint64_t v599 = (uint64_t) v36;
              TASSIGN(v598, v599);
              pipe_barrier(PIPE_V);
              TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v598, v25, v596, v590, v594);
              set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
              // pto: %small_top_inline4959__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v600 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
              // pto: %small_top_inline4959__ssa_v0
              ;
              uint64_t v601 = (uint64_t) v36;
              TASSIGN(v600, v601);
              // pto: %233
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v602;
              // pto: %233
              ;
              uint64_t v603 = (uint64_t) v36;
              TASSIGN(v602, v603);
              // pto: %234
              ;
              int64_t v604 = v505 < v53 ? v53 : v505;
              // pto: %235
              ;
              __gm__ float* v605 = PTOAS__GLOBAL_TENSOR_DATA(v120);
              // pto: %235
              ;
              const int64_t v606 = 0;
              // pto: %235
              ;
              const int64_t v607 = 1024;
              // pto: %235
              ;
              pto::Shape<1, 1, 1, 1, 1024> v608 = pto::Shape<1, 1, 1, 1, 1024>();
              // pto: %235
              ;
              pto::Stride<1024, 1024, 1024, 1024, 1> v609 = pto::Stride<1024, 1024, 1024, 1024, 1>();
              // pto: %235
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v610 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v605 + (v606 + v604 * v607), v608, v609);
              wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
              pipe_barrier(PIPE_MTE3);
              TSTORE(v610, v602);
            } else {
              // pto: %236
              ;
              if (v504 <= v73) {
                // pto: %t__ci_tmp_v2
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v611 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
                // pto: %t__ci_tmp_v2
                ;
                uint64_t v612 = (uint64_t) v34;
                TASSIGN(v611, v612);
                // pto: %t__tmp_v853
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v613 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v73);
                // pto: %t__tmp_v853
                ;
                uint64_t v614 = (uint64_t) v26;
                TASSIGN(v613, v614);
                // pto: %237
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v615;
                TRESHAPE(v615, v611);
                // pto: %238
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v616;
                TRESHAPE(v616, v613);
                pipe_barrier(PIPE_V);
                TCI<Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v616, v52, v615);
                // pto: %leaf_indices_inline4960__ssa_v0
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v617 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v73);
                // pto: %leaf_indices_inline4960__ssa_v0
                ;
                uint64_t v618 = (uint64_t) v36;
                TASSIGN(v617, v618);
                pipe_barrier(PIPE_V);
                TADDS(v617, v613, v506);
                set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
                // pto: %leaf_scores_raw_inline4961__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v619 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v504);
                // pto: %leaf_scores_raw_inline4961__ssa_v0
                ;
                uint64_t v620 = (uint64_t) v26;
                TASSIGN(v619, v620);
                // pto: %239, %240
                ;
                int64_t v621 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v500);
                // pto: %241
                ;
                int64_t v622 = v621 < v53 ? v53 : v621;
                // pto: %242
                ;
                const int64_t v623 = 0;
                // pto: %242
                ;
                __gm__ float* v624 = PTOAS__GLOBAL_TENSOR_DATA(v86);
                // pto: %242
                ;
                const int64_t v625 = 1;
                // pto: %242
                ;
                const int64_t v626 = 1;
                // pto: %242
                ;
                const int64_t v627 = 1;
                // pto: %242
                ;
                int64_t v628 = v46 * v48;
                // pto: %242
                ;
                int64_t v629 = v627 * v628;
                // pto: %242
                ;
                pto::Shape<1, 1, 1, 1, -1> v630 = pto::Shape<1, 1, 1, 1, -1>(v625, v626, v627, v46, v504);
                // pto: %242
                ;
                pto::Stride<-1, -1, -1, -1, -1> v631 = pto::Stride<-1, -1, -1, -1, -1>(v626 * v629, v629, v628, v48, v46);
                // pto: %242
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v632 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v624 + (v623 + v622 * v48 + v53 * v46), v630, v631);
                wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
                TLOAD(v619, v632);
                set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
                // pto: %leaf_scores_inline4962__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v633 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
                // pto: %leaf_scores_inline4962__ssa_v0
                ;
                uint64_t v634 = (uint64_t) v26;
                TASSIGN(v633, v634);
                wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
                TFILLPAD<pto::TFillPadMode::InPlace>(v633, v619);
                // pto: %leaf_scores_v1_inline4963__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v635 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
                // pto: %leaf_scores_v1_inline4963__ssa_v0
                ;
                uint64_t v636 = (uint64_t) v37;
                TASSIGN(v635, v636);
                pipe_barrier(PIPE_V);
                TMAXS(v635, v633, v70);
                // pto: %t__tmp_v854
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v637 = Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v73);
                // pto: %t__tmp_v854
                ;
                uint64_t v638 = (uint64_t) v36;
                TASSIGN(v637, v638);
                // pto: %pairs_inline4964__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v639 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v63);
                // pto: %pairs_inline4964__ssa_v0
                ;
                uint64_t v640 = (uint64_t) v26;
                TASSIGN(v639, v640);
                // pto: %243
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v641;
                TRESHAPE(v641, v635);
                // pto: %244
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v642;
                TRESHAPE(v642, v637);
                // pto: %245
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v643;
                TRESHAPE(v643, v639);
                pipe_barrier(PIPE_V);
                TSORT32(v643, v641, v642);
                // pto: %pairs_v1_inline4965__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v644 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v63);
                // pto: %pairs_v1_inline4965__ssa_v0
                ;
                uint64_t v645 = (uint64_t) v36;
                TASSIGN(v644, v645);
                pipe_barrier(PIPE_V);
                TMRGSORT(v644, v639, v71);
                // pto: %pairs_v2_inline4966__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v646 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v63);
                // pto: %pairs_v2_inline4966__ssa_v0
                ;
                uint64_t v647 = (uint64_t) v26;
                TASSIGN(v646, v647);
                pipe_barrier(PIPE_V);
                TMRGSORT(v646, v644, v72);
                // pto: %pairs_v3_inline4967__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v648 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v63);
                // pto: %pairs_v3_inline4967__ssa_v0
                ;
                uint64_t v649 = (uint64_t) v36;
                TASSIGN(v648, v649);
                pipe_barrier(PIPE_V);
                TMRGSORT(v648, v646, v74);
                set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
                // pto: %t__tmp_v855
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v650 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                // pto: %t__tmp_v855
                ;
                uint64_t v651 = (uint64_t) v36;
                TASSIGN(v650, v651);
                // pto: %246
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v652;
                // pto: %246
                ;
                uint64_t v653 = (uint64_t) v36;
                TASSIGN(v652, v653);
                // pto: %247
                ;
                int64_t v654 = v505 < v53 ? v53 : v505;
                // pto: %248
                ;
                __gm__ float* v655 = PTOAS__GLOBAL_TENSOR_DATA(v120);
                // pto: %248
                ;
                const int64_t v656 = 0;
                // pto: %248
                ;
                const int64_t v657 = 1024;
                // pto: %248
                ;
                pto::Shape<1, 1, 1, 1, 1024> v658 = pto::Shape<1, 1, 1, 1, 1024>();
                // pto: %248
                ;
                pto::Stride<1024, 1024, 1024, 1024, 1> v659 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                // pto: %248
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v660 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v655 + (v656 + v654 * v657), v658, v659);
                wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
                pipe_barrier(PIPE_MTE3);
                TSTORE(v660, v652);
              } else {
                // pto: %249
                ;
                if (v504 <= v75) {
                  // pto: %t__ci_tmp_v3
                  ;
                  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v661 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
                  // pto: %t__ci_tmp_v3
                  ;
                  uint64_t v662 = (uint64_t) v38;
                  TASSIGN(v661, v662);
                  // pto: %t__tmp_v856
                  ;
                  Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v663 = Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v75);
                  // pto: %t__tmp_v856
                  ;
                  uint64_t v664 = (uint64_t) v26;
                  TASSIGN(v663, v664);
                  // pto: %250
                  ;
                  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v665;
                  TRESHAPE(v665, v661);
                  // pto: %251
                  ;
                  Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v666;
                  TRESHAPE(v666, v663);
                  pipe_barrier(PIPE_V);
                  TCI<Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v666, v52, v665);
                  // pto: %partial_indices_inline4968__ssa_v0
                  ;
                  Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v667 = Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v75);
                  // pto: %partial_indices_inline4968__ssa_v0
                  ;
                  uint64_t v668 = (uint64_t) v39;
                  TASSIGN(v667, v668);
                  pipe_barrier(PIPE_V);
                  TADDS(v667, v663, v506);
                  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
                  // pto: %partial_raw_inline4969__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v669 = Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v504);
                  // pto: %partial_raw_inline4969__ssa_v0
                  ;
                  uint64_t v670 = (uint64_t) v26;
                  TASSIGN(v669, v670);
                  // pto: %252, %253
                  ;
                  int64_t v671 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v500);
                  // pto: %254
                  ;
                  int64_t v672 = v671 < v53 ? v53 : v671;
                  // pto: %255
                  ;
                  const int64_t v673 = 0;
                  // pto: %255
                  ;
                  __gm__ float* v674 = PTOAS__GLOBAL_TENSOR_DATA(v86);
                  // pto: %255
                  ;
                  const int64_t v675 = 1;
                  // pto: %255
                  ;
                  const int64_t v676 = 1;
                  // pto: %255
                  ;
                  const int64_t v677 = 1;
                  // pto: %255
                  ;
                  int64_t v678 = v46 * v48;
                  // pto: %255
                  ;
                  int64_t v679 = v677 * v678;
                  // pto: %255
                  ;
                  pto::Shape<1, 1, 1, 1, -1> v680 = pto::Shape<1, 1, 1, 1, -1>(v675, v676, v677, v46, v504);
                  // pto: %255
                  ;
                  pto::Stride<-1, -1, -1, -1, -1> v681 = pto::Stride<-1, -1, -1, -1, -1>(v676 * v679, v679, v678, v48, v46);
                  // pto: %255
                  ;
                  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v682 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v674 + (v673 + v672 * v48 + v53 * v46), v680, v681);
                  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
                  TLOAD(v669, v682);
                  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
                  // pto: %partial_scores_inline4970__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v683 = Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v75);
                  // pto: %partial_scores_inline4970__ssa_v0
                  ;
                  uint64_t v684 = (uint64_t) v26;
                  TASSIGN(v683, v684);
                  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
                  TFILLPAD<pto::TFillPadMode::InPlace>(v683, v669);
                  // pto: %partial_scores_v1_inline4971__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v685 = Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v75);
                  // pto: %partial_scores_v1_inline4971__ssa_v0
                  ;
                  uint64_t v686 = (uint64_t) v40;
                  TASSIGN(v685, v686);
                  pipe_barrier(PIPE_V);
                  TMAXS(v685, v683, v70);
                  // pto: %t__tmp_v857
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v687 = Tile<TileType::Vec, uint32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v75);
                  // pto: %t__tmp_v857
                  ;
                  uint64_t v688 = (uint64_t) v39;
                  TASSIGN(v687, v688);
                  // pto: %partial_pairs_inline4972__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v689 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v76);
                  // pto: %partial_pairs_inline4972__ssa_v0
                  ;
                  uint64_t v690 = (uint64_t) v26;
                  TASSIGN(v689, v690);
                  // pto: %256
                  ;
                  Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v691;
                  TRESHAPE(v691, v685);
                  // pto: %257
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v692;
                  TRESHAPE(v692, v687);
                  // pto: %258
                  ;
                  Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 5120, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v693;
                  TRESHAPE(v693, v689);
                  pipe_barrier(PIPE_V);
                  TSORT32(v693, v691, v692);
                  // pto: %partial_pairs_v1_inline4973__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v694 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v76);
                  // pto: %partial_pairs_v1_inline4973__ssa_v0
                  ;
                  uint64_t v695 = (uint64_t) v39;
                  TASSIGN(v694, v695);
                  pipe_barrier(PIPE_V);
                  TMRGSORT(v694, v689, v71);
                  // pto: %partial_pairs_v2_inline4974__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v696 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v76);
                  // pto: %partial_pairs_v2_inline4974__ssa_v0
                  ;
                  uint64_t v697 = (uint64_t) v26;
                  TASSIGN(v696, v697);
                  pipe_barrier(PIPE_V);
                  TMRGSORT(v696, v694, v72);
                  v696.SetValidShape(v46, v63);
                  // pto: %partial_prefix_v1_inline4976__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v698 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v76);
                  // pto: %partial_prefix_v1_inline4976__ssa_v0
                  ;
                  uint64_t v699 = (uint64_t) v39;
                  TASSIGN(v698, v699);
                  pipe_barrier(PIPE_V);
                  TMRGSORT(v698, v696, v74);
                  // pto: %partial_left_inline4977__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v700 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                  // pto: %partial_left_inline4977__ssa_v0
                  ;
                  uint64_t v701 = (uint64_t) v39;
                  TASSIGN(v700, v701);
                  // pto: %259
                  ;
                  Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v702;
                  // pto: %259
                  ;
                  uint64_t v703 = (uint64_t) v39;
                  TASSIGN(v702, v703);
                  // pto: %partial_right_inline4978__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v704 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                  // pto: %partial_right_inline4978__ssa_v0
                  ;
                  uint64_t v705 = (uint64_t) v36;
                  TASSIGN(v704, v705);
                  // pto: %260
                  ;
                  Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v706;
                  // pto: %260
                  ;
                  uint64_t v707 = (uint64_t) v36;
                  TASSIGN(v706, v707);
                  // pto: %partial_tmp_inline4979__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v708 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v73);
                  // pto: %partial_tmp_inline4979__ssa_v0
                  ;
                  uint64_t v709 = (uint64_t) v41;
                  TASSIGN(v708, v709);
                  // pto: %partial_merged_inline4980__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v710 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
                  // pto: %partial_merged_inline4980__ssa_v0
                  ;
                  uint64_t v711 = (uint64_t) v29;
                  TASSIGN(v710, v711);
                  pipe_barrier(PIPE_V);
                  TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v710, v25, v708, v706, v702);
                  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
                  // pto: %t__tmp_v858
                  ;
                  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v712 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                  // pto: %t__tmp_v858
                  ;
                  uint64_t v713 = (uint64_t) v29;
                  TASSIGN(v712, v713);
                  // pto: %262
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v714;
                  // pto: %262
                  ;
                  uint64_t v715 = (uint64_t) v29;
                  TASSIGN(v714, v715);
                  // pto: %263
                  ;
                  int64_t v716 = v505 < v53 ? v53 : v505;
                  // pto: %264
                  ;
                  __gm__ float* v717 = PTOAS__GLOBAL_TENSOR_DATA(v120);
                  // pto: %264
                  ;
                  const int64_t v718 = 0;
                  // pto: %264
                  ;
                  const int64_t v719 = 1024;
                  // pto: %264
                  ;
                  pto::Shape<1, 1, 1, 1, 1024> v720 = pto::Shape<1, 1, 1, 1, 1024>();
                  // pto: %264
                  ;
                  pto::Stride<1024, 1024, 1024, 1024, 1> v721 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                  // pto: %264
                  ;
                  GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v722 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v717 + (v718 + v716 * v719), v720, v721);
                  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
                  pipe_barrier(PIPE_MTE3);
                  TSTORE(v722, v714);
                } else {
                  // pto: %265
                  ;
                  if (v504 <= v77) {
                    // pto: %t__ci_tmp_v4
                    ;
                    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v723 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
                    // pto: %t__ci_tmp_v4
                    ;
                    uint64_t v724 = (uint64_t) v35;
                    TASSIGN(v723, v724);
                    // pto: %t__tmp_v859
                    ;
                    Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v725 = Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v77);
                    // pto: %t__tmp_v859
                    ;
                    uint64_t v726 = (uint64_t) v26;
                    TASSIGN(v725, v726);
                    // pto: %266
                    ;
                    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v727;
                    TRESHAPE(v727, v723);
                    // pto: %267
                    ;
                    Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v728;
                    TRESHAPE(v728, v725);
                    pipe_barrier(PIPE_V);
                    TCI<Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v728, v52, v727);
                    // pto: %triple_indices_inline4981__ssa_v0
                    ;
                    Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v729 = Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v77);
                    // pto: %triple_indices_inline4981__ssa_v0
                    ;
                    uint64_t v730 = (uint64_t) v37;
                    TASSIGN(v729, v730);
                    pipe_barrier(PIPE_V);
                    TADDS(v729, v725, v506);
                    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                    // pto: %triple_raw_inline4982__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v731 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v504);
                    // pto: %triple_raw_inline4982__ssa_v0
                    ;
                    uint64_t v732 = (uint64_t) v26;
                    TASSIGN(v731, v732);
                    // pto: %268, %269
                    ;
                    int64_t v733 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v500);
                    // pto: %270
                    ;
                    int64_t v734 = v733 < v53 ? v53 : v733;
                    // pto: %271
                    ;
                    const int64_t v735 = 0;
                    // pto: %271
                    ;
                    __gm__ float* v736 = PTOAS__GLOBAL_TENSOR_DATA(v86);
                    // pto: %271
                    ;
                    const int64_t v737 = 1;
                    // pto: %271
                    ;
                    const int64_t v738 = 1;
                    // pto: %271
                    ;
                    const int64_t v739 = 1;
                    // pto: %271
                    ;
                    int64_t v740 = v46 * v48;
                    // pto: %271
                    ;
                    int64_t v741 = v739 * v740;
                    // pto: %271
                    ;
                    pto::Shape<1, 1, 1, 1, -1> v742 = pto::Shape<1, 1, 1, 1, -1>(v737, v738, v739, v46, v504);
                    // pto: %271
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v743 = pto::Stride<-1, -1, -1, -1, -1>(v738 * v741, v741, v740, v48, v46);
                    // pto: %271
                    ;
                    GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v744 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v736 + (v735 + v734 * v48 + v53 * v46), v742, v743);
                    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                    TLOAD(v731, v744);
                    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                    // pto: %triple_scores_inline4983__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v745 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v77);
                    // pto: %triple_scores_inline4983__ssa_v0
                    ;
                    uint64_t v746 = (uint64_t) v26;
                    TASSIGN(v745, v746);
                    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                    TFILLPAD<pto::TFillPadMode::InPlace>(v745, v731);
                    // pto: %triple_scores_v1_inline4984__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v747 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v77);
                    // pto: %triple_scores_v1_inline4984__ssa_v0
                    ;
                    uint64_t v748 = (uint64_t) v42;
                    TASSIGN(v747, v748);
                    pipe_barrier(PIPE_V);
                    TMAXS(v747, v745, v70);
                    // pto: %t__tmp_v860
                    ;
                    Tile<TileType::Vec, uint32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v749 = Tile<TileType::Vec, uint32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v77);
                    // pto: %t__tmp_v860
                    ;
                    uint64_t v750 = (uint64_t) v37;
                    TASSIGN(v749, v750);
                    // pto: %triple_pairs_inline4985__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v751 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v78);
                    // pto: %triple_pairs_inline4985__ssa_v0
                    ;
                    uint64_t v752 = (uint64_t) v26;
                    TASSIGN(v751, v752);
                    // pto: %272
                    ;
                    Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v753;
                    TRESHAPE(v753, v747);
                    // pto: %273
                    ;
                    Tile<TileType::Vec, uint32_t, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v754;
                    TRESHAPE(v754, v749);
                    // pto: %274
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 6144, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v755;
                    TRESHAPE(v755, v751);
                    pipe_barrier(PIPE_V);
                    TSORT32(v755, v753, v754);
                    // pto: %triple_pairs_v1_inline4986__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v756 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v78);
                    // pto: %triple_pairs_v1_inline4986__ssa_v0
                    ;
                    uint64_t v757 = (uint64_t) v37;
                    TASSIGN(v756, v757);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v756, v751, v71);
                    // pto: %triple_pairs_v2_inline4987__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v758 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v78);
                    // pto: %triple_pairs_v2_inline4987__ssa_v0
                    ;
                    uint64_t v759 = (uint64_t) v26;
                    TASSIGN(v758, v759);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v758, v756, v72);
                    v758.SetValidShape(v46, v63);
                    // pto: %triple_prefix_v1_inline4989__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v760 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v78);
                    // pto: %triple_prefix_v1_inline4989__ssa_v0
                    ;
                    uint64_t v761 = (uint64_t) v37;
                    TASSIGN(v760, v761);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v760, v758, v74);
                    // pto: %triple_left_inline4990__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v762 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                    // pto: %triple_left_inline4990__ssa_v0
                    ;
                    uint64_t v763 = (uint64_t) v37;
                    TASSIGN(v762, v763);
                    // pto: %275
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v764;
                    // pto: %275
                    ;
                    uint64_t v765 = (uint64_t) v37;
                    TASSIGN(v764, v765);
                    // pto: %triple_right0_inline4991__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v766 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                    // pto: %triple_right0_inline4991__ssa_v0
                    ;
                    uint64_t v767 = (uint64_t) v36;
                    TASSIGN(v766, v767);
                    // pto: %276
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v768;
                    // pto: %276
                    ;
                    uint64_t v769 = (uint64_t) v36;
                    TASSIGN(v768, v769);
                    // pto: %triple_right1_inline4992__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v770 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                    // pto: %triple_right1_inline4992__ssa_v0
                    ;
                    uint64_t v771 = (uint64_t) v39;
                    TASSIGN(v770, v771);
                    // pto: %277
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v772;
                    // pto: %277
                    ;
                    uint64_t v773 = (uint64_t) v39;
                    TASSIGN(v772, v773);
                    // pto: %triple_tmp_inline4993__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v774 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v77);
                    // pto: %triple_tmp_inline4993__ssa_v0
                    ;
                    uint64_t v775 = (uint64_t) v29;
                    TASSIGN(v774, v775);
                    // pto: %triple_merged_inline4994__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v776 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v77);
                    // pto: %triple_merged_inline4994__ssa_v0
                    ;
                    uint64_t v777 = (uint64_t) v43;
                    TASSIGN(v776, v777);
                    pipe_barrier(PIPE_V);
                    TMRGSORT<Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v776, v25, v774, v768, v772, v764);
                    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
                    // pto: %t__tmp_v861
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v778 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                    // pto: %t__tmp_v861
                    ;
                    uint64_t v779 = (uint64_t) v43;
                    TASSIGN(v778, v779);
                    // pto: %279
                    ;
                    Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v780;
                    // pto: %279
                    ;
                    uint64_t v781 = (uint64_t) v43;
                    TASSIGN(v780, v781);
                    // pto: %280
                    ;
                    int64_t v782 = v505 < v53 ? v53 : v505;
                    // pto: %281
                    ;
                    __gm__ float* v783 = PTOAS__GLOBAL_TENSOR_DATA(v120);
                    // pto: %281
                    ;
                    const int64_t v784 = 0;
                    // pto: %281
                    ;
                    const int64_t v785 = 1024;
                    // pto: %281
                    ;
                    pto::Shape<1, 1, 1, 1, 1024> v786 = pto::Shape<1, 1, 1, 1, 1024>();
                    // pto: %281
                    ;
                    pto::Stride<1024, 1024, 1024, 1024, 1> v787 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                    // pto: %281
                    ;
                    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v788 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v783 + (v784 + v782 * v785), v786, v787);
                    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
                    TSTORE(v788, v780);
                  } else {
                    // pto: %t__ci_tmp_v5
                    ;
                    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v789 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
                    // pto: %t__ci_tmp_v5
                    ;
                    uint64_t v790 = (uint64_t) v36;
                    TASSIGN(v789, v790);
                    // pto: %t__tmp_v862
                    ;
                    Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v791 = Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v63);
                    // pto: %t__tmp_v862
                    ;
                    uint64_t v792 = (uint64_t) v26;
                    TASSIGN(v791, v792);
                    // pto: %282
                    ;
                    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v793;
                    TRESHAPE(v793, v789);
                    // pto: %283
                    ;
                    Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v794;
                    TRESHAPE(v794, v791);
                    pipe_barrier(PIPE_V);
                    TCI<Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v794, v52, v793);
                    // pto: %medium_indices_inline4995__ssa_v0
                    ;
                    Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v795 = Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v63);
                    // pto: %medium_indices_inline4995__ssa_v0
                    ;
                    uint64_t v796 = (uint64_t) v44;
                    TASSIGN(v795, v796);
                    pipe_barrier(PIPE_V);
                    TADDS(v795, v791, v506);
                    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                    // pto: %medium_scores_raw_inline4996__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v797 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v504);
                    // pto: %medium_scores_raw_inline4996__ssa_v0
                    ;
                    uint64_t v798 = (uint64_t) v26;
                    TASSIGN(v797, v798);
                    // pto: %284, %285
                    ;
                    int64_t v799 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v500);
                    // pto: %286
                    ;
                    int64_t v800 = v799 < v53 ? v53 : v799;
                    // pto: %287
                    ;
                    const int64_t v801 = 0;
                    // pto: %287
                    ;
                    __gm__ float* v802 = PTOAS__GLOBAL_TENSOR_DATA(v86);
                    // pto: %287
                    ;
                    const int64_t v803 = 1;
                    // pto: %287
                    ;
                    const int64_t v804 = 1;
                    // pto: %287
                    ;
                    const int64_t v805 = 1;
                    // pto: %287
                    ;
                    int64_t v806 = v46 * v48;
                    // pto: %287
                    ;
                    int64_t v807 = v805 * v806;
                    // pto: %287
                    ;
                    pto::Shape<1, 1, 1, 1, -1> v808 = pto::Shape<1, 1, 1, 1, -1>(v803, v804, v805, v46, v504);
                    // pto: %287
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v809 = pto::Stride<-1, -1, -1, -1, -1>(v804 * v807, v807, v806, v48, v46);
                    // pto: %287
                    ;
                    GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v810 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v802 + (v801 + v800 * v48 + v53 * v46), v808, v809);
                    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                    TLOAD(v797, v810);
                    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                    // pto: %medium_scores_inline4997__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v811 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v63);
                    // pto: %medium_scores_inline4997__ssa_v0
                    ;
                    uint64_t v812 = (uint64_t) v26;
                    TASSIGN(v811, v812);
                    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                    TFILLPAD<pto::TFillPadMode::InPlace>(v811, v797);
                    // pto: %medium_scores_v1_inline4998__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v813 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v63);
                    // pto: %medium_scores_v1_inline4998__ssa_v0
                    ;
                    uint64_t v814 = (uint64_t) v29;
                    TASSIGN(v813, v814);
                    pipe_barrier(PIPE_V);
                    TMAXS(v813, v811, v70);
                    // pto: %t__tmp_v863
                    ;
                    Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v815 = Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v63);
                    // pto: %t__tmp_v863
                    ;
                    uint64_t v816 = (uint64_t) v44;
                    TASSIGN(v815, v816);
                    // pto: %medium_pairs_inline4999__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v817 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v48);
                    // pto: %medium_pairs_inline4999__ssa_v0
                    ;
                    uint64_t v818 = (uint64_t) v26;
                    TASSIGN(v817, v818);
                    // pto: %288
                    ;
                    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v819;
                    TRESHAPE(v819, v813);
                    // pto: %289
                    ;
                    Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v820;
                    TRESHAPE(v820, v815);
                    // pto: %290
                    ;
                    Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 8192, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v821;
                    TRESHAPE(v821, v817);
                    pipe_barrier(PIPE_V);
                    TSORT32(v821, v819, v820);
                    // pto: %medium_pairs_v1_inline5000__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v822 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v48);
                    // pto: %medium_pairs_v1_inline5000__ssa_v0
                    ;
                    uint64_t v823 = (uint64_t) v29;
                    TASSIGN(v822, v823);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v822, v817, v71);
                    // pto: %medium_pairs_v2_inline5001__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v824 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v48);
                    // pto: %medium_pairs_v2_inline5001__ssa_v0
                    ;
                    uint64_t v825 = (uint64_t) v26;
                    TASSIGN(v824, v825);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v824, v822, v72);
                    // pto: %medium_pairs_v3_inline5002__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v826 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v48);
                    // pto: %medium_pairs_v3_inline5002__ssa_v0
                    ;
                    uint64_t v827 = (uint64_t) v29;
                    TASSIGN(v826, v827);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v826, v824, v74);
                    // pto: %medium_left_inline5003__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v828 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                    // pto: %medium_left_inline5003__ssa_v0
                    ;
                    uint64_t v829 = (uint64_t) v29;
                    TASSIGN(v828, v829);
                    // pto: %291
                    ;
                    Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v830;
                    // pto: %291
                    ;
                    uint64_t v831 = (uint64_t) v29;
                    TASSIGN(v830, v831);
                    // pto: %medium_right_inline5004__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v832 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                    // pto: %medium_right_inline5004__ssa_v0
                    ;
                    uint64_t v833 = (uint64_t) v45;
                    TASSIGN(v832, v833);
                    // pto: %292
                    ;
                    Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v834;
                    // pto: %292
                    ;
                    uint64_t v835 = (uint64_t) v45;
                    TASSIGN(v834, v835);
                    // pto: %medium_tmp_inline5005__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v836 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v73);
                    // pto: %medium_tmp_inline5005__ssa_v0
                    ;
                    uint64_t v837 = (uint64_t) v26;
                    TASSIGN(v836, v837);
                    // pto: %medium_merged_inline5006__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v838 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
                    // pto: %medium_merged_inline5006__ssa_v0
                    ;
                    uint64_t v839 = (uint64_t) v34;
                    TASSIGN(v838, v839);
                    pipe_barrier(PIPE_V);
                    TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v838, v25, v836, v834, v830);
                    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                    // pto: %t__tmp_v864
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v840 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                    // pto: %t__tmp_v864
                    ;
                    uint64_t v841 = (uint64_t) v34;
                    TASSIGN(v840, v841);
                    // pto: %294
                    ;
                    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v842;
                    // pto: %294
                    ;
                    uint64_t v843 = (uint64_t) v34;
                    TASSIGN(v842, v843);
                    // pto: %295
                    ;
                    int64_t v844 = v505 < v53 ? v53 : v505;
                    // pto: %296
                    ;
                    __gm__ float* v845 = PTOAS__GLOBAL_TENSOR_DATA(v120);
                    // pto: %296
                    ;
                    const int64_t v846 = 0;
                    // pto: %296
                    ;
                    const int64_t v847 = 1024;
                    // pto: %296
                    ;
                    pto::Shape<1, 1, 1, 1, 1024> v848 = pto::Shape<1, 1, 1, 1, 1024>();
                    // pto: %296
                    ;
                    pto::Stride<1024, 1024, 1024, 1024, 1> v849 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                    // pto: %296
                    ;
                    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v850 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v845 + (v846 + v844 * v847), v848, v849);
                    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                    TSTORE(v850, v842);
                  };
                };
              };
            };
          };
        } else {
          // pto: %empty_pairs_inline3745__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v851 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v51);
          // pto: %empty_pairs_inline3745__ssa_v0
          ;
          uint64_t v852 = (uint64_t) v26;
          TASSIGN(v851, v852);
          pipe_barrier(PIPE_V);
          TEXPANDS(v851, v70);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
          // pto: %297
          ;
          int64_t v853 = v505 < v53 ? v53 : v505;
          // pto: %298
          ;
          __gm__ float* v854 = PTOAS__GLOBAL_TENSOR_DATA(v120);
          // pto: %298
          ;
          const int64_t v855 = 0;
          // pto: %298
          ;
          const int64_t v856 = 1024;
          // pto: %298
          ;
          pto::Shape<1, 1, 1, 1, 1024> v857 = pto::Shape<1, 1, 1, 1, 1024>();
          // pto: %298
          ;
          pto::Stride<1024, 1024, 1024, 1024, 1> v858 = pto::Stride<1024, 1024, 1024, 1024, 1>();
          // pto: %298
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v859 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v854 + (v855 + v853 * v856), v857, v858);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
          pipe_barrier(PIPE_MTE3);
          TSTORE(v859, v851);
        };
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    };
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}