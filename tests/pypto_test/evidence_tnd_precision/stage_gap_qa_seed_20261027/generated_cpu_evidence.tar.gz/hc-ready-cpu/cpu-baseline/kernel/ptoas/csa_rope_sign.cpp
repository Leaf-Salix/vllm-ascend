#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void csa_rope_sign(__gm__ float* v1, __gm__ float* v2, int64_t v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v8 = 0;
  // pto: %c1280_i64
  const int64_t v9 = 1280;
  // pto: %c1024_i64
  const int64_t v10 = 1024;
  // pto: %c64_index
  const int64_t v11 = 64;
  // pto: %c1_index
  const int64_t v12 = 1;
  // pto: %c16_index
  const int64_t v13 = 16;
  // pto: %c4_index
  const int64_t v14 = 4;
  // pto: %cst_7
  const float v15 = 1.0f;
  // pto: %c192_index
  const int64_t v16 = 192;
  // pto: %c0_i32
  const int32_t v17 = 0;
  // pto: %cst_10
  const float v18 = 0.5f;
  // pto: %cst_11
  const float v19 = 2.0f;
  // pto: %c0_index
  const int64_t v20 = 0;
  // pto: %freqs_sin__ssa_v0_view
  const int64_t v21 = 1;
  // pto: %freqs_sin__ssa_v0_view
  const int64_t v22 = 1;
  // pto: %freqs_sin__ssa_v0_view
  const int64_t v23 = 1;
  // pto: %freqs_sin__ssa_v0_view
  int64_t v24 = (int64_t) v5;
  // pto: %freqs_sin__ssa_v0_view
  int64_t v25 = v24 * v11;
  // pto: %freqs_sin__ssa_v0_view
  int64_t v26 = v23 * v25;
  // pto: %freqs_sin__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v27 = pto::Shape<1, 1, 1, -1, -1>(v21, v22, v23, v24, v11);
  // pto: %freqs_sin__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v28 = pto::Stride<-1, -1, -1, -1, -1>(v22 * v26, v26, v25, v11, v12);
  // pto: %freqs_sin__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v29 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v27, v28);
  // pto: %idx_sin_signed__ssa_v0_view
  const int64_t v30 = 1;
  // pto: %idx_sin_signed__ssa_v0_view
  const int64_t v31 = 1;
  // pto: %idx_sin_signed__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %idx_sin_signed__ssa_v0_view
  int64_t v33 = (int64_t) v5;
  // pto: %idx_sin_signed__ssa_v0_view
  int64_t v34 = v33 * v11;
  // pto: %idx_sin_signed__ssa_v0_view
  int64_t v35 = v32 * v34;
  // pto: %idx_sin_signed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v36 = pto::Shape<1, 1, 1, -1, -1>(v30, v31, v32, v33, v11);
  // pto: %idx_sin_signed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v37 = pto::Stride<-1, -1, -1, -1, -1>(v31 * v35, v35, v34, v11, v12);
  // pto: %idx_sin_signed__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v38 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v36, v37);
  // pto: %t__tmp_v9
  // pto: %0
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  for (int64_t v39 = (int64_t) v6; v39 < v3; v39 += v3 < v13 ? v3 : v13) {
    // pto: %1
    ;
    int64_t v40 = (int64_t) ((uint64_t) v39 * (uint64_t) v14);
    // pto: %2
    ;
    int64_t v41 = (int64_t) ((uint64_t) v5 - (uint64_t) v40);
    // pto: %3
    ;
    int64_t v42 = v41 < v14 ? v41 : v14;
    // pto: %il_ones__ssa_v0
    ;
    Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v43 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v11);
    // pto: %il_ones__ssa_v0
    ;
    uint64_t v44 = (uint64_t) v8;
    TASSIGN(v43, v44);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    TEXPANDS(v43, v15);
    // pto: %t__ci_tmp_v0
    ;
    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v45 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v16);
    // pto: %t__ci_tmp_v0
    ;
    uint64_t v46 = (uint64_t) v9;
    TASSIGN(v45, v46);
    // pto: %t__tmp_v10
    ;
    Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v47 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v11);
    // pto: %t__tmp_v10
    ;
    uint64_t v48 = (uint64_t) v10;
    TASSIGN(v47, v48);
    // pto: %ci_tmp_view
    ;
    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v49;
    TRESHAPE(v49, v45);
    // pto: %ci_dst_view
    ;
    Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v50;
    TRESHAPE(v50, v47);
    TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v50, v17, v49);
    // pto: %il_lane_ids__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v51 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v11);
    // pto: %il_lane_ids__ssa_v0
    ;
    uint64_t v52 = (uint64_t) v9;
    TASSIGN(v51, v52);
    pipe_barrier(PIPE_V);
    RoundMode v53 = RoundMode::CAST_ROUND;
    SaturationMode v54 = SaturationMode::ON;
    TCVT(v51, v47, v53, v54);
    // pto: %il_col__ssa_v0
    ;
    Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v55 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v11);
    // pto: %il_col__ssa_v0
    ;
    uint64_t v56 = (uint64_t) v8;
    TASSIGN(v55, v56);
    pipe_barrier(PIPE_V);
    TCOLEXPANDMUL(v55, v43, v51);
    // pto: %t__tmp_v11
    ;
    Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v57 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v11);
    // pto: %t__tmp_v11
    ;
    uint64_t v58 = (uint64_t) v9;
    TASSIGN(v57, v58);
    pipe_barrier(PIPE_V);
    TMULS(v57, v55, v18);
    // pto: %t__tmp_v12
    ;
    Tile<TileType::Vec, int32_t, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v59 = Tile<TileType::Vec, int32_t, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v11);
    // pto: %t__tmp_v12
    ;
    uint64_t v60 = (uint64_t) v9;
    TASSIGN(v59, v60);
    pipe_barrier(PIPE_V);
    RoundMode v61 = RoundMode::CAST_TRUNC;
    SaturationMode v62 = SaturationMode::ON;
    TCVT(v59, v57, v61, v62);
    // pto: %il_dup_f__ssa_v0
    ;
    Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v63 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v11);
    // pto: %il_dup_f__ssa_v0
    ;
    uint64_t v64 = (uint64_t) v9;
    TASSIGN(v63, v64);
    pipe_barrier(PIPE_V);
    RoundMode v65 = RoundMode::CAST_ROUND;
    SaturationMode v66 = SaturationMode::ON;
    TCVT(v63, v59, v65, v66);
    // pto: %t__tmp_v13
    ;
    Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v67 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v11);
    // pto: %t__tmp_v13
    ;
    uint64_t v68 = (uint64_t) v9;
    TASSIGN(v67, v68);
    pipe_barrier(PIPE_V);
    TMULS(v67, v63, v19);
    // pto: %il_lane__ssa_v0
    ;
    Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v69 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v11);
    // pto: %il_lane__ssa_v0
    ;
    uint64_t v70 = (uint64_t) v8;
    TASSIGN(v69, v70);
    pipe_barrier(PIPE_V);
    TSUB(v69, v55, v67);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %t__tmp_v14
    ;
    Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v71 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v11);
    // pto: %t__tmp_v14
    ;
    uint64_t v72 = (uint64_t) v8;
    TASSIGN(v71, v72);
    pipe_barrier(PIPE_V);
    TMULS(v71, v69, v19);
    // pto: %il_sign__ssa_v0
    ;
    Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v73 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v11);
    // pto: %il_sign__ssa_v0
    ;
    uint64_t v74 = (uint64_t) v8;
    TASSIGN(v73, v74);
    pipe_barrier(PIPE_V);
    TSUBS(v73, v71, v15);
    // pto: %rope_sin_rows__ssa_v0
    ;
    Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v75 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v42, v11);
    // pto: %rope_sin_rows__ssa_v0
    ;
    uint64_t v76 = (uint64_t) v9;
    TASSIGN(v75, v76);
    // pto: %4
    ;
    int64_t v77 = v40 < v20 ? v20 : v40;
    // pto: %freqs_sin__ssa_v0_pview
    ;
    const int64_t v78 = 0;
    // pto: %freqs_sin__ssa_v0_pview
    ;
    __gm__ float* v79 = PTOAS__GLOBAL_TENSOR_DATA(v29);
    // pto: %freqs_sin__ssa_v0_pview
    ;
    const int64_t v80 = 1;
    // pto: %freqs_sin__ssa_v0_pview
    ;
    const int64_t v81 = 1;
    // pto: %freqs_sin__ssa_v0_pview
    ;
    const int64_t v82 = 1;
    // pto: %freqs_sin__ssa_v0_pview
    ;
    int64_t v83 = v42 * v11;
    // pto: %freqs_sin__ssa_v0_pview
    ;
    int64_t v84 = v82 * v83;
    // pto: %freqs_sin__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 64> v85 = pto::Shape<1, 1, 1, -1, 64>(v80, v81, v82, v42, v11);
    // pto: %freqs_sin__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v86 = pto::Stride<-1, -1, -1, -1, -1>(v81 * v84, v84, v83, v11, v12);
    // pto: %freqs_sin__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v87 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v79 + (v78 + v77 * v11 + v20 * v12), v85, v86);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v75, v87);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    v73.SetValidShape(v42, v11);
    // pto: %t__tmp_v15
    ;
    Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v88 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v42, v11);
    // pto: %t__tmp_v15
    ;
    uint64_t v89 = (uint64_t) v8;
    TASSIGN(v88, v89);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    pipe_barrier(PIPE_V);
    TMUL(v88, v75, v73);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %idx_sin_signed__ssa_v0_pview
    ;
    const int64_t v90 = 0;
    // pto: %idx_sin_signed__ssa_v0_pview
    ;
    __gm__ float* v91 = PTOAS__GLOBAL_TENSOR_DATA(v38);
    // pto: %idx_sin_signed__ssa_v0_pview
    ;
    const int64_t v92 = 1;
    // pto: %idx_sin_signed__ssa_v0_pview
    ;
    const int64_t v93 = 1;
    // pto: %idx_sin_signed__ssa_v0_pview
    ;
    const int64_t v94 = 1;
    // pto: %idx_sin_signed__ssa_v0_pview
    ;
    int64_t v95 = v42 * v11;
    // pto: %idx_sin_signed__ssa_v0_pview
    ;
    int64_t v96 = v94 * v95;
    // pto: %idx_sin_signed__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 64> v97 = pto::Shape<1, 1, 1, -1, 64>(v92, v93, v94, v42, v11);
    // pto: %idx_sin_signed__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v98 = pto::Stride<-1, -1, -1, -1, -1>(v93 * v96, v96, v95, v11, v12);
    // pto: %idx_sin_signed__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v99 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v91 + (v90 + v77 * v11 + v20 * v12), v97, v98);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v99, v88);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}