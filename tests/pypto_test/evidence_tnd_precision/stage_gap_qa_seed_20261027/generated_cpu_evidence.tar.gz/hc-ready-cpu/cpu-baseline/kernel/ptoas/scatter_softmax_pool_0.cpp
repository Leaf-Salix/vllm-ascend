#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void scatter_softmax_pool_0(__gm__ float* v1, __gm__ float* v2, __gm__ float* v3, __gm__ int32_t* v4, __gm__ int64_t* v5, __gm__ int32_t* v6, __gm__ int32_t* v7, __gm__ float* v8, __gm__ float* v9, __gm__ float* v10, __gm__ float* v11, int64_t v12, int64_t v13, int64_t v14, int64_t v15, int64_t v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v22 = -7;
  // pto: %c768_i64
  const int64_t v23 = 768;
  // pto: %c2816_i64
  const int64_t v24 = 2816;
  // pto: %c0_i64
  const int64_t v25 = 0;
  // pto: %c256_i64
  const int64_t v26 = 256;
  // pto: %c512_i64
  const int64_t v27 = 512;
  const int64_t v28 = 1792;
  const int64_t v29 = 3328;
  const int64_t v30 = 3072;
  const int64_t v31 = 1280;
  const int64_t v32 = 1024;
  // pto: %c384_index
  const int64_t v33 = 384;
  // pto: %c128_index
  const int64_t v34 = 128;
  // pto: %c1_index
  const int64_t v35 = 1;
  // pto: %c256_index
  const int64_t v36 = 256;
  // pto: %c4_index
  const int64_t v37 = 4;
  // pto: %c0_index
  const int64_t v38 = 0;
  // pto: %cst_16
  const float v39 = 0.0f;
  // pto: %c1_i64
  const int64_t v40 = 1;
  // pto: %c4_i64
  const int64_t v41 = 4;
  // pto: %c64_index
  const int64_t v42 = 64;
  // pto: %c8_index
  const int64_t v43 = 8;
  // pto: %cst_22
  const float v44 = -3.40282347E+38f;
  // pto: %c2_i64
  const int64_t v45 = 2;
  // pto: %c512_index
  const int64_t v46 = 512;
  // pto: %c2_index
  const int64_t v47 = 2;
  // pto: %pooled_kv_inline3359__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %pooled_kv_inline3359__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %pooled_kv_inline3359__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %pooled_kv_inline3359__ssa_v0_view
  int64_t v51 = v33 * v34;
  // pto: %pooled_kv_inline3359__ssa_v0_view
  int64_t v52 = v50 * v51;
  // pto: %pooled_kv_inline3359__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v53 = pto::Shape<1, 1, 1, -1, -1>(v48, v49, v50, v33, v34);
  // pto: %pooled_kv_inline3359__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v54 = pto::Stride<-1, -1, -1, -1, -1>(v49 * v52, v52, v51, v34, v35);
  // pto: %pooled_kv_inline3359__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v55 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v53, v54);
  // pto: %window_scores_inline3393__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %window_scores_inline3393__ssa_v0_view
  const int64_t v57 = 1;
  // pto: %window_scores_inline3393__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %window_scores_inline3393__ssa_v0_view
  int64_t v59 = v33 * v34;
  // pto: %window_scores_inline3393__ssa_v0_view
  int64_t v60 = v58 * v59;
  // pto: %window_scores_inline3393__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v61 = pto::Shape<1, 1, 1, -1, -1>(v56, v57, v58, v33, v34);
  // pto: %window_scores_inline3393__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v62 = pto::Stride<-1, -1, -1, -1, -1>(v57 * v60, v60, v59, v34, v35);
  // pto: %window_scores_inline3393__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v63 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v61, v62);
  // pto: %window_values_inline3392__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %window_values_inline3392__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %window_values_inline3392__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %window_values_inline3392__ssa_v0_view
  int64_t v67 = v33 * v34;
  // pto: %window_values_inline3392__ssa_v0_view
  int64_t v68 = v66 * v67;
  // pto: %window_values_inline3392__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v69 = pto::Shape<1, 1, 1, -1, -1>(v64, v65, v66, v33, v34);
  // pto: %window_values_inline3392__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v70 = pto::Stride<-1, -1, -1, -1, -1>(v65 * v68, v68, v67, v34, v35);
  // pto: %window_values_inline3392__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v71 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v69, v70);
  // pto: %inner_compress_state__ssa_v0_view
  const int64_t v72 = 1;
  // pto: %inner_compress_state__ssa_v0_view
  const int64_t v73 = 1;
  // pto: %inner_compress_state__ssa_v0_view
  const int64_t v74 = 1;
  // pto: %inner_compress_state__ssa_v0_view
  int64_t v75 = (int64_t) v18;
  // pto: %inner_compress_state__ssa_v0_view
  int64_t v76 = (int64_t) v19;
  // pto: %inner_compress_state__ssa_v0_view
  int64_t v77 = v75 * v76;
  // pto: %inner_compress_state__ssa_v0_view
  int64_t v78 = v74 * v77;
  // pto: %inner_compress_state__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v79 = pto::Shape<1, 1, 1, -1, -1>(v72, v73, v74, v75, (int64_t) v19);
  // pto: %inner_compress_state__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v80 = pto::Stride<-1, -1, -1, -1, -1>(v73 * v78, v78, v77, v76, v35);
  // pto: %inner_compress_state__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v81 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v79, v80);
  // pto: %kv_proj_pad_inline3357__rv_v2_view
  const int64_t v82 = 1;
  // pto: %kv_proj_pad_inline3357__rv_v2_view
  const int64_t v83 = 1;
  // pto: %kv_proj_pad_inline3357__rv_v2_view
  const int64_t v84 = 1;
  // pto: %kv_proj_pad_inline3357__rv_v2_view
  int64_t v85 = v33 * v36;
  // pto: %kv_proj_pad_inline3357__rv_v2_view
  int64_t v86 = v84 * v85;
  // pto: %kv_proj_pad_inline3357__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v87 = pto::Shape<1, 1, 1, -1, -1>(v82, v83, v84, v33, v36);
  // pto: %kv_proj_pad_inline3357__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v88 = pto::Stride<-1, -1, -1, -1, -1>(v83 * v86, v86, v85, v36, v35);
  // pto: %kv_proj_pad_inline3357__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v89 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v87, v88);
  // pto: %score_proj_pad_inline3358__rv_v2_view
  const int64_t v90 = 1;
  // pto: %score_proj_pad_inline3358__rv_v2_view
  const int64_t v91 = 1;
  // pto: %score_proj_pad_inline3358__rv_v2_view
  const int64_t v92 = 1;
  // pto: %score_proj_pad_inline3358__rv_v2_view
  int64_t v93 = v33 * v36;
  // pto: %score_proj_pad_inline3358__rv_v2_view
  int64_t v94 = v92 * v93;
  // pto: %score_proj_pad_inline3358__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v95 = pto::Shape<1, 1, 1, -1, -1>(v90, v91, v92, v33, v36);
  // pto: %score_proj_pad_inline3358__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v96 = pto::Stride<-1, -1, -1, -1, -1>(v91 * v94, v94, v93, v36, v35);
  // pto: %score_proj_pad_inline3358__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v97 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v10, v95, v96);
  // pto: %inner_ape__ssa_v0_view
  const int64_t v98 = 1;
  // pto: %inner_ape__ssa_v0_view
  const int64_t v99 = 1;
  // pto: %inner_ape__ssa_v0_view
  const int64_t v100 = 1;
  // pto: %inner_ape__ssa_v0_view
  int64_t v101 = v37 * v36;
  // pto: %inner_ape__ssa_v0_view
  int64_t v102 = v100 * v101;
  // pto: %inner_ape__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v103 = pto::Shape<1, 1, 1, -1, -1>(v98, v99, v100, v37, v36);
  // pto: %inner_ape__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v104 = pto::Stride<-1, -1, -1, -1, -1>(v99 * v102, v102, v101, v36, v35);
  // pto: %inner_ape__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v105 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v11, v103, v104);
  // pto: %score_inline3411__phi_v4
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %score_inline3411__phi_v4
  uint64_t v107 = (uint64_t) v27;
  TASSIGN(v106, v107);
  // pto: %value_inline3410__phi_v3
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %value_inline3410__phi_v3
  uint64_t v109 = (uint64_t) v26;
  TASSIGN(v108, v109);
  // pto: %score_inline3411__phi_v3
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %score_inline3411__phi_v3
  uint64_t v111 = (uint64_t) v27;
  TASSIGN(v110, v111);
  // pto: %value_inline3410__phi_v2
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v112 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %value_inline3410__phi_v2
  uint64_t v113 = (uint64_t) v26;
  TASSIGN(v112, v113);
  // pto: %score_inline3411__phi_v7
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v114 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %score_inline3411__phi_v7
  uint64_t v115 = (uint64_t) v24;
  TASSIGN(v114, v115);
  // pto: %value_inline3410__phi_v6
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %value_inline3410__phi_v6
  uint64_t v117 = (uint64_t) v23;
  TASSIGN(v116, v117);
  // pto: %score_inline3411__phi_v6
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v118 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %score_inline3411__phi_v6
  uint64_t v119 = (uint64_t) v24;
  TASSIGN(v118, v119);
  // pto: %value_inline3410__phi_v5
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %value_inline3410__phi_v5
  uint64_t v121 = (uint64_t) v23;
  TASSIGN(v120, v121);
  // pto: %pool_worker_inline3396__ssa_v0
  int64_t v122 = (int64_t) v20;
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v123 = v122; v123 < v12; v123 += v13) {
    // pto: %31
    ;
    int32_t v124 = (v4)[v123];
    // pto: %32
    ;
    int64_t v125 = (int64_t) v124;
    // pto: %34, %33
    ;
    int32_t v126 = (v4)[(int64_t) ((uint64_t) v123 + (uint64_t) v35)];
    // pto: %35
    ;
    int64_t v127 = (int64_t) v126;
    // pto: %36
    ;
    // pto: %first_pos_b_inline3400__phi_v2
    ;
    int64_t v128;
    if (v125 < v127) {
      // pto: %37
      ;
      int64_t v129 = (v5)[v125];
      v128 = v129;
    } else {
      v128 = v38;
    };
    for (int64_t v130 = v125; v130 < v127; v130 += v35) {
      // pto: %token_pos_inline3404__tile
      ;
      int64_t v131 = (v5)[v130];
      // pto: %t__tile
      ;
      Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v132 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v34);
      // pto: %t__tile
      ;
      uint64_t v133 = (uint64_t) v23;
      TASSIGN(v132, v133);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      TEXPANDS(v132, v39);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      // pto: %44
      ;
      int64_t v134 = v130 < v38 ? v38 : v130;
      // pto: %pooled_kv_inline3359__iter_v3_pview
      ;
      __gm__ float* v135 = PTOAS__GLOBAL_TENSOR_DATA(v55);
      // pto: %pooled_kv_inline3359__iter_v3_pview
      ;
      const int64_t v136 = 0;
      // pto: %pooled_kv_inline3359__iter_v3_pview
      ;
      const int64_t v137 = 128;
      // pto: %pooled_kv_inline3359__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, 1, 128> v138 = pto::Shape<1, 1, 1, 1, 128>();
      // pto: %pooled_kv_inline3359__iter_v3_pview
      ;
      pto::Stride<128, 128, 128, 128, 1> v139 = pto::Stride<128, 128, 128, 128, 1>();
      // pto: %pooled_kv_inline3359__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v140 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v135 + (v136 + v134 * v137), v138, v139);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v140, v132);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      // pto: %45
      ;
      int32_t v141 = (v6)[v130];
      // pto: %48, %49
      ;
      int64_t v142 = (int64_t) ((uint64_t) v131 + (uint64_t) v40) % v41;
      // pto: %50, %51, %52
      ;
      int64_t v143 = v142 < v25 ? (int64_t) ((uint64_t) v142 + (uint64_t) v41) : v142;
      // pto: %46, %47, %53, %54
      ;
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      if ((int64_t) v141 >= v38 & v143 == v25) {
        for (int64_t v144 = v38; v144 < v34; v144 += v42) {
          // pto: %57
          ;
          int64_t v145 = (int64_t) ((uint64_t) v122 * (uint64_t) v43);
          wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
          for (int64_t v146 = v38; v146 < v43; v146 += v35) {
            // pto: %59
            ;
            int64_t v147 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v131 + (uint64_t) v22) + (uint64_t) v146);
            // pto: %value_inline3410__tile
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v148 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
            // pto: %value_inline3410__tile
            ;
            uint64_t v149 = (uint64_t) v23;
            TASSIGN(v148, v149);
            wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
            pipe_barrier(PIPE_V);
            TEXPANDS(v148, v39);
            // pto: %score_inline3411__tile
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v150 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
            // pto: %score_inline3411__tile
            ;
            uint64_t v151 = (uint64_t) v24;
            TASSIGN(v150, v151);
            wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
            TEXPANDS(v150, v44);
            // pto: %60, %state_half_inline3412__phi_v2
            ;
            int64_t v152 = v146 >= v37 ? v34 : v38;
            // pto: %64
            ;
            bool v153 = v147 < v128;
            // pto: %62, %65
            ;
            wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
            if (v147 >= v38 & v153) {
              // pto: %0
              ;
              Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v154 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
              // pto: %0
              ;
              uint64_t v155 = (uint64_t) v25;
              TASSIGN(v154, v155);
              TEXPANDS(v154, v39);
              // pto: %67
              ;
              const int64_t v156 = 1;
              // pto: %67
              ;
              const int64_t v157 = 0;
              // pto: %67
              ;
              int64_t v158 = v147 / v45;
              // pto: %67
              ;
              bool v159 = v147 < v157;
              // pto: %67
              ;
              bool v160 = v45 < v157;
              // pto: %67
              ;
              bool v161 = v159 == v160;
              // pto: %67
              ;
              bool v162 = v147 % v45 != v157 && v159 != v160;
              // pto: %67
              ;
              int64_t v163 = v162 ? v158 - v156 : v158;
              // pto: %flat_offset_mul, %flat_offset, %66
              ;
              int32_t v164 = (v7)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v17) + (uint64_t) v163)];
              // pto: %69
              ;
              int64_t v165 = (int64_t) v164;
              // pto: %70
              ;
              if (v165 >= v38) {
                // pto: %71
                ;
                int64_t v166 = v147 % v45;
                // pto: %72, %73, %74
                ;
                int64_t v167 = v166 < v25 ? (int64_t) ((uint64_t) v166 + (uint64_t) v45) : v166;
                // pto: %76, %77, %78
                ;
                int64_t v168 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v167 * (uint64_t) v46) + (uint64_t) v152) + (uint64_t) v144);
                // pto: %1
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %1
                ;
                uint64_t v170 = (uint64_t) v26;
                TASSIGN(v169, v170);
                // pto: %79
                ;
                int64_t v171 = v165 < v38 ? v38 : v165;
                // pto: %80
                ;
                int64_t v172 = v168 < v38 ? v38 : v168;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                int64_t v173 = (int64_t) v19;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                const int64_t v174 = 0;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                __gm__ float* v175 = PTOAS__GLOBAL_TENSOR_DATA(v81);
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                const int64_t v176 = 1;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                const int64_t v177 = 1;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                const int64_t v178 = 1;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                int64_t v179 = v35 * v173;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                int64_t v180 = v178 * v179;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                pto::Shape<1, 1, 1, 1, 64> v181 = pto::Shape<1, 1, 1, 1, 64>(v176, v177, v178, v35, v42);
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                pto::Stride<-1, -1, -1, -1, -1> v182 = pto::Stride<-1, -1, -1, -1, -1>(v177 * v180, v180, v179, v173, v35);
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v183 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v175 + (v174 + v171 * v173 + v172 * v35), v181, v182);
                TLOAD(v169, v183);
                // pto: %2
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v184 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %2
                ;
                uint64_t v185 = (uint64_t) v27;
                TASSIGN(v184, v185);
                // pto: %82
                ;
                int64_t v186 = (int64_t) ((uint64_t) v168 + (uint64_t) v36);
                // pto: %83
                ;
                int64_t v187 = v186 < v38 ? v38 : v186;
                // pto: %84
                ;
                int64_t v188 = (int64_t) v19;
                // pto: %84
                ;
                const int64_t v189 = 0;
                // pto: %84
                ;
                __gm__ float* v190 = PTOAS__GLOBAL_TENSOR_DATA(v81);
                // pto: %84
                ;
                const int64_t v191 = 1;
                // pto: %84
                ;
                const int64_t v192 = 1;
                // pto: %84
                ;
                const int64_t v193 = 1;
                // pto: %84
                ;
                int64_t v194 = v35 * v188;
                // pto: %84
                ;
                int64_t v195 = v193 * v194;
                // pto: %84
                ;
                pto::Shape<1, 1, 1, 1, 64> v196 = pto::Shape<1, 1, 1, 1, 64>(v191, v192, v193, v35, v42);
                // pto: %84
                ;
                pto::Stride<-1, -1, -1, -1, -1> v197 = pto::Stride<-1, -1, -1, -1, -1>(v192 * v195, v195, v194, v188, v35);
                // pto: %84
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v198 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v190 + (v189 + v171 * v188 + v187 * v35), v196, v197);
                TLOAD(v184, v198);
              } else {
                // pto: %score_inline3411__tile_mv
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v199 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %score_inline3411__tile_mv
                ;
                uint64_t v200 = (uint64_t) v27;
                TASSIGN(v199, v200);
                pipe_barrier(PIPE_V);
                TMOV(v199, v154);
                // pto: %value_inline3410__tile_mv
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v201 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %value_inline3410__tile_mv
                ;
                uint64_t v202 = (uint64_t) v26;
                TASSIGN(v201, v202);
                TMOV(v201, v148);
              };
            } else {
              // pto: %3
              ;
              Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v203 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
              // pto: %3
              ;
              uint64_t v204 = (uint64_t) v27;
              TASSIGN(v203, v204);
              pipe_barrier(PIPE_V);
              TMOV(v203, v150);
              // pto: %4
              ;
              Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v205 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
              // pto: %4
              ;
              uint64_t v206 = (uint64_t) v26;
              TASSIGN(v205, v206);
              TMOV(v205, v148);
            };
            set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
            // pto: %86
            ;
            bool v207 = v128 <= v147;
            wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
            wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
            if (v207) {
              // pto: %87
              ;
              if (v147 <= v131) {
                // pto: %90
                ;
                uint64_t v208 = (uint64_t) v128;
                // pto: %89, %90
                ;
                int64_t v209 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v125 + (uint64_t) v147) - v208);
                // pto: %91
                ;
                int64_t v210 = v147 % v41;
                // pto: %92, %93, %94
                ;
                int64_t v211 = v210 < v25 ? (int64_t) ((uint64_t) v210 + (uint64_t) v41) : v210;
                // pto: %5
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v212 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %5
                ;
                uint64_t v213 = (uint64_t) v23;
                TASSIGN(v212, v213);
                // pto: %96
                ;
                int64_t v214 = v209 < v38 ? v38 : v209;
                // pto: %97
                ;
                int64_t v215 = (int64_t) ((uint64_t) v152 + (uint64_t) v144);
                // pto: %98
                ;
                int64_t v216 = v215 < v38 ? v38 : v215;
                // pto: %kv_proj_pad_inline3357__rv_v2_pview
                ;
                __gm__ float* v217 = PTOAS__GLOBAL_TENSOR_DATA(v89);
                // pto: %kv_proj_pad_inline3357__rv_v2_pview
                ;
                const int64_t v218 = 0;
                // pto: %kv_proj_pad_inline3357__rv_v2_pview
                ;
                const int64_t v219 = 256;
                // pto: %kv_proj_pad_inline3357__rv_v2_pview
                ;
                pto::Shape<1, 1, 1, 1, 64> v220 = pto::Shape<1, 1, 1, 1, 64>();
                // pto: %kv_proj_pad_inline3357__rv_v2_pview
                ;
                pto::Stride<256, 256, 256, 256, 1> v221 = pto::Stride<256, 256, 256, 256, 1>();
                // pto: %kv_proj_pad_inline3357__rv_v2_pview
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND> v222 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND>(v217 + (v218 + v214 * v219 + v216), v220, v221);
                TLOAD(v212, v222);
                // pto: %6
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v223 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %6
                ;
                uint64_t v224 = (uint64_t) v24;
                TASSIGN(v223, v224);
                // pto: %score_proj_pad_inline3358__rv_v2_pview
                ;
                __gm__ float* v225 = PTOAS__GLOBAL_TENSOR_DATA(v97);
                // pto: %score_proj_pad_inline3358__rv_v2_pview
                ;
                const int64_t v226 = 0;
                // pto: %score_proj_pad_inline3358__rv_v2_pview
                ;
                const int64_t v227 = 256;
                // pto: %score_proj_pad_inline3358__rv_v2_pview
                ;
                pto::Shape<1, 1, 1, 1, 64> v228 = pto::Shape<1, 1, 1, 1, 64>();
                // pto: %score_proj_pad_inline3358__rv_v2_pview
                ;
                pto::Stride<256, 256, 256, 256, 1> v229 = pto::Stride<256, 256, 256, 256, 1>();
                // pto: %score_proj_pad_inline3358__rv_v2_pview
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND> v230 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND>(v225 + (v226 + v214 * v227 + v216), v228, v229);
                TLOAD(v223, v230);
                // pto: %7
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v231 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %7
                ;
                uint64_t v232 = (uint64_t) v25;
                TASSIGN(v231, v232);
                // pto: %102
                ;
                int64_t v233 = v211 < v38 ? v38 : v211;
                // pto: %inner_ape__ssa_v0_pview
                ;
                __gm__ float* v234 = PTOAS__GLOBAL_TENSOR_DATA(v105);
                // pto: %inner_ape__ssa_v0_pview
                ;
                const int64_t v235 = 0;
                // pto: %inner_ape__ssa_v0_pview
                ;
                const int64_t v236 = 256;
                // pto: %inner_ape__ssa_v0_pview
                ;
                pto::Shape<1, 1, 1, 1, 64> v237 = pto::Shape<1, 1, 1, 1, 64>();
                // pto: %inner_ape__ssa_v0_pview
                ;
                pto::Stride<256, 256, 256, 256, 1> v238 = pto::Stride<256, 256, 256, 256, 1>();
                // pto: %inner_ape__ssa_v0_pview
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND> v239 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND>(v234 + (v235 + v233 * v236 + v216), v237, v238);
                TLOAD(v231, v239);
                set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
                // pto: %8
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v240 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %8
                ;
                uint64_t v241 = (uint64_t) v24;
                TASSIGN(v240, v241);
                wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
                TADD(v240, v223, v231);
              } else {
                // pto: %score_inline3411__phi_v4_mv
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v242 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %score_inline3411__phi_v4_mv
                ;
                uint64_t v243 = (uint64_t) v24;
                TASSIGN(v242, v243);
                pipe_barrier(PIPE_V);
                TMOV(v242, v106);
                // pto: %value_inline3410__phi_v3_mv
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v244 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %value_inline3410__phi_v3_mv
                ;
                uint64_t v245 = (uint64_t) v23;
                TASSIGN(v244, v245);
                TMOV(v244, v108);
              };
            } else {
              // pto: %9
              ;
              Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v246 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
              // pto: %9
              ;
              uint64_t v247 = (uint64_t) v24;
              TASSIGN(v246, v247);
              pipe_barrier(PIPE_V);
              TMOV(v246, v106);
              // pto: %10
              ;
              Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v248 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
              // pto: %10
              ;
              uint64_t v249 = (uint64_t) v23;
              TASSIGN(v248, v249);
              TMOV(v248, v108);
            };
            set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
            set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
            set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
            // pto: %105
            ;
            int64_t v250 = v146 % v37;
            // pto: %106, %107, %108
            ;
            int64_t v251 = v250 < v38 ? (int64_t) ((uint64_t) v250 + (uint64_t) v37) : v250;
            // pto: %110
            ;
            const int64_t v252 = 1;
            // pto: %110
            ;
            const int64_t v253 = 0;
            // pto: %110
            ;
            int64_t v254 = v146 / v37;
            // pto: %110
            ;
            bool v255 = v146 < v253;
            // pto: %110
            ;
            bool v256 = v37 < v253;
            // pto: %110
            ;
            bool v257 = v255 == v256;
            // pto: %110
            ;
            bool v258 = v146 % v37 != v253 && v255 != v256;
            // pto: %110
            ;
            int64_t v259 = v258 ? v254 - v252 : v254;
            // pto: %112, %109, %111
            ;
            int64_t v260 = (int64_t) ((uint64_t) v145 + (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v251 * (uint64_t) v47) + (uint64_t) v259));
            // pto: %113
            ;
            int64_t v261 = v260 < v38 ? v38 : v260;
            // pto: %114
            ;
            int64_t v262 = v144 < v38 ? v38 : v144;
            // pto: %window_values_inline3392__iter_v7_pview
            ;
            __gm__ float* v263 = PTOAS__GLOBAL_TENSOR_DATA(v71);
            // pto: %window_values_inline3392__iter_v7_pview
            ;
            const int64_t v264 = 0;
            // pto: %window_values_inline3392__iter_v7_pview
            ;
            const int64_t v265 = 128;
            // pto: %window_values_inline3392__iter_v7_pview
            ;
            pto::Shape<1, 1, 1, 1, 64> v266 = pto::Shape<1, 1, 1, 1, 64>();
            // pto: %window_values_inline3392__iter_v7_pview
            ;
            pto::Stride<128, 128, 128, 128, 1> v267 = pto::Stride<128, 128, 128, 128, 1>();
            // pto: %window_values_inline3392__iter_v7_pview
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v268 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v263 + (v264 + v261 * v265 + v262), v266, v267);
            wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
            wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
            TSTORE(v268, v116);
            set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
            // pto: %window_scores_inline3393__iter_v7_pview
            ;
            __gm__ float* v269 = PTOAS__GLOBAL_TENSOR_DATA(v63);
            // pto: %window_scores_inline3393__iter_v7_pview
            ;
            const int64_t v270 = 0;
            // pto: %window_scores_inline3393__iter_v7_pview
            ;
            const int64_t v271 = 128;
            // pto: %window_scores_inline3393__iter_v7_pview
            ;
            pto::Shape<1, 1, 1, 1, 64> v272 = pto::Shape<1, 1, 1, 1, 64>();
            // pto: %window_scores_inline3393__iter_v7_pview
            ;
            pto::Stride<128, 128, 128, 128, 1> v273 = pto::Stride<128, 128, 128, 128, 1>();
            // pto: %window_scores_inline3393__iter_v7_pview
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v274 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v269 + (v270 + v261 * v271 + v262), v272, v273);
            TSTORE(v274, v114);
            set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
          };
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
          // pto: %score_rows_inline3419__tile
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v275 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v42);
          // pto: %score_rows_inline3419__tile
          ;
          uint64_t v276 = (uint64_t) v23;
          TASSIGN(v275, v276);
          // pto: %117
          ;
          int64_t v277 = v145 < v38 ? v38 : v145;
          // pto: %118
          ;
          int64_t v278 = v144 < v38 ? v38 : v144;
          // pto: %window_scores_inline3393__rv_v8_pview
          ;
          __gm__ float* v279 = PTOAS__GLOBAL_TENSOR_DATA(v63);
          // pto: %window_scores_inline3393__rv_v8_pview
          ;
          const int64_t v280 = 0;
          // pto: %window_scores_inline3393__rv_v8_pview
          ;
          const int64_t v281 = 128;
          // pto: %window_scores_inline3393__rv_v8_pview
          ;
          pto::Shape<1, 1, 1, 8, 64> v282 = pto::Shape<1, 1, 1, 8, 64>();
          // pto: %window_scores_inline3393__rv_v8_pview
          ;
          pto::Stride<1024, 1024, 1024, 128, 1> v283 = pto::Stride<1024, 1024, 1024, 128, 1>();
          // pto: %window_scores_inline3393__rv_v8_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<1024, 1024, 1024, 128, 1>, pto::Layout::ND> v284 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<1024, 1024, 1024, 128, 1>, pto::Layout::ND>(v279 + (v280 + v277 * v281 + v278), v282, v283);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
          TLOAD(v275, v284);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          // pto: %11
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v285 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %11
          ;
          uint64_t v286 = (uint64_t) v23;
          TASSIGN(v285, v286);
          // pto: %slice_view
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, 4, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v287;
          // pto: %slice_view
          ;
          uint64_t v288 = (uint64_t) v23;
          TASSIGN(v287, v288);
          // pto: %12
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v289 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %12
          ;
          uint64_t v290 = (uint64_t) v28;
          TASSIGN(v289, v290);
          // pto: %119
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, 4, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v291;
          // pto: %119
          ;
          uint64_t v292 = (uint64_t) v28;
          TASSIGN(v291, v292);
          // pto: %max4_inline3420__tile
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v293 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %max4_inline3420__tile
          ;
          uint64_t v294 = (uint64_t) v24;
          TASSIGN(v293, v294);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          TMAX(v293, v287, v291);
          // pto: %13
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v295 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %13
          ;
          uint64_t v296 = (uint64_t) v24;
          TASSIGN(v295, v296);
          // pto: %120
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, 2, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v297;
          // pto: %120
          ;
          uint64_t v298 = (uint64_t) v24;
          TASSIGN(v297, v298);
          // pto: %14
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v299 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %14
          ;
          uint64_t v300 = (uint64_t) v29;
          TASSIGN(v299, v300);
          // pto: %121
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, 2, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v301;
          // pto: %121
          ;
          uint64_t v302 = (uint64_t) v29;
          TASSIGN(v301, v302);
          // pto: %max2_inline3421__tile
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v303 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %max2_inline3421__tile
          ;
          uint64_t v304 = (uint64_t) v24;
          TASSIGN(v303, v304);
          pipe_barrier(PIPE_V);
          TMAX(v303, v297, v301);
          // pto: %15
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v305 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %15
          ;
          uint64_t v306 = (uint64_t) v24;
          TASSIGN(v305, v306);
          // pto: %122
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v307;
          // pto: %122
          ;
          uint64_t v308 = (uint64_t) v24;
          TASSIGN(v307, v308);
          // pto: %16
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %16
          ;
          uint64_t v310 = (uint64_t) v30;
          TASSIGN(v309, v310);
          // pto: %123
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v311;
          // pto: %123
          ;
          uint64_t v312 = (uint64_t) v30;
          TASSIGN(v311, v312);
          // pto: %maximum_inline3422__tile
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %maximum_inline3422__tile
          ;
          uint64_t v314 = (uint64_t) v24;
          TASSIGN(v313, v314);
          pipe_barrier(PIPE_V);
          TMAX(v313, v307, v311);
          // pto: %17
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v42);
          // pto: %17
          ;
          uint64_t v316 = (uint64_t) v23;
          TASSIGN(v315, v316);
          pipe_barrier(PIPE_V);
          TCOLEXPANDSUB(v315, v275, v313);
          // pto: %probability_inline3423__tile
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v317 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v42);
          // pto: %probability_inline3423__tile
          ;
          uint64_t v318 = (uint64_t) v23;
          TASSIGN(v317, v318);
          pipe_barrier(PIPE_V);
          TEXP(v317, v315);
          // pto: %18
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v319 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %18
          ;
          uint64_t v320 = (uint64_t) v23;
          TASSIGN(v319, v320);
          // pto: %124
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, 4, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v321;
          // pto: %124
          ;
          uint64_t v322 = (uint64_t) v23;
          TASSIGN(v321, v322);
          // pto: %19
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v323 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %19
          ;
          uint64_t v324 = (uint64_t) v28;
          TASSIGN(v323, v324);
          // pto: %125
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, 4, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v325;
          // pto: %125
          ;
          uint64_t v326 = (uint64_t) v28;
          TASSIGN(v325, v326);
          // pto: %sum4_inline3424__tile
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v327 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %sum4_inline3424__tile
          ;
          uint64_t v328 = (uint64_t) v24;
          TASSIGN(v327, v328);
          pipe_barrier(PIPE_V);
          TADD(v327, v321, v325);
          // pto: %20
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v329 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %20
          ;
          uint64_t v330 = (uint64_t) v24;
          TASSIGN(v329, v330);
          // pto: %126
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, 2, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v331;
          // pto: %126
          ;
          uint64_t v332 = (uint64_t) v24;
          TASSIGN(v331, v332);
          // pto: %21
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v333 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %21
          ;
          uint64_t v334 = (uint64_t) v29;
          TASSIGN(v333, v334);
          // pto: %127
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, 2, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v335;
          // pto: %127
          ;
          uint64_t v336 = (uint64_t) v29;
          TASSIGN(v335, v336);
          // pto: %sum2_inline3425__tile
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v337 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %sum2_inline3425__tile
          ;
          uint64_t v338 = (uint64_t) v24;
          TASSIGN(v337, v338);
          pipe_barrier(PIPE_V);
          TADD(v337, v331, v335);
          // pto: %22
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v339 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %22
          ;
          uint64_t v340 = (uint64_t) v24;
          TASSIGN(v339, v340);
          // pto: %128
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v341;
          // pto: %128
          ;
          uint64_t v342 = (uint64_t) v24;
          TASSIGN(v341, v342);
          // pto: %23
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v343 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %23
          ;
          uint64_t v344 = (uint64_t) v30;
          TASSIGN(v343, v344);
          // pto: %129
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v345;
          // pto: %129
          ;
          uint64_t v346 = (uint64_t) v30;
          TASSIGN(v345, v346);
          // pto: %total_inline3426__tile
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v347 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %total_inline3426__tile
          ;
          uint64_t v348 = (uint64_t) v24;
          TASSIGN(v347, v348);
          pipe_barrier(PIPE_V);
          TADD(v347, v341, v345);
          // pto: %probability_v1_inline3427__tile
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v349 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v42);
          // pto: %probability_v1_inline3427__tile
          ;
          uint64_t v350 = (uint64_t) v23;
          TASSIGN(v349, v350);
          pipe_barrier(PIPE_V);
          TCOLEXPANDDIV(v349, v317, v347);
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
          // pto: %value_rows_inline3428__tile
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v351 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v42);
          // pto: %value_rows_inline3428__tile
          ;
          uint64_t v352 = (uint64_t) v24;
          TASSIGN(v351, v352);
          // pto: %window_values_inline3392__rv_v8_pview
          ;
          __gm__ float* v353 = PTOAS__GLOBAL_TENSOR_DATA(v71);
          // pto: %window_values_inline3392__rv_v8_pview
          ;
          const int64_t v354 = 0;
          // pto: %window_values_inline3392__rv_v8_pview
          ;
          const int64_t v355 = 128;
          // pto: %window_values_inline3392__rv_v8_pview
          ;
          pto::Shape<1, 1, 1, 8, 64> v356 = pto::Shape<1, 1, 1, 8, 64>();
          // pto: %window_values_inline3392__rv_v8_pview
          ;
          pto::Stride<1024, 1024, 1024, 128, 1> v357 = pto::Stride<1024, 1024, 1024, 128, 1>();
          // pto: %window_values_inline3392__rv_v8_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<1024, 1024, 1024, 128, 1>, pto::Layout::ND> v358 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<1024, 1024, 1024, 128, 1>, pto::Layout::ND>(v353 + (v354 + v277 * v355 + v278), v356, v357);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
          TLOAD(v351, v358);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
          // pto: %weighted_inline3429__tile
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v359 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v42);
          // pto: %weighted_inline3429__tile
          ;
          uint64_t v360 = (uint64_t) v23;
          TASSIGN(v359, v360);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
          TMUL(v359, v351, v349);
          // pto: %24
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v361 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %24
          ;
          uint64_t v362 = (uint64_t) v23;
          TASSIGN(v361, v362);
          // pto: %132
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, 4, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v363;
          // pto: %132
          ;
          uint64_t v364 = (uint64_t) v23;
          TASSIGN(v363, v364);
          // pto: %25
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v365 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %25
          ;
          uint64_t v366 = (uint64_t) v28;
          TASSIGN(v365, v366);
          // pto: %133
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, 4, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v367;
          // pto: %133
          ;
          uint64_t v368 = (uint64_t) v28;
          TASSIGN(v367, v368);
          // pto: %weighted4_inline3430__tile
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v369 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %weighted4_inline3430__tile
          ;
          uint64_t v370 = (uint64_t) v23;
          TASSIGN(v369, v370);
          pipe_barrier(PIPE_V);
          TADD(v369, v363, v367);
          // pto: %26
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v371 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %26
          ;
          uint64_t v372 = (uint64_t) v23;
          TASSIGN(v371, v372);
          // pto: %134
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, 2, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v373;
          // pto: %134
          ;
          uint64_t v374 = (uint64_t) v23;
          TASSIGN(v373, v374);
          // pto: %27
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v375 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %27
          ;
          uint64_t v376 = (uint64_t) v31;
          TASSIGN(v375, v376);
          // pto: %135
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, 2, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v377;
          // pto: %135
          ;
          uint64_t v378 = (uint64_t) v31;
          TASSIGN(v377, v378);
          // pto: %weighted2_inline3431__tile
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v379 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %weighted2_inline3431__tile
          ;
          uint64_t v380 = (uint64_t) v23;
          TASSIGN(v379, v380);
          pipe_barrier(PIPE_V);
          TADD(v379, v373, v377);
          // pto: %28
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v381 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %28
          ;
          uint64_t v382 = (uint64_t) v23;
          TASSIGN(v381, v382);
          // pto: %136
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v383;
          // pto: %136
          ;
          uint64_t v384 = (uint64_t) v23;
          TASSIGN(v383, v384);
          // pto: %29
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v385 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %29
          ;
          uint64_t v386 = (uint64_t) v32;
          TASSIGN(v385, v386);
          // pto: %137
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v387;
          // pto: %137
          ;
          uint64_t v388 = (uint64_t) v32;
          TASSIGN(v387, v388);
          // pto: %30
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v389 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %30
          ;
          uint64_t v390 = (uint64_t) v23;
          TASSIGN(v389, v390);
          pipe_barrier(PIPE_V);
          TADD(v389, v383, v387);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          // pto: %pooled_kv_inline3359__iter_v6_pview
          ;
          __gm__ float* v391 = PTOAS__GLOBAL_TENSOR_DATA(v55);
          // pto: %pooled_kv_inline3359__iter_v6_pview
          ;
          const int64_t v392 = 0;
          // pto: %pooled_kv_inline3359__iter_v6_pview
          ;
          const int64_t v393 = 128;
          // pto: %pooled_kv_inline3359__iter_v6_pview
          ;
          pto::Shape<1, 1, 1, 1, 64> v394 = pto::Shape<1, 1, 1, 1, 64>();
          // pto: %pooled_kv_inline3359__iter_v6_pview
          ;
          pto::Stride<128, 128, 128, 128, 1> v395 = pto::Stride<128, 128, 128, 128, 1>();
          // pto: %pooled_kv_inline3359__iter_v6_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v396 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v391 + (v392 + v134 * v393 + v278), v394, v395);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          TSTORE(v396, v389);
          set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
        };
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    };
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}