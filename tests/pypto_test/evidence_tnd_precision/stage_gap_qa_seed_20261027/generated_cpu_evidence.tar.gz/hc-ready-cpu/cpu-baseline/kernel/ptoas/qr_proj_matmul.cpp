#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qr_proj_matmul(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ float* v3, int64_t v4, int64_t v5, int64_t v6, int64_t v7, int64_t v8, int64_t v9, int32_t v10, int32_t v11) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v12 = 0;
  // pto: %c32768_i64
  const int64_t v13 = 32768;
  // pto: %c49152_i64
  const int64_t v14 = 49152;
  // pto: %c81920_i64
  const int64_t v15 = 81920;
  // pto: %c16384_i64
  const int64_t v16 = 16384;
  // pto: %c4096_index
  const int64_t v17 = 4096;
  // pto: %c1_index
  const int64_t v18 = 1;
  // pto: %c256_index
  const int64_t v19 = 256;
  // pto: %c64_index
  const int64_t v20 = 64;
  // pto: %c16_index
  const int64_t v21 = 16;
  // pto: %c4194304_index
  const int64_t v22 = 4194304;
  // pto: %c16384_index
  const int64_t v23 = 16384;
  // pto: %c1024_index
  const int64_t v24 = 1024;
  // pto: %c32_index
  const int64_t v25 = 32;
  // pto: %c96_index
  const int64_t v26 = 96;
  // pto: %c0_index
  const int64_t v27 = 0;
  // pto: %c2_index
  const int64_t v28 = 2;
  // pto: %c9_index
  const int64_t v29 = 9;
  // pto: %c7_index
  const int64_t v30 = 7;
  // pto: %c8_index
  const int64_t v31 = 8;
  // pto: %cn1_index
  const int64_t v32 = -1;
  // pto: %x_view_inline2841__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %x_view_inline2841__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %x_view_inline2841__ssa_v0_view
  const int64_t v35 = 1;
  // pto: %x_view_inline2841__ssa_v0_view
  int64_t v36 = (int64_t) v8;
  // pto: %x_view_inline2841__ssa_v0_view
  int64_t v37 = v36 * v17;
  // pto: %x_view_inline2841__ssa_v0_view
  int64_t v38 = v35 * v37;
  // pto: %x_view_inline2841__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v39 = pto::Shape<1, 1, 1, -1, -1>(v33, v34, v35, v36, v17);
  // pto: %x_view_inline2841__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v40 = pto::Stride<-1, -1, -1, -1, -1>(v34 * v38, v38, v37, v17, v18);
  // pto: %x_view_inline2841__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v41 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v39, v40);
  // pto: %wq_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v42 = pto::Shape<-1, -1, -1, -1, -1>(v18, v19, v20, v21, v21);
  // pto: %wq_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v43 = pto::Stride<-1, -1, -1, -1, -1>(v22, v23, v19, v21, v18);
  // pto: %wq_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v44 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v2, v42, v43);
  // pto: %qr_fp32_inline2839__rv_v2_view
  const int64_t v45 = 1;
  // pto: %qr_fp32_inline2839__rv_v2_view
  const int64_t v46 = 1;
  // pto: %qr_fp32_inline2839__rv_v2_view
  const int64_t v47 = 1;
  // pto: %qr_fp32_inline2839__rv_v2_view
  int64_t v48 = (int64_t) v9;
  // pto: %qr_fp32_inline2839__rv_v2_view
  int64_t v49 = v48 * v24;
  // pto: %qr_fp32_inline2839__rv_v2_view
  int64_t v50 = v47 * v49;
  // pto: %qr_fp32_inline2839__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v51 = pto::Shape<1, 1, 1, -1, -1>(v45, v46, v47, v48, v24);
  // pto: %qr_fp32_inline2839__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v52 = pto::Stride<-1, -1, -1, -1, -1>(v46 * v50, v50, v49, v24, v18);
  // pto: %qr_fp32_inline2839__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v53 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v51, v52);
  // pto: %qbg_idx_inline2847__ssa_v0, %14
  int64_t v54 = (int64_t) ((uint64_t) ((int64_t) v10) * (uint64_t) v25);
  // pto: %15
  const int64_t v55 = 1;
  // pto: %15
  const int64_t v56 = 0;
  // pto: %15
  int64_t v57 = v54 / v26;
  // pto: %15
  bool v58 = v54 < v56;
  // pto: %15
  bool v59 = v26 < v56;
  // pto: %15
  bool v60 = v58 == v59;
  // pto: %15
  bool v61 = v54 % v26 != v56 && v58 != v59;
  // pto: %15
  int64_t v62 = v61 ? v57 - v55 : v57;
  // pto: %dense_acc_inline2853__tile
  Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v63 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v20, v25);
  // pto: %dense_acc_inline2853__tile
  uint64_t v64 = (uint64_t) v12;
  TASSIGN(v63, v64);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  for (int64_t v65 = v27; v65 < v21; v65 += v28) {
    // pto: %16
    ;
    int64_t v66 = (int64_t) ((uint64_t) v65 + (uint64_t) v18);
    // pto: %17
    ;
    bool v67 = v62 < v29;
    // pto: %dense_k_order_inline2855__phi_v2
    ;
    int64_t v68;
    if (v67) {
      // pto: %18
      ;
      const int64_t v69 = 1;
      // pto: %18
      ;
      const int64_t v70 = 0;
      // pto: %18
      ;
      int64_t v71 = v65 / v28;
      // pto: %18
      ;
      bool v72 = v65 < v70;
      // pto: %18
      ;
      bool v73 = v28 < v70;
      // pto: %18
      ;
      bool v74 = v72 == v73;
      // pto: %18
      ;
      bool v75 = v65 % v28 != v70 && v72 != v73;
      // pto: %18
      ;
      int64_t v76 = v75 ? v71 - v69 : v71;
      // pto: %19
      ;
      int64_t v77 = v62 % v28;
      // pto: %20, %21, %22
      ;
      int64_t v78 = v77 < v27 ? (int64_t) ((uint64_t) v77 + (uint64_t) v28) : v77;
      // pto: %23
      ;
      // pto: %native_packet_inline2856__phi_v2
      ;
      int64_t v79;
      if (v78 == v18) {
        // pto: %24
        ;
        v79 = (int64_t) ((uint64_t) v30 - (uint64_t) v76);
      } else {
        v79 = v76;
      };
      // pto: %25
      ;
      const int64_t v80 = 1;
      // pto: %25
      ;
      const int64_t v81 = 0;
      // pto: %25
      ;
      int64_t v82 = v62 / v28;
      // pto: %25
      ;
      bool v83 = v62 < v81;
      // pto: %25
      ;
      bool v84 = v28 < v81;
      // pto: %25
      ;
      bool v85 = v83 == v84;
      // pto: %25
      ;
      bool v86 = v62 % v28 != v81 && v83 != v84;
      // pto: %25
      ;
      int64_t v87 = v86 ? v82 - v80 : v82;
      // pto: %26
      ;
      uint64_t v88 = (uint64_t) v79;
      // pto: %26, %27
      ;
      int64_t v89 = (int64_t) ((uint64_t) v87 + v88) % v31;
      // pto: %28, %29, %30
      ;
      int64_t v90 = v89 < v27 ? (int64_t) ((uint64_t) v89 + (uint64_t) v31) : v89;
      // pto: %32
      ;
      int64_t v91 = v65 % v28;
      // pto: %33, %34, %35
      ;
      int64_t v92 = v91 < v27 ? (int64_t) ((uint64_t) v91 + (uint64_t) v28) : v91;
      // pto: %31, %36
      ;
      v68 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v90 * (uint64_t) v28) + (uint64_t) v92);
    } else {
      v68 = v65;
    };
    // pto: %37
    ;
    bool v93 = v68 < v27;
    // pto: %37
    ;
    int64_t v94 = v93 ? v27 : v68;
    // pto: %38
    ;
    int64_t v95 = (int64_t) ((uint64_t) v94 * (uint64_t) v19);
    // pto: %dense_x_inline2858__tile
    ;
    Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v96 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v19);
    // pto: %dense_x_inline2858__tile
    ;
    uint64_t v97 = (uint64_t) v12;
    TASSIGN(v96, v97);
    // pto: %39
    ;
    int64_t v98 = v4 < v27 ? v27 : v4;
    // pto: %40
    ;
    int64_t v99 = v95 < v27 ? v27 : v95;
    // pto: %x_view_inline2841__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v100 = PTOAS__GLOBAL_TENSOR_DATA(v41);
    // pto: %x_view_inline2841__ssa_v0_pview
    ;
    const int64_t v101 = 0;
    // pto: %x_view_inline2841__ssa_v0_pview
    ;
    const int64_t v102 = 4096;
    // pto: %x_view_inline2841__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 64, 256> v103 = pto::Shape<1, 1, 1, 64, 256>();
    // pto: %x_view_inline2841__ssa_v0_pview
    ;
    pto::Stride<262144, 262144, 262144, 4096, 1> v104 = pto::Stride<262144, 262144, 262144, 4096, 1>();
    // pto: %x_view_inline2841__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND> v105 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND>(v100 + (v101 + v98 * v102 + v99), v103, v104);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v96, v105);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    // pto: %dense_w_inline2859__tile
    ;
    Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v19);
    // pto: %dense_w_inline2859__tile
    ;
    uint64_t v107 = (uint64_t) v13;
    TASSIGN(v106, v107);
    // pto: %41
    ;
    const int64_t v108 = 1;
    // pto: %41
    ;
    const int64_t v109 = 0;
    // pto: %41
    ;
    int64_t v110 = v95 / v21;
    // pto: %41
    ;
    bool v111 = v95 < v109;
    // pto: %41
    ;
    bool v112 = v21 < v109;
    // pto: %41
    ;
    bool v113 = v111 == v112;
    // pto: %41
    ;
    bool v114 = v95 % v21 != v109 && v111 != v112;
    // pto: %41
    ;
    int64_t v115 = v114 ? v110 - v108 : v110;
    // pto: %42
    ;
    int64_t v116 = v115 < v27 ? v27 : v115;
    // pto: %43
    ;
    const int64_t v117 = 1;
    // pto: %43
    ;
    const int64_t v118 = 0;
    // pto: %43
    ;
    int64_t v119 = v54 / v21;
    // pto: %43
    ;
    bool v120 = v54 < v118;
    // pto: %43
    ;
    bool v121 = v21 < v118;
    // pto: %43
    ;
    bool v122 = v120 == v121;
    // pto: %43
    ;
    bool v123 = v54 % v21 != v118 && v120 != v121;
    // pto: %43
    ;
    int64_t v124 = v123 ? v119 - v117 : v119;
    // pto: %44
    ;
    int64_t v125 = v124 < v27 ? v27 : v124;
    // pto: %wq_a__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v126 = PTOAS__GLOBAL_TENSOR_DATA(v44);
    // pto: %wq_a__ssa_v0_pview
    ;
    const int64_t v127 = 0;
    // pto: %wq_a__ssa_v0_pview
    ;
    const int64_t v128 = 16384;
    // pto: %wq_a__ssa_v0_pview
    ;
    const int64_t v129 = 256;
    // pto: %wq_a__ssa_v0_pview
    ;
    pto::Shape<1, 16, 2, 16, 16> v130 = pto::Shape<1, 16, 2, 16, 16>();
    // pto: %wq_a__ssa_v0_pview
    ;
    pto::Stride<4194304, 16384, 256, 16, 1> v131 = pto::Stride<4194304, 16384, 256, 16, 1>();
    // pto: %wq_a__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v132 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v126 + (v127 + v116 * v128 + v125 * v129), v130, v131);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    TLOAD(v106, v132);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    // pto: %46
    ;
    int64_t v133;
    if (v67) {
      // pto: %48
      ;
      const int64_t v134 = 1;
      // pto: %48
      ;
      const int64_t v135 = 0;
      // pto: %48
      ;
      int64_t v136 = v66 / v28;
      // pto: %48
      ;
      bool v137 = v66 < v135;
      // pto: %48
      ;
      bool v138 = v28 < v135;
      // pto: %48
      ;
      bool v139 = v137 == v138;
      // pto: %48
      ;
      bool v140 = v66 % v28 != v135 && v137 != v138;
      // pto: %48
      ;
      int64_t v141 = v140 ? v136 - v134 : v136;
      // pto: %49
      ;
      int64_t v142 = v62 % v28;
      // pto: %50, %51, %52
      ;
      int64_t v143 = v142 < v27 ? (int64_t) ((uint64_t) v142 + (uint64_t) v28) : v142;
      // pto: %53
      ;
      // pto: %54
      ;
      int64_t v144;
      if (v143 == v18) {
        // pto: %55
        ;
        v144 = (int64_t) ((uint64_t) v30 - (uint64_t) v141);
      } else {
        v144 = v141;
      };
      // pto: %56
      ;
      const int64_t v145 = 1;
      // pto: %56
      ;
      const int64_t v146 = 0;
      // pto: %56
      ;
      int64_t v147 = v62 / v28;
      // pto: %56
      ;
      bool v148 = v62 < v146;
      // pto: %56
      ;
      bool v149 = v28 < v146;
      // pto: %56
      ;
      bool v150 = v148 == v149;
      // pto: %56
      ;
      bool v151 = v62 % v28 != v146 && v148 != v149;
      // pto: %56
      ;
      int64_t v152 = v151 ? v147 - v145 : v147;
      // pto: %57
      ;
      uint64_t v153 = (uint64_t) v144;
      // pto: %57, %58
      ;
      int64_t v154 = (int64_t) ((uint64_t) v152 + v153) % v31;
      // pto: %59, %60, %61
      ;
      int64_t v155 = v154 < v27 ? (int64_t) ((uint64_t) v154 + (uint64_t) v31) : v154;
      // pto: %64
      ;
      int64_t v156 = v66 % v28;
      // pto: %65, %66, %67
      ;
      int64_t v157 = v156 < v27 ? (int64_t) ((uint64_t) v156 + (uint64_t) v28) : v156;
      // pto: %62, %68
      ;
      v133 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v155 * (uint64_t) v28) + (uint64_t) v157);
    } else {
      v133 = v66;
    };
    // pto: %69
    ;
    bool v158 = v133 < v27;
    // pto: %69
    ;
    int64_t v159 = v158 ? v27 : v133;
    // pto: %70
    ;
    int64_t v160 = (int64_t) ((uint64_t) v159 * (uint64_t) v19);
    // pto: %0
    ;
    Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v161 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v19);
    // pto: %0
    ;
    uint64_t v162 = (uint64_t) v14;
    TASSIGN(v161, v162);
    // pto: %72
    ;
    int64_t v163 = v160 < v27 ? v27 : v160;
    // pto: %73
    ;
    __gm__ bfloat16_t* v164 = PTOAS__GLOBAL_TENSOR_DATA(v41);
    // pto: %73
    ;
    const int64_t v165 = 0;
    // pto: %73
    ;
    const int64_t v166 = 4096;
    // pto: %73
    ;
    pto::Shape<1, 1, 1, 64, 256> v167 = pto::Shape<1, 1, 1, 64, 256>();
    // pto: %73
    ;
    pto::Stride<262144, 262144, 262144, 4096, 1> v168 = pto::Stride<262144, 262144, 262144, 4096, 1>();
    // pto: %73
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND> v169 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND>(v164 + (v165 + v98 * v166 + v163), v167, v168);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    TLOAD(v161, v169);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    // pto: %1
    ;
    Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v170 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v19);
    // pto: %1
    ;
    uint64_t v171 = (uint64_t) v15;
    TASSIGN(v170, v171);
    // pto: %74
    ;
    const int64_t v172 = 1;
    // pto: %74
    ;
    const int64_t v173 = 0;
    // pto: %74
    ;
    int64_t v174 = v160 / v21;
    // pto: %74
    ;
    bool v175 = v160 < v173;
    // pto: %74
    ;
    bool v176 = v21 < v173;
    // pto: %74
    ;
    bool v177 = v175 == v176;
    // pto: %74
    ;
    bool v178 = v160 % v21 != v173 && v175 != v176;
    // pto: %74
    ;
    int64_t v179 = v178 ? v174 - v172 : v174;
    // pto: %75
    ;
    int64_t v180 = v179 < v27 ? v27 : v179;
    // pto: %78
    ;
    __gm__ bfloat16_t* v181 = PTOAS__GLOBAL_TENSOR_DATA(v44);
    // pto: %78
    ;
    const int64_t v182 = 0;
    // pto: %78
    ;
    const int64_t v183 = 16384;
    // pto: %78
    ;
    const int64_t v184 = 256;
    // pto: %78
    ;
    pto::Shape<1, 16, 2, 16, 16> v185 = pto::Shape<1, 16, 2, 16, 16>();
    // pto: %78
    ;
    pto::Stride<4194304, 16384, 256, 16, 1> v186 = pto::Stride<4194304, 16384, 256, 16, 1>();
    // pto: %78
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v187 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v181 + (v182 + v180 * v183 + v125 * v184), v185, v186);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    TLOAD(v170, v187);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    // pto: %dense_w_inline2859__tile_t
    ;
    Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v188 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v25);
    // pto: %dense_w_inline2859__tile_t
    ;
    uint64_t v189 = (uint64_t) v13;
    TASSIGN(v188, v189);
    // pto: %dense_x_inline2858__tile_Left
    ;
    Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v190 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v19);
    // pto: %dense_x_inline2858__tile_Left
    ;
    uint64_t v191 = (uint64_t) v13;
    TASSIGN(v190, v191);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    TMOV(v190, v96);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    // pto: %dense_w_inline2859__tile_t_Right
    ;
    Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v192 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v25);
    // pto: %dense_w_inline2859__tile_t_Right
    ;
    uint64_t v193 = (uint64_t) v16;
    TASSIGN(v192, v193);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    TMOV(v192, v188);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    // pto: %79
    ;
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    if (v65 == v27) {
      pipe_barrier(PIPE_M);
      TMATMUL(v63, v190, v192);
    } else {
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v63, v63, v190, v192);
    };
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    // pto: %3
    ;
    Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v194 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v25);
    // pto: %3
    ;
    uint64_t v195 = (uint64_t) v15;
    TASSIGN(v194, v195);
    // pto: %4
    ;
    Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v196 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v19);
    // pto: %4
    ;
    uint64_t v197 = (uint64_t) v12;
    TASSIGN(v196, v197);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    TMOV(v196, v161);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    // pto: %5
    ;
    Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v198 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v25);
    // pto: %5
    ;
    uint64_t v199 = (uint64_t) v12;
    TASSIGN(v198, v199);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    TMOV(v198, v194);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
    // pto: %80
    ;
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
    if (v65 == v32) {
      pipe_barrier(PIPE_M);
      TMATMUL(v63, v196, v198);
    } else {
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v63, v63, v196, v198);
    };
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  // pto: %81
  int64_t v200 = v54 < v27 ? v27 : v54;
  // pto: %qr_fp32_inline2839__rv_v2_pview
  __gm__ float* v201 = PTOAS__GLOBAL_TENSOR_DATA(v53);
  // pto: %qr_fp32_inline2839__rv_v2_pview
  const int64_t v202 = 0;
  // pto: %qr_fp32_inline2839__rv_v2_pview
  pto::Shape<1, 1, 1, 64, 32> v203 = pto::Shape<1, 1, 1, 64, 32>();
  // pto: %qr_fp32_inline2839__rv_v2_pview
  pto::Stride<65536, 65536, 65536, 1024, 1> v204 = pto::Stride<65536, 65536, 65536, 1024, 1>();
  // pto: %qr_fp32_inline2839__rv_v2_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 64, 32>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND> v205 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 32>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND>(v201 + (v202 + v200), v203, v204);
  wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  TSTORE(v205, v63);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  for (int64_t v206 = v5; v206 < v6; v206 += v21) {
    // pto: %q_acc_inline2861__tile
    ;
    Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v21, v25);
    // pto: %q_acc_inline2861__tile
    ;
    uint64_t v208 = (uint64_t) v12;
    TASSIGN(v207, v208);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    for (int64_t v209 = v27; v209 < v21; v209 += v28) {
      // pto: %82
      ;
      int64_t v210 = (int64_t) ((uint64_t) v7 - (uint64_t) v206);
      // pto: %83
      ;
      int64_t v211 = v210 < v21 ? v210 : v21;
      // pto: %84
      ;
      int64_t v212 = (int64_t) ((uint64_t) v4 + (uint64_t) v206);
      // pto: %85
      ;
      int64_t v213 = (int64_t) ((uint64_t) v209 + (uint64_t) v18);
      // pto: %89
      ;
      bool v214 = v62 < v29;
      // pto: %qr_k_order_inline2863__phi_v2
      ;
      int64_t v215;
      if (v214) {
        // pto: %90
        ;
        const int64_t v216 = 1;
        // pto: %90
        ;
        const int64_t v217 = 0;
        // pto: %90
        ;
        int64_t v218 = v209 / v28;
        // pto: %90
        ;
        bool v219 = v209 < v217;
        // pto: %90
        ;
        bool v220 = v28 < v217;
        // pto: %90
        ;
        bool v221 = v219 == v220;
        // pto: %90
        ;
        bool v222 = v209 % v28 != v217 && v219 != v220;
        // pto: %90
        ;
        int64_t v223 = v222 ? v218 - v216 : v218;
        // pto: %91
        ;
        int64_t v224 = v62 % v28;
        // pto: %92, %93, %94
        ;
        int64_t v225 = v224 < v27 ? (int64_t) ((uint64_t) v224 + (uint64_t) v28) : v224;
        // pto: %95
        ;
        // pto: %native_packet_v1_inline2864__phi_v2
        ;
        int64_t v226;
        if (v225 == v18) {
          // pto: %96
          ;
          v226 = (int64_t) ((uint64_t) v30 - (uint64_t) v223);
        } else {
          v226 = v223;
        };
        // pto: %97
        ;
        const int64_t v227 = 1;
        // pto: %97
        ;
        const int64_t v228 = 0;
        // pto: %97
        ;
        int64_t v229 = v62 / v28;
        // pto: %97
        ;
        bool v230 = v62 < v228;
        // pto: %97
        ;
        bool v231 = v28 < v228;
        // pto: %97
        ;
        bool v232 = v230 == v231;
        // pto: %97
        ;
        bool v233 = v62 % v28 != v228 && v230 != v231;
        // pto: %97
        ;
        int64_t v234 = v233 ? v229 - v227 : v229;
        // pto: %98
        ;
        uint64_t v235 = (uint64_t) v226;
        // pto: %98, %99
        ;
        int64_t v236 = (int64_t) ((uint64_t) v234 + v235) % v31;
        // pto: %100, %101, %102
        ;
        int64_t v237 = v236 < v27 ? (int64_t) ((uint64_t) v236 + (uint64_t) v31) : v236;
        // pto: %104
        ;
        int64_t v238 = v209 % v28;
        // pto: %105, %106, %107
        ;
        int64_t v239 = v238 < v27 ? (int64_t) ((uint64_t) v238 + (uint64_t) v28) : v238;
        // pto: %103, %108
        ;
        v215 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v237 * (uint64_t) v28) + (uint64_t) v239);
      } else {
        v215 = v209;
      };
      // pto: %109
      ;
      bool v240 = v215 < v27;
      // pto: %109
      ;
      int64_t v241 = v240 ? v27 : v215;
      // pto: %110
      ;
      int64_t v242 = (int64_t) ((uint64_t) v241 * (uint64_t) v19);
      // pto: %q_x_chunk_bf16_inline2868__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v243 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v211, v19);
      // pto: %q_x_chunk_bf16_inline2868__tile
      ;
      uint64_t v244 = (uint64_t) v13;
      TASSIGN(v243, v244);
      // pto: %111
      ;
      int64_t v245 = v212 < v27 ? v27 : v212;
      // pto: %112
      ;
      int64_t v246 = v242 < v27 ? v27 : v242;
      // pto: %113
      ;
      const int64_t v247 = 0;
      // pto: %113
      ;
      __gm__ bfloat16_t* v248 = PTOAS__GLOBAL_TENSOR_DATA(v41);
      // pto: %113
      ;
      const int64_t v249 = 1;
      // pto: %113
      ;
      const int64_t v250 = 1;
      // pto: %113
      ;
      const int64_t v251 = 1;
      // pto: %113
      ;
      int64_t v252 = v211 * v17;
      // pto: %113
      ;
      int64_t v253 = v251 * v252;
      // pto: %113
      ;
      pto::Shape<1, 1, 1, -1, 256> v254 = pto::Shape<1, 1, 1, -1, 256>(v249, v250, v251, v211, v19);
      // pto: %113
      ;
      pto::Stride<-1, -1, -1, -1, -1> v255 = pto::Stride<-1, -1, -1, -1, -1>(v250 * v253, v253, v252, v17, v18);
      // pto: %113
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v256 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v248 + (v247 + v245 * v17 + v246 * v18), v254, v255);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      TLOAD(v243, v256);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      // pto: %w_chunk_inline2869__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v257 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v19);
      // pto: %w_chunk_inline2869__tile
      ;
      uint64_t v258 = (uint64_t) v12;
      TASSIGN(v257, v258);
      // pto: %114
      ;
      const int64_t v259 = 1;
      // pto: %114
      ;
      const int64_t v260 = 0;
      // pto: %114
      ;
      int64_t v261 = v242 / v21;
      // pto: %114
      ;
      bool v262 = v242 < v260;
      // pto: %114
      ;
      bool v263 = v21 < v260;
      // pto: %114
      ;
      bool v264 = v262 == v263;
      // pto: %114
      ;
      bool v265 = v242 % v21 != v260 && v262 != v263;
      // pto: %114
      ;
      int64_t v266 = v265 ? v261 - v259 : v261;
      // pto: %115
      ;
      int64_t v267 = v266 < v27 ? v27 : v266;
      // pto: %116
      ;
      const int64_t v268 = 1;
      // pto: %116
      ;
      const int64_t v269 = 0;
      // pto: %116
      ;
      int64_t v270 = v54 / v21;
      // pto: %116
      ;
      bool v271 = v54 < v269;
      // pto: %116
      ;
      bool v272 = v21 < v269;
      // pto: %116
      ;
      bool v273 = v271 == v272;
      // pto: %116
      ;
      bool v274 = v54 % v21 != v269 && v271 != v272;
      // pto: %116
      ;
      int64_t v275 = v274 ? v270 - v268 : v270;
      // pto: %117
      ;
      int64_t v276 = v275 < v27 ? v27 : v275;
      // pto: %118
      ;
      __gm__ bfloat16_t* v277 = PTOAS__GLOBAL_TENSOR_DATA(v44);
      // pto: %118
      ;
      const int64_t v278 = 0;
      // pto: %118
      ;
      const int64_t v279 = 16384;
      // pto: %118
      ;
      const int64_t v280 = 256;
      // pto: %118
      ;
      pto::Shape<1, 16, 2, 16, 16> v281 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %118
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v282 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %118
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v283 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v277 + (v278 + v267 * v279 + v276 * v280), v281, v282);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      TLOAD(v257, v283);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      // pto: %120
      ;
      int64_t v284;
      if (v214) {
        // pto: %122
        ;
        const int64_t v285 = 1;
        // pto: %122
        ;
        const int64_t v286 = 0;
        // pto: %122
        ;
        int64_t v287 = v213 / v28;
        // pto: %122
        ;
        bool v288 = v213 < v286;
        // pto: %122
        ;
        bool v289 = v28 < v286;
        // pto: %122
        ;
        bool v290 = v288 == v289;
        // pto: %122
        ;
        bool v291 = v213 % v28 != v286 && v288 != v289;
        // pto: %122
        ;
        int64_t v292 = v291 ? v287 - v285 : v287;
        // pto: %123
        ;
        int64_t v293 = v62 % v28;
        // pto: %124, %125, %126
        ;
        int64_t v294 = v293 < v27 ? (int64_t) ((uint64_t) v293 + (uint64_t) v28) : v293;
        // pto: %127
        ;
        // pto: %128
        ;
        int64_t v295;
        if (v294 == v18) {
          // pto: %129
          ;
          v295 = (int64_t) ((uint64_t) v30 - (uint64_t) v292);
        } else {
          v295 = v292;
        };
        // pto: %130
        ;
        const int64_t v296 = 1;
        // pto: %130
        ;
        const int64_t v297 = 0;
        // pto: %130
        ;
        int64_t v298 = v62 / v28;
        // pto: %130
        ;
        bool v299 = v62 < v297;
        // pto: %130
        ;
        bool v300 = v28 < v297;
        // pto: %130
        ;
        bool v301 = v299 == v300;
        // pto: %130
        ;
        bool v302 = v62 % v28 != v297 && v299 != v300;
        // pto: %130
        ;
        int64_t v303 = v302 ? v298 - v296 : v298;
        // pto: %131
        ;
        uint64_t v304 = (uint64_t) v295;
        // pto: %131, %132
        ;
        int64_t v305 = (int64_t) ((uint64_t) v303 + v304) % v31;
        // pto: %133, %134, %135
        ;
        int64_t v306 = v305 < v27 ? (int64_t) ((uint64_t) v305 + (uint64_t) v31) : v305;
        // pto: %138
        ;
        int64_t v307 = v213 % v28;
        // pto: %139, %140, %141
        ;
        int64_t v308 = v307 < v27 ? (int64_t) ((uint64_t) v307 + (uint64_t) v28) : v307;
        // pto: %136, %142
        ;
        v284 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v306 * (uint64_t) v28) + (uint64_t) v308);
      } else {
        v284 = v213;
      };
      // pto: %143
      ;
      bool v309 = v284 < v27;
      // pto: %143
      ;
      int64_t v310 = v309 ? v27 : v284;
      // pto: %144
      ;
      int64_t v311 = (int64_t) ((uint64_t) v310 * (uint64_t) v19);
      // pto: %7
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v312 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v211, v19);
      // pto: %7
      ;
      uint64_t v313 = (uint64_t) v15;
      TASSIGN(v312, v313);
      // pto: %146
      ;
      int64_t v314 = v311 < v27 ? v27 : v311;
      // pto: %147
      ;
      const int64_t v315 = 0;
      // pto: %147
      ;
      __gm__ bfloat16_t* v316 = PTOAS__GLOBAL_TENSOR_DATA(v41);
      // pto: %147
      ;
      const int64_t v317 = 1;
      // pto: %147
      ;
      const int64_t v318 = 1;
      // pto: %147
      ;
      const int64_t v319 = 1;
      // pto: %147
      ;
      int64_t v320 = v211 * v17;
      // pto: %147
      ;
      int64_t v321 = v319 * v320;
      // pto: %147
      ;
      pto::Shape<1, 1, 1, -1, 256> v322 = pto::Shape<1, 1, 1, -1, 256>(v317, v318, v319, v211, v19);
      // pto: %147
      ;
      pto::Stride<-1, -1, -1, -1, -1> v323 = pto::Stride<-1, -1, -1, -1, -1>(v318 * v321, v321, v320, v17, v18);
      // pto: %147
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v324 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v316 + (v315 + v245 * v17 + v314 * v18), v322, v323);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      TLOAD(v312, v324);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
      // pto: %8
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v325 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v19);
      // pto: %8
      ;
      uint64_t v326 = (uint64_t) v14;
      TASSIGN(v325, v326);
      // pto: %148
      ;
      const int64_t v327 = 1;
      // pto: %148
      ;
      const int64_t v328 = 0;
      // pto: %148
      ;
      int64_t v329 = v311 / v21;
      // pto: %148
      ;
      bool v330 = v311 < v328;
      // pto: %148
      ;
      bool v331 = v21 < v328;
      // pto: %148
      ;
      bool v332 = v330 == v331;
      // pto: %148
      ;
      bool v333 = v311 % v21 != v328 && v330 != v331;
      // pto: %148
      ;
      int64_t v334 = v333 ? v329 - v327 : v329;
      // pto: %149
      ;
      int64_t v335 = v334 < v27 ? v27 : v334;
      // pto: %152
      ;
      __gm__ bfloat16_t* v336 = PTOAS__GLOBAL_TENSOR_DATA(v44);
      // pto: %152
      ;
      const int64_t v337 = 0;
      // pto: %152
      ;
      const int64_t v338 = 16384;
      // pto: %152
      ;
      const int64_t v339 = 256;
      // pto: %152
      ;
      pto::Shape<1, 16, 2, 16, 16> v340 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %152
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v341 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %152
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v342 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v336 + (v337 + v335 * v338 + v276 * v339), v340, v341);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v325, v342);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
      // pto: %w_chunk_inline2869__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v343 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v25);
      // pto: %w_chunk_inline2869__tile_t
      ;
      uint64_t v344 = (uint64_t) v12;
      TASSIGN(v343, v344);
      // pto: %q_x_chunk_bf16_inline2868__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v345 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v211, v19);
      // pto: %q_x_chunk_bf16_inline2868__tile_Left
      ;
      uint64_t v346 = (uint64_t) v13;
      TASSIGN(v345, v346);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      TMOV(v345, v243);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      // pto: %w_chunk_inline2869__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v347 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v25);
      // pto: %w_chunk_inline2869__tile_t_Right
      ;
      uint64_t v348 = (uint64_t) v16;
      TASSIGN(v347, v348);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      TMOV(v347, v343);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      // pto: %153
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      if (v209 == v27) {
        pipe_barrier(PIPE_M);
        TMATMUL(v207, v345, v347);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v207, v207, v345, v347);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      // pto: %10
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v349 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v25);
      // pto: %10
      ;
      uint64_t v350 = (uint64_t) v14;
      TASSIGN(v349, v350);
      // pto: %11
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v351 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v211, v19);
      // pto: %11
      ;
      uint64_t v352 = (uint64_t) v12;
      TASSIGN(v351, v352);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      TMOV(v351, v312);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      // pto: %12
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v353 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v25);
      // pto: %12
      ;
      uint64_t v354 = (uint64_t) v12;
      TASSIGN(v353, v354);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
      TMOV(v353, v349);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %154
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      if (v209 == v32) {
        pipe_barrier(PIPE_M);
        TMATMUL(v207, v351, v353);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v207, v207, v351, v353);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    };
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
    // pto: %156
    ;
    int64_t v355 = v206 < v27 ? v27 : v206;
    // pto: %qr_fp32_inline2839__iter_v9_pview
    ;
    __gm__ float* v356 = PTOAS__GLOBAL_TENSOR_DATA(v53);
    // pto: %qr_fp32_inline2839__iter_v9_pview
    ;
    const int64_t v357 = 0;
    // pto: %qr_fp32_inline2839__iter_v9_pview
    ;
    const int64_t v358 = 1024;
    // pto: %qr_fp32_inline2839__iter_v9_pview
    ;
    pto::Shape<1, 1, 1, 16, 32> v359 = pto::Shape<1, 1, 1, 16, 32>();
    // pto: %qr_fp32_inline2839__iter_v9_pview
    ;
    pto::Stride<16384, 16384, 16384, 1024, 1> v360 = pto::Stride<16384, 16384, 16384, 1024, 1>();
    // pto: %qr_fp32_inline2839__iter_v9_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND> v361 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND>(v356 + (v357 + v355 * v358 + v200), v359, v360);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
    pipe_barrier(PIPE_FIX);
    TSTORE(v361, v207);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  }
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}