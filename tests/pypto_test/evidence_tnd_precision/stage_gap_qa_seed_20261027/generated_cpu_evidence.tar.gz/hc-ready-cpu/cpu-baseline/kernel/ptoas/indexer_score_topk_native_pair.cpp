#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void indexer_score_topk_native_pair_aic(__gm__ int32_t* v1, __gm__ int32_t* v2, __gm__ int64_t* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, __gm__ int64_t* v7, __gm__ int8_t* v8, __gm__ half* v9, __gm__ int32_t* v10, __gm__ int8_t* v11, __gm__ int8_t* v12, __gm__ float* v13, __gm__ int8_t* v14, __gm__ float* v15, int64_t v16, int64_t v17, int64_t v18, int64_t v19, int64_t v20, int64_t v21, int64_t v22, int64_t v23, int32_t v24, int32_t v25) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int64_t v26 = 992;
  const int64_t v27 = 928;
  const int64_t v28 = 864;
  const int64_t v29 = 800;
  const int64_t v30 = 736;
  const int64_t v31 = 672;
  const int64_t v32 = 608;
  const int64_t v33 = 544;
  const int64_t v34 = 480;
  const int64_t v35 = 416;
  const int64_t v36 = 352;
  const int64_t v37 = 224;
  const int64_t v38 = 160;
  const int64_t v39 = 52224;
  const int64_t v40 = 96;
  const int64_t v41 = 51200;
  const int64_t v42 = 50176;
  // pto: %c0_i64
  const int64_t v43 = 0;
  // pto: %c65536_i64
  const int64_t v44 = 65536;
  // pto: %c49152_i64
  const int64_t v45 = 49152;
  // pto: %c16384_i64
  const int64_t v46 = 16384;
  // pto: %c8192_i64
  const int64_t v47 = 8192;
  // pto: %c98304_i64
  const int64_t v48 = 98304;
  // pto: %c1_index
  const int64_t v49 = 1;
  // pto: %c27648_index
  const int64_t v50 = 27648;
  const int64_t v51 = 128;
  // pto: %c1152_index
  const int64_t v52 = 1152;
  const int64_t v53 = 384;
  const int64_t v54 = 288;
  // pto: %c1024_index
  const int64_t v55 = 1024;
  const int64_t v56 = 0;
  // pto: %c4_index
  const int64_t v57 = 4;
  // pto: %c262144_index
  const int64_t v58 = 262144;
  // pto: %c1023_index
  const int64_t v59 = 1023;
  // pto: %c8191_index
  const int64_t v60 = 8191;
  // pto: %c8192_index
  const int64_t v61 = 8192;
  // pto: %c3_index
  const int64_t v62 = 3;
  // pto: %c48_index
  const int64_t v63 = 48;
  // pto: %c24_index
  const int64_t v64 = 24;
  // pto: %c6_index
  const int64_t v65 = 6;
  const int64_t v66 = 32;
  // pto: %c8_index
  const int64_t v67 = 8;
  // pto: %c1_i64
  const int64_t v68 = 1;
  // pto: %c4_i64
  const int64_t v69 = 4;
  const int64_t v70 = 512;
  // pto: %c4096_index
  const int64_t v71 = 4096;
  // pto: %c511_index
  const int64_t v72 = 511;
  const int64_t v73 = 64;
  // pto: %c16_index
  const int64_t v74 = 16;
  // pto: %c2_index
  const int64_t v75 = 2;
  // pto: %c12_index
  const int64_t v76 = 12;
  // pto: %c981467136_i64
  const int64_t v77 = 981467136;
  const int64_t v78 = 192;
  const int64_t v79 = 256;
  const int64_t v80 = 320;
  const int64_t v81 = 448;
  const int64_t v82 = 576;
  const int64_t v83 = 640;
  const int64_t v84 = 704;
  const int64_t v85 = 768;
  const int64_t v86 = 832;
  const int64_t v87 = 896;
  // pto: %c960_index
  const int64_t v88 = 960;
  // pto: %qr_hadamard_i8_inline3547__rv_v2_view
  const int64_t v89 = 1;
  // pto: %qr_hadamard_i8_inline3547__rv_v2_view
  const int64_t v90 = 1;
  // pto: %qr_hadamard_i8_inline3547__rv_v2_view
  const int64_t v91 = 1;
  // pto: %qr_hadamard_i8_inline3547__rv_v2_view
  int64_t v92 = v50 * v51;
  // pto: %qr_hadamard_i8_inline3547__rv_v2_view
  int64_t v93 = v91 * v92;
  // pto: %qr_hadamard_i8_inline3547__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v94 = pto::Shape<1, 1, 1, -1, -1>(v89, v90, v91, v50, v51);
  // pto: %qr_hadamard_i8_inline3547__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v95 = pto::Stride<-1, -1, -1, -1, -1>(v90 * v93, v93, v92, v51, v49);
  // pto: %qr_hadamard_i8_inline3547__rv_v2_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v96 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v94, v95);
  // pto: %coefficients_inline3772__ssa_v0_view
  const int64_t v97 = 1;
  // pto: %coefficients_inline3772__ssa_v0_view
  const int64_t v98 = 1;
  // pto: %coefficients_inline3772__ssa_v0_view
  const int64_t v99 = 1;
  // pto: %coefficients_inline3772__ssa_v0_view
  int64_t v100 = v52 * v53;
  // pto: %coefficients_inline3772__ssa_v0_view
  int64_t v101 = v99 * v100;
  // pto: %coefficients_inline3772__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v102 = pto::Shape<1, 1, 1, -1, -1>(v97, v98, v99, v52, v53);
  // pto: %coefficients_inline3772__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v103 = pto::Stride<-1, -1, -1, -1, -1>(v98 * v101, v101, v100, v53, v49);
  // pto: %coefficients_inline3772__ssa_v0_view
  GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v104 = GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v102, v103);
  // pto: %idx_kv_cache_inline3769__ssa_v0_view
  const int64_t v105 = 1;
  // pto: %idx_kv_cache_inline3769__ssa_v0_view
  const int64_t v106 = 1;
  // pto: %idx_kv_cache_inline3769__ssa_v0_view
  const int64_t v107 = 1;
  // pto: %idx_kv_cache_inline3769__ssa_v0_view
  int64_t v108 = (int64_t) v20;
  // pto: %idx_kv_cache_inline3769__ssa_v0_view
  int64_t v109 = v108 * v51;
  // pto: %idx_kv_cache_inline3769__ssa_v0_view
  int64_t v110 = v107 * v109;
  // pto: %idx_kv_cache_inline3769__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v111 = pto::Shape<1, 1, 1, -1, -1>(v105, v106, v107, v108, v51);
  // pto: %idx_kv_cache_inline3769__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v112 = pto::Stride<-1, -1, -1, -1, -1>(v106 * v110, v110, v109, v51, v49);
  // pto: %idx_kv_cache_inline3769__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v113 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v11, v111, v112);
  // pto: %idx_kv_cache_shift64_inline3770__ssa_v0_view
  const int64_t v114 = 1;
  // pto: %idx_kv_cache_shift64_inline3770__ssa_v0_view
  const int64_t v115 = 1;
  // pto: %idx_kv_cache_shift64_inline3770__ssa_v0_view
  const int64_t v116 = 1;
  // pto: %idx_kv_cache_shift64_inline3770__ssa_v0_view
  int64_t v117 = (int64_t) v21;
  // pto: %idx_kv_cache_shift64_inline3770__ssa_v0_view
  int64_t v118 = v117 * v51;
  // pto: %idx_kv_cache_shift64_inline3770__ssa_v0_view
  int64_t v119 = v116 * v118;
  // pto: %idx_kv_cache_shift64_inline3770__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v120 = pto::Shape<1, 1, 1, -1, -1>(v114, v115, v116, v117, v51);
  // pto: %idx_kv_cache_shift64_inline3770__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v121 = pto::Stride<-1, -1, -1, -1, -1>(v115 * v119, v119, v118, v51, v49);
  // pto: %idx_kv_cache_shift64_inline3770__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v122 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v12, v120, v121);
  // pto: %buf_score_transfer_inline3774__ssa_v0_view
  const int64_t v123 = 1;
  // pto: %buf_score_transfer_inline3774__ssa_v0_view
  const int64_t v124 = 1;
  // pto: %buf_score_transfer_inline3774__ssa_v0_view
  const int64_t v125 = 1;
  // pto: %buf_score_transfer_inline3774__ssa_v0_view
  int64_t v126 = v54 * v55;
  // pto: %buf_score_transfer_inline3774__ssa_v0_view
  int64_t v127 = v125 * v126;
  // pto: %buf_score_transfer_inline3774__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v128 = pto::Shape<1, 1, 1, -1, -1>(v123, v124, v125, v54, v55);
  // pto: %buf_score_transfer_inline3774__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v129 = pto::Stride<-1, -1, -1, -1, -1>(v124 * v127, v127, v126, v55, v49);
  // pto: %buf_score_transfer_inline3774__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v130 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v128, v129);
  // pto: %buf_key_l1_pool_inline3811__phi_v3
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v3
  uint64_t v132 = (uint64_t) v45;
  TASSIGN(v131, v132);
  // pto: %buf_key_l1_pool_inline3811__phi_v6
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v6
  uint64_t v134 = (uint64_t) v45;
  TASSIGN(v133, v134);
  // pto: %buf_key_l1_pool_inline3811__phi_v12
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v135 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v12
  uint64_t v136 = (uint64_t) v45;
  TASSIGN(v135, v136);
  // pto: %buf_key_l1_pool_inline3811__phi_v17
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v17
  uint64_t v138 = (uint64_t) v45;
  TASSIGN(v137, v138);
  // pto: %buf_key_l1_pool_inline3811__phi_v23
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v139 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v23
  uint64_t v140 = (uint64_t) v45;
  TASSIGN(v139, v140);
  // pto: %buf_key_l1_pool_inline3811__phi_v28
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v141 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v28
  uint64_t v142 = (uint64_t) v45;
  TASSIGN(v141, v142);
  // pto: %buf_key_l1_pool_inline3811__phi_v34
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v143 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v34
  uint64_t v144 = (uint64_t) v45;
  TASSIGN(v143, v144);
  // pto: %buf_key_l1_pool_inline3811__phi_v39
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v145 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v39
  uint64_t v146 = (uint64_t) v45;
  TASSIGN(v145, v146);
  // pto: %buf_key_l1_pool_inline3811__phi_v45
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v147 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v45
  uint64_t v148 = (uint64_t) v45;
  TASSIGN(v147, v148);
  // pto: %buf_key_l1_pool_inline3811__phi_v50
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v149 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v50
  uint64_t v150 = (uint64_t) v45;
  TASSIGN(v149, v150);
  // pto: %buf_key_l1_pool_inline3811__phi_v56
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v151 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v56
  uint64_t v152 = (uint64_t) v45;
  TASSIGN(v151, v152);
  // pto: %buf_key_l1_pool_inline3811__phi_v61
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v153 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v61
  uint64_t v154 = (uint64_t) v45;
  TASSIGN(v153, v154);
  // pto: %buf_key_l1_pool_inline3811__phi_v67
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v155 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v67
  uint64_t v156 = (uint64_t) v45;
  TASSIGN(v155, v156);
  // pto: %buf_key_l1_pool_inline3811__phi_v72
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v72
  uint64_t v158 = (uint64_t) v45;
  TASSIGN(v157, v158);
  // pto: %buf_key_l1_pool_inline3811__phi_v78
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v159 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v78
  uint64_t v160 = (uint64_t) v45;
  TASSIGN(v159, v160);
  // pto: %buf_key_l1_pool_inline3811__phi_v83
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v161 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v83
  uint64_t v162 = (uint64_t) v45;
  TASSIGN(v161, v162);
  // pto: %buf_key_l1_pool_inline3811__phi_v89
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v163 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v89
  uint64_t v164 = (uint64_t) v45;
  TASSIGN(v163, v164);
  // pto: %buf_key_l1_pool_inline3811__phi_v94
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v165 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v94
  uint64_t v166 = (uint64_t) v45;
  TASSIGN(v165, v166);
  // pto: %buf_key_l1_pool_inline3811__phi_v100
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v167 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v100
  uint64_t v168 = (uint64_t) v45;
  TASSIGN(v167, v168);
  // pto: %buf_key_l1_pool_inline3811__phi_v105
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v105
  uint64_t v170 = (uint64_t) v45;
  TASSIGN(v169, v170);
  // pto: %buf_key_l1_pool_inline3811__phi_v111
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v171 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v111
  uint64_t v172 = (uint64_t) v45;
  TASSIGN(v171, v172);
  // pto: %buf_key_l1_pool_inline3811__phi_v116
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v173 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v116
  uint64_t v174 = (uint64_t) v45;
  TASSIGN(v173, v174);
  // pto: %buf_key_l1_pool_inline3811__phi_v122
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v122
  uint64_t v176 = (uint64_t) v45;
  TASSIGN(v175, v176);
  // pto: %buf_key_l1_pool_inline3811__phi_v127
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v127
  uint64_t v178 = (uint64_t) v45;
  TASSIGN(v177, v178);
  // pto: %buf_key_l1_pool_inline3811__phi_v133
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v179 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v133
  uint64_t v180 = (uint64_t) v45;
  TASSIGN(v179, v180);
  // pto: %buf_key_l1_pool_inline3811__phi_v138
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v138
  uint64_t v182 = (uint64_t) v45;
  TASSIGN(v181, v182);
  // pto: %buf_key_l1_pool_inline3811__phi_v144
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v144
  uint64_t v184 = (uint64_t) v45;
  TASSIGN(v183, v184);
  // pto: %buf_key_l1_pool_inline3811__phi_v149
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v185 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v149
  uint64_t v186 = (uint64_t) v45;
  TASSIGN(v185, v186);
  // pto: %buf_key_l1_pool_inline3811__phi_v155
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v187 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v155
  uint64_t v188 = (uint64_t) v45;
  TASSIGN(v187, v188);
  // pto: %buf_key_l1_pool_inline3811__phi_v160
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v189 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v160
  uint64_t v190 = (uint64_t) v45;
  TASSIGN(v189, v190);
  // pto: %buf_key_l1_pool_inline3811__phi_v166
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v191 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v166
  uint64_t v192 = (uint64_t) v45;
  TASSIGN(v191, v192);
  // pto: %buf_key_l1_pool_inline3811__phi_v171
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v193 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline3811__phi_v171
  uint64_t v194 = (uint64_t) v45;
  TASSIGN(v193, v194);
  // pto: %buf_worker_inline3777__ssa_v0
  int64_t v195 = (int64_t) v24;
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  // pto: %buf_max_cache_len_inline3778__rv_v2
  int64_t v196;
  v196 = v56;
  for (int64_t v197 = v56; v197 < v17; v197 += v49) {
    // pto: %t__tile
    ;
    int32_t v198 = (v1)[v197];
    // pto: %0
    ;
    int64_t v199 = (int64_t) v198;
    // pto: %1
    ;
    const int64_t v200 = 1;
    // pto: %1
    ;
    const int64_t v201 = 0;
    // pto: %1
    ;
    int64_t v202 = v199 / v57;
    // pto: %1
    ;
    bool v203 = v199 < v201;
    // pto: %1
    ;
    bool v204 = v57 < v201;
    // pto: %1
    ;
    bool v205 = v203 == v204;
    // pto: %1
    ;
    bool v206 = v199 % v57 != v201 && v203 != v204;
    // pto: %1
    ;
    int64_t v207 = v206 ? v202 - v200 : v202;
    // pto: %2
    ;
    bool v208 = v196 < v207;
    // pto: %2
    ;
    int64_t v209 = v208 ? v207 : v196;
    v196 = v209;
  }
  // pto: %3
  bool v210 = v196 < v58;
  // pto: %3
  int64_t v211 = v210 ? v196 : v58;
  // pto: %4
  int32_t v212 = (v2)[v56];
  // pto: %5
  int64_t v213 = (int64_t) v212;
  // pto: %6
  int64_t v214 = (int64_t) ((uint64_t) v211 + (uint64_t) v59);
  // pto: %7
  const int64_t v215 = 1;
  // pto: %7
  const int64_t v216 = 0;
  // pto: %7
  int64_t v217 = v214 / v55;
  // pto: %7
  bool v218 = v214 < v216;
  // pto: %7
  bool v219 = v55 < v216;
  // pto: %7
  bool v220 = v218 == v219;
  // pto: %7
  bool v221 = v214 % v55 != v216 && v218 != v219;
  // pto: %7
  int64_t v222 = v221 ? v217 - v215 : v217;
  // pto: %8
  int64_t v223 = (int64_t) ((uint64_t) v211 + (uint64_t) v60);
  // pto: %9
  const int64_t v224 = 1;
  // pto: %9
  const int64_t v225 = 0;
  // pto: %9
  int64_t v226 = v223 / v61;
  // pto: %9
  bool v227 = v223 < v225;
  // pto: %9
  bool v228 = v61 < v225;
  // pto: %9
  bool v229 = v227 == v228;
  // pto: %9
  bool v230 = v223 % v61 != v225 && v227 != v228;
  // pto: %9
  int64_t v231 = v230 ? v226 - v224 : v226;
  // pto: %10
  int64_t v232 = v231 < v49 ? v49 : v231;
  // pto: %11
  int64_t v233 = (int64_t) ((uint64_t) v213 * (uint64_t) v62);
  // pto: %12
  // pto: %leaf_multiple_inline3962__phi_v6
  int64_t v234;
  if (v233 == v63) {
    v234 = v62;
  } else {
    // pto: %14
    ;
    // pto: %leaf_multiple_inline3962__phi_v5
    ;
    int64_t v235;
    if (v233 == v64) {
      v235 = v62;
    } else {
      // pto: %15, %16, %leaf_multiple_inline3962__phi_v4
      ;
      v235 = (int64_t) ((uint64_t) v213 * (uint64_t) v65) == v64 ? v65 : v49;
    };
    v234 = v235;
  }
  // pto: %17
  bool v236 = v234 > v49;
  // pto: %extra_leaves_inline3961__phi_v3
  int64_t v237;
  // pto: %leaf_count_inline3959__phi_v3
  int64_t v238;
  // pto: %leaf_tiles_inline3960__phi_v3
  int64_t v239;
  if (v236) {
    // pto: %18
    ;
    uint64_t v240 = (uint64_t) v234;
    // pto: %18, %19
    ;
    int64_t v241 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v232 + v240) - (uint64_t) v49);
    // pto: %20
    ;
    const int64_t v242 = 1;
    // pto: %20
    ;
    const int64_t v243 = 0;
    // pto: %20
    ;
    int64_t v244 = v241 / v234;
    // pto: %20
    ;
    int64_t v245 = v241 % v234;
    // pto: %20
    ;
    bool v246 = v241 < v243;
    // pto: %20
    ;
    bool v247 = v234 < v243;
    // pto: %20
    ;
    bool v248 = v246 == v247;
    // pto: %20
    ;
    bool v249 = v245 != v243 && v246 != v247;
    // pto: %20
    ;
    int64_t v250 = v249 ? v244 - v242 : v244;
    // pto: %21
    ;
    uint64_t v251 = (uint64_t) v234;
    // pto: %21
    ;
    int64_t v252 = (int64_t) ((uint64_t) v250 * v251);
    // pto: %22
    ;
    bool v253 = v252 <= v66;
    // pto: %extra_leaves_inline3961__phi_v2
    ;
    // pto: %leaf_count_inline3959__phi_v2
    ;
    int64_t v254;
    // pto: %leaf_tiles_inline3960__phi_v2
    ;
    int64_t v255;
    if (v253) {
      // pto: %23
      ;
      const int64_t v256 = 1;
      // pto: %23
      ;
      const int64_t v257 = 0;
      // pto: %23
      ;
      int64_t v258 = v222 / v252;
      // pto: %23
      ;
      bool v259 = v222 < v257;
      // pto: %23
      ;
      bool v260 = v252 < v257;
      // pto: %23
      ;
      bool v261 = v259 == v260;
      // pto: %23
      ;
      bool v262 = v222 % v252 != v257 && v259 != v260;
      // pto: %23
      ;
      int64_t v263 = v262 ? v258 - v256 : v258;
      // pto: %24
      ;
      // pto: %25
      ;
      int64_t v264 = v222 % v252;
      // pto: %26, %27, %28
      ;
      bool v265 = v264 < v56 ^ v252 < v56;
      // pto: %29, %30, %31, %32
      ;
      v254 = v264 != v56 & v265 ? (int64_t) ((uint64_t) v264 + (uint64_t) v252) : v264;
      v255 = v263 < v49 ? v49 : v263;
    } else {
      v254 = v56;
      v255 = v67;
    };
    v237 = v254;
    v238 = v253 ? v252 : v232;
    v239 = v255;
  } else {
    v237 = v56;
    v238 = v232;
    v239 = v67;
  }
  uint64_t v266 = reinterpret_cast<uint64_t>(v3);
  set_ffts_base_addr(v266);
  // pto: %33
  uint64_t v267 = (uint64_t) v238;
  // pto: %33
  for (int64_t v268 = v195; v268 < ((int64_t) ((uint64_t) v213 * v267)); v268 += v64) {
    // pto: %34
    ;
    // pto: %buf_group_inline3787__phi_v2
    ;
    int64_t v269;
    // pto: %buf_leaf_inline3788__phi_v2
    ;
    int64_t v270;
    if (v213 < v64) {
      // pto: %35
      ;
      int64_t v271 = v268 % v213;
      // pto: %36, %37, %38
      ;
      bool v272 = v271 < v56 ^ v213 < v56;
      // pto: %39, %40, %41, %42
      ;
      // pto: %43
      ;
      const int64_t v273 = 1;
      // pto: %43
      ;
      const int64_t v274 = 0;
      // pto: %43
      ;
      int64_t v275 = v268 / v213;
      // pto: %43
      ;
      bool v276 = v268 < v274;
      // pto: %43
      ;
      bool v277 = v213 < v274;
      // pto: %43
      ;
      bool v278 = v276 == v277;
      // pto: %43
      ;
      bool v279 = v268 % v213 != v274 && v276 != v277;
      // pto: %43
      ;
      v269 = v271 != v56 & v272 ? (int64_t) ((uint64_t) v271 + (uint64_t) v213) : v271;
      v270 = v279 ? v275 - v273 : v275;
    } else {
      // pto: %44
      ;
      const int64_t v280 = 1;
      // pto: %44
      ;
      const int64_t v281 = 0;
      // pto: %44
      ;
      int64_t v282 = v268 / v238;
      // pto: %44
      ;
      int64_t v283 = v268 % v238;
      // pto: %44
      ;
      bool v284 = v268 < v281;
      // pto: %44
      ;
      bool v285 = v238 < v281;
      // pto: %44
      ;
      bool v286 = v284 == v285;
      // pto: %44
      ;
      bool v287 = v283 != v281 && v284 != v285;
      // pto: %44
      ;
      // pto: %45
      ;
      int64_t v288 = v268 % v238;
      // pto: %47
      ;
      bool v289 = v238 < v56;
      // pto: %46, %48
      ;
      bool v290 = v288 < v56 ^ v289;
      // pto: %51
      ;
      uint64_t v291 = (uint64_t) v238;
      // pto: %49, %50, %51, %52
      ;
      v269 = v287 ? v282 - v280 : v282;
      v270 = v288 != v56 & v290 ? (int64_t) ((uint64_t) v288 + v291) : v288;
    };
    // pto: %53
    ;
    int32_t v292 = (v4)[v269];
    // pto: %54
    ;
    int64_t v293 = (int64_t) v292;
    // pto: %55
    ;
    int32_t v294 = (v5)[v269];
    // pto: %57
    ;
    int32_t v295 = (v6)[v293];
    // pto: %58
    ;
    int64_t v296 = (int64_t) v295;
    // pto: %59, %56, %60, %buf_last_position_inline3792__tile
    ;
    int64_t v297 = (v7)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v293 + (uint64_t) ((int64_t) v294)) - (uint64_t) v49)];
    // pto: %61
    ;
    int32_t v298 = (v1)[v296];
    // pto: %62
    ;
    int64_t v299 = (int64_t) v298;
    // pto: %63
    ;
    const int64_t v300 = 1;
    // pto: %63
    ;
    const int64_t v301 = 0;
    // pto: %63
    ;
    int64_t v302 = v299 / v57;
    // pto: %63
    ;
    bool v303 = v299 < v301;
    // pto: %63
    ;
    bool v304 = v57 < v301;
    // pto: %63
    ;
    bool v305 = v303 == v304;
    // pto: %63
    ;
    bool v306 = v299 % v57 != v301 && v303 != v304;
    // pto: %63
    ;
    int64_t v307 = v306 ? v302 - v300 : v302;
    // pto: %64
    ;
    int64_t v308 = (int64_t) ((uint64_t) v297 + (uint64_t) v68);
    // pto: %65
    ;
    const int64_t v309 = 1;
    // pto: %65
    ;
    const int64_t v310 = 0;
    // pto: %65
    ;
    int64_t v311 = v308 / v69;
    // pto: %65
    ;
    bool v312 = v308 < v310;
    // pto: %65
    ;
    bool v313 = v69 < v310;
    // pto: %65
    ;
    bool v314 = v312 == v313;
    // pto: %65
    ;
    bool v315 = v308 % v69 != v310 && v312 != v313;
    // pto: %65
    ;
    int64_t v316 = v315 ? v311 - v309 : v311;
    // pto: %67
    ;
    int64_t v317 = v307 < v316 ? v307 : v316;
    // pto: %68
    ;
    int64_t v318 = v317 < v58 ? v317 : v58;
    // pto: %69
    ;
    int64_t v319 = v318 < v56 ? v56 : v318;
    // pto: %70
    ;
    uint64_t v320 = (uint64_t) v270;
    // pto: %70
    ;
    uint64_t v321 = (uint64_t) v239;
    // pto: %71
    ;
    bool v322 = v270 < v237;
    // pto: %71
    ;
    int64_t v323 = v322 ? v270 : v237;
    // pto: %70, %72, %73
    ;
    int64_t v324 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v320 * v321) + (uint64_t) v323) * (uint64_t) v55);
    // pto: %74
    ;
    bool v325 = v270 < v237;
    // pto: %76
    ;
    uint64_t v326 = (uint64_t) v239;
    // pto: %75, %76, %77
    ;
    int64_t v327 = (int64_t) ((uint64_t) ((int64_t) v326 + (uint64_t) ((int64_t) v325)) * (uint64_t) v55);
    // pto: %78
    ;
    if (v324 < v319) {
      // pto: %79
      ;
      int64_t v328 = (int64_t) ((uint64_t) v319 - (uint64_t) v324);
      // pto: %80
      ;
      int64_t v329 = v327 < v328 ? v327 : v328;
      // pto: %81
      ;
      int64_t v330 = (int64_t) ((uint64_t) v329 + (uint64_t) v59);
      // pto: %82
      ;
      const int64_t v331 = 1;
      // pto: %82
      ;
      const int64_t v332 = 0;
      // pto: %82
      ;
      int64_t v333 = v330 / v55;
      // pto: %82
      ;
      bool v334 = v330 < v332;
      // pto: %82
      ;
      bool v335 = v55 < v332;
      // pto: %82
      ;
      bool v336 = v334 == v335;
      // pto: %82
      ;
      bool v337 = v330 % v55 != v332 && v334 != v335;
      // pto: %82
      ;
      int64_t v338 = v337 ? v333 - v331 : v333;
      // pto: %83
      ;
      int64_t v339 = (int64_t) ((uint64_t) v338 * (uint64_t) v70);
      // pto: %84
      ;
      int64_t v340 = v339 < v71 ? v339 : v71;
      // pto: %85
      ;
      int64_t v341 = (int64_t) ((uint64_t) v340 + (uint64_t) v72);
      // pto: %86
      ;
      const int64_t v342 = 1;
      // pto: %86
      ;
      const int64_t v343 = 0;
      // pto: %86
      ;
      int64_t v344 = v341 / v70;
      // pto: %86
      ;
      bool v345 = v341 < v343;
      // pto: %86
      ;
      bool v346 = v70 < v343;
      // pto: %86
      ;
      bool v347 = v345 == v346;
      // pto: %86
      ;
      bool v348 = v341 % v70 != v343 && v345 != v346;
      // pto: %86
      ;
      int64_t v349 = v348 ? v344 - v342 : v344;
      // pto: %buf_query_vector_inline3801__ssa_v0
      ;
      Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v350 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v51);
      // pto: %buf_query_vector_inline3801__ssa_v0
      ;
      uint64_t v351 = (uint64_t) v43;
      TASSIGN(v350, v351);
      // pto: %87
      ;
      int64_t v352 = (int64_t) ((uint64_t) v293 * (uint64_t) v73);
      // pto: %88
      ;
      int64_t v353 = v352 < v56 ? v56 : v352;
      // pto: %qr_hadamard_i8_inline3547__rv_v2_pview
      ;
      __gm__ int8_t* v354 = PTOAS__GLOBAL_TENSOR_DATA(v96);
      // pto: %qr_hadamard_i8_inline3547__rv_v2_pview
      ;
      const int64_t v355 = 0;
      // pto: %qr_hadamard_i8_inline3547__rv_v2_pview
      ;
      const int64_t v356 = 128;
      // pto: %qr_hadamard_i8_inline3547__rv_v2_pview
      ;
      pto::Shape<1, 1, 1, 384, 128> v357 = pto::Shape<1, 1, 1, 384, 128>();
      // pto: %qr_hadamard_i8_inline3547__rv_v2_pview
      ;
      pto::Stride<49152, 49152, 49152, 128, 1> v358 = pto::Stride<49152, 49152, 49152, 128, 1>();
      // pto: %qr_hadamard_i8_inline3547__rv_v2_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, 384, 128>, pto::Stride<49152, 49152, 49152, 128, 1>, pto::Layout::ND> v359 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 384, 128>, pto::Stride<49152, 49152, 49152, 128, 1>, pto::Layout::ND>(v354 + (v355 + v353 * v356), v357, v358);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v350, v359);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %buf_coefficients_l1_inline3802__ssa_v0
      ;
      Tile<TileType::Mat, half, 16, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v360 = Tile<TileType::Mat, half, 16, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v74, v53);
      // pto: %buf_coefficients_l1_inline3802__ssa_v0
      ;
      uint64_t v361 = (uint64_t) v44;
      TASSIGN(v360, v361);
      // pto: %89
      ;
      uint64_t v362 = (uint64_t) v269;
      // pto: %89
      ;
      int64_t v363 = (int64_t) (v362 * (uint64_t) v74);
      // pto: %90
      ;
      int64_t v364 = v363 < v56 ? v56 : v363;
      // pto: %coefficients_inline3772__ssa_v0_pview
      ;
      __gm__ half* v365 = PTOAS__GLOBAL_TENSOR_DATA(v104);
      // pto: %coefficients_inline3772__ssa_v0_pview
      ;
      const int64_t v366 = 0;
      // pto: %coefficients_inline3772__ssa_v0_pview
      ;
      const int64_t v367 = 384;
      // pto: %coefficients_inline3772__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 384> v368 = pto::Shape<1, 1, 1, 16, 384>();
      // pto: %coefficients_inline3772__ssa_v0_pview
      ;
      pto::Stride<6144, 6144, 6144, 384, 1> v369 = pto::Stride<6144, 6144, 6144, 384, 1>();
      // pto: %coefficients_inline3772__ssa_v0_pview
      ;
      GlobalTensor<half, pto::Shape<1, 1, 1, 16, 384>, pto::Stride<6144, 6144, 6144, 384, 1>, pto::Layout::ND> v370 = GlobalTensor<half, pto::Shape<1, 1, 1, 16, 384>, pto::Stride<6144, 6144, 6144, 384, 1>, pto::Layout::ND>(v365 + (v366 + v364 * v367), v368, v369);
      TLOAD(v360, v370);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %buf_query_left_inline3803__ssa_v0
      ;
      Tile<TileType::Left, int8_t, 384, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v371 = Tile<TileType::Left, int8_t, 384, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v51);
      // pto: %buf_query_left_inline3803__ssa_v0
      ;
      uint64_t v372 = (uint64_t) v43;
      TASSIGN(v371, v372);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      TMOV(v371, v350);
      // pto: %buf_coefficient_pair_inline3804__ssa_v0
      ;
      Tile<TileType::Left, half, 16, 384, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v373 = Tile<TileType::Left, half, 16, 384, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v74, v53);
      // pto: %buf_coefficient_pair_inline3804__ssa_v0
      ;
      uint64_t v374 = (uint64_t) v45;
      TASSIGN(v373, v374);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      TMOV(v373, v360);
      for (int64_t v375 = v56; v375 < v349; v375 += v49) {
        // pto: %91
        ;
        if (v375 >= v75) {
          int32_t v376 = (int32_t) v49;
          wait_flag_dev(v376);
        };
        // pto: %94
        ;
        int64_t v377 = v375 % v75;
        // pto: %95, %96, %97
        ;
        int64_t v378 = v377 < v56 ? (int64_t) ((uint64_t) v377 + (uint64_t) v75) : v377;
        // pto: %93, %99, %98
        ;
        int64_t v379 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v195 * (uint64_t) v76) + (uint64_t) ((int64_t) (uint64_t) v378 * (uint64_t) v65));
        // pto: %buf_key_l1_pool_inline3811__ssa_v0
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v380 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %buf_key_l1_pool_inline3811__ssa_v0
        ;
        uint64_t v381 = (uint64_t) v45;
        TASSIGN(v380, v381);
        // pto: %100, %92
        ;
        int64_t v382 = (int64_t) ((uint64_t) v324 + (uint64_t) ((int64_t) (uint64_t) v375 * (uint64_t) v55));
        // pto: %102
        ;
        const int64_t v383 = 1;
        // pto: %102
        ;
        const int64_t v384 = 0;
        // pto: %102
        ;
        int64_t v385 = v382 / v66;
        // pto: %102
        ;
        bool v386 = v382 < v384;
        // pto: %102
        ;
        bool v387 = v66 < v384;
        // pto: %102
        ;
        bool v388 = v386 == v387;
        // pto: %102
        ;
        bool v389 = v382 % v66 != v384 && v386 != v387;
        // pto: %102
        ;
        int64_t v390 = v389 ? v385 - v383 : v385;
        // pto: %103
        ;
        int64_t v391 = (int64_t) ((uint64_t) v307 - (uint64_t) v49);
        // pto: %104
        ;
        const int64_t v392 = 1;
        // pto: %104
        ;
        const int64_t v393 = 0;
        // pto: %104
        ;
        int64_t v394 = v391 / v66;
        // pto: %104
        ;
        bool v395 = v391 < v393;
        // pto: %104
        ;
        bool v396 = v66 < v393;
        // pto: %104
        ;
        bool v397 = v395 == v396;
        // pto: %104
        ;
        bool v398 = v391 % v66 != v393 && v395 != v396;
        // pto: %104
        ;
        int64_t v399 = v398 ? v394 - v392 : v394;
        // pto: %105
        ;
        int64_t v400 = v399 < v56 ? v56 : v399;
        // pto: %106
        ;
        int64_t v401 = v390 < v400 ? v390 : v400;
        // pto: %flat_offset_mul
        ;
        int64_t v402 = (int64_t) ((uint64_t) v296 * (uint64_t) v19);
        // pto: %flat_offset, %107
        ;
        int32_t v403 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v401)];
        // pto: %108
        ;
        int64_t v404 = (int64_t) v403;
        // pto: %109
        ;
        int64_t v405 = v404 < v56 ? v56 : v404;
        // pto: %110
        ;
        int64_t v406 = (int64_t) ((uint64_t) v405 * (uint64_t) v16);
        // pto: %111
        ;
        int64_t v407 = v406 % v51;
        // pto: %112, %113, %114
        ;
        int64_t v408 = v407 < v56 ? (int64_t) ((uint64_t) v407 + (uint64_t) v51) : v407;
        // pto: %115
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        if (v408 == v56) {
          // pto: %gather_row_view
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v409;
          // pto: %gather_row_view
          ;
          uint64_t v410 = (uint64_t) v45;
          TASSIGN(v409, v410);
          // pto: %116
          ;
          const int64_t v411 = 1;
          // pto: %116
          ;
          const int64_t v412 = 0;
          // pto: %116
          ;
          int64_t v413 = v406 / v51;
          // pto: %116
          ;
          bool v414 = v406 < v412;
          // pto: %116
          ;
          bool v415 = v51 < v412;
          // pto: %116
          ;
          bool v416 = v414 == v415;
          // pto: %116
          ;
          bool v417 = v406 % v51 != v412 && v414 != v415;
          // pto: %116
          ;
          int64_t v418 = v417 ? v413 - v411 : v413;
          // pto: %117
          ;
          int64_t v419 = v418 < v56 ? v56 : v418;
          // pto: %idx_kv_cache_inline3769__ssa_v0_pview
          ;
          __gm__ int8_t* v420 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %idx_kv_cache_inline3769__ssa_v0_pview
          ;
          const int64_t v421 = 0;
          // pto: %idx_kv_cache_inline3769__ssa_v0_pview
          ;
          const int64_t v422 = 128;
          // pto: %idx_kv_cache_inline3769__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 32, 128> v423 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %idx_kv_cache_inline3769__ssa_v0_pview
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v424 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %idx_kv_cache_inline3769__ssa_v0_pview
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v425 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v420 + (v421 + v419 * v422), v423, v424);
          TLOAD(v409, v425);
        } else {
          // pto: %118
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v426;
          // pto: %118
          ;
          uint64_t v427 = (uint64_t) v45;
          TASSIGN(v426, v427);
          // pto: %119
          ;
          const int64_t v428 = 1;
          // pto: %119
          ;
          const int64_t v429 = 0;
          // pto: %119
          ;
          int64_t v430 = v406 / v51;
          // pto: %119
          ;
          bool v431 = v406 < v429;
          // pto: %119
          ;
          bool v432 = v51 < v429;
          // pto: %119
          ;
          bool v433 = v431 == v432;
          // pto: %119
          ;
          bool v434 = v406 % v51 != v429 && v431 != v432;
          // pto: %119
          ;
          int64_t v435 = v434 ? v430 - v428 : v430;
          // pto: %120
          ;
          int64_t v436 = v435 < v56 ? v56 : v435;
          // pto: %idx_kv_cache_shift64_inline3770__ssa_v0_pview
          ;
          __gm__ int8_t* v437 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %idx_kv_cache_shift64_inline3770__ssa_v0_pview
          ;
          const int64_t v438 = 0;
          // pto: %idx_kv_cache_shift64_inline3770__ssa_v0_pview
          ;
          const int64_t v439 = 128;
          // pto: %idx_kv_cache_shift64_inline3770__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 32, 128> v440 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %idx_kv_cache_shift64_inline3770__ssa_v0_pview
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v441 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %idx_kv_cache_shift64_inline3770__ssa_v0_pview
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v442 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v437 + (v438 + v436 * v439), v440, v441);
          TLOAD(v426, v442);
        };
        // pto: %123
        ;
        int64_t v443 = (int64_t) ((uint64_t) v382 + (uint64_t) v66);
        // pto: %124
        ;
        const int64_t v444 = 1;
        // pto: %124
        ;
        const int64_t v445 = 0;
        // pto: %124
        ;
        int64_t v446 = v443 / v66;
        // pto: %124
        ;
        bool v447 = v443 < v445;
        // pto: %124
        ;
        bool v448 = v66 < v445;
        // pto: %124
        ;
        bool v449 = v447 == v448;
        // pto: %124
        ;
        bool v450 = v443 % v66 != v445 && v447 != v448;
        // pto: %124
        ;
        int64_t v451 = v450 ? v446 - v444 : v446;
        // pto: %128
        ;
        int64_t v452 = v451 < v400 ? v451 : v400;
        // pto: %131, %129
        ;
        int32_t v453 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v452)];
        // pto: %132
        ;
        int64_t v454 = (int64_t) v453;
        // pto: %133
        ;
        int64_t v455 = v454 < v56 ? v56 : v454;
        // pto: %134
        ;
        int64_t v456 = (int64_t) ((uint64_t) v455 * (uint64_t) v16);
        // pto: %135
        ;
        int64_t v457 = v456 % v51;
        // pto: %136, %137, %138
        ;
        int64_t v458 = v457 < v56 ? (int64_t) ((uint64_t) v457 + (uint64_t) v51) : v457;
        // pto: %139
        ;
        if (v458 == v56) {
          // pto: %140
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v459;
          // pto: %140
          ;
          uint64_t v460 = (uint64_t) v42;
          TASSIGN(v459, v460);
          // pto: %141
          ;
          const int64_t v461 = 1;
          // pto: %141
          ;
          const int64_t v462 = 0;
          // pto: %141
          ;
          int64_t v463 = v456 / v51;
          // pto: %141
          ;
          bool v464 = v456 < v462;
          // pto: %141
          ;
          bool v465 = v51 < v462;
          // pto: %141
          ;
          bool v466 = v464 == v465;
          // pto: %141
          ;
          bool v467 = v456 % v51 != v462 && v464 != v465;
          // pto: %141
          ;
          int64_t v468 = v467 ? v463 - v461 : v463;
          // pto: %142
          ;
          int64_t v469 = v468 < v56 ? v56 : v468;
          // pto: %143
          ;
          __gm__ int8_t* v470 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %143
          ;
          const int64_t v471 = 0;
          // pto: %143
          ;
          const int64_t v472 = 128;
          // pto: %143
          ;
          pto::Shape<1, 1, 1, 32, 128> v473 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %143
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v474 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %143
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v475 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v470 + (v471 + v469 * v472), v473, v474);
          TLOAD(v459, v475);
        } else {
          // pto: %144
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v476;
          // pto: %144
          ;
          uint64_t v477 = (uint64_t) v42;
          TASSIGN(v476, v477);
          // pto: %145
          ;
          const int64_t v478 = 1;
          // pto: %145
          ;
          const int64_t v479 = 0;
          // pto: %145
          ;
          int64_t v480 = v456 / v51;
          // pto: %145
          ;
          bool v481 = v456 < v479;
          // pto: %145
          ;
          bool v482 = v51 < v479;
          // pto: %145
          ;
          bool v483 = v481 == v482;
          // pto: %145
          ;
          bool v484 = v456 % v51 != v479 && v481 != v482;
          // pto: %145
          ;
          int64_t v485 = v484 ? v480 - v478 : v480;
          // pto: %146
          ;
          int64_t v486 = v485 < v56 ? v56 : v485;
          // pto: %147
          ;
          __gm__ int8_t* v487 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %147
          ;
          const int64_t v488 = 0;
          // pto: %147
          ;
          const int64_t v489 = 128;
          // pto: %147
          ;
          pto::Shape<1, 1, 1, 32, 128> v490 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %147
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v491 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %147
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v492 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v487 + (v488 + v486 * v489), v490, v491);
          TLOAD(v476, v492);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        // pto: %t__tmp_v360
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v493 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v360
        ;
        uint64_t v494 = (uint64_t) v45;
        TASSIGN(v493, v494);
        // pto: %buf_current_key_inline3809__ssa_v1
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v495 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline3809__ssa_v1
        ;
        uint64_t v496 = (uint64_t) v46;
        TASSIGN(v495, v496);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v497 = static_cast<uint16_t>(v56);
        uint16_t v498 = static_cast<uint16_t>(v56);
        TEXTRACT(v495, v493, v497, v498);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %149
        ;
        int64_t v499 = (int64_t) ((uint64_t) v382 + (uint64_t) v73);
        // pto: %150
        ;
        const int64_t v500 = 1;
        // pto: %150
        ;
        const int64_t v501 = 0;
        // pto: %150
        ;
        int64_t v502 = v499 / v66;
        // pto: %150
        ;
        bool v503 = v499 < v501;
        // pto: %150
        ;
        bool v504 = v66 < v501;
        // pto: %150
        ;
        bool v505 = v503 == v504;
        // pto: %150
        ;
        bool v506 = v499 % v66 != v501 && v503 != v504;
        // pto: %150
        ;
        int64_t v507 = v506 ? v502 - v500 : v502;
        // pto: %154
        ;
        int64_t v508 = v507 < v400 ? v507 : v400;
        // pto: %157, %155
        ;
        int32_t v509 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v508)];
        // pto: %158
        ;
        int64_t v510 = (int64_t) v509;
        // pto: %159
        ;
        int64_t v511 = v510 < v56 ? v56 : v510;
        // pto: %160
        ;
        int64_t v512 = (int64_t) ((uint64_t) v511 * (uint64_t) v16);
        // pto: %161
        ;
        int64_t v513 = v512 % v51;
        // pto: %162, %163, %164
        ;
        int64_t v514 = v513 < v56 ? (int64_t) ((uint64_t) v513 + (uint64_t) v51) : v513;
        // pto: %165
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        if (v514 == v56) {
          // pto: %166
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v515;
          // pto: %166
          ;
          uint64_t v516 = (uint64_t) v41;
          TASSIGN(v515, v516);
          // pto: %167
          ;
          const int64_t v517 = 1;
          // pto: %167
          ;
          const int64_t v518 = 0;
          // pto: %167
          ;
          int64_t v519 = v512 / v51;
          // pto: %167
          ;
          bool v520 = v512 < v518;
          // pto: %167
          ;
          bool v521 = v51 < v518;
          // pto: %167
          ;
          bool v522 = v520 == v521;
          // pto: %167
          ;
          bool v523 = v512 % v51 != v518 && v520 != v521;
          // pto: %167
          ;
          int64_t v524 = v523 ? v519 - v517 : v519;
          // pto: %168
          ;
          int64_t v525 = v524 < v56 ? v56 : v524;
          // pto: %169
          ;
          __gm__ int8_t* v526 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %169
          ;
          const int64_t v527 = 0;
          // pto: %169
          ;
          const int64_t v528 = 128;
          // pto: %169
          ;
          pto::Shape<1, 1, 1, 32, 128> v529 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %169
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v530 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %169
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v531 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v526 + (v527 + v525 * v528), v529, v530);
          TLOAD(v515, v531);
        } else {
          // pto: %170
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v532;
          // pto: %170
          ;
          uint64_t v533 = (uint64_t) v41;
          TASSIGN(v532, v533);
          // pto: %171
          ;
          const int64_t v534 = 1;
          // pto: %171
          ;
          const int64_t v535 = 0;
          // pto: %171
          ;
          int64_t v536 = v512 / v51;
          // pto: %171
          ;
          bool v537 = v512 < v535;
          // pto: %171
          ;
          bool v538 = v51 < v535;
          // pto: %171
          ;
          bool v539 = v537 == v538;
          // pto: %171
          ;
          bool v540 = v512 % v51 != v535 && v537 != v538;
          // pto: %171
          ;
          int64_t v541 = v540 ? v536 - v534 : v536;
          // pto: %172
          ;
          int64_t v542 = v541 < v56 ? v56 : v541;
          // pto: %173
          ;
          __gm__ int8_t* v543 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %173
          ;
          const int64_t v544 = 0;
          // pto: %173
          ;
          const int64_t v545 = 128;
          // pto: %173
          ;
          pto::Shape<1, 1, 1, 32, 128> v546 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %173
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v547 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %173
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v548 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v543 + (v544 + v542 * v545), v546, v547);
          TLOAD(v532, v548);
        };
        // pto: %176
        ;
        int64_t v549 = (int64_t) ((uint64_t) v382 + (uint64_t) v40);
        // pto: %177
        ;
        const int64_t v550 = 1;
        // pto: %177
        ;
        const int64_t v551 = 0;
        // pto: %177
        ;
        int64_t v552 = v549 / v66;
        // pto: %177
        ;
        bool v553 = v549 < v551;
        // pto: %177
        ;
        bool v554 = v66 < v551;
        // pto: %177
        ;
        bool v555 = v553 == v554;
        // pto: %177
        ;
        bool v556 = v549 % v66 != v551 && v553 != v554;
        // pto: %177
        ;
        int64_t v557 = v556 ? v552 - v550 : v552;
        // pto: %181
        ;
        int64_t v558 = v557 < v400 ? v557 : v400;
        // pto: %184, %182
        ;
        int32_t v559 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v558)];
        // pto: %185
        ;
        int64_t v560 = (int64_t) v559;
        // pto: %186
        ;
        int64_t v561 = v560 < v56 ? v56 : v560;
        // pto: %187
        ;
        int64_t v562 = (int64_t) ((uint64_t) v561 * (uint64_t) v16);
        // pto: %188
        ;
        int64_t v563 = v562 % v51;
        // pto: %189, %190, %191
        ;
        int64_t v564 = v563 < v56 ? (int64_t) ((uint64_t) v563 + (uint64_t) v51) : v563;
        // pto: %192
        ;
        if (v564 == v56) {
          // pto: %194
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v565;
          // pto: %194
          ;
          uint64_t v566 = (uint64_t) v39;
          TASSIGN(v565, v566);
          // pto: %195
          ;
          const int64_t v567 = 1;
          // pto: %195
          ;
          const int64_t v568 = 0;
          // pto: %195
          ;
          int64_t v569 = v562 / v51;
          // pto: %195
          ;
          bool v570 = v562 < v568;
          // pto: %195
          ;
          bool v571 = v51 < v568;
          // pto: %195
          ;
          bool v572 = v570 == v571;
          // pto: %195
          ;
          bool v573 = v562 % v51 != v568 && v570 != v571;
          // pto: %195
          ;
          int64_t v574 = v573 ? v569 - v567 : v569;
          // pto: %196
          ;
          int64_t v575 = v574 < v56 ? v56 : v574;
          // pto: %197
          ;
          __gm__ int8_t* v576 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %197
          ;
          const int64_t v577 = 0;
          // pto: %197
          ;
          const int64_t v578 = 128;
          // pto: %197
          ;
          pto::Shape<1, 1, 1, 32, 128> v579 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %197
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v580 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %197
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v581 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v576 + (v577 + v575 * v578), v579, v580);
          TLOAD(v565, v581);
        } else {
          // pto: %199
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v582;
          // pto: %199
          ;
          uint64_t v583 = (uint64_t) v39;
          TASSIGN(v582, v583);
          // pto: %200
          ;
          const int64_t v584 = 1;
          // pto: %200
          ;
          const int64_t v585 = 0;
          // pto: %200
          ;
          int64_t v586 = v562 / v51;
          // pto: %200
          ;
          bool v587 = v562 < v585;
          // pto: %200
          ;
          bool v588 = v51 < v585;
          // pto: %200
          ;
          bool v589 = v587 == v588;
          // pto: %200
          ;
          bool v590 = v562 % v51 != v585 && v587 != v588;
          // pto: %200
          ;
          int64_t v591 = v590 ? v586 - v584 : v586;
          // pto: %201
          ;
          int64_t v592 = v591 < v56 ? v56 : v591;
          // pto: %202
          ;
          __gm__ int8_t* v593 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %202
          ;
          const int64_t v594 = 0;
          // pto: %202
          ;
          const int64_t v595 = 128;
          // pto: %202
          ;
          pto::Shape<1, 1, 1, 32, 128> v596 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %202
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v597 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %202
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v598 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v593 + (v594 + v592 * v595), v596, v597);
          TLOAD(v582, v598);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
        // pto: %t__tmp_v363
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v599 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v363
        ;
        uint64_t v600 = (uint64_t) v45;
        TASSIGN(v599, v600);
        // pto: %buf_prefetched_key_inline3810__ssa_v1
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v601 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline3810__ssa_v1
        ;
        uint64_t v602 = (uint64_t) v43;
        TASSIGN(v601, v602);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
        uint16_t v603 = static_cast<uint16_t>(v56);
        uint16_t v604 = static_cast<uint16_t>(v73);
        TEXTRACT(v601, v599, v603, v604);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %buf_key_panel_inline3828__ssa_v0
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v605 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline3828__ssa_v0
        ;
        uint64_t v606 = (uint64_t) v46;
        TASSIGN(v605, v606);
        // pto: %buf_scores_l1_inline3829__ssa_v0
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v607 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline3829__ssa_v0
        ;
        uint64_t v608 = (uint64_t) v43;
        TASSIGN(v607, v608);
        // pto: %buf_scores_inline3831__ssa_v1
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v609 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline3831__ssa_v1
        ;
        uint64_t v610 = (uint64_t) v43;
        TASSIGN(v609, v610);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        TMATMUL(v609, v371, v605);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v611 = static_cast<uint64_t>(v77);
        uint16_t v612 = static_cast<uint16_t>(v56);
        uint16_t v613 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v607, v609, v611, v612, v613);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        // pto: %buf_previous_l1_inline3808__ssa_v1
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v614 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline3808__ssa_v1
        ;
        uint64_t v615 = (uint64_t) v43;
        TASSIGN(v614, v615);
        // pto: %buf_current_key_inline3809__ssa_v7
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v616 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline3809__ssa_v7
        ;
        uint64_t v617 = (uint64_t) v43;
        TASSIGN(v616, v617);
        // pto: %204
        ;
        int64_t v618 = (int64_t) ((uint64_t) v382 + (uint64_t) v51);
        // pto: %205
        ;
        const int64_t v619 = 1;
        // pto: %205
        ;
        const int64_t v620 = 0;
        // pto: %205
        ;
        int64_t v621 = v618 / v66;
        // pto: %205
        ;
        bool v622 = v618 < v620;
        // pto: %205
        ;
        bool v623 = v66 < v620;
        // pto: %205
        ;
        bool v624 = v622 == v623;
        // pto: %205
        ;
        bool v625 = v618 % v66 != v620 && v622 != v623;
        // pto: %205
        ;
        int64_t v626 = v625 ? v621 - v619 : v621;
        // pto: %209
        ;
        int64_t v627 = v626 < v400 ? v626 : v400;
        // pto: %212, %210
        ;
        int32_t v628 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v627)];
        // pto: %213
        ;
        int64_t v629 = (int64_t) v628;
        // pto: %214
        ;
        int64_t v630 = v629 < v56 ? v56 : v629;
        // pto: %215
        ;
        int64_t v631 = (int64_t) ((uint64_t) v630 * (uint64_t) v16);
        // pto: %216
        ;
        int64_t v632 = v631 % v51;
        // pto: %217, %218, %219
        ;
        int64_t v633 = v632 < v56 ? (int64_t) ((uint64_t) v632 + (uint64_t) v51) : v632;
        // pto: %220
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        if (v633 == v56) {
          // pto: %221
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v634;
          // pto: %221
          ;
          uint64_t v635 = (uint64_t) v45;
          TASSIGN(v634, v635);
          // pto: %222
          ;
          const int64_t v636 = 1;
          // pto: %222
          ;
          const int64_t v637 = 0;
          // pto: %222
          ;
          int64_t v638 = v631 / v51;
          // pto: %222
          ;
          bool v639 = v631 < v637;
          // pto: %222
          ;
          bool v640 = v51 < v637;
          // pto: %222
          ;
          bool v641 = v639 == v640;
          // pto: %222
          ;
          bool v642 = v631 % v51 != v637 && v639 != v640;
          // pto: %222
          ;
          int64_t v643 = v642 ? v638 - v636 : v638;
          // pto: %223
          ;
          int64_t v644 = v643 < v56 ? v56 : v643;
          // pto: %224
          ;
          __gm__ int8_t* v645 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %224
          ;
          const int64_t v646 = 0;
          // pto: %224
          ;
          const int64_t v647 = 128;
          // pto: %224
          ;
          pto::Shape<1, 1, 1, 32, 128> v648 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %224
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v649 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %224
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v650 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v645 + (v646 + v644 * v647), v648, v649);
          TLOAD(v634, v650);
        } else {
          // pto: %225
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v651;
          // pto: %225
          ;
          uint64_t v652 = (uint64_t) v45;
          TASSIGN(v651, v652);
          // pto: %226
          ;
          const int64_t v653 = 1;
          // pto: %226
          ;
          const int64_t v654 = 0;
          // pto: %226
          ;
          int64_t v655 = v631 / v51;
          // pto: %226
          ;
          bool v656 = v631 < v654;
          // pto: %226
          ;
          bool v657 = v51 < v654;
          // pto: %226
          ;
          bool v658 = v656 == v657;
          // pto: %226
          ;
          bool v659 = v631 % v51 != v654 && v656 != v657;
          // pto: %226
          ;
          int64_t v660 = v659 ? v655 - v653 : v655;
          // pto: %227
          ;
          int64_t v661 = v660 < v56 ? v56 : v660;
          // pto: %228
          ;
          __gm__ int8_t* v662 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %228
          ;
          const int64_t v663 = 0;
          // pto: %228
          ;
          const int64_t v664 = 128;
          // pto: %228
          ;
          pto::Shape<1, 1, 1, 32, 128> v665 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %228
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v666 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %228
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v667 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v662 + (v663 + v661 * v664), v665, v666);
          TLOAD(v651, v667);
        };
        // pto: %231
        ;
        int64_t v668 = (int64_t) ((uint64_t) v382 + (uint64_t) v38);
        // pto: %232
        ;
        const int64_t v669 = 1;
        // pto: %232
        ;
        const int64_t v670 = 0;
        // pto: %232
        ;
        int64_t v671 = v668 / v66;
        // pto: %232
        ;
        bool v672 = v668 < v670;
        // pto: %232
        ;
        bool v673 = v66 < v670;
        // pto: %232
        ;
        bool v674 = v672 == v673;
        // pto: %232
        ;
        bool v675 = v668 % v66 != v670 && v672 != v673;
        // pto: %232
        ;
        int64_t v676 = v675 ? v671 - v669 : v671;
        // pto: %236
        ;
        int64_t v677 = v676 < v400 ? v676 : v400;
        // pto: %239, %237
        ;
        int32_t v678 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v677)];
        // pto: %240
        ;
        int64_t v679 = (int64_t) v678;
        // pto: %241
        ;
        int64_t v680 = v679 < v56 ? v56 : v679;
        // pto: %242
        ;
        int64_t v681 = (int64_t) ((uint64_t) v680 * (uint64_t) v16);
        // pto: %243
        ;
        int64_t v682 = v681 % v51;
        // pto: %244, %245, %246
        ;
        int64_t v683 = v682 < v56 ? (int64_t) ((uint64_t) v682 + (uint64_t) v51) : v682;
        // pto: %247
        ;
        if (v683 == v56) {
          // pto: %249
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v684;
          // pto: %249
          ;
          uint64_t v685 = (uint64_t) v42;
          TASSIGN(v684, v685);
          // pto: %250
          ;
          const int64_t v686 = 1;
          // pto: %250
          ;
          const int64_t v687 = 0;
          // pto: %250
          ;
          int64_t v688 = v681 / v51;
          // pto: %250
          ;
          bool v689 = v681 < v687;
          // pto: %250
          ;
          bool v690 = v51 < v687;
          // pto: %250
          ;
          bool v691 = v689 == v690;
          // pto: %250
          ;
          bool v692 = v681 % v51 != v687 && v689 != v690;
          // pto: %250
          ;
          int64_t v693 = v692 ? v688 - v686 : v688;
          // pto: %251
          ;
          int64_t v694 = v693 < v56 ? v56 : v693;
          // pto: %252
          ;
          __gm__ int8_t* v695 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %252
          ;
          const int64_t v696 = 0;
          // pto: %252
          ;
          const int64_t v697 = 128;
          // pto: %252
          ;
          pto::Shape<1, 1, 1, 32, 128> v698 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %252
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v699 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %252
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v700 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v695 + (v696 + v694 * v697), v698, v699);
          TLOAD(v684, v700);
        } else {
          // pto: %254
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v701;
          // pto: %254
          ;
          uint64_t v702 = (uint64_t) v42;
          TASSIGN(v701, v702);
          // pto: %255
          ;
          const int64_t v703 = 1;
          // pto: %255
          ;
          const int64_t v704 = 0;
          // pto: %255
          ;
          int64_t v705 = v681 / v51;
          // pto: %255
          ;
          bool v706 = v681 < v704;
          // pto: %255
          ;
          bool v707 = v51 < v704;
          // pto: %255
          ;
          bool v708 = v706 == v707;
          // pto: %255
          ;
          bool v709 = v681 % v51 != v704 && v706 != v707;
          // pto: %255
          ;
          int64_t v710 = v709 ? v705 - v703 : v705;
          // pto: %256
          ;
          int64_t v711 = v710 < v56 ? v56 : v710;
          // pto: %257
          ;
          __gm__ int8_t* v712 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %257
          ;
          const int64_t v713 = 0;
          // pto: %257
          ;
          const int64_t v714 = 128;
          // pto: %257
          ;
          pto::Shape<1, 1, 1, 32, 128> v715 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %257
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v716 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %257
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v717 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v712 + (v713 + v711 * v714), v715, v716);
          TLOAD(v701, v717);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
        // pto: %t__tmp_v366
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v718 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v366
        ;
        uint64_t v719 = (uint64_t) v45;
        TASSIGN(v718, v719);
        // pto: %buf_prefetched_key_inline3810__ssa_v6
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v720 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline3810__ssa_v6
        ;
        uint64_t v721 = (uint64_t) v47;
        TASSIGN(v720, v721);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
        uint16_t v722 = static_cast<uint16_t>(v56);
        uint16_t v723 = static_cast<uint16_t>(v56);
        TEXTRACT(v720, v718, v722, v723);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        // pto: %buf_key_panel_inline3828__ssa_v3
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v724 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline3828__ssa_v3
        ;
        uint64_t v725 = (uint64_t) v43;
        TASSIGN(v724, v725);
        // pto: %buf_scores_l1_inline3829__ssa_v4
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v726 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline3829__ssa_v4
        ;
        uint64_t v727 = (uint64_t) v44;
        TASSIGN(v726, v727);
        // pto: %buf_previous_pair_inline3830__ssa_v1
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v728 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline3830__ssa_v1
        ;
        uint64_t v729 = (uint64_t) v46;
        TASSIGN(v728, v729);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        uint16_t v730 = static_cast<uint16_t>(v56);
        uint16_t v731 = static_cast<uint16_t>(v56);
        TEXTRACT(v728, v614, v730, v731);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %buf_scores_inline3831__ssa_v3
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v732 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline3831__ssa_v3
        ;
        uint64_t v733 = (uint64_t) v43;
        TASSIGN(v732, v733);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL(v732, v371, v724);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        // pto: %buf_reduced_pair_inline3832__ssa_v1
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v734 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline3832__ssa_v1
        ;
        uint64_t v735 = (uint64_t) v48;
        TASSIGN(v734, v735);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        TMATMUL(v734, v373, v728);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        uint64_t v736 = static_cast<uint64_t>(v77);
        uint16_t v737 = static_cast<uint16_t>(v56);
        uint16_t v738 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v726, v732, v736, v737, v738);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID1);
        v734.SetValidShape(v65, v73);
        // pto: %258
        ;
        int64_t v739 = v379 < v56 ? v56 : v379;
        // pto: %buf_score_transfer_inline3774__ssa_v0_pview
        ;
        __gm__ float* v740 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %buf_score_transfer_inline3774__ssa_v0_pview
        ;
        const int64_t v741 = 0;
        // pto: %buf_score_transfer_inline3774__ssa_v0_pview
        ;
        const int64_t v742 = 1024;
        // pto: %buf_score_transfer_inline3774__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 6, 64> v743 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %buf_score_transfer_inline3774__ssa_v0_pview
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v744 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %buf_score_transfer_inline3774__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v745 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v740 + (v741 + v739 * v742), v743, v744);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
        TSTORE(v745, v734);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
        // pto: %buf_previous_l1_inline3808__ssa_v2
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v746 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline3808__ssa_v2
        ;
        uint64_t v747 = (uint64_t) v44;
        TASSIGN(v746, v747);
        // pto: %buf_current_key_inline3809__ssa_v14
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v748 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline3809__ssa_v14
        ;
        uint64_t v749 = (uint64_t) v47;
        TASSIGN(v748, v749);
        // pto: %262
        ;
        int64_t v750 = (int64_t) ((uint64_t) v382 + (uint64_t) v78);
        // pto: %263
        ;
        const int64_t v751 = 1;
        // pto: %263
        ;
        const int64_t v752 = 0;
        // pto: %263
        ;
        int64_t v753 = v750 / v66;
        // pto: %263
        ;
        bool v754 = v750 < v752;
        // pto: %263
        ;
        bool v755 = v66 < v752;
        // pto: %263
        ;
        bool v756 = v754 == v755;
        // pto: %263
        ;
        bool v757 = v750 % v66 != v752 && v754 != v755;
        // pto: %263
        ;
        int64_t v758 = v757 ? v753 - v751 : v753;
        // pto: %267
        ;
        int64_t v759 = v758 < v400 ? v758 : v400;
        // pto: %270, %268
        ;
        int32_t v760 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v759)];
        // pto: %271
        ;
        int64_t v761 = (int64_t) v760;
        // pto: %272
        ;
        int64_t v762 = v761 < v56 ? v56 : v761;
        // pto: %273
        ;
        int64_t v763 = (int64_t) ((uint64_t) v762 * (uint64_t) v16);
        // pto: %274
        ;
        int64_t v764 = v763 % v51;
        // pto: %275, %276, %277
        ;
        int64_t v765 = v764 < v56 ? (int64_t) ((uint64_t) v764 + (uint64_t) v51) : v764;
        // pto: %278
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        if (v765 == v56) {
          // pto: %279
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v766;
          // pto: %279
          ;
          uint64_t v767 = (uint64_t) v41;
          TASSIGN(v766, v767);
          // pto: %280
          ;
          const int64_t v768 = 1;
          // pto: %280
          ;
          const int64_t v769 = 0;
          // pto: %280
          ;
          int64_t v770 = v763 / v51;
          // pto: %280
          ;
          bool v771 = v763 < v769;
          // pto: %280
          ;
          bool v772 = v51 < v769;
          // pto: %280
          ;
          bool v773 = v771 == v772;
          // pto: %280
          ;
          bool v774 = v763 % v51 != v769 && v771 != v772;
          // pto: %280
          ;
          int64_t v775 = v774 ? v770 - v768 : v770;
          // pto: %281
          ;
          int64_t v776 = v775 < v56 ? v56 : v775;
          // pto: %282
          ;
          __gm__ int8_t* v777 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %282
          ;
          const int64_t v778 = 0;
          // pto: %282
          ;
          const int64_t v779 = 128;
          // pto: %282
          ;
          pto::Shape<1, 1, 1, 32, 128> v780 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %282
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v781 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %282
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v782 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v777 + (v778 + v776 * v779), v780, v781);
          TLOAD(v766, v782);
        } else {
          // pto: %283
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v783;
          // pto: %283
          ;
          uint64_t v784 = (uint64_t) v41;
          TASSIGN(v783, v784);
          // pto: %284
          ;
          const int64_t v785 = 1;
          // pto: %284
          ;
          const int64_t v786 = 0;
          // pto: %284
          ;
          int64_t v787 = v763 / v51;
          // pto: %284
          ;
          bool v788 = v763 < v786;
          // pto: %284
          ;
          bool v789 = v51 < v786;
          // pto: %284
          ;
          bool v790 = v788 == v789;
          // pto: %284
          ;
          bool v791 = v763 % v51 != v786 && v788 != v789;
          // pto: %284
          ;
          int64_t v792 = v791 ? v787 - v785 : v787;
          // pto: %285
          ;
          int64_t v793 = v792 < v56 ? v56 : v792;
          // pto: %286
          ;
          __gm__ int8_t* v794 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %286
          ;
          const int64_t v795 = 0;
          // pto: %286
          ;
          const int64_t v796 = 128;
          // pto: %286
          ;
          pto::Shape<1, 1, 1, 32, 128> v797 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %286
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v798 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %286
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v799 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v794 + (v795 + v793 * v796), v797, v798);
          TLOAD(v783, v799);
        };
        // pto: %289
        ;
        int64_t v800 = (int64_t) ((uint64_t) v382 + (uint64_t) v37);
        // pto: %290
        ;
        const int64_t v801 = 1;
        // pto: %290
        ;
        const int64_t v802 = 0;
        // pto: %290
        ;
        int64_t v803 = v800 / v66;
        // pto: %290
        ;
        bool v804 = v800 < v802;
        // pto: %290
        ;
        bool v805 = v66 < v802;
        // pto: %290
        ;
        bool v806 = v804 == v805;
        // pto: %290
        ;
        bool v807 = v800 % v66 != v802 && v804 != v805;
        // pto: %290
        ;
        int64_t v808 = v807 ? v803 - v801 : v803;
        // pto: %294
        ;
        int64_t v809 = v808 < v400 ? v808 : v400;
        // pto: %297, %295
        ;
        int32_t v810 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v809)];
        // pto: %298
        ;
        int64_t v811 = (int64_t) v810;
        // pto: %299
        ;
        int64_t v812 = v811 < v56 ? v56 : v811;
        // pto: %300
        ;
        int64_t v813 = (int64_t) ((uint64_t) v812 * (uint64_t) v16);
        // pto: %301
        ;
        int64_t v814 = v813 % v51;
        // pto: %302, %303, %304
        ;
        int64_t v815 = v814 < v56 ? (int64_t) ((uint64_t) v814 + (uint64_t) v51) : v814;
        // pto: %305
        ;
        if (v815 == v56) {
          // pto: %307
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v816;
          // pto: %307
          ;
          uint64_t v817 = (uint64_t) v39;
          TASSIGN(v816, v817);
          // pto: %308
          ;
          const int64_t v818 = 1;
          // pto: %308
          ;
          const int64_t v819 = 0;
          // pto: %308
          ;
          int64_t v820 = v813 / v51;
          // pto: %308
          ;
          bool v821 = v813 < v819;
          // pto: %308
          ;
          bool v822 = v51 < v819;
          // pto: %308
          ;
          bool v823 = v821 == v822;
          // pto: %308
          ;
          bool v824 = v813 % v51 != v819 && v821 != v822;
          // pto: %308
          ;
          int64_t v825 = v824 ? v820 - v818 : v820;
          // pto: %309
          ;
          int64_t v826 = v825 < v56 ? v56 : v825;
          // pto: %310
          ;
          __gm__ int8_t* v827 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %310
          ;
          const int64_t v828 = 0;
          // pto: %310
          ;
          const int64_t v829 = 128;
          // pto: %310
          ;
          pto::Shape<1, 1, 1, 32, 128> v830 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %310
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v831 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %310
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v832 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v827 + (v828 + v826 * v829), v830, v831);
          TLOAD(v816, v832);
        } else {
          // pto: %312
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v833;
          // pto: %312
          ;
          uint64_t v834 = (uint64_t) v39;
          TASSIGN(v833, v834);
          // pto: %313
          ;
          const int64_t v835 = 1;
          // pto: %313
          ;
          const int64_t v836 = 0;
          // pto: %313
          ;
          int64_t v837 = v813 / v51;
          // pto: %313
          ;
          bool v838 = v813 < v836;
          // pto: %313
          ;
          bool v839 = v51 < v836;
          // pto: %313
          ;
          bool v840 = v838 == v839;
          // pto: %313
          ;
          bool v841 = v813 % v51 != v836 && v838 != v839;
          // pto: %313
          ;
          int64_t v842 = v841 ? v837 - v835 : v837;
          // pto: %314
          ;
          int64_t v843 = v842 < v56 ? v56 : v842;
          // pto: %315
          ;
          __gm__ int8_t* v844 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %315
          ;
          const int64_t v845 = 0;
          // pto: %315
          ;
          const int64_t v846 = 128;
          // pto: %315
          ;
          pto::Shape<1, 1, 1, 32, 128> v847 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %315
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v848 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %315
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v849 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v844 + (v845 + v843 * v846), v847, v848);
          TLOAD(v833, v849);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        // pto: %t__tmp_v370
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v850 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v370
        ;
        uint64_t v851 = (uint64_t) v45;
        TASSIGN(v850, v851);
        // pto: %buf_prefetched_key_inline3810__ssa_v11
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v852 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline3810__ssa_v11
        ;
        uint64_t v853 = (uint64_t) v43;
        TASSIGN(v852, v853);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v854 = static_cast<uint16_t>(v56);
        uint16_t v855 = static_cast<uint16_t>(v73);
        TEXTRACT(v852, v850, v854, v855);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
        // pto: %buf_key_panel_inline3828__ssa_v6
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v856 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline3828__ssa_v6
        ;
        uint64_t v857 = (uint64_t) v47;
        TASSIGN(v856, v857);
        // pto: %buf_scores_l1_inline3829__ssa_v8
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v858 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline3829__ssa_v8
        ;
        uint64_t v859 = (uint64_t) v43;
        TASSIGN(v858, v859);
        // pto: %buf_previous_pair_inline3830__ssa_v2
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v860 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline3830__ssa_v2
        ;
        uint64_t v861 = (uint64_t) v46;
        TASSIGN(v860, v861);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v862 = static_cast<uint16_t>(v56);
        uint16_t v863 = static_cast<uint16_t>(v56);
        TEXTRACT(v860, v746, v862, v863);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        // pto: %buf_scores_inline3831__ssa_v6
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v864 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline3831__ssa_v6
        ;
        uint64_t v865 = (uint64_t) v43;
        TASSIGN(v864, v865);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v864, v371, v856);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
        // pto: %buf_reduced_pair_inline3832__ssa_v2
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v866 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline3832__ssa_v2
        ;
        uint64_t v867 = (uint64_t) v48;
        TASSIGN(v866, v867);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
        TMATMUL(v866, v373, v860);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
        uint64_t v868 = static_cast<uint64_t>(v77);
        uint16_t v869 = static_cast<uint16_t>(v56);
        uint16_t v870 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v858, v864, v868, v869, v870);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID2);
        v866.SetValidShape(v65, v73);
        // pto: %319
        ;
        __gm__ float* v871 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %319
        ;
        const int64_t v872 = 64;
        // pto: %319
        ;
        const int64_t v873 = 1024;
        // pto: %319
        ;
        pto::Shape<1, 1, 1, 6, 64> v874 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %319
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v875 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %319
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v876 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v871 + (v872 + v739 * v873), v874, v875);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
        TSTORE(v876, v866);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
        // pto: %buf_previous_l1_inline3808__ssa_v3
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v877 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline3808__ssa_v3
        ;
        uint64_t v878 = (uint64_t) v43;
        TASSIGN(v877, v878);
        // pto: %buf_current_key_inline3809__ssa_v21
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v879 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline3809__ssa_v21
        ;
        uint64_t v880 = (uint64_t) v43;
        TASSIGN(v879, v880);
        // pto: %321
        ;
        int64_t v881 = (int64_t) ((uint64_t) v382 + (uint64_t) v79);
        // pto: %322
        ;
        const int64_t v882 = 1;
        // pto: %322
        ;
        const int64_t v883 = 0;
        // pto: %322
        ;
        int64_t v884 = v881 / v66;
        // pto: %322
        ;
        bool v885 = v881 < v883;
        // pto: %322
        ;
        bool v886 = v66 < v883;
        // pto: %322
        ;
        bool v887 = v885 == v886;
        // pto: %322
        ;
        bool v888 = v881 % v66 != v883 && v885 != v886;
        // pto: %322
        ;
        int64_t v889 = v888 ? v884 - v882 : v884;
        // pto: %326
        ;
        int64_t v890 = v889 < v400 ? v889 : v400;
        // pto: %329, %327
        ;
        int32_t v891 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v890)];
        // pto: %330
        ;
        int64_t v892 = (int64_t) v891;
        // pto: %331
        ;
        int64_t v893 = v892 < v56 ? v56 : v892;
        // pto: %332
        ;
        int64_t v894 = (int64_t) ((uint64_t) v893 * (uint64_t) v16);
        // pto: %333
        ;
        int64_t v895 = v894 % v51;
        // pto: %334, %335, %336
        ;
        int64_t v896 = v895 < v56 ? (int64_t) ((uint64_t) v895 + (uint64_t) v51) : v895;
        // pto: %337
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        if (v896 == v56) {
          // pto: %338
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v897;
          // pto: %338
          ;
          uint64_t v898 = (uint64_t) v45;
          TASSIGN(v897, v898);
          // pto: %339
          ;
          const int64_t v899 = 1;
          // pto: %339
          ;
          const int64_t v900 = 0;
          // pto: %339
          ;
          int64_t v901 = v894 / v51;
          // pto: %339
          ;
          bool v902 = v894 < v900;
          // pto: %339
          ;
          bool v903 = v51 < v900;
          // pto: %339
          ;
          bool v904 = v902 == v903;
          // pto: %339
          ;
          bool v905 = v894 % v51 != v900 && v902 != v903;
          // pto: %339
          ;
          int64_t v906 = v905 ? v901 - v899 : v901;
          // pto: %340
          ;
          int64_t v907 = v906 < v56 ? v56 : v906;
          // pto: %341
          ;
          __gm__ int8_t* v908 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %341
          ;
          const int64_t v909 = 0;
          // pto: %341
          ;
          const int64_t v910 = 128;
          // pto: %341
          ;
          pto::Shape<1, 1, 1, 32, 128> v911 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %341
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v912 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %341
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v913 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v908 + (v909 + v907 * v910), v911, v912);
          TLOAD(v897, v913);
        } else {
          // pto: %342
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v914;
          // pto: %342
          ;
          uint64_t v915 = (uint64_t) v45;
          TASSIGN(v914, v915);
          // pto: %343
          ;
          const int64_t v916 = 1;
          // pto: %343
          ;
          const int64_t v917 = 0;
          // pto: %343
          ;
          int64_t v918 = v894 / v51;
          // pto: %343
          ;
          bool v919 = v894 < v917;
          // pto: %343
          ;
          bool v920 = v51 < v917;
          // pto: %343
          ;
          bool v921 = v919 == v920;
          // pto: %343
          ;
          bool v922 = v894 % v51 != v917 && v919 != v920;
          // pto: %343
          ;
          int64_t v923 = v922 ? v918 - v916 : v918;
          // pto: %344
          ;
          int64_t v924 = v923 < v56 ? v56 : v923;
          // pto: %345
          ;
          __gm__ int8_t* v925 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %345
          ;
          const int64_t v926 = 0;
          // pto: %345
          ;
          const int64_t v927 = 128;
          // pto: %345
          ;
          pto::Shape<1, 1, 1, 32, 128> v928 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %345
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v929 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %345
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v930 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v925 + (v926 + v924 * v927), v928, v929);
          TLOAD(v914, v930);
        };
        // pto: %348
        ;
        int64_t v931 = (int64_t) ((uint64_t) v382 + (uint64_t) v54);
        // pto: %349
        ;
        const int64_t v932 = 1;
        // pto: %349
        ;
        const int64_t v933 = 0;
        // pto: %349
        ;
        int64_t v934 = v931 / v66;
        // pto: %349
        ;
        bool v935 = v931 < v933;
        // pto: %349
        ;
        bool v936 = v66 < v933;
        // pto: %349
        ;
        bool v937 = v935 == v936;
        // pto: %349
        ;
        bool v938 = v931 % v66 != v933 && v935 != v936;
        // pto: %349
        ;
        int64_t v939 = v938 ? v934 - v932 : v934;
        // pto: %353
        ;
        int64_t v940 = v939 < v400 ? v939 : v400;
        // pto: %356, %354
        ;
        int32_t v941 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v940)];
        // pto: %357
        ;
        int64_t v942 = (int64_t) v941;
        // pto: %358
        ;
        int64_t v943 = v942 < v56 ? v56 : v942;
        // pto: %359
        ;
        int64_t v944 = (int64_t) ((uint64_t) v943 * (uint64_t) v16);
        // pto: %360
        ;
        int64_t v945 = v944 % v51;
        // pto: %361, %362, %363
        ;
        int64_t v946 = v945 < v56 ? (int64_t) ((uint64_t) v945 + (uint64_t) v51) : v945;
        // pto: %364
        ;
        if (v946 == v56) {
          // pto: %366
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v947;
          // pto: %366
          ;
          uint64_t v948 = (uint64_t) v42;
          TASSIGN(v947, v948);
          // pto: %367
          ;
          const int64_t v949 = 1;
          // pto: %367
          ;
          const int64_t v950 = 0;
          // pto: %367
          ;
          int64_t v951 = v944 / v51;
          // pto: %367
          ;
          bool v952 = v944 < v950;
          // pto: %367
          ;
          bool v953 = v51 < v950;
          // pto: %367
          ;
          bool v954 = v952 == v953;
          // pto: %367
          ;
          bool v955 = v944 % v51 != v950 && v952 != v953;
          // pto: %367
          ;
          int64_t v956 = v955 ? v951 - v949 : v951;
          // pto: %368
          ;
          int64_t v957 = v956 < v56 ? v56 : v956;
          // pto: %369
          ;
          __gm__ int8_t* v958 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %369
          ;
          const int64_t v959 = 0;
          // pto: %369
          ;
          const int64_t v960 = 128;
          // pto: %369
          ;
          pto::Shape<1, 1, 1, 32, 128> v961 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %369
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v962 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %369
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v963 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v958 + (v959 + v957 * v960), v961, v962);
          TLOAD(v947, v963);
        } else {
          // pto: %371
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v964;
          // pto: %371
          ;
          uint64_t v965 = (uint64_t) v42;
          TASSIGN(v964, v965);
          // pto: %372
          ;
          const int64_t v966 = 1;
          // pto: %372
          ;
          const int64_t v967 = 0;
          // pto: %372
          ;
          int64_t v968 = v944 / v51;
          // pto: %372
          ;
          bool v969 = v944 < v967;
          // pto: %372
          ;
          bool v970 = v51 < v967;
          // pto: %372
          ;
          bool v971 = v969 == v970;
          // pto: %372
          ;
          bool v972 = v944 % v51 != v967 && v969 != v970;
          // pto: %372
          ;
          int64_t v973 = v972 ? v968 - v966 : v968;
          // pto: %373
          ;
          int64_t v974 = v973 < v56 ? v56 : v973;
          // pto: %374
          ;
          __gm__ int8_t* v975 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %374
          ;
          const int64_t v976 = 0;
          // pto: %374
          ;
          const int64_t v977 = 128;
          // pto: %374
          ;
          pto::Shape<1, 1, 1, 32, 128> v978 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %374
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v979 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %374
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v980 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v975 + (v976 + v974 * v977), v978, v979);
          TLOAD(v964, v980);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
        // pto: %t__tmp_v374
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v981 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v374
        ;
        uint64_t v982 = (uint64_t) v45;
        TASSIGN(v981, v982);
        // pto: %buf_prefetched_key_inline3810__ssa_v16
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v983 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline3810__ssa_v16
        ;
        uint64_t v984 = (uint64_t) v47;
        TASSIGN(v983, v984);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        uint16_t v985 = static_cast<uint16_t>(v56);
        uint16_t v986 = static_cast<uint16_t>(v56);
        TEXTRACT(v983, v981, v985, v986);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
        // pto: %buf_key_panel_inline3828__ssa_v9
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v987 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline3828__ssa_v9
        ;
        uint64_t v988 = (uint64_t) v43;
        TASSIGN(v987, v988);
        // pto: %buf_scores_l1_inline3829__ssa_v12
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v989 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline3829__ssa_v12
        ;
        uint64_t v990 = (uint64_t) v44;
        TASSIGN(v989, v990);
        // pto: %buf_previous_pair_inline3830__ssa_v3
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v991 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline3830__ssa_v3
        ;
        uint64_t v992 = (uint64_t) v46;
        TASSIGN(v991, v992);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        uint16_t v993 = static_cast<uint16_t>(v56);
        uint16_t v994 = static_cast<uint16_t>(v56);
        TEXTRACT(v991, v877, v993, v994);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        // pto: %buf_scores_inline3831__ssa_v9
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v995 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline3831__ssa_v9
        ;
        uint64_t v996 = (uint64_t) v43;
        TASSIGN(v995, v996);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
        TMATMUL(v995, v371, v987);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
        // pto: %buf_reduced_pair_inline3832__ssa_v3
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v997 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline3832__ssa_v3
        ;
        uint64_t v998 = (uint64_t) v48;
        TASSIGN(v997, v998);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
        TMATMUL(v997, v373, v991);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID6);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
        uint64_t v999 = static_cast<uint64_t>(v77);
        uint16_t v1000 = static_cast<uint16_t>(v56);
        uint16_t v1001 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v989, v995, v999, v1000, v1001);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID3);
        v997.SetValidShape(v65, v73);
        // pto: %378
        ;
        __gm__ float* v1002 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %378
        ;
        const int64_t v1003 = 128;
        // pto: %378
        ;
        const int64_t v1004 = 1024;
        // pto: %378
        ;
        pto::Shape<1, 1, 1, 6, 64> v1005 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %378
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1006 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %378
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1007 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1002 + (v1003 + v739 * v1004), v1005, v1006);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID6);
        TSTORE(v1007, v997);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
        // pto: %buf_previous_l1_inline3808__ssa_v4
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1008 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline3808__ssa_v4
        ;
        uint64_t v1009 = (uint64_t) v44;
        TASSIGN(v1008, v1009);
        // pto: %buf_current_key_inline3809__ssa_v28
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1010 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline3809__ssa_v28
        ;
        uint64_t v1011 = (uint64_t) v47;
        TASSIGN(v1010, v1011);
        // pto: %380
        ;
        int64_t v1012 = (int64_t) ((uint64_t) v382 + (uint64_t) v80);
        // pto: %381
        ;
        const int64_t v1013 = 1;
        // pto: %381
        ;
        const int64_t v1014 = 0;
        // pto: %381
        ;
        int64_t v1015 = v1012 / v66;
        // pto: %381
        ;
        bool v1016 = v1012 < v1014;
        // pto: %381
        ;
        bool v1017 = v66 < v1014;
        // pto: %381
        ;
        bool v1018 = v1016 == v1017;
        // pto: %381
        ;
        bool v1019 = v1012 % v66 != v1014 && v1016 != v1017;
        // pto: %381
        ;
        int64_t v1020 = v1019 ? v1015 - v1013 : v1015;
        // pto: %385
        ;
        int64_t v1021 = v1020 < v400 ? v1020 : v400;
        // pto: %388, %386
        ;
        int32_t v1022 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v1021)];
        // pto: %389
        ;
        int64_t v1023 = (int64_t) v1022;
        // pto: %390
        ;
        int64_t v1024 = v1023 < v56 ? v56 : v1023;
        // pto: %391
        ;
        int64_t v1025 = (int64_t) ((uint64_t) v1024 * (uint64_t) v16);
        // pto: %392
        ;
        int64_t v1026 = v1025 % v51;
        // pto: %393, %394, %395
        ;
        int64_t v1027 = v1026 < v56 ? (int64_t) ((uint64_t) v1026 + (uint64_t) v51) : v1026;
        // pto: %396
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
        if (v1027 == v56) {
          // pto: %397
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1028;
          // pto: %397
          ;
          uint64_t v1029 = (uint64_t) v41;
          TASSIGN(v1028, v1029);
          // pto: %398
          ;
          const int64_t v1030 = 1;
          // pto: %398
          ;
          const int64_t v1031 = 0;
          // pto: %398
          ;
          int64_t v1032 = v1025 / v51;
          // pto: %398
          ;
          bool v1033 = v1025 < v1031;
          // pto: %398
          ;
          bool v1034 = v51 < v1031;
          // pto: %398
          ;
          bool v1035 = v1033 == v1034;
          // pto: %398
          ;
          bool v1036 = v1025 % v51 != v1031 && v1033 != v1034;
          // pto: %398
          ;
          int64_t v1037 = v1036 ? v1032 - v1030 : v1032;
          // pto: %399
          ;
          int64_t v1038 = v1037 < v56 ? v56 : v1037;
          // pto: %400
          ;
          __gm__ int8_t* v1039 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %400
          ;
          const int64_t v1040 = 0;
          // pto: %400
          ;
          const int64_t v1041 = 128;
          // pto: %400
          ;
          pto::Shape<1, 1, 1, 32, 128> v1042 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %400
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1043 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %400
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1044 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1039 + (v1040 + v1038 * v1041), v1042, v1043);
          TLOAD(v1028, v1044);
        } else {
          // pto: %401
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1045;
          // pto: %401
          ;
          uint64_t v1046 = (uint64_t) v41;
          TASSIGN(v1045, v1046);
          // pto: %402
          ;
          const int64_t v1047 = 1;
          // pto: %402
          ;
          const int64_t v1048 = 0;
          // pto: %402
          ;
          int64_t v1049 = v1025 / v51;
          // pto: %402
          ;
          bool v1050 = v1025 < v1048;
          // pto: %402
          ;
          bool v1051 = v51 < v1048;
          // pto: %402
          ;
          bool v1052 = v1050 == v1051;
          // pto: %402
          ;
          bool v1053 = v1025 % v51 != v1048 && v1050 != v1051;
          // pto: %402
          ;
          int64_t v1054 = v1053 ? v1049 - v1047 : v1049;
          // pto: %403
          ;
          int64_t v1055 = v1054 < v56 ? v56 : v1054;
          // pto: %404
          ;
          __gm__ int8_t* v1056 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %404
          ;
          const int64_t v1057 = 0;
          // pto: %404
          ;
          const int64_t v1058 = 128;
          // pto: %404
          ;
          pto::Shape<1, 1, 1, 32, 128> v1059 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %404
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1060 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %404
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1061 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1056 + (v1057 + v1055 * v1058), v1059, v1060);
          TLOAD(v1045, v1061);
        };
        // pto: %407
        ;
        int64_t v1062 = (int64_t) ((uint64_t) v382 + (uint64_t) v36);
        // pto: %408
        ;
        const int64_t v1063 = 1;
        // pto: %408
        ;
        const int64_t v1064 = 0;
        // pto: %408
        ;
        int64_t v1065 = v1062 / v66;
        // pto: %408
        ;
        bool v1066 = v1062 < v1064;
        // pto: %408
        ;
        bool v1067 = v66 < v1064;
        // pto: %408
        ;
        bool v1068 = v1066 == v1067;
        // pto: %408
        ;
        bool v1069 = v1062 % v66 != v1064 && v1066 != v1067;
        // pto: %408
        ;
        int64_t v1070 = v1069 ? v1065 - v1063 : v1065;
        // pto: %412
        ;
        int64_t v1071 = v1070 < v400 ? v1070 : v400;
        // pto: %415, %413
        ;
        int32_t v1072 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v1071)];
        // pto: %416
        ;
        int64_t v1073 = (int64_t) v1072;
        // pto: %417
        ;
        int64_t v1074 = v1073 < v56 ? v56 : v1073;
        // pto: %418
        ;
        int64_t v1075 = (int64_t) ((uint64_t) v1074 * (uint64_t) v16);
        // pto: %419
        ;
        int64_t v1076 = v1075 % v51;
        // pto: %420, %421, %422
        ;
        int64_t v1077 = v1076 < v56 ? (int64_t) ((uint64_t) v1076 + (uint64_t) v51) : v1076;
        // pto: %423
        ;
        if (v1077 == v56) {
          // pto: %425
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1078;
          // pto: %425
          ;
          uint64_t v1079 = (uint64_t) v39;
          TASSIGN(v1078, v1079);
          // pto: %426
          ;
          const int64_t v1080 = 1;
          // pto: %426
          ;
          const int64_t v1081 = 0;
          // pto: %426
          ;
          int64_t v1082 = v1075 / v51;
          // pto: %426
          ;
          bool v1083 = v1075 < v1081;
          // pto: %426
          ;
          bool v1084 = v51 < v1081;
          // pto: %426
          ;
          bool v1085 = v1083 == v1084;
          // pto: %426
          ;
          bool v1086 = v1075 % v51 != v1081 && v1083 != v1084;
          // pto: %426
          ;
          int64_t v1087 = v1086 ? v1082 - v1080 : v1082;
          // pto: %427
          ;
          int64_t v1088 = v1087 < v56 ? v56 : v1087;
          // pto: %428
          ;
          __gm__ int8_t* v1089 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %428
          ;
          const int64_t v1090 = 0;
          // pto: %428
          ;
          const int64_t v1091 = 128;
          // pto: %428
          ;
          pto::Shape<1, 1, 1, 32, 128> v1092 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %428
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1093 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %428
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1094 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1089 + (v1090 + v1088 * v1091), v1092, v1093);
          TLOAD(v1078, v1094);
        } else {
          // pto: %430
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1095;
          // pto: %430
          ;
          uint64_t v1096 = (uint64_t) v39;
          TASSIGN(v1095, v1096);
          // pto: %431
          ;
          const int64_t v1097 = 1;
          // pto: %431
          ;
          const int64_t v1098 = 0;
          // pto: %431
          ;
          int64_t v1099 = v1075 / v51;
          // pto: %431
          ;
          bool v1100 = v1075 < v1098;
          // pto: %431
          ;
          bool v1101 = v51 < v1098;
          // pto: %431
          ;
          bool v1102 = v1100 == v1101;
          // pto: %431
          ;
          bool v1103 = v1075 % v51 != v1098 && v1100 != v1101;
          // pto: %431
          ;
          int64_t v1104 = v1103 ? v1099 - v1097 : v1099;
          // pto: %432
          ;
          int64_t v1105 = v1104 < v56 ? v56 : v1104;
          // pto: %433
          ;
          __gm__ int8_t* v1106 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %433
          ;
          const int64_t v1107 = 0;
          // pto: %433
          ;
          const int64_t v1108 = 128;
          // pto: %433
          ;
          pto::Shape<1, 1, 1, 32, 128> v1109 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %433
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1110 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %433
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1111 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1106 + (v1107 + v1105 * v1108), v1109, v1110);
          TLOAD(v1095, v1111);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
        // pto: %t__tmp_v378
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1112 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v378
        ;
        uint64_t v1113 = (uint64_t) v45;
        TASSIGN(v1112, v1113);
        // pto: %buf_prefetched_key_inline3810__ssa_v21
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1114 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline3810__ssa_v21
        ;
        uint64_t v1115 = (uint64_t) v43;
        TASSIGN(v1114, v1115);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
        uint16_t v1116 = static_cast<uint16_t>(v56);
        uint16_t v1117 = static_cast<uint16_t>(v73);
        TEXTRACT(v1114, v1112, v1116, v1117);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        // pto: %buf_key_panel_inline3828__ssa_v12
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1118 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline3828__ssa_v12
        ;
        uint64_t v1119 = (uint64_t) v47;
        TASSIGN(v1118, v1119);
        // pto: %buf_scores_l1_inline3829__ssa_v16
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1120 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline3829__ssa_v16
        ;
        uint64_t v1121 = (uint64_t) v43;
        TASSIGN(v1120, v1121);
        // pto: %buf_previous_pair_inline3830__ssa_v4
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1122 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline3830__ssa_v4
        ;
        uint64_t v1123 = (uint64_t) v46;
        TASSIGN(v1122, v1123);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID3);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        uint16_t v1124 = static_cast<uint16_t>(v56);
        uint16_t v1125 = static_cast<uint16_t>(v56);
        TEXTRACT(v1122, v1008, v1124, v1125);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        // pto: %buf_scores_inline3831__ssa_v12
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1126 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline3831__ssa_v12
        ;
        uint64_t v1127 = (uint64_t) v43;
        TASSIGN(v1126, v1127);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
        TMATMUL(v1126, v371, v1118);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID7);
        // pto: %buf_reduced_pair_inline3832__ssa_v4
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1128 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline3832__ssa_v4
        ;
        uint64_t v1129 = (uint64_t) v48;
        TASSIGN(v1128, v1129);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
        TMATMUL(v1128, v373, v1122);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID7);
        uint64_t v1130 = static_cast<uint64_t>(v77);
        uint16_t v1131 = static_cast<uint16_t>(v56);
        uint16_t v1132 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1120, v1126, v1130, v1131, v1132);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID4);
        v1128.SetValidShape(v65, v73);
        // pto: %437
        ;
        __gm__ float* v1133 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %437
        ;
        const int64_t v1134 = 192;
        // pto: %437
        ;
        const int64_t v1135 = 1024;
        // pto: %437
        ;
        pto::Shape<1, 1, 1, 6, 64> v1136 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %437
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1137 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %437
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1138 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1133 + (v1134 + v739 * v1135), v1136, v1137);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        TSTORE(v1138, v1128);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline3808__ssa_v5
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1139 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline3808__ssa_v5
        ;
        uint64_t v1140 = (uint64_t) v43;
        TASSIGN(v1139, v1140);
        // pto: %buf_current_key_inline3809__ssa_v35
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1141 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline3809__ssa_v35
        ;
        uint64_t v1142 = (uint64_t) v43;
        TASSIGN(v1141, v1142);
        // pto: %439
        ;
        int64_t v1143 = (int64_t) ((uint64_t) v382 + (uint64_t) v53);
        // pto: %440
        ;
        const int64_t v1144 = 1;
        // pto: %440
        ;
        const int64_t v1145 = 0;
        // pto: %440
        ;
        int64_t v1146 = v1143 / v66;
        // pto: %440
        ;
        bool v1147 = v1143 < v1145;
        // pto: %440
        ;
        bool v1148 = v66 < v1145;
        // pto: %440
        ;
        bool v1149 = v1147 == v1148;
        // pto: %440
        ;
        bool v1150 = v1143 % v66 != v1145 && v1147 != v1148;
        // pto: %440
        ;
        int64_t v1151 = v1150 ? v1146 - v1144 : v1146;
        // pto: %444
        ;
        int64_t v1152 = v1151 < v400 ? v1151 : v400;
        // pto: %447, %445
        ;
        int32_t v1153 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v1152)];
        // pto: %448
        ;
        int64_t v1154 = (int64_t) v1153;
        // pto: %449
        ;
        int64_t v1155 = v1154 < v56 ? v56 : v1154;
        // pto: %450
        ;
        int64_t v1156 = (int64_t) ((uint64_t) v1155 * (uint64_t) v16);
        // pto: %451
        ;
        int64_t v1157 = v1156 % v51;
        // pto: %452, %453, %454
        ;
        int64_t v1158 = v1157 < v56 ? (int64_t) ((uint64_t) v1157 + (uint64_t) v51) : v1157;
        // pto: %455
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
        if (v1158 == v56) {
          // pto: %456
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1159;
          // pto: %456
          ;
          uint64_t v1160 = (uint64_t) v45;
          TASSIGN(v1159, v1160);
          // pto: %457
          ;
          const int64_t v1161 = 1;
          // pto: %457
          ;
          const int64_t v1162 = 0;
          // pto: %457
          ;
          int64_t v1163 = v1156 / v51;
          // pto: %457
          ;
          bool v1164 = v1156 < v1162;
          // pto: %457
          ;
          bool v1165 = v51 < v1162;
          // pto: %457
          ;
          bool v1166 = v1164 == v1165;
          // pto: %457
          ;
          bool v1167 = v1156 % v51 != v1162 && v1164 != v1165;
          // pto: %457
          ;
          int64_t v1168 = v1167 ? v1163 - v1161 : v1163;
          // pto: %458
          ;
          int64_t v1169 = v1168 < v56 ? v56 : v1168;
          // pto: %459
          ;
          __gm__ int8_t* v1170 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %459
          ;
          const int64_t v1171 = 0;
          // pto: %459
          ;
          const int64_t v1172 = 128;
          // pto: %459
          ;
          pto::Shape<1, 1, 1, 32, 128> v1173 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %459
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1174 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %459
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1175 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1170 + (v1171 + v1169 * v1172), v1173, v1174);
          TLOAD(v1159, v1175);
        } else {
          // pto: %460
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1176;
          // pto: %460
          ;
          uint64_t v1177 = (uint64_t) v45;
          TASSIGN(v1176, v1177);
          // pto: %461
          ;
          const int64_t v1178 = 1;
          // pto: %461
          ;
          const int64_t v1179 = 0;
          // pto: %461
          ;
          int64_t v1180 = v1156 / v51;
          // pto: %461
          ;
          bool v1181 = v1156 < v1179;
          // pto: %461
          ;
          bool v1182 = v51 < v1179;
          // pto: %461
          ;
          bool v1183 = v1181 == v1182;
          // pto: %461
          ;
          bool v1184 = v1156 % v51 != v1179 && v1181 != v1182;
          // pto: %461
          ;
          int64_t v1185 = v1184 ? v1180 - v1178 : v1180;
          // pto: %462
          ;
          int64_t v1186 = v1185 < v56 ? v56 : v1185;
          // pto: %463
          ;
          __gm__ int8_t* v1187 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %463
          ;
          const int64_t v1188 = 0;
          // pto: %463
          ;
          const int64_t v1189 = 128;
          // pto: %463
          ;
          pto::Shape<1, 1, 1, 32, 128> v1190 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %463
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1191 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %463
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1192 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1187 + (v1188 + v1186 * v1189), v1190, v1191);
          TLOAD(v1176, v1192);
        };
        // pto: %466
        ;
        int64_t v1193 = (int64_t) ((uint64_t) v382 + (uint64_t) v35);
        // pto: %467
        ;
        const int64_t v1194 = 1;
        // pto: %467
        ;
        const int64_t v1195 = 0;
        // pto: %467
        ;
        int64_t v1196 = v1193 / v66;
        // pto: %467
        ;
        bool v1197 = v1193 < v1195;
        // pto: %467
        ;
        bool v1198 = v66 < v1195;
        // pto: %467
        ;
        bool v1199 = v1197 == v1198;
        // pto: %467
        ;
        bool v1200 = v1193 % v66 != v1195 && v1197 != v1198;
        // pto: %467
        ;
        int64_t v1201 = v1200 ? v1196 - v1194 : v1196;
        // pto: %471
        ;
        int64_t v1202 = v1201 < v400 ? v1201 : v400;
        // pto: %474, %472
        ;
        int32_t v1203 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v1202)];
        // pto: %475
        ;
        int64_t v1204 = (int64_t) v1203;
        // pto: %476
        ;
        int64_t v1205 = v1204 < v56 ? v56 : v1204;
        // pto: %477
        ;
        int64_t v1206 = (int64_t) ((uint64_t) v1205 * (uint64_t) v16);
        // pto: %478
        ;
        int64_t v1207 = v1206 % v51;
        // pto: %479, %480, %481
        ;
        int64_t v1208 = v1207 < v56 ? (int64_t) ((uint64_t) v1207 + (uint64_t) v51) : v1207;
        // pto: %482
        ;
        if (v1208 == v56) {
          // pto: %484
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1209;
          // pto: %484
          ;
          uint64_t v1210 = (uint64_t) v42;
          TASSIGN(v1209, v1210);
          // pto: %485
          ;
          const int64_t v1211 = 1;
          // pto: %485
          ;
          const int64_t v1212 = 0;
          // pto: %485
          ;
          int64_t v1213 = v1206 / v51;
          // pto: %485
          ;
          bool v1214 = v1206 < v1212;
          // pto: %485
          ;
          bool v1215 = v51 < v1212;
          // pto: %485
          ;
          bool v1216 = v1214 == v1215;
          // pto: %485
          ;
          bool v1217 = v1206 % v51 != v1212 && v1214 != v1215;
          // pto: %485
          ;
          int64_t v1218 = v1217 ? v1213 - v1211 : v1213;
          // pto: %486
          ;
          int64_t v1219 = v1218 < v56 ? v56 : v1218;
          // pto: %487
          ;
          __gm__ int8_t* v1220 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %487
          ;
          const int64_t v1221 = 0;
          // pto: %487
          ;
          const int64_t v1222 = 128;
          // pto: %487
          ;
          pto::Shape<1, 1, 1, 32, 128> v1223 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %487
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1224 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %487
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1225 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1220 + (v1221 + v1219 * v1222), v1223, v1224);
          TLOAD(v1209, v1225);
        } else {
          // pto: %489
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1226;
          // pto: %489
          ;
          uint64_t v1227 = (uint64_t) v42;
          TASSIGN(v1226, v1227);
          // pto: %490
          ;
          const int64_t v1228 = 1;
          // pto: %490
          ;
          const int64_t v1229 = 0;
          // pto: %490
          ;
          int64_t v1230 = v1206 / v51;
          // pto: %490
          ;
          bool v1231 = v1206 < v1229;
          // pto: %490
          ;
          bool v1232 = v51 < v1229;
          // pto: %490
          ;
          bool v1233 = v1231 == v1232;
          // pto: %490
          ;
          bool v1234 = v1206 % v51 != v1229 && v1231 != v1232;
          // pto: %490
          ;
          int64_t v1235 = v1234 ? v1230 - v1228 : v1230;
          // pto: %491
          ;
          int64_t v1236 = v1235 < v56 ? v56 : v1235;
          // pto: %492
          ;
          __gm__ int8_t* v1237 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %492
          ;
          const int64_t v1238 = 0;
          // pto: %492
          ;
          const int64_t v1239 = 128;
          // pto: %492
          ;
          pto::Shape<1, 1, 1, 32, 128> v1240 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %492
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1241 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %492
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1242 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1237 + (v1238 + v1236 * v1239), v1240, v1241);
          TLOAD(v1226, v1242);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v382
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1243 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v382
        ;
        uint64_t v1244 = (uint64_t) v45;
        TASSIGN(v1243, v1244);
        // pto: %buf_prefetched_key_inline3810__ssa_v26
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1245 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline3810__ssa_v26
        ;
        uint64_t v1246 = (uint64_t) v47;
        TASSIGN(v1245, v1246);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1247 = static_cast<uint16_t>(v56);
        uint16_t v1248 = static_cast<uint16_t>(v56);
        TEXTRACT(v1245, v1243, v1247, v1248);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        // pto: %buf_key_panel_inline3828__ssa_v15
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1249 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline3828__ssa_v15
        ;
        uint64_t v1250 = (uint64_t) v43;
        TASSIGN(v1249, v1250);
        // pto: %buf_scores_l1_inline3829__ssa_v20
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1251 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline3829__ssa_v20
        ;
        uint64_t v1252 = (uint64_t) v44;
        TASSIGN(v1251, v1252);
        // pto: %buf_previous_pair_inline3830__ssa_v5
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1253 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline3830__ssa_v5
        ;
        uint64_t v1254 = (uint64_t) v46;
        TASSIGN(v1253, v1254);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID4);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v1255 = static_cast<uint16_t>(v56);
        uint16_t v1256 = static_cast<uint16_t>(v56);
        TEXTRACT(v1253, v1139, v1255, v1256);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
        // pto: %buf_scores_inline3831__ssa_v15
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1257 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline3831__ssa_v15
        ;
        uint64_t v1258 = (uint64_t) v43;
        TASSIGN(v1257, v1258);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1257, v371, v1249);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline3832__ssa_v5
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1259 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline3832__ssa_v5
        ;
        uint64_t v1260 = (uint64_t) v48;
        TASSIGN(v1259, v1260);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1259, v373, v1253);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1261 = static_cast<uint64_t>(v77);
        uint16_t v1262 = static_cast<uint16_t>(v56);
        uint16_t v1263 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1251, v1257, v1261, v1262, v1263);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID5);
        v1259.SetValidShape(v65, v73);
        // pto: %496
        ;
        __gm__ float* v1264 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %496
        ;
        const int64_t v1265 = 256;
        // pto: %496
        ;
        const int64_t v1266 = 1024;
        // pto: %496
        ;
        pto::Shape<1, 1, 1, 6, 64> v1267 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %496
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1268 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %496
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1269 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1264 + (v1265 + v739 * v1266), v1267, v1268);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1269, v1259);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline3808__ssa_v6
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1270 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline3808__ssa_v6
        ;
        uint64_t v1271 = (uint64_t) v44;
        TASSIGN(v1270, v1271);
        // pto: %buf_current_key_inline3809__ssa_v42
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1272 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline3809__ssa_v42
        ;
        uint64_t v1273 = (uint64_t) v47;
        TASSIGN(v1272, v1273);
        // pto: %498
        ;
        int64_t v1274 = (int64_t) ((uint64_t) v382 + (uint64_t) v81);
        // pto: %499
        ;
        const int64_t v1275 = 1;
        // pto: %499
        ;
        const int64_t v1276 = 0;
        // pto: %499
        ;
        int64_t v1277 = v1274 / v66;
        // pto: %499
        ;
        bool v1278 = v1274 < v1276;
        // pto: %499
        ;
        bool v1279 = v66 < v1276;
        // pto: %499
        ;
        bool v1280 = v1278 == v1279;
        // pto: %499
        ;
        bool v1281 = v1274 % v66 != v1276 && v1278 != v1279;
        // pto: %499
        ;
        int64_t v1282 = v1281 ? v1277 - v1275 : v1277;
        // pto: %503
        ;
        int64_t v1283 = v1282 < v400 ? v1282 : v400;
        // pto: %506, %504
        ;
        int32_t v1284 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v1283)];
        // pto: %507
        ;
        int64_t v1285 = (int64_t) v1284;
        // pto: %508
        ;
        int64_t v1286 = v1285 < v56 ? v56 : v1285;
        // pto: %509
        ;
        int64_t v1287 = (int64_t) ((uint64_t) v1286 * (uint64_t) v16);
        // pto: %510
        ;
        int64_t v1288 = v1287 % v51;
        // pto: %511, %512, %513
        ;
        int64_t v1289 = v1288 < v56 ? (int64_t) ((uint64_t) v1288 + (uint64_t) v51) : v1288;
        // pto: %514
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        if (v1289 == v56) {
          // pto: %515
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1290;
          // pto: %515
          ;
          uint64_t v1291 = (uint64_t) v41;
          TASSIGN(v1290, v1291);
          // pto: %516
          ;
          const int64_t v1292 = 1;
          // pto: %516
          ;
          const int64_t v1293 = 0;
          // pto: %516
          ;
          int64_t v1294 = v1287 / v51;
          // pto: %516
          ;
          bool v1295 = v1287 < v1293;
          // pto: %516
          ;
          bool v1296 = v51 < v1293;
          // pto: %516
          ;
          bool v1297 = v1295 == v1296;
          // pto: %516
          ;
          bool v1298 = v1287 % v51 != v1293 && v1295 != v1296;
          // pto: %516
          ;
          int64_t v1299 = v1298 ? v1294 - v1292 : v1294;
          // pto: %517
          ;
          int64_t v1300 = v1299 < v56 ? v56 : v1299;
          // pto: %518
          ;
          __gm__ int8_t* v1301 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %518
          ;
          const int64_t v1302 = 0;
          // pto: %518
          ;
          const int64_t v1303 = 128;
          // pto: %518
          ;
          pto::Shape<1, 1, 1, 32, 128> v1304 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %518
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1305 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %518
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1306 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1301 + (v1302 + v1300 * v1303), v1304, v1305);
          TLOAD(v1290, v1306);
        } else {
          // pto: %519
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1307;
          // pto: %519
          ;
          uint64_t v1308 = (uint64_t) v41;
          TASSIGN(v1307, v1308);
          // pto: %520
          ;
          const int64_t v1309 = 1;
          // pto: %520
          ;
          const int64_t v1310 = 0;
          // pto: %520
          ;
          int64_t v1311 = v1287 / v51;
          // pto: %520
          ;
          bool v1312 = v1287 < v1310;
          // pto: %520
          ;
          bool v1313 = v51 < v1310;
          // pto: %520
          ;
          bool v1314 = v1312 == v1313;
          // pto: %520
          ;
          bool v1315 = v1287 % v51 != v1310 && v1312 != v1313;
          // pto: %520
          ;
          int64_t v1316 = v1315 ? v1311 - v1309 : v1311;
          // pto: %521
          ;
          int64_t v1317 = v1316 < v56 ? v56 : v1316;
          // pto: %522
          ;
          __gm__ int8_t* v1318 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %522
          ;
          const int64_t v1319 = 0;
          // pto: %522
          ;
          const int64_t v1320 = 128;
          // pto: %522
          ;
          pto::Shape<1, 1, 1, 32, 128> v1321 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %522
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1322 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %522
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1323 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1318 + (v1319 + v1317 * v1320), v1321, v1322);
          TLOAD(v1307, v1323);
        };
        // pto: %525
        ;
        int64_t v1324 = (int64_t) ((uint64_t) v382 + (uint64_t) v34);
        // pto: %526
        ;
        const int64_t v1325 = 1;
        // pto: %526
        ;
        const int64_t v1326 = 0;
        // pto: %526
        ;
        int64_t v1327 = v1324 / v66;
        // pto: %526
        ;
        bool v1328 = v1324 < v1326;
        // pto: %526
        ;
        bool v1329 = v66 < v1326;
        // pto: %526
        ;
        bool v1330 = v1328 == v1329;
        // pto: %526
        ;
        bool v1331 = v1324 % v66 != v1326 && v1328 != v1329;
        // pto: %526
        ;
        int64_t v1332 = v1331 ? v1327 - v1325 : v1327;
        // pto: %530
        ;
        int64_t v1333 = v1332 < v400 ? v1332 : v400;
        // pto: %533, %531
        ;
        int32_t v1334 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v1333)];
        // pto: %534
        ;
        int64_t v1335 = (int64_t) v1334;
        // pto: %535
        ;
        int64_t v1336 = v1335 < v56 ? v56 : v1335;
        // pto: %536
        ;
        int64_t v1337 = (int64_t) ((uint64_t) v1336 * (uint64_t) v16);
        // pto: %537
        ;
        int64_t v1338 = v1337 % v51;
        // pto: %538, %539, %540
        ;
        int64_t v1339 = v1338 < v56 ? (int64_t) ((uint64_t) v1338 + (uint64_t) v51) : v1338;
        // pto: %541
        ;
        if (v1339 == v56) {
          // pto: %543
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1340;
          // pto: %543
          ;
          uint64_t v1341 = (uint64_t) v39;
          TASSIGN(v1340, v1341);
          // pto: %544
          ;
          const int64_t v1342 = 1;
          // pto: %544
          ;
          const int64_t v1343 = 0;
          // pto: %544
          ;
          int64_t v1344 = v1337 / v51;
          // pto: %544
          ;
          bool v1345 = v1337 < v1343;
          // pto: %544
          ;
          bool v1346 = v51 < v1343;
          // pto: %544
          ;
          bool v1347 = v1345 == v1346;
          // pto: %544
          ;
          bool v1348 = v1337 % v51 != v1343 && v1345 != v1346;
          // pto: %544
          ;
          int64_t v1349 = v1348 ? v1344 - v1342 : v1344;
          // pto: %545
          ;
          int64_t v1350 = v1349 < v56 ? v56 : v1349;
          // pto: %546
          ;
          __gm__ int8_t* v1351 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %546
          ;
          const int64_t v1352 = 0;
          // pto: %546
          ;
          const int64_t v1353 = 128;
          // pto: %546
          ;
          pto::Shape<1, 1, 1, 32, 128> v1354 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %546
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1355 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %546
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1356 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1351 + (v1352 + v1350 * v1353), v1354, v1355);
          TLOAD(v1340, v1356);
        } else {
          // pto: %548
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1357;
          // pto: %548
          ;
          uint64_t v1358 = (uint64_t) v39;
          TASSIGN(v1357, v1358);
          // pto: %549
          ;
          const int64_t v1359 = 1;
          // pto: %549
          ;
          const int64_t v1360 = 0;
          // pto: %549
          ;
          int64_t v1361 = v1337 / v51;
          // pto: %549
          ;
          bool v1362 = v1337 < v1360;
          // pto: %549
          ;
          bool v1363 = v51 < v1360;
          // pto: %549
          ;
          bool v1364 = v1362 == v1363;
          // pto: %549
          ;
          bool v1365 = v1337 % v51 != v1360 && v1362 != v1363;
          // pto: %549
          ;
          int64_t v1366 = v1365 ? v1361 - v1359 : v1361;
          // pto: %550
          ;
          int64_t v1367 = v1366 < v56 ? v56 : v1366;
          // pto: %551
          ;
          __gm__ int8_t* v1368 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %551
          ;
          const int64_t v1369 = 0;
          // pto: %551
          ;
          const int64_t v1370 = 128;
          // pto: %551
          ;
          pto::Shape<1, 1, 1, 32, 128> v1371 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %551
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1372 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %551
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1373 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1368 + (v1369 + v1367 * v1370), v1371, v1372);
          TLOAD(v1357, v1373);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v386
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1374 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v386
        ;
        uint64_t v1375 = (uint64_t) v45;
        TASSIGN(v1374, v1375);
        // pto: %buf_prefetched_key_inline3810__ssa_v31
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1376 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline3810__ssa_v31
        ;
        uint64_t v1377 = (uint64_t) v43;
        TASSIGN(v1376, v1377);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1378 = static_cast<uint16_t>(v56);
        uint16_t v1379 = static_cast<uint16_t>(v73);
        TEXTRACT(v1376, v1374, v1378, v1379);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        // pto: %buf_key_panel_inline3828__ssa_v18
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1380 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline3828__ssa_v18
        ;
        uint64_t v1381 = (uint64_t) v47;
        TASSIGN(v1380, v1381);
        // pto: %buf_scores_l1_inline3829__ssa_v24
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1382 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline3829__ssa_v24
        ;
        uint64_t v1383 = (uint64_t) v43;
        TASSIGN(v1382, v1383);
        // pto: %buf_previous_pair_inline3830__ssa_v6
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1384 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline3830__ssa_v6
        ;
        uint64_t v1385 = (uint64_t) v46;
        TASSIGN(v1384, v1385);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID5);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v1386 = static_cast<uint16_t>(v56);
        uint16_t v1387 = static_cast<uint16_t>(v56);
        TEXTRACT(v1384, v1270, v1386, v1387);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        // pto: %buf_scores_inline3831__ssa_v18
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1388 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline3831__ssa_v18
        ;
        uint64_t v1389 = (uint64_t) v43;
        TASSIGN(v1388, v1389);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1388, v371, v1380);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline3832__ssa_v6
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1390 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline3832__ssa_v6
        ;
        uint64_t v1391 = (uint64_t) v48;
        TASSIGN(v1390, v1391);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1390, v373, v1384);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1392 = static_cast<uint64_t>(v77);
        uint16_t v1393 = static_cast<uint16_t>(v56);
        uint16_t v1394 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1382, v1388, v1392, v1393, v1394);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID6);
        v1390.SetValidShape(v65, v73);
        // pto: %555
        ;
        __gm__ float* v1395 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %555
        ;
        const int64_t v1396 = 320;
        // pto: %555
        ;
        const int64_t v1397 = 1024;
        // pto: %555
        ;
        pto::Shape<1, 1, 1, 6, 64> v1398 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %555
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1399 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %555
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1400 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1395 + (v1396 + v739 * v1397), v1398, v1399);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1400, v1390);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline3808__ssa_v7
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1401 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline3808__ssa_v7
        ;
        uint64_t v1402 = (uint64_t) v43;
        TASSIGN(v1401, v1402);
        // pto: %buf_current_key_inline3809__ssa_v49
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1403 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline3809__ssa_v49
        ;
        uint64_t v1404 = (uint64_t) v43;
        TASSIGN(v1403, v1404);
        // pto: %557
        ;
        int64_t v1405 = (int64_t) ((uint64_t) v382 + (uint64_t) v70);
        // pto: %558
        ;
        const int64_t v1406 = 1;
        // pto: %558
        ;
        const int64_t v1407 = 0;
        // pto: %558
        ;
        int64_t v1408 = v1405 / v66;
        // pto: %558
        ;
        bool v1409 = v1405 < v1407;
        // pto: %558
        ;
        bool v1410 = v66 < v1407;
        // pto: %558
        ;
        bool v1411 = v1409 == v1410;
        // pto: %558
        ;
        bool v1412 = v1405 % v66 != v1407 && v1409 != v1410;
        // pto: %558
        ;
        int64_t v1413 = v1412 ? v1408 - v1406 : v1408;
        // pto: %562
        ;
        int64_t v1414 = v1413 < v400 ? v1413 : v400;
        // pto: %565, %563
        ;
        int32_t v1415 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v1414)];
        // pto: %566
        ;
        int64_t v1416 = (int64_t) v1415;
        // pto: %567
        ;
        int64_t v1417 = v1416 < v56 ? v56 : v1416;
        // pto: %568
        ;
        int64_t v1418 = (int64_t) ((uint64_t) v1417 * (uint64_t) v16);
        // pto: %569
        ;
        int64_t v1419 = v1418 % v51;
        // pto: %570, %571, %572
        ;
        int64_t v1420 = v1419 < v56 ? (int64_t) ((uint64_t) v1419 + (uint64_t) v51) : v1419;
        // pto: %573
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        if (v1420 == v56) {
          // pto: %574
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1421;
          // pto: %574
          ;
          uint64_t v1422 = (uint64_t) v45;
          TASSIGN(v1421, v1422);
          // pto: %575
          ;
          const int64_t v1423 = 1;
          // pto: %575
          ;
          const int64_t v1424 = 0;
          // pto: %575
          ;
          int64_t v1425 = v1418 / v51;
          // pto: %575
          ;
          bool v1426 = v1418 < v1424;
          // pto: %575
          ;
          bool v1427 = v51 < v1424;
          // pto: %575
          ;
          bool v1428 = v1426 == v1427;
          // pto: %575
          ;
          bool v1429 = v1418 % v51 != v1424 && v1426 != v1427;
          // pto: %575
          ;
          int64_t v1430 = v1429 ? v1425 - v1423 : v1425;
          // pto: %576
          ;
          int64_t v1431 = v1430 < v56 ? v56 : v1430;
          // pto: %577
          ;
          __gm__ int8_t* v1432 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %577
          ;
          const int64_t v1433 = 0;
          // pto: %577
          ;
          const int64_t v1434 = 128;
          // pto: %577
          ;
          pto::Shape<1, 1, 1, 32, 128> v1435 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %577
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1436 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %577
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1437 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1432 + (v1433 + v1431 * v1434), v1435, v1436);
          TLOAD(v1421, v1437);
        } else {
          // pto: %578
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1438;
          // pto: %578
          ;
          uint64_t v1439 = (uint64_t) v45;
          TASSIGN(v1438, v1439);
          // pto: %579
          ;
          const int64_t v1440 = 1;
          // pto: %579
          ;
          const int64_t v1441 = 0;
          // pto: %579
          ;
          int64_t v1442 = v1418 / v51;
          // pto: %579
          ;
          bool v1443 = v1418 < v1441;
          // pto: %579
          ;
          bool v1444 = v51 < v1441;
          // pto: %579
          ;
          bool v1445 = v1443 == v1444;
          // pto: %579
          ;
          bool v1446 = v1418 % v51 != v1441 && v1443 != v1444;
          // pto: %579
          ;
          int64_t v1447 = v1446 ? v1442 - v1440 : v1442;
          // pto: %580
          ;
          int64_t v1448 = v1447 < v56 ? v56 : v1447;
          // pto: %581
          ;
          __gm__ int8_t* v1449 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %581
          ;
          const int64_t v1450 = 0;
          // pto: %581
          ;
          const int64_t v1451 = 128;
          // pto: %581
          ;
          pto::Shape<1, 1, 1, 32, 128> v1452 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %581
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1453 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %581
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1454 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1449 + (v1450 + v1448 * v1451), v1452, v1453);
          TLOAD(v1438, v1454);
        };
        // pto: %584
        ;
        int64_t v1455 = (int64_t) ((uint64_t) v382 + (uint64_t) v33);
        // pto: %585
        ;
        const int64_t v1456 = 1;
        // pto: %585
        ;
        const int64_t v1457 = 0;
        // pto: %585
        ;
        int64_t v1458 = v1455 / v66;
        // pto: %585
        ;
        bool v1459 = v1455 < v1457;
        // pto: %585
        ;
        bool v1460 = v66 < v1457;
        // pto: %585
        ;
        bool v1461 = v1459 == v1460;
        // pto: %585
        ;
        bool v1462 = v1455 % v66 != v1457 && v1459 != v1460;
        // pto: %585
        ;
        int64_t v1463 = v1462 ? v1458 - v1456 : v1458;
        // pto: %589
        ;
        int64_t v1464 = v1463 < v400 ? v1463 : v400;
        // pto: %592, %590
        ;
        int32_t v1465 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v1464)];
        // pto: %593
        ;
        int64_t v1466 = (int64_t) v1465;
        // pto: %594
        ;
        int64_t v1467 = v1466 < v56 ? v56 : v1466;
        // pto: %595
        ;
        int64_t v1468 = (int64_t) ((uint64_t) v1467 * (uint64_t) v16);
        // pto: %596
        ;
        int64_t v1469 = v1468 % v51;
        // pto: %597, %598, %599
        ;
        int64_t v1470 = v1469 < v56 ? (int64_t) ((uint64_t) v1469 + (uint64_t) v51) : v1469;
        // pto: %600
        ;
        if (v1470 == v56) {
          // pto: %602
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1471;
          // pto: %602
          ;
          uint64_t v1472 = (uint64_t) v42;
          TASSIGN(v1471, v1472);
          // pto: %603
          ;
          const int64_t v1473 = 1;
          // pto: %603
          ;
          const int64_t v1474 = 0;
          // pto: %603
          ;
          int64_t v1475 = v1468 / v51;
          // pto: %603
          ;
          bool v1476 = v1468 < v1474;
          // pto: %603
          ;
          bool v1477 = v51 < v1474;
          // pto: %603
          ;
          bool v1478 = v1476 == v1477;
          // pto: %603
          ;
          bool v1479 = v1468 % v51 != v1474 && v1476 != v1477;
          // pto: %603
          ;
          int64_t v1480 = v1479 ? v1475 - v1473 : v1475;
          // pto: %604
          ;
          int64_t v1481 = v1480 < v56 ? v56 : v1480;
          // pto: %605
          ;
          __gm__ int8_t* v1482 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %605
          ;
          const int64_t v1483 = 0;
          // pto: %605
          ;
          const int64_t v1484 = 128;
          // pto: %605
          ;
          pto::Shape<1, 1, 1, 32, 128> v1485 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %605
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1486 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %605
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1487 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1482 + (v1483 + v1481 * v1484), v1485, v1486);
          TLOAD(v1471, v1487);
        } else {
          // pto: %607
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1488;
          // pto: %607
          ;
          uint64_t v1489 = (uint64_t) v42;
          TASSIGN(v1488, v1489);
          // pto: %608
          ;
          const int64_t v1490 = 1;
          // pto: %608
          ;
          const int64_t v1491 = 0;
          // pto: %608
          ;
          int64_t v1492 = v1468 / v51;
          // pto: %608
          ;
          bool v1493 = v1468 < v1491;
          // pto: %608
          ;
          bool v1494 = v51 < v1491;
          // pto: %608
          ;
          bool v1495 = v1493 == v1494;
          // pto: %608
          ;
          bool v1496 = v1468 % v51 != v1491 && v1493 != v1494;
          // pto: %608
          ;
          int64_t v1497 = v1496 ? v1492 - v1490 : v1492;
          // pto: %609
          ;
          int64_t v1498 = v1497 < v56 ? v56 : v1497;
          // pto: %610
          ;
          __gm__ int8_t* v1499 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %610
          ;
          const int64_t v1500 = 0;
          // pto: %610
          ;
          const int64_t v1501 = 128;
          // pto: %610
          ;
          pto::Shape<1, 1, 1, 32, 128> v1502 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %610
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1503 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %610
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1504 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1499 + (v1500 + v1498 * v1501), v1502, v1503);
          TLOAD(v1488, v1504);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v390
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1505 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v390
        ;
        uint64_t v1506 = (uint64_t) v45;
        TASSIGN(v1505, v1506);
        // pto: %buf_prefetched_key_inline3810__ssa_v36
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1507 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline3810__ssa_v36
        ;
        uint64_t v1508 = (uint64_t) v47;
        TASSIGN(v1507, v1508);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1509 = static_cast<uint16_t>(v56);
        uint16_t v1510 = static_cast<uint16_t>(v56);
        TEXTRACT(v1507, v1505, v1509, v1510);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        // pto: %buf_key_panel_inline3828__ssa_v21
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1511 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline3828__ssa_v21
        ;
        uint64_t v1512 = (uint64_t) v43;
        TASSIGN(v1511, v1512);
        // pto: %buf_scores_l1_inline3829__ssa_v28
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1513 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline3829__ssa_v28
        ;
        uint64_t v1514 = (uint64_t) v44;
        TASSIGN(v1513, v1514);
        // pto: %buf_previous_pair_inline3830__ssa_v7
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1515 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline3830__ssa_v7
        ;
        uint64_t v1516 = (uint64_t) v46;
        TASSIGN(v1515, v1516);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID6);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v1517 = static_cast<uint16_t>(v56);
        uint16_t v1518 = static_cast<uint16_t>(v56);
        TEXTRACT(v1515, v1401, v1517, v1518);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline3831__ssa_v21
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1519 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline3831__ssa_v21
        ;
        uint64_t v1520 = (uint64_t) v43;
        TASSIGN(v1519, v1520);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1519, v371, v1511);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline3832__ssa_v7
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1521 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline3832__ssa_v7
        ;
        uint64_t v1522 = (uint64_t) v48;
        TASSIGN(v1521, v1522);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1521, v373, v1515);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1523 = static_cast<uint64_t>(v77);
        uint16_t v1524 = static_cast<uint16_t>(v56);
        uint16_t v1525 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1513, v1519, v1523, v1524, v1525);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID7);
        v1521.SetValidShape(v65, v73);
        // pto: %614
        ;
        __gm__ float* v1526 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %614
        ;
        const int64_t v1527 = 384;
        // pto: %614
        ;
        const int64_t v1528 = 1024;
        // pto: %614
        ;
        pto::Shape<1, 1, 1, 6, 64> v1529 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %614
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1530 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %614
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1531 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1526 + (v1527 + v739 * v1528), v1529, v1530);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1531, v1521);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline3808__ssa_v8
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1532 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline3808__ssa_v8
        ;
        uint64_t v1533 = (uint64_t) v44;
        TASSIGN(v1532, v1533);
        // pto: %buf_current_key_inline3809__ssa_v56
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1534 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline3809__ssa_v56
        ;
        uint64_t v1535 = (uint64_t) v47;
        TASSIGN(v1534, v1535);
        // pto: %616
        ;
        int64_t v1536 = (int64_t) ((uint64_t) v382 + (uint64_t) v82);
        // pto: %617
        ;
        const int64_t v1537 = 1;
        // pto: %617
        ;
        const int64_t v1538 = 0;
        // pto: %617
        ;
        int64_t v1539 = v1536 / v66;
        // pto: %617
        ;
        bool v1540 = v1536 < v1538;
        // pto: %617
        ;
        bool v1541 = v66 < v1538;
        // pto: %617
        ;
        bool v1542 = v1540 == v1541;
        // pto: %617
        ;
        bool v1543 = v1536 % v66 != v1538 && v1540 != v1541;
        // pto: %617
        ;
        int64_t v1544 = v1543 ? v1539 - v1537 : v1539;
        // pto: %621
        ;
        int64_t v1545 = v1544 < v400 ? v1544 : v400;
        // pto: %624, %622
        ;
        int32_t v1546 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v1545)];
        // pto: %625
        ;
        int64_t v1547 = (int64_t) v1546;
        // pto: %626
        ;
        int64_t v1548 = v1547 < v56 ? v56 : v1547;
        // pto: %627
        ;
        int64_t v1549 = (int64_t) ((uint64_t) v1548 * (uint64_t) v16);
        // pto: %628
        ;
        int64_t v1550 = v1549 % v51;
        // pto: %629, %630, %631
        ;
        int64_t v1551 = v1550 < v56 ? (int64_t) ((uint64_t) v1550 + (uint64_t) v51) : v1550;
        // pto: %632
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        if (v1551 == v56) {
          // pto: %633
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1552;
          // pto: %633
          ;
          uint64_t v1553 = (uint64_t) v41;
          TASSIGN(v1552, v1553);
          // pto: %634
          ;
          const int64_t v1554 = 1;
          // pto: %634
          ;
          const int64_t v1555 = 0;
          // pto: %634
          ;
          int64_t v1556 = v1549 / v51;
          // pto: %634
          ;
          bool v1557 = v1549 < v1555;
          // pto: %634
          ;
          bool v1558 = v51 < v1555;
          // pto: %634
          ;
          bool v1559 = v1557 == v1558;
          // pto: %634
          ;
          bool v1560 = v1549 % v51 != v1555 && v1557 != v1558;
          // pto: %634
          ;
          int64_t v1561 = v1560 ? v1556 - v1554 : v1556;
          // pto: %635
          ;
          int64_t v1562 = v1561 < v56 ? v56 : v1561;
          // pto: %636
          ;
          __gm__ int8_t* v1563 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %636
          ;
          const int64_t v1564 = 0;
          // pto: %636
          ;
          const int64_t v1565 = 128;
          // pto: %636
          ;
          pto::Shape<1, 1, 1, 32, 128> v1566 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %636
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1567 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %636
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1568 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1563 + (v1564 + v1562 * v1565), v1566, v1567);
          TLOAD(v1552, v1568);
        } else {
          // pto: %637
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1569;
          // pto: %637
          ;
          uint64_t v1570 = (uint64_t) v41;
          TASSIGN(v1569, v1570);
          // pto: %638
          ;
          const int64_t v1571 = 1;
          // pto: %638
          ;
          const int64_t v1572 = 0;
          // pto: %638
          ;
          int64_t v1573 = v1549 / v51;
          // pto: %638
          ;
          bool v1574 = v1549 < v1572;
          // pto: %638
          ;
          bool v1575 = v51 < v1572;
          // pto: %638
          ;
          bool v1576 = v1574 == v1575;
          // pto: %638
          ;
          bool v1577 = v1549 % v51 != v1572 && v1574 != v1575;
          // pto: %638
          ;
          int64_t v1578 = v1577 ? v1573 - v1571 : v1573;
          // pto: %639
          ;
          int64_t v1579 = v1578 < v56 ? v56 : v1578;
          // pto: %640
          ;
          __gm__ int8_t* v1580 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %640
          ;
          const int64_t v1581 = 0;
          // pto: %640
          ;
          const int64_t v1582 = 128;
          // pto: %640
          ;
          pto::Shape<1, 1, 1, 32, 128> v1583 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %640
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1584 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %640
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1585 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1580 + (v1581 + v1579 * v1582), v1583, v1584);
          TLOAD(v1569, v1585);
        };
        // pto: %643
        ;
        int64_t v1586 = (int64_t) ((uint64_t) v382 + (uint64_t) v32);
        // pto: %644
        ;
        const int64_t v1587 = 1;
        // pto: %644
        ;
        const int64_t v1588 = 0;
        // pto: %644
        ;
        int64_t v1589 = v1586 / v66;
        // pto: %644
        ;
        bool v1590 = v1586 < v1588;
        // pto: %644
        ;
        bool v1591 = v66 < v1588;
        // pto: %644
        ;
        bool v1592 = v1590 == v1591;
        // pto: %644
        ;
        bool v1593 = v1586 % v66 != v1588 && v1590 != v1591;
        // pto: %644
        ;
        int64_t v1594 = v1593 ? v1589 - v1587 : v1589;
        // pto: %648
        ;
        int64_t v1595 = v1594 < v400 ? v1594 : v400;
        // pto: %651, %649
        ;
        int32_t v1596 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v1595)];
        // pto: %652
        ;
        int64_t v1597 = (int64_t) v1596;
        // pto: %653
        ;
        int64_t v1598 = v1597 < v56 ? v56 : v1597;
        // pto: %654
        ;
        int64_t v1599 = (int64_t) ((uint64_t) v1598 * (uint64_t) v16);
        // pto: %655
        ;
        int64_t v1600 = v1599 % v51;
        // pto: %656, %657, %658
        ;
        int64_t v1601 = v1600 < v56 ? (int64_t) ((uint64_t) v1600 + (uint64_t) v51) : v1600;
        // pto: %659
        ;
        if (v1601 == v56) {
          // pto: %661
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1602;
          // pto: %661
          ;
          uint64_t v1603 = (uint64_t) v39;
          TASSIGN(v1602, v1603);
          // pto: %662
          ;
          const int64_t v1604 = 1;
          // pto: %662
          ;
          const int64_t v1605 = 0;
          // pto: %662
          ;
          int64_t v1606 = v1599 / v51;
          // pto: %662
          ;
          bool v1607 = v1599 < v1605;
          // pto: %662
          ;
          bool v1608 = v51 < v1605;
          // pto: %662
          ;
          bool v1609 = v1607 == v1608;
          // pto: %662
          ;
          bool v1610 = v1599 % v51 != v1605 && v1607 != v1608;
          // pto: %662
          ;
          int64_t v1611 = v1610 ? v1606 - v1604 : v1606;
          // pto: %663
          ;
          int64_t v1612 = v1611 < v56 ? v56 : v1611;
          // pto: %664
          ;
          __gm__ int8_t* v1613 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %664
          ;
          const int64_t v1614 = 0;
          // pto: %664
          ;
          const int64_t v1615 = 128;
          // pto: %664
          ;
          pto::Shape<1, 1, 1, 32, 128> v1616 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %664
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1617 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %664
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1618 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1613 + (v1614 + v1612 * v1615), v1616, v1617);
          TLOAD(v1602, v1618);
        } else {
          // pto: %666
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1619;
          // pto: %666
          ;
          uint64_t v1620 = (uint64_t) v39;
          TASSIGN(v1619, v1620);
          // pto: %667
          ;
          const int64_t v1621 = 1;
          // pto: %667
          ;
          const int64_t v1622 = 0;
          // pto: %667
          ;
          int64_t v1623 = v1599 / v51;
          // pto: %667
          ;
          bool v1624 = v1599 < v1622;
          // pto: %667
          ;
          bool v1625 = v51 < v1622;
          // pto: %667
          ;
          bool v1626 = v1624 == v1625;
          // pto: %667
          ;
          bool v1627 = v1599 % v51 != v1622 && v1624 != v1625;
          // pto: %667
          ;
          int64_t v1628 = v1627 ? v1623 - v1621 : v1623;
          // pto: %668
          ;
          int64_t v1629 = v1628 < v56 ? v56 : v1628;
          // pto: %669
          ;
          __gm__ int8_t* v1630 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %669
          ;
          const int64_t v1631 = 0;
          // pto: %669
          ;
          const int64_t v1632 = 128;
          // pto: %669
          ;
          pto::Shape<1, 1, 1, 32, 128> v1633 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %669
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1634 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %669
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1635 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1630 + (v1631 + v1629 * v1632), v1633, v1634);
          TLOAD(v1619, v1635);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v394
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1636 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v394
        ;
        uint64_t v1637 = (uint64_t) v45;
        TASSIGN(v1636, v1637);
        // pto: %buf_prefetched_key_inline3810__ssa_v41
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1638 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline3810__ssa_v41
        ;
        uint64_t v1639 = (uint64_t) v43;
        TASSIGN(v1638, v1639);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1640 = static_cast<uint16_t>(v56);
        uint16_t v1641 = static_cast<uint16_t>(v73);
        TEXTRACT(v1638, v1636, v1640, v1641);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        // pto: %buf_key_panel_inline3828__ssa_v24
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1642 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline3828__ssa_v24
        ;
        uint64_t v1643 = (uint64_t) v47;
        TASSIGN(v1642, v1643);
        // pto: %buf_scores_l1_inline3829__ssa_v32
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1644 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline3829__ssa_v32
        ;
        uint64_t v1645 = (uint64_t) v43;
        TASSIGN(v1644, v1645);
        // pto: %buf_previous_pair_inline3830__ssa_v8
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1646 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline3830__ssa_v8
        ;
        uint64_t v1647 = (uint64_t) v46;
        TASSIGN(v1646, v1647);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID7);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v1648 = static_cast<uint16_t>(v56);
        uint16_t v1649 = static_cast<uint16_t>(v56);
        TEXTRACT(v1646, v1532, v1648, v1649);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline3831__ssa_v24
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1650 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline3831__ssa_v24
        ;
        uint64_t v1651 = (uint64_t) v43;
        TASSIGN(v1650, v1651);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1650, v371, v1642);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline3832__ssa_v8
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1652 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline3832__ssa_v8
        ;
        uint64_t v1653 = (uint64_t) v48;
        TASSIGN(v1652, v1653);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1652, v373, v1646);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1654 = static_cast<uint64_t>(v77);
        uint16_t v1655 = static_cast<uint16_t>(v56);
        uint16_t v1656 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1644, v1650, v1654, v1655, v1656);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v1652.SetValidShape(v65, v73);
        // pto: %673
        ;
        __gm__ float* v1657 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %673
        ;
        const int64_t v1658 = 448;
        // pto: %673
        ;
        const int64_t v1659 = 1024;
        // pto: %673
        ;
        pto::Shape<1, 1, 1, 6, 64> v1660 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %673
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1661 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %673
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1662 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1657 + (v1658 + v739 * v1659), v1660, v1661);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1662, v1652);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline3808__ssa_v9
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1663 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline3808__ssa_v9
        ;
        uint64_t v1664 = (uint64_t) v43;
        TASSIGN(v1663, v1664);
        // pto: %buf_current_key_inline3809__ssa_v63
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1665 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline3809__ssa_v63
        ;
        uint64_t v1666 = (uint64_t) v43;
        TASSIGN(v1665, v1666);
        // pto: %675
        ;
        int64_t v1667 = (int64_t) ((uint64_t) v382 + (uint64_t) v83);
        // pto: %676
        ;
        const int64_t v1668 = 1;
        // pto: %676
        ;
        const int64_t v1669 = 0;
        // pto: %676
        ;
        int64_t v1670 = v1667 / v66;
        // pto: %676
        ;
        bool v1671 = v1667 < v1669;
        // pto: %676
        ;
        bool v1672 = v66 < v1669;
        // pto: %676
        ;
        bool v1673 = v1671 == v1672;
        // pto: %676
        ;
        bool v1674 = v1667 % v66 != v1669 && v1671 != v1672;
        // pto: %676
        ;
        int64_t v1675 = v1674 ? v1670 - v1668 : v1670;
        // pto: %680
        ;
        int64_t v1676 = v1675 < v400 ? v1675 : v400;
        // pto: %683, %681
        ;
        int32_t v1677 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v1676)];
        // pto: %684
        ;
        int64_t v1678 = (int64_t) v1677;
        // pto: %685
        ;
        int64_t v1679 = v1678 < v56 ? v56 : v1678;
        // pto: %686
        ;
        int64_t v1680 = (int64_t) ((uint64_t) v1679 * (uint64_t) v16);
        // pto: %687
        ;
        int64_t v1681 = v1680 % v51;
        // pto: %688, %689, %690
        ;
        int64_t v1682 = v1681 < v56 ? (int64_t) ((uint64_t) v1681 + (uint64_t) v51) : v1681;
        // pto: %691
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        if (v1682 == v56) {
          // pto: %692
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1683;
          // pto: %692
          ;
          uint64_t v1684 = (uint64_t) v45;
          TASSIGN(v1683, v1684);
          // pto: %693
          ;
          const int64_t v1685 = 1;
          // pto: %693
          ;
          const int64_t v1686 = 0;
          // pto: %693
          ;
          int64_t v1687 = v1680 / v51;
          // pto: %693
          ;
          bool v1688 = v1680 < v1686;
          // pto: %693
          ;
          bool v1689 = v51 < v1686;
          // pto: %693
          ;
          bool v1690 = v1688 == v1689;
          // pto: %693
          ;
          bool v1691 = v1680 % v51 != v1686 && v1688 != v1689;
          // pto: %693
          ;
          int64_t v1692 = v1691 ? v1687 - v1685 : v1687;
          // pto: %694
          ;
          int64_t v1693 = v1692 < v56 ? v56 : v1692;
          // pto: %695
          ;
          __gm__ int8_t* v1694 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %695
          ;
          const int64_t v1695 = 0;
          // pto: %695
          ;
          const int64_t v1696 = 128;
          // pto: %695
          ;
          pto::Shape<1, 1, 1, 32, 128> v1697 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %695
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1698 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %695
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1699 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1694 + (v1695 + v1693 * v1696), v1697, v1698);
          TLOAD(v1683, v1699);
        } else {
          // pto: %696
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1700;
          // pto: %696
          ;
          uint64_t v1701 = (uint64_t) v45;
          TASSIGN(v1700, v1701);
          // pto: %697
          ;
          const int64_t v1702 = 1;
          // pto: %697
          ;
          const int64_t v1703 = 0;
          // pto: %697
          ;
          int64_t v1704 = v1680 / v51;
          // pto: %697
          ;
          bool v1705 = v1680 < v1703;
          // pto: %697
          ;
          bool v1706 = v51 < v1703;
          // pto: %697
          ;
          bool v1707 = v1705 == v1706;
          // pto: %697
          ;
          bool v1708 = v1680 % v51 != v1703 && v1705 != v1706;
          // pto: %697
          ;
          int64_t v1709 = v1708 ? v1704 - v1702 : v1704;
          // pto: %698
          ;
          int64_t v1710 = v1709 < v56 ? v56 : v1709;
          // pto: %699
          ;
          __gm__ int8_t* v1711 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %699
          ;
          const int64_t v1712 = 0;
          // pto: %699
          ;
          const int64_t v1713 = 128;
          // pto: %699
          ;
          pto::Shape<1, 1, 1, 32, 128> v1714 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %699
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1715 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %699
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1716 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1711 + (v1712 + v1710 * v1713), v1714, v1715);
          TLOAD(v1700, v1716);
        };
        // pto: %702
        ;
        int64_t v1717 = (int64_t) ((uint64_t) v382 + (uint64_t) v31);
        // pto: %703
        ;
        const int64_t v1718 = 1;
        // pto: %703
        ;
        const int64_t v1719 = 0;
        // pto: %703
        ;
        int64_t v1720 = v1717 / v66;
        // pto: %703
        ;
        bool v1721 = v1717 < v1719;
        // pto: %703
        ;
        bool v1722 = v66 < v1719;
        // pto: %703
        ;
        bool v1723 = v1721 == v1722;
        // pto: %703
        ;
        bool v1724 = v1717 % v66 != v1719 && v1721 != v1722;
        // pto: %703
        ;
        int64_t v1725 = v1724 ? v1720 - v1718 : v1720;
        // pto: %707
        ;
        int64_t v1726 = v1725 < v400 ? v1725 : v400;
        // pto: %710, %708
        ;
        int32_t v1727 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v1726)];
        // pto: %711
        ;
        int64_t v1728 = (int64_t) v1727;
        // pto: %712
        ;
        int64_t v1729 = v1728 < v56 ? v56 : v1728;
        // pto: %713
        ;
        int64_t v1730 = (int64_t) ((uint64_t) v1729 * (uint64_t) v16);
        // pto: %714
        ;
        int64_t v1731 = v1730 % v51;
        // pto: %715, %716, %717
        ;
        int64_t v1732 = v1731 < v56 ? (int64_t) ((uint64_t) v1731 + (uint64_t) v51) : v1731;
        // pto: %718
        ;
        if (v1732 == v56) {
          // pto: %720
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1733;
          // pto: %720
          ;
          uint64_t v1734 = (uint64_t) v42;
          TASSIGN(v1733, v1734);
          // pto: %721
          ;
          const int64_t v1735 = 1;
          // pto: %721
          ;
          const int64_t v1736 = 0;
          // pto: %721
          ;
          int64_t v1737 = v1730 / v51;
          // pto: %721
          ;
          bool v1738 = v1730 < v1736;
          // pto: %721
          ;
          bool v1739 = v51 < v1736;
          // pto: %721
          ;
          bool v1740 = v1738 == v1739;
          // pto: %721
          ;
          bool v1741 = v1730 % v51 != v1736 && v1738 != v1739;
          // pto: %721
          ;
          int64_t v1742 = v1741 ? v1737 - v1735 : v1737;
          // pto: %722
          ;
          int64_t v1743 = v1742 < v56 ? v56 : v1742;
          // pto: %723
          ;
          __gm__ int8_t* v1744 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %723
          ;
          const int64_t v1745 = 0;
          // pto: %723
          ;
          const int64_t v1746 = 128;
          // pto: %723
          ;
          pto::Shape<1, 1, 1, 32, 128> v1747 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %723
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1748 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %723
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1749 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1744 + (v1745 + v1743 * v1746), v1747, v1748);
          TLOAD(v1733, v1749);
        } else {
          // pto: %725
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1750;
          // pto: %725
          ;
          uint64_t v1751 = (uint64_t) v42;
          TASSIGN(v1750, v1751);
          // pto: %726
          ;
          const int64_t v1752 = 1;
          // pto: %726
          ;
          const int64_t v1753 = 0;
          // pto: %726
          ;
          int64_t v1754 = v1730 / v51;
          // pto: %726
          ;
          bool v1755 = v1730 < v1753;
          // pto: %726
          ;
          bool v1756 = v51 < v1753;
          // pto: %726
          ;
          bool v1757 = v1755 == v1756;
          // pto: %726
          ;
          bool v1758 = v1730 % v51 != v1753 && v1755 != v1756;
          // pto: %726
          ;
          int64_t v1759 = v1758 ? v1754 - v1752 : v1754;
          // pto: %727
          ;
          int64_t v1760 = v1759 < v56 ? v56 : v1759;
          // pto: %728
          ;
          __gm__ int8_t* v1761 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %728
          ;
          const int64_t v1762 = 0;
          // pto: %728
          ;
          const int64_t v1763 = 128;
          // pto: %728
          ;
          pto::Shape<1, 1, 1, 32, 128> v1764 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %728
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1765 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %728
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1766 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1761 + (v1762 + v1760 * v1763), v1764, v1765);
          TLOAD(v1750, v1766);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v398
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1767 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v398
        ;
        uint64_t v1768 = (uint64_t) v45;
        TASSIGN(v1767, v1768);
        // pto: %buf_prefetched_key_inline3810__ssa_v46
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1769 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline3810__ssa_v46
        ;
        uint64_t v1770 = (uint64_t) v47;
        TASSIGN(v1769, v1770);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1771 = static_cast<uint16_t>(v56);
        uint16_t v1772 = static_cast<uint16_t>(v56);
        TEXTRACT(v1769, v1767, v1771, v1772);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        // pto: %buf_key_panel_inline3828__ssa_v27
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1773 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline3828__ssa_v27
        ;
        uint64_t v1774 = (uint64_t) v43;
        TASSIGN(v1773, v1774);
        // pto: %buf_scores_l1_inline3829__ssa_v36
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1775 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline3829__ssa_v36
        ;
        uint64_t v1776 = (uint64_t) v44;
        TASSIGN(v1775, v1776);
        // pto: %buf_previous_pair_inline3830__ssa_v9
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1777 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline3830__ssa_v9
        ;
        uint64_t v1778 = (uint64_t) v46;
        TASSIGN(v1777, v1778);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v1779 = static_cast<uint16_t>(v56);
        uint16_t v1780 = static_cast<uint16_t>(v56);
        TEXTRACT(v1777, v1663, v1779, v1780);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline3831__ssa_v27
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1781 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline3831__ssa_v27
        ;
        uint64_t v1782 = (uint64_t) v43;
        TASSIGN(v1781, v1782);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1781, v371, v1773);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline3832__ssa_v9
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1783 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline3832__ssa_v9
        ;
        uint64_t v1784 = (uint64_t) v48;
        TASSIGN(v1783, v1784);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1783, v373, v1777);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1785 = static_cast<uint64_t>(v77);
        uint16_t v1786 = static_cast<uint16_t>(v56);
        uint16_t v1787 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1775, v1781, v1785, v1786, v1787);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v1783.SetValidShape(v65, v73);
        // pto: %732
        ;
        __gm__ float* v1788 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %732
        ;
        const int64_t v1789 = 512;
        // pto: %732
        ;
        const int64_t v1790 = 1024;
        // pto: %732
        ;
        pto::Shape<1, 1, 1, 6, 64> v1791 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %732
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1792 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %732
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1793 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1788 + (v1789 + v739 * v1790), v1791, v1792);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1793, v1783);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline3808__ssa_v10
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1794 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline3808__ssa_v10
        ;
        uint64_t v1795 = (uint64_t) v44;
        TASSIGN(v1794, v1795);
        // pto: %buf_current_key_inline3809__ssa_v70
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1796 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline3809__ssa_v70
        ;
        uint64_t v1797 = (uint64_t) v47;
        TASSIGN(v1796, v1797);
        // pto: %734
        ;
        int64_t v1798 = (int64_t) ((uint64_t) v382 + (uint64_t) v84);
        // pto: %735
        ;
        const int64_t v1799 = 1;
        // pto: %735
        ;
        const int64_t v1800 = 0;
        // pto: %735
        ;
        int64_t v1801 = v1798 / v66;
        // pto: %735
        ;
        bool v1802 = v1798 < v1800;
        // pto: %735
        ;
        bool v1803 = v66 < v1800;
        // pto: %735
        ;
        bool v1804 = v1802 == v1803;
        // pto: %735
        ;
        bool v1805 = v1798 % v66 != v1800 && v1802 != v1803;
        // pto: %735
        ;
        int64_t v1806 = v1805 ? v1801 - v1799 : v1801;
        // pto: %739
        ;
        int64_t v1807 = v1806 < v400 ? v1806 : v400;
        // pto: %742, %740
        ;
        int32_t v1808 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v1807)];
        // pto: %743
        ;
        int64_t v1809 = (int64_t) v1808;
        // pto: %744
        ;
        int64_t v1810 = v1809 < v56 ? v56 : v1809;
        // pto: %745
        ;
        int64_t v1811 = (int64_t) ((uint64_t) v1810 * (uint64_t) v16);
        // pto: %746
        ;
        int64_t v1812 = v1811 % v51;
        // pto: %747, %748, %749
        ;
        int64_t v1813 = v1812 < v56 ? (int64_t) ((uint64_t) v1812 + (uint64_t) v51) : v1812;
        // pto: %750
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        if (v1813 == v56) {
          // pto: %751
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1814;
          // pto: %751
          ;
          uint64_t v1815 = (uint64_t) v41;
          TASSIGN(v1814, v1815);
          // pto: %752
          ;
          const int64_t v1816 = 1;
          // pto: %752
          ;
          const int64_t v1817 = 0;
          // pto: %752
          ;
          int64_t v1818 = v1811 / v51;
          // pto: %752
          ;
          bool v1819 = v1811 < v1817;
          // pto: %752
          ;
          bool v1820 = v51 < v1817;
          // pto: %752
          ;
          bool v1821 = v1819 == v1820;
          // pto: %752
          ;
          bool v1822 = v1811 % v51 != v1817 && v1819 != v1820;
          // pto: %752
          ;
          int64_t v1823 = v1822 ? v1818 - v1816 : v1818;
          // pto: %753
          ;
          int64_t v1824 = v1823 < v56 ? v56 : v1823;
          // pto: %754
          ;
          __gm__ int8_t* v1825 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %754
          ;
          const int64_t v1826 = 0;
          // pto: %754
          ;
          const int64_t v1827 = 128;
          // pto: %754
          ;
          pto::Shape<1, 1, 1, 32, 128> v1828 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %754
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1829 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %754
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1830 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1825 + (v1826 + v1824 * v1827), v1828, v1829);
          TLOAD(v1814, v1830);
        } else {
          // pto: %755
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1831;
          // pto: %755
          ;
          uint64_t v1832 = (uint64_t) v41;
          TASSIGN(v1831, v1832);
          // pto: %756
          ;
          const int64_t v1833 = 1;
          // pto: %756
          ;
          const int64_t v1834 = 0;
          // pto: %756
          ;
          int64_t v1835 = v1811 / v51;
          // pto: %756
          ;
          bool v1836 = v1811 < v1834;
          // pto: %756
          ;
          bool v1837 = v51 < v1834;
          // pto: %756
          ;
          bool v1838 = v1836 == v1837;
          // pto: %756
          ;
          bool v1839 = v1811 % v51 != v1834 && v1836 != v1837;
          // pto: %756
          ;
          int64_t v1840 = v1839 ? v1835 - v1833 : v1835;
          // pto: %757
          ;
          int64_t v1841 = v1840 < v56 ? v56 : v1840;
          // pto: %758
          ;
          __gm__ int8_t* v1842 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %758
          ;
          const int64_t v1843 = 0;
          // pto: %758
          ;
          const int64_t v1844 = 128;
          // pto: %758
          ;
          pto::Shape<1, 1, 1, 32, 128> v1845 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %758
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1846 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %758
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1847 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1842 + (v1843 + v1841 * v1844), v1845, v1846);
          TLOAD(v1831, v1847);
        };
        // pto: %761
        ;
        int64_t v1848 = (int64_t) ((uint64_t) v382 + (uint64_t) v30);
        // pto: %762
        ;
        const int64_t v1849 = 1;
        // pto: %762
        ;
        const int64_t v1850 = 0;
        // pto: %762
        ;
        int64_t v1851 = v1848 / v66;
        // pto: %762
        ;
        bool v1852 = v1848 < v1850;
        // pto: %762
        ;
        bool v1853 = v66 < v1850;
        // pto: %762
        ;
        bool v1854 = v1852 == v1853;
        // pto: %762
        ;
        bool v1855 = v1848 % v66 != v1850 && v1852 != v1853;
        // pto: %762
        ;
        int64_t v1856 = v1855 ? v1851 - v1849 : v1851;
        // pto: %766
        ;
        int64_t v1857 = v1856 < v400 ? v1856 : v400;
        // pto: %769, %767
        ;
        int32_t v1858 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v1857)];
        // pto: %770
        ;
        int64_t v1859 = (int64_t) v1858;
        // pto: %771
        ;
        int64_t v1860 = v1859 < v56 ? v56 : v1859;
        // pto: %772
        ;
        int64_t v1861 = (int64_t) ((uint64_t) v1860 * (uint64_t) v16);
        // pto: %773
        ;
        int64_t v1862 = v1861 % v51;
        // pto: %774, %775, %776
        ;
        int64_t v1863 = v1862 < v56 ? (int64_t) ((uint64_t) v1862 + (uint64_t) v51) : v1862;
        // pto: %777
        ;
        if (v1863 == v56) {
          // pto: %779
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1864;
          // pto: %779
          ;
          uint64_t v1865 = (uint64_t) v39;
          TASSIGN(v1864, v1865);
          // pto: %780
          ;
          const int64_t v1866 = 1;
          // pto: %780
          ;
          const int64_t v1867 = 0;
          // pto: %780
          ;
          int64_t v1868 = v1861 / v51;
          // pto: %780
          ;
          bool v1869 = v1861 < v1867;
          // pto: %780
          ;
          bool v1870 = v51 < v1867;
          // pto: %780
          ;
          bool v1871 = v1869 == v1870;
          // pto: %780
          ;
          bool v1872 = v1861 % v51 != v1867 && v1869 != v1870;
          // pto: %780
          ;
          int64_t v1873 = v1872 ? v1868 - v1866 : v1868;
          // pto: %781
          ;
          int64_t v1874 = v1873 < v56 ? v56 : v1873;
          // pto: %782
          ;
          __gm__ int8_t* v1875 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %782
          ;
          const int64_t v1876 = 0;
          // pto: %782
          ;
          const int64_t v1877 = 128;
          // pto: %782
          ;
          pto::Shape<1, 1, 1, 32, 128> v1878 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %782
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1879 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %782
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1880 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1875 + (v1876 + v1874 * v1877), v1878, v1879);
          TLOAD(v1864, v1880);
        } else {
          // pto: %784
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1881;
          // pto: %784
          ;
          uint64_t v1882 = (uint64_t) v39;
          TASSIGN(v1881, v1882);
          // pto: %785
          ;
          const int64_t v1883 = 1;
          // pto: %785
          ;
          const int64_t v1884 = 0;
          // pto: %785
          ;
          int64_t v1885 = v1861 / v51;
          // pto: %785
          ;
          bool v1886 = v1861 < v1884;
          // pto: %785
          ;
          bool v1887 = v51 < v1884;
          // pto: %785
          ;
          bool v1888 = v1886 == v1887;
          // pto: %785
          ;
          bool v1889 = v1861 % v51 != v1884 && v1886 != v1887;
          // pto: %785
          ;
          int64_t v1890 = v1889 ? v1885 - v1883 : v1885;
          // pto: %786
          ;
          int64_t v1891 = v1890 < v56 ? v56 : v1890;
          // pto: %787
          ;
          __gm__ int8_t* v1892 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %787
          ;
          const int64_t v1893 = 0;
          // pto: %787
          ;
          const int64_t v1894 = 128;
          // pto: %787
          ;
          pto::Shape<1, 1, 1, 32, 128> v1895 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %787
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1896 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %787
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1897 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1892 + (v1893 + v1891 * v1894), v1895, v1896);
          TLOAD(v1881, v1897);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v402
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1898 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v402
        ;
        uint64_t v1899 = (uint64_t) v45;
        TASSIGN(v1898, v1899);
        // pto: %buf_prefetched_key_inline3810__ssa_v51
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1900 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline3810__ssa_v51
        ;
        uint64_t v1901 = (uint64_t) v43;
        TASSIGN(v1900, v1901);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1902 = static_cast<uint16_t>(v56);
        uint16_t v1903 = static_cast<uint16_t>(v73);
        TEXTRACT(v1900, v1898, v1902, v1903);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        // pto: %buf_key_panel_inline3828__ssa_v30
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1904 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline3828__ssa_v30
        ;
        uint64_t v1905 = (uint64_t) v47;
        TASSIGN(v1904, v1905);
        // pto: %buf_scores_l1_inline3829__ssa_v40
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1906 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline3829__ssa_v40
        ;
        uint64_t v1907 = (uint64_t) v43;
        TASSIGN(v1906, v1907);
        // pto: %buf_previous_pair_inline3830__ssa_v10
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1908 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline3830__ssa_v10
        ;
        uint64_t v1909 = (uint64_t) v46;
        TASSIGN(v1908, v1909);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v1910 = static_cast<uint16_t>(v56);
        uint16_t v1911 = static_cast<uint16_t>(v56);
        TEXTRACT(v1908, v1794, v1910, v1911);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline3831__ssa_v30
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1912 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline3831__ssa_v30
        ;
        uint64_t v1913 = (uint64_t) v43;
        TASSIGN(v1912, v1913);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1912, v371, v1904);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline3832__ssa_v10
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1914 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline3832__ssa_v10
        ;
        uint64_t v1915 = (uint64_t) v48;
        TASSIGN(v1914, v1915);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1914, v373, v1908);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1916 = static_cast<uint64_t>(v77);
        uint16_t v1917 = static_cast<uint16_t>(v56);
        uint16_t v1918 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1906, v1912, v1916, v1917, v1918);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v1914.SetValidShape(v65, v73);
        // pto: %791
        ;
        __gm__ float* v1919 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %791
        ;
        const int64_t v1920 = 576;
        // pto: %791
        ;
        const int64_t v1921 = 1024;
        // pto: %791
        ;
        pto::Shape<1, 1, 1, 6, 64> v1922 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %791
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1923 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %791
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1924 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1919 + (v1920 + v739 * v1921), v1922, v1923);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1924, v1914);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline3808__ssa_v11
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1925 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline3808__ssa_v11
        ;
        uint64_t v1926 = (uint64_t) v43;
        TASSIGN(v1925, v1926);
        // pto: %buf_current_key_inline3809__ssa_v77
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1927 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline3809__ssa_v77
        ;
        uint64_t v1928 = (uint64_t) v43;
        TASSIGN(v1927, v1928);
        // pto: %793
        ;
        int64_t v1929 = (int64_t) ((uint64_t) v382 + (uint64_t) v85);
        // pto: %794
        ;
        const int64_t v1930 = 1;
        // pto: %794
        ;
        const int64_t v1931 = 0;
        // pto: %794
        ;
        int64_t v1932 = v1929 / v66;
        // pto: %794
        ;
        bool v1933 = v1929 < v1931;
        // pto: %794
        ;
        bool v1934 = v66 < v1931;
        // pto: %794
        ;
        bool v1935 = v1933 == v1934;
        // pto: %794
        ;
        bool v1936 = v1929 % v66 != v1931 && v1933 != v1934;
        // pto: %794
        ;
        int64_t v1937 = v1936 ? v1932 - v1930 : v1932;
        // pto: %798
        ;
        int64_t v1938 = v1937 < v400 ? v1937 : v400;
        // pto: %801, %799
        ;
        int32_t v1939 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v1938)];
        // pto: %802
        ;
        int64_t v1940 = (int64_t) v1939;
        // pto: %803
        ;
        int64_t v1941 = v1940 < v56 ? v56 : v1940;
        // pto: %804
        ;
        int64_t v1942 = (int64_t) ((uint64_t) v1941 * (uint64_t) v16);
        // pto: %805
        ;
        int64_t v1943 = v1942 % v51;
        // pto: %806, %807, %808
        ;
        int64_t v1944 = v1943 < v56 ? (int64_t) ((uint64_t) v1943 + (uint64_t) v51) : v1943;
        // pto: %809
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        if (v1944 == v56) {
          // pto: %810
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1945;
          // pto: %810
          ;
          uint64_t v1946 = (uint64_t) v45;
          TASSIGN(v1945, v1946);
          // pto: %811
          ;
          const int64_t v1947 = 1;
          // pto: %811
          ;
          const int64_t v1948 = 0;
          // pto: %811
          ;
          int64_t v1949 = v1942 / v51;
          // pto: %811
          ;
          bool v1950 = v1942 < v1948;
          // pto: %811
          ;
          bool v1951 = v51 < v1948;
          // pto: %811
          ;
          bool v1952 = v1950 == v1951;
          // pto: %811
          ;
          bool v1953 = v1942 % v51 != v1948 && v1950 != v1951;
          // pto: %811
          ;
          int64_t v1954 = v1953 ? v1949 - v1947 : v1949;
          // pto: %812
          ;
          int64_t v1955 = v1954 < v56 ? v56 : v1954;
          // pto: %813
          ;
          __gm__ int8_t* v1956 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %813
          ;
          const int64_t v1957 = 0;
          // pto: %813
          ;
          const int64_t v1958 = 128;
          // pto: %813
          ;
          pto::Shape<1, 1, 1, 32, 128> v1959 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %813
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1960 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %813
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1961 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1956 + (v1957 + v1955 * v1958), v1959, v1960);
          TLOAD(v1945, v1961);
        } else {
          // pto: %814
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1962;
          // pto: %814
          ;
          uint64_t v1963 = (uint64_t) v45;
          TASSIGN(v1962, v1963);
          // pto: %815
          ;
          const int64_t v1964 = 1;
          // pto: %815
          ;
          const int64_t v1965 = 0;
          // pto: %815
          ;
          int64_t v1966 = v1942 / v51;
          // pto: %815
          ;
          bool v1967 = v1942 < v1965;
          // pto: %815
          ;
          bool v1968 = v51 < v1965;
          // pto: %815
          ;
          bool v1969 = v1967 == v1968;
          // pto: %815
          ;
          bool v1970 = v1942 % v51 != v1965 && v1967 != v1968;
          // pto: %815
          ;
          int64_t v1971 = v1970 ? v1966 - v1964 : v1966;
          // pto: %816
          ;
          int64_t v1972 = v1971 < v56 ? v56 : v1971;
          // pto: %817
          ;
          __gm__ int8_t* v1973 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %817
          ;
          const int64_t v1974 = 0;
          // pto: %817
          ;
          const int64_t v1975 = 128;
          // pto: %817
          ;
          pto::Shape<1, 1, 1, 32, 128> v1976 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %817
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1977 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %817
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1978 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1973 + (v1974 + v1972 * v1975), v1976, v1977);
          TLOAD(v1962, v1978);
        };
        // pto: %820
        ;
        int64_t v1979 = (int64_t) ((uint64_t) v382 + (uint64_t) v29);
        // pto: %821
        ;
        const int64_t v1980 = 1;
        // pto: %821
        ;
        const int64_t v1981 = 0;
        // pto: %821
        ;
        int64_t v1982 = v1979 / v66;
        // pto: %821
        ;
        bool v1983 = v1979 < v1981;
        // pto: %821
        ;
        bool v1984 = v66 < v1981;
        // pto: %821
        ;
        bool v1985 = v1983 == v1984;
        // pto: %821
        ;
        bool v1986 = v1979 % v66 != v1981 && v1983 != v1984;
        // pto: %821
        ;
        int64_t v1987 = v1986 ? v1982 - v1980 : v1982;
        // pto: %825
        ;
        int64_t v1988 = v1987 < v400 ? v1987 : v400;
        // pto: %828, %826
        ;
        int32_t v1989 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v1988)];
        // pto: %829
        ;
        int64_t v1990 = (int64_t) v1989;
        // pto: %830
        ;
        int64_t v1991 = v1990 < v56 ? v56 : v1990;
        // pto: %831
        ;
        int64_t v1992 = (int64_t) ((uint64_t) v1991 * (uint64_t) v16);
        // pto: %832
        ;
        int64_t v1993 = v1992 % v51;
        // pto: %833, %834, %835
        ;
        int64_t v1994 = v1993 < v56 ? (int64_t) ((uint64_t) v1993 + (uint64_t) v51) : v1993;
        // pto: %836
        ;
        if (v1994 == v56) {
          // pto: %838
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1995;
          // pto: %838
          ;
          uint64_t v1996 = (uint64_t) v42;
          TASSIGN(v1995, v1996);
          // pto: %839
          ;
          const int64_t v1997 = 1;
          // pto: %839
          ;
          const int64_t v1998 = 0;
          // pto: %839
          ;
          int64_t v1999 = v1992 / v51;
          // pto: %839
          ;
          bool v2000 = v1992 < v1998;
          // pto: %839
          ;
          bool v2001 = v51 < v1998;
          // pto: %839
          ;
          bool v2002 = v2000 == v2001;
          // pto: %839
          ;
          bool v2003 = v1992 % v51 != v1998 && v2000 != v2001;
          // pto: %839
          ;
          int64_t v2004 = v2003 ? v1999 - v1997 : v1999;
          // pto: %840
          ;
          int64_t v2005 = v2004 < v56 ? v56 : v2004;
          // pto: %841
          ;
          __gm__ int8_t* v2006 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %841
          ;
          const int64_t v2007 = 0;
          // pto: %841
          ;
          const int64_t v2008 = 128;
          // pto: %841
          ;
          pto::Shape<1, 1, 1, 32, 128> v2009 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %841
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v2010 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %841
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v2011 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v2006 + (v2007 + v2005 * v2008), v2009, v2010);
          TLOAD(v1995, v2011);
        } else {
          // pto: %843
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v2012;
          // pto: %843
          ;
          uint64_t v2013 = (uint64_t) v42;
          TASSIGN(v2012, v2013);
          // pto: %844
          ;
          const int64_t v2014 = 1;
          // pto: %844
          ;
          const int64_t v2015 = 0;
          // pto: %844
          ;
          int64_t v2016 = v1992 / v51;
          // pto: %844
          ;
          bool v2017 = v1992 < v2015;
          // pto: %844
          ;
          bool v2018 = v51 < v2015;
          // pto: %844
          ;
          bool v2019 = v2017 == v2018;
          // pto: %844
          ;
          bool v2020 = v1992 % v51 != v2015 && v2017 != v2018;
          // pto: %844
          ;
          int64_t v2021 = v2020 ? v2016 - v2014 : v2016;
          // pto: %845
          ;
          int64_t v2022 = v2021 < v56 ? v56 : v2021;
          // pto: %846
          ;
          __gm__ int8_t* v2023 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %846
          ;
          const int64_t v2024 = 0;
          // pto: %846
          ;
          const int64_t v2025 = 128;
          // pto: %846
          ;
          pto::Shape<1, 1, 1, 32, 128> v2026 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %846
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v2027 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %846
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v2028 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v2023 + (v2024 + v2022 * v2025), v2026, v2027);
          TLOAD(v2012, v2028);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v406
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v2029 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v406
        ;
        uint64_t v2030 = (uint64_t) v45;
        TASSIGN(v2029, v2030);
        // pto: %buf_prefetched_key_inline3810__ssa_v56
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v2031 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline3810__ssa_v56
        ;
        uint64_t v2032 = (uint64_t) v47;
        TASSIGN(v2031, v2032);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v2033 = static_cast<uint16_t>(v56);
        uint16_t v2034 = static_cast<uint16_t>(v56);
        TEXTRACT(v2031, v2029, v2033, v2034);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        // pto: %buf_key_panel_inline3828__ssa_v33
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v2035 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline3828__ssa_v33
        ;
        uint64_t v2036 = (uint64_t) v43;
        TASSIGN(v2035, v2036);
        // pto: %buf_scores_l1_inline3829__ssa_v44
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v2037 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline3829__ssa_v44
        ;
        uint64_t v2038 = (uint64_t) v44;
        TASSIGN(v2037, v2038);
        // pto: %buf_previous_pair_inline3830__ssa_v11
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v2039 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline3830__ssa_v11
        ;
        uint64_t v2040 = (uint64_t) v46;
        TASSIGN(v2039, v2040);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v2041 = static_cast<uint16_t>(v56);
        uint16_t v2042 = static_cast<uint16_t>(v56);
        TEXTRACT(v2039, v1925, v2041, v2042);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline3831__ssa_v33
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v2043 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline3831__ssa_v33
        ;
        uint64_t v2044 = (uint64_t) v43;
        TASSIGN(v2043, v2044);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v2043, v371, v2035);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline3832__ssa_v11
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v2045 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline3832__ssa_v11
        ;
        uint64_t v2046 = (uint64_t) v48;
        TASSIGN(v2045, v2046);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v2045, v373, v2039);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v2047 = static_cast<uint64_t>(v77);
        uint16_t v2048 = static_cast<uint16_t>(v56);
        uint16_t v2049 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v2037, v2043, v2047, v2048, v2049);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v2045.SetValidShape(v65, v73);
        // pto: %850
        ;
        __gm__ float* v2050 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %850
        ;
        const int64_t v2051 = 640;
        // pto: %850
        ;
        const int64_t v2052 = 1024;
        // pto: %850
        ;
        pto::Shape<1, 1, 1, 6, 64> v2053 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %850
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v2054 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %850
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v2055 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v2050 + (v2051 + v739 * v2052), v2053, v2054);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v2055, v2045);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline3808__ssa_v12
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v2056 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline3808__ssa_v12
        ;
        uint64_t v2057 = (uint64_t) v44;
        TASSIGN(v2056, v2057);
        // pto: %buf_current_key_inline3809__ssa_v84
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v2058 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline3809__ssa_v84
        ;
        uint64_t v2059 = (uint64_t) v47;
        TASSIGN(v2058, v2059);
        // pto: %852
        ;
        int64_t v2060 = (int64_t) ((uint64_t) v382 + (uint64_t) v86);
        // pto: %853
        ;
        const int64_t v2061 = 1;
        // pto: %853
        ;
        const int64_t v2062 = 0;
        // pto: %853
        ;
        int64_t v2063 = v2060 / v66;
        // pto: %853
        ;
        bool v2064 = v2060 < v2062;
        // pto: %853
        ;
        bool v2065 = v66 < v2062;
        // pto: %853
        ;
        bool v2066 = v2064 == v2065;
        // pto: %853
        ;
        bool v2067 = v2060 % v66 != v2062 && v2064 != v2065;
        // pto: %853
        ;
        int64_t v2068 = v2067 ? v2063 - v2061 : v2063;
        // pto: %857
        ;
        int64_t v2069 = v2068 < v400 ? v2068 : v400;
        // pto: %860, %858
        ;
        int32_t v2070 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v2069)];
        // pto: %861
        ;
        int64_t v2071 = (int64_t) v2070;
        // pto: %862
        ;
        int64_t v2072 = v2071 < v56 ? v56 : v2071;
        // pto: %863
        ;
        int64_t v2073 = (int64_t) ((uint64_t) v2072 * (uint64_t) v16);
        // pto: %864
        ;
        int64_t v2074 = v2073 % v51;
        // pto: %865, %866, %867
        ;
        int64_t v2075 = v2074 < v56 ? (int64_t) ((uint64_t) v2074 + (uint64_t) v51) : v2074;
        // pto: %868
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        if (v2075 == v56) {
          // pto: %869
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v2076;
          // pto: %869
          ;
          uint64_t v2077 = (uint64_t) v41;
          TASSIGN(v2076, v2077);
          // pto: %870
          ;
          const int64_t v2078 = 1;
          // pto: %870
          ;
          const int64_t v2079 = 0;
          // pto: %870
          ;
          int64_t v2080 = v2073 / v51;
          // pto: %870
          ;
          bool v2081 = v2073 < v2079;
          // pto: %870
          ;
          bool v2082 = v51 < v2079;
          // pto: %870
          ;
          bool v2083 = v2081 == v2082;
          // pto: %870
          ;
          bool v2084 = v2073 % v51 != v2079 && v2081 != v2082;
          // pto: %870
          ;
          int64_t v2085 = v2084 ? v2080 - v2078 : v2080;
          // pto: %871
          ;
          int64_t v2086 = v2085 < v56 ? v56 : v2085;
          // pto: %872
          ;
          __gm__ int8_t* v2087 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %872
          ;
          const int64_t v2088 = 0;
          // pto: %872
          ;
          const int64_t v2089 = 128;
          // pto: %872
          ;
          pto::Shape<1, 1, 1, 32, 128> v2090 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %872
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v2091 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %872
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v2092 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v2087 + (v2088 + v2086 * v2089), v2090, v2091);
          TLOAD(v2076, v2092);
        } else {
          // pto: %873
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v2093;
          // pto: %873
          ;
          uint64_t v2094 = (uint64_t) v41;
          TASSIGN(v2093, v2094);
          // pto: %874
          ;
          const int64_t v2095 = 1;
          // pto: %874
          ;
          const int64_t v2096 = 0;
          // pto: %874
          ;
          int64_t v2097 = v2073 / v51;
          // pto: %874
          ;
          bool v2098 = v2073 < v2096;
          // pto: %874
          ;
          bool v2099 = v51 < v2096;
          // pto: %874
          ;
          bool v2100 = v2098 == v2099;
          // pto: %874
          ;
          bool v2101 = v2073 % v51 != v2096 && v2098 != v2099;
          // pto: %874
          ;
          int64_t v2102 = v2101 ? v2097 - v2095 : v2097;
          // pto: %875
          ;
          int64_t v2103 = v2102 < v56 ? v56 : v2102;
          // pto: %876
          ;
          __gm__ int8_t* v2104 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %876
          ;
          const int64_t v2105 = 0;
          // pto: %876
          ;
          const int64_t v2106 = 128;
          // pto: %876
          ;
          pto::Shape<1, 1, 1, 32, 128> v2107 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %876
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v2108 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %876
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v2109 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v2104 + (v2105 + v2103 * v2106), v2107, v2108);
          TLOAD(v2093, v2109);
        };
        // pto: %879
        ;
        int64_t v2110 = (int64_t) ((uint64_t) v382 + (uint64_t) v28);
        // pto: %880
        ;
        const int64_t v2111 = 1;
        // pto: %880
        ;
        const int64_t v2112 = 0;
        // pto: %880
        ;
        int64_t v2113 = v2110 / v66;
        // pto: %880
        ;
        bool v2114 = v2110 < v2112;
        // pto: %880
        ;
        bool v2115 = v66 < v2112;
        // pto: %880
        ;
        bool v2116 = v2114 == v2115;
        // pto: %880
        ;
        bool v2117 = v2110 % v66 != v2112 && v2114 != v2115;
        // pto: %880
        ;
        int64_t v2118 = v2117 ? v2113 - v2111 : v2113;
        // pto: %884
        ;
        int64_t v2119 = v2118 < v400 ? v2118 : v400;
        // pto: %887, %885
        ;
        int32_t v2120 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v2119)];
        // pto: %888
        ;
        int64_t v2121 = (int64_t) v2120;
        // pto: %889
        ;
        int64_t v2122 = v2121 < v56 ? v56 : v2121;
        // pto: %890
        ;
        int64_t v2123 = (int64_t) ((uint64_t) v2122 * (uint64_t) v16);
        // pto: %891
        ;
        int64_t v2124 = v2123 % v51;
        // pto: %892, %893, %894
        ;
        int64_t v2125 = v2124 < v56 ? (int64_t) ((uint64_t) v2124 + (uint64_t) v51) : v2124;
        // pto: %895
        ;
        if (v2125 == v56) {
          // pto: %897
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v2126;
          // pto: %897
          ;
          uint64_t v2127 = (uint64_t) v39;
          TASSIGN(v2126, v2127);
          // pto: %898
          ;
          const int64_t v2128 = 1;
          // pto: %898
          ;
          const int64_t v2129 = 0;
          // pto: %898
          ;
          int64_t v2130 = v2123 / v51;
          // pto: %898
          ;
          bool v2131 = v2123 < v2129;
          // pto: %898
          ;
          bool v2132 = v51 < v2129;
          // pto: %898
          ;
          bool v2133 = v2131 == v2132;
          // pto: %898
          ;
          bool v2134 = v2123 % v51 != v2129 && v2131 != v2132;
          // pto: %898
          ;
          int64_t v2135 = v2134 ? v2130 - v2128 : v2130;
          // pto: %899
          ;
          int64_t v2136 = v2135 < v56 ? v56 : v2135;
          // pto: %900
          ;
          __gm__ int8_t* v2137 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %900
          ;
          const int64_t v2138 = 0;
          // pto: %900
          ;
          const int64_t v2139 = 128;
          // pto: %900
          ;
          pto::Shape<1, 1, 1, 32, 128> v2140 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %900
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v2141 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %900
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v2142 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v2137 + (v2138 + v2136 * v2139), v2140, v2141);
          TLOAD(v2126, v2142);
        } else {
          // pto: %902
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v2143;
          // pto: %902
          ;
          uint64_t v2144 = (uint64_t) v39;
          TASSIGN(v2143, v2144);
          // pto: %903
          ;
          const int64_t v2145 = 1;
          // pto: %903
          ;
          const int64_t v2146 = 0;
          // pto: %903
          ;
          int64_t v2147 = v2123 / v51;
          // pto: %903
          ;
          bool v2148 = v2123 < v2146;
          // pto: %903
          ;
          bool v2149 = v51 < v2146;
          // pto: %903
          ;
          bool v2150 = v2148 == v2149;
          // pto: %903
          ;
          bool v2151 = v2123 % v51 != v2146 && v2148 != v2149;
          // pto: %903
          ;
          int64_t v2152 = v2151 ? v2147 - v2145 : v2147;
          // pto: %904
          ;
          int64_t v2153 = v2152 < v56 ? v56 : v2152;
          // pto: %905
          ;
          __gm__ int8_t* v2154 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %905
          ;
          const int64_t v2155 = 0;
          // pto: %905
          ;
          const int64_t v2156 = 128;
          // pto: %905
          ;
          pto::Shape<1, 1, 1, 32, 128> v2157 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %905
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v2158 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %905
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v2159 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v2154 + (v2155 + v2153 * v2156), v2157, v2158);
          TLOAD(v2143, v2159);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v410
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v2160 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v410
        ;
        uint64_t v2161 = (uint64_t) v45;
        TASSIGN(v2160, v2161);
        // pto: %buf_prefetched_key_inline3810__ssa_v61
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v2162 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline3810__ssa_v61
        ;
        uint64_t v2163 = (uint64_t) v43;
        TASSIGN(v2162, v2163);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v2164 = static_cast<uint16_t>(v56);
        uint16_t v2165 = static_cast<uint16_t>(v73);
        TEXTRACT(v2162, v2160, v2164, v2165);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        // pto: %buf_key_panel_inline3828__ssa_v36
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v2166 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline3828__ssa_v36
        ;
        uint64_t v2167 = (uint64_t) v47;
        TASSIGN(v2166, v2167);
        // pto: %buf_scores_l1_inline3829__ssa_v48
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v2168 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline3829__ssa_v48
        ;
        uint64_t v2169 = (uint64_t) v43;
        TASSIGN(v2168, v2169);
        // pto: %buf_previous_pair_inline3830__ssa_v12
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v2170 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline3830__ssa_v12
        ;
        uint64_t v2171 = (uint64_t) v46;
        TASSIGN(v2170, v2171);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v2172 = static_cast<uint16_t>(v56);
        uint16_t v2173 = static_cast<uint16_t>(v56);
        TEXTRACT(v2170, v2056, v2172, v2173);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline3831__ssa_v36
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v2174 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline3831__ssa_v36
        ;
        uint64_t v2175 = (uint64_t) v43;
        TASSIGN(v2174, v2175);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v2174, v371, v2166);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline3832__ssa_v12
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v2176 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline3832__ssa_v12
        ;
        uint64_t v2177 = (uint64_t) v48;
        TASSIGN(v2176, v2177);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v2176, v373, v2170);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v2178 = static_cast<uint64_t>(v77);
        uint16_t v2179 = static_cast<uint16_t>(v56);
        uint16_t v2180 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v2168, v2174, v2178, v2179, v2180);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v2176.SetValidShape(v65, v73);
        // pto: %909
        ;
        __gm__ float* v2181 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %909
        ;
        const int64_t v2182 = 704;
        // pto: %909
        ;
        const int64_t v2183 = 1024;
        // pto: %909
        ;
        pto::Shape<1, 1, 1, 6, 64> v2184 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %909
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v2185 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %909
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v2186 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v2181 + (v2182 + v739 * v2183), v2184, v2185);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v2186, v2176);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline3808__ssa_v13
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v2187 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline3808__ssa_v13
        ;
        uint64_t v2188 = (uint64_t) v43;
        TASSIGN(v2187, v2188);
        // pto: %buf_current_key_inline3809__ssa_v91
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v2189 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline3809__ssa_v91
        ;
        uint64_t v2190 = (uint64_t) v43;
        TASSIGN(v2189, v2190);
        // pto: %911
        ;
        int64_t v2191 = (int64_t) ((uint64_t) v382 + (uint64_t) v87);
        // pto: %912
        ;
        const int64_t v2192 = 1;
        // pto: %912
        ;
        const int64_t v2193 = 0;
        // pto: %912
        ;
        int64_t v2194 = v2191 / v66;
        // pto: %912
        ;
        bool v2195 = v2191 < v2193;
        // pto: %912
        ;
        bool v2196 = v66 < v2193;
        // pto: %912
        ;
        bool v2197 = v2195 == v2196;
        // pto: %912
        ;
        bool v2198 = v2191 % v66 != v2193 && v2195 != v2196;
        // pto: %912
        ;
        int64_t v2199 = v2198 ? v2194 - v2192 : v2194;
        // pto: %916
        ;
        int64_t v2200 = v2199 < v400 ? v2199 : v400;
        // pto: %919, %917
        ;
        int32_t v2201 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v2200)];
        // pto: %920
        ;
        int64_t v2202 = (int64_t) v2201;
        // pto: %921
        ;
        int64_t v2203 = v2202 < v56 ? v56 : v2202;
        // pto: %922
        ;
        int64_t v2204 = (int64_t) ((uint64_t) v2203 * (uint64_t) v16);
        // pto: %923
        ;
        int64_t v2205 = v2204 % v51;
        // pto: %924, %925, %926
        ;
        int64_t v2206 = v2205 < v56 ? (int64_t) ((uint64_t) v2205 + (uint64_t) v51) : v2205;
        // pto: %927
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        if (v2206 == v56) {
          // pto: %928
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v2207;
          // pto: %928
          ;
          uint64_t v2208 = (uint64_t) v45;
          TASSIGN(v2207, v2208);
          // pto: %929
          ;
          const int64_t v2209 = 1;
          // pto: %929
          ;
          const int64_t v2210 = 0;
          // pto: %929
          ;
          int64_t v2211 = v2204 / v51;
          // pto: %929
          ;
          bool v2212 = v2204 < v2210;
          // pto: %929
          ;
          bool v2213 = v51 < v2210;
          // pto: %929
          ;
          bool v2214 = v2212 == v2213;
          // pto: %929
          ;
          bool v2215 = v2204 % v51 != v2210 && v2212 != v2213;
          // pto: %929
          ;
          int64_t v2216 = v2215 ? v2211 - v2209 : v2211;
          // pto: %930
          ;
          int64_t v2217 = v2216 < v56 ? v56 : v2216;
          // pto: %931
          ;
          __gm__ int8_t* v2218 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %931
          ;
          const int64_t v2219 = 0;
          // pto: %931
          ;
          const int64_t v2220 = 128;
          // pto: %931
          ;
          pto::Shape<1, 1, 1, 32, 128> v2221 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %931
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v2222 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %931
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v2223 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v2218 + (v2219 + v2217 * v2220), v2221, v2222);
          TLOAD(v2207, v2223);
        } else {
          // pto: %932
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v2224;
          // pto: %932
          ;
          uint64_t v2225 = (uint64_t) v45;
          TASSIGN(v2224, v2225);
          // pto: %933
          ;
          const int64_t v2226 = 1;
          // pto: %933
          ;
          const int64_t v2227 = 0;
          // pto: %933
          ;
          int64_t v2228 = v2204 / v51;
          // pto: %933
          ;
          bool v2229 = v2204 < v2227;
          // pto: %933
          ;
          bool v2230 = v51 < v2227;
          // pto: %933
          ;
          bool v2231 = v2229 == v2230;
          // pto: %933
          ;
          bool v2232 = v2204 % v51 != v2227 && v2229 != v2230;
          // pto: %933
          ;
          int64_t v2233 = v2232 ? v2228 - v2226 : v2228;
          // pto: %934
          ;
          int64_t v2234 = v2233 < v56 ? v56 : v2233;
          // pto: %935
          ;
          __gm__ int8_t* v2235 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %935
          ;
          const int64_t v2236 = 0;
          // pto: %935
          ;
          const int64_t v2237 = 128;
          // pto: %935
          ;
          pto::Shape<1, 1, 1, 32, 128> v2238 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %935
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v2239 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %935
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v2240 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v2235 + (v2236 + v2234 * v2237), v2238, v2239);
          TLOAD(v2224, v2240);
        };
        // pto: %938
        ;
        int64_t v2241 = (int64_t) ((uint64_t) v382 + (uint64_t) v27);
        // pto: %939
        ;
        const int64_t v2242 = 1;
        // pto: %939
        ;
        const int64_t v2243 = 0;
        // pto: %939
        ;
        int64_t v2244 = v2241 / v66;
        // pto: %939
        ;
        bool v2245 = v2241 < v2243;
        // pto: %939
        ;
        bool v2246 = v66 < v2243;
        // pto: %939
        ;
        bool v2247 = v2245 == v2246;
        // pto: %939
        ;
        bool v2248 = v2241 % v66 != v2243 && v2245 != v2246;
        // pto: %939
        ;
        int64_t v2249 = v2248 ? v2244 - v2242 : v2244;
        // pto: %943
        ;
        int64_t v2250 = v2249 < v400 ? v2249 : v400;
        // pto: %946, %944
        ;
        int32_t v2251 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v2250)];
        // pto: %947
        ;
        int64_t v2252 = (int64_t) v2251;
        // pto: %948
        ;
        int64_t v2253 = v2252 < v56 ? v56 : v2252;
        // pto: %949
        ;
        int64_t v2254 = (int64_t) ((uint64_t) v2253 * (uint64_t) v16);
        // pto: %950
        ;
        int64_t v2255 = v2254 % v51;
        // pto: %951, %952, %953
        ;
        int64_t v2256 = v2255 < v56 ? (int64_t) ((uint64_t) v2255 + (uint64_t) v51) : v2255;
        // pto: %954
        ;
        if (v2256 == v56) {
          // pto: %956
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v2257;
          // pto: %956
          ;
          uint64_t v2258 = (uint64_t) v42;
          TASSIGN(v2257, v2258);
          // pto: %957
          ;
          const int64_t v2259 = 1;
          // pto: %957
          ;
          const int64_t v2260 = 0;
          // pto: %957
          ;
          int64_t v2261 = v2254 / v51;
          // pto: %957
          ;
          bool v2262 = v2254 < v2260;
          // pto: %957
          ;
          bool v2263 = v51 < v2260;
          // pto: %957
          ;
          bool v2264 = v2262 == v2263;
          // pto: %957
          ;
          bool v2265 = v2254 % v51 != v2260 && v2262 != v2263;
          // pto: %957
          ;
          int64_t v2266 = v2265 ? v2261 - v2259 : v2261;
          // pto: %958
          ;
          int64_t v2267 = v2266 < v56 ? v56 : v2266;
          // pto: %959
          ;
          __gm__ int8_t* v2268 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %959
          ;
          const int64_t v2269 = 0;
          // pto: %959
          ;
          const int64_t v2270 = 128;
          // pto: %959
          ;
          pto::Shape<1, 1, 1, 32, 128> v2271 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %959
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v2272 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %959
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v2273 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v2268 + (v2269 + v2267 * v2270), v2271, v2272);
          TLOAD(v2257, v2273);
        } else {
          // pto: %961
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v2274;
          // pto: %961
          ;
          uint64_t v2275 = (uint64_t) v42;
          TASSIGN(v2274, v2275);
          // pto: %962
          ;
          const int64_t v2276 = 1;
          // pto: %962
          ;
          const int64_t v2277 = 0;
          // pto: %962
          ;
          int64_t v2278 = v2254 / v51;
          // pto: %962
          ;
          bool v2279 = v2254 < v2277;
          // pto: %962
          ;
          bool v2280 = v51 < v2277;
          // pto: %962
          ;
          bool v2281 = v2279 == v2280;
          // pto: %962
          ;
          bool v2282 = v2254 % v51 != v2277 && v2279 != v2280;
          // pto: %962
          ;
          int64_t v2283 = v2282 ? v2278 - v2276 : v2278;
          // pto: %963
          ;
          int64_t v2284 = v2283 < v56 ? v56 : v2283;
          // pto: %964
          ;
          __gm__ int8_t* v2285 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %964
          ;
          const int64_t v2286 = 0;
          // pto: %964
          ;
          const int64_t v2287 = 128;
          // pto: %964
          ;
          pto::Shape<1, 1, 1, 32, 128> v2288 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %964
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v2289 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %964
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v2290 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v2285 + (v2286 + v2284 * v2287), v2288, v2289);
          TLOAD(v2274, v2290);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v414
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v2291 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v414
        ;
        uint64_t v2292 = (uint64_t) v45;
        TASSIGN(v2291, v2292);
        // pto: %buf_prefetched_key_inline3810__ssa_v66
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v2293 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline3810__ssa_v66
        ;
        uint64_t v2294 = (uint64_t) v47;
        TASSIGN(v2293, v2294);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v2295 = static_cast<uint16_t>(v56);
        uint16_t v2296 = static_cast<uint16_t>(v56);
        TEXTRACT(v2293, v2291, v2295, v2296);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        // pto: %buf_key_panel_inline3828__ssa_v39
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v2297 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline3828__ssa_v39
        ;
        uint64_t v2298 = (uint64_t) v43;
        TASSIGN(v2297, v2298);
        // pto: %buf_scores_l1_inline3829__ssa_v52
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v2299 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline3829__ssa_v52
        ;
        uint64_t v2300 = (uint64_t) v44;
        TASSIGN(v2299, v2300);
        // pto: %buf_previous_pair_inline3830__ssa_v13
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v2301 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline3830__ssa_v13
        ;
        uint64_t v2302 = (uint64_t) v46;
        TASSIGN(v2301, v2302);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v2303 = static_cast<uint16_t>(v56);
        uint16_t v2304 = static_cast<uint16_t>(v56);
        TEXTRACT(v2301, v2187, v2303, v2304);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline3831__ssa_v39
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v2305 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline3831__ssa_v39
        ;
        uint64_t v2306 = (uint64_t) v43;
        TASSIGN(v2305, v2306);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v2305, v371, v2297);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline3832__ssa_v13
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v2307 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline3832__ssa_v13
        ;
        uint64_t v2308 = (uint64_t) v48;
        TASSIGN(v2307, v2308);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v2307, v373, v2301);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v2309 = static_cast<uint64_t>(v77);
        uint16_t v2310 = static_cast<uint16_t>(v56);
        uint16_t v2311 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v2299, v2305, v2309, v2310, v2311);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v2307.SetValidShape(v65, v73);
        // pto: %968
        ;
        __gm__ float* v2312 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %968
        ;
        const int64_t v2313 = 768;
        // pto: %968
        ;
        const int64_t v2314 = 1024;
        // pto: %968
        ;
        pto::Shape<1, 1, 1, 6, 64> v2315 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %968
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v2316 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %968
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v2317 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v2312 + (v2313 + v739 * v2314), v2315, v2316);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v2317, v2307);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline3808__ssa_v14
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v2318 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline3808__ssa_v14
        ;
        uint64_t v2319 = (uint64_t) v44;
        TASSIGN(v2318, v2319);
        // pto: %buf_current_key_inline3809__ssa_v98
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v2320 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline3809__ssa_v98
        ;
        uint64_t v2321 = (uint64_t) v47;
        TASSIGN(v2320, v2321);
        // pto: %970
        ;
        int64_t v2322 = (int64_t) ((uint64_t) v382 + (uint64_t) v88);
        // pto: %971
        ;
        const int64_t v2323 = 1;
        // pto: %971
        ;
        const int64_t v2324 = 0;
        // pto: %971
        ;
        int64_t v2325 = v2322 / v66;
        // pto: %971
        ;
        bool v2326 = v2322 < v2324;
        // pto: %971
        ;
        bool v2327 = v66 < v2324;
        // pto: %971
        ;
        bool v2328 = v2326 == v2327;
        // pto: %971
        ;
        bool v2329 = v2322 % v66 != v2324 && v2326 != v2327;
        // pto: %971
        ;
        int64_t v2330 = v2329 ? v2325 - v2323 : v2325;
        // pto: %975
        ;
        int64_t v2331 = v2330 < v400 ? v2330 : v400;
        // pto: %978, %976
        ;
        int32_t v2332 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v2331)];
        // pto: %979
        ;
        int64_t v2333 = (int64_t) v2332;
        // pto: %980
        ;
        int64_t v2334 = v2333 < v56 ? v56 : v2333;
        // pto: %981
        ;
        int64_t v2335 = (int64_t) ((uint64_t) v2334 * (uint64_t) v16);
        // pto: %982
        ;
        int64_t v2336 = v2335 % v51;
        // pto: %983, %984, %985
        ;
        int64_t v2337 = v2336 < v56 ? (int64_t) ((uint64_t) v2336 + (uint64_t) v51) : v2336;
        // pto: %986
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        if (v2337 == v56) {
          // pto: %987
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v2338;
          // pto: %987
          ;
          uint64_t v2339 = (uint64_t) v41;
          TASSIGN(v2338, v2339);
          // pto: %988
          ;
          const int64_t v2340 = 1;
          // pto: %988
          ;
          const int64_t v2341 = 0;
          // pto: %988
          ;
          int64_t v2342 = v2335 / v51;
          // pto: %988
          ;
          bool v2343 = v2335 < v2341;
          // pto: %988
          ;
          bool v2344 = v51 < v2341;
          // pto: %988
          ;
          bool v2345 = v2343 == v2344;
          // pto: %988
          ;
          bool v2346 = v2335 % v51 != v2341 && v2343 != v2344;
          // pto: %988
          ;
          int64_t v2347 = v2346 ? v2342 - v2340 : v2342;
          // pto: %989
          ;
          int64_t v2348 = v2347 < v56 ? v56 : v2347;
          // pto: %990
          ;
          __gm__ int8_t* v2349 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %990
          ;
          const int64_t v2350 = 0;
          // pto: %990
          ;
          const int64_t v2351 = 128;
          // pto: %990
          ;
          pto::Shape<1, 1, 1, 32, 128> v2352 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %990
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v2353 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %990
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v2354 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v2349 + (v2350 + v2348 * v2351), v2352, v2353);
          TLOAD(v2338, v2354);
        } else {
          // pto: %991
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v2355;
          // pto: %991
          ;
          uint64_t v2356 = (uint64_t) v41;
          TASSIGN(v2355, v2356);
          // pto: %992
          ;
          const int64_t v2357 = 1;
          // pto: %992
          ;
          const int64_t v2358 = 0;
          // pto: %992
          ;
          int64_t v2359 = v2335 / v51;
          // pto: %992
          ;
          bool v2360 = v2335 < v2358;
          // pto: %992
          ;
          bool v2361 = v51 < v2358;
          // pto: %992
          ;
          bool v2362 = v2360 == v2361;
          // pto: %992
          ;
          bool v2363 = v2335 % v51 != v2358 && v2360 != v2361;
          // pto: %992
          ;
          int64_t v2364 = v2363 ? v2359 - v2357 : v2359;
          // pto: %993
          ;
          int64_t v2365 = v2364 < v56 ? v56 : v2364;
          // pto: %994
          ;
          __gm__ int8_t* v2366 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %994
          ;
          const int64_t v2367 = 0;
          // pto: %994
          ;
          const int64_t v2368 = 128;
          // pto: %994
          ;
          pto::Shape<1, 1, 1, 32, 128> v2369 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %994
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v2370 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %994
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v2371 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v2366 + (v2367 + v2365 * v2368), v2369, v2370);
          TLOAD(v2355, v2371);
        };
        int64_t v2372 = (int64_t) ((uint64_t) v382 + (uint64_t) v26);
        // pto: %998
        ;
        const int64_t v2373 = 1;
        // pto: %998
        ;
        const int64_t v2374 = 0;
        // pto: %998
        ;
        int64_t v2375 = v2372 / v66;
        // pto: %998
        ;
        bool v2376 = v2372 < v2374;
        // pto: %998
        ;
        bool v2377 = v66 < v2374;
        // pto: %998
        ;
        bool v2378 = v2376 == v2377;
        // pto: %998
        ;
        bool v2379 = v2372 % v66 != v2374 && v2376 != v2377;
        // pto: %998
        ;
        int64_t v2380 = v2379 ? v2375 - v2373 : v2375;
        // pto: %1002
        ;
        int64_t v2381 = v2380 < v400 ? v2380 : v400;
        // pto: %1005, %1003
        ;
        int32_t v2382 = (v10)[(int64_t) ((uint64_t) v402 + (uint64_t) v2381)];
        // pto: %1006
        ;
        int64_t v2383 = (int64_t) v2382;
        // pto: %1007
        ;
        int64_t v2384 = v2383 < v56 ? v56 : v2383;
        // pto: %1008
        ;
        int64_t v2385 = (int64_t) ((uint64_t) v2384 * (uint64_t) v16);
        // pto: %1009
        ;
        int64_t v2386 = v2385 % v51;
        // pto: %1010, %1011, %1012
        ;
        int64_t v2387 = v2386 < v56 ? (int64_t) ((uint64_t) v2386 + (uint64_t) v51) : v2386;
        // pto: %1013
        ;
        if (v2387 == v56) {
          // pto: %1015
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v2388;
          // pto: %1015
          ;
          uint64_t v2389 = (uint64_t) v39;
          TASSIGN(v2388, v2389);
          // pto: %1016
          ;
          const int64_t v2390 = 1;
          // pto: %1016
          ;
          const int64_t v2391 = 0;
          // pto: %1016
          ;
          int64_t v2392 = v2385 / v51;
          // pto: %1016
          ;
          bool v2393 = v2385 < v2391;
          // pto: %1016
          ;
          bool v2394 = v51 < v2391;
          // pto: %1016
          ;
          bool v2395 = v2393 == v2394;
          // pto: %1016
          ;
          bool v2396 = v2385 % v51 != v2391 && v2393 != v2394;
          // pto: %1016
          ;
          int64_t v2397 = v2396 ? v2392 - v2390 : v2392;
          // pto: %1017
          ;
          int64_t v2398 = v2397 < v56 ? v56 : v2397;
          // pto: %1018
          ;
          __gm__ int8_t* v2399 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %1018
          ;
          const int64_t v2400 = 0;
          // pto: %1018
          ;
          const int64_t v2401 = 128;
          // pto: %1018
          ;
          pto::Shape<1, 1, 1, 32, 128> v2402 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %1018
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v2403 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %1018
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v2404 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v2399 + (v2400 + v2398 * v2401), v2402, v2403);
          TLOAD(v2388, v2404);
        } else {
          // pto: %1020
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v2405;
          // pto: %1020
          ;
          uint64_t v2406 = (uint64_t) v39;
          TASSIGN(v2405, v2406);
          // pto: %1021
          ;
          const int64_t v2407 = 1;
          // pto: %1021
          ;
          const int64_t v2408 = 0;
          // pto: %1021
          ;
          int64_t v2409 = v2385 / v51;
          // pto: %1021
          ;
          bool v2410 = v2385 < v2408;
          // pto: %1021
          ;
          bool v2411 = v51 < v2408;
          // pto: %1021
          ;
          bool v2412 = v2410 == v2411;
          // pto: %1021
          ;
          bool v2413 = v2385 % v51 != v2408 && v2410 != v2411;
          // pto: %1021
          ;
          int64_t v2414 = v2413 ? v2409 - v2407 : v2409;
          // pto: %1022
          ;
          int64_t v2415 = v2414 < v56 ? v56 : v2414;
          // pto: %1023
          ;
          __gm__ int8_t* v2416 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %1023
          ;
          const int64_t v2417 = 0;
          // pto: %1023
          ;
          const int64_t v2418 = 128;
          // pto: %1023
          ;
          pto::Shape<1, 1, 1, 32, 128> v2419 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %1023
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v2420 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %1023
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v2421 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v2416 + (v2417 + v2415 * v2418), v2419, v2420);
          TLOAD(v2405, v2421);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v418
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v2422 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v418
        ;
        uint64_t v2423 = (uint64_t) v45;
        TASSIGN(v2422, v2423);
        // pto: %buf_prefetched_key_inline3810__ssa_v71
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v2424 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline3810__ssa_v71
        ;
        uint64_t v2425 = (uint64_t) v43;
        TASSIGN(v2424, v2425);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v2426 = static_cast<uint16_t>(v56);
        uint16_t v2427 = static_cast<uint16_t>(v73);
        TEXTRACT(v2424, v2422, v2426, v2427);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        // pto: %buf_key_panel_inline3828__ssa_v42
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v2428 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline3828__ssa_v42
        ;
        uint64_t v2429 = (uint64_t) v47;
        TASSIGN(v2428, v2429);
        // pto: %buf_scores_l1_inline3829__ssa_v56
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v2430 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline3829__ssa_v56
        ;
        uint64_t v2431 = (uint64_t) v43;
        TASSIGN(v2430, v2431);
        // pto: %buf_previous_pair_inline3830__ssa_v14
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v2432 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline3830__ssa_v14
        ;
        uint64_t v2433 = (uint64_t) v46;
        TASSIGN(v2432, v2433);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v2434 = static_cast<uint16_t>(v56);
        uint16_t v2435 = static_cast<uint16_t>(v56);
        TEXTRACT(v2432, v2318, v2434, v2435);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline3831__ssa_v42
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v2436 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline3831__ssa_v42
        ;
        uint64_t v2437 = (uint64_t) v43;
        TASSIGN(v2436, v2437);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v2436, v371, v2428);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline3832__ssa_v14
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v2438 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline3832__ssa_v14
        ;
        uint64_t v2439 = (uint64_t) v48;
        TASSIGN(v2438, v2439);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v2438, v373, v2432);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v2440 = static_cast<uint64_t>(v77);
        uint16_t v2441 = static_cast<uint16_t>(v56);
        uint16_t v2442 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v2430, v2436, v2440, v2441, v2442);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v2438.SetValidShape(v65, v73);
        // pto: %1027
        ;
        __gm__ float* v2443 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %1027
        ;
        const int64_t v2444 = 832;
        // pto: %1027
        ;
        const int64_t v2445 = 1024;
        // pto: %1027
        ;
        pto::Shape<1, 1, 1, 6, 64> v2446 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %1027
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v2447 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %1027
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v2448 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v2443 + (v2444 + v739 * v2445), v2446, v2447);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v2448, v2438);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline3808__ssa_v15
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v2449 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline3808__ssa_v15
        ;
        uint64_t v2450 = (uint64_t) v43;
        TASSIGN(v2449, v2450);
        // pto: %buf_current_key_inline3809__ssa_v105
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v2451 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline3809__ssa_v105
        ;
        uint64_t v2452 = (uint64_t) v43;
        TASSIGN(v2451, v2452);
        // pto: %buf_key_panel_inline3828__ssa_v45
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v2453 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline3828__ssa_v45
        ;
        uint64_t v2454 = (uint64_t) v43;
        TASSIGN(v2453, v2454);
        // pto: %buf_scores_l1_inline3829__ssa_v60
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v2455 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline3829__ssa_v60
        ;
        uint64_t v2456 = (uint64_t) v44;
        TASSIGN(v2455, v2456);
        // pto: %buf_previous_pair_inline3830__ssa_v15
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v2457 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline3830__ssa_v15
        ;
        uint64_t v2458 = (uint64_t) v46;
        TASSIGN(v2457, v2458);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v2459 = static_cast<uint16_t>(v56);
        uint16_t v2460 = static_cast<uint16_t>(v56);
        TEXTRACT(v2457, v2449, v2459, v2460);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline3831__ssa_v45
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v2461 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline3831__ssa_v45
        ;
        uint64_t v2462 = (uint64_t) v43;
        TASSIGN(v2461, v2462);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v2461, v371, v2453);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline3832__ssa_v15
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v2463 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline3832__ssa_v15
        ;
        uint64_t v2464 = (uint64_t) v48;
        TASSIGN(v2463, v2464);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v2463, v373, v2457);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v2465 = static_cast<uint64_t>(v77);
        uint16_t v2466 = static_cast<uint16_t>(v56);
        uint16_t v2467 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v2455, v2461, v2465, v2466, v2467);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v2463.SetValidShape(v65, v73);
        // pto: %1031
        ;
        __gm__ float* v2468 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %1031
        ;
        const int64_t v2469 = 896;
        // pto: %1031
        ;
        const int64_t v2470 = 1024;
        // pto: %1031
        ;
        pto::Shape<1, 1, 1, 6, 64> v2471 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %1031
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v2472 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %1031
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v2473 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v2468 + (v2469 + v739 * v2470), v2471, v2472);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v2473, v2463);
        // pto: %buf_previous_l1_inline3808__ssa_v16
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v2474 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline3808__ssa_v16
        ;
        uint64_t v2475 = (uint64_t) v44;
        TASSIGN(v2474, v2475);
        // pto: %buf_last_pair_inline3833__ssa_v0
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v2476 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_last_pair_inline3833__ssa_v0
        ;
        uint64_t v2477 = (uint64_t) v46;
        TASSIGN(v2476, v2477);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v2478 = static_cast<uint16_t>(v56);
        uint16_t v2479 = static_cast<uint16_t>(v56);
        TEXTRACT(v2476, v2474, v2478, v2479);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_last_scores_inline3834__ssa_v0
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v2480 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_last_scores_inline3834__ssa_v0
        ;
        uint64_t v2481 = (uint64_t) v43;
        TASSIGN(v2480, v2481);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        TMATMUL(v2480, v373, v2476);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        v2480.SetValidShape(v65, v73);
        // pto: %1033
        ;
        __gm__ float* v2482 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %1033
        ;
        const int64_t v2483 = 960;
        // pto: %1033
        ;
        const int64_t v2484 = 1024;
        // pto: %1033
        ;
        pto::Shape<1, 1, 1, 6, 64> v2485 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %1033
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v2486 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %1033
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v2487 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v2482 + (v2483 + v739 * v2484), v2485, v2486);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        pipe_barrier(PIPE_FIX);
        TSTORE(v2487, v2480);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        uint16_t v2488 = getFFTSMsg(FFTS_MODE_VAL, v56);
        ffts_cross_core_sync(PIPE_FIX, v2488);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      // pto: %1034
      ;
      for (int64_t v2489 = v56; v2489 < (v349 < v75 ? v349 : v75); v2489 += v49) {
        int32_t v2490 = (int32_t) v49;
        wait_flag_dev(v2490);
      };
    };
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void indexer_score_topk_native_pair_aiv(__gm__ int32_t* v1, __gm__ int32_t* v2, __gm__ int64_t* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, __gm__ int64_t* v7, __gm__ int8_t* v8, __gm__ half* v9, __gm__ int32_t* v10, __gm__ int8_t* v11, __gm__ int8_t* v12, __gm__ float* v13, __gm__ int8_t* v14, __gm__ float* v15, int64_t v16, int64_t v17, int64_t v18, int64_t v19, int64_t v20, int64_t v21, int64_t v22, int64_t v23, int32_t v24, int32_t v25, int32_t v26) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v27 = 8192;
  const int64_t v28 = 4096;
  pto::MrgSortExecutedNumList v29 = pto::MrgSortExecutedNumList{0, 0, 0, 0};
  // pto: %c0_i64
  const int64_t v30 = 0;
  // pto: %c12288_i64
  const int64_t v31 = 12288;
  // pto: %c57344_i64
  const int64_t v32 = 57344;
  // pto: %c73728_i64
  const int64_t v33 = 73728;
  // pto: %c40960_i64
  const int64_t v34 = 40960;
  // pto: %c49152_i64
  const int64_t v35 = 49152;
  // pto: %c36864_i64
  const int64_t v36 = 36864;
  const int64_t v37 = 77824;
  // pto: %c1_index
  const int64_t v38 = 1;
  // pto: %c27648_index
  const int64_t v39 = 27648;
  // pto: %c288_index
  const int64_t v40 = 288;
  // pto: %c1024_index
  const int64_t v41 = 1024;
  // pto: %c0_index
  const int64_t v42 = 0;
  // pto: %c4_index
  const int64_t v43 = 4;
  // pto: %c262144_index
  const int64_t v44 = 262144;
  // pto: %c1023_index
  const int64_t v45 = 1023;
  // pto: %c8191_index
  const int64_t v46 = 8191;
  // pto: %c8192_index
  const int64_t v47 = 8192;
  // pto: %c3_index
  const int64_t v48 = 3;
  // pto: %c48_index
  const int64_t v49 = 48;
  // pto: %c24_index
  const int64_t v50 = 24;
  // pto: %c6_index
  const int64_t v51 = 6;
  // pto: %c32_index
  const int64_t v52 = 32;
  // pto: %c8_index
  const int64_t v53 = 8;
  // pto: %c1_i64
  const int64_t v54 = 1;
  // pto: %c4_i64
  const int64_t v55 = 4;
  // pto: %cst_30
  const float v56 = -3.40282347E+38f;
  // pto: %c12_index
  const int64_t v57 = 12;
  // pto: %c2_index
  const int64_t v58 = 2;
  // pto: %c2048_index
  const int64_t v59 = 2048;
  // pto: %c64_index
  const int64_t v60 = 64;
  // pto: %c4096_index
  const int64_t v61 = 4096;
  // pto: %c512_index
  const int64_t v62 = 512;
  // pto: %c192_index
  const int64_t v63 = 192;
  // pto: %c0_i32
  const int32_t v64 = 0;
  // pto: %c64_i32
  const int32_t v65 = 64;
  // pto: %c256_i32
  const int32_t v66 = 256;
  // pto: %c1024_i32
  const int32_t v67 = 1024;
  // pto: %buf_score_transfer_inline3774__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %buf_score_transfer_inline3774__ssa_v0_view
  const int64_t v69 = 1;
  // pto: %buf_score_transfer_inline3774__ssa_v0_view
  const int64_t v70 = 1;
  // pto: %buf_score_transfer_inline3774__ssa_v0_view
  int64_t v71 = v40 * v41;
  // pto: %buf_score_transfer_inline3774__ssa_v0_view
  int64_t v72 = v70 * v71;
  // pto: %buf_score_transfer_inline3774__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v73 = pto::Shape<1, 1, 1, -1, -1>(v68, v69, v70, v40, v41);
  // pto: %buf_score_transfer_inline3774__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v74 = pto::Stride<-1, -1, -1, -1, -1>(v69 * v72, v72, v71, v41, v38);
  // pto: %buf_score_transfer_inline3774__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v75 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v73, v74);
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v76 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v77 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v78 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v79 = (int64_t) v22;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v80 = (int64_t) v23;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v81 = v79 * v80;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v82 = v78 * v81;
  // pto: %idx_native_kv_cache__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v83 = pto::Shape<1, 1, 1, -1, -1>(v76, v77, v78, v79, (int64_t) v23);
  // pto: %idx_native_kv_cache__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v84 = pto::Stride<-1, -1, -1, -1, -1>(v77 * v82, v82, v81, v80, v38);
  // pto: %idx_native_kv_cache__rv_v2_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v85 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v83, v84);
  // pto: %pair_arena_inline3677__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %pair_arena_inline3677__ssa_v0_view
  const int64_t v87 = 1;
  // pto: %pair_arena_inline3677__ssa_v0_view
  const int64_t v88 = 1;
  // pto: %pair_arena_inline3677__ssa_v0_view
  int64_t v89 = v39 * v41;
  // pto: %pair_arena_inline3677__ssa_v0_view
  int64_t v90 = v88 * v89;
  // pto: %pair_arena_inline3677__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v91 = pto::Shape<1, 1, 1, -1, -1>(v86, v87, v88, v39, v41);
  // pto: %pair_arena_inline3677__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v92 = pto::Stride<-1, -1, -1, -1, -1>(v87 * v90, v90, v89, v41, v38);
  // pto: %pair_arena_inline3677__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v93 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v91, v92);
  // pto: %single_roots_inline3850__phi_v15
  Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
  // pto: %single_roots_inline3850__phi_v15
  uint64_t v95 = (uint64_t) v30;
  TASSIGN(v94, v95);
  // pto: %single_roots_inline3850__phi_v6
  Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v96 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
  // pto: %single_roots_inline3850__phi_v6
  uint64_t v97 = (uint64_t) v30;
  TASSIGN(v96, v97);
  // pto: %single_new_root_inline3883__phi_v4
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v98 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
  // pto: %single_new_root_inline3883__phi_v4
  uint64_t v99 = (uint64_t) v36;
  TASSIGN(v98, v99);
  // pto: %single_new_root_inline3883__phi_v3
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v100 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
  // pto: %single_new_root_inline3883__phi_v3
  uint64_t v101 = (uint64_t) v36;
  TASSIGN(v100, v101);
  // pto: %single_roots_inline3850__phi_v5
  Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
  // pto: %single_roots_inline3850__phi_v5
  uint64_t v103 = (uint64_t) v30;
  TASSIGN(v102, v103);
  // pto: %single_roots_inline3850__phi_v10
  Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v104 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
  // pto: %single_roots_inline3850__phi_v10
  uint64_t v105 = (uint64_t) v30;
  TASSIGN(v104, v105);
  // pto: %single_new_root_inline3883__phi_v9
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
  // pto: %single_new_root_inline3883__phi_v9
  uint64_t v107 = (uint64_t) v36;
  TASSIGN(v106, v107);
  // pto: %single_new_root_inline3883__phi_v8
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
  // pto: %single_new_root_inline3883__phi_v8
  uint64_t v109 = (uint64_t) v36;
  TASSIGN(v108, v109);
  // pto: %single_roots_inline3850__phi_v9
  Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
  // pto: %single_roots_inline3850__phi_v9
  uint64_t v111 = (uint64_t) v30;
  TASSIGN(v110, v111);
  // pto: %single_roots_inline3850__phi_v14
  Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v112 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
  // pto: %single_roots_inline3850__phi_v14
  uint64_t v113 = (uint64_t) v30;
  TASSIGN(v112, v113);
  // pto: %single_new_root_inline3883__phi_v14
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v114 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
  // pto: %single_new_root_inline3883__phi_v14
  uint64_t v115 = (uint64_t) v36;
  TASSIGN(v114, v115);
  // pto: %single_new_root_inline3883__phi_v13
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
  // pto: %single_new_root_inline3883__phi_v13
  uint64_t v117 = (uint64_t) v36;
  TASSIGN(v116, v117);
  // pto: %single_roots_inline3850__phi_v13
  Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v118 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
  // pto: %single_roots_inline3850__phi_v13
  uint64_t v119 = (uint64_t) v30;
  TASSIGN(v118, v119);
  // pto: %buf_worker_inline3777__ssa_v0
  int64_t v120 = (int64_t) v24;
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  // pto: %buf_max_cache_len_inline3778__rv_v2
  int64_t v121;
  v121 = v42;
  for (int64_t v122 = v42; v122 < v17; v122 += v38) {
    // pto: %t__tile
    ;
    int32_t v123 = (v1)[v122];
    // pto: %0
    ;
    int64_t v124 = (int64_t) v123;
    // pto: %1
    ;
    const int64_t v125 = 1;
    // pto: %1
    ;
    const int64_t v126 = 0;
    // pto: %1
    ;
    int64_t v127 = v124 / v43;
    // pto: %1
    ;
    bool v128 = v124 < v126;
    // pto: %1
    ;
    bool v129 = v43 < v126;
    // pto: %1
    ;
    bool v130 = v128 == v129;
    // pto: %1
    ;
    bool v131 = v124 % v43 != v126 && v128 != v129;
    // pto: %1
    ;
    int64_t v132 = v131 ? v127 - v125 : v127;
    // pto: %2
    ;
    bool v133 = v121 < v132;
    // pto: %2
    ;
    int64_t v134 = v133 ? v132 : v121;
    v121 = v134;
  }
  // pto: %3
  bool v135 = v121 < v44;
  // pto: %3
  int64_t v136 = v135 ? v121 : v44;
  // pto: %4
  int32_t v137 = (v2)[v42];
  // pto: %5
  int64_t v138 = (int64_t) v137;
  // pto: %6
  int64_t v139 = (int64_t) ((uint64_t) v136 + (uint64_t) v45);
  // pto: %7
  const int64_t v140 = 1;
  // pto: %7
  const int64_t v141 = 0;
  // pto: %7
  int64_t v142 = v139 / v41;
  // pto: %7
  bool v143 = v139 < v141;
  // pto: %7
  bool v144 = v41 < v141;
  // pto: %7
  bool v145 = v143 == v144;
  // pto: %7
  bool v146 = v139 % v41 != v141 && v143 != v144;
  // pto: %7
  int64_t v147 = v146 ? v142 - v140 : v142;
  // pto: %8
  int64_t v148 = (int64_t) ((uint64_t) v136 + (uint64_t) v46);
  // pto: %9
  const int64_t v149 = 1;
  // pto: %9
  const int64_t v150 = 0;
  // pto: %9
  int64_t v151 = v148 / v47;
  // pto: %9
  bool v152 = v148 < v150;
  // pto: %9
  bool v153 = v47 < v150;
  // pto: %9
  bool v154 = v152 == v153;
  // pto: %9
  bool v155 = v148 % v47 != v150 && v152 != v153;
  // pto: %9
  int64_t v156 = v155 ? v151 - v149 : v151;
  // pto: %10
  int64_t v157 = v156 < v38 ? v38 : v156;
  // pto: %11
  int64_t v158 = (int64_t) ((uint64_t) v138 * (uint64_t) v48);
  // pto: %12
  // pto: %leaf_multiple_inline3962__phi_v6
  int64_t v159;
  if (v158 == v49) {
    v159 = v48;
  } else {
    // pto: %14
    ;
    // pto: %leaf_multiple_inline3962__phi_v5
    ;
    int64_t v160;
    if (v158 == v50) {
      v160 = v48;
    } else {
      // pto: %15, %16, %leaf_multiple_inline3962__phi_v4
      ;
      v160 = (int64_t) ((uint64_t) v138 * (uint64_t) v51) == v50 ? v51 : v38;
    };
    v159 = v160;
  }
  // pto: %17
  bool v161 = v159 > v38;
  // pto: %extra_leaves_inline3961__phi_v3
  int64_t v162;
  // pto: %leaf_count_inline3959__phi_v3
  int64_t v163;
  // pto: %leaf_tiles_inline3960__phi_v3
  int64_t v164;
  if (v161) {
    // pto: %18
    ;
    uint64_t v165 = (uint64_t) v159;
    // pto: %18, %19
    ;
    int64_t v166 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v157 + v165) - (uint64_t) v38);
    // pto: %20
    ;
    const int64_t v167 = 1;
    // pto: %20
    ;
    const int64_t v168 = 0;
    // pto: %20
    ;
    int64_t v169 = v166 / v159;
    // pto: %20
    ;
    int64_t v170 = v166 % v159;
    // pto: %20
    ;
    bool v171 = v166 < v168;
    // pto: %20
    ;
    bool v172 = v159 < v168;
    // pto: %20
    ;
    bool v173 = v171 == v172;
    // pto: %20
    ;
    bool v174 = v170 != v168 && v171 != v172;
    // pto: %20
    ;
    int64_t v175 = v174 ? v169 - v167 : v169;
    // pto: %21
    ;
    uint64_t v176 = (uint64_t) v159;
    // pto: %21
    ;
    int64_t v177 = (int64_t) ((uint64_t) v175 * v176);
    // pto: %22
    ;
    bool v178 = v177 <= v52;
    // pto: %extra_leaves_inline3961__phi_v2
    ;
    // pto: %leaf_count_inline3959__phi_v2
    ;
    int64_t v179;
    // pto: %leaf_tiles_inline3960__phi_v2
    ;
    int64_t v180;
    if (v178) {
      // pto: %23
      ;
      const int64_t v181 = 1;
      // pto: %23
      ;
      const int64_t v182 = 0;
      // pto: %23
      ;
      int64_t v183 = v147 / v177;
      // pto: %23
      ;
      bool v184 = v147 < v182;
      // pto: %23
      ;
      bool v185 = v177 < v182;
      // pto: %23
      ;
      bool v186 = v184 == v185;
      // pto: %23
      ;
      bool v187 = v147 % v177 != v182 && v184 != v185;
      // pto: %23
      ;
      int64_t v188 = v187 ? v183 - v181 : v183;
      // pto: %24
      ;
      // pto: %25
      ;
      int64_t v189 = v147 % v177;
      // pto: %26, %27, %28
      ;
      bool v190 = v189 < v42 ^ v177 < v42;
      // pto: %29, %30, %31, %32
      ;
      v179 = v189 != v42 & v190 ? (int64_t) ((uint64_t) v189 + (uint64_t) v177) : v189;
      v180 = v188 < v38 ? v38 : v188;
    } else {
      v179 = v42;
      v180 = v53;
    };
    v162 = v179;
    v163 = v178 ? v177 : v157;
    v164 = v180;
  } else {
    v162 = v42;
    v163 = v157;
    v164 = v53;
  }
  uint64_t v191 = reinterpret_cast<uint64_t>(v3);
  set_ffts_base_addr(v191);
  // pto: %buf_score_lane_inline3836__ssa_v0
  int64_t v192 = (int64_t) v26;
  // pto: %33
  uint64_t v193 = (uint64_t) v163;
  // pto: %33
  for (int64_t v194 = v120; v194 < ((int64_t) ((uint64_t) v138 * v193)); v194 += v50) {
    // pto: %34
    ;
    // pto: %single_group_inline3838__phi_v2
    ;
    int64_t v195;
    // pto: %single_leaf_inline3839__phi_v2
    ;
    int64_t v196;
    if (v138 < v50) {
      // pto: %35
      ;
      int64_t v197 = v194 % v138;
      // pto: %36, %37, %38
      ;
      bool v198 = v197 < v42 ^ v138 < v42;
      // pto: %39, %40, %41, %42
      ;
      // pto: %43
      ;
      const int64_t v199 = 1;
      // pto: %43
      ;
      const int64_t v200 = 0;
      // pto: %43
      ;
      int64_t v201 = v194 / v138;
      // pto: %43
      ;
      bool v202 = v194 < v200;
      // pto: %43
      ;
      bool v203 = v138 < v200;
      // pto: %43
      ;
      bool v204 = v202 == v203;
      // pto: %43
      ;
      bool v205 = v194 % v138 != v200 && v202 != v203;
      // pto: %43
      ;
      v195 = v197 != v42 & v198 ? (int64_t) ((uint64_t) v197 + (uint64_t) v138) : v197;
      v196 = v205 ? v201 - v199 : v201;
    } else {
      // pto: %44
      ;
      const int64_t v206 = 1;
      // pto: %44
      ;
      const int64_t v207 = 0;
      // pto: %44
      ;
      int64_t v208 = v194 / v163;
      // pto: %44
      ;
      int64_t v209 = v194 % v163;
      // pto: %44
      ;
      bool v210 = v194 < v207;
      // pto: %44
      ;
      bool v211 = v163 < v207;
      // pto: %44
      ;
      bool v212 = v210 == v211;
      // pto: %44
      ;
      bool v213 = v209 != v207 && v210 != v211;
      // pto: %44
      ;
      // pto: %45
      ;
      int64_t v214 = v194 % v163;
      // pto: %47
      ;
      bool v215 = v163 < v42;
      // pto: %46, %48
      ;
      bool v216 = v214 < v42 ^ v215;
      // pto: %51
      ;
      uint64_t v217 = (uint64_t) v163;
      // pto: %49, %50, %51, %52
      ;
      v195 = v213 ? v208 - v206 : v208;
      v196 = v214 != v42 & v216 ? (int64_t) ((uint64_t) v214 + v217) : v214;
    };
    // pto: %53
    ;
    int32_t v218 = (v4)[v195];
    // pto: %54
    ;
    int64_t v219 = (int64_t) v218;
    // pto: %55
    ;
    int32_t v220 = (v5)[v195];
    // pto: %56
    ;
    int64_t v221 = (int64_t) v220;
    // pto: %57
    ;
    int32_t v222 = (v6)[v219];
    // pto: %58
    ;
    int64_t v223 = (int64_t) v222;
    // pto: %59
    ;
    int32_t v224 = (v1)[v223];
    // pto: %60
    ;
    int64_t v225 = (int64_t) v224;
    // pto: %61
    ;
    const int64_t v226 = 1;
    // pto: %61
    ;
    const int64_t v227 = 0;
    // pto: %61
    ;
    int64_t v228 = v225 / v43;
    // pto: %61
    ;
    bool v229 = v225 < v227;
    // pto: %61
    ;
    bool v230 = v43 < v227;
    // pto: %61
    ;
    bool v231 = v229 == v230;
    // pto: %61
    ;
    bool v232 = v225 % v43 != v227 && v229 != v230;
    // pto: %61
    ;
    int64_t v233 = v232 ? v228 - v226 : v228;
    // pto: %62, %63, %single_last_position_inline3844__tile
    ;
    int64_t v234 = (v7)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v219 + (uint64_t) v221) - (uint64_t) v38)];
    // pto: %64
    ;
    int64_t v235 = (int64_t) ((uint64_t) v234 + (uint64_t) v54);
    // pto: %65
    ;
    const int64_t v236 = 1;
    // pto: %65
    ;
    const int64_t v237 = 0;
    // pto: %65
    ;
    int64_t v238 = v235 / v55;
    // pto: %65
    ;
    bool v239 = v235 < v237;
    // pto: %65
    ;
    bool v240 = v55 < v237;
    // pto: %65
    ;
    bool v241 = v239 == v240;
    // pto: %65
    ;
    bool v242 = v235 % v55 != v237 && v239 != v240;
    // pto: %65
    ;
    int64_t v243 = v242 ? v238 - v236 : v238;
    // pto: %67
    ;
    int64_t v244 = v233 < v243 ? v233 : v243;
    // pto: %68
    ;
    int64_t v245 = v244 < v44 ? v244 : v44;
    // pto: %69
    ;
    int64_t v246 = v245 < v42 ? v42 : v245;
    // pto: %70
    ;
    uint64_t v247 = (uint64_t) v196;
    // pto: %70
    ;
    uint64_t v248 = (uint64_t) v164;
    // pto: %71
    ;
    bool v249 = v196 < v162;
    // pto: %71
    ;
    int64_t v250 = v249 ? v196 : v162;
    // pto: %70, %72, %73
    ;
    int64_t v251 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v247 * v248) + (uint64_t) v250) * (uint64_t) v41);
    // pto: %74
    ;
    bool v252 = v196 < v162;
    // pto: %76
    ;
    uint64_t v253 = (uint64_t) v164;
    // pto: %75, %76, %77
    ;
    int64_t v254 = (int64_t) ((uint64_t) ((int64_t) v253 + (uint64_t) ((int64_t) v252)) * (uint64_t) v41);
    // pto: %78
    ;
    if (v251 < v246) {
      // pto: %79
      ;
      int64_t v255 = (int64_t) ((uint64_t) v246 - (uint64_t) v251);
      // pto: %80
      ;
      int64_t v256 = v254 < v255 ? v254 : v255;
      // pto: %81
      ;
      int64_t v257 = (int64_t) ((uint64_t) v256 + (uint64_t) v45);
      // pto: %82
      ;
      const int64_t v258 = 1;
      // pto: %82
      ;
      const int64_t v259 = 0;
      // pto: %82
      ;
      int64_t v260 = v257 / v41;
      // pto: %82
      ;
      bool v261 = v257 < v259;
      // pto: %82
      ;
      bool v262 = v41 < v259;
      // pto: %82
      ;
      bool v263 = v261 == v262;
      // pto: %82
      ;
      bool v264 = v257 % v41 != v259 && v261 != v262;
      // pto: %82
      ;
      int64_t v265 = v264 ? v260 - v258 : v260;
      // pto: %single_roots_inline3850__ssa_v0
      ;
      Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v266 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
      // pto: %single_roots_inline3850__ssa_v0
      ;
      uint64_t v267 = (uint64_t) v30;
      TASSIGN(v266, v267);
      pipe_barrier(PIPE_V);
      TEXPANDS(v266, v56);
      // pto: %single_segments_inline3851__ssa_v0
      ;
      Tile<TileType::Vec, float, 6, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v268 = Tile<TileType::Vec, float, 6, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v51, v41);
      // pto: %single_segments_inline3851__ssa_v0
      ;
      uint64_t v269 = (uint64_t) v31;
      TASSIGN(v268, v269);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      TEXPANDS(v268, v56);
      for (int64_t v270 = v42; v270 < v265; v270 += v38) {
        // pto: %84, %83
        ;
        int64_t v271 = (int64_t) ((uint64_t) v251 + (uint64_t) ((int64_t) (uint64_t) v270 * (uint64_t) v41));
        // pto: %86
        ;
        int64_t v272 = v270 % v58;
        // pto: %87, %88, %89
        ;
        int64_t v273 = v272 < v42 ? (int64_t) ((uint64_t) v272 + (uint64_t) v58) : v272;
        // pto: %92
        ;
        int64_t v274 = (int64_t) ((uint64_t) v192 * (uint64_t) v48);
        // pto: %85, %91, %90, %93
        ;
        int64_t v275 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v120 * (uint64_t) v57) + (uint64_t) ((int64_t) (uint64_t) v273 * (uint64_t) v51)) + (uint64_t) v274);
        // pto: %single_scale_bytes_inline3855__ssa_v0
        ;
        Tile<TileType::Vec, int8_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v276 = Tile<TileType::Vec, int8_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
        // pto: %single_scale_bytes_inline3855__ssa_v0
        ;
        uint64_t v277 = (uint64_t) v32;
        TASSIGN(v276, v277);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
        for (int64_t v278 = v42; v278 < v52; v278 += v38) {
          // pto: %94
          ;
          const int64_t v279 = 1;
          // pto: %94
          ;
          const int64_t v280 = 0;
          // pto: %94
          ;
          int64_t v281 = v271 / v52;
          // pto: %94
          ;
          bool v282 = v271 < v280;
          // pto: %94
          ;
          bool v283 = v52 < v280;
          // pto: %94
          ;
          bool v284 = v282 == v283;
          // pto: %94
          ;
          bool v285 = v271 % v52 != v280 && v282 != v283;
          // pto: %94
          ;
          int64_t v286 = v285 ? v281 - v279 : v281;
          // pto: %95
          ;
          int64_t v287 = (int64_t) ((uint64_t) v286 + (uint64_t) v278);
          // pto: %96
          ;
          int64_t v288 = (int64_t) ((uint64_t) v233 - (uint64_t) v38);
          // pto: %97
          ;
          const int64_t v289 = 1;
          // pto: %97
          ;
          const int64_t v290 = 0;
          // pto: %97
          ;
          int64_t v291 = v288 / v52;
          // pto: %97
          ;
          bool v292 = v288 < v290;
          // pto: %97
          ;
          bool v293 = v52 < v290;
          // pto: %97
          ;
          bool v294 = v292 == v293;
          // pto: %97
          ;
          bool v295 = v288 % v52 != v290 && v292 != v293;
          // pto: %97
          ;
          int64_t v296 = v295 ? v291 - v289 : v291;
          // pto: %98
          ;
          int64_t v297 = v296 < v42 ? v42 : v296;
          // pto: %99
          ;
          int64_t v298 = v287 < v297 ? v287 : v297;
          // pto: %flat_offset_mul, %flat_offset, %100
          ;
          int32_t v299 = (v10)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v223 * (uint64_t) v19) + (uint64_t) v298)];
          // pto: %101
          ;
          int64_t v300 = (int64_t) v299;
          // pto: %102
          ;
          int64_t v301 = v300 < v42 ? v42 : v300;
          // pto: %gather_row_view
          ;
          Tile<TileType::Vec, int8_t, 1, 2048, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v302;
          // pto: %103, %gather_row_view
          ;
          uint64_t v303 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v278 * (uint64_t) v60) + (uint64_t) v32);
          TASSIGN(v302, v303);
          // pto: %104
          ;
          int64_t v304 = v301 < v42 ? v42 : v301;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v305 = (int64_t) v23;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v306 = 0;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          __gm__ int8_t* v307 = PTOAS__GLOBAL_TENSOR_DATA(v85);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v308 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v309 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v310 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v311 = v38 * v305;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v312 = v310 * v311;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          pto::Shape<1, 1, 1, 1, 64> v313 = pto::Shape<1, 1, 1, 1, 64>(v308, v309, v310, v38, v60);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v314 = pto::Stride<-1, -1, -1, -1, -1>(v309 * v312, v312, v311, v305, v38);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v315 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v307 + (v306 + v304 * v305 + v61 * v38), v313, v314);
          TLOAD(v302, v315);
        };
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %single_scale_half_inline3859__ssa_v0
        ;
        Tile<TileType::Vec, half, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v316 = Tile<TileType::Vec, half, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_scale_half_inline3859__ssa_v0
        ;
        uint64_t v317 = (uint64_t) v32;
        TASSIGN(v316, v317);
        // pto: %single_kv_scale_inline3860__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v318 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_kv_scale_inline3860__ssa_v0
        ;
        uint64_t v319 = (uint64_t) v33;
        TASSIGN(v318, v319);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v320 = RoundMode::CAST_ROUND;
        SaturationMode v321 = SaturationMode::ON;
        TCVT(v318, v316, v320, v321);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        int32_t v322 = (int32_t) v42;
        wait_flag_dev(v322);
        // pto: %single_scores_inline3861__ssa_v0
        ;
        Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v323 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
        // pto: %single_scores_inline3861__ssa_v0
        ;
        uint64_t v324 = (uint64_t) v32;
        TASSIGN(v323, v324);
        // pto: %105
        ;
        int64_t v325 = v275 < v42 ? v42 : v275;
        // pto: %buf_score_transfer_inline3774__ssa_v0_pview
        ;
        __gm__ float* v326 = PTOAS__GLOBAL_TENSOR_DATA(v75);
        // pto: %buf_score_transfer_inline3774__ssa_v0_pview
        ;
        const int64_t v327 = 0;
        // pto: %buf_score_transfer_inline3774__ssa_v0_pview
        ;
        const int64_t v328 = 1024;
        // pto: %buf_score_transfer_inline3774__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 3, 1024> v329 = pto::Shape<1, 1, 1, 3, 1024>();
        // pto: %buf_score_transfer_inline3774__ssa_v0_pview
        ;
        pto::Stride<3072, 3072, 3072, 1024, 1> v330 = pto::Stride<3072, 3072, 3072, 1024, 1>();
        // pto: %buf_score_transfer_inline3774__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 3, 1024>, pto::Stride<3072, 3072, 3072, 1024, 1>, pto::Layout::ND> v331 = GlobalTensor<float, pto::Shape<1, 1, 1, 3, 1024>, pto::Stride<3072, 3072, 3072, 1024, 1>, pto::Layout::ND>(v326 + (v327 + v325 * v328), v329, v330);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        TLOAD(v323, v331);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        uint16_t v332 = getFFTSMsg(FFTS_MODE_VAL, v38);
        ffts_cross_core_sync(PIPE_MTE2, v332);
        // pto: %single_score_row_inline3863__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v333 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_score_row_inline3863__ssa_v0
        ;
        uint64_t v334 = (uint64_t) v34;
        TASSIGN(v333, v334);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        uint16_t v335 = static_cast<uint16_t>(v42);
        uint16_t v336 = static_cast<uint16_t>(v42);
        TEXTRACT(v333, v323, v335, v336);
        // pto: %single_scaled_inline3864__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v337 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_scaled_inline3864__ssa_v0
        ;
        uint64_t v338 = (uint64_t) v34;
        TASSIGN(v337, v338);
        pipe_barrier(PIPE_V);
        TMUL(v337, v333, v318);
        // pto: %assemble_view
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v339;
        // pto: %assemble_view
        ;
        uint64_t v340 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v273 * (uint64_t) v28) + (uint64_t) v31);
        TASSIGN(v339, v340);
        pipe_barrier(PIPE_V);
        TMOV(v339, v337);
        // pto: %single_score_row_inline3863__ssa_v1
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v341 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_score_row_inline3863__ssa_v1
        ;
        uint64_t v342 = (uint64_t) v34;
        TASSIGN(v341, v342);
        pipe_barrier(PIPE_V);
        uint16_t v343 = static_cast<uint16_t>(v38);
        uint16_t v344 = static_cast<uint16_t>(v42);
        TEXTRACT(v341, v323, v343, v344);
        // pto: %single_scaled_inline3864__ssa_v1
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v345 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_scaled_inline3864__ssa_v1
        ;
        uint64_t v346 = (uint64_t) v34;
        TASSIGN(v345, v346);
        pipe_barrier(PIPE_V);
        TMUL(v345, v341, v318);
        // pto: %115
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v347;
        // pto: %114, %115
        ;
        uint64_t v348 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v273 + (uint64_t) v58) * (uint64_t) v28) + (uint64_t) v31);
        TASSIGN(v347, v348);
        pipe_barrier(PIPE_V);
        TMOV(v347, v345);
        // pto: %single_score_row_inline3863__ssa_v2
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v349 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_score_row_inline3863__ssa_v2
        ;
        uint64_t v350 = (uint64_t) v34;
        TASSIGN(v349, v350);
        pipe_barrier(PIPE_V);
        uint16_t v351 = static_cast<uint16_t>(v58);
        uint16_t v352 = static_cast<uint16_t>(v42);
        TEXTRACT(v349, v323, v351, v352);
        // pto: %single_scaled_inline3864__ssa_v2
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v353 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_scaled_inline3864__ssa_v2
        ;
        uint64_t v354 = (uint64_t) v32;
        TASSIGN(v353, v354);
        pipe_barrier(PIPE_V);
        TMUL(v353, v349, v318);
        // pto: %121
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v355;
        // pto: %120, %121
        ;
        uint64_t v356 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v273 + (uint64_t) v43) * (uint64_t) v28) + (uint64_t) v31);
        TASSIGN(v355, v356);
        pipe_barrier(PIPE_V);
        TMOV(v355, v353);
        // pto: %126, %127, %128, %129
        ;
        if (v273 == v38 | (int64_t) ((uint64_t) v270 + (uint64_t) v38) == v265) {
          // pto: %130
          ;
          const int64_t v357 = 1;
          // pto: %130
          ;
          const int64_t v358 = 0;
          // pto: %130
          ;
          int64_t v359 = v270 / v58;
          // pto: %130
          ;
          bool v360 = v270 < v358;
          // pto: %130
          ;
          bool v361 = v58 < v358;
          // pto: %130
          ;
          bool v362 = v360 == v361;
          // pto: %130
          ;
          bool v363 = v270 % v58 != v358 && v360 != v361;
          // pto: %130
          ;
          int64_t v364 = v363 ? v359 - v357 : v359;
          // pto: %132, %131
          ;
          int64_t v365 = (int64_t) ((uint64_t) v251 + (uint64_t) ((int64_t) (uint64_t) v364 * (uint64_t) v59));
          // pto: %137, %138
          ;
          int64_t v366 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v273 * (uint64_t) v41) + (uint64_t) v41);
          // pto: %single_segment_rows_inline3867__ssa_v0
          ;
          Tile<TileType::Vec, float, 3, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v367 = Tile<TileType::Vec, float, 3, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v59);
          // pto: %single_segment_rows_inline3867__ssa_v0
          ;
          uint64_t v368 = (uint64_t) v31;
          TASSIGN(v367, v368);
          // pto: %141
          ;
          int64_t v369 = (int64_t) ((uint64_t) v221 - (uint64_t) v38);
          // pto: %142
          ;
          int64_t v370 = v274 < v369 ? v274 : v369;
          // pto: %143, %single_position_inline3871__tile
          ;
          int64_t v371 = (v7)[(int64_t) ((uint64_t) v219 + (uint64_t) v370)];
          // pto: %144
          ;
          int64_t v372 = (int64_t) ((uint64_t) v371 + (uint64_t) v54);
          // pto: %145
          ;
          const int64_t v373 = 1;
          // pto: %145
          ;
          const int64_t v374 = 0;
          // pto: %145
          ;
          int64_t v375 = v372 / v55;
          // pto: %145
          ;
          bool v376 = v372 < v374;
          // pto: %145
          ;
          bool v377 = v55 < v374;
          // pto: %145
          ;
          bool v378 = v376 == v377;
          // pto: %145
          ;
          bool v379 = v372 % v55 != v374 && v376 != v377;
          // pto: %145
          ;
          int64_t v380 = v379 ? v375 - v373 : v375;
          // pto: %147
          ;
          int64_t v381 = v233 < v380 ? v233 : v380;
          // pto: %148
          ;
          int64_t v382 = v381 < v44 ? v381 : v44;
          // pto: %149
          ;
          int64_t v383 = v382 < v42 ? v42 : v382;
          // pto: %150
          ;
          int64_t v384 = (int64_t) ((uint64_t) v383 - (uint64_t) v365);
          // pto: %151
          ;
          int64_t v385 = v384 < v366 ? v384 : v366;
          // pto: %152
          ;
          int64_t v386 = v385 < v42 ? v42 : v385;
          // pto: %153, %140, %154
          ;
          if (v386 > v42 & v274 < v221) {
            // pto: %single_segment_data_inline3874__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v387 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
            // pto: %single_segment_data_inline3874__ssa_v0
            ;
            uint64_t v388 = (uint64_t) v32;
            TASSIGN(v387, v388);
            pipe_barrier(PIPE_V);
            uint16_t v389 = static_cast<uint16_t>(v42);
            uint16_t v390 = static_cast<uint16_t>(v42);
            TEXTRACT(v387, v367, v389, v390);
            // pto: %155
            ;
            int32_t v391 = (int32_t) v365;
            // pto: %156
            ;
            if (v386 <= v62) {
              // pto: %t__ci_tmp_v0
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v392 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
              // pto: %t__ci_tmp_v0
              ;
              uint64_t v393 = (uint64_t) v34;
              TASSIGN(v392, v393);
              // pto: %t__tmp_v427
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v394 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v427
              ;
              uint64_t v395 = (uint64_t) v33;
              TASSIGN(v394, v395);
              // pto: %ci_tmp_view
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v396;
              TRESHAPE(v396, v392);
              // pto: %ci_dst_view
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v397;
              TRESHAPE(v397, v394);
              TCI<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v397, v64, v396);
              // pto: %tiny_indices_inline3876__ssa_v0
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v398 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %tiny_indices_inline3876__ssa_v0
              ;
              uint64_t v399 = (uint64_t) v34;
              TASSIGN(v398, v399);
              pipe_barrier(PIPE_V);
              TADDS(v398, v394, v391);
              // pto: %tiny_tile_inline3877__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v400 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %tiny_tile_inline3877__ssa_v0
              ;
              uint64_t v401 = (uint64_t) v33;
              TASSIGN(v400, v401);
              pipe_barrier(PIPE_V);
              uint16_t v402 = static_cast<uint16_t>(v42);
              uint16_t v403 = static_cast<uint16_t>(v42);
              TEXTRACT(v400, v387, v402, v403);
              v400.SetValidShape(v38, v386);
              // pto: %t__tmp_v428
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v404 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v428
              ;
              uint64_t v405 = (uint64_t) v33;
              TASSIGN(v404, v405);
              pipe_barrier(PIPE_V);
              TFILLPAD<pto::TFillPadMode::InPlace>(v404, v400);
              // pto: %tiny_scores_inline3879__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v406 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v62);
              // pto: %tiny_scores_inline3879__ssa_v0
              ;
              uint64_t v407 = (uint64_t) v35;
              TASSIGN(v406, v407);
              pipe_barrier(PIPE_V);
              TMAXS(v406, v404, v56);
              // pto: %t__tmp_v429
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v408 = Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v429
              ;
              uint64_t v409 = (uint64_t) v34;
              TASSIGN(v408, v409);
              // pto: %tiny_pairs_inline3880__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v410 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_inline3880__ssa_v0
              ;
              uint64_t v411 = (uint64_t) v33;
              TASSIGN(v410, v411);
              // pto: %sort32_src_view
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v412;
              TRESHAPE(v412, v406);
              // pto: %sort32_idx_view
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v413;
              TRESHAPE(v413, v408);
              // pto: %sort32_dst_view
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v414;
              TRESHAPE(v414, v410);
              pipe_barrier(PIPE_V);
              TSORT32(v414, v412, v413);
              // pto: %tiny_pairs_v1_inline3881__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v415 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_v1_inline3881__ssa_v0
              ;
              uint64_t v416 = (uint64_t) v34;
              TASSIGN(v415, v416);
              pipe_barrier(PIPE_V);
              TMRGSORT(v415, v410, v65);
              // pto: %tiny_pairs_v2_inline3882__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v417 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_v2_inline3882__ssa_v0
              ;
              uint64_t v418 = (uint64_t) v33;
              TASSIGN(v417, v418);
              pipe_barrier(PIPE_V);
              TMRGSORT(v417, v415, v66);
              // pto: %single_new_root_inline3883__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v419 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_new_root_inline3883__ssa_v0
              ;
              uint64_t v420 = (uint64_t) v36;
              TASSIGN(v419, v420);
              pipe_barrier(PIPE_V);
              uint16_t v421 = static_cast<uint16_t>(v42);
              uint16_t v422 = static_cast<uint16_t>(v42);
              TEXTRACT(v419, v417, v421, v422);
            } else {
              // pto: %157
              ;
              if (v386 <= v41) {
                // pto: %t__ci_tmp_v1
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v423 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
                // pto: %t__ci_tmp_v1
                ;
                uint64_t v424 = (uint64_t) v34;
                TASSIGN(v423, v424);
                // pto: %t__tmp_v430
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v425 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v430
                ;
                uint64_t v426 = (uint64_t) v33;
                TASSIGN(v425, v426);
                // pto: %158
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v427;
                TRESHAPE(v427, v423);
                // pto: %159
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v428;
                TRESHAPE(v428, v425);
                TCI<Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v428, v64, v427);
                // pto: %small_indices_inline3884__ssa_v0
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v429 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %small_indices_inline3884__ssa_v0
                ;
                uint64_t v430 = (uint64_t) v34;
                TASSIGN(v429, v430);
                pipe_barrier(PIPE_V);
                TADDS(v429, v425, v391);
                // pto: %small_tile_inline3885__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v431 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %small_tile_inline3885__ssa_v0
                ;
                uint64_t v432 = (uint64_t) v33;
                TASSIGN(v431, v432);
                pipe_barrier(PIPE_V);
                uint16_t v433 = static_cast<uint16_t>(v42);
                uint16_t v434 = static_cast<uint16_t>(v42);
                TEXTRACT(v431, v387, v433, v434);
                v431.SetValidShape(v38, v386);
                // pto: %t__tmp_v431
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v435 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v431
                ;
                uint64_t v436 = (uint64_t) v33;
                TASSIGN(v435, v436);
                pipe_barrier(PIPE_V);
                TFILLPAD<pto::TFillPadMode::InPlace>(v435, v431);
                // pto: %small_scores_inline3887__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v437 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_scores_inline3887__ssa_v0
                ;
                uint64_t v438 = (uint64_t) v35;
                TASSIGN(v437, v438);
                pipe_barrier(PIPE_V);
                TMAXS(v437, v435, v56);
                // pto: %t__tmp_v432
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v439 = Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v432
                ;
                uint64_t v440 = (uint64_t) v34;
                TASSIGN(v439, v440);
                // pto: %small_pairs_inline3888__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v441 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_inline3888__ssa_v0
                ;
                uint64_t v442 = (uint64_t) v33;
                TASSIGN(v441, v442);
                // pto: %160
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v443;
                TRESHAPE(v443, v437);
                // pto: %161
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v444;
                TRESHAPE(v444, v439);
                // pto: %162
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v445;
                TRESHAPE(v445, v441);
                pipe_barrier(PIPE_V);
                TSORT32(v445, v443, v444);
                // pto: %small_pairs_v1_inline3889__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v446 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_v1_inline3889__ssa_v0
                ;
                uint64_t v447 = (uint64_t) v34;
                TASSIGN(v446, v447);
                pipe_barrier(PIPE_V);
                TMRGSORT(v446, v441, v65);
                // pto: %small_pairs_v2_inline3890__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v448 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_v2_inline3890__ssa_v0
                ;
                uint64_t v449 = (uint64_t) v33;
                TASSIGN(v448, v449);
                pipe_barrier(PIPE_V);
                TMRGSORT(v448, v446, v66);
                // pto: %small_left_inline3891__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v450 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_left_inline3891__ssa_v0
                ;
                uint64_t v451 = (uint64_t) v33;
                TASSIGN(v450, v451);
                // pto: %slice_view
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v452;
                // pto: %slice_view
                ;
                uint64_t v453 = (uint64_t) v33;
                TASSIGN(v452, v453);
                // pto: %small_right_inline3892__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v454 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_right_inline3892__ssa_v0
                ;
                uint64_t v455 = (uint64_t) v37;
                TASSIGN(v454, v455);
                // pto: %163
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v456;
                // pto: %163
                ;
                uint64_t v457 = (uint64_t) v37;
                TASSIGN(v456, v457);
                // pto: %small_tmp_inline3893__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v458 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %small_tmp_inline3893__ssa_v0
                ;
                uint64_t v459 = (uint64_t) v34;
                TASSIGN(v458, v459);
                // pto: %small_merged_inline3894__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v460 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_merged_inline3894__ssa_v0
                ;
                uint64_t v461 = (uint64_t) v35;
                TASSIGN(v460, v461);
                pipe_barrier(PIPE_V);
                TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v460, v29, v458, v452, v456);
                // pto: %single_new_root_inline3883__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v462 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline3883__ssa_v1
                ;
                uint64_t v463 = (uint64_t) v36;
                TASSIGN(v462, v463);
                pipe_barrier(PIPE_V);
                uint16_t v464 = static_cast<uint16_t>(v42);
                uint16_t v465 = static_cast<uint16_t>(v42);
                TEXTRACT(v462, v460, v464, v465);
              } else {
                // pto: %t__ci_tmp_v2
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v466 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
                // pto: %t__ci_tmp_v2
                ;
                uint64_t v467 = (uint64_t) v34;
                TASSIGN(v466, v467);
                // pto: %t__tmp_v433
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v468 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v433
                ;
                uint64_t v469 = (uint64_t) v33;
                TASSIGN(v468, v469);
                // pto: %164
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v470;
                TRESHAPE(v470, v466);
                // pto: %165
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v471;
                TRESHAPE(v471, v468);
                TCI<Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v471, v64, v470);
                // pto: %large_indices_inline3895__ssa_v0
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v472 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %large_indices_inline3895__ssa_v0
                ;
                uint64_t v473 = (uint64_t) v33;
                TASSIGN(v472, v473);
                pipe_barrier(PIPE_V);
                TADDS(v472, v468, v391);
                // pto: %large_tile_inline3896__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v474 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %large_tile_inline3896__ssa_v0
                ;
                uint64_t v475 = (uint64_t) v34;
                TASSIGN(v474, v475);
                uint16_t v476 = static_cast<uint16_t>(v42);
                uint16_t v477 = static_cast<uint16_t>(v42);
                TEXTRACT(v474, v387, v476, v477);
                v474.SetValidShape(v38, v386);
                // pto: %t__tmp_v434
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v478 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v434
                ;
                uint64_t v479 = (uint64_t) v32;
                TASSIGN(v478, v479);
                pipe_barrier(PIPE_V);
                TFILLPAD(v478, v474);
                // pto: %large_scores_inline3898__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v480 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %large_scores_inline3898__ssa_v0
                ;
                uint64_t v481 = (uint64_t) v34;
                TASSIGN(v480, v481);
                pipe_barrier(PIPE_V);
                TMAXS(v480, v478, v56);
                // pto: %t__tmp_v435
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v482 = Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v435
                ;
                uint64_t v483 = (uint64_t) v33;
                TASSIGN(v482, v483);
                // pto: %large_pairs_inline3899__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v484 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_inline3899__ssa_v0
                ;
                uint64_t v485 = (uint64_t) v32;
                TASSIGN(v484, v485);
                // pto: %166
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v486;
                TRESHAPE(v486, v480);
                // pto: %167
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v487;
                TRESHAPE(v487, v482);
                // pto: %168
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v488;
                TRESHAPE(v488, v484);
                pipe_barrier(PIPE_V);
                TSORT32(v488, v486, v487);
                // pto: %large_pairs_v1_inline3900__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v489 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v1_inline3900__ssa_v0
                ;
                uint64_t v490 = (uint64_t) v33;
                TASSIGN(v489, v490);
                pipe_barrier(PIPE_V);
                TMRGSORT(v489, v484, v65);
                // pto: %large_pairs_v2_inline3901__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v491 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v2_inline3901__ssa_v0
                ;
                uint64_t v492 = (uint64_t) v32;
                TASSIGN(v491, v492);
                pipe_barrier(PIPE_V);
                TMRGSORT(v491, v489, v66);
                // pto: %large_pairs_v3_inline3902__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v493 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v3_inline3902__ssa_v0
                ;
                uint64_t v494 = (uint64_t) v33;
                TASSIGN(v493, v494);
                pipe_barrier(PIPE_V);
                TMRGSORT(v493, v491, v67);
                // pto: %single_new_root_inline3883__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v495 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline3883__ssa_v2
                ;
                uint64_t v496 = (uint64_t) v34;
                TASSIGN(v495, v496);
                pipe_barrier(PIPE_V);
                uint16_t v497 = static_cast<uint16_t>(v42);
                uint16_t v498 = static_cast<uint16_t>(v42);
                TEXTRACT(v495, v493, v497, v498);
                // pto: %single_new_root_inline3883__ssa_v2_mv
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v499 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline3883__ssa_v2_mv
                ;
                uint64_t v500 = (uint64_t) v36;
                TASSIGN(v499, v500);
                pipe_barrier(PIPE_V);
                TMOV(v499, v495);
              };
            };
            // pto: %169
            ;
            if (v270 < v58) {
              // pto: %170
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v501;
              // pto: %170
              ;
              uint64_t v502 = (uint64_t) v30;
              TASSIGN(v501, v502);
              pipe_barrier(PIPE_V);
              TMOV(v501, v98);
            } else {
              // pto: %single_old_root_inline3903__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v503 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_old_root_inline3903__ssa_v0
              ;
              uint64_t v504 = (uint64_t) v35;
              TASSIGN(v503, v504);
              pipe_barrier(PIPE_V);
              uint16_t v505 = static_cast<uint16_t>(v42);
              uint16_t v506 = static_cast<uint16_t>(v42);
              TEXTRACT(v503, v266, v505, v506);
              // pto: %single_merge_tmp_inline3904__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v507 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
              // pto: %single_merge_tmp_inline3904__ssa_v0
              ;
              uint64_t v508 = (uint64_t) v32;
              TASSIGN(v507, v508);
              // pto: %single_merged_inline3905__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v509 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
              // pto: %single_merged_inline3905__ssa_v0
              ;
              uint64_t v510 = (uint64_t) v33;
              TASSIGN(v509, v510);
              pipe_barrier(PIPE_V);
              TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, false>(v509, v29, v507, v98, v503);
              // pto: %single_next_root_inline3906__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v511 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_next_root_inline3906__ssa_v0
              ;
              uint64_t v512 = (uint64_t) v32;
              TASSIGN(v511, v512);
              pipe_barrier(PIPE_V);
              uint16_t v513 = static_cast<uint16_t>(v42);
              uint16_t v514 = static_cast<uint16_t>(v42);
              TEXTRACT(v511, v509, v513, v514);
              // pto: %172
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v515;
              // pto: %172
              ;
              uint64_t v516 = (uint64_t) v30;
              TASSIGN(v515, v516);
              pipe_barrier(PIPE_V);
              TMOV(v515, v511);
            };
          };
          // pto: %174
          ;
          int64_t v517 = (int64_t) ((uint64_t) v274 + (uint64_t) v38);
          // pto: %178
          ;
          int64_t v518 = v517 < v369 ? v517 : v369;
          // pto: %179, %176
          ;
          int64_t v519 = (v7)[(int64_t) ((uint64_t) v219 + (uint64_t) v518)];
          // pto: %180
          ;
          int64_t v520 = (int64_t) ((uint64_t) v519 + (uint64_t) v54);
          // pto: %181
          ;
          const int64_t v521 = 1;
          // pto: %181
          ;
          const int64_t v522 = 0;
          // pto: %181
          ;
          int64_t v523 = v520 / v55;
          // pto: %181
          ;
          bool v524 = v520 < v522;
          // pto: %181
          ;
          bool v525 = v55 < v522;
          // pto: %181
          ;
          bool v526 = v524 == v525;
          // pto: %181
          ;
          bool v527 = v520 % v55 != v522 && v524 != v525;
          // pto: %181
          ;
          int64_t v528 = v527 ? v523 - v521 : v523;
          // pto: %183
          ;
          int64_t v529 = v233 < v528 ? v233 : v528;
          // pto: %184
          ;
          int64_t v530 = v529 < v44 ? v529 : v44;
          // pto: %185
          ;
          int64_t v531 = v530 < v42 ? v42 : v530;
          // pto: %186
          ;
          int64_t v532 = (int64_t) ((uint64_t) v531 - (uint64_t) v365);
          // pto: %187
          ;
          int64_t v533 = v532 < v366 ? v532 : v366;
          // pto: %188
          ;
          int64_t v534 = v533 < v42 ? v42 : v533;
          // pto: %189, %175, %190
          ;
          if (v534 > v42 & v517 < v221) {
            // pto: %single_segment_data_inline3874__ssa_v1
            ;
            Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v535 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
            // pto: %single_segment_data_inline3874__ssa_v1
            ;
            uint64_t v536 = (uint64_t) v32;
            TASSIGN(v535, v536);
            pipe_barrier(PIPE_V);
            uint16_t v537 = static_cast<uint16_t>(v38);
            uint16_t v538 = static_cast<uint16_t>(v42);
            TEXTRACT(v535, v367, v537, v538);
            // pto: %191
            ;
            int32_t v539 = (int32_t) v365;
            // pto: %192
            ;
            if (v534 <= v62) {
              // pto: %t__ci_tmp_v3
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v540 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
              // pto: %t__ci_tmp_v3
              ;
              uint64_t v541 = (uint64_t) v34;
              TASSIGN(v540, v541);
              // pto: %t__tmp_v436
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v542 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v436
              ;
              uint64_t v543 = (uint64_t) v33;
              TASSIGN(v542, v543);
              // pto: %193
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v544;
              TRESHAPE(v544, v540);
              // pto: %194
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v545;
              TRESHAPE(v545, v542);
              TCI<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v545, v64, v544);
              // pto: %tiny_indices_inline3876__ssa_v1
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v546 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %tiny_indices_inline3876__ssa_v1
              ;
              uint64_t v547 = (uint64_t) v34;
              TASSIGN(v546, v547);
              pipe_barrier(PIPE_V);
              TADDS(v546, v542, v539);
              // pto: %tiny_tile_inline3877__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v548 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %tiny_tile_inline3877__ssa_v1
              ;
              uint64_t v549 = (uint64_t) v33;
              TASSIGN(v548, v549);
              pipe_barrier(PIPE_V);
              uint16_t v550 = static_cast<uint16_t>(v42);
              uint16_t v551 = static_cast<uint16_t>(v42);
              TEXTRACT(v548, v535, v550, v551);
              v548.SetValidShape(v38, v534);
              // pto: %t__tmp_v437
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v552 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v437
              ;
              uint64_t v553 = (uint64_t) v33;
              TASSIGN(v552, v553);
              pipe_barrier(PIPE_V);
              TFILLPAD<pto::TFillPadMode::InPlace>(v552, v548);
              // pto: %tiny_scores_inline3879__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v554 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v62);
              // pto: %tiny_scores_inline3879__ssa_v1
              ;
              uint64_t v555 = (uint64_t) v35;
              TASSIGN(v554, v555);
              pipe_barrier(PIPE_V);
              TMAXS(v554, v552, v56);
              // pto: %t__tmp_v438
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v556 = Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v438
              ;
              uint64_t v557 = (uint64_t) v34;
              TASSIGN(v556, v557);
              // pto: %tiny_pairs_inline3880__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v558 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_inline3880__ssa_v1
              ;
              uint64_t v559 = (uint64_t) v33;
              TASSIGN(v558, v559);
              // pto: %195
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v560;
              TRESHAPE(v560, v554);
              // pto: %196
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v561;
              TRESHAPE(v561, v556);
              // pto: %197
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v562;
              TRESHAPE(v562, v558);
              pipe_barrier(PIPE_V);
              TSORT32(v562, v560, v561);
              // pto: %tiny_pairs_v1_inline3881__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v563 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_v1_inline3881__ssa_v1
              ;
              uint64_t v564 = (uint64_t) v34;
              TASSIGN(v563, v564);
              pipe_barrier(PIPE_V);
              TMRGSORT(v563, v558, v65);
              // pto: %tiny_pairs_v2_inline3882__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v565 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_v2_inline3882__ssa_v1
              ;
              uint64_t v566 = (uint64_t) v33;
              TASSIGN(v565, v566);
              pipe_barrier(PIPE_V);
              TMRGSORT(v565, v563, v66);
              // pto: %single_new_root_inline3883__ssa_v5
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v567 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_new_root_inline3883__ssa_v5
              ;
              uint64_t v568 = (uint64_t) v36;
              TASSIGN(v567, v568);
              pipe_barrier(PIPE_V);
              uint16_t v569 = static_cast<uint16_t>(v42);
              uint16_t v570 = static_cast<uint16_t>(v42);
              TEXTRACT(v567, v565, v569, v570);
            } else {
              // pto: %198
              ;
              if (v534 <= v41) {
                // pto: %t__ci_tmp_v4
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v571 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
                // pto: %t__ci_tmp_v4
                ;
                uint64_t v572 = (uint64_t) v34;
                TASSIGN(v571, v572);
                // pto: %t__tmp_v439
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v573 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v439
                ;
                uint64_t v574 = (uint64_t) v33;
                TASSIGN(v573, v574);
                // pto: %199
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v575;
                TRESHAPE(v575, v571);
                // pto: %200
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v576;
                TRESHAPE(v576, v573);
                TCI<Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v576, v64, v575);
                // pto: %small_indices_inline3884__ssa_v1
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v577 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %small_indices_inline3884__ssa_v1
                ;
                uint64_t v578 = (uint64_t) v34;
                TASSIGN(v577, v578);
                pipe_barrier(PIPE_V);
                TADDS(v577, v573, v539);
                // pto: %small_tile_inline3885__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v579 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %small_tile_inline3885__ssa_v1
                ;
                uint64_t v580 = (uint64_t) v33;
                TASSIGN(v579, v580);
                pipe_barrier(PIPE_V);
                uint16_t v581 = static_cast<uint16_t>(v42);
                uint16_t v582 = static_cast<uint16_t>(v42);
                TEXTRACT(v579, v535, v581, v582);
                v579.SetValidShape(v38, v534);
                // pto: %t__tmp_v440
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v583 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v440
                ;
                uint64_t v584 = (uint64_t) v33;
                TASSIGN(v583, v584);
                pipe_barrier(PIPE_V);
                TFILLPAD<pto::TFillPadMode::InPlace>(v583, v579);
                // pto: %small_scores_inline3887__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v585 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_scores_inline3887__ssa_v1
                ;
                uint64_t v586 = (uint64_t) v35;
                TASSIGN(v585, v586);
                pipe_barrier(PIPE_V);
                TMAXS(v585, v583, v56);
                // pto: %t__tmp_v441
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v587 = Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v441
                ;
                uint64_t v588 = (uint64_t) v34;
                TASSIGN(v587, v588);
                // pto: %small_pairs_inline3888__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v589 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_inline3888__ssa_v1
                ;
                uint64_t v590 = (uint64_t) v33;
                TASSIGN(v589, v590);
                // pto: %201
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v591;
                TRESHAPE(v591, v585);
                // pto: %202
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v592;
                TRESHAPE(v592, v587);
                // pto: %203
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v593;
                TRESHAPE(v593, v589);
                pipe_barrier(PIPE_V);
                TSORT32(v593, v591, v592);
                // pto: %small_pairs_v1_inline3889__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v594 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_v1_inline3889__ssa_v1
                ;
                uint64_t v595 = (uint64_t) v34;
                TASSIGN(v594, v595);
                pipe_barrier(PIPE_V);
                TMRGSORT(v594, v589, v65);
                // pto: %small_pairs_v2_inline3890__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v596 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_v2_inline3890__ssa_v1
                ;
                uint64_t v597 = (uint64_t) v33;
                TASSIGN(v596, v597);
                pipe_barrier(PIPE_V);
                TMRGSORT(v596, v594, v66);
                // pto: %small_left_inline3891__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v598 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_left_inline3891__ssa_v1
                ;
                uint64_t v599 = (uint64_t) v33;
                TASSIGN(v598, v599);
                // pto: %204
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v600;
                // pto: %204
                ;
                uint64_t v601 = (uint64_t) v33;
                TASSIGN(v600, v601);
                // pto: %small_right_inline3892__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v602 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_right_inline3892__ssa_v1
                ;
                uint64_t v603 = (uint64_t) v37;
                TASSIGN(v602, v603);
                // pto: %205
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v604;
                // pto: %205
                ;
                uint64_t v605 = (uint64_t) v37;
                TASSIGN(v604, v605);
                // pto: %small_tmp_inline3893__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v606 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %small_tmp_inline3893__ssa_v1
                ;
                uint64_t v607 = (uint64_t) v34;
                TASSIGN(v606, v607);
                // pto: %small_merged_inline3894__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v608 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_merged_inline3894__ssa_v1
                ;
                uint64_t v609 = (uint64_t) v35;
                TASSIGN(v608, v609);
                pipe_barrier(PIPE_V);
                TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v608, v29, v606, v600, v604);
                // pto: %single_new_root_inline3883__ssa_v6
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v610 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline3883__ssa_v6
                ;
                uint64_t v611 = (uint64_t) v36;
                TASSIGN(v610, v611);
                pipe_barrier(PIPE_V);
                uint16_t v612 = static_cast<uint16_t>(v42);
                uint16_t v613 = static_cast<uint16_t>(v42);
                TEXTRACT(v610, v608, v612, v613);
              } else {
                // pto: %t__ci_tmp_v5
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v614 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
                // pto: %t__ci_tmp_v5
                ;
                uint64_t v615 = (uint64_t) v34;
                TASSIGN(v614, v615);
                // pto: %t__tmp_v442
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v616 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v442
                ;
                uint64_t v617 = (uint64_t) v33;
                TASSIGN(v616, v617);
                // pto: %207
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v618;
                TRESHAPE(v618, v614);
                // pto: %208
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v619;
                TRESHAPE(v619, v616);
                TCI<Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v619, v64, v618);
                // pto: %large_indices_inline3895__ssa_v1
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v620 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %large_indices_inline3895__ssa_v1
                ;
                uint64_t v621 = (uint64_t) v33;
                TASSIGN(v620, v621);
                pipe_barrier(PIPE_V);
                TADDS(v620, v616, v539);
                // pto: %large_tile_inline3896__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v622 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %large_tile_inline3896__ssa_v1
                ;
                uint64_t v623 = (uint64_t) v34;
                TASSIGN(v622, v623);
                uint16_t v624 = static_cast<uint16_t>(v42);
                uint16_t v625 = static_cast<uint16_t>(v42);
                TEXTRACT(v622, v535, v624, v625);
                v622.SetValidShape(v38, v534);
                // pto: %t__tmp_v443
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v626 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v443
                ;
                uint64_t v627 = (uint64_t) v32;
                TASSIGN(v626, v627);
                pipe_barrier(PIPE_V);
                TFILLPAD(v626, v622);
                // pto: %large_scores_inline3898__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v628 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %large_scores_inline3898__ssa_v1
                ;
                uint64_t v629 = (uint64_t) v34;
                TASSIGN(v628, v629);
                pipe_barrier(PIPE_V);
                TMAXS(v628, v626, v56);
                // pto: %t__tmp_v444
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v630 = Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v444
                ;
                uint64_t v631 = (uint64_t) v33;
                TASSIGN(v630, v631);
                // pto: %large_pairs_inline3899__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v632 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_inline3899__ssa_v1
                ;
                uint64_t v633 = (uint64_t) v32;
                TASSIGN(v632, v633);
                // pto: %209
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v634;
                TRESHAPE(v634, v628);
                // pto: %210
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v635;
                TRESHAPE(v635, v630);
                // pto: %211
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v636;
                TRESHAPE(v636, v632);
                pipe_barrier(PIPE_V);
                TSORT32(v636, v634, v635);
                // pto: %large_pairs_v1_inline3900__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v637 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v1_inline3900__ssa_v1
                ;
                uint64_t v638 = (uint64_t) v33;
                TASSIGN(v637, v638);
                pipe_barrier(PIPE_V);
                TMRGSORT(v637, v632, v65);
                // pto: %large_pairs_v2_inline3901__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v639 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v2_inline3901__ssa_v1
                ;
                uint64_t v640 = (uint64_t) v32;
                TASSIGN(v639, v640);
                pipe_barrier(PIPE_V);
                TMRGSORT(v639, v637, v66);
                // pto: %large_pairs_v3_inline3902__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v641 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v3_inline3902__ssa_v1
                ;
                uint64_t v642 = (uint64_t) v33;
                TASSIGN(v641, v642);
                pipe_barrier(PIPE_V);
                TMRGSORT(v641, v639, v67);
                // pto: %single_new_root_inline3883__ssa_v7
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v643 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline3883__ssa_v7
                ;
                uint64_t v644 = (uint64_t) v34;
                TASSIGN(v643, v644);
                pipe_barrier(PIPE_V);
                uint16_t v645 = static_cast<uint16_t>(v42);
                uint16_t v646 = static_cast<uint16_t>(v42);
                TEXTRACT(v643, v641, v645, v646);
                // pto: %single_new_root_inline3883__ssa_v7_mv
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v647 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline3883__ssa_v7_mv
                ;
                uint64_t v648 = (uint64_t) v36;
                TASSIGN(v647, v648);
                pipe_barrier(PIPE_V);
                TMOV(v647, v643);
              };
            };
            // pto: %212
            ;
            if (v270 < v58) {
              // pto: %213
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v649;
              // pto: %213
              ;
              uint64_t v650 = (uint64_t) v28;
              TASSIGN(v649, v650);
              pipe_barrier(PIPE_V);
              TMOV(v649, v106);
            } else {
              // pto: %single_old_root_inline3903__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v651 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_old_root_inline3903__ssa_v1
              ;
              uint64_t v652 = (uint64_t) v35;
              TASSIGN(v651, v652);
              pipe_barrier(PIPE_V);
              uint16_t v653 = static_cast<uint16_t>(v38);
              uint16_t v654 = static_cast<uint16_t>(v42);
              TEXTRACT(v651, v96, v653, v654);
              // pto: %single_merge_tmp_inline3904__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v655 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
              // pto: %single_merge_tmp_inline3904__ssa_v1
              ;
              uint64_t v656 = (uint64_t) v32;
              TASSIGN(v655, v656);
              // pto: %single_merged_inline3905__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v657 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
              // pto: %single_merged_inline3905__ssa_v1
              ;
              uint64_t v658 = (uint64_t) v33;
              TASSIGN(v657, v658);
              pipe_barrier(PIPE_V);
              TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, false>(v657, v29, v655, v106, v651);
              // pto: %single_next_root_inline3906__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v659 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_next_root_inline3906__ssa_v1
              ;
              uint64_t v660 = (uint64_t) v32;
              TASSIGN(v659, v660);
              pipe_barrier(PIPE_V);
              uint16_t v661 = static_cast<uint16_t>(v42);
              uint16_t v662 = static_cast<uint16_t>(v42);
              TEXTRACT(v659, v657, v661, v662);
              // pto: %215
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v663;
              // pto: %215
              ;
              uint64_t v664 = (uint64_t) v28;
              TASSIGN(v663, v664);
              pipe_barrier(PIPE_V);
              TMOV(v663, v659);
            };
          };
          // pto: %217
          ;
          int64_t v665 = (int64_t) ((uint64_t) v274 + (uint64_t) v58);
          // pto: %221
          ;
          int64_t v666 = v665 < v369 ? v665 : v369;
          // pto: %222, %219
          ;
          int64_t v667 = (v7)[(int64_t) ((uint64_t) v219 + (uint64_t) v666)];
          // pto: %223
          ;
          int64_t v668 = (int64_t) ((uint64_t) v667 + (uint64_t) v54);
          // pto: %224
          ;
          const int64_t v669 = 1;
          // pto: %224
          ;
          const int64_t v670 = 0;
          // pto: %224
          ;
          int64_t v671 = v668 / v55;
          // pto: %224
          ;
          bool v672 = v668 < v670;
          // pto: %224
          ;
          bool v673 = v55 < v670;
          // pto: %224
          ;
          bool v674 = v672 == v673;
          // pto: %224
          ;
          bool v675 = v668 % v55 != v670 && v672 != v673;
          // pto: %224
          ;
          int64_t v676 = v675 ? v671 - v669 : v671;
          // pto: %226
          ;
          int64_t v677 = v233 < v676 ? v233 : v676;
          // pto: %227
          ;
          int64_t v678 = v677 < v44 ? v677 : v44;
          // pto: %228
          ;
          int64_t v679 = v678 < v42 ? v42 : v678;
          // pto: %229
          ;
          int64_t v680 = (int64_t) ((uint64_t) v679 - (uint64_t) v365);
          // pto: %230
          ;
          int64_t v681 = v680 < v366 ? v680 : v366;
          // pto: %231
          ;
          int64_t v682 = v681 < v42 ? v42 : v681;
          // pto: %232, %218, %233
          ;
          if (v682 > v42 & v665 < v221) {
            // pto: %single_segment_data_inline3874__ssa_v2
            ;
            Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v683 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
            // pto: %single_segment_data_inline3874__ssa_v2
            ;
            uint64_t v684 = (uint64_t) v32;
            TASSIGN(v683, v684);
            pipe_barrier(PIPE_V);
            uint16_t v685 = static_cast<uint16_t>(v58);
            uint16_t v686 = static_cast<uint16_t>(v42);
            TEXTRACT(v683, v367, v685, v686);
            // pto: %234
            ;
            int32_t v687 = (int32_t) v365;
            // pto: %235
            ;
            if (v682 <= v62) {
              // pto: %t__ci_tmp_v6
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v688 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
              // pto: %t__ci_tmp_v6
              ;
              uint64_t v689 = (uint64_t) v34;
              TASSIGN(v688, v689);
              // pto: %t__tmp_v445
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v690 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v445
              ;
              uint64_t v691 = (uint64_t) v33;
              TASSIGN(v690, v691);
              // pto: %236
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v692;
              TRESHAPE(v692, v688);
              // pto: %237
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v693;
              TRESHAPE(v693, v690);
              TCI<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v693, v64, v692);
              // pto: %tiny_indices_inline3876__ssa_v2
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v694 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %tiny_indices_inline3876__ssa_v2
              ;
              uint64_t v695 = (uint64_t) v34;
              TASSIGN(v694, v695);
              pipe_barrier(PIPE_V);
              TADDS(v694, v690, v687);
              // pto: %tiny_tile_inline3877__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v696 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %tiny_tile_inline3877__ssa_v2
              ;
              uint64_t v697 = (uint64_t) v33;
              TASSIGN(v696, v697);
              pipe_barrier(PIPE_V);
              uint16_t v698 = static_cast<uint16_t>(v42);
              uint16_t v699 = static_cast<uint16_t>(v42);
              TEXTRACT(v696, v683, v698, v699);
              v696.SetValidShape(v38, v682);
              // pto: %t__tmp_v446
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v700 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v446
              ;
              uint64_t v701 = (uint64_t) v33;
              TASSIGN(v700, v701);
              pipe_barrier(PIPE_V);
              TFILLPAD<pto::TFillPadMode::InPlace>(v700, v696);
              // pto: %tiny_scores_inline3879__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v702 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v62);
              // pto: %tiny_scores_inline3879__ssa_v2
              ;
              uint64_t v703 = (uint64_t) v35;
              TASSIGN(v702, v703);
              pipe_barrier(PIPE_V);
              TMAXS(v702, v700, v56);
              // pto: %t__tmp_v447
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v704 = Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v447
              ;
              uint64_t v705 = (uint64_t) v34;
              TASSIGN(v704, v705);
              // pto: %tiny_pairs_inline3880__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v706 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_inline3880__ssa_v2
              ;
              uint64_t v707 = (uint64_t) v33;
              TASSIGN(v706, v707);
              // pto: %238
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v708;
              TRESHAPE(v708, v702);
              // pto: %239
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v709;
              TRESHAPE(v709, v704);
              // pto: %240
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v710;
              TRESHAPE(v710, v706);
              pipe_barrier(PIPE_V);
              TSORT32(v710, v708, v709);
              // pto: %tiny_pairs_v1_inline3881__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v711 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_v1_inline3881__ssa_v2
              ;
              uint64_t v712 = (uint64_t) v34;
              TASSIGN(v711, v712);
              pipe_barrier(PIPE_V);
              TMRGSORT(v711, v706, v65);
              // pto: %tiny_pairs_v2_inline3882__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v713 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_v2_inline3882__ssa_v2
              ;
              uint64_t v714 = (uint64_t) v33;
              TASSIGN(v713, v714);
              pipe_barrier(PIPE_V);
              TMRGSORT(v713, v711, v66);
              // pto: %single_new_root_inline3883__ssa_v10
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v715 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_new_root_inline3883__ssa_v10
              ;
              uint64_t v716 = (uint64_t) v36;
              TASSIGN(v715, v716);
              pipe_barrier(PIPE_V);
              uint16_t v717 = static_cast<uint16_t>(v42);
              uint16_t v718 = static_cast<uint16_t>(v42);
              TEXTRACT(v715, v713, v717, v718);
            } else {
              // pto: %241
              ;
              if (v682 <= v41) {
                // pto: %t__ci_tmp_v7
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v719 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
                // pto: %t__ci_tmp_v7
                ;
                uint64_t v720 = (uint64_t) v34;
                TASSIGN(v719, v720);
                // pto: %t__tmp_v448
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v721 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v448
                ;
                uint64_t v722 = (uint64_t) v33;
                TASSIGN(v721, v722);
                // pto: %242
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v723;
                TRESHAPE(v723, v719);
                // pto: %243
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v724;
                TRESHAPE(v724, v721);
                TCI<Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v724, v64, v723);
                // pto: %small_indices_inline3884__ssa_v2
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v725 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %small_indices_inline3884__ssa_v2
                ;
                uint64_t v726 = (uint64_t) v34;
                TASSIGN(v725, v726);
                pipe_barrier(PIPE_V);
                TADDS(v725, v721, v687);
                // pto: %small_tile_inline3885__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v727 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %small_tile_inline3885__ssa_v2
                ;
                uint64_t v728 = (uint64_t) v33;
                TASSIGN(v727, v728);
                pipe_barrier(PIPE_V);
                uint16_t v729 = static_cast<uint16_t>(v42);
                uint16_t v730 = static_cast<uint16_t>(v42);
                TEXTRACT(v727, v683, v729, v730);
                v727.SetValidShape(v38, v682);
                // pto: %t__tmp_v449
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v731 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v449
                ;
                uint64_t v732 = (uint64_t) v33;
                TASSIGN(v731, v732);
                pipe_barrier(PIPE_V);
                TFILLPAD<pto::TFillPadMode::InPlace>(v731, v727);
                // pto: %small_scores_inline3887__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v733 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_scores_inline3887__ssa_v2
                ;
                uint64_t v734 = (uint64_t) v35;
                TASSIGN(v733, v734);
                pipe_barrier(PIPE_V);
                TMAXS(v733, v731, v56);
                // pto: %t__tmp_v450
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v735 = Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v450
                ;
                uint64_t v736 = (uint64_t) v34;
                TASSIGN(v735, v736);
                // pto: %small_pairs_inline3888__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v737 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_inline3888__ssa_v2
                ;
                uint64_t v738 = (uint64_t) v33;
                TASSIGN(v737, v738);
                // pto: %244
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v739;
                TRESHAPE(v739, v733);
                // pto: %245
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v740;
                TRESHAPE(v740, v735);
                // pto: %246
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v741;
                TRESHAPE(v741, v737);
                pipe_barrier(PIPE_V);
                TSORT32(v741, v739, v740);
                // pto: %small_pairs_v1_inline3889__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v742 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_v1_inline3889__ssa_v2
                ;
                uint64_t v743 = (uint64_t) v34;
                TASSIGN(v742, v743);
                pipe_barrier(PIPE_V);
                TMRGSORT(v742, v737, v65);
                // pto: %small_pairs_v2_inline3890__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v744 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_v2_inline3890__ssa_v2
                ;
                uint64_t v745 = (uint64_t) v33;
                TASSIGN(v744, v745);
                pipe_barrier(PIPE_V);
                TMRGSORT(v744, v742, v66);
                // pto: %small_left_inline3891__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v746 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_left_inline3891__ssa_v2
                ;
                uint64_t v747 = (uint64_t) v33;
                TASSIGN(v746, v747);
                // pto: %247
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v748;
                // pto: %247
                ;
                uint64_t v749 = (uint64_t) v33;
                TASSIGN(v748, v749);
                // pto: %small_right_inline3892__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v750 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_right_inline3892__ssa_v2
                ;
                uint64_t v751 = (uint64_t) v37;
                TASSIGN(v750, v751);
                // pto: %248
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v752;
                // pto: %248
                ;
                uint64_t v753 = (uint64_t) v37;
                TASSIGN(v752, v753);
                // pto: %small_tmp_inline3893__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v754 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %small_tmp_inline3893__ssa_v2
                ;
                uint64_t v755 = (uint64_t) v34;
                TASSIGN(v754, v755);
                // pto: %small_merged_inline3894__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v756 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_merged_inline3894__ssa_v2
                ;
                uint64_t v757 = (uint64_t) v35;
                TASSIGN(v756, v757);
                pipe_barrier(PIPE_V);
                TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v756, v29, v754, v748, v752);
                // pto: %single_new_root_inline3883__ssa_v11
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v758 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline3883__ssa_v11
                ;
                uint64_t v759 = (uint64_t) v36;
                TASSIGN(v758, v759);
                pipe_barrier(PIPE_V);
                uint16_t v760 = static_cast<uint16_t>(v42);
                uint16_t v761 = static_cast<uint16_t>(v42);
                TEXTRACT(v758, v756, v760, v761);
              } else {
                // pto: %t__ci_tmp_v8
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v762 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
                // pto: %t__ci_tmp_v8
                ;
                uint64_t v763 = (uint64_t) v34;
                TASSIGN(v762, v763);
                // pto: %t__tmp_v451
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v764 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v451
                ;
                uint64_t v765 = (uint64_t) v33;
                TASSIGN(v764, v765);
                // pto: %250
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v766;
                TRESHAPE(v766, v762);
                // pto: %251
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v767;
                TRESHAPE(v767, v764);
                TCI<Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v767, v64, v766);
                // pto: %large_indices_inline3895__ssa_v2
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v768 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %large_indices_inline3895__ssa_v2
                ;
                uint64_t v769 = (uint64_t) v33;
                TASSIGN(v768, v769);
                pipe_barrier(PIPE_V);
                TADDS(v768, v764, v687);
                // pto: %large_tile_inline3896__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v770 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %large_tile_inline3896__ssa_v2
                ;
                uint64_t v771 = (uint64_t) v34;
                TASSIGN(v770, v771);
                uint16_t v772 = static_cast<uint16_t>(v42);
                uint16_t v773 = static_cast<uint16_t>(v42);
                TEXTRACT(v770, v683, v772, v773);
                v770.SetValidShape(v38, v682);
                // pto: %t__tmp_v452
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v774 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v452
                ;
                uint64_t v775 = (uint64_t) v32;
                TASSIGN(v774, v775);
                pipe_barrier(PIPE_V);
                TFILLPAD(v774, v770);
                // pto: %large_scores_inline3898__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v776 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %large_scores_inline3898__ssa_v2
                ;
                uint64_t v777 = (uint64_t) v34;
                TASSIGN(v776, v777);
                pipe_barrier(PIPE_V);
                TMAXS(v776, v774, v56);
                // pto: %t__tmp_v453
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v778 = Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v453
                ;
                uint64_t v779 = (uint64_t) v33;
                TASSIGN(v778, v779);
                // pto: %large_pairs_inline3899__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v780 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_inline3899__ssa_v2
                ;
                uint64_t v781 = (uint64_t) v32;
                TASSIGN(v780, v781);
                // pto: %252
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v782;
                TRESHAPE(v782, v776);
                // pto: %253
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v783;
                TRESHAPE(v783, v778);
                // pto: %254
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v784;
                TRESHAPE(v784, v780);
                pipe_barrier(PIPE_V);
                TSORT32(v784, v782, v783);
                // pto: %large_pairs_v1_inline3900__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v785 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v1_inline3900__ssa_v2
                ;
                uint64_t v786 = (uint64_t) v33;
                TASSIGN(v785, v786);
                pipe_barrier(PIPE_V);
                TMRGSORT(v785, v780, v65);
                // pto: %large_pairs_v2_inline3901__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v787 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v2_inline3901__ssa_v2
                ;
                uint64_t v788 = (uint64_t) v32;
                TASSIGN(v787, v788);
                pipe_barrier(PIPE_V);
                TMRGSORT(v787, v785, v66);
                // pto: %large_pairs_v3_inline3902__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v789 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v3_inline3902__ssa_v2
                ;
                uint64_t v790 = (uint64_t) v33;
                TASSIGN(v789, v790);
                pipe_barrier(PIPE_V);
                TMRGSORT(v789, v787, v67);
                // pto: %single_new_root_inline3883__ssa_v12
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v791 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline3883__ssa_v12
                ;
                uint64_t v792 = (uint64_t) v34;
                TASSIGN(v791, v792);
                pipe_barrier(PIPE_V);
                uint16_t v793 = static_cast<uint16_t>(v42);
                uint16_t v794 = static_cast<uint16_t>(v42);
                TEXTRACT(v791, v789, v793, v794);
                // pto: %single_new_root_inline3883__ssa_v12_mv
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v795 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline3883__ssa_v12_mv
                ;
                uint64_t v796 = (uint64_t) v36;
                TASSIGN(v795, v796);
                pipe_barrier(PIPE_V);
                TMOV(v795, v791);
              };
            };
            // pto: %255
            ;
            if (v270 < v58) {
              // pto: %256
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v797;
              // pto: %256
              ;
              uint64_t v798 = (uint64_t) v27;
              TASSIGN(v797, v798);
              pipe_barrier(PIPE_V);
              TMOV(v797, v114);
            } else {
              // pto: %single_old_root_inline3903__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v799 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_old_root_inline3903__ssa_v2
              ;
              uint64_t v800 = (uint64_t) v35;
              TASSIGN(v799, v800);
              pipe_barrier(PIPE_V);
              uint16_t v801 = static_cast<uint16_t>(v58);
              uint16_t v802 = static_cast<uint16_t>(v42);
              TEXTRACT(v799, v104, v801, v802);
              // pto: %single_merge_tmp_inline3904__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v803 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
              // pto: %single_merge_tmp_inline3904__ssa_v2
              ;
              uint64_t v804 = (uint64_t) v32;
              TASSIGN(v803, v804);
              // pto: %single_merged_inline3905__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v805 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
              // pto: %single_merged_inline3905__ssa_v2
              ;
              uint64_t v806 = (uint64_t) v33;
              TASSIGN(v805, v806);
              pipe_barrier(PIPE_V);
              TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, false>(v805, v29, v803, v114, v799);
              // pto: %single_next_root_inline3906__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v807 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_next_root_inline3906__ssa_v2
              ;
              uint64_t v808 = (uint64_t) v32;
              TASSIGN(v807, v808);
              pipe_barrier(PIPE_V);
              uint16_t v809 = static_cast<uint16_t>(v42);
              uint16_t v810 = static_cast<uint16_t>(v42);
              TEXTRACT(v807, v805, v809, v810);
              // pto: %258
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v811;
              // pto: %258
              ;
              uint64_t v812 = (uint64_t) v27;
              TASSIGN(v811, v812);
              pipe_barrier(PIPE_V);
              TMOV(v811, v807);
            };
          };
        };
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      };
      // pto: %259
      ;
      int64_t v813 = (int64_t) ((uint64_t) v192 * (uint64_t) v48);
      // pto: %260
      ;
      if (v813 < v221) {
        // pto: %single_root_inline3908__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v814 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_root_inline3908__ssa_v0
        ;
        uint64_t v815 = (uint64_t) v31;
        TASSIGN(v814, v815);
        pipe_barrier(PIPE_V);
        uint16_t v816 = static_cast<uint16_t>(v42);
        uint16_t v817 = static_cast<uint16_t>(v42);
        TEXTRACT(v814, v266, v816, v817);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %263
        ;
        uint64_t v818 = (uint64_t) v196;
        // pto: %261, %262, %263
        ;
        int64_t v819 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v219 + (uint64_t) v813) * (uint64_t) v60) + v818);
        // pto: %264
        ;
        int64_t v820 = v819 < v42 ? v42 : v819;
        // pto: %pair_arena_inline3677__ssa_v0_pview
        ;
        __gm__ float* v821 = PTOAS__GLOBAL_TENSOR_DATA(v93);
        // pto: %pair_arena_inline3677__ssa_v0_pview
        ;
        const int64_t v822 = 0;
        // pto: %pair_arena_inline3677__ssa_v0_pview
        ;
        const int64_t v823 = 1024;
        // pto: %pair_arena_inline3677__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 1024> v824 = pto::Shape<1, 1, 1, 1, 1024>();
        // pto: %pair_arena_inline3677__ssa_v0_pview
        ;
        pto::Stride<1024, 1024, 1024, 1024, 1> v825 = pto::Stride<1024, 1024, 1024, 1024, 1>();
        // pto: %pair_arena_inline3677__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v826 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v821 + (v822 + v820 * v823), v824, v825);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v826, v814);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      // pto: %266
      ;
      int64_t v827 = (int64_t) ((uint64_t) v813 + (uint64_t) v38);
      // pto: %267
      ;
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      if (v827 < v221) {
        // pto: %single_root_inline3908__ssa_v1
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v828 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_root_inline3908__ssa_v1
        ;
        uint64_t v829 = (uint64_t) v31;
        TASSIGN(v828, v829);
        pipe_barrier(PIPE_V);
        uint16_t v830 = static_cast<uint16_t>(v38);
        uint16_t v831 = static_cast<uint16_t>(v42);
        TEXTRACT(v828, v266, v830, v831);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        // pto: %270
        ;
        uint64_t v832 = (uint64_t) v196;
        // pto: %268, %269, %270
        ;
        int64_t v833 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v219 + (uint64_t) v827) * (uint64_t) v60) + v832);
        // pto: %271
        ;
        int64_t v834 = v833 < v42 ? v42 : v833;
        // pto: %272
        ;
        __gm__ float* v835 = PTOAS__GLOBAL_TENSOR_DATA(v93);
        // pto: %272
        ;
        const int64_t v836 = 0;
        // pto: %272
        ;
        const int64_t v837 = 1024;
        // pto: %272
        ;
        pto::Shape<1, 1, 1, 1, 1024> v838 = pto::Shape<1, 1, 1, 1, 1024>();
        // pto: %272
        ;
        pto::Stride<1024, 1024, 1024, 1024, 1> v839 = pto::Stride<1024, 1024, 1024, 1024, 1>();
        // pto: %272
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v840 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v835 + (v836 + v834 * v837), v838, v839);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v840, v828);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      // pto: %274
      ;
      int64_t v841 = (int64_t) ((uint64_t) v813 + (uint64_t) v58);
      // pto: %275
      ;
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      if (v841 < v221) {
        // pto: %single_root_inline3908__ssa_v2
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v842 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_root_inline3908__ssa_v2
        ;
        uint64_t v843 = (uint64_t) v31;
        TASSIGN(v842, v843);
        pipe_barrier(PIPE_V);
        uint16_t v844 = static_cast<uint16_t>(v58);
        uint16_t v845 = static_cast<uint16_t>(v42);
        TEXTRACT(v842, v266, v844, v845);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        // pto: %278
        ;
        uint64_t v846 = (uint64_t) v196;
        // pto: %276, %277, %278
        ;
        int64_t v847 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v219 + (uint64_t) v841) * (uint64_t) v60) + v846);
        // pto: %279
        ;
        int64_t v848 = v847 < v42 ? v42 : v847;
        // pto: %280
        ;
        __gm__ float* v849 = PTOAS__GLOBAL_TENSOR_DATA(v93);
        // pto: %280
        ;
        const int64_t v850 = 0;
        // pto: %280
        ;
        const int64_t v851 = 1024;
        // pto: %280
        ;
        pto::Shape<1, 1, 1, 1, 1024> v852 = pto::Shape<1, 1, 1, 1, 1024>();
        // pto: %280
        ;
        pto::Stride<1024, 1024, 1024, 1024, 1> v853 = pto::Stride<1024, 1024, 1024, 1024, 1>();
        // pto: %280
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v854 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v849 + (v850 + v848 * v851), v852, v853);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        TSTORE(v854, v842);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    };
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}