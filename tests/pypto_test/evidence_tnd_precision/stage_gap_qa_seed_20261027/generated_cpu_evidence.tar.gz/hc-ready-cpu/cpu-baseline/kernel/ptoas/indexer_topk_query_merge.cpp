#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void indexer_topk_query_merge(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ int32_t* v3, __gm__ int32_t* v4, __gm__ float* v5, __gm__ float* v6, __gm__ int32_t* v7, int64_t v8, int64_t v9, int64_t v10, int32_t v11, int32_t v12) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  pto::MrgSortExecutedNumList v13 = pto::MrgSortExecutedNumList{0, 0, 0, 0};
  // pto: %c36864_i64
  const int64_t v14 = 36864;
  // pto: %c40960_i64
  const int64_t v15 = 40960;
  // pto: %c45056_i64
  const int64_t v16 = 45056;
  // pto: %c0_i64
  const int64_t v17 = 0;
  // pto: %c4096_i64
  const int64_t v18 = 4096;
  // pto: %c20480_i64
  const int64_t v19 = 20480;
  // pto: %c1_index
  const int64_t v20 = 1;
  // pto: %c27648_index
  const int64_t v21 = 27648;
  // pto: %c1024_index
  const int64_t v22 = 1024;
  // pto: %c512_index
  const int64_t v23 = 512;
  // pto: %c0_index
  const int64_t v24 = 0;
  // pto: %c5_index
  const int64_t v25 = 5;
  // pto: %c6_index
  const int64_t v26 = 6;
  // pto: %c4_index
  const int64_t v27 = 4;
  // pto: %c2_index
  const int64_t v28 = 2;
  // pto: %c262144_index
  const int64_t v29 = 262144;
  // pto: %c1023_index
  const int64_t v30 = 1023;
  // pto: %c8191_index
  const int64_t v31 = 8191;
  // pto: %c8192_index
  const int64_t v32 = 8192;
  // pto: %c3_index
  const int64_t v33 = 3;
  // pto: %c48_index
  const int64_t v34 = 48;
  // pto: %c24_index
  const int64_t v35 = 24;
  // pto: %c32_index
  const int64_t v36 = 32;
  // pto: %c8_index
  const int64_t v37 = 8;
  // pto: %c1_i64
  const int64_t v38 = 1;
  // pto: %c4_i64
  const int64_t v39 = 4;
  // pto: %c64_index
  const int64_t v40 = 64;
  // pto: %c4096_index
  const int64_t v41 = 4096;
  // pto: %c3072_index
  const int64_t v42 = 3072;
  // pto: %c2048_index
  const int64_t v43 = 2048;
  // pto: %cn1_i32
  const int32_t v44 = -1;
  // pto: %cst_31
  const float v45 = -3.40282347E+38f;
  // pto: %pair_arena__ssa_v0_view
  const int64_t v46 = 1;
  // pto: %pair_arena__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %pair_arena__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %pair_arena__ssa_v0_view
  int64_t v49 = v21 * v22;
  // pto: %pair_arena__ssa_v0_view
  int64_t v50 = v48 * v49;
  // pto: %pair_arena__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v51 = pto::Shape<1, 1, 1, -1, -1>(v46, v47, v48, v21, v22);
  // pto: %pair_arena__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v52 = pto::Stride<-1, -1, -1, -1, -1>(v47 * v50, v50, v49, v22, v20);
  // pto: %pair_arena__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v53 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v51, v52);
  // pto: %topk_scores__ssa_v0_view
  const int64_t v54 = 1;
  // pto: %topk_scores__ssa_v0_view
  const int64_t v55 = 1;
  // pto: %topk_scores__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %topk_scores__ssa_v0_view
  int64_t v57 = (int64_t) v8;
  // pto: %topk_scores__ssa_v0_view
  int64_t v58 = v57 * v23;
  // pto: %topk_scores__ssa_v0_view
  int64_t v59 = v56 * v58;
  // pto: %topk_scores__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v60 = pto::Shape<1, 1, 1, -1, -1>(v54, v55, v56, v57, v23);
  // pto: %topk_scores__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v61 = pto::Stride<-1, -1, -1, -1, -1>(v55 * v59, v59, v58, v23, v20);
  // pto: %topk_scores__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v62 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v60, v61);
  // pto: %topk_indices__ssa_v0_view
  const int64_t v63 = 1;
  // pto: %topk_indices__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %topk_indices__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %topk_indices__ssa_v0_view
  int64_t v66 = (int64_t) v8;
  // pto: %topk_indices__ssa_v0_view
  int64_t v67 = v66 * v23;
  // pto: %topk_indices__ssa_v0_view
  int64_t v68 = v65 * v67;
  // pto: %topk_indices__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v69 = pto::Shape<1, 1, 1, -1, -1>(v63, v64, v65, v66, v23);
  // pto: %topk_indices__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v70 = pto::Stride<-1, -1, -1, -1, -1>(v64 * v68, v68, v67, v23, v20);
  // pto: %topk_indices__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v71 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v69, v70);
  // pto: %root_inline5699__phi_v7
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v72 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
  // pto: %root_inline5699__phi_v7
  uint64_t v73 = (uint64_t) v14;
  TASSIGN(v72, v73);
  // pto: %root_inline5699__phi_v6
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v74 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
  // pto: %root_inline5699__phi_v6
  uint64_t v75 = (uint64_t) v14;
  TASSIGN(v74, v75);
  // pto: %worker__ssa_v0
  set_flag(PIPE_S, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_S, PIPE_V, EVENT_ID1);
  // pto: %count_inline5666__rv_v2
  int64_t v76;
  v76 = v24;
  for (int64_t v77 = v24; v77 < v9; v77 += v20) {
    // pto: %t__tile
    ;
    int32_t v78 = (v4)[v77];
    // pto: %2, %1
    ;
    int32_t v79 = (v4)[(int64_t) ((uint64_t) v77 + (uint64_t) v20)];
    // pto: %4
    ;
    int32_t v80 = (v2)[v77];
    // pto: %5, %6
    ;
    // pto: %count_inline5666__phi_v4
    ;
    int64_t v81;
    if ((int64_t) v80 > v24) {
      // pto: %3, %7, %0, %8
      ;
      int64_t v82 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v79) - (uint64_t) ((int64_t) v78)) + (uint64_t) v25);
      // pto: %9
      ;
      const int64_t v83 = 1;
      // pto: %9
      ;
      const int64_t v84 = 0;
      // pto: %9
      ;
      int64_t v85 = v82 / v26;
      // pto: %9
      ;
      bool v86 = v82 < v84;
      // pto: %9
      ;
      bool v87 = v26 < v84;
      // pto: %9
      ;
      bool v88 = v86 == v87;
      // pto: %9
      ;
      bool v89 = v82 % v26 != v84 && v86 != v87;
      // pto: %9
      ;
      int64_t v90 = v89 ? v85 - v83 : v85;
      // pto: %10
      ;
      uint64_t v91 = (uint64_t) v76;
      // pto: %10
      ;
      v81 = (int64_t) (v91 + (uint64_t) v90);
    } else {
      v81 = v76;
    };
    v76 = v81;
  }
  // pto: %11
  bool v92 = v76 >= v27;
  // pto: %max_cache_count__rv_v2
  int64_t v93;
  v93 = v24;
  for (int64_t v94 = v24; v94 < v9; v94 += v20) {
    // pto: %13
    ;
    int32_t v95 = (v2)[v94];
    // pto: %14
    ;
    int64_t v96 = (int64_t) v95;
    // pto: %15
    ;
    const int64_t v97 = 1;
    // pto: %15
    ;
    const int64_t v98 = 0;
    // pto: %15
    ;
    int64_t v99 = v96 / v27;
    // pto: %15
    ;
    bool v100 = v96 < v98;
    // pto: %15
    ;
    bool v101 = v27 < v98;
    // pto: %15
    ;
    bool v102 = v100 == v101;
    // pto: %15
    ;
    bool v103 = v96 % v27 != v98 && v100 != v101;
    // pto: %15
    ;
    int64_t v104 = v103 ? v99 - v97 : v99;
    // pto: %16
    ;
    bool v105 = v93 < v104;
    // pto: %16
    ;
    int64_t v106 = v105 ? v104 : v93;
    v93 = v106;
  }
  // pto: %count_inline5670__rv_v2
  int64_t v107;
  v107 = v24;
  for (int64_t v108 = v24; v108 < v9; v108 += v20) {
    // pto: %17
    ;
    int32_t v109 = (v4)[v108];
    // pto: %20, %19
    ;
    int32_t v110 = (v4)[(int64_t) ((uint64_t) v108 + (uint64_t) v20)];
    // pto: %22
    ;
    int32_t v111 = (v2)[v108];
    // pto: %23, %24
    ;
    // pto: %count_inline5670__phi_v4
    ;
    int64_t v112;
    if ((int64_t) v111 > v24) {
      // pto: %21, %25, %18, %26
      ;
      int64_t v113 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v110) - (uint64_t) ((int64_t) v109)) + (uint64_t) v20);
      // pto: %27
      ;
      const int64_t v114 = 1;
      // pto: %27
      ;
      const int64_t v115 = 0;
      // pto: %27
      ;
      int64_t v116 = v113 / v28;
      // pto: %27
      ;
      bool v117 = v113 < v115;
      // pto: %27
      ;
      bool v118 = v28 < v115;
      // pto: %27
      ;
      bool v119 = v117 == v118;
      // pto: %27
      ;
      bool v120 = v113 % v28 != v115 && v117 != v118;
      // pto: %27
      ;
      int64_t v121 = v120 ? v116 - v114 : v116;
      // pto: %28
      ;
      uint64_t v122 = (uint64_t) v107;
      // pto: %28
      ;
      v112 = (int64_t) (v122 + (uint64_t) v121);
    } else {
      v112 = v107;
    };
    v107 = v112;
  }
  // pto: %12, %29
  bool v123 = (int64_t) v92 == v20;
  // pto: %query_groups__phi_v2
  int64_t v124 = v123 ? v76 : v107;
  // pto: %30
  bool v125 = v93 < v29;
  // pto: %30
  int64_t v126 = v125 ? v93 : v29;
  // pto: %31
  int64_t v127 = (int64_t) ((uint64_t) v126 + (uint64_t) v30);
  // pto: %32
  const int64_t v128 = 1;
  // pto: %32
  const int64_t v129 = 0;
  // pto: %32
  int64_t v130 = v127 / v22;
  // pto: %32
  bool v131 = v127 < v129;
  // pto: %32
  bool v132 = v22 < v129;
  // pto: %32
  bool v133 = v131 == v132;
  // pto: %32
  bool v134 = v127 % v22 != v129 && v131 != v132;
  // pto: %32
  int64_t v135 = v134 ? v130 - v128 : v130;
  // pto: %34
  int64_t v136 = (int64_t) ((uint64_t) v126 + (uint64_t) v31);
  // pto: %35
  const int64_t v137 = 1;
  // pto: %35
  const int64_t v138 = 0;
  // pto: %35
  int64_t v139 = v136 / v32;
  // pto: %35
  bool v140 = v136 < v138;
  // pto: %35
  bool v141 = v32 < v138;
  // pto: %35
  bool v142 = v140 == v141;
  // pto: %35
  bool v143 = v136 % v32 != v138 && v140 != v141;
  // pto: %35
  int64_t v144 = v143 ? v139 - v137 : v139;
  // pto: %36
  int64_t v145 = v144 < v20 ? v20 : v144;
  // pto: %37
  int64_t v146 = (int64_t) ((uint64_t) v124 * (uint64_t) v33);
  // pto: %38
  // pto: %leaf_multiple_inline5678__phi_v6
  int64_t v147;
  if (v146 == v34) {
    v147 = v33;
  } else {
    // pto: %40
    ;
    // pto: %leaf_multiple_inline5678__phi_v5
    ;
    int64_t v148;
    if (v146 == v35) {
      v148 = v33;
    } else {
      // pto: %41, %42, %leaf_multiple_inline5678__phi_v4
      ;
      v148 = (int64_t) ((uint64_t) v124 * (uint64_t) v26) == v35 ? v26 : v20;
    };
    v147 = v148;
  }
  // pto: %43
  bool v149 = v147 > v20;
  // pto: %extra_leaves_inline5677__phi_v3
  int64_t v150;
  // pto: %leaf_tiles_inline5676__phi_v3
  int64_t v151;
  if (v149) {
    // pto: %44
    ;
    uint64_t v152 = (uint64_t) v147;
    // pto: %44, %45
    ;
    int64_t v153 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v145 + v152) - (uint64_t) v20);
    // pto: %46
    ;
    const int64_t v154 = 1;
    // pto: %46
    ;
    const int64_t v155 = 0;
    // pto: %46
    ;
    int64_t v156 = v153 / v147;
    // pto: %46
    ;
    int64_t v157 = v153 % v147;
    // pto: %46
    ;
    bool v158 = v153 < v155;
    // pto: %46
    ;
    bool v159 = v147 < v155;
    // pto: %46
    ;
    bool v160 = v158 == v159;
    // pto: %46
    ;
    bool v161 = v157 != v155 && v158 != v159;
    // pto: %46
    ;
    int64_t v162 = v161 ? v156 - v154 : v156;
    // pto: %47
    ;
    uint64_t v163 = (uint64_t) v147;
    // pto: %47
    ;
    int64_t v164 = (int64_t) ((uint64_t) v162 * v163);
    // pto: %48
    ;
    // pto: %extra_leaves_inline5677__phi_v2
    ;
    int64_t v165;
    // pto: %leaf_tiles_inline5676__phi_v2
    ;
    int64_t v166;
    if (v164 <= v36) {
      // pto: %49
      ;
      const int64_t v167 = 1;
      // pto: %49
      ;
      const int64_t v168 = 0;
      // pto: %49
      ;
      int64_t v169 = v135 / v164;
      // pto: %49
      ;
      bool v170 = v135 < v168;
      // pto: %49
      ;
      bool v171 = v164 < v168;
      // pto: %49
      ;
      bool v172 = v170 == v171;
      // pto: %49
      ;
      bool v173 = v135 % v164 != v168 && v170 != v171;
      // pto: %49
      ;
      int64_t v174 = v173 ? v169 - v167 : v169;
      // pto: %50
      ;
      // pto: %51
      ;
      int64_t v175 = v135 % v164;
      // pto: %52, %53, %54
      ;
      bool v176 = v175 < v24 ^ v164 < v24;
      // pto: %55, %56, %57, %58
      ;
      v165 = v175 != v24 & v176 ? (int64_t) ((uint64_t) v175 + (uint64_t) v164) : v175;
      v166 = v174 < v20 ? v20 : v174;
    } else {
      v165 = v24;
      v166 = v37;
    };
    v150 = v165;
    v151 = v166;
  } else {
    v150 = v24;
    v151 = v37;
  }
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  for (int64_t v177 = (int64_t) v11; v177 < v8; v177 += v34) {
    // pto: %59
    ;
    int32_t v178 = (v3)[v177];
    // pto: %60
    ;
    int64_t v179 = (int64_t) v178;
    // pto: %position_inline5681__tile
    ;
    int64_t v180 = (v1)[v177];
    // pto: %62
    ;
    int64_t v181 = v179 < v24 ? v24 : v179;
    // pto: %61
    ;
    int32_t v182 = (v2)[v181];
    // pto: %63
    ;
    int64_t v183 = (int64_t) v182;
    // pto: %64
    ;
    const int64_t v184 = 1;
    // pto: %64
    ;
    const int64_t v185 = 0;
    // pto: %64
    ;
    int64_t v186 = v183 / v27;
    // pto: %64
    ;
    bool v187 = v183 < v185;
    // pto: %64
    ;
    bool v188 = v27 < v185;
    // pto: %64
    ;
    bool v189 = v187 == v188;
    // pto: %64
    ;
    bool v190 = v183 % v27 != v185 && v187 != v188;
    // pto: %64
    ;
    int64_t v191 = v190 ? v186 - v184 : v186;
    // pto: %65, %cache_len_inline5682__phi_v2
    ;
    int64_t v192 = v179 < v24 ? v24 : v191;
    // pto: %66
    ;
    int64_t v193 = (int64_t) ((uint64_t) v180 + (uint64_t) v38);
    // pto: %67
    ;
    const int64_t v194 = 1;
    // pto: %67
    ;
    const int64_t v195 = 0;
    // pto: %67
    ;
    int64_t v196 = v193 / v39;
    // pto: %67
    ;
    bool v197 = v193 < v195;
    // pto: %67
    ;
    bool v198 = v39 < v195;
    // pto: %67
    ;
    bool v199 = v197 == v198;
    // pto: %67
    ;
    bool v200 = v193 % v39 != v195 && v197 != v198;
    // pto: %67
    ;
    int64_t v201 = v200 ? v196 - v194 : v196;
    // pto: %69
    ;
    int64_t v202 = v192 < v201 ? v192 : v201;
    // pto: %70
    ;
    int64_t v203 = v202 < v29 ? v202 : v29;
    // pto: %71
    ;
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    if (v203 > v24) {
      // pto: %72
      ;
      int64_t v204 = (int64_t) ((uint64_t) v203 + (uint64_t) v30);
      // pto: %73
      ;
      const int64_t v205 = 1;
      // pto: %73
      ;
      const int64_t v206 = 0;
      // pto: %73
      ;
      int64_t v207 = v204 / v22;
      // pto: %73
      ;
      bool v208 = v204 < v206;
      // pto: %73
      ;
      bool v209 = v22 < v206;
      // pto: %73
      ;
      bool v210 = v208 == v209;
      // pto: %73
      ;
      bool v211 = v204 % v22 != v206 && v208 != v209;
      // pto: %73
      ;
      int64_t v212 = v211 ? v207 - v205 : v207;
      // pto: %74
      ;
      uint64_t v213 = (uint64_t) v151;
      // pto: %74
      ;
      int64_t v214 = (int64_t) (v213 + (uint64_t) v20);
      // pto: %75
      ;
      uint64_t v215 = (uint64_t) v150;
      // pto: %76
      ;
      uint64_t v216 = (uint64_t) v151;
      // pto: %76
      ;
      int64_t v217 = (int64_t) ((uint64_t) v212 + v216);
      // pto: %78
      ;
      const int64_t v218 = 1;
      // pto: %78
      ;
      const int64_t v219 = 0;
      // pto: %78
      ;
      int64_t v220 = v217 / v214;
      // pto: %78
      ;
      bool v221 = v217 < v219;
      // pto: %78
      ;
      bool v222 = v214 < v219;
      // pto: %78
      ;
      bool v223 = v221 == v222;
      // pto: %78
      ;
      bool v224 = v217 % v214 != v219 && v221 != v222;
      // pto: %78
      ;
      int64_t v225 = v224 ? v220 - v218 : v220;
      // pto: %79
      ;
      bool v226 = v150 < v225;
      // pto: %79
      ;
      int64_t v227 = v226 ? v150 : v225;
      // pto: %80, %75
      ;
      int64_t v228 = (int64_t) ((uint64_t) v212 - (uint64_t) ((int64_t) v215 * (uint64_t) v214));
      // pto: %81
      ;
      int64_t v229 = v228 < v24 ? v24 : v228;
      // pto: %82
      ;
      uint64_t v230 = (uint64_t) v151;
      // pto: %82, %83
      ;
      int64_t v231 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v229 + v230) - (uint64_t) v20);
      // pto: %84
      ;
      const int64_t v232 = 1;
      // pto: %84
      ;
      const int64_t v233 = 0;
      // pto: %84
      ;
      int64_t v234 = v231 / v151;
      // pto: %84
      ;
      int64_t v235 = v231 % v151;
      // pto: %84
      ;
      bool v236 = v231 < v233;
      // pto: %84
      ;
      bool v237 = v151 < v233;
      // pto: %84
      ;
      bool v238 = v236 == v237;
      // pto: %84
      ;
      bool v239 = v235 != v233 && v236 != v237;
      // pto: %84
      ;
      int64_t v240 = v239 ? v234 - v232 : v234;
      // pto: %85
      ;
      int64_t v241 = (int64_t) ((uint64_t) v227 + (uint64_t) v240);
      // pto: %86, %half_count_inline5690__phi_v2
      ;
      int64_t v242 = v123 ? v241 : (int64_t) ((uint64_t) v241 * (uint64_t) v28);
      // pto: %88
      ;
      int64_t v243 = (int64_t) ((uint64_t) v177 * (uint64_t) v40);
      // pto: %root_inline5699__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v244 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
      // pto: %root_inline5699__ssa_v0
      ;
      uint64_t v245 = (uint64_t) v14;
      TASSIGN(v244, v245);
      // pto: %89
      ;
      int64_t v246 = v243 < v24 ? v24 : v243;
      // pto: %pair_arena__ssa_v0_pview
      ;
      __gm__ float* v247 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %pair_arena__ssa_v0_pview
      ;
      const int64_t v248 = 0;
      // pto: %pair_arena__ssa_v0_pview
      ;
      const int64_t v249 = 1024;
      // pto: %pair_arena__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 1024> v250 = pto::Shape<1, 1, 1, 1, 1024>();
      // pto: %pair_arena__ssa_v0_pview
      ;
      pto::Stride<1024, 1024, 1024, 1024, 1> v251 = pto::Stride<1024, 1024, 1024, 1024, 1>();
      // pto: %pair_arena__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v252 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v247 + (v248 + v246 * v249), v250, v251);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      TLOAD(v244, v252);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
      pipe_barrier(PIPE_ALL);
      for (int64_t v253 = v20; v253 < v242; v253 += v33) {
        // pto: %incoming1_inline5701__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v254 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
        // pto: %incoming1_inline5701__ssa_v0
        ;
        uint64_t v255 = (uint64_t) v15;
        TASSIGN(v254, v255);
        // pto: %90
        ;
        int64_t v256 = (int64_t) ((uint64_t) v243 + (uint64_t) v253);
        // pto: %91
        ;
        int64_t v257 = v256 < v24 ? v24 : v256;
        // pto: %92
        ;
        __gm__ float* v258 = PTOAS__GLOBAL_TENSOR_DATA(v53);
        // pto: %92
        ;
        const int64_t v259 = 0;
        // pto: %92
        ;
        const int64_t v260 = 1024;
        // pto: %92
        ;
        pto::Shape<1, 1, 1, 1, 1024> v261 = pto::Shape<1, 1, 1, 1, 1024>();
        // pto: %92
        ;
        pto::Stride<1024, 1024, 1024, 1024, 1> v262 = pto::Stride<1024, 1024, 1024, 1024, 1>();
        // pto: %92
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v263 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v258 + (v259 + v257 * v260), v261, v262);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
        TLOAD(v254, v263);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %93, %94
        ;
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        if ((int64_t) ((uint64_t) v253 + (uint64_t) v28) < v242) {
          // pto: %incoming2_inline5702__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v264 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
          // pto: %incoming2_inline5702__ssa_v0
          ;
          uint64_t v265 = (uint64_t) v16;
          TASSIGN(v264, v265);
          // pto: %96
          ;
          int64_t v266 = (int64_t) ((uint64_t) v256 + (uint64_t) v20);
          // pto: %97
          ;
          int64_t v267 = v266 < v24 ? v24 : v266;
          // pto: %98
          ;
          __gm__ float* v268 = PTOAS__GLOBAL_TENSOR_DATA(v53);
          // pto: %98
          ;
          const int64_t v269 = 0;
          // pto: %98
          ;
          const int64_t v270 = 1024;
          // pto: %98
          ;
          pto::Shape<1, 1, 1, 1, 1024> v271 = pto::Shape<1, 1, 1, 1, 1024>();
          // pto: %98
          ;
          pto::Stride<1024, 1024, 1024, 1024, 1> v272 = pto::Stride<1024, 1024, 1024, 1024, 1>();
          // pto: %98
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v273 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v268 + (v269 + v267 * v270), v271, v272);
          TLOAD(v264, v273);
          // pto: %incoming3_inline5703__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v274 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
          // pto: %incoming3_inline5703__ssa_v0
          ;
          uint64_t v275 = (uint64_t) v17;
          TASSIGN(v274, v275);
          // pto: %100
          ;
          int64_t v276 = (int64_t) ((uint64_t) v256 + (uint64_t) v28);
          // pto: %101
          ;
          int64_t v277 = v276 < v24 ? v24 : v276;
          // pto: %102
          ;
          __gm__ float* v278 = PTOAS__GLOBAL_TENSOR_DATA(v53);
          // pto: %102
          ;
          const int64_t v279 = 0;
          // pto: %102
          ;
          const int64_t v280 = 1024;
          // pto: %102
          ;
          pto::Shape<1, 1, 1, 1, 1024> v281 = pto::Shape<1, 1, 1, 1, 1024>();
          // pto: %102
          ;
          pto::Stride<1024, 1024, 1024, 1024, 1> v282 = pto::Stride<1024, 1024, 1024, 1024, 1>();
          // pto: %102
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v283 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v278 + (v279 + v277 * v280), v281, v282);
          TLOAD(v274, v283);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
          // pto: %merge_tmp4_inline5704__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v284 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v41);
          // pto: %merge_tmp4_inline5704__ssa_v0
          ;
          uint64_t v285 = (uint64_t) v18;
          TASSIGN(v284, v285);
          // pto: %merged4_inline5705__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v286 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v41);
          // pto: %merged4_inline5705__ssa_v0
          ;
          uint64_t v287 = (uint64_t) v19;
          TASSIGN(v286, v287);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
          pipe_barrier(PIPE_V);
          TMRGSORT<Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, true>(v286, v13, v284, v274, v264, v254, v244);
          // pto: %root_inline5699__ssa_v3
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v288 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
          // pto: %root_inline5699__ssa_v3
          ;
          uint64_t v289 = (uint64_t) v14;
          TASSIGN(v288, v289);
          pipe_barrier(PIPE_V);
          uint16_t v290 = static_cast<uint16_t>(v24);
          uint16_t v291 = static_cast<uint16_t>(v24);
          TEXTRACT(v288, v286, v290, v291);
        } else {
          // pto: %103, %104
          ;
          if ((int64_t) ((uint64_t) v253 + (uint64_t) v20) < v242) {
            // pto: %incoming2_inline5702__ssa_v1
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v292 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
            // pto: %incoming2_inline5702__ssa_v1
            ;
            uint64_t v293 = (uint64_t) v16;
            TASSIGN(v292, v293);
            // pto: %106
            ;
            int64_t v294 = (int64_t) ((uint64_t) v256 + (uint64_t) v20);
            // pto: %107
            ;
            int64_t v295 = v294 < v24 ? v24 : v294;
            // pto: %108
            ;
            __gm__ float* v296 = PTOAS__GLOBAL_TENSOR_DATA(v53);
            // pto: %108
            ;
            const int64_t v297 = 0;
            // pto: %108
            ;
            const int64_t v298 = 1024;
            // pto: %108
            ;
            pto::Shape<1, 1, 1, 1, 1024> v299 = pto::Shape<1, 1, 1, 1, 1024>();
            // pto: %108
            ;
            pto::Stride<1024, 1024, 1024, 1024, 1> v300 = pto::Stride<1024, 1024, 1024, 1024, 1>();
            // pto: %108
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v301 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v296 + (v297 + v295 * v298), v299, v300);
            TLOAD(v292, v301);
            set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
            // pto: %merge_tmp3_inline5706__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v302 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v42);
            // pto: %merge_tmp3_inline5706__ssa_v0
            ;
            uint64_t v303 = (uint64_t) v18;
            TASSIGN(v302, v303);
            // pto: %merged3_inline5707__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v304 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v42);
            // pto: %merged3_inline5707__ssa_v0
            ;
            uint64_t v305 = (uint64_t) v19;
            TASSIGN(v304, v305);
            wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
            pipe_barrier(PIPE_V);
            TMRGSORT<Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, true>(v304, v13, v302, v292, v254, v244);
            // pto: %root_inline5699__ssa_v4
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v306 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
            // pto: %root_inline5699__ssa_v4
            ;
            uint64_t v307 = (uint64_t) v14;
            TASSIGN(v306, v307);
            pipe_barrier(PIPE_V);
            uint16_t v308 = static_cast<uint16_t>(v24);
            uint16_t v309 = static_cast<uint16_t>(v24);
            TEXTRACT(v306, v304, v308, v309);
          } else {
            // pto: %merge_tmp2_inline5708__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v310 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v43);
            // pto: %merge_tmp2_inline5708__ssa_v0
            ;
            uint64_t v311 = (uint64_t) v18;
            TASSIGN(v310, v311);
            // pto: %merged2_inline5709__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v312 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v43);
            // pto: %merged2_inline5709__ssa_v0
            ;
            uint64_t v313 = (uint64_t) v19;
            TASSIGN(v312, v313);
            pipe_barrier(PIPE_V);
            TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, false>(v312, v13, v310, v254, v244);
            // pto: %root_inline5699__ssa_v5
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v314 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
            // pto: %root_inline5699__ssa_v5
            ;
            uint64_t v315 = (uint64_t) v14;
            TASSIGN(v314, v315);
            pipe_barrier(PIPE_V);
            uint16_t v316 = static_cast<uint16_t>(v24);
            uint16_t v317 = static_cast<uint16_t>(v24);
            TEXTRACT(v314, v312, v316, v317);
          };
        };
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      };
      // pto: %root_pairs_inline5692__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v318 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
      // pto: %root_pairs_inline5692__ssa_v0
      ;
      uint64_t v319 = (uint64_t) v14;
      TASSIGN(v318, v319);
      // pto: %root_scores_inline5695__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v320 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v23);
      // pto: %root_scores_inline5695__ssa_v0
      ;
      uint64_t v321 = (uint64_t) v18;
      TASSIGN(v320, v321);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      pipe_barrier(PIPE_ALL);
      wait_flag(PIPE_S, PIPE_V, EVENT_ID1);
      TGATHER<Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, MaskPattern::P0101>(v320, v318);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      // pto: %111
      ;
      int64_t v322 = v177 < v24 ? v24 : v177;
      // pto: %topk_scores__ssa_v0_pview
      ;
      __gm__ float* v323 = PTOAS__GLOBAL_TENSOR_DATA(v62);
      // pto: %topk_scores__ssa_v0_pview
      ;
      const int64_t v324 = 0;
      // pto: %topk_scores__ssa_v0_pview
      ;
      const int64_t v325 = 512;
      // pto: %topk_scores__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v326 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %topk_scores__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 512, 1> v327 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %topk_scores__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v328 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v323 + (v324 + v322 * v325), v326, v327);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v328, v320);
      // pto: %root_indices_inline5696__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v329 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v23);
      // pto: %root_indices_inline5696__ssa_v0
      ;
      uint64_t v330 = (uint64_t) v18;
      TASSIGN(v329, v330);
      pipe_barrier(PIPE_ALL);
      TGATHER<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, MaskPattern::P1010>(v329, v318);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      set_flag(PIPE_V, PIPE_S, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      // pto: %112
      ;
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
      if (v203 >= v23) {
        // pto: %topk_indices__ssa_v0_pview
        ;
        __gm__ int32_t* v331 = PTOAS__GLOBAL_TENSOR_DATA(v71);
        // pto: %topk_indices__ssa_v0_pview
        ;
        const int64_t v332 = 0;
        // pto: %topk_indices__ssa_v0_pview
        ;
        const int64_t v333 = 512;
        // pto: %topk_indices__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 512> v334 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %topk_indices__ssa_v0_pview
        ;
        pto::Stride<512, 512, 512, 512, 1> v335 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %topk_indices__ssa_v0_pview
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v336 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v331 + (v332 + v322 * v333), v334, v335);
        TSTORE(v336, v329);
      } else {
        // pto: %output_indices_inline5697__ssa_v0
        ;
        Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v337 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v23);
        // pto: %output_indices_inline5697__ssa_v0
        ;
        uint64_t v338 = (uint64_t) v19;
        TASSIGN(v337, v338);
        TEXPANDS(v337, v44);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        set_flag(PIPE_V, PIPE_S, EVENT_ID1);
        wait_flag(PIPE_V, PIPE_S, EVENT_ID1);
        for (int64_t v339 = v24; v339 < v203; v339 += v20) {
          // pto: %t__tmp_v12
          ;
          int32_t v340 = v329.GetValue(v339);
          v337.SetValue(v339, v340);
        };
        set_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
        // pto: %117
        ;
        __gm__ int32_t* v341 = PTOAS__GLOBAL_TENSOR_DATA(v71);
        // pto: %117
        ;
        const int64_t v342 = 0;
        // pto: %117
        ;
        const int64_t v343 = 512;
        // pto: %117
        ;
        pto::Shape<1, 1, 1, 1, 512> v344 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %117
        ;
        pto::Stride<512, 512, 512, 512, 1> v345 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %117
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v346 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v341 + (v342 + v322 * v343), v344, v345);
        wait_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        TSTORE(v346, v337);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
      set_flag(PIPE_S, PIPE_V, EVENT_ID1);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    } else {
      // pto: %t__tmp_v13
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v347 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v23);
      // pto: %t__tmp_v13
      ;
      uint64_t v348 = (uint64_t) v18;
      TASSIGN(v347, v348);
      pipe_barrier(PIPE_V);
      pipe_barrier(PIPE_ALL);
      TEXPANDS(v347, v45);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      // pto: %118
      ;
      int64_t v349 = v177 < v24 ? v24 : v177;
      // pto: %119
      ;
      __gm__ float* v350 = PTOAS__GLOBAL_TENSOR_DATA(v62);
      // pto: %119
      ;
      const int64_t v351 = 0;
      // pto: %119
      ;
      const int64_t v352 = 512;
      // pto: %119
      ;
      pto::Shape<1, 1, 1, 1, 512> v353 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %119
      ;
      pto::Stride<512, 512, 512, 512, 1> v354 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %119
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v355 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v350 + (v351 + v349 * v352), v353, v354);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      TSTORE(v355, v347);
      // pto: %t__tmp_v14
      ;
      Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v356 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v23);
      // pto: %t__tmp_v14
      ;
      uint64_t v357 = (uint64_t) v18;
      TASSIGN(v356, v357);
      pipe_barrier(PIPE_ALL);
      TEXPANDS(v356, v44);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
      // pto: %121
      ;
      __gm__ int32_t* v358 = PTOAS__GLOBAL_TENSOR_DATA(v71);
      // pto: %121
      ;
      const int64_t v359 = 0;
      // pto: %121
      ;
      const int64_t v360 = 512;
      // pto: %121
      ;
      pto::Shape<1, 1, 1, 1, 512> v361 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %121
      ;
      pto::Stride<512, 512, 512, 512, 1> v362 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %121
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v363 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v358 + (v359 + v349 * v360), v361, v362);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
      TSTORE(v363, v356);
    };
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID1);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}