#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void compress_state_commit(__gm__ float* v1, __gm__ int32_t* v2, __gm__ int32_t* v3, __gm__ int64_t* v4, __gm__ float* v5, __gm__ float* v6, __gm__ float* v7, int64_t v8, int64_t v9, int64_t v10, int64_t v11, int64_t v12, int64_t v13, int32_t v14, int32_t v15) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v16 = 0;
  // pto: %c4096_i64
  const int64_t v17 = 4096;
  // pto: %c1_index
  const int64_t v18 = 1;
  // pto: %c2_index
  const int64_t v19 = 2;
  // pto: %c384_index
  const int64_t v20 = 384;
  // pto: %c1024_index
  const int64_t v21 = 1024;
  // pto: %c4_index
  const int64_t v22 = 4;
  // pto: %c0_index
  const int64_t v23 = 0;
  // pto: %c2048_index
  const int64_t v24 = 2048;
  // pto: %c4_i64
  const int64_t v25 = 4;
  // pto: %compress_state__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %compress_state__ssa_v0_view
  const int64_t v27 = 1;
  // pto: %compress_state__ssa_v0_view
  const int64_t v28 = 1;
  // pto: %compress_state__ssa_v0_view
  int64_t v29 = (int64_t) v10;
  // pto: %compress_state__ssa_v0_view
  int64_t v30 = (int64_t) v11;
  // pto: %compress_state__ssa_v0_view
  int64_t v31 = v29 * v30;
  // pto: %compress_state__ssa_v0_view
  int64_t v32 = v28 * v31;
  // pto: %compress_state__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v33 = pto::Shape<1, 1, 1, -1, -1>(v26, v27, v28, v29, (int64_t) v11);
  // pto: %compress_state__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v34 = pto::Stride<-1, -1, -1, -1, -1>(v27 * v32, v32, v31, v30, v18);
  // pto: %compress_state__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v35 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v33, v34);
  // pto: %cmp4_kv_proj_pad_inline3287__ssa_v0_view
  const int64_t v36 = 1;
  // pto: %cmp4_kv_proj_pad_inline3287__ssa_v0_view
  const int64_t v37 = 1;
  // pto: %cmp4_kv_proj_pad_inline3287__ssa_v0_view
  const int64_t v38 = 1;
  // pto: %cmp4_kv_proj_pad_inline3287__ssa_v0_view
  int64_t v39 = v20 * v21;
  // pto: %cmp4_kv_proj_pad_inline3287__ssa_v0_view
  int64_t v40 = v38 * v39;
  // pto: %cmp4_kv_proj_pad_inline3287__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v41 = pto::Shape<1, 1, 1, -1, -1>(v36, v37, v38, v20, v21);
  // pto: %cmp4_kv_proj_pad_inline3287__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v42 = pto::Stride<-1, -1, -1, -1, -1>(v37 * v40, v40, v39, v21, v18);
  // pto: %cmp4_kv_proj_pad_inline3287__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v43 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v41, v42);
  // pto: %cmp4_score_proj_pad_inline3288__ssa_v0_view
  const int64_t v44 = 1;
  // pto: %cmp4_score_proj_pad_inline3288__ssa_v0_view
  const int64_t v45 = 1;
  // pto: %cmp4_score_proj_pad_inline3288__ssa_v0_view
  const int64_t v46 = 1;
  // pto: %cmp4_score_proj_pad_inline3288__ssa_v0_view
  int64_t v47 = v20 * v21;
  // pto: %cmp4_score_proj_pad_inline3288__ssa_v0_view
  int64_t v48 = v46 * v47;
  // pto: %cmp4_score_proj_pad_inline3288__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v49 = pto::Shape<1, 1, 1, -1, -1>(v44, v45, v46, v20, v21);
  // pto: %cmp4_score_proj_pad_inline3288__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v50 = pto::Stride<-1, -1, -1, -1, -1>(v45 * v48, v48, v47, v21, v18);
  // pto: %cmp4_score_proj_pad_inline3288__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v51 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v49, v50);
  // pto: %cmp_ape__ssa_v0_view
  const int64_t v52 = 1;
  // pto: %cmp_ape__ssa_v0_view
  const int64_t v53 = 1;
  // pto: %cmp_ape__ssa_v0_view
  const int64_t v54 = 1;
  // pto: %cmp_ape__ssa_v0_view
  int64_t v55 = v22 * v21;
  // pto: %cmp_ape__ssa_v0_view
  int64_t v56 = v54 * v55;
  // pto: %cmp_ape__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v57 = pto::Shape<1, 1, 1, -1, -1>(v52, v53, v54, v22, v21);
  // pto: %cmp_ape__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v58 = pto::Stride<-1, -1, -1, -1, -1>(v53 * v56, v56, v55, v21, v18);
  // pto: %cmp_ape__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v59 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v57, v58);
  // pto: %commit_worker_inline3290__ssa_v0
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v60 = (int64_t) v14; v60 < v8; v60 += v9) {
    // pto: %3
    ;
    int32_t v61 = (v2)[v60];
    // pto: %4
    ;
    // pto: %6, %5
    ;
    int32_t v62 = (v2)[(int64_t) ((uint64_t) v60 + (uint64_t) v18)];
    // pto: %7
    ;
    for (int64_t v63 = (int64_t) v61; v63 < ((int64_t) v62); v63 += v18) {
      // pto: %flat_offset_mul
      ;
      int64_t v64 = (int64_t) ((uint64_t) v63 * (uint64_t) v19);
      // pto: %state_page_inline3295__tile
      ;
      int32_t v65 = (v3)[v64];
      // pto: %9, %state_offset_inline3296__tile
      ;
      int32_t v66 = (v3)[(int64_t) ((uint64_t) v64 + (uint64_t) v18)];
      // pto: %10
      ;
      int64_t v67 = (int64_t) v65;
      // pto: %12
      ;
      int64_t v68 = (int64_t) v66;
      // pto: %11, %13, %14
      ;
      if (v67 >= v23 & v68 >= v23) {
        // pto: %token_pos_inline3297__tile
        ;
        int64_t v69 = (v4)[v63];
        // pto: %17
        ;
        int64_t v70 = (int64_t) ((uint64_t) v68 * (uint64_t) v24);
        // pto: %18
        ;
        int64_t v71 = v69 % v25;
        // pto: %19, %20, %21
        ;
        int64_t v72 = v71 < v16 ? (int64_t) ((uint64_t) v71 + (uint64_t) v25) : v71;
        // pto: %t__tile
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v73 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v21);
        // pto: %t__tile
        ;
        uint64_t v74 = (uint64_t) v16;
        TASSIGN(v73, v74);
        // pto: %23
        ;
        int64_t v75 = v63 < v23 ? v23 : v63;
        // pto: %cmp4_kv_proj_pad_inline3287__ssa_v0_pview
        ;
        __gm__ float* v76 = PTOAS__GLOBAL_TENSOR_DATA(v43);
        // pto: %cmp4_kv_proj_pad_inline3287__ssa_v0_pview
        ;
        const int64_t v77 = 0;
        // pto: %cmp4_kv_proj_pad_inline3287__ssa_v0_pview
        ;
        const int64_t v78 = 1024;
        // pto: %cmp4_kv_proj_pad_inline3287__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 1024> v79 = pto::Shape<1, 1, 1, 1, 1024>();
        // pto: %cmp4_kv_proj_pad_inline3287__ssa_v0_pview
        ;
        pto::Stride<1024, 1024, 1024, 1024, 1> v80 = pto::Stride<1024, 1024, 1024, 1024, 1>();
        // pto: %cmp4_kv_proj_pad_inline3287__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v81 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v76 + (v77 + v75 * v78), v79, v80);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
        TLOAD(v73, v81);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
        // pto: %24
        ;
        int64_t v82 = v67 < v23 ? v23 : v67;
        // pto: %25
        ;
        int64_t v83 = v70 < v23 ? v23 : v70;
        // pto: %compress_state__iter_v3_pview
        ;
        int64_t v84 = (int64_t) v11;
        // pto: %compress_state__iter_v3_pview
        ;
        const int64_t v85 = 0;
        // pto: %compress_state__iter_v3_pview
        ;
        __gm__ float* v86 = PTOAS__GLOBAL_TENSOR_DATA(v35);
        // pto: %compress_state__iter_v3_pview
        ;
        const int64_t v87 = 1;
        // pto: %compress_state__iter_v3_pview
        ;
        const int64_t v88 = 1;
        // pto: %compress_state__iter_v3_pview
        ;
        const int64_t v89 = 1;
        // pto: %compress_state__iter_v3_pview
        ;
        int64_t v90 = v18 * v84;
        // pto: %compress_state__iter_v3_pview
        ;
        int64_t v91 = v89 * v90;
        // pto: %compress_state__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, 1, 1024> v92 = pto::Shape<1, 1, 1, 1, 1024>(v87, v88, v89, v18, v21);
        // pto: %compress_state__iter_v3_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v93 = pto::Stride<-1, -1, -1, -1, -1>(v88 * v91, v91, v90, v84, v18);
        // pto: %compress_state__iter_v3_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v94 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v86 + (v85 + v82 * v84 + v83 * v18), v92, v93);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
        TSTORE(v94, v73);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
        // pto: %0
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v95 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v21);
        // pto: %0
        ;
        uint64_t v96 = (uint64_t) v16;
        TASSIGN(v95, v96);
        // pto: %cmp4_score_proj_pad_inline3288__ssa_v0_pview
        ;
        __gm__ float* v97 = PTOAS__GLOBAL_TENSOR_DATA(v51);
        // pto: %cmp4_score_proj_pad_inline3288__ssa_v0_pview
        ;
        const int64_t v98 = 0;
        // pto: %cmp4_score_proj_pad_inline3288__ssa_v0_pview
        ;
        const int64_t v99 = 1024;
        // pto: %cmp4_score_proj_pad_inline3288__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 1024> v100 = pto::Shape<1, 1, 1, 1, 1024>();
        // pto: %cmp4_score_proj_pad_inline3288__ssa_v0_pview
        ;
        pto::Stride<1024, 1024, 1024, 1024, 1> v101 = pto::Stride<1024, 1024, 1024, 1024, 1>();
        // pto: %cmp4_score_proj_pad_inline3288__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v102 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v97 + (v98 + v75 * v99), v100, v101);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
        TLOAD(v95, v102);
        // pto: %1
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v21);
        // pto: %1
        ;
        uint64_t v104 = (uint64_t) v17;
        TASSIGN(v103, v104);
        // pto: %27
        ;
        int64_t v105 = v72 < v23 ? v23 : v72;
        // pto: %cmp_ape__ssa_v0_pview
        ;
        __gm__ float* v106 = PTOAS__GLOBAL_TENSOR_DATA(v59);
        // pto: %cmp_ape__ssa_v0_pview
        ;
        const int64_t v107 = 0;
        // pto: %cmp_ape__ssa_v0_pview
        ;
        const int64_t v108 = 1024;
        // pto: %cmp_ape__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 1024> v109 = pto::Shape<1, 1, 1, 1, 1024>();
        // pto: %cmp_ape__ssa_v0_pview
        ;
        pto::Stride<1024, 1024, 1024, 1024, 1> v110 = pto::Stride<1024, 1024, 1024, 1024, 1>();
        // pto: %cmp_ape__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v111 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v106 + (v107 + v105 * v108), v109, v110);
        TLOAD(v103, v111);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %2
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v112 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v21);
        // pto: %2
        ;
        uint64_t v113 = (uint64_t) v16;
        TASSIGN(v112, v113);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        TADD(v112, v95, v103);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %30
        ;
        int64_t v114 = (int64_t) ((uint64_t) v70 + (uint64_t) v21);
        // pto: %31
        ;
        int64_t v115 = v114 < v23 ? v23 : v114;
        // pto: %compress_state__tile_pview
        ;
        int64_t v116 = (int64_t) v11;
        // pto: %compress_state__tile_pview
        ;
        const int64_t v117 = 0;
        // pto: %compress_state__tile_pview
        ;
        __gm__ float* v118 = PTOAS__GLOBAL_TENSOR_DATA(v35);
        // pto: %compress_state__tile_pview
        ;
        const int64_t v119 = 1;
        // pto: %compress_state__tile_pview
        ;
        const int64_t v120 = 1;
        // pto: %compress_state__tile_pview
        ;
        const int64_t v121 = 1;
        // pto: %compress_state__tile_pview
        ;
        int64_t v122 = v18 * v116;
        // pto: %compress_state__tile_pview
        ;
        int64_t v123 = v121 * v122;
        // pto: %compress_state__tile_pview
        ;
        pto::Shape<1, 1, 1, 1, 1024> v124 = pto::Shape<1, 1, 1, 1, 1024>(v119, v120, v121, v18, v21);
        // pto: %compress_state__tile_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v125 = pto::Stride<-1, -1, -1, -1, -1>(v120 * v123, v123, v122, v116, v18);
        // pto: %compress_state__tile_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v126 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v118 + (v117 + v82 * v116 + v115 * v18), v124, v125);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v126, v112);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      };
    };
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}