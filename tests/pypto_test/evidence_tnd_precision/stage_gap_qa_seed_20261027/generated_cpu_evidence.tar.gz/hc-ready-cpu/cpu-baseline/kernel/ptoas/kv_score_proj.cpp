#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void kv_score_proj(__gm__ int32_t* v1, __gm__ float* v2, __gm__ float* v3, __gm__ bfloat16_t* v4, __gm__ bfloat16_t* v5, __gm__ bfloat16_t* v6, int64_t v7, int64_t v8, int64_t v9, int64_t v10, int32_t v11, int32_t v12) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v13 = 0;
  // pto: %c8192_i64
  const int64_t v14 = 8192;
  // pto: %c16384_i64
  const int64_t v15 = 16384;
  // pto: %c24576_i64
  const int64_t v16 = 24576;
  // pto: %c32768_i64
  const int64_t v17 = 32768;
  // pto: %c49152_i64
  const int64_t v18 = 49152;
  // pto: %c57344_i64
  const int64_t v19 = 57344;
  // pto: %c1_index
  const int64_t v20 = 1;
  // pto: %c384_index
  const int64_t v21 = 384;
  // pto: %c1024_index
  const int64_t v22 = 1024;
  // pto: %c4096_index
  const int64_t v23 = 4096;
  // pto: %c0_index
  const int64_t v24 = 0;
  // pto: %c0_i32
  const int32_t v25 = 0;
  // pto: %c32_index
  const int64_t v26 = 32;
  // pto: %c64_index
  const int64_t v27 = 64;
  // pto: %c2_index
  const int64_t v28 = 2;
  // pto: %c24_index
  const int64_t v29 = 24;
  // pto: %c128_index
  const int64_t v30 = 128;
  // pto: %c512_index
  const int64_t v31 = 512;
  // pto: %c256_index
  const int64_t v32 = 256;
  // pto: %cmp4_kv_proj_pad_inline3216__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %cmp4_kv_proj_pad_inline3216__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %cmp4_kv_proj_pad_inline3216__ssa_v0_view
  const int64_t v35 = 1;
  // pto: %cmp4_kv_proj_pad_inline3216__ssa_v0_view
  int64_t v36 = v21 * v22;
  // pto: %cmp4_kv_proj_pad_inline3216__ssa_v0_view
  int64_t v37 = v35 * v36;
  // pto: %cmp4_kv_proj_pad_inline3216__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v38 = pto::Shape<1, 1, 1, -1, -1>(v33, v34, v35, v21, v22);
  // pto: %cmp4_kv_proj_pad_inline3216__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v39 = pto::Stride<-1, -1, -1, -1, -1>(v34 * v37, v37, v36, v22, v20);
  // pto: %cmp4_kv_proj_pad_inline3216__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v40 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v38, v39);
  // pto: %cmp4_score_proj_pad_inline3217__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %cmp4_score_proj_pad_inline3217__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %cmp4_score_proj_pad_inline3217__ssa_v0_view
  const int64_t v43 = 1;
  // pto: %cmp4_score_proj_pad_inline3217__ssa_v0_view
  int64_t v44 = v21 * v22;
  // pto: %cmp4_score_proj_pad_inline3217__ssa_v0_view
  int64_t v45 = v43 * v44;
  // pto: %cmp4_score_proj_pad_inline3217__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v46 = pto::Shape<1, 1, 1, -1, -1>(v41, v42, v43, v21, v22);
  // pto: %cmp4_score_proj_pad_inline3217__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v47 = pto::Stride<-1, -1, -1, -1, -1>(v42 * v45, v45, v44, v22, v20);
  // pto: %cmp4_score_proj_pad_inline3217__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v48 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v46, v47);
  // pto: %x_flat_inline3215__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %x_flat_inline3215__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %x_flat_inline3215__ssa_v0_view
  const int64_t v51 = 1;
  // pto: %x_flat_inline3215__ssa_v0_view
  int64_t v52 = (int64_t) v10;
  // pto: %x_flat_inline3215__ssa_v0_view
  int64_t v53 = v52 * v23;
  // pto: %x_flat_inline3215__ssa_v0_view
  int64_t v54 = v51 * v53;
  // pto: %x_flat_inline3215__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v55 = pto::Shape<1, 1, 1, -1, -1>(v49, v50, v51, v52, v23);
  // pto: %x_flat_inline3215__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v56 = pto::Stride<-1, -1, -1, -1, -1>(v50 * v54, v54, v53, v23, v20);
  // pto: %x_flat_inline3215__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v57 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v55, v56);
  // pto: %cmp_wkv__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %cmp_wkv__ssa_v0_view
  const int64_t v59 = 1;
  // pto: %cmp_wkv__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %cmp_wkv__ssa_v0_view
  int64_t v61 = v22 * v23;
  // pto: %cmp_wkv__ssa_v0_view
  int64_t v62 = v60 * v61;
  // pto: %cmp_wkv__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v63 = pto::Shape<1, 1, 1, -1, -1>(v58, v59, v60, v22, v23);
  // pto: %cmp_wkv__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v64 = pto::Stride<-1, -1, -1, -1, -1>(v59 * v62, v62, v61, v23, v20);
  // pto: %cmp_wkv__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v65 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v63, v64);
  // pto: %cmp_wgate__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %cmp_wgate__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %cmp_wgate__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %cmp_wgate__ssa_v0_view
  int64_t v69 = v22 * v23;
  // pto: %cmp_wgate__ssa_v0_view
  int64_t v70 = v68 * v69;
  // pto: %cmp_wgate__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v71 = pto::Shape<1, 1, 1, -1, -1>(v66, v67, v68, v22, v23);
  // pto: %cmp_wgate__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v67 * v70, v70, v69, v23, v20);
  // pto: %cmp_wgate__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v73 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v71, v72);
  // pto: %kv_acc_inline3225__phi_v5
  Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v74 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v27, v26);
  // pto: %kv_acc_inline3225__phi_v5
  uint64_t v75 = (uint64_t) v13;
  TASSIGN(v74, v75);
  // pto: %score_acc_inline3226__phi_v5
  Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v76 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v27, v26);
  // pto: %score_acc_inline3226__phi_v5
  uint64_t v77 = (uint64_t) v14;
  TASSIGN(v76, v77);
  // pto: %kv_worker_inline3219__ssa_v0
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  // pto: %t__tile
  int32_t v78 = (v1)[v20];
  // pto: %17
  int32_t v79 = (v1)[v24];
  // pto: %19
  // pto: %deviation_inline3233__rv_v2
  int32_t v80;
  v80 = v25;
  for (int64_t v81 = v20; v81 < ((int64_t) ((uint64_t) v9 - (uint64_t) v20)); v81 += v20) {
    // pto: %21, %20
    ;
    int32_t v82 = (v1)[(int64_t) ((uint64_t) v81 + (uint64_t) v20)];
    // pto: %22
    ;
    int32_t v83 = (v1)[v81];
    // pto: %23, %24, %18
    ;
    int32_t v84 = (int32_t) ((uint32_t) ((int32_t) (uint32_t) v82 - (uint32_t) v83) - (uint32_t) ((int32_t) (uint32_t) v78 - (uint32_t) v79));
    // pto: %26
    ;
    uint32_t v85 = (uint32_t) v80;
    // pto: %25, %26
    ;
    v80 = (int32_t) (v85 + (uint32_t) ((int32_t) (uint32_t) v84 * (uint32_t) v84));
  }
  // pto: %27
  int64_t v86 = (int64_t) v80;
  // pto: %28, %29, %30, %group_inline3237__phi_v4
  int64_t v87 = v86 == v24 & v7 <= v21 ? v26 : v27;
  // pto: %31
  const int64_t v88 = 1;
  // pto: %31
  const int64_t v89 = 0;
  // pto: %31
  int64_t v90 = v8 / v28;
  // pto: %31
  bool v91 = v8 < v89;
  // pto: %31
  bool v92 = v28 < v89;
  // pto: %31
  bool v93 = v91 == v92;
  // pto: %31
  bool v94 = v8 % v28 != v89 && v91 != v92;
  // pto: %31
  for (int64_t v95 = (int64_t) v11; v95 < (v94 ? v90 - v88 : v90); v95 += v29) {
    // pto: %32
    ;
    const int64_t v96 = 1;
    // pto: %32
    ;
    const int64_t v97 = 0;
    // pto: %32
    ;
    int64_t v98 = v95 / v26;
    // pto: %32
    ;
    bool v99 = v95 < v97;
    // pto: %32
    ;
    bool v100 = v26 < v97;
    // pto: %32
    ;
    bool v101 = v99 == v100;
    // pto: %32
    ;
    bool v102 = v95 % v26 != v97 && v99 != v100;
    // pto: %32
    ;
    int64_t v103 = v102 ? v98 - v96 : v98;
    // pto: %33
    ;
    int64_t v104 = (int64_t) ((uint64_t) v103 * (uint64_t) v27);
    // pto: %34
    ;
    int64_t v105 = v95 % v26;
    // pto: %35, %36, %37
    ;
    int64_t v106 = v105 < v24 ? (int64_t) ((uint64_t) v105 + (uint64_t) v26) : v105;
    // pto: %38
    ;
    int64_t v107 = (int64_t) ((uint64_t) v106 * (uint64_t) v26);
    // pto: %39
    ;
    int64_t v108 = (int64_t) ((uint64_t) v7 - (uint64_t) v104);
    // pto: %40
    ;
    int64_t v109 = v108 < v27 ? v108 : v27;
    // pto: %kv_acc_inline3225__tile_narrowed_storage
    ;
    Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v110 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v27, v26);
    // pto: %kv_acc_inline3225__tile_narrowed_storage
    ;
    uint64_t v111 = (uint64_t) v13;
    TASSIGN(v110, v111);
    v110.SetValidShape(v109, v26);
    // pto: %score_acc_inline3226__tile_narrowed_storage
    ;
    Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v112 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v27, v26);
    // pto: %score_acc_inline3226__tile_narrowed_storage
    ;
    uint64_t v113 = (uint64_t) v14;
    TASSIGN(v112, v113);
    v112.SetValidShape(v109, v26);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    for (int64_t v114 = v24; v114 < v26; v114 += v28) {
      // pto: %42
      ;
      int64_t v115 = v107 % v31;
      // pto: %43, %44, %45
      ;
      int64_t v116 = v115 < v24 ? (int64_t) ((uint64_t) v115 + (uint64_t) v31) : v115;
      // pto: %46
      ;
      const int64_t v117 = 1;
      // pto: %46
      ;
      const int64_t v118 = 0;
      // pto: %46
      ;
      int64_t v119 = v116 / v87;
      // pto: %46
      ;
      bool v120 = v116 < v118;
      // pto: %46
      ;
      bool v121 = v87 < v118;
      // pto: %46
      ;
      bool v122 = v120 == v121;
      // pto: %46
      ;
      bool v123 = v116 % v87 != v118 && v120 != v121;
      // pto: %46
      ;
      int64_t v124 = v123 ? v119 - v117 : v119;
      // pto: %41, %48, %47
      ;
      int64_t v125 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v114 * (uint64_t) v30) + (uint64_t) ((int64_t) (uint64_t) v124 * (uint64_t) v32));
      // pto: %49
      ;
      int64_t v126 = v125 % v23;
      // pto: %50, %51, %52
      ;
      int64_t v127 = v126 < v24 ? (int64_t) ((uint64_t) v126 + (uint64_t) v23) : v126;
      // pto: %61, %62
      ;
      int64_t v128 = (int64_t) ((uint64_t) v125 + (uint64_t) v30) % v23;
      // pto: %63, %64, %65
      ;
      int64_t v129 = v128 < v24 ? (int64_t) ((uint64_t) v128 + (uint64_t) v23) : v128;
      // pto: %x_tile_inline3229__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v109, v30);
      // pto: %x_tile_inline3229__tile
      ;
      uint64_t v131 = (uint64_t) v13;
      TASSIGN(v130, v131);
      // pto: %66
      ;
      int64_t v132 = v104 < v24 ? v24 : v104;
      // pto: %67
      ;
      int64_t v133 = v127 < v24 ? v24 : v127;
      // pto: %x_flat_inline3215__ssa_v0_pview
      ;
      const int64_t v134 = 0;
      // pto: %x_flat_inline3215__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v135 = PTOAS__GLOBAL_TENSOR_DATA(v57);
      // pto: %x_flat_inline3215__ssa_v0_pview
      ;
      const int64_t v136 = 1;
      // pto: %x_flat_inline3215__ssa_v0_pview
      ;
      const int64_t v137 = 1;
      // pto: %x_flat_inline3215__ssa_v0_pview
      ;
      const int64_t v138 = 1;
      // pto: %x_flat_inline3215__ssa_v0_pview
      ;
      int64_t v139 = v109 * v23;
      // pto: %x_flat_inline3215__ssa_v0_pview
      ;
      int64_t v140 = v138 * v139;
      // pto: %x_flat_inline3215__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 128> v141 = pto::Shape<1, 1, 1, -1, 128>(v136, v137, v138, v109, v30);
      // pto: %x_flat_inline3215__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v142 = pto::Stride<-1, -1, -1, -1, -1>(v137 * v140, v140, v139, v23, v20);
      // pto: %x_flat_inline3215__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v143 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v135 + (v134 + v132 * v23 + v133 * v20), v141, v142);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v130, v143);
      // pto: %wkv_tile_inline3230__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v144 = Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v26, v30);
      // pto: %wkv_tile_inline3230__tile
      ;
      uint64_t v145 = (uint64_t) v15;
      TASSIGN(v144, v145);
      // pto: %68
      ;
      int64_t v146 = v107 < v24 ? v24 : v107;
      // pto: %cmp_wkv__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v147 = PTOAS__GLOBAL_TENSOR_DATA(v65);
      // pto: %cmp_wkv__ssa_v0_pview
      ;
      const int64_t v148 = 0;
      // pto: %cmp_wkv__ssa_v0_pview
      ;
      const int64_t v149 = 4096;
      // pto: %cmp_wkv__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 32, 128> v150 = pto::Shape<1, 1, 1, 32, 128>();
      // pto: %cmp_wkv__ssa_v0_pview
      ;
      pto::Stride<131072, 131072, 131072, 4096, 1> v151 = pto::Stride<131072, 131072, 131072, 4096, 1>();
      // pto: %cmp_wkv__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND> v152 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND>(v147 + (v148 + v146 * v149 + v133), v150, v151);
      TLOAD(v144, v152);
      // pto: %wgate_tile_inline3231__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v153 = Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v26, v30);
      // pto: %wgate_tile_inline3231__tile
      ;
      uint64_t v154 = (uint64_t) v16;
      TASSIGN(v153, v154);
      // pto: %cmp_wgate__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v155 = PTOAS__GLOBAL_TENSOR_DATA(v73);
      // pto: %cmp_wgate__ssa_v0_pview
      ;
      const int64_t v156 = 0;
      // pto: %cmp_wgate__ssa_v0_pview
      ;
      const int64_t v157 = 4096;
      // pto: %cmp_wgate__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 32, 128> v158 = pto::Shape<1, 1, 1, 32, 128>();
      // pto: %cmp_wgate__ssa_v0_pview
      ;
      pto::Stride<131072, 131072, 131072, 4096, 1> v159 = pto::Stride<131072, 131072, 131072, 4096, 1>();
      // pto: %cmp_wgate__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND> v160 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND>(v155 + (v156 + v146 * v157 + v133), v158, v159);
      TLOAD(v153, v160);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %0
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v161 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v109, v30);
      // pto: %0
      ;
      uint64_t v162 = (uint64_t) v17;
      TASSIGN(v161, v162);
      // pto: %73
      ;
      int64_t v163 = v129 < v24 ? v24 : v129;
      // pto: %74
      ;
      const int64_t v164 = 0;
      // pto: %74
      ;
      __gm__ bfloat16_t* v165 = PTOAS__GLOBAL_TENSOR_DATA(v57);
      // pto: %74
      ;
      const int64_t v166 = 1;
      // pto: %74
      ;
      const int64_t v167 = 1;
      // pto: %74
      ;
      const int64_t v168 = 1;
      // pto: %74
      ;
      int64_t v169 = v109 * v23;
      // pto: %74
      ;
      int64_t v170 = v168 * v169;
      // pto: %74
      ;
      pto::Shape<1, 1, 1, -1, 128> v171 = pto::Shape<1, 1, 1, -1, 128>(v166, v167, v168, v109, v30);
      // pto: %74
      ;
      pto::Stride<-1, -1, -1, -1, -1> v172 = pto::Stride<-1, -1, -1, -1, -1>(v167 * v170, v170, v169, v23, v20);
      // pto: %74
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v173 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v165 + (v164 + v132 * v23 + v163 * v20), v171, v172);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v161, v173);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %1
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v174 = Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v26, v30);
      // pto: %1
      ;
      uint64_t v175 = (uint64_t) v18;
      TASSIGN(v174, v175);
      // pto: %77
      ;
      __gm__ bfloat16_t* v176 = PTOAS__GLOBAL_TENSOR_DATA(v65);
      // pto: %77
      ;
      const int64_t v177 = 0;
      // pto: %77
      ;
      const int64_t v178 = 4096;
      // pto: %77
      ;
      pto::Shape<1, 1, 1, 32, 128> v179 = pto::Shape<1, 1, 1, 32, 128>();
      // pto: %77
      ;
      pto::Stride<131072, 131072, 131072, 4096, 1> v180 = pto::Stride<131072, 131072, 131072, 4096, 1>();
      // pto: %77
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND> v181 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND>(v176 + (v177 + v146 * v178 + v163), v179, v180);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v174, v181);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      // pto: %2
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v182 = Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v26, v30);
      // pto: %2
      ;
      uint64_t v183 = (uint64_t) v19;
      TASSIGN(v182, v183);
      // pto: %80
      ;
      __gm__ bfloat16_t* v184 = PTOAS__GLOBAL_TENSOR_DATA(v73);
      // pto: %80
      ;
      const int64_t v185 = 0;
      // pto: %80
      ;
      const int64_t v186 = 4096;
      // pto: %80
      ;
      pto::Shape<1, 1, 1, 32, 128> v187 = pto::Shape<1, 1, 1, 32, 128>();
      // pto: %80
      ;
      pto::Stride<131072, 131072, 131072, 4096, 1> v188 = pto::Stride<131072, 131072, 131072, 4096, 1>();
      // pto: %80
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND> v189 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND>(v184 + (v185 + v146 * v186 + v163), v187, v188);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v182, v189);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %81
      ;
      v74.SetValidShape(v109, v26);
      v76.SetValidShape(v109, v26);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      if (v114 == v24) {
        // pto: %wkv_tile_inline3230__tile_t
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v190 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v26);
        // pto: %wkv_tile_inline3230__tile_t
        ;
        uint64_t v191 = (uint64_t) v15;
        TASSIGN(v190, v191);
        // pto: %x_tile_inline3229__tile_Left
        ;
        Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v192 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v109, v30);
        // pto: %x_tile_inline3229__tile_Left
        ;
        uint64_t v193 = (uint64_t) v13;
        TASSIGN(v192, v193);
        TMOV(v192, v130);
        // pto: %wkv_tile_inline3230__tile_t_Right
        ;
        Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v194 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v26);
        // pto: %wkv_tile_inline3230__tile_t_Right
        ;
        uint64_t v195 = (uint64_t) v13;
        TASSIGN(v194, v195);
        TMOV(v194, v190);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %kv_acc_inline3225__tile
        ;
        Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v196 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v109, v26);
        // pto: %kv_acc_inline3225__tile
        ;
        uint64_t v197 = (uint64_t) v13;
        TASSIGN(v196, v197);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        TMATMUL(v196, v192, v194);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        // pto: %wgate_tile_inline3231__tile_t
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v198 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v26);
        // pto: %wgate_tile_inline3231__tile_t
        ;
        uint64_t v199 = (uint64_t) v16;
        TASSIGN(v198, v199);
        // pto: %wgate_tile_inline3231__tile_t_Right
        ;
        Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v200 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v26);
        // pto: %wgate_tile_inline3231__tile_t_Right
        ;
        uint64_t v201 = (uint64_t) v13;
        TASSIGN(v200, v201);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        TMOV(v200, v198);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %score_acc_inline3226__tile
        ;
        Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v202 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v109, v26);
        // pto: %score_acc_inline3226__tile
        ;
        uint64_t v203 = (uint64_t) v14;
        TASSIGN(v202, v203);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL(v202, v192, v200);
      } else {
        // pto: %3
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v204 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v26);
        // pto: %3
        ;
        uint64_t v205 = (uint64_t) v15;
        TASSIGN(v204, v205);
        // pto: %4
        ;
        Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v206 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v109, v30);
        // pto: %4
        ;
        uint64_t v207 = (uint64_t) v13;
        TASSIGN(v206, v207);
        TMOV(v206, v130);
        // pto: %5
        ;
        Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v208 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v26);
        // pto: %5
        ;
        uint64_t v209 = (uint64_t) v13;
        TASSIGN(v208, v209);
        TMOV(v208, v204);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        TMATMUL_ACC(v110, v110, v206, v208);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        // pto: %7
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v210 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v26);
        // pto: %7
        ;
        uint64_t v211 = (uint64_t) v16;
        TASSIGN(v210, v211);
        // pto: %8
        ;
        Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v212 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v26);
        // pto: %8
        ;
        uint64_t v213 = (uint64_t) v13;
        TASSIGN(v212, v213);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        TMOV(v212, v210);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        TMATMUL_ACC(v112, v112, v206, v212);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %10
      ;
      Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v214 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v26);
      // pto: %10
      ;
      uint64_t v215 = (uint64_t) v18;
      TASSIGN(v214, v215);
      // pto: %11
      ;
      Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v216 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v109, v30);
      // pto: %11
      ;
      uint64_t v217 = (uint64_t) v15;
      TASSIGN(v216, v217);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      TMOV(v216, v161);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %12
      ;
      Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v26);
      // pto: %12
      ;
      uint64_t v219 = (uint64_t) v14;
      TASSIGN(v218, v219);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      TMOV(v218, v214);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
      TMATMUL_ACC(v74, v74, v216, v218);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      // pto: %14
      ;
      Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v26);
      // pto: %14
      ;
      uint64_t v221 = (uint64_t) v19;
      TASSIGN(v220, v221);
      // pto: %15
      ;
      Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v222 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v26);
      // pto: %15
      ;
      uint64_t v223 = (uint64_t) v14;
      TASSIGN(v222, v223);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      TMOV(v222, v220);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
      TMATMUL_ACC(v76, v76, v216, v222);
    };
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %82
    ;
    int64_t v224 = v104 < v24 ? v24 : v104;
    // pto: %83
    ;
    int64_t v225 = v107 < v24 ? v24 : v107;
    // pto: %cmp4_kv_proj_pad_inline3216__iter_v1_pview
    ;
    const int64_t v226 = 0;
    // pto: %cmp4_kv_proj_pad_inline3216__iter_v1_pview
    ;
    __gm__ float* v227 = PTOAS__GLOBAL_TENSOR_DATA(v40);
    // pto: %cmp4_kv_proj_pad_inline3216__iter_v1_pview
    ;
    const int64_t v228 = 1;
    // pto: %cmp4_kv_proj_pad_inline3216__iter_v1_pview
    ;
    const int64_t v229 = 1;
    // pto: %cmp4_kv_proj_pad_inline3216__iter_v1_pview
    ;
    const int64_t v230 = 1;
    // pto: %cmp4_kv_proj_pad_inline3216__iter_v1_pview
    ;
    int64_t v231 = v109 * v22;
    // pto: %cmp4_kv_proj_pad_inline3216__iter_v1_pview
    ;
    int64_t v232 = v230 * v231;
    // pto: %cmp4_kv_proj_pad_inline3216__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, -1, 32> v233 = pto::Shape<1, 1, 1, -1, 32>(v228, v229, v230, v109, v26);
    // pto: %cmp4_kv_proj_pad_inline3216__iter_v1_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v234 = pto::Stride<-1, -1, -1, -1, -1>(v229 * v232, v232, v231, v22, v20);
    // pto: %cmp4_kv_proj_pad_inline3216__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v235 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v227 + (v226 + v224 * v22 + v225 * v20), v233, v234);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE(v235, v110);
    // pto: %cmp4_score_proj_pad_inline3217__iter_v1_pview
    ;
    const int64_t v236 = 0;
    // pto: %cmp4_score_proj_pad_inline3217__iter_v1_pview
    ;
    __gm__ float* v237 = PTOAS__GLOBAL_TENSOR_DATA(v48);
    // pto: %cmp4_score_proj_pad_inline3217__iter_v1_pview
    ;
    const int64_t v238 = 1;
    // pto: %cmp4_score_proj_pad_inline3217__iter_v1_pview
    ;
    const int64_t v239 = 1;
    // pto: %cmp4_score_proj_pad_inline3217__iter_v1_pview
    ;
    const int64_t v240 = 1;
    // pto: %cmp4_score_proj_pad_inline3217__iter_v1_pview
    ;
    int64_t v241 = v109 * v22;
    // pto: %cmp4_score_proj_pad_inline3217__iter_v1_pview
    ;
    int64_t v242 = v240 * v241;
    // pto: %cmp4_score_proj_pad_inline3217__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, -1, 32> v243 = pto::Shape<1, 1, 1, -1, 32>(v238, v239, v240, v109, v26);
    // pto: %cmp4_score_proj_pad_inline3217__iter_v1_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v244 = pto::Stride<-1, -1, -1, -1, -1>(v239 * v242, v242, v241, v22, v20);
    // pto: %cmp4_score_proj_pad_inline3217__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v245 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v237 + (v236 + v224 * v22 + v225 * v20), v243, v244);
    TSTORE(v245, v112);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}