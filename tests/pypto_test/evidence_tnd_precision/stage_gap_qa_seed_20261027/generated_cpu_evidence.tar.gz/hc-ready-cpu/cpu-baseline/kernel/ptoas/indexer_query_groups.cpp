#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void indexer_query_groups(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ float* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, __gm__ int32_t* v7, __gm__ int32_t* v8, __gm__ int32_t* v9, __gm__ int32_t* v10, __gm__ int32_t* v11, __gm__ int32_t* v12, int64_t v13, int64_t v14, int64_t v15) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v16 = 0;
  // pto: %c1_index
  const int64_t v17 = 1;
  // pto: %c512_index
  const int64_t v18 = 512;
  // pto: %c0_index
  const int64_t v19 = 0;
  // pto: %cst_5
  const float v20 = -3.40282347E+38f;
  // pto: %cn1_i32
  const int32_t v21 = -1;
  // pto: %c5_index
  const int64_t v22 = 5;
  // pto: %c6_index
  const int64_t v23 = 6;
  // pto: %c2_index
  const int64_t v24 = 2;
  // pto: %idx_topk_scores__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %idx_topk_scores__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %idx_topk_scores__ssa_v0_view
  const int64_t v27 = 1;
  // pto: %idx_topk_scores__ssa_v0_view
  int64_t v28 = (int64_t) v13;
  // pto: %idx_topk_scores__ssa_v0_view
  int64_t v29 = v28 * v18;
  // pto: %idx_topk_scores__ssa_v0_view
  int64_t v30 = v27 * v29;
  // pto: %idx_topk_scores__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v31 = pto::Shape<1, 1, 1, -1, -1>(v25, v26, v27, v28, v18);
  // pto: %idx_topk_scores__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v32 = pto::Stride<-1, -1, -1, -1, -1>(v26 * v30, v30, v29, v18, v17);
  // pto: %idx_topk_scores__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v33 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v31, v32);
  // pto: %idx_topk__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %idx_topk__ssa_v0_view
  const int64_t v35 = 1;
  // pto: %idx_topk__ssa_v0_view
  const int64_t v36 = 1;
  // pto: %idx_topk__ssa_v0_view
  int64_t v37 = (int64_t) v13;
  // pto: %idx_topk__ssa_v0_view
  int64_t v38 = v37 * v18;
  // pto: %idx_topk__ssa_v0_view
  int64_t v39 = v36 * v38;
  // pto: %idx_topk__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v40 = pto::Shape<1, 1, 1, -1, -1>(v34, v35, v36, v37, v18);
  // pto: %idx_topk__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v41 = pto::Stride<-1, -1, -1, -1, -1>(v35 * v39, v39, v38, v18, v17);
  // pto: %idx_topk__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v42 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v40, v41);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  for (int64_t v43 = v19; v43 < v13; v43 += v17) {
    // pto: %t__tile
    ;
    int32_t v44 = (v2)[v43];
    // pto: %0, %1
    ;
    if ((int64_t) v44 < v19) {
      // pto: %t__tmp_v322
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v45 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v18);
      // pto: %t__tmp_v322
      ;
      uint64_t v46 = (uint64_t) v16;
      TASSIGN(v45, v46);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      TEXPANDS(v45, v20);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      // pto: %2
      ;
      int64_t v47 = v43 < v19 ? v19 : v43;
      // pto: %idx_topk_scores__ssa_v0_pview
      ;
      __gm__ float* v48 = PTOAS__GLOBAL_TENSOR_DATA(v33);
      // pto: %idx_topk_scores__ssa_v0_pview
      ;
      const int64_t v49 = 0;
      // pto: %idx_topk_scores__ssa_v0_pview
      ;
      const int64_t v50 = 512;
      // pto: %idx_topk_scores__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v51 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %idx_topk_scores__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 512, 1> v52 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %idx_topk_scores__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v53 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v48 + (v49 + v47 * v50), v51, v52);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v53, v45);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      // pto: %t__tmp_v323
      ;
      Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v54 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v18);
      // pto: %t__tmp_v323
      ;
      uint64_t v55 = (uint64_t) v16;
      TASSIGN(v54, v55);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      TEXPANDS(v54, v21);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      // pto: %idx_topk__ssa_v0_pview
      ;
      __gm__ int32_t* v56 = PTOAS__GLOBAL_TENSOR_DATA(v42);
      // pto: %idx_topk__ssa_v0_pview
      ;
      const int64_t v57 = 0;
      // pto: %idx_topk__ssa_v0_pview
      ;
      const int64_t v58 = 512;
      // pto: %idx_topk__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v59 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %idx_topk__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 512, 1> v60 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %idx_topk__ssa_v0_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v61 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v56 + (v57 + v47 * v58), v59, v60);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      TSTORE(v61, v54);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    };
  }
  // pto: %count_inline3746__rv_v2
  int64_t v62;
  v62 = v19;
  for (int64_t v63 = v19; v63 < v14; v63 += v17) {
    // pto: %4
    ;
    int32_t v64 = (v6)[v63];
    // pto: %5
    ;
    int64_t v65 = (int64_t) v64;
    // pto: %7, %6
    ;
    int32_t v66 = (v6)[(int64_t) ((uint64_t) v63 + (uint64_t) v17)];
    // pto: %8
    ;
    int64_t v67 = (int64_t) v66;
    // pto: %9
    ;
    int32_t v68 = (v5)[v63];
    // pto: %10, %11
    ;
    // pto: %groups_here_inline3750__phi_v2
    ;
    int64_t v69;
    if ((int64_t) v68 > v19) {
      // pto: %12, %13
      ;
      int64_t v70 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v67 - (uint64_t) v65) + (uint64_t) v22);
      // pto: %14
      ;
      const int64_t v71 = 1;
      // pto: %14
      ;
      const int64_t v72 = 0;
      // pto: %14
      ;
      int64_t v73 = v70 / v23;
      // pto: %14
      ;
      bool v74 = v70 < v72;
      // pto: %14
      ;
      bool v75 = v23 < v72;
      // pto: %14
      ;
      bool v76 = v74 == v75;
      // pto: %14
      ;
      bool v77 = v70 % v23 != v72 && v74 != v75;
      // pto: %14
      ;
      v69 = v77 ? v73 - v71 : v73;
    } else {
      v69 = v19;
    };
    for (int64_t v78 = v19; v78 < v69; v78 += v17) {
      // pto: %16, %15
      ;
      int64_t v79 = (int64_t) ((uint64_t) v65 + (uint64_t) ((int64_t) (uint64_t) v78 * (uint64_t) v23));
      // pto: %17
      ;
      int32_t v80 = (int32_t) v79;
      // pto: %18
      ;
      uint64_t v81 = (uint64_t) v62;
      // pto: %18
      ;
      int64_t v82 = (int64_t) (v81 + (uint64_t) v78);
      (v7)[v82] = v80;
      // pto: %19
      ;
      int64_t v83 = (int64_t) ((uint64_t) v67 - (uint64_t) v79);
      // pto: %20
      ;
      int64_t v84 = v83 < v23 ? v83 : v23;
      // pto: %21
      ;
      int32_t v85 = (int32_t) v84;
      (v8)[v82] = v85;
    };
    // pto: %23
    ;
    uint64_t v86 = (uint64_t) v62;
    // pto: %23
    ;
    uint64_t v87 = (uint64_t) v69;
    // pto: %23
    ;
    v62 = (int64_t) (v86 + v87);
  }
  // pto: %24
  int32_t v88 = (int32_t) v62;
  (v9)[v19] = v88;
  // pto: %count_inline3753__rv_v2
  int64_t v89;
  v89 = v19;
  for (int64_t v90 = v19; v90 < v14; v90 += v17) {
    // pto: %25
    ;
    int32_t v91 = (v6)[v90];
    // pto: %26
    ;
    int64_t v92 = (int64_t) v91;
    // pto: %28, %27
    ;
    int32_t v93 = (v6)[(int64_t) ((uint64_t) v90 + (uint64_t) v17)];
    // pto: %29
    ;
    int64_t v94 = (int64_t) v93;
    // pto: %30
    ;
    int32_t v95 = (v5)[v90];
    // pto: %31, %32
    ;
    // pto: %groups_here_inline3757__phi_v2
    ;
    int64_t v96;
    if ((int64_t) v95 > v19) {
      // pto: %33, %34
      ;
      int64_t v97 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v94 - (uint64_t) v92) + (uint64_t) v17);
      // pto: %35
      ;
      const int64_t v98 = 1;
      // pto: %35
      ;
      const int64_t v99 = 0;
      // pto: %35
      ;
      int64_t v100 = v97 / v24;
      // pto: %35
      ;
      bool v101 = v97 < v99;
      // pto: %35
      ;
      bool v102 = v24 < v99;
      // pto: %35
      ;
      bool v103 = v101 == v102;
      // pto: %35
      ;
      bool v104 = v97 % v24 != v99 && v101 != v102;
      // pto: %35
      ;
      v96 = v104 ? v100 - v98 : v100;
    } else {
      v96 = v19;
    };
    for (int64_t v105 = v19; v105 < v96; v105 += v17) {
      // pto: %37, %36
      ;
      int64_t v106 = (int64_t) ((uint64_t) v92 + (uint64_t) ((int64_t) (uint64_t) v105 * (uint64_t) v24));
      // pto: %38
      ;
      int32_t v107 = (int32_t) v106;
      // pto: %39
      ;
      uint64_t v108 = (uint64_t) v89;
      // pto: %39
      ;
      int64_t v109 = (int64_t) (v108 + (uint64_t) v105);
      (v10)[v109] = v107;
      // pto: %40
      ;
      int64_t v110 = (int64_t) ((uint64_t) v94 - (uint64_t) v106);
      // pto: %41
      ;
      int64_t v111 = v110 < v24 ? v110 : v24;
      // pto: %42
      ;
      int32_t v112 = (int32_t) v111;
      (v11)[v109] = v112;
    };
    // pto: %44
    ;
    uint64_t v113 = (uint64_t) v89;
    // pto: %44
    ;
    uint64_t v114 = (uint64_t) v96;
    // pto: %44
    ;
    v89 = (int64_t) (v113 + v114);
  }
  // pto: %45
  int32_t v115 = (int32_t) v89;
  (v12)[v19] = v115;
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  dsb((mem_dsb_t)0);
  #endif // __DAV_VEC__

  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  dsb((mem_dsb_t)0);
  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}