#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qproj_dequant_rms_nope_rope(__gm__ bfloat16_t* v1, __gm__ float* v2, __gm__ float* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, __gm__ float* v7, int64_t v8, int64_t v9, int64_t v10, int64_t v11, int64_t v12, int64_t v13, int32_t v14, int32_t v15) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v16 = 256;
  // pto: %c79872_i64
  const int64_t v17 = 79872;
  // pto: %c79904_i64
  const int64_t v18 = 79904;
  // pto: %c81952_i64
  const int64_t v19 = 81952;
  // pto: %c0_i64
  const int64_t v20 = 0;
  // pto: %c2048_i64
  const int64_t v21 = 2048;
  // pto: %c18432_i64
  const int64_t v22 = 18432;
  // pto: %c20480_i64
  const int64_t v23 = 20480;
  // pto: %c36864_i64
  const int64_t v24 = 36864;
  // pto: %c38912_i64
  const int64_t v25 = 38912;
  const int64_t v26 = 39936;
  const int64_t v27 = 39168;
  const int64_t v28 = 40192;
  // pto: %c55296_i64
  const int64_t v29 = 55296;
  const int64_t v30 = 39424;
  const int64_t v31 = 40448;
  // pto: %c57344_i64
  const int64_t v32 = 57344;
  const int64_t v33 = 39680;
  const int64_t v34 = 40704;
  const int64_t v35 = 3840;
  // pto: %c59392_i64
  const int64_t v36 = 59392;
  const int64_t v37 = 60416;
  const int64_t v38 = 59648;
  const int64_t v39 = 60672;
  // pto: %c75776_i64
  const int64_t v40 = 75776;
  const int64_t v41 = 59904;
  const int64_t v42 = 60928;
  // pto: %c77824_i64
  const int64_t v43 = 77824;
  const int64_t v44 = 60160;
  const int64_t v45 = 61184;
  const int64_t v46 = 22272;
  const int64_t v47 = 21504;
  const int64_t v48 = 20736;
  const int64_t v49 = 21760;
  const int64_t v50 = 20992;
  const int64_t v51 = 22016;
  const int64_t v52 = 21248;
  // pto: %c32768_index
  const int64_t v53 = 32768;
  // pto: %c1_index
  const int64_t v54 = 1;
  // pto: %c512_index
  const int64_t v55 = 512;
  // pto: %c64_index
  const int64_t v56 = 64;
  // pto: %c384_index
  const int64_t v57 = 384;
  // pto: %c0_index
  const int64_t v58 = 0;
  // pto: %c96_index
  const int64_t v59 = 96;
  // pto: %c16_index
  const int64_t v60 = 16;
  // pto: %c4_index
  const int64_t v61 = 4;
  // pto: %c7_index
  const int64_t v62 = 7;
  // pto: %c8_index
  const int64_t v63 = 8;
  // pto: %c48_index
  const int64_t v64 = 48;
  // pto: %c2_index
  const int64_t v65 = 2;
  // pto: %cst_49
  const float v66 = 1.0f;
  // pto: %c128_index
  const int64_t v67 = 128;
  // pto: %c192_index
  const int64_t v68 = 192;
  // pto: %c448_index
  const int64_t v69 = 448;
  // pto: %cst_55
  const float v70 = 0.001953125f;
  // pto: %cst_56
  const float v71 = 9.99999997E-7f;
  // pto: %c0_i32
  const int32_t v72 = 0;
  // pto: %cst_58
  const float v73 = 0.5f;
  // pto: %cst_59
  const float v74 = 2.0f;
  // pto: %cst_60
  const float v75 = 64.0f;
  // pto: %q_flat_inline5114__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %q_flat_inline5114__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %q_flat_inline5114__ssa_v0_view
  const int64_t v78 = 1;
  // pto: %q_flat_inline5114__ssa_v0_view
  int64_t v79 = (int64_t) v10;
  // pto: %q_flat_inline5114__ssa_v0_view
  int64_t v80 = v79 * v53;
  // pto: %q_flat_inline5114__ssa_v0_view
  int64_t v81 = v78 * v80;
  // pto: %q_flat_inline5114__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v82 = pto::Shape<1, 1, 1, -1, -1>(v76, v77, v78, v79, v53);
  // pto: %q_flat_inline5114__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v83 = pto::Stride<-1, -1, -1, -1, -1>(v77 * v81, v81, v80, v53, v54);
  // pto: %q_flat_inline5114__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v84 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v82, v83);
  // pto: %qr_scale_pad_store_inline4921__rv_v2_view
  const int64_t v85 = 1;
  // pto: %qr_scale_pad_store_inline4921__rv_v2_view
  const int64_t v86 = 1;
  // pto: %qr_scale_pad_store_inline4921__rv_v2_view
  const int64_t v87 = 1;
  // pto: %qr_scale_pad_store_inline4921__rv_v2_view
  int64_t v88 = v55 * v54;
  // pto: %qr_scale_pad_store_inline4921__rv_v2_view
  int64_t v89 = v87 * v88;
  // pto: %qr_scale_pad_store_inline4921__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v90 = pto::Shape<1, 1, 1, -1, -1>(v85, v86, v87, v55, v54);
  // pto: %qr_scale_pad_store_inline4921__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v91 = pto::Stride<-1, -1, -1, -1, -1>(v86 * v89, v89, v88, v54, v55);
  // pto: %qr_scale_pad_store_inline4921__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v92 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v2, v90, v91);
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v93 = 1;
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v94 = 1;
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v96 = (int64_t) v11;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v97 = v96 * v56;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v98 = v95 * v97;
  // pto: %freqs_cos__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v99 = pto::Shape<1, 1, 1, -1, -1>(v93, v94, v95, v96, v56);
  // pto: %freqs_cos__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v100 = pto::Stride<-1, -1, -1, -1, -1>(v94 * v98, v98, v97, v56, v54);
  // pto: %freqs_cos__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v101 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v99, v100);
  // pto: %q_rope_sin_signed_inline4885__ssa_v0_view
  const int64_t v102 = 1;
  // pto: %q_rope_sin_signed_inline4885__ssa_v0_view
  const int64_t v103 = 1;
  // pto: %q_rope_sin_signed_inline4885__ssa_v0_view
  const int64_t v104 = 1;
  // pto: %q_rope_sin_signed_inline4885__ssa_v0_view
  int64_t v105 = (int64_t) v12;
  // pto: %q_rope_sin_signed_inline4885__ssa_v0_view
  int64_t v106 = v105 * v56;
  // pto: %q_rope_sin_signed_inline4885__ssa_v0_view
  int64_t v107 = v104 * v106;
  // pto: %q_rope_sin_signed_inline4885__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v108 = pto::Shape<1, 1, 1, -1, -1>(v102, v103, v104, v105, v56);
  // pto: %q_rope_sin_signed_inline4885__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v109 = pto::Stride<-1, -1, -1, -1, -1>(v103 * v107, v107, v106, v56, v54);
  // pto: %q_rope_sin_signed_inline4885__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v110 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v108, v109);
  // pto: %q_rope_swap_idx_inline4886__ssa_v0_view
  const int64_t v111 = 1;
  // pto: %q_rope_swap_idx_inline4886__ssa_v0_view
  const int64_t v112 = 1;
  // pto: %q_rope_swap_idx_inline4886__ssa_v0_view
  const int64_t v113 = 1;
  // pto: %q_rope_swap_idx_inline4886__ssa_v0_view
  int64_t v114 = (int64_t) v12;
  // pto: %q_rope_swap_idx_inline4886__ssa_v0_view
  int64_t v115 = v114 * v56;
  // pto: %q_rope_swap_idx_inline4886__ssa_v0_view
  int64_t v116 = v113 * v115;
  // pto: %q_rope_swap_idx_inline4886__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v117 = pto::Shape<1, 1, 1, -1, -1>(v111, v112, v113, v114, v56);
  // pto: %q_rope_swap_idx_inline4886__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v118 = pto::Stride<-1, -1, -1, -1, -1>(v112 * v116, v116, v115, v56, v54);
  // pto: %q_rope_swap_idx_inline4886__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v119 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v117, v118);
  // pto: %q_proj_i32_inline5095__ssa_v9_view
  const int64_t v120 = 1;
  // pto: %q_proj_i32_inline5095__ssa_v9_view
  const int64_t v121 = 1;
  // pto: %q_proj_i32_inline5095__ssa_v9_view
  const int64_t v122 = 1;
  // pto: %q_proj_i32_inline5095__ssa_v9_view
  int64_t v123 = (int64_t) v13;
  // pto: %q_proj_i32_inline5095__ssa_v9_view
  int64_t v124 = v123 * v53;
  // pto: %q_proj_i32_inline5095__ssa_v9_view
  int64_t v125 = v122 * v124;
  // pto: %q_proj_i32_inline5095__ssa_v9_view
  pto::Shape<1, 1, 1, -1, -1> v126 = pto::Shape<1, 1, 1, -1, -1>(v120, v121, v122, v123, v53);
  // pto: %q_proj_i32_inline5095__ssa_v9_view
  pto::Stride<-1, -1, -1, -1, -1> v127 = pto::Stride<-1, -1, -1, -1, -1>(v121 * v125, v125, v124, v53, v54);
  // pto: %q_proj_i32_inline5095__ssa_v9_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v128 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v126, v127);
  // pto: %wq_b_scale__ssa_v0_view
  const int64_t v129 = 1;
  // pto: %wq_b_scale__ssa_v0_view
  const int64_t v130 = 1;
  // pto: %wq_b_scale__ssa_v0_view
  const int64_t v131 = 1;
  // pto: %wq_b_scale__ssa_v0_view
  const int64_t v132 = 1;
  // pto: %wq_b_scale__ssa_v0_view
  int64_t v133 = v53 * v54;
  // pto: %wq_b_scale__ssa_v0_view
  int64_t v134 = v132 * v133;
  // pto: %wq_b_scale__ssa_v0_view
  int64_t v135 = v131 * v134;
  // pto: %wq_b_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v136 = pto::Shape<1, 1, 1, 1, -1>(v129, v130, v131, v132, v53);
  // pto: %wq_b_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v137 = pto::Stride<-1, -1, -1, -1, -1>(v130 * v135, v135, v134, v133, v54);
  // pto: %wq_b_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v138 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v136, v137);
  // pto: %dq_worker_inline5115__ssa_v0
  // pto: %118
  int64_t v139 = v8 % v57;
  // pto: %119, %120, %121
  int64_t v140 = v139 < v58 ? (int64_t) ((uint64_t) v139 + (uint64_t) v57) : v139;
  // pto: %117, %122, %123
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  // pto: %dq_head_tile_inline5116__phi_v4
  int64_t v141;
  if (v8 >= v57 & v140 == v58) {
    v141 = v56;
  } else {
    // pto: %125
    ;
    int64_t v142 = v8 % v59;
    // pto: %126, %127, %128
    ;
    int64_t v143 = v142 < v58 ? (int64_t) ((uint64_t) v142 + (uint64_t) v59) : v142;
    // pto: %124, %129, %130, %dq_head_tile_inline5116__phi_v3
    ;
    v141 = v8 >= v59 & v143 == v58 ? v60 : v61;
  }
  // pto: %131
  int64_t v144 = (int64_t) ((uint64_t) v8 + (uint64_t) v62);
  // pto: %132
  const int64_t v145 = 1;
  // pto: %132
  const int64_t v146 = 0;
  // pto: %132
  int64_t v147 = v144 / v63;
  // pto: %132
  bool v148 = v144 < v146;
  // pto: %132
  bool v149 = v63 < v146;
  // pto: %132
  bool v150 = v148 == v149;
  // pto: %132
  bool v151 = v144 % v63 != v146 && v148 != v149;
  // pto: %132
  int64_t v152 = v151 ? v147 - v145 : v147;
  // pto: %133
  const int64_t v153 = 1;
  // pto: %133
  const int64_t v154 = 0;
  // pto: %133
  int64_t v155 = v56 / v141;
  // pto: %133
  int64_t v156 = v56 % v141;
  // pto: %133
  bool v157 = v56 < v154;
  // pto: %133
  bool v158 = v141 < v154;
  // pto: %133
  bool v159 = v157 == v158;
  // pto: %133
  bool v160 = v156 != v154 && v157 != v158;
  // pto: %133
  int64_t v161 = v160 ? v155 - v153 : v155;
  // pto: %134
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v162 = (int64_t) v14; v162 < ((int64_t) ((uint64_t) v152 * (uint64_t) v161)); v162 += v64) {
    // pto: %136
    ;
    int64_t v163 = v162 % v161;
    // pto: %137, %138, %139
    ;
    bool v164 = v163 < v58 ^ v161 < v58;
    // pto: %140, %141, %142, %143
    ;
    int64_t v165 = v163 != v58 & v164 ? (int64_t) ((uint64_t) v163 + (uint64_t) v161) : v163;
    // pto: %144
    ;
    uint64_t v166 = (uint64_t) v141;
    // pto: %144
    ;
    int64_t v167 = (int64_t) ((uint64_t) v165 * v166);
    // pto: %146
    ;
    const int64_t v168 = 1;
    // pto: %146
    ;
    const int64_t v169 = 0;
    // pto: %146
    ;
    int64_t v170 = v162 / v161;
    // pto: %146
    ;
    bool v171 = v162 < v169;
    // pto: %146
    ;
    bool v172 = v161 < v169;
    // pto: %146
    ;
    bool v173 = v171 == v172;
    // pto: %146
    ;
    bool v174 = v162 % v161 != v169 && v171 != v172;
    // pto: %146
    ;
    int64_t v175 = v174 ? v170 - v168 : v170;
    // pto: %147
    ;
    int64_t v176 = (int64_t) ((uint64_t) v175 * (uint64_t) v63);
    // pto: %148
    ;
    int64_t v177 = (int64_t) ((uint64_t) v9 + (uint64_t) v176);
    // pto: %149, %150
    ;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    if ((int64_t) ((uint64_t) v176 + (uint64_t) v63) <= v8) {
      // pto: %qr_scale_dq_t_inline5121__tile
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v178 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
      // pto: %qr_scale_dq_t_inline5121__tile
      ;
      uint64_t v179 = (uint64_t) v17;
      TASSIGN(v178, v179);
      // pto: %151
      ;
      int64_t v180 = v176 < v58 ? v58 : v176;
      // pto: %qr_scale_pad_store_inline4921__rv_v2_pview
      ;
      __gm__ float* v181 = PTOAS__GLOBAL_TENSOR_DATA(v92);
      // pto: %qr_scale_pad_store_inline4921__rv_v2_pview
      ;
      const int64_t v182 = 0;
      // pto: %qr_scale_pad_store_inline4921__rv_v2_pview
      ;
      pto::Shape<1, 1, 1, 8, 1> v183 = pto::Shape<1, 1, 1, 8, 1>();
      // pto: %qr_scale_pad_store_inline4921__rv_v2_pview
      ;
      pto::Stride<8, 8, 8, 1, 512> v184 = pto::Stride<8, 8, 8, 1, 512>();
      // pto: %qr_scale_pad_store_inline4921__rv_v2_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 512>, pto::Layout::DN> v185 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 512>, pto::Layout::DN>(v181 + (v182 + v180), v183, v184);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
      pipe_barrier(PIPE_ALL);
      TLOAD(v178, v185);
      // pto: %q_cos_il_inline5122__tile
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v186 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_cos_il_inline5122__tile
      ;
      uint64_t v187 = (uint64_t) v18;
      TASSIGN(v186, v187);
      // pto: %152
      ;
      int64_t v188 = v177 < v58 ? v58 : v177;
      // pto: %freqs_cos__ssa_v0_pview
      ;
      __gm__ float* v189 = PTOAS__GLOBAL_TENSOR_DATA(v101);
      // pto: %freqs_cos__ssa_v0_pview
      ;
      const int64_t v190 = 0;
      // pto: %freqs_cos__ssa_v0_pview
      ;
      const int64_t v191 = 64;
      // pto: %freqs_cos__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 64> v192 = pto::Shape<1, 1, 1, 8, 64>();
      // pto: %freqs_cos__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 64, 1> v193 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %freqs_cos__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v194 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v189 + (v190 + v188 * v191), v192, v193);
      pipe_barrier(PIPE_ALL);
      TLOAD(v186, v194);
      // pto: %q_sin_signed_inline5123__tile
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v195 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_sin_signed_inline5123__tile
      ;
      uint64_t v196 = (uint64_t) v19;
      TASSIGN(v195, v196);
      // pto: %q_rope_sin_signed_inline4885__ssa_v0_pview
      ;
      __gm__ float* v197 = PTOAS__GLOBAL_TENSOR_DATA(v110);
      // pto: %q_rope_sin_signed_inline4885__ssa_v0_pview
      ;
      const int64_t v198 = 0;
      // pto: %q_rope_sin_signed_inline4885__ssa_v0_pview
      ;
      const int64_t v199 = 64;
      // pto: %q_rope_sin_signed_inline4885__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 64> v200 = pto::Shape<1, 1, 1, 8, 64>();
      // pto: %q_rope_sin_signed_inline4885__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 64, 1> v201 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %q_rope_sin_signed_inline4885__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v202 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v197 + (v198 + v188 * v199), v200, v201);
      pipe_barrier(PIPE_ALL);
      TLOAD(v195, v202);
      // pto: %q_swap_idx_inline5124__tile
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v203 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_swap_idx_inline5124__tile
      ;
      uint64_t v204 = (uint64_t) v20;
      TASSIGN(v203, v204);
      // pto: %q_rope_swap_idx_inline4886__ssa_v0_pview
      ;
      __gm__ int32_t* v205 = PTOAS__GLOBAL_TENSOR_DATA(v119);
      // pto: %q_rope_swap_idx_inline4886__ssa_v0_pview
      ;
      const int64_t v206 = 0;
      // pto: %q_rope_swap_idx_inline4886__ssa_v0_pview
      ;
      const int64_t v207 = 64;
      // pto: %q_rope_swap_idx_inline4886__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 64> v208 = pto::Shape<1, 1, 1, 8, 64>();
      // pto: %q_rope_swap_idx_inline4886__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 64, 1> v209 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %q_rope_swap_idx_inline4886__ssa_v0_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v210 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v205 + (v206 + v188 * v207), v208, v209);
      TLOAD(v203, v210);
      // pto: %155
      ;
      const int64_t v211 = 1;
      // pto: %155
      ;
      const int64_t v212 = 0;
      // pto: %155
      ;
      int64_t v213 = v141 / v65;
      // pto: %155
      ;
      int64_t v214 = v141 % v65;
      // pto: %155
      ;
      bool v215 = v141 < v212;
      // pto: %155
      ;
      bool v216 = v65 < v212;
      // pto: %155
      ;
      bool v217 = v215 == v216;
      // pto: %155
      ;
      bool v218 = v214 != v212 && v215 != v216;
      // pto: %155
      ;
      int64_t v219 = v218 ? v213 - v211 : v213;
      // pto: %156
      ;
      int64_t v220 = (int64_t) ((uint64_t) v219 * (uint64_t) v65);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      for (int64_t v221 = v58; v221 < v220; v221 += v65) {
        // pto: %157, %158
        ;
        int64_t v222 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v167 + (uint64_t) v221) * (uint64_t) v55);
        // pto: %160, %159, %161
        ;
        int64_t v223 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v167 + (uint64_t) ((int64_t) (uint64_t) v221 + (uint64_t) v54)) * (uint64_t) v55);
        // pto: %q_head_acc_inline5128__tile
        ;
        Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v224 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_acc_inline5128__tile
        ;
        uint64_t v225 = (uint64_t) v21;
        TASSIGN(v224, v225);
        // pto: %163
        ;
        int64_t v226 = v222 < v58 ? v58 : v222;
        // pto: %q_proj_i32_inline5095__ssa_v9_pview
        ;
        __gm__ int32_t* v227 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %q_proj_i32_inline5095__ssa_v9_pview
        ;
        const int64_t v228 = 0;
        // pto: %q_proj_i32_inline5095__ssa_v9_pview
        ;
        const int64_t v229 = 32768;
        // pto: %q_proj_i32_inline5095__ssa_v9_pview
        ;
        pto::Shape<1, 1, 1, 8, 512> v230 = pto::Shape<1, 1, 1, 8, 512>();
        // pto: %q_proj_i32_inline5095__ssa_v9_pview
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v231 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %q_proj_i32_inline5095__ssa_v9_pview
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v232 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v227 + (v228 + v180 * v229 + v226), v230, v231);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        TLOAD(v224, v232);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %t__tile
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v233 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %t__tile
        ;
        uint64_t v234 = (uint64_t) v22;
        TASSIGN(v233, v234);
        // pto: %wq_b_scale__ssa_v0_pview
        ;
        __gm__ float* v235 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %wq_b_scale__ssa_v0_pview
        ;
        const int64_t v236 = 0;
        // pto: %wq_b_scale__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 512> v237 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %wq_b_scale__ssa_v0_pview
        ;
        pto::Stride<512, 512, 512, 512, 1> v238 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %wq_b_scale__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v239 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v235 + (v236 + v226), v237, v238);
        TLOAD(v233, v239);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        // pto: %0
        ;
        Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v240 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %0
        ;
        uint64_t v241 = (uint64_t) v23;
        TASSIGN(v240, v241);
        // pto: %166
        ;
        int64_t v242 = v223 < v58 ? v58 : v223;
        // pto: %167
        ;
        __gm__ int32_t* v243 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %167
        ;
        const int64_t v244 = 0;
        // pto: %167
        ;
        const int64_t v245 = 32768;
        // pto: %167
        ;
        pto::Shape<1, 1, 1, 8, 512> v246 = pto::Shape<1, 1, 1, 8, 512>();
        // pto: %167
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v247 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %167
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v248 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v243 + (v244 + v180 * v245 + v242), v246, v247);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
        TLOAD(v240, v248);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        // pto: %1
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v249 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %1
        ;
        uint64_t v250 = (uint64_t) v24;
        TASSIGN(v249, v250);
        // pto: %169
        ;
        __gm__ float* v251 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %169
        ;
        const int64_t v252 = 0;
        // pto: %169
        ;
        pto::Shape<1, 1, 1, 1, 512> v253 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %169
        ;
        pto::Stride<512, 512, 512, 512, 1> v254 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %169
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v255 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v251 + (v252 + v242), v253, v254);
        TLOAD(v249, v255);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
        // pto: %q_head_scale_inline5129__tile
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v256 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %q_head_scale_inline5129__tile
        ;
        uint64_t v257 = (uint64_t) v22;
        TASSIGN(v256, v257);
        // pto: %q_head_acc_fp32_inline5130__tile
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v258 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_acc_fp32_inline5130__tile
        ;
        uint64_t v259 = (uint64_t) v21;
        TASSIGN(v258, v259);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v260 = RoundMode::CAST_NONE;
        SaturationMode v261 = SaturationMode::ON;
        TCVT(v258, v224, v260, v261);
        // pto: %2
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v262 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %2
        ;
        uint64_t v263 = (uint64_t) v25;
        TASSIGN(v262, v263);
        TEXPANDS(v262, v66);
        // pto: %3
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v264 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %3
        ;
        uint64_t v265 = (uint64_t) v25;
        TASSIGN(v264, v265);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v264, v262, v178);
        // pto: %q_head_scale_combined_inline5131__tile
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v266 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_scale_combined_inline5131__tile
        ;
        uint64_t v267 = (uint64_t) v25;
        TASSIGN(v266, v267);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        TCOLEXPANDMUL(v266, v264, v256);
        // pto: %q_head_dq_inline5132__tile
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v268 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_dq_inline5132__tile
        ;
        uint64_t v269 = (uint64_t) v21;
        TASSIGN(v268, v269);
        pipe_barrier(PIPE_V);
        TMUL(v268, v258, v266);
        // pto: %4
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v270 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %4
        ;
        uint64_t v271 = (uint64_t) v25;
        TASSIGN(v270, v271);
        pipe_barrier(PIPE_V);
        RoundMode v272 = RoundMode::CAST_RINT;
        SaturationMode v273 = SaturationMode::ON;
        TCVT(v270, v268, v272, v273);
        // pto: %q_head_dq_v1_inline5133__tile
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v274 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_dq_v1_inline5133__tile
        ;
        uint64_t v275 = (uint64_t) v21;
        TASSIGN(v274, v275);
        pipe_barrier(PIPE_V);
        RoundMode v276 = RoundMode::CAST_ROUND;
        SaturationMode v277 = SaturationMode::ON;
        TCVT(v274, v270, v276, v277);
        // pto: %q_head_sq_inline5134__tile
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v278 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_sq_inline5134__tile
        ;
        uint64_t v279 = (uint64_t) v25;
        TASSIGN(v278, v279);
        pipe_barrier(PIPE_V);
        TMUL(v278, v274, v274);
        // pto: %5
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v280 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %5
        ;
        uint64_t v281 = (uint64_t) v25;
        TASSIGN(v280, v281);
        // pto: %slice_view
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v282;
        // pto: %slice_view
        ;
        uint64_t v283 = (uint64_t) v25;
        TASSIGN(v282, v283);
        // pto: %6
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v284 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %6
        ;
        uint64_t v285 = (uint64_t) v26;
        TASSIGN(v284, v285);
        // pto: %170
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v286;
        // pto: %170
        ;
        uint64_t v287 = (uint64_t) v26;
        TASSIGN(v286, v287);
        // pto: %q_sq_04_inline5135__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v288 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_04_inline5135__tile
        ;
        uint64_t v289 = (uint64_t) v22;
        TASSIGN(v288, v289);
        pipe_barrier(PIPE_V);
        TADD(v288, v282, v286);
        // pto: %7
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v290 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %7
        ;
        uint64_t v291 = (uint64_t) v27;
        TASSIGN(v290, v291);
        // pto: %171
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v292;
        // pto: %171
        ;
        uint64_t v293 = (uint64_t) v27;
        TASSIGN(v292, v293);
        // pto: %8
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v294 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %8
        ;
        uint64_t v295 = (uint64_t) v28;
        TASSIGN(v294, v295);
        // pto: %172
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v296;
        // pto: %172
        ;
        uint64_t v297 = (uint64_t) v28;
        TASSIGN(v296, v297);
        // pto: %q_sq_15_inline5136__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_15_inline5136__tile
        ;
        uint64_t v299 = (uint64_t) v29;
        TASSIGN(v298, v299);
        TADD(v298, v292, v296);
        // pto: %9
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v300 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %9
        ;
        uint64_t v301 = (uint64_t) v30;
        TASSIGN(v300, v301);
        // pto: %173
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v302;
        // pto: %173
        ;
        uint64_t v303 = (uint64_t) v30;
        TASSIGN(v302, v303);
        // pto: %10
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v304 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %10
        ;
        uint64_t v305 = (uint64_t) v31;
        TASSIGN(v304, v305);
        // pto: %174
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v306;
        // pto: %174
        ;
        uint64_t v307 = (uint64_t) v31;
        TASSIGN(v306, v307);
        // pto: %q_sq_26_inline5137__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v308 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_26_inline5137__tile
        ;
        uint64_t v309 = (uint64_t) v32;
        TASSIGN(v308, v309);
        TADD(v308, v302, v306);
        // pto: %11
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v310 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %11
        ;
        uint64_t v311 = (uint64_t) v33;
        TASSIGN(v310, v311);
        // pto: %175
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v312;
        // pto: %175
        ;
        uint64_t v313 = (uint64_t) v33;
        TASSIGN(v312, v313);
        // pto: %12
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v314 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %12
        ;
        uint64_t v315 = (uint64_t) v34;
        TASSIGN(v314, v315);
        // pto: %176
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v316;
        // pto: %176
        ;
        uint64_t v317 = (uint64_t) v34;
        TASSIGN(v316, v317);
        // pto: %q_sq_37_inline5138__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v318 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_37_inline5138__tile
        ;
        uint64_t v319 = (uint64_t) v25;
        TASSIGN(v318, v319);
        pipe_barrier(PIPE_V);
        TADD(v318, v312, v316);
        // pto: %q_sq_0246_inline5139__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v320 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_0246_inline5139__tile
        ;
        uint64_t v321 = (uint64_t) v22;
        TASSIGN(v320, v321);
        TADD(v320, v288, v308);
        // pto: %q_sq_1357_inline5140__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v322 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_1357_inline5140__tile
        ;
        uint64_t v323 = (uint64_t) v25;
        TASSIGN(v322, v323);
        pipe_barrier(PIPE_V);
        TADD(v322, v298, v318);
        // pto: %q_sq_64_inline5141__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v324 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_64_inline5141__tile
        ;
        uint64_t v325 = (uint64_t) v22;
        TASSIGN(v324, v325);
        pipe_barrier(PIPE_V);
        TADD(v324, v320, v322);
        // pto: %tmp_tile
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v326 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v67);
        // pto: %tmp_tile
        ;
        uint64_t v327 = (uint64_t) v25;
        TASSIGN(v326, v327);
        // pto: %q_head_sq_row_inline5142__tile
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v328 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %q_head_sq_row_inline5142__tile
        ;
        uint64_t v329 = (uint64_t) v29;
        TASSIGN(v328, v329);
        pipe_barrier(PIPE_V);
        TROWSUM(v328, v324, v326);
        // pto: %q_head_sq_sum_inline5143__tile
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v330 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_sq_sum_inline5143__tile
        ;
        uint64_t v331 = (uint64_t) v29;
        TASSIGN(v330, v331);
        // pto: %q_head_sq_mean_inline5144__tile
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v332 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_sq_mean_inline5144__tile
        ;
        uint64_t v333 = (uint64_t) v25;
        TASSIGN(v332, v333);
        pipe_barrier(PIPE_V);
        TMULS(v332, v330, v70);
        // pto: %q_head_var_inline5145__tile
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v334 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_var_inline5145__tile
        ;
        uint64_t v335 = (uint64_t) v25;
        TASSIGN(v334, v335);
        pipe_barrier(PIPE_V);
        TADDS(v334, v332, v71);
        // pto: %rsqrt_tmp
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v336 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %rsqrt_tmp
        ;
        uint64_t v337 = (uint64_t) v22;
        TASSIGN(v336, v337);
        // pto: %q_head_inv_rms_inline5146__tile
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v338 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_inv_rms_inline5146__tile
        ;
        uint64_t v339 = (uint64_t) v29;
        TASSIGN(v338, v339);
        pipe_barrier(PIPE_V);
        TRSQRT(v338, v334, v336);
        // pto: %q_head_inv_rms_t_inline5147__tile
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v340 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %q_head_inv_rms_t_inline5147__tile
        ;
        uint64_t v341 = (uint64_t) v29;
        TASSIGN(v340, v341);
        // pto: %13
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v342 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %13
        ;
        uint64_t v343 = (uint64_t) v21;
        TASSIGN(v342, v343);
        // pto: %177
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 448, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v344;
        // pto: %177
        ;
        uint64_t v345 = (uint64_t) v21;
        TASSIGN(v344, v345);
        // pto: %q_nope_normed_inline5148__tile
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v346 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %q_nope_normed_inline5148__tile
        ;
        uint64_t v347 = (uint64_t) v25;
        TASSIGN(v346, v347);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v346, v344, v340);
        // pto: %q_nope_bf16_inline5149__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v348 = Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %q_nope_bf16_inline5149__tile
        ;
        uint64_t v349 = (uint64_t) v25;
        TASSIGN(v348, v349);
        pipe_barrier(PIPE_V);
        RoundMode v350 = RoundMode::CAST_RINT;
        SaturationMode v351 = SaturationMode::ON;
        TCVT(v348, v346, v350, v351);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %q_rope_chunk_raw_inline5150__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v352 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_chunk_raw_inline5150__tile
        ;
        uint64_t v353 = (uint64_t) v35;
        TASSIGN(v352, v353);
        // pto: %178
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v354;
        // pto: %178
        ;
        uint64_t v355 = (uint64_t) v35;
        TASSIGN(v354, v355);
        // pto: %q_rope_chunk_inline5151__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v356 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_chunk_inline5151__tile
        ;
        uint64_t v357 = (uint64_t) v21;
        TASSIGN(v356, v357);
        TROWEXPANDMUL(v356, v354, v340);
        // pto: %14
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v358 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %14
        ;
        uint64_t v359 = (uint64_t) v22;
        TASSIGN(v358, v359);
        pipe_barrier(PIPE_V);
        RoundMode v360 = RoundMode::CAST_RINT;
        SaturationMode v361 = SaturationMode::ON;
        TCVT(v358, v356, v360, v361);
        // pto: %q_rope_chunk_v1_inline5152__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v362 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_chunk_v1_inline5152__tile
        ;
        uint64_t v363 = (uint64_t) v21;
        TASSIGN(v362, v363);
        pipe_barrier(PIPE_V);
        RoundMode v364 = RoundMode::CAST_ROUND;
        SaturationMode v365 = SaturationMode::ON;
        TCVT(v362, v358, v364, v365);
        // pto: %gather_acc_init
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v366 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %gather_acc_init
        ;
        uint64_t v367 = (uint64_t) v22;
        TASSIGN(v366, v367);
        for (int64_t v368 = v58; v368 < v63; v368 += v54) {
          // pto: %gather_inp_row
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v369 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %gather_inp_row
          ;
          uint64_t v370 = (uint64_t) v21;
          TASSIGN(v369, v370);
          // pto: %179
          ;
          int64_t v371 = (int64_t) ((uint64_t) v368 * (uint64_t) v16);
          // pto: %179
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v372;
          // pto: %179
          ;
          uint64_t v373 = (uint64_t) ((int64_t) (uint64_t) v371 + (uint64_t) v21);
          TASSIGN(v372, v373);
          // pto: %gather_idx_row
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v374 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %gather_idx_row
          ;
          uint64_t v375 = (uint64_t) v20;
          TASSIGN(v374, v375);
          // pto: %180
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v376;
          // pto: %180
          ;
          uint64_t v377 = (uint64_t) v371;
          TASSIGN(v376, v377);
          // pto: %gather_row_tmp
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v378 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %gather_row_tmp
          ;
          uint64_t v379 = (uint64_t) v29;
          TASSIGN(v378, v379);
          // pto: %gather_row
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v380 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %gather_row
          ;
          uint64_t v381 = (uint64_t) v32;
          TASSIGN(v380, v381);
          pipe_barrier(PIPE_V);
          TGATHER(v380, v372, v376, v378);
          // pto: %assemble_view
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v382;
          // pto: %assemble_view
          ;
          uint64_t v383 = (uint64_t) ((int64_t) (uint64_t) v371 + (uint64_t) v22);
          TASSIGN(v382, v383);
          pipe_barrier(PIPE_V);
          TMOV(v382, v380);
        };
        // pto: %q_rope_swapped_inline5153__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v384 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_swapped_inline5153__tile
        ;
        uint64_t v385 = (uint64_t) v22;
        TASSIGN(v384, v385);
        // pto: %q_rope_base_inline5154__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v386 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_base_inline5154__tile
        ;
        uint64_t v387 = (uint64_t) v21;
        TASSIGN(v386, v387);
        pipe_barrier(PIPE_V);
        TMUL(v386, v362, v186);
        // pto: %q_rope_delta_inline5155__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v388 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_delta_inline5155__tile
        ;
        uint64_t v389 = (uint64_t) v22;
        TASSIGN(v388, v389);
        TMUL(v388, v384, v195);
        // pto: %q_rope_rot_inline5156__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v390 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_rot_inline5156__tile
        ;
        uint64_t v391 = (uint64_t) v21;
        TASSIGN(v390, v391);
        pipe_barrier(PIPE_V);
        TADD(v390, v386, v388);
        // pto: %q_rope_bf16_inline5157__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v392 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_bf16_inline5157__tile
        ;
        uint64_t v393 = (uint64_t) v21;
        TASSIGN(v392, v393);
        pipe_barrier(PIPE_V);
        RoundMode v394 = RoundMode::CAST_RINT;
        SaturationMode v395 = SaturationMode::ON;
        TCVT(v392, v390, v394, v395);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        // pto: %q_flat_inline5114__iter_v3_pview
        ;
        __gm__ bfloat16_t* v396 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %q_flat_inline5114__iter_v3_pview
        ;
        const int64_t v397 = 0;
        // pto: %q_flat_inline5114__iter_v3_pview
        ;
        const int64_t v398 = 32768;
        // pto: %q_flat_inline5114__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, 8, 448> v399 = pto::Shape<1, 1, 1, 8, 448>();
        // pto: %q_flat_inline5114__iter_v3_pview
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v400 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %q_flat_inline5114__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v401 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v396 + (v397 + v188 * v398 + v226), v399, v400);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v401, v348);
        // pto: %185
        ;
        int64_t v402 = (int64_t) ((uint64_t) v222 + (uint64_t) v69);
        // pto: %186
        ;
        int64_t v403 = v402 < v58 ? v58 : v402;
        // pto: %q_flat_inline5114__tile_pview
        ;
        __gm__ bfloat16_t* v404 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %q_flat_inline5114__tile_pview
        ;
        const int64_t v405 = 0;
        // pto: %q_flat_inline5114__tile_pview
        ;
        const int64_t v406 = 32768;
        // pto: %q_flat_inline5114__tile_pview
        ;
        pto::Shape<1, 1, 1, 8, 64> v407 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %q_flat_inline5114__tile_pview
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v408 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %q_flat_inline5114__tile_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v409 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v404 + (v405 + v188 * v406 + v403), v407, v408);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v409, v392);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        // pto: %15
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v410 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %15
        ;
        uint64_t v411 = (uint64_t) v24;
        TASSIGN(v410, v411);
        // pto: %16
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v412 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %16
        ;
        uint64_t v413 = (uint64_t) v23;
        TASSIGN(v412, v413);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        RoundMode v414 = RoundMode::CAST_NONE;
        SaturationMode v415 = SaturationMode::ON;
        TCVT(v412, v240, v414, v415);
        // pto: %17
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v416 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %17
        ;
        uint64_t v417 = (uint64_t) v36;
        TASSIGN(v416, v417);
        TEXPANDS(v416, v66);
        // pto: %18
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v418 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %18
        ;
        uint64_t v419 = (uint64_t) v36;
        TASSIGN(v418, v419);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v418, v416, v178);
        // pto: %19
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v420 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %19
        ;
        uint64_t v421 = (uint64_t) v36;
        TASSIGN(v420, v421);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
        TCOLEXPANDMUL(v420, v418, v410);
        // pto: %20
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v422 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %20
        ;
        uint64_t v423 = (uint64_t) v23;
        TASSIGN(v422, v423);
        pipe_barrier(PIPE_V);
        TMUL(v422, v412, v420);
        // pto: %21
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v424 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %21
        ;
        uint64_t v425 = (uint64_t) v36;
        TASSIGN(v424, v425);
        pipe_barrier(PIPE_V);
        RoundMode v426 = RoundMode::CAST_RINT;
        SaturationMode v427 = SaturationMode::ON;
        TCVT(v424, v422, v426, v427);
        // pto: %22
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v428 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %22
        ;
        uint64_t v429 = (uint64_t) v23;
        TASSIGN(v428, v429);
        pipe_barrier(PIPE_V);
        RoundMode v430 = RoundMode::CAST_ROUND;
        SaturationMode v431 = SaturationMode::ON;
        TCVT(v428, v424, v430, v431);
        // pto: %23
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v432 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %23
        ;
        uint64_t v433 = (uint64_t) v36;
        TASSIGN(v432, v433);
        pipe_barrier(PIPE_V);
        TMUL(v432, v428, v428);
        // pto: %24
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v434 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %24
        ;
        uint64_t v435 = (uint64_t) v36;
        TASSIGN(v434, v435);
        // pto: %187
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v436;
        // pto: %187
        ;
        uint64_t v437 = (uint64_t) v36;
        TASSIGN(v436, v437);
        // pto: %25
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v438 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %25
        ;
        uint64_t v439 = (uint64_t) v37;
        TASSIGN(v438, v439);
        // pto: %188
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v440;
        // pto: %188
        ;
        uint64_t v441 = (uint64_t) v37;
        TASSIGN(v440, v441);
        // pto: %26
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v442 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %26
        ;
        uint64_t v443 = (uint64_t) v24;
        TASSIGN(v442, v443);
        pipe_barrier(PIPE_V);
        TADD(v442, v436, v440);
        // pto: %27
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v444 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %27
        ;
        uint64_t v445 = (uint64_t) v38;
        TASSIGN(v444, v445);
        // pto: %189
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v446;
        // pto: %189
        ;
        uint64_t v447 = (uint64_t) v38;
        TASSIGN(v446, v447);
        // pto: %28
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v448 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %28
        ;
        uint64_t v449 = (uint64_t) v39;
        TASSIGN(v448, v449);
        // pto: %190
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v450;
        // pto: %190
        ;
        uint64_t v451 = (uint64_t) v39;
        TASSIGN(v450, v451);
        // pto: %29
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v452 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %29
        ;
        uint64_t v453 = (uint64_t) v40;
        TASSIGN(v452, v453);
        TADD(v452, v446, v450);
        // pto: %30
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v454 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %30
        ;
        uint64_t v455 = (uint64_t) v41;
        TASSIGN(v454, v455);
        // pto: %191
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v456;
        // pto: %191
        ;
        uint64_t v457 = (uint64_t) v41;
        TASSIGN(v456, v457);
        // pto: %31
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v458 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %31
        ;
        uint64_t v459 = (uint64_t) v42;
        TASSIGN(v458, v459);
        // pto: %192
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v460;
        // pto: %192
        ;
        uint64_t v461 = (uint64_t) v42;
        TASSIGN(v460, v461);
        // pto: %32
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v462 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %32
        ;
        uint64_t v463 = (uint64_t) v43;
        TASSIGN(v462, v463);
        TADD(v462, v456, v460);
        // pto: %33
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v464 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %33
        ;
        uint64_t v465 = (uint64_t) v44;
        TASSIGN(v464, v465);
        // pto: %193
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v466;
        // pto: %193
        ;
        uint64_t v467 = (uint64_t) v44;
        TASSIGN(v466, v467);
        // pto: %34
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v468 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %34
        ;
        uint64_t v469 = (uint64_t) v45;
        TASSIGN(v468, v469);
        // pto: %194
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v470;
        // pto: %194
        ;
        uint64_t v471 = (uint64_t) v45;
        TASSIGN(v470, v471);
        // pto: %35
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v472 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %35
        ;
        uint64_t v473 = (uint64_t) v36;
        TASSIGN(v472, v473);
        pipe_barrier(PIPE_V);
        TADD(v472, v466, v470);
        // pto: %36
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v474 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %36
        ;
        uint64_t v475 = (uint64_t) v24;
        TASSIGN(v474, v475);
        TADD(v474, v442, v462);
        // pto: %37
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v476 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %37
        ;
        uint64_t v477 = (uint64_t) v36;
        TASSIGN(v476, v477);
        pipe_barrier(PIPE_V);
        TADD(v476, v452, v472);
        // pto: %38
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v478 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %38
        ;
        uint64_t v479 = (uint64_t) v24;
        TASSIGN(v478, v479);
        pipe_barrier(PIPE_V);
        TADD(v478, v474, v476);
        // pto: %39
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v480 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v67);
        // pto: %39
        ;
        uint64_t v481 = (uint64_t) v36;
        TASSIGN(v480, v481);
        // pto: %40
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v482 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %40
        ;
        uint64_t v483 = (uint64_t) v40;
        TASSIGN(v482, v483);
        pipe_barrier(PIPE_V);
        TROWSUM(v482, v478, v480);
        // pto: %41
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v484 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %41
        ;
        uint64_t v485 = (uint64_t) v40;
        TASSIGN(v484, v485);
        // pto: %42
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v486 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %42
        ;
        uint64_t v487 = (uint64_t) v36;
        TASSIGN(v486, v487);
        pipe_barrier(PIPE_V);
        TMULS(v486, v484, v70);
        // pto: %43
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v488 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %43
        ;
        uint64_t v489 = (uint64_t) v36;
        TASSIGN(v488, v489);
        pipe_barrier(PIPE_V);
        TADDS(v488, v486, v71);
        // pto: %44
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v490 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %44
        ;
        uint64_t v491 = (uint64_t) v24;
        TASSIGN(v490, v491);
        // pto: %45
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v492 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %45
        ;
        uint64_t v493 = (uint64_t) v40;
        TASSIGN(v492, v493);
        pipe_barrier(PIPE_V);
        TRSQRT(v492, v488, v490);
        // pto: %46
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v494 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %46
        ;
        uint64_t v495 = (uint64_t) v40;
        TASSIGN(v494, v495);
        // pto: %47
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v496 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %47
        ;
        uint64_t v497 = (uint64_t) v23;
        TASSIGN(v496, v497);
        // pto: %195
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 448, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v498;
        // pto: %195
        ;
        uint64_t v499 = (uint64_t) v23;
        TASSIGN(v498, v499);
        // pto: %48
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v500 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %48
        ;
        uint64_t v501 = (uint64_t) v36;
        TASSIGN(v500, v501);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v500, v498, v494);
        // pto: %49
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v502 = Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %49
        ;
        uint64_t v503 = (uint64_t) v36;
        TASSIGN(v502, v503);
        pipe_barrier(PIPE_V);
        RoundMode v504 = RoundMode::CAST_RINT;
        SaturationMode v505 = SaturationMode::ON;
        TCVT(v502, v500, v504, v505);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        // pto: %50
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v506 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %50
        ;
        uint64_t v507 = (uint64_t) v46;
        TASSIGN(v506, v507);
        // pto: %196
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v508;
        // pto: %196
        ;
        uint64_t v509 = (uint64_t) v46;
        TASSIGN(v508, v509);
        // pto: %51
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v510 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %51
        ;
        uint64_t v511 = (uint64_t) v23;
        TASSIGN(v510, v511);
        TROWEXPANDMUL(v510, v508, v494);
        // pto: %52
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v512 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %52
        ;
        uint64_t v513 = (uint64_t) v24;
        TASSIGN(v512, v513);
        pipe_barrier(PIPE_V);
        RoundMode v514 = RoundMode::CAST_RINT;
        SaturationMode v515 = SaturationMode::ON;
        TCVT(v512, v510, v514, v515);
        // pto: %53
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v516 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %53
        ;
        uint64_t v517 = (uint64_t) v23;
        TASSIGN(v516, v517);
        pipe_barrier(PIPE_V);
        RoundMode v518 = RoundMode::CAST_ROUND;
        SaturationMode v519 = SaturationMode::ON;
        TCVT(v516, v512, v518, v519);
        // pto: %54
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v520 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %54
        ;
        uint64_t v521 = (uint64_t) v24;
        TASSIGN(v520, v521);
        for (int64_t v522 = v58; v522 < v63; v522 += v54) {
          // pto: %55
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v523 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %55
          ;
          uint64_t v524 = (uint64_t) v23;
          TASSIGN(v523, v524);
          // pto: %198
          ;
          int64_t v525 = (int64_t) ((uint64_t) v522 * (uint64_t) v16);
          // pto: %198
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v526;
          // pto: %198
          ;
          uint64_t v527 = (uint64_t) ((int64_t) (uint64_t) v525 + (uint64_t) v23);
          TASSIGN(v526, v527);
          // pto: %56
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v528 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %56
          ;
          uint64_t v529 = (uint64_t) v20;
          TASSIGN(v528, v529);
          // pto: %199
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v530;
          // pto: %199
          ;
          uint64_t v531 = (uint64_t) v525;
          TASSIGN(v530, v531);
          // pto: %57
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v532 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %57
          ;
          uint64_t v533 = (uint64_t) v40;
          TASSIGN(v532, v533);
          // pto: %58
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v534 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %58
          ;
          uint64_t v535 = (uint64_t) v43;
          TASSIGN(v534, v535);
          pipe_barrier(PIPE_V);
          TGATHER(v534, v526, v530, v532);
          // pto: %200
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v536;
          // pto: %200
          ;
          uint64_t v537 = (uint64_t) ((int64_t) (uint64_t) v525 + (uint64_t) v24);
          TASSIGN(v536, v537);
          pipe_barrier(PIPE_V);
          TMOV(v536, v534);
        };
        // pto: %60
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v538 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %60
        ;
        uint64_t v539 = (uint64_t) v24;
        TASSIGN(v538, v539);
        // pto: %61
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v540 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %61
        ;
        uint64_t v541 = (uint64_t) v23;
        TASSIGN(v540, v541);
        pipe_barrier(PIPE_V);
        TMUL(v540, v516, v186);
        // pto: %62
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v542 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %62
        ;
        uint64_t v543 = (uint64_t) v24;
        TASSIGN(v542, v543);
        TMUL(v542, v538, v195);
        // pto: %63
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v544 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %63
        ;
        uint64_t v545 = (uint64_t) v23;
        TASSIGN(v544, v545);
        pipe_barrier(PIPE_V);
        TADD(v544, v540, v542);
        // pto: %64
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v546 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %64
        ;
        uint64_t v547 = (uint64_t) v23;
        TASSIGN(v546, v547);
        pipe_barrier(PIPE_V);
        RoundMode v548 = RoundMode::CAST_RINT;
        SaturationMode v549 = SaturationMode::ON;
        TCVT(v546, v544, v548, v549);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        // pto: %204
        ;
        __gm__ bfloat16_t* v550 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %204
        ;
        const int64_t v551 = 0;
        // pto: %204
        ;
        const int64_t v552 = 32768;
        // pto: %204
        ;
        pto::Shape<1, 1, 1, 8, 448> v553 = pto::Shape<1, 1, 1, 8, 448>();
        // pto: %204
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v554 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %204
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v555 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v550 + (v551 + v188 * v552 + v242), v553, v554);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v555, v502);
        // pto: %207
        ;
        int64_t v556 = (int64_t) ((uint64_t) v223 + (uint64_t) v69);
        // pto: %208
        ;
        int64_t v557 = v556 < v58 ? v58 : v556;
        // pto: %209
        ;
        __gm__ bfloat16_t* v558 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %209
        ;
        const int64_t v559 = 0;
        // pto: %209
        ;
        const int64_t v560 = 32768;
        // pto: %209
        ;
        pto::Shape<1, 1, 1, 8, 64> v561 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %209
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v562 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %209
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v563 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v558 + (v559 + v188 * v560 + v557), v561, v562);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        TSTORE(v563, v546);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
      // pto: %210
      ;
      uint64_t v564 = (uint64_t) v141;
      // pto: %210, %211
      ;
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
      if ((int64_t) (v564 - (uint64_t) v220) == v54) {
        // pto: %212, %213
        ;
        int64_t v565 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v167 + (uint64_t) v220) * (uint64_t) v55);
        // pto: %65
        ;
        Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v566 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %65
        ;
        uint64_t v567 = (uint64_t) v21;
        TASSIGN(v566, v567);
        // pto: %215
        ;
        int64_t v568 = v565 < v58 ? v58 : v565;
        // pto: %216
        ;
        __gm__ int32_t* v569 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %216
        ;
        const int64_t v570 = 0;
        // pto: %216
        ;
        const int64_t v571 = 32768;
        // pto: %216
        ;
        pto::Shape<1, 1, 1, 8, 512> v572 = pto::Shape<1, 1, 1, 8, 512>();
        // pto: %216
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v573 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %216
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v574 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v569 + (v570 + v180 * v571 + v568), v572, v573);
        TLOAD(v566, v574);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        // pto: %66
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v575 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %66
        ;
        uint64_t v576 = (uint64_t) v25;
        TASSIGN(v575, v576);
        // pto: %218
        ;
        __gm__ float* v577 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %218
        ;
        const int64_t v578 = 0;
        // pto: %218
        ;
        pto::Shape<1, 1, 1, 1, 512> v579 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %218
        ;
        pto::Stride<512, 512, 512, 512, 1> v580 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %218
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v581 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v577 + (v578 + v568), v579, v580);
        TLOAD(v575, v581);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        // pto: %67
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v582 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %67
        ;
        uint64_t v583 = (uint64_t) v25;
        TASSIGN(v582, v583);
        // pto: %68
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v584 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %68
        ;
        uint64_t v585 = (uint64_t) v21;
        TASSIGN(v584, v585);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        RoundMode v586 = RoundMode::CAST_NONE;
        SaturationMode v587 = SaturationMode::ON;
        TCVT(v584, v566, v586, v587);
        // pto: %69
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v588 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %69
        ;
        uint64_t v589 = (uint64_t) v23;
        TASSIGN(v588, v589);
        TEXPANDS(v588, v66);
        // pto: %70
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v590 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %70
        ;
        uint64_t v591 = (uint64_t) v23;
        TASSIGN(v590, v591);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v590, v588, v178);
        // pto: %71
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v592 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %71
        ;
        uint64_t v593 = (uint64_t) v23;
        TASSIGN(v592, v593);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        TCOLEXPANDMUL(v592, v590, v582);
        // pto: %72
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v594 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %72
        ;
        uint64_t v595 = (uint64_t) v21;
        TASSIGN(v594, v595);
        pipe_barrier(PIPE_V);
        TMUL(v594, v584, v592);
        // pto: %73
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v596 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %73
        ;
        uint64_t v597 = (uint64_t) v23;
        TASSIGN(v596, v597);
        pipe_barrier(PIPE_V);
        RoundMode v598 = RoundMode::CAST_RINT;
        SaturationMode v599 = SaturationMode::ON;
        TCVT(v596, v594, v598, v599);
        // pto: %74
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v600 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %74
        ;
        uint64_t v601 = (uint64_t) v21;
        TASSIGN(v600, v601);
        pipe_barrier(PIPE_V);
        RoundMode v602 = RoundMode::CAST_ROUND;
        SaturationMode v603 = SaturationMode::ON;
        TCVT(v600, v596, v602, v603);
        // pto: %75
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v604 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %75
        ;
        uint64_t v605 = (uint64_t) v23;
        TASSIGN(v604, v605);
        pipe_barrier(PIPE_V);
        TMUL(v604, v600, v600);
        // pto: %76
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v606 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %76
        ;
        uint64_t v607 = (uint64_t) v23;
        TASSIGN(v606, v607);
        // pto: %219
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v608;
        // pto: %219
        ;
        uint64_t v609 = (uint64_t) v23;
        TASSIGN(v608, v609);
        // pto: %77
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v610 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %77
        ;
        uint64_t v611 = (uint64_t) v47;
        TASSIGN(v610, v611);
        // pto: %220
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v612;
        // pto: %220
        ;
        uint64_t v613 = (uint64_t) v47;
        TASSIGN(v612, v613);
        // pto: %78
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v614 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %78
        ;
        uint64_t v615 = (uint64_t) v25;
        TASSIGN(v614, v615);
        pipe_barrier(PIPE_V);
        TADD(v614, v608, v612);
        // pto: %79
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v616 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %79
        ;
        uint64_t v617 = (uint64_t) v48;
        TASSIGN(v616, v617);
        // pto: %221
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v618;
        // pto: %221
        ;
        uint64_t v619 = (uint64_t) v48;
        TASSIGN(v618, v619);
        // pto: %80
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v620 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %80
        ;
        uint64_t v621 = (uint64_t) v49;
        TASSIGN(v620, v621);
        // pto: %222
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v622;
        // pto: %222
        ;
        uint64_t v623 = (uint64_t) v49;
        TASSIGN(v622, v623);
        // pto: %81
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v624 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %81
        ;
        uint64_t v625 = (uint64_t) v36;
        TASSIGN(v624, v625);
        TADD(v624, v618, v622);
        // pto: %82
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v626 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %82
        ;
        uint64_t v627 = (uint64_t) v50;
        TASSIGN(v626, v627);
        // pto: %223
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v628;
        // pto: %223
        ;
        uint64_t v629 = (uint64_t) v50;
        TASSIGN(v628, v629);
        // pto: %83
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v630 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %83
        ;
        uint64_t v631 = (uint64_t) v51;
        TASSIGN(v630, v631);
        // pto: %224
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v632;
        // pto: %224
        ;
        uint64_t v633 = (uint64_t) v51;
        TASSIGN(v632, v633);
        // pto: %84
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v634 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %84
        ;
        uint64_t v635 = (uint64_t) v22;
        TASSIGN(v634, v635);
        TADD(v634, v628, v632);
        // pto: %85
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v636 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %85
        ;
        uint64_t v637 = (uint64_t) v52;
        TASSIGN(v636, v637);
        // pto: %225
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v638;
        // pto: %225
        ;
        uint64_t v639 = (uint64_t) v52;
        TASSIGN(v638, v639);
        // pto: %86
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v640 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %86
        ;
        uint64_t v641 = (uint64_t) v46;
        TASSIGN(v640, v641);
        // pto: %226
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v642;
        // pto: %226
        ;
        uint64_t v643 = (uint64_t) v46;
        TASSIGN(v642, v643);
        // pto: %87
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v644 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %87
        ;
        uint64_t v645 = (uint64_t) v23;
        TASSIGN(v644, v645);
        pipe_barrier(PIPE_V);
        TADD(v644, v638, v642);
        // pto: %88
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v646 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %88
        ;
        uint64_t v647 = (uint64_t) v25;
        TASSIGN(v646, v647);
        TADD(v646, v614, v634);
        // pto: %89
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v648 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %89
        ;
        uint64_t v649 = (uint64_t) v23;
        TASSIGN(v648, v649);
        pipe_barrier(PIPE_V);
        TADD(v648, v624, v644);
        // pto: %90
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v650 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %90
        ;
        uint64_t v651 = (uint64_t) v25;
        TASSIGN(v650, v651);
        pipe_barrier(PIPE_V);
        TADD(v650, v646, v648);
        // pto: %91
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v652 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v67);
        // pto: %91
        ;
        uint64_t v653 = (uint64_t) v23;
        TASSIGN(v652, v653);
        // pto: %92
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v654 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %92
        ;
        uint64_t v655 = (uint64_t) v36;
        TASSIGN(v654, v655);
        pipe_barrier(PIPE_V);
        TROWSUM(v654, v650, v652);
        // pto: %93
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v656 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %93
        ;
        uint64_t v657 = (uint64_t) v36;
        TASSIGN(v656, v657);
        // pto: %94
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v658 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %94
        ;
        uint64_t v659 = (uint64_t) v23;
        TASSIGN(v658, v659);
        pipe_barrier(PIPE_V);
        TMULS(v658, v656, v70);
        // pto: %95
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v660 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %95
        ;
        uint64_t v661 = (uint64_t) v23;
        TASSIGN(v660, v661);
        pipe_barrier(PIPE_V);
        TADDS(v660, v658, v71);
        // pto: %96
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v662 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %96
        ;
        uint64_t v663 = (uint64_t) v25;
        TASSIGN(v662, v663);
        // pto: %97
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v664 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %97
        ;
        uint64_t v665 = (uint64_t) v36;
        TASSIGN(v664, v665);
        pipe_barrier(PIPE_V);
        TRSQRT(v664, v660, v662);
        // pto: %98
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v666 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %98
        ;
        uint64_t v667 = (uint64_t) v36;
        TASSIGN(v666, v667);
        // pto: %99
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v668 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %99
        ;
        uint64_t v669 = (uint64_t) v21;
        TASSIGN(v668, v669);
        // pto: %227
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 448, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v670;
        // pto: %227
        ;
        uint64_t v671 = (uint64_t) v21;
        TASSIGN(v670, v671);
        // pto: %100
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v672 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %100
        ;
        uint64_t v673 = (uint64_t) v23;
        TASSIGN(v672, v673);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v672, v670, v666);
        // pto: %101
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v674 = Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %101
        ;
        uint64_t v675 = (uint64_t) v23;
        TASSIGN(v674, v675);
        pipe_barrier(PIPE_V);
        RoundMode v676 = RoundMode::CAST_RINT;
        SaturationMode v677 = SaturationMode::ON;
        TCVT(v674, v672, v676, v677);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        // pto: %q_flat_inline5114__rv_v4_main_pview
        ;
        __gm__ bfloat16_t* v678 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %q_flat_inline5114__rv_v4_main_pview
        ;
        const int64_t v679 = 0;
        // pto: %q_flat_inline5114__rv_v4_main_pview
        ;
        const int64_t v680 = 32768;
        // pto: %q_flat_inline5114__rv_v4_main_pview
        ;
        pto::Shape<1, 1, 1, 8, 448> v681 = pto::Shape<1, 1, 1, 8, 448>();
        // pto: %q_flat_inline5114__rv_v4_main_pview
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v682 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %q_flat_inline5114__rv_v4_main_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v683 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v678 + (v679 + v188 * v680 + v568), v681, v682);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        TSTORE(v683, v674);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
        // pto: %102
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v684 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %102
        ;
        uint64_t v685 = (uint64_t) v35;
        TASSIGN(v684, v685);
        // pto: %231
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v686;
        // pto: %231
        ;
        uint64_t v687 = (uint64_t) v35;
        TASSIGN(v686, v687);
        // pto: %103
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v688 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %103
        ;
        uint64_t v689 = (uint64_t) v21;
        TASSIGN(v688, v689);
        TROWEXPANDMUL(v688, v686, v666);
        // pto: %104
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v690 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %104
        ;
        uint64_t v691 = (uint64_t) v23;
        TASSIGN(v690, v691);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
        RoundMode v692 = RoundMode::CAST_RINT;
        SaturationMode v693 = SaturationMode::ON;
        TCVT(v690, v688, v692, v693);
        // pto: %105
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v694 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %105
        ;
        uint64_t v695 = (uint64_t) v21;
        TASSIGN(v694, v695);
        pipe_barrier(PIPE_V);
        RoundMode v696 = RoundMode::CAST_ROUND;
        SaturationMode v697 = SaturationMode::ON;
        TCVT(v694, v690, v696, v697);
        // pto: %106
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v698 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %106
        ;
        uint64_t v699 = (uint64_t) v23;
        TASSIGN(v698, v699);
        for (int64_t v700 = v58; v700 < v63; v700 += v54) {
          // pto: %107
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v701 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %107
          ;
          uint64_t v702 = (uint64_t) v21;
          TASSIGN(v701, v702);
          // pto: %233
          ;
          int64_t v703 = (int64_t) ((uint64_t) v700 * (uint64_t) v16);
          // pto: %233
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v704;
          // pto: %233
          ;
          uint64_t v705 = (uint64_t) ((int64_t) (uint64_t) v703 + (uint64_t) v21);
          TASSIGN(v704, v705);
          // pto: %108
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v706 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %108
          ;
          uint64_t v707 = (uint64_t) v20;
          TASSIGN(v706, v707);
          // pto: %234
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v708;
          // pto: %234
          ;
          uint64_t v709 = (uint64_t) v703;
          TASSIGN(v708, v709);
          // pto: %109
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v710 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %109
          ;
          uint64_t v711 = (uint64_t) v25;
          TASSIGN(v710, v711);
          // pto: %110
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v712 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %110
          ;
          uint64_t v713 = (uint64_t) v36;
          TASSIGN(v712, v713);
          pipe_barrier(PIPE_V);
          TGATHER(v712, v704, v708, v710);
          // pto: %235
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v714;
          // pto: %235
          ;
          uint64_t v715 = (uint64_t) ((int64_t) (uint64_t) v703 + (uint64_t) v23);
          TASSIGN(v714, v715);
          pipe_barrier(PIPE_V);
          TMOV(v714, v712);
        };
        // pto: %112
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v716 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %112
        ;
        uint64_t v717 = (uint64_t) v23;
        TASSIGN(v716, v717);
        // pto: %113
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v718 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %113
        ;
        uint64_t v719 = (uint64_t) v21;
        TASSIGN(v718, v719);
        pipe_barrier(PIPE_V);
        TMUL(v718, v694, v186);
        // pto: %114
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v720 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %114
        ;
        uint64_t v721 = (uint64_t) v23;
        TASSIGN(v720, v721);
        TMUL(v720, v716, v195);
        // pto: %115
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v722 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %115
        ;
        uint64_t v723 = (uint64_t) v21;
        TASSIGN(v722, v723);
        pipe_barrier(PIPE_V);
        TADD(v722, v718, v720);
        // pto: %116
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v724 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %116
        ;
        uint64_t v725 = (uint64_t) v21;
        TASSIGN(v724, v725);
        pipe_barrier(PIPE_V);
        RoundMode v726 = RoundMode::CAST_RINT;
        SaturationMode v727 = SaturationMode::ON;
        TCVT(v724, v722, v726, v727);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        // pto: %238
        ;
        int64_t v728 = (int64_t) ((uint64_t) v565 + (uint64_t) v69);
        // pto: %239
        ;
        int64_t v729 = v728 < v58 ? v58 : v728;
        // pto: %240
        ;
        __gm__ bfloat16_t* v730 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %240
        ;
        const int64_t v731 = 0;
        // pto: %240
        ;
        const int64_t v732 = 32768;
        // pto: %240
        ;
        pto::Shape<1, 1, 1, 8, 64> v733 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %240
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v734 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %240
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v735 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v730 + (v731 + v188 * v732 + v729), v733, v734);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        TSTORE(v735, v724);
      };
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    } else {
      // pto: %241
      ;
      int64_t v736 = (int64_t) ((uint64_t) v8 - (uint64_t) v176);
      // pto: %qr_scale_dq_tail_inline5159__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v737 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
      // pto: %qr_scale_dq_tail_inline5159__ssa_v0
      ;
      uint64_t v738 = (uint64_t) v32;
      TASSIGN(v737, v738);
      // pto: %242
      ;
      int64_t v739 = v176 < v58 ? v58 : v176;
      // pto: %243
      ;
      __gm__ float* v740 = PTOAS__GLOBAL_TENSOR_DATA(v92);
      // pto: %243
      ;
      const int64_t v741 = 0;
      // pto: %243
      ;
      pto::Shape<1, 1, 1, 8, 1> v742 = pto::Shape<1, 1, 1, 8, 1>();
      // pto: %243
      ;
      pto::Stride<8, 8, 8, 1, 512> v743 = pto::Stride<8, 8, 8, 1, 512>();
      // pto: %243
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 512>, pto::Layout::DN> v744 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 512>, pto::Layout::DN>(v740 + (v741 + v739), v742, v743);
      pipe_barrier(PIPE_ALL);
      TLOAD(v737, v744);
      // pto: %q_cos_il_tail_inline5160__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v745 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v736, v56);
      // pto: %q_cos_il_tail_inline5160__ssa_v0
      ;
      uint64_t v746 = (uint64_t) v25;
      TASSIGN(v745, v746);
      // pto: %244
      ;
      int64_t v747 = v177 < v58 ? v58 : v177;
      // pto: %245
      ;
      const int64_t v748 = 0;
      // pto: %245
      ;
      __gm__ float* v749 = PTOAS__GLOBAL_TENSOR_DATA(v101);
      // pto: %245
      ;
      const int64_t v750 = 1;
      // pto: %245
      ;
      const int64_t v751 = 1;
      // pto: %245
      ;
      const int64_t v752 = 1;
      // pto: %245
      ;
      int64_t v753 = v736 * v56;
      // pto: %245
      ;
      int64_t v754 = v752 * v753;
      // pto: %245
      ;
      pto::Shape<1, 1, 1, -1, 64> v755 = pto::Shape<1, 1, 1, -1, 64>(v750, v751, v752, v736, v56);
      // pto: %245
      ;
      pto::Stride<-1, -1, -1, -1, -1> v756 = pto::Stride<-1, -1, -1, -1, -1>(v751 * v754, v754, v753, v56, v54);
      // pto: %245
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v757 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v749 + (v748 + v747 * v56 + v58 * v54), v755, v756);
      pipe_barrier(PIPE_ALL);
      TLOAD(v745, v757);
      // pto: %q_sin_signed_tail_inline5161__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v758 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v736, v56);
      // pto: %q_sin_signed_tail_inline5161__ssa_v0
      ;
      uint64_t v759 = (uint64_t) v36;
      TASSIGN(v758, v759);
      // pto: %247
      ;
      const int64_t v760 = 0;
      // pto: %247
      ;
      __gm__ float* v761 = PTOAS__GLOBAL_TENSOR_DATA(v110);
      // pto: %247
      ;
      const int64_t v762 = 1;
      // pto: %247
      ;
      const int64_t v763 = 1;
      // pto: %247
      ;
      const int64_t v764 = 1;
      // pto: %247
      ;
      int64_t v765 = v736 * v56;
      // pto: %247
      ;
      int64_t v766 = v764 * v765;
      // pto: %247
      ;
      pto::Shape<1, 1, 1, -1, 64> v767 = pto::Shape<1, 1, 1, -1, 64>(v762, v763, v764, v736, v56);
      // pto: %247
      ;
      pto::Stride<-1, -1, -1, -1, -1> v768 = pto::Stride<-1, -1, -1, -1, -1>(v763 * v766, v766, v765, v56, v54);
      // pto: %247
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v769 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v761 + (v760 + v747 * v56 + v58 * v54), v767, v768);
      pipe_barrier(PIPE_ALL);
      TLOAD(v758, v769);
      // pto: %t__tmp_v68
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v770 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %t__tmp_v68
      ;
      uint64_t v771 = (uint64_t) v21;
      TASSIGN(v770, v771);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      pipe_barrier(PIPE_V);
      TEXPANDS(v770, v66);
      // pto: %t__ci_tmp_v0
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v772 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v68);
      // pto: %t__ci_tmp_v0
      ;
      uint64_t v773 = (uint64_t) v23;
      TASSIGN(v772, v773);
      // pto: %t__tmp_v69
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v774 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
      // pto: %t__tmp_v69
      ;
      uint64_t v775 = (uint64_t) v18;
      TASSIGN(v774, v775);
      // pto: %ci_tmp_view
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v776;
      TRESHAPE(v776, v772);
      // pto: %ci_dst_view
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v777;
      TRESHAPE(v777, v774);
      TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v777, v72, v776);
      // pto: %t__tmp_v70
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v778 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
      // pto: %t__tmp_v70
      ;
      uint64_t v779 = (uint64_t) v23;
      TASSIGN(v778, v779);
      pipe_barrier(PIPE_V);
      RoundMode v780 = RoundMode::CAST_ROUND;
      SaturationMode v781 = SaturationMode::ON;
      TCVT(v778, v774, v780, v781);
      // pto: %q_col_inline5162__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v782 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_col_inline5162__ssa_v0
      ;
      uint64_t v783 = (uint64_t) v21;
      TASSIGN(v782, v783);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v782, v770, v778);
      // pto: %t__tmp_v71
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v784 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %t__tmp_v71
      ;
      uint64_t v785 = (uint64_t) v23;
      TASSIGN(v784, v785);
      pipe_barrier(PIPE_V);
      TMULS(v784, v782, v73);
      // pto: %t__tmp_v72
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v786 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %t__tmp_v72
      ;
      uint64_t v787 = (uint64_t) v23;
      TASSIGN(v786, v787);
      pipe_barrier(PIPE_V);
      RoundMode v788 = RoundMode::CAST_TRUNC;
      SaturationMode v789 = SaturationMode::ON;
      TCVT(v786, v784, v788, v789);
      // pto: %q_dup_f_inline5163__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v790 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_dup_f_inline5163__ssa_v0
      ;
      uint64_t v791 = (uint64_t) v23;
      TASSIGN(v790, v791);
      pipe_barrier(PIPE_V);
      RoundMode v792 = RoundMode::CAST_ROUND;
      SaturationMode v793 = SaturationMode::ON;
      TCVT(v790, v786, v792, v793);
      // pto: %t__tmp_v73
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v794 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %t__tmp_v73
      ;
      uint64_t v795 = (uint64_t) v23;
      TASSIGN(v794, v795);
      pipe_barrier(PIPE_V);
      TMULS(v794, v790, v74);
      // pto: %q_lane_inline5164__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v796 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_lane_inline5164__ssa_v0
      ;
      uint64_t v797 = (uint64_t) v23;
      TASSIGN(v796, v797);
      pipe_barrier(PIPE_V);
      TSUB(v796, v782, v794);
      // pto: %t__tmp_v74
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v798 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %t__tmp_v74
      ;
      uint64_t v799 = (uint64_t) v21;
      TASSIGN(v798, v799);
      pipe_barrier(PIPE_V);
      TADDS(v798, v782, v66);
      // pto: %t__tmp_v75
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v800 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %t__tmp_v75
      ;
      uint64_t v801 = (uint64_t) v23;
      TASSIGN(v800, v801);
      TMULS(v800, v796, v74);
      // pto: %q_swap_f_inline5165__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v802 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_swap_f_inline5165__ssa_v0
      ;
      uint64_t v803 = (uint64_t) v21;
      TASSIGN(v802, v803);
      pipe_barrier(PIPE_V);
      TSUB(v802, v798, v800);
      // pto: %t__ci_tmp_v1
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v804 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v68);
      // pto: %t__ci_tmp_v1
      ;
      uint64_t v805 = (uint64_t) v23;
      TASSIGN(v804, v805);
      // pto: %t__tmp_v76
      ;
      Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v806 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
      // pto: %t__tmp_v76
      ;
      uint64_t v807 = (uint64_t) v18;
      TASSIGN(v806, v807);
      // pto: %248
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v808;
      TRESHAPE(v808, v804);
      // pto: %249
      ;
      Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v809;
      TRESHAPE(v809, v806);
      pipe_barrier(PIPE_V);
      TCI<Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v809, v72, v808);
      // pto: %t__tmp_v77
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v810 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
      // pto: %t__tmp_v77
      ;
      uint64_t v811 = (uint64_t) v23;
      TASSIGN(v810, v811);
      pipe_barrier(PIPE_V);
      RoundMode v812 = RoundMode::CAST_ROUND;
      SaturationMode v813 = SaturationMode::ON;
      TCVT(v810, v806, v812, v813);
      // pto: %q_row_seed_inline5166__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v814 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
      // pto: %q_row_seed_inline5166__ssa_v0
      ;
      uint64_t v815 = (uint64_t) v18;
      TASSIGN(v814, v815);
      pipe_barrier(PIPE_V);
      TMULS(v814, v810, v75);
      // pto: %t__tmp_v78
      ;
      Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v816 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v56, v63);
      // pto: %t__tmp_v78
      ;
      uint64_t v817 = (uint64_t) v23;
      TASSIGN(v816, v817);
      pipe_barrier(PIPE_V);
      TEXPANDS(v816, v66);
      // pto: %q_row_grid_inline5167__ssa_v0
      ;
      Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v818 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v56, v63);
      // pto: %q_row_grid_inline5167__ssa_v0
      ;
      uint64_t v819 = (uint64_t) v23;
      TASSIGN(v818, v819);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v818, v816, v814);
      // pto: %transpose_tmp
      ;
      Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v820 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v56, v63);
      // pto: %transpose_tmp
      ;
      uint64_t v821 = (uint64_t) v18;
      TASSIGN(v820, v821);
      // pto: %q_row_offset_inline5168__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v822 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_row_offset_inline5168__ssa_v0
      ;
      uint64_t v823 = (uint64_t) v19;
      TASSIGN(v822, v823);
      pipe_barrier(PIPE_V);
      TTRANS(v822, v818, v820);
      // pto: %t__tmp_v79
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v824 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %t__tmp_v79
      ;
      uint64_t v825 = (uint64_t) v21;
      TASSIGN(v824, v825);
      pipe_barrier(PIPE_V);
      TADD(v824, v802, v822);
      // pto: %q_swap_idx_tail_inline5169__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v826 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_swap_idx_tail_inline5169__ssa_v0
      ;
      uint64_t v827 = (uint64_t) v18;
      TASSIGN(v826, v827);
      pipe_barrier(PIPE_V);
      RoundMode v828 = RoundMode::CAST_ROUND;
      SaturationMode v829 = SaturationMode::ON;
      TCVT(v826, v824, v828, v829);
      // pto: %q_head_reduce_tmp_inline5170__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v830 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_head_reduce_tmp_inline5170__ssa_v0
      ;
      uint64_t v831 = (uint64_t) v19;
      TASSIGN(v830, v831);
      // pto: %q_rsqrt_tmp_inline5171__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v832 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
      // pto: %q_rsqrt_tmp_inline5171__ssa_v0
      ;
      uint64_t v833 = (uint64_t) v40;
      TASSIGN(v832, v833);
      // pto: %q_gather_tmp_inline5172__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v834 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_gather_tmp_inline5172__ssa_v0
      ;
      uint64_t v835 = (uint64_t) v20;
      TASSIGN(v834, v835);
      pipe_barrier(PIPE_ALL);
      for (int64_t v836 = v58; v836 < v141; v836 += v54) {
        // pto: %250, %251
        ;
        int64_t v837 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v167 + (uint64_t) v836) * (uint64_t) v55);
        // pto: %q_head_acc_tail_inline5176__ssa_v0
        ;
        Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v838 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_acc_tail_inline5176__ssa_v0
        ;
        uint64_t v839 = (uint64_t) v21;
        TASSIGN(v838, v839);
        // pto: %253
        ;
        int64_t v840 = v837 < v58 ? v58 : v837;
        // pto: %254
        ;
        __gm__ int32_t* v841 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %254
        ;
        const int64_t v842 = 0;
        // pto: %254
        ;
        const int64_t v843 = 32768;
        // pto: %254
        ;
        pto::Shape<1, 1, 1, 8, 512> v844 = pto::Shape<1, 1, 1, 8, 512>();
        // pto: %254
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v845 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %254
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v846 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v841 + (v842 + v739 * v843 + v840), v844, v845);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
        TLOAD(v838, v846);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %q_head_scale_input_tail_inline5177__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v847 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %q_head_scale_input_tail_inline5177__ssa_v0
        ;
        uint64_t v848 = (uint64_t) v22;
        TASSIGN(v847, v848);
        // pto: %256
        ;
        __gm__ float* v849 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %256
        ;
        const int64_t v850 = 0;
        // pto: %256
        ;
        pto::Shape<1, 1, 1, 1, 512> v851 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %256
        ;
        pto::Stride<512, 512, 512, 512, 1> v852 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %256
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v853 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v849 + (v850 + v840), v851, v852);
        TLOAD(v847, v853);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        // pto: %q_head_scale_tail_inline5178__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v854 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %q_head_scale_tail_inline5178__ssa_v0
        ;
        uint64_t v855 = (uint64_t) v22;
        TASSIGN(v854, v855);
        // pto: %q_head_acc_fp32_tail_inline5179__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v856 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_acc_fp32_tail_inline5179__ssa_v0
        ;
        uint64_t v857 = (uint64_t) v21;
        TASSIGN(v856, v857);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v858 = RoundMode::CAST_NONE;
        SaturationMode v859 = SaturationMode::ON;
        TCVT(v856, v838, v858, v859);
        // pto: %t__tmp_v80
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v860 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %t__tmp_v80
        ;
        uint64_t v861 = (uint64_t) v23;
        TASSIGN(v860, v861);
        TEXPANDS(v860, v66);
        // pto: %t__tmp_v81
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v862 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %t__tmp_v81
        ;
        uint64_t v863 = (uint64_t) v23;
        TASSIGN(v862, v863);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v862, v860, v737);
        // pto: %q_head_scale_combined_tail_inline5180__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v864 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_scale_combined_tail_inline5180__ssa_v0
        ;
        uint64_t v865 = (uint64_t) v23;
        TASSIGN(v864, v865);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        TCOLEXPANDMUL(v864, v862, v854);
        // pto: %q_head_dq_tail_inline5181__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v866 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_dq_tail_inline5181__ssa_v0
        ;
        uint64_t v867 = (uint64_t) v21;
        TASSIGN(v866, v867);
        pipe_barrier(PIPE_V);
        TMUL(v866, v856, v864);
        // pto: %t__tmp_v82
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v868 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %t__tmp_v82
        ;
        uint64_t v869 = (uint64_t) v23;
        TASSIGN(v868, v869);
        pipe_barrier(PIPE_V);
        RoundMode v870 = RoundMode::CAST_RINT;
        SaturationMode v871 = SaturationMode::ON;
        TCVT(v868, v866, v870, v871);
        // pto: %q_head_dq_tail_v1_inline5182__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v872 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_dq_tail_v1_inline5182__ssa_v0
        ;
        uint64_t v873 = (uint64_t) v21;
        TASSIGN(v872, v873);
        pipe_barrier(PIPE_V);
        RoundMode v874 = RoundMode::CAST_ROUND;
        SaturationMode v875 = SaturationMode::ON;
        TCVT(v872, v868, v874, v875);
        // pto: %q_head_sq_tail_inline5183__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v876 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_sq_tail_inline5183__ssa_v0
        ;
        uint64_t v877 = (uint64_t) v23;
        TASSIGN(v876, v877);
        pipe_barrier(PIPE_V);
        TMUL(v876, v872, v872);
        // pto: %t__tmp_v83
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v878 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v83
        ;
        uint64_t v879 = (uint64_t) v23;
        TASSIGN(v878, v879);
        // pto: %257
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v880;
        // pto: %257
        ;
        uint64_t v881 = (uint64_t) v23;
        TASSIGN(v880, v881);
        // pto: %t__tmp_v84
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v882 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v84
        ;
        uint64_t v883 = (uint64_t) v47;
        TASSIGN(v882, v883);
        // pto: %258
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v884;
        // pto: %258
        ;
        uint64_t v885 = (uint64_t) v47;
        TASSIGN(v884, v885);
        // pto: %q_sq_04_tail_inline5184__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v886 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_04_tail_inline5184__ssa_v0
        ;
        uint64_t v887 = (uint64_t) v22;
        TASSIGN(v886, v887);
        pipe_barrier(PIPE_V);
        TADD(v886, v880, v884);
        // pto: %t__tmp_v85
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v888 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v85
        ;
        uint64_t v889 = (uint64_t) v48;
        TASSIGN(v888, v889);
        // pto: %259
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v890;
        // pto: %259
        ;
        uint64_t v891 = (uint64_t) v48;
        TASSIGN(v890, v891);
        // pto: %t__tmp_v86
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v892 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v86
        ;
        uint64_t v893 = (uint64_t) v49;
        TASSIGN(v892, v893);
        // pto: %260
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v894;
        // pto: %260
        ;
        uint64_t v895 = (uint64_t) v49;
        TASSIGN(v894, v895);
        // pto: %q_sq_15_tail_inline5185__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v896 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_15_tail_inline5185__ssa_v0
        ;
        uint64_t v897 = (uint64_t) v24;
        TASSIGN(v896, v897);
        TADD(v896, v890, v894);
        // pto: %t__tmp_v87
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v898 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v87
        ;
        uint64_t v899 = (uint64_t) v50;
        TASSIGN(v898, v899);
        // pto: %261
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v900;
        // pto: %261
        ;
        uint64_t v901 = (uint64_t) v50;
        TASSIGN(v900, v901);
        // pto: %t__tmp_v88
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v902 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v88
        ;
        uint64_t v903 = (uint64_t) v51;
        TASSIGN(v902, v903);
        // pto: %262
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v904;
        // pto: %262
        ;
        uint64_t v905 = (uint64_t) v51;
        TASSIGN(v904, v905);
        // pto: %q_sq_26_tail_inline5186__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v906 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_26_tail_inline5186__ssa_v0
        ;
        uint64_t v907 = (uint64_t) v29;
        TASSIGN(v906, v907);
        TADD(v906, v900, v904);
        // pto: %t__tmp_v89
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v908 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v89
        ;
        uint64_t v909 = (uint64_t) v52;
        TASSIGN(v908, v909);
        // pto: %263
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v910;
        // pto: %263
        ;
        uint64_t v911 = (uint64_t) v52;
        TASSIGN(v910, v911);
        // pto: %t__tmp_v90
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v912 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v90
        ;
        uint64_t v913 = (uint64_t) v46;
        TASSIGN(v912, v913);
        // pto: %264
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v914;
        // pto: %264
        ;
        uint64_t v915 = (uint64_t) v46;
        TASSIGN(v914, v915);
        // pto: %q_sq_37_tail_inline5187__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v916 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_37_tail_inline5187__ssa_v0
        ;
        uint64_t v917 = (uint64_t) v23;
        TASSIGN(v916, v917);
        pipe_barrier(PIPE_V);
        TADD(v916, v910, v914);
        // pto: %q_sq_0246_tail_inline5188__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v918 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_0246_tail_inline5188__ssa_v0
        ;
        uint64_t v919 = (uint64_t) v22;
        TASSIGN(v918, v919);
        TADD(v918, v886, v906);
        // pto: %q_sq_1357_tail_inline5189__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v920 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_1357_tail_inline5189__ssa_v0
        ;
        uint64_t v921 = (uint64_t) v23;
        TASSIGN(v920, v921);
        pipe_barrier(PIPE_V);
        TADD(v920, v896, v916);
        // pto: %q_sq_64_tail_inline5190__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v922 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_64_tail_inline5190__ssa_v0
        ;
        uint64_t v923 = (uint64_t) v23;
        TASSIGN(v922, v923);
        pipe_barrier(PIPE_V);
        TADD(v922, v918, v920);
        // pto: %q_head_sq_sum_tail_inline5191__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v924 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %q_head_sq_sum_tail_inline5191__ssa_v0
        ;
        uint64_t v925 = (uint64_t) v22;
        TASSIGN(v924, v925);
        pipe_barrier(PIPE_V);
        TROWSUM(v924, v922, v830);
        // pto: %t__rm_a0_tmp_v0
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v926 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %t__rm_a0_tmp_v0
        ;
        uint64_t v927 = (uint64_t) v22;
        TASSIGN(v926, v927);
        // pto: %t__row_major_tmp_v1
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v928 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %t__row_major_tmp_v1
        ;
        uint64_t v929 = (uint64_t) v23;
        TASSIGN(v928, v929);
        pipe_barrier(PIPE_V);
        TMULS(v928, v926, v70);
        // pto: %t__tmp_v91
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v930 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %t__tmp_v91
        ;
        uint64_t v931 = (uint64_t) v23;
        TASSIGN(v930, v931);
        // pto: %q_head_var_tail_inline5192__rm_a0_tmp_v2
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v932 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_var_tail_inline5192__rm_a0_tmp_v2
        ;
        uint64_t v933 = (uint64_t) v23;
        TASSIGN(v932, v933);
        // pto: %q_head_var_tail_inline5192__row_major_tmp_v3
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v934 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_var_tail_inline5192__row_major_tmp_v3
        ;
        uint64_t v935 = (uint64_t) v23;
        TASSIGN(v934, v935);
        pipe_barrier(PIPE_V);
        TADDS(v934, v932, v71);
        // pto: %q_head_var_tail_inline5192__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v936 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %q_head_var_tail_inline5192__ssa_v0
        ;
        uint64_t v937 = (uint64_t) v23;
        TASSIGN(v936, v937);
        // pto: %q_head_inv_rms_tail_inline5193__rm_a0_tmp_v4
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v938 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_inv_rms_tail_inline5193__rm_a0_tmp_v4
        ;
        uint64_t v939 = (uint64_t) v23;
        TASSIGN(v938, v939);
        // pto: %q_head_inv_rms_tail_inline5193__rm_a1_tmp_v5
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v940 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_inv_rms_tail_inline5193__rm_a1_tmp_v5
        ;
        uint64_t v941 = (uint64_t) v40;
        TASSIGN(v940, v941);
        // pto: %q_head_inv_rms_tail_inline5193__row_major_tmp_v6
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v942 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_inv_rms_tail_inline5193__row_major_tmp_v6
        ;
        uint64_t v943 = (uint64_t) v22;
        TASSIGN(v942, v943);
        pipe_barrier(PIPE_V);
        TRSQRT(v942, v938, v940);
        // pto: %q_head_inv_rms_tail_inline5193__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v944 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %q_head_inv_rms_tail_inline5193__ssa_v0
        ;
        uint64_t v945 = (uint64_t) v22;
        TASSIGN(v944, v945);
        // pto: %t__tmp_v92
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v946 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %t__tmp_v92
        ;
        uint64_t v947 = (uint64_t) v21;
        TASSIGN(v946, v947);
        // pto: %265
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 448, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v948;
        // pto: %265
        ;
        uint64_t v949 = (uint64_t) v21;
        TASSIGN(v948, v949);
        // pto: %q_nope_normed_tail_inline5194__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v950 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %q_nope_normed_tail_inline5194__ssa_v0
        ;
        uint64_t v951 = (uint64_t) v23;
        TASSIGN(v950, v951);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v950, v948, v944);
        // pto: %q_nope_bf16_tail_inline5195__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v952 = Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %q_nope_bf16_tail_inline5195__ssa_v0
        ;
        uint64_t v953 = (uint64_t) v23;
        TASSIGN(v952, v953);
        pipe_barrier(PIPE_V);
        RoundMode v954 = RoundMode::CAST_RINT;
        SaturationMode v955 = SaturationMode::ON;
        TCVT(v952, v950, v954, v955);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        v952.SetValidShape(v736, v69);
        // pto: %q_flat_inline5114__iter_v1_pview
        ;
        const int64_t v956 = 0;
        // pto: %q_flat_inline5114__iter_v1_pview
        ;
        __gm__ bfloat16_t* v957 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %q_flat_inline5114__iter_v1_pview
        ;
        const int64_t v958 = 1;
        // pto: %q_flat_inline5114__iter_v1_pview
        ;
        const int64_t v959 = 1;
        // pto: %q_flat_inline5114__iter_v1_pview
        ;
        const int64_t v960 = 1;
        // pto: %q_flat_inline5114__iter_v1_pview
        ;
        int64_t v961 = v736 * v53;
        // pto: %q_flat_inline5114__iter_v1_pview
        ;
        int64_t v962 = v960 * v961;
        // pto: %q_flat_inline5114__iter_v1_pview
        ;
        pto::Shape<1, 1, 1, -1, 448> v963 = pto::Shape<1, 1, 1, -1, 448>(v958, v959, v960, v736, v69);
        // pto: %q_flat_inline5114__iter_v1_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v964 = pto::Stride<-1, -1, -1, -1, -1>(v959 * v962, v962, v961, v53, v54);
        // pto: %q_flat_inline5114__iter_v1_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 448>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v965 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 448>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v957 + (v956 + v747 * v53 + v840 * v54), v963, v964);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        TSTORE(v965, v952);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
        // pto: %q_rope_chunk_raw_tail_inline5197__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v966 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_chunk_raw_tail_inline5197__ssa_v0
        ;
        uint64_t v967 = (uint64_t) v35;
        TASSIGN(v966, v967);
        // pto: %268
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v968;
        // pto: %268
        ;
        uint64_t v969 = (uint64_t) v35;
        TASSIGN(v968, v969);
        // pto: %q_rope_chunk_tail_inline5198__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v970 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_chunk_tail_inline5198__ssa_v0
        ;
        uint64_t v971 = (uint64_t) v21;
        TASSIGN(v970, v971);
        TROWEXPANDMUL(v970, v968, v944);
        // pto: %t__tmp_v93
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v972 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v93
        ;
        uint64_t v973 = (uint64_t) v23;
        TASSIGN(v972, v973);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
        RoundMode v974 = RoundMode::CAST_RINT;
        SaturationMode v975 = SaturationMode::ON;
        TCVT(v972, v970, v974, v975);
        // pto: %q_rope_chunk_tail_v1_inline5199__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v976 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_chunk_tail_v1_inline5199__ssa_v0
        ;
        uint64_t v977 = (uint64_t) v21;
        TASSIGN(v976, v977);
        pipe_barrier(PIPE_V);
        RoundMode v978 = RoundMode::CAST_ROUND;
        SaturationMode v979 = SaturationMode::ON;
        TCVT(v976, v972, v978, v979);
        // pto: %q_rope_swapped_tail_inline5200__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v980 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_swapped_tail_inline5200__ssa_v0
        ;
        uint64_t v981 = (uint64_t) v23;
        TASSIGN(v980, v981);
        pipe_barrier(PIPE_V);
        TGATHER(v980, v976, v826, v834);
        v976.SetValidShape(v736, v56);
        v980.SetValidShape(v736, v56);
        // pto: %q_rope_base_tail_inline5203__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v982 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v736, v56);
        // pto: %q_rope_base_tail_inline5203__ssa_v0
        ;
        uint64_t v983 = (uint64_t) v21;
        TASSIGN(v982, v983);
        pipe_barrier(PIPE_V);
        TMUL(v982, v976, v745);
        // pto: %q_rope_delta_tail_inline5204__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v984 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v736, v56);
        // pto: %q_rope_delta_tail_inline5204__ssa_v0
        ;
        uint64_t v985 = (uint64_t) v23;
        TASSIGN(v984, v985);
        TMUL(v984, v980, v758);
        // pto: %q_rope_rot_tail_inline5205__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v986 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v736, v56);
        // pto: %q_rope_rot_tail_inline5205__ssa_v0
        ;
        uint64_t v987 = (uint64_t) v21;
        TASSIGN(v986, v987);
        pipe_barrier(PIPE_V);
        TADD(v986, v982, v984);
        // pto: %q_rope_bf16_tail_inline5206__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v988 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v736, v56);
        // pto: %q_rope_bf16_tail_inline5206__ssa_v0
        ;
        uint64_t v989 = (uint64_t) v21;
        TASSIGN(v988, v989);
        pipe_barrier(PIPE_V);
        RoundMode v990 = RoundMode::CAST_RINT;
        SaturationMode v991 = SaturationMode::ON;
        TCVT(v988, v986, v990, v991);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        v988.SetValidShape(v736, v56);
        // pto: %270
        ;
        int64_t v992 = (int64_t) ((uint64_t) v837 + (uint64_t) v69);
        // pto: %271
        ;
        int64_t v993 = v992 < v58 ? v58 : v992;
        // pto: %272
        ;
        const int64_t v994 = 0;
        // pto: %272
        ;
        __gm__ bfloat16_t* v995 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %272
        ;
        const int64_t v996 = 1;
        // pto: %272
        ;
        const int64_t v997 = 1;
        // pto: %272
        ;
        const int64_t v998 = 1;
        // pto: %272
        ;
        int64_t v999 = v736 * v53;
        // pto: %272
        ;
        int64_t v1000 = v998 * v999;
        // pto: %272
        ;
        pto::Shape<1, 1, 1, -1, 64> v1001 = pto::Shape<1, 1, 1, -1, 64>(v996, v997, v998, v736, v56);
        // pto: %272
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1002 = pto::Stride<-1, -1, -1, -1, -1>(v997 * v1000, v1000, v999, v53, v54);
        // pto: %272
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1003 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v995 + (v994 + v747 * v53 + v993 * v54), v1001, v1002);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        TSTORE(v1003, v988);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
    };
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}