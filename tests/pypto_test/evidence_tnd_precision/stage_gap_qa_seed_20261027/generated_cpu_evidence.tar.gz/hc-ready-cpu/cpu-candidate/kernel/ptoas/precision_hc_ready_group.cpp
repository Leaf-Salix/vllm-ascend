#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void hc_ready_cube(__gm__ float* v1, __gm__ float* v2, __gm__ bfloat16_t* v3, __gm__ bfloat16_t* v4, __gm__ float* v5, __gm__ int64_t* v6, __gm__ bfloat16_t* v7, __gm__ float* v8, __gm__ float* v9, __gm__ float* v10, __gm__ float* v11, __gm__ float* v12, __gm__ float* v13, __gm__ bfloat16_t* v14, __gm__ bfloat16_t* v15, __gm__ bfloat16_t* v16, __gm__ bfloat16_t* v17, int64_t v18, int64_t v19, int64_t v20, int64_t v21, int32_t v22, int32_t v23) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v24 = 0;
  // pto: %c16384_i64
  const int64_t v25 = 16384;
  // pto: %c2048_i64
  const int64_t v26 = 2048;
  // pto: %c16384_index
  const int64_t v27 = 16384;
  // pto: %c1_index
  const int64_t v28 = 1;
  // pto: %c16_index
  const int64_t v29 = 16;
  // pto: %c32768_index
  const int64_t v30 = 32768;
  // pto: %c32_index
  const int64_t v31 = 32;
  const int64_t v32 = 64;
  // pto: %c24_index
  const int64_t v33 = 24;
  // pto: %c4_index
  const int64_t v34 = 4;
  // pto: %c22_index
  const int64_t v35 = 22;
  // pto: %c21_index
  const int64_t v36 = 21;
  // pto: %c0_index
  const int64_t v37 = 0;
  // pto: %c768_index
  const int64_t v38 = 768;
  // pto: %c2_index
  const int64_t v39 = 2;
  // pto: %cn1_index
  const int64_t v40 = -1;
  // pto: %c63_index
  const int64_t v41 = 63;
  // pto: %c1536_index
  const int64_t v42 = 1536;
  // pto: %c128_index
  const int64_t v43 = 128;
  // pto: %wide__ssa_v0_view
  const int64_t v44 = 1;
  // pto: %wide__ssa_v0_view
  const int64_t v45 = 1;
  // pto: %wide__ssa_v0_view
  const int64_t v46 = 1;
  // pto: %wide__ssa_v0_view
  int64_t v47 = (int64_t) v18;
  // pto: %wide__ssa_v0_view
  int64_t v48 = v47 * v27;
  // pto: %wide__ssa_v0_view
  int64_t v49 = v46 * v48;
  // pto: %wide__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v50 = pto::Shape<1, 1, 1, -1, -1>(v44, v45, v46, v47, v27);
  // pto: %wide__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v51 = pto::Stride<-1, -1, -1, -1, -1>(v45 * v49, v49, v48, v27, v28);
  // pto: %wide__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v52 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v50, v51);
  // pto: %spmd_square__ssa_v0_view
  const int64_t v53 = 1;
  // pto: %spmd_square__ssa_v0_view
  const int64_t v54 = 1;
  // pto: %spmd_square__ssa_v0_view
  const int64_t v55 = 1;
  // pto: %spmd_square__ssa_v0_view
  int64_t v56 = (int64_t) v19;
  // pto: %spmd_square__ssa_v0_view
  int64_t v57 = v56 * v29;
  // pto: %spmd_square__ssa_v0_view
  int64_t v58 = v55 * v57;
  // pto: %spmd_square__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v59 = pto::Shape<1, 1, 1, -1, -1>(v53, v54, v55, v56, v29);
  // pto: %spmd_square__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v60 = pto::Stride<-1, -1, -1, -1, -1>(v54 * v58, v58, v57, v29, v28);
  // pto: %spmd_square__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v61 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v59, v60);
  // pto: %hc_packed_weight__ssa_v0_view
  const int64_t v62 = 1;
  // pto: %hc_packed_weight__ssa_v0_view
  const int64_t v63 = 1;
  // pto: %hc_packed_weight__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %hc_packed_weight__ssa_v0_view
  int64_t v65 = v30 * v31;
  // pto: %hc_packed_weight__ssa_v0_view
  int64_t v66 = v64 * v65;
  // pto: %hc_packed_weight__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v67 = pto::Shape<1, 1, 1, -1, -1>(v62, v63, v64, v30, v31);
  // pto: %hc_packed_weight__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v68 = pto::Stride<-1, -1, -1, -1, -1>(v63 * v66, v66, v65, v31, v28);
  // pto: %hc_packed_weight__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v69 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v67, v68);
  // pto: %packed_flat__ssa_v0_view
  const int64_t v70 = 1;
  // pto: %packed_flat__ssa_v0_view
  const int64_t v71 = 1;
  // pto: %packed_flat__ssa_v0_view
  const int64_t v72 = 1;
  // pto: %packed_flat__ssa_v0_view
  int64_t v73 = (int64_t) v20;
  // pto: %packed_flat__ssa_v0_view
  int64_t v74 = v73 * v30;
  // pto: %packed_flat__ssa_v0_view
  int64_t v75 = v72 * v74;
  // pto: %packed_flat__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v76 = pto::Shape<1, 1, 1, -1, -1>(v70, v71, v72, v73, v30);
  // pto: %packed_flat__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v77 = pto::Stride<-1, -1, -1, -1, -1>(v71 * v75, v75, v74, v30, v28);
  // pto: %packed_flat__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v78 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v76, v77);
  // pto: %spmd_linear__ssa_v0_view
  const int64_t v79 = 1;
  // pto: %spmd_linear__ssa_v0_view
  const int64_t v80 = 1;
  // pto: %spmd_linear__ssa_v0_view
  const int64_t v81 = 1;
  // pto: %spmd_linear__ssa_v0_view
  int64_t v82 = (int64_t) v19;
  // pto: %spmd_linear__ssa_v0_view
  int64_t v83 = v82 * v31;
  // pto: %spmd_linear__ssa_v0_view
  int64_t v84 = v81 * v83;
  // pto: %spmd_linear__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v85 = pto::Shape<1, 1, 1, -1, -1>(v79, v80, v81, v82, v31);
  // pto: %spmd_linear__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v86 = pto::Stride<-1, -1, -1, -1, -1>(v80 * v84, v84, v83, v31, v28);
  // pto: %spmd_linear__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v87 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v85, v86);
  // pto: %native_sq_acc_inline2595__rv_v2
  Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v88 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v29, v29);
  // pto: %native_sq_acc_inline2595__rv_v2
  uint64_t v89 = (uint64_t) v24;
  TASSIGN(v88, v89);
  uint64_t v90 = reinterpret_cast<uint64_t>(v6);
  set_ffts_base_addr(v90);
  // pto: %worker__ssa_v0
  int64_t v91 = (int64_t) v22;
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %13
  const int64_t v92 = 1;
  // pto: %13
  const int64_t v93 = 0;
  // pto: %13
  int64_t v94 = v19 / v35;
  // pto: %13
  bool v95 = v19 < v93;
  // pto: %13
  bool v96 = v35 < v93;
  // pto: %13
  bool v97 = v95 == v96;
  // pto: %13
  bool v98 = v19 % v35 != v93 && v95 != v96;
  // pto: %13
  int64_t v99 = v98 ? v94 - v92 : v94;
  // pto: %14
  bool v100 = v18 >= v32;
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  // pto: %sq_group_inline2585__phi_v2
  int64_t v101 = v100 ? v34 : v28;
  // pto: %15
  int64_t v102 = (int64_t) ((uint64_t) v101 + (uint64_t) v36);
  // pto: %16
  const int64_t v103 = 1;
  // pto: %16
  const int64_t v104 = 0;
  // pto: %16
  int64_t v105 = v102 / v101;
  // pto: %16
  bool v106 = v102 < v104;
  // pto: %16
  bool v107 = v101 < v104;
  // pto: %16
  bool v108 = v106 == v107;
  // pto: %16
  bool v109 = v102 % v101 != v104 && v106 != v107;
  // pto: %16
  int64_t v110 = v109 ? v105 - v103 : v105;
  // pto: %17
  const int64_t v111 = 1;
  // pto: %17
  const int64_t v112 = 0;
  // pto: %17
  int64_t v113 = v99 / v29;
  // pto: %17
  bool v114 = v99 < v112;
  // pto: %17
  bool v115 = v29 < v112;
  // pto: %17
  bool v116 = v114 == v115;
  // pto: %17
  bool v117 = v99 % v29 != v112 && v114 != v115;
  // pto: %17
  int64_t v118 = v117 ? v113 - v111 : v113;
  // pto: %18
  for (int64_t v119 = v91; v119 < ((int64_t) ((uint64_t) v118 * (uint64_t) v110)); v119 += v33) {
    // pto: %19
    ;
    const int64_t v120 = 1;
    // pto: %19
    ;
    const int64_t v121 = 0;
    // pto: %19
    ;
    int64_t v122 = v119 / v110;
    // pto: %19
    ;
    bool v123 = v119 < v121;
    // pto: %19
    ;
    bool v124 = v110 < v121;
    // pto: %19
    ;
    bool v125 = v123 == v124;
    // pto: %19
    ;
    bool v126 = v119 % v110 != v121 && v123 != v124;
    // pto: %19
    ;
    int64_t v127 = v126 ? v122 - v120 : v122;
    // pto: %20
    ;
    int64_t v128 = (int64_t) ((uint64_t) v127 * (uint64_t) v29);
    // pto: %21
    ;
    int64_t v129 = v119 % v110;
    // pto: %22, %23, %24
    ;
    bool v130 = v129 < v37 ^ v110 < v37;
    // pto: %25, %26, %27, %28
    ;
    int64_t v131 = v129 != v37 & v130 ? (int64_t) ((uint64_t) v129 + (uint64_t) v110) : v129;
    // pto: %29
    ;
    int64_t v132 = (int64_t) ((uint64_t) v131 * (uint64_t) v101);
    // pto: %30
    ;
    int64_t v133 = (int64_t) ((uint64_t) v18 - (uint64_t) v128);
    // pto: %31
    ;
    int64_t v134 = v133 < v29 ? v133 : v29;
    // pto: %32
    ;
    int64_t v135 = (int64_t) ((uint64_t) v35 - (uint64_t) v132);
    // pto: %33
    ;
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    for (int64_t v136 = v37; v136 < (v101 < v135 ? v101 : v135); v136 += v28) {
      // pto: %34
      ;
      int64_t v137 = (int64_t) ((uint64_t) v132 + (uint64_t) v136);
      // pto: %35
      ;
      int64_t v138 = (int64_t) ((uint64_t) v137 * (uint64_t) v38);
      // pto: %36
      ;
      int64_t v139 = (int64_t) ((uint64_t) v27 - (uint64_t) v138);
      // pto: %37
      ;
      int64_t v140 = v139 < v38 ? v139 : v38;
      // pto: %38
      ;
      const int64_t v141 = 1;
      // pto: %38
      ;
      const int64_t v142 = 0;
      // pto: %38
      ;
      int64_t v143 = v140 / v31;
      // pto: %38
      ;
      bool v144 = v140 < v142;
      // pto: %38
      ;
      bool v145 = v31 < v142;
      // pto: %38
      ;
      bool v146 = v144 == v145;
      // pto: %38
      ;
      bool v147 = v140 % v31 != v142 && v144 != v145;
      // pto: %38
      ;
      int64_t v148 = v147 ? v143 - v141 : v143;
      // pto: %native_sq_acc_inline2595__tile
      ;
      Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v149 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v29, v29);
      // pto: %native_sq_acc_inline2595__tile
      ;
      uint64_t v150 = (uint64_t) v24;
      TASSIGN(v149, v150);
      // pto: %39
      ;
      const int64_t v151 = 1;
      // pto: %39
      ;
      const int64_t v152 = 0;
      // pto: %39
      ;
      int64_t v153 = v148 / v39;
      // pto: %39
      ;
      bool v154 = v148 < v152;
      // pto: %39
      ;
      bool v155 = v39 < v152;
      // pto: %39
      ;
      bool v156 = v154 == v155;
      // pto: %39
      ;
      bool v157 = v148 % v39 != v152 && v154 != v155;
      // pto: %39
      ;
      int64_t v158 = v157 ? v153 - v151 : v153;
      // pto: %40
      ;
      int64_t v159 = (int64_t) ((uint64_t) v158 * (uint64_t) v39);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      for (int64_t v160 = v37; v160 < v159; v160 += v39) {
        // pto: %42
        ;
        int64_t v161 = (int64_t) ((uint64_t) v160 * (uint64_t) v31);
        // pto: %43
        ;
        int64_t v162 = (int64_t) ((uint64_t) v138 + (uint64_t) v161);
        // pto: %47, %46
        ;
        int64_t v163 = (int64_t) ((uint64_t) v138 + (uint64_t) ((int64_t) (uint64_t) v161 + (uint64_t) v31));
        // pto: %sq_lhs_inline2598__tile
        ;
        Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v164 = Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v134, v31);
        // pto: %sq_lhs_inline2598__tile
        ;
        uint64_t v165 = (uint64_t) v24;
        TASSIGN(v164, v165);
        // pto: %48
        ;
        int64_t v166 = v128 < v37 ? v37 : v128;
        // pto: %49
        ;
        int64_t v167 = v162 < v37 ? v37 : v162;
        // pto: %wide__ssa_v0_pview
        ;
        const int64_t v168 = 0;
        // pto: %wide__ssa_v0_pview
        ;
        __gm__ float* v169 = PTOAS__GLOBAL_TENSOR_DATA(v52);
        // pto: %wide__ssa_v0_pview
        ;
        const int64_t v170 = 1;
        // pto: %wide__ssa_v0_pview
        ;
        const int64_t v171 = 1;
        // pto: %wide__ssa_v0_pview
        ;
        const int64_t v172 = 1;
        // pto: %wide__ssa_v0_pview
        ;
        int64_t v173 = v134 * v27;
        // pto: %wide__ssa_v0_pview
        ;
        int64_t v174 = v172 * v173;
        // pto: %wide__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 32> v175 = pto::Shape<1, 1, 1, -1, 32>(v170, v171, v172, v134, v31);
        // pto: %wide__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v176 = pto::Stride<-1, -1, -1, -1, -1>(v171 * v174, v174, v173, v27, v28);
        // pto: %wide__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v177 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v169 + (v168 + v166 * v27 + v167 * v28), v175, v176);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v164, v177);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %0
        ;
        Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v178 = Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v134, v31);
        // pto: %0
        ;
        uint64_t v179 = (uint64_t) v25;
        TASSIGN(v178, v179);
        // pto: %51
        ;
        int64_t v180 = v163 < v37 ? v37 : v163;
        // pto: %52
        ;
        const int64_t v181 = 0;
        // pto: %52
        ;
        __gm__ float* v182 = PTOAS__GLOBAL_TENSOR_DATA(v52);
        // pto: %52
        ;
        const int64_t v183 = 1;
        // pto: %52
        ;
        const int64_t v184 = 1;
        // pto: %52
        ;
        const int64_t v185 = 1;
        // pto: %52
        ;
        int64_t v186 = v134 * v27;
        // pto: %52
        ;
        int64_t v187 = v185 * v186;
        // pto: %52
        ;
        pto::Shape<1, 1, 1, -1, 32> v188 = pto::Shape<1, 1, 1, -1, 32>(v183, v184, v185, v134, v31);
        // pto: %52
        ;
        pto::Stride<-1, -1, -1, -1, -1> v189 = pto::Stride<-1, -1, -1, -1, -1>(v184 * v187, v187, v186, v27, v28);
        // pto: %52
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v190 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v182 + (v181 + v166 * v27 + v180 * v28), v188, v189);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        TLOAD(v178, v190);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %sq_lhs_inline2598__tile_t
        ;
        Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v191 = Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v31, v134);
        // pto: %sq_lhs_inline2598__tile_t
        ;
        uint64_t v192 = (uint64_t) v24;
        TASSIGN(v191, v192);
        // pto: %sq_lhs_inline2598__tile_Left
        ;
        Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v193 = Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v134, v31);
        // pto: %sq_lhs_inline2598__tile_Left
        ;
        uint64_t v194 = (uint64_t) v26;
        TASSIGN(v193, v194);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        TMOV(v193, v164);
        // pto: %sq_lhs_inline2598__tile_t_Right
        ;
        Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v195 = Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v31, v134);
        // pto: %sq_lhs_inline2598__tile_t_Right
        ;
        uint64_t v196 = (uint64_t) v26;
        TASSIGN(v195, v196);
        TMOV(v195, v191);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %53
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        if (v160 == v37) {
          pipe_barrier(PIPE_M);
          TMATMUL(v149, v193, v195);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v149, v149, v193, v195);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        // pto: %2
        ;
        Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v197 = Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v31, v134);
        // pto: %2
        ;
        uint64_t v198 = (uint64_t) v25;
        TASSIGN(v197, v198);
        // pto: %3
        ;
        Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v199 = Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v134, v31);
        // pto: %3
        ;
        uint64_t v200 = (uint64_t) v24;
        TASSIGN(v199, v200);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        TMOV(v199, v178);
        // pto: %4
        ;
        Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v201 = Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v31, v134);
        // pto: %4
        ;
        uint64_t v202 = (uint64_t) v24;
        TASSIGN(v201, v202);
        TMOV(v201, v197);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %54
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        if (v160 == v40) {
          pipe_barrier(PIPE_M);
          TMATMUL(v149, v199, v201);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v149, v149, v199, v201);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      // pto: %55, %56
      ;
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      if ((int64_t) ((uint64_t) v148 - (uint64_t) v159) == v28) {
        // pto: %59
        ;
        int64_t v203 = (int64_t) ((uint64_t) v138 + (uint64_t) ((int64_t) (uint64_t) v158 * (uint64_t) v32));
        // pto: %6
        ;
        Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v204 = Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v134, v31);
        // pto: %6
        ;
        uint64_t v205 = (uint64_t) v24;
        TASSIGN(v204, v205);
        // pto: %60
        ;
        int64_t v206 = v128 < v37 ? v37 : v128;
        // pto: %61
        ;
        int64_t v207 = v203 < v37 ? v37 : v203;
        // pto: %62
        ;
        const int64_t v208 = 0;
        // pto: %62
        ;
        __gm__ float* v209 = PTOAS__GLOBAL_TENSOR_DATA(v52);
        // pto: %62
        ;
        const int64_t v210 = 1;
        // pto: %62
        ;
        const int64_t v211 = 1;
        // pto: %62
        ;
        const int64_t v212 = 1;
        // pto: %62
        ;
        int64_t v213 = v134 * v27;
        // pto: %62
        ;
        int64_t v214 = v212 * v213;
        // pto: %62
        ;
        pto::Shape<1, 1, 1, -1, 32> v215 = pto::Shape<1, 1, 1, -1, 32>(v210, v211, v212, v134, v31);
        // pto: %62
        ;
        pto::Stride<-1, -1, -1, -1, -1> v216 = pto::Stride<-1, -1, -1, -1, -1>(v211 * v214, v214, v213, v27, v28);
        // pto: %62
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v217 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v209 + (v208 + v206 * v27 + v207 * v28), v215, v216);
        TLOAD(v204, v217);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        // pto: %7
        ;
        Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v31, v134);
        // pto: %7
        ;
        uint64_t v219 = (uint64_t) v24;
        TASSIGN(v218, v219);
        // pto: %8
        ;
        Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v134, v31);
        // pto: %8
        ;
        uint64_t v221 = (uint64_t) v26;
        TASSIGN(v220, v221);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        TMOV(v220, v204);
        // pto: %9
        ;
        Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v222 = Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v31, v134);
        // pto: %9
        ;
        uint64_t v223 = (uint64_t) v26;
        TASSIGN(v222, v223);
        TMOV(v222, v218);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %63
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        if (v159 == v37) {
          pipe_barrier(PIPE_M);
          TMATMUL(v149, v220, v222);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v149, v149, v220, v222);
        };
      };
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %64, %65
      ;
      int64_t v224 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v137 * (uint64_t) v99) + (uint64_t) v128);
      // pto: %66
      ;
      int64_t v225 = v224 < v37 ? v37 : v224;
      // pto: %square__iter_v3_pview
      ;
      __gm__ float* v226 = PTOAS__GLOBAL_TENSOR_DATA(v61);
      // pto: %square__iter_v3_pview
      ;
      const int64_t v227 = 0;
      // pto: %square__iter_v3_pview
      ;
      const int64_t v228 = 16;
      // pto: %square__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, 16, 16> v229 = pto::Shape<1, 1, 1, 16, 16>();
      // pto: %square__iter_v3_pview
      ;
      pto::Stride<256, 256, 256, 16, 1> v230 = pto::Stride<256, 256, 256, 16, 1>();
      // pto: %square__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<256, 256, 256, 16, 1>, pto::Layout::ND> v231 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<256, 256, 256, 16, 1>, pto::Layout::ND>(v226 + (v227 + v225 * v228), v229, v230);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      pipe_barrier(PIPE_FIX);
      TSTORE(v231, v88);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    };
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  if (v100) {
    // pto: %68
    ;
    int64_t v232 = (int64_t) ((uint64_t) v20 + (uint64_t) v41);
    // pto: %69
    ;
    const int64_t v233 = 1;
    // pto: %69
    ;
    const int64_t v234 = 0;
    // pto: %69
    ;
    int64_t v235 = v232 / v32;
    // pto: %69
    ;
    bool v236 = v232 < v234;
    // pto: %69
    ;
    bool v237 = v32 < v234;
    // pto: %69
    ;
    bool v238 = v236 == v237;
    // pto: %69
    ;
    bool v239 = v232 % v32 != v234 && v236 != v237;
    // pto: %69
    ;
    int64_t v240 = v239 ? v235 - v233 : v235;
    // pto: %70
    ;
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    for (int64_t v241 = v91; v241 < ((int64_t) ((uint64_t) v240 * (uint64_t) v35)); v241 += v33) {
      // pto: %73
      ;
      const int64_t v242 = 1;
      // pto: %73
      ;
      const int64_t v243 = 0;
      // pto: %73
      ;
      int64_t v244 = v241 / v240;
      // pto: %73
      ;
      bool v245 = v241 < v243;
      // pto: %73
      ;
      bool v246 = v240 < v243;
      // pto: %73
      ;
      bool v247 = v245 == v246;
      // pto: %73
      ;
      bool v248 = v241 % v240 != v243 && v245 != v246;
      // pto: %73
      ;
      int64_t v249 = v248 ? v244 - v242 : v244;
      // pto: %76
      ;
      int64_t v250 = v241 % v240;
      // pto: %77, %78, %79
      ;
      bool v251 = v250 < v37 ^ v240 < v37;
      // pto: %80, %81, %82, %83
      ;
      int64_t v252 = v250 != v37 & v251 ? (int64_t) ((uint64_t) v250 + (uint64_t) v240) : v250;
      // pto: %84
      ;
      int64_t v253 = (int64_t) ((uint64_t) v252 * (uint64_t) v32);
      // pto: %85
      ;
      int64_t v254 = (int64_t) ((uint64_t) v20 - (uint64_t) v253);
      // pto: %86
      ;
      int64_t v255 = v254 < v32 ? v254 : v32;
      // pto: %88, %87
      ;
      int64_t v256 = (int64_t) ((uint64_t) v27 - (uint64_t) ((int64_t) (uint64_t) v249 * (uint64_t) v38));
      // pto: %89
      ;
      int64_t v257 = v256 < v38 ? v256 : v38;
      // pto: %90
      ;
      const int64_t v258 = 1;
      // pto: %90
      ;
      const int64_t v259 = 0;
      // pto: %90
      ;
      int64_t v260 = v257 / v32;
      // pto: %90
      ;
      bool v261 = v257 < v259;
      // pto: %90
      ;
      bool v262 = v32 < v259;
      // pto: %90
      ;
      bool v263 = v261 == v262;
      // pto: %90
      ;
      bool v264 = v257 % v32 != v259 && v261 != v262;
      // pto: %90
      ;
      // pto: %91
      ;
      int64_t v265 = (int64_t) ((uint64_t) v249 * (uint64_t) v42);
      // pto: %panel64_wide_first_x_inline2608__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v266 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v255, v43);
      // pto: %panel64_wide_first_x_inline2608__tile
      ;
      uint64_t v267 = (uint64_t) v24;
      TASSIGN(v266, v267);
      // pto: %92
      ;
      int64_t v268 = v253 < v37 ? v37 : v253;
      // pto: %93
      ;
      int64_t v269 = v265 < v37 ? v37 : v265;
      // pto: %packed_flat__ssa_v0_pview
      ;
      const int64_t v270 = 0;
      // pto: %packed_flat__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v271 = PTOAS__GLOBAL_TENSOR_DATA(v78);
      // pto: %packed_flat__ssa_v0_pview
      ;
      const int64_t v272 = 1;
      // pto: %packed_flat__ssa_v0_pview
      ;
      const int64_t v273 = 1;
      // pto: %packed_flat__ssa_v0_pview
      ;
      const int64_t v274 = 1;
      // pto: %packed_flat__ssa_v0_pview
      ;
      int64_t v275 = v255 * v30;
      // pto: %packed_flat__ssa_v0_pview
      ;
      int64_t v276 = v274 * v275;
      // pto: %packed_flat__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 128> v277 = pto::Shape<1, 1, 1, -1, 128>(v272, v273, v274, v255, v43);
      // pto: %packed_flat__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v278 = pto::Stride<-1, -1, -1, -1, -1>(v273 * v276, v276, v275, v30, v28);
      // pto: %packed_flat__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v279 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v271 + (v270 + v268 * v30 + v269 * v28), v277, v278);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      TLOAD(v266, v279);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %panel64_wide_first_w_inline2609__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v280 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v43, v31);
      // pto: %panel64_wide_first_w_inline2609__tile
      ;
      uint64_t v281 = (uint64_t) v25;
      TASSIGN(v280, v281);
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v282 = PTOAS__GLOBAL_TENSOR_DATA(v69);
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      const int64_t v283 = 0;
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      const int64_t v284 = 32;
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 128, 32> v285 = pto::Shape<1, 1, 1, 128, 32>();
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      pto::Stride<4096, 4096, 4096, 32, 1> v286 = pto::Stride<4096, 4096, 4096, 32, 1>();
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND> v287 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND>(v282 + (v283 + v269 * v284), v285, v286);
      TLOAD(v280, v287);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      // pto: %panel64_wide_first_x_inline2608__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v288 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v255, v43);
      // pto: %panel64_wide_first_x_inline2608__tile_Left
      ;
      uint64_t v289 = (uint64_t) v26;
      TASSIGN(v288, v289);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      TMOV(v288, v266);
      // pto: %panel64_wide_first_w_inline2609__tile_Right
      ;
      Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v290 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v43, v31);
      // pto: %panel64_wide_first_w_inline2609__tile_Right
      ;
      uint64_t v291 = (uint64_t) v26;
      TASSIGN(v290, v291);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      TMOV(v290, v280);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      // pto: %panel64_wide_accumulator_inline2610__tile
      ;
      Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v292 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v255, v31);
      // pto: %panel64_wide_accumulator_inline2610__tile
      ;
      uint64_t v293 = (uint64_t) v24;
      TASSIGN(v292, v293);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
      TMATMUL(v292, v288, v290);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      for (int64_t v294 = v28; v294 < (v264 ? v260 - v258 : v260); v294 += v28) {
        // pto: %97, %96
        ;
        int64_t v295 = (int64_t) ((uint64_t) v265 + (uint64_t) ((int64_t) (uint64_t) v294 * (uint64_t) v43));
        // pto: %panel64_wide_x_inline2613__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v296 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v255, v43);
        // pto: %panel64_wide_x_inline2613__tile
        ;
        uint64_t v297 = (uint64_t) v24;
        TASSIGN(v296, v297);
        // pto: %99
        ;
        int64_t v298 = v295 < v37 ? v37 : v295;
        // pto: %100
        ;
        const int64_t v299 = 0;
        // pto: %100
        ;
        __gm__ bfloat16_t* v300 = PTOAS__GLOBAL_TENSOR_DATA(v78);
        // pto: %100
        ;
        const int64_t v301 = 1;
        // pto: %100
        ;
        const int64_t v302 = 1;
        // pto: %100
        ;
        const int64_t v303 = 1;
        // pto: %100
        ;
        int64_t v304 = v255 * v30;
        // pto: %100
        ;
        int64_t v305 = v303 * v304;
        // pto: %100
        ;
        pto::Shape<1, 1, 1, -1, 128> v306 = pto::Shape<1, 1, 1, -1, 128>(v301, v302, v303, v255, v43);
        // pto: %100
        ;
        pto::Stride<-1, -1, -1, -1, -1> v307 = pto::Stride<-1, -1, -1, -1, -1>(v302 * v305, v305, v304, v30, v28);
        // pto: %100
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v308 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v300 + (v299 + v268 * v30 + v298 * v28), v306, v307);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
        TLOAD(v296, v308);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        // pto: %panel64_wide_w_inline2614__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v43, v31);
        // pto: %panel64_wide_w_inline2614__tile
        ;
        uint64_t v310 = (uint64_t) v25;
        TASSIGN(v309, v310);
        // pto: %102
        ;
        __gm__ bfloat16_t* v311 = PTOAS__GLOBAL_TENSOR_DATA(v69);
        // pto: %102
        ;
        const int64_t v312 = 0;
        // pto: %102
        ;
        const int64_t v313 = 32;
        // pto: %102
        ;
        pto::Shape<1, 1, 1, 128, 32> v314 = pto::Shape<1, 1, 1, 128, 32>();
        // pto: %102
        ;
        pto::Stride<4096, 4096, 4096, 32, 1> v315 = pto::Stride<4096, 4096, 4096, 32, 1>();
        // pto: %102
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND> v316 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND>(v311 + (v312 + v298 * v313), v314, v315);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        TLOAD(v309, v316);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
        // pto: %panel64_wide_x_inline2613__tile_Left
        ;
        Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v317 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v255, v43);
        // pto: %panel64_wide_x_inline2613__tile_Left
        ;
        uint64_t v318 = (uint64_t) v26;
        TASSIGN(v317, v318);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        TMOV(v317, v296);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
        // pto: %panel64_wide_w_inline2614__tile_Right
        ;
        Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v319 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v43, v31);
        // pto: %panel64_wide_w_inline2614__tile_Right
        ;
        uint64_t v320 = (uint64_t) v26;
        TASSIGN(v319, v320);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
        TMOV(v319, v309);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        TMATMUL_ACC(v292, v292, v317, v319);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      };
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      v292.SetValidShape(v255, v31);
      // pto: %103, %104
      ;
      int64_t v321 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v249 * (uint64_t) v20) + (uint64_t) v253);
      // pto: %105
      ;
      int64_t v322 = v321 < v37 ? v37 : v321;
      // pto: %linear__iter_v1_pview
      ;
      const int64_t v323 = 0;
      // pto: %linear__iter_v1_pview
      ;
      __gm__ float* v324 = PTOAS__GLOBAL_TENSOR_DATA(v87);
      // pto: %linear__iter_v1_pview
      ;
      const int64_t v325 = 1;
      // pto: %linear__iter_v1_pview
      ;
      const int64_t v326 = 1;
      // pto: %linear__iter_v1_pview
      ;
      const int64_t v327 = 1;
      // pto: %linear__iter_v1_pview
      ;
      int64_t v328 = v255 * v31;
      // pto: %linear__iter_v1_pview
      ;
      int64_t v329 = v327 * v328;
      // pto: %linear__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, -1, 32> v330 = pto::Shape<1, 1, 1, -1, 32>(v325, v326, v327, v255, v31);
      // pto: %linear__iter_v1_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v331 = pto::Stride<-1, -1, -1, -1, -1>(v326 * v329, v329, v328, v31, v28);
      // pto: %linear__iter_v1_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v332 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v324 + (v323 + v322 * v31 + v37 * v28), v330, v331);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      TSTORE(v332, v292);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
    };
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  } else {
    // pto: %106
    ;
    const int64_t v333 = 1;
    // pto: %106
    ;
    const int64_t v334 = 0;
    // pto: %106
    ;
    int64_t v335 = v20 / v29;
    // pto: %106
    ;
    bool v336 = v20 < v334;
    // pto: %106
    ;
    bool v337 = v29 < v334;
    // pto: %106
    ;
    bool v338 = v336 == v337;
    // pto: %106
    ;
    bool v339 = v20 % v29 != v334 && v336 != v337;
    // pto: %106
    ;
    int64_t v340 = v339 ? v335 - v333 : v335;
    // pto: %107
    ;
    for (int64_t v341 = v91; v341 < ((int64_t) ((uint64_t) v340 * (uint64_t) v35)); v341 += v33) {
      // pto: %109
      ;
      const int64_t v342 = 1;
      // pto: %109
      ;
      const int64_t v343 = 0;
      // pto: %109
      ;
      int64_t v344 = v341 / v340;
      // pto: %109
      ;
      bool v345 = v341 < v343;
      // pto: %109
      ;
      bool v346 = v340 < v343;
      // pto: %109
      ;
      bool v347 = v345 == v346;
      // pto: %109
      ;
      bool v348 = v341 % v340 != v343 && v345 != v346;
      // pto: %109
      ;
      int64_t v349 = v348 ? v344 - v342 : v344;
      // pto: %111
      ;
      int64_t v350 = v341 % v340;
      // pto: %112, %113, %114
      ;
      bool v351 = v350 < v37 ^ v340 < v37;
      // pto: %115, %116, %117, %118
      ;
      int64_t v352 = v350 != v37 & v351 ? (int64_t) ((uint64_t) v350 + (uint64_t) v340) : v350;
      // pto: %119
      ;
      int64_t v353 = (int64_t) ((uint64_t) v352 * (uint64_t) v29);
      // pto: %121, %120
      ;
      int64_t v354 = (int64_t) ((uint64_t) v27 - (uint64_t) ((int64_t) (uint64_t) v349 * (uint64_t) v38));
      // pto: %122
      ;
      int64_t v355 = v354 < v38 ? v354 : v38;
      // pto: %123
      ;
      const int64_t v356 = 1;
      // pto: %123
      ;
      const int64_t v357 = 0;
      // pto: %123
      ;
      int64_t v358 = v355 / v32;
      // pto: %123
      ;
      bool v359 = v355 < v357;
      // pto: %123
      ;
      bool v360 = v32 < v357;
      // pto: %123
      ;
      bool v361 = v359 == v360;
      // pto: %123
      ;
      bool v362 = v355 % v32 != v357 && v359 != v360;
      // pto: %123
      ;
      // pto: %panel64_accumulator_inline2620__tile
      ;
      Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v363 = Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v29, v31);
      // pto: %panel64_accumulator_inline2620__tile
      ;
      uint64_t v364 = (uint64_t) v24;
      TASSIGN(v363, v364);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v365 = v37; v365 < (v362 ? v358 - v356 : v358); v365 += v28) {
        // pto: %124, %126, %125
        ;
        int64_t v366 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v349 * (uint64_t) v42) + (uint64_t) ((int64_t) (uint64_t) v365 * (uint64_t) v43));
        // pto: %panel64_x16_inline2623__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v367 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v29, v43);
        // pto: %panel64_x16_inline2623__tile
        ;
        uint64_t v368 = (uint64_t) v25;
        TASSIGN(v367, v368);
        // pto: %127
        ;
        int64_t v369 = v353 < v37 ? v37 : v353;
        // pto: %128
        ;
        int64_t v370 = v366 < v37 ? v37 : v366;
        // pto: %129
        ;
        __gm__ bfloat16_t* v371 = PTOAS__GLOBAL_TENSOR_DATA(v78);
        // pto: %129
        ;
        const int64_t v372 = 0;
        // pto: %129
        ;
        const int64_t v373 = 32768;
        // pto: %129
        ;
        pto::Shape<1, 1, 1, 16, 128> v374 = pto::Shape<1, 1, 1, 16, 128>();
        // pto: %129
        ;
        pto::Stride<524288, 524288, 524288, 32768, 1> v375 = pto::Stride<524288, 524288, 524288, 32768, 1>();
        // pto: %129
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND> v376 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND>(v371 + (v372 + v369 * v373 + v370), v374, v375);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        TLOAD(v367, v376);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
        // pto: %panel64_w16_inline2624__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v377 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v43, v31);
        // pto: %panel64_w16_inline2624__tile
        ;
        uint64_t v378 = (uint64_t) v24;
        TASSIGN(v377, v378);
        // pto: %131
        ;
        __gm__ bfloat16_t* v379 = PTOAS__GLOBAL_TENSOR_DATA(v69);
        // pto: %131
        ;
        const int64_t v380 = 0;
        // pto: %131
        ;
        const int64_t v381 = 32;
        // pto: %131
        ;
        pto::Shape<1, 1, 1, 128, 32> v382 = pto::Shape<1, 1, 1, 128, 32>();
        // pto: %131
        ;
        pto::Stride<4096, 4096, 4096, 32, 1> v383 = pto::Stride<4096, 4096, 4096, 32, 1>();
        // pto: %131
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND> v384 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND>(v379 + (v380 + v370 * v381), v382, v383);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v377, v384);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %panel64_x16_inline2623__tile_Left
        ;
        Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v385 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v29, v43);
        // pto: %panel64_x16_inline2623__tile_Left
        ;
        uint64_t v386 = (uint64_t) v26;
        TASSIGN(v385, v386);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
        pipe_barrier(PIPE_MTE1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        TMOV(v385, v367);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        // pto: %panel64_w16_inline2624__tile_Right
        ;
        Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v387 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v43, v31);
        // pto: %panel64_w16_inline2624__tile_Right
        ;
        uint64_t v388 = (uint64_t) v26;
        TASSIGN(v387, v388);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        TMOV(v387, v377);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        // pto: %132
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        if (v365 == v37) {
          TMATMUL(v363, v385, v387);
        } else {
          TMATMUL_ACC(v363, v363, v385, v387);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
      // pto: %134, %135
      ;
      int64_t v389 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v349 * (uint64_t) v20) + (uint64_t) v353);
      // pto: %136
      ;
      int64_t v390 = v389 < v37 ? v37 : v389;
      // pto: %linear__iter_v4_pview
      ;
      __gm__ float* v391 = PTOAS__GLOBAL_TENSOR_DATA(v87);
      // pto: %linear__iter_v4_pview
      ;
      const int64_t v392 = 0;
      // pto: %linear__iter_v4_pview
      ;
      const int64_t v393 = 32;
      // pto: %linear__iter_v4_pview
      ;
      pto::Shape<1, 1, 1, 16, 32> v394 = pto::Shape<1, 1, 1, 16, 32>();
      // pto: %linear__iter_v4_pview
      ;
      pto::Stride<512, 512, 512, 32, 1> v395 = pto::Stride<512, 512, 512, 32, 1>();
      // pto: %linear__iter_v4_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND> v396 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND>(v391 + (v392 + v390 * v393), v394, v395);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
      pipe_barrier(PIPE_FIX);
      TSTORE(v396, v363);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
    };
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void hc_ready_vector(__gm__ float* v1, __gm__ float* v2, __gm__ bfloat16_t* v3, __gm__ bfloat16_t* v4, __gm__ float* v5, __gm__ int64_t* v6, __gm__ bfloat16_t* v7, __gm__ float* v8, __gm__ float* v9, __gm__ float* v10, __gm__ float* v11, __gm__ float* v12, __gm__ float* v13, __gm__ bfloat16_t* v14, __gm__ bfloat16_t* v15, __gm__ bfloat16_t* v16, __gm__ bfloat16_t* v17, int64_t v18, int64_t v19, int64_t v20, int64_t v21, int32_t v22, int32_t v23, int32_t v24) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v25 = 12544;
  const int64_t v26 = 8448;
  const int64_t v27 = 4352;
  const int64_t v28 = 64;
  const int64_t v29 = 32;
  const int64_t v30 = 8388608;
  // pto: %c81920_i64
  const int64_t v31 = 81920;
  // pto: %c114944_i64
  const int64_t v32 = 114944;
  // pto: %c16384_i64
  const int64_t v33 = 16384;
  // pto: %c49152_i64
  const int64_t v34 = 49152;
  // pto: %c114688_i64
  const int64_t v35 = 114688;
  // pto: %c114720_i64
  const int64_t v36 = 114720;
  // pto: %c114752_i64
  const int64_t v37 = 114752;
  // pto: %c114784_i64
  const int64_t v38 = 114784;
  // pto: %c123136_i64
  const int64_t v39 = 123136;
  // pto: %c131328_i64
  const int64_t v40 = 131328;
  // pto: %c0_i64
  const int64_t v41 = 0;
  // pto: %c8192_i64
  const int64_t v42 = 8192;
  const int64_t v43 = 57344;
  const int64_t v44 = 53248;
  const int64_t v45 = 51200;
  const int64_t v46 = 50176;
  const int64_t v47 = 49664;
  const int64_t v48 = 49408;
  // pto: %c16384_index
  const int64_t v49 = 16384;
  // pto: %c1_index
  const int64_t v50 = 1;
  // pto: %c16_index
  const int64_t v51 = 16;
  // pto: %c32768_index
  const int64_t v52 = 32768;
  // pto: %c32_index
  const int64_t v53 = 32;
  // pto: %c64_index
  const int64_t v54 = 64;
  // pto: %c24_index
  const int64_t v55 = 24;
  // pto: %c4_index
  const int64_t v56 = 4;
  // pto: %c4096_index
  const int64_t v57 = 4096;
  // pto: %c8_index
  const int64_t v58 = 8;
  // pto: %c2_index
  const int64_t v59 = 2;
  // pto: %c48_index
  const int64_t v60 = 48;
  // pto: %c0_index
  const int64_t v61 = 0;
  const int64_t v62 = 512;
  // pto: %c256_index
  const int64_t v63 = 256;
  // pto: %cst_34
  const float v64 = 0.0f;
  // pto: %cst_35
  const bfloat16_t v65 = 0.0f;
  // pto: %c7_index
  const int64_t v66 = 7;
  // pto: %c192_index
  const int64_t v67 = 192;
  // pto: %c0_i32
  const int32_t v68 = 0;
  // pto: %c16_i32
  const int32_t v69 = 16;
  // pto: %c22_index
  const int64_t v70 = 22;
  // pto: %cst_41
  const float v71 = 6.10351563E-5f;
  // pto: %cst_42
  const float v72 = 9.99999997E-7f;
  // pto: %cst_43
  const float v73 = 1.0f;
  // pto: %cst_45
  const float v74 = 2.0f;
  // pto: %c8192_index
  const int64_t v75 = 8192;
  // pto: %c12288_index
  const int64_t v76 = 12288;
  // pto: %c2048_index
  const int64_t v77 = 2048;
  // pto: %c1024_index
  const int64_t v78 = 1024;
  // pto: %c128_index
  const int64_t v79 = 128;
  // pto: %cst_51
  const float v80 = 2.44140625E-4f;
  // pto: %c8388608_index
  const int64_t v81 = 8388608;
  // pto: %c2139095040_i64
  const int64_t v82 = 2139095040;
  // pto: %c2_i64
  const int64_t v83 = 2;
  // pto: %c152_i64
  const int64_t v84 = 152;
  // pto: %c1_i64
  const int64_t v85 = 1;
  // pto: %wide__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %wide__ssa_v0_view
  const int64_t v87 = 1;
  // pto: %wide__ssa_v0_view
  const int64_t v88 = 1;
  // pto: %wide__ssa_v0_view
  int64_t v89 = (int64_t) v18;
  // pto: %wide__ssa_v0_view
  int64_t v90 = v89 * v49;
  // pto: %wide__ssa_v0_view
  int64_t v91 = v88 * v90;
  // pto: %wide__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v92 = pto::Shape<1, 1, 1, -1, -1>(v86, v87, v88, v89, v49);
  // pto: %wide__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v93 = pto::Stride<-1, -1, -1, -1, -1>(v87 * v91, v91, v90, v49, v50);
  // pto: %wide__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v94 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v92, v93);
  // pto: %packed_flat__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %packed_flat__ssa_v0_view
  const int64_t v96 = 1;
  // pto: %packed_flat__ssa_v0_view
  const int64_t v97 = 1;
  // pto: %packed_flat__ssa_v0_view
  int64_t v98 = (int64_t) v20;
  // pto: %packed_flat__ssa_v0_view
  int64_t v99 = v98 * v52;
  // pto: %packed_flat__ssa_v0_view
  int64_t v100 = v97 * v99;
  // pto: %packed_flat__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v101 = pto::Shape<1, 1, 1, -1, -1>(v95, v96, v97, v98, v52);
  // pto: %packed_flat__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v102 = pto::Stride<-1, -1, -1, -1, -1>(v96 * v100, v100, v99, v52, v50);
  // pto: %packed_flat__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v103 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v101, v102);
  // pto: %flat_hc__ssa_v0_view
  const int64_t v104 = 1;
  // pto: %flat_hc__ssa_v0_view
  const int64_t v105 = 1;
  // pto: %flat_hc__ssa_v0_view
  const int64_t v106 = 1;
  // pto: %flat_hc__ssa_v0_view
  int64_t v107 = (int64_t) v18;
  // pto: %flat_hc__ssa_v0_view
  int64_t v108 = v107 * v49;
  // pto: %flat_hc__ssa_v0_view
  int64_t v109 = v106 * v108;
  // pto: %flat_hc__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v110 = pto::Shape<1, 1, 1, -1, -1>(v104, v105, v106, v107, v49);
  // pto: %flat_hc__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v111 = pto::Stride<-1, -1, -1, -1, -1>(v105 * v109, v109, v108, v49, v50);
  // pto: %flat_hc__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v112 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v110, v111);
  // pto: %spmd_square_read__ssa_v0_view
  const int64_t v113 = 1;
  // pto: %spmd_square_read__ssa_v0_view
  const int64_t v114 = 1;
  // pto: %spmd_square_read__ssa_v0_view
  const int64_t v115 = 1;
  // pto: %spmd_square_read__ssa_v0_view
  int64_t v116 = (int64_t) v19;
  // pto: %spmd_square_read__ssa_v0_view
  int64_t v117 = v116 * v51;
  // pto: %spmd_square_read__ssa_v0_view
  int64_t v118 = v115 * v117;
  // pto: %spmd_square_read__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v119 = pto::Shape<1, 1, 1, -1, -1>(v113, v114, v115, v116, v51);
  // pto: %spmd_square_read__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v120 = pto::Stride<-1, -1, -1, -1, -1>(v114 * v118, v118, v117, v51, v50);
  // pto: %spmd_square_read__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v121 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v119, v120);
  // pto: %vec_ws__ssa_v0_view
  const int64_t v122 = 1;
  // pto: %vec_ws__ssa_v0_view
  const int64_t v123 = 1;
  // pto: %vec_ws__ssa_v0_view
  const int64_t v124 = 1;
  // pto: %vec_ws__ssa_v0_view
  int64_t v125 = (int64_t) v21;
  // pto: %vec_ws__ssa_v0_view
  int64_t v126 = v125 * v54;
  // pto: %vec_ws__ssa_v0_view
  int64_t v127 = v124 * v126;
  // pto: %vec_ws__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v128 = pto::Shape<1, 1, 1, -1, -1>(v122, v123, v124, v125, v54);
  // pto: %vec_ws__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v129 = pto::Stride<-1, -1, -1, -1, -1>(v123 * v127, v127, v126, v54, v50);
  // pto: %vec_ws__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v130 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v128, v129);
  // pto: %spmd_linear_read__ssa_v0_view
  const int64_t v131 = 1;
  // pto: %spmd_linear_read__ssa_v0_view
  const int64_t v132 = 1;
  // pto: %spmd_linear_read__ssa_v0_view
  const int64_t v133 = 1;
  // pto: %spmd_linear_read__ssa_v0_view
  int64_t v134 = (int64_t) v19;
  // pto: %spmd_linear_read__ssa_v0_view
  int64_t v135 = v134 * v53;
  // pto: %spmd_linear_read__ssa_v0_view
  int64_t v136 = v133 * v135;
  // pto: %spmd_linear_read__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v137 = pto::Shape<1, 1, 1, -1, -1>(v131, v132, v133, v134, v53);
  // pto: %spmd_linear_read__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v138 = pto::Stride<-1, -1, -1, -1, -1>(v132 * v136, v136, v135, v53, v50);
  // pto: %spmd_linear_read__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v139 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v10, v137, v138);
  // pto: %hc_attn_base__ssa_v0_view
  const int64_t v140 = 1;
  // pto: %hc_attn_base__ssa_v0_view
  const int64_t v141 = 1;
  // pto: %hc_attn_base__ssa_v0_view
  const int64_t v142 = 1;
  // pto: %hc_attn_base__ssa_v0_view
  const int64_t v143 = 1;
  // pto: %hc_attn_base__ssa_v0_view
  int64_t v144 = v55 * v50;
  // pto: %hc_attn_base__ssa_v0_view
  int64_t v145 = v143 * v144;
  // pto: %hc_attn_base__ssa_v0_view
  int64_t v146 = v142 * v145;
  // pto: %hc_attn_base__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v147 = pto::Shape<1, 1, 1, 1, -1>(v140, v141, v142, v143, v55);
  // pto: %hc_attn_base__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v148 = pto::Stride<-1, -1, -1, -1, -1>(v141 * v146, v146, v145, v144, v50);
  // pto: %hc_attn_base__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v149 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v12, v147, v148);
  // pto: %post__ssa_v0_view
  const int64_t v150 = 1;
  // pto: %post__ssa_v0_view
  const int64_t v151 = 1;
  // pto: %post__ssa_v0_view
  const int64_t v152 = 1;
  // pto: %post__ssa_v0_view
  int64_t v153 = (int64_t) v18;
  // pto: %post__ssa_v0_view
  int64_t v154 = v153 * v56;
  // pto: %post__ssa_v0_view
  int64_t v155 = v152 * v154;
  // pto: %post__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v156 = pto::Shape<1, 1, 1, -1, -1>(v150, v151, v152, v153, v56);
  // pto: %post__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v157 = pto::Stride<-1, -1, -1, -1, -1>(v151 * v155, v155, v154, v56, v50);
  // pto: %post__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v158 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v156, v157);
  // pto: %mixed__ssa_v0_view
  const int64_t v159 = 1;
  // pto: %mixed__ssa_v0_view
  const int64_t v160 = 1;
  // pto: %mixed__ssa_v0_view
  const int64_t v161 = 1;
  // pto: %mixed__ssa_v0_view
  int64_t v162 = (int64_t) v18;
  // pto: %mixed__ssa_v0_view
  int64_t v163 = v162 * v57;
  // pto: %mixed__ssa_v0_view
  int64_t v164 = v161 * v163;
  // pto: %mixed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v165 = pto::Shape<1, 1, 1, -1, -1>(v159, v160, v161, v162, v57);
  // pto: %mixed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v166 = pto::Stride<-1, -1, -1, -1, -1>(v160 * v164, v164, v163, v57, v50);
  // pto: %mixed__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v167 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v165, v166);
  // pto: %mixed_tail__ssa_v0_view
  const int64_t v168 = 1;
  // pto: %mixed_tail__ssa_v0_view
  const int64_t v169 = 1;
  // pto: %mixed_tail__ssa_v0_view
  const int64_t v170 = 1;
  // pto: %mixed_tail__ssa_v0_view
  int64_t v171 = v58 * v57;
  // pto: %mixed_tail__ssa_v0_view
  int64_t v172 = v170 * v171;
  // pto: %mixed_tail__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v173 = pto::Shape<1, 1, 1, -1, -1>(v168, v169, v170, v58, v57);
  // pto: %mixed_tail__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v174 = pto::Stride<-1, -1, -1, -1, -1>(v169 * v172, v172, v171, v57, v50);
  // pto: %mixed_tail__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v175 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v173, v174);
  // pto: %attn_norm_w__ssa_v0_view
  const int64_t v176 = 1;
  // pto: %attn_norm_w__ssa_v0_view
  const int64_t v177 = 1;
  // pto: %attn_norm_w__ssa_v0_view
  const int64_t v178 = 1;
  // pto: %attn_norm_w__ssa_v0_view
  const int64_t v179 = 1;
  // pto: %attn_norm_w__ssa_v0_view
  int64_t v180 = v57 * v50;
  // pto: %attn_norm_w__ssa_v0_view
  int64_t v181 = v179 * v180;
  // pto: %attn_norm_w__ssa_v0_view
  int64_t v182 = v178 * v181;
  // pto: %attn_norm_w__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v183 = pto::Shape<1, 1, 1, 1, -1>(v176, v177, v178, v179, v57);
  // pto: %attn_norm_w__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v184 = pto::Stride<-1, -1, -1, -1, -1>(v177 * v182, v182, v181, v180, v50);
  // pto: %attn_norm_w__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v185 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v183, v184);
  // pto: %normed__ssa_v0_view
  const int64_t v186 = 1;
  // pto: %normed__ssa_v0_view
  const int64_t v187 = 1;
  // pto: %normed__ssa_v0_view
  const int64_t v188 = 1;
  // pto: %normed__ssa_v0_view
  int64_t v189 = (int64_t) v18;
  // pto: %normed__ssa_v0_view
  int64_t v190 = v189 * v57;
  // pto: %normed__ssa_v0_view
  int64_t v191 = v188 * v190;
  // pto: %normed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v192 = pto::Shape<1, 1, 1, -1, -1>(v186, v187, v188, v189, v57);
  // pto: %normed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v193 = pto::Stride<-1, -1, -1, -1, -1>(v187 * v191, v191, v190, v57, v50);
  // pto: %normed__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v194 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v17, v192, v193);
  uint64_t v195 = reinterpret_cast<uint64_t>(v6);
  set_ffts_base_addr(v195);
  // pto: %t__tmp_v0, %34, %35, %t__tmp_v1
  int64_t v196 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v22) * (uint64_t) v59) + (uint64_t) ((int64_t) v24));
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  set_flag(PIPE_S, PIPE_V, EVENT_ID5);
  for (int64_t v197 = v196; v197 < v18; v197 += v60) {
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    for (int64_t v198 = v61; v198 < v53; v198 += v59) {
      // pto: %36
      ;
      int64_t v199 = (int64_t) ((uint64_t) v198 * (uint64_t) v62);
      // pto: %38
      ;
      int64_t v200 = (int64_t) ((uint64_t) v199 + (uint64_t) v62);
      // pto: %t__tile
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v201 = Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
      // pto: %t__tile
      ;
      uint64_t v202 = (uint64_t) v31;
      TASSIGN(v201, v202);
      // pto: %39
      ;
      int64_t v203 = v197 < v61 ? v61 : v197;
      // pto: %40
      ;
      int64_t v204 = v199 < v61 ? v61 : v199;
      // pto: %flat_hc__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v205 = PTOAS__GLOBAL_TENSOR_DATA(v112);
      // pto: %flat_hc__ssa_v0_pview
      ;
      const int64_t v206 = 0;
      // pto: %flat_hc__ssa_v0_pview
      ;
      const int64_t v207 = 16384;
      // pto: %flat_hc__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v208 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %flat_hc__ssa_v0_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v209 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %flat_hc__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v210 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v205 + (v206 + v203 * v207 + v204), v208, v209);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      TLOAD(v201, v210);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %0
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
      // pto: %0
      ;
      uint64_t v212 = (uint64_t) v32;
      TASSIGN(v211, v212);
      // pto: %42
      ;
      int64_t v213 = v200 < v61 ? v61 : v200;
      // pto: %43
      ;
      __gm__ bfloat16_t* v214 = PTOAS__GLOBAL_TENSOR_DATA(v112);
      // pto: %43
      ;
      const int64_t v215 = 0;
      // pto: %43
      ;
      const int64_t v216 = 16384;
      // pto: %43
      ;
      pto::Shape<1, 1, 1, 1, 512> v217 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %43
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v218 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %43
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v219 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v214 + (v215 + v203 * v216 + v213), v217, v218);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      TLOAD(v211, v219);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %value_inline2845__tile
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
      // pto: %value_inline2845__tile
      ;
      uint64_t v221 = (uint64_t) v33;
      TASSIGN(v220, v221);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      RoundMode v222 = RoundMode::CAST_ROUND;
      SaturationMode v223 = SaturationMode::ON;
      TCVT(v220, v201, v222, v223);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      // pto: %wide__iter_v3_pview
      ;
      __gm__ float* v224 = PTOAS__GLOBAL_TENSOR_DATA(v94);
      // pto: %wide__iter_v3_pview
      ;
      const int64_t v225 = 0;
      // pto: %wide__iter_v3_pview
      ;
      const int64_t v226 = 16384;
      // pto: %wide__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v227 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %wide__iter_v3_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v228 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %wide__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v229 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v224 + (v225 + v203 * v226 + v204), v227, v228);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v229, v220);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      // pto: %1
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v230 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
      // pto: %1
      ;
      uint64_t v231 = (uint64_t) v34;
      TASSIGN(v230, v231);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      RoundMode v232 = RoundMode::CAST_ROUND;
      SaturationMode v233 = SaturationMode::ON;
      TCVT(v230, v211, v232, v233);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      // pto: %wide__tile_pview
      ;
      __gm__ float* v234 = PTOAS__GLOBAL_TENSOR_DATA(v94);
      // pto: %wide__tile_pview
      ;
      const int64_t v235 = 0;
      // pto: %wide__tile_pview
      ;
      const int64_t v236 = 16384;
      // pto: %wide__tile_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v237 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %wide__tile_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v238 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %wide__tile_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v239 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v234 + (v235 + v203 * v236 + v213), v237, v238);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v239, v230);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    };
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %49
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  if (v18 >= v54) {
    // pto: %51
    ;
    const int64_t v240 = 1;
    // pto: %51
    ;
    const int64_t v241 = 0;
    // pto: %51
    ;
    int64_t v242 = v20 / v51;
    // pto: %51
    ;
    bool v243 = v20 < v241;
    // pto: %51
    ;
    bool v244 = v51 < v241;
    // pto: %51
    ;
    bool v245 = v243 == v244;
    // pto: %51
    ;
    bool v246 = v20 % v51 != v241 && v243 != v244;
    // pto: %51
    ;
    int64_t v247 = v246 ? v242 - v240 : v242;
    // pto: %52
    ;
    int64_t v248 = (int64_t) ((uint64_t) v247 * (uint64_t) v54);
    // pto: %53
    ;
    const int64_t v249 = 1;
    // pto: %53
    ;
    const int64_t v250 = 0;
    // pto: %53
    ;
    int64_t v251 = v248 / v56;
    // pto: %53
    ;
    bool v252 = v248 < v250;
    // pto: %53
    ;
    bool v253 = v56 < v250;
    // pto: %53
    ;
    bool v254 = v252 == v253;
    // pto: %53
    ;
    bool v255 = v248 % v56 != v250 && v252 != v253;
    // pto: %53
    ;
    for (int64_t v256 = v196; v256 < (v255 ? v251 - v249 : v251); v256 += v60) {
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      for (int64_t v257 = v61; v257 < v56; v257 += v50) {
        // pto: %54, %55
        ;
        int64_t v258 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v256 * (uint64_t) v56) + (uint64_t) v257);
        // pto: %56
        ;
        const int64_t v259 = 1;
        // pto: %56
        ;
        const int64_t v260 = 0;
        // pto: %56
        ;
        int64_t v261 = v258 / v54;
        // pto: %56
        ;
        bool v262 = v258 < v260;
        // pto: %56
        ;
        bool v263 = v54 < v260;
        // pto: %56
        ;
        bool v264 = v262 == v263;
        // pto: %56
        ;
        bool v265 = v258 % v54 != v260 && v262 != v263;
        // pto: %56
        ;
        int64_t v266 = v265 ? v261 - v259 : v261;
        // pto: %57
        ;
        int64_t v267 = (int64_t) ((uint64_t) v266 * (uint64_t) v51);
        // pto: %58
        ;
        int64_t v268 = v258 % v54;
        // pto: %59, %60, %61
        ;
        int64_t v269 = v268 < v61 ? (int64_t) ((uint64_t) v268 + (uint64_t) v54) : v268;
        // pto: %62
        ;
        int64_t v270 = (int64_t) ((uint64_t) v269 * (uint64_t) v63);
        // pto: %63
        ;
        int64_t v271 = (int64_t) ((uint64_t) v18 - (uint64_t) v267);
        // pto: %64
        ;
        int64_t v272 = v271 < v51 ? v271 : v51;
        // pto: %panel64_values_inline2854__ssa_v0
        ;
        Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v273 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v272, v63);
        // pto: %panel64_values_inline2854__ssa_v0
        ;
        uint64_t v274 = (uint64_t) v33;
        TASSIGN(v273, v274);
        // pto: %65
        ;
        int64_t v275 = v267 < v61 ? v61 : v267;
        // pto: %66
        ;
        int64_t v276 = v270 < v61 ? v61 : v270;
        // pto: %wide_v1__ssa_v0_pview
        ;
        const int64_t v277 = 0;
        // pto: %wide_v1__ssa_v0_pview
        ;
        __gm__ float* v278 = PTOAS__GLOBAL_TENSOR_DATA(v94);
        // pto: %wide_v1__ssa_v0_pview
        ;
        const int64_t v279 = 1;
        // pto: %wide_v1__ssa_v0_pview
        ;
        const int64_t v280 = 1;
        // pto: %wide_v1__ssa_v0_pview
        ;
        const int64_t v281 = 1;
        // pto: %wide_v1__ssa_v0_pview
        ;
        int64_t v282 = v272 * v49;
        // pto: %wide_v1__ssa_v0_pview
        ;
        int64_t v283 = v281 * v282;
        // pto: %wide_v1__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v284 = pto::Shape<1, 1, 1, -1, 256>(v279, v280, v281, v272, v63);
        // pto: %wide_v1__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v285 = pto::Stride<-1, -1, -1, -1, -1>(v280 * v283, v283, v282, v49, v50);
        // pto: %wide_v1__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v286 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v278 + (v277 + v275 * v49 + v276 * v50), v284, v285);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        TLOAD(v273, v286);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        set_flag(PIPE_MTE2, PIPE_S, EVENT_ID1);
        wait_flag(PIPE_MTE2, PIPE_S, EVENT_ID1);
        for (int64_t v287 = v272; v287 < v51; v287 += v50) {
          for (int64_t v288 = v61; v288 < v63; v288 += v50) {
            // pto: %flat_offset_mul, %flat_offset
            ;
            int64_t v289 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v287 * (uint64_t) v63) + (uint64_t) v288);
            v273.SetValue(v289, v64);
          };
        };
        set_flag(PIPE_S, PIPE_V, EVENT_ID1);
        v273.SetValidShape(v51, v63);
        // pto: %panel64_values_v2_inline2858__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v290 = Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v51, v63);
        // pto: %panel64_values_v2_inline2858__ssa_v0
        ;
        uint64_t v291 = (uint64_t) v33;
        TASSIGN(v290, v291);
        wait_flag(PIPE_S, PIPE_V, EVENT_ID1);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v292 = RoundMode::CAST_ROUND;
        SaturationMode v293 = SaturationMode::ON;
        TCVT(v290, v273, v292, v293);
        // pto: %transpose_tmp
        ;
        Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v294 = Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v51, v63);
        // pto: %transpose_tmp
        ;
        uint64_t v295 = (uint64_t) v34;
        TASSIGN(v294, v295);
        // pto: %panel64_transposed_values_inline2859__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v296 = Tile<TileType::Vec, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v51);
        // pto: %panel64_transposed_values_inline2859__ssa_v0
        ;
        uint64_t v297 = (uint64_t) v31;
        TASSIGN(v296, v297);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
        TTRANS(v296, v290, v294);
        // pto: %panel64_packed_transposed_inline2860__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Vec, bfloat16_t, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v51);
        // pto: %panel64_packed_transposed_inline2860__ssa_v0
        ;
        uint64_t v299 = (uint64_t) v33;
        TASSIGN(v298, v299);
        pipe_barrier(PIPE_V);
        TEXPANDS(v298, v65);
        for (int64_t v300 = v61; v300 < v53; v300 += v50) {
          // pto: %panel64_input8_inline2862__ssa_v0
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v301 = Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v51);
          // pto: %panel64_input8_inline2862__ssa_v0
          ;
          uint64_t v302 = (uint64_t) v31;
          TASSIGN(v301, v302);
          // pto: %slice_view
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v303;
          // pto: %71, %slice_view
          ;
          uint64_t v304 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v300 * (uint64_t) v58) * (uint64_t) v29) + (uint64_t) v31);
          TASSIGN(v303, v304);
          // pto: %72
          ;
          int64_t v305 = (int64_t) ((uint64_t) v300 * (uint64_t) v51);
          // pto: %assemble_view
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v306;
          // pto: %assemble_view
          ;
          uint64_t v307 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v305 * (uint64_t) v29) + (uint64_t) v33);
          TASSIGN(v306, v307);
          pipe_barrier(PIPE_V);
          TMOV(v306, v303);
          // pto: %75
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v308;
          // pto: %74, %75
          ;
          uint64_t v309 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v305 + (uint64_t) v58) * (uint64_t) v29) + (uint64_t) v33);
          TASSIGN(v308, v309);
          pipe_barrier(PIPE_V);
          TMOV(v308, v303);
        };
        // pto: %2
        ;
        Tile<TileType::Vec, bfloat16_t, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v310 = Tile<TileType::Vec, bfloat16_t, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v51);
        // pto: %2
        ;
        uint64_t v311 = (uint64_t) v34;
        TASSIGN(v310, v311);
        // pto: %panel64_packed_values_inline2863__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v312 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v51, v62);
        // pto: %panel64_packed_values_inline2863__ssa_v0
        ;
        uint64_t v313 = (uint64_t) v31;
        TASSIGN(v312, v313);
        pipe_barrier(PIPE_V);
        TTRANS(v312, v298, v310);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        int64_t v314 = (int64_t) ((uint64_t) v269 * (uint64_t) v62);
        // pto: %78
        ;
        int64_t v315 = v314 < v61 ? v61 : v314;
        // pto: %packed_flat__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v316 = PTOAS__GLOBAL_TENSOR_DATA(v103);
        // pto: %packed_flat__ssa_v0_pview
        ;
        const int64_t v317 = 0;
        // pto: %packed_flat__ssa_v0_pview
        ;
        const int64_t v318 = 32768;
        // pto: %packed_flat__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 16, 512> v319 = pto::Shape<1, 1, 1, 16, 512>();
        // pto: %packed_flat__ssa_v0_pview
        ;
        pto::Stride<524288, 524288, 524288, 32768, 1> v320 = pto::Stride<524288, 524288, 524288, 32768, 1>();
        // pto: %packed_flat__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND> v321 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND>(v316 + (v317 + v275 * v318 + v315), v319, v320);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        TSTORE(v321, v312);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      };
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    };
  } else {
    // pto: %80
    ;
    const int64_t v322 = 1;
    // pto: %80
    ;
    const int64_t v323 = 0;
    // pto: %80
    ;
    int64_t v324 = v20 / v51;
    // pto: %80
    ;
    bool v325 = v20 < v323;
    // pto: %80
    ;
    bool v326 = v51 < v323;
    // pto: %80
    ;
    bool v327 = v325 == v326;
    // pto: %80
    ;
    bool v328 = v20 % v51 != v323 && v325 != v326;
    // pto: %80
    ;
    int64_t v329 = v328 ? v324 - v322 : v324;
    // pto: %81
    ;
    for (int64_t v330 = v196; v330 < ((int64_t) ((uint64_t) v329 * (uint64_t) v54)); v330 += v60) {
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      // pto: %85
      ;
      const int64_t v331 = 1;
      // pto: %85
      ;
      const int64_t v332 = 0;
      // pto: %85
      ;
      int64_t v333 = v330 / v54;
      // pto: %85
      ;
      bool v334 = v330 < v332;
      // pto: %85
      ;
      bool v335 = v54 < v332;
      // pto: %85
      ;
      bool v336 = v334 == v335;
      // pto: %85
      ;
      bool v337 = v330 % v54 != v332 && v334 != v335;
      // pto: %85
      ;
      int64_t v338 = v337 ? v333 - v331 : v333;
      // pto: %86
      ;
      int64_t v339 = (int64_t) ((uint64_t) v338 * (uint64_t) v51);
      // pto: %87
      ;
      int64_t v340 = v330 % v54;
      // pto: %88, %89, %90
      ;
      int64_t v341 = v340 < v61 ? (int64_t) ((uint64_t) v340 + (uint64_t) v54) : v340;
      // pto: %91
      ;
      int64_t v342 = (int64_t) ((uint64_t) v341 * (uint64_t) v63);
      // pto: %92
      ;
      int64_t v343 = (int64_t) ((uint64_t) v18 - (uint64_t) v339);
      // pto: %93
      ;
      int64_t v344 = v343 < v51 ? v343 : v51;
      // pto: %panel64_values_inline2872__ssa_v0
      ;
      Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v345 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v344, v63);
      // pto: %panel64_values_inline2872__ssa_v0
      ;
      uint64_t v346 = (uint64_t) v33;
      TASSIGN(v345, v346);
      // pto: %94
      ;
      int64_t v347 = v339 < v61 ? v61 : v339;
      // pto: %95
      ;
      int64_t v348 = v342 < v61 ? v61 : v342;
      // pto: %98
      ;
      const int64_t v349 = 0;
      // pto: %98
      ;
      __gm__ float* v350 = PTOAS__GLOBAL_TENSOR_DATA(v94);
      // pto: %98
      ;
      const int64_t v351 = 1;
      // pto: %98
      ;
      const int64_t v352 = 1;
      // pto: %98
      ;
      const int64_t v353 = 1;
      // pto: %98
      ;
      int64_t v354 = v344 * v49;
      // pto: %98
      ;
      int64_t v355 = v353 * v354;
      // pto: %98
      ;
      pto::Shape<1, 1, 1, -1, 256> v356 = pto::Shape<1, 1, 1, -1, 256>(v351, v352, v353, v344, v63);
      // pto: %98
      ;
      pto::Stride<-1, -1, -1, -1, -1> v357 = pto::Stride<-1, -1, -1, -1, -1>(v352 * v355, v355, v354, v49, v50);
      // pto: %98
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v358 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v350 + (v349 + v347 * v49 + v348 * v50), v356, v357);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      TLOAD(v345, v358);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      set_flag(PIPE_MTE2, PIPE_S, EVENT_ID2);
      wait_flag(PIPE_MTE2, PIPE_S, EVENT_ID2);
      for (int64_t v359 = v344; v359 < v51; v359 += v50) {
        for (int64_t v360 = v61; v360 < v63; v360 += v50) {
          // pto: %101, %102
          ;
          int64_t v361 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v359 * (uint64_t) v63) + (uint64_t) v360);
          v345.SetValue(v361, v64);
        };
      };
      set_flag(PIPE_S, PIPE_V, EVENT_ID2);
      v345.SetValidShape(v51, v63);
      // pto: %3
      ;
      Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v362 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v51, v63);
      // pto: %3
      ;
      uint64_t v363 = (uint64_t) v34;
      TASSIGN(v362, v363);
      // pto: %panel64_transposed_values_inline2876__ssa_v0
      ;
      Tile<TileType::Vec, float, 256, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v364 = Tile<TileType::Vec, float, 256, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v51);
      // pto: %panel64_transposed_values_inline2876__ssa_v0
      ;
      uint64_t v365 = (uint64_t) v31;
      TASSIGN(v364, v365);
      wait_flag(PIPE_S, PIPE_V, EVENT_ID2);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      TTRANS(v364, v345, v362);
      // pto: %panel64_packed_transposed_inline2877__ssa_v0
      ;
      Tile<TileType::Vec, float, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v366 = Tile<TileType::Vec, float, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v51);
      // pto: %panel64_packed_transposed_inline2877__ssa_v0
      ;
      uint64_t v367 = (uint64_t) v33;
      TASSIGN(v366, v367);
      pipe_barrier(PIPE_V);
      TEXPANDS(v366, v64);
      for (int64_t v368 = v61; v368 < v53; v368 += v50) {
        // pto: %panel64_input8_inline2879__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v369 = Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v51);
        // pto: %panel64_input8_inline2879__ssa_v0
        ;
        uint64_t v370 = (uint64_t) v31;
        TASSIGN(v369, v370);
        // pto: %104
        ;
        Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v371;
        // pto: %103, %104
        ;
        uint64_t v372 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v368 * (uint64_t) v58) * (uint64_t) v28) + (uint64_t) v31);
        TASSIGN(v371, v372);
        // pto: %105
        ;
        int64_t v373 = (int64_t) ((uint64_t) v368 * (uint64_t) v51);
        // pto: %106
        ;
        Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v374;
        // pto: %106
        ;
        uint64_t v375 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v373 * (uint64_t) v28) + (uint64_t) v33);
        TASSIGN(v374, v375);
        pipe_barrier(PIPE_V);
        TMOV(v374, v371);
        // pto: %109
        ;
        Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v376;
        // pto: %108, %109
        ;
        uint64_t v377 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v373 + (uint64_t) v58) * (uint64_t) v28) + (uint64_t) v33);
        TASSIGN(v376, v377);
        pipe_barrier(PIPE_V);
        TMOV(v376, v371);
      };
      // pto: %4
      ;
      Tile<TileType::Vec, float, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v378 = Tile<TileType::Vec, float, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v51);
      // pto: %4
      ;
      uint64_t v379 = (uint64_t) v34;
      TASSIGN(v378, v379);
      // pto: %panel64_packed_values_inline2880__ssa_v0
      ;
      Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v380 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v51, v62);
      // pto: %panel64_packed_values_inline2880__ssa_v0
      ;
      uint64_t v381 = (uint64_t) v31;
      TASSIGN(v380, v381);
      pipe_barrier(PIPE_V);
      TTRANS(v380, v366, v378);
      // pto: %t__tmp_v4
      ;
      Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v382 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v51, v62);
      // pto: %t__tmp_v4
      ;
      uint64_t v383 = (uint64_t) v33;
      TASSIGN(v382, v383);
      pipe_barrier(PIPE_V);
      RoundMode v384 = RoundMode::CAST_ROUND;
      SaturationMode v385 = SaturationMode::ON;
      TCVT(v382, v380, v384, v385);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      int64_t v386 = (int64_t) ((uint64_t) v341 * (uint64_t) v62);
      // pto: %112
      ;
      int64_t v387 = v386 < v61 ? v61 : v386;
      // pto: %113
      ;
      __gm__ bfloat16_t* v388 = PTOAS__GLOBAL_TENSOR_DATA(v103);
      // pto: %113
      ;
      const int64_t v389 = 0;
      // pto: %113
      ;
      const int64_t v390 = 32768;
      // pto: %113
      ;
      pto::Shape<1, 1, 1, 16, 512> v391 = pto::Shape<1, 1, 1, 16, 512>();
      // pto: %113
      ;
      pto::Stride<524288, 524288, 524288, 32768, 1> v392 = pto::Stride<524288, 524288, 524288, 32768, 1>();
      // pto: %113
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND> v393 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND>(v388 + (v389 + v347 * v390 + v387), v391, v392);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      TSTORE(v393, v382);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    };
  }
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %114
  int64_t v394 = (int64_t) ((uint64_t) v21 - (uint64_t) v58);
  // pto: %115
  int64_t v395 = (int64_t) ((uint64_t) v18 + (uint64_t) v66);
  // pto: %116
  const int64_t v396 = 1;
  // pto: %116
  const int64_t v397 = 0;
  // pto: %116
  int64_t v398 = v395 / v58;
  // pto: %116
  bool v399 = v395 < v397;
  // pto: %116
  bool v400 = v58 < v397;
  // pto: %116
  bool v401 = v399 == v400;
  // pto: %116
  bool v402 = v395 % v58 != v397 && v399 != v400;
  // pto: %116
  int64_t v403 = v402 ? v398 - v396 : v398;
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  for (int64_t v404 = v196; v404 < v403; v404 += v60) {
    // pto: %117
    ;
    int64_t v405 = (int64_t) ((uint64_t) v404 * (uint64_t) v58);
    // pto: %rms_lanes_inline2886__ci_tmp_v0
    ;
    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v406 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v67);
    // pto: %rms_lanes_inline2886__ci_tmp_v0
    ;
    uint64_t v407 = (uint64_t) v33;
    TASSIGN(v406, v407);
    // pto: %rms_lanes_inline2886__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v408 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %rms_lanes_inline2886__tile
    ;
    uint64_t v409 = (uint64_t) v34;
    TASSIGN(v408, v409);
    // pto: %ci_tmp_view
    ;
    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v410;
    TRESHAPE(v410, v406);
    // pto: %ci_dst_view
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v411;
    TRESHAPE(v411, v408);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    TCI<Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v411, v68, v410);
    // pto: %rms_rows_inline2887__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v412 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %rms_rows_inline2887__tile
    ;
    uint64_t v413 = (uint64_t) v33;
    TASSIGN(v412, v413);
    // pto: %118
    ;
    int32_t v414 = (int32_t) v405;
    pipe_barrier(PIPE_V);
    TADDS(v412, v408, v414);
    // pto: %rms_local_inline2888__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v415 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %rms_local_inline2888__tile
    ;
    uint64_t v416 = (uint64_t) v34;
    TASSIGN(v415, v416);
    // pto: %119
    ;
    int64_t v417 = v405 % v51;
    // pto: %120, %121, %122
    ;
    int64_t v418 = v417 < v61 ? (int64_t) ((uint64_t) v417 + (uint64_t) v51) : v417;
    // pto: %123
    ;
    int32_t v419 = (int32_t) v418;
    pipe_barrier(PIPE_V);
    TADDS(v415, v408, v419);
    // pto: %5
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v420 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %5
    ;
    uint64_t v421 = (uint64_t) v33;
    TASSIGN(v420, v421);
    TMULS(v420, v412, v69);
    // pto: %rms_index_inline2889__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v422 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %rms_index_inline2889__tile
    ;
    uint64_t v423 = (uint64_t) v33;
    TASSIGN(v422, v423);
    pipe_barrier(PIPE_V);
    TADD(v422, v420, v415);
    set_flag(PIPE_V, PIPE_S, EVENT_ID1);
    // pto: %rms_total_inline2890__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v424 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %rms_total_inline2890__tile
    ;
    uint64_t v425 = (uint64_t) v34;
    TASSIGN(v424, v425);
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    const int64_t v426 = 0;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    __gm__ float* v427 = PTOAS__GLOBAL_TENSOR_DATA(v121);
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    const int64_t v428 = 1;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    const int64_t v429 = 1;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    const int64_t v430 = 1;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    int64_t v431 = (int64_t) v19;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    int64_t v432 = v431 * v51;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    int64_t v433 = v430 * v432;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 16> v434 = pto::Shape<1, 1, 1, -1, 16>(v428, v429, v430, v431, v51);
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v435 = pto::Stride<-1, -1, -1, -1, -1>(v429 * v433, v433, v432, v51, v50);
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v436 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v427 + (v426 + v61 * v51 + v61 * v50), v434, v435);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID1);
    MGATHER<pto::Coalesce::Elem>(v424, v436, v422);
    set_flag(PIPE_S, PIPE_V, EVENT_ID4);
    for (int64_t v437 = v50; v437 < v70; v437 += v50) {
      // pto: %rms_part_index_inline2892__tile
      ;
      Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v438 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
      // pto: %rms_part_index_inline2892__tile
      ;
      uint64_t v439 = (uint64_t) v31;
      TASSIGN(v438, v439);
      // pto: %124, %125, %126
      ;
      int32_t v440 = (int32_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v437 * (uint64_t) v394) * (uint64_t) v51);
      pipe_barrier(PIPE_V);
      TADDS(v438, v422, v440);
      set_flag(PIPE_V, PIPE_S, EVENT_ID2);
      // pto: %rms_value_inline2893__tile
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v441 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
      // pto: %rms_value_inline2893__tile
      ;
      uint64_t v442 = (uint64_t) v32;
      TASSIGN(v441, v442);
      wait_flag(PIPE_V, PIPE_S, EVENT_ID2);
      MGATHER<pto::Coalesce::Elem>(v441, v436, v438);
      set_flag(PIPE_S, PIPE_V, EVENT_ID3);
      // pto: %6
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v443 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
      // pto: %6
      ;
      uint64_t v444 = (uint64_t) v34;
      TASSIGN(v443, v444);
      wait_flag(PIPE_S, PIPE_V, EVENT_ID3);
      TADD(v443, v424, v441);
    };
    // pto: %7
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v445 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %7
    ;
    uint64_t v446 = (uint64_t) v33;
    TASSIGN(v445, v446);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID4);
    TMULS(v445, v424, v71);
    // pto: %rms_variance_inline2894__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v447 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %rms_variance_inline2894__tile
    ;
    uint64_t v448 = (uint64_t) v33;
    TASSIGN(v447, v448);
    pipe_barrier(PIPE_V);
    TADDS(v447, v445, v72);
    // pto: %rms_root_inline2895__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v449 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %rms_root_inline2895__tile
    ;
    uint64_t v450 = (uint64_t) v33;
    TASSIGN(v449, v450);
    pipe_barrier(PIPE_V);
    TSQRT(v449, v447);
    // pto: %8
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v451 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %8
    ;
    uint64_t v452 = (uint64_t) v34;
    TASSIGN(v451, v452);
    TEXPANDS(v451, v73);
    // pto: %native_inverse_inline2896__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v453 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %native_inverse_inline2896__tile
    ;
    uint64_t v454 = (uint64_t) v33;
    TASSIGN(v453, v454);
    pipe_barrier(PIPE_V);
    TDIV(v453, v451, v449);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
    // pto: %128
    ;
    int64_t v455 = v405 < v61 ? v61 : v405;
    // pto: %vec_ws__iter_v1_pview
    ;
    __gm__ float* v456 = PTOAS__GLOBAL_TENSOR_DATA(v130);
    // pto: %vec_ws__iter_v1_pview
    ;
    const int64_t v457 = 40;
    // pto: %vec_ws__iter_v1_pview
    ;
    const int64_t v458 = 64;
    // pto: %vec_ws__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v459 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %vec_ws__iter_v1_pview
    ;
    pto::Stride<64, 64, 64, 64, 1> v460 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %vec_ws__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v461 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v456 + (v457 + v455 * v458), v459, v460);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
    TSTORE(v461, v453);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %130
  const int64_t v462 = 1;
  // pto: %130
  const int64_t v463 = 0;
  // pto: %130
  int64_t v464 = v394 / v51;
  // pto: %130
  bool v465 = v394 < v463;
  // pto: %130
  bool v466 = v51 < v463;
  // pto: %130
  bool v467 = v465 == v466;
  // pto: %130
  bool v468 = v394 % v51 != v463 && v465 != v466;
  // pto: %130
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  for (int64_t v469 = v196; v469 < (v468 ? v464 - v462 : v464); v469 += v60) {
    // pto: %131
    ;
    int64_t v470 = (int64_t) ((uint64_t) v469 * (uint64_t) v51);
    // pto: %mixes_total_inline2900__tile
    ;
    Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v471 = Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v51, v53);
    // pto: %mixes_total_inline2900__tile
    ;
    uint64_t v472 = (uint64_t) v33;
    TASSIGN(v471, v472);
    // pto: %132
    ;
    int64_t v473 = v470 < v61 ? v61 : v470;
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    __gm__ float* v474 = PTOAS__GLOBAL_TENSOR_DATA(v139);
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    const int64_t v475 = 0;
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    const int64_t v476 = 32;
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 16, 32> v477 = pto::Shape<1, 1, 1, 16, 32>();
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    pto::Stride<512, 512, 512, 32, 1> v478 = pto::Stride<512, 512, 512, 32, 1>();
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND> v479 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND>(v474 + (v475 + v473 * v476), v477, v478);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
    TLOAD(v471, v479);
    set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    for (int64_t v480 = v50; v480 < v70; v480 += v50) {
      // pto: %133, %134
      ;
      int64_t v481 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v480 * (uint64_t) v394) + (uint64_t) v470);
      // pto: %partial_tile_inline2903__tile
      ;
      Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v482 = Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v51, v53);
      // pto: %partial_tile_inline2903__tile
      ;
      uint64_t v483 = (uint64_t) v34;
      TASSIGN(v482, v483);
      // pto: %135
      ;
      int64_t v484 = v481 < v61 ? v61 : v481;
      // pto: %136
      ;
      __gm__ float* v485 = PTOAS__GLOBAL_TENSOR_DATA(v139);
      // pto: %136
      ;
      const int64_t v486 = 0;
      // pto: %136
      ;
      const int64_t v487 = 32;
      // pto: %136
      ;
      pto::Shape<1, 1, 1, 16, 32> v488 = pto::Shape<1, 1, 1, 16, 32>();
      // pto: %136
      ;
      pto::Stride<512, 512, 512, 32, 1> v489 = pto::Stride<512, 512, 512, 32, 1>();
      // pto: %136
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND> v490 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND>(v485 + (v486 + v484 * v487), v488, v489);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      TLOAD(v482, v490);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      // pto: %9
      ;
      Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v491 = Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v51, v53);
      // pto: %9
      ;
      uint64_t v492 = (uint64_t) v33;
      TASSIGN(v491, v492);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      TADD(v491, v471, v482);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    };
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    __gm__ float* v493 = PTOAS__GLOBAL_TENSOR_DATA(v130);
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    const int64_t v494 = 0;
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    const int64_t v495 = 64;
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 32> v496 = pto::Shape<1, 1, 1, 16, 32>();
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    pto::Stride<1024, 1024, 1024, 64, 1> v497 = pto::Stride<1024, 1024, 1024, 64, 1>();
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<1024, 1024, 1024, 64, 1>, pto::Layout::ND> v498 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<1024, 1024, 1024, 64, 1>, pto::Layout::ND>(v493 + (v494 + v473 * v495), v496, v497);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
    wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    TSTORE(v498, v471);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %scale0_inline2906__tile
  float v499 = (v11)[v61];
  // pto: %scale1_inline2907__tile
  float v500 = (v11)[v50];
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  for (int64_t v501 = v196; v501 < v403; v501 += v60) {
    // pto: %140
    ;
    int64_t v502 = (int64_t) ((uint64_t) v501 * (uint64_t) v58);
    // pto: %141
    ;
    int64_t v503 = (int64_t) ((uint64_t) v18 - (uint64_t) v502);
    // pto: %142
    ;
    int64_t v504 = v503 < v58 ? v503 : v58;
    // pto: %t__tmp_v10
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v505 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %t__tmp_v10
    ;
    uint64_t v506 = (uint64_t) v31;
    TASSIGN(v505, v506);
    // pto: %143
    ;
    int64_t v507 = v502 < v61 ? v61 : v502;
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    __gm__ float* v508 = PTOAS__GLOBAL_TENSOR_DATA(v130);
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    const int64_t v509 = 40;
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    const int64_t v510 = 64;
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v511 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    pto::Stride<64, 64, 64, 64, 1> v512 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v513 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v508 + (v509 + v507 * v510), v511, v512);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    TLOAD(v505, v513);
    // pto: %inv_col_inline2911__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v514 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v50);
    // pto: %inv_col_inline2911__ssa_v0
    ;
    uint64_t v515 = (uint64_t) v31;
    TASSIGN(v514, v515);
    // pto: %t__tmp_v11
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v516 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %t__tmp_v11
    ;
    uint64_t v517 = (uint64_t) v32;
    TASSIGN(v516, v517);
    // pto: %hc_attn_base__ssa_v0_pview
    ;
    __gm__ float* v518 = PTOAS__GLOBAL_TENSOR_DATA(v149);
    // pto: %hc_attn_base__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v519 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %hc_attn_base__ssa_v0_pview
    ;
    pto::Stride<8, 8, 8, 8, 1> v520 = pto::Stride<8, 8, 8, 8, 1>();
    // pto: %hc_attn_base__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND> v521 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND>(v518, v519, v520);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    TLOAD(v516, v521);
    // pto: %pre_base_inline2912__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v522 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %pre_base_inline2912__ssa_v0
    ;
    uint64_t v523 = (uint64_t) v32;
    TASSIGN(v522, v523);
    // pto: %t__tmp_v12
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v524 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %t__tmp_v12
    ;
    uint64_t v525 = (uint64_t) v33;
    TASSIGN(v524, v525);
    // pto: %145
    ;
    __gm__ float* v526 = PTOAS__GLOBAL_TENSOR_DATA(v130);
    // pto: %145
    ;
    const int64_t v527 = 0;
    // pto: %145
    ;
    const int64_t v528 = 64;
    // pto: %145
    ;
    pto::Shape<1, 1, 1, 8, 8> v529 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %145
    ;
    pto::Stride<512, 512, 512, 64, 1> v530 = pto::Stride<512, 512, 512, 64, 1>();
    // pto: %145
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v531 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v526 + (v527 + v507 * v528), v529, v530);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    TLOAD(v524, v531);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    // pto: %t__tmp_v13
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v532 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %t__tmp_v13
    ;
    uint64_t v533 = (uint64_t) v33;
    TASSIGN(v532, v533);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    TROWEXPANDMUL(v532, v524, v514);
    // pto: %pre_scaled_inline2913__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v534 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %pre_scaled_inline2913__ssa_v0
    ;
    uint64_t v535 = (uint64_t) v33;
    TASSIGN(v534, v535);
    pipe_barrier(PIPE_V);
    TMULS(v534, v532, v499);
    // pto: %t__tmp_v14
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v536 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %t__tmp_v14
    ;
    uint64_t v537 = (uint64_t) v34;
    TASSIGN(v536, v537);
    TCOLEXPAND(v536, v522);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %pre_logits_inline2914__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v538 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %pre_logits_inline2914__ssa_v0
    ;
    uint64_t v539 = (uint64_t) v33;
    TASSIGN(v538, v539);
    pipe_barrier(PIPE_V);
    TADD(v538, v534, v536);
    // pto: %t__tmp_v15
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v540 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %t__tmp_v15
    ;
    uint64_t v541 = (uint64_t) v34;
    TASSIGN(v540, v541);
    pipe_barrier(PIPE_V);
    TEXPANDS(v540, v73);
    // pto: %t__tmp_v16
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v542 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %t__tmp_v16
    ;
    uint64_t v543 = (uint64_t) v33;
    TASSIGN(v542, v543);
    TNEG(v542, v538);
    // pto: %t__tmp_v17
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v544 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %t__tmp_v17
    ;
    uint64_t v545 = (uint64_t) v33;
    TASSIGN(v544, v545);
    pipe_barrier(PIPE_V);
    TEXP(v544, v542);
    // pto: %t__tmp_v18
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v546 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %t__tmp_v18
    ;
    uint64_t v547 = (uint64_t) v33;
    TASSIGN(v546, v547);
    pipe_barrier(PIPE_V);
    TADDS(v546, v544, v73);
    // pto: %pre_sig_inline2915__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v548 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %pre_sig_inline2915__ssa_v0
    ;
    uint64_t v549 = (uint64_t) v33;
    TASSIGN(v548, v549);
    pipe_barrier(PIPE_V);
    TDIV(v548, v540, v546);
    // pto: %pre_val_inline2916__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v550 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %pre_val_inline2916__ssa_v0
    ;
    uint64_t v551 = (uint64_t) v33;
    TASSIGN(v550, v551);
    pipe_barrier(PIPE_V);
    TADDS(v550, v548, v72);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
    // pto: %147
    ;
    __gm__ float* v552 = PTOAS__GLOBAL_TENSOR_DATA(v130);
    // pto: %147
    ;
    const int64_t v553 = 32;
    // pto: %147
    ;
    const int64_t v554 = 64;
    // pto: %147
    ;
    pto::Shape<1, 1, 1, 8, 8> v555 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %147
    ;
    pto::Stride<512, 512, 512, 64, 1> v556 = pto::Stride<512, 512, 512, 64, 1>();
    // pto: %147
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v557 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v552 + (v553 + v507 * v554), v555, v556);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
    TSTORE(v557, v550);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    // pto: %t__tmp_v19
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v558 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %t__tmp_v19
    ;
    uint64_t v559 = (uint64_t) v32;
    TASSIGN(v558, v559);
    // pto: %148
    ;
    __gm__ float* v560 = PTOAS__GLOBAL_TENSOR_DATA(v149);
    // pto: %148
    ;
    unsigned v561 = 4;
    // pto: %148
    ;
    pto::Shape<1, 1, 1, 1, 8> v562 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %148
    ;
    pto::Stride<8, 8, 8, 8, 1> v563 = pto::Stride<8, 8, 8, 8, 1>();
    // pto: %148
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND> v564 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND>(v560 + v561, v562, v563);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v558, v564);
    // pto: %post_base_inline2917__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v565 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %post_base_inline2917__ssa_v0
    ;
    uint64_t v566 = (uint64_t) v32;
    TASSIGN(v565, v566);
    // pto: %t__tmp_v20
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v567 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %t__tmp_v20
    ;
    uint64_t v568 = (uint64_t) v33;
    TASSIGN(v567, v568);
    // pto: %150
    ;
    __gm__ float* v569 = PTOAS__GLOBAL_TENSOR_DATA(v130);
    // pto: %150
    ;
    const int64_t v570 = 4;
    // pto: %150
    ;
    const int64_t v571 = 64;
    // pto: %150
    ;
    pto::Shape<1, 1, 1, 8, 8> v572 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %150
    ;
    pto::Stride<512, 512, 512, 64, 1> v573 = pto::Stride<512, 512, 512, 64, 1>();
    // pto: %150
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v574 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v569 + (v570 + v507 * v571), v572, v573);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    TLOAD(v567, v574);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
    // pto: %t__tmp_v21
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v575 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %t__tmp_v21
    ;
    uint64_t v576 = (uint64_t) v33;
    TASSIGN(v575, v576);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
    TROWEXPANDMUL(v575, v567, v514);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    // pto: %post_scaled_inline2918__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v577 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %post_scaled_inline2918__ssa_v0
    ;
    uint64_t v578 = (uint64_t) v33;
    TASSIGN(v577, v578);
    pipe_barrier(PIPE_V);
    TMULS(v577, v575, v500);
    // pto: %t__tmp_v22
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v579 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %t__tmp_v22
    ;
    uint64_t v580 = (uint64_t) v34;
    TASSIGN(v579, v580);
    TCOLEXPAND(v579, v565);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    // pto: %post_logits_inline2919__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v581 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %post_logits_inline2919__ssa_v0
    ;
    uint64_t v582 = (uint64_t) v33;
    TASSIGN(v581, v582);
    pipe_barrier(PIPE_V);
    TADD(v581, v577, v579);
    // pto: %t__tmp_v23
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v583 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %t__tmp_v23
    ;
    uint64_t v584 = (uint64_t) v34;
    TASSIGN(v583, v584);
    pipe_barrier(PIPE_V);
    TEXPANDS(v583, v73);
    // pto: %t__tmp_v24
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v585 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %t__tmp_v24
    ;
    uint64_t v586 = (uint64_t) v33;
    TASSIGN(v585, v586);
    TNEG(v585, v581);
    // pto: %t__tmp_v25
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v587 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %t__tmp_v25
    ;
    uint64_t v588 = (uint64_t) v33;
    TASSIGN(v587, v588);
    pipe_barrier(PIPE_V);
    TEXP(v587, v585);
    // pto: %t__tmp_v26
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v589 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %t__tmp_v26
    ;
    uint64_t v590 = (uint64_t) v33;
    TASSIGN(v589, v590);
    pipe_barrier(PIPE_V);
    TADDS(v589, v587, v73);
    // pto: %post_sig_inline2920__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v591 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %post_sig_inline2920__ssa_v0
    ;
    uint64_t v592 = (uint64_t) v33;
    TASSIGN(v591, v592);
    pipe_barrier(PIPE_V);
    TDIV(v591, v583, v589);
    // pto: %post_pad_inline2921__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v593 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %post_pad_inline2921__ssa_v0
    ;
    uint64_t v594 = (uint64_t) v33;
    TASSIGN(v593, v594);
    pipe_barrier(PIPE_V);
    TMULS(v593, v591, v74);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
    // pto: %151
    ;
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    if (v504 == v58) {
      // pto: %t__tmp_v27
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v595 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v56);
      // pto: %t__tmp_v27
      ;
      uint64_t v596 = (uint64_t) v33;
      TASSIGN(v595, v596);
      // pto: %152
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, 8, 4, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v597;
      // pto: %152
      ;
      uint64_t v598 = (uint64_t) v33;
      TASSIGN(v597, v598);
      // pto: %post__ssa_v0_pview
      ;
      __gm__ float* v599 = PTOAS__GLOBAL_TENSOR_DATA(v158);
      // pto: %post__ssa_v0_pview
      ;
      const int64_t v600 = 0;
      // pto: %post__ssa_v0_pview
      ;
      const int64_t v601 = 4;
      // pto: %post__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 4> v602 = pto::Shape<1, 1, 1, 8, 4>();
      // pto: %post__ssa_v0_pview
      ;
      pto::Stride<32, 32, 32, 4, 1> v603 = pto::Stride<32, 32, 32, 4, 1>();
      // pto: %post__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<32, 32, 32, 4, 1>, pto::Layout::ND> v604 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<32, 32, 32, 4, 1>, pto::Layout::ND>(v599 + (v600 + v507 * v601), v602, v603);
      TSTORE(v604, v597);
    } else {
      // pto: %155
      ;
      int64_t v605 = v394 < v61 ? v61 : v394;
      // pto: %156
      ;
      __gm__ float* v606 = PTOAS__GLOBAL_TENSOR_DATA(v130);
      // pto: %156
      ;
      const int64_t v607 = 0;
      // pto: %156
      ;
      const int64_t v608 = 64;
      // pto: %156
      ;
      pto::Shape<1, 1, 1, 8, 8> v609 = pto::Shape<1, 1, 1, 8, 8>();
      // pto: %156
      ;
      pto::Stride<512, 512, 512, 64, 1> v610 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %156
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v611 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v606 + (v607 + v605 * v608), v609, v610);
      TSTORE(v611, v593);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      // pto: %post_tile_inline2922__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v612 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v504, v56);
      // pto: %post_tile_inline2922__ssa_v0
      ;
      uint64_t v613 = (uint64_t) v33;
      TASSIGN(v612, v613);
      // pto: %159
      ;
      const int64_t v614 = 0;
      // pto: %159
      ;
      __gm__ float* v615 = PTOAS__GLOBAL_TENSOR_DATA(v130);
      // pto: %159
      ;
      const int64_t v616 = 1;
      // pto: %159
      ;
      const int64_t v617 = 1;
      // pto: %159
      ;
      const int64_t v618 = 1;
      // pto: %159
      ;
      int64_t v619 = v504 * v54;
      // pto: %159
      ;
      int64_t v620 = v618 * v619;
      // pto: %159
      ;
      pto::Shape<1, 1, 1, -1, 4> v621 = pto::Shape<1, 1, 1, -1, 4>(v616, v617, v618, v504, v56);
      // pto: %159
      ;
      pto::Stride<-1, -1, -1, -1, -1> v622 = pto::Stride<-1, -1, -1, -1, -1>(v617 * v620, v620, v619, v54, v50);
      // pto: %159
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v623 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v615 + (v614 + v605 * v54 + v61 * v50), v621, v622);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      TLOAD(v612, v623);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
      // pto: %161
      ;
      const int64_t v624 = 0;
      // pto: %161
      ;
      __gm__ float* v625 = PTOAS__GLOBAL_TENSOR_DATA(v158);
      // pto: %161
      ;
      const int64_t v626 = 1;
      // pto: %161
      ;
      const int64_t v627 = 1;
      // pto: %161
      ;
      const int64_t v628 = 1;
      // pto: %161
      ;
      int64_t v629 = v504 * v56;
      // pto: %161
      ;
      int64_t v630 = v628 * v629;
      // pto: %161
      ;
      pto::Shape<1, 1, 1, -1, 4> v631 = pto::Shape<1, 1, 1, -1, 4>(v626, v627, v628, v504, v56);
      // pto: %161
      ;
      pto::Stride<-1, -1, -1, -1, -1> v632 = pto::Stride<-1, -1, -1, -1, -1>(v627 * v630, v630, v629, v56, v50);
      // pto: %161
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v633 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v625 + (v624 + v507 * v56 + v61 * v50), v631, v632);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
      TSTORE(v633, v612);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v634 = v196; v634 < v403; v634 += v60) {
    // pto: %164
    ;
    int64_t v635 = (int64_t) ((uint64_t) v634 * (uint64_t) v58);
    // pto: %165
    ;
    int64_t v636 = (int64_t) ((uint64_t) v18 - (uint64_t) v635);
    // pto: %166
    ;
    int64_t v637 = v636 < v58 ? v636 : v58;
    // pto: %10
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v638 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %10
    ;
    uint64_t v639 = (uint64_t) v33;
    TASSIGN(v638, v639);
    // pto: %167
    ;
    int64_t v640 = v635 < v61 ? v61 : v635;
    // pto: %168
    ;
    __gm__ float* v641 = PTOAS__GLOBAL_TENSOR_DATA(v130);
    // pto: %168
    ;
    const int64_t v642 = 32;
    // pto: %168
    ;
    const int64_t v643 = 64;
    // pto: %168
    ;
    pto::Shape<1, 1, 1, 8, 8> v644 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %168
    ;
    pto::Stride<512, 512, 512, 64, 1> v645 = pto::Stride<512, 512, 512, 64, 1>();
    // pto: %168
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v646 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v641 + (v642 + v640 * v643), v644, v645);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v638, v646);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
    // pto: %11
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v647 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %11
    ;
    uint64_t v648 = (uint64_t) v34;
    TASSIGN(v647, v648);
    // pto: %pre_tile_t_inline2929__tile
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v649 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v58);
    // pto: %pre_tile_t_inline2929__tile
    ;
    uint64_t v650 = (uint64_t) v35;
    TASSIGN(v649, v650);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
    TTRANS(v649, v638, v647);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    // pto: %12
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v651 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %12
    ;
    uint64_t v652 = (uint64_t) v35;
    TASSIGN(v651, v652);
    // pto: %pre0_inline2930__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v653 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v50);
    // pto: %pre0_inline2930__tile
    ;
    uint64_t v654 = (uint64_t) v35;
    TASSIGN(v653, v654);
    // pto: %13
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v655 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %13
    ;
    uint64_t v656 = (uint64_t) v36;
    TASSIGN(v655, v656);
    // pto: %pre1_inline2931__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v657 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v50);
    // pto: %pre1_inline2931__tile
    ;
    uint64_t v658 = (uint64_t) v36;
    TASSIGN(v657, v658);
    // pto: %14
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v659 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %14
    ;
    uint64_t v660 = (uint64_t) v37;
    TASSIGN(v659, v660);
    // pto: %pre2_inline2932__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v661 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v50);
    // pto: %pre2_inline2932__tile
    ;
    uint64_t v662 = (uint64_t) v37;
    TASSIGN(v661, v662);
    // pto: %15
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v663 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %15
    ;
    uint64_t v664 = (uint64_t) v38;
    TASSIGN(v663, v664);
    // pto: %pre3_inline2933__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v665 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v50);
    // pto: %pre3_inline2933__tile
    ;
    uint64_t v666 = (uint64_t) v38;
    TASSIGN(v665, v666);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    for (int64_t v667 = v61; v667 < v51; v667 += v59) {
      // pto: %173
      ;
      int64_t v668 = (int64_t) ((uint64_t) v667 * (uint64_t) v63);
      // pto: %176
      ;
      int64_t v669 = (int64_t) ((uint64_t) v668 + (uint64_t) v63);
      // pto: %x0_inline2936__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v670 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %x0_inline2936__tile
      ;
      uint64_t v671 = (uint64_t) v33;
      TASSIGN(v670, v671);
      // pto: %179
      ;
      int64_t v672 = v668 < v61 ? v61 : v668;
      // pto: %180
      ;
      const int64_t v673 = 0;
      // pto: %180
      ;
      __gm__ float* v674 = PTOAS__GLOBAL_TENSOR_DATA(v94);
      // pto: %180
      ;
      const int64_t v675 = 1;
      // pto: %180
      ;
      const int64_t v676 = 1;
      // pto: %180
      ;
      const int64_t v677 = 1;
      // pto: %180
      ;
      int64_t v678 = v637 * v49;
      // pto: %180
      ;
      int64_t v679 = v677 * v678;
      // pto: %180
      ;
      pto::Shape<1, 1, 1, -1, 256> v680 = pto::Shape<1, 1, 1, -1, 256>(v675, v676, v677, v637, v63);
      // pto: %180
      ;
      pto::Stride<-1, -1, -1, -1, -1> v681 = pto::Stride<-1, -1, -1, -1, -1>(v676 * v679, v679, v678, v49, v50);
      // pto: %180
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v682 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v674 + (v673 + v640 * v49 + v672 * v50), v680, v681);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      TLOAD(v670, v682);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %x1_inline2937__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v683 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %x1_inline2937__tile
      ;
      uint64_t v684 = (uint64_t) v34;
      TASSIGN(v683, v684);
      // pto: %182
      ;
      int64_t v685 = (int64_t) ((uint64_t) v668 + (uint64_t) v57);
      // pto: %183
      ;
      int64_t v686 = v685 < v61 ? v61 : v685;
      // pto: %184
      ;
      const int64_t v687 = 0;
      // pto: %184
      ;
      __gm__ float* v688 = PTOAS__GLOBAL_TENSOR_DATA(v94);
      // pto: %184
      ;
      const int64_t v689 = 1;
      // pto: %184
      ;
      const int64_t v690 = 1;
      // pto: %184
      ;
      const int64_t v691 = 1;
      // pto: %184
      ;
      int64_t v692 = v637 * v49;
      // pto: %184
      ;
      int64_t v693 = v691 * v692;
      // pto: %184
      ;
      pto::Shape<1, 1, 1, -1, 256> v694 = pto::Shape<1, 1, 1, -1, 256>(v689, v690, v691, v637, v63);
      // pto: %184
      ;
      pto::Stride<-1, -1, -1, -1, -1> v695 = pto::Stride<-1, -1, -1, -1, -1>(v690 * v693, v693, v692, v49, v50);
      // pto: %184
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v696 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v688 + (v687 + v640 * v49 + v686 * v50), v694, v695);
      TLOAD(v683, v696);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %x2_inline2938__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v697 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %x2_inline2938__tile
      ;
      uint64_t v698 = (uint64_t) v31;
      TASSIGN(v697, v698);
      // pto: %186
      ;
      int64_t v699 = (int64_t) ((uint64_t) v668 + (uint64_t) v75);
      // pto: %187
      ;
      int64_t v700 = v699 < v61 ? v61 : v699;
      // pto: %188
      ;
      const int64_t v701 = 0;
      // pto: %188
      ;
      __gm__ float* v702 = PTOAS__GLOBAL_TENSOR_DATA(v94);
      // pto: %188
      ;
      const int64_t v703 = 1;
      // pto: %188
      ;
      const int64_t v704 = 1;
      // pto: %188
      ;
      const int64_t v705 = 1;
      // pto: %188
      ;
      int64_t v706 = v637 * v49;
      // pto: %188
      ;
      int64_t v707 = v705 * v706;
      // pto: %188
      ;
      pto::Shape<1, 1, 1, -1, 256> v708 = pto::Shape<1, 1, 1, -1, 256>(v703, v704, v705, v637, v63);
      // pto: %188
      ;
      pto::Stride<-1, -1, -1, -1, -1> v709 = pto::Stride<-1, -1, -1, -1, -1>(v704 * v707, v707, v706, v49, v50);
      // pto: %188
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v710 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v702 + (v701 + v640 * v49 + v700 * v50), v708, v709);
      TLOAD(v697, v710);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %x3_inline2939__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v711 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %x3_inline2939__tile
      ;
      uint64_t v712 = (uint64_t) v32;
      TASSIGN(v711, v712);
      // pto: %190
      ;
      int64_t v713 = (int64_t) ((uint64_t) v668 + (uint64_t) v76);
      // pto: %191
      ;
      int64_t v714 = v713 < v61 ? v61 : v713;
      // pto: %192
      ;
      const int64_t v715 = 0;
      // pto: %192
      ;
      __gm__ float* v716 = PTOAS__GLOBAL_TENSOR_DATA(v94);
      // pto: %192
      ;
      const int64_t v717 = 1;
      // pto: %192
      ;
      const int64_t v718 = 1;
      // pto: %192
      ;
      const int64_t v719 = 1;
      // pto: %192
      ;
      int64_t v720 = v637 * v49;
      // pto: %192
      ;
      int64_t v721 = v719 * v720;
      // pto: %192
      ;
      pto::Shape<1, 1, 1, -1, 256> v722 = pto::Shape<1, 1, 1, -1, 256>(v717, v718, v719, v637, v63);
      // pto: %192
      ;
      pto::Stride<-1, -1, -1, -1, -1> v723 = pto::Stride<-1, -1, -1, -1, -1>(v718 * v721, v721, v720, v49, v50);
      // pto: %192
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v724 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v716 + (v715 + v640 * v49 + v714 * v50), v722, v723);
      TLOAD(v711, v724);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %16
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v725 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %16
      ;
      uint64_t v726 = (uint64_t) v39;
      TASSIGN(v725, v726);
      // pto: %194
      ;
      int64_t v727 = v669 < v61 ? v61 : v669;
      // pto: %195
      ;
      const int64_t v728 = 0;
      // pto: %195
      ;
      __gm__ float* v729 = PTOAS__GLOBAL_TENSOR_DATA(v94);
      // pto: %195
      ;
      const int64_t v730 = 1;
      // pto: %195
      ;
      const int64_t v731 = 1;
      // pto: %195
      ;
      const int64_t v732 = 1;
      // pto: %195
      ;
      int64_t v733 = v637 * v49;
      // pto: %195
      ;
      int64_t v734 = v732 * v733;
      // pto: %195
      ;
      pto::Shape<1, 1, 1, -1, 256> v735 = pto::Shape<1, 1, 1, -1, 256>(v730, v731, v732, v637, v63);
      // pto: %195
      ;
      pto::Stride<-1, -1, -1, -1, -1> v736 = pto::Stride<-1, -1, -1, -1, -1>(v731 * v734, v734, v733, v49, v50);
      // pto: %195
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v737 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v729 + (v728 + v640 * v49 + v727 * v50), v735, v736);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      TLOAD(v725, v737);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      // pto: %17
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v738 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %17
      ;
      uint64_t v739 = (uint64_t) v40;
      TASSIGN(v738, v739);
      int64_t v740 = (int64_t) ((uint64_t) v668 + (uint64_t) v27);
      // pto: %198
      ;
      int64_t v741 = v740 < v61 ? v61 : v740;
      // pto: %199
      ;
      const int64_t v742 = 0;
      // pto: %199
      ;
      __gm__ float* v743 = PTOAS__GLOBAL_TENSOR_DATA(v94);
      // pto: %199
      ;
      const int64_t v744 = 1;
      // pto: %199
      ;
      const int64_t v745 = 1;
      // pto: %199
      ;
      const int64_t v746 = 1;
      // pto: %199
      ;
      int64_t v747 = v637 * v49;
      // pto: %199
      ;
      int64_t v748 = v746 * v747;
      // pto: %199
      ;
      pto::Shape<1, 1, 1, -1, 256> v749 = pto::Shape<1, 1, 1, -1, 256>(v744, v745, v746, v637, v63);
      // pto: %199
      ;
      pto::Stride<-1, -1, -1, -1, -1> v750 = pto::Stride<-1, -1, -1, -1, -1>(v745 * v748, v748, v747, v49, v50);
      // pto: %199
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v751 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v743 + (v742 + v640 * v49 + v741 * v50), v749, v750);
      TLOAD(v738, v751);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      // pto: %18
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v752 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %18
      ;
      uint64_t v753 = (uint64_t) v41;
      TASSIGN(v752, v753);
      int64_t v754 = (int64_t) ((uint64_t) v668 + (uint64_t) v26);
      // pto: %202
      ;
      int64_t v755 = v754 < v61 ? v61 : v754;
      // pto: %203
      ;
      const int64_t v756 = 0;
      // pto: %203
      ;
      __gm__ float* v757 = PTOAS__GLOBAL_TENSOR_DATA(v94);
      // pto: %203
      ;
      const int64_t v758 = 1;
      // pto: %203
      ;
      const int64_t v759 = 1;
      // pto: %203
      ;
      const int64_t v760 = 1;
      // pto: %203
      ;
      int64_t v761 = v637 * v49;
      // pto: %203
      ;
      int64_t v762 = v760 * v761;
      // pto: %203
      ;
      pto::Shape<1, 1, 1, -1, 256> v763 = pto::Shape<1, 1, 1, -1, 256>(v758, v759, v760, v637, v63);
      // pto: %203
      ;
      pto::Stride<-1, -1, -1, -1, -1> v764 = pto::Stride<-1, -1, -1, -1, -1>(v759 * v762, v762, v761, v49, v50);
      // pto: %203
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v765 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v757 + (v756 + v640 * v49 + v755 * v50), v763, v764);
      TLOAD(v752, v765);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
      // pto: %19
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v766 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %19
      ;
      uint64_t v767 = (uint64_t) v42;
      TASSIGN(v766, v767);
      int64_t v768 = (int64_t) ((uint64_t) v668 + (uint64_t) v25);
      // pto: %206
      ;
      int64_t v769 = v768 < v61 ? v61 : v768;
      // pto: %207
      ;
      const int64_t v770 = 0;
      // pto: %207
      ;
      __gm__ float* v771 = PTOAS__GLOBAL_TENSOR_DATA(v94);
      // pto: %207
      ;
      const int64_t v772 = 1;
      // pto: %207
      ;
      const int64_t v773 = 1;
      // pto: %207
      ;
      const int64_t v774 = 1;
      // pto: %207
      ;
      int64_t v775 = v637 * v49;
      // pto: %207
      ;
      int64_t v776 = v774 * v775;
      // pto: %207
      ;
      pto::Shape<1, 1, 1, -1, 256> v777 = pto::Shape<1, 1, 1, -1, 256>(v772, v773, v774, v637, v63);
      // pto: %207
      ;
      pto::Stride<-1, -1, -1, -1, -1> v778 = pto::Stride<-1, -1, -1, -1, -1>(v773 * v776, v776, v775, v49, v50);
      // pto: %207
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v779 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v771 + (v770 + v640 * v49 + v769 * v50), v777, v778);
      TLOAD(v766, v779);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
      // pto: %y0_inline2940__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v780 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %y0_inline2940__tile
      ;
      uint64_t v781 = (uint64_t) v33;
      TASSIGN(v780, v781);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      TROWEXPANDMUL(v780, v670, v653);
      // pto: %y1_inline2941__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v782 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %y1_inline2941__tile
      ;
      uint64_t v783 = (uint64_t) v34;
      TASSIGN(v782, v783);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      TROWEXPANDMUL(v782, v683, v657);
      // pto: %y2_inline2942__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v784 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %y2_inline2942__tile
      ;
      uint64_t v785 = (uint64_t) v31;
      TASSIGN(v784, v785);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      TROWEXPANDMUL(v784, v697, v661);
      // pto: %y3_inline2943__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v786 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %y3_inline2943__tile
      ;
      uint64_t v787 = (uint64_t) v32;
      TASSIGN(v786, v787);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      TROWEXPANDMUL(v786, v711, v665);
      // pto: %20
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v788 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %20
      ;
      uint64_t v789 = (uint64_t) v33;
      TASSIGN(v788, v789);
      pipe_barrier(PIPE_V);
      TADD(v788, v780, v782);
      // pto: %21
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v790 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %21
      ;
      uint64_t v791 = (uint64_t) v33;
      TASSIGN(v790, v791);
      pipe_barrier(PIPE_V);
      TADD(v790, v788, v784);
      // pto: %y_tile_inline2944__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v792 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %y_tile_inline2944__tile
      ;
      uint64_t v793 = (uint64_t) v33;
      TASSIGN(v792, v793);
      pipe_barrier(PIPE_V);
      TADD(v792, v790, v786);
      // pto: %y_bf16_inline2945__tile
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v794 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %y_bf16_inline2945__tile
      ;
      uint64_t v795 = (uint64_t) v33;
      TASSIGN(v794, v795);
      pipe_barrier(PIPE_V);
      RoundMode v796 = RoundMode::CAST_RINT;
      SaturationMode v797 = SaturationMode::ON;
      TCVT(v794, v792, v796, v797);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      // pto: %208
      ;
      bool v798 = v637 == v58;
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      if (v798) {
        // pto: %mixed__iter_v3_pview
        ;
        const int64_t v799 = 0;
        // pto: %mixed__iter_v3_pview
        ;
        __gm__ bfloat16_t* v800 = PTOAS__GLOBAL_TENSOR_DATA(v167);
        // pto: %mixed__iter_v3_pview
        ;
        const int64_t v801 = 1;
        // pto: %mixed__iter_v3_pview
        ;
        const int64_t v802 = 1;
        // pto: %mixed__iter_v3_pview
        ;
        const int64_t v803 = 1;
        // pto: %mixed__iter_v3_pview
        ;
        int64_t v804 = v637 * v57;
        // pto: %mixed__iter_v3_pview
        ;
        int64_t v805 = v803 * v804;
        // pto: %mixed__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v806 = pto::Shape<1, 1, 1, -1, 256>(v801, v802, v803, v637, v63);
        // pto: %mixed__iter_v3_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v807 = pto::Stride<-1, -1, -1, -1, -1>(v802 * v805, v805, v804, v57, v50);
        // pto: %mixed__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v808 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v800 + (v799 + v640 * v57 + v672 * v50), v806, v807);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v808, v794);
      } else {
        // pto: %mixed_tail__iter_v3_pview
        ;
        const int64_t v809 = 0;
        // pto: %mixed_tail__iter_v3_pview
        ;
        __gm__ bfloat16_t* v810 = PTOAS__GLOBAL_TENSOR_DATA(v175);
        // pto: %mixed_tail__iter_v3_pview
        ;
        const int64_t v811 = 1;
        // pto: %mixed_tail__iter_v3_pview
        ;
        const int64_t v812 = 1;
        // pto: %mixed_tail__iter_v3_pview
        ;
        const int64_t v813 = 1;
        // pto: %mixed_tail__iter_v3_pview
        ;
        int64_t v814 = v637 * v57;
        // pto: %mixed_tail__iter_v3_pview
        ;
        int64_t v815 = v813 * v814;
        // pto: %mixed_tail__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v816 = pto::Shape<1, 1, 1, -1, 256>(v811, v812, v813, v637, v63);
        // pto: %mixed_tail__iter_v3_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v817 = pto::Stride<-1, -1, -1, -1, -1>(v812 * v815, v815, v814, v57, v50);
        // pto: %mixed_tail__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v818 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v810 + (v809 + v61 * v57 + v672 * v50), v816, v817);
        TSTORE(v818, v794);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        // pto: %y_out_inline2946__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v819 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
        // pto: %y_out_inline2946__ssa_v0
        ;
        uint64_t v820 = (uint64_t) v33;
        TASSIGN(v819, v820);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        TLOAD(v819, v818);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
        // pto: %215
        ;
        const int64_t v821 = 0;
        // pto: %215
        ;
        __gm__ bfloat16_t* v822 = PTOAS__GLOBAL_TENSOR_DATA(v167);
        // pto: %215
        ;
        const int64_t v823 = 1;
        // pto: %215
        ;
        const int64_t v824 = 1;
        // pto: %215
        ;
        const int64_t v825 = 1;
        // pto: %215
        ;
        int64_t v826 = v637 * v57;
        // pto: %215
        ;
        int64_t v827 = v825 * v826;
        // pto: %215
        ;
        pto::Shape<1, 1, 1, -1, 256> v828 = pto::Shape<1, 1, 1, -1, 256>(v823, v824, v825, v637, v63);
        // pto: %215
        ;
        pto::Stride<-1, -1, -1, -1, -1> v829 = pto::Stride<-1, -1, -1, -1, -1>(v824 * v827, v827, v826, v57, v50);
        // pto: %215
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v830 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v822 + (v821 + v640 * v57 + v672 * v50), v828, v829);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
        TSTORE(v830, v819);
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      // pto: %22
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v831 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %22
      ;
      uint64_t v832 = (uint64_t) v39;
      TASSIGN(v831, v832);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      TROWEXPANDMUL(v831, v725, v653);
      // pto: %23
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v833 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %23
      ;
      uint64_t v834 = (uint64_t) v40;
      TASSIGN(v833, v834);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      TROWEXPANDMUL(v833, v738, v657);
      // pto: %24
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v835 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %24
      ;
      uint64_t v836 = (uint64_t) v41;
      TASSIGN(v835, v836);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
      TROWEXPANDMUL(v835, v752, v661);
      // pto: %25
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v837 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %25
      ;
      uint64_t v838 = (uint64_t) v42;
      TASSIGN(v837, v838);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
      TROWEXPANDMUL(v837, v766, v665);
      // pto: %26
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v839 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %26
      ;
      uint64_t v840 = (uint64_t) v39;
      TASSIGN(v839, v840);
      pipe_barrier(PIPE_V);
      TADD(v839, v831, v833);
      // pto: %27
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v841 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %27
      ;
      uint64_t v842 = (uint64_t) v39;
      TASSIGN(v841, v842);
      pipe_barrier(PIPE_V);
      TADD(v841, v839, v835);
      // pto: %28
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v843 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %28
      ;
      uint64_t v844 = (uint64_t) v39;
      TASSIGN(v843, v844);
      pipe_barrier(PIPE_V);
      TADD(v843, v841, v837);
      // pto: %29
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v845 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
      // pto: %29
      ;
      uint64_t v846 = (uint64_t) v39;
      TASSIGN(v845, v846);
      pipe_barrier(PIPE_V);
      RoundMode v847 = RoundMode::CAST_RINT;
      SaturationMode v848 = SaturationMode::ON;
      TCVT(v845, v843, v847, v848);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      if (v798) {
        // pto: %mixed__phi_v6_pview
        ;
        const int64_t v849 = 0;
        // pto: %mixed__phi_v6_pview
        ;
        __gm__ bfloat16_t* v850 = PTOAS__GLOBAL_TENSOR_DATA(v167);
        // pto: %mixed__phi_v6_pview
        ;
        const int64_t v851 = 1;
        // pto: %mixed__phi_v6_pview
        ;
        const int64_t v852 = 1;
        // pto: %mixed__phi_v6_pview
        ;
        const int64_t v853 = 1;
        // pto: %mixed__phi_v6_pview
        ;
        int64_t v854 = v637 * v57;
        // pto: %mixed__phi_v6_pview
        ;
        int64_t v855 = v853 * v854;
        // pto: %mixed__phi_v6_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v856 = pto::Shape<1, 1, 1, -1, 256>(v851, v852, v853, v637, v63);
        // pto: %mixed__phi_v6_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v857 = pto::Stride<-1, -1, -1, -1, -1>(v852 * v855, v855, v854, v57, v50);
        // pto: %mixed__phi_v6_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v858 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v850 + (v849 + v640 * v57 + v727 * v50), v856, v857);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v858, v845);
      } else {
        // pto: %mixed_tail__phi_v6_pview
        ;
        const int64_t v859 = 0;
        // pto: %mixed_tail__phi_v6_pview
        ;
        __gm__ bfloat16_t* v860 = PTOAS__GLOBAL_TENSOR_DATA(v175);
        // pto: %mixed_tail__phi_v6_pview
        ;
        const int64_t v861 = 1;
        // pto: %mixed_tail__phi_v6_pview
        ;
        const int64_t v862 = 1;
        // pto: %mixed_tail__phi_v6_pview
        ;
        const int64_t v863 = 1;
        // pto: %mixed_tail__phi_v6_pview
        ;
        int64_t v864 = v637 * v57;
        // pto: %mixed_tail__phi_v6_pview
        ;
        int64_t v865 = v863 * v864;
        // pto: %mixed_tail__phi_v6_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v866 = pto::Shape<1, 1, 1, -1, 256>(v861, v862, v863, v637, v63);
        // pto: %mixed_tail__phi_v6_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v867 = pto::Stride<-1, -1, -1, -1, -1>(v862 * v865, v865, v864, v57, v50);
        // pto: %mixed_tail__phi_v6_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v868 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v860 + (v859 + v61 * v57 + v727 * v50), v866, v867);
        TSTORE(v868, v845);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        // pto: %30
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v869 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v637, v63);
        // pto: %30
        ;
        uint64_t v870 = (uint64_t) v39;
        TASSIGN(v869, v870);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        TLOAD(v869, v868);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID3);
        // pto: %226
        ;
        const int64_t v871 = 0;
        // pto: %226
        ;
        __gm__ bfloat16_t* v872 = PTOAS__GLOBAL_TENSOR_DATA(v167);
        // pto: %226
        ;
        const int64_t v873 = 1;
        // pto: %226
        ;
        const int64_t v874 = 1;
        // pto: %226
        ;
        const int64_t v875 = 1;
        // pto: %226
        ;
        int64_t v876 = v637 * v57;
        // pto: %226
        ;
        int64_t v877 = v875 * v876;
        // pto: %226
        ;
        pto::Shape<1, 1, 1, -1, 256> v878 = pto::Shape<1, 1, 1, -1, 256>(v873, v874, v875, v637, v63);
        // pto: %226
        ;
        pto::Stride<-1, -1, -1, -1, -1> v879 = pto::Stride<-1, -1, -1, -1, -1>(v874 * v877, v877, v876, v57, v50);
        // pto: %226
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v880 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v872 + (v871 + v640 * v57 + v727 * v50), v878, v879);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID3);
        TSTORE(v880, v869);
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    };
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v881 = v196; v881 < v18; v881 += v60) {
    // pto: %raw_inline2949__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v882 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v57);
    // pto: %raw_inline2949__ssa_v0
    ;
    uint64_t v883 = (uint64_t) v34;
    TASSIGN(v882, v883);
    // pto: %227
    ;
    int64_t v884 = v881 < v61 ? v61 : v881;
    // pto: %mixed__ssa_v7_pview
    ;
    __gm__ bfloat16_t* v885 = PTOAS__GLOBAL_TENSOR_DATA(v167);
    // pto: %mixed__ssa_v7_pview
    ;
    const int64_t v886 = 0;
    // pto: %mixed__ssa_v7_pview
    ;
    const int64_t v887 = 4096;
    // pto: %mixed__ssa_v7_pview
    ;
    pto::Shape<1, 1, 1, 1, 4096> v888 = pto::Shape<1, 1, 1, 1, 4096>();
    // pto: %mixed__ssa_v7_pview
    ;
    pto::Stride<4096, 4096, 4096, 4096, 1> v889 = pto::Stride<4096, 4096, 4096, 4096, 1>();
    // pto: %mixed__ssa_v7_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v890 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v885 + (v886 + v884 * v887), v888, v889);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v882, v890);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %wide_inline2950__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v891 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v57);
    // pto: %wide_inline2950__ssa_v0
    ;
    uint64_t v892 = (uint64_t) v33;
    TASSIGN(v891, v892);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
    RoundMode v893 = RoundMode::CAST_ROUND;
    SaturationMode v894 = SaturationMode::ON;
    TCVT(v891, v882, v893, v894);
    // pto: %square_inline2951__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v895 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v57);
    // pto: %square_inline2951__ssa_v0
    ;
    uint64_t v896 = (uint64_t) v34;
    TASSIGN(v895, v896);
    pipe_barrier(PIPE_V);
    TMUL(v895, v891, v891);
    // pto: %t__tmp_v37
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v897 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v77);
    // pto: %t__tmp_v37
    ;
    uint64_t v898 = (uint64_t) v34;
    TASSIGN(v897, v898);
    // pto: %228
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v899;
    // pto: %228
    ;
    uint64_t v900 = (uint64_t) v34;
    TASSIGN(v899, v900);
    // pto: %t__tmp_v38
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v901 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v77);
    // pto: %t__tmp_v38
    ;
    uint64_t v902 = (uint64_t) v43;
    TASSIGN(v901, v902);
    // pto: %229
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v903;
    // pto: %229
    ;
    uint64_t v904 = (uint64_t) v43;
    TASSIGN(v903, v904);
    // pto: %fold2048_inline2952__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v905 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v77);
    // pto: %fold2048_inline2952__ssa_v0
    ;
    uint64_t v906 = (uint64_t) v34;
    TASSIGN(v905, v906);
    pipe_barrier(PIPE_V);
    TADD(v905, v899, v903);
    // pto: %t__tmp_v39
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v907 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v78);
    // pto: %t__tmp_v39
    ;
    uint64_t v908 = (uint64_t) v34;
    TASSIGN(v907, v908);
    // pto: %230
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v909;
    // pto: %230
    ;
    uint64_t v910 = (uint64_t) v34;
    TASSIGN(v909, v910);
    // pto: %t__tmp_v40
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v911 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v78);
    // pto: %t__tmp_v40
    ;
    uint64_t v912 = (uint64_t) v44;
    TASSIGN(v911, v912);
    // pto: %231
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v913;
    // pto: %231
    ;
    uint64_t v914 = (uint64_t) v44;
    TASSIGN(v913, v914);
    // pto: %fold1024_inline2953__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v915 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v78);
    // pto: %fold1024_inline2953__ssa_v0
    ;
    uint64_t v916 = (uint64_t) v34;
    TASSIGN(v915, v916);
    pipe_barrier(PIPE_V);
    TADD(v915, v909, v913);
    // pto: %t__tmp_v41
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v917 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
    // pto: %t__tmp_v41
    ;
    uint64_t v918 = (uint64_t) v34;
    TASSIGN(v917, v918);
    // pto: %232
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v919;
    // pto: %232
    ;
    uint64_t v920 = (uint64_t) v34;
    TASSIGN(v919, v920);
    // pto: %t__tmp_v42
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v921 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
    // pto: %t__tmp_v42
    ;
    uint64_t v922 = (uint64_t) v45;
    TASSIGN(v921, v922);
    // pto: %233
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v923;
    // pto: %233
    ;
    uint64_t v924 = (uint64_t) v45;
    TASSIGN(v923, v924);
    // pto: %fold512_inline2954__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v925 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
    // pto: %fold512_inline2954__ssa_v0
    ;
    uint64_t v926 = (uint64_t) v34;
    TASSIGN(v925, v926);
    pipe_barrier(PIPE_V);
    TADD(v925, v919, v923);
    // pto: %t__tmp_v43
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v927 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v63);
    // pto: %t__tmp_v43
    ;
    uint64_t v928 = (uint64_t) v34;
    TASSIGN(v927, v928);
    // pto: %234
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v929;
    // pto: %234
    ;
    uint64_t v930 = (uint64_t) v34;
    TASSIGN(v929, v930);
    // pto: %t__tmp_v44
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v931 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v63);
    // pto: %t__tmp_v44
    ;
    uint64_t v932 = (uint64_t) v46;
    TASSIGN(v931, v932);
    // pto: %235
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v933;
    // pto: %235
    ;
    uint64_t v934 = (uint64_t) v46;
    TASSIGN(v933, v934);
    // pto: %fold256_inline2955__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v935 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v63);
    // pto: %fold256_inline2955__ssa_v0
    ;
    uint64_t v936 = (uint64_t) v34;
    TASSIGN(v935, v936);
    pipe_barrier(PIPE_V);
    TADD(v935, v929, v933);
    // pto: %t__tmp_v45
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v937 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v79);
    // pto: %t__tmp_v45
    ;
    uint64_t v938 = (uint64_t) v34;
    TASSIGN(v937, v938);
    // pto: %236
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v939;
    // pto: %236
    ;
    uint64_t v940 = (uint64_t) v34;
    TASSIGN(v939, v940);
    // pto: %t__tmp_v46
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v941 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v79);
    // pto: %t__tmp_v46
    ;
    uint64_t v942 = (uint64_t) v47;
    TASSIGN(v941, v942);
    // pto: %237
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v943;
    // pto: %237
    ;
    uint64_t v944 = (uint64_t) v47;
    TASSIGN(v943, v944);
    // pto: %fold128_inline2956__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v945 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v79);
    // pto: %fold128_inline2956__ssa_v0
    ;
    uint64_t v946 = (uint64_t) v34;
    TASSIGN(v945, v946);
    pipe_barrier(PIPE_V);
    TADD(v945, v939, v943);
    // pto: %t__tmp_v47
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v947 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v54);
    // pto: %t__tmp_v47
    ;
    uint64_t v948 = (uint64_t) v34;
    TASSIGN(v947, v948);
    // pto: %238
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v949;
    // pto: %238
    ;
    uint64_t v950 = (uint64_t) v34;
    TASSIGN(v949, v950);
    // pto: %t__tmp_v48
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v951 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v54);
    // pto: %t__tmp_v48
    ;
    uint64_t v952 = (uint64_t) v48;
    TASSIGN(v951, v952);
    // pto: %239
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v953;
    // pto: %239
    ;
    uint64_t v954 = (uint64_t) v48;
    TASSIGN(v953, v954);
    // pto: %fold64_inline2957__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v955 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v54);
    // pto: %fold64_inline2957__ssa_v0
    ;
    uint64_t v956 = (uint64_t) v31;
    TASSIGN(v955, v956);
    pipe_barrier(PIPE_V);
    TADD(v955, v949, v953);
    // pto: %t__tmp_v49
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v957 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v54);
    // pto: %t__tmp_v49
    ;
    uint64_t v958 = (uint64_t) v34;
    TASSIGN(v957, v958);
    // pto: %repeated_inline2958__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v959 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v54);
    // pto: %repeated_inline2958__ssa_v0
    ;
    uint64_t v960 = (uint64_t) v34;
    TASSIGN(v959, v960);
    pipe_barrier(PIPE_V);
    TCOLEXPAND(v959, v955);
    // pto: %t__tmp_v50
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v961 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v54);
    // pto: %t__tmp_v50
    ;
    uint64_t v962 = (uint64_t) v31;
    TASSIGN(v961, v962);
    // pto: %total_inline2959__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v963 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v58, v50);
    // pto: %total_inline2959__ssa_v0
    ;
    uint64_t v964 = (uint64_t) v32;
    TASSIGN(v963, v964);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID5);
    TROWSUM(v963, v959, v961);
    set_flag(PIPE_V, PIPE_S, EVENT_ID3);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID3);
    // pto: %total_scalar_inline2960__ssa_v0
    ;
    float v965 = v963.GetValue(v61);
    // pto: %31
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v966 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %31
    ;
    uint64_t v967 = (uint64_t) v34;
    TASSIGN(v966, v967);
    pipe_barrier(PIPE_V);
    TEXPANDS(v966, v73);
    // pto: %total_vector_inline2961__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v968 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %total_vector_inline2961__tile
    ;
    uint64_t v969 = (uint64_t) v34;
    TASSIGN(v968, v969);
    pipe_barrier(PIPE_V);
    TMULS(v968, v966, v965);
    // pto: %32
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v970 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %32
    ;
    uint64_t v971 = (uint64_t) v34;
    TASSIGN(v970, v971);
    pipe_barrier(PIPE_V);
    TMULS(v970, v968, v80);
    // pto: %variance_inline2962__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v972 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %variance_inline2962__tile
    ;
    uint64_t v973 = (uint64_t) v34;
    TASSIGN(v972, v973);
    pipe_barrier(PIPE_V);
    TADDS(v972, v970, v72);
    set_flag(PIPE_V, PIPE_S, EVENT_ID4);
    // pto: %root_value_inline2963__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v974 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %root_value_inline2963__tile
    ;
    uint64_t v975 = (uint64_t) v31;
    TASSIGN(v974, v975);
    pipe_barrier(PIPE_V);
    TSQRT(v974, v972);
    set_flag(PIPE_V, PIPE_S, EVENT_ID5);
    // pto: %variance_bits_inline2964__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v976 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %variance_bits_inline2964__tile
    ;
    uint64_t v977 = (uint64_t) v34;
    TASSIGN(v976, v977);
    // pto: %approx_bits_inline2965__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v978 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %approx_bits_inline2965__tile
    ;
    uint64_t v979 = (uint64_t) v31;
    TASSIGN(v978, v979);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID4);
    // pto: %240
    ;
    int32_t v980 = v976.GetValue(v61);
    set_flag(PIPE_S, PIPE_V, EVENT_ID6);
    // pto: %241
    ;
    int64_t v981 = (int64_t) v980;
    wait_flag(PIPE_V, PIPE_S, EVENT_ID5);
    // pto: %242
    ;
    int32_t v982 = v978.GetValue(v61);
    set_flag(PIPE_S, PIPE_MTE2, EVENT_ID1);
    // pto: %243
    ;
    int64_t v983 = (int64_t) v982;
    // pto: %245, %246, %247
    ;
    // pto: %y_bits_inline2967__phi_v7
    ;
    int64_t v984;
    if ((int64_t) v980 >= v81 & v981 < v82) {
      // pto: %249
      ;
      const int64_t v985 = 1;
      // pto: %249
      ;
      const int64_t v986 = 0;
      // pto: %249
      ;
      int64_t v987 = v981 / v30;
      // pto: %249
      ;
      bool v988 = v981 < v986;
      // pto: %249
      ;
      bool v989 = v30 < v986;
      // pto: %249
      ;
      bool v990 = v988 == v989;
      // pto: %249
      ;
      bool v991 = v981 % v30 != v986 && v988 != v989;
      // pto: %249
      ;
      int64_t v992 = v991 ? v987 - v985 : v987;
      // pto: %251
      ;
      int64_t v993 = v981 % v30;
      // pto: %255, %252, %256, %257, %258
      ;
      int64_t v994 = v993 != v41 & v993 < v41 ? (int64_t) ((uint64_t) v993 + (uint64_t) v30) : v993;
      // pto: %260
      ;
      int64_t v995 = (int64_t) ((uint64_t) v994 + (uint64_t) v30);
      // pto: %y_bits_inline2967__rv_v2
      ;
      int64_t v996;
      v996 = v983;
      for (int64_t v997 = v61; v997 < v59; v997 += v50) {
        // pto: %262
        ;
        const int64_t v998 = 1;
        // pto: %262
        ;
        const int64_t v999 = 0;
        // pto: %262
        ;
        int64_t v1000 = v996 / v30;
        // pto: %262
        ;
        int64_t v1001 = v996 % v30;
        // pto: %262
        ;
        bool v1002 = v996 < v999;
        // pto: %262
        ;
        bool v1003 = v30 < v999;
        // pto: %262
        ;
        bool v1004 = v1002 == v1003;
        // pto: %262
        ;
        bool v1005 = v1001 != v999 && v1002 != v1003;
        // pto: %262
        ;
        int64_t v1006 = v1005 ? v1000 - v998 : v1000;
        // pto: %264
        ;
        int64_t v1007 = v996 % v30;
        // pto: %268, %265, %269, %270, %271
        ;
        int64_t v1008 = v1007 != v41 & v1007 < v41 ? (int64_t) ((uint64_t) v1007 + (uint64_t) v30) : v1007;
        // pto: %273, %274, %276
        ;
        int64_t v1009 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v1008 + (uint64_t) v30) * (uint64_t) v83) + (uint64_t) v50);
        // pto: %277
        ;
        int64_t v1010 = (int64_t) ((uint64_t) v1009 * (uint64_t) v1009);
        // pto: %283, %281, %278, %282
        ;
        int64_t v1011 = (int64_t) ((uint64_t) v995 << (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v992 - (uint64_t) ((int64_t) (uint64_t) v1006 * (uint64_t) v83)) + (uint64_t) v84));
        // pto: %284
        ;
        uint64_t v1012 = (uint64_t) v996;
        // pto: %284
        ;
        int64_t v1013 = (int64_t) (v1012 - (uint64_t) v85);
        // pto: %286
        ;
        const int64_t v1014 = 1;
        // pto: %286
        ;
        const int64_t v1015 = 0;
        // pto: %286
        ;
        int64_t v1016 = v1013 / v30;
        // pto: %286
        ;
        bool v1017 = v1013 < v1015;
        // pto: %286
        ;
        bool v1018 = v30 < v1015;
        // pto: %286
        ;
        bool v1019 = v1017 == v1018;
        // pto: %286
        ;
        bool v1020 = v1013 % v30 != v1015 && v1017 != v1018;
        // pto: %286
        ;
        int64_t v1021 = v1020 ? v1016 - v1014 : v1016;
        // pto: %288
        ;
        int64_t v1022 = v1013 % v30;
        // pto: %292, %289, %293, %294, %295
        ;
        int64_t v1023 = v1022 != v41 & v1022 < v41 ? (int64_t) ((uint64_t) v1022 + (uint64_t) v30) : v1022;
        // pto: %297, %298, %300
        ;
        int64_t v1024 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v1023 + (uint64_t) v30) * (uint64_t) v83) + (uint64_t) v50);
        // pto: %301
        ;
        int64_t v1025 = (int64_t) ((uint64_t) v1024 * (uint64_t) v1024);
        // pto: %307, %305, %302, %306
        ;
        int64_t v1026 = (int64_t) ((uint64_t) v995 << (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v992 - (uint64_t) ((int64_t) (uint64_t) v1021 * (uint64_t) v83)) + (uint64_t) v84));
        // pto: %312
        ;
        int64_t v1027 = v996 % v83;
        // pto: %313, %314, %315
        ;
        int64_t v1028 = v1027 < v41 ? (int64_t) ((uint64_t) v1027 + (uint64_t) v83) : v1027;
        // pto: %316
        ;
        bool v1029 = v1028 == v85;
        // pto: %309, %311, %317, %318
        ;
        // pto: %y_bits_inline2967__phi_v6
        ;
        int64_t v1030;
        if (v1010 < v1011 | v1011 == v1010 & v1029) {
          // pto: %319
          ;
          uint64_t v1031 = (uint64_t) v996;
          // pto: %319
          ;
          v1030 = (int64_t) (v1031 + (uint64_t) v85);
        } else {
          // pto: %321, %323, %329, %330
          ;
          bool v1032 = v1026 < v1025 | v1026 == v1025 & v1029;
          // pto: %y_bits_inline2967__phi_v5
          ;
          int64_t v1033 = v1032 ? v1013 : v996;
          v1030 = v1033;
        };
        v996 = v1030;
      };
      v984 = v996;
    } else {
      v984 = v983;
    };
    // pto: %rounded_bits_inline2983__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1034 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %rounded_bits_inline2983__tile
    ;
    uint64_t v1035 = (uint64_t) v34;
    TASSIGN(v1034, v1035);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID6);
    pipe_barrier(PIPE_V);
    TEXPANDS(v1034, v68);
    set_flag(PIPE_V, PIPE_S, EVENT_ID6);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID6);
    for (int64_t v1036 = v61; v1036 < v58; v1036 += v50) {
      // pto: %332
      ;
      int32_t v1037 = (int32_t) v984;
      v1034.SetValue(v1036, v1037);
    };
    // pto: %rounded_root_inline2985__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1038 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %rounded_root_inline2985__tile
    ;
    uint64_t v1039 = (uint64_t) v34;
    TASSIGN(v1038, v1039);
    // pto: %scalar_root_value_inline2986__tile
    ;
    float v1040 = v1038.GetValue(v61);
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
    // pto: %335
    ;
    float v1041 = v73 / v1040;
    // pto: %33
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1042 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %33
    ;
    uint64_t v1043 = (uint64_t) v34;
    TASSIGN(v1042, v1043);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    TEXPANDS(v1042, v73);
    // pto: %inverse_inline2988__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1044 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v58);
    // pto: %inverse_inline2988__tile
    ;
    uint64_t v1045 = (uint64_t) v32;
    TASSIGN(v1044, v1045);
    pipe_barrier(PIPE_V);
    TMULS(v1044, v1042, v1041);
    set_flag(PIPE_V, PIPE_S, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    __gm__ float* v1046 = PTOAS__GLOBAL_TENSOR_DATA(v130);
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    const int64_t v1047 = 48;
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    const int64_t v1048 = 64;
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v1049 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    pto::Stride<64, 64, 64, 64, 1> v1050 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v1051 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v1046 + (v1047 + v884 * v1048), v1049, v1050);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1051, v1044);
    // pto: %apply_value_inline2989__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1052 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v57);
    // pto: %apply_value_inline2989__ssa_v0
    ;
    uint64_t v1053 = (uint64_t) v33;
    TASSIGN(v1052, v1053);
    // pto: %t__tmp_v56
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1054 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v57);
    // pto: %t__tmp_v56
    ;
    uint64_t v1055 = (uint64_t) v31;
    TASSIGN(v1054, v1055);
    // pto: %attn_norm_w__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v1056 = PTOAS__GLOBAL_TENSOR_DATA(v185);
    // pto: %attn_norm_w__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 4096> v1057 = pto::Shape<1, 1, 1, 1, 4096>();
    // pto: %attn_norm_w__ssa_v0_pview
    ;
    pto::Stride<4096, 4096, 4096, 4096, 1> v1058 = pto::Stride<4096, 4096, 4096, 4096, 1>();
    // pto: %attn_norm_w__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v1059 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v1056, v1057, v1058);
    wait_flag(PIPE_S, PIPE_MTE2, EVENT_ID1);
    TLOAD(v1054, v1059);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %w_raw_inline2990__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1060 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v57);
    // pto: %w_raw_inline2990__ssa_v0
    ;
    uint64_t v1061 = (uint64_t) v31;
    TASSIGN(v1060, v1061);
    // pto: %w_inline2991__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1062 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v57);
    // pto: %w_inline2991__ssa_v0
    ;
    uint64_t v1063 = (uint64_t) v34;
    TASSIGN(v1062, v1063);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    pipe_barrier(PIPE_V);
    RoundMode v1064 = RoundMode::CAST_ROUND;
    SaturationMode v1065 = SaturationMode::ON;
    TCVT(v1062, v1060, v1064, v1065);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
    // pto: %inv_inline2992__tile
    ;
    float v1066 = v1044.GetValue(v61);
    set_flag(PIPE_S, PIPE_V, EVENT_ID5);
    // pto: %scaled_inline2993__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1067 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v57);
    // pto: %scaled_inline2993__ssa_v0
    ;
    uint64_t v1068 = (uint64_t) v33;
    TASSIGN(v1067, v1068);
    TMULS(v1067, v1052, v1066);
    // pto: %result_inline2994__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1069 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v57);
    // pto: %result_inline2994__ssa_v0
    ;
    uint64_t v1070 = (uint64_t) v33;
    TASSIGN(v1069, v1070);
    pipe_barrier(PIPE_V);
    TCOLEXPANDMUL(v1069, v1067, v1062);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %t__tmp_v57
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1071 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v57);
    // pto: %t__tmp_v57
    ;
    uint64_t v1072 = (uint64_t) v33;
    TASSIGN(v1071, v1072);
    pipe_barrier(PIPE_V);
    RoundMode v1073 = RoundMode::CAST_RINT;
    SaturationMode v1074 = SaturationMode::ON;
    TCVT(v1071, v1069, v1073, v1074);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %normed__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v1075 = PTOAS__GLOBAL_TENSOR_DATA(v194);
    // pto: %normed__ssa_v0_pview
    ;
    const int64_t v1076 = 0;
    // pto: %normed__ssa_v0_pview
    ;
    const int64_t v1077 = 4096;
    // pto: %normed__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 4096> v1078 = pto::Shape<1, 1, 1, 1, 4096>();
    // pto: %normed__ssa_v0_pview
    ;
    pto::Stride<4096, 4096, 4096, 4096, 1> v1079 = pto::Stride<4096, 4096, 4096, 4096, 1>();
    // pto: %normed__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v1080 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v1075 + (v1076 + v884 * v1077), v1078, v1079);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1080, v1071);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID5);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}