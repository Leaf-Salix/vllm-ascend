#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void indexer_score_topk_native_pair_2_aic(__gm__ int32_t* v1, __gm__ int32_t* v2, __gm__ int64_t* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, __gm__ int64_t* v7, __gm__ int8_t* v8, __gm__ half* v9, __gm__ int32_t* v10, __gm__ int8_t* v11, __gm__ int8_t* v12, __gm__ float* v13, __gm__ int8_t* v14, __gm__ float* v15, __gm__ float* v16, int64_t v17, int64_t v18, int64_t v19, int64_t v20, int64_t v21, int64_t v22, int64_t v23, int64_t v24, int32_t v25, int32_t v26) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int64_t v27 = 352;
  const int64_t v28 = 320;
  const int64_t v29 = 288;
  const int64_t v30 = 35840;
  const int64_t v31 = 224;
  const int64_t v32 = 34816;
  const int64_t v33 = 192;
  const int64_t v34 = 33792;
  const int64_t v35 = 160;
  const int64_t v36 = 3072;
  const int64_t v37 = 2048;
  const int64_t v38 = 1024;
  // pto: %c0_i64
  const int64_t v39 = 0;
  // pto: %c32768_i64
  const int64_t v40 = 32768;
  // pto: %c16384_i64
  const int64_t v41 = 16384;
  // pto: %c65536_i64
  const int64_t v42 = 65536;
  // pto: %c1_index
  const int64_t v43 = 1;
  // pto: %c27648_index
  const int64_t v44 = 27648;
  const int64_t v45 = 128;
  // pto: %c3456_index
  const int64_t v46 = 3456;
  // pto: %c96_index
  const int64_t v47 = 96;
  // pto: %c768_index
  const int64_t v48 = 768;
  // pto: %c8192_index
  const int64_t v49 = 8192;
  const int64_t v50 = 0;
  // pto: %c4_index
  const int64_t v51 = 4;
  // pto: %c262144_index
  const int64_t v52 = 262144;
  // pto: %c8191_index
  const int64_t v53 = 8191;
  // pto: %c24_index
  const int64_t v54 = 24;
  // pto: %c1_i64
  const int64_t v55 = 1;
  // pto: %c4_i64
  const int64_t v56 = 4;
  // pto: %c767_index
  const int64_t v57 = 767;
  const int64_t v58 = 384;
  // pto: %c4096_index
  const int64_t v59 = 4096;
  // pto: %c383_index
  const int64_t v60 = 383;
  // pto: %c64_index
  const int64_t v61 = 64;
  // pto: %c16_index
  const int64_t v62 = 16;
  // pto: %c2_index
  const int64_t v63 = 2;
  // pto: %c32_index
  const int64_t v64 = 32;
  // pto: %c981467136_i64
  const int64_t v65 = 981467136;
  const int64_t v66 = 256;
  // pto: %qr_hadamard_i8_inline5635__rv_v2_view
  const int64_t v67 = 1;
  // pto: %qr_hadamard_i8_inline5635__rv_v2_view
  const int64_t v68 = 1;
  // pto: %qr_hadamard_i8_inline5635__rv_v2_view
  const int64_t v69 = 1;
  // pto: %qr_hadamard_i8_inline5635__rv_v2_view
  int64_t v70 = v44 * v45;
  // pto: %qr_hadamard_i8_inline5635__rv_v2_view
  int64_t v71 = v69 * v70;
  // pto: %qr_hadamard_i8_inline5635__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v72 = pto::Shape<1, 1, 1, -1, -1>(v67, v68, v69, v44, v45);
  // pto: %qr_hadamard_i8_inline5635__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v73 = pto::Stride<-1, -1, -1, -1, -1>(v68 * v71, v71, v70, v45, v43);
  // pto: %qr_hadamard_i8_inline5635__rv_v2_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v74 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v72, v73);
  // pto: %coefficients_inline6744__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %coefficients_inline6744__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %coefficients_inline6744__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %coefficients_inline6744__ssa_v0_view
  int64_t v78 = v46 * v45;
  // pto: %coefficients_inline6744__ssa_v0_view
  int64_t v79 = v77 * v78;
  // pto: %coefficients_inline6744__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v80 = pto::Shape<1, 1, 1, -1, -1>(v75, v76, v77, v46, v45);
  // pto: %coefficients_inline6744__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v81 = pto::Stride<-1, -1, -1, -1, -1>(v76 * v79, v79, v78, v45, v43);
  // pto: %coefficients_inline6744__ssa_v0_view
  GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v82 = GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v80, v81);
  // pto: %idx_kv_cache_inline6741__ssa_v0_view
  const int64_t v83 = 1;
  // pto: %idx_kv_cache_inline6741__ssa_v0_view
  const int64_t v84 = 1;
  // pto: %idx_kv_cache_inline6741__ssa_v0_view
  const int64_t v85 = 1;
  // pto: %idx_kv_cache_inline6741__ssa_v0_view
  int64_t v86 = (int64_t) v21;
  // pto: %idx_kv_cache_inline6741__ssa_v0_view
  int64_t v87 = v86 * v45;
  // pto: %idx_kv_cache_inline6741__ssa_v0_view
  int64_t v88 = v85 * v87;
  // pto: %idx_kv_cache_inline6741__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v89 = pto::Shape<1, 1, 1, -1, -1>(v83, v84, v85, v86, v45);
  // pto: %idx_kv_cache_inline6741__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v90 = pto::Stride<-1, -1, -1, -1, -1>(v84 * v88, v88, v87, v45, v43);
  // pto: %idx_kv_cache_inline6741__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v91 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v11, v89, v90);
  // pto: %idx_kv_cache_shift64_inline6742__ssa_v0_view
  const int64_t v92 = 1;
  // pto: %idx_kv_cache_shift64_inline6742__ssa_v0_view
  const int64_t v93 = 1;
  // pto: %idx_kv_cache_shift64_inline6742__ssa_v0_view
  const int64_t v94 = 1;
  // pto: %idx_kv_cache_shift64_inline6742__ssa_v0_view
  int64_t v95 = (int64_t) v22;
  // pto: %idx_kv_cache_shift64_inline6742__ssa_v0_view
  int64_t v96 = v95 * v45;
  // pto: %idx_kv_cache_shift64_inline6742__ssa_v0_view
  int64_t v97 = v94 * v96;
  // pto: %idx_kv_cache_shift64_inline6742__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v98 = pto::Shape<1, 1, 1, -1, -1>(v92, v93, v94, v95, v45);
  // pto: %idx_kv_cache_shift64_inline6742__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v99 = pto::Stride<-1, -1, -1, -1, -1>(v93 * v97, v97, v96, v45, v43);
  // pto: %idx_kv_cache_shift64_inline6742__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v100 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v12, v98, v99);
  // pto: %buf_score_transfer_inline6746__ssa_v0_view
  const int64_t v101 = 1;
  // pto: %buf_score_transfer_inline6746__ssa_v0_view
  const int64_t v102 = 1;
  // pto: %buf_score_transfer_inline6746__ssa_v0_view
  const int64_t v103 = 1;
  // pto: %buf_score_transfer_inline6746__ssa_v0_view
  int64_t v104 = v47 * v48;
  // pto: %buf_score_transfer_inline6746__ssa_v0_view
  int64_t v105 = v103 * v104;
  // pto: %buf_score_transfer_inline6746__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v106 = pto::Shape<1, 1, 1, -1, -1>(v101, v102, v103, v47, v48);
  // pto: %buf_score_transfer_inline6746__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v107 = pto::Stride<-1, -1, -1, -1, -1>(v102 * v105, v105, v104, v48, v43);
  // pto: %buf_score_transfer_inline6746__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v108 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v106, v107);
  // pto: %buf_panel_keys_inline6794__phi_v5
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v109 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v5
  uint64_t v110 = (uint64_t) v39;
  TASSIGN(v109, v110);
  // pto: %buf_panel_keys_inline6794__phi_v10
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v10
  uint64_t v112 = (uint64_t) v39;
  TASSIGN(v111, v112);
  // pto: %buf_panel_keys_inline6794__phi_v15
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v15
  uint64_t v114 = (uint64_t) v39;
  TASSIGN(v113, v114);
  // pto: %buf_panel_keys_inline6794__phi_v20
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v115 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v20
  uint64_t v116 = (uint64_t) v39;
  TASSIGN(v115, v116);
  // pto: %buf_panel_keys_inline6794__phi_v26
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v26
  uint64_t v118 = (uint64_t) v40;
  TASSIGN(v117, v118);
  // pto: %buf_panel_keys_inline6794__phi_v31
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v119 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v31
  uint64_t v120 = (uint64_t) v40;
  TASSIGN(v119, v120);
  // pto: %buf_panel_keys_inline6794__phi_v36
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v36
  uint64_t v122 = (uint64_t) v40;
  TASSIGN(v121, v122);
  // pto: %buf_panel_keys_inline6794__phi_v41
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v123 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v41
  uint64_t v124 = (uint64_t) v40;
  TASSIGN(v123, v124);
  // pto: %buf_panel_keys_inline6794__phi_v47
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v125 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v47
  uint64_t v126 = (uint64_t) v39;
  TASSIGN(v125, v126);
  // pto: %buf_panel_keys_inline6794__phi_v52
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v52
  uint64_t v128 = (uint64_t) v39;
  TASSIGN(v127, v128);
  // pto: %buf_panel_keys_inline6794__phi_v57
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v57
  uint64_t v130 = (uint64_t) v39;
  TASSIGN(v129, v130);
  // pto: %buf_panel_keys_inline6794__phi_v62
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v62
  uint64_t v132 = (uint64_t) v39;
  TASSIGN(v131, v132);
  // pto: %buf_panel_keys_inline6794__phi_v68
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v68
  uint64_t v134 = (uint64_t) v40;
  TASSIGN(v133, v134);
  // pto: %buf_panel_keys_inline6794__phi_v73
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v135 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v73
  uint64_t v136 = (uint64_t) v40;
  TASSIGN(v135, v136);
  // pto: %buf_panel_keys_inline6794__phi_v78
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v78
  uint64_t v138 = (uint64_t) v40;
  TASSIGN(v137, v138);
  // pto: %buf_panel_keys_inline6794__phi_v83
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v139 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v83
  uint64_t v140 = (uint64_t) v40;
  TASSIGN(v139, v140);
  // pto: %buf_panel_keys_inline6794__phi_v89
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v141 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v89
  uint64_t v142 = (uint64_t) v39;
  TASSIGN(v141, v142);
  // pto: %buf_panel_keys_inline6794__phi_v94
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v143 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v94
  uint64_t v144 = (uint64_t) v39;
  TASSIGN(v143, v144);
  // pto: %buf_panel_keys_inline6794__phi_v99
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v145 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v99
  uint64_t v146 = (uint64_t) v39;
  TASSIGN(v145, v146);
  // pto: %buf_panel_keys_inline6794__phi_v104
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v147 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v104
  uint64_t v148 = (uint64_t) v39;
  TASSIGN(v147, v148);
  // pto: %buf_panel_keys_inline6794__phi_v110
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v149 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v110
  uint64_t v150 = (uint64_t) v40;
  TASSIGN(v149, v150);
  // pto: %buf_panel_keys_inline6794__phi_v115
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v151 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v115
  uint64_t v152 = (uint64_t) v40;
  TASSIGN(v151, v152);
  // pto: %buf_panel_keys_inline6794__phi_v120
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v153 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v120
  uint64_t v154 = (uint64_t) v40;
  TASSIGN(v153, v154);
  // pto: %buf_panel_keys_inline6794__phi_v125
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v155 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
  // pto: %buf_panel_keys_inline6794__phi_v125
  uint64_t v156 = (uint64_t) v40;
  TASSIGN(v155, v156);
  // pto: %buf_worker_inline6749__ssa_v0
  int64_t v157 = (int64_t) v25;
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  // pto: %buf_max_cache_len_inline6750__rv_v2
  int64_t v158;
  v158 = v50;
  for (int64_t v159 = v50; v159 < v18; v159 += v43) {
    // pto: %t__tile
    ;
    int32_t v160 = (v1)[v159];
    // pto: %0
    ;
    int64_t v161 = (int64_t) v160;
    // pto: %1
    ;
    const int64_t v162 = 1;
    // pto: %1
    ;
    const int64_t v163 = 0;
    // pto: %1
    ;
    int64_t v164 = v161 / v51;
    // pto: %1
    ;
    bool v165 = v161 < v163;
    // pto: %1
    ;
    bool v166 = v51 < v163;
    // pto: %1
    ;
    bool v167 = v165 == v166;
    // pto: %1
    ;
    bool v168 = v161 % v51 != v163 && v165 != v166;
    // pto: %1
    ;
    int64_t v169 = v168 ? v164 - v162 : v164;
    // pto: %2
    ;
    bool v170 = v158 < v169;
    // pto: %2
    ;
    int64_t v171 = v170 ? v169 : v158;
    v158 = v171;
  }
  // pto: %3
  bool v172 = v158 < v52;
  // pto: %3
  int64_t v173 = v172 ? v158 : v52;
  // pto: %4
  int64_t v174 = (int64_t) ((uint64_t) v173 + (uint64_t) v53);
  // pto: %5
  const int64_t v175 = 1;
  // pto: %5
  const int64_t v176 = 0;
  // pto: %5
  int64_t v177 = v174 / v49;
  // pto: %5
  bool v178 = v174 < v176;
  // pto: %5
  bool v179 = v49 < v176;
  // pto: %5
  bool v180 = v178 == v179;
  // pto: %5
  bool v181 = v174 % v49 != v176 && v178 != v179;
  // pto: %5
  int64_t v182 = v181 ? v177 - v175 : v177;
  // pto: %6
  int64_t v183 = v182 < v43 ? v43 : v182;
  // pto: %7
  int32_t v184 = (v2)[v50];
  // pto: %8
  int64_t v185 = (int64_t) v184;
  uint64_t v186 = reinterpret_cast<uint64_t>(v3);
  set_ffts_base_addr(v186);
  // pto: %9
  for (int64_t v187 = v157; v187 < ((int64_t) ((uint64_t) v185 * (uint64_t) v183)); v187 += v54) {
    // pto: %10
    ;
    // pto: %buf_group_inline6759__phi_v2
    ;
    int64_t v188;
    // pto: %buf_leaf_inline6760__phi_v2
    ;
    int64_t v189;
    if (v185 < v54) {
      // pto: %11
      ;
      int64_t v190 = v187 % v185;
      // pto: %12, %13, %14
      ;
      bool v191 = v190 < v50 ^ v185 < v50;
      // pto: %15, %16, %17, %18
      ;
      // pto: %19
      ;
      const int64_t v192 = 1;
      // pto: %19
      ;
      const int64_t v193 = 0;
      // pto: %19
      ;
      int64_t v194 = v187 / v185;
      // pto: %19
      ;
      bool v195 = v187 < v193;
      // pto: %19
      ;
      bool v196 = v185 < v193;
      // pto: %19
      ;
      bool v197 = v195 == v196;
      // pto: %19
      ;
      bool v198 = v187 % v185 != v193 && v195 != v196;
      // pto: %19
      ;
      v188 = v190 != v50 & v191 ? (int64_t) ((uint64_t) v190 + (uint64_t) v185) : v190;
      v189 = v198 ? v194 - v192 : v194;
    } else {
      // pto: %20
      ;
      const int64_t v199 = 1;
      // pto: %20
      ;
      const int64_t v200 = 0;
      // pto: %20
      ;
      int64_t v201 = v187 / v183;
      // pto: %20
      ;
      bool v202 = v187 < v200;
      // pto: %20
      ;
      bool v203 = v183 < v200;
      // pto: %20
      ;
      bool v204 = v202 == v203;
      // pto: %20
      ;
      bool v205 = v187 % v183 != v200 && v202 != v203;
      // pto: %20
      ;
      // pto: %21
      ;
      int64_t v206 = v187 % v183;
      // pto: %22, %23, %24
      ;
      bool v207 = v206 < v50 ^ v183 < v50;
      // pto: %25, %26, %27, %28
      ;
      v188 = v205 ? v201 - v199 : v201;
      v189 = v206 != v50 & v207 ? (int64_t) ((uint64_t) v206 + (uint64_t) v183) : v206;
    };
    // pto: %29
    ;
    int32_t v208 = (v4)[v188];
    // pto: %30
    ;
    int64_t v209 = (int64_t) v208;
    // pto: %31
    ;
    int32_t v210 = (v5)[v188];
    // pto: %33
    ;
    int32_t v211 = (v6)[v209];
    // pto: %34
    ;
    int64_t v212 = (int64_t) v211;
    // pto: %35, %32, %36, %buf_last_position_inline6764__tile
    ;
    int64_t v213 = (v7)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v209 + (uint64_t) ((int64_t) v210)) - (uint64_t) v43)];
    // pto: %37
    ;
    int32_t v214 = (v1)[v212];
    // pto: %38
    ;
    int64_t v215 = (int64_t) v214;
    // pto: %39
    ;
    const int64_t v216 = 1;
    // pto: %39
    ;
    const int64_t v217 = 0;
    // pto: %39
    ;
    int64_t v218 = v215 / v51;
    // pto: %39
    ;
    bool v219 = v215 < v217;
    // pto: %39
    ;
    bool v220 = v51 < v217;
    // pto: %39
    ;
    bool v221 = v219 == v220;
    // pto: %39
    ;
    bool v222 = v215 % v51 != v217 && v219 != v220;
    // pto: %39
    ;
    int64_t v223 = v222 ? v218 - v216 : v218;
    // pto: %40
    ;
    int64_t v224 = (int64_t) ((uint64_t) v213 + (uint64_t) v55);
    // pto: %41
    ;
    const int64_t v225 = 1;
    // pto: %41
    ;
    const int64_t v226 = 0;
    // pto: %41
    ;
    int64_t v227 = v224 / v56;
    // pto: %41
    ;
    bool v228 = v224 < v226;
    // pto: %41
    ;
    bool v229 = v56 < v226;
    // pto: %41
    ;
    bool v230 = v228 == v229;
    // pto: %41
    ;
    bool v231 = v224 % v56 != v226 && v228 != v229;
    // pto: %41
    ;
    int64_t v232 = v231 ? v227 - v225 : v227;
    // pto: %43
    ;
    int64_t v233 = v223 < v232 ? v223 : v232;
    // pto: %44
    ;
    int64_t v234 = v233 < v52 ? v233 : v52;
    // pto: %45
    ;
    int64_t v235 = v234 < v50 ? v50 : v234;
    // pto: %46
    ;
    uint64_t v236 = (uint64_t) v189;
    // pto: %46
    ;
    int64_t v237 = (int64_t) (v236 * (uint64_t) v49);
    // pto: %47
    ;
    if (v237 < v235) {
      // pto: %48
      ;
      int64_t v238 = (int64_t) ((uint64_t) v235 - (uint64_t) v237);
      // pto: %49
      ;
      int64_t v239 = v238 < v49 ? v238 : v49;
      // pto: %50
      ;
      int64_t v240 = (int64_t) ((uint64_t) v239 + (uint64_t) v57);
      // pto: %51
      ;
      const int64_t v241 = 1;
      // pto: %51
      ;
      const int64_t v242 = 0;
      // pto: %51
      ;
      int64_t v243 = v240 / v48;
      // pto: %51
      ;
      bool v244 = v240 < v242;
      // pto: %51
      ;
      bool v245 = v48 < v242;
      // pto: %51
      ;
      bool v246 = v244 == v245;
      // pto: %51
      ;
      bool v247 = v240 % v48 != v242 && v244 != v245;
      // pto: %51
      ;
      int64_t v248 = v247 ? v243 - v241 : v243;
      // pto: %52
      ;
      int64_t v249 = (int64_t) ((uint64_t) v248 * (uint64_t) v58);
      // pto: %53
      ;
      int64_t v250 = v249 < v59 ? v249 : v59;
      // pto: %54
      ;
      int64_t v251 = (int64_t) ((uint64_t) v250 + (uint64_t) v60);
      // pto: %55
      ;
      const int64_t v252 = 1;
      // pto: %55
      ;
      const int64_t v253 = 0;
      // pto: %55
      ;
      int64_t v254 = v251 / v58;
      // pto: %55
      ;
      bool v255 = v251 < v253;
      // pto: %55
      ;
      bool v256 = v58 < v253;
      // pto: %55
      ;
      bool v257 = v255 == v256;
      // pto: %55
      ;
      bool v258 = v251 % v58 != v253 && v255 != v256;
      // pto: %55
      ;
      int64_t v259 = v258 ? v254 - v252 : v254;
      // pto: %buf_query_vector_inline6773__ssa_v0
      ;
      Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v260 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
      // pto: %buf_query_vector_inline6773__ssa_v0
      ;
      uint64_t v261 = (uint64_t) v39;
      TASSIGN(v260, v261);
      // pto: %56
      ;
      int64_t v262 = (int64_t) ((uint64_t) v209 * (uint64_t) v61);
      // pto: %57
      ;
      int64_t v263 = v262 < v50 ? v50 : v262;
      // pto: %qr_hadamard_i8_inline5635__rv_v2_pview
      ;
      __gm__ int8_t* v264 = PTOAS__GLOBAL_TENSOR_DATA(v74);
      // pto: %qr_hadamard_i8_inline5635__rv_v2_pview
      ;
      const int64_t v265 = 0;
      // pto: %qr_hadamard_i8_inline5635__rv_v2_pview
      ;
      const int64_t v266 = 128;
      // pto: %qr_hadamard_i8_inline5635__rv_v2_pview
      ;
      pto::Shape<1, 1, 1, 128, 128> v267 = pto::Shape<1, 1, 1, 128, 128>();
      // pto: %qr_hadamard_i8_inline5635__rv_v2_pview
      ;
      pto::Stride<16384, 16384, 16384, 128, 1> v268 = pto::Stride<16384, 16384, 16384, 128, 1>();
      // pto: %qr_hadamard_i8_inline5635__rv_v2_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, 128, 128>, pto::Stride<16384, 16384, 16384, 128, 1>, pto::Layout::ND> v269 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 128, 128>, pto::Stride<16384, 16384, 16384, 128, 1>, pto::Layout::ND>(v264 + (v265 + v263 * v266), v267, v268);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v260, v269);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %buf_coefficients_l1_inline6774__ssa_v0
      ;
      Tile<TileType::Mat, half, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v270 = Tile<TileType::Mat, half, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v62, v45);
      // pto: %buf_coefficients_l1_inline6774__ssa_v0
      ;
      uint64_t v271 = (uint64_t) v40;
      TASSIGN(v270, v271);
      // pto: %58
      ;
      uint64_t v272 = (uint64_t) v188;
      // pto: %58
      ;
      int64_t v273 = (int64_t) (v272 * (uint64_t) v62);
      // pto: %59
      ;
      int64_t v274 = v273 < v50 ? v50 : v273;
      // pto: %coefficients_inline6744__ssa_v0_pview
      ;
      __gm__ half* v275 = PTOAS__GLOBAL_TENSOR_DATA(v82);
      // pto: %coefficients_inline6744__ssa_v0_pview
      ;
      const int64_t v276 = 0;
      // pto: %coefficients_inline6744__ssa_v0_pview
      ;
      const int64_t v277 = 128;
      // pto: %coefficients_inline6744__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 128> v278 = pto::Shape<1, 1, 1, 16, 128>();
      // pto: %coefficients_inline6744__ssa_v0_pview
      ;
      pto::Stride<2048, 2048, 2048, 128, 1> v279 = pto::Stride<2048, 2048, 2048, 128, 1>();
      // pto: %coefficients_inline6744__ssa_v0_pview
      ;
      GlobalTensor<half, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<2048, 2048, 2048, 128, 1>, pto::Layout::ND> v280 = GlobalTensor<half, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<2048, 2048, 2048, 128, 1>, pto::Layout::ND>(v275 + (v276 + v274 * v277), v278, v279);
      TLOAD(v270, v280);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %buf_query_left_inline6775__ssa_v0
      ;
      Tile<TileType::Left, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v281 = Tile<TileType::Left, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
      // pto: %buf_query_left_inline6775__ssa_v0
      ;
      uint64_t v282 = (uint64_t) v39;
      TASSIGN(v281, v282);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      TMOV(v281, v260);
      // pto: %buf_coefficient_pair_inline6776__ssa_v0
      ;
      Tile<TileType::Left, half, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v283 = Tile<TileType::Left, half, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v62, v45);
      // pto: %buf_coefficient_pair_inline6776__ssa_v0
      ;
      uint64_t v284 = (uint64_t) v41;
      TASSIGN(v283, v284);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      TMOV(v283, v270);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      for (int64_t v285 = v50; v285 < v259; v285 += v43) {
        // pto: %60
        ;
        if (v285 >= v63) {
          int32_t v286 = (int32_t) v43;
          wait_flag_dev(v286);
        };
        // pto: %63
        ;
        int64_t v287 = v285 % v63;
        // pto: %64, %65, %66
        ;
        int64_t v288 = v287 < v50 ? (int64_t) ((uint64_t) v287 + (uint64_t) v63) : v287;
        // pto: %62, %68, %67
        ;
        int64_t v289 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v157 * (uint64_t) v51) + (uint64_t) ((int64_t) (uint64_t) v288 * (uint64_t) v63));
        // pto: %buf_panel_keys_inline6794__ssa_v0
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v290 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_panel_keys_inline6794__ssa_v0
        ;
        uint64_t v291 = (uint64_t) v39;
        TASSIGN(v290, v291);
        // pto: %69, %61
        ;
        int64_t v292 = (int64_t) ((uint64_t) v237 + (uint64_t) ((int64_t) (uint64_t) v285 * (uint64_t) v58));
        // pto: %71
        ;
        const int64_t v293 = 1;
        // pto: %71
        ;
        const int64_t v294 = 0;
        // pto: %71
        ;
        int64_t v295 = v292 / v64;
        // pto: %71
        ;
        bool v296 = v292 < v294;
        // pto: %71
        ;
        bool v297 = v64 < v294;
        // pto: %71
        ;
        bool v298 = v296 == v297;
        // pto: %71
        ;
        bool v299 = v292 % v64 != v294 && v296 != v297;
        // pto: %71
        ;
        int64_t v300 = v299 ? v295 - v293 : v295;
        // pto: %72
        ;
        int64_t v301 = (int64_t) ((uint64_t) v223 - (uint64_t) v43);
        // pto: %73
        ;
        const int64_t v302 = 1;
        // pto: %73
        ;
        const int64_t v303 = 0;
        // pto: %73
        ;
        int64_t v304 = v301 / v64;
        // pto: %73
        ;
        bool v305 = v301 < v303;
        // pto: %73
        ;
        bool v306 = v64 < v303;
        // pto: %73
        ;
        bool v307 = v305 == v306;
        // pto: %73
        ;
        bool v308 = v301 % v64 != v303 && v305 != v306;
        // pto: %73
        ;
        int64_t v309 = v308 ? v304 - v302 : v304;
        // pto: %74
        ;
        int64_t v310 = v309 < v50 ? v50 : v309;
        // pto: %75
        ;
        int64_t v311 = v300 < v310 ? v300 : v310;
        // pto: %flat_offset_mul
        ;
        int64_t v312 = (int64_t) ((uint64_t) v212 * (uint64_t) v20);
        // pto: %flat_offset, %76
        ;
        int32_t v313 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v311)];
        // pto: %77
        ;
        int64_t v314 = (int64_t) v313;
        // pto: %78
        ;
        int64_t v315 = v314 < v50 ? v50 : v314;
        // pto: %79
        ;
        int64_t v316 = (int64_t) ((uint64_t) v315 * (uint64_t) v17);
        // pto: %80
        ;
        int64_t v317 = v316 % v45;
        // pto: %81, %82, %83
        ;
        int64_t v318 = v317 < v50 ? (int64_t) ((uint64_t) v317 + (uint64_t) v45) : v317;
        // pto: %84
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        if (v318 == v50) {
          // pto: %gather_row_view
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v319;
          // pto: %gather_row_view
          ;
          uint64_t v320 = (uint64_t) v39;
          TASSIGN(v319, v320);
          // pto: %85
          ;
          const int64_t v321 = 1;
          // pto: %85
          ;
          const int64_t v322 = 0;
          // pto: %85
          ;
          int64_t v323 = v316 / v45;
          // pto: %85
          ;
          bool v324 = v316 < v322;
          // pto: %85
          ;
          bool v325 = v45 < v322;
          // pto: %85
          ;
          bool v326 = v324 == v325;
          // pto: %85
          ;
          bool v327 = v316 % v45 != v322 && v324 != v325;
          // pto: %85
          ;
          int64_t v328 = v327 ? v323 - v321 : v323;
          // pto: %86
          ;
          int64_t v329 = v328 < v50 ? v50 : v328;
          // pto: %idx_kv_cache_inline6741__ssa_v0_pview
          ;
          __gm__ int8_t* v330 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %idx_kv_cache_inline6741__ssa_v0_pview
          ;
          const int64_t v331 = 0;
          // pto: %idx_kv_cache_inline6741__ssa_v0_pview
          ;
          const int64_t v332 = 128;
          // pto: %idx_kv_cache_inline6741__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 32, 128> v333 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %idx_kv_cache_inline6741__ssa_v0_pview
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v334 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %idx_kv_cache_inline6741__ssa_v0_pview
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v335 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v330 + (v331 + v329 * v332), v333, v334);
          TLOAD(v319, v335);
        } else {
          // pto: %87
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v336;
          // pto: %87
          ;
          uint64_t v337 = (uint64_t) v39;
          TASSIGN(v336, v337);
          // pto: %88
          ;
          const int64_t v338 = 1;
          // pto: %88
          ;
          const int64_t v339 = 0;
          // pto: %88
          ;
          int64_t v340 = v316 / v45;
          // pto: %88
          ;
          bool v341 = v316 < v339;
          // pto: %88
          ;
          bool v342 = v45 < v339;
          // pto: %88
          ;
          bool v343 = v341 == v342;
          // pto: %88
          ;
          bool v344 = v316 % v45 != v339 && v341 != v342;
          // pto: %88
          ;
          int64_t v345 = v344 ? v340 - v338 : v340;
          // pto: %89
          ;
          int64_t v346 = v345 < v50 ? v50 : v345;
          // pto: %idx_kv_cache_shift64_inline6742__ssa_v0_pview
          ;
          __gm__ int8_t* v347 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %idx_kv_cache_shift64_inline6742__ssa_v0_pview
          ;
          const int64_t v348 = 0;
          // pto: %idx_kv_cache_shift64_inline6742__ssa_v0_pview
          ;
          const int64_t v349 = 128;
          // pto: %idx_kv_cache_shift64_inline6742__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 32, 128> v350 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %idx_kv_cache_shift64_inline6742__ssa_v0_pview
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v351 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %idx_kv_cache_shift64_inline6742__ssa_v0_pview
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v352 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v347 + (v348 + v346 * v349), v350, v351);
          TLOAD(v336, v352);
        };
        // pto: %92
        ;
        int64_t v353 = (int64_t) ((uint64_t) v292 + (uint64_t) v64);
        // pto: %93
        ;
        const int64_t v354 = 1;
        // pto: %93
        ;
        const int64_t v355 = 0;
        // pto: %93
        ;
        int64_t v356 = v353 / v64;
        // pto: %93
        ;
        bool v357 = v353 < v355;
        // pto: %93
        ;
        bool v358 = v64 < v355;
        // pto: %93
        ;
        bool v359 = v357 == v358;
        // pto: %93
        ;
        bool v360 = v353 % v64 != v355 && v357 != v358;
        // pto: %93
        ;
        int64_t v361 = v360 ? v356 - v354 : v356;
        // pto: %97
        ;
        int64_t v362 = v361 < v310 ? v361 : v310;
        // pto: %100, %98
        ;
        int32_t v363 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v362)];
        // pto: %101
        ;
        int64_t v364 = (int64_t) v363;
        // pto: %102
        ;
        int64_t v365 = v364 < v50 ? v50 : v364;
        // pto: %103
        ;
        int64_t v366 = (int64_t) ((uint64_t) v365 * (uint64_t) v17);
        // pto: %104
        ;
        int64_t v367 = v366 % v45;
        // pto: %105, %106, %107
        ;
        int64_t v368 = v367 < v50 ? (int64_t) ((uint64_t) v367 + (uint64_t) v45) : v367;
        // pto: %108
        ;
        if (v368 == v50) {
          // pto: %109
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v369;
          // pto: %109
          ;
          uint64_t v370 = (uint64_t) v38;
          TASSIGN(v369, v370);
          // pto: %110
          ;
          const int64_t v371 = 1;
          // pto: %110
          ;
          const int64_t v372 = 0;
          // pto: %110
          ;
          int64_t v373 = v366 / v45;
          // pto: %110
          ;
          bool v374 = v366 < v372;
          // pto: %110
          ;
          bool v375 = v45 < v372;
          // pto: %110
          ;
          bool v376 = v374 == v375;
          // pto: %110
          ;
          bool v377 = v366 % v45 != v372 && v374 != v375;
          // pto: %110
          ;
          int64_t v378 = v377 ? v373 - v371 : v373;
          // pto: %111
          ;
          int64_t v379 = v378 < v50 ? v50 : v378;
          // pto: %112
          ;
          __gm__ int8_t* v380 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %112
          ;
          const int64_t v381 = 0;
          // pto: %112
          ;
          const int64_t v382 = 128;
          // pto: %112
          ;
          pto::Shape<1, 1, 1, 32, 128> v383 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %112
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v384 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %112
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v385 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v380 + (v381 + v379 * v382), v383, v384);
          TLOAD(v369, v385);
        } else {
          // pto: %113
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v386;
          // pto: %113
          ;
          uint64_t v387 = (uint64_t) v38;
          TASSIGN(v386, v387);
          // pto: %114
          ;
          const int64_t v388 = 1;
          // pto: %114
          ;
          const int64_t v389 = 0;
          // pto: %114
          ;
          int64_t v390 = v366 / v45;
          // pto: %114
          ;
          bool v391 = v366 < v389;
          // pto: %114
          ;
          bool v392 = v45 < v389;
          // pto: %114
          ;
          bool v393 = v391 == v392;
          // pto: %114
          ;
          bool v394 = v366 % v45 != v389 && v391 != v392;
          // pto: %114
          ;
          int64_t v395 = v394 ? v390 - v388 : v390;
          // pto: %115
          ;
          int64_t v396 = v395 < v50 ? v50 : v395;
          // pto: %116
          ;
          __gm__ int8_t* v397 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %116
          ;
          const int64_t v398 = 0;
          // pto: %116
          ;
          const int64_t v399 = 128;
          // pto: %116
          ;
          pto::Shape<1, 1, 1, 32, 128> v400 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %116
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v401 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %116
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v402 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v397 + (v398 + v396 * v399), v400, v401);
          TLOAD(v386, v402);
        };
        // pto: %119
        ;
        int64_t v403 = (int64_t) ((uint64_t) v292 + (uint64_t) v61);
        // pto: %120
        ;
        const int64_t v404 = 1;
        // pto: %120
        ;
        const int64_t v405 = 0;
        // pto: %120
        ;
        int64_t v406 = v403 / v64;
        // pto: %120
        ;
        bool v407 = v403 < v405;
        // pto: %120
        ;
        bool v408 = v64 < v405;
        // pto: %120
        ;
        bool v409 = v407 == v408;
        // pto: %120
        ;
        bool v410 = v403 % v64 != v405 && v407 != v408;
        // pto: %120
        ;
        int64_t v411 = v410 ? v406 - v404 : v406;
        // pto: %124
        ;
        int64_t v412 = v411 < v310 ? v411 : v310;
        // pto: %127, %125
        ;
        int32_t v413 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v412)];
        // pto: %128
        ;
        int64_t v414 = (int64_t) v413;
        // pto: %129
        ;
        int64_t v415 = v414 < v50 ? v50 : v414;
        // pto: %130
        ;
        int64_t v416 = (int64_t) ((uint64_t) v415 * (uint64_t) v17);
        // pto: %131
        ;
        int64_t v417 = v416 % v45;
        // pto: %132, %133, %134
        ;
        int64_t v418 = v417 < v50 ? (int64_t) ((uint64_t) v417 + (uint64_t) v45) : v417;
        // pto: %135
        ;
        if (v418 == v50) {
          // pto: %136
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v419;
          // pto: %136
          ;
          uint64_t v420 = (uint64_t) v37;
          TASSIGN(v419, v420);
          // pto: %137
          ;
          const int64_t v421 = 1;
          // pto: %137
          ;
          const int64_t v422 = 0;
          // pto: %137
          ;
          int64_t v423 = v416 / v45;
          // pto: %137
          ;
          bool v424 = v416 < v422;
          // pto: %137
          ;
          bool v425 = v45 < v422;
          // pto: %137
          ;
          bool v426 = v424 == v425;
          // pto: %137
          ;
          bool v427 = v416 % v45 != v422 && v424 != v425;
          // pto: %137
          ;
          int64_t v428 = v427 ? v423 - v421 : v423;
          // pto: %138
          ;
          int64_t v429 = v428 < v50 ? v50 : v428;
          // pto: %139
          ;
          __gm__ int8_t* v430 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %139
          ;
          const int64_t v431 = 0;
          // pto: %139
          ;
          const int64_t v432 = 128;
          // pto: %139
          ;
          pto::Shape<1, 1, 1, 32, 128> v433 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %139
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v434 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %139
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v435 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v430 + (v431 + v429 * v432), v433, v434);
          TLOAD(v419, v435);
        } else {
          // pto: %140
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v436;
          // pto: %140
          ;
          uint64_t v437 = (uint64_t) v37;
          TASSIGN(v436, v437);
          // pto: %141
          ;
          const int64_t v438 = 1;
          // pto: %141
          ;
          const int64_t v439 = 0;
          // pto: %141
          ;
          int64_t v440 = v416 / v45;
          // pto: %141
          ;
          bool v441 = v416 < v439;
          // pto: %141
          ;
          bool v442 = v45 < v439;
          // pto: %141
          ;
          bool v443 = v441 == v442;
          // pto: %141
          ;
          bool v444 = v416 % v45 != v439 && v441 != v442;
          // pto: %141
          ;
          int64_t v445 = v444 ? v440 - v438 : v440;
          // pto: %142
          ;
          int64_t v446 = v445 < v50 ? v50 : v445;
          // pto: %143
          ;
          __gm__ int8_t* v447 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %143
          ;
          const int64_t v448 = 0;
          // pto: %143
          ;
          const int64_t v449 = 128;
          // pto: %143
          ;
          pto::Shape<1, 1, 1, 32, 128> v450 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %143
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v451 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %143
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v452 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v447 + (v448 + v446 * v449), v450, v451);
          TLOAD(v436, v452);
        };
        // pto: %146
        ;
        int64_t v453 = (int64_t) ((uint64_t) v292 + (uint64_t) v47);
        // pto: %147
        ;
        const int64_t v454 = 1;
        // pto: %147
        ;
        const int64_t v455 = 0;
        // pto: %147
        ;
        int64_t v456 = v453 / v64;
        // pto: %147
        ;
        bool v457 = v453 < v455;
        // pto: %147
        ;
        bool v458 = v64 < v455;
        // pto: %147
        ;
        bool v459 = v457 == v458;
        // pto: %147
        ;
        bool v460 = v453 % v64 != v455 && v457 != v458;
        // pto: %147
        ;
        int64_t v461 = v460 ? v456 - v454 : v456;
        // pto: %151
        ;
        int64_t v462 = v461 < v310 ? v461 : v310;
        // pto: %154, %152
        ;
        int32_t v463 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v462)];
        // pto: %155
        ;
        int64_t v464 = (int64_t) v463;
        // pto: %156
        ;
        int64_t v465 = v464 < v50 ? v50 : v464;
        // pto: %157
        ;
        int64_t v466 = (int64_t) ((uint64_t) v465 * (uint64_t) v17);
        // pto: %158
        ;
        int64_t v467 = v466 % v45;
        // pto: %159, %160, %161
        ;
        int64_t v468 = v467 < v50 ? (int64_t) ((uint64_t) v467 + (uint64_t) v45) : v467;
        // pto: %162
        ;
        if (v468 == v50) {
          // pto: %163
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v469;
          // pto: %163
          ;
          uint64_t v470 = (uint64_t) v36;
          TASSIGN(v469, v470);
          // pto: %164
          ;
          const int64_t v471 = 1;
          // pto: %164
          ;
          const int64_t v472 = 0;
          // pto: %164
          ;
          int64_t v473 = v466 / v45;
          // pto: %164
          ;
          bool v474 = v466 < v472;
          // pto: %164
          ;
          bool v475 = v45 < v472;
          // pto: %164
          ;
          bool v476 = v474 == v475;
          // pto: %164
          ;
          bool v477 = v466 % v45 != v472 && v474 != v475;
          // pto: %164
          ;
          int64_t v478 = v477 ? v473 - v471 : v473;
          // pto: %165
          ;
          int64_t v479 = v478 < v50 ? v50 : v478;
          // pto: %166
          ;
          __gm__ int8_t* v480 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %166
          ;
          const int64_t v481 = 0;
          // pto: %166
          ;
          const int64_t v482 = 128;
          // pto: %166
          ;
          pto::Shape<1, 1, 1, 32, 128> v483 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %166
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v484 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %166
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v485 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v480 + (v481 + v479 * v482), v483, v484);
          TLOAD(v469, v485);
        } else {
          // pto: %167
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v486;
          // pto: %167
          ;
          uint64_t v487 = (uint64_t) v36;
          TASSIGN(v486, v487);
          // pto: %168
          ;
          const int64_t v488 = 1;
          // pto: %168
          ;
          const int64_t v489 = 0;
          // pto: %168
          ;
          int64_t v490 = v466 / v45;
          // pto: %168
          ;
          bool v491 = v466 < v489;
          // pto: %168
          ;
          bool v492 = v45 < v489;
          // pto: %168
          ;
          bool v493 = v491 == v492;
          // pto: %168
          ;
          bool v494 = v466 % v45 != v489 && v491 != v492;
          // pto: %168
          ;
          int64_t v495 = v494 ? v490 - v488 : v490;
          // pto: %169
          ;
          int64_t v496 = v495 < v50 ? v50 : v495;
          // pto: %170
          ;
          __gm__ int8_t* v497 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %170
          ;
          const int64_t v498 = 0;
          // pto: %170
          ;
          const int64_t v499 = 128;
          // pto: %170
          ;
          pto::Shape<1, 1, 1, 32, 128> v500 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %170
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v501 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %170
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v502 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v497 + (v498 + v496 * v499), v500, v501);
          TLOAD(v486, v502);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        // pto: %t__tmp_v765
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v503 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %t__tmp_v765
        ;
        uint64_t v504 = (uint64_t) v39;
        TASSIGN(v503, v504);
        // pto: %buf_prefetched_key_inline6782__ssa_v3
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v505 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_prefetched_key_inline6782__ssa_v3
        ;
        uint64_t v506 = (uint64_t) v41;
        TASSIGN(v505, v506);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        TMOV(v505, v503);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_key_panel_inline6800__ssa_v1
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v507 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_key_panel_inline6800__ssa_v1
        ;
        uint64_t v508 = (uint64_t) v41;
        TASSIGN(v507, v508);
        // pto: %buf_scores_l1_inline6801__ssa_v0
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v509 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_l1_inline6801__ssa_v0
        ;
        uint64_t v510 = (uint64_t) v39;
        TASSIGN(v509, v510);
        // pto: %buf_scores_inline6803__ssa_v1
        ;
        Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v511 = Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_inline6803__ssa_v1
        ;
        uint64_t v512 = (uint64_t) v39;
        TASSIGN(v511, v512);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        TMATMUL(v511, v281, v507);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v513 = static_cast<uint64_t>(v65);
        uint16_t v514 = static_cast<uint16_t>(v50);
        uint16_t v515 = static_cast<uint16_t>(v50);
        TINSERT<Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v509, v511, v513, v514, v515);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        // pto: %buf_previous_l1_inline6780__ssa_v1
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v516 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_previous_l1_inline6780__ssa_v1
        ;
        uint64_t v517 = (uint64_t) v39;
        TASSIGN(v516, v517);
        // pto: %buf_panel_keys_inline6794__ssa_v21
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v518 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_panel_keys_inline6794__ssa_v21
        ;
        uint64_t v519 = (uint64_t) v40;
        TASSIGN(v518, v519);
        // pto: %172
        ;
        int64_t v520 = (int64_t) ((uint64_t) v292 + (uint64_t) v45);
        // pto: %173
        ;
        const int64_t v521 = 1;
        // pto: %173
        ;
        const int64_t v522 = 0;
        // pto: %173
        ;
        int64_t v523 = v520 / v64;
        // pto: %173
        ;
        bool v524 = v520 < v522;
        // pto: %173
        ;
        bool v525 = v64 < v522;
        // pto: %173
        ;
        bool v526 = v524 == v525;
        // pto: %173
        ;
        bool v527 = v520 % v64 != v522 && v524 != v525;
        // pto: %173
        ;
        int64_t v528 = v527 ? v523 - v521 : v523;
        // pto: %177
        ;
        int64_t v529 = v528 < v310 ? v528 : v310;
        // pto: %180, %178
        ;
        int32_t v530 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v529)];
        // pto: %181
        ;
        int64_t v531 = (int64_t) v530;
        // pto: %182
        ;
        int64_t v532 = v531 < v50 ? v50 : v531;
        // pto: %183
        ;
        int64_t v533 = (int64_t) ((uint64_t) v532 * (uint64_t) v17);
        // pto: %184
        ;
        int64_t v534 = v533 % v45;
        // pto: %185, %186, %187
        ;
        int64_t v535 = v534 < v50 ? (int64_t) ((uint64_t) v534 + (uint64_t) v45) : v534;
        // pto: %188
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        if (v535 == v50) {
          // pto: %189
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v536;
          // pto: %189
          ;
          uint64_t v537 = (uint64_t) v40;
          TASSIGN(v536, v537);
          // pto: %190
          ;
          const int64_t v538 = 1;
          // pto: %190
          ;
          const int64_t v539 = 0;
          // pto: %190
          ;
          int64_t v540 = v533 / v45;
          // pto: %190
          ;
          bool v541 = v533 < v539;
          // pto: %190
          ;
          bool v542 = v45 < v539;
          // pto: %190
          ;
          bool v543 = v541 == v542;
          // pto: %190
          ;
          bool v544 = v533 % v45 != v539 && v541 != v542;
          // pto: %190
          ;
          int64_t v545 = v544 ? v540 - v538 : v540;
          // pto: %191
          ;
          int64_t v546 = v545 < v50 ? v50 : v545;
          // pto: %192
          ;
          __gm__ int8_t* v547 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %192
          ;
          const int64_t v548 = 0;
          // pto: %192
          ;
          const int64_t v549 = 128;
          // pto: %192
          ;
          pto::Shape<1, 1, 1, 32, 128> v550 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %192
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v551 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %192
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v552 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v547 + (v548 + v546 * v549), v550, v551);
          TLOAD(v536, v552);
        } else {
          // pto: %193
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v553;
          // pto: %193
          ;
          uint64_t v554 = (uint64_t) v40;
          TASSIGN(v553, v554);
          // pto: %194
          ;
          const int64_t v555 = 1;
          // pto: %194
          ;
          const int64_t v556 = 0;
          // pto: %194
          ;
          int64_t v557 = v533 / v45;
          // pto: %194
          ;
          bool v558 = v533 < v556;
          // pto: %194
          ;
          bool v559 = v45 < v556;
          // pto: %194
          ;
          bool v560 = v558 == v559;
          // pto: %194
          ;
          bool v561 = v533 % v45 != v556 && v558 != v559;
          // pto: %194
          ;
          int64_t v562 = v561 ? v557 - v555 : v557;
          // pto: %195
          ;
          int64_t v563 = v562 < v50 ? v50 : v562;
          // pto: %196
          ;
          __gm__ int8_t* v564 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %196
          ;
          const int64_t v565 = 0;
          // pto: %196
          ;
          const int64_t v566 = 128;
          // pto: %196
          ;
          pto::Shape<1, 1, 1, 32, 128> v567 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %196
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v568 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %196
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v569 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v564 + (v565 + v563 * v566), v567, v568);
          TLOAD(v553, v569);
        };
        // pto: %199
        ;
        int64_t v570 = (int64_t) ((uint64_t) v292 + (uint64_t) v35);
        // pto: %200
        ;
        const int64_t v571 = 1;
        // pto: %200
        ;
        const int64_t v572 = 0;
        // pto: %200
        ;
        int64_t v573 = v570 / v64;
        // pto: %200
        ;
        bool v574 = v570 < v572;
        // pto: %200
        ;
        bool v575 = v64 < v572;
        // pto: %200
        ;
        bool v576 = v574 == v575;
        // pto: %200
        ;
        bool v577 = v570 % v64 != v572 && v574 != v575;
        // pto: %200
        ;
        int64_t v578 = v577 ? v573 - v571 : v573;
        // pto: %204
        ;
        int64_t v579 = v578 < v310 ? v578 : v310;
        // pto: %207, %205
        ;
        int32_t v580 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v579)];
        // pto: %208
        ;
        int64_t v581 = (int64_t) v580;
        // pto: %209
        ;
        int64_t v582 = v581 < v50 ? v50 : v581;
        // pto: %210
        ;
        int64_t v583 = (int64_t) ((uint64_t) v582 * (uint64_t) v17);
        // pto: %211
        ;
        int64_t v584 = v583 % v45;
        // pto: %212, %213, %214
        ;
        int64_t v585 = v584 < v50 ? (int64_t) ((uint64_t) v584 + (uint64_t) v45) : v584;
        // pto: %215
        ;
        if (v585 == v50) {
          // pto: %216
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v586;
          // pto: %216
          ;
          uint64_t v587 = (uint64_t) v34;
          TASSIGN(v586, v587);
          // pto: %217
          ;
          const int64_t v588 = 1;
          // pto: %217
          ;
          const int64_t v589 = 0;
          // pto: %217
          ;
          int64_t v590 = v583 / v45;
          // pto: %217
          ;
          bool v591 = v583 < v589;
          // pto: %217
          ;
          bool v592 = v45 < v589;
          // pto: %217
          ;
          bool v593 = v591 == v592;
          // pto: %217
          ;
          bool v594 = v583 % v45 != v589 && v591 != v592;
          // pto: %217
          ;
          int64_t v595 = v594 ? v590 - v588 : v590;
          // pto: %218
          ;
          int64_t v596 = v595 < v50 ? v50 : v595;
          // pto: %219
          ;
          __gm__ int8_t* v597 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %219
          ;
          const int64_t v598 = 0;
          // pto: %219
          ;
          const int64_t v599 = 128;
          // pto: %219
          ;
          pto::Shape<1, 1, 1, 32, 128> v600 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %219
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v601 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %219
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v602 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v597 + (v598 + v596 * v599), v600, v601);
          TLOAD(v586, v602);
        } else {
          // pto: %220
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v603;
          // pto: %220
          ;
          uint64_t v604 = (uint64_t) v34;
          TASSIGN(v603, v604);
          // pto: %221
          ;
          const int64_t v605 = 1;
          // pto: %221
          ;
          const int64_t v606 = 0;
          // pto: %221
          ;
          int64_t v607 = v583 / v45;
          // pto: %221
          ;
          bool v608 = v583 < v606;
          // pto: %221
          ;
          bool v609 = v45 < v606;
          // pto: %221
          ;
          bool v610 = v608 == v609;
          // pto: %221
          ;
          bool v611 = v583 % v45 != v606 && v608 != v609;
          // pto: %221
          ;
          int64_t v612 = v611 ? v607 - v605 : v607;
          // pto: %222
          ;
          int64_t v613 = v612 < v50 ? v50 : v612;
          // pto: %223
          ;
          __gm__ int8_t* v614 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %223
          ;
          const int64_t v615 = 0;
          // pto: %223
          ;
          const int64_t v616 = 128;
          // pto: %223
          ;
          pto::Shape<1, 1, 1, 32, 128> v617 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %223
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v618 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %223
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v619 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v614 + (v615 + v613 * v616), v617, v618);
          TLOAD(v603, v619);
        };
        // pto: %226
        ;
        int64_t v620 = (int64_t) ((uint64_t) v292 + (uint64_t) v33);
        // pto: %227
        ;
        const int64_t v621 = 1;
        // pto: %227
        ;
        const int64_t v622 = 0;
        // pto: %227
        ;
        int64_t v623 = v620 / v64;
        // pto: %227
        ;
        bool v624 = v620 < v622;
        // pto: %227
        ;
        bool v625 = v64 < v622;
        // pto: %227
        ;
        bool v626 = v624 == v625;
        // pto: %227
        ;
        bool v627 = v620 % v64 != v622 && v624 != v625;
        // pto: %227
        ;
        int64_t v628 = v627 ? v623 - v621 : v623;
        // pto: %231
        ;
        int64_t v629 = v628 < v310 ? v628 : v310;
        // pto: %234, %232
        ;
        int32_t v630 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v629)];
        // pto: %235
        ;
        int64_t v631 = (int64_t) v630;
        // pto: %236
        ;
        int64_t v632 = v631 < v50 ? v50 : v631;
        // pto: %237
        ;
        int64_t v633 = (int64_t) ((uint64_t) v632 * (uint64_t) v17);
        // pto: %238
        ;
        int64_t v634 = v633 % v45;
        // pto: %239, %240, %241
        ;
        int64_t v635 = v634 < v50 ? (int64_t) ((uint64_t) v634 + (uint64_t) v45) : v634;
        // pto: %242
        ;
        if (v635 == v50) {
          // pto: %243
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v636;
          // pto: %243
          ;
          uint64_t v637 = (uint64_t) v32;
          TASSIGN(v636, v637);
          // pto: %244
          ;
          const int64_t v638 = 1;
          // pto: %244
          ;
          const int64_t v639 = 0;
          // pto: %244
          ;
          int64_t v640 = v633 / v45;
          // pto: %244
          ;
          bool v641 = v633 < v639;
          // pto: %244
          ;
          bool v642 = v45 < v639;
          // pto: %244
          ;
          bool v643 = v641 == v642;
          // pto: %244
          ;
          bool v644 = v633 % v45 != v639 && v641 != v642;
          // pto: %244
          ;
          int64_t v645 = v644 ? v640 - v638 : v640;
          // pto: %245
          ;
          int64_t v646 = v645 < v50 ? v50 : v645;
          // pto: %246
          ;
          __gm__ int8_t* v647 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %246
          ;
          const int64_t v648 = 0;
          // pto: %246
          ;
          const int64_t v649 = 128;
          // pto: %246
          ;
          pto::Shape<1, 1, 1, 32, 128> v650 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %246
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v651 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %246
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v652 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v647 + (v648 + v646 * v649), v650, v651);
          TLOAD(v636, v652);
        } else {
          // pto: %247
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v653;
          // pto: %247
          ;
          uint64_t v654 = (uint64_t) v32;
          TASSIGN(v653, v654);
          // pto: %248
          ;
          const int64_t v655 = 1;
          // pto: %248
          ;
          const int64_t v656 = 0;
          // pto: %248
          ;
          int64_t v657 = v633 / v45;
          // pto: %248
          ;
          bool v658 = v633 < v656;
          // pto: %248
          ;
          bool v659 = v45 < v656;
          // pto: %248
          ;
          bool v660 = v658 == v659;
          // pto: %248
          ;
          bool v661 = v633 % v45 != v656 && v658 != v659;
          // pto: %248
          ;
          int64_t v662 = v661 ? v657 - v655 : v657;
          // pto: %249
          ;
          int64_t v663 = v662 < v50 ? v50 : v662;
          // pto: %250
          ;
          __gm__ int8_t* v664 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %250
          ;
          const int64_t v665 = 0;
          // pto: %250
          ;
          const int64_t v666 = 128;
          // pto: %250
          ;
          pto::Shape<1, 1, 1, 32, 128> v667 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %250
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v668 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %250
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v669 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v664 + (v665 + v663 * v666), v667, v668);
          TLOAD(v653, v669);
        };
        // pto: %253
        ;
        int64_t v670 = (int64_t) ((uint64_t) v292 + (uint64_t) v31);
        // pto: %254
        ;
        const int64_t v671 = 1;
        // pto: %254
        ;
        const int64_t v672 = 0;
        // pto: %254
        ;
        int64_t v673 = v670 / v64;
        // pto: %254
        ;
        bool v674 = v670 < v672;
        // pto: %254
        ;
        bool v675 = v64 < v672;
        // pto: %254
        ;
        bool v676 = v674 == v675;
        // pto: %254
        ;
        bool v677 = v670 % v64 != v672 && v674 != v675;
        // pto: %254
        ;
        int64_t v678 = v677 ? v673 - v671 : v673;
        // pto: %258
        ;
        int64_t v679 = v678 < v310 ? v678 : v310;
        // pto: %261, %259
        ;
        int32_t v680 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v679)];
        // pto: %262
        ;
        int64_t v681 = (int64_t) v680;
        // pto: %263
        ;
        int64_t v682 = v681 < v50 ? v50 : v681;
        // pto: %264
        ;
        int64_t v683 = (int64_t) ((uint64_t) v682 * (uint64_t) v17);
        // pto: %265
        ;
        int64_t v684 = v683 % v45;
        // pto: %266, %267, %268
        ;
        int64_t v685 = v684 < v50 ? (int64_t) ((uint64_t) v684 + (uint64_t) v45) : v684;
        // pto: %269
        ;
        if (v685 == v50) {
          // pto: %270
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v686;
          // pto: %270
          ;
          uint64_t v687 = (uint64_t) v30;
          TASSIGN(v686, v687);
          // pto: %271
          ;
          const int64_t v688 = 1;
          // pto: %271
          ;
          const int64_t v689 = 0;
          // pto: %271
          ;
          int64_t v690 = v683 / v45;
          // pto: %271
          ;
          bool v691 = v683 < v689;
          // pto: %271
          ;
          bool v692 = v45 < v689;
          // pto: %271
          ;
          bool v693 = v691 == v692;
          // pto: %271
          ;
          bool v694 = v683 % v45 != v689 && v691 != v692;
          // pto: %271
          ;
          int64_t v695 = v694 ? v690 - v688 : v690;
          // pto: %272
          ;
          int64_t v696 = v695 < v50 ? v50 : v695;
          // pto: %273
          ;
          __gm__ int8_t* v697 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %273
          ;
          const int64_t v698 = 0;
          // pto: %273
          ;
          const int64_t v699 = 128;
          // pto: %273
          ;
          pto::Shape<1, 1, 1, 32, 128> v700 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %273
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v701 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %273
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v702 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v697 + (v698 + v696 * v699), v700, v701);
          TLOAD(v686, v702);
        } else {
          // pto: %274
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v703;
          // pto: %274
          ;
          uint64_t v704 = (uint64_t) v30;
          TASSIGN(v703, v704);
          // pto: %275
          ;
          const int64_t v705 = 1;
          // pto: %275
          ;
          const int64_t v706 = 0;
          // pto: %275
          ;
          int64_t v707 = v683 / v45;
          // pto: %275
          ;
          bool v708 = v683 < v706;
          // pto: %275
          ;
          bool v709 = v45 < v706;
          // pto: %275
          ;
          bool v710 = v708 == v709;
          // pto: %275
          ;
          bool v711 = v683 % v45 != v706 && v708 != v709;
          // pto: %275
          ;
          int64_t v712 = v711 ? v707 - v705 : v707;
          // pto: %276
          ;
          int64_t v713 = v712 < v50 ? v50 : v712;
          // pto: %277
          ;
          __gm__ int8_t* v714 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %277
          ;
          const int64_t v715 = 0;
          // pto: %277
          ;
          const int64_t v716 = 128;
          // pto: %277
          ;
          pto::Shape<1, 1, 1, 32, 128> v717 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %277
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v718 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %277
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v719 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v714 + (v715 + v713 * v716), v717, v718);
          TLOAD(v703, v719);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
        // pto: %t__tmp_v770
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v720 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %t__tmp_v770
        ;
        uint64_t v721 = (uint64_t) v40;
        TASSIGN(v720, v721);
        // pto: %buf_prefetched_key_inline6782__ssa_v8
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v722 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_prefetched_key_inline6782__ssa_v8
        ;
        uint64_t v723 = (uint64_t) v39;
        TASSIGN(v722, v723);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
        TMOV(v722, v720);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %buf_key_panel_inline6800__ssa_v4
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v724 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_key_panel_inline6800__ssa_v4
        ;
        uint64_t v725 = (uint64_t) v39;
        TASSIGN(v724, v725);
        // pto: %buf_scores_l1_inline6801__ssa_v4
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v726 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_l1_inline6801__ssa_v4
        ;
        uint64_t v727 = (uint64_t) v40;
        TASSIGN(v726, v727);
        // pto: %buf_previous_pair_inline6802__ssa_v1
        ;
        Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v728 = Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_previous_pair_inline6802__ssa_v1
        ;
        uint64_t v729 = (uint64_t) v41;
        TASSIGN(v728, v729);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        uint16_t v730 = static_cast<uint16_t>(v50);
        uint16_t v731 = static_cast<uint16_t>(v50);
        TEXTRACT(v728, v516, v730, v731);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %buf_scores_inline6803__ssa_v3
        ;
        Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v732 = Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_inline6803__ssa_v3
        ;
        uint64_t v733 = (uint64_t) v39;
        TASSIGN(v732, v733);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v732, v281, v724);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        // pto: %buf_reduced_pair_inline6804__ssa_v1
        ;
        Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v734 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v62, v45);
        // pto: %buf_reduced_pair_inline6804__ssa_v1
        ;
        uint64_t v735 = (uint64_t) v42;
        TASSIGN(v734, v735);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        TMATMUL(v734, v283, v728);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        uint64_t v736 = static_cast<uint64_t>(v65);
        uint16_t v737 = static_cast<uint16_t>(v50);
        uint16_t v738 = static_cast<uint16_t>(v50);
        TINSERT<Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v726, v732, v736, v737, v738);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID1);
        v734.SetValidShape(v63, v45);
        // pto: %278
        ;
        int64_t v739 = v289 < v50 ? v50 : v289;
        // pto: %buf_score_transfer_inline6746__ssa_v0_pview
        ;
        __gm__ float* v740 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %buf_score_transfer_inline6746__ssa_v0_pview
        ;
        const int64_t v741 = 0;
        // pto: %buf_score_transfer_inline6746__ssa_v0_pview
        ;
        const int64_t v742 = 768;
        // pto: %buf_score_transfer_inline6746__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 2, 128> v743 = pto::Shape<1, 1, 1, 2, 128>();
        // pto: %buf_score_transfer_inline6746__ssa_v0_pview
        ;
        pto::Stride<1536, 1536, 1536, 768, 1> v744 = pto::Stride<1536, 1536, 1536, 768, 1>();
        // pto: %buf_score_transfer_inline6746__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND> v745 = GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND>(v740 + (v741 + v739 * v742), v743, v744);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
        TSTORE(v745, v734);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
        // pto: %buf_previous_l1_inline6780__ssa_v2
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v746 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_previous_l1_inline6780__ssa_v2
        ;
        uint64_t v747 = (uint64_t) v40;
        TASSIGN(v746, v747);
        // pto: %buf_panel_keys_inline6794__ssa_v42
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v748 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_panel_keys_inline6794__ssa_v42
        ;
        uint64_t v749 = (uint64_t) v39;
        TASSIGN(v748, v749);
        // pto: %282
        ;
        int64_t v750 = (int64_t) ((uint64_t) v292 + (uint64_t) v66);
        // pto: %283
        ;
        const int64_t v751 = 1;
        // pto: %283
        ;
        const int64_t v752 = 0;
        // pto: %283
        ;
        int64_t v753 = v750 / v64;
        // pto: %283
        ;
        bool v754 = v750 < v752;
        // pto: %283
        ;
        bool v755 = v64 < v752;
        // pto: %283
        ;
        bool v756 = v754 == v755;
        // pto: %283
        ;
        bool v757 = v750 % v64 != v752 && v754 != v755;
        // pto: %283
        ;
        int64_t v758 = v757 ? v753 - v751 : v753;
        // pto: %287
        ;
        int64_t v759 = v758 < v310 ? v758 : v310;
        // pto: %290, %288
        ;
        int32_t v760 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v759)];
        // pto: %291
        ;
        int64_t v761 = (int64_t) v760;
        // pto: %292
        ;
        int64_t v762 = v761 < v50 ? v50 : v761;
        // pto: %293
        ;
        int64_t v763 = (int64_t) ((uint64_t) v762 * (uint64_t) v17);
        // pto: %294
        ;
        int64_t v764 = v763 % v45;
        // pto: %295, %296, %297
        ;
        int64_t v765 = v764 < v50 ? (int64_t) ((uint64_t) v764 + (uint64_t) v45) : v764;
        // pto: %298
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        if (v765 == v50) {
          // pto: %299
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v766;
          // pto: %299
          ;
          uint64_t v767 = (uint64_t) v39;
          TASSIGN(v766, v767);
          // pto: %300
          ;
          const int64_t v768 = 1;
          // pto: %300
          ;
          const int64_t v769 = 0;
          // pto: %300
          ;
          int64_t v770 = v763 / v45;
          // pto: %300
          ;
          bool v771 = v763 < v769;
          // pto: %300
          ;
          bool v772 = v45 < v769;
          // pto: %300
          ;
          bool v773 = v771 == v772;
          // pto: %300
          ;
          bool v774 = v763 % v45 != v769 && v771 != v772;
          // pto: %300
          ;
          int64_t v775 = v774 ? v770 - v768 : v770;
          // pto: %301
          ;
          int64_t v776 = v775 < v50 ? v50 : v775;
          // pto: %302
          ;
          __gm__ int8_t* v777 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %302
          ;
          const int64_t v778 = 0;
          // pto: %302
          ;
          const int64_t v779 = 128;
          // pto: %302
          ;
          pto::Shape<1, 1, 1, 32, 128> v780 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %302
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v781 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %302
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v782 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v777 + (v778 + v776 * v779), v780, v781);
          TLOAD(v766, v782);
        } else {
          // pto: %303
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v783;
          // pto: %303
          ;
          uint64_t v784 = (uint64_t) v39;
          TASSIGN(v783, v784);
          // pto: %304
          ;
          const int64_t v785 = 1;
          // pto: %304
          ;
          const int64_t v786 = 0;
          // pto: %304
          ;
          int64_t v787 = v763 / v45;
          // pto: %304
          ;
          bool v788 = v763 < v786;
          // pto: %304
          ;
          bool v789 = v45 < v786;
          // pto: %304
          ;
          bool v790 = v788 == v789;
          // pto: %304
          ;
          bool v791 = v763 % v45 != v786 && v788 != v789;
          // pto: %304
          ;
          int64_t v792 = v791 ? v787 - v785 : v787;
          // pto: %305
          ;
          int64_t v793 = v792 < v50 ? v50 : v792;
          // pto: %306
          ;
          __gm__ int8_t* v794 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %306
          ;
          const int64_t v795 = 0;
          // pto: %306
          ;
          const int64_t v796 = 128;
          // pto: %306
          ;
          pto::Shape<1, 1, 1, 32, 128> v797 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %306
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v798 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %306
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v799 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v794 + (v795 + v793 * v796), v797, v798);
          TLOAD(v783, v799);
        };
        // pto: %309
        ;
        int64_t v800 = (int64_t) ((uint64_t) v292 + (uint64_t) v29);
        // pto: %310
        ;
        const int64_t v801 = 1;
        // pto: %310
        ;
        const int64_t v802 = 0;
        // pto: %310
        ;
        int64_t v803 = v800 / v64;
        // pto: %310
        ;
        bool v804 = v800 < v802;
        // pto: %310
        ;
        bool v805 = v64 < v802;
        // pto: %310
        ;
        bool v806 = v804 == v805;
        // pto: %310
        ;
        bool v807 = v800 % v64 != v802 && v804 != v805;
        // pto: %310
        ;
        int64_t v808 = v807 ? v803 - v801 : v803;
        // pto: %314
        ;
        int64_t v809 = v808 < v310 ? v808 : v310;
        // pto: %317, %315
        ;
        int32_t v810 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v809)];
        // pto: %318
        ;
        int64_t v811 = (int64_t) v810;
        // pto: %319
        ;
        int64_t v812 = v811 < v50 ? v50 : v811;
        // pto: %320
        ;
        int64_t v813 = (int64_t) ((uint64_t) v812 * (uint64_t) v17);
        // pto: %321
        ;
        int64_t v814 = v813 % v45;
        // pto: %322, %323, %324
        ;
        int64_t v815 = v814 < v50 ? (int64_t) ((uint64_t) v814 + (uint64_t) v45) : v814;
        // pto: %325
        ;
        if (v815 == v50) {
          // pto: %326
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v816;
          // pto: %326
          ;
          uint64_t v817 = (uint64_t) v38;
          TASSIGN(v816, v817);
          // pto: %327
          ;
          const int64_t v818 = 1;
          // pto: %327
          ;
          const int64_t v819 = 0;
          // pto: %327
          ;
          int64_t v820 = v813 / v45;
          // pto: %327
          ;
          bool v821 = v813 < v819;
          // pto: %327
          ;
          bool v822 = v45 < v819;
          // pto: %327
          ;
          bool v823 = v821 == v822;
          // pto: %327
          ;
          bool v824 = v813 % v45 != v819 && v821 != v822;
          // pto: %327
          ;
          int64_t v825 = v824 ? v820 - v818 : v820;
          // pto: %328
          ;
          int64_t v826 = v825 < v50 ? v50 : v825;
          // pto: %329
          ;
          __gm__ int8_t* v827 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %329
          ;
          const int64_t v828 = 0;
          // pto: %329
          ;
          const int64_t v829 = 128;
          // pto: %329
          ;
          pto::Shape<1, 1, 1, 32, 128> v830 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %329
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v831 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %329
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v832 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v827 + (v828 + v826 * v829), v830, v831);
          TLOAD(v816, v832);
        } else {
          // pto: %330
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v833;
          // pto: %330
          ;
          uint64_t v834 = (uint64_t) v38;
          TASSIGN(v833, v834);
          // pto: %331
          ;
          const int64_t v835 = 1;
          // pto: %331
          ;
          const int64_t v836 = 0;
          // pto: %331
          ;
          int64_t v837 = v813 / v45;
          // pto: %331
          ;
          bool v838 = v813 < v836;
          // pto: %331
          ;
          bool v839 = v45 < v836;
          // pto: %331
          ;
          bool v840 = v838 == v839;
          // pto: %331
          ;
          bool v841 = v813 % v45 != v836 && v838 != v839;
          // pto: %331
          ;
          int64_t v842 = v841 ? v837 - v835 : v837;
          // pto: %332
          ;
          int64_t v843 = v842 < v50 ? v50 : v842;
          // pto: %333
          ;
          __gm__ int8_t* v844 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %333
          ;
          const int64_t v845 = 0;
          // pto: %333
          ;
          const int64_t v846 = 128;
          // pto: %333
          ;
          pto::Shape<1, 1, 1, 32, 128> v847 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %333
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v848 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %333
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v849 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v844 + (v845 + v843 * v846), v847, v848);
          TLOAD(v833, v849);
        };
        // pto: %336
        ;
        int64_t v850 = (int64_t) ((uint64_t) v292 + (uint64_t) v28);
        // pto: %337
        ;
        const int64_t v851 = 1;
        // pto: %337
        ;
        const int64_t v852 = 0;
        // pto: %337
        ;
        int64_t v853 = v850 / v64;
        // pto: %337
        ;
        bool v854 = v850 < v852;
        // pto: %337
        ;
        bool v855 = v64 < v852;
        // pto: %337
        ;
        bool v856 = v854 == v855;
        // pto: %337
        ;
        bool v857 = v850 % v64 != v852 && v854 != v855;
        // pto: %337
        ;
        int64_t v858 = v857 ? v853 - v851 : v853;
        // pto: %341
        ;
        int64_t v859 = v858 < v310 ? v858 : v310;
        // pto: %344, %342
        ;
        int32_t v860 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v859)];
        // pto: %345
        ;
        int64_t v861 = (int64_t) v860;
        // pto: %346
        ;
        int64_t v862 = v861 < v50 ? v50 : v861;
        // pto: %347
        ;
        int64_t v863 = (int64_t) ((uint64_t) v862 * (uint64_t) v17);
        // pto: %348
        ;
        int64_t v864 = v863 % v45;
        // pto: %349, %350, %351
        ;
        int64_t v865 = v864 < v50 ? (int64_t) ((uint64_t) v864 + (uint64_t) v45) : v864;
        // pto: %352
        ;
        if (v865 == v50) {
          // pto: %353
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v866;
          // pto: %353
          ;
          uint64_t v867 = (uint64_t) v37;
          TASSIGN(v866, v867);
          // pto: %354
          ;
          const int64_t v868 = 1;
          // pto: %354
          ;
          const int64_t v869 = 0;
          // pto: %354
          ;
          int64_t v870 = v863 / v45;
          // pto: %354
          ;
          bool v871 = v863 < v869;
          // pto: %354
          ;
          bool v872 = v45 < v869;
          // pto: %354
          ;
          bool v873 = v871 == v872;
          // pto: %354
          ;
          bool v874 = v863 % v45 != v869 && v871 != v872;
          // pto: %354
          ;
          int64_t v875 = v874 ? v870 - v868 : v870;
          // pto: %355
          ;
          int64_t v876 = v875 < v50 ? v50 : v875;
          // pto: %356
          ;
          __gm__ int8_t* v877 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %356
          ;
          const int64_t v878 = 0;
          // pto: %356
          ;
          const int64_t v879 = 128;
          // pto: %356
          ;
          pto::Shape<1, 1, 1, 32, 128> v880 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %356
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v881 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %356
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v882 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v877 + (v878 + v876 * v879), v880, v881);
          TLOAD(v866, v882);
        } else {
          // pto: %357
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v883;
          // pto: %357
          ;
          uint64_t v884 = (uint64_t) v37;
          TASSIGN(v883, v884);
          // pto: %358
          ;
          const int64_t v885 = 1;
          // pto: %358
          ;
          const int64_t v886 = 0;
          // pto: %358
          ;
          int64_t v887 = v863 / v45;
          // pto: %358
          ;
          bool v888 = v863 < v886;
          // pto: %358
          ;
          bool v889 = v45 < v886;
          // pto: %358
          ;
          bool v890 = v888 == v889;
          // pto: %358
          ;
          bool v891 = v863 % v45 != v886 && v888 != v889;
          // pto: %358
          ;
          int64_t v892 = v891 ? v887 - v885 : v887;
          // pto: %359
          ;
          int64_t v893 = v892 < v50 ? v50 : v892;
          // pto: %360
          ;
          __gm__ int8_t* v894 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %360
          ;
          const int64_t v895 = 0;
          // pto: %360
          ;
          const int64_t v896 = 128;
          // pto: %360
          ;
          pto::Shape<1, 1, 1, 32, 128> v897 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %360
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v898 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %360
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v899 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v894 + (v895 + v893 * v896), v897, v898);
          TLOAD(v883, v899);
        };
        // pto: %363
        ;
        int64_t v900 = (int64_t) ((uint64_t) v292 + (uint64_t) v27);
        // pto: %364
        ;
        const int64_t v901 = 1;
        // pto: %364
        ;
        const int64_t v902 = 0;
        // pto: %364
        ;
        int64_t v903 = v900 / v64;
        // pto: %364
        ;
        bool v904 = v900 < v902;
        // pto: %364
        ;
        bool v905 = v64 < v902;
        // pto: %364
        ;
        bool v906 = v904 == v905;
        // pto: %364
        ;
        bool v907 = v900 % v64 != v902 && v904 != v905;
        // pto: %364
        ;
        int64_t v908 = v907 ? v903 - v901 : v903;
        // pto: %368
        ;
        int64_t v909 = v908 < v310 ? v908 : v310;
        // pto: %371, %369
        ;
        int32_t v910 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v909)];
        // pto: %372
        ;
        int64_t v911 = (int64_t) v910;
        // pto: %373
        ;
        int64_t v912 = v911 < v50 ? v50 : v911;
        // pto: %374
        ;
        int64_t v913 = (int64_t) ((uint64_t) v912 * (uint64_t) v17);
        // pto: %375
        ;
        int64_t v914 = v913 % v45;
        // pto: %376, %377, %378
        ;
        int64_t v915 = v914 < v50 ? (int64_t) ((uint64_t) v914 + (uint64_t) v45) : v914;
        // pto: %379
        ;
        if (v915 == v50) {
          // pto: %380
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v916;
          // pto: %380
          ;
          uint64_t v917 = (uint64_t) v36;
          TASSIGN(v916, v917);
          // pto: %381
          ;
          const int64_t v918 = 1;
          // pto: %381
          ;
          const int64_t v919 = 0;
          // pto: %381
          ;
          int64_t v920 = v913 / v45;
          // pto: %381
          ;
          bool v921 = v913 < v919;
          // pto: %381
          ;
          bool v922 = v45 < v919;
          // pto: %381
          ;
          bool v923 = v921 == v922;
          // pto: %381
          ;
          bool v924 = v913 % v45 != v919 && v921 != v922;
          // pto: %381
          ;
          int64_t v925 = v924 ? v920 - v918 : v920;
          // pto: %382
          ;
          int64_t v926 = v925 < v50 ? v50 : v925;
          // pto: %383
          ;
          __gm__ int8_t* v927 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %383
          ;
          const int64_t v928 = 0;
          // pto: %383
          ;
          const int64_t v929 = 128;
          // pto: %383
          ;
          pto::Shape<1, 1, 1, 32, 128> v930 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %383
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v931 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %383
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v932 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v927 + (v928 + v926 * v929), v930, v931);
          TLOAD(v916, v932);
        } else {
          // pto: %384
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v933;
          // pto: %384
          ;
          uint64_t v934 = (uint64_t) v36;
          TASSIGN(v933, v934);
          // pto: %385
          ;
          const int64_t v935 = 1;
          // pto: %385
          ;
          const int64_t v936 = 0;
          // pto: %385
          ;
          int64_t v937 = v913 / v45;
          // pto: %385
          ;
          bool v938 = v913 < v936;
          // pto: %385
          ;
          bool v939 = v45 < v936;
          // pto: %385
          ;
          bool v940 = v938 == v939;
          // pto: %385
          ;
          bool v941 = v913 % v45 != v936 && v938 != v939;
          // pto: %385
          ;
          int64_t v942 = v941 ? v937 - v935 : v937;
          // pto: %386
          ;
          int64_t v943 = v942 < v50 ? v50 : v942;
          // pto: %387
          ;
          __gm__ int8_t* v944 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %387
          ;
          const int64_t v945 = 0;
          // pto: %387
          ;
          const int64_t v946 = 128;
          // pto: %387
          ;
          pto::Shape<1, 1, 1, 32, 128> v947 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %387
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v948 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %387
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v949 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v944 + (v945 + v943 * v946), v947, v948);
          TLOAD(v933, v949);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
        // pto: %t__tmp_v776
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v950 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %t__tmp_v776
        ;
        uint64_t v951 = (uint64_t) v39;
        TASSIGN(v950, v951);
        // pto: %buf_prefetched_key_inline6782__ssa_v13
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v952 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_prefetched_key_inline6782__ssa_v13
        ;
        uint64_t v953 = (uint64_t) v39;
        TASSIGN(v952, v953);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        TMOV(v952, v950);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        // pto: %buf_key_panel_inline6800__ssa_v7
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v954 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_key_panel_inline6800__ssa_v7
        ;
        uint64_t v955 = (uint64_t) v39;
        TASSIGN(v954, v955);
        // pto: %buf_scores_l1_inline6801__ssa_v8
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v956 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_l1_inline6801__ssa_v8
        ;
        uint64_t v957 = (uint64_t) v39;
        TASSIGN(v956, v957);
        // pto: %buf_previous_pair_inline6802__ssa_v2
        ;
        Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v958 = Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_previous_pair_inline6802__ssa_v2
        ;
        uint64_t v959 = (uint64_t) v41;
        TASSIGN(v958, v959);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v960 = static_cast<uint16_t>(v50);
        uint16_t v961 = static_cast<uint16_t>(v50);
        TEXTRACT(v958, v746, v960, v961);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        // pto: %buf_scores_inline6803__ssa_v6
        ;
        Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v962 = Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_inline6803__ssa_v6
        ;
        uint64_t v963 = (uint64_t) v39;
        TASSIGN(v962, v963);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v962, v281, v954);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
        // pto: %buf_reduced_pair_inline6804__ssa_v2
        ;
        Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v964 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v62, v45);
        // pto: %buf_reduced_pair_inline6804__ssa_v2
        ;
        uint64_t v965 = (uint64_t) v42;
        TASSIGN(v964, v965);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
        TMATMUL(v964, v283, v958);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
        uint64_t v966 = static_cast<uint64_t>(v65);
        uint16_t v967 = static_cast<uint16_t>(v50);
        uint16_t v968 = static_cast<uint16_t>(v50);
        TINSERT<Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v956, v962, v966, v967, v968);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID2);
        v964.SetValidShape(v63, v45);
        // pto: %391
        ;
        __gm__ float* v969 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %391
        ;
        const int64_t v970 = 128;
        // pto: %391
        ;
        const int64_t v971 = 768;
        // pto: %391
        ;
        pto::Shape<1, 1, 1, 2, 128> v972 = pto::Shape<1, 1, 1, 2, 128>();
        // pto: %391
        ;
        pto::Stride<1536, 1536, 1536, 768, 1> v973 = pto::Stride<1536, 1536, 1536, 768, 1>();
        // pto: %391
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND> v974 = GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND>(v969 + (v970 + v739 * v971), v972, v973);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
        TSTORE(v974, v964);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
        // pto: %buf_previous_l1_inline6780__ssa_v3
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v975 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_previous_l1_inline6780__ssa_v3
        ;
        uint64_t v976 = (uint64_t) v39;
        TASSIGN(v975, v976);
        // pto: %buf_panel_keys_inline6794__ssa_v63
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v977 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_panel_keys_inline6794__ssa_v63
        ;
        uint64_t v978 = (uint64_t) v40;
        TASSIGN(v977, v978);
        // pto: %395
        ;
        int64_t v979 = (int64_t) ((uint64_t) v292 + (uint64_t) v250);
        // pto: %401
        ;
        const int64_t v980 = 1;
        // pto: %401
        ;
        const int64_t v981 = 0;
        // pto: %401
        ;
        int64_t v982 = v979 / v64;
        // pto: %401
        ;
        bool v983 = v979 < v981;
        // pto: %401
        ;
        bool v984 = v64 < v981;
        // pto: %401
        ;
        bool v985 = v983 == v984;
        // pto: %401
        ;
        bool v986 = v979 % v64 != v981 && v983 != v984;
        // pto: %401
        ;
        int64_t v987 = v986 ? v982 - v980 : v982;
        // pto: %405
        ;
        int64_t v988 = v987 < v310 ? v987 : v310;
        // pto: %408, %406
        ;
        int32_t v989 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v988)];
        // pto: %409
        ;
        int64_t v990 = (int64_t) v989;
        // pto: %410
        ;
        int64_t v991 = v990 < v50 ? v50 : v990;
        // pto: %411
        ;
        int64_t v992 = (int64_t) ((uint64_t) v991 * (uint64_t) v17);
        // pto: %412
        ;
        int64_t v993 = v992 % v45;
        // pto: %413, %414, %415
        ;
        int64_t v994 = v993 < v50 ? (int64_t) ((uint64_t) v993 + (uint64_t) v45) : v993;
        // pto: %416
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        if (v994 == v50) {
          // pto: %417
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v995;
          // pto: %417
          ;
          uint64_t v996 = (uint64_t) v40;
          TASSIGN(v995, v996);
          // pto: %418
          ;
          const int64_t v997 = 1;
          // pto: %418
          ;
          const int64_t v998 = 0;
          // pto: %418
          ;
          int64_t v999 = v992 / v45;
          // pto: %418
          ;
          bool v1000 = v992 < v998;
          // pto: %418
          ;
          bool v1001 = v45 < v998;
          // pto: %418
          ;
          bool v1002 = v1000 == v1001;
          // pto: %418
          ;
          bool v1003 = v992 % v45 != v998 && v1000 != v1001;
          // pto: %418
          ;
          int64_t v1004 = v1003 ? v999 - v997 : v999;
          // pto: %419
          ;
          int64_t v1005 = v1004 < v50 ? v50 : v1004;
          // pto: %420
          ;
          __gm__ int8_t* v1006 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %420
          ;
          const int64_t v1007 = 0;
          // pto: %420
          ;
          const int64_t v1008 = 128;
          // pto: %420
          ;
          pto::Shape<1, 1, 1, 32, 128> v1009 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %420
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1010 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %420
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1011 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1006 + (v1007 + v1005 * v1008), v1009, v1010);
          TLOAD(v995, v1011);
        } else {
          // pto: %421
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1012;
          // pto: %421
          ;
          uint64_t v1013 = (uint64_t) v40;
          TASSIGN(v1012, v1013);
          // pto: %422
          ;
          const int64_t v1014 = 1;
          // pto: %422
          ;
          const int64_t v1015 = 0;
          // pto: %422
          ;
          int64_t v1016 = v992 / v45;
          // pto: %422
          ;
          bool v1017 = v992 < v1015;
          // pto: %422
          ;
          bool v1018 = v45 < v1015;
          // pto: %422
          ;
          bool v1019 = v1017 == v1018;
          // pto: %422
          ;
          bool v1020 = v992 % v45 != v1015 && v1017 != v1018;
          // pto: %422
          ;
          int64_t v1021 = v1020 ? v1016 - v1014 : v1016;
          // pto: %423
          ;
          int64_t v1022 = v1021 < v50 ? v50 : v1021;
          // pto: %424
          ;
          __gm__ int8_t* v1023 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %424
          ;
          const int64_t v1024 = 0;
          // pto: %424
          ;
          const int64_t v1025 = 128;
          // pto: %424
          ;
          pto::Shape<1, 1, 1, 32, 128> v1026 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %424
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1027 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %424
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1028 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1023 + (v1024 + v1022 * v1025), v1026, v1027);
          TLOAD(v1012, v1028);
        };
        // pto: %434
        ;
        int64_t v1029 = (int64_t) ((uint64_t) v979 + (uint64_t) v64);
        // pto: %435
        ;
        const int64_t v1030 = 1;
        // pto: %435
        ;
        const int64_t v1031 = 0;
        // pto: %435
        ;
        int64_t v1032 = v1029 / v64;
        // pto: %435
        ;
        bool v1033 = v1029 < v1031;
        // pto: %435
        ;
        bool v1034 = v64 < v1031;
        // pto: %435
        ;
        bool v1035 = v1033 == v1034;
        // pto: %435
        ;
        bool v1036 = v1029 % v64 != v1031 && v1033 != v1034;
        // pto: %435
        ;
        int64_t v1037 = v1036 ? v1032 - v1030 : v1032;
        // pto: %439
        ;
        int64_t v1038 = v1037 < v310 ? v1037 : v310;
        // pto: %442, %440
        ;
        int32_t v1039 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v1038)];
        // pto: %443
        ;
        int64_t v1040 = (int64_t) v1039;
        // pto: %444
        ;
        int64_t v1041 = v1040 < v50 ? v50 : v1040;
        // pto: %445
        ;
        int64_t v1042 = (int64_t) ((uint64_t) v1041 * (uint64_t) v17);
        // pto: %446
        ;
        int64_t v1043 = v1042 % v45;
        // pto: %447, %448, %449
        ;
        int64_t v1044 = v1043 < v50 ? (int64_t) ((uint64_t) v1043 + (uint64_t) v45) : v1043;
        // pto: %450
        ;
        if (v1044 == v50) {
          // pto: %451
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1045;
          // pto: %451
          ;
          uint64_t v1046 = (uint64_t) v34;
          TASSIGN(v1045, v1046);
          // pto: %452
          ;
          const int64_t v1047 = 1;
          // pto: %452
          ;
          const int64_t v1048 = 0;
          // pto: %452
          ;
          int64_t v1049 = v1042 / v45;
          // pto: %452
          ;
          bool v1050 = v1042 < v1048;
          // pto: %452
          ;
          bool v1051 = v45 < v1048;
          // pto: %452
          ;
          bool v1052 = v1050 == v1051;
          // pto: %452
          ;
          bool v1053 = v1042 % v45 != v1048 && v1050 != v1051;
          // pto: %452
          ;
          int64_t v1054 = v1053 ? v1049 - v1047 : v1049;
          // pto: %453
          ;
          int64_t v1055 = v1054 < v50 ? v50 : v1054;
          // pto: %454
          ;
          __gm__ int8_t* v1056 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %454
          ;
          const int64_t v1057 = 0;
          // pto: %454
          ;
          const int64_t v1058 = 128;
          // pto: %454
          ;
          pto::Shape<1, 1, 1, 32, 128> v1059 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %454
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1060 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %454
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1061 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1056 + (v1057 + v1055 * v1058), v1059, v1060);
          TLOAD(v1045, v1061);
        } else {
          // pto: %455
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1062;
          // pto: %455
          ;
          uint64_t v1063 = (uint64_t) v34;
          TASSIGN(v1062, v1063);
          // pto: %456
          ;
          const int64_t v1064 = 1;
          // pto: %456
          ;
          const int64_t v1065 = 0;
          // pto: %456
          ;
          int64_t v1066 = v1042 / v45;
          // pto: %456
          ;
          bool v1067 = v1042 < v1065;
          // pto: %456
          ;
          bool v1068 = v45 < v1065;
          // pto: %456
          ;
          bool v1069 = v1067 == v1068;
          // pto: %456
          ;
          bool v1070 = v1042 % v45 != v1065 && v1067 != v1068;
          // pto: %456
          ;
          int64_t v1071 = v1070 ? v1066 - v1064 : v1066;
          // pto: %457
          ;
          int64_t v1072 = v1071 < v50 ? v50 : v1071;
          // pto: %458
          ;
          __gm__ int8_t* v1073 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %458
          ;
          const int64_t v1074 = 0;
          // pto: %458
          ;
          const int64_t v1075 = 128;
          // pto: %458
          ;
          pto::Shape<1, 1, 1, 32, 128> v1076 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %458
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1077 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %458
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1078 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1073 + (v1074 + v1072 * v1075), v1076, v1077);
          TLOAD(v1062, v1078);
        };
        // pto: %468
        ;
        int64_t v1079 = (int64_t) ((uint64_t) v979 + (uint64_t) v61);
        // pto: %469
        ;
        const int64_t v1080 = 1;
        // pto: %469
        ;
        const int64_t v1081 = 0;
        // pto: %469
        ;
        int64_t v1082 = v1079 / v64;
        // pto: %469
        ;
        bool v1083 = v1079 < v1081;
        // pto: %469
        ;
        bool v1084 = v64 < v1081;
        // pto: %469
        ;
        bool v1085 = v1083 == v1084;
        // pto: %469
        ;
        bool v1086 = v1079 % v64 != v1081 && v1083 != v1084;
        // pto: %469
        ;
        int64_t v1087 = v1086 ? v1082 - v1080 : v1082;
        // pto: %473
        ;
        int64_t v1088 = v1087 < v310 ? v1087 : v310;
        // pto: %476, %474
        ;
        int32_t v1089 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v1088)];
        // pto: %477
        ;
        int64_t v1090 = (int64_t) v1089;
        // pto: %478
        ;
        int64_t v1091 = v1090 < v50 ? v50 : v1090;
        // pto: %479
        ;
        int64_t v1092 = (int64_t) ((uint64_t) v1091 * (uint64_t) v17);
        // pto: %480
        ;
        int64_t v1093 = v1092 % v45;
        // pto: %481, %482, %483
        ;
        int64_t v1094 = v1093 < v50 ? (int64_t) ((uint64_t) v1093 + (uint64_t) v45) : v1093;
        // pto: %484
        ;
        if (v1094 == v50) {
          // pto: %485
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1095;
          // pto: %485
          ;
          uint64_t v1096 = (uint64_t) v32;
          TASSIGN(v1095, v1096);
          // pto: %486
          ;
          const int64_t v1097 = 1;
          // pto: %486
          ;
          const int64_t v1098 = 0;
          // pto: %486
          ;
          int64_t v1099 = v1092 / v45;
          // pto: %486
          ;
          bool v1100 = v1092 < v1098;
          // pto: %486
          ;
          bool v1101 = v45 < v1098;
          // pto: %486
          ;
          bool v1102 = v1100 == v1101;
          // pto: %486
          ;
          bool v1103 = v1092 % v45 != v1098 && v1100 != v1101;
          // pto: %486
          ;
          int64_t v1104 = v1103 ? v1099 - v1097 : v1099;
          // pto: %487
          ;
          int64_t v1105 = v1104 < v50 ? v50 : v1104;
          // pto: %488
          ;
          __gm__ int8_t* v1106 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %488
          ;
          const int64_t v1107 = 0;
          // pto: %488
          ;
          const int64_t v1108 = 128;
          // pto: %488
          ;
          pto::Shape<1, 1, 1, 32, 128> v1109 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %488
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1110 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %488
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1111 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1106 + (v1107 + v1105 * v1108), v1109, v1110);
          TLOAD(v1095, v1111);
        } else {
          // pto: %489
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1112;
          // pto: %489
          ;
          uint64_t v1113 = (uint64_t) v32;
          TASSIGN(v1112, v1113);
          // pto: %490
          ;
          const int64_t v1114 = 1;
          // pto: %490
          ;
          const int64_t v1115 = 0;
          // pto: %490
          ;
          int64_t v1116 = v1092 / v45;
          // pto: %490
          ;
          bool v1117 = v1092 < v1115;
          // pto: %490
          ;
          bool v1118 = v45 < v1115;
          // pto: %490
          ;
          bool v1119 = v1117 == v1118;
          // pto: %490
          ;
          bool v1120 = v1092 % v45 != v1115 && v1117 != v1118;
          // pto: %490
          ;
          int64_t v1121 = v1120 ? v1116 - v1114 : v1116;
          // pto: %491
          ;
          int64_t v1122 = v1121 < v50 ? v50 : v1121;
          // pto: %492
          ;
          __gm__ int8_t* v1123 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %492
          ;
          const int64_t v1124 = 0;
          // pto: %492
          ;
          const int64_t v1125 = 128;
          // pto: %492
          ;
          pto::Shape<1, 1, 1, 32, 128> v1126 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %492
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1127 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %492
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1128 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1123 + (v1124 + v1122 * v1125), v1126, v1127);
          TLOAD(v1112, v1128);
        };
        // pto: %502
        ;
        int64_t v1129 = (int64_t) ((uint64_t) v979 + (uint64_t) v47);
        // pto: %503
        ;
        const int64_t v1130 = 1;
        // pto: %503
        ;
        const int64_t v1131 = 0;
        // pto: %503
        ;
        int64_t v1132 = v1129 / v64;
        // pto: %503
        ;
        bool v1133 = v1129 < v1131;
        // pto: %503
        ;
        bool v1134 = v64 < v1131;
        // pto: %503
        ;
        bool v1135 = v1133 == v1134;
        // pto: %503
        ;
        bool v1136 = v1129 % v64 != v1131 && v1133 != v1134;
        // pto: %503
        ;
        int64_t v1137 = v1136 ? v1132 - v1130 : v1132;
        // pto: %507
        ;
        int64_t v1138 = v1137 < v310 ? v1137 : v310;
        // pto: %510, %508
        ;
        int32_t v1139 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v1138)];
        // pto: %511
        ;
        int64_t v1140 = (int64_t) v1139;
        // pto: %512
        ;
        int64_t v1141 = v1140 < v50 ? v50 : v1140;
        // pto: %513
        ;
        int64_t v1142 = (int64_t) ((uint64_t) v1141 * (uint64_t) v17);
        // pto: %514
        ;
        int64_t v1143 = v1142 % v45;
        // pto: %515, %516, %517
        ;
        int64_t v1144 = v1143 < v50 ? (int64_t) ((uint64_t) v1143 + (uint64_t) v45) : v1143;
        // pto: %518
        ;
        if (v1144 == v50) {
          // pto: %519
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1145;
          // pto: %519
          ;
          uint64_t v1146 = (uint64_t) v30;
          TASSIGN(v1145, v1146);
          // pto: %520
          ;
          const int64_t v1147 = 1;
          // pto: %520
          ;
          const int64_t v1148 = 0;
          // pto: %520
          ;
          int64_t v1149 = v1142 / v45;
          // pto: %520
          ;
          bool v1150 = v1142 < v1148;
          // pto: %520
          ;
          bool v1151 = v45 < v1148;
          // pto: %520
          ;
          bool v1152 = v1150 == v1151;
          // pto: %520
          ;
          bool v1153 = v1142 % v45 != v1148 && v1150 != v1151;
          // pto: %520
          ;
          int64_t v1154 = v1153 ? v1149 - v1147 : v1149;
          // pto: %521
          ;
          int64_t v1155 = v1154 < v50 ? v50 : v1154;
          // pto: %522
          ;
          __gm__ int8_t* v1156 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %522
          ;
          const int64_t v1157 = 0;
          // pto: %522
          ;
          const int64_t v1158 = 128;
          // pto: %522
          ;
          pto::Shape<1, 1, 1, 32, 128> v1159 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %522
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1160 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %522
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1161 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1156 + (v1157 + v1155 * v1158), v1159, v1160);
          TLOAD(v1145, v1161);
        } else {
          // pto: %523
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1162;
          // pto: %523
          ;
          uint64_t v1163 = (uint64_t) v30;
          TASSIGN(v1162, v1163);
          // pto: %524
          ;
          const int64_t v1164 = 1;
          // pto: %524
          ;
          const int64_t v1165 = 0;
          // pto: %524
          ;
          int64_t v1166 = v1142 / v45;
          // pto: %524
          ;
          bool v1167 = v1142 < v1165;
          // pto: %524
          ;
          bool v1168 = v45 < v1165;
          // pto: %524
          ;
          bool v1169 = v1167 == v1168;
          // pto: %524
          ;
          bool v1170 = v1142 % v45 != v1165 && v1167 != v1168;
          // pto: %524
          ;
          int64_t v1171 = v1170 ? v1166 - v1164 : v1166;
          // pto: %525
          ;
          int64_t v1172 = v1171 < v50 ? v50 : v1171;
          // pto: %526
          ;
          __gm__ int8_t* v1173 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %526
          ;
          const int64_t v1174 = 0;
          // pto: %526
          ;
          const int64_t v1175 = 128;
          // pto: %526
          ;
          pto::Shape<1, 1, 1, 32, 128> v1176 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %526
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1177 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %526
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1178 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1173 + (v1174 + v1172 * v1175), v1176, v1177);
          TLOAD(v1162, v1178);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        // pto: %t__tmp_v782
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1179 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %t__tmp_v782
        ;
        uint64_t v1180 = (uint64_t) v40;
        TASSIGN(v1179, v1180);
        // pto: %buf_prefetched_key_inline6782__ssa_v18
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1181 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_prefetched_key_inline6782__ssa_v18
        ;
        uint64_t v1182 = (uint64_t) v39;
        TASSIGN(v1181, v1182);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        TMOV(v1181, v1179);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        // pto: %buf_key_panel_inline6800__ssa_v10
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1183 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_key_panel_inline6800__ssa_v10
        ;
        uint64_t v1184 = (uint64_t) v39;
        TASSIGN(v1183, v1184);
        // pto: %buf_scores_l1_inline6801__ssa_v12
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1185 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_l1_inline6801__ssa_v12
        ;
        uint64_t v1186 = (uint64_t) v40;
        TASSIGN(v1185, v1186);
        // pto: %buf_previous_pair_inline6802__ssa_v3
        ;
        Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1187 = Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_previous_pair_inline6802__ssa_v3
        ;
        uint64_t v1188 = (uint64_t) v41;
        TASSIGN(v1187, v1188);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        uint16_t v1189 = static_cast<uint16_t>(v50);
        uint16_t v1190 = static_cast<uint16_t>(v50);
        TEXTRACT(v1187, v975, v1189, v1190);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
        // pto: %buf_scores_inline6803__ssa_v9
        ;
        Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1191 = Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_inline6803__ssa_v9
        ;
        uint64_t v1192 = (uint64_t) v39;
        TASSIGN(v1191, v1192);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
        TMATMUL(v1191, v281, v1183);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
        // pto: %buf_reduced_pair_inline6804__ssa_v3
        ;
        Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1193 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v62, v45);
        // pto: %buf_reduced_pair_inline6804__ssa_v3
        ;
        uint64_t v1194 = (uint64_t) v42;
        TASSIGN(v1193, v1194);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
        TMATMUL(v1193, v283, v1187);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID6);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
        uint64_t v1195 = static_cast<uint64_t>(v65);
        uint16_t v1196 = static_cast<uint16_t>(v50);
        uint16_t v1197 = static_cast<uint16_t>(v50);
        TINSERT<Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1185, v1191, v1195, v1196, v1197);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID3);
        v1193.SetValidShape(v63, v45);
        // pto: %530
        ;
        __gm__ float* v1198 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %530
        ;
        const int64_t v1199 = 256;
        // pto: %530
        ;
        const int64_t v1200 = 768;
        // pto: %530
        ;
        pto::Shape<1, 1, 1, 2, 128> v1201 = pto::Shape<1, 1, 1, 2, 128>();
        // pto: %530
        ;
        pto::Stride<1536, 1536, 1536, 768, 1> v1202 = pto::Stride<1536, 1536, 1536, 768, 1>();
        // pto: %530
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND> v1203 = GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND>(v1198 + (v1199 + v739 * v1200), v1201, v1202);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID6);
        TSTORE(v1203, v1193);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
        // pto: %buf_previous_l1_inline6780__ssa_v4
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1204 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_previous_l1_inline6780__ssa_v4
        ;
        uint64_t v1205 = (uint64_t) v40;
        TASSIGN(v1204, v1205);
        // pto: %buf_panel_keys_inline6794__ssa_v84
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1206 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_panel_keys_inline6794__ssa_v84
        ;
        uint64_t v1207 = (uint64_t) v39;
        TASSIGN(v1206, v1207);
        // pto: %539
        ;
        int64_t v1208 = (int64_t) ((uint64_t) v979 + (uint64_t) v45);
        // pto: %540
        ;
        const int64_t v1209 = 1;
        // pto: %540
        ;
        const int64_t v1210 = 0;
        // pto: %540
        ;
        int64_t v1211 = v1208 / v64;
        // pto: %540
        ;
        bool v1212 = v1208 < v1210;
        // pto: %540
        ;
        bool v1213 = v64 < v1210;
        // pto: %540
        ;
        bool v1214 = v1212 == v1213;
        // pto: %540
        ;
        bool v1215 = v1208 % v64 != v1210 && v1212 != v1213;
        // pto: %540
        ;
        int64_t v1216 = v1215 ? v1211 - v1209 : v1211;
        // pto: %544
        ;
        int64_t v1217 = v1216 < v310 ? v1216 : v310;
        // pto: %547, %545
        ;
        int32_t v1218 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v1217)];
        // pto: %548
        ;
        int64_t v1219 = (int64_t) v1218;
        // pto: %549
        ;
        int64_t v1220 = v1219 < v50 ? v50 : v1219;
        // pto: %550
        ;
        int64_t v1221 = (int64_t) ((uint64_t) v1220 * (uint64_t) v17);
        // pto: %551
        ;
        int64_t v1222 = v1221 % v45;
        // pto: %552, %553, %554
        ;
        int64_t v1223 = v1222 < v50 ? (int64_t) ((uint64_t) v1222 + (uint64_t) v45) : v1222;
        // pto: %555
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
        if (v1223 == v50) {
          // pto: %556
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1224;
          // pto: %556
          ;
          uint64_t v1225 = (uint64_t) v39;
          TASSIGN(v1224, v1225);
          // pto: %557
          ;
          const int64_t v1226 = 1;
          // pto: %557
          ;
          const int64_t v1227 = 0;
          // pto: %557
          ;
          int64_t v1228 = v1221 / v45;
          // pto: %557
          ;
          bool v1229 = v1221 < v1227;
          // pto: %557
          ;
          bool v1230 = v45 < v1227;
          // pto: %557
          ;
          bool v1231 = v1229 == v1230;
          // pto: %557
          ;
          bool v1232 = v1221 % v45 != v1227 && v1229 != v1230;
          // pto: %557
          ;
          int64_t v1233 = v1232 ? v1228 - v1226 : v1228;
          // pto: %558
          ;
          int64_t v1234 = v1233 < v50 ? v50 : v1233;
          // pto: %559
          ;
          __gm__ int8_t* v1235 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %559
          ;
          const int64_t v1236 = 0;
          // pto: %559
          ;
          const int64_t v1237 = 128;
          // pto: %559
          ;
          pto::Shape<1, 1, 1, 32, 128> v1238 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %559
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1239 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %559
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1240 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1235 + (v1236 + v1234 * v1237), v1238, v1239);
          TLOAD(v1224, v1240);
        } else {
          // pto: %560
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1241;
          // pto: %560
          ;
          uint64_t v1242 = (uint64_t) v39;
          TASSIGN(v1241, v1242);
          // pto: %561
          ;
          const int64_t v1243 = 1;
          // pto: %561
          ;
          const int64_t v1244 = 0;
          // pto: %561
          ;
          int64_t v1245 = v1221 / v45;
          // pto: %561
          ;
          bool v1246 = v1221 < v1244;
          // pto: %561
          ;
          bool v1247 = v45 < v1244;
          // pto: %561
          ;
          bool v1248 = v1246 == v1247;
          // pto: %561
          ;
          bool v1249 = v1221 % v45 != v1244 && v1246 != v1247;
          // pto: %561
          ;
          int64_t v1250 = v1249 ? v1245 - v1243 : v1245;
          // pto: %562
          ;
          int64_t v1251 = v1250 < v50 ? v50 : v1250;
          // pto: %563
          ;
          __gm__ int8_t* v1252 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %563
          ;
          const int64_t v1253 = 0;
          // pto: %563
          ;
          const int64_t v1254 = 128;
          // pto: %563
          ;
          pto::Shape<1, 1, 1, 32, 128> v1255 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %563
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1256 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %563
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1257 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1252 + (v1253 + v1251 * v1254), v1255, v1256);
          TLOAD(v1241, v1257);
        };
        // pto: %573
        ;
        int64_t v1258 = (int64_t) ((uint64_t) v979 + (uint64_t) v35);
        // pto: %574
        ;
        const int64_t v1259 = 1;
        // pto: %574
        ;
        const int64_t v1260 = 0;
        // pto: %574
        ;
        int64_t v1261 = v1258 / v64;
        // pto: %574
        ;
        bool v1262 = v1258 < v1260;
        // pto: %574
        ;
        bool v1263 = v64 < v1260;
        // pto: %574
        ;
        bool v1264 = v1262 == v1263;
        // pto: %574
        ;
        bool v1265 = v1258 % v64 != v1260 && v1262 != v1263;
        // pto: %574
        ;
        int64_t v1266 = v1265 ? v1261 - v1259 : v1261;
        // pto: %578
        ;
        int64_t v1267 = v1266 < v310 ? v1266 : v310;
        // pto: %581, %579
        ;
        int32_t v1268 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v1267)];
        // pto: %582
        ;
        int64_t v1269 = (int64_t) v1268;
        // pto: %583
        ;
        int64_t v1270 = v1269 < v50 ? v50 : v1269;
        // pto: %584
        ;
        int64_t v1271 = (int64_t) ((uint64_t) v1270 * (uint64_t) v17);
        // pto: %585
        ;
        int64_t v1272 = v1271 % v45;
        // pto: %586, %587, %588
        ;
        int64_t v1273 = v1272 < v50 ? (int64_t) ((uint64_t) v1272 + (uint64_t) v45) : v1272;
        // pto: %589
        ;
        if (v1273 == v50) {
          // pto: %590
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1274;
          // pto: %590
          ;
          uint64_t v1275 = (uint64_t) v38;
          TASSIGN(v1274, v1275);
          // pto: %591
          ;
          const int64_t v1276 = 1;
          // pto: %591
          ;
          const int64_t v1277 = 0;
          // pto: %591
          ;
          int64_t v1278 = v1271 / v45;
          // pto: %591
          ;
          bool v1279 = v1271 < v1277;
          // pto: %591
          ;
          bool v1280 = v45 < v1277;
          // pto: %591
          ;
          bool v1281 = v1279 == v1280;
          // pto: %591
          ;
          bool v1282 = v1271 % v45 != v1277 && v1279 != v1280;
          // pto: %591
          ;
          int64_t v1283 = v1282 ? v1278 - v1276 : v1278;
          // pto: %592
          ;
          int64_t v1284 = v1283 < v50 ? v50 : v1283;
          // pto: %593
          ;
          __gm__ int8_t* v1285 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %593
          ;
          const int64_t v1286 = 0;
          // pto: %593
          ;
          const int64_t v1287 = 128;
          // pto: %593
          ;
          pto::Shape<1, 1, 1, 32, 128> v1288 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %593
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1289 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %593
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1290 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1285 + (v1286 + v1284 * v1287), v1288, v1289);
          TLOAD(v1274, v1290);
        } else {
          // pto: %594
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1291;
          // pto: %594
          ;
          uint64_t v1292 = (uint64_t) v38;
          TASSIGN(v1291, v1292);
          // pto: %595
          ;
          const int64_t v1293 = 1;
          // pto: %595
          ;
          const int64_t v1294 = 0;
          // pto: %595
          ;
          int64_t v1295 = v1271 / v45;
          // pto: %595
          ;
          bool v1296 = v1271 < v1294;
          // pto: %595
          ;
          bool v1297 = v45 < v1294;
          // pto: %595
          ;
          bool v1298 = v1296 == v1297;
          // pto: %595
          ;
          bool v1299 = v1271 % v45 != v1294 && v1296 != v1297;
          // pto: %595
          ;
          int64_t v1300 = v1299 ? v1295 - v1293 : v1295;
          // pto: %596
          ;
          int64_t v1301 = v1300 < v50 ? v50 : v1300;
          // pto: %597
          ;
          __gm__ int8_t* v1302 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %597
          ;
          const int64_t v1303 = 0;
          // pto: %597
          ;
          const int64_t v1304 = 128;
          // pto: %597
          ;
          pto::Shape<1, 1, 1, 32, 128> v1305 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %597
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1306 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %597
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1307 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1302 + (v1303 + v1301 * v1304), v1305, v1306);
          TLOAD(v1291, v1307);
        };
        // pto: %607
        ;
        int64_t v1308 = (int64_t) ((uint64_t) v979 + (uint64_t) v33);
        // pto: %608
        ;
        const int64_t v1309 = 1;
        // pto: %608
        ;
        const int64_t v1310 = 0;
        // pto: %608
        ;
        int64_t v1311 = v1308 / v64;
        // pto: %608
        ;
        bool v1312 = v1308 < v1310;
        // pto: %608
        ;
        bool v1313 = v64 < v1310;
        // pto: %608
        ;
        bool v1314 = v1312 == v1313;
        // pto: %608
        ;
        bool v1315 = v1308 % v64 != v1310 && v1312 != v1313;
        // pto: %608
        ;
        int64_t v1316 = v1315 ? v1311 - v1309 : v1311;
        // pto: %612
        ;
        int64_t v1317 = v1316 < v310 ? v1316 : v310;
        // pto: %615, %613
        ;
        int32_t v1318 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v1317)];
        // pto: %616
        ;
        int64_t v1319 = (int64_t) v1318;
        // pto: %617
        ;
        int64_t v1320 = v1319 < v50 ? v50 : v1319;
        // pto: %618
        ;
        int64_t v1321 = (int64_t) ((uint64_t) v1320 * (uint64_t) v17);
        // pto: %619
        ;
        int64_t v1322 = v1321 % v45;
        // pto: %620, %621, %622
        ;
        int64_t v1323 = v1322 < v50 ? (int64_t) ((uint64_t) v1322 + (uint64_t) v45) : v1322;
        // pto: %623
        ;
        if (v1323 == v50) {
          // pto: %624
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1324;
          // pto: %624
          ;
          uint64_t v1325 = (uint64_t) v37;
          TASSIGN(v1324, v1325);
          // pto: %625
          ;
          const int64_t v1326 = 1;
          // pto: %625
          ;
          const int64_t v1327 = 0;
          // pto: %625
          ;
          int64_t v1328 = v1321 / v45;
          // pto: %625
          ;
          bool v1329 = v1321 < v1327;
          // pto: %625
          ;
          bool v1330 = v45 < v1327;
          // pto: %625
          ;
          bool v1331 = v1329 == v1330;
          // pto: %625
          ;
          bool v1332 = v1321 % v45 != v1327 && v1329 != v1330;
          // pto: %625
          ;
          int64_t v1333 = v1332 ? v1328 - v1326 : v1328;
          // pto: %626
          ;
          int64_t v1334 = v1333 < v50 ? v50 : v1333;
          // pto: %627
          ;
          __gm__ int8_t* v1335 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %627
          ;
          const int64_t v1336 = 0;
          // pto: %627
          ;
          const int64_t v1337 = 128;
          // pto: %627
          ;
          pto::Shape<1, 1, 1, 32, 128> v1338 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %627
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1339 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %627
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1340 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1335 + (v1336 + v1334 * v1337), v1338, v1339);
          TLOAD(v1324, v1340);
        } else {
          // pto: %628
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1341;
          // pto: %628
          ;
          uint64_t v1342 = (uint64_t) v37;
          TASSIGN(v1341, v1342);
          // pto: %629
          ;
          const int64_t v1343 = 1;
          // pto: %629
          ;
          const int64_t v1344 = 0;
          // pto: %629
          ;
          int64_t v1345 = v1321 / v45;
          // pto: %629
          ;
          bool v1346 = v1321 < v1344;
          // pto: %629
          ;
          bool v1347 = v45 < v1344;
          // pto: %629
          ;
          bool v1348 = v1346 == v1347;
          // pto: %629
          ;
          bool v1349 = v1321 % v45 != v1344 && v1346 != v1347;
          // pto: %629
          ;
          int64_t v1350 = v1349 ? v1345 - v1343 : v1345;
          // pto: %630
          ;
          int64_t v1351 = v1350 < v50 ? v50 : v1350;
          // pto: %631
          ;
          __gm__ int8_t* v1352 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %631
          ;
          const int64_t v1353 = 0;
          // pto: %631
          ;
          const int64_t v1354 = 128;
          // pto: %631
          ;
          pto::Shape<1, 1, 1, 32, 128> v1355 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %631
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1356 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %631
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1357 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1352 + (v1353 + v1351 * v1354), v1355, v1356);
          TLOAD(v1341, v1357);
        };
        // pto: %641
        ;
        int64_t v1358 = (int64_t) ((uint64_t) v979 + (uint64_t) v31);
        // pto: %642
        ;
        const int64_t v1359 = 1;
        // pto: %642
        ;
        const int64_t v1360 = 0;
        // pto: %642
        ;
        int64_t v1361 = v1358 / v64;
        // pto: %642
        ;
        bool v1362 = v1358 < v1360;
        // pto: %642
        ;
        bool v1363 = v64 < v1360;
        // pto: %642
        ;
        bool v1364 = v1362 == v1363;
        // pto: %642
        ;
        bool v1365 = v1358 % v64 != v1360 && v1362 != v1363;
        // pto: %642
        ;
        int64_t v1366 = v1365 ? v1361 - v1359 : v1361;
        // pto: %646
        ;
        int64_t v1367 = v1366 < v310 ? v1366 : v310;
        // pto: %649, %647
        ;
        int32_t v1368 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v1367)];
        // pto: %650
        ;
        int64_t v1369 = (int64_t) v1368;
        // pto: %651
        ;
        int64_t v1370 = v1369 < v50 ? v50 : v1369;
        // pto: %652
        ;
        int64_t v1371 = (int64_t) ((uint64_t) v1370 * (uint64_t) v17);
        // pto: %653
        ;
        int64_t v1372 = v1371 % v45;
        // pto: %654, %655, %656
        ;
        int64_t v1373 = v1372 < v50 ? (int64_t) ((uint64_t) v1372 + (uint64_t) v45) : v1372;
        // pto: %657
        ;
        if (v1373 == v50) {
          // pto: %658
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1374;
          // pto: %658
          ;
          uint64_t v1375 = (uint64_t) v36;
          TASSIGN(v1374, v1375);
          // pto: %659
          ;
          const int64_t v1376 = 1;
          // pto: %659
          ;
          const int64_t v1377 = 0;
          // pto: %659
          ;
          int64_t v1378 = v1371 / v45;
          // pto: %659
          ;
          bool v1379 = v1371 < v1377;
          // pto: %659
          ;
          bool v1380 = v45 < v1377;
          // pto: %659
          ;
          bool v1381 = v1379 == v1380;
          // pto: %659
          ;
          bool v1382 = v1371 % v45 != v1377 && v1379 != v1380;
          // pto: %659
          ;
          int64_t v1383 = v1382 ? v1378 - v1376 : v1378;
          // pto: %660
          ;
          int64_t v1384 = v1383 < v50 ? v50 : v1383;
          // pto: %661
          ;
          __gm__ int8_t* v1385 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %661
          ;
          const int64_t v1386 = 0;
          // pto: %661
          ;
          const int64_t v1387 = 128;
          // pto: %661
          ;
          pto::Shape<1, 1, 1, 32, 128> v1388 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %661
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1389 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %661
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1390 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1385 + (v1386 + v1384 * v1387), v1388, v1389);
          TLOAD(v1374, v1390);
        } else {
          // pto: %662
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1391;
          // pto: %662
          ;
          uint64_t v1392 = (uint64_t) v36;
          TASSIGN(v1391, v1392);
          // pto: %663
          ;
          const int64_t v1393 = 1;
          // pto: %663
          ;
          const int64_t v1394 = 0;
          // pto: %663
          ;
          int64_t v1395 = v1371 / v45;
          // pto: %663
          ;
          bool v1396 = v1371 < v1394;
          // pto: %663
          ;
          bool v1397 = v45 < v1394;
          // pto: %663
          ;
          bool v1398 = v1396 == v1397;
          // pto: %663
          ;
          bool v1399 = v1371 % v45 != v1394 && v1396 != v1397;
          // pto: %663
          ;
          int64_t v1400 = v1399 ? v1395 - v1393 : v1395;
          // pto: %664
          ;
          int64_t v1401 = v1400 < v50 ? v50 : v1400;
          // pto: %665
          ;
          __gm__ int8_t* v1402 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %665
          ;
          const int64_t v1403 = 0;
          // pto: %665
          ;
          const int64_t v1404 = 128;
          // pto: %665
          ;
          pto::Shape<1, 1, 1, 32, 128> v1405 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %665
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1406 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %665
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1407 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1402 + (v1403 + v1401 * v1404), v1405, v1406);
          TLOAD(v1391, v1407);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
        // pto: %t__tmp_v788
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1408 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %t__tmp_v788
        ;
        uint64_t v1409 = (uint64_t) v39;
        TASSIGN(v1408, v1409);
        // pto: %buf_prefetched_key_inline6782__ssa_v23
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1410 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_prefetched_key_inline6782__ssa_v23
        ;
        uint64_t v1411 = (uint64_t) v39;
        TASSIGN(v1410, v1411);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
        TMOV(v1410, v1408);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        // pto: %buf_key_panel_inline6800__ssa_v13
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1412 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_key_panel_inline6800__ssa_v13
        ;
        uint64_t v1413 = (uint64_t) v39;
        TASSIGN(v1412, v1413);
        // pto: %buf_scores_l1_inline6801__ssa_v16
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1414 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_l1_inline6801__ssa_v16
        ;
        uint64_t v1415 = (uint64_t) v39;
        TASSIGN(v1414, v1415);
        // pto: %buf_previous_pair_inline6802__ssa_v4
        ;
        Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1416 = Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_previous_pair_inline6802__ssa_v4
        ;
        uint64_t v1417 = (uint64_t) v41;
        TASSIGN(v1416, v1417);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID3);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        uint16_t v1418 = static_cast<uint16_t>(v50);
        uint16_t v1419 = static_cast<uint16_t>(v50);
        TEXTRACT(v1416, v1204, v1418, v1419);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline6803__ssa_v12
        ;
        Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1420 = Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_inline6803__ssa_v12
        ;
        uint64_t v1421 = (uint64_t) v39;
        TASSIGN(v1420, v1421);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
        TMATMUL(v1420, v281, v1412);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID7);
        // pto: %buf_reduced_pair_inline6804__ssa_v4
        ;
        Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1422 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v62, v45);
        // pto: %buf_reduced_pair_inline6804__ssa_v4
        ;
        uint64_t v1423 = (uint64_t) v42;
        TASSIGN(v1422, v1423);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
        TMATMUL(v1422, v283, v1416);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID7);
        uint64_t v1424 = static_cast<uint64_t>(v65);
        uint16_t v1425 = static_cast<uint16_t>(v50);
        uint16_t v1426 = static_cast<uint16_t>(v50);
        TINSERT<Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1414, v1420, v1424, v1425, v1426);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID4);
        v1422.SetValidShape(v63, v45);
        // pto: %669
        ;
        __gm__ float* v1427 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %669
        ;
        const int64_t v1428 = 384;
        // pto: %669
        ;
        const int64_t v1429 = 768;
        // pto: %669
        ;
        pto::Shape<1, 1, 1, 2, 128> v1430 = pto::Shape<1, 1, 1, 2, 128>();
        // pto: %669
        ;
        pto::Stride<1536, 1536, 1536, 768, 1> v1431 = pto::Stride<1536, 1536, 1536, 768, 1>();
        // pto: %669
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND> v1432 = GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND>(v1427 + (v1428 + v739 * v1429), v1430, v1431);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        TSTORE(v1432, v1422);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline6780__ssa_v5
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1433 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_previous_l1_inline6780__ssa_v5
        ;
        uint64_t v1434 = (uint64_t) v39;
        TASSIGN(v1433, v1434);
        // pto: %buf_panel_keys_inline6794__ssa_v105
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1435 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_panel_keys_inline6794__ssa_v105
        ;
        uint64_t v1436 = (uint64_t) v40;
        TASSIGN(v1435, v1436);
        // pto: %678
        ;
        int64_t v1437 = (int64_t) ((uint64_t) v979 + (uint64_t) v66);
        // pto: %679
        ;
        const int64_t v1438 = 1;
        // pto: %679
        ;
        const int64_t v1439 = 0;
        // pto: %679
        ;
        int64_t v1440 = v1437 / v64;
        // pto: %679
        ;
        bool v1441 = v1437 < v1439;
        // pto: %679
        ;
        bool v1442 = v64 < v1439;
        // pto: %679
        ;
        bool v1443 = v1441 == v1442;
        // pto: %679
        ;
        bool v1444 = v1437 % v64 != v1439 && v1441 != v1442;
        // pto: %679
        ;
        int64_t v1445 = v1444 ? v1440 - v1438 : v1440;
        // pto: %683
        ;
        int64_t v1446 = v1445 < v310 ? v1445 : v310;
        // pto: %686, %684
        ;
        int32_t v1447 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v1446)];
        // pto: %687
        ;
        int64_t v1448 = (int64_t) v1447;
        // pto: %688
        ;
        int64_t v1449 = v1448 < v50 ? v50 : v1448;
        // pto: %689
        ;
        int64_t v1450 = (int64_t) ((uint64_t) v1449 * (uint64_t) v17);
        // pto: %690
        ;
        int64_t v1451 = v1450 % v45;
        // pto: %691, %692, %693
        ;
        int64_t v1452 = v1451 < v50 ? (int64_t) ((uint64_t) v1451 + (uint64_t) v45) : v1451;
        // pto: %694
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
        if (v1452 == v50) {
          // pto: %695
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1453;
          // pto: %695
          ;
          uint64_t v1454 = (uint64_t) v40;
          TASSIGN(v1453, v1454);
          // pto: %696
          ;
          const int64_t v1455 = 1;
          // pto: %696
          ;
          const int64_t v1456 = 0;
          // pto: %696
          ;
          int64_t v1457 = v1450 / v45;
          // pto: %696
          ;
          bool v1458 = v1450 < v1456;
          // pto: %696
          ;
          bool v1459 = v45 < v1456;
          // pto: %696
          ;
          bool v1460 = v1458 == v1459;
          // pto: %696
          ;
          bool v1461 = v1450 % v45 != v1456 && v1458 != v1459;
          // pto: %696
          ;
          int64_t v1462 = v1461 ? v1457 - v1455 : v1457;
          // pto: %697
          ;
          int64_t v1463 = v1462 < v50 ? v50 : v1462;
          // pto: %698
          ;
          __gm__ int8_t* v1464 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %698
          ;
          const int64_t v1465 = 0;
          // pto: %698
          ;
          const int64_t v1466 = 128;
          // pto: %698
          ;
          pto::Shape<1, 1, 1, 32, 128> v1467 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %698
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1468 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %698
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1469 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1464 + (v1465 + v1463 * v1466), v1467, v1468);
          TLOAD(v1453, v1469);
        } else {
          // pto: %699
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1470;
          // pto: %699
          ;
          uint64_t v1471 = (uint64_t) v40;
          TASSIGN(v1470, v1471);
          // pto: %700
          ;
          const int64_t v1472 = 1;
          // pto: %700
          ;
          const int64_t v1473 = 0;
          // pto: %700
          ;
          int64_t v1474 = v1450 / v45;
          // pto: %700
          ;
          bool v1475 = v1450 < v1473;
          // pto: %700
          ;
          bool v1476 = v45 < v1473;
          // pto: %700
          ;
          bool v1477 = v1475 == v1476;
          // pto: %700
          ;
          bool v1478 = v1450 % v45 != v1473 && v1475 != v1476;
          // pto: %700
          ;
          int64_t v1479 = v1478 ? v1474 - v1472 : v1474;
          // pto: %701
          ;
          int64_t v1480 = v1479 < v50 ? v50 : v1479;
          // pto: %702
          ;
          __gm__ int8_t* v1481 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %702
          ;
          const int64_t v1482 = 0;
          // pto: %702
          ;
          const int64_t v1483 = 128;
          // pto: %702
          ;
          pto::Shape<1, 1, 1, 32, 128> v1484 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %702
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1485 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %702
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1486 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1481 + (v1482 + v1480 * v1483), v1484, v1485);
          TLOAD(v1470, v1486);
        };
        // pto: %712
        ;
        int64_t v1487 = (int64_t) ((uint64_t) v979 + (uint64_t) v29);
        // pto: %713
        ;
        const int64_t v1488 = 1;
        // pto: %713
        ;
        const int64_t v1489 = 0;
        // pto: %713
        ;
        int64_t v1490 = v1487 / v64;
        // pto: %713
        ;
        bool v1491 = v1487 < v1489;
        // pto: %713
        ;
        bool v1492 = v64 < v1489;
        // pto: %713
        ;
        bool v1493 = v1491 == v1492;
        // pto: %713
        ;
        bool v1494 = v1487 % v64 != v1489 && v1491 != v1492;
        // pto: %713
        ;
        int64_t v1495 = v1494 ? v1490 - v1488 : v1490;
        // pto: %717
        ;
        int64_t v1496 = v1495 < v310 ? v1495 : v310;
        // pto: %720, %718
        ;
        int32_t v1497 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v1496)];
        // pto: %721
        ;
        int64_t v1498 = (int64_t) v1497;
        // pto: %722
        ;
        int64_t v1499 = v1498 < v50 ? v50 : v1498;
        // pto: %723
        ;
        int64_t v1500 = (int64_t) ((uint64_t) v1499 * (uint64_t) v17);
        // pto: %724
        ;
        int64_t v1501 = v1500 % v45;
        // pto: %725, %726, %727
        ;
        int64_t v1502 = v1501 < v50 ? (int64_t) ((uint64_t) v1501 + (uint64_t) v45) : v1501;
        // pto: %728
        ;
        if (v1502 == v50) {
          // pto: %729
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1503;
          // pto: %729
          ;
          uint64_t v1504 = (uint64_t) v34;
          TASSIGN(v1503, v1504);
          // pto: %730
          ;
          const int64_t v1505 = 1;
          // pto: %730
          ;
          const int64_t v1506 = 0;
          // pto: %730
          ;
          int64_t v1507 = v1500 / v45;
          // pto: %730
          ;
          bool v1508 = v1500 < v1506;
          // pto: %730
          ;
          bool v1509 = v45 < v1506;
          // pto: %730
          ;
          bool v1510 = v1508 == v1509;
          // pto: %730
          ;
          bool v1511 = v1500 % v45 != v1506 && v1508 != v1509;
          // pto: %730
          ;
          int64_t v1512 = v1511 ? v1507 - v1505 : v1507;
          // pto: %731
          ;
          int64_t v1513 = v1512 < v50 ? v50 : v1512;
          // pto: %732
          ;
          __gm__ int8_t* v1514 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %732
          ;
          const int64_t v1515 = 0;
          // pto: %732
          ;
          const int64_t v1516 = 128;
          // pto: %732
          ;
          pto::Shape<1, 1, 1, 32, 128> v1517 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %732
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1518 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %732
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1519 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1514 + (v1515 + v1513 * v1516), v1517, v1518);
          TLOAD(v1503, v1519);
        } else {
          // pto: %733
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1520;
          // pto: %733
          ;
          uint64_t v1521 = (uint64_t) v34;
          TASSIGN(v1520, v1521);
          // pto: %734
          ;
          const int64_t v1522 = 1;
          // pto: %734
          ;
          const int64_t v1523 = 0;
          // pto: %734
          ;
          int64_t v1524 = v1500 / v45;
          // pto: %734
          ;
          bool v1525 = v1500 < v1523;
          // pto: %734
          ;
          bool v1526 = v45 < v1523;
          // pto: %734
          ;
          bool v1527 = v1525 == v1526;
          // pto: %734
          ;
          bool v1528 = v1500 % v45 != v1523 && v1525 != v1526;
          // pto: %734
          ;
          int64_t v1529 = v1528 ? v1524 - v1522 : v1524;
          // pto: %735
          ;
          int64_t v1530 = v1529 < v50 ? v50 : v1529;
          // pto: %736
          ;
          __gm__ int8_t* v1531 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %736
          ;
          const int64_t v1532 = 0;
          // pto: %736
          ;
          const int64_t v1533 = 128;
          // pto: %736
          ;
          pto::Shape<1, 1, 1, 32, 128> v1534 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %736
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1535 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %736
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1536 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1531 + (v1532 + v1530 * v1533), v1534, v1535);
          TLOAD(v1520, v1536);
        };
        // pto: %746
        ;
        int64_t v1537 = (int64_t) ((uint64_t) v979 + (uint64_t) v28);
        // pto: %747
        ;
        const int64_t v1538 = 1;
        // pto: %747
        ;
        const int64_t v1539 = 0;
        // pto: %747
        ;
        int64_t v1540 = v1537 / v64;
        // pto: %747
        ;
        bool v1541 = v1537 < v1539;
        // pto: %747
        ;
        bool v1542 = v64 < v1539;
        // pto: %747
        ;
        bool v1543 = v1541 == v1542;
        // pto: %747
        ;
        bool v1544 = v1537 % v64 != v1539 && v1541 != v1542;
        // pto: %747
        ;
        int64_t v1545 = v1544 ? v1540 - v1538 : v1540;
        // pto: %751
        ;
        int64_t v1546 = v1545 < v310 ? v1545 : v310;
        // pto: %754, %752
        ;
        int32_t v1547 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v1546)];
        // pto: %755
        ;
        int64_t v1548 = (int64_t) v1547;
        // pto: %756
        ;
        int64_t v1549 = v1548 < v50 ? v50 : v1548;
        // pto: %757
        ;
        int64_t v1550 = (int64_t) ((uint64_t) v1549 * (uint64_t) v17);
        // pto: %758
        ;
        int64_t v1551 = v1550 % v45;
        // pto: %759, %760, %761
        ;
        int64_t v1552 = v1551 < v50 ? (int64_t) ((uint64_t) v1551 + (uint64_t) v45) : v1551;
        // pto: %762
        ;
        if (v1552 == v50) {
          // pto: %763
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1553;
          // pto: %763
          ;
          uint64_t v1554 = (uint64_t) v32;
          TASSIGN(v1553, v1554);
          // pto: %764
          ;
          const int64_t v1555 = 1;
          // pto: %764
          ;
          const int64_t v1556 = 0;
          // pto: %764
          ;
          int64_t v1557 = v1550 / v45;
          // pto: %764
          ;
          bool v1558 = v1550 < v1556;
          // pto: %764
          ;
          bool v1559 = v45 < v1556;
          // pto: %764
          ;
          bool v1560 = v1558 == v1559;
          // pto: %764
          ;
          bool v1561 = v1550 % v45 != v1556 && v1558 != v1559;
          // pto: %764
          ;
          int64_t v1562 = v1561 ? v1557 - v1555 : v1557;
          // pto: %765
          ;
          int64_t v1563 = v1562 < v50 ? v50 : v1562;
          // pto: %766
          ;
          __gm__ int8_t* v1564 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %766
          ;
          const int64_t v1565 = 0;
          // pto: %766
          ;
          const int64_t v1566 = 128;
          // pto: %766
          ;
          pto::Shape<1, 1, 1, 32, 128> v1567 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %766
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1568 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %766
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1569 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1564 + (v1565 + v1563 * v1566), v1567, v1568);
          TLOAD(v1553, v1569);
        } else {
          // pto: %767
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1570;
          // pto: %767
          ;
          uint64_t v1571 = (uint64_t) v32;
          TASSIGN(v1570, v1571);
          // pto: %768
          ;
          const int64_t v1572 = 1;
          // pto: %768
          ;
          const int64_t v1573 = 0;
          // pto: %768
          ;
          int64_t v1574 = v1550 / v45;
          // pto: %768
          ;
          bool v1575 = v1550 < v1573;
          // pto: %768
          ;
          bool v1576 = v45 < v1573;
          // pto: %768
          ;
          bool v1577 = v1575 == v1576;
          // pto: %768
          ;
          bool v1578 = v1550 % v45 != v1573 && v1575 != v1576;
          // pto: %768
          ;
          int64_t v1579 = v1578 ? v1574 - v1572 : v1574;
          // pto: %769
          ;
          int64_t v1580 = v1579 < v50 ? v50 : v1579;
          // pto: %770
          ;
          __gm__ int8_t* v1581 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %770
          ;
          const int64_t v1582 = 0;
          // pto: %770
          ;
          const int64_t v1583 = 128;
          // pto: %770
          ;
          pto::Shape<1, 1, 1, 32, 128> v1584 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %770
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1585 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %770
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1586 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1581 + (v1582 + v1580 * v1583), v1584, v1585);
          TLOAD(v1570, v1586);
        };
        // pto: %780
        ;
        int64_t v1587 = (int64_t) ((uint64_t) v979 + (uint64_t) v27);
        // pto: %781
        ;
        const int64_t v1588 = 1;
        // pto: %781
        ;
        const int64_t v1589 = 0;
        // pto: %781
        ;
        int64_t v1590 = v1587 / v64;
        // pto: %781
        ;
        bool v1591 = v1587 < v1589;
        // pto: %781
        ;
        bool v1592 = v64 < v1589;
        // pto: %781
        ;
        bool v1593 = v1591 == v1592;
        // pto: %781
        ;
        bool v1594 = v1587 % v64 != v1589 && v1591 != v1592;
        // pto: %781
        ;
        int64_t v1595 = v1594 ? v1590 - v1588 : v1590;
        // pto: %785
        ;
        int64_t v1596 = v1595 < v310 ? v1595 : v310;
        // pto: %788, %786
        ;
        int32_t v1597 = (v10)[(int64_t) ((uint64_t) v312 + (uint64_t) v1596)];
        // pto: %789
        ;
        int64_t v1598 = (int64_t) v1597;
        // pto: %790
        ;
        int64_t v1599 = v1598 < v50 ? v50 : v1598;
        // pto: %791
        ;
        int64_t v1600 = (int64_t) ((uint64_t) v1599 * (uint64_t) v17);
        // pto: %792
        ;
        int64_t v1601 = v1600 % v45;
        // pto: %793, %794, %795
        ;
        int64_t v1602 = v1601 < v50 ? (int64_t) ((uint64_t) v1601 + (uint64_t) v45) : v1601;
        // pto: %796
        ;
        if (v1602 == v50) {
          // pto: %797
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1603;
          // pto: %797
          ;
          uint64_t v1604 = (uint64_t) v30;
          TASSIGN(v1603, v1604);
          // pto: %798
          ;
          const int64_t v1605 = 1;
          // pto: %798
          ;
          const int64_t v1606 = 0;
          // pto: %798
          ;
          int64_t v1607 = v1600 / v45;
          // pto: %798
          ;
          bool v1608 = v1600 < v1606;
          // pto: %798
          ;
          bool v1609 = v45 < v1606;
          // pto: %798
          ;
          bool v1610 = v1608 == v1609;
          // pto: %798
          ;
          bool v1611 = v1600 % v45 != v1606 && v1608 != v1609;
          // pto: %798
          ;
          int64_t v1612 = v1611 ? v1607 - v1605 : v1607;
          // pto: %799
          ;
          int64_t v1613 = v1612 < v50 ? v50 : v1612;
          // pto: %800
          ;
          __gm__ int8_t* v1614 = PTOAS__GLOBAL_TENSOR_DATA(v91);
          // pto: %800
          ;
          const int64_t v1615 = 0;
          // pto: %800
          ;
          const int64_t v1616 = 128;
          // pto: %800
          ;
          pto::Shape<1, 1, 1, 32, 128> v1617 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %800
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1618 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %800
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1619 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1614 + (v1615 + v1613 * v1616), v1617, v1618);
          TLOAD(v1603, v1619);
        } else {
          // pto: %801
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1620;
          // pto: %801
          ;
          uint64_t v1621 = (uint64_t) v30;
          TASSIGN(v1620, v1621);
          // pto: %802
          ;
          const int64_t v1622 = 1;
          // pto: %802
          ;
          const int64_t v1623 = 0;
          // pto: %802
          ;
          int64_t v1624 = v1600 / v45;
          // pto: %802
          ;
          bool v1625 = v1600 < v1623;
          // pto: %802
          ;
          bool v1626 = v45 < v1623;
          // pto: %802
          ;
          bool v1627 = v1625 == v1626;
          // pto: %802
          ;
          bool v1628 = v1600 % v45 != v1623 && v1625 != v1626;
          // pto: %802
          ;
          int64_t v1629 = v1628 ? v1624 - v1622 : v1624;
          // pto: %803
          ;
          int64_t v1630 = v1629 < v50 ? v50 : v1629;
          // pto: %804
          ;
          __gm__ int8_t* v1631 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %804
          ;
          const int64_t v1632 = 0;
          // pto: %804
          ;
          const int64_t v1633 = 128;
          // pto: %804
          ;
          pto::Shape<1, 1, 1, 32, 128> v1634 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %804
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1635 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %804
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1636 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1631 + (v1632 + v1630 * v1633), v1634, v1635);
          TLOAD(v1620, v1636);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
        // pto: %t__tmp_v794
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1637 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %t__tmp_v794
        ;
        uint64_t v1638 = (uint64_t) v40;
        TASSIGN(v1637, v1638);
        // pto: %buf_prefetched_key_inline6782__ssa_v28
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1639 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_prefetched_key_inline6782__ssa_v28
        ;
        uint64_t v1640 = (uint64_t) v39;
        TASSIGN(v1639, v1640);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        TMOV(v1639, v1637);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_key_panel_inline6800__ssa_v16
        ;
        Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1641 = Tile<TileType::Right, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_key_panel_inline6800__ssa_v16
        ;
        uint64_t v1642 = (uint64_t) v39;
        TASSIGN(v1641, v1642);
        // pto: %buf_scores_l1_inline6801__ssa_v20
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1643 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_l1_inline6801__ssa_v20
        ;
        uint64_t v1644 = (uint64_t) v40;
        TASSIGN(v1643, v1644);
        // pto: %buf_previous_pair_inline6802__ssa_v5
        ;
        Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1645 = Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_previous_pair_inline6802__ssa_v5
        ;
        uint64_t v1646 = (uint64_t) v41;
        TASSIGN(v1645, v1646);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID4);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v1647 = static_cast<uint16_t>(v50);
        uint16_t v1648 = static_cast<uint16_t>(v50);
        TEXTRACT(v1645, v1433, v1647, v1648);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %buf_scores_inline6803__ssa_v15
        ;
        Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1649 = Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_scores_inline6803__ssa_v15
        ;
        uint64_t v1650 = (uint64_t) v39;
        TASSIGN(v1649, v1650);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1649, v281, v1641);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline6804__ssa_v5
        ;
        Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1651 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v62, v45);
        // pto: %buf_reduced_pair_inline6804__ssa_v5
        ;
        uint64_t v1652 = (uint64_t) v42;
        TASSIGN(v1651, v1652);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1651, v283, v1645);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1653 = static_cast<uint64_t>(v65);
        uint16_t v1654 = static_cast<uint16_t>(v50);
        uint16_t v1655 = static_cast<uint16_t>(v50);
        TINSERT<Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1643, v1649, v1653, v1654, v1655);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID5);
        v1651.SetValidShape(v63, v45);
        // pto: %808
        ;
        __gm__ float* v1656 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %808
        ;
        const int64_t v1657 = 512;
        // pto: %808
        ;
        const int64_t v1658 = 768;
        // pto: %808
        ;
        pto::Shape<1, 1, 1, 2, 128> v1659 = pto::Shape<1, 1, 1, 2, 128>();
        // pto: %808
        ;
        pto::Stride<1536, 1536, 1536, 768, 1> v1660 = pto::Stride<1536, 1536, 1536, 768, 1>();
        // pto: %808
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND> v1661 = GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND>(v1656 + (v1657 + v739 * v1658), v1659, v1660);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1661, v1651);
        // pto: %buf_previous_l1_inline6780__ssa_v6
        ;
        Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1662 = Tile<TileType::Mat, half, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_previous_l1_inline6780__ssa_v6
        ;
        uint64_t v1663 = (uint64_t) v40;
        TASSIGN(v1662, v1663);
        // pto: %buf_last_pair_inline6805__ssa_v0
        ;
        Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1664 = Tile<TileType::Right, half, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v45, v45);
        // pto: %buf_last_pair_inline6805__ssa_v0
        ;
        uint64_t v1665 = (uint64_t) v41;
        TASSIGN(v1664, v1665);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID5);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1666 = static_cast<uint16_t>(v50);
        uint16_t v1667 = static_cast<uint16_t>(v50);
        TEXTRACT(v1664, v1662, v1666, v1667);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_last_scores_inline6806__ssa_v0
        ;
        Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1668 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v62, v45);
        // pto: %buf_last_scores_inline6806__ssa_v0
        ;
        uint64_t v1669 = (uint64_t) v39;
        TASSIGN(v1668, v1669);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        TMATMUL(v1668, v283, v1664);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        v1668.SetValidShape(v63, v45);
        // pto: %810
        ;
        __gm__ float* v1670 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %810
        ;
        const int64_t v1671 = 640;
        // pto: %810
        ;
        const int64_t v1672 = 768;
        // pto: %810
        ;
        pto::Shape<1, 1, 1, 2, 128> v1673 = pto::Shape<1, 1, 1, 2, 128>();
        // pto: %810
        ;
        pto::Stride<1536, 1536, 1536, 768, 1> v1674 = pto::Stride<1536, 1536, 1536, 768, 1>();
        // pto: %810
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND> v1675 = GlobalTensor<float, pto::Shape<1, 1, 1, 2, 128>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND>(v1670 + (v1671 + v739 * v1672), v1673, v1674);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        pipe_barrier(PIPE_FIX);
        TSTORE(v1675, v1668);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        uint16_t v1676 = getFFTSMsg(FFTS_MODE_VAL, v50);
        ffts_cross_core_sync(PIPE_FIX, v1676);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      // pto: %811
      ;
      for (int64_t v1677 = v50; v1677 < (v259 < v63 ? v259 : v63); v1677 += v43) {
        int32_t v1678 = (int32_t) v43;
        wait_flag_dev(v1678);
      };
    };
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void indexer_score_topk_native_pair_2_aiv(__gm__ int32_t* v1, __gm__ int32_t* v2, __gm__ int64_t* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, __gm__ int64_t* v7, __gm__ int8_t* v8, __gm__ half* v9, __gm__ int32_t* v10, __gm__ int8_t* v11, __gm__ int8_t* v12, __gm__ float* v13, __gm__ int8_t* v14, __gm__ float* v15, __gm__ float* v16, int64_t v17, int64_t v18, int64_t v19, int64_t v20, int64_t v21, int64_t v22, int64_t v23, int64_t v24, int32_t v25, int32_t v26, int32_t v27) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  pto::MrgSortExecutedNumList v28 = pto::MrgSortExecutedNumList{0, 0, 0, 0};
  // pto: %c28672_i64
  const int64_t v29 = 28672;
  // pto: %c61440_i64
  const int64_t v30 = 61440;
  // pto: %c12288_i64
  const int64_t v31 = 12288;
  const int64_t v32 = 30208;
  const int64_t v33 = 32768;
  const int64_t v34 = 45056;
  // pto: %c0_i64
  const int64_t v35 = 0;
  const int64_t v36 = 49152;
  const int64_t v37 = 77824;
  // pto: %c1_index
  const int64_t v38 = 1;
  // pto: %c432_index
  const int64_t v39 = 432;
  // pto: %c27648_index
  const int64_t v40 = 27648;
  // pto: %c96_index
  const int64_t v41 = 96;
  // pto: %c768_index
  const int64_t v42 = 768;
  // pto: %c8192_index
  const int64_t v43 = 8192;
  // pto: %c1024_index
  const int64_t v44 = 1024;
  // pto: %c0_index
  const int64_t v45 = 0;
  // pto: %c4_index
  const int64_t v46 = 4;
  // pto: %c262144_index
  const int64_t v47 = 262144;
  // pto: %c8191_index
  const int64_t v48 = 8191;
  // pto: %c24_index
  const int64_t v49 = 24;
  // pto: %c1_i64
  const int64_t v50 = 1;
  // pto: %c4_i64
  const int64_t v51 = 4;
  // pto: %c767_index
  const int64_t v52 = 767;
  // pto: %c384_index
  const int64_t v53 = 384;
  // pto: %c4096_index
  const int64_t v54 = 4096;
  // pto: %c383_index
  const int64_t v55 = 383;
  // pto: %c2_index
  const int64_t v56 = 2;
  // pto: %c12_index
  const int64_t v57 = 12;
  // pto: %c32_index
  const int64_t v58 = 32;
  // pto: %c64_index
  const int64_t v59 = 64;
  // pto: %c512_index
  const int64_t v60 = 512;
  // pto: %c192_index
  const int64_t v61 = 192;
  // pto: %c0_i32
  const int32_t v62 = 0;
  // pto: %cst_36
  const float v63 = -3.40282347E+38f;
  // pto: %c64_i32
  const int32_t v64 = 64;
  // pto: %c256_i32
  const int32_t v65 = 256;
  // pto: %c2048_index
  const int64_t v66 = 2048;
  // pto: %c1024_i32
  const int32_t v67 = 1024;
  // pto: %c2560_index
  const int64_t v68 = 2560;
  // pto: %c5120_index
  const int64_t v69 = 5120;
  // pto: %c3072_index
  const int64_t v70 = 3072;
  // pto: %c6144_index
  const int64_t v71 = 6144;
  // pto: %buf_score_transfer_inline6746__ssa_v0_view
  const int64_t v72 = 1;
  // pto: %buf_score_transfer_inline6746__ssa_v0_view
  const int64_t v73 = 1;
  // pto: %buf_score_transfer_inline6746__ssa_v0_view
  const int64_t v74 = 1;
  // pto: %buf_score_transfer_inline6746__ssa_v0_view
  int64_t v75 = v41 * v42;
  // pto: %buf_score_transfer_inline6746__ssa_v0_view
  int64_t v76 = v74 * v75;
  // pto: %buf_score_transfer_inline6746__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v77 = pto::Shape<1, 1, 1, -1, -1>(v72, v73, v74, v41, v42);
  // pto: %buf_score_transfer_inline6746__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v78 = pto::Stride<-1, -1, -1, -1, -1>(v73 * v76, v76, v75, v42, v38);
  // pto: %buf_score_transfer_inline6746__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v79 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v77, v78);
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v80 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v81 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v82 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v83 = (int64_t) v23;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v84 = (int64_t) v24;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v85 = v83 * v84;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v86 = v82 * v85;
  // pto: %idx_native_kv_cache__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v87 = pto::Shape<1, 1, 1, -1, -1>(v80, v81, v82, v83, (int64_t) v24);
  // pto: %idx_native_kv_cache__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v88 = pto::Stride<-1, -1, -1, -1, -1>(v81 * v86, v86, v85, v84, v38);
  // pto: %idx_native_kv_cache__rv_v2_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v89 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v87, v88);
  // pto: %score_arena_inline5766__ssa_v0_view
  const int64_t v90 = 1;
  // pto: %score_arena_inline5766__ssa_v0_view
  const int64_t v91 = 1;
  // pto: %score_arena_inline5766__ssa_v0_view
  const int64_t v92 = 1;
  // pto: %score_arena_inline5766__ssa_v0_view
  int64_t v93 = v39 * v43;
  // pto: %score_arena_inline5766__ssa_v0_view
  int64_t v94 = v92 * v93;
  // pto: %score_arena_inline5766__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v95 = pto::Shape<1, 1, 1, -1, -1>(v90, v91, v92, v39, v43);
  // pto: %score_arena_inline5766__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v96 = pto::Stride<-1, -1, -1, -1, -1>(v91 * v94, v94, v93, v43, v38);
  // pto: %score_arena_inline5766__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v97 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v95, v96);
  // pto: %pair_arena_inline5765__ssa_v0_view
  const int64_t v98 = 1;
  // pto: %pair_arena_inline5765__ssa_v0_view
  const int64_t v99 = 1;
  // pto: %pair_arena_inline5765__ssa_v0_view
  const int64_t v100 = 1;
  // pto: %pair_arena_inline5765__ssa_v0_view
  int64_t v101 = v40 * v44;
  // pto: %pair_arena_inline5765__ssa_v0_view
  int64_t v102 = v100 * v101;
  // pto: %pair_arena_inline5765__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v103 = pto::Shape<1, 1, 1, -1, -1>(v98, v99, v100, v40, v44);
  // pto: %pair_arena_inline5765__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v104 = pto::Stride<-1, -1, -1, -1, -1>(v99 * v102, v102, v101, v44, v38);
  // pto: %pair_arena_inline5765__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v105 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v103, v104);
  // pto: %buf_worker_inline6749__ssa_v0
  int64_t v106 = (int64_t) v25;
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  // pto: %buf_max_cache_len_inline6750__rv_v2
  int64_t v107;
  v107 = v45;
  for (int64_t v108 = v45; v108 < v18; v108 += v38) {
    // pto: %t__tile
    ;
    int32_t v109 = (v1)[v108];
    // pto: %0
    ;
    int64_t v110 = (int64_t) v109;
    // pto: %1
    ;
    const int64_t v111 = 1;
    // pto: %1
    ;
    const int64_t v112 = 0;
    // pto: %1
    ;
    int64_t v113 = v110 / v46;
    // pto: %1
    ;
    bool v114 = v110 < v112;
    // pto: %1
    ;
    bool v115 = v46 < v112;
    // pto: %1
    ;
    bool v116 = v114 == v115;
    // pto: %1
    ;
    bool v117 = v110 % v46 != v112 && v114 != v115;
    // pto: %1
    ;
    int64_t v118 = v117 ? v113 - v111 : v113;
    // pto: %2
    ;
    bool v119 = v107 < v118;
    // pto: %2
    ;
    int64_t v120 = v119 ? v118 : v107;
    v107 = v120;
  }
  // pto: %3
  bool v121 = v107 < v47;
  // pto: %3
  int64_t v122 = v121 ? v107 : v47;
  // pto: %4
  int64_t v123 = (int64_t) ((uint64_t) v122 + (uint64_t) v48);
  // pto: %5
  const int64_t v124 = 1;
  // pto: %5
  const int64_t v125 = 0;
  // pto: %5
  int64_t v126 = v123 / v43;
  // pto: %5
  bool v127 = v123 < v125;
  // pto: %5
  bool v128 = v43 < v125;
  // pto: %5
  bool v129 = v127 == v128;
  // pto: %5
  bool v130 = v123 % v43 != v125 && v127 != v128;
  // pto: %5
  int64_t v131 = v130 ? v126 - v124 : v126;
  // pto: %6
  int64_t v132 = v131 < v38 ? v38 : v131;
  // pto: %7
  int32_t v133 = (v2)[v45];
  // pto: %8
  int64_t v134 = (int64_t) v133;
  uint64_t v135 = reinterpret_cast<uint64_t>(v3);
  set_ffts_base_addr(v135);
  // pto: %buf_score_lane_inline6808__ssa_v0
  int64_t v136 = (int64_t) v27;
  // pto: %9
  for (int64_t v137 = v106; v137 < ((int64_t) ((uint64_t) v134 * (uint64_t) v132)); v137 += v49) {
    // pto: %10
    ;
    // pto: %buf_group_inline6759__phi_v5
    ;
    int64_t v138;
    // pto: %buf_leaf_inline6760__phi_v5
    ;
    int64_t v139;
    if (v134 < v49) {
      // pto: %11
      ;
      int64_t v140 = v137 % v134;
      // pto: %12, %13, %14
      ;
      bool v141 = v140 < v45 ^ v134 < v45;
      // pto: %15, %16, %17, %18
      ;
      // pto: %19
      ;
      const int64_t v142 = 1;
      // pto: %19
      ;
      const int64_t v143 = 0;
      // pto: %19
      ;
      int64_t v144 = v137 / v134;
      // pto: %19
      ;
      bool v145 = v137 < v143;
      // pto: %19
      ;
      bool v146 = v134 < v143;
      // pto: %19
      ;
      bool v147 = v145 == v146;
      // pto: %19
      ;
      bool v148 = v137 % v134 != v143 && v145 != v146;
      // pto: %19
      ;
      v138 = v140 != v45 & v141 ? (int64_t) ((uint64_t) v140 + (uint64_t) v134) : v140;
      v139 = v148 ? v144 - v142 : v144;
    } else {
      // pto: %20
      ;
      const int64_t v149 = 1;
      // pto: %20
      ;
      const int64_t v150 = 0;
      // pto: %20
      ;
      int64_t v151 = v137 / v132;
      // pto: %20
      ;
      bool v152 = v137 < v150;
      // pto: %20
      ;
      bool v153 = v132 < v150;
      // pto: %20
      ;
      bool v154 = v152 == v153;
      // pto: %20
      ;
      bool v155 = v137 % v132 != v150 && v152 != v153;
      // pto: %20
      ;
      // pto: %21
      ;
      int64_t v156 = v137 % v132;
      // pto: %22, %23, %24
      ;
      bool v157 = v156 < v45 ^ v132 < v45;
      // pto: %25, %26, %27, %28
      ;
      v138 = v155 ? v151 - v149 : v151;
      v139 = v156 != v45 & v157 ? (int64_t) ((uint64_t) v156 + (uint64_t) v132) : v156;
    };
    // pto: %29
    ;
    int32_t v158 = (v4)[v138];
    // pto: %30
    ;
    int64_t v159 = (int64_t) v158;
    // pto: %31
    ;
    int32_t v160 = (v5)[v138];
    // pto: %32
    ;
    int64_t v161 = (int64_t) v160;
    // pto: %33
    ;
    int32_t v162 = (v6)[v159];
    // pto: %34
    ;
    int64_t v163 = (int64_t) v162;
    // pto: %35, %36, %buf_last_position_inline6764__tile
    ;
    int64_t v164 = (v7)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v159 + (uint64_t) v161) - (uint64_t) v38)];
    // pto: %37
    ;
    int32_t v165 = (v1)[v163];
    // pto: %38
    ;
    int64_t v166 = (int64_t) v165;
    // pto: %39
    ;
    const int64_t v167 = 1;
    // pto: %39
    ;
    const int64_t v168 = 0;
    // pto: %39
    ;
    int64_t v169 = v166 / v46;
    // pto: %39
    ;
    bool v170 = v166 < v168;
    // pto: %39
    ;
    bool v171 = v46 < v168;
    // pto: %39
    ;
    bool v172 = v170 == v171;
    // pto: %39
    ;
    bool v173 = v166 % v46 != v168 && v170 != v171;
    // pto: %39
    ;
    int64_t v174 = v173 ? v169 - v167 : v169;
    // pto: %40
    ;
    int64_t v175 = (int64_t) ((uint64_t) v164 + (uint64_t) v50);
    // pto: %41
    ;
    const int64_t v176 = 1;
    // pto: %41
    ;
    const int64_t v177 = 0;
    // pto: %41
    ;
    int64_t v178 = v175 / v51;
    // pto: %41
    ;
    bool v179 = v175 < v177;
    // pto: %41
    ;
    bool v180 = v51 < v177;
    // pto: %41
    ;
    bool v181 = v179 == v180;
    // pto: %41
    ;
    bool v182 = v175 % v51 != v177 && v179 != v180;
    // pto: %41
    ;
    int64_t v183 = v182 ? v178 - v176 : v178;
    // pto: %43
    ;
    int64_t v184 = v174 < v183 ? v174 : v183;
    // pto: %44
    ;
    int64_t v185 = v184 < v47 ? v184 : v47;
    // pto: %45
    ;
    int64_t v186 = v185 < v45 ? v45 : v185;
    // pto: %46
    ;
    uint64_t v187 = (uint64_t) v139;
    // pto: %46
    ;
    int64_t v188 = (int64_t) (v187 * (uint64_t) v43);
    // pto: %47
    ;
    if (v188 < v186) {
      // pto: %48
      ;
      int64_t v189 = (int64_t) ((uint64_t) v186 - (uint64_t) v188);
      // pto: %49
      ;
      int64_t v190 = v189 < v43 ? v189 : v43;
      // pto: %50
      ;
      int64_t v191 = (int64_t) ((uint64_t) v190 + (uint64_t) v52);
      // pto: %51
      ;
      const int64_t v192 = 1;
      // pto: %51
      ;
      const int64_t v193 = 0;
      // pto: %51
      ;
      int64_t v194 = v191 / v42;
      // pto: %51
      ;
      bool v195 = v191 < v193;
      // pto: %51
      ;
      bool v196 = v42 < v193;
      // pto: %51
      ;
      bool v197 = v195 == v196;
      // pto: %51
      ;
      bool v198 = v191 % v42 != v193 && v195 != v196;
      // pto: %51
      ;
      int64_t v199 = v198 ? v194 - v192 : v194;
      // pto: %52
      ;
      int64_t v200 = (int64_t) ((uint64_t) v199 * (uint64_t) v53);
      // pto: %53
      ;
      int64_t v201 = v200 < v54 ? v200 : v54;
      // pto: %54
      ;
      int64_t v202 = (int64_t) ((uint64_t) v201 + (uint64_t) v55);
      // pto: %55
      ;
      const int64_t v203 = 1;
      // pto: %55
      ;
      const int64_t v204 = 0;
      // pto: %55
      ;
      int64_t v205 = v202 / v53;
      // pto: %55
      ;
      bool v206 = v202 < v204;
      // pto: %55
      ;
      bool v207 = v53 < v204;
      // pto: %55
      ;
      bool v208 = v206 == v207;
      // pto: %55
      ;
      bool v209 = v202 % v53 != v204 && v206 != v207;
      // pto: %55
      ;
      // pto: %56
      ;
      int64_t v210 = (int64_t) ((uint64_t) v136 * (uint64_t) v201);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      for (int64_t v211 = v45; v211 < (v209 ? v205 - v203 : v205); v211 += v38) {
        // pto: %57
        ;
        int64_t v212 = (int64_t) ((uint64_t) v211 * (uint64_t) v53);
        // pto: %58
        ;
        int64_t v213 = (int64_t) ((uint64_t) v106 * (uint64_t) v46);
        // pto: %59
        ;
        int64_t v214 = v211 % v56;
        // pto: %60, %61, %62
        ;
        int64_t v215 = v214 < v45 ? (int64_t) ((uint64_t) v214 + (uint64_t) v56) : v214;
        // pto: %64, %63
        ;
        int64_t v216 = (int64_t) ((uint64_t) v213 + (uint64_t) ((int64_t) (uint64_t) v215 * (uint64_t) v56));
        // pto: %buf_scale_bytes_inline6885__ssa_v0
        ;
        Tile<TileType::Vec, int8_t, 1, 768, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Vec, int8_t, 1, 768, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v42);
        // pto: %buf_scale_bytes_inline6885__ssa_v0
        ;
        uint64_t v218 = (uint64_t) v29;
        TASSIGN(v217, v218);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        for (int64_t v219 = v45; v219 < v57; v219 += v38) {
          // pto: %65, %66, %68, %67
          ;
          int64_t v220 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v188 + (uint64_t) v212) + (uint64_t) v210) + (uint64_t) ((int64_t) (uint64_t) v219 * (uint64_t) v58));
          // pto: %69
          ;
          const int64_t v221 = 1;
          // pto: %69
          ;
          const int64_t v222 = 0;
          // pto: %69
          ;
          int64_t v223 = v220 / v58;
          // pto: %69
          ;
          bool v224 = v220 < v222;
          // pto: %69
          ;
          bool v225 = v58 < v222;
          // pto: %69
          ;
          bool v226 = v224 == v225;
          // pto: %69
          ;
          bool v227 = v220 % v58 != v222 && v224 != v225;
          // pto: %69
          ;
          int64_t v228 = v227 ? v223 - v221 : v223;
          // pto: %70
          ;
          int64_t v229 = (int64_t) ((uint64_t) v174 - (uint64_t) v38);
          // pto: %71
          ;
          const int64_t v230 = 1;
          // pto: %71
          ;
          const int64_t v231 = 0;
          // pto: %71
          ;
          int64_t v232 = v229 / v58;
          // pto: %71
          ;
          bool v233 = v229 < v231;
          // pto: %71
          ;
          bool v234 = v58 < v231;
          // pto: %71
          ;
          bool v235 = v233 == v234;
          // pto: %71
          ;
          bool v236 = v229 % v58 != v231 && v233 != v234;
          // pto: %71
          ;
          int64_t v237 = v236 ? v232 - v230 : v232;
          // pto: %72
          ;
          int64_t v238 = v237 < v45 ? v45 : v237;
          // pto: %73
          ;
          int64_t v239 = v228 < v238 ? v228 : v238;
          // pto: %flat_offset_mul, %flat_offset, %74
          ;
          int32_t v240 = (v10)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v163 * (uint64_t) v20) + (uint64_t) v239)];
          // pto: %75
          ;
          int64_t v241 = (int64_t) v240;
          // pto: %76
          ;
          int64_t v242 = v241 < v45 ? v45 : v241;
          // pto: %gather_row_view
          ;
          Tile<TileType::Vec, int8_t, 1, 768, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v243;
          // pto: %77, %gather_row_view
          ;
          uint64_t v244 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v219 * (uint64_t) v59) + (uint64_t) v29);
          TASSIGN(v243, v244);
          // pto: %78
          ;
          int64_t v245 = v242 < v45 ? v45 : v242;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v246 = (int64_t) v24;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v247 = 0;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          __gm__ int8_t* v248 = PTOAS__GLOBAL_TENSOR_DATA(v89);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v249 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v250 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v251 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v252 = v38 * v246;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v253 = v251 * v252;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          pto::Shape<1, 1, 1, 1, 64> v254 = pto::Shape<1, 1, 1, 1, 64>(v249, v250, v251, v38, v59);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v255 = pto::Stride<-1, -1, -1, -1, -1>(v250 * v253, v253, v252, v246, v38);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v256 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v248 + (v247 + v245 * v246 + v54 * v38), v254, v255);
          TLOAD(v243, v256);
        };
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %buf_scale_half_inline6890__ssa_v0
        ;
        Tile<TileType::Vec, half, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v257 = Tile<TileType::Vec, half, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v53);
        // pto: %buf_scale_half_inline6890__ssa_v0
        ;
        uint64_t v258 = (uint64_t) v29;
        TASSIGN(v257, v258);
        // pto: %buf_kv_scale_inline6891__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v259 = Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v53);
        // pto: %buf_kv_scale_inline6891__ssa_v0
        ;
        uint64_t v260 = (uint64_t) v30;
        TASSIGN(v259, v260);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v261 = RoundMode::CAST_ROUND;
        SaturationMode v262 = SaturationMode::ON;
        TCVT(v259, v257, v261, v262);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        int32_t v263 = (int32_t) v45;
        wait_flag_dev(v263);
        // pto: %buf_score_sums_inline6892__ssa_v0
        ;
        Tile<TileType::Vec, float, 2, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v264 = Tile<TileType::Vec, float, 2, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v56, v53);
        // pto: %buf_score_sums_inline6892__ssa_v0
        ;
        uint64_t v265 = (uint64_t) v29;
        TASSIGN(v264, v265);
        // pto: %79
        ;
        int64_t v266 = v216 < v45 ? v45 : v216;
        // pto: %80
        ;
        int64_t v267 = (int64_t) ((uint64_t) v136 * (uint64_t) v53);
        // pto: %81
        ;
        int64_t v268 = v267 < v45 ? v45 : v267;
        // pto: %buf_score_transfer_inline6746__ssa_v0_pview
        ;
        __gm__ float* v269 = PTOAS__GLOBAL_TENSOR_DATA(v79);
        // pto: %buf_score_transfer_inline6746__ssa_v0_pview
        ;
        const int64_t v270 = 0;
        // pto: %buf_score_transfer_inline6746__ssa_v0_pview
        ;
        const int64_t v271 = 768;
        // pto: %buf_score_transfer_inline6746__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 2, 384> v272 = pto::Shape<1, 1, 1, 2, 384>();
        // pto: %buf_score_transfer_inline6746__ssa_v0_pview
        ;
        pto::Stride<1536, 1536, 1536, 768, 1> v273 = pto::Stride<1536, 1536, 1536, 768, 1>();
        // pto: %buf_score_transfer_inline6746__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 2, 384>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND> v274 = GlobalTensor<float, pto::Shape<1, 1, 1, 2, 384>, pto::Stride<1536, 1536, 1536, 768, 1>, pto::Layout::ND>(v269 + (v270 + v266 * v271 + v268), v272, v273);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        TLOAD(v264, v274);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        uint16_t v275 = getFFTSMsg(FFTS_MODE_VAL, v38);
        ffts_cross_core_sync(PIPE_MTE2, v275);
        // pto: %83
        ;
        int64_t v276 = (int64_t) ((uint64_t) v161 - (uint64_t) v38);
        // pto: %84
        ;
        int64_t v277 = v276 < v45 ? v276 : v45;
        // pto: %85, %buf_position_inline6895__tile
        ;
        int64_t v278 = (v7)[(int64_t) ((uint64_t) v159 + (uint64_t) v277)];
        // pto: %86
        ;
        int64_t v279 = (int64_t) ((uint64_t) v278 + (uint64_t) v50);
        // pto: %87
        ;
        const int64_t v280 = 1;
        // pto: %87
        ;
        const int64_t v281 = 0;
        // pto: %87
        ;
        int64_t v282 = v279 / v51;
        // pto: %87
        ;
        bool v283 = v279 < v281;
        // pto: %87
        ;
        bool v284 = v51 < v281;
        // pto: %87
        ;
        bool v285 = v283 == v284;
        // pto: %87
        ;
        bool v286 = v279 % v51 != v281 && v283 != v284;
        // pto: %87
        ;
        int64_t v287 = v286 ? v282 - v280 : v282;
        // pto: %89
        ;
        int64_t v288 = v174 < v287 ? v174 : v287;
        // pto: %90
        ;
        int64_t v289 = v288 < v47 ? v288 : v47;
        // pto: %91
        ;
        int64_t v290 = v289 < v45 ? v45 : v289;
        // pto: %92, %93, %94
        ;
        int64_t v291 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v290 - (uint64_t) v188) - (uint64_t) v212) - (uint64_t) v210);
        // pto: %95
        ;
        int64_t v292 = v291 < v53 ? v291 : v53;
        // pto: %96
        ;
        int64_t v293 = v292 < v45 ? v45 : v292;
        // pto: %97
        ;
        int64_t v294 = (int64_t) ((uint64_t) v201 - (uint64_t) v212);
        // pto: %98
        ;
        int64_t v295 = v294 < v45 ? v45 : v294;
        // pto: %99
        ;
        int64_t v296 = v293 < v295 ? v293 : v295;
        // pto: %buf_score_sum_inline6899__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v297 = Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v53);
        // pto: %buf_score_sum_inline6899__ssa_v0
        ;
        uint64_t v298 = (uint64_t) v29;
        TASSIGN(v297, v298);
        // pto: %slice_view
        ;
        Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, 1, 384, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v299;
        // pto: %slice_view
        ;
        uint64_t v300 = (uint64_t) v29;
        TASSIGN(v299, v300);
        // pto: %buf_score_row_inline6900__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v301 = Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v53);
        // pto: %buf_score_row_inline6900__ssa_v0
        ;
        uint64_t v302 = (uint64_t) v31;
        TASSIGN(v301, v302);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        TMUL(v301, v299, v259);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %101
        ;
        bool v303 = v132 > v38;
        // pto: %100, %buf_store_column_inline6902__phi_v2
        ;
        int64_t v304 = v303 ? v212 : (int64_t) ((uint64_t) v212 + (uint64_t) v210);
        // pto: %buf_store_row_inline6901__phi_v2
        ;
        int64_t v305;
        if (v303) {
          // pto: %103
          ;
          v305 = (int64_t) ((uint64_t) v213 + (uint64_t) v136);
        } else {
          v305 = v159;
        };
        // pto: %104, %82, %105
        ;
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        if (v296 > v45 & v161 > v45) {
          v301.SetValidShape(v38, v296);
          // pto: %106
          ;
          bool v306 = v305 < v45;
          // pto: %106
          ;
          int64_t v307 = v306 ? v45 : v305;
          // pto: %107
          ;
          int64_t v308 = v304 < v45 ? v45 : v304;
          // pto: %score_arena_inline5766__ssa_v0_pview
          ;
          const int64_t v309 = 0;
          // pto: %score_arena_inline5766__ssa_v0_pview
          ;
          __gm__ float* v310 = PTOAS__GLOBAL_TENSOR_DATA(v97);
          // pto: %score_arena_inline5766__ssa_v0_pview
          ;
          const int64_t v311 = 1;
          // pto: %score_arena_inline5766__ssa_v0_pview
          ;
          const int64_t v312 = 1;
          // pto: %score_arena_inline5766__ssa_v0_pview
          ;
          const int64_t v313 = 1;
          // pto: %score_arena_inline5766__ssa_v0_pview
          ;
          int64_t v314 = v38 * v43;
          // pto: %score_arena_inline5766__ssa_v0_pview
          ;
          int64_t v315 = v313 * v314;
          // pto: %score_arena_inline5766__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 1, -1> v316 = pto::Shape<1, 1, 1, 1, -1>(v311, v312, v313, v38, v296);
          // pto: %score_arena_inline5766__ssa_v0_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v317 = pto::Stride<-1, -1, -1, -1, -1>(v312 * v315, v315, v314, v43, v38);
          // pto: %score_arena_inline5766__ssa_v0_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v318 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v310 + (v309 + v307 * v43 + v308 * v38), v316, v317);
          TSTORE(v318, v301);
        };
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        // pto: %111
        ;
        int64_t v319 = v276 < v38 ? v276 : v38;
        // pto: %112, %109
        ;
        int64_t v320 = (v7)[(int64_t) ((uint64_t) v159 + (uint64_t) v319)];
        // pto: %113
        ;
        int64_t v321 = (int64_t) ((uint64_t) v320 + (uint64_t) v50);
        // pto: %114
        ;
        const int64_t v322 = 1;
        // pto: %114
        ;
        const int64_t v323 = 0;
        // pto: %114
        ;
        int64_t v324 = v321 / v51;
        // pto: %114
        ;
        bool v325 = v321 < v323;
        // pto: %114
        ;
        bool v326 = v51 < v323;
        // pto: %114
        ;
        bool v327 = v325 == v326;
        // pto: %114
        ;
        bool v328 = v321 % v51 != v323 && v325 != v326;
        // pto: %114
        ;
        int64_t v329 = v328 ? v324 - v322 : v324;
        // pto: %116
        ;
        int64_t v330 = v174 < v329 ? v174 : v329;
        // pto: %117
        ;
        int64_t v331 = v330 < v47 ? v330 : v47;
        // pto: %118
        ;
        int64_t v332 = v331 < v45 ? v45 : v331;
        // pto: %119, %120, %121
        ;
        int64_t v333 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v332 - (uint64_t) v188) - (uint64_t) v212) - (uint64_t) v210);
        // pto: %122
        ;
        int64_t v334 = v333 < v53 ? v333 : v53;
        // pto: %123
        ;
        int64_t v335 = v334 < v45 ? v45 : v334;
        // pto: %126
        ;
        int64_t v336 = v335 < v295 ? v335 : v295;
        // pto: %buf_score_sum_inline6899__ssa_v1
        ;
        Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v337 = Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v53);
        // pto: %buf_score_sum_inline6899__ssa_v1
        ;
        uint64_t v338 = (uint64_t) v32;
        TASSIGN(v337, v338);
        // pto: %127
        ;
        Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, 1, 384, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v339;
        // pto: %127
        ;
        uint64_t v340 = (uint64_t) v32;
        TASSIGN(v339, v340);
        // pto: %buf_score_row_inline6900__ssa_v1
        ;
        Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v341 = Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v53);
        // pto: %buf_score_row_inline6900__ssa_v1
        ;
        uint64_t v342 = (uint64_t) v29;
        TASSIGN(v341, v342);
        pipe_barrier(PIPE_V);
        TMUL(v341, v339, v259);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        // pto: %128
        ;
        // pto: %buf_store_column_inline6902__phi_v5
        ;
        int64_t v343;
        if (v303) {
          // pto: %132, %133
          ;
          v343 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v213 + (uint64_t) v136) + (uint64_t) v56);
        } else {
          v343 = (int64_t) ((uint64_t) v159 + (uint64_t) v38);
        };
        // pto: %134, %108, %135
        ;
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        if (v336 > v45 & v161 > v38) {
          v341.SetValidShape(v38, v336);
          // pto: %136
          ;
          bool v344 = v343 < v45;
          // pto: %136
          ;
          int64_t v345 = v344 ? v45 : v343;
          // pto: %137
          ;
          int64_t v346 = v304 < v45 ? v45 : v304;
          // pto: %138
          ;
          const int64_t v347 = 0;
          // pto: %138
          ;
          __gm__ float* v348 = PTOAS__GLOBAL_TENSOR_DATA(v97);
          // pto: %138
          ;
          const int64_t v349 = 1;
          // pto: %138
          ;
          const int64_t v350 = 1;
          // pto: %138
          ;
          const int64_t v351 = 1;
          // pto: %138
          ;
          int64_t v352 = v38 * v43;
          // pto: %138
          ;
          int64_t v353 = v351 * v352;
          // pto: %138
          ;
          pto::Shape<1, 1, 1, 1, -1> v354 = pto::Shape<1, 1, 1, 1, -1>(v349, v350, v351, v38, v336);
          // pto: %138
          ;
          pto::Stride<-1, -1, -1, -1, -1> v355 = pto::Stride<-1, -1, -1, -1, -1>(v350 * v353, v353, v352, v43, v38);
          // pto: %138
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v356 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v348 + (v347 + v345 * v43 + v346 * v38), v354, v355);
          pipe_barrier(PIPE_MTE3);
          TSTORE(v356, v341);
        };
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      // pto: %139
      ;
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      if (v132 > v38) {
        // pto: %140
        ;
        if (v161 > v45) {
          // pto: %141
          ;
          int64_t v357 = (v7)[v159];
          // pto: %142
          ;
          int64_t v358 = (int64_t) ((uint64_t) v357 + (uint64_t) v50);
          // pto: %143
          ;
          const int64_t v359 = 1;
          // pto: %143
          ;
          const int64_t v360 = 0;
          // pto: %143
          ;
          int64_t v361 = v358 / v51;
          // pto: %143
          ;
          bool v362 = v358 < v360;
          // pto: %143
          ;
          bool v363 = v51 < v360;
          // pto: %143
          ;
          bool v364 = v362 == v363;
          // pto: %143
          ;
          bool v365 = v358 % v51 != v360 && v362 != v363;
          // pto: %143
          ;
          int64_t v366 = v365 ? v361 - v359 : v361;
          // pto: %145
          ;
          int64_t v367 = v174 < v366 ? v174 : v366;
          // pto: %146
          ;
          int64_t v368 = v367 < v47 ? v367 : v47;
          // pto: %147
          ;
          int64_t v369 = v368 < v45 ? v45 : v368;
          // pto: %148
          ;
          int64_t v370 = (int64_t) ((uint64_t) v188 + (uint64_t) v210);
          // pto: %149
          ;
          int64_t v371 = (int64_t) ((uint64_t) v369 - (uint64_t) v370);
          // pto: %150
          ;
          int64_t v372 = v371 < v201 ? v371 : v201;
          // pto: %151
          ;
          int64_t v373 = v372 < v45 ? v45 : v372;
          // pto: %153
          ;
          uint64_t v374 = (uint64_t) v139;
          // pto: %152, %154, %153, %155
          ;
          int64_t v375 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v159 * (uint64_t) v59) + (uint64_t) ((int64_t) v374 * (uint64_t) v56)) + (uint64_t) v136);
          // pto: %156
          ;
          if (v373 > v45) {
            // pto: %157
            ;
            int32_t v376 = (int32_t) v370;
            // pto: %158
            ;
            if (v373 <= v60) {
              // pto: %t__ci_tmp_v0
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v377 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
              // pto: %t__ci_tmp_v0
              ;
              uint64_t v378 = (uint64_t) v30;
              TASSIGN(v377, v378);
              // pto: %t__tmp_v804
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v379 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v60);
              // pto: %t__tmp_v804
              ;
              uint64_t v380 = (uint64_t) v29;
              TASSIGN(v379, v380);
              // pto: %ci_tmp_view
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v381;
              TRESHAPE(v381, v377);
              // pto: %ci_dst_view
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v382;
              TRESHAPE(v382, v379);
              pipe_barrier(PIPE_V);
              TCI<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v382, v62, v381);
              // pto: %short_indices_inline6962__ssa_v0
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v383 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v60);
              // pto: %short_indices_inline6962__ssa_v0
              ;
              uint64_t v384 = (uint64_t) v30;
              TASSIGN(v383, v384);
              pipe_barrier(PIPE_V);
              TADDS(v383, v379, v376);
              set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
              // pto: %short_raw_inline6963__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v385 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v373);
              // pto: %short_raw_inline6963__ssa_v0
              ;
              uint64_t v386 = (uint64_t) v29;
              TASSIGN(v385, v386);
              // pto: %159, %160
              ;
              int64_t v387 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v136);
              // pto: %161
              ;
              int64_t v388 = v387 < v45 ? v45 : v387;
              // pto: %162
              ;
              const int64_t v389 = 0;
              // pto: %162
              ;
              __gm__ float* v390 = PTOAS__GLOBAL_TENSOR_DATA(v97);
              // pto: %162
              ;
              const int64_t v391 = 1;
              // pto: %162
              ;
              const int64_t v392 = 1;
              // pto: %162
              ;
              const int64_t v393 = 1;
              // pto: %162
              ;
              int64_t v394 = v38 * v43;
              // pto: %162
              ;
              int64_t v395 = v393 * v394;
              // pto: %162
              ;
              pto::Shape<1, 1, 1, 1, -1> v396 = pto::Shape<1, 1, 1, 1, -1>(v391, v392, v393, v38, v373);
              // pto: %162
              ;
              pto::Stride<-1, -1, -1, -1, -1> v397 = pto::Stride<-1, -1, -1, -1, -1>(v392 * v395, v395, v394, v43, v38);
              // pto: %162
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v398 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v390 + (v389 + v388 * v43 + v45 * v38), v396, v397);
              wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
              TLOAD(v385, v398);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
              // pto: %short_scores_inline6964__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v399 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v60);
              // pto: %short_scores_inline6964__ssa_v0
              ;
              uint64_t v400 = (uint64_t) v29;
              TASSIGN(v399, v400);
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
              TFILLPAD<pto::TFillPadMode::InPlace>(v399, v385);
              // pto: %short_scores_v1_inline6965__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v401 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v60);
              // pto: %short_scores_v1_inline6965__ssa_v0
              ;
              uint64_t v402 = (uint64_t) v31;
              TASSIGN(v401, v402);
              pipe_barrier(PIPE_V);
              TMAXS(v401, v399, v63);
              // pto: %t__tmp_v805
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v403 = Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v60);
              // pto: %t__tmp_v805
              ;
              uint64_t v404 = (uint64_t) v30;
              TASSIGN(v403, v404);
              // pto: %short_pairs_inline6966__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v405 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
              // pto: %short_pairs_inline6966__ssa_v0
              ;
              uint64_t v406 = (uint64_t) v29;
              TASSIGN(v405, v406);
              // pto: %sort32_src_view
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v407;
              TRESHAPE(v407, v401);
              // pto: %sort32_idx_view
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v408;
              TRESHAPE(v408, v403);
              // pto: %sort32_dst_view
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v409;
              TRESHAPE(v409, v405);
              pipe_barrier(PIPE_V);
              TSORT32(v409, v407, v408);
              // pto: %short_pairs_v1_inline6967__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v410 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
              // pto: %short_pairs_v1_inline6967__ssa_v0
              ;
              uint64_t v411 = (uint64_t) v30;
              TASSIGN(v410, v411);
              pipe_barrier(PIPE_V);
              TMRGSORT(v410, v405, v64);
              // pto: %short_pairs_v2_inline6968__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v412 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
              // pto: %short_pairs_v2_inline6968__ssa_v0
              ;
              uint64_t v413 = (uint64_t) v29;
              TASSIGN(v412, v413);
              pipe_barrier(PIPE_V);
              TMRGSORT(v412, v410, v65);
              set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
              // pto: %163
              ;
              int64_t v414 = v375 < v45 ? v45 : v375;
              // pto: %pair_arena_inline5765__ssa_v0_pview
              ;
              __gm__ float* v415 = PTOAS__GLOBAL_TENSOR_DATA(v105);
              // pto: %pair_arena_inline5765__ssa_v0_pview
              ;
              const int64_t v416 = 0;
              // pto: %pair_arena_inline5765__ssa_v0_pview
              ;
              const int64_t v417 = 1024;
              // pto: %pair_arena_inline5765__ssa_v0_pview
              ;
              pto::Shape<1, 1, 1, 1, 1024> v418 = pto::Shape<1, 1, 1, 1, 1024>();
              // pto: %pair_arena_inline5765__ssa_v0_pview
              ;
              pto::Stride<1024, 1024, 1024, 1024, 1> v419 = pto::Stride<1024, 1024, 1024, 1024, 1>();
              // pto: %pair_arena_inline5765__ssa_v0_pview
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v420 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v415 + (v416 + v414 * v417), v418, v419);
              wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
              pipe_barrier(PIPE_MTE3);
              TSTORE(v420, v412);
            } else {
              // pto: %164
              ;
              if (v373 <= v44) {
                // pto: %t__ci_tmp_v1
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v421 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
                // pto: %t__ci_tmp_v1
                ;
                uint64_t v422 = (uint64_t) v30;
                TASSIGN(v421, v422);
                // pto: %t__tmp_v806
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v423 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v44);
                // pto: %t__tmp_v806
                ;
                uint64_t v424 = (uint64_t) v29;
                TASSIGN(v423, v424);
                // pto: %165
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v425;
                TRESHAPE(v425, v421);
                // pto: %166
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v426;
                TRESHAPE(v426, v423);
                pipe_barrier(PIPE_V);
                TCI<Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v426, v62, v425);
                // pto: %small_indices_inline6969__ssa_v0
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v427 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v44);
                // pto: %small_indices_inline6969__ssa_v0
                ;
                uint64_t v428 = (uint64_t) v30;
                TASSIGN(v427, v428);
                pipe_barrier(PIPE_V);
                TADDS(v427, v423, v376);
                set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
                // pto: %small_raw_inline6970__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v429 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v373);
                // pto: %small_raw_inline6970__ssa_v0
                ;
                uint64_t v430 = (uint64_t) v29;
                TASSIGN(v429, v430);
                // pto: %167, %168
                ;
                int64_t v431 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v136);
                // pto: %169
                ;
                int64_t v432 = v431 < v45 ? v45 : v431;
                // pto: %170
                ;
                const int64_t v433 = 0;
                // pto: %170
                ;
                __gm__ float* v434 = PTOAS__GLOBAL_TENSOR_DATA(v97);
                // pto: %170
                ;
                const int64_t v435 = 1;
                // pto: %170
                ;
                const int64_t v436 = 1;
                // pto: %170
                ;
                const int64_t v437 = 1;
                // pto: %170
                ;
                int64_t v438 = v38 * v43;
                // pto: %170
                ;
                int64_t v439 = v437 * v438;
                // pto: %170
                ;
                pto::Shape<1, 1, 1, 1, -1> v440 = pto::Shape<1, 1, 1, 1, -1>(v435, v436, v437, v38, v373);
                // pto: %170
                ;
                pto::Stride<-1, -1, -1, -1, -1> v441 = pto::Stride<-1, -1, -1, -1, -1>(v436 * v439, v439, v438, v43, v38);
                // pto: %170
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v442 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v434 + (v433 + v432 * v43 + v45 * v38), v440, v441);
                wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
                TLOAD(v429, v442);
                set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
                // pto: %small_scores_inline6971__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v443 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                // pto: %small_scores_inline6971__ssa_v0
                ;
                uint64_t v444 = (uint64_t) v29;
                TASSIGN(v443, v444);
                wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
                TFILLPAD<pto::TFillPadMode::InPlace>(v443, v429);
                // pto: %small_scores_v1_inline6972__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v445 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                // pto: %small_scores_v1_inline6972__ssa_v0
                ;
                uint64_t v446 = (uint64_t) v31;
                TASSIGN(v445, v446);
                pipe_barrier(PIPE_V);
                TMAXS(v445, v443, v63);
                // pto: %t__tmp_v807
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v447 = Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v44);
                // pto: %t__tmp_v807
                ;
                uint64_t v448 = (uint64_t) v30;
                TASSIGN(v447, v448);
                // pto: %small_pairs_inline6973__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v449 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                // pto: %small_pairs_inline6973__ssa_v0
                ;
                uint64_t v450 = (uint64_t) v29;
                TASSIGN(v449, v450);
                // pto: %171
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v451;
                TRESHAPE(v451, v445);
                // pto: %172
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v452;
                TRESHAPE(v452, v447);
                // pto: %173
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v453;
                TRESHAPE(v453, v449);
                pipe_barrier(PIPE_V);
                TSORT32(v453, v451, v452);
                // pto: %small_pairs_v1_inline6974__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v454 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                // pto: %small_pairs_v1_inline6974__ssa_v0
                ;
                uint64_t v455 = (uint64_t) v30;
                TASSIGN(v454, v455);
                pipe_barrier(PIPE_V);
                TMRGSORT(v454, v449, v64);
                // pto: %small_pairs_v2_inline6975__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v456 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                // pto: %small_pairs_v2_inline6975__ssa_v0
                ;
                uint64_t v457 = (uint64_t) v29;
                TASSIGN(v456, v457);
                pipe_barrier(PIPE_V);
                TMRGSORT(v456, v454, v65);
                // pto: %small_left_inline6976__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v458 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                // pto: %small_left_inline6976__ssa_v0
                ;
                uint64_t v459 = (uint64_t) v29;
                TASSIGN(v458, v459);
                // pto: %174
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v460;
                // pto: %174
                ;
                uint64_t v461 = (uint64_t) v29;
                TASSIGN(v460, v461);
                // pto: %small_right_inline6977__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v462 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                // pto: %small_right_inline6977__ssa_v0
                ;
                uint64_t v463 = (uint64_t) v33;
                TASSIGN(v462, v463);
                // pto: %175
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v464;
                // pto: %175
                ;
                uint64_t v465 = (uint64_t) v33;
                TASSIGN(v464, v465);
                // pto: %small_tmp_inline6978__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v466 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                // pto: %small_tmp_inline6978__ssa_v0
                ;
                uint64_t v467 = (uint64_t) v30;
                TASSIGN(v466, v467);
                // pto: %small_merged_inline6979__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v468 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                // pto: %small_merged_inline6979__ssa_v0
                ;
                uint64_t v469 = (uint64_t) v31;
                TASSIGN(v468, v469);
                pipe_barrier(PIPE_V);
                TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v468, v28, v466, v460, v464);
                set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
                // pto: %small_top_inline6980__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v470 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                // pto: %small_top_inline6980__ssa_v0
                ;
                uint64_t v471 = (uint64_t) v31;
                TASSIGN(v470, v471);
                // pto: %176
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v472;
                // pto: %176
                ;
                uint64_t v473 = (uint64_t) v31;
                TASSIGN(v472, v473);
                // pto: %177
                ;
                int64_t v474 = v375 < v45 ? v45 : v375;
                // pto: %178
                ;
                __gm__ float* v475 = PTOAS__GLOBAL_TENSOR_DATA(v105);
                // pto: %178
                ;
                const int64_t v476 = 0;
                // pto: %178
                ;
                const int64_t v477 = 1024;
                // pto: %178
                ;
                pto::Shape<1, 1, 1, 1, 1024> v478 = pto::Shape<1, 1, 1, 1, 1024>();
                // pto: %178
                ;
                pto::Stride<1024, 1024, 1024, 1024, 1> v479 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                // pto: %178
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v480 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v475 + (v476 + v474 * v477), v478, v479);
                wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
                pipe_barrier(PIPE_MTE3);
                TSTORE(v480, v472);
              } else {
                // pto: %179
                ;
                if (v373 <= v66) {
                  // pto: %t__ci_tmp_v2
                  ;
                  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v481 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
                  // pto: %t__ci_tmp_v2
                  ;
                  uint64_t v482 = (uint64_t) v30;
                  TASSIGN(v481, v482);
                  // pto: %t__tmp_v808
                  ;
                  Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v483 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                  // pto: %t__tmp_v808
                  ;
                  uint64_t v484 = (uint64_t) v29;
                  TASSIGN(v483, v484);
                  // pto: %180
                  ;
                  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v485;
                  TRESHAPE(v485, v481);
                  // pto: %181
                  ;
                  Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v486;
                  TRESHAPE(v486, v483);
                  pipe_barrier(PIPE_V);
                  TCI<Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v486, v62, v485);
                  // pto: %leaf_indices_inline6981__ssa_v0
                  ;
                  Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v487 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                  // pto: %leaf_indices_inline6981__ssa_v0
                  ;
                  uint64_t v488 = (uint64_t) v30;
                  TASSIGN(v487, v488);
                  pipe_barrier(PIPE_V);
                  TADDS(v487, v483, v376);
                  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
                  // pto: %leaf_scores_raw_inline6982__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v489 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v373);
                  // pto: %leaf_scores_raw_inline6982__ssa_v0
                  ;
                  uint64_t v490 = (uint64_t) v29;
                  TASSIGN(v489, v490);
                  // pto: %182, %183
                  ;
                  int64_t v491 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v136);
                  // pto: %184
                  ;
                  int64_t v492 = v491 < v45 ? v45 : v491;
                  // pto: %185
                  ;
                  const int64_t v493 = 0;
                  // pto: %185
                  ;
                  __gm__ float* v494 = PTOAS__GLOBAL_TENSOR_DATA(v97);
                  // pto: %185
                  ;
                  const int64_t v495 = 1;
                  // pto: %185
                  ;
                  const int64_t v496 = 1;
                  // pto: %185
                  ;
                  const int64_t v497 = 1;
                  // pto: %185
                  ;
                  int64_t v498 = v38 * v43;
                  // pto: %185
                  ;
                  int64_t v499 = v497 * v498;
                  // pto: %185
                  ;
                  pto::Shape<1, 1, 1, 1, -1> v500 = pto::Shape<1, 1, 1, 1, -1>(v495, v496, v497, v38, v373);
                  // pto: %185
                  ;
                  pto::Stride<-1, -1, -1, -1, -1> v501 = pto::Stride<-1, -1, -1, -1, -1>(v496 * v499, v499, v498, v43, v38);
                  // pto: %185
                  ;
                  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v502 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v494 + (v493 + v492 * v43 + v45 * v38), v500, v501);
                  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
                  TLOAD(v489, v502);
                  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
                  // pto: %leaf_scores_inline6983__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v503 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                  // pto: %leaf_scores_inline6983__ssa_v0
                  ;
                  uint64_t v504 = (uint64_t) v29;
                  TASSIGN(v503, v504);
                  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
                  TFILLPAD<pto::TFillPadMode::InPlace>(v503, v489);
                  // pto: %leaf_scores_v1_inline6984__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v505 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                  // pto: %leaf_scores_v1_inline6984__ssa_v0
                  ;
                  uint64_t v506 = (uint64_t) v31;
                  TASSIGN(v505, v506);
                  pipe_barrier(PIPE_V);
                  TMAXS(v505, v503, v63);
                  // pto: %t__tmp_v809
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v507 = Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                  // pto: %t__tmp_v809
                  ;
                  uint64_t v508 = (uint64_t) v30;
                  TASSIGN(v507, v508);
                  // pto: %pairs_inline6985__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v509 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                  // pto: %pairs_inline6985__ssa_v0
                  ;
                  uint64_t v510 = (uint64_t) v29;
                  TASSIGN(v509, v510);
                  // pto: %186
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v511;
                  TRESHAPE(v511, v505);
                  // pto: %187
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v512;
                  TRESHAPE(v512, v507);
                  // pto: %188
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v513;
                  TRESHAPE(v513, v509);
                  pipe_barrier(PIPE_V);
                  TSORT32(v513, v511, v512);
                  // pto: %pairs_v1_inline6986__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v514 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                  // pto: %pairs_v1_inline6986__ssa_v0
                  ;
                  uint64_t v515 = (uint64_t) v30;
                  TASSIGN(v514, v515);
                  pipe_barrier(PIPE_V);
                  TMRGSORT(v514, v509, v64);
                  // pto: %pairs_v2_inline6987__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v516 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                  // pto: %pairs_v2_inline6987__ssa_v0
                  ;
                  uint64_t v517 = (uint64_t) v29;
                  TASSIGN(v516, v517);
                  pipe_barrier(PIPE_V);
                  TMRGSORT(v516, v514, v65);
                  // pto: %pairs_v3_inline6988__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v518 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                  // pto: %pairs_v3_inline6988__ssa_v0
                  ;
                  uint64_t v519 = (uint64_t) v30;
                  TASSIGN(v518, v519);
                  pipe_barrier(PIPE_V);
                  TMRGSORT(v518, v516, v67);
                  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
                  // pto: %t__tmp_v810
                  ;
                  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v520 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                  // pto: %t__tmp_v810
                  ;
                  uint64_t v521 = (uint64_t) v30;
                  TASSIGN(v520, v521);
                  // pto: %189
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v522;
                  // pto: %189
                  ;
                  uint64_t v523 = (uint64_t) v30;
                  TASSIGN(v522, v523);
                  // pto: %190
                  ;
                  int64_t v524 = v375 < v45 ? v45 : v375;
                  // pto: %191
                  ;
                  __gm__ float* v525 = PTOAS__GLOBAL_TENSOR_DATA(v105);
                  // pto: %191
                  ;
                  const int64_t v526 = 0;
                  // pto: %191
                  ;
                  const int64_t v527 = 1024;
                  // pto: %191
                  ;
                  pto::Shape<1, 1, 1, 1, 1024> v528 = pto::Shape<1, 1, 1, 1, 1024>();
                  // pto: %191
                  ;
                  pto::Stride<1024, 1024, 1024, 1024, 1> v529 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                  // pto: %191
                  ;
                  GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v530 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v525 + (v526 + v524 * v527), v528, v529);
                  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
                  pipe_barrier(PIPE_MTE3);
                  TSTORE(v530, v522);
                } else {
                  // pto: %192
                  ;
                  if (v373 <= v68) {
                    // pto: %t__ci_tmp_v3
                    ;
                    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v531 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
                    // pto: %t__ci_tmp_v3
                    ;
                    uint64_t v532 = (uint64_t) v30;
                    TASSIGN(v531, v532);
                    // pto: %t__tmp_v811
                    ;
                    Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v533 = Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v68);
                    // pto: %t__tmp_v811
                    ;
                    uint64_t v534 = (uint64_t) v29;
                    TASSIGN(v533, v534);
                    // pto: %193
                    ;
                    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v535;
                    TRESHAPE(v535, v531);
                    // pto: %194
                    ;
                    Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v536;
                    TRESHAPE(v536, v533);
                    pipe_barrier(PIPE_V);
                    TCI<Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v536, v62, v535);
                    // pto: %partial_indices_inline6989__ssa_v0
                    ;
                    Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v537 = Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v68);
                    // pto: %partial_indices_inline6989__ssa_v0
                    ;
                    uint64_t v538 = (uint64_t) v30;
                    TASSIGN(v537, v538);
                    pipe_barrier(PIPE_V);
                    TADDS(v537, v533, v376);
                    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
                    // pto: %partial_raw_inline6990__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v539 = Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v373);
                    // pto: %partial_raw_inline6990__ssa_v0
                    ;
                    uint64_t v540 = (uint64_t) v29;
                    TASSIGN(v539, v540);
                    // pto: %195, %196
                    ;
                    int64_t v541 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v136);
                    // pto: %197
                    ;
                    int64_t v542 = v541 < v45 ? v45 : v541;
                    // pto: %198
                    ;
                    const int64_t v543 = 0;
                    // pto: %198
                    ;
                    __gm__ float* v544 = PTOAS__GLOBAL_TENSOR_DATA(v97);
                    // pto: %198
                    ;
                    const int64_t v545 = 1;
                    // pto: %198
                    ;
                    const int64_t v546 = 1;
                    // pto: %198
                    ;
                    const int64_t v547 = 1;
                    // pto: %198
                    ;
                    int64_t v548 = v38 * v43;
                    // pto: %198
                    ;
                    int64_t v549 = v547 * v548;
                    // pto: %198
                    ;
                    pto::Shape<1, 1, 1, 1, -1> v550 = pto::Shape<1, 1, 1, 1, -1>(v545, v546, v547, v38, v373);
                    // pto: %198
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v551 = pto::Stride<-1, -1, -1, -1, -1>(v546 * v549, v549, v548, v43, v38);
                    // pto: %198
                    ;
                    GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v552 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v544 + (v543 + v542 * v43 + v45 * v38), v550, v551);
                    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
                    TLOAD(v539, v552);
                    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
                    // pto: %partial_scores_inline6991__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v553 = Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v68);
                    // pto: %partial_scores_inline6991__ssa_v0
                    ;
                    uint64_t v554 = (uint64_t) v29;
                    TASSIGN(v553, v554);
                    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
                    TFILLPAD<pto::TFillPadMode::InPlace>(v553, v539);
                    // pto: %partial_scores_v1_inline6992__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v555 = Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v68);
                    // pto: %partial_scores_v1_inline6992__ssa_v0
                    ;
                    uint64_t v556 = (uint64_t) v31;
                    TASSIGN(v555, v556);
                    pipe_barrier(PIPE_V);
                    TMAXS(v555, v553, v63);
                    // pto: %t__tmp_v812
                    ;
                    Tile<TileType::Vec, uint32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v557 = Tile<TileType::Vec, uint32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v68);
                    // pto: %t__tmp_v812
                    ;
                    uint64_t v558 = (uint64_t) v30;
                    TASSIGN(v557, v558);
                    // pto: %partial_pairs_inline6993__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v559 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v69);
                    // pto: %partial_pairs_inline6993__ssa_v0
                    ;
                    uint64_t v560 = (uint64_t) v29;
                    TASSIGN(v559, v560);
                    // pto: %199
                    ;
                    Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v561;
                    TRESHAPE(v561, v555);
                    // pto: %200
                    ;
                    Tile<TileType::Vec, uint32_t, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v562;
                    TRESHAPE(v562, v557);
                    // pto: %201
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 5120, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v563;
                    TRESHAPE(v563, v559);
                    pipe_barrier(PIPE_V);
                    TSORT32(v563, v561, v562);
                    // pto: %partial_pairs_v1_inline6994__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v564 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v69);
                    // pto: %partial_pairs_v1_inline6994__ssa_v0
                    ;
                    uint64_t v565 = (uint64_t) v30;
                    TASSIGN(v564, v565);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v564, v559, v64);
                    // pto: %partial_pairs_v2_inline6995__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v566 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v69);
                    // pto: %partial_pairs_v2_inline6995__ssa_v0
                    ;
                    uint64_t v567 = (uint64_t) v29;
                    TASSIGN(v566, v567);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v566, v564, v65);
                    v566.SetValidShape(v38, v54);
                    // pto: %partial_prefix_v1_inline6997__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v568 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v69);
                    // pto: %partial_prefix_v1_inline6997__ssa_v0
                    ;
                    uint64_t v569 = (uint64_t) v30;
                    TASSIGN(v568, v569);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v568, v566, v67);
                    // pto: %partial_left_inline6998__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v570 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                    // pto: %partial_left_inline6998__ssa_v0
                    ;
                    uint64_t v571 = (uint64_t) v30;
                    TASSIGN(v570, v571);
                    // pto: %202
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v572;
                    // pto: %202
                    ;
                    uint64_t v573 = (uint64_t) v30;
                    TASSIGN(v572, v573);
                    // pto: %partial_right_inline6999__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v574 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                    // pto: %partial_right_inline6999__ssa_v0
                    ;
                    uint64_t v575 = (uint64_t) v34;
                    TASSIGN(v574, v575);
                    // pto: %203
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v576;
                    // pto: %203
                    ;
                    uint64_t v577 = (uint64_t) v34;
                    TASSIGN(v576, v577);
                    // pto: %partial_tmp_inline7000__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v578 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                    // pto: %partial_tmp_inline7000__ssa_v0
                    ;
                    uint64_t v579 = (uint64_t) v31;
                    TASSIGN(v578, v579);
                    // pto: %partial_merged_inline7001__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v580 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                    // pto: %partial_merged_inline7001__ssa_v0
                    ;
                    uint64_t v581 = (uint64_t) v35;
                    TASSIGN(v580, v581);
                    pipe_barrier(PIPE_V);
                    TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v580, v28, v578, v576, v572);
                    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
                    // pto: %t__tmp_v813
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v582 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                    // pto: %t__tmp_v813
                    ;
                    uint64_t v583 = (uint64_t) v35;
                    TASSIGN(v582, v583);
                    // pto: %205
                    ;
                    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v584;
                    // pto: %205
                    ;
                    uint64_t v585 = (uint64_t) v35;
                    TASSIGN(v584, v585);
                    // pto: %206
                    ;
                    int64_t v586 = v375 < v45 ? v45 : v375;
                    // pto: %207
                    ;
                    __gm__ float* v587 = PTOAS__GLOBAL_TENSOR_DATA(v105);
                    // pto: %207
                    ;
                    const int64_t v588 = 0;
                    // pto: %207
                    ;
                    const int64_t v589 = 1024;
                    // pto: %207
                    ;
                    pto::Shape<1, 1, 1, 1, 1024> v590 = pto::Shape<1, 1, 1, 1, 1024>();
                    // pto: %207
                    ;
                    pto::Stride<1024, 1024, 1024, 1024, 1> v591 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                    // pto: %207
                    ;
                    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v592 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v587 + (v588 + v586 * v589), v590, v591);
                    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
                    TSTORE(v592, v584);
                  } else {
                    // pto: %208
                    ;
                    if (v373 <= v70) {
                      // pto: %t__ci_tmp_v4
                      ;
                      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v593 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
                      // pto: %t__ci_tmp_v4
                      ;
                      uint64_t v594 = (uint64_t) v30;
                      TASSIGN(v593, v594);
                      // pto: %t__tmp_v814
                      ;
                      Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v595 = Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v70);
                      // pto: %t__tmp_v814
                      ;
                      uint64_t v596 = (uint64_t) v29;
                      TASSIGN(v595, v596);
                      // pto: %209
                      ;
                      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v597;
                      TRESHAPE(v597, v593);
                      // pto: %210
                      ;
                      Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v598;
                      TRESHAPE(v598, v595);
                      pipe_barrier(PIPE_V);
                      TCI<Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v598, v62, v597);
                      // pto: %triple_indices_inline7002__ssa_v0
                      ;
                      Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v599 = Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v70);
                      // pto: %triple_indices_inline7002__ssa_v0
                      ;
                      uint64_t v600 = (uint64_t) v30;
                      TASSIGN(v599, v600);
                      pipe_barrier(PIPE_V);
                      TADDS(v599, v595, v376);
                      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
                      // pto: %triple_raw_inline7003__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v601 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v373);
                      // pto: %triple_raw_inline7003__ssa_v0
                      ;
                      uint64_t v602 = (uint64_t) v29;
                      TASSIGN(v601, v602);
                      // pto: %211, %212
                      ;
                      int64_t v603 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v136);
                      // pto: %213
                      ;
                      int64_t v604 = v603 < v45 ? v45 : v603;
                      // pto: %214
                      ;
                      const int64_t v605 = 0;
                      // pto: %214
                      ;
                      __gm__ float* v606 = PTOAS__GLOBAL_TENSOR_DATA(v97);
                      // pto: %214
                      ;
                      const int64_t v607 = 1;
                      // pto: %214
                      ;
                      const int64_t v608 = 1;
                      // pto: %214
                      ;
                      const int64_t v609 = 1;
                      // pto: %214
                      ;
                      int64_t v610 = v38 * v43;
                      // pto: %214
                      ;
                      int64_t v611 = v609 * v610;
                      // pto: %214
                      ;
                      pto::Shape<1, 1, 1, 1, -1> v612 = pto::Shape<1, 1, 1, 1, -1>(v607, v608, v609, v38, v373);
                      // pto: %214
                      ;
                      pto::Stride<-1, -1, -1, -1, -1> v613 = pto::Stride<-1, -1, -1, -1, -1>(v608 * v611, v611, v610, v43, v38);
                      // pto: %214
                      ;
                      GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v614 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v606 + (v605 + v604 * v43 + v45 * v38), v612, v613);
                      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
                      TLOAD(v601, v614);
                      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
                      // pto: %triple_scores_inline7004__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v615 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v70);
                      // pto: %triple_scores_inline7004__ssa_v0
                      ;
                      uint64_t v616 = (uint64_t) v29;
                      TASSIGN(v615, v616);
                      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
                      TFILLPAD<pto::TFillPadMode::InPlace>(v615, v601);
                      // pto: %triple_scores_v1_inline7005__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v617 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v70);
                      // pto: %triple_scores_v1_inline7005__ssa_v0
                      ;
                      uint64_t v618 = (uint64_t) v31;
                      TASSIGN(v617, v618);
                      pipe_barrier(PIPE_V);
                      TMAXS(v617, v615, v63);
                      // pto: %t__tmp_v815
                      ;
                      Tile<TileType::Vec, uint32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v619 = Tile<TileType::Vec, uint32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v70);
                      // pto: %t__tmp_v815
                      ;
                      uint64_t v620 = (uint64_t) v30;
                      TASSIGN(v619, v620);
                      // pto: %triple_pairs_inline7006__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v621 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v71);
                      // pto: %triple_pairs_inline7006__ssa_v0
                      ;
                      uint64_t v622 = (uint64_t) v29;
                      TASSIGN(v621, v622);
                      // pto: %215
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v623;
                      TRESHAPE(v623, v617);
                      // pto: %216
                      ;
                      Tile<TileType::Vec, uint32_t, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v624;
                      TRESHAPE(v624, v619);
                      // pto: %217
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 6144, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v625;
                      TRESHAPE(v625, v621);
                      pipe_barrier(PIPE_V);
                      TSORT32(v625, v623, v624);
                      // pto: %triple_pairs_v1_inline7007__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v626 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v71);
                      // pto: %triple_pairs_v1_inline7007__ssa_v0
                      ;
                      uint64_t v627 = (uint64_t) v30;
                      TASSIGN(v626, v627);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v626, v621, v64);
                      // pto: %triple_pairs_v2_inline7008__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v628 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v71);
                      // pto: %triple_pairs_v2_inline7008__ssa_v0
                      ;
                      uint64_t v629 = (uint64_t) v29;
                      TASSIGN(v628, v629);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v628, v626, v65);
                      v628.SetValidShape(v38, v54);
                      // pto: %triple_prefix_v1_inline7010__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v630 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v71);
                      // pto: %triple_prefix_v1_inline7010__ssa_v0
                      ;
                      uint64_t v631 = (uint64_t) v30;
                      TASSIGN(v630, v631);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v630, v628, v67);
                      // pto: %triple_left_inline7011__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v632 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %triple_left_inline7011__ssa_v0
                      ;
                      uint64_t v633 = (uint64_t) v30;
                      TASSIGN(v632, v633);
                      // pto: %218
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v634;
                      // pto: %218
                      ;
                      uint64_t v635 = (uint64_t) v30;
                      TASSIGN(v634, v635);
                      // pto: %triple_right0_inline7012__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v636 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %triple_right0_inline7012__ssa_v0
                      ;
                      uint64_t v637 = (uint64_t) v34;
                      TASSIGN(v636, v637);
                      // pto: %219
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v638;
                      // pto: %219
                      ;
                      uint64_t v639 = (uint64_t) v34;
                      TASSIGN(v638, v639);
                      // pto: %triple_right1_inline7013__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v640 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %triple_right1_inline7013__ssa_v0
                      ;
                      uint64_t v641 = (uint64_t) v36;
                      TASSIGN(v640, v641);
                      // pto: %220
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v642;
                      // pto: %220
                      ;
                      uint64_t v643 = (uint64_t) v36;
                      TASSIGN(v642, v643);
                      // pto: %triple_tmp_inline7014__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v644 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v70);
                      // pto: %triple_tmp_inline7014__ssa_v0
                      ;
                      uint64_t v645 = (uint64_t) v31;
                      TASSIGN(v644, v645);
                      // pto: %triple_merged_inline7015__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v646 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v70);
                      // pto: %triple_merged_inline7015__ssa_v0
                      ;
                      uint64_t v647 = (uint64_t) v35;
                      TASSIGN(v646, v647);
                      pipe_barrier(PIPE_V);
                      TMRGSORT<Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v646, v28, v644, v638, v642, v634);
                      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
                      // pto: %t__tmp_v816
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v648 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %t__tmp_v816
                      ;
                      uint64_t v649 = (uint64_t) v35;
                      TASSIGN(v648, v649);
                      // pto: %222
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v650;
                      // pto: %222
                      ;
                      uint64_t v651 = (uint64_t) v35;
                      TASSIGN(v650, v651);
                      // pto: %223
                      ;
                      int64_t v652 = v375 < v45 ? v45 : v375;
                      // pto: %224
                      ;
                      __gm__ float* v653 = PTOAS__GLOBAL_TENSOR_DATA(v105);
                      // pto: %224
                      ;
                      const int64_t v654 = 0;
                      // pto: %224
                      ;
                      const int64_t v655 = 1024;
                      // pto: %224
                      ;
                      pto::Shape<1, 1, 1, 1, 1024> v656 = pto::Shape<1, 1, 1, 1, 1024>();
                      // pto: %224
                      ;
                      pto::Stride<1024, 1024, 1024, 1024, 1> v657 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                      // pto: %224
                      ;
                      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v658 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v653 + (v654 + v652 * v655), v656, v657);
                      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
                      TSTORE(v658, v650);
                    } else {
                      // pto: %t__ci_tmp_v5
                      ;
                      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v659 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
                      // pto: %t__ci_tmp_v5
                      ;
                      uint64_t v660 = (uint64_t) v30;
                      TASSIGN(v659, v660);
                      // pto: %t__tmp_v817
                      ;
                      Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v661 = Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v54);
                      // pto: %t__tmp_v817
                      ;
                      uint64_t v662 = (uint64_t) v29;
                      TASSIGN(v661, v662);
                      // pto: %225
                      ;
                      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v663;
                      TRESHAPE(v663, v659);
                      // pto: %226
                      ;
                      Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v664;
                      TRESHAPE(v664, v661);
                      pipe_barrier(PIPE_V);
                      TCI<Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v664, v62, v663);
                      // pto: %medium_indices_inline7016__ssa_v0
                      ;
                      Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v665 = Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v54);
                      // pto: %medium_indices_inline7016__ssa_v0
                      ;
                      uint64_t v666 = (uint64_t) v30;
                      TASSIGN(v665, v666);
                      pipe_barrier(PIPE_V);
                      TADDS(v665, v661, v376);
                      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                      // pto: %medium_scores_raw_inline7017__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v667 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v373);
                      // pto: %medium_scores_raw_inline7017__ssa_v0
                      ;
                      uint64_t v668 = (uint64_t) v29;
                      TASSIGN(v667, v668);
                      // pto: %227, %228
                      ;
                      int64_t v669 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v136);
                      // pto: %229
                      ;
                      int64_t v670 = v669 < v45 ? v45 : v669;
                      // pto: %230
                      ;
                      const int64_t v671 = 0;
                      // pto: %230
                      ;
                      __gm__ float* v672 = PTOAS__GLOBAL_TENSOR_DATA(v97);
                      // pto: %230
                      ;
                      const int64_t v673 = 1;
                      // pto: %230
                      ;
                      const int64_t v674 = 1;
                      // pto: %230
                      ;
                      const int64_t v675 = 1;
                      // pto: %230
                      ;
                      int64_t v676 = v38 * v43;
                      // pto: %230
                      ;
                      int64_t v677 = v675 * v676;
                      // pto: %230
                      ;
                      pto::Shape<1, 1, 1, 1, -1> v678 = pto::Shape<1, 1, 1, 1, -1>(v673, v674, v675, v38, v373);
                      // pto: %230
                      ;
                      pto::Stride<-1, -1, -1, -1, -1> v679 = pto::Stride<-1, -1, -1, -1, -1>(v674 * v677, v677, v676, v43, v38);
                      // pto: %230
                      ;
                      GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v680 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v672 + (v671 + v670 * v43 + v45 * v38), v678, v679);
                      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                      TLOAD(v667, v680);
                      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
                      // pto: %medium_scores_inline7018__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v681 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                      // pto: %medium_scores_inline7018__ssa_v0
                      ;
                      uint64_t v682 = (uint64_t) v29;
                      TASSIGN(v681, v682);
                      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
                      TFILLPAD<pto::TFillPadMode::InPlace>(v681, v667);
                      // pto: %medium_scores_v1_inline7019__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v683 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                      // pto: %medium_scores_v1_inline7019__ssa_v0
                      ;
                      uint64_t v684 = (uint64_t) v31;
                      TASSIGN(v683, v684);
                      pipe_barrier(PIPE_V);
                      TMAXS(v683, v681, v63);
                      // pto: %t__tmp_v818
                      ;
                      Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v685 = Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v54);
                      // pto: %t__tmp_v818
                      ;
                      uint64_t v686 = (uint64_t) v30;
                      TASSIGN(v685, v686);
                      // pto: %medium_pairs_inline7020__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v687 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v43);
                      // pto: %medium_pairs_inline7020__ssa_v0
                      ;
                      uint64_t v688 = (uint64_t) v29;
                      TASSIGN(v687, v688);
                      // pto: %231
                      ;
                      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v689;
                      TRESHAPE(v689, v683);
                      // pto: %232
                      ;
                      Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v690;
                      TRESHAPE(v690, v685);
                      // pto: %233
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 8192, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v691;
                      TRESHAPE(v691, v687);
                      pipe_barrier(PIPE_V);
                      TSORT32(v691, v689, v690);
                      // pto: %medium_pairs_v1_inline7021__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v692 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v43);
                      // pto: %medium_pairs_v1_inline7021__ssa_v0
                      ;
                      uint64_t v693 = (uint64_t) v30;
                      TASSIGN(v692, v693);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v692, v687, v64);
                      // pto: %medium_pairs_v2_inline7022__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v694 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v43);
                      // pto: %medium_pairs_v2_inline7022__ssa_v0
                      ;
                      uint64_t v695 = (uint64_t) v29;
                      TASSIGN(v694, v695);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v694, v692, v65);
                      // pto: %medium_pairs_v3_inline7023__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v696 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v43);
                      // pto: %medium_pairs_v3_inline7023__ssa_v0
                      ;
                      uint64_t v697 = (uint64_t) v30;
                      TASSIGN(v696, v697);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v696, v694, v67);
                      // pto: %medium_left_inline7024__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v698 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %medium_left_inline7024__ssa_v0
                      ;
                      uint64_t v699 = (uint64_t) v30;
                      TASSIGN(v698, v699);
                      // pto: %234
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v700;
                      // pto: %234
                      ;
                      uint64_t v701 = (uint64_t) v30;
                      TASSIGN(v700, v701);
                      // pto: %medium_right_inline7025__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v702 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %medium_right_inline7025__ssa_v0
                      ;
                      uint64_t v703 = (uint64_t) v37;
                      TASSIGN(v702, v703);
                      // pto: %235
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v704;
                      // pto: %235
                      ;
                      uint64_t v705 = (uint64_t) v37;
                      TASSIGN(v704, v705);
                      // pto: %medium_tmp_inline7026__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v706 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                      // pto: %medium_tmp_inline7026__ssa_v0
                      ;
                      uint64_t v707 = (uint64_t) v29;
                      TASSIGN(v706, v707);
                      // pto: %medium_merged_inline7027__ssa_v0
                      ;
                      Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v708 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                      // pto: %medium_merged_inline7027__ssa_v0
                      ;
                      uint64_t v709 = (uint64_t) v31;
                      TASSIGN(v708, v709);
                      pipe_barrier(PIPE_V);
                      TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v708, v28, v706, v704, v700);
                      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
                      // pto: %t__tmp_v819
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v710 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %t__tmp_v819
                      ;
                      uint64_t v711 = (uint64_t) v31;
                      TASSIGN(v710, v711);
                      // pto: %237
                      ;
                      Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v712;
                      // pto: %237
                      ;
                      uint64_t v713 = (uint64_t) v31;
                      TASSIGN(v712, v713);
                      // pto: %238
                      ;
                      int64_t v714 = v375 < v45 ? v45 : v375;
                      // pto: %239
                      ;
                      __gm__ float* v715 = PTOAS__GLOBAL_TENSOR_DATA(v105);
                      // pto: %239
                      ;
                      const int64_t v716 = 0;
                      // pto: %239
                      ;
                      const int64_t v717 = 1024;
                      // pto: %239
                      ;
                      pto::Shape<1, 1, 1, 1, 1024> v718 = pto::Shape<1, 1, 1, 1, 1024>();
                      // pto: %239
                      ;
                      pto::Stride<1024, 1024, 1024, 1024, 1> v719 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                      // pto: %239
                      ;
                      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v720 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v715 + (v716 + v714 * v717), v718, v719);
                      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
                      pipe_barrier(PIPE_MTE3);
                      TSTORE(v720, v712);
                    };
                  };
                };
              };
            };
          } else {
            // pto: %t__tmp_v820
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v721 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v44);
            // pto: %t__tmp_v820
            ;
            uint64_t v722 = (uint64_t) v29;
            TASSIGN(v721, v722);
            pipe_barrier(PIPE_V);
            TEXPANDS(v721, v63);
            set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
            // pto: %240
            ;
            int64_t v723 = v375 < v45 ? v45 : v375;
            // pto: %241
            ;
            __gm__ float* v724 = PTOAS__GLOBAL_TENSOR_DATA(v105);
            // pto: %241
            ;
            const int64_t v725 = 0;
            // pto: %241
            ;
            const int64_t v726 = 1024;
            // pto: %241
            ;
            pto::Shape<1, 1, 1, 1, 1024> v727 = pto::Shape<1, 1, 1, 1, 1024>();
            // pto: %241
            ;
            pto::Stride<1024, 1024, 1024, 1024, 1> v728 = pto::Stride<1024, 1024, 1024, 1024, 1>();
            // pto: %241
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v729 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v724 + (v725 + v723 * v726), v727, v728);
            wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
            pipe_barrier(PIPE_MTE3);
            TSTORE(v729, v721);
          };
        };
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
        // pto: %242
        ;
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
        if (v161 > v38) {
          // pto: %244, %243
          ;
          int64_t v730 = (v7)[(int64_t) ((uint64_t) v159 + (uint64_t) v38)];
          // pto: %245
          ;
          int64_t v731 = (int64_t) ((uint64_t) v730 + (uint64_t) v50);
          // pto: %246
          ;
          const int64_t v732 = 1;
          // pto: %246
          ;
          const int64_t v733 = 0;
          // pto: %246
          ;
          int64_t v734 = v731 / v51;
          // pto: %246
          ;
          bool v735 = v731 < v733;
          // pto: %246
          ;
          bool v736 = v51 < v733;
          // pto: %246
          ;
          bool v737 = v735 == v736;
          // pto: %246
          ;
          bool v738 = v731 % v51 != v733 && v735 != v736;
          // pto: %246
          ;
          int64_t v739 = v738 ? v734 - v732 : v734;
          // pto: %248
          ;
          int64_t v740 = v174 < v739 ? v174 : v739;
          // pto: %249
          ;
          int64_t v741 = v740 < v47 ? v740 : v47;
          // pto: %250
          ;
          int64_t v742 = v741 < v45 ? v45 : v741;
          // pto: %251
          ;
          int64_t v743 = (int64_t) ((uint64_t) v188 + (uint64_t) v210);
          // pto: %252
          ;
          int64_t v744 = (int64_t) ((uint64_t) v742 - (uint64_t) v743);
          // pto: %253
          ;
          int64_t v745 = v744 < v201 ? v744 : v201;
          // pto: %254
          ;
          int64_t v746 = v745 < v45 ? v45 : v745;
          // pto: %256
          ;
          uint64_t v747 = (uint64_t) v139;
          // pto: %255, %257, %256, %258, %259
          ;
          int64_t v748 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v159 * (uint64_t) v59) + (uint64_t) ((int64_t) v747 * (uint64_t) v56)) + (uint64_t) v136) + (uint64_t) v59);
          // pto: %260
          ;
          if (v746 > v45) {
            // pto: %261
            ;
            int32_t v749 = (int32_t) v743;
            // pto: %262
            ;
            if (v746 <= v60) {
              // pto: %t__ci_tmp_v6
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v750 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
              // pto: %t__ci_tmp_v6
              ;
              uint64_t v751 = (uint64_t) v30;
              TASSIGN(v750, v751);
              // pto: %t__tmp_v821
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v752 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v60);
              // pto: %t__tmp_v821
              ;
              uint64_t v753 = (uint64_t) v29;
              TASSIGN(v752, v753);
              // pto: %263
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v754;
              TRESHAPE(v754, v750);
              // pto: %264
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v755;
              TRESHAPE(v755, v752);
              pipe_barrier(PIPE_V);
              TCI<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v755, v62, v754);
              // pto: %short_indices_inline6962__ssa_v1
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v756 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v60);
              // pto: %short_indices_inline6962__ssa_v1
              ;
              uint64_t v757 = (uint64_t) v30;
              TASSIGN(v756, v757);
              pipe_barrier(PIPE_V);
              TADDS(v756, v752, v749);
              set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
              // pto: %short_raw_inline6963__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v758 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v746);
              // pto: %short_raw_inline6963__ssa_v1
              ;
              uint64_t v759 = (uint64_t) v29;
              TASSIGN(v758, v759);
              // pto: %265, %266, %267
              ;
              int64_t v760 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v136) + (uint64_t) v56);
              // pto: %268
              ;
              int64_t v761 = v760 < v45 ? v45 : v760;
              // pto: %269
              ;
              const int64_t v762 = 0;
              // pto: %269
              ;
              __gm__ float* v763 = PTOAS__GLOBAL_TENSOR_DATA(v97);
              // pto: %269
              ;
              const int64_t v764 = 1;
              // pto: %269
              ;
              const int64_t v765 = 1;
              // pto: %269
              ;
              const int64_t v766 = 1;
              // pto: %269
              ;
              int64_t v767 = v38 * v43;
              // pto: %269
              ;
              int64_t v768 = v766 * v767;
              // pto: %269
              ;
              pto::Shape<1, 1, 1, 1, -1> v769 = pto::Shape<1, 1, 1, 1, -1>(v764, v765, v766, v38, v746);
              // pto: %269
              ;
              pto::Stride<-1, -1, -1, -1, -1> v770 = pto::Stride<-1, -1, -1, -1, -1>(v765 * v768, v768, v767, v43, v38);
              // pto: %269
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v771 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v763 + (v762 + v761 * v43 + v45 * v38), v769, v770);
              wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
              TLOAD(v758, v771);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
              // pto: %short_scores_inline6964__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v772 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v60);
              // pto: %short_scores_inline6964__ssa_v1
              ;
              uint64_t v773 = (uint64_t) v29;
              TASSIGN(v772, v773);
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
              TFILLPAD<pto::TFillPadMode::InPlace>(v772, v758);
              // pto: %short_scores_v1_inline6965__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v774 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v60);
              // pto: %short_scores_v1_inline6965__ssa_v1
              ;
              uint64_t v775 = (uint64_t) v31;
              TASSIGN(v774, v775);
              pipe_barrier(PIPE_V);
              TMAXS(v774, v772, v63);
              // pto: %t__tmp_v822
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v776 = Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v60);
              // pto: %t__tmp_v822
              ;
              uint64_t v777 = (uint64_t) v30;
              TASSIGN(v776, v777);
              // pto: %short_pairs_inline6966__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v778 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
              // pto: %short_pairs_inline6966__ssa_v1
              ;
              uint64_t v779 = (uint64_t) v29;
              TASSIGN(v778, v779);
              // pto: %270
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v780;
              TRESHAPE(v780, v774);
              // pto: %271
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v781;
              TRESHAPE(v781, v776);
              // pto: %272
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v782;
              TRESHAPE(v782, v778);
              pipe_barrier(PIPE_V);
              TSORT32(v782, v780, v781);
              // pto: %short_pairs_v1_inline6967__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v783 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
              // pto: %short_pairs_v1_inline6967__ssa_v1
              ;
              uint64_t v784 = (uint64_t) v30;
              TASSIGN(v783, v784);
              pipe_barrier(PIPE_V);
              TMRGSORT(v783, v778, v64);
              // pto: %short_pairs_v2_inline6968__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v785 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
              // pto: %short_pairs_v2_inline6968__ssa_v1
              ;
              uint64_t v786 = (uint64_t) v29;
              TASSIGN(v785, v786);
              pipe_barrier(PIPE_V);
              TMRGSORT(v785, v783, v65);
              set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
              // pto: %273
              ;
              int64_t v787 = v748 < v45 ? v45 : v748;
              // pto: %274
              ;
              __gm__ float* v788 = PTOAS__GLOBAL_TENSOR_DATA(v105);
              // pto: %274
              ;
              const int64_t v789 = 0;
              // pto: %274
              ;
              const int64_t v790 = 1024;
              // pto: %274
              ;
              pto::Shape<1, 1, 1, 1, 1024> v791 = pto::Shape<1, 1, 1, 1, 1024>();
              // pto: %274
              ;
              pto::Stride<1024, 1024, 1024, 1024, 1> v792 = pto::Stride<1024, 1024, 1024, 1024, 1>();
              // pto: %274
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v793 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v788 + (v789 + v787 * v790), v791, v792);
              wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
              pipe_barrier(PIPE_MTE3);
              TSTORE(v793, v785);
            } else {
              // pto: %275
              ;
              if (v746 <= v44) {
                // pto: %t__ci_tmp_v7
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v794 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
                // pto: %t__ci_tmp_v7
                ;
                uint64_t v795 = (uint64_t) v30;
                TASSIGN(v794, v795);
                // pto: %t__tmp_v823
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v796 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v44);
                // pto: %t__tmp_v823
                ;
                uint64_t v797 = (uint64_t) v29;
                TASSIGN(v796, v797);
                // pto: %276
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v798;
                TRESHAPE(v798, v794);
                // pto: %277
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v799;
                TRESHAPE(v799, v796);
                pipe_barrier(PIPE_V);
                TCI<Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v799, v62, v798);
                // pto: %small_indices_inline6969__ssa_v1
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v800 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v44);
                // pto: %small_indices_inline6969__ssa_v1
                ;
                uint64_t v801 = (uint64_t) v30;
                TASSIGN(v800, v801);
                pipe_barrier(PIPE_V);
                TADDS(v800, v796, v749);
                set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                // pto: %small_raw_inline6970__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v802 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v746);
                // pto: %small_raw_inline6970__ssa_v1
                ;
                uint64_t v803 = (uint64_t) v29;
                TASSIGN(v802, v803);
                // pto: %278, %279, %280
                ;
                int64_t v804 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v136) + (uint64_t) v56);
                // pto: %281
                ;
                int64_t v805 = v804 < v45 ? v45 : v804;
                // pto: %282
                ;
                const int64_t v806 = 0;
                // pto: %282
                ;
                __gm__ float* v807 = PTOAS__GLOBAL_TENSOR_DATA(v97);
                // pto: %282
                ;
                const int64_t v808 = 1;
                // pto: %282
                ;
                const int64_t v809 = 1;
                // pto: %282
                ;
                const int64_t v810 = 1;
                // pto: %282
                ;
                int64_t v811 = v38 * v43;
                // pto: %282
                ;
                int64_t v812 = v810 * v811;
                // pto: %282
                ;
                pto::Shape<1, 1, 1, 1, -1> v813 = pto::Shape<1, 1, 1, 1, -1>(v808, v809, v810, v38, v746);
                // pto: %282
                ;
                pto::Stride<-1, -1, -1, -1, -1> v814 = pto::Stride<-1, -1, -1, -1, -1>(v809 * v812, v812, v811, v43, v38);
                // pto: %282
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v815 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v807 + (v806 + v805 * v43 + v45 * v38), v813, v814);
                wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                TLOAD(v802, v815);
                set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                // pto: %small_scores_inline6971__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v816 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                // pto: %small_scores_inline6971__ssa_v1
                ;
                uint64_t v817 = (uint64_t) v29;
                TASSIGN(v816, v817);
                wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                TFILLPAD<pto::TFillPadMode::InPlace>(v816, v802);
                // pto: %small_scores_v1_inline6972__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v818 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                // pto: %small_scores_v1_inline6972__ssa_v1
                ;
                uint64_t v819 = (uint64_t) v31;
                TASSIGN(v818, v819);
                pipe_barrier(PIPE_V);
                TMAXS(v818, v816, v63);
                // pto: %t__tmp_v824
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v820 = Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v44);
                // pto: %t__tmp_v824
                ;
                uint64_t v821 = (uint64_t) v30;
                TASSIGN(v820, v821);
                // pto: %small_pairs_inline6973__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v822 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                // pto: %small_pairs_inline6973__ssa_v1
                ;
                uint64_t v823 = (uint64_t) v29;
                TASSIGN(v822, v823);
                // pto: %283
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v824;
                TRESHAPE(v824, v818);
                // pto: %284
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v825;
                TRESHAPE(v825, v820);
                // pto: %285
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v826;
                TRESHAPE(v826, v822);
                pipe_barrier(PIPE_V);
                TSORT32(v826, v824, v825);
                // pto: %small_pairs_v1_inline6974__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v827 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                // pto: %small_pairs_v1_inline6974__ssa_v1
                ;
                uint64_t v828 = (uint64_t) v30;
                TASSIGN(v827, v828);
                pipe_barrier(PIPE_V);
                TMRGSORT(v827, v822, v64);
                // pto: %small_pairs_v2_inline6975__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v829 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                // pto: %small_pairs_v2_inline6975__ssa_v1
                ;
                uint64_t v830 = (uint64_t) v29;
                TASSIGN(v829, v830);
                pipe_barrier(PIPE_V);
                TMRGSORT(v829, v827, v65);
                // pto: %small_left_inline6976__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v831 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                // pto: %small_left_inline6976__ssa_v1
                ;
                uint64_t v832 = (uint64_t) v29;
                TASSIGN(v831, v832);
                // pto: %286
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v833;
                // pto: %286
                ;
                uint64_t v834 = (uint64_t) v29;
                TASSIGN(v833, v834);
                // pto: %small_right_inline6977__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v835 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                // pto: %small_right_inline6977__ssa_v1
                ;
                uint64_t v836 = (uint64_t) v33;
                TASSIGN(v835, v836);
                // pto: %287
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v837;
                // pto: %287
                ;
                uint64_t v838 = (uint64_t) v33;
                TASSIGN(v837, v838);
                // pto: %small_tmp_inline6978__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v839 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                // pto: %small_tmp_inline6978__ssa_v1
                ;
                uint64_t v840 = (uint64_t) v30;
                TASSIGN(v839, v840);
                // pto: %small_merged_inline6979__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v841 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                // pto: %small_merged_inline6979__ssa_v1
                ;
                uint64_t v842 = (uint64_t) v31;
                TASSIGN(v841, v842);
                pipe_barrier(PIPE_V);
                TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v841, v28, v839, v833, v837);
                set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                // pto: %small_top_inline6980__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v843 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                // pto: %small_top_inline6980__ssa_v1
                ;
                uint64_t v844 = (uint64_t) v31;
                TASSIGN(v843, v844);
                // pto: %289
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v845;
                // pto: %289
                ;
                uint64_t v846 = (uint64_t) v31;
                TASSIGN(v845, v846);
                // pto: %290
                ;
                int64_t v847 = v748 < v45 ? v45 : v748;
                // pto: %291
                ;
                __gm__ float* v848 = PTOAS__GLOBAL_TENSOR_DATA(v105);
                // pto: %291
                ;
                const int64_t v849 = 0;
                // pto: %291
                ;
                const int64_t v850 = 1024;
                // pto: %291
                ;
                pto::Shape<1, 1, 1, 1, 1024> v851 = pto::Shape<1, 1, 1, 1, 1024>();
                // pto: %291
                ;
                pto::Stride<1024, 1024, 1024, 1024, 1> v852 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                // pto: %291
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v853 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v848 + (v849 + v847 * v850), v851, v852);
                wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                pipe_barrier(PIPE_MTE3);
                TSTORE(v853, v845);
              } else {
                // pto: %292
                ;
                if (v746 <= v66) {
                  // pto: %t__ci_tmp_v8
                  ;
                  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v854 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
                  // pto: %t__ci_tmp_v8
                  ;
                  uint64_t v855 = (uint64_t) v30;
                  TASSIGN(v854, v855);
                  // pto: %t__tmp_v825
                  ;
                  Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v856 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                  // pto: %t__tmp_v825
                  ;
                  uint64_t v857 = (uint64_t) v29;
                  TASSIGN(v856, v857);
                  // pto: %293
                  ;
                  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v858;
                  TRESHAPE(v858, v854);
                  // pto: %294
                  ;
                  Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v859;
                  TRESHAPE(v859, v856);
                  pipe_barrier(PIPE_V);
                  TCI<Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v859, v62, v858);
                  // pto: %leaf_indices_inline6981__ssa_v1
                  ;
                  Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v860 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                  // pto: %leaf_indices_inline6981__ssa_v1
                  ;
                  uint64_t v861 = (uint64_t) v30;
                  TASSIGN(v860, v861);
                  pipe_barrier(PIPE_V);
                  TADDS(v860, v856, v749);
                  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                  // pto: %leaf_scores_raw_inline6982__ssa_v1
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v862 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v746);
                  // pto: %leaf_scores_raw_inline6982__ssa_v1
                  ;
                  uint64_t v863 = (uint64_t) v29;
                  TASSIGN(v862, v863);
                  // pto: %295, %296, %297
                  ;
                  int64_t v864 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v136) + (uint64_t) v56);
                  // pto: %298
                  ;
                  int64_t v865 = v864 < v45 ? v45 : v864;
                  // pto: %299
                  ;
                  const int64_t v866 = 0;
                  // pto: %299
                  ;
                  __gm__ float* v867 = PTOAS__GLOBAL_TENSOR_DATA(v97);
                  // pto: %299
                  ;
                  const int64_t v868 = 1;
                  // pto: %299
                  ;
                  const int64_t v869 = 1;
                  // pto: %299
                  ;
                  const int64_t v870 = 1;
                  // pto: %299
                  ;
                  int64_t v871 = v38 * v43;
                  // pto: %299
                  ;
                  int64_t v872 = v870 * v871;
                  // pto: %299
                  ;
                  pto::Shape<1, 1, 1, 1, -1> v873 = pto::Shape<1, 1, 1, 1, -1>(v868, v869, v870, v38, v746);
                  // pto: %299
                  ;
                  pto::Stride<-1, -1, -1, -1, -1> v874 = pto::Stride<-1, -1, -1, -1, -1>(v869 * v872, v872, v871, v43, v38);
                  // pto: %299
                  ;
                  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v875 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v867 + (v866 + v865 * v43 + v45 * v38), v873, v874);
                  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                  TLOAD(v862, v875);
                  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                  // pto: %leaf_scores_inline6983__ssa_v1
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v876 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                  // pto: %leaf_scores_inline6983__ssa_v1
                  ;
                  uint64_t v877 = (uint64_t) v29;
                  TASSIGN(v876, v877);
                  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                  TFILLPAD<pto::TFillPadMode::InPlace>(v876, v862);
                  // pto: %leaf_scores_v1_inline6984__ssa_v1
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v878 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                  // pto: %leaf_scores_v1_inline6984__ssa_v1
                  ;
                  uint64_t v879 = (uint64_t) v31;
                  TASSIGN(v878, v879);
                  pipe_barrier(PIPE_V);
                  TMAXS(v878, v876, v63);
                  // pto: %t__tmp_v826
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v880 = Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                  // pto: %t__tmp_v826
                  ;
                  uint64_t v881 = (uint64_t) v30;
                  TASSIGN(v880, v881);
                  // pto: %pairs_inline6985__ssa_v1
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v882 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                  // pto: %pairs_inline6985__ssa_v1
                  ;
                  uint64_t v883 = (uint64_t) v29;
                  TASSIGN(v882, v883);
                  // pto: %300
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v884;
                  TRESHAPE(v884, v878);
                  // pto: %301
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v885;
                  TRESHAPE(v885, v880);
                  // pto: %302
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v886;
                  TRESHAPE(v886, v882);
                  pipe_barrier(PIPE_V);
                  TSORT32(v886, v884, v885);
                  // pto: %pairs_v1_inline6986__ssa_v1
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v887 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                  // pto: %pairs_v1_inline6986__ssa_v1
                  ;
                  uint64_t v888 = (uint64_t) v30;
                  TASSIGN(v887, v888);
                  pipe_barrier(PIPE_V);
                  TMRGSORT(v887, v882, v64);
                  // pto: %pairs_v2_inline6987__ssa_v1
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v889 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                  // pto: %pairs_v2_inline6987__ssa_v1
                  ;
                  uint64_t v890 = (uint64_t) v29;
                  TASSIGN(v889, v890);
                  pipe_barrier(PIPE_V);
                  TMRGSORT(v889, v887, v65);
                  // pto: %pairs_v3_inline6988__ssa_v1
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v891 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                  // pto: %pairs_v3_inline6988__ssa_v1
                  ;
                  uint64_t v892 = (uint64_t) v30;
                  TASSIGN(v891, v892);
                  pipe_barrier(PIPE_V);
                  TMRGSORT(v891, v889, v67);
                  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                  // pto: %t__tmp_v827
                  ;
                  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v893 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                  // pto: %t__tmp_v827
                  ;
                  uint64_t v894 = (uint64_t) v30;
                  TASSIGN(v893, v894);
                  // pto: %303
                  ;
                  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v895;
                  // pto: %303
                  ;
                  uint64_t v896 = (uint64_t) v30;
                  TASSIGN(v895, v896);
                  // pto: %304
                  ;
                  int64_t v897 = v748 < v45 ? v45 : v748;
                  // pto: %305
                  ;
                  __gm__ float* v898 = PTOAS__GLOBAL_TENSOR_DATA(v105);
                  // pto: %305
                  ;
                  const int64_t v899 = 0;
                  // pto: %305
                  ;
                  const int64_t v900 = 1024;
                  // pto: %305
                  ;
                  pto::Shape<1, 1, 1, 1, 1024> v901 = pto::Shape<1, 1, 1, 1, 1024>();
                  // pto: %305
                  ;
                  pto::Stride<1024, 1024, 1024, 1024, 1> v902 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                  // pto: %305
                  ;
                  GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v903 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v898 + (v899 + v897 * v900), v901, v902);
                  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                  pipe_barrier(PIPE_MTE3);
                  TSTORE(v903, v895);
                } else {
                  // pto: %306
                  ;
                  if (v746 <= v68) {
                    // pto: %t__ci_tmp_v9
                    ;
                    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v904 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
                    // pto: %t__ci_tmp_v9
                    ;
                    uint64_t v905 = (uint64_t) v30;
                    TASSIGN(v904, v905);
                    // pto: %t__tmp_v828
                    ;
                    Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v906 = Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v68);
                    // pto: %t__tmp_v828
                    ;
                    uint64_t v907 = (uint64_t) v29;
                    TASSIGN(v906, v907);
                    // pto: %307
                    ;
                    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v908;
                    TRESHAPE(v908, v904);
                    // pto: %308
                    ;
                    Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v909;
                    TRESHAPE(v909, v906);
                    pipe_barrier(PIPE_V);
                    TCI<Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v909, v62, v908);
                    // pto: %partial_indices_inline6989__ssa_v1
                    ;
                    Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v910 = Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v68);
                    // pto: %partial_indices_inline6989__ssa_v1
                    ;
                    uint64_t v911 = (uint64_t) v30;
                    TASSIGN(v910, v911);
                    pipe_barrier(PIPE_V);
                    TADDS(v910, v906, v749);
                    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                    // pto: %partial_raw_inline6990__ssa_v1
                    ;
                    Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v912 = Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v746);
                    // pto: %partial_raw_inline6990__ssa_v1
                    ;
                    uint64_t v913 = (uint64_t) v29;
                    TASSIGN(v912, v913);
                    // pto: %309, %310, %311
                    ;
                    int64_t v914 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v136) + (uint64_t) v56);
                    // pto: %312
                    ;
                    int64_t v915 = v914 < v45 ? v45 : v914;
                    // pto: %313
                    ;
                    const int64_t v916 = 0;
                    // pto: %313
                    ;
                    __gm__ float* v917 = PTOAS__GLOBAL_TENSOR_DATA(v97);
                    // pto: %313
                    ;
                    const int64_t v918 = 1;
                    // pto: %313
                    ;
                    const int64_t v919 = 1;
                    // pto: %313
                    ;
                    const int64_t v920 = 1;
                    // pto: %313
                    ;
                    int64_t v921 = v38 * v43;
                    // pto: %313
                    ;
                    int64_t v922 = v920 * v921;
                    // pto: %313
                    ;
                    pto::Shape<1, 1, 1, 1, -1> v923 = pto::Shape<1, 1, 1, 1, -1>(v918, v919, v920, v38, v746);
                    // pto: %313
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v924 = pto::Stride<-1, -1, -1, -1, -1>(v919 * v922, v922, v921, v43, v38);
                    // pto: %313
                    ;
                    GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v925 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v917 + (v916 + v915 * v43 + v45 * v38), v923, v924);
                    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                    TLOAD(v912, v925);
                    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                    // pto: %partial_scores_inline6991__ssa_v1
                    ;
                    Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v926 = Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v68);
                    // pto: %partial_scores_inline6991__ssa_v1
                    ;
                    uint64_t v927 = (uint64_t) v29;
                    TASSIGN(v926, v927);
                    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                    TFILLPAD<pto::TFillPadMode::InPlace>(v926, v912);
                    // pto: %partial_scores_v1_inline6992__ssa_v1
                    ;
                    Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v928 = Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v68);
                    // pto: %partial_scores_v1_inline6992__ssa_v1
                    ;
                    uint64_t v929 = (uint64_t) v31;
                    TASSIGN(v928, v929);
                    pipe_barrier(PIPE_V);
                    TMAXS(v928, v926, v63);
                    // pto: %t__tmp_v829
                    ;
                    Tile<TileType::Vec, uint32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v930 = Tile<TileType::Vec, uint32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v68);
                    // pto: %t__tmp_v829
                    ;
                    uint64_t v931 = (uint64_t) v30;
                    TASSIGN(v930, v931);
                    // pto: %partial_pairs_inline6993__ssa_v1
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v932 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v69);
                    // pto: %partial_pairs_inline6993__ssa_v1
                    ;
                    uint64_t v933 = (uint64_t) v29;
                    TASSIGN(v932, v933);
                    // pto: %314
                    ;
                    Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v934;
                    TRESHAPE(v934, v928);
                    // pto: %315
                    ;
                    Tile<TileType::Vec, uint32_t, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v935;
                    TRESHAPE(v935, v930);
                    // pto: %316
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 5120, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v936;
                    TRESHAPE(v936, v932);
                    pipe_barrier(PIPE_V);
                    TSORT32(v936, v934, v935);
                    // pto: %partial_pairs_v1_inline6994__ssa_v1
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v937 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v69);
                    // pto: %partial_pairs_v1_inline6994__ssa_v1
                    ;
                    uint64_t v938 = (uint64_t) v30;
                    TASSIGN(v937, v938);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v937, v932, v64);
                    // pto: %partial_pairs_v2_inline6995__ssa_v1
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v939 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v69);
                    // pto: %partial_pairs_v2_inline6995__ssa_v1
                    ;
                    uint64_t v940 = (uint64_t) v29;
                    TASSIGN(v939, v940);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v939, v937, v65);
                    v939.SetValidShape(v38, v54);
                    // pto: %partial_prefix_v1_inline6997__ssa_v1
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v941 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v69);
                    // pto: %partial_prefix_v1_inline6997__ssa_v1
                    ;
                    uint64_t v942 = (uint64_t) v30;
                    TASSIGN(v941, v942);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v941, v939, v67);
                    // pto: %partial_left_inline6998__ssa_v1
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v943 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                    // pto: %partial_left_inline6998__ssa_v1
                    ;
                    uint64_t v944 = (uint64_t) v30;
                    TASSIGN(v943, v944);
                    // pto: %317
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v945;
                    // pto: %317
                    ;
                    uint64_t v946 = (uint64_t) v30;
                    TASSIGN(v945, v946);
                    // pto: %partial_right_inline6999__ssa_v1
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v947 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                    // pto: %partial_right_inline6999__ssa_v1
                    ;
                    uint64_t v948 = (uint64_t) v34;
                    TASSIGN(v947, v948);
                    // pto: %318
                    ;
                    Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v949;
                    // pto: %318
                    ;
                    uint64_t v950 = (uint64_t) v34;
                    TASSIGN(v949, v950);
                    // pto: %partial_tmp_inline7000__ssa_v1
                    ;
                    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v951 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                    // pto: %partial_tmp_inline7000__ssa_v1
                    ;
                    uint64_t v952 = (uint64_t) v31;
                    TASSIGN(v951, v952);
                    // pto: %partial_merged_inline7001__ssa_v1
                    ;
                    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v953 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                    // pto: %partial_merged_inline7001__ssa_v1
                    ;
                    uint64_t v954 = (uint64_t) v35;
                    TASSIGN(v953, v954);
                    pipe_barrier(PIPE_V);
                    TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v953, v28, v951, v949, v945);
                    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                    // pto: %t__tmp_v830
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v955 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                    // pto: %t__tmp_v830
                    ;
                    uint64_t v956 = (uint64_t) v35;
                    TASSIGN(v955, v956);
                    // pto: %320
                    ;
                    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v957;
                    // pto: %320
                    ;
                    uint64_t v958 = (uint64_t) v35;
                    TASSIGN(v957, v958);
                    // pto: %321
                    ;
                    int64_t v959 = v748 < v45 ? v45 : v748;
                    // pto: %322
                    ;
                    __gm__ float* v960 = PTOAS__GLOBAL_TENSOR_DATA(v105);
                    // pto: %322
                    ;
                    const int64_t v961 = 0;
                    // pto: %322
                    ;
                    const int64_t v962 = 1024;
                    // pto: %322
                    ;
                    pto::Shape<1, 1, 1, 1, 1024> v963 = pto::Shape<1, 1, 1, 1, 1024>();
                    // pto: %322
                    ;
                    pto::Stride<1024, 1024, 1024, 1024, 1> v964 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                    // pto: %322
                    ;
                    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v965 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v960 + (v961 + v959 * v962), v963, v964);
                    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                    TSTORE(v965, v957);
                  } else {
                    // pto: %323
                    ;
                    if (v746 <= v70) {
                      // pto: %t__ci_tmp_v10
                      ;
                      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v966 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
                      // pto: %t__ci_tmp_v10
                      ;
                      uint64_t v967 = (uint64_t) v30;
                      TASSIGN(v966, v967);
                      // pto: %t__tmp_v831
                      ;
                      Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v968 = Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v70);
                      // pto: %t__tmp_v831
                      ;
                      uint64_t v969 = (uint64_t) v29;
                      TASSIGN(v968, v969);
                      // pto: %324
                      ;
                      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v970;
                      TRESHAPE(v970, v966);
                      // pto: %325
                      ;
                      Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v971;
                      TRESHAPE(v971, v968);
                      pipe_barrier(PIPE_V);
                      TCI<Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v971, v62, v970);
                      // pto: %triple_indices_inline7002__ssa_v1
                      ;
                      Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v972 = Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v70);
                      // pto: %triple_indices_inline7002__ssa_v1
                      ;
                      uint64_t v973 = (uint64_t) v30;
                      TASSIGN(v972, v973);
                      pipe_barrier(PIPE_V);
                      TADDS(v972, v968, v749);
                      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                      // pto: %triple_raw_inline7003__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v974 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v746);
                      // pto: %triple_raw_inline7003__ssa_v1
                      ;
                      uint64_t v975 = (uint64_t) v29;
                      TASSIGN(v974, v975);
                      // pto: %326, %327, %328
                      ;
                      int64_t v976 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v136) + (uint64_t) v56);
                      // pto: %329
                      ;
                      int64_t v977 = v976 < v45 ? v45 : v976;
                      // pto: %330
                      ;
                      const int64_t v978 = 0;
                      // pto: %330
                      ;
                      __gm__ float* v979 = PTOAS__GLOBAL_TENSOR_DATA(v97);
                      // pto: %330
                      ;
                      const int64_t v980 = 1;
                      // pto: %330
                      ;
                      const int64_t v981 = 1;
                      // pto: %330
                      ;
                      const int64_t v982 = 1;
                      // pto: %330
                      ;
                      int64_t v983 = v38 * v43;
                      // pto: %330
                      ;
                      int64_t v984 = v982 * v983;
                      // pto: %330
                      ;
                      pto::Shape<1, 1, 1, 1, -1> v985 = pto::Shape<1, 1, 1, 1, -1>(v980, v981, v982, v38, v746);
                      // pto: %330
                      ;
                      pto::Stride<-1, -1, -1, -1, -1> v986 = pto::Stride<-1, -1, -1, -1, -1>(v981 * v984, v984, v983, v43, v38);
                      // pto: %330
                      ;
                      GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v987 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v979 + (v978 + v977 * v43 + v45 * v38), v985, v986);
                      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                      TLOAD(v974, v987);
                      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                      // pto: %triple_scores_inline7004__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v988 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v70);
                      // pto: %triple_scores_inline7004__ssa_v1
                      ;
                      uint64_t v989 = (uint64_t) v29;
                      TASSIGN(v988, v989);
                      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                      TFILLPAD<pto::TFillPadMode::InPlace>(v988, v974);
                      // pto: %triple_scores_v1_inline7005__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v990 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v70);
                      // pto: %triple_scores_v1_inline7005__ssa_v1
                      ;
                      uint64_t v991 = (uint64_t) v31;
                      TASSIGN(v990, v991);
                      pipe_barrier(PIPE_V);
                      TMAXS(v990, v988, v63);
                      // pto: %t__tmp_v832
                      ;
                      Tile<TileType::Vec, uint32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v992 = Tile<TileType::Vec, uint32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v70);
                      // pto: %t__tmp_v832
                      ;
                      uint64_t v993 = (uint64_t) v30;
                      TASSIGN(v992, v993);
                      // pto: %triple_pairs_inline7006__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v994 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v71);
                      // pto: %triple_pairs_inline7006__ssa_v1
                      ;
                      uint64_t v995 = (uint64_t) v29;
                      TASSIGN(v994, v995);
                      // pto: %331
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v996;
                      TRESHAPE(v996, v990);
                      // pto: %332
                      ;
                      Tile<TileType::Vec, uint32_t, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v997;
                      TRESHAPE(v997, v992);
                      // pto: %333
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 6144, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v998;
                      TRESHAPE(v998, v994);
                      pipe_barrier(PIPE_V);
                      TSORT32(v998, v996, v997);
                      // pto: %triple_pairs_v1_inline7007__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v999 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v71);
                      // pto: %triple_pairs_v1_inline7007__ssa_v1
                      ;
                      uint64_t v1000 = (uint64_t) v30;
                      TASSIGN(v999, v1000);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v999, v994, v64);
                      // pto: %triple_pairs_v2_inline7008__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1001 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v71);
                      // pto: %triple_pairs_v2_inline7008__ssa_v1
                      ;
                      uint64_t v1002 = (uint64_t) v29;
                      TASSIGN(v1001, v1002);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v1001, v999, v65);
                      v1001.SetValidShape(v38, v54);
                      // pto: %triple_prefix_v1_inline7010__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1003 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v71);
                      // pto: %triple_prefix_v1_inline7010__ssa_v1
                      ;
                      uint64_t v1004 = (uint64_t) v30;
                      TASSIGN(v1003, v1004);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v1003, v1001, v67);
                      // pto: %triple_left_inline7011__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1005 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %triple_left_inline7011__ssa_v1
                      ;
                      uint64_t v1006 = (uint64_t) v30;
                      TASSIGN(v1005, v1006);
                      // pto: %334
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1007;
                      // pto: %334
                      ;
                      uint64_t v1008 = (uint64_t) v30;
                      TASSIGN(v1007, v1008);
                      // pto: %triple_right0_inline7012__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1009 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %triple_right0_inline7012__ssa_v1
                      ;
                      uint64_t v1010 = (uint64_t) v34;
                      TASSIGN(v1009, v1010);
                      // pto: %335
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1011;
                      // pto: %335
                      ;
                      uint64_t v1012 = (uint64_t) v34;
                      TASSIGN(v1011, v1012);
                      // pto: %triple_right1_inline7013__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1013 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %triple_right1_inline7013__ssa_v1
                      ;
                      uint64_t v1014 = (uint64_t) v36;
                      TASSIGN(v1013, v1014);
                      // pto: %336
                      ;
                      Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1015;
                      // pto: %336
                      ;
                      uint64_t v1016 = (uint64_t) v36;
                      TASSIGN(v1015, v1016);
                      // pto: %triple_tmp_inline7014__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1017 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v70);
                      // pto: %triple_tmp_inline7014__ssa_v1
                      ;
                      uint64_t v1018 = (uint64_t) v31;
                      TASSIGN(v1017, v1018);
                      // pto: %triple_merged_inline7015__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1019 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v70);
                      // pto: %triple_merged_inline7015__ssa_v1
                      ;
                      uint64_t v1020 = (uint64_t) v35;
                      TASSIGN(v1019, v1020);
                      pipe_barrier(PIPE_V);
                      TMRGSORT<Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v1019, v28, v1017, v1011, v1015, v1007);
                      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                      // pto: %t__tmp_v833
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1021 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %t__tmp_v833
                      ;
                      uint64_t v1022 = (uint64_t) v35;
                      TASSIGN(v1021, v1022);
                      // pto: %338
                      ;
                      Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1023;
                      // pto: %338
                      ;
                      uint64_t v1024 = (uint64_t) v35;
                      TASSIGN(v1023, v1024);
                      // pto: %339
                      ;
                      int64_t v1025 = v748 < v45 ? v45 : v748;
                      // pto: %340
                      ;
                      __gm__ float* v1026 = PTOAS__GLOBAL_TENSOR_DATA(v105);
                      // pto: %340
                      ;
                      const int64_t v1027 = 0;
                      // pto: %340
                      ;
                      const int64_t v1028 = 1024;
                      // pto: %340
                      ;
                      pto::Shape<1, 1, 1, 1, 1024> v1029 = pto::Shape<1, 1, 1, 1, 1024>();
                      // pto: %340
                      ;
                      pto::Stride<1024, 1024, 1024, 1024, 1> v1030 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                      // pto: %340
                      ;
                      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v1031 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v1026 + (v1027 + v1025 * v1028), v1029, v1030);
                      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                      TSTORE(v1031, v1023);
                    } else {
                      // pto: %t__ci_tmp_v11
                      ;
                      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1032 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v61);
                      // pto: %t__ci_tmp_v11
                      ;
                      uint64_t v1033 = (uint64_t) v30;
                      TASSIGN(v1032, v1033);
                      // pto: %t__tmp_v834
                      ;
                      Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1034 = Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v54);
                      // pto: %t__tmp_v834
                      ;
                      uint64_t v1035 = (uint64_t) v29;
                      TASSIGN(v1034, v1035);
                      // pto: %341
                      ;
                      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1036;
                      TRESHAPE(v1036, v1032);
                      // pto: %342
                      ;
                      Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1037;
                      TRESHAPE(v1037, v1034);
                      pipe_barrier(PIPE_V);
                      TCI<Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v1037, v62, v1036);
                      // pto: %medium_indices_inline7016__ssa_v1
                      ;
                      Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1038 = Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v54);
                      // pto: %medium_indices_inline7016__ssa_v1
                      ;
                      uint64_t v1039 = (uint64_t) v30;
                      TASSIGN(v1038, v1039);
                      pipe_barrier(PIPE_V);
                      TADDS(v1038, v1034, v749);
                      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                      // pto: %medium_scores_raw_inline7017__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1040 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v746);
                      // pto: %medium_scores_raw_inline7017__ssa_v1
                      ;
                      uint64_t v1041 = (uint64_t) v29;
                      TASSIGN(v1040, v1041);
                      // pto: %343, %344, %345
                      ;
                      int64_t v1042 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v46) + (uint64_t) v136) + (uint64_t) v56);
                      // pto: %346
                      ;
                      int64_t v1043 = v1042 < v45 ? v45 : v1042;
                      // pto: %347
                      ;
                      const int64_t v1044 = 0;
                      // pto: %347
                      ;
                      __gm__ float* v1045 = PTOAS__GLOBAL_TENSOR_DATA(v97);
                      // pto: %347
                      ;
                      const int64_t v1046 = 1;
                      // pto: %347
                      ;
                      const int64_t v1047 = 1;
                      // pto: %347
                      ;
                      const int64_t v1048 = 1;
                      // pto: %347
                      ;
                      int64_t v1049 = v38 * v43;
                      // pto: %347
                      ;
                      int64_t v1050 = v1048 * v1049;
                      // pto: %347
                      ;
                      pto::Shape<1, 1, 1, 1, -1> v1051 = pto::Shape<1, 1, 1, 1, -1>(v1046, v1047, v1048, v38, v746);
                      // pto: %347
                      ;
                      pto::Stride<-1, -1, -1, -1, -1> v1052 = pto::Stride<-1, -1, -1, -1, -1>(v1047 * v1050, v1050, v1049, v43, v38);
                      // pto: %347
                      ;
                      GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1053 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1045 + (v1044 + v1043 * v43 + v45 * v38), v1051, v1052);
                      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                      TLOAD(v1040, v1053);
                      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                      // pto: %medium_scores_inline7018__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1054 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                      // pto: %medium_scores_inline7018__ssa_v1
                      ;
                      uint64_t v1055 = (uint64_t) v29;
                      TASSIGN(v1054, v1055);
                      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                      TFILLPAD<pto::TFillPadMode::InPlace>(v1054, v1040);
                      // pto: %medium_scores_v1_inline7019__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1056 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v54);
                      // pto: %medium_scores_v1_inline7019__ssa_v1
                      ;
                      uint64_t v1057 = (uint64_t) v31;
                      TASSIGN(v1056, v1057);
                      pipe_barrier(PIPE_V);
                      TMAXS(v1056, v1054, v63);
                      // pto: %t__tmp_v835
                      ;
                      Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1058 = Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v54);
                      // pto: %t__tmp_v835
                      ;
                      uint64_t v1059 = (uint64_t) v30;
                      TASSIGN(v1058, v1059);
                      // pto: %medium_pairs_inline7020__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1060 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v43);
                      // pto: %medium_pairs_inline7020__ssa_v1
                      ;
                      uint64_t v1061 = (uint64_t) v29;
                      TASSIGN(v1060, v1061);
                      // pto: %348
                      ;
                      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1062;
                      TRESHAPE(v1062, v1056);
                      // pto: %349
                      ;
                      Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1063;
                      TRESHAPE(v1063, v1058);
                      // pto: %350
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 8192, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1064;
                      TRESHAPE(v1064, v1060);
                      pipe_barrier(PIPE_V);
                      TSORT32(v1064, v1062, v1063);
                      // pto: %medium_pairs_v1_inline7021__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1065 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v43);
                      // pto: %medium_pairs_v1_inline7021__ssa_v1
                      ;
                      uint64_t v1066 = (uint64_t) v30;
                      TASSIGN(v1065, v1066);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v1065, v1060, v64);
                      // pto: %medium_pairs_v2_inline7022__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1067 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v43);
                      // pto: %medium_pairs_v2_inline7022__ssa_v1
                      ;
                      uint64_t v1068 = (uint64_t) v29;
                      TASSIGN(v1067, v1068);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v1067, v1065, v65);
                      // pto: %medium_pairs_v3_inline7023__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1069 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v43);
                      // pto: %medium_pairs_v3_inline7023__ssa_v1
                      ;
                      uint64_t v1070 = (uint64_t) v30;
                      TASSIGN(v1069, v1070);
                      pipe_barrier(PIPE_V);
                      TMRGSORT(v1069, v1067, v67);
                      // pto: %medium_left_inline7024__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1071 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %medium_left_inline7024__ssa_v1
                      ;
                      uint64_t v1072 = (uint64_t) v30;
                      TASSIGN(v1071, v1072);
                      // pto: %351
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1073;
                      // pto: %351
                      ;
                      uint64_t v1074 = (uint64_t) v30;
                      TASSIGN(v1073, v1074);
                      // pto: %medium_right_inline7025__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1075 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %medium_right_inline7025__ssa_v1
                      ;
                      uint64_t v1076 = (uint64_t) v37;
                      TASSIGN(v1075, v1076);
                      // pto: %352
                      ;
                      Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1077;
                      // pto: %352
                      ;
                      uint64_t v1078 = (uint64_t) v37;
                      TASSIGN(v1077, v1078);
                      // pto: %medium_tmp_inline7026__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1079 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v66);
                      // pto: %medium_tmp_inline7026__ssa_v1
                      ;
                      uint64_t v1080 = (uint64_t) v29;
                      TASSIGN(v1079, v1080);
                      // pto: %medium_merged_inline7027__ssa_v1
                      ;
                      Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1081 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v66);
                      // pto: %medium_merged_inline7027__ssa_v1
                      ;
                      uint64_t v1082 = (uint64_t) v31;
                      TASSIGN(v1081, v1082);
                      pipe_barrier(PIPE_V);
                      TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v1081, v28, v1079, v1077, v1073);
                      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                      // pto: %t__tmp_v836
                      ;
                      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1083 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v44);
                      // pto: %t__tmp_v836
                      ;
                      uint64_t v1084 = (uint64_t) v31;
                      TASSIGN(v1083, v1084);
                      // pto: %354
                      ;
                      Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1085;
                      // pto: %354
                      ;
                      uint64_t v1086 = (uint64_t) v31;
                      TASSIGN(v1085, v1086);
                      // pto: %355
                      ;
                      int64_t v1087 = v748 < v45 ? v45 : v748;
                      // pto: %356
                      ;
                      __gm__ float* v1088 = PTOAS__GLOBAL_TENSOR_DATA(v105);
                      // pto: %356
                      ;
                      const int64_t v1089 = 0;
                      // pto: %356
                      ;
                      const int64_t v1090 = 1024;
                      // pto: %356
                      ;
                      pto::Shape<1, 1, 1, 1, 1024> v1091 = pto::Shape<1, 1, 1, 1, 1024>();
                      // pto: %356
                      ;
                      pto::Stride<1024, 1024, 1024, 1024, 1> v1092 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                      // pto: %356
                      ;
                      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v1093 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v1088 + (v1089 + v1087 * v1090), v1091, v1092);
                      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                      pipe_barrier(PIPE_MTE3);
                      TSTORE(v1093, v1085);
                    };
                  };
                };
              };
            };
          } else {
            // pto: %t__tmp_v837
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1094 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v44);
            // pto: %t__tmp_v837
            ;
            uint64_t v1095 = (uint64_t) v29;
            TASSIGN(v1094, v1095);
            pipe_barrier(PIPE_V);
            TEXPANDS(v1094, v63);
            set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
            // pto: %357
            ;
            int64_t v1096 = v748 < v45 ? v45 : v748;
            // pto: %358
            ;
            __gm__ float* v1097 = PTOAS__GLOBAL_TENSOR_DATA(v105);
            // pto: %358
            ;
            const int64_t v1098 = 0;
            // pto: %358
            ;
            const int64_t v1099 = 1024;
            // pto: %358
            ;
            pto::Shape<1, 1, 1, 1, 1024> v1100 = pto::Shape<1, 1, 1, 1, 1024>();
            // pto: %358
            ;
            pto::Stride<1024, 1024, 1024, 1024, 1> v1101 = pto::Stride<1024, 1024, 1024, 1024, 1>();
            // pto: %358
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v1102 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v1097 + (v1098 + v1096 * v1099), v1100, v1101);
            wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
            pipe_barrier(PIPE_MTE3);
            TSTORE(v1102, v1094);
          };
        };
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    };
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}