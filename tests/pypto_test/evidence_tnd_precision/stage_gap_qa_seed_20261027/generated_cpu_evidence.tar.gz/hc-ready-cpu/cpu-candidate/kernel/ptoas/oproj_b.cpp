#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_b(__gm__ int8_t* v1, __gm__ int8_t* v2, __gm__ int32_t* v3, int64_t v4, int64_t v5, int64_t v6, int32_t v7, int32_t v8) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v9 = 0;
  // pto: %c8192_i64
  const int64_t v10 = 8192;
  // pto: %c4096_i64
  const int64_t v11 = 4096;
  // pto: %c32768_i64
  const int64_t v12 = 32768;
  // pto: %c8192_index
  const int64_t v13 = 8192;
  // pto: %c1_index
  const int64_t v14 = 1;
  // pto: %c128_index
  const int64_t v15 = 128;
  // pto: %c512_index
  const int64_t v16 = 512;
  // pto: %c16_index
  const int64_t v17 = 16;
  // pto: %c32_index
  const int64_t v18 = 32;
  // pto: %c33554432_index
  const int64_t v19 = 33554432;
  // pto: %c262144_index
  const int64_t v20 = 262144;
  // pto: %c4096_index
  const int64_t v21 = 4096;
  // pto: %c0_index
  const int64_t v22 = 0;
  // pto: %c256_index
  const int64_t v23 = 256;
  // pto: %c63_index
  const int64_t v24 = 63;
  // pto: %quantized_o__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %quantized_o__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %quantized_o__ssa_v0_view
  const int64_t v27 = 1;
  // pto: %quantized_o__ssa_v0_view
  int64_t v28 = (int64_t) v5;
  // pto: %quantized_o__ssa_v0_view
  int64_t v29 = v28 * v13;
  // pto: %quantized_o__ssa_v0_view
  int64_t v30 = v27 * v29;
  // pto: %quantized_o__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v31 = pto::Shape<1, 1, 1, -1, -1>(v25, v26, v27, v28, v13);
  // pto: %quantized_o__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v32 = pto::Stride<-1, -1, -1, -1, -1>(v26 * v30, v30, v29, v13, v14);
  // pto: %quantized_o__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v33 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v31, v32);
  // pto: %wo_b__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v34 = pto::Shape<-1, -1, -1, -1, -1>(v14, v15, v16, v17, v18);
  // pto: %wo_b__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v35 = pto::Stride<-1, -1, -1, -1, -1>(v19, v20, v16, v18, v14);
  // pto: %wo_b__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v36 = GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v2, v34, v35);
  // pto: %23
  int64_t v37 = (int64_t) ((uint64_t) v6 + (uint64_t) v24);
  // pto: %integer_accum_inline7498__ssa_v0_view
  const int64_t v38 = 1;
  // pto: %integer_accum_inline7498__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %integer_accum_inline7498__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %integer_accum_inline7498__ssa_v0_view
  int64_t v41 = v37 * v21;
  // pto: %integer_accum_inline7498__ssa_v0_view
  int64_t v42 = v40 * v41;
  // pto: %integer_accum_inline7498__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v43 = pto::Shape<1, 1, 1, -1, -1>(v38, v39, v40, v37, v21);
  // pto: %integer_accum_inline7498__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v44 = pto::Stride<-1, -1, -1, -1, -1>(v39 * v42, v42, v41, v21, v14);
  // pto: %integer_accum_inline7498__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v45 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v43, v44);
  // pto: %block_inline7499__ssa_v0
  int64_t v46 = (int64_t) v7;
  // pto: %3
  const int64_t v47 = 1;
  // pto: %3
  const int64_t v48 = 0;
  // pto: %3
  int64_t v49 = v46 / v18;
  // pto: %3
  bool v50 = v46 < v48;
  // pto: %3
  bool v51 = v18 < v48;
  // pto: %3
  bool v52 = v50 == v51;
  // pto: %3
  bool v53 = v46 % v18 != v48 && v50 != v51;
  // pto: %3
  int64_t v54 = v53 ? v49 - v47 : v49;
  // pto: %4
  int64_t v55 = (int64_t) ((uint64_t) v54 * (uint64_t) v17);
  // pto: %5
  int64_t v56 = v46 % v18;
  // pto: %6, %7, %8
  int64_t v57 = v56 < v22 ? (int64_t) ((uint64_t) v56 + (uint64_t) v18) : v56;
  // pto: %9
  int64_t v58 = (int64_t) ((uint64_t) v57 * (uint64_t) v15);
  // pto: %10
  int64_t v59 = (int64_t) ((uint64_t) v6 - (uint64_t) v55);
  // pto: %b_acc_inline7500__tile
  Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v60 = Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v17, v15);
  // pto: %b_acc_inline7500__tile
  uint64_t v61 = (uint64_t) v9;
  TASSIGN(v60, v61);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  for (int64_t v62 = v22; v62 < v17; v62 += v14) {
    // pto: %11
    ;
    int64_t v63 = (int64_t) ((uint64_t) v62 * (uint64_t) v16);
    // pto: %b_input_inline7503__tile
    ;
    Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v64 = Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v59, v16);
    // pto: %b_input_inline7503__tile
    ;
    uint64_t v65 = (uint64_t) v9;
    TASSIGN(v64, v65);
    // pto: %12
    ;
    int64_t v66 = v55 < v22 ? v22 : v55;
    // pto: %13
    ;
    int64_t v67 = v63 < v22 ? v22 : v63;
    // pto: %quantized_o__ssa_v0_pview
    ;
    const int64_t v68 = 0;
    // pto: %quantized_o__ssa_v0_pview
    ;
    __gm__ int8_t* v69 = PTOAS__GLOBAL_TENSOR_DATA(v33);
    // pto: %quantized_o__ssa_v0_pview
    ;
    const int64_t v70 = 1;
    // pto: %quantized_o__ssa_v0_pview
    ;
    const int64_t v71 = 1;
    // pto: %quantized_o__ssa_v0_pview
    ;
    const int64_t v72 = 1;
    // pto: %quantized_o__ssa_v0_pview
    ;
    int64_t v73 = v59 * v13;
    // pto: %quantized_o__ssa_v0_pview
    ;
    int64_t v74 = v72 * v73;
    // pto: %quantized_o__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v75 = pto::Shape<1, 1, 1, -1, 512>(v70, v71, v72, v59, v16);
    // pto: %quantized_o__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v76 = pto::Stride<-1, -1, -1, -1, -1>(v71 * v74, v74, v73, v13, v14);
    // pto: %quantized_o__ssa_v0_pview
    ;
    GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v77 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v69 + (v68 + v66 * v13 + v67 * v14), v75, v76);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v64, v77);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    // pto: %b_weight_inline7504__tile
    ;
    Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v78 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v15);
    // pto: %b_weight_inline7504__tile
    ;
    uint64_t v79 = (uint64_t) v10;
    TASSIGN(v78, v79);
    // pto: %14
    ;
    const int64_t v80 = 1;
    // pto: %14
    ;
    const int64_t v81 = 0;
    // pto: %14
    ;
    int64_t v82 = v58 / v18;
    // pto: %14
    ;
    bool v83 = v58 < v81;
    // pto: %14
    ;
    bool v84 = v18 < v81;
    // pto: %14
    ;
    bool v85 = v83 == v84;
    // pto: %14
    ;
    bool v86 = v58 % v18 != v81 && v83 != v84;
    // pto: %14
    ;
    int64_t v87 = v86 ? v82 - v80 : v82;
    // pto: %15
    ;
    int64_t v88 = v87 < v22 ? v22 : v87;
    // pto: %16
    ;
    const int64_t v89 = 1;
    // pto: %16
    ;
    const int64_t v90 = 0;
    // pto: %16
    ;
    int64_t v91 = v63 / v17;
    // pto: %16
    ;
    bool v92 = v63 < v90;
    // pto: %16
    ;
    bool v93 = v17 < v90;
    // pto: %16
    ;
    bool v94 = v92 == v93;
    // pto: %16
    ;
    bool v95 = v63 % v17 != v90 && v92 != v93;
    // pto: %16
    ;
    int64_t v96 = v95 ? v91 - v89 : v91;
    // pto: %17
    ;
    int64_t v97 = v96 < v22 ? v22 : v96;
    // pto: %wo_b__ssa_v0_pview
    ;
    __gm__ int8_t* v98 = PTOAS__GLOBAL_TENSOR_DATA(v36);
    // pto: %wo_b__ssa_v0_pview
    ;
    const int64_t v99 = 0;
    // pto: %wo_b__ssa_v0_pview
    ;
    const int64_t v100 = 262144;
    // pto: %wo_b__ssa_v0_pview
    ;
    const int64_t v101 = 512;
    // pto: %wo_b__ssa_v0_pview
    ;
    pto::Shape<1, 4, 32, 16, 32> v102 = pto::Shape<1, 4, 32, 16, 32>();
    // pto: %wo_b__ssa_v0_pview
    ;
    pto::Stride<33554432, 262144, 512, 32, 1> v103 = pto::Stride<33554432, 262144, 512, 32, 1>();
    // pto: %wo_b__ssa_v0_pview
    ;
    GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v104 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v98 + (v99 + v88 * v100 + v97 * v101), v102, v103);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    TLOAD(v78, v104);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    // pto: %18
    ;
    int64_t v105 = v59 < v17 ? v59 : v17;
    // pto: %b_acc_inline7500__tile_l0_a
    ;
    Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v106 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v105, v23);
    // pto: %b_acc_inline7500__tile_l0_a
    ;
    uint64_t v107 = (uint64_t) v9;
    TASSIGN(v106, v107);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    uint16_t v108 = static_cast<uint16_t>(v22);
    uint16_t v109 = static_cast<uint16_t>(v22);
    TEXTRACT(v106, v64, v108, v109);
    // pto: %b_acc_inline7500__tile_l0_b
    ;
    Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v15);
    // pto: %b_acc_inline7500__tile_l0_b
    ;
    uint64_t v111 = (uint64_t) v9;
    TASSIGN(v110, v111);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    uint16_t v112 = static_cast<uint16_t>(v22);
    uint16_t v113 = static_cast<uint16_t>(v22);
    TEXTRACT(v110, v78, v112, v113);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    // pto: %0
    ;
    Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v114 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v105, v23);
    // pto: %0
    ;
    uint64_t v115 = (uint64_t) v11;
    TASSIGN(v114, v115);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    uint16_t v116 = static_cast<uint16_t>(v22);
    uint16_t v117 = static_cast<uint16_t>(v23);
    TEXTRACT(v114, v64, v116, v117);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    // pto: %1
    ;
    Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v118 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v15);
    // pto: %1
    ;
    uint64_t v119 = (uint64_t) v12;
    TASSIGN(v118, v119);
    uint16_t v120 = static_cast<uint16_t>(v23);
    uint16_t v121 = static_cast<uint16_t>(v22);
    TEXTRACT(v118, v78, v120, v121);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
    // pto: %20
    ;
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    if (v62 == v22) {
      pipe_barrier(PIPE_M);
      TMATMUL(v60, v106, v110);
    } else {
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v60, v60, v106, v110);
    };
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    pipe_barrier(PIPE_M);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
    TMATMUL_ACC(v60, v60, v114, v118);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  }
  set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  // pto: %21
  int64_t v122 = v55 < v22 ? v22 : v55;
  // pto: %22
  int64_t v123 = v58 < v22 ? v22 : v58;
  // pto: %integer_accum_inline7498__ssa_v0_pview
  __gm__ int32_t* v124 = PTOAS__GLOBAL_TENSOR_DATA(v45);
  // pto: %integer_accum_inline7498__ssa_v0_pview
  const int64_t v125 = 0;
  // pto: %integer_accum_inline7498__ssa_v0_pview
  const int64_t v126 = 4096;
  // pto: %integer_accum_inline7498__ssa_v0_pview
  pto::Shape<1, 1, 1, 16, 128> v127 = pto::Shape<1, 1, 1, 16, 128>();
  // pto: %integer_accum_inline7498__ssa_v0_pview
  pto::Stride<65536, 65536, 65536, 4096, 1> v128 = pto::Stride<65536, 65536, 65536, 4096, 1>();
  // pto: %integer_accum_inline7498__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v129 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v124 + (v125 + v122 * v126 + v123), v127, v128);
  wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  TSTORE(v129, v60);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}