#include "pto/pto-inst.hpp"
using namespace pto;

enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void csa_row_offsets(__gm__ int32_t* v1, __gm__ int32_t* v2, __gm__ int32_t* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, __gm__ int32_t* v7, __gm__ int32_t* v8, int64_t v9, int64_t v10, int64_t v11) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c1_index
  const int64_t v12 = 1;
  // pto: %c0_index
  const int64_t v13 = 0;
  // pto: %c4_index
  const int64_t v14 = 4;
  // pto: %cn1_i32
  const int32_t v15 = -1;
  // pto: %prefix_inline4867__rv_v2
  int64_t v16;
  v16 = v13;
  for (int64_t v17 = v13; v17 < v9; v17 += v12) {
    // pto: %begin_inline4869__tile
    ;
    int32_t v18 = (v2)[v17];
    // pto: %0, %end_inline4870__tile
    ;
    int32_t v19 = (v2)[(int64_t) ((uint64_t) v17 + (uint64_t) v12)];
    // pto: %length_inline4871__tile
    ;
    int32_t v20 = (v1)[v17];
    // pto: %1, %2, %3
    ;
    int64_t v21 = (int64_t) ((int32_t) (uint32_t) ((int32_t) (uint32_t) v20 + (uint32_t) v18) - (uint32_t) v19);
    // pto: %4
    ;
    const int64_t v22 = 1;
    // pto: %4
    ;
    const int64_t v23 = 0;
    // pto: %4
    ;
    int64_t v24 = v21 / v14;
    // pto: %4
    ;
    bool v25 = v21 < v23;
    // pto: %4
    ;
    bool v26 = v14 < v23;
    // pto: %4
    ;
    bool v27 = v25 == v26;
    // pto: %4
    ;
    bool v28 = v21 % v14 != v23 && v25 != v26;
    // pto: %4
    ;
    int64_t v29 = v28 ? v24 - v22 : v24;
    // pto: %5
    ;
    uint64_t v30 = (uint64_t) v16;
    // pto: %5, %6, %7
    ;
    int32_t v31 = (int32_t) ((int64_t) (uint64_t) ((int64_t) v30 - (uint64_t) v29) - (uint64_t) v12);
    (v3)[v17] = v31;
    // pto: %8
    ;
    int64_t v32 = (int64_t) v20;
    // pto: %9
    ;
    const int64_t v33 = 1;
    // pto: %9
    ;
    const int64_t v34 = 0;
    // pto: %9
    ;
    int64_t v35 = v32 / v14;
    // pto: %9
    ;
    bool v36 = v32 < v34;
    // pto: %9
    ;
    bool v37 = v14 < v34;
    // pto: %9
    ;
    bool v38 = v36 == v37;
    // pto: %9
    ;
    bool v39 = v32 % v14 != v34 && v36 != v37;
    // pto: %9
    ;
    int64_t v40 = v39 ? v35 - v33 : v35;
    // pto: %10
    ;
    uint64_t v41 = (uint64_t) v16;
    // pto: %10, %13
    ;
    v16 = (int64_t) ((uint64_t) ((int64_t) v41 + (uint64_t) v40) - (uint64_t) v29);
  }
  // pto: %prefix_inline4873__rv_v2
  int64_t v42;
  v42 = v13;
  for (int64_t v43 = v13; v43 < v9; v43 += v12) {
    // pto: %begin_inline4875__tile
    ;
    int32_t v44 = (v5)[v43];
    // pto: %14, %end_inline4876__tile
    ;
    int32_t v45 = (v5)[(int64_t) ((uint64_t) v43 + (uint64_t) v12)];
    // pto: %length_inline4877__tile
    ;
    int32_t v46 = (v4)[v43];
    // pto: %15, %16, %17
    ;
    int64_t v47 = (int64_t) ((int32_t) (uint32_t) ((int32_t) (uint32_t) v46 + (uint32_t) v44) - (uint32_t) v45);
    // pto: %18
    ;
    const int64_t v48 = 1;
    // pto: %18
    ;
    const int64_t v49 = 0;
    // pto: %18
    ;
    int64_t v50 = v47 / v14;
    // pto: %18
    ;
    bool v51 = v47 < v49;
    // pto: %18
    ;
    bool v52 = v14 < v49;
    // pto: %18
    ;
    bool v53 = v51 == v52;
    // pto: %18
    ;
    bool v54 = v47 % v14 != v49 && v51 != v52;
    // pto: %18
    ;
    int64_t v55 = v54 ? v50 - v48 : v50;
    // pto: %19
    ;
    uint64_t v56 = (uint64_t) v42;
    // pto: %19, %20, %21
    ;
    int32_t v57 = (int32_t) ((int64_t) (uint64_t) ((int64_t) v56 - (uint64_t) v55) - (uint64_t) v12);
    (v6)[v43] = v57;
    // pto: %22
    ;
    int64_t v58 = (int64_t) v46;
    // pto: %23
    ;
    const int64_t v59 = 1;
    // pto: %23
    ;
    const int64_t v60 = 0;
    // pto: %23
    ;
    int64_t v61 = v58 / v14;
    // pto: %23
    ;
    bool v62 = v58 < v60;
    // pto: %23
    ;
    bool v63 = v14 < v60;
    // pto: %23
    ;
    bool v64 = v62 == v63;
    // pto: %23
    ;
    bool v65 = v58 % v14 != v60 && v62 != v63;
    // pto: %23
    ;
    int64_t v66 = v65 ? v61 - v59 : v61;
    // pto: %24
    ;
    uint64_t v67 = (uint64_t) v42;
    // pto: %24, %27
    ;
    v42 = (int64_t) ((uint64_t) ((int64_t) v67 + (uint64_t) v66) - (uint64_t) v55);
  }
  for (int64_t v68 = v13; v68 < v11; v68 += v12) {
    (v7)[v68] = v15;
  }
  for (int64_t v69 = v13; v69 < v9; v69 += v12) {
    // pto: %t__tile
    ;
    int32_t v70 = (v8)[v69];
    // pto: %28
    ;
    // pto: %30, %29
    ;
    int32_t v71 = (v8)[(int64_t) ((uint64_t) v69 + (uint64_t) v12)];
    // pto: %31
    ;
    // pto: %32
    ;
    int32_t v72 = (v4)[v69];
    // pto: %33, %34
    ;
    if ((int64_t) v72 > v13) {
      for (int64_t v73 = (int64_t) v70; v73 < ((int64_t) v71); v73 += v12) {
        // pto: %35
        ;
        int32_t v74 = (int32_t) v69;
        (v7)[v73] = v74;
      };
    };
  }
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  dsb((mem_dsb_t)0);
  #endif // __DAV_VEC__

  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  dsb((mem_dsb_t)0);
  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}