#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void idx_qr_dequant_rope(__gm__ bfloat16_t* v1, __gm__ float* v2, __gm__ float* v3, __gm__ float* v4, __gm__ float* v5, __gm__ int32_t* v6, int64_t v7, int64_t v8, int64_t v9, int64_t v10, int32_t v11, int32_t v12) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v13 = 256;
  const int64_t v14 = 512;
  // pto: %c6176_i64
  const int64_t v15 = 6176;
  // pto: %c10272_i64
  const int64_t v16 = 10272;
  // pto: %c14368_i64
  const int64_t v17 = 14368;
  // pto: %c0_i64
  const int64_t v18 = 0;
  // pto: %c2048_i64
  const int64_t v19 = 2048;
  // pto: %c2080_i64
  const int64_t v20 = 2080;
  // pto: %c4128_i64
  const int64_t v21 = 4128;
  // pto: %c18464_i64
  const int64_t v22 = 18464;
  // pto: %c24096_i64
  const int64_t v23 = 24096;
  const int64_t v24 = 6432;
  // pto: %c19488_i64
  const int64_t v25 = 19488;
  // pto: %c19744_i64
  const int64_t v26 = 19744;
  // pto: %c20000_i64
  const int64_t v27 = 20000;
  const int64_t v28 = 10528;
  // pto: %c25120_i64
  const int64_t v29 = 25120;
  // pto: %c25376_i64
  const int64_t v30 = 25376;
  const int64_t v31 = 14624;
  // pto: %c432_index
  const int64_t v32 = 432;
  // pto: %c8192_index
  const int64_t v33 = 8192;
  // pto: %c1_index
  const int64_t v34 = 1;
  // pto: %c64_index
  const int64_t v35 = 64;
  // pto: %c448_index
  const int64_t v36 = 448;
  // pto: %c8_index
  const int64_t v37 = 8;
  // pto: %cst_23
  const float v38 = 1.0f;
  // pto: %c192_index
  const int64_t v39 = 192;
  // pto: %c0_i32
  const int32_t v40 = 0;
  // pto: %cst_26
  const float v41 = 0.5f;
  // pto: %cst_27
  const float v42 = 2.0f;
  // pto: %c16_index
  const int64_t v43 = 16;
  // pto: %c0_index
  const int64_t v44 = 0;
  // pto: %c4_index
  const int64_t v45 = 4;
  // pto: %c2_index
  const int64_t v46 = 2;
  // pto: %c128_index
  const int64_t v47 = 128;
  // pto: %qr_bf16_2d_inline5662__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %qr_bf16_2d_inline5662__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %qr_bf16_2d_inline5662__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %qr_bf16_2d_inline5662__ssa_v0_view
  int64_t v51 = v32 * v33;
  // pto: %qr_bf16_2d_inline5662__ssa_v0_view
  int64_t v52 = v50 * v51;
  // pto: %qr_bf16_2d_inline5662__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v53 = pto::Shape<1, 1, 1, -1, -1>(v48, v49, v50, v32, v33);
  // pto: %qr_bf16_2d_inline5662__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v54 = pto::Stride<-1, -1, -1, -1, -1>(v49 * v52, v52, v51, v33, v34);
  // pto: %qr_bf16_2d_inline5662__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v55 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v53, v54);
  // pto: %qr_scale__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %qr_scale__ssa_v0_view
  const int64_t v57 = 1;
  // pto: %qr_scale__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %qr_scale__ssa_v0_view
  int64_t v59 = (int64_t) v10;
  // pto: %qr_scale__ssa_v0_view
  int64_t v60 = v59 * v34;
  // pto: %qr_scale__ssa_v0_view
  int64_t v61 = v58 * v60;
  // pto: %qr_scale__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v62 = pto::Shape<1, 1, 1, -1, -1>(v56, v57, v58, v59, v34);
  // pto: %qr_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v63 = pto::Stride<-1, -1, -1, -1, -1>(v57 * v61, v61, v60, v34, (int64_t) v10);
  // pto: %qr_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v64 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v2, v62, v63);
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v68 = (int64_t) v10;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v69 = v68 * v35;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v70 = v67 * v69;
  // pto: %freqs_cos__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v71 = pto::Shape<1, 1, 1, -1, -1>(v65, v66, v67, v68, v35);
  // pto: %freqs_cos__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v66 * v70, v70, v69, v35, v34);
  // pto: %freqs_cos__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v73 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v71, v72);
  // pto: %idx_sin_signed__ssa_v0_view
  const int64_t v74 = 1;
  // pto: %idx_sin_signed__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %idx_sin_signed__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %idx_sin_signed__ssa_v0_view
  int64_t v77 = (int64_t) v10;
  // pto: %idx_sin_signed__ssa_v0_view
  int64_t v78 = v77 * v35;
  // pto: %idx_sin_signed__ssa_v0_view
  int64_t v79 = v76 * v78;
  // pto: %idx_sin_signed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v80 = pto::Shape<1, 1, 1, -1, -1>(v74, v75, v76, v77, v35);
  // pto: %idx_sin_signed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v81 = pto::Stride<-1, -1, -1, -1, -1>(v75 * v79, v79, v78, v35, v34);
  // pto: %idx_sin_signed__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v82 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v80, v81);
  // pto: %idx_wq_b_scale__ssa_v0_view
  const int64_t v83 = 1;
  // pto: %idx_wq_b_scale__ssa_v0_view
  const int64_t v84 = 1;
  // pto: %idx_wq_b_scale__ssa_v0_view
  const int64_t v85 = 1;
  // pto: %idx_wq_b_scale__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %idx_wq_b_scale__ssa_v0_view
  int64_t v87 = v33 * v34;
  // pto: %idx_wq_b_scale__ssa_v0_view
  int64_t v88 = v86 * v87;
  // pto: %idx_wq_b_scale__ssa_v0_view
  int64_t v89 = v85 * v88;
  // pto: %idx_wq_b_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v90 = pto::Shape<1, 1, 1, 1, -1>(v83, v84, v85, v86, v33);
  // pto: %idx_wq_b_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v91 = pto::Stride<-1, -1, -1, -1, -1>(v84 * v89, v89, v88, v87, v34);
  // pto: %idx_wq_b_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v92 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v90, v91);
  // pto: %qr_acc_pad_inline5651__rv_v2_view
  const int64_t v93 = 1;
  // pto: %qr_acc_pad_inline5651__rv_v2_view
  const int64_t v94 = 1;
  // pto: %qr_acc_pad_inline5651__rv_v2_view
  const int64_t v95 = 1;
  // pto: %qr_acc_pad_inline5651__rv_v2_view
  int64_t v96 = v36 * v33;
  // pto: %qr_acc_pad_inline5651__rv_v2_view
  int64_t v97 = v95 * v96;
  // pto: %qr_acc_pad_inline5651__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v98 = pto::Shape<1, 1, 1, -1, -1>(v93, v94, v95, v36, v33);
  // pto: %qr_acc_pad_inline5651__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v99 = pto::Stride<-1, -1, -1, -1, -1>(v94 * v97, v97, v96, v33, v34);
  // pto: %qr_acc_pad_inline5651__rv_v2_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v100 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v98, v99);
  // pto: %dq_rope_worker_inline5665__ssa_v0
  // pto: %sw_ones_inline5666__tile
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %sw_ones_inline5666__tile
  uint64_t v102 = (uint64_t) v15;
  TASSIGN(v101, v102);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  TEXPANDS(v101, v38);
  // pto: %t__ci_tmp_v0
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v39);
  // pto: %t__ci_tmp_v0
  uint64_t v104 = (uint64_t) v16;
  TASSIGN(v103, v104);
  // pto: %t__tile
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v105 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
  // pto: %t__tile
  uint64_t v106 = (uint64_t) v17;
  TASSIGN(v105, v106);
  // pto: %ci_tmp_view
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v107;
  TRESHAPE(v107, v103);
  // pto: %ci_dst_view
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v108;
  TRESHAPE(v108, v105);
  TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v108, v40, v107);
  // pto: %sw_index_inline5667__tile
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v109 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
  // pto: %sw_index_inline5667__tile
  uint64_t v110 = (uint64_t) v16;
  TASSIGN(v109, v110);
  pipe_barrier(PIPE_V);
  RoundMode v111 = RoundMode::CAST_ROUND;
  SaturationMode v112 = SaturationMode::ON;
  TCVT(v109, v105, v111, v112);
  // pto: %sw_col_inline5668__tile
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %sw_col_inline5668__tile
  uint64_t v114 = (uint64_t) v15;
  TASSIGN(v113, v114);
  pipe_barrier(PIPE_V);
  TCOLEXPANDMUL(v113, v101, v109);
  // pto: %0
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v115 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %0
  uint64_t v116 = (uint64_t) v16;
  TASSIGN(v115, v116);
  pipe_barrier(PIPE_V);
  TMULS(v115, v113, v41);
  // pto: %1
  Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %1
  uint64_t v118 = (uint64_t) v16;
  TASSIGN(v117, v118);
  pipe_barrier(PIPE_V);
  RoundMode v119 = RoundMode::CAST_TRUNC;
  SaturationMode v120 = SaturationMode::ON;
  TCVT(v117, v115, v119, v120);
  // pto: %sw_dup_f_inline5669__tile
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %sw_dup_f_inline5669__tile
  uint64_t v122 = (uint64_t) v16;
  TASSIGN(v121, v122);
  pipe_barrier(PIPE_V);
  RoundMode v123 = RoundMode::CAST_ROUND;
  SaturationMode v124 = SaturationMode::ON;
  TCVT(v121, v117, v123, v124);
  // pto: %2
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v125 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %2
  uint64_t v126 = (uint64_t) v16;
  TASSIGN(v125, v126);
  pipe_barrier(PIPE_V);
  TMULS(v125, v121, v42);
  // pto: %sw_lane_inline5670__tile
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %sw_lane_inline5670__tile
  uint64_t v128 = (uint64_t) v16;
  TASSIGN(v127, v128);
  pipe_barrier(PIPE_V);
  TSUB(v127, v113, v125);
  // pto: %3
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %3
  uint64_t v130 = (uint64_t) v15;
  TASSIGN(v129, v130);
  pipe_barrier(PIPE_V);
  TADDS(v129, v113, v38);
  // pto: %4
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %4
  uint64_t v132 = (uint64_t) v16;
  TASSIGN(v131, v132);
  TMULS(v131, v127, v42);
  // pto: %5
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %5
  uint64_t v134 = (uint64_t) v15;
  TASSIGN(v133, v134);
  pipe_barrier(PIPE_V);
  TSUB(v133, v129, v131);
  // pto: %rope_swap_idx_inline5671__tile
  Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v135 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %rope_swap_idx_inline5671__tile
  uint64_t v136 = (uint64_t) v18;
  TASSIGN(v135, v136);
  pipe_barrier(PIPE_V);
  RoundMode v137 = RoundMode::CAST_ROUND;
  SaturationMode v138 = SaturationMode::ON;
  TCVT(v135, v133, v137, v138);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  for (int64_t v139 = (int64_t) v11; v139 < v7; v139 += v8) {
    // pto: %72
    ;
    int64_t v140 = v139 % v43;
    // pto: %73, %74, %75
    ;
    int64_t v141 = v140 < v44 ? (int64_t) ((uint64_t) v140 + (uint64_t) v43) : v140;
    // pto: %76
    ;
    int64_t v142 = (int64_t) ((uint64_t) v141 * (uint64_t) v45);
    // pto: %77
    ;
    const int64_t v143 = 1;
    // pto: %77
    ;
    const int64_t v144 = 0;
    // pto: %77
    ;
    int64_t v145 = v139 / v43;
    // pto: %77
    ;
    bool v146 = v139 < v144;
    // pto: %77
    ;
    bool v147 = v43 < v144;
    // pto: %77
    ;
    bool v148 = v146 == v147;
    // pto: %77
    ;
    bool v149 = v139 % v43 != v144 && v146 != v147;
    // pto: %77
    ;
    int64_t v150 = v149 ? v145 - v143 : v145;
    // pto: %78
    ;
    int64_t v151 = (int64_t) ((uint64_t) v150 * (uint64_t) v37);
    // pto: %79, %80
    ;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    if ((int64_t) ((uint64_t) v151 + (uint64_t) v37) <= v9) {
      // pto: %qr_scale_tile_inline5675__tile
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v152 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v34);
      // pto: %qr_scale_tile_inline5675__tile
      ;
      uint64_t v153 = (uint64_t) v19;
      TASSIGN(v152, v153);
      // pto: %81
      ;
      int64_t v154 = v151 < v44 ? v44 : v151;
      // pto: %qr_scale__ssa_v0_pview
      ;
      int64_t v155 = (int64_t) v10;
      // pto: %qr_scale__ssa_v0_pview
      ;
      const int64_t v156 = 0;
      // pto: %qr_scale__ssa_v0_pview
      ;
      __gm__ float* v157 = PTOAS__GLOBAL_TENSOR_DATA(v64);
      // pto: %qr_scale__ssa_v0_pview
      ;
      const int64_t v158 = 1;
      // pto: %qr_scale__ssa_v0_pview
      ;
      const int64_t v159 = 1;
      // pto: %qr_scale__ssa_v0_pview
      ;
      const int64_t v160 = 1;
      // pto: %qr_scale__ssa_v0_pview
      ;
      int64_t v161 = v37 * v34;
      // pto: %qr_scale__ssa_v0_pview
      ;
      int64_t v162 = v160 * v161;
      // pto: %qr_scale__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 1> v163 = pto::Shape<1, 1, 1, 8, 1>(v158, v159, v160, v37, v34);
      // pto: %qr_scale__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v164 = pto::Stride<-1, -1, -1, -1, -1>(v159 * v162, v162, v161, v34, v155);
      // pto: %qr_scale__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v165 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v157 + (v156 + v154 * v34 + v44 * v155), v163, v164);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
      TLOAD(v152, v165);
      // pto: %cos_tile_inline5676__tile
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v166 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
      // pto: %cos_tile_inline5676__tile
      ;
      uint64_t v167 = (uint64_t) v20;
      TASSIGN(v166, v167);
      // pto: %freqs_cos__ssa_v0_pview
      ;
      __gm__ float* v168 = PTOAS__GLOBAL_TENSOR_DATA(v73);
      // pto: %freqs_cos__ssa_v0_pview
      ;
      const int64_t v169 = 0;
      // pto: %freqs_cos__ssa_v0_pview
      ;
      const int64_t v170 = 64;
      // pto: %freqs_cos__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 64> v171 = pto::Shape<1, 1, 1, 8, 64>();
      // pto: %freqs_cos__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 64, 1> v172 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %freqs_cos__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v173 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v168 + (v169 + v154 * v170), v171, v172);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
      TLOAD(v166, v173);
      // pto: %sin_tile_inline5677__tile
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v174 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
      // pto: %sin_tile_inline5677__tile
      ;
      uint64_t v175 = (uint64_t) v21;
      TASSIGN(v174, v175);
      // pto: %idx_sin_signed__ssa_v0_pview
      ;
      __gm__ float* v176 = PTOAS__GLOBAL_TENSOR_DATA(v82);
      // pto: %idx_sin_signed__ssa_v0_pview
      ;
      const int64_t v177 = 0;
      // pto: %idx_sin_signed__ssa_v0_pview
      ;
      const int64_t v178 = 64;
      // pto: %idx_sin_signed__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 64> v179 = pto::Shape<1, 1, 1, 8, 64>();
      // pto: %idx_sin_signed__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 64, 1> v180 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %idx_sin_signed__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v181 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v176 + (v177 + v154 * v178), v179, v180);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      TLOAD(v174, v181);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      for (int64_t v182 = v44; v182 < v45; v182 += v46) {
        // pto: %84, %85
        ;
        int64_t v183 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v142 + (uint64_t) v182) * (uint64_t) v47);
        // pto: %87, %86, %88
        ;
        int64_t v184 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v142 + (uint64_t) ((int64_t) (uint64_t) v182 + (uint64_t) v34)) * (uint64_t) v47);
        // pto: %6
        ;
        Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v185 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
        // pto: %6
        ;
        uint64_t v186 = (uint64_t) v22;
        TASSIGN(v185, v186);
        // pto: %89
        ;
        int64_t v187 = v183 < v44 ? v44 : v183;
        // pto: %idx_wq_b_scale__ssa_v0_pview
        ;
        __gm__ float* v188 = PTOAS__GLOBAL_TENSOR_DATA(v92);
        // pto: %idx_wq_b_scale__ssa_v0_pview
        ;
        const int64_t v189 = 0;
        // pto: %idx_wq_b_scale__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 128> v190 = pto::Shape<1, 1, 1, 1, 128>();
        // pto: %idx_wq_b_scale__ssa_v0_pview
        ;
        pto::Stride<128, 128, 128, 128, 1> v191 = pto::Stride<128, 128, 128, 128, 1>();
        // pto: %idx_wq_b_scale__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v192 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v188 + (v189 + v187), v190, v191);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        TLOAD(v185, v192);
        // pto: %7
        ;
        Tile<TileType::Vec, int32_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v193 = Tile<TileType::Vec, int32_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %7
        ;
        uint64_t v194 = (uint64_t) v15;
        TASSIGN(v193, v194);
        // pto: %qr_acc_pad_inline5651__rv_v2_pview
        ;
        __gm__ int32_t* v195 = PTOAS__GLOBAL_TENSOR_DATA(v100);
        // pto: %qr_acc_pad_inline5651__rv_v2_pview
        ;
        const int64_t v196 = 0;
        // pto: %qr_acc_pad_inline5651__rv_v2_pview
        ;
        const int64_t v197 = 8192;
        // pto: %qr_acc_pad_inline5651__rv_v2_pview
        ;
        pto::Shape<1, 1, 1, 8, 128> v198 = pto::Shape<1, 1, 1, 8, 128>();
        // pto: %qr_acc_pad_inline5651__rv_v2_pview
        ;
        pto::Stride<65536, 65536, 65536, 8192, 1> v199 = pto::Stride<65536, 65536, 65536, 8192, 1>();
        // pto: %qr_acc_pad_inline5651__rv_v2_pview
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 128>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v200 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 128>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v195 + (v196 + v154 * v197 + v187), v198, v199);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        TLOAD(v193, v200);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %8
        ;
        Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v201 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
        // pto: %8
        ;
        uint64_t v202 = (uint64_t) v23;
        TASSIGN(v201, v202);
        // pto: %92
        ;
        int64_t v203 = v184 < v44 ? v44 : v184;
        // pto: %93
        ;
        __gm__ float* v204 = PTOAS__GLOBAL_TENSOR_DATA(v92);
        // pto: %93
        ;
        const int64_t v205 = 0;
        // pto: %93
        ;
        pto::Shape<1, 1, 1, 1, 128> v206 = pto::Shape<1, 1, 1, 1, 128>();
        // pto: %93
        ;
        pto::Stride<128, 128, 128, 128, 1> v207 = pto::Stride<128, 128, 128, 128, 1>();
        // pto: %93
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v208 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v204 + (v205 + v203), v206, v207);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
        TLOAD(v201, v208);
        // pto: %9
        ;
        Tile<TileType::Vec, int32_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v209 = Tile<TileType::Vec, int32_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %9
        ;
        uint64_t v210 = (uint64_t) v16;
        TASSIGN(v209, v210);
        // pto: %96
        ;
        __gm__ int32_t* v211 = PTOAS__GLOBAL_TENSOR_DATA(v100);
        // pto: %96
        ;
        const int64_t v212 = 0;
        // pto: %96
        ;
        const int64_t v213 = 8192;
        // pto: %96
        ;
        pto::Shape<1, 1, 1, 8, 128> v214 = pto::Shape<1, 1, 1, 8, 128>();
        // pto: %96
        ;
        pto::Stride<65536, 65536, 65536, 8192, 1> v215 = pto::Stride<65536, 65536, 65536, 8192, 1>();
        // pto: %96
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 128>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v216 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 128>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v211 + (v212 + v154 * v213 + v203), v214, v215);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        TLOAD(v209, v216);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %wq_scale_inline5680__tile
        ;
        Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
        // pto: %wq_scale_inline5680__tile
        ;
        uint64_t v218 = (uint64_t) v22;
        TASSIGN(v217, v218);
        // pto: %acc_fp32_inline5681__tile
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v219 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %acc_fp32_inline5681__tile
        ;
        uint64_t v220 = (uint64_t) v15;
        TASSIGN(v219, v220);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v221 = RoundMode::CAST_NONE;
        SaturationMode v222 = SaturationMode::ON;
        TCVT(v219, v193, v221, v222);
        // pto: %10
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v223 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %10
        ;
        uint64_t v224 = (uint64_t) v17;
        TASSIGN(v223, v224);
        TEXPANDS(v223, v38);
        // pto: %11
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v225 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %11
        ;
        uint64_t v226 = (uint64_t) v17;
        TASSIGN(v225, v226);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v225, v223, v152);
        // pto: %qr_dequant_scale_inline5682__tile
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v227 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %qr_dequant_scale_inline5682__tile
        ;
        uint64_t v228 = (uint64_t) v17;
        TASSIGN(v227, v228);
        pipe_barrier(PIPE_V);
        TCOLEXPANDMUL(v227, v225, v217);
        // pto: %qr_dequant_inline5683__tile
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v229 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %qr_dequant_inline5683__tile
        ;
        uint64_t v230 = (uint64_t) v15;
        TASSIGN(v229, v230);
        pipe_barrier(PIPE_V);
        TMUL(v229, v219, v227);
        // pto: %12
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v231 = Tile<TileType::Vec, bfloat16_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %12
        ;
        uint64_t v232 = (uint64_t) v17;
        TASSIGN(v231, v232);
        pipe_barrier(PIPE_V);
        RoundMode v233 = RoundMode::CAST_RINT;
        SaturationMode v234 = SaturationMode::ON;
        TCVT(v231, v229, v233, v234);
        // pto: %qr_dequant_v1_inline5684__tile
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v235 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %qr_dequant_v1_inline5684__tile
        ;
        uint64_t v236 = (uint64_t) v15;
        TASSIGN(v235, v236);
        pipe_barrier(PIPE_V);
        RoundMode v237 = RoundMode::CAST_ROUND;
        SaturationMode v238 = SaturationMode::ON;
        TCVT(v235, v231, v237, v238);
        // pto: %13
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v239 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %13
        ;
        uint64_t v240 = (uint64_t) v15;
        TASSIGN(v239, v240);
        // pto: %slice_view
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v241;
        // pto: %slice_view
        ;
        uint64_t v242 = (uint64_t) v15;
        TASSIGN(v241, v242);
        // pto: %qr_nope_bf16_inline5685__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v243 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %qr_nope_bf16_inline5685__tile
        ;
        uint64_t v244 = (uint64_t) v22;
        TASSIGN(v243, v244);
        pipe_barrier(PIPE_V);
        RoundMode v245 = RoundMode::CAST_RINT;
        SaturationMode v246 = SaturationMode::ON;
        TCVT(v243, v241, v245, v246);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %qr_rope_slice_inline5686__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v247 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %qr_rope_slice_inline5686__tile
        ;
        uint64_t v248 = (uint64_t) v24;
        TASSIGN(v247, v248);
        // pto: %97
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v249;
        // pto: %97
        ;
        uint64_t v250 = (uint64_t) v24;
        TASSIGN(v249, v250);
        // pto: %gather_acc_init
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v251 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %gather_acc_init
        ;
        uint64_t v252 = (uint64_t) v17;
        TASSIGN(v251, v252);
        for (int64_t v253 = v44; v253 < v37; v253 += v34) {
          // pto: %gather_inp_row
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v254 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %gather_inp_row
          ;
          uint64_t v255 = (uint64_t) v15;
          TASSIGN(v254, v255);
          // pto: %98
          ;
          Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v256;
          // pto: %98
          ;
          uint64_t v257 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v253 * (uint64_t) v14) + (uint64_t) v24);
          TASSIGN(v256, v257);
          // pto: %gather_idx_row
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v258 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %gather_idx_row
          ;
          uint64_t v259 = (uint64_t) v18;
          TASSIGN(v258, v259);
          // pto: %99
          ;
          int64_t v260 = (int64_t) ((uint64_t) v253 * (uint64_t) v13);
          // pto: %99
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v261;
          // pto: %99
          ;
          uint64_t v262 = (uint64_t) v260;
          TASSIGN(v261, v262);
          // pto: %gather_row_tmp
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v263 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %gather_row_tmp
          ;
          uint64_t v264 = (uint64_t) v25;
          TASSIGN(v263, v264);
          // pto: %gather_row
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v265 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %gather_row
          ;
          uint64_t v266 = (uint64_t) v26;
          TASSIGN(v265, v266);
          pipe_barrier(PIPE_V);
          TGATHER(v265, v256, v261, v263);
          // pto: %assemble_view
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v267;
          // pto: %assemble_view
          ;
          uint64_t v268 = (uint64_t) ((int64_t) (uint64_t) v260 + (uint64_t) v17);
          TASSIGN(v267, v268);
          pipe_barrier(PIPE_V);
          TMOV(v267, v265);
        };
        // pto: %qr_swapped_inline5687__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v269 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %qr_swapped_inline5687__tile
        ;
        uint64_t v270 = (uint64_t) v17;
        TASSIGN(v269, v270);
        // pto: %14
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v271 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %14
        ;
        uint64_t v272 = (uint64_t) v15;
        TASSIGN(v271, v272);
        pipe_barrier(PIPE_V);
        TMUL(v271, v249, v166);
        // pto: %15
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v273 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %15
        ;
        uint64_t v274 = (uint64_t) v17;
        TASSIGN(v273, v274);
        TMUL(v273, v269, v174);
        // pto: %rope_rot_inline5688__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v275 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %rope_rot_inline5688__tile
        ;
        uint64_t v276 = (uint64_t) v15;
        TASSIGN(v275, v276);
        pipe_barrier(PIPE_V);
        TADD(v275, v271, v273);
        // pto: %rope_bf16_inline5689__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v277 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %rope_bf16_inline5689__tile
        ;
        uint64_t v278 = (uint64_t) v15;
        TASSIGN(v277, v278);
        pipe_barrier(PIPE_V);
        RoundMode v279 = RoundMode::CAST_RINT;
        SaturationMode v280 = SaturationMode::ON;
        TCVT(v277, v275, v279, v280);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        // pto: %qr_bf16_2d_inline5662__iter_v3_pview
        ;
        __gm__ bfloat16_t* v281 = PTOAS__GLOBAL_TENSOR_DATA(v55);
        // pto: %qr_bf16_2d_inline5662__iter_v3_pview
        ;
        const int64_t v282 = 0;
        // pto: %qr_bf16_2d_inline5662__iter_v3_pview
        ;
        const int64_t v283 = 8192;
        // pto: %qr_bf16_2d_inline5662__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, 8, 64> v284 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %qr_bf16_2d_inline5662__iter_v3_pview
        ;
        pto::Stride<65536, 65536, 65536, 8192, 1> v285 = pto::Stride<65536, 65536, 65536, 8192, 1>();
        // pto: %qr_bf16_2d_inline5662__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v286 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v281 + (v282 + v154 * v283 + v187), v284, v285);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v286, v243);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        // pto: %104
        ;
        int64_t v287 = (int64_t) ((uint64_t) v183 + (uint64_t) v35);
        // pto: %105
        ;
        int64_t v288 = v287 < v44 ? v44 : v287;
        // pto: %qr_bf16_2d_inline5662__tile_pview
        ;
        __gm__ bfloat16_t* v289 = PTOAS__GLOBAL_TENSOR_DATA(v55);
        // pto: %qr_bf16_2d_inline5662__tile_pview
        ;
        const int64_t v290 = 0;
        // pto: %qr_bf16_2d_inline5662__tile_pview
        ;
        const int64_t v291 = 8192;
        // pto: %qr_bf16_2d_inline5662__tile_pview
        ;
        pto::Shape<1, 1, 1, 8, 64> v292 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %qr_bf16_2d_inline5662__tile_pview
        ;
        pto::Stride<65536, 65536, 65536, 8192, 1> v293 = pto::Stride<65536, 65536, 65536, 8192, 1>();
        // pto: %qr_bf16_2d_inline5662__tile_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v294 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v289 + (v290 + v154 * v291 + v288), v292, v293);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v294, v277);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        // pto: %16
        ;
        Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v295 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
        // pto: %16
        ;
        uint64_t v296 = (uint64_t) v23;
        TASSIGN(v295, v296);
        // pto: %17
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v297 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %17
        ;
        uint64_t v298 = (uint64_t) v16;
        TASSIGN(v297, v298);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        RoundMode v299 = RoundMode::CAST_NONE;
        SaturationMode v300 = SaturationMode::ON;
        TCVT(v297, v209, v299, v300);
        // pto: %18
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v301 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %18
        ;
        uint64_t v302 = (uint64_t) v27;
        TASSIGN(v301, v302);
        TEXPANDS(v301, v38);
        // pto: %19
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v303 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %19
        ;
        uint64_t v304 = (uint64_t) v27;
        TASSIGN(v303, v304);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v303, v301, v152);
        // pto: %20
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v305 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %20
        ;
        uint64_t v306 = (uint64_t) v27;
        TASSIGN(v305, v306);
        pipe_barrier(PIPE_V);
        TCOLEXPANDMUL(v305, v303, v295);
        // pto: %21
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v307 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %21
        ;
        uint64_t v308 = (uint64_t) v16;
        TASSIGN(v307, v308);
        pipe_barrier(PIPE_V);
        TMUL(v307, v297, v305);
        // pto: %22
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Vec, bfloat16_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %22
        ;
        uint64_t v310 = (uint64_t) v27;
        TASSIGN(v309, v310);
        pipe_barrier(PIPE_V);
        RoundMode v311 = RoundMode::CAST_RINT;
        SaturationMode v312 = SaturationMode::ON;
        TCVT(v309, v307, v311, v312);
        // pto: %23
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %23
        ;
        uint64_t v314 = (uint64_t) v16;
        TASSIGN(v313, v314);
        pipe_barrier(PIPE_V);
        RoundMode v315 = RoundMode::CAST_ROUND;
        SaturationMode v316 = SaturationMode::ON;
        TCVT(v313, v309, v315, v316);
        // pto: %24
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v317 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %24
        ;
        uint64_t v318 = (uint64_t) v16;
        TASSIGN(v317, v318);
        // pto: %106
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v319;
        // pto: %106
        ;
        uint64_t v320 = (uint64_t) v16;
        TASSIGN(v319, v320);
        // pto: %25
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v321 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %25
        ;
        uint64_t v322 = (uint64_t) v23;
        TASSIGN(v321, v322);
        pipe_barrier(PIPE_V);
        RoundMode v323 = RoundMode::CAST_RINT;
        SaturationMode v324 = SaturationMode::ON;
        TCVT(v321, v319, v323, v324);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        // pto: %26
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v325 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %26
        ;
        uint64_t v326 = (uint64_t) v28;
        TASSIGN(v325, v326);
        // pto: %107
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v327;
        // pto: %107
        ;
        uint64_t v328 = (uint64_t) v28;
        TASSIGN(v327, v328);
        // pto: %27
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v329 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %27
        ;
        uint64_t v330 = (uint64_t) v27;
        TASSIGN(v329, v330);
        for (int64_t v331 = v44; v331 < v37; v331 += v34) {
          // pto: %28
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v332 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %28
          ;
          uint64_t v333 = (uint64_t) v16;
          TASSIGN(v332, v333);
          // pto: %109
          ;
          Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v334;
          // pto: %109
          ;
          uint64_t v335 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v331 * (uint64_t) v14) + (uint64_t) v28);
          TASSIGN(v334, v335);
          // pto: %29
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v336 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %29
          ;
          uint64_t v337 = (uint64_t) v18;
          TASSIGN(v336, v337);
          // pto: %110
          ;
          int64_t v338 = (int64_t) ((uint64_t) v331 * (uint64_t) v13);
          // pto: %110
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v339;
          // pto: %110
          ;
          uint64_t v340 = (uint64_t) v338;
          TASSIGN(v339, v340);
          // pto: %30
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v341 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %30
          ;
          uint64_t v342 = (uint64_t) v29;
          TASSIGN(v341, v342);
          // pto: %31
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v343 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %31
          ;
          uint64_t v344 = (uint64_t) v30;
          TASSIGN(v343, v344);
          pipe_barrier(PIPE_V);
          TGATHER(v343, v334, v339, v341);
          // pto: %111
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v345;
          // pto: %111
          ;
          uint64_t v346 = (uint64_t) ((int64_t) (uint64_t) v338 + (uint64_t) v27);
          TASSIGN(v345, v346);
          pipe_barrier(PIPE_V);
          TMOV(v345, v343);
        };
        // pto: %33
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v347 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %33
        ;
        uint64_t v348 = (uint64_t) v27;
        TASSIGN(v347, v348);
        // pto: %34
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v349 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %34
        ;
        uint64_t v350 = (uint64_t) v16;
        TASSIGN(v349, v350);
        pipe_barrier(PIPE_V);
        TMUL(v349, v327, v166);
        // pto: %35
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v351 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %35
        ;
        uint64_t v352 = (uint64_t) v27;
        TASSIGN(v351, v352);
        TMUL(v351, v347, v174);
        // pto: %36
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v353 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %36
        ;
        uint64_t v354 = (uint64_t) v16;
        TASSIGN(v353, v354);
        pipe_barrier(PIPE_V);
        TADD(v353, v349, v351);
        // pto: %37
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v355 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %37
        ;
        uint64_t v356 = (uint64_t) v16;
        TASSIGN(v355, v356);
        pipe_barrier(PIPE_V);
        RoundMode v357 = RoundMode::CAST_RINT;
        SaturationMode v358 = SaturationMode::ON;
        TCVT(v355, v353, v357, v358);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        // pto: %115
        ;
        __gm__ bfloat16_t* v359 = PTOAS__GLOBAL_TENSOR_DATA(v55);
        // pto: %115
        ;
        const int64_t v360 = 0;
        // pto: %115
        ;
        const int64_t v361 = 8192;
        // pto: %115
        ;
        pto::Shape<1, 1, 1, 8, 64> v362 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %115
        ;
        pto::Stride<65536, 65536, 65536, 8192, 1> v363 = pto::Stride<65536, 65536, 65536, 8192, 1>();
        // pto: %115
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v364 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v359 + (v360 + v154 * v361 + v203), v362, v363);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v364, v321);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
        // pto: %118
        ;
        int64_t v365 = (int64_t) ((uint64_t) v184 + (uint64_t) v35);
        // pto: %119
        ;
        int64_t v366 = v365 < v44 ? v44 : v365;
        // pto: %120
        ;
        __gm__ bfloat16_t* v367 = PTOAS__GLOBAL_TENSOR_DATA(v55);
        // pto: %120
        ;
        const int64_t v368 = 0;
        // pto: %120
        ;
        const int64_t v369 = 8192;
        // pto: %120
        ;
        pto::Shape<1, 1, 1, 8, 64> v370 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %120
        ;
        pto::Stride<65536, 65536, 65536, 8192, 1> v371 = pto::Stride<65536, 65536, 65536, 8192, 1>();
        // pto: %120
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v372 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v367 + (v368 + v154 * v369 + v366), v370, v371);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        TSTORE(v372, v355);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      };
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    } else {
      // pto: %tail_swap_idx_inline5690__tile
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v373 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
      // pto: %tail_swap_idx_inline5690__tile
      ;
      uint64_t v374 = (uint64_t) v18;
      TASSIGN(v373, v374);
      // pto: %121
      ;
      uint64_t v375 = (uint64_t) v18;
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      for (int64_t v376 = v151; v376 < v9; v376 += v34) {
        // pto: %tail_qr_scale_value_inline5692__tile
        ;
        float v377 = (v2)[v376];
        // pto: %tail_cos_tile_inline5693__tile
        ;
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v378 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
        // pto: %tail_cos_tile_inline5693__tile
        ;
        uint64_t v379 = (uint64_t) v20;
        TASSIGN(v378, v379);
        // pto: %122
        ;
        int64_t v380 = v376 < v44 ? v44 : v376;
        // pto: %123
        ;
        __gm__ float* v381 = PTOAS__GLOBAL_TENSOR_DATA(v73);
        // pto: %123
        ;
        const int64_t v382 = 0;
        // pto: %123
        ;
        const int64_t v383 = 64;
        // pto: %123
        ;
        pto::Shape<1, 1, 1, 1, 64> v384 = pto::Shape<1, 1, 1, 1, 64>();
        // pto: %123
        ;
        pto::Stride<64, 64, 64, 64, 1> v385 = pto::Stride<64, 64, 64, 64, 1>();
        // pto: %123
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v386 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v381 + (v382 + v380 * v383), v384, v385);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        TLOAD(v378, v386);
        // pto: %tail_sin_tile_inline5694__tile
        ;
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v387 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
        // pto: %tail_sin_tile_inline5694__tile
        ;
        uint64_t v388 = (uint64_t) v21;
        TASSIGN(v387, v388);
        // pto: %125
        ;
        __gm__ float* v389 = PTOAS__GLOBAL_TENSOR_DATA(v82);
        // pto: %125
        ;
        const int64_t v390 = 0;
        // pto: %125
        ;
        const int64_t v391 = 64;
        // pto: %125
        ;
        pto::Shape<1, 1, 1, 1, 64> v392 = pto::Shape<1, 1, 1, 1, 64>();
        // pto: %125
        ;
        pto::Stride<64, 64, 64, 64, 1> v393 = pto::Stride<64, 64, 64, 64, 1>();
        // pto: %125
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v394 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v389 + (v390 + v380 * v391), v392, v393);
        pipe_barrier(PIPE_ALL);
        TLOAD(v387, v394);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
        for (int64_t v395 = v44; v395 < v45; v395 += v46) {
          // pto: %126, %127
          ;
          int64_t v396 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v142 + (uint64_t) v395) * (uint64_t) v47);
          // pto: %129, %128, %130
          ;
          int64_t v397 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v142 + (uint64_t) ((int64_t) (uint64_t) v395 + (uint64_t) v34)) * (uint64_t) v47);
          // pto: %38
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v398 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %38
          ;
          uint64_t v399 = (uint64_t) v15;
          TASSIGN(v398, v399);
          // pto: %131
          ;
          int64_t v400 = v396 < v44 ? v44 : v396;
          // pto: %132
          ;
          __gm__ float* v401 = PTOAS__GLOBAL_TENSOR_DATA(v92);
          // pto: %132
          ;
          const int64_t v402 = 0;
          // pto: %132
          ;
          pto::Shape<1, 1, 1, 1, 128> v403 = pto::Shape<1, 1, 1, 1, 128>();
          // pto: %132
          ;
          pto::Stride<128, 128, 128, 128, 1> v404 = pto::Stride<128, 128, 128, 128, 1>();
          // pto: %132
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v405 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v401 + (v402 + v400), v403, v404);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
          TLOAD(v398, v405);
          // pto: %39
          ;
          Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v406 = Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %39
          ;
          uint64_t v407 = (uint64_t) v16;
          TASSIGN(v406, v407);
          // pto: %135
          ;
          __gm__ int32_t* v408 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %135
          ;
          const int64_t v409 = 0;
          // pto: %135
          ;
          const int64_t v410 = 8192;
          // pto: %135
          ;
          pto::Shape<1, 1, 1, 1, 128> v411 = pto::Shape<1, 1, 1, 1, 128>();
          // pto: %135
          ;
          pto::Stride<8192, 8192, 8192, 8192, 1> v412 = pto::Stride<8192, 8192, 8192, 8192, 1>();
          // pto: %135
          ;
          GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v413 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v408 + (v409 + v380 * v410 + v400), v411, v412);
          TLOAD(v406, v413);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          // pto: %40
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v414 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %40
          ;
          uint64_t v415 = (uint64_t) v17;
          TASSIGN(v414, v415);
          // pto: %136
          ;
          int64_t v416 = v397 < v44 ? v44 : v397;
          // pto: %137
          ;
          __gm__ float* v417 = PTOAS__GLOBAL_TENSOR_DATA(v92);
          // pto: %137
          ;
          const int64_t v418 = 0;
          // pto: %137
          ;
          pto::Shape<1, 1, 1, 1, 128> v419 = pto::Shape<1, 1, 1, 1, 128>();
          // pto: %137
          ;
          pto::Stride<128, 128, 128, 128, 1> v420 = pto::Stride<128, 128, 128, 128, 1>();
          // pto: %137
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v421 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v417 + (v418 + v416), v419, v420);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
          TLOAD(v414, v421);
          // pto: %41
          ;
          Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v422 = Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %41
          ;
          uint64_t v423 = (uint64_t) v27;
          TASSIGN(v422, v423);
          // pto: %140
          ;
          __gm__ int32_t* v424 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %140
          ;
          const int64_t v425 = 0;
          // pto: %140
          ;
          const int64_t v426 = 8192;
          // pto: %140
          ;
          pto::Shape<1, 1, 1, 1, 128> v427 = pto::Shape<1, 1, 1, 1, 128>();
          // pto: %140
          ;
          pto::Stride<8192, 8192, 8192, 8192, 1> v428 = pto::Stride<8192, 8192, 8192, 8192, 1>();
          // pto: %140
          ;
          GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v429 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v424 + (v425 + v380 * v426 + v416), v427, v428);
          TLOAD(v422, v429);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
          // pto: %tail_wq_scale_inline5697__tile
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v430 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %tail_wq_scale_inline5697__tile
          ;
          uint64_t v431 = (uint64_t) v15;
          TASSIGN(v430, v431);
          // pto: %tail_acc_fp32_inline5698__tile
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v432 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %tail_acc_fp32_inline5698__tile
          ;
          uint64_t v433 = (uint64_t) v16;
          TASSIGN(v432, v433);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          RoundMode v434 = RoundMode::CAST_NONE;
          SaturationMode v435 = SaturationMode::ON;
          TCVT(v432, v406, v434, v435);
          // pto: %tail_qr_dequant_scale_inline5699__tile
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v436 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %tail_qr_dequant_scale_inline5699__tile
          ;
          uint64_t v437 = (uint64_t) v15;
          TASSIGN(v436, v437);
          TMULS(v436, v430, v377);
          // pto: %tail_qr_dequant_inline5700__tile
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v438 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %tail_qr_dequant_inline5700__tile
          ;
          uint64_t v439 = (uint64_t) v15;
          TASSIGN(v438, v439);
          pipe_barrier(PIPE_V);
          TMUL(v438, v432, v436);
          // pto: %42
          ;
          Tile<TileType::Vec, bfloat16_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v440 = Tile<TileType::Vec, bfloat16_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %42
          ;
          uint64_t v441 = (uint64_t) v16;
          TASSIGN(v440, v441);
          pipe_barrier(PIPE_V);
          RoundMode v442 = RoundMode::CAST_RINT;
          SaturationMode v443 = SaturationMode::ON;
          TCVT(v440, v438, v442, v443);
          // pto: %tail_qr_dequant_v1_inline5701__tile
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v444 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %tail_qr_dequant_v1_inline5701__tile
          ;
          uint64_t v445 = (uint64_t) v15;
          TASSIGN(v444, v445);
          pipe_barrier(PIPE_V);
          RoundMode v446 = RoundMode::CAST_ROUND;
          SaturationMode v447 = SaturationMode::ON;
          TCVT(v444, v440, v446, v447);
          // pto: %43
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v448 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %43
          ;
          uint64_t v449 = (uint64_t) v15;
          TASSIGN(v448, v449);
          // pto: %141
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v450;
          // pto: %141
          ;
          uint64_t v451 = (uint64_t) v15;
          TASSIGN(v450, v451);
          // pto: %tail_qr_nope_bf16_inline5702__tile
          ;
          Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v452 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %tail_qr_nope_bf16_inline5702__tile
          ;
          uint64_t v453 = (uint64_t) v29;
          TASSIGN(v452, v453);
          pipe_barrier(PIPE_V);
          RoundMode v454 = RoundMode::CAST_RINT;
          SaturationMode v455 = SaturationMode::ON;
          TCVT(v452, v450, v454, v455);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
          // pto: %tail_qr_rope_slice_inline5703__tile
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v456 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %tail_qr_rope_slice_inline5703__tile
          ;
          uint64_t v457 = (uint64_t) v24;
          TASSIGN(v456, v457);
          // pto: %142
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v458;
          // pto: %142
          ;
          uint64_t v459 = (uint64_t) v24;
          TASSIGN(v458, v459);
          // pto: %44
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v460 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %44
          ;
          uint64_t v461 = (uint64_t) v16;
          TASSIGN(v460, v461);
          // pto: %45
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v462 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %45
          ;
          uint64_t v463 = (uint64_t) v15;
          TASSIGN(v462, v463);
          // pto: %143
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v464;
          // pto: %143
          ;
          uint64_t v465 = (uint64_t) v24;
          TASSIGN(v464, v465);
          // pto: %46
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v466 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %46
          ;
          uint64_t v467 = (uint64_t) v18;
          TASSIGN(v466, v467);
          // pto: %144
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v468;
          // pto: %144
          ;
          uint64_t v469 = (uint64_t) v18;
          TASSIGN(v468, v469);
          // pto: %47
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v470 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %47
          ;
          uint64_t v471 = (uint64_t) v22;
          TASSIGN(v470, v471);
          // pto: %48
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v472 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %48
          ;
          uint64_t v473 = (uint64_t) v23;
          TASSIGN(v472, v473);
          TGATHER(v472, v464, v468, v470);
          // pto: %145
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v474;
          // pto: %145
          ;
          uint64_t v475 = (uint64_t) v16;
          TASSIGN(v474, v475);
          pipe_barrier(PIPE_V);
          TMOV(v474, v472);
          // pto: %tail_qr_swapped_inline5704__tile
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v476 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %tail_qr_swapped_inline5704__tile
          ;
          uint64_t v477 = (uint64_t) v16;
          TASSIGN(v476, v477);
          // pto: %50
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v478 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %50
          ;
          uint64_t v479 = (uint64_t) v15;
          TASSIGN(v478, v479);
          TMUL(v478, v458, v378);
          // pto: %51
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v480 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %51
          ;
          uint64_t v481 = (uint64_t) v16;
          TASSIGN(v480, v481);
          pipe_barrier(PIPE_V);
          TMUL(v480, v476, v387);
          // pto: %tail_rope_rot_inline5705__tile
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v482 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %tail_rope_rot_inline5705__tile
          ;
          uint64_t v483 = (uint64_t) v15;
          TASSIGN(v482, v483);
          pipe_barrier(PIPE_V);
          TADD(v482, v478, v480);
          // pto: %tail_rope_bf16_inline5706__tile
          ;
          Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v484 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %tail_rope_bf16_inline5706__tile
          ;
          uint64_t v485 = (uint64_t) v15;
          TASSIGN(v484, v485);
          pipe_barrier(PIPE_V);
          RoundMode v486 = RoundMode::CAST_RINT;
          SaturationMode v487 = SaturationMode::ON;
          TCVT(v484, v482, v486, v487);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
          // pto: %qr_bf16_2d_inline5662__iter_v9_pview
          ;
          __gm__ bfloat16_t* v488 = PTOAS__GLOBAL_TENSOR_DATA(v55);
          // pto: %qr_bf16_2d_inline5662__iter_v9_pview
          ;
          const int64_t v489 = 0;
          // pto: %qr_bf16_2d_inline5662__iter_v9_pview
          ;
          const int64_t v490 = 8192;
          // pto: %qr_bf16_2d_inline5662__iter_v9_pview
          ;
          pto::Shape<1, 1, 1, 1, 64> v491 = pto::Shape<1, 1, 1, 1, 64>();
          // pto: %qr_bf16_2d_inline5662__iter_v9_pview
          ;
          pto::Stride<8192, 8192, 8192, 8192, 1> v492 = pto::Stride<8192, 8192, 8192, 8192, 1>();
          // pto: %qr_bf16_2d_inline5662__iter_v9_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v493 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v488 + (v489 + v380 * v490 + v400), v491, v492);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
          pipe_barrier(PIPE_MTE3);
          TSTORE(v493, v452);
          // pto: %151
          ;
          int64_t v494 = (int64_t) ((uint64_t) v396 + (uint64_t) v35);
          // pto: %152
          ;
          int64_t v495 = v494 < v44 ? v44 : v494;
          // pto: %153
          ;
          __gm__ bfloat16_t* v496 = PTOAS__GLOBAL_TENSOR_DATA(v55);
          // pto: %153
          ;
          const int64_t v497 = 0;
          // pto: %153
          ;
          const int64_t v498 = 8192;
          // pto: %153
          ;
          pto::Shape<1, 1, 1, 1, 64> v499 = pto::Shape<1, 1, 1, 1, 64>();
          // pto: %153
          ;
          pto::Stride<8192, 8192, 8192, 8192, 1> v500 = pto::Stride<8192, 8192, 8192, 8192, 1>();
          // pto: %153
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v501 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v496 + (v497 + v380 * v498 + v495), v499, v500);
          pipe_barrier(PIPE_MTE3);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
          TSTORE(v501, v484);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
          // pto: %52
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v502 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %52
          ;
          uint64_t v503 = (uint64_t) v17;
          TASSIGN(v502, v503);
          // pto: %53
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v504 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %53
          ;
          uint64_t v505 = (uint64_t) v27;
          TASSIGN(v504, v505);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
          RoundMode v506 = RoundMode::CAST_NONE;
          SaturationMode v507 = SaturationMode::ON;
          TCVT(v504, v422, v506, v507);
          // pto: %54
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v508 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %54
          ;
          uint64_t v509 = (uint64_t) v17;
          TASSIGN(v508, v509);
          TMULS(v508, v502, v377);
          // pto: %55
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v510 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %55
          ;
          uint64_t v511 = (uint64_t) v17;
          TASSIGN(v510, v511);
          pipe_barrier(PIPE_V);
          TMUL(v510, v504, v508);
          // pto: %56
          ;
          Tile<TileType::Vec, bfloat16_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v512 = Tile<TileType::Vec, bfloat16_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %56
          ;
          uint64_t v513 = (uint64_t) v27;
          TASSIGN(v512, v513);
          pipe_barrier(PIPE_V);
          RoundMode v514 = RoundMode::CAST_RINT;
          SaturationMode v515 = SaturationMode::ON;
          TCVT(v512, v510, v514, v515);
          // pto: %57
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v516 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %57
          ;
          uint64_t v517 = (uint64_t) v17;
          TASSIGN(v516, v517);
          pipe_barrier(PIPE_V);
          RoundMode v518 = RoundMode::CAST_ROUND;
          SaturationMode v519 = SaturationMode::ON;
          TCVT(v516, v512, v518, v519);
          // pto: %58
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v520 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %58
          ;
          uint64_t v521 = (uint64_t) v17;
          TASSIGN(v520, v521);
          // pto: %154
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v522;
          // pto: %154
          ;
          uint64_t v523 = (uint64_t) v17;
          TASSIGN(v522, v523);
          // pto: %59
          ;
          Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v524 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %59
          ;
          uint64_t v525 = (uint64_t) v30;
          TASSIGN(v524, v525);
          pipe_barrier(PIPE_V);
          RoundMode v526 = RoundMode::CAST_RINT;
          SaturationMode v527 = SaturationMode::ON;
          TCVT(v524, v522, v526, v527);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
          // pto: %60
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v528 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %60
          ;
          uint64_t v529 = (uint64_t) v31;
          TASSIGN(v528, v529);
          // pto: %155
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v530;
          // pto: %155
          ;
          uint64_t v531 = (uint64_t) v31;
          TASSIGN(v530, v531);
          // pto: %61
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v532 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %61
          ;
          uint64_t v533 = (uint64_t) v27;
          TASSIGN(v532, v533);
          // pto: %62
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v534 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %62
          ;
          uint64_t v535 = (uint64_t) v17;
          TASSIGN(v534, v535);
          // pto: %156
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v536;
          // pto: %156
          ;
          uint64_t v537 = (uint64_t) v31;
          TASSIGN(v536, v537);
          // pto: %63
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v538 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %63
          ;
          uint64_t v539 = (uint64_t) v18;
          TASSIGN(v538, v539);
          // pto: %157
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v540;
          // pto: %157
          ;
          uint64_t v541 = (uint64_t) v18;
          TASSIGN(v540, v541);
          // pto: %64
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v542 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %64
          ;
          uint64_t v543 = (uint64_t) v25;
          TASSIGN(v542, v543);
          // pto: %65
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v544 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %65
          ;
          uint64_t v545 = (uint64_t) v26;
          TASSIGN(v544, v545);
          TGATHER(v544, v536, v540, v542);
          // pto: %158
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v546;
          // pto: %158
          ;
          uint64_t v547 = (uint64_t) v27;
          TASSIGN(v546, v547);
          pipe_barrier(PIPE_V);
          TMOV(v546, v544);
          // pto: %67
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v548 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %67
          ;
          uint64_t v549 = (uint64_t) v27;
          TASSIGN(v548, v549);
          // pto: %68
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v550 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %68
          ;
          uint64_t v551 = (uint64_t) v17;
          TASSIGN(v550, v551);
          TMUL(v550, v530, v378);
          // pto: %69
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v552 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %69
          ;
          uint64_t v553 = (uint64_t) v27;
          TASSIGN(v552, v553);
          pipe_barrier(PIPE_V);
          TMUL(v552, v548, v387);
          // pto: %70
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v554 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %70
          ;
          uint64_t v555 = (uint64_t) v17;
          TASSIGN(v554, v555);
          pipe_barrier(PIPE_V);
          TADD(v554, v550, v552);
          // pto: %71
          ;
          Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v556 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %71
          ;
          uint64_t v557 = (uint64_t) v17;
          TASSIGN(v556, v557);
          pipe_barrier(PIPE_V);
          RoundMode v558 = RoundMode::CAST_RINT;
          SaturationMode v559 = SaturationMode::ON;
          TCVT(v556, v554, v558, v559);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
          // pto: %162
          ;
          __gm__ bfloat16_t* v560 = PTOAS__GLOBAL_TENSOR_DATA(v55);
          // pto: %162
          ;
          const int64_t v561 = 0;
          // pto: %162
          ;
          const int64_t v562 = 8192;
          // pto: %162
          ;
          pto::Shape<1, 1, 1, 1, 64> v563 = pto::Shape<1, 1, 1, 1, 64>();
          // pto: %162
          ;
          pto::Stride<8192, 8192, 8192, 8192, 1> v564 = pto::Stride<8192, 8192, 8192, 8192, 1>();
          // pto: %162
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v565 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v560 + (v561 + v380 * v562 + v416), v563, v564);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
          pipe_barrier(PIPE_MTE3);
          TSTORE(v565, v524);
          // pto: %165
          ;
          int64_t v566 = (int64_t) ((uint64_t) v397 + (uint64_t) v35);
          // pto: %166
          ;
          int64_t v567 = v566 < v44 ? v44 : v566;
          // pto: %167
          ;
          __gm__ bfloat16_t* v568 = PTOAS__GLOBAL_TENSOR_DATA(v55);
          // pto: %167
          ;
          const int64_t v569 = 0;
          // pto: %167
          ;
          const int64_t v570 = 8192;
          // pto: %167
          ;
          pto::Shape<1, 1, 1, 1, 64> v571 = pto::Shape<1, 1, 1, 1, 64>();
          // pto: %167
          ;
          pto::Stride<8192, 8192, 8192, 8192, 1> v572 = pto::Stride<8192, 8192, 8192, 8192, 1>();
          // pto: %167
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v573 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v568 + (v569 + v380 * v570 + v567), v571, v572);
          pipe_barrier(PIPE_MTE3);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
          TSTORE(v573, v556);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        };
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      };
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}