#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void scatter_softmax_pool(__gm__ float* v1, __gm__ int32_t* v2, __gm__ int64_t* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ float* v6, __gm__ float* v7, __gm__ float* v8, __gm__ float* v9, int64_t v10, int64_t v11, int64_t v12, int64_t v13, int64_t v14, int64_t v15, int64_t v16, int64_t v17, int32_t v18, int32_t v19) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v20 = -7;
  // pto: %c0_i64
  const int64_t v21 = 0;
  // pto: %c16384_i64
  const int64_t v22 = 16384;
  // pto: %c40960_i64
  const int64_t v23 = 40960;
  // pto: %c32768_i64
  const int64_t v24 = 32768;
  // pto: %c34816_i64
  const int64_t v25 = 34816;
  // pto: %c36864_i64
  const int64_t v26 = 36864;
  // pto: %c38912_i64
  const int64_t v27 = 38912;
  const int64_t v28 = 24576;
  const int64_t v29 = 45056;
  const int64_t v30 = 43008;
  const int64_t v31 = 8192;
  const int64_t v32 = 4096;
  const int64_t v33 = 2048;
  // pto: %c384_index
  const int64_t v34 = 384;
  // pto: %c512_index
  const int64_t v35 = 512;
  // pto: %c1_index
  const int64_t v36 = 1;
  // pto: %c1024_index
  const int64_t v37 = 1024;
  // pto: %c4_index
  const int64_t v38 = 4;
  // pto: %c0_index
  const int64_t v39 = 0;
  // pto: %cst_19
  const float v40 = 0.0f;
  // pto: %c1_i64
  const int64_t v41 = 1;
  // pto: %c4_i64
  const int64_t v42 = 4;
  // pto: %c8_index
  const int64_t v43 = 8;
  // pto: %cst_24
  const float v44 = -3.40282347E+38f;
  // pto: %c2_i64
  const int64_t v45 = 2;
  // pto: %c2048_index
  const int64_t v46 = 2048;
  // pto: %c2_index
  const int64_t v47 = 2;
  // pto: %pooled_kv_inline5290__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %pooled_kv_inline5290__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %pooled_kv_inline5290__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %pooled_kv_inline5290__ssa_v0_view
  int64_t v51 = v34 * v35;
  // pto: %pooled_kv_inline5290__ssa_v0_view
  int64_t v52 = v50 * v51;
  // pto: %pooled_kv_inline5290__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v53 = pto::Shape<1, 1, 1, -1, -1>(v48, v49, v50, v34, v35);
  // pto: %pooled_kv_inline5290__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v54 = pto::Stride<-1, -1, -1, -1, -1>(v49 * v52, v52, v51, v35, v36);
  // pto: %pooled_kv_inline5290__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v55 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v53, v54);
  // pto: %compress_state__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %compress_state__ssa_v0_view
  const int64_t v57 = 1;
  // pto: %compress_state__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %compress_state__ssa_v0_view
  int64_t v59 = (int64_t) v16;
  // pto: %compress_state__ssa_v0_view
  int64_t v60 = (int64_t) v17;
  // pto: %compress_state__ssa_v0_view
  int64_t v61 = v59 * v60;
  // pto: %compress_state__ssa_v0_view
  int64_t v62 = v58 * v61;
  // pto: %compress_state__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v63 = pto::Shape<1, 1, 1, -1, -1>(v56, v57, v58, v59, (int64_t) v17);
  // pto: %compress_state__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v64 = pto::Stride<-1, -1, -1, -1, -1>(v57 * v62, v62, v61, v60, v36);
  // pto: %compress_state__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v65 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v63, v64);
  // pto: %cmp4_kv_proj_pad_inline5328__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %cmp4_kv_proj_pad_inline5328__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %cmp4_kv_proj_pad_inline5328__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %cmp4_kv_proj_pad_inline5328__ssa_v0_view
  int64_t v69 = v34 * v37;
  // pto: %cmp4_kv_proj_pad_inline5328__ssa_v0_view
  int64_t v70 = v68 * v69;
  // pto: %cmp4_kv_proj_pad_inline5328__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v71 = pto::Shape<1, 1, 1, -1, -1>(v66, v67, v68, v34, v37);
  // pto: %cmp4_kv_proj_pad_inline5328__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v67 * v70, v70, v69, v37, v36);
  // pto: %cmp4_kv_proj_pad_inline5328__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v73 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v71, v72);
  // pto: %cmp4_score_proj_pad_inline5329__ssa_v0_view
  const int64_t v74 = 1;
  // pto: %cmp4_score_proj_pad_inline5329__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %cmp4_score_proj_pad_inline5329__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %cmp4_score_proj_pad_inline5329__ssa_v0_view
  int64_t v77 = v34 * v37;
  // pto: %cmp4_score_proj_pad_inline5329__ssa_v0_view
  int64_t v78 = v76 * v77;
  // pto: %cmp4_score_proj_pad_inline5329__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v79 = pto::Shape<1, 1, 1, -1, -1>(v74, v75, v76, v34, v37);
  // pto: %cmp4_score_proj_pad_inline5329__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v80 = pto::Stride<-1, -1, -1, -1, -1>(v75 * v78, v78, v77, v37, v36);
  // pto: %cmp4_score_proj_pad_inline5329__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v81 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v79, v80);
  // pto: %cmp_ape__ssa_v0_view
  const int64_t v82 = 1;
  // pto: %cmp_ape__ssa_v0_view
  const int64_t v83 = 1;
  // pto: %cmp_ape__ssa_v0_view
  const int64_t v84 = 1;
  // pto: %cmp_ape__ssa_v0_view
  int64_t v85 = v38 * v37;
  // pto: %cmp_ape__ssa_v0_view
  int64_t v86 = v84 * v85;
  // pto: %cmp_ape__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v87 = pto::Shape<1, 1, 1, -1, -1>(v82, v83, v84, v38, v37);
  // pto: %cmp_ape__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v88 = pto::Stride<-1, -1, -1, -1, -1>(v83 * v86, v86, v85, v37, v36);
  // pto: %cmp_ape__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v89 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v87, v88);
  // pto: %score_inline5350__phi_v4
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v90 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %score_inline5350__phi_v4
  uint64_t v91 = (uint64_t) v27;
  TASSIGN(v90, v91);
  // pto: %value_inline5349__phi_v3
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v92 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %value_inline5349__phi_v3
  uint64_t v93 = (uint64_t) v26;
  TASSIGN(v92, v93);
  // pto: %score_inline5350__phi_v3
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %score_inline5350__phi_v3
  uint64_t v95 = (uint64_t) v27;
  TASSIGN(v94, v95);
  // pto: %value_inline5349__phi_v2
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v96 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %value_inline5349__phi_v2
  uint64_t v97 = (uint64_t) v26;
  TASSIGN(v96, v97);
  // pto: %score_inline5350__phi_v7
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v98 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %score_inline5350__phi_v7
  uint64_t v99 = (uint64_t) v24;
  TASSIGN(v98, v99);
  // pto: %value_inline5349__phi_v6
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v100 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %value_inline5349__phi_v6
  uint64_t v101 = (uint64_t) v23;
  TASSIGN(v100, v101);
  // pto: %score_inline5350__phi_v6
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %score_inline5350__phi_v6
  uint64_t v103 = (uint64_t) v24;
  TASSIGN(v102, v103);
  // pto: %value_inline5349__phi_v5
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v104 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %value_inline5349__phi_v5
  uint64_t v105 = (uint64_t) v23;
  TASSIGN(v104, v105);
  // pto: %pool_worker_inline5333__ssa_v0
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v106 = (int64_t) v18; v106 < v10; v106 += v11) {
    // pto: %3
    ;
    int32_t v107 = (v2)[v106];
    // pto: %4
    ;
    int64_t v108 = (int64_t) v107;
    // pto: %6, %5
    ;
    int32_t v109 = (v2)[(int64_t) ((uint64_t) v106 + (uint64_t) v36)];
    // pto: %7
    ;
    int64_t v110 = (int64_t) v109;
    // pto: %8
    ;
    // pto: %first_pos_b_inline5337__phi_v2
    ;
    int64_t v111;
    if (v108 < v110) {
      // pto: %9
      ;
      int64_t v112 = (v3)[v108];
      v111 = v112;
    } else {
      v111 = v39;
    };
    // pto: %c_len_inline5338__tile
    ;
    int32_t v113 = (v4)[v106];
    for (int64_t v114 = v108; v114 < v110; v114 += v36) {
      // pto: %token_pos_inline5342__tile
      ;
      int64_t v115 = (v3)[v114];
      // pto: %t__tile
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
      // pto: %t__tile
      ;
      uint64_t v117 = (uint64_t) v21;
      TASSIGN(v116, v117);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      TEXPANDS(v116, v40);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      // pto: %16
      ;
      int64_t v118 = v114 < v39 ? v39 : v114;
      // pto: %pooled_kv_inline5290__iter_v3_pview
      ;
      __gm__ float* v119 = PTOAS__GLOBAL_TENSOR_DATA(v55);
      // pto: %pooled_kv_inline5290__iter_v3_pview
      ;
      const int64_t v120 = 0;
      // pto: %pooled_kv_inline5290__iter_v3_pview
      ;
      const int64_t v121 = 512;
      // pto: %pooled_kv_inline5290__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v122 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %pooled_kv_inline5290__iter_v3_pview
      ;
      pto::Stride<512, 512, 512, 512, 1> v123 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %pooled_kv_inline5290__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v124 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v119 + (v120 + v118 * v121), v122, v123);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v124, v116);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      // pto: %19, %20
      ;
      int64_t v125 = (int64_t) ((uint64_t) v115 + (uint64_t) v41) % v42;
      // pto: %21, %22, %23
      ;
      int64_t v126 = v125 < v21 ? (int64_t) ((uint64_t) v125 + (uint64_t) v42) : v125;
      // pto: %17, %18, %24, %25
      ;
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      if ((int64_t) v113 > v39 & v126 == v21) {
        // pto: %window_values_inline5345__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v35);
        // pto: %window_values_inline5345__ssa_v0
        ;
        uint64_t v128 = (uint64_t) v21;
        TASSIGN(v127, v128);
        TEXPANDS(v127, v40);
        // pto: %window_scores_inline5346__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v35);
        // pto: %window_scores_inline5346__ssa_v0
        ;
        uint64_t v130 = (uint64_t) v22;
        TASSIGN(v129, v130);
        TEXPANDS(v129, v44);
        for (int64_t v131 = v39; v131 < v43; v131 += v36) {
          // pto: %29
          ;
          int64_t v132 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v115 + (uint64_t) v20) + (uint64_t) v131);
          // pto: %value_inline5349__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
          // pto: %value_inline5349__ssa_v0
          ;
          uint64_t v134 = (uint64_t) v23;
          TASSIGN(v133, v134);
          pipe_barrier(PIPE_V);
          TEXPANDS(v133, v40);
          // pto: %score_inline5350__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v135 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
          // pto: %score_inline5350__ssa_v0
          ;
          uint64_t v136 = (uint64_t) v24;
          TASSIGN(v135, v136);
          TEXPANDS(v135, v44);
          // pto: %30, %state_half_inline5351__phi_v2
          ;
          int64_t v137 = v131 >= v38 ? v35 : v39;
          // pto: %34
          ;
          bool v138 = v132 < v111;
          // pto: %32, %35
          ;
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
          if (v132 >= v39 & v138) {
            // pto: %score_inline5350__ssa_v1
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v139 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
            // pto: %score_inline5350__ssa_v1
            ;
            uint64_t v140 = (uint64_t) v25;
            TASSIGN(v139, v140);
            TEXPANDS(v139, v40);
            // pto: %37
            ;
            const int64_t v141 = 1;
            // pto: %37
            ;
            const int64_t v142 = 0;
            // pto: %37
            ;
            int64_t v143 = v132 / v45;
            // pto: %37
            ;
            bool v144 = v132 < v142;
            // pto: %37
            ;
            bool v145 = v45 < v142;
            // pto: %37
            ;
            bool v146 = v144 == v145;
            // pto: %37
            ;
            bool v147 = v132 % v45 != v142 && v144 != v145;
            // pto: %37
            ;
            int64_t v148 = v147 ? v143 - v141 : v143;
            // pto: %flat_offset_mul, %flat_offset, %36
            ;
            int32_t v149 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v15) + (uint64_t) v148)];
            // pto: %39
            ;
            int64_t v150 = (int64_t) v149;
            // pto: %40
            ;
            if (v150 >= v39) {
              // pto: %41
              ;
              int64_t v151 = v132 % v45;
              // pto: %42, %43, %44
              ;
              int64_t v152 = v151 < v21 ? (int64_t) ((uint64_t) v151 + (uint64_t) v45) : v151;
              // pto: %46, %47
              ;
              int64_t v153 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v152 * (uint64_t) v46) + (uint64_t) v137);
              // pto: %value_inline5349__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v154 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %value_inline5349__ssa_v1
              ;
              uint64_t v155 = (uint64_t) v26;
              TASSIGN(v154, v155);
              // pto: %48
              ;
              int64_t v156 = v150 < v39 ? v39 : v150;
              // pto: %49
              ;
              int64_t v157 = v153 < v39 ? v39 : v153;
              // pto: %compress_state__ssa_v0_pview
              ;
              int64_t v158 = (int64_t) v17;
              // pto: %compress_state__ssa_v0_pview
              ;
              const int64_t v159 = 0;
              // pto: %compress_state__ssa_v0_pview
              ;
              __gm__ float* v160 = PTOAS__GLOBAL_TENSOR_DATA(v65);
              // pto: %compress_state__ssa_v0_pview
              ;
              const int64_t v161 = 1;
              // pto: %compress_state__ssa_v0_pview
              ;
              const int64_t v162 = 1;
              // pto: %compress_state__ssa_v0_pview
              ;
              const int64_t v163 = 1;
              // pto: %compress_state__ssa_v0_pview
              ;
              int64_t v164 = v36 * v158;
              // pto: %compress_state__ssa_v0_pview
              ;
              int64_t v165 = v163 * v164;
              // pto: %compress_state__ssa_v0_pview
              ;
              pto::Shape<1, 1, 1, 1, 512> v166 = pto::Shape<1, 1, 1, 1, 512>(v161, v162, v163, v36, v35);
              // pto: %compress_state__ssa_v0_pview
              ;
              pto::Stride<-1, -1, -1, -1, -1> v167 = pto::Stride<-1, -1, -1, -1, -1>(v162 * v165, v165, v164, v158, v36);
              // pto: %compress_state__ssa_v0_pview
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v168 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v160 + (v159 + v156 * v158 + v157 * v36), v166, v167);
              TLOAD(v154, v168);
              // pto: %score_inline5350__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %score_inline5350__ssa_v2
              ;
              uint64_t v170 = (uint64_t) v27;
              TASSIGN(v169, v170);
              // pto: %51
              ;
              int64_t v171 = (int64_t) ((uint64_t) v153 + (uint64_t) v37);
              // pto: %52
              ;
              int64_t v172 = v171 < v39 ? v39 : v171;
              // pto: %53
              ;
              int64_t v173 = (int64_t) v17;
              // pto: %53
              ;
              const int64_t v174 = 0;
              // pto: %53
              ;
              __gm__ float* v175 = PTOAS__GLOBAL_TENSOR_DATA(v65);
              // pto: %53
              ;
              const int64_t v176 = 1;
              // pto: %53
              ;
              const int64_t v177 = 1;
              // pto: %53
              ;
              const int64_t v178 = 1;
              // pto: %53
              ;
              int64_t v179 = v36 * v173;
              // pto: %53
              ;
              int64_t v180 = v178 * v179;
              // pto: %53
              ;
              pto::Shape<1, 1, 1, 1, 512> v181 = pto::Shape<1, 1, 1, 1, 512>(v176, v177, v178, v36, v35);
              // pto: %53
              ;
              pto::Stride<-1, -1, -1, -1, -1> v182 = pto::Stride<-1, -1, -1, -1, -1>(v177 * v180, v180, v179, v173, v36);
              // pto: %53
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v183 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v175 + (v174 + v156 * v173 + v172 * v36), v181, v182);
              TLOAD(v169, v183);
            } else {
              // pto: %score_inline5350__ssa_v1_mv
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v184 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %score_inline5350__ssa_v1_mv
              ;
              uint64_t v185 = (uint64_t) v27;
              TASSIGN(v184, v185);
              pipe_barrier(PIPE_V);
              TMOV(v184, v139);
              // pto: %value_inline5349__ssa_v0_mv
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v186 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %value_inline5349__ssa_v0_mv
              ;
              uint64_t v187 = (uint64_t) v26;
              TASSIGN(v186, v187);
              TMOV(v186, v133);
            };
          } else {
            // pto: %score_inline5350__ssa_v0_mv
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v188 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
            // pto: %score_inline5350__ssa_v0_mv
            ;
            uint64_t v189 = (uint64_t) v27;
            TASSIGN(v188, v189);
            pipe_barrier(PIPE_V);
            TMOV(v188, v135);
            // pto: %0
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v190 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
            // pto: %0
            ;
            uint64_t v191 = (uint64_t) v26;
            TASSIGN(v190, v191);
            TMOV(v190, v133);
          };
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
          // pto: %55
          ;
          bool v192 = v111 <= v132;
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
          if (v192) {
            // pto: %56
            ;
            if (v132 <= v115) {
              // pto: %59
              ;
              uint64_t v193 = (uint64_t) v111;
              // pto: %58, %59
              ;
              int64_t v194 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v108 + (uint64_t) v132) - v193);
              // pto: %60
              ;
              int64_t v195 = v132 % v42;
              // pto: %61, %62, %63
              ;
              int64_t v196 = v195 < v21 ? (int64_t) ((uint64_t) v195 + (uint64_t) v42) : v195;
              // pto: %value_inline5349__ssa_v4
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v197 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %value_inline5349__ssa_v4
              ;
              uint64_t v198 = (uint64_t) v23;
              TASSIGN(v197, v198);
              // pto: %65
              ;
              int64_t v199 = v194 < v39 ? v39 : v194;
              // pto: %66
              ;
              int64_t v200 = v137 < v39 ? v39 : v137;
              // pto: %cmp4_kv_proj_pad_inline5328__ssa_v0_pview
              ;
              __gm__ float* v201 = PTOAS__GLOBAL_TENSOR_DATA(v73);
              // pto: %cmp4_kv_proj_pad_inline5328__ssa_v0_pview
              ;
              const int64_t v202 = 0;
              // pto: %cmp4_kv_proj_pad_inline5328__ssa_v0_pview
              ;
              const int64_t v203 = 1024;
              // pto: %cmp4_kv_proj_pad_inline5328__ssa_v0_pview
              ;
              pto::Shape<1, 1, 1, 1, 512> v204 = pto::Shape<1, 1, 1, 1, 512>();
              // pto: %cmp4_kv_proj_pad_inline5328__ssa_v0_pview
              ;
              pto::Stride<1024, 1024, 1024, 1024, 1> v205 = pto::Stride<1024, 1024, 1024, 1024, 1>();
              // pto: %cmp4_kv_proj_pad_inline5328__ssa_v0_pview
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v206 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v201 + (v202 + v199 * v203 + v200), v204, v205);
              TLOAD(v197, v206);
              // pto: %t__tmp_v147
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %t__tmp_v147
              ;
              uint64_t v208 = (uint64_t) v24;
              TASSIGN(v207, v208);
              // pto: %cmp4_score_proj_pad_inline5329__ssa_v0_pview
              ;
              __gm__ float* v209 = PTOAS__GLOBAL_TENSOR_DATA(v81);
              // pto: %cmp4_score_proj_pad_inline5329__ssa_v0_pview
              ;
              const int64_t v210 = 0;
              // pto: %cmp4_score_proj_pad_inline5329__ssa_v0_pview
              ;
              const int64_t v211 = 1024;
              // pto: %cmp4_score_proj_pad_inline5329__ssa_v0_pview
              ;
              pto::Shape<1, 1, 1, 1, 512> v212 = pto::Shape<1, 1, 1, 1, 512>();
              // pto: %cmp4_score_proj_pad_inline5329__ssa_v0_pview
              ;
              pto::Stride<1024, 1024, 1024, 1024, 1> v213 = pto::Stride<1024, 1024, 1024, 1024, 1>();
              // pto: %cmp4_score_proj_pad_inline5329__ssa_v0_pview
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v214 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v209 + (v210 + v199 * v211 + v200), v212, v213);
              TLOAD(v207, v214);
              // pto: %t__tmp_v148
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %t__tmp_v148
              ;
              uint64_t v216 = (uint64_t) v25;
              TASSIGN(v215, v216);
              // pto: %69
              ;
              int64_t v217 = v196 < v39 ? v39 : v196;
              // pto: %cmp_ape__ssa_v0_pview
              ;
              __gm__ float* v218 = PTOAS__GLOBAL_TENSOR_DATA(v89);
              // pto: %cmp_ape__ssa_v0_pview
              ;
              const int64_t v219 = 0;
              // pto: %cmp_ape__ssa_v0_pview
              ;
              const int64_t v220 = 1024;
              // pto: %cmp_ape__ssa_v0_pview
              ;
              pto::Shape<1, 1, 1, 1, 512> v221 = pto::Shape<1, 1, 1, 1, 512>();
              // pto: %cmp_ape__ssa_v0_pview
              ;
              pto::Stride<1024, 1024, 1024, 1024, 1> v222 = pto::Stride<1024, 1024, 1024, 1024, 1>();
              // pto: %cmp_ape__ssa_v0_pview
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v223 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v218 + (v219 + v217 * v220 + v200), v221, v222);
              TLOAD(v215, v223);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
              // pto: %score_inline5350__ssa_v5
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v224 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %score_inline5350__ssa_v5
              ;
              uint64_t v225 = (uint64_t) v24;
              TASSIGN(v224, v225);
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
              TADD(v224, v207, v215);
            } else {
              // pto: %score_inline5350__phi_v4_mv
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v226 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %score_inline5350__phi_v4_mv
              ;
              uint64_t v227 = (uint64_t) v24;
              TASSIGN(v226, v227);
              pipe_barrier(PIPE_V);
              TMOV(v226, v90);
              // pto: %value_inline5349__phi_v3_mv
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v228 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %value_inline5349__phi_v3_mv
              ;
              uint64_t v229 = (uint64_t) v23;
              TASSIGN(v228, v229);
              TMOV(v228, v92);
            };
          } else {
            // pto: %1
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v230 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
            // pto: %1
            ;
            uint64_t v231 = (uint64_t) v24;
            TASSIGN(v230, v231);
            pipe_barrier(PIPE_V);
            TMOV(v230, v90);
            // pto: %2
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v232 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
            // pto: %2
            ;
            uint64_t v233 = (uint64_t) v23;
            TASSIGN(v232, v233);
            TMOV(v232, v92);
          };
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
          // pto: %71
          ;
          int64_t v234 = v131 % v38;
          // pto: %72, %73, %74
          ;
          int64_t v235 = v234 < v39 ? (int64_t) ((uint64_t) v234 + (uint64_t) v38) : v234;
          // pto: %76
          ;
          const int64_t v236 = 1;
          // pto: %76
          ;
          const int64_t v237 = 0;
          // pto: %76
          ;
          int64_t v238 = v131 / v38;
          // pto: %76
          ;
          bool v239 = v131 < v237;
          // pto: %76
          ;
          bool v240 = v38 < v237;
          // pto: %76
          ;
          bool v241 = v239 == v240;
          // pto: %76
          ;
          bool v242 = v131 % v38 != v237 && v239 != v240;
          // pto: %76
          ;
          int64_t v243 = v242 ? v238 - v236 : v238;
          // pto: %75, %77, %assemble_view
          ;
          int64_t v244 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v235 * (uint64_t) v47) + (uint64_t) v243) * (uint64_t) v33);
          // pto: %assemble_view
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v245;
          // pto: %assemble_view
          ;
          uint64_t v246 = (uint64_t) v244;
          TASSIGN(v245, v246);
          pipe_barrier(PIPE_V);
          TMOV(v245, v100);
          // pto: %78
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v247;
          // pto: %78
          ;
          uint64_t v248 = (uint64_t) ((int64_t) (uint64_t) v244 + (uint64_t) v22);
          TASSIGN(v247, v248);
          TMOV(v247, v98);
        };
        // pto: %t__tmp_v149
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v249 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %t__tmp_v149
        ;
        uint64_t v250 = (uint64_t) v22;
        TASSIGN(v249, v250);
        // pto: %slice_view
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, 4, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v251;
        // pto: %slice_view
        ;
        uint64_t v252 = (uint64_t) v22;
        TASSIGN(v251, v252);
        // pto: %t__tmp_v150
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v253 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %t__tmp_v150
        ;
        uint64_t v254 = (uint64_t) v28;
        TASSIGN(v253, v254);
        // pto: %79
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, 4, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v255;
        // pto: %79
        ;
        uint64_t v256 = (uint64_t) v28;
        TASSIGN(v255, v256);
        // pto: %max4_inline5357__ssa_v0
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v257 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %max4_inline5357__ssa_v0
        ;
        uint64_t v258 = (uint64_t) v23;
        TASSIGN(v257, v258);
        pipe_barrier(PIPE_V);
        TMAX(v257, v251, v255);
        // pto: %t__tmp_v151
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v259 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %t__tmp_v151
        ;
        uint64_t v260 = (uint64_t) v23;
        TASSIGN(v259, v260);
        // pto: %80
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, 2, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v261;
        // pto: %80
        ;
        uint64_t v262 = (uint64_t) v23;
        TASSIGN(v261, v262);
        // pto: %t__tmp_v152
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v263 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %t__tmp_v152
        ;
        uint64_t v264 = (uint64_t) v29;
        TASSIGN(v263, v264);
        // pto: %81
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, 2, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v265;
        // pto: %81
        ;
        uint64_t v266 = (uint64_t) v29;
        TASSIGN(v265, v266);
        // pto: %max2_inline5358__ssa_v0
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v267 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %max2_inline5358__ssa_v0
        ;
        uint64_t v268 = (uint64_t) v23;
        TASSIGN(v267, v268);
        pipe_barrier(PIPE_V);
        TMAX(v267, v261, v265);
        // pto: %t__tmp_v153
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v269 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %t__tmp_v153
        ;
        uint64_t v270 = (uint64_t) v23;
        TASSIGN(v269, v270);
        // pto: %82
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v271;
        // pto: %82
        ;
        uint64_t v272 = (uint64_t) v23;
        TASSIGN(v271, v272);
        // pto: %t__tmp_v154
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v273 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %t__tmp_v154
        ;
        uint64_t v274 = (uint64_t) v30;
        TASSIGN(v273, v274);
        // pto: %83
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v275;
        // pto: %83
        ;
        uint64_t v276 = (uint64_t) v30;
        TASSIGN(v275, v276);
        // pto: %maximum_inline5359__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v277 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %maximum_inline5359__ssa_v0
        ;
        uint64_t v278 = (uint64_t) v23;
        TASSIGN(v277, v278);
        pipe_barrier(PIPE_V);
        TMAX(v277, v271, v275);
        // pto: %t__tmp_v155
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v279 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v35);
        // pto: %t__tmp_v155
        ;
        uint64_t v280 = (uint64_t) v22;
        TASSIGN(v279, v280);
        pipe_barrier(PIPE_V);
        TCOLEXPANDSUB(v279, v129, v277);
        // pto: %probability_inline5360__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v281 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v35);
        // pto: %probability_inline5360__ssa_v0
        ;
        uint64_t v282 = (uint64_t) v22;
        TASSIGN(v281, v282);
        pipe_barrier(PIPE_V);
        TEXP(v281, v279);
        // pto: %t__tmp_v156
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v283 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %t__tmp_v156
        ;
        uint64_t v284 = (uint64_t) v22;
        TASSIGN(v283, v284);
        // pto: %84
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, 4, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v285;
        // pto: %84
        ;
        uint64_t v286 = (uint64_t) v22;
        TASSIGN(v285, v286);
        // pto: %t__tmp_v157
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v287 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %t__tmp_v157
        ;
        uint64_t v288 = (uint64_t) v28;
        TASSIGN(v287, v288);
        // pto: %85
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, 4, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v289;
        // pto: %85
        ;
        uint64_t v290 = (uint64_t) v28;
        TASSIGN(v289, v290);
        // pto: %sum4_inline5361__ssa_v0
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v291 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %sum4_inline5361__ssa_v0
        ;
        uint64_t v292 = (uint64_t) v23;
        TASSIGN(v291, v292);
        pipe_barrier(PIPE_V);
        TADD(v291, v285, v289);
        // pto: %t__tmp_v158
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v293 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %t__tmp_v158
        ;
        uint64_t v294 = (uint64_t) v23;
        TASSIGN(v293, v294);
        // pto: %86
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, 2, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v295;
        // pto: %86
        ;
        uint64_t v296 = (uint64_t) v23;
        TASSIGN(v295, v296);
        // pto: %t__tmp_v159
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v297 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %t__tmp_v159
        ;
        uint64_t v298 = (uint64_t) v29;
        TASSIGN(v297, v298);
        // pto: %87
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, 2, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v299;
        // pto: %87
        ;
        uint64_t v300 = (uint64_t) v29;
        TASSIGN(v299, v300);
        // pto: %sum2_inline5362__ssa_v0
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v301 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %sum2_inline5362__ssa_v0
        ;
        uint64_t v302 = (uint64_t) v23;
        TASSIGN(v301, v302);
        pipe_barrier(PIPE_V);
        TADD(v301, v295, v299);
        // pto: %t__tmp_v160
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v303 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %t__tmp_v160
        ;
        uint64_t v304 = (uint64_t) v23;
        TASSIGN(v303, v304);
        // pto: %88
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v305;
        // pto: %88
        ;
        uint64_t v306 = (uint64_t) v23;
        TASSIGN(v305, v306);
        // pto: %t__tmp_v161
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v307 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %t__tmp_v161
        ;
        uint64_t v308 = (uint64_t) v30;
        TASSIGN(v307, v308);
        // pto: %89
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309;
        // pto: %89
        ;
        uint64_t v310 = (uint64_t) v30;
        TASSIGN(v309, v310);
        // pto: %total_inline5363__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v311 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %total_inline5363__ssa_v0
        ;
        uint64_t v312 = (uint64_t) v23;
        TASSIGN(v311, v312);
        pipe_barrier(PIPE_V);
        TADD(v311, v305, v309);
        // pto: %probability_v1_inline5364__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v35);
        // pto: %probability_v1_inline5364__ssa_v0
        ;
        uint64_t v314 = (uint64_t) v22;
        TASSIGN(v313, v314);
        pipe_barrier(PIPE_V);
        TCOLEXPANDDIV(v313, v281, v311);
        // pto: %weighted_inline5365__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v35);
        // pto: %weighted_inline5365__ssa_v0
        ;
        uint64_t v316 = (uint64_t) v21;
        TASSIGN(v315, v316);
        pipe_barrier(PIPE_V);
        TMUL(v315, v127, v313);
        // pto: %t__tmp_v162
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v317 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %t__tmp_v162
        ;
        uint64_t v318 = (uint64_t) v21;
        TASSIGN(v317, v318);
        // pto: %90
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, 4, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v319;
        // pto: %90
        ;
        uint64_t v320 = (uint64_t) v21;
        TASSIGN(v319, v320);
        // pto: %t__tmp_v163
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v321 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %t__tmp_v163
        ;
        uint64_t v322 = (uint64_t) v31;
        TASSIGN(v321, v322);
        // pto: %91
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, 4, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v323;
        // pto: %91
        ;
        uint64_t v324 = (uint64_t) v31;
        TASSIGN(v323, v324);
        // pto: %weighted4_inline5366__ssa_v0
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v325 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %weighted4_inline5366__ssa_v0
        ;
        uint64_t v326 = (uint64_t) v21;
        TASSIGN(v325, v326);
        pipe_barrier(PIPE_V);
        TADD(v325, v319, v323);
        // pto: %t__tmp_v164
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v327 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %t__tmp_v164
        ;
        uint64_t v328 = (uint64_t) v21;
        TASSIGN(v327, v328);
        // pto: %92
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, 2, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v329;
        // pto: %92
        ;
        uint64_t v330 = (uint64_t) v21;
        TASSIGN(v329, v330);
        // pto: %t__tmp_v165
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v331 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %t__tmp_v165
        ;
        uint64_t v332 = (uint64_t) v32;
        TASSIGN(v331, v332);
        // pto: %93
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, 2, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v333;
        // pto: %93
        ;
        uint64_t v334 = (uint64_t) v32;
        TASSIGN(v333, v334);
        // pto: %weighted2_inline5367__ssa_v0
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v335 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %weighted2_inline5367__ssa_v0
        ;
        uint64_t v336 = (uint64_t) v21;
        TASSIGN(v335, v336);
        pipe_barrier(PIPE_V);
        TADD(v335, v329, v333);
        // pto: %t__tmp_v166
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v337 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %t__tmp_v166
        ;
        uint64_t v338 = (uint64_t) v21;
        TASSIGN(v337, v338);
        // pto: %94
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v339;
        // pto: %94
        ;
        uint64_t v340 = (uint64_t) v21;
        TASSIGN(v339, v340);
        // pto: %t__tmp_v167
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v341 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %t__tmp_v167
        ;
        uint64_t v342 = (uint64_t) v33;
        TASSIGN(v341, v342);
        // pto: %95
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v343;
        // pto: %95
        ;
        uint64_t v344 = (uint64_t) v33;
        TASSIGN(v343, v344);
        // pto: %pooled_row_inline5368__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v345 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %pooled_row_inline5368__ssa_v0
        ;
        uint64_t v346 = (uint64_t) v21;
        TASSIGN(v345, v346);
        pipe_barrier(PIPE_V);
        TADD(v345, v339, v343);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v124, v345);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    };
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}