#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qproj_matmul(__gm__ int32_t* v1, __gm__ int8_t* v2, __gm__ int8_t* v3, int64_t v4, int64_t v5, int64_t v6, int64_t v7, int32_t v8, int32_t v9) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int64_t v10 = 151;
  // pto: %c0_i64
  const int64_t v11 = 0;
  // pto: %c262144_i64
  const int64_t v12 = 262144;
  // pto: %c8192_i64
  const int64_t v13 = 8192;
  // pto: %c32768_i64
  const int64_t v14 = 32768;
  // pto: %c32768_index
  const int64_t v15 = 32768;
  // pto: %c1_index
  const int64_t v16 = 1;
  // pto: %c1024_index
  const int64_t v17 = 1024;
  // pto: %c64_index
  const int64_t v18 = 64;
  // pto: %c16_index
  const int64_t v19 = 16;
  // pto: %c32_index
  const int64_t v20 = 32;
  // pto: %c33554432_index
  const int64_t v21 = 33554432;
  // pto: %c512_index
  const int64_t v22 = 512;
  // pto: %c0_index
  const int64_t v23 = 0;
  // pto: %c128_index
  const int64_t v24 = 128;
  // pto: %c24_index
  const int64_t v25 = 24;
  // pto: %c256_index
  const int64_t v26 = 256;
  // pto: %cn128_index
  const int64_t v27 = -128;
  // pto: %q_proj_i32_inline5095__ssa_v0_view
  const int64_t v28 = 1;
  // pto: %q_proj_i32_inline5095__ssa_v0_view
  const int64_t v29 = 1;
  // pto: %q_proj_i32_inline5095__ssa_v0_view
  const int64_t v30 = 1;
  // pto: %q_proj_i32_inline5095__ssa_v0_view
  int64_t v31 = (int64_t) v7;
  // pto: %q_proj_i32_inline5095__ssa_v0_view
  int64_t v32 = v31 * v15;
  // pto: %q_proj_i32_inline5095__ssa_v0_view
  int64_t v33 = v30 * v32;
  // pto: %q_proj_i32_inline5095__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v34 = pto::Shape<1, 1, 1, -1, -1>(v28, v29, v30, v31, v15);
  // pto: %q_proj_i32_inline5095__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v35 = pto::Stride<-1, -1, -1, -1, -1>(v29 * v33, v33, v32, v15, v16);
  // pto: %q_proj_i32_inline5095__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v36 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v34, v35);
  // pto: %wq_b__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v37 = pto::Shape<-1, -1, -1, -1, -1>(v16, v17, v18, v19, v20);
  // pto: %wq_b__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v38 = pto::Stride<-1, -1, -1, -1, -1>(v21, v15, v22, v20, v16);
  // pto: %wq_b__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v39 = GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v2, v37, v38);
  // pto: %qr_i8_matmul_inline4920__rv_v2_view
  const int64_t v40 = 1;
  // pto: %qr_i8_matmul_inline4920__rv_v2_view
  const int64_t v41 = 1;
  // pto: %qr_i8_matmul_inline4920__rv_v2_view
  const int64_t v42 = 1;
  // pto: %qr_i8_matmul_inline4920__rv_v2_view
  int64_t v43 = v22 * v17;
  // pto: %qr_i8_matmul_inline4920__rv_v2_view
  int64_t v44 = v42 * v43;
  // pto: %qr_i8_matmul_inline4920__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v45 = pto::Shape<1, 1, 1, -1, -1>(v40, v41, v42, v22, v17);
  // pto: %qr_i8_matmul_inline4920__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v46 = pto::Stride<-1, -1, -1, -1, -1>(v41 * v44, v44, v43, v17, v16);
  // pto: %qr_i8_matmul_inline4920__rv_v2_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v47 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v45, v46);
  // pto: %qproj_worker_inline5101__ssa_v0
  int64_t v48 = (int64_t) v8;
  int64_t v49 = (int64_t) ((uint64_t) v10 - (uint64_t) v48);
  // pto: %8
  const int64_t v50 = 1;
  // pto: %8
  const int64_t v51 = 0;
  // pto: %8
  int64_t v52 = v49 / v25;
  // pto: %8
  bool v53 = v49 < v51;
  // pto: %8
  bool v54 = v25 < v51;
  // pto: %8
  bool v55 = v53 == v54;
  // pto: %8
  bool v56 = v49 % v25 != v51 && v53 != v54;
  // pto: %8
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  for (int64_t v57 = v23; v57 < (v56 ? v52 - v50 : v52); v57 += v16) {
    // pto: %10, %9, %11
    ;
    int64_t v58 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v48 + (uint64_t) ((int64_t) (uint64_t) v57 * (uint64_t) v25)) * (uint64_t) v26);
    // pto: %wq_full_inline5105__tile
    ;
    Tile<TileType::Mat, int8_t, 1024, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v59 = Tile<TileType::Mat, int8_t, 1024, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v17, v26);
    // pto: %wq_full_inline5105__tile
    ;
    uint64_t v60 = (uint64_t) v11;
    TASSIGN(v59, v60);
    // pto: %12
    ;
    const int64_t v61 = 1;
    // pto: %12
    ;
    const int64_t v62 = 0;
    // pto: %12
    ;
    int64_t v63 = v58 / v20;
    // pto: %12
    ;
    bool v64 = v58 < v62;
    // pto: %12
    ;
    bool v65 = v20 < v62;
    // pto: %12
    ;
    bool v66 = v64 == v65;
    // pto: %12
    ;
    bool v67 = v58 % v20 != v62 && v64 != v65;
    // pto: %12
    ;
    int64_t v68 = v67 ? v63 - v61 : v63;
    // pto: %13
    ;
    int64_t v69 = v68 < v23 ? v23 : v68;
    // pto: %wq_b__ssa_v0_pview
    ;
    __gm__ int8_t* v70 = PTOAS__GLOBAL_TENSOR_DATA(v39);
    // pto: %wq_b__ssa_v0_pview
    ;
    const int64_t v71 = 0;
    // pto: %wq_b__ssa_v0_pview
    ;
    const int64_t v72 = 32768;
    // pto: %wq_b__ssa_v0_pview
    ;
    pto::Shape<1, 8, 64, 16, 32> v73 = pto::Shape<1, 8, 64, 16, 32>();
    // pto: %wq_b__ssa_v0_pview
    ;
    pto::Stride<33554432, 32768, 512, 32, 1> v74 = pto::Stride<33554432, 32768, 512, 32, 1>();
    // pto: %wq_b__ssa_v0_pview
    ;
    GlobalTensor<int8_t, pto::Shape<1, 8, 64, 16, 32>, pto::Stride<33554432, 32768, 512, 32, 1>, pto::Layout::NZ> v75 = GlobalTensor<int8_t, pto::Shape<1, 8, 64, 16, 32>, pto::Stride<33554432, 32768, 512, 32, 1>, pto::Layout::NZ>(v70 + (v71 + v69 * v72), v73, v74);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v59, v75);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    for (int64_t v76 = v23; v76 < v4; v76 += v18) {
      // pto: %qr_full_inline5107__tile
      ;
      Tile<TileType::Mat, int8_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v77 = Tile<TileType::Mat, int8_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v17);
      // pto: %qr_full_inline5107__tile
      ;
      uint64_t v78 = (uint64_t) v12;
      TASSIGN(v77, v78);
      // pto: %14
      ;
      int64_t v79 = v76 < v23 ? v23 : v76;
      // pto: %qr_i8_matmul_inline4920__rv_v2_pview
      ;
      __gm__ int8_t* v80 = PTOAS__GLOBAL_TENSOR_DATA(v47);
      // pto: %qr_i8_matmul_inline4920__rv_v2_pview
      ;
      const int64_t v81 = 0;
      // pto: %qr_i8_matmul_inline4920__rv_v2_pview
      ;
      const int64_t v82 = 1024;
      // pto: %qr_i8_matmul_inline4920__rv_v2_pview
      ;
      pto::Shape<1, 1, 1, 64, 1024> v83 = pto::Shape<1, 1, 1, 64, 1024>();
      // pto: %qr_i8_matmul_inline4920__rv_v2_pview
      ;
      pto::Stride<65536, 65536, 65536, 1024, 1> v84 = pto::Stride<65536, 65536, 65536, 1024, 1>();
      // pto: %qr_i8_matmul_inline4920__rv_v2_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, 64, 1024>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND> v85 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 64, 1024>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND>(v80 + (v81 + v79 * v82), v83, v84);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v77, v85);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %col_acc_inline5108__tile_l0_init
      ;
      Tile<TileType::Acc, int32_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v86 = Tile<TileType::Acc, int32_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v18, v26);
      // pto: %col_acc_inline5108__tile_l0_init
      ;
      uint64_t v87 = (uint64_t) v11;
      TASSIGN(v86, v87);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
      for (int64_t v88 = v23; v88 < v17; v88 += v26) {
        // pto: %col_acc_inline5108__tile_l0_a
        ;
        Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v89 = Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v24);
        // pto: %col_acc_inline5108__tile_l0_a
        ;
        uint64_t v90 = (uint64_t) v11;
        TASSIGN(v89, v90);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        pipe_barrier(PIPE_MTE1);
        uint16_t v91 = static_cast<uint16_t>(v23);
        uint16_t v92 = static_cast<uint16_t>(v88);
        TEXTRACT(v89, v77, v91, v92);
        // pto: %col_acc_inline5108__tile_l0_b
        ;
        Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v24, v26);
        // pto: %col_acc_inline5108__tile_l0_b
        ;
        uint64_t v94 = (uint64_t) v11;
        TASSIGN(v93, v94);
        uint16_t v95 = static_cast<uint16_t>(v88);
        uint16_t v96 = static_cast<uint16_t>(v23);
        TEXTRACT(v93, v59, v95, v96);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %0
        ;
        Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v24);
        // pto: %0
        ;
        uint64_t v98 = (uint64_t) v13;
        TASSIGN(v97, v98);
        // pto: %15
        ;
        int64_t v99 = (int64_t) ((uint64_t) v88 + (uint64_t) v24);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v100 = static_cast<uint16_t>(v23);
        uint16_t v101 = static_cast<uint16_t>(v99);
        TEXTRACT(v97, v77, v100, v101);
        // pto: %1
        ;
        Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v24, v26);
        // pto: %1
        ;
        uint64_t v103 = (uint64_t) v14;
        TASSIGN(v102, v103);
        uint16_t v104 = static_cast<uint16_t>(v99);
        uint16_t v105 = static_cast<uint16_t>(v23);
        TEXTRACT(v102, v59, v104, v105);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %17
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        if (v88 == v23) {
          pipe_barrier(PIPE_M);
          TMATMUL(v86, v89, v93);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v86, v86, v89, v93);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        // pto: %18
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        if (v88 == v27) {
          pipe_barrier(PIPE_M);
          TMATMUL(v86, v97, v102);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v86, v86, v97, v102);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %20
      ;
      int64_t v106 = v58 < v23 ? v23 : v58;
      // pto: %q_proj_i32_inline5095__iter_v3_pview
      ;
      __gm__ int32_t* v107 = PTOAS__GLOBAL_TENSOR_DATA(v36);
      // pto: %q_proj_i32_inline5095__iter_v3_pview
      ;
      const int64_t v108 = 0;
      // pto: %q_proj_i32_inline5095__iter_v3_pview
      ;
      const int64_t v109 = 32768;
      // pto: %q_proj_i32_inline5095__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, 64, 256> v110 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %q_proj_i32_inline5095__iter_v3_pview
      ;
      pto::Stride<2097152, 2097152, 2097152, 32768, 1> v111 = pto::Stride<2097152, 2097152, 2097152, 32768, 1>();
      // pto: %q_proj_i32_inline5095__iter_v3_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<2097152, 2097152, 2097152, 32768, 1>, pto::Layout::ND> v112 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<2097152, 2097152, 2097152, 32768, 1>, pto::Layout::ND>(v107 + (v108 + v79 * v109 + v106), v110, v111);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      pipe_barrier(PIPE_FIX);
      TSTORE(v112, v86);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
    };
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
    for (int64_t v113 = v4; v113 < v5; v113 += v18) {
      // pto: %21
      ;
      int64_t v114 = (int64_t) ((uint64_t) v6 - (uint64_t) v113);
      // pto: %22
      ;
      int64_t v115 = v114 < v18 ? v114 : v18;
      // pto: %qr_tail_inline5111__tile
      ;
      Tile<TileType::Mat, int8_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Mat, int8_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v115, v17);
      // pto: %qr_tail_inline5111__tile
      ;
      uint64_t v117 = (uint64_t) v12;
      TASSIGN(v116, v117);
      // pto: %23
      ;
      int64_t v118 = v113 < v23 ? v23 : v113;
      // pto: %24
      ;
      const int64_t v119 = 0;
      // pto: %24
      ;
      __gm__ int8_t* v120 = PTOAS__GLOBAL_TENSOR_DATA(v47);
      // pto: %24
      ;
      const int64_t v121 = 1;
      // pto: %24
      ;
      const int64_t v122 = 1;
      // pto: %24
      ;
      const int64_t v123 = 1;
      // pto: %24
      ;
      int64_t v124 = v115 * v17;
      // pto: %24
      ;
      int64_t v125 = v123 * v124;
      // pto: %24
      ;
      pto::Shape<1, 1, 1, -1, 1024> v126 = pto::Shape<1, 1, 1, -1, 1024>(v121, v122, v123, v115, v17);
      // pto: %24
      ;
      pto::Stride<-1, -1, -1, -1, -1> v127 = pto::Stride<-1, -1, -1, -1, -1>(v122 * v125, v125, v124, v17, v16);
      // pto: %24
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v128 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v120 + (v119 + v118 * v17 + v23 * v16), v126, v127);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v116, v128);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %tail_acc_inline5112__tile_l0_init_storage
      ;
      Tile<TileType::Acc, int32_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v129 = Tile<TileType::Acc, int32_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v18, v26);
      // pto: %tail_acc_inline5112__tile_l0_init_storage
      ;
      uint64_t v130 = (uint64_t) v11;
      TASSIGN(v129, v130);
      v129.SetValidShape(v115, v26);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
      for (int64_t v131 = v23; v131 < v17; v131 += v26) {
        // pto: %tail_acc_inline5112__tile_l0_a
        ;
        Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v132 = Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v115, v24);
        // pto: %tail_acc_inline5112__tile_l0_a
        ;
        uint64_t v133 = (uint64_t) v11;
        TASSIGN(v132, v133);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        uint16_t v134 = static_cast<uint16_t>(v23);
        uint16_t v135 = static_cast<uint16_t>(v131);
        TEXTRACT(v132, v116, v134, v135);
        // pto: %tail_acc_inline5112__tile_l0_b
        ;
        Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v136 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v24, v26);
        // pto: %tail_acc_inline5112__tile_l0_b
        ;
        uint64_t v137 = (uint64_t) v11;
        TASSIGN(v136, v137);
        uint16_t v138 = static_cast<uint16_t>(v131);
        uint16_t v139 = static_cast<uint16_t>(v23);
        TEXTRACT(v136, v59, v138, v139);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %3
        ;
        Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v140 = Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v115, v24);
        // pto: %3
        ;
        uint64_t v141 = (uint64_t) v13;
        TASSIGN(v140, v141);
        // pto: %25
        ;
        int64_t v142 = (int64_t) ((uint64_t) v131 + (uint64_t) v24);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        uint16_t v143 = static_cast<uint16_t>(v23);
        uint16_t v144 = static_cast<uint16_t>(v142);
        TEXTRACT(v140, v116, v143, v144);
        // pto: %4
        ;
        Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v145 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v24, v26);
        // pto: %4
        ;
        uint64_t v146 = (uint64_t) v14;
        TASSIGN(v145, v146);
        pipe_barrier(PIPE_MTE1);
        uint16_t v147 = static_cast<uint16_t>(v142);
        uint16_t v148 = static_cast<uint16_t>(v23);
        TEXTRACT(v145, v59, v147, v148);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        // pto: %27
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        if (v131 == v23) {
          pipe_barrier(PIPE_M);
          TMATMUL(v129, v132, v136);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v129, v129, v132, v136);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        // pto: %28
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        if (v131 == v27) {
          pipe_barrier(PIPE_M);
          TMATMUL(v129, v140, v145);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v129, v129, v140, v145);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      };
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      // pto: %31
      ;
      int64_t v149 = v58 < v23 ? v23 : v58;
      // pto: %q_proj_i32_inline5095__iter_v6_pview
      ;
      const int64_t v150 = 0;
      // pto: %q_proj_i32_inline5095__iter_v6_pview
      ;
      __gm__ int32_t* v151 = PTOAS__GLOBAL_TENSOR_DATA(v36);
      // pto: %q_proj_i32_inline5095__iter_v6_pview
      ;
      const int64_t v152 = 1;
      // pto: %q_proj_i32_inline5095__iter_v6_pview
      ;
      const int64_t v153 = 1;
      // pto: %q_proj_i32_inline5095__iter_v6_pview
      ;
      const int64_t v154 = 1;
      // pto: %q_proj_i32_inline5095__iter_v6_pview
      ;
      int64_t v155 = v115 * v15;
      // pto: %q_proj_i32_inline5095__iter_v6_pview
      ;
      int64_t v156 = v154 * v155;
      // pto: %q_proj_i32_inline5095__iter_v6_pview
      ;
      pto::Shape<1, 1, 1, -1, 256> v157 = pto::Shape<1, 1, 1, -1, 256>(v152, v153, v154, v115, v26);
      // pto: %q_proj_i32_inline5095__iter_v6_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v158 = pto::Stride<-1, -1, -1, -1, -1>(v153 * v156, v156, v155, v15, v16);
      // pto: %q_proj_i32_inline5095__iter_v6_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v159 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v151 + (v150 + v118 * v15 + v149 * v16), v157, v158);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      pipe_barrier(PIPE_FIX);
      TSTORE(v159, v129);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
    };
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}