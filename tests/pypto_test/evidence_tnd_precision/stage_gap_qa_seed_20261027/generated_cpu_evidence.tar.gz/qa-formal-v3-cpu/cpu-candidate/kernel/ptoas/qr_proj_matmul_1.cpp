#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qr_proj_matmul_1(__gm__ float* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, int64_t v4, int64_t v5, int64_t v6, int64_t v7, int64_t v8, int64_t v9, int32_t v10, int32_t v11) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v12 = 0;
  // pto: %c32768_i64
  const int64_t v13 = 32768;
  // pto: %c49152_i64
  const int64_t v14 = 49152;
  // pto: %c81920_i64
  const int64_t v15 = 81920;
  // pto: %c16384_i64
  const int64_t v16 = 16384;
  // pto: %c1024_index
  const int64_t v17 = 1024;
  // pto: %c1_index
  const int64_t v18 = 1;
  // pto: %c4096_index
  const int64_t v19 = 4096;
  // pto: %c256_index
  const int64_t v20 = 256;
  // pto: %c64_index
  const int64_t v21 = 64;
  // pto: %c16_index
  const int64_t v22 = 16;
  // pto: %c4194304_index
  const int64_t v23 = 4194304;
  // pto: %c16384_index
  const int64_t v24 = 16384;
  // pto: %c32_index
  const int64_t v25 = 32;
  // pto: %c96_index
  const int64_t v26 = 96;
  // pto: %c0_index
  const int64_t v27 = 0;
  // pto: %c2_index
  const int64_t v28 = 2;
  // pto: %c9_index
  const int64_t v29 = 9;
  // pto: %c7_index
  const int64_t v30 = 7;
  // pto: %c8_index
  const int64_t v31 = 8;
  // pto: %cn1_index
  const int64_t v32 = -1;
  // pto: %qr_fp32_inline2899__phi_v30_view
  const int64_t v33 = 1;
  // pto: %qr_fp32_inline2899__phi_v30_view
  const int64_t v34 = 1;
  // pto: %qr_fp32_inline2899__phi_v30_view
  const int64_t v35 = 1;
  // pto: %qr_fp32_inline2899__phi_v30_view
  int64_t v36 = (int64_t) v8;
  // pto: %qr_fp32_inline2899__phi_v30_view
  int64_t v37 = v36 * v17;
  // pto: %qr_fp32_inline2899__phi_v30_view
  int64_t v38 = v35 * v37;
  // pto: %qr_fp32_inline2899__phi_v30_view
  pto::Shape<1, 1, 1, -1, -1> v39 = pto::Shape<1, 1, 1, -1, -1>(v33, v34, v35, v36, v17);
  // pto: %qr_fp32_inline2899__phi_v30_view
  pto::Stride<-1, -1, -1, -1, -1> v40 = pto::Stride<-1, -1, -1, -1, -1>(v34 * v38, v38, v37, v17, v18);
  // pto: %qr_fp32_inline2899__phi_v30_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v41 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v39, v40);
  // pto: %x_view_inline2961__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %x_view_inline2961__ssa_v0_view
  const int64_t v43 = 1;
  // pto: %x_view_inline2961__ssa_v0_view
  const int64_t v44 = 1;
  // pto: %x_view_inline2961__ssa_v0_view
  int64_t v45 = (int64_t) v9;
  // pto: %x_view_inline2961__ssa_v0_view
  int64_t v46 = v45 * v19;
  // pto: %x_view_inline2961__ssa_v0_view
  int64_t v47 = v44 * v46;
  // pto: %x_view_inline2961__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v48 = pto::Shape<1, 1, 1, -1, -1>(v42, v43, v44, v45, v19);
  // pto: %x_view_inline2961__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v49 = pto::Stride<-1, -1, -1, -1, -1>(v43 * v47, v47, v46, v19, v18);
  // pto: %x_view_inline2961__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v50 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v48, v49);
  // pto: %wq_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v51 = pto::Shape<-1, -1, -1, -1, -1>(v18, v20, v21, v22, v22);
  // pto: %wq_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v52 = pto::Stride<-1, -1, -1, -1, -1>(v23, v24, v20, v22, v18);
  // pto: %wq_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v53 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v3, v51, v52);
  // pto: %qbg_idx_inline2967__ssa_v0, %14
  int64_t v54 = (int64_t) ((uint64_t) ((int64_t) v10) * (uint64_t) v25);
  // pto: %15
  const int64_t v55 = 1;
  // pto: %15
  const int64_t v56 = 0;
  // pto: %15
  int64_t v57 = v54 / v26;
  // pto: %15
  bool v58 = v54 < v56;
  // pto: %15
  bool v59 = v26 < v56;
  // pto: %15
  bool v60 = v58 == v59;
  // pto: %15
  bool v61 = v54 % v26 != v56 && v58 != v59;
  // pto: %15
  int64_t v62 = v61 ? v57 - v55 : v57;
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  for (int64_t v63 = v27; v63 < v4; v63 += v21) {
    // pto: %16
    ;
    int64_t v64 = (int64_t) ((uint64_t) v5 + (uint64_t) v63);
    // pto: %dense_acc_inline2973__tile
    ;
    Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v65 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v21, v25);
    // pto: %dense_acc_inline2973__tile
    ;
    uint64_t v66 = (uint64_t) v12;
    TASSIGN(v65, v66);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    for (int64_t v67 = v27; v67 < v22; v67 += v28) {
      // pto: %17
      ;
      int64_t v68 = (int64_t) ((uint64_t) v67 + (uint64_t) v18);
      // pto: %18
      ;
      bool v69 = v62 < v29;
      // pto: %dense_k_order_inline2975__phi_v2
      ;
      int64_t v70;
      if (v69) {
        // pto: %19
        ;
        const int64_t v71 = 1;
        // pto: %19
        ;
        const int64_t v72 = 0;
        // pto: %19
        ;
        int64_t v73 = v67 / v28;
        // pto: %19
        ;
        bool v74 = v67 < v72;
        // pto: %19
        ;
        bool v75 = v28 < v72;
        // pto: %19
        ;
        bool v76 = v74 == v75;
        // pto: %19
        ;
        bool v77 = v67 % v28 != v72 && v74 != v75;
        // pto: %19
        ;
        int64_t v78 = v77 ? v73 - v71 : v73;
        // pto: %20
        ;
        int64_t v79 = v62 % v28;
        // pto: %21, %22, %23
        ;
        int64_t v80 = v79 < v27 ? (int64_t) ((uint64_t) v79 + (uint64_t) v28) : v79;
        // pto: %24
        ;
        // pto: %native_packet_inline2976__phi_v2
        ;
        int64_t v81;
        if (v80 == v18) {
          // pto: %25
          ;
          v81 = (int64_t) ((uint64_t) v30 - (uint64_t) v78);
        } else {
          v81 = v78;
        };
        // pto: %26
        ;
        const int64_t v82 = 1;
        // pto: %26
        ;
        const int64_t v83 = 0;
        // pto: %26
        ;
        int64_t v84 = v62 / v28;
        // pto: %26
        ;
        bool v85 = v62 < v83;
        // pto: %26
        ;
        bool v86 = v28 < v83;
        // pto: %26
        ;
        bool v87 = v85 == v86;
        // pto: %26
        ;
        bool v88 = v62 % v28 != v83 && v85 != v86;
        // pto: %26
        ;
        int64_t v89 = v88 ? v84 - v82 : v84;
        // pto: %27
        ;
        uint64_t v90 = (uint64_t) v81;
        // pto: %27, %28
        ;
        int64_t v91 = (int64_t) ((uint64_t) v89 + v90) % v31;
        // pto: %29, %30, %31
        ;
        int64_t v92 = v91 < v27 ? (int64_t) ((uint64_t) v91 + (uint64_t) v31) : v91;
        // pto: %33
        ;
        int64_t v93 = v67 % v28;
        // pto: %34, %35, %36
        ;
        int64_t v94 = v93 < v27 ? (int64_t) ((uint64_t) v93 + (uint64_t) v28) : v93;
        // pto: %32, %37
        ;
        v70 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v92 * (uint64_t) v28) + (uint64_t) v94);
      } else {
        v70 = v67;
      };
      // pto: %38
      ;
      bool v95 = v70 < v27;
      // pto: %38
      ;
      int64_t v96 = v95 ? v27 : v70;
      // pto: %39
      ;
      int64_t v97 = (int64_t) ((uint64_t) v96 * (uint64_t) v20);
      // pto: %dense_x_inline2978__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v98 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v21, v20);
      // pto: %dense_x_inline2978__tile
      ;
      uint64_t v99 = (uint64_t) v12;
      TASSIGN(v98, v99);
      // pto: %40
      ;
      int64_t v100 = v64 < v27 ? v27 : v64;
      // pto: %41
      ;
      int64_t v101 = v97 < v27 ? v27 : v97;
      // pto: %x_view_inline2961__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v102 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %x_view_inline2961__ssa_v0_pview
      ;
      const int64_t v103 = 0;
      // pto: %x_view_inline2961__ssa_v0_pview
      ;
      const int64_t v104 = 4096;
      // pto: %x_view_inline2961__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 64, 256> v105 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %x_view_inline2961__ssa_v0_pview
      ;
      pto::Stride<262144, 262144, 262144, 4096, 1> v106 = pto::Stride<262144, 262144, 262144, 4096, 1>();
      // pto: %x_view_inline2961__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND> v107 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND>(v102 + (v103 + v100 * v104 + v101), v105, v106);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v98, v107);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %dense_w_inline2979__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v20);
      // pto: %dense_w_inline2979__tile
      ;
      uint64_t v109 = (uint64_t) v13;
      TASSIGN(v108, v109);
      // pto: %42
      ;
      const int64_t v110 = 1;
      // pto: %42
      ;
      const int64_t v111 = 0;
      // pto: %42
      ;
      int64_t v112 = v97 / v22;
      // pto: %42
      ;
      bool v113 = v97 < v111;
      // pto: %42
      ;
      bool v114 = v22 < v111;
      // pto: %42
      ;
      bool v115 = v113 == v114;
      // pto: %42
      ;
      bool v116 = v97 % v22 != v111 && v113 != v114;
      // pto: %42
      ;
      int64_t v117 = v116 ? v112 - v110 : v112;
      // pto: %43
      ;
      int64_t v118 = v117 < v27 ? v27 : v117;
      // pto: %44
      ;
      const int64_t v119 = 1;
      // pto: %44
      ;
      const int64_t v120 = 0;
      // pto: %44
      ;
      int64_t v121 = v54 / v22;
      // pto: %44
      ;
      bool v122 = v54 < v120;
      // pto: %44
      ;
      bool v123 = v22 < v120;
      // pto: %44
      ;
      bool v124 = v122 == v123;
      // pto: %44
      ;
      bool v125 = v54 % v22 != v120 && v122 != v123;
      // pto: %44
      ;
      int64_t v126 = v125 ? v121 - v119 : v121;
      // pto: %45
      ;
      int64_t v127 = v126 < v27 ? v27 : v126;
      // pto: %wq_a__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v128 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %wq_a__ssa_v0_pview
      ;
      const int64_t v129 = 0;
      // pto: %wq_a__ssa_v0_pview
      ;
      const int64_t v130 = 16384;
      // pto: %wq_a__ssa_v0_pview
      ;
      const int64_t v131 = 256;
      // pto: %wq_a__ssa_v0_pview
      ;
      pto::Shape<1, 16, 2, 16, 16> v132 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %wq_a__ssa_v0_pview
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v133 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %wq_a__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v134 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v128 + (v129 + v118 * v130 + v127 * v131), v132, v133);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v108, v134);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %47
      ;
      int64_t v135;
      if (v69) {
        // pto: %49
        ;
        const int64_t v136 = 1;
        // pto: %49
        ;
        const int64_t v137 = 0;
        // pto: %49
        ;
        int64_t v138 = v68 / v28;
        // pto: %49
        ;
        bool v139 = v68 < v137;
        // pto: %49
        ;
        bool v140 = v28 < v137;
        // pto: %49
        ;
        bool v141 = v139 == v140;
        // pto: %49
        ;
        bool v142 = v68 % v28 != v137 && v139 != v140;
        // pto: %49
        ;
        int64_t v143 = v142 ? v138 - v136 : v138;
        // pto: %50
        ;
        int64_t v144 = v62 % v28;
        // pto: %51, %52, %53
        ;
        int64_t v145 = v144 < v27 ? (int64_t) ((uint64_t) v144 + (uint64_t) v28) : v144;
        // pto: %54
        ;
        // pto: %55
        ;
        int64_t v146;
        if (v145 == v18) {
          // pto: %56
          ;
          v146 = (int64_t) ((uint64_t) v30 - (uint64_t) v143);
        } else {
          v146 = v143;
        };
        // pto: %57
        ;
        const int64_t v147 = 1;
        // pto: %57
        ;
        const int64_t v148 = 0;
        // pto: %57
        ;
        int64_t v149 = v62 / v28;
        // pto: %57
        ;
        bool v150 = v62 < v148;
        // pto: %57
        ;
        bool v151 = v28 < v148;
        // pto: %57
        ;
        bool v152 = v150 == v151;
        // pto: %57
        ;
        bool v153 = v62 % v28 != v148 && v150 != v151;
        // pto: %57
        ;
        int64_t v154 = v153 ? v149 - v147 : v149;
        // pto: %58
        ;
        uint64_t v155 = (uint64_t) v146;
        // pto: %58, %59
        ;
        int64_t v156 = (int64_t) ((uint64_t) v154 + v155) % v31;
        // pto: %60, %61, %62
        ;
        int64_t v157 = v156 < v27 ? (int64_t) ((uint64_t) v156 + (uint64_t) v31) : v156;
        // pto: %65
        ;
        int64_t v158 = v68 % v28;
        // pto: %66, %67, %68
        ;
        int64_t v159 = v158 < v27 ? (int64_t) ((uint64_t) v158 + (uint64_t) v28) : v158;
        // pto: %63, %69
        ;
        v135 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v157 * (uint64_t) v28) + (uint64_t) v159);
      } else {
        v135 = v68;
      };
      // pto: %70
      ;
      bool v160 = v135 < v27;
      // pto: %70
      ;
      int64_t v161 = v160 ? v27 : v135;
      // pto: %71
      ;
      int64_t v162 = (int64_t) ((uint64_t) v161 * (uint64_t) v20);
      // pto: %0
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v163 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v21, v20);
      // pto: %0
      ;
      uint64_t v164 = (uint64_t) v14;
      TASSIGN(v163, v164);
      // pto: %73
      ;
      int64_t v165 = v162 < v27 ? v27 : v162;
      // pto: %74
      ;
      __gm__ bfloat16_t* v166 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %74
      ;
      const int64_t v167 = 0;
      // pto: %74
      ;
      const int64_t v168 = 4096;
      // pto: %74
      ;
      pto::Shape<1, 1, 1, 64, 256> v169 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %74
      ;
      pto::Stride<262144, 262144, 262144, 4096, 1> v170 = pto::Stride<262144, 262144, 262144, 4096, 1>();
      // pto: %74
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND> v171 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND>(v166 + (v167 + v100 * v168 + v165), v169, v170);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v163, v171);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      // pto: %1
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v172 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v20);
      // pto: %1
      ;
      uint64_t v173 = (uint64_t) v15;
      TASSIGN(v172, v173);
      // pto: %75
      ;
      const int64_t v174 = 1;
      // pto: %75
      ;
      const int64_t v175 = 0;
      // pto: %75
      ;
      int64_t v176 = v162 / v22;
      // pto: %75
      ;
      bool v177 = v162 < v175;
      // pto: %75
      ;
      bool v178 = v22 < v175;
      // pto: %75
      ;
      bool v179 = v177 == v178;
      // pto: %75
      ;
      bool v180 = v162 % v22 != v175 && v177 != v178;
      // pto: %75
      ;
      int64_t v181 = v180 ? v176 - v174 : v176;
      // pto: %76
      ;
      int64_t v182 = v181 < v27 ? v27 : v181;
      // pto: %79
      ;
      __gm__ bfloat16_t* v183 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %79
      ;
      const int64_t v184 = 0;
      // pto: %79
      ;
      const int64_t v185 = 16384;
      // pto: %79
      ;
      const int64_t v186 = 256;
      // pto: %79
      ;
      pto::Shape<1, 16, 2, 16, 16> v187 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %79
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v188 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %79
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v189 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v183 + (v184 + v182 * v185 + v127 * v186), v187, v188);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v172, v189);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %dense_w_inline2979__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v190 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %dense_w_inline2979__tile_t
      ;
      uint64_t v191 = (uint64_t) v13;
      TASSIGN(v190, v191);
      // pto: %dense_x_inline2978__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v192 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v21, v20);
      // pto: %dense_x_inline2978__tile_Left
      ;
      uint64_t v193 = (uint64_t) v13;
      TASSIGN(v192, v193);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      TMOV(v192, v98);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %dense_w_inline2979__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v194 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %dense_w_inline2979__tile_t_Right
      ;
      uint64_t v195 = (uint64_t) v16;
      TASSIGN(v194, v195);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      TMOV(v194, v190);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %80
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (v67 == v27) {
        pipe_barrier(PIPE_M);
        TMATMUL(v65, v192, v194);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v65, v65, v192, v194);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      // pto: %3
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v196 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %3
      ;
      uint64_t v197 = (uint64_t) v15;
      TASSIGN(v196, v197);
      // pto: %4
      ;
      Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v198 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v21, v20);
      // pto: %4
      ;
      uint64_t v199 = (uint64_t) v12;
      TASSIGN(v198, v199);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      TMOV(v198, v163);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      // pto: %5
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v200 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %5
      ;
      uint64_t v201 = (uint64_t) v12;
      TASSIGN(v200, v201);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      TMOV(v200, v196);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      // pto: %81
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      if (v67 == v32) {
        pipe_barrier(PIPE_M);
        TMATMUL(v65, v198, v200);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v65, v65, v198, v200);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    };
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %82
    ;
    int64_t v202 = v63 < v27 ? v27 : v63;
    // pto: %83
    ;
    int64_t v203 = v54 < v27 ? v27 : v54;
    // pto: %qr_fp32_inline2899__iter_v31_pview
    ;
    __gm__ float* v204 = PTOAS__GLOBAL_TENSOR_DATA(v41);
    // pto: %qr_fp32_inline2899__iter_v31_pview
    ;
    const int64_t v205 = 0;
    // pto: %qr_fp32_inline2899__iter_v31_pview
    ;
    const int64_t v206 = 1024;
    // pto: %qr_fp32_inline2899__iter_v31_pview
    ;
    pto::Shape<1, 1, 1, 64, 32> v207 = pto::Shape<1, 1, 1, 64, 32>();
    // pto: %qr_fp32_inline2899__iter_v31_pview
    ;
    pto::Stride<65536, 65536, 65536, 1024, 1> v208 = pto::Stride<65536, 65536, 65536, 1024, 1>();
    // pto: %qr_fp32_inline2899__iter_v31_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 64, 32>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND> v209 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 32>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND>(v204 + (v205 + v202 * v206 + v203), v207, v208);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE(v209, v65);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  for (int64_t v210 = v4; v210 < v6; v210 += v22) {
    // pto: %q_acc_inline2981__tile
    ;
    Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %q_acc_inline2981__tile
    ;
    uint64_t v212 = (uint64_t) v12;
    TASSIGN(v211, v212);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    for (int64_t v213 = v27; v213 < v22; v213 += v28) {
      // pto: %84
      ;
      int64_t v214 = (int64_t) ((uint64_t) v7 - (uint64_t) v210);
      // pto: %85
      ;
      int64_t v215 = v214 < v22 ? v214 : v22;
      // pto: %86
      ;
      int64_t v216 = (int64_t) ((uint64_t) v5 + (uint64_t) v210);
      // pto: %87
      ;
      int64_t v217 = (int64_t) ((uint64_t) v213 + (uint64_t) v18);
      // pto: %91
      ;
      bool v218 = v62 < v29;
      // pto: %qr_k_order_inline2983__phi_v2
      ;
      int64_t v219;
      if (v218) {
        // pto: %92
        ;
        const int64_t v220 = 1;
        // pto: %92
        ;
        const int64_t v221 = 0;
        // pto: %92
        ;
        int64_t v222 = v213 / v28;
        // pto: %92
        ;
        bool v223 = v213 < v221;
        // pto: %92
        ;
        bool v224 = v28 < v221;
        // pto: %92
        ;
        bool v225 = v223 == v224;
        // pto: %92
        ;
        bool v226 = v213 % v28 != v221 && v223 != v224;
        // pto: %92
        ;
        int64_t v227 = v226 ? v222 - v220 : v222;
        // pto: %93
        ;
        int64_t v228 = v62 % v28;
        // pto: %94, %95, %96
        ;
        int64_t v229 = v228 < v27 ? (int64_t) ((uint64_t) v228 + (uint64_t) v28) : v228;
        // pto: %97
        ;
        // pto: %native_packet_v1_inline2984__phi_v2
        ;
        int64_t v230;
        if (v229 == v18) {
          // pto: %98
          ;
          v230 = (int64_t) ((uint64_t) v30 - (uint64_t) v227);
        } else {
          v230 = v227;
        };
        // pto: %99
        ;
        const int64_t v231 = 1;
        // pto: %99
        ;
        const int64_t v232 = 0;
        // pto: %99
        ;
        int64_t v233 = v62 / v28;
        // pto: %99
        ;
        bool v234 = v62 < v232;
        // pto: %99
        ;
        bool v235 = v28 < v232;
        // pto: %99
        ;
        bool v236 = v234 == v235;
        // pto: %99
        ;
        bool v237 = v62 % v28 != v232 && v234 != v235;
        // pto: %99
        ;
        int64_t v238 = v237 ? v233 - v231 : v233;
        // pto: %100
        ;
        uint64_t v239 = (uint64_t) v230;
        // pto: %100, %101
        ;
        int64_t v240 = (int64_t) ((uint64_t) v238 + v239) % v31;
        // pto: %102, %103, %104
        ;
        int64_t v241 = v240 < v27 ? (int64_t) ((uint64_t) v240 + (uint64_t) v31) : v240;
        // pto: %106
        ;
        int64_t v242 = v213 % v28;
        // pto: %107, %108, %109
        ;
        int64_t v243 = v242 < v27 ? (int64_t) ((uint64_t) v242 + (uint64_t) v28) : v242;
        // pto: %105, %110
        ;
        v219 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v241 * (uint64_t) v28) + (uint64_t) v243);
      } else {
        v219 = v213;
      };
      // pto: %111
      ;
      bool v244 = v219 < v27;
      // pto: %111
      ;
      int64_t v245 = v244 ? v27 : v219;
      // pto: %112
      ;
      int64_t v246 = (int64_t) ((uint64_t) v245 * (uint64_t) v20);
      // pto: %q_x_chunk_bf16_inline2988__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v247 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v215, v20);
      // pto: %q_x_chunk_bf16_inline2988__tile
      ;
      uint64_t v248 = (uint64_t) v13;
      TASSIGN(v247, v248);
      // pto: %113
      ;
      int64_t v249 = v216 < v27 ? v27 : v216;
      // pto: %114
      ;
      int64_t v250 = v246 < v27 ? v27 : v246;
      // pto: %115
      ;
      const int64_t v251 = 0;
      // pto: %115
      ;
      __gm__ bfloat16_t* v252 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %115
      ;
      const int64_t v253 = 1;
      // pto: %115
      ;
      const int64_t v254 = 1;
      // pto: %115
      ;
      const int64_t v255 = 1;
      // pto: %115
      ;
      int64_t v256 = v215 * v19;
      // pto: %115
      ;
      int64_t v257 = v255 * v256;
      // pto: %115
      ;
      pto::Shape<1, 1, 1, -1, 256> v258 = pto::Shape<1, 1, 1, -1, 256>(v253, v254, v255, v215, v20);
      // pto: %115
      ;
      pto::Stride<-1, -1, -1, -1, -1> v259 = pto::Stride<-1, -1, -1, -1, -1>(v254 * v257, v257, v256, v19, v18);
      // pto: %115
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v260 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v252 + (v251 + v249 * v19 + v250 * v18), v258, v259);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      TLOAD(v247, v260);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      // pto: %w_chunk_inline2989__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v261 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v20);
      // pto: %w_chunk_inline2989__tile
      ;
      uint64_t v262 = (uint64_t) v12;
      TASSIGN(v261, v262);
      // pto: %116
      ;
      const int64_t v263 = 1;
      // pto: %116
      ;
      const int64_t v264 = 0;
      // pto: %116
      ;
      int64_t v265 = v246 / v22;
      // pto: %116
      ;
      bool v266 = v246 < v264;
      // pto: %116
      ;
      bool v267 = v22 < v264;
      // pto: %116
      ;
      bool v268 = v266 == v267;
      // pto: %116
      ;
      bool v269 = v246 % v22 != v264 && v266 != v267;
      // pto: %116
      ;
      int64_t v270 = v269 ? v265 - v263 : v265;
      // pto: %117
      ;
      int64_t v271 = v270 < v27 ? v27 : v270;
      // pto: %118
      ;
      const int64_t v272 = 1;
      // pto: %118
      ;
      const int64_t v273 = 0;
      // pto: %118
      ;
      int64_t v274 = v54 / v22;
      // pto: %118
      ;
      bool v275 = v54 < v273;
      // pto: %118
      ;
      bool v276 = v22 < v273;
      // pto: %118
      ;
      bool v277 = v275 == v276;
      // pto: %118
      ;
      bool v278 = v54 % v22 != v273 && v275 != v276;
      // pto: %118
      ;
      int64_t v279 = v278 ? v274 - v272 : v274;
      // pto: %119
      ;
      int64_t v280 = v279 < v27 ? v27 : v279;
      // pto: %120
      ;
      __gm__ bfloat16_t* v281 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %120
      ;
      const int64_t v282 = 0;
      // pto: %120
      ;
      const int64_t v283 = 16384;
      // pto: %120
      ;
      const int64_t v284 = 256;
      // pto: %120
      ;
      pto::Shape<1, 16, 2, 16, 16> v285 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %120
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v286 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %120
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v287 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v281 + (v282 + v271 * v283 + v280 * v284), v285, v286);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      TLOAD(v261, v287);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      // pto: %122
      ;
      int64_t v288;
      if (v218) {
        // pto: %124
        ;
        const int64_t v289 = 1;
        // pto: %124
        ;
        const int64_t v290 = 0;
        // pto: %124
        ;
        int64_t v291 = v217 / v28;
        // pto: %124
        ;
        bool v292 = v217 < v290;
        // pto: %124
        ;
        bool v293 = v28 < v290;
        // pto: %124
        ;
        bool v294 = v292 == v293;
        // pto: %124
        ;
        bool v295 = v217 % v28 != v290 && v292 != v293;
        // pto: %124
        ;
        int64_t v296 = v295 ? v291 - v289 : v291;
        // pto: %125
        ;
        int64_t v297 = v62 % v28;
        // pto: %126, %127, %128
        ;
        int64_t v298 = v297 < v27 ? (int64_t) ((uint64_t) v297 + (uint64_t) v28) : v297;
        // pto: %129
        ;
        // pto: %130
        ;
        int64_t v299;
        if (v298 == v18) {
          // pto: %131
          ;
          v299 = (int64_t) ((uint64_t) v30 - (uint64_t) v296);
        } else {
          v299 = v296;
        };
        // pto: %132
        ;
        const int64_t v300 = 1;
        // pto: %132
        ;
        const int64_t v301 = 0;
        // pto: %132
        ;
        int64_t v302 = v62 / v28;
        // pto: %132
        ;
        bool v303 = v62 < v301;
        // pto: %132
        ;
        bool v304 = v28 < v301;
        // pto: %132
        ;
        bool v305 = v303 == v304;
        // pto: %132
        ;
        bool v306 = v62 % v28 != v301 && v303 != v304;
        // pto: %132
        ;
        int64_t v307 = v306 ? v302 - v300 : v302;
        // pto: %133
        ;
        uint64_t v308 = (uint64_t) v299;
        // pto: %133, %134
        ;
        int64_t v309 = (int64_t) ((uint64_t) v307 + v308) % v31;
        // pto: %135, %136, %137
        ;
        int64_t v310 = v309 < v27 ? (int64_t) ((uint64_t) v309 + (uint64_t) v31) : v309;
        // pto: %140
        ;
        int64_t v311 = v217 % v28;
        // pto: %141, %142, %143
        ;
        int64_t v312 = v311 < v27 ? (int64_t) ((uint64_t) v311 + (uint64_t) v28) : v311;
        // pto: %138, %144
        ;
        v288 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v310 * (uint64_t) v28) + (uint64_t) v312);
      } else {
        v288 = v217;
      };
      // pto: %145
      ;
      bool v313 = v288 < v27;
      // pto: %145
      ;
      int64_t v314 = v313 ? v27 : v288;
      // pto: %146
      ;
      int64_t v315 = (int64_t) ((uint64_t) v314 * (uint64_t) v20);
      // pto: %7
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v316 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v215, v20);
      // pto: %7
      ;
      uint64_t v317 = (uint64_t) v15;
      TASSIGN(v316, v317);
      // pto: %148
      ;
      int64_t v318 = v315 < v27 ? v27 : v315;
      // pto: %149
      ;
      const int64_t v319 = 0;
      // pto: %149
      ;
      __gm__ bfloat16_t* v320 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %149
      ;
      const int64_t v321 = 1;
      // pto: %149
      ;
      const int64_t v322 = 1;
      // pto: %149
      ;
      const int64_t v323 = 1;
      // pto: %149
      ;
      int64_t v324 = v215 * v19;
      // pto: %149
      ;
      int64_t v325 = v323 * v324;
      // pto: %149
      ;
      pto::Shape<1, 1, 1, -1, 256> v326 = pto::Shape<1, 1, 1, -1, 256>(v321, v322, v323, v215, v20);
      // pto: %149
      ;
      pto::Stride<-1, -1, -1, -1, -1> v327 = pto::Stride<-1, -1, -1, -1, -1>(v322 * v325, v325, v324, v19, v18);
      // pto: %149
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v328 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v320 + (v319 + v249 * v19 + v318 * v18), v326, v327);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      TLOAD(v316, v328);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
      // pto: %8
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v329 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v20);
      // pto: %8
      ;
      uint64_t v330 = (uint64_t) v14;
      TASSIGN(v329, v330);
      // pto: %150
      ;
      const int64_t v331 = 1;
      // pto: %150
      ;
      const int64_t v332 = 0;
      // pto: %150
      ;
      int64_t v333 = v315 / v22;
      // pto: %150
      ;
      bool v334 = v315 < v332;
      // pto: %150
      ;
      bool v335 = v22 < v332;
      // pto: %150
      ;
      bool v336 = v334 == v335;
      // pto: %150
      ;
      bool v337 = v315 % v22 != v332 && v334 != v335;
      // pto: %150
      ;
      int64_t v338 = v337 ? v333 - v331 : v333;
      // pto: %151
      ;
      int64_t v339 = v338 < v27 ? v27 : v338;
      // pto: %154
      ;
      __gm__ bfloat16_t* v340 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %154
      ;
      const int64_t v341 = 0;
      // pto: %154
      ;
      const int64_t v342 = 16384;
      // pto: %154
      ;
      const int64_t v343 = 256;
      // pto: %154
      ;
      pto::Shape<1, 16, 2, 16, 16> v344 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %154
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v345 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %154
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v346 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v340 + (v341 + v339 * v342 + v280 * v343), v344, v345);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v329, v346);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
      // pto: %w_chunk_inline2989__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v347 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %w_chunk_inline2989__tile_t
      ;
      uint64_t v348 = (uint64_t) v12;
      TASSIGN(v347, v348);
      // pto: %q_x_chunk_bf16_inline2988__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v349 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v215, v20);
      // pto: %q_x_chunk_bf16_inline2988__tile_Left
      ;
      uint64_t v350 = (uint64_t) v13;
      TASSIGN(v349, v350);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      TMOV(v349, v247);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      // pto: %w_chunk_inline2989__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v351 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %w_chunk_inline2989__tile_t_Right
      ;
      uint64_t v352 = (uint64_t) v16;
      TASSIGN(v351, v352);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      TMOV(v351, v347);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      // pto: %155
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      if (v213 == v27) {
        pipe_barrier(PIPE_M);
        TMATMUL(v211, v349, v351);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v211, v211, v349, v351);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      // pto: %10
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v353 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %10
      ;
      uint64_t v354 = (uint64_t) v14;
      TASSIGN(v353, v354);
      // pto: %11
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v355 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v215, v20);
      // pto: %11
      ;
      uint64_t v356 = (uint64_t) v12;
      TASSIGN(v355, v356);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      TMOV(v355, v316);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      // pto: %12
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v357 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %12
      ;
      uint64_t v358 = (uint64_t) v12;
      TASSIGN(v357, v358);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
      TMOV(v357, v353);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %156
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      if (v213 == v32) {
        pipe_barrier(PIPE_M);
        TMATMUL(v211, v355, v357);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v211, v211, v355, v357);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    };
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
    // pto: %158
    ;
    int64_t v359 = v210 < v27 ? v27 : v210;
    // pto: %159
    ;
    int64_t v360 = v54 < v27 ? v27 : v54;
    // pto: %qr_fp32_inline2899__iter_v34_pview
    ;
    __gm__ float* v361 = PTOAS__GLOBAL_TENSOR_DATA(v41);
    // pto: %qr_fp32_inline2899__iter_v34_pview
    ;
    const int64_t v362 = 0;
    // pto: %qr_fp32_inline2899__iter_v34_pview
    ;
    const int64_t v363 = 1024;
    // pto: %qr_fp32_inline2899__iter_v34_pview
    ;
    pto::Shape<1, 1, 1, 16, 32> v364 = pto::Shape<1, 1, 1, 16, 32>();
    // pto: %qr_fp32_inline2899__iter_v34_pview
    ;
    pto::Stride<16384, 16384, 16384, 1024, 1> v365 = pto::Stride<16384, 16384, 16384, 1024, 1>();
    // pto: %qr_fp32_inline2899__iter_v34_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND> v366 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND>(v361 + (v362 + v359 * v363 + v360), v364, v365);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
    pipe_barrier(PIPE_FIX);
    TSTORE(v366, v211);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}