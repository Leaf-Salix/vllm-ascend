#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void kv_score_proj_0(__gm__ int32_t* v1, __gm__ float* v2, __gm__ float* v3, __gm__ bfloat16_t* v4, __gm__ bfloat16_t* v5, __gm__ bfloat16_t* v6, int64_t v7, int64_t v8, int64_t v9, int64_t v10, int32_t v11, int32_t v12) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v13 = 0;
  // pto: %c1024_i64
  const int64_t v14 = 1024;
  // pto: %c32768_i64
  const int64_t v15 = 32768;
  // pto: %c40960_i64
  const int64_t v16 = 40960;
  // pto: %c8192_i64
  const int64_t v17 = 8192;
  // pto: %c16384_i64
  const int64_t v18 = 16384;
  // pto: %c24576_i64
  const int64_t v19 = 24576;
  // pto: %c1_index
  const int64_t v20 = 1;
  // pto: %c384_index
  const int64_t v21 = 384;
  // pto: %c256_index
  const int64_t v22 = 256;
  // pto: %c4096_index
  const int64_t v23 = 4096;
  // pto: %c0_index
  const int64_t v24 = 0;
  // pto: %c0_i32
  const int32_t v25 = 0;
  // pto: %c1536_index
  const int64_t v26 = 1536;
  // pto: %c16_index
  const int64_t v27 = 16;
  // pto: %c64_index
  const int64_t v28 = 64;
  // pto: %c24_index
  const int64_t v29 = 24;
  // pto: %c2_index
  const int64_t v30 = 2;
  // pto: %c128_index
  const int64_t v31 = 128;
  // pto: %cn1_index
  const int64_t v32 = -1;
  // pto: %kv_proj_pad_inline3447__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %kv_proj_pad_inline3447__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %kv_proj_pad_inline3447__ssa_v0_view
  const int64_t v35 = 1;
  // pto: %kv_proj_pad_inline3447__ssa_v0_view
  int64_t v36 = v21 * v22;
  // pto: %kv_proj_pad_inline3447__ssa_v0_view
  int64_t v37 = v35 * v36;
  // pto: %kv_proj_pad_inline3447__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v38 = pto::Shape<1, 1, 1, -1, -1>(v33, v34, v35, v21, v22);
  // pto: %kv_proj_pad_inline3447__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v39 = pto::Stride<-1, -1, -1, -1, -1>(v34 * v37, v37, v36, v22, v20);
  // pto: %kv_proj_pad_inline3447__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v40 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v38, v39);
  // pto: %score_proj_pad_inline3448__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %score_proj_pad_inline3448__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %score_proj_pad_inline3448__ssa_v0_view
  const int64_t v43 = 1;
  // pto: %score_proj_pad_inline3448__ssa_v0_view
  int64_t v44 = v21 * v22;
  // pto: %score_proj_pad_inline3448__ssa_v0_view
  int64_t v45 = v43 * v44;
  // pto: %score_proj_pad_inline3448__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v46 = pto::Shape<1, 1, 1, -1, -1>(v41, v42, v43, v21, v22);
  // pto: %score_proj_pad_inline3448__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v47 = pto::Stride<-1, -1, -1, -1, -1>(v42 * v45, v45, v44, v22, v20);
  // pto: %score_proj_pad_inline3448__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v48 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v46, v47);
  // pto: %x_flat_inline3456__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %x_flat_inline3456__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %x_flat_inline3456__ssa_v0_view
  const int64_t v51 = 1;
  // pto: %x_flat_inline3456__ssa_v0_view
  int64_t v52 = (int64_t) v10;
  // pto: %x_flat_inline3456__ssa_v0_view
  int64_t v53 = v52 * v23;
  // pto: %x_flat_inline3456__ssa_v0_view
  int64_t v54 = v51 * v53;
  // pto: %x_flat_inline3456__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v55 = pto::Shape<1, 1, 1, -1, -1>(v49, v50, v51, v52, v23);
  // pto: %x_flat_inline3456__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v56 = pto::Stride<-1, -1, -1, -1, -1>(v50 * v54, v54, v53, v23, v20);
  // pto: %x_flat_inline3456__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v57 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v55, v56);
  // pto: %inner_wkv__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %inner_wkv__ssa_v0_view
  const int64_t v59 = 1;
  // pto: %inner_wkv__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %inner_wkv__ssa_v0_view
  int64_t v61 = v22 * v23;
  // pto: %inner_wkv__ssa_v0_view
  int64_t v62 = v60 * v61;
  // pto: %inner_wkv__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v63 = pto::Shape<1, 1, 1, -1, -1>(v58, v59, v60, v22, v23);
  // pto: %inner_wkv__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v64 = pto::Stride<-1, -1, -1, -1, -1>(v59 * v62, v62, v61, v23, v20);
  // pto: %inner_wkv__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v65 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v63, v64);
  // pto: %inner_wgate__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %inner_wgate__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %inner_wgate__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %inner_wgate__ssa_v0_view
  int64_t v69 = v22 * v23;
  // pto: %inner_wgate__ssa_v0_view
  int64_t v70 = v68 * v69;
  // pto: %inner_wgate__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v71 = pto::Shape<1, 1, 1, -1, -1>(v66, v67, v68, v22, v23);
  // pto: %inner_wgate__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v67 * v70, v70, v69, v23, v20);
  // pto: %inner_wgate__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v73 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v71, v72);
  // pto: %kv_worker_inline3458__ssa_v0
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
  // pto: %t__tile
  int32_t v74 = (v1)[v20];
  // pto: %12
  int32_t v75 = (v1)[v24];
  // pto: %14
  // pto: %deviation_inline3472__rv_v2
  int32_t v76;
  v76 = v25;
  for (int64_t v77 = v20; v77 < ((int64_t) ((uint64_t) v9 - (uint64_t) v20)); v77 += v20) {
    // pto: %16, %15
    ;
    int32_t v78 = (v1)[(int64_t) ((uint64_t) v77 + (uint64_t) v20)];
    // pto: %17
    ;
    int32_t v79 = (v1)[v77];
    // pto: %18, %19, %13
    ;
    int32_t v80 = (int32_t) ((uint32_t) ((int32_t) (uint32_t) v78 - (uint32_t) v79) - (uint32_t) ((int32_t) (uint32_t) v74 - (uint32_t) v75));
    // pto: %21
    ;
    uint32_t v81 = (uint32_t) v76;
    // pto: %20, %21
    ;
    v76 = (int32_t) (v81 + (uint32_t) ((int32_t) (uint32_t) v80 * (uint32_t) v80));
  }
  // pto: %22
  int64_t v82 = (int64_t) v76;
  // pto: %23, %24, %25, %group_inline3476__phi_v4
  int64_t v83 = v82 == v24 & v7 <= v26 ? v27 : v28;
  for (int64_t v84 = (int64_t) v11; v84 < v8; v84 += v29) {
    // pto: %26
    ;
    const int64_t v85 = 1;
    // pto: %26
    ;
    const int64_t v86 = 0;
    // pto: %26
    ;
    int64_t v87 = v84 / v27;
    // pto: %26
    ;
    bool v88 = v84 < v86;
    // pto: %26
    ;
    bool v89 = v27 < v86;
    // pto: %26
    ;
    bool v90 = v88 == v89;
    // pto: %26
    ;
    bool v91 = v84 % v27 != v86 && v88 != v89;
    // pto: %26
    ;
    int64_t v92 = v91 ? v87 - v85 : v87;
    // pto: %27
    ;
    int64_t v93 = (int64_t) ((uint64_t) v92 * (uint64_t) v27);
    // pto: %28
    ;
    int64_t v94 = v84 % v27;
    // pto: %29, %30, %31
    ;
    int64_t v95 = v94 < v24 ? (int64_t) ((uint64_t) v94 + (uint64_t) v27) : v94;
    // pto: %32
    ;
    int64_t v96 = (int64_t) ((uint64_t) v95 * (uint64_t) v27);
    // pto: %kv_acc_inline3463__tile
    ;
    Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v27, v27);
    // pto: %kv_acc_inline3463__tile
    ;
    uint64_t v98 = (uint64_t) v13;
    TASSIGN(v97, v98);
    // pto: %score_acc_inline3464__tile
    ;
    Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v27, v27);
    // pto: %score_acc_inline3464__tile
    ;
    uint64_t v100 = (uint64_t) v14;
    TASSIGN(v99, v100);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    for (int64_t v101 = v24; v101 < v27; v101 += v30) {
      // pto: %33
      ;
      int64_t v102 = v96 % v31;
      // pto: %34, %35, %36
      ;
      int64_t v103 = v102 < v24 ? (int64_t) ((uint64_t) v102 + (uint64_t) v31) : v102;
      // pto: %37
      ;
      const int64_t v104 = 1;
      // pto: %37
      ;
      const int64_t v105 = 0;
      // pto: %37
      ;
      int64_t v106 = v103 / v83;
      // pto: %37
      ;
      bool v107 = v103 < v105;
      // pto: %37
      ;
      bool v108 = v83 < v105;
      // pto: %37
      ;
      bool v109 = v107 == v108;
      // pto: %37
      ;
      bool v110 = v103 % v83 != v105 && v107 != v108;
      // pto: %37
      ;
      int64_t v111 = v110 ? v106 - v104 : v106;
      // pto: %38, %39
      ;
      int64_t v112 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v101 + (uint64_t) v111) * (uint64_t) v22);
      // pto: %40
      ;
      int64_t v113 = v112 % v23;
      // pto: %41, %42, %43
      ;
      int64_t v114 = v113 < v24 ? (int64_t) ((uint64_t) v113 + (uint64_t) v23) : v113;
      // pto: %44
      ;
      int64_t v115 = (int64_t) ((uint64_t) v7 - (uint64_t) v93);
      // pto: %45
      ;
      int64_t v116 = v115 < v27 ? v115 : v27;
      // pto: %53, %54
      ;
      int64_t v117 = (int64_t) ((uint64_t) v112 + (uint64_t) v22) % v23;
      // pto: %55, %56, %57
      ;
      int64_t v118 = v117 < v24 ? (int64_t) ((uint64_t) v117 + (uint64_t) v23) : v117;
      // pto: %x_tile_inline3468__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v119 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v116, v22);
      // pto: %x_tile_inline3468__tile
      ;
      uint64_t v120 = (uint64_t) v15;
      TASSIGN(v119, v120);
      // pto: %60
      ;
      int64_t v121 = v93 < v24 ? v24 : v93;
      // pto: %61
      ;
      int64_t v122 = v114 < v24 ? v24 : v114;
      // pto: %x_flat_inline3456__ssa_v0_pview
      ;
      const int64_t v123 = 0;
      // pto: %x_flat_inline3456__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v124 = PTOAS__GLOBAL_TENSOR_DATA(v57);
      // pto: %x_flat_inline3456__ssa_v0_pview
      ;
      const int64_t v125 = 1;
      // pto: %x_flat_inline3456__ssa_v0_pview
      ;
      const int64_t v126 = 1;
      // pto: %x_flat_inline3456__ssa_v0_pview
      ;
      const int64_t v127 = 1;
      // pto: %x_flat_inline3456__ssa_v0_pview
      ;
      int64_t v128 = v116 * v23;
      // pto: %x_flat_inline3456__ssa_v0_pview
      ;
      int64_t v129 = v127 * v128;
      // pto: %x_flat_inline3456__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 256> v130 = pto::Shape<1, 1, 1, -1, 256>(v125, v126, v127, v116, v22);
      // pto: %x_flat_inline3456__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v131 = pto::Stride<-1, -1, -1, -1, -1>(v126 * v129, v129, v128, v23, v20);
      // pto: %x_flat_inline3456__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v132 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v124 + (v123 + v121 * v23 + v122 * v20), v130, v131);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v119, v132);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %wkv_tile_inline3469__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v27, v22);
      // pto: %wkv_tile_inline3469__tile
      ;
      uint64_t v134 = (uint64_t) v16;
      TASSIGN(v133, v134);
      // pto: %62
      ;
      int64_t v135 = v96 < v24 ? v24 : v96;
      // pto: %inner_wkv__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v136 = PTOAS__GLOBAL_TENSOR_DATA(v65);
      // pto: %inner_wkv__ssa_v0_pview
      ;
      const int64_t v137 = 0;
      // pto: %inner_wkv__ssa_v0_pview
      ;
      const int64_t v138 = 4096;
      // pto: %inner_wkv__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 256> v139 = pto::Shape<1, 1, 1, 16, 256>();
      // pto: %inner_wkv__ssa_v0_pview
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v140 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %inner_wkv__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v141 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v136 + (v137 + v135 * v138 + v122), v139, v140);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v133, v141);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %wgate_tile_inline3470__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v142 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v27, v22);
      // pto: %wgate_tile_inline3470__tile
      ;
      uint64_t v143 = (uint64_t) v13;
      TASSIGN(v142, v143);
      // pto: %inner_wgate__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v144 = PTOAS__GLOBAL_TENSOR_DATA(v73);
      // pto: %inner_wgate__ssa_v0_pview
      ;
      const int64_t v145 = 0;
      // pto: %inner_wgate__ssa_v0_pview
      ;
      const int64_t v146 = 4096;
      // pto: %inner_wgate__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 256> v147 = pto::Shape<1, 1, 1, 16, 256>();
      // pto: %inner_wgate__ssa_v0_pview
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v148 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %inner_wgate__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v149 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v144 + (v145 + v135 * v146 + v122), v147, v148);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v142, v149);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      // pto: %0
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v150 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v116, v22);
      // pto: %0
      ;
      uint64_t v151 = (uint64_t) v17;
      TASSIGN(v150, v151);
      // pto: %67
      ;
      int64_t v152 = v118 < v24 ? v24 : v118;
      // pto: %68
      ;
      const int64_t v153 = 0;
      // pto: %68
      ;
      __gm__ bfloat16_t* v154 = PTOAS__GLOBAL_TENSOR_DATA(v57);
      // pto: %68
      ;
      const int64_t v155 = 1;
      // pto: %68
      ;
      const int64_t v156 = 1;
      // pto: %68
      ;
      const int64_t v157 = 1;
      // pto: %68
      ;
      int64_t v158 = v116 * v23;
      // pto: %68
      ;
      int64_t v159 = v157 * v158;
      // pto: %68
      ;
      pto::Shape<1, 1, 1, -1, 256> v160 = pto::Shape<1, 1, 1, -1, 256>(v155, v156, v157, v116, v22);
      // pto: %68
      ;
      pto::Stride<-1, -1, -1, -1, -1> v161 = pto::Stride<-1, -1, -1, -1, -1>(v156 * v159, v159, v158, v23, v20);
      // pto: %68
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v162 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v154 + (v153 + v121 * v23 + v152 * v20), v160, v161);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v150, v162);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %1
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v163 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v27, v22);
      // pto: %1
      ;
      uint64_t v164 = (uint64_t) v18;
      TASSIGN(v163, v164);
      // pto: %71
      ;
      __gm__ bfloat16_t* v165 = PTOAS__GLOBAL_TENSOR_DATA(v65);
      // pto: %71
      ;
      const int64_t v166 = 0;
      // pto: %71
      ;
      const int64_t v167 = 4096;
      // pto: %71
      ;
      pto::Shape<1, 1, 1, 16, 256> v168 = pto::Shape<1, 1, 1, 16, 256>();
      // pto: %71
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v169 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %71
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v170 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v165 + (v166 + v135 * v167 + v152), v168, v169);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
      TLOAD(v163, v170);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      // pto: %2
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v171 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v27, v22);
      // pto: %2
      ;
      uint64_t v172 = (uint64_t) v19;
      TASSIGN(v171, v172);
      // pto: %74
      ;
      __gm__ bfloat16_t* v173 = PTOAS__GLOBAL_TENSOR_DATA(v73);
      // pto: %74
      ;
      const int64_t v174 = 0;
      // pto: %74
      ;
      const int64_t v175 = 4096;
      // pto: %74
      ;
      pto::Shape<1, 1, 1, 16, 256> v176 = pto::Shape<1, 1, 1, 16, 256>();
      // pto: %74
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v177 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %74
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v178 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v173 + (v174 + v135 * v175 + v152), v176, v177);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      TLOAD(v171, v178);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      // pto: %wkv_tile_inline3469__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v179 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v22, v27);
      // pto: %wkv_tile_inline3469__tile_t
      ;
      uint64_t v180 = (uint64_t) v16;
      TASSIGN(v179, v180);
      // pto: %x_tile_inline3468__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v116, v22);
      // pto: %x_tile_inline3468__tile_Left
      ;
      uint64_t v182 = (uint64_t) v13;
      TASSIGN(v181, v182);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      TMOV(v181, v119);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %wkv_tile_inline3469__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v22, v27);
      // pto: %wkv_tile_inline3469__tile_t_Right
      ;
      uint64_t v184 = (uint64_t) v13;
      TASSIGN(v183, v184);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      TMOV(v183, v179);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %75
      ;
      bool v185 = v101 == v24;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (v185) {
        TMATMUL(v97, v181, v183);
      } else {
        TMATMUL_ACC(v97, v97, v181, v183);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      // pto: %wgate_tile_inline3470__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v186 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v22, v27);
      // pto: %wgate_tile_inline3470__tile_t
      ;
      uint64_t v187 = (uint64_t) v13;
      TASSIGN(v186, v187);
      // pto: %wgate_tile_inline3470__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v188 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v22, v27);
      // pto: %wgate_tile_inline3470__tile_t_Right
      ;
      uint64_t v189 = (uint64_t) v13;
      TASSIGN(v188, v189);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      pipe_barrier(PIPE_MTE1);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      TMOV(v188, v186);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      if (v185) {
        TMATMUL(v99, v181, v188);
      } else {
        TMATMUL_ACC(v99, v99, v181, v188);
      };
      // pto: %5
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v190 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v22, v27);
      // pto: %5
      ;
      uint64_t v191 = (uint64_t) v18;
      TASSIGN(v190, v191);
      // pto: %6
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v192 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v116, v22);
      // pto: %6
      ;
      uint64_t v193 = (uint64_t) v17;
      TASSIGN(v192, v193);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      TMOV(v192, v150);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      // pto: %7
      ;
      Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v194 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v22, v27);
      // pto: %7
      ;
      uint64_t v195 = (uint64_t) v17;
      TASSIGN(v194, v195);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      TMOV(v194, v190);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
      // pto: %77
      ;
      bool v196 = v101 == v32;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      if (v196) {
        TMATMUL(v97, v192, v194);
      } else {
        TMATMUL_ACC(v97, v97, v192, v194);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %9
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v197 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v22, v27);
      // pto: %9
      ;
      uint64_t v198 = (uint64_t) v19;
      TASSIGN(v197, v198);
      // pto: %10
      ;
      Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v199 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v22, v27);
      // pto: %10
      ;
      uint64_t v200 = (uint64_t) v17;
      TASSIGN(v199, v200);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      pipe_barrier(PIPE_MTE1);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      TMOV(v199, v197);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      if (v196) {
        TMATMUL(v99, v192, v199);
      } else {
        TMATMUL_ACC(v99, v99, v192, v199);
      };
    };
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %79
    ;
    int64_t v201 = v93 < v24 ? v24 : v93;
    // pto: %80
    ;
    int64_t v202 = v96 < v24 ? v24 : v96;
    // pto: %kv_proj_pad_inline3447__iter_v1_pview
    ;
    __gm__ float* v203 = PTOAS__GLOBAL_TENSOR_DATA(v40);
    // pto: %kv_proj_pad_inline3447__iter_v1_pview
    ;
    const int64_t v204 = 0;
    // pto: %kv_proj_pad_inline3447__iter_v1_pview
    ;
    const int64_t v205 = 256;
    // pto: %kv_proj_pad_inline3447__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 16> v206 = pto::Shape<1, 1, 1, 16, 16>();
    // pto: %kv_proj_pad_inline3447__iter_v1_pview
    ;
    pto::Stride<4096, 4096, 4096, 256, 1> v207 = pto::Stride<4096, 4096, 4096, 256, 1>();
    // pto: %kv_proj_pad_inline3447__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<4096, 4096, 4096, 256, 1>, pto::Layout::ND> v208 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<4096, 4096, 4096, 256, 1>, pto::Layout::ND>(v203 + (v204 + v201 * v205 + v202), v206, v207);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE(v208, v97);
    // pto: %score_proj_pad_inline3448__iter_v1_pview
    ;
    __gm__ float* v209 = PTOAS__GLOBAL_TENSOR_DATA(v48);
    // pto: %score_proj_pad_inline3448__iter_v1_pview
    ;
    const int64_t v210 = 0;
    // pto: %score_proj_pad_inline3448__iter_v1_pview
    ;
    const int64_t v211 = 256;
    // pto: %score_proj_pad_inline3448__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 16> v212 = pto::Shape<1, 1, 1, 16, 16>();
    // pto: %score_proj_pad_inline3448__iter_v1_pview
    ;
    pto::Stride<4096, 4096, 4096, 256, 1> v213 = pto::Stride<4096, 4096, 4096, 256, 1>();
    // pto: %score_proj_pad_inline3448__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<4096, 4096, 4096, 256, 1>, pto::Layout::ND> v214 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<4096, 4096, 4096, 256, 1>, pto::Layout::ND>(v209 + (v210 + v201 * v211 + v202), v212, v213);
    TSTORE(v214, v99);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}