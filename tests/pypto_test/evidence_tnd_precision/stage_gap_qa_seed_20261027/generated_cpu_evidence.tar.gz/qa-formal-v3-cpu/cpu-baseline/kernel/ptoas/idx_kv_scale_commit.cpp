#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void idx_kv_scale_commit(__gm__ int32_t* v1, __gm__ int64_t* v2, __gm__ int32_t* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ float* v6, __gm__ int8_t* v7, int64_t v8, int64_t v9, int64_t v10, int64_t v11, int64_t v12, int64_t v13, int64_t v14) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v15 = 0;
  // pto: %c1_index
  const int64_t v16 = 1;
  // pto: %c2_index
  const int64_t v17 = 2;
  // pto: %c0_index
  const int64_t v18 = 0;
  // pto: %c4_index
  const int64_t v19 = 4;
  // pto: %c3_index
  const int64_t v20 = 3;
  // pto: %c1_i64
  const int64_t v21 = 1;
  // pto: %c4_i64
  const int64_t v22 = 4;
  // pto: %c64_index
  const int64_t v23 = 64;
  // pto: %c4096_index
  const int64_t v24 = 4096;
  // pto: %c32_index
  const int64_t v25 = 32;
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v26 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v27 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v28 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v29 = (int64_t) v13;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v30 = (int64_t) v14;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v31 = v29 * v30;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v32 = v28 * v31;
  // pto: %idx_native_kv_cache__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v33 = pto::Shape<1, 1, 1, -1, -1>(v26, v27, v28, v29, (int64_t) v14);
  // pto: %idx_native_kv_cache__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v34 = pto::Stride<-1, -1, -1, -1, -1>(v27 * v32, v32, v31, v30, v16);
  // pto: %idx_native_kv_cache__rv_v2_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v35 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v33, v34);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v36 = v18; v36 < v8; v36 += v16) {
    // pto: %0
    ;
    const int64_t v37 = 1;
    // pto: %0
    ;
    const int64_t v38 = 0;
    // pto: %0
    ;
    int64_t v39 = v36 / v17;
    // pto: %0
    ;
    bool v40 = v36 < v38;
    // pto: %0
    ;
    bool v41 = v17 < v38;
    // pto: %0
    ;
    bool v42 = v40 == v41;
    // pto: %0
    ;
    bool v43 = v36 % v17 != v38 && v40 != v41;
    // pto: %0
    ;
    int64_t v44 = v43 ? v39 - v37 : v39;
    // pto: %t__tile
    ;
    int32_t v45 = (v1)[v44];
    // pto: %1
    ;
    int64_t v46 = (int64_t) v45;
    // pto: %3, %2
    ;
    int32_t v47 = (v1)[(int64_t) ((uint64_t) v44 + (uint64_t) v16)];
    // pto: %4
    ;
    int64_t v48 = (int64_t) v47;
    // pto: %5
    ;
    // pto: %first_pos_inline3612__phi_v5
    ;
    int64_t v49;
    if (v46 < v48) {
      // pto: %6
      ;
      int64_t v50 = (v2)[v46];
      v49 = v50;
    } else {
      v49 = v18;
    };
    // pto: %8
    ;
    int64_t v51 = v36 % v17;
    // pto: %9, %10, %11
    ;
    int64_t v52 = v51 < v18 ? (int64_t) ((uint64_t) v51 + (uint64_t) v17) : v51;
    // pto: %13
    ;
    int64_t v53 = v49 % v19;
    // pto: %14, %15, %16
    ;
    int64_t v54 = v53 < v18 ? (int64_t) ((uint64_t) v53 + (uint64_t) v19) : v53;
    // pto: %12, %17, %18
    ;
    int64_t v55 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v52 * (uint64_t) v19) - (uint64_t) v54) + (uint64_t) v20);
    // pto: %19
    ;
    int32_t v56 = (v3)[v44];
    // pto: %20, %21, %22, %23, %24
    ;
    if ((int64_t) v56 > v18 & v55 < (int64_t) ((uint64_t) v48 - (uint64_t) v46)) {
      // pto: %25, %token_pos_v1_inline3626__tile
      ;
      int64_t v57 = (v2)[(int64_t) ((uint64_t) v46 + (uint64_t) v55)];
      // pto: %26
      ;
      int32_t v58 = (v4)[v44];
      // pto: %28
      ;
      int64_t v59 = (int64_t) ((uint64_t) v57 + (uint64_t) v21);
      // pto: %29
      ;
      const int64_t v60 = 1;
      // pto: %29
      ;
      const int64_t v61 = 0;
      // pto: %29
      ;
      int64_t v62 = v59 / v22;
      // pto: %29
      ;
      bool v63 = v59 < v61;
      // pto: %29
      ;
      bool v64 = v22 < v61;
      // pto: %29
      ;
      bool v65 = v63 == v64;
      // pto: %29
      ;
      bool v66 = v59 % v22 != v61 && v63 != v64;
      // pto: %29
      ;
      int64_t v67 = v66 ? v62 - v60 : v62;
      // pto: %27, %31
      ;
      int64_t v68 = (int64_t) ((uint64_t) ((int64_t) v58) + (uint64_t) v67);
      // pto: %32
      ;
      int64_t v69 = (int64_t) ((uint64_t) v12 - (uint64_t) v16);
      // pto: %33
      ;
      int64_t v70 = v68 < v69 ? v68 : v69;
      // pto: %flat_offset_mul
      ;
      int64_t v71 = (int64_t) ((uint64_t) v70 * (uint64_t) v17);
      // pto: %native_page_v1_inline3630__tile
      ;
      int32_t v72 = (v5)[v71];
      // pto: %35, %native_offset_v1_inline3631__tile
      ;
      int32_t v73 = (v5)[(int64_t) ((uint64_t) v71 + (uint64_t) v16)];
      // pto: %37
      ;
      int64_t v74 = (int64_t) v72;
      // pto: %40
      ;
      int64_t v75 = (int64_t) v73;
      // pto: %36, %38, %39, %41, %42
      ;
      if ((v68 < v12 & v74 >= v18) & v75 >= v18) {
        // pto: %43
        ;
        float v76 = (v6)[v36];
        // pto: %46
        ;
        half v77 = (half) v76;
        // pto: %native_scale_bytes_inline3634__ssa_v0
        ;
        Tile<TileType::Vec, int8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v78 = Tile<TileType::Vec, int8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v23);
        // pto: %native_scale_bytes_inline3634__ssa_v0
        ;
        uint64_t v79 = (uint64_t) v15;
        TASSIGN(v78, v79);
        // pto: %48
        ;
        int64_t v80 = v74 < v18 ? v18 : v74;
        // pto: %idx_native_kv_cache__rv_v2_pview
        ;
        int64_t v81 = (int64_t) v14;
        // pto: %idx_native_kv_cache__rv_v2_pview
        ;
        const int64_t v82 = 0;
        // pto: %idx_native_kv_cache__rv_v2_pview
        ;
        __gm__ int8_t* v83 = PTOAS__GLOBAL_TENSOR_DATA(v35);
        // pto: %idx_native_kv_cache__rv_v2_pview
        ;
        const int64_t v84 = 1;
        // pto: %idx_native_kv_cache__rv_v2_pview
        ;
        const int64_t v85 = 1;
        // pto: %idx_native_kv_cache__rv_v2_pview
        ;
        const int64_t v86 = 1;
        // pto: %idx_native_kv_cache__rv_v2_pview
        ;
        int64_t v87 = v16 * v81;
        // pto: %idx_native_kv_cache__rv_v2_pview
        ;
        int64_t v88 = v86 * v87;
        // pto: %idx_native_kv_cache__rv_v2_pview
        ;
        pto::Shape<1, 1, 1, 1, 64> v89 = pto::Shape<1, 1, 1, 1, 64>(v84, v85, v86, v16, v23);
        // pto: %idx_native_kv_cache__rv_v2_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v90 = pto::Stride<-1, -1, -1, -1, -1>(v85 * v88, v88, v87, v81, v16);
        // pto: %idx_native_kv_cache__rv_v2_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v91 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v83 + (v82 + v80 * v81 + v24 * v16), v89, v90);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
        TLOAD(v78, v91);
        set_flag(PIPE_MTE2, PIPE_S, EVENT_ID0);
        // pto: %native_scale_half_inline3635__ssa_v0
        ;
        Tile<TileType::Vec, half, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v92 = Tile<TileType::Vec, half, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v25);
        // pto: %native_scale_half_inline3635__ssa_v0
        ;
        uint64_t v93 = (uint64_t) v15;
        TASSIGN(v92, v93);
        wait_flag(PIPE_MTE2, PIPE_S, EVENT_ID0);
        v92.SetValue(v75, v77);
        set_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
        // pto: %native_updated_bytes_inline3636__ssa_v0
        ;
        Tile<TileType::Vec, int8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Vec, int8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v23);
        // pto: %native_updated_bytes_inline3636__ssa_v0
        ;
        uint64_t v95 = (uint64_t) v15;
        TASSIGN(v94, v95);
        wait_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
        TSTORE(v91, v94);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      };
    };
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}