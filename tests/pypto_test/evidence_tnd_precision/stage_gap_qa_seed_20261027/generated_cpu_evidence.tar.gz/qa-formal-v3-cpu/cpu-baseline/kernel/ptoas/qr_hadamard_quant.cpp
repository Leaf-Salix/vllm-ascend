#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qr_hadamard_quant(__gm__ int8_t* v1, __gm__ float* v2, __gm__ float* v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c49408_i64
  const int64_t v8 = 49408;
  // pto: %c16384_i64
  const int64_t v9 = 16384;
  // pto: %c82176_i64
  const int64_t v10 = 82176;
  // pto: %c0_i64
  const int64_t v11 = 0;
  // pto: %c49152_i64
  const int64_t v12 = 49152;
  // pto: %c27648_index
  const int64_t v13 = 27648;
  // pto: %c128_index
  const int64_t v14 = 128;
  // pto: %c1_index
  const int64_t v15 = 1;
  // pto: %c64_index
  const int64_t v16 = 64;
  // pto: %c48_index
  const int64_t v17 = 48;
  // pto: %c0_index
  const int64_t v18 = 0;
  // pto: %cst_11
  const float v19 = 0.0883883461f;
  // pto: %cst_12
  const float v20 = 9.99999974E-5f;
  // pto: %cst_13
  const float v21 = 127.0f;
  // pto: %qr_hadamard_i8_inline3637__ssa_v0_view
  const int64_t v22 = 1;
  // pto: %qr_hadamard_i8_inline3637__ssa_v0_view
  const int64_t v23 = 1;
  // pto: %qr_hadamard_i8_inline3637__ssa_v0_view
  const int64_t v24 = 1;
  // pto: %qr_hadamard_i8_inline3637__ssa_v0_view
  int64_t v25 = v13 * v14;
  // pto: %qr_hadamard_i8_inline3637__ssa_v0_view
  int64_t v26 = v24 * v25;
  // pto: %qr_hadamard_i8_inline3637__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v27 = pto::Shape<1, 1, 1, -1, -1>(v22, v23, v24, v13, v14);
  // pto: %qr_hadamard_i8_inline3637__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v28 = pto::Stride<-1, -1, -1, -1, -1>(v23 * v26, v26, v25, v14, v15);
  // pto: %qr_hadamard_i8_inline3637__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v29 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v27, v28);
  // pto: %qr_hadamard_scale_dq_inline3638__ssa_v0_view
  const int64_t v30 = 1;
  // pto: %qr_hadamard_scale_dq_inline3638__ssa_v0_view
  const int64_t v31 = 1;
  // pto: %qr_hadamard_scale_dq_inline3638__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %qr_hadamard_scale_dq_inline3638__ssa_v0_view
  int64_t v33 = v13 * v15;
  // pto: %qr_hadamard_scale_dq_inline3638__ssa_v0_view
  int64_t v34 = v32 * v33;
  // pto: %qr_hadamard_scale_dq_inline3638__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v35 = pto::Shape<1, 1, 1, -1, -1>(v30, v31, v32, v13, v15);
  // pto: %qr_hadamard_scale_dq_inline3638__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v36 = pto::Stride<-1, -1, -1, -1, -1>(v31 * v34, v34, v33, v15, v13);
  // pto: %qr_hadamard_scale_dq_inline3638__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v37 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v2, v35, v36);
  // pto: %qh_acc_gm_inline3711__rv_v2_view
  const int64_t v38 = 1;
  // pto: %qh_acc_gm_inline3711__rv_v2_view
  const int64_t v39 = 1;
  // pto: %qh_acc_gm_inline3711__rv_v2_view
  const int64_t v40 = 1;
  // pto: %qh_acc_gm_inline3711__rv_v2_view
  int64_t v41 = (int64_t) v5;
  // pto: %qh_acc_gm_inline3711__rv_v2_view
  int64_t v42 = v41 * v14;
  // pto: %qh_acc_gm_inline3711__rv_v2_view
  int64_t v43 = v40 * v42;
  // pto: %qh_acc_gm_inline3711__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v44 = pto::Shape<1, 1, 1, -1, -1>(v38, v39, v40, v41, v14);
  // pto: %qh_acc_gm_inline3711__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v45 = pto::Stride<-1, -1, -1, -1, -1>(v39 * v43, v43, v42, v14, v15);
  // pto: %qh_acc_gm_inline3711__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v46 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v44, v45);
  // pto: %qh_quant_worker_inline3719__ssa_v0
  // pto: %6
  const int64_t v47 = 1;
  // pto: %6
  const int64_t v48 = 0;
  // pto: %6
  int64_t v49 = v5 / v16;
  // pto: %6
  bool v50 = v5 < v48;
  // pto: %6
  bool v51 = v16 < v48;
  // pto: %6
  bool v52 = v50 == v51;
  // pto: %6
  bool v53 = v5 % v16 != v48 && v50 != v51;
  // pto: %6
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v54 = (int64_t) v6; v54 < (v53 ? v49 - v47 : v49); v54 += v17) {
    // pto: %7
    ;
    int64_t v55 = (int64_t) ((uint64_t) v54 * (uint64_t) v16);
    // pto: %qh_full_f32_inline3721__tile
    ;
    Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v56 = Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v14);
    // pto: %qh_full_f32_inline3721__tile
    ;
    uint64_t v57 = (uint64_t) v8;
    TASSIGN(v56, v57);
    // pto: %8
    ;
    int64_t v58 = v55 < v18 ? v18 : v55;
    // pto: %qh_acc_gm_inline3711__rv_v2_pview
    ;
    __gm__ float* v59 = PTOAS__GLOBAL_TENSOR_DATA(v46);
    // pto: %qh_acc_gm_inline3711__rv_v2_pview
    ;
    const int64_t v60 = 0;
    // pto: %qh_acc_gm_inline3711__rv_v2_pview
    ;
    const int64_t v61 = 128;
    // pto: %qh_acc_gm_inline3711__rv_v2_pview
    ;
    pto::Shape<1, 1, 1, 64, 128> v62 = pto::Shape<1, 1, 1, 64, 128>();
    // pto: %qh_acc_gm_inline3711__rv_v2_pview
    ;
    pto::Stride<8192, 8192, 8192, 128, 1> v63 = pto::Stride<8192, 8192, 8192, 128, 1>();
    // pto: %qh_acc_gm_inline3711__rv_v2_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND> v64 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND>(v59 + (v60 + v58 * v61), v62, v63);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v56, v64);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %t__tile
    ;
    Tile<TileType::Vec, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v65 = Tile<TileType::Vec, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v14);
    // pto: %t__tile
    ;
    uint64_t v66 = (uint64_t) v9;
    TASSIGN(v65, v66);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v67 = RoundMode::CAST_RINT;
    SaturationMode v68 = SaturationMode::ON;
    TCVT(v65, v56, v67, v68);
    // pto: %qh_full_f32_v1_inline3722__tile
    ;
    Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v69 = Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v14);
    // pto: %qh_full_f32_v1_inline3722__tile
    ;
    uint64_t v70 = (uint64_t) v8;
    TASSIGN(v69, v70);
    pipe_barrier(PIPE_V);
    RoundMode v71 = RoundMode::CAST_ROUND;
    SaturationMode v72 = SaturationMode::ON;
    TCVT(v69, v65, v71, v72);
    // pto: %0
    ;
    Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v73 = Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v14);
    // pto: %0
    ;
    uint64_t v74 = (uint64_t) v8;
    TASSIGN(v73, v74);
    pipe_barrier(PIPE_V);
    TMULS(v73, v69, v19);
    // pto: %1
    ;
    Tile<TileType::Vec, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v75 = Tile<TileType::Vec, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v14);
    // pto: %1
    ;
    uint64_t v76 = (uint64_t) v9;
    TASSIGN(v75, v76);
    pipe_barrier(PIPE_V);
    RoundMode v77 = RoundMode::CAST_RINT;
    SaturationMode v78 = SaturationMode::ON;
    TCVT(v75, v73, v77, v78);
    // pto: %qh_full_f32_v2_inline3723__tile
    ;
    Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v79 = Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v14);
    // pto: %qh_full_f32_v2_inline3723__tile
    ;
    uint64_t v80 = (uint64_t) v8;
    TASSIGN(v79, v80);
    pipe_barrier(PIPE_V);
    RoundMode v81 = RoundMode::CAST_ROUND;
    SaturationMode v82 = SaturationMode::ON;
    TCVT(v79, v75, v81, v82);
    // pto: %qh_amax_inline3724__tile
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v83 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v16);
    // pto: %qh_amax_inline3724__tile
    ;
    uint64_t v84 = (uint64_t) v10;
    TASSIGN(v83, v84);
    TEXPANDS(v83, v20);
    for (int64_t v85 = v18; v85 < v14; v85 += v16) {
      // pto: %qh_a_f32_inline3726__tile_textract
      ;
      Tile<TileType::Vec, float, 64, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v86 = Tile<TileType::Vec, float, 64, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v16);
      // pto: %qh_a_f32_inline3726__tile_textract
      ;
      uint64_t v87 = (uint64_t) v9;
      TASSIGN(v86, v87);
      pipe_barrier(PIPE_V);
      uint16_t v88 = static_cast<uint16_t>(v18);
      uint16_t v89 = static_cast<uint16_t>(v85);
      TEXTRACT(v86, v79, v88, v89);
      // pto: %qh_a_neg_inline3727__tile
      ;
      Tile<TileType::Vec, float, 64, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v90 = Tile<TileType::Vec, float, 64, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v16);
      // pto: %qh_a_neg_inline3727__tile
      ;
      uint64_t v91 = (uint64_t) v9;
      TASSIGN(v90, v91);
      pipe_barrier(PIPE_V);
      TNEG(v90, v86);
      // pto: %2
      ;
      Tile<TileType::Vec, float, 64, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v92 = Tile<TileType::Vec, float, 64, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v16);
      // pto: %2
      ;
      uint64_t v93 = (uint64_t) v11;
      TASSIGN(v92, v93);
      uint16_t v94 = static_cast<uint16_t>(v18);
      uint16_t v95 = static_cast<uint16_t>(v85);
      TEXTRACT(v92, v79, v94, v95);
      // pto: %qh_a_abs_inline3728__tile
      ;
      Tile<TileType::Vec, float, 64, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v96 = Tile<TileType::Vec, float, 64, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v16);
      // pto: %qh_a_abs_inline3728__tile
      ;
      uint64_t v97 = (uint64_t) v11;
      TASSIGN(v96, v97);
      pipe_barrier(PIPE_V);
      TMAX(v96, v92, v90);
      // pto: %tmp_tile
      ;
      Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v98 = Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v14);
      // pto: %tmp_tile
      ;
      uint64_t v99 = (uint64_t) v9;
      TASSIGN(v98, v99);
      // pto: %qh_a_max_col_inline3729__tile
      ;
      Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v100 = Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v15);
      // pto: %qh_a_max_col_inline3729__tile
      ;
      uint64_t v101 = (uint64_t) v12;
      TASSIGN(v100, v101);
      pipe_barrier(PIPE_V);
      TROWMAX(v100, v96, v98);
      // pto: %qh_a_max_inline3730__tile
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v16);
      // pto: %qh_a_max_inline3730__tile
      ;
      uint64_t v103 = (uint64_t) v12;
      TASSIGN(v102, v103);
      // pto: %3
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v104 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v16);
      // pto: %3
      ;
      uint64_t v105 = (uint64_t) v10;
      TASSIGN(v104, v105);
      pipe_barrier(PIPE_V);
      TMAX(v104, v83, v102);
    };
    // pto: %qh_scale_numerator_inline3731__tile
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v16);
    // pto: %qh_scale_numerator_inline3731__tile
    ;
    uint64_t v107 = (uint64_t) v9;
    TASSIGN(v106, v107);
    pipe_barrier(PIPE_V);
    TEXPANDS(v106, v21);
    // pto: %qh_scale_quant_row_inline3732__tile
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v16);
    // pto: %qh_scale_quant_row_inline3732__tile
    ;
    uint64_t v109 = (uint64_t) v9;
    TASSIGN(v108, v109);
    pipe_barrier(PIPE_V);
    TDIV(v108, v106, v83);
    // pto: %qh_scale_recip_inline3733__tile
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v16);
    // pto: %qh_scale_recip_inline3733__tile
    ;
    uint64_t v111 = (uint64_t) v11;
    TASSIGN(v110, v111);
    pipe_barrier(PIPE_V);
    TRECIP(v110, v108);
    // pto: %qh_scale_dq_inline3734__tile
    ;
    Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v112 = Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v15);
    // pto: %qh_scale_dq_inline3734__tile
    ;
    uint64_t v113 = (uint64_t) v11;
    TASSIGN(v112, v113);
    // pto: %t__rm_a0_tmp_v0
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v114 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v16);
    // pto: %t__rm_a0_tmp_v0
    ;
    uint64_t v115 = (uint64_t) v11;
    TASSIGN(v114, v115);
    // pto: %t__row_major_tmp_v1
    ;
    Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v16);
    // pto: %t__row_major_tmp_v1
    ;
    uint64_t v117 = (uint64_t) v10;
    TASSIGN(v116, v117);
    pipe_barrier(PIPE_V);
    RoundMode v118 = RoundMode::CAST_RINT;
    SaturationMode v119 = SaturationMode::ON;
    TCVT(v116, v114, v118, v119);
    // pto: %4
    ;
    Tile<TileType::Vec, half, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Vec, half, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v15);
    // pto: %4
    ;
    uint64_t v121 = (uint64_t) v10;
    TASSIGN(v120, v121);
    // pto: %t__rm_a0_tmp_v2
    ;
    Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v122 = Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v16);
    // pto: %t__rm_a0_tmp_v2
    ;
    uint64_t v123 = (uint64_t) v10;
    TASSIGN(v122, v123);
    // pto: %t__row_major_tmp_v3
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v16);
    // pto: %t__row_major_tmp_v3
    ;
    uint64_t v125 = (uint64_t) v11;
    TASSIGN(v124, v125);
    pipe_barrier(PIPE_V);
    RoundMode v126 = RoundMode::CAST_ROUND;
    SaturationMode v127 = SaturationMode::ON;
    TCVT(v124, v122, v126, v127);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %5
    ;
    Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v128 = Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v15);
    // pto: %5
    ;
    uint64_t v129 = (uint64_t) v11;
    TASSIGN(v128, v129);
    // pto: %qr_hadamard_scale_dq_inline3638__iter_v1_pview
    ;
    __gm__ float* v130 = PTOAS__GLOBAL_TENSOR_DATA(v37);
    // pto: %qr_hadamard_scale_dq_inline3638__iter_v1_pview
    ;
    const int64_t v131 = 0;
    // pto: %qr_hadamard_scale_dq_inline3638__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 64, 1> v132 = pto::Shape<1, 1, 1, 64, 1>();
    // pto: %qr_hadamard_scale_dq_inline3638__iter_v1_pview
    ;
    pto::Stride<64, 64, 64, 1, 27648> v133 = pto::Stride<64, 64, 64, 1, 27648>();
    // pto: %qr_hadamard_scale_dq_inline3638__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 64, 1>, pto::Stride<64, 64, 64, 1, 27648>, pto::Layout::DN> v134 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 1>, pto::Stride<64, 64, 64, 1, 27648>, pto::Layout::DN>(v130 + (v131 + v58), v132, v133);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v134, v128);
    // pto: %qh_scale_quant_inline3735__tile
    ;
    Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v135 = Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v15);
    // pto: %qh_scale_quant_inline3735__tile
    ;
    uint64_t v136 = (uint64_t) v9;
    TASSIGN(v135, v136);
    // pto: %qh_q_scaled_inline3736__tile
    ;
    Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v14);
    // pto: %qh_q_scaled_inline3736__tile
    ;
    uint64_t v138 = (uint64_t) v8;
    TASSIGN(v137, v138);
    TROWEXPANDMUL(v137, v79, v135);
    // pto: %qh_q_i32_inline3737__tile
    ;
    Tile<TileType::Vec, int32_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v139 = Tile<TileType::Vec, int32_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v14);
    // pto: %qh_q_i32_inline3737__tile
    ;
    uint64_t v140 = (uint64_t) v8;
    TASSIGN(v139, v140);
    pipe_barrier(PIPE_V);
    RoundMode v141 = RoundMode::CAST_RINT;
    SaturationMode v142 = SaturationMode::ON;
    TCVT(v139, v137, v141, v142);
    // pto: %qh_q_half_inline3738__tile
    ;
    Tile<TileType::Vec, half, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v143 = Tile<TileType::Vec, half, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v14);
    // pto: %qh_q_half_inline3738__tile
    ;
    uint64_t v144 = (uint64_t) v8;
    TASSIGN(v143, v144);
    pipe_barrier(PIPE_V);
    RoundMode v145 = RoundMode::CAST_ROUND;
    SaturationMode v146 = SaturationMode::ON;
    TCVT(v143, v139, v145, v146);
    // pto: %qh_i8_inline3739__tile
    ;
    Tile<TileType::Vec, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v147 = Tile<TileType::Vec, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v14);
    // pto: %qh_i8_inline3739__tile
    ;
    uint64_t v148 = (uint64_t) v8;
    TASSIGN(v147, v148);
    pipe_barrier(PIPE_V);
    RoundMode v149 = RoundMode::CAST_TRUNC;
    SaturationMode v150 = SaturationMode::ON;
    TCVT(v147, v143, v149, v150);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %qr_hadamard_i8_inline3637__iter_v1_pview
    ;
    __gm__ int8_t* v151 = PTOAS__GLOBAL_TENSOR_DATA(v29);
    // pto: %qr_hadamard_i8_inline3637__iter_v1_pview
    ;
    const int64_t v152 = 0;
    // pto: %qr_hadamard_i8_inline3637__iter_v1_pview
    ;
    const int64_t v153 = 128;
    // pto: %qr_hadamard_i8_inline3637__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 64, 128> v154 = pto::Shape<1, 1, 1, 64, 128>();
    // pto: %qr_hadamard_i8_inline3637__iter_v1_pview
    ;
    pto::Stride<8192, 8192, 8192, 128, 1> v155 = pto::Stride<8192, 8192, 8192, 128, 1>();
    // pto: %qr_hadamard_i8_inline3637__iter_v1_pview
    ;
    GlobalTensor<int8_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND> v156 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND>(v151 + (v152 + v58 * v153), v154, v155);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    TSTORE(v156, v147);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}