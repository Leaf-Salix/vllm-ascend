#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void packed_prefix_indexer_cube(__gm__ float* v1, __gm__ float* v2, __gm__ bfloat16_t* v3, __gm__ bfloat16_t* v4, __gm__ float* v5, __gm__ bfloat16_t* v6, __gm__ bfloat16_t* v7, __gm__ int32_t* v8, __gm__ float* v9, __gm__ int64_t* v10, __gm__ bfloat16_t* v11, __gm__ int32_t* v12, __gm__ float* v13, __gm__ bfloat16_t* v14, __gm__ float* v15, __gm__ float* v16, __gm__ float* v17, __gm__ float* v18, __gm__ float* v19, __gm__ float* v20, __gm__ float* v21, __gm__ float* v22, __gm__ bfloat16_t* v23, __gm__ bfloat16_t* v24, __gm__ bfloat16_t* v25, __gm__ float* v26, __gm__ bfloat16_t* v27, __gm__ float* v28, __gm__ bfloat16_t* v29, __gm__ bfloat16_t* v30, __gm__ half* v31, int64_t v32, int64_t v33, int64_t v34, int64_t v35, int64_t v36, int32_t v37, int32_t v38) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v39 = 0;
  // pto: %c32768_i64
  const int64_t v40 = 32768;
  // pto: %c2048_i64
  const int64_t v41 = 2048;
  // pto: %c16384_index
  const int64_t v42 = 16384;
  // pto: %c1_index
  const int64_t v43 = 1;
  // pto: %c16_index
  const int64_t v44 = 16;
  // pto: %c32768_index
  const int64_t v45 = 32768;
  const int64_t v46 = 32;
  // pto: %c4096_index
  const int64_t v47 = 4096;
  // pto: %c512_index
  const int64_t v48 = 512;
  const int64_t v49 = 64;
  // pto: %c4_index
  const int64_t v50 = 4;
  // pto: %c24_index
  const int64_t v51 = 24;
  // pto: %c22_index
  const int64_t v52 = 22;
  // pto: %c21_index
  const int64_t v53 = 21;
  // pto: %c0_index
  const int64_t v54 = 0;
  // pto: %c768_index
  const int64_t v55 = 768;
  // pto: %c2_index
  const int64_t v56 = 2;
  // pto: %cn1_index
  const int64_t v57 = -1;
  // pto: %c63_index
  const int64_t v58 = 63;
  // pto: %c1536_index
  const int64_t v59 = 1536;
  // pto: %c128_index
  const int64_t v60 = 128;
  // pto: %c15_index
  const int64_t v61 = 15;
  // pto: %c256_index
  const int64_t v62 = 256;
  // pto: %wide__ssa_v0_view
  const int64_t v63 = 1;
  // pto: %wide__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %wide__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %wide__ssa_v0_view
  int64_t v66 = (int64_t) v32;
  // pto: %wide__ssa_v0_view
  int64_t v67 = v66 * v42;
  // pto: %wide__ssa_v0_view
  int64_t v68 = v65 * v67;
  // pto: %wide__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v69 = pto::Shape<1, 1, 1, -1, -1>(v63, v64, v65, v66, v42);
  // pto: %wide__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v70 = pto::Stride<-1, -1, -1, -1, -1>(v64 * v68, v68, v67, v42, v43);
  // pto: %wide__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v71 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v69, v70);
  // pto: %spmd_square__ssa_v0_view
  const int64_t v72 = 1;
  // pto: %spmd_square__ssa_v0_view
  const int64_t v73 = 1;
  // pto: %spmd_square__ssa_v0_view
  const int64_t v74 = 1;
  // pto: %spmd_square__ssa_v0_view
  int64_t v75 = (int64_t) v33;
  // pto: %spmd_square__ssa_v0_view
  int64_t v76 = v75 * v44;
  // pto: %spmd_square__ssa_v0_view
  int64_t v77 = v74 * v76;
  // pto: %spmd_square__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v78 = pto::Shape<1, 1, 1, -1, -1>(v72, v73, v74, v75, v44);
  // pto: %spmd_square__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v79 = pto::Stride<-1, -1, -1, -1, -1>(v73 * v77, v77, v76, v44, v43);
  // pto: %spmd_square__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v80 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v78, v79);
  // pto: %hc_packed_weight__ssa_v0_view
  const int64_t v81 = 1;
  // pto: %hc_packed_weight__ssa_v0_view
  const int64_t v82 = 1;
  // pto: %hc_packed_weight__ssa_v0_view
  const int64_t v83 = 1;
  // pto: %hc_packed_weight__ssa_v0_view
  int64_t v84 = v45 * v46;
  // pto: %hc_packed_weight__ssa_v0_view
  int64_t v85 = v83 * v84;
  // pto: %hc_packed_weight__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v86 = pto::Shape<1, 1, 1, -1, -1>(v81, v82, v83, v45, v46);
  // pto: %hc_packed_weight__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v87 = pto::Stride<-1, -1, -1, -1, -1>(v82 * v85, v85, v84, v46, v43);
  // pto: %hc_packed_weight__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v88 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v86, v87);
  // pto: %packed_flat__ssa_v0_view
  const int64_t v89 = 1;
  // pto: %packed_flat__ssa_v0_view
  const int64_t v90 = 1;
  // pto: %packed_flat__ssa_v0_view
  const int64_t v91 = 1;
  // pto: %packed_flat__ssa_v0_view
  int64_t v92 = (int64_t) v34;
  // pto: %packed_flat__ssa_v0_view
  int64_t v93 = v92 * v45;
  // pto: %packed_flat__ssa_v0_view
  int64_t v94 = v91 * v93;
  // pto: %packed_flat__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v95 = pto::Shape<1, 1, 1, -1, -1>(v89, v90, v91, v92, v45);
  // pto: %packed_flat__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v96 = pto::Stride<-1, -1, -1, -1, -1>(v90 * v94, v94, v93, v45, v43);
  // pto: %packed_flat__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v97 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v95, v96);
  // pto: %spmd_linear__ssa_v0_view
  const int64_t v98 = 1;
  // pto: %spmd_linear__ssa_v0_view
  const int64_t v99 = 1;
  // pto: %spmd_linear__ssa_v0_view
  const int64_t v100 = 1;
  // pto: %spmd_linear__ssa_v0_view
  int64_t v101 = (int64_t) v33;
  // pto: %spmd_linear__ssa_v0_view
  int64_t v102 = v101 * v46;
  // pto: %spmd_linear__ssa_v0_view
  int64_t v103 = v100 * v102;
  // pto: %spmd_linear__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v104 = pto::Shape<1, 1, 1, -1, -1>(v98, v99, v100, v101, v46);
  // pto: %spmd_linear__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v105 = pto::Stride<-1, -1, -1, -1, -1>(v99 * v103, v103, v102, v46, v43);
  // pto: %spmd_linear__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v106 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v104, v105);
  // pto: %normed__ssa_v0_view
  const int64_t v107 = 1;
  // pto: %normed__ssa_v0_view
  const int64_t v108 = 1;
  // pto: %normed__ssa_v0_view
  const int64_t v109 = 1;
  // pto: %normed__ssa_v0_view
  int64_t v110 = (int64_t) v32;
  // pto: %normed__ssa_v0_view
  int64_t v111 = v110 * v47;
  // pto: %normed__ssa_v0_view
  int64_t v112 = v109 * v111;
  // pto: %normed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v113 = pto::Shape<1, 1, 1, -1, -1>(v107, v108, v109, v110, v47);
  // pto: %normed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v114 = pto::Stride<-1, -1, -1, -1, -1>(v108 * v112, v112, v111, v47, v43);
  // pto: %normed__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v115 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v113, v114);
  // pto: %wkv__ssa_v0_view
  const int64_t v116 = 1;
  // pto: %wkv__ssa_v0_view
  const int64_t v117 = 1;
  // pto: %wkv__ssa_v0_view
  const int64_t v118 = 1;
  // pto: %wkv__ssa_v0_view
  int64_t v119 = v48 * v47;
  // pto: %wkv__ssa_v0_view
  int64_t v120 = v118 * v119;
  // pto: %wkv__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v121 = pto::Shape<1, 1, 1, -1, -1>(v116, v117, v118, v48, v47);
  // pto: %wkv__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v122 = pto::Stride<-1, -1, -1, -1, -1>(v117 * v120, v120, v119, v47, v43);
  // pto: %wkv__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v123 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v121, v122);
  // pto: %spmd_accum__ssa_v0_view
  const int64_t v124 = 1;
  // pto: %spmd_accum__ssa_v0_view
  const int64_t v125 = 1;
  // pto: %spmd_accum__ssa_v0_view
  const int64_t v126 = 1;
  // pto: %spmd_accum__ssa_v0_view
  int64_t v127 = (int64_t) v35;
  // pto: %spmd_accum__ssa_v0_view
  int64_t v128 = v127 * v48;
  // pto: %spmd_accum__ssa_v0_view
  int64_t v129 = v126 * v128;
  // pto: %spmd_accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v130 = pto::Shape<1, 1, 1, -1, -1>(v124, v125, v126, v127, v48);
  // pto: %spmd_accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v131 = pto::Stride<-1, -1, -1, -1, -1>(v125 * v129, v129, v128, v48, v43);
  // pto: %spmd_accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v132 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v130, v131);
  // pto: %weights_proj__ssa_v0_view
  const int64_t v133 = 1;
  // pto: %weights_proj__ssa_v0_view
  const int64_t v134 = 1;
  // pto: %weights_proj__ssa_v0_view
  const int64_t v135 = 1;
  // pto: %weights_proj__ssa_v0_view
  int64_t v136 = v49 * v47;
  // pto: %weights_proj__ssa_v0_view
  int64_t v137 = v135 * v136;
  // pto: %weights_proj__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v138 = pto::Shape<1, 1, 1, -1, -1>(v133, v134, v135, v49, v47);
  // pto: %weights_proj__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v139 = pto::Stride<-1, -1, -1, -1, -1>(v134 * v137, v137, v136, v47, v43);
  // pto: %weights_proj__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v140 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v11, v138, v139);
  // pto: %spmd_idx_accum__ssa_v0_view
  const int64_t v141 = 1;
  // pto: %spmd_idx_accum__ssa_v0_view
  const int64_t v142 = 1;
  // pto: %spmd_idx_accum__ssa_v0_view
  const int64_t v143 = 1;
  // pto: %spmd_idx_accum__ssa_v0_view
  int64_t v144 = (int64_t) v34;
  // pto: %spmd_idx_accum__ssa_v0_view
  int64_t v145 = v144 * v49;
  // pto: %spmd_idx_accum__ssa_v0_view
  int64_t v146 = v143 * v145;
  // pto: %spmd_idx_accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v147 = pto::Shape<1, 1, 1, -1, -1>(v141, v142, v143, v144, v49);
  // pto: %spmd_idx_accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v148 = pto::Stride<-1, -1, -1, -1, -1>(v142 * v146, v146, v145, v49, v43);
  // pto: %spmd_idx_accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v149 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v147, v148);
  // pto: %native_sq_acc_inline5817__rv_v2
  Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v150 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v44);
  // pto: %native_sq_acc_inline5817__rv_v2
  uint64_t v151 = (uint64_t) v39;
  TASSIGN(v150, v151);
  uint64_t v152 = reinterpret_cast<uint64_t>(v10);
  set_ffts_base_addr(v152);
  // pto: %worker__ssa_v0
  int64_t v153 = (int64_t) v37;
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %17
  const int64_t v154 = 1;
  // pto: %17
  const int64_t v155 = 0;
  // pto: %17
  int64_t v156 = v33 / v52;
  // pto: %17
  bool v157 = v33 < v155;
  // pto: %17
  bool v158 = v52 < v155;
  // pto: %17
  bool v159 = v157 == v158;
  // pto: %17
  bool v160 = v33 % v52 != v155 && v157 != v158;
  // pto: %17
  int64_t v161 = v160 ? v156 - v154 : v156;
  // pto: %18
  bool v162 = v32 >= v49;
  // pto: %sq_group_inline5807__phi_v2
  int64_t v163 = v162 ? v50 : v43;
  // pto: %19
  int64_t v164 = (int64_t) ((uint64_t) v163 + (uint64_t) v53);
  // pto: %20
  const int64_t v165 = 1;
  // pto: %20
  const int64_t v166 = 0;
  // pto: %20
  int64_t v167 = v164 / v163;
  // pto: %20
  bool v168 = v164 < v166;
  // pto: %20
  bool v169 = v163 < v166;
  // pto: %20
  bool v170 = v168 == v169;
  // pto: %20
  bool v171 = v164 % v163 != v166 && v168 != v169;
  // pto: %20
  int64_t v172 = v171 ? v167 - v165 : v167;
  // pto: %21
  const int64_t v173 = 1;
  // pto: %21
  const int64_t v174 = 0;
  // pto: %21
  int64_t v175 = v161 / v44;
  // pto: %21
  bool v176 = v161 < v174;
  // pto: %21
  bool v177 = v44 < v174;
  // pto: %21
  bool v178 = v176 == v177;
  // pto: %21
  bool v179 = v161 % v44 != v174 && v176 != v177;
  // pto: %21
  int64_t v180 = v179 ? v175 - v173 : v175;
  // pto: %22
  for (int64_t v181 = v153; v181 < ((int64_t) ((uint64_t) v180 * (uint64_t) v172)); v181 += v51) {
    // pto: %23
    ;
    const int64_t v182 = 1;
    // pto: %23
    ;
    const int64_t v183 = 0;
    // pto: %23
    ;
    int64_t v184 = v181 / v172;
    // pto: %23
    ;
    bool v185 = v181 < v183;
    // pto: %23
    ;
    bool v186 = v172 < v183;
    // pto: %23
    ;
    bool v187 = v185 == v186;
    // pto: %23
    ;
    bool v188 = v181 % v172 != v183 && v185 != v186;
    // pto: %23
    ;
    int64_t v189 = v188 ? v184 - v182 : v184;
    // pto: %24
    ;
    int64_t v190 = (int64_t) ((uint64_t) v189 * (uint64_t) v44);
    // pto: %25
    ;
    int64_t v191 = v181 % v172;
    // pto: %26, %27, %28
    ;
    bool v192 = v191 < v54 ^ v172 < v54;
    // pto: %29, %30, %31, %32
    ;
    int64_t v193 = v191 != v54 & v192 ? (int64_t) ((uint64_t) v191 + (uint64_t) v172) : v191;
    // pto: %33
    ;
    int64_t v194 = (int64_t) ((uint64_t) v193 * (uint64_t) v163);
    // pto: %34
    ;
    int64_t v195 = (int64_t) ((uint64_t) v32 - (uint64_t) v190);
    // pto: %35
    ;
    int64_t v196 = v195 < v44 ? v195 : v44;
    // pto: %36
    ;
    int64_t v197 = (int64_t) ((uint64_t) v52 - (uint64_t) v194);
    // pto: %37
    ;
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    for (int64_t v198 = v54; v198 < (v163 < v197 ? v163 : v197); v198 += v43) {
      // pto: %38
      ;
      int64_t v199 = (int64_t) ((uint64_t) v194 + (uint64_t) v198);
      // pto: %39
      ;
      int64_t v200 = (int64_t) ((uint64_t) v199 * (uint64_t) v55);
      // pto: %40
      ;
      int64_t v201 = (int64_t) ((uint64_t) v42 - (uint64_t) v200);
      // pto: %41
      ;
      int64_t v202 = v201 < v55 ? v201 : v55;
      // pto: %42
      ;
      const int64_t v203 = 1;
      // pto: %42
      ;
      const int64_t v204 = 0;
      // pto: %42
      ;
      int64_t v205 = v202 / v46;
      // pto: %42
      ;
      bool v206 = v202 < v204;
      // pto: %42
      ;
      bool v207 = v46 < v204;
      // pto: %42
      ;
      bool v208 = v206 == v207;
      // pto: %42
      ;
      bool v209 = v202 % v46 != v204 && v206 != v207;
      // pto: %42
      ;
      int64_t v210 = v209 ? v205 - v203 : v205;
      // pto: %native_sq_acc_inline5817__tile
      ;
      Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v44);
      // pto: %native_sq_acc_inline5817__tile
      ;
      uint64_t v212 = (uint64_t) v39;
      TASSIGN(v211, v212);
      // pto: %43
      ;
      const int64_t v213 = 1;
      // pto: %43
      ;
      const int64_t v214 = 0;
      // pto: %43
      ;
      int64_t v215 = v210 / v56;
      // pto: %43
      ;
      bool v216 = v210 < v214;
      // pto: %43
      ;
      bool v217 = v56 < v214;
      // pto: %43
      ;
      bool v218 = v216 == v217;
      // pto: %43
      ;
      bool v219 = v210 % v56 != v214 && v216 != v217;
      // pto: %43
      ;
      int64_t v220 = v219 ? v215 - v213 : v215;
      // pto: %44
      ;
      int64_t v221 = (int64_t) ((uint64_t) v220 * (uint64_t) v56);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      for (int64_t v222 = v54; v222 < v221; v222 += v56) {
        // pto: %46
        ;
        int64_t v223 = (int64_t) ((uint64_t) v222 * (uint64_t) v46);
        // pto: %47
        ;
        int64_t v224 = (int64_t) ((uint64_t) v200 + (uint64_t) v223);
        // pto: %51, %50
        ;
        int64_t v225 = (int64_t) ((uint64_t) v200 + (uint64_t) ((int64_t) (uint64_t) v223 + (uint64_t) v46));
        // pto: %sq_lhs_inline5820__tile
        ;
        Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v226 = Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v196, v46);
        // pto: %sq_lhs_inline5820__tile
        ;
        uint64_t v227 = (uint64_t) v39;
        TASSIGN(v226, v227);
        // pto: %52
        ;
        int64_t v228 = v190 < v54 ? v54 : v190;
        // pto: %53
        ;
        int64_t v229 = v224 < v54 ? v54 : v224;
        // pto: %wide__ssa_v0_pview
        ;
        const int64_t v230 = 0;
        // pto: %wide__ssa_v0_pview
        ;
        __gm__ float* v231 = PTOAS__GLOBAL_TENSOR_DATA(v71);
        // pto: %wide__ssa_v0_pview
        ;
        const int64_t v232 = 1;
        // pto: %wide__ssa_v0_pview
        ;
        const int64_t v233 = 1;
        // pto: %wide__ssa_v0_pview
        ;
        const int64_t v234 = 1;
        // pto: %wide__ssa_v0_pview
        ;
        int64_t v235 = v196 * v42;
        // pto: %wide__ssa_v0_pview
        ;
        int64_t v236 = v234 * v235;
        // pto: %wide__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 32> v237 = pto::Shape<1, 1, 1, -1, 32>(v232, v233, v234, v196, v46);
        // pto: %wide__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v238 = pto::Stride<-1, -1, -1, -1, -1>(v233 * v236, v236, v235, v42, v43);
        // pto: %wide__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v239 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v231 + (v230 + v228 * v42 + v229 * v43), v237, v238);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v226, v239);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %0
        ;
        Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v240 = Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v196, v46);
        // pto: %0
        ;
        uint64_t v241 = (uint64_t) v40;
        TASSIGN(v240, v241);
        // pto: %55
        ;
        int64_t v242 = v225 < v54 ? v54 : v225;
        // pto: %56
        ;
        const int64_t v243 = 0;
        // pto: %56
        ;
        __gm__ float* v244 = PTOAS__GLOBAL_TENSOR_DATA(v71);
        // pto: %56
        ;
        const int64_t v245 = 1;
        // pto: %56
        ;
        const int64_t v246 = 1;
        // pto: %56
        ;
        const int64_t v247 = 1;
        // pto: %56
        ;
        int64_t v248 = v196 * v42;
        // pto: %56
        ;
        int64_t v249 = v247 * v248;
        // pto: %56
        ;
        pto::Shape<1, 1, 1, -1, 32> v250 = pto::Shape<1, 1, 1, -1, 32>(v245, v246, v247, v196, v46);
        // pto: %56
        ;
        pto::Stride<-1, -1, -1, -1, -1> v251 = pto::Stride<-1, -1, -1, -1, -1>(v246 * v249, v249, v248, v42, v43);
        // pto: %56
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v252 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v244 + (v243 + v228 * v42 + v242 * v43), v250, v251);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        TLOAD(v240, v252);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %sq_lhs_inline5820__tile_t
        ;
        Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v253 = Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v196);
        // pto: %sq_lhs_inline5820__tile_t
        ;
        uint64_t v254 = (uint64_t) v39;
        TASSIGN(v253, v254);
        // pto: %sq_lhs_inline5820__tile_Left
        ;
        Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v255 = Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v196, v46);
        // pto: %sq_lhs_inline5820__tile_Left
        ;
        uint64_t v256 = (uint64_t) v41;
        TASSIGN(v255, v256);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        TMOV(v255, v226);
        // pto: %sq_lhs_inline5820__tile_t_Right
        ;
        Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v257 = Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v196);
        // pto: %sq_lhs_inline5820__tile_t_Right
        ;
        uint64_t v258 = (uint64_t) v41;
        TASSIGN(v257, v258);
        TMOV(v257, v253);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %57
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        if (v222 == v54) {
          pipe_barrier(PIPE_M);
          TMATMUL(v211, v255, v257);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v211, v211, v255, v257);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        // pto: %2
        ;
        Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v259 = Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v196);
        // pto: %2
        ;
        uint64_t v260 = (uint64_t) v40;
        TASSIGN(v259, v260);
        // pto: %3
        ;
        Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v261 = Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v196, v46);
        // pto: %3
        ;
        uint64_t v262 = (uint64_t) v39;
        TASSIGN(v261, v262);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        TMOV(v261, v240);
        // pto: %4
        ;
        Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v263 = Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v196);
        // pto: %4
        ;
        uint64_t v264 = (uint64_t) v39;
        TASSIGN(v263, v264);
        TMOV(v263, v259);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %58
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        if (v222 == v57) {
          pipe_barrier(PIPE_M);
          TMATMUL(v211, v261, v263);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v211, v211, v261, v263);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      // pto: %59, %60
      ;
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      if ((int64_t) ((uint64_t) v210 - (uint64_t) v221) == v43) {
        // pto: %63
        ;
        int64_t v265 = (int64_t) ((uint64_t) v200 + (uint64_t) ((int64_t) (uint64_t) v220 * (uint64_t) v49));
        // pto: %6
        ;
        Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v266 = Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v196, v46);
        // pto: %6
        ;
        uint64_t v267 = (uint64_t) v39;
        TASSIGN(v266, v267);
        // pto: %64
        ;
        int64_t v268 = v190 < v54 ? v54 : v190;
        // pto: %65
        ;
        int64_t v269 = v265 < v54 ? v54 : v265;
        // pto: %66
        ;
        const int64_t v270 = 0;
        // pto: %66
        ;
        __gm__ float* v271 = PTOAS__GLOBAL_TENSOR_DATA(v71);
        // pto: %66
        ;
        const int64_t v272 = 1;
        // pto: %66
        ;
        const int64_t v273 = 1;
        // pto: %66
        ;
        const int64_t v274 = 1;
        // pto: %66
        ;
        int64_t v275 = v196 * v42;
        // pto: %66
        ;
        int64_t v276 = v274 * v275;
        // pto: %66
        ;
        pto::Shape<1, 1, 1, -1, 32> v277 = pto::Shape<1, 1, 1, -1, 32>(v272, v273, v274, v196, v46);
        // pto: %66
        ;
        pto::Stride<-1, -1, -1, -1, -1> v278 = pto::Stride<-1, -1, -1, -1, -1>(v273 * v276, v276, v275, v42, v43);
        // pto: %66
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v279 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v271 + (v270 + v268 * v42 + v269 * v43), v277, v278);
        TLOAD(v266, v279);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        // pto: %7
        ;
        Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v280 = Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v196);
        // pto: %7
        ;
        uint64_t v281 = (uint64_t) v39;
        TASSIGN(v280, v281);
        // pto: %8
        ;
        Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v282 = Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v196, v46);
        // pto: %8
        ;
        uint64_t v283 = (uint64_t) v41;
        TASSIGN(v282, v283);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        TMOV(v282, v266);
        // pto: %9
        ;
        Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v284 = Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v196);
        // pto: %9
        ;
        uint64_t v285 = (uint64_t) v41;
        TASSIGN(v284, v285);
        TMOV(v284, v280);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %67
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        if (v221 == v54) {
          pipe_barrier(PIPE_M);
          TMATMUL(v211, v282, v284);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v211, v211, v282, v284);
        };
      };
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %68, %69
      ;
      int64_t v286 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v199 * (uint64_t) v161) + (uint64_t) v190);
      // pto: %70
      ;
      int64_t v287 = v286 < v54 ? v54 : v286;
      // pto: %square__iter_v3_pview
      ;
      __gm__ float* v288 = PTOAS__GLOBAL_TENSOR_DATA(v80);
      // pto: %square__iter_v3_pview
      ;
      const int64_t v289 = 0;
      // pto: %square__iter_v3_pview
      ;
      const int64_t v290 = 16;
      // pto: %square__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, 16, 16> v291 = pto::Shape<1, 1, 1, 16, 16>();
      // pto: %square__iter_v3_pview
      ;
      pto::Stride<256, 256, 256, 16, 1> v292 = pto::Stride<256, 256, 256, 16, 1>();
      // pto: %square__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<256, 256, 256, 16, 1>, pto::Layout::ND> v293 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<256, 256, 256, 16, 1>, pto::Layout::ND>(v288 + (v289 + v287 * v290), v291, v292);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      pipe_barrier(PIPE_FIX);
      TSTORE(v293, v150);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    };
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  if (v162) {
    // pto: %72
    ;
    int64_t v294 = (int64_t) ((uint64_t) v34 + (uint64_t) v58);
    // pto: %73
    ;
    const int64_t v295 = 1;
    // pto: %73
    ;
    const int64_t v296 = 0;
    // pto: %73
    ;
    int64_t v297 = v294 / v49;
    // pto: %73
    ;
    bool v298 = v294 < v296;
    // pto: %73
    ;
    bool v299 = v49 < v296;
    // pto: %73
    ;
    bool v300 = v298 == v299;
    // pto: %73
    ;
    bool v301 = v294 % v49 != v296 && v298 != v299;
    // pto: %73
    ;
    int64_t v302 = v301 ? v297 - v295 : v297;
    // pto: %74
    ;
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    for (int64_t v303 = v153; v303 < ((int64_t) ((uint64_t) v302 * (uint64_t) v52)); v303 += v51) {
      // pto: %77
      ;
      const int64_t v304 = 1;
      // pto: %77
      ;
      const int64_t v305 = 0;
      // pto: %77
      ;
      int64_t v306 = v303 / v302;
      // pto: %77
      ;
      bool v307 = v303 < v305;
      // pto: %77
      ;
      bool v308 = v302 < v305;
      // pto: %77
      ;
      bool v309 = v307 == v308;
      // pto: %77
      ;
      bool v310 = v303 % v302 != v305 && v307 != v308;
      // pto: %77
      ;
      int64_t v311 = v310 ? v306 - v304 : v306;
      // pto: %80
      ;
      int64_t v312 = v303 % v302;
      // pto: %81, %82, %83
      ;
      bool v313 = v312 < v54 ^ v302 < v54;
      // pto: %84, %85, %86, %87
      ;
      int64_t v314 = v312 != v54 & v313 ? (int64_t) ((uint64_t) v312 + (uint64_t) v302) : v312;
      // pto: %88
      ;
      int64_t v315 = (int64_t) ((uint64_t) v314 * (uint64_t) v49);
      // pto: %89
      ;
      int64_t v316 = (int64_t) ((uint64_t) v34 - (uint64_t) v315);
      // pto: %90
      ;
      int64_t v317 = v316 < v49 ? v316 : v49;
      // pto: %92, %91
      ;
      int64_t v318 = (int64_t) ((uint64_t) v42 - (uint64_t) ((int64_t) (uint64_t) v311 * (uint64_t) v55));
      // pto: %93
      ;
      int64_t v319 = v318 < v55 ? v318 : v55;
      // pto: %94
      ;
      const int64_t v320 = 1;
      // pto: %94
      ;
      const int64_t v321 = 0;
      // pto: %94
      ;
      int64_t v322 = v319 / v49;
      // pto: %94
      ;
      bool v323 = v319 < v321;
      // pto: %94
      ;
      bool v324 = v49 < v321;
      // pto: %94
      ;
      bool v325 = v323 == v324;
      // pto: %94
      ;
      bool v326 = v319 % v49 != v321 && v323 != v324;
      // pto: %94
      ;
      // pto: %95
      ;
      int64_t v327 = (int64_t) ((uint64_t) v311 * (uint64_t) v59);
      // pto: %panel64_wide_first_x_inline5830__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v328 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v317, v60);
      // pto: %panel64_wide_first_x_inline5830__tile
      ;
      uint64_t v329 = (uint64_t) v39;
      TASSIGN(v328, v329);
      // pto: %96
      ;
      int64_t v330 = v315 < v54 ? v54 : v315;
      // pto: %97
      ;
      int64_t v331 = v327 < v54 ? v54 : v327;
      // pto: %packed_flat__ssa_v0_pview
      ;
      const int64_t v332 = 0;
      // pto: %packed_flat__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v333 = PTOAS__GLOBAL_TENSOR_DATA(v97);
      // pto: %packed_flat__ssa_v0_pview
      ;
      const int64_t v334 = 1;
      // pto: %packed_flat__ssa_v0_pview
      ;
      const int64_t v335 = 1;
      // pto: %packed_flat__ssa_v0_pview
      ;
      const int64_t v336 = 1;
      // pto: %packed_flat__ssa_v0_pview
      ;
      int64_t v337 = v317 * v45;
      // pto: %packed_flat__ssa_v0_pview
      ;
      int64_t v338 = v336 * v337;
      // pto: %packed_flat__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 128> v339 = pto::Shape<1, 1, 1, -1, 128>(v334, v335, v336, v317, v60);
      // pto: %packed_flat__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v340 = pto::Stride<-1, -1, -1, -1, -1>(v335 * v338, v338, v337, v45, v43);
      // pto: %packed_flat__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v341 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v333 + (v332 + v330 * v45 + v331 * v43), v339, v340);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      TLOAD(v328, v341);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %panel64_wide_first_w_inline5831__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v342 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
      // pto: %panel64_wide_first_w_inline5831__tile
      ;
      uint64_t v343 = (uint64_t) v40;
      TASSIGN(v342, v343);
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v344 = PTOAS__GLOBAL_TENSOR_DATA(v88);
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      const int64_t v345 = 0;
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      const int64_t v346 = 32;
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 128, 32> v347 = pto::Shape<1, 1, 1, 128, 32>();
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      pto::Stride<4096, 4096, 4096, 32, 1> v348 = pto::Stride<4096, 4096, 4096, 32, 1>();
      // pto: %hc_packed_weight__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND> v349 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND>(v344 + (v345 + v331 * v346), v347, v348);
      TLOAD(v342, v349);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      // pto: %panel64_wide_first_x_inline5830__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v350 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v317, v60);
      // pto: %panel64_wide_first_x_inline5830__tile_Left
      ;
      uint64_t v351 = (uint64_t) v41;
      TASSIGN(v350, v351);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      TMOV(v350, v328);
      // pto: %panel64_wide_first_w_inline5831__tile_Right
      ;
      Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v352 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
      // pto: %panel64_wide_first_w_inline5831__tile_Right
      ;
      uint64_t v353 = (uint64_t) v41;
      TASSIGN(v352, v353);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      TMOV(v352, v342);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      // pto: %panel64_wide_accumulator_inline5832__tile
      ;
      Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v354 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v317, v46);
      // pto: %panel64_wide_accumulator_inline5832__tile
      ;
      uint64_t v355 = (uint64_t) v39;
      TASSIGN(v354, v355);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
      TMATMUL(v354, v350, v352);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      for (int64_t v356 = v43; v356 < (v326 ? v322 - v320 : v322); v356 += v43) {
        // pto: %101, %100
        ;
        int64_t v357 = (int64_t) ((uint64_t) v327 + (uint64_t) ((int64_t) (uint64_t) v356 * (uint64_t) v60));
        // pto: %panel64_wide_x_inline5835__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v358 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v317, v60);
        // pto: %panel64_wide_x_inline5835__tile
        ;
        uint64_t v359 = (uint64_t) v39;
        TASSIGN(v358, v359);
        // pto: %103
        ;
        int64_t v360 = v357 < v54 ? v54 : v357;
        // pto: %104
        ;
        const int64_t v361 = 0;
        // pto: %104
        ;
        __gm__ bfloat16_t* v362 = PTOAS__GLOBAL_TENSOR_DATA(v97);
        // pto: %104
        ;
        const int64_t v363 = 1;
        // pto: %104
        ;
        const int64_t v364 = 1;
        // pto: %104
        ;
        const int64_t v365 = 1;
        // pto: %104
        ;
        int64_t v366 = v317 * v45;
        // pto: %104
        ;
        int64_t v367 = v365 * v366;
        // pto: %104
        ;
        pto::Shape<1, 1, 1, -1, 128> v368 = pto::Shape<1, 1, 1, -1, 128>(v363, v364, v365, v317, v60);
        // pto: %104
        ;
        pto::Stride<-1, -1, -1, -1, -1> v369 = pto::Stride<-1, -1, -1, -1, -1>(v364 * v367, v367, v366, v45, v43);
        // pto: %104
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v370 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v362 + (v361 + v330 * v45 + v360 * v43), v368, v369);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
        TLOAD(v358, v370);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        // pto: %panel64_wide_w_inline5836__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v371 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
        // pto: %panel64_wide_w_inline5836__tile
        ;
        uint64_t v372 = (uint64_t) v40;
        TASSIGN(v371, v372);
        // pto: %106
        ;
        __gm__ bfloat16_t* v373 = PTOAS__GLOBAL_TENSOR_DATA(v88);
        // pto: %106
        ;
        const int64_t v374 = 0;
        // pto: %106
        ;
        const int64_t v375 = 32;
        // pto: %106
        ;
        pto::Shape<1, 1, 1, 128, 32> v376 = pto::Shape<1, 1, 1, 128, 32>();
        // pto: %106
        ;
        pto::Stride<4096, 4096, 4096, 32, 1> v377 = pto::Stride<4096, 4096, 4096, 32, 1>();
        // pto: %106
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND> v378 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND>(v373 + (v374 + v360 * v375), v376, v377);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        TLOAD(v371, v378);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
        // pto: %panel64_wide_x_inline5835__tile_Left
        ;
        Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v379 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v317, v60);
        // pto: %panel64_wide_x_inline5835__tile_Left
        ;
        uint64_t v380 = (uint64_t) v41;
        TASSIGN(v379, v380);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        TMOV(v379, v358);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
        // pto: %panel64_wide_w_inline5836__tile_Right
        ;
        Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v381 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
        // pto: %panel64_wide_w_inline5836__tile_Right
        ;
        uint64_t v382 = (uint64_t) v41;
        TASSIGN(v381, v382);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
        TMOV(v381, v371);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        TMATMUL_ACC(v354, v354, v379, v381);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      };
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      v354.SetValidShape(v317, v46);
      // pto: %107, %108
      ;
      int64_t v383 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v311 * (uint64_t) v34) + (uint64_t) v315);
      // pto: %109
      ;
      int64_t v384 = v383 < v54 ? v54 : v383;
      // pto: %linear__iter_v1_pview
      ;
      const int64_t v385 = 0;
      // pto: %linear__iter_v1_pview
      ;
      __gm__ float* v386 = PTOAS__GLOBAL_TENSOR_DATA(v106);
      // pto: %linear__iter_v1_pview
      ;
      const int64_t v387 = 1;
      // pto: %linear__iter_v1_pview
      ;
      const int64_t v388 = 1;
      // pto: %linear__iter_v1_pview
      ;
      const int64_t v389 = 1;
      // pto: %linear__iter_v1_pview
      ;
      int64_t v390 = v317 * v46;
      // pto: %linear__iter_v1_pview
      ;
      int64_t v391 = v389 * v390;
      // pto: %linear__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, -1, 32> v392 = pto::Shape<1, 1, 1, -1, 32>(v387, v388, v389, v317, v46);
      // pto: %linear__iter_v1_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v393 = pto::Stride<-1, -1, -1, -1, -1>(v388 * v391, v391, v390, v46, v43);
      // pto: %linear__iter_v1_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v394 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v386 + (v385 + v384 * v46 + v54 * v43), v392, v393);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      TSTORE(v394, v354);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
    };
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  } else {
    // pto: %110
    ;
    const int64_t v395 = 1;
    // pto: %110
    ;
    const int64_t v396 = 0;
    // pto: %110
    ;
    int64_t v397 = v34 / v44;
    // pto: %110
    ;
    bool v398 = v34 < v396;
    // pto: %110
    ;
    bool v399 = v44 < v396;
    // pto: %110
    ;
    bool v400 = v398 == v399;
    // pto: %110
    ;
    bool v401 = v34 % v44 != v396 && v398 != v399;
    // pto: %110
    ;
    int64_t v402 = v401 ? v397 - v395 : v397;
    // pto: %111
    ;
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
    for (int64_t v403 = v153; v403 < ((int64_t) ((uint64_t) v402 * (uint64_t) v52)); v403 += v51) {
      // pto: %113
      ;
      const int64_t v404 = 1;
      // pto: %113
      ;
      const int64_t v405 = 0;
      // pto: %113
      ;
      int64_t v406 = v403 / v402;
      // pto: %113
      ;
      bool v407 = v403 < v405;
      // pto: %113
      ;
      bool v408 = v402 < v405;
      // pto: %113
      ;
      bool v409 = v407 == v408;
      // pto: %113
      ;
      bool v410 = v403 % v402 != v405 && v407 != v408;
      // pto: %113
      ;
      int64_t v411 = v410 ? v406 - v404 : v406;
      // pto: %115
      ;
      int64_t v412 = v403 % v402;
      // pto: %116, %117, %118
      ;
      bool v413 = v412 < v54 ^ v402 < v54;
      // pto: %119, %120, %121, %122
      ;
      int64_t v414 = v412 != v54 & v413 ? (int64_t) ((uint64_t) v412 + (uint64_t) v402) : v412;
      // pto: %123
      ;
      int64_t v415 = (int64_t) ((uint64_t) v414 * (uint64_t) v44);
      // pto: %125, %124
      ;
      int64_t v416 = (int64_t) ((uint64_t) v42 - (uint64_t) ((int64_t) (uint64_t) v411 * (uint64_t) v55));
      // pto: %126
      ;
      int64_t v417 = v416 < v55 ? v416 : v55;
      // pto: %127
      ;
      const int64_t v418 = 1;
      // pto: %127
      ;
      const int64_t v419 = 0;
      // pto: %127
      ;
      int64_t v420 = v417 / v49;
      // pto: %127
      ;
      bool v421 = v417 < v419;
      // pto: %127
      ;
      bool v422 = v49 < v419;
      // pto: %127
      ;
      bool v423 = v421 == v422;
      // pto: %127
      ;
      bool v424 = v417 % v49 != v419 && v421 != v422;
      // pto: %127
      ;
      // pto: %panel64_accumulator_inline5842__tile
      ;
      Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v425 = Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v46);
      // pto: %panel64_accumulator_inline5842__tile
      ;
      uint64_t v426 = (uint64_t) v39;
      TASSIGN(v425, v426);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v427 = v54; v427 < (v424 ? v420 - v418 : v420); v427 += v43) {
        // pto: %128, %130, %129
        ;
        int64_t v428 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v411 * (uint64_t) v59) + (uint64_t) ((int64_t) (uint64_t) v427 * (uint64_t) v60));
        // pto: %panel64_x16_inline5845__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v429 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v60);
        // pto: %panel64_x16_inline5845__tile
        ;
        uint64_t v430 = (uint64_t) v40;
        TASSIGN(v429, v430);
        // pto: %131
        ;
        int64_t v431 = v415 < v54 ? v54 : v415;
        // pto: %132
        ;
        int64_t v432 = v428 < v54 ? v54 : v428;
        // pto: %133
        ;
        __gm__ bfloat16_t* v433 = PTOAS__GLOBAL_TENSOR_DATA(v97);
        // pto: %133
        ;
        const int64_t v434 = 0;
        // pto: %133
        ;
        const int64_t v435 = 32768;
        // pto: %133
        ;
        pto::Shape<1, 1, 1, 16, 128> v436 = pto::Shape<1, 1, 1, 16, 128>();
        // pto: %133
        ;
        pto::Stride<524288, 524288, 524288, 32768, 1> v437 = pto::Stride<524288, 524288, 524288, 32768, 1>();
        // pto: %133
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND> v438 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND>(v433 + (v434 + v431 * v435 + v432), v436, v437);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        TLOAD(v429, v438);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
        // pto: %panel64_w16_inline5846__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v439 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
        // pto: %panel64_w16_inline5846__tile
        ;
        uint64_t v440 = (uint64_t) v39;
        TASSIGN(v439, v440);
        // pto: %135
        ;
        __gm__ bfloat16_t* v441 = PTOAS__GLOBAL_TENSOR_DATA(v88);
        // pto: %135
        ;
        const int64_t v442 = 0;
        // pto: %135
        ;
        const int64_t v443 = 32;
        // pto: %135
        ;
        pto::Shape<1, 1, 1, 128, 32> v444 = pto::Shape<1, 1, 1, 128, 32>();
        // pto: %135
        ;
        pto::Stride<4096, 4096, 4096, 32, 1> v445 = pto::Stride<4096, 4096, 4096, 32, 1>();
        // pto: %135
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND> v446 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND>(v441 + (v442 + v432 * v443), v444, v445);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v439, v446);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %panel64_x16_inline5845__tile_Left
        ;
        Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v447 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v60);
        // pto: %panel64_x16_inline5845__tile_Left
        ;
        uint64_t v448 = (uint64_t) v41;
        TASSIGN(v447, v448);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
        pipe_barrier(PIPE_MTE1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        TMOV(v447, v429);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        // pto: %panel64_w16_inline5846__tile_Right
        ;
        Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v449 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
        // pto: %panel64_w16_inline5846__tile_Right
        ;
        uint64_t v450 = (uint64_t) v41;
        TASSIGN(v449, v450);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        TMOV(v449, v439);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        // pto: %136
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        if (v427 == v54) {
          TMATMUL(v425, v447, v449);
        } else {
          TMATMUL_ACC(v425, v425, v447, v449);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
      // pto: %138, %139
      ;
      int64_t v451 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v411 * (uint64_t) v34) + (uint64_t) v415);
      // pto: %140
      ;
      int64_t v452 = v451 < v54 ? v54 : v451;
      // pto: %linear__iter_v4_pview
      ;
      __gm__ float* v453 = PTOAS__GLOBAL_TENSOR_DATA(v106);
      // pto: %linear__iter_v4_pview
      ;
      const int64_t v454 = 0;
      // pto: %linear__iter_v4_pview
      ;
      const int64_t v455 = 32;
      // pto: %linear__iter_v4_pview
      ;
      pto::Shape<1, 1, 1, 16, 32> v456 = pto::Shape<1, 1, 1, 16, 32>();
      // pto: %linear__iter_v4_pview
      ;
      pto::Stride<512, 512, 512, 32, 1> v457 = pto::Stride<512, 512, 512, 32, 1>();
      // pto: %linear__iter_v4_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND> v458 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND>(v453 + (v454 + v452 * v455), v456, v457);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
      pipe_barrier(PIPE_FIX);
      TSTORE(v458, v425);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
    };
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %141
  int64_t v459 = (int64_t) ((uint64_t) v32 + (uint64_t) v61);
  // pto: %142
  const int64_t v460 = 1;
  // pto: %142
  const int64_t v461 = 0;
  // pto: %142
  int64_t v462 = v459 / v44;
  // pto: %142
  bool v463 = v459 < v461;
  // pto: %142
  bool v464 = v44 < v461;
  // pto: %142
  bool v465 = v463 == v464;
  // pto: %142
  bool v466 = v459 % v44 != v461 && v463 != v464;
  // pto: %142
  int64_t v467 = v466 ? v462 - v460 : v462;
  // pto: %143
  int64_t v468 = (int64_t) ((uint64_t) v32 + (uint64_t) v58);
  // pto: %144
  const int64_t v469 = 1;
  // pto: %144
  const int64_t v470 = 0;
  // pto: %144
  int64_t v471 = v468 / v49;
  // pto: %144
  bool v472 = v468 < v470;
  // pto: %144
  bool v473 = v49 < v470;
  // pto: %144
  bool v474 = v472 == v473;
  // pto: %144
  bool v475 = v468 % v49 != v470 && v472 != v473;
  // pto: %144
  int64_t v476 = v475 ? v471 - v469 : v471;
  // pto: %145
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
  if (v32 <= v44) {
    // pto: %146
    ;
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
    for (int64_t v477 = v153; v477 < ((int64_t) ((uint64_t) v467 * (uint64_t) v46)); v477 += v51) {
      // pto: %147
      ;
      const int64_t v478 = 1;
      // pto: %147
      ;
      const int64_t v479 = 0;
      // pto: %147
      ;
      int64_t v480 = v477 / v46;
      // pto: %147
      ;
      bool v481 = v477 < v479;
      // pto: %147
      ;
      bool v482 = v46 < v479;
      // pto: %147
      ;
      bool v483 = v481 == v482;
      // pto: %147
      ;
      bool v484 = v477 % v46 != v479 && v481 != v482;
      // pto: %147
      ;
      int64_t v485 = v484 ? v480 - v478 : v480;
      // pto: %148
      ;
      int64_t v486 = (int64_t) ((uint64_t) v485 * (uint64_t) v44);
      // pto: %149
      ;
      int64_t v487 = v477 % v46;
      // pto: %150, %151, %152
      ;
      int64_t v488 = v487 < v54 ? (int64_t) ((uint64_t) v487 + (uint64_t) v46) : v487;
      // pto: %153
      ;
      int64_t v489 = (int64_t) ((uint64_t) v488 * (uint64_t) v44);
      // pto: %154
      ;
      int64_t v490 = (int64_t) ((uint64_t) v32 - (uint64_t) v486);
      // pto: %155
      ;
      int64_t v491 = v490 < v44 ? v490 : v44;
      // pto: %m16_tile_inline5855__tile
      ;
      Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v492 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v44);
      // pto: %m16_tile_inline5855__tile
      ;
      uint64_t v493 = (uint64_t) v39;
      TASSIGN(v492, v493);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v494 = v54; v494 < v44; v494 += v43) {
        // pto: %flat_offset, %m16_k_block_inline5857__tile
        ;
        int32_t v495 = (v8)[(int64_t) ((uint64_t) v489 + (uint64_t) v494)];
        // pto: %156
        ;
        int64_t v496 = (int64_t) v495;
        // pto: %157
        ;
        int64_t v497 = v496 < v54 ? v54 : v496;
        // pto: %158
        ;
        int64_t v498 = (int64_t) ((uint64_t) v497 * (uint64_t) v62);
        // pto: %m16_a_inline5859__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v499 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v491, v62);
        // pto: %m16_a_inline5859__tile
        ;
        uint64_t v500 = (uint64_t) v39;
        TASSIGN(v499, v500);
        // pto: %159
        ;
        int64_t v501 = v486 < v54 ? v54 : v486;
        // pto: %160
        ;
        int64_t v502 = v498 < v54 ? v54 : v498;
        // pto: %normed__ssa_v0_pview
        ;
        const int64_t v503 = 0;
        // pto: %normed__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v504 = PTOAS__GLOBAL_TENSOR_DATA(v115);
        // pto: %normed__ssa_v0_pview
        ;
        const int64_t v505 = 1;
        // pto: %normed__ssa_v0_pview
        ;
        const int64_t v506 = 1;
        // pto: %normed__ssa_v0_pview
        ;
        const int64_t v507 = 1;
        // pto: %normed__ssa_v0_pview
        ;
        int64_t v508 = v491 * v47;
        // pto: %normed__ssa_v0_pview
        ;
        int64_t v509 = v507 * v508;
        // pto: %normed__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v510 = pto::Shape<1, 1, 1, -1, 256>(v505, v506, v507, v491, v62);
        // pto: %normed__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v511 = pto::Stride<-1, -1, -1, -1, -1>(v506 * v509, v509, v508, v47, v43);
        // pto: %normed__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v512 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v504 + (v503 + v501 * v47 + v502 * v43), v510, v511);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        TLOAD(v499, v512);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %m16_b_inline5860__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v513 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v62);
        // pto: %m16_b_inline5860__tile
        ;
        uint64_t v514 = (uint64_t) v40;
        TASSIGN(v513, v514);
        // pto: %161
        ;
        int64_t v515 = v489 < v54 ? v54 : v489;
        // pto: %wkv__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v516 = PTOAS__GLOBAL_TENSOR_DATA(v123);
        // pto: %wkv__ssa_v0_pview
        ;
        const int64_t v517 = 0;
        // pto: %wkv__ssa_v0_pview
        ;
        const int64_t v518 = 4096;
        // pto: %wkv__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 16, 256> v519 = pto::Shape<1, 1, 1, 16, 256>();
        // pto: %wkv__ssa_v0_pview
        ;
        pto::Stride<65536, 65536, 65536, 4096, 1> v520 = pto::Stride<65536, 65536, 65536, 4096, 1>();
        // pto: %wkv__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v521 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v516 + (v517 + v515 * v518 + v502), v519, v520);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v513, v521);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %m16_b_inline5860__tile_t
        ;
        Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v522 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
        // pto: %m16_b_inline5860__tile_t
        ;
        uint64_t v523 = (uint64_t) v40;
        TASSIGN(v522, v523);
        // pto: %m16_a_inline5859__tile_Left
        ;
        Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v524 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v491, v62);
        // pto: %m16_a_inline5859__tile_Left
        ;
        uint64_t v525 = (uint64_t) v41;
        TASSIGN(v524, v525);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        TMOV(v524, v499);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        // pto: %m16_b_inline5860__tile_t_Right
        ;
        Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v526 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
        // pto: %m16_b_inline5860__tile_t_Right
        ;
        uint64_t v527 = (uint64_t) v41;
        TASSIGN(v526, v527);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        TMOV(v526, v522);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
        // pto: %163
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
        if (v494 == v54) {
          TMATMUL(v492, v524, v526);
        } else {
          TMATMUL_ACC(v492, v492, v524, v526);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
      // pto: %164
      ;
      int64_t v528 = v486 < v54 ? v54 : v486;
      // pto: %165
      ;
      int64_t v529 = v489 < v54 ? v54 : v489;
      // pto: %accum__iter_v1_pview
      ;
      __gm__ float* v530 = PTOAS__GLOBAL_TENSOR_DATA(v132);
      // pto: %accum__iter_v1_pview
      ;
      const int64_t v531 = 0;
      // pto: %accum__iter_v1_pview
      ;
      const int64_t v532 = 512;
      // pto: %accum__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, 16, 16> v533 = pto::Shape<1, 1, 1, 16, 16>();
      // pto: %accum__iter_v1_pview
      ;
      pto::Stride<8192, 8192, 8192, 512, 1> v534 = pto::Stride<8192, 8192, 8192, 512, 1>();
      // pto: %accum__iter_v1_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v535 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v530 + (v531 + v528 * v532 + v529), v533, v534);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
      pipe_barrier(PIPE_FIX);
      TSTORE(v535, v492);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
    };
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
  } else {
    // pto: %166
    ;
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
    for (int64_t v536 = v153; v536 < ((int64_t) ((uint64_t) v476 * (uint64_t) v44)); v536 += v51) {
      // pto: %167
      ;
      const int64_t v537 = 1;
      // pto: %167
      ;
      const int64_t v538 = 0;
      // pto: %167
      ;
      int64_t v539 = v536 / v44;
      // pto: %167
      ;
      bool v540 = v536 < v538;
      // pto: %167
      ;
      bool v541 = v44 < v538;
      // pto: %167
      ;
      bool v542 = v540 == v541;
      // pto: %167
      ;
      bool v543 = v536 % v44 != v538 && v540 != v541;
      // pto: %167
      ;
      int64_t v544 = v543 ? v539 - v537 : v539;
      // pto: %168
      ;
      int64_t v545 = (int64_t) ((uint64_t) v544 * (uint64_t) v49);
      // pto: %169
      ;
      int64_t v546 = v536 % v44;
      // pto: %170, %171, %172
      ;
      int64_t v547 = v546 < v54 ? (int64_t) ((uint64_t) v546 + (uint64_t) v44) : v546;
      // pto: %173
      ;
      int64_t v548 = (int64_t) ((uint64_t) v547 * (uint64_t) v56);
      int64_t v549 = (int64_t) ((uint64_t) v547 * (uint64_t) v46);
      // pto: %175
      ;
      int64_t v550 = (int64_t) ((uint64_t) v32 - (uint64_t) v545);
      // pto: %176
      ;
      int64_t v551 = v550 < v49 ? v550 : v49;
      // pto: %same_order_inline5866__rv_v2
      ;
      int64_t v552;
      v552 = v43;
      for (int64_t v553 = v54; v553 < v44; v553 += v43) {
        // pto: %178, %t__tile
        ;
        int32_t v554 = (v8)[(int64_t) ((uint64_t) v549 + (uint64_t) v553)];
        // pto: %180, %181, %182, %179
        ;
        int32_t v555 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v548 + (uint64_t) v43) * (uint64_t) v44) + (uint64_t) v553)];
        // pto: %183, %same_order_inline5866__phi_v4
        ;
        int64_t v556 = v554 != v555 ? v54 : v552;
        v552 = v556;
      };
      // pto: %184
      ;
      bool v557 = v552 == v43;
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
      if (v557) {
        // pto: %first_block_inline5868__tile
        ;
        int32_t v558 = (v8)[v549];
        // pto: %187
        ;
        int64_t v559 = (int64_t) v558;
        // pto: %188
        ;
        int64_t v560 = v559 < v54 ? v54 : v559;
        // pto: %189
        ;
        int64_t v561 = (int64_t) ((uint64_t) v560 * (uint64_t) v62);
        // pto: %first_a_inline5870__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v562 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v551, v62);
        // pto: %first_a_inline5870__tile
        ;
        uint64_t v563 = (uint64_t) v39;
        TASSIGN(v562, v563);
        // pto: %190
        ;
        int64_t v564 = v545 < v54 ? v54 : v545;
        // pto: %191
        ;
        int64_t v565 = v561 < v54 ? v54 : v561;
        // pto: %192
        ;
        const int64_t v566 = 0;
        // pto: %192
        ;
        __gm__ bfloat16_t* v567 = PTOAS__GLOBAL_TENSOR_DATA(v115);
        // pto: %192
        ;
        const int64_t v568 = 1;
        // pto: %192
        ;
        const int64_t v569 = 1;
        // pto: %192
        ;
        const int64_t v570 = 1;
        // pto: %192
        ;
        int64_t v571 = v551 * v47;
        // pto: %192
        ;
        int64_t v572 = v570 * v571;
        // pto: %192
        ;
        pto::Shape<1, 1, 1, -1, 256> v573 = pto::Shape<1, 1, 1, -1, 256>(v568, v569, v570, v551, v62);
        // pto: %192
        ;
        pto::Stride<-1, -1, -1, -1, -1> v574 = pto::Stride<-1, -1, -1, -1, -1>(v569 * v572, v572, v571, v47, v43);
        // pto: %192
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v575 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v567 + (v566 + v564 * v47 + v565 * v43), v573, v574);
        TLOAD(v562, v575);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %first_b_inline5871__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v576 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %first_b_inline5871__tile
        ;
        uint64_t v577 = (uint64_t) v40;
        TASSIGN(v576, v577);
        // pto: %193
        ;
        int64_t v578 = v549 < v54 ? v54 : v549;
        // pto: %195
        ;
        __gm__ bfloat16_t* v579 = PTOAS__GLOBAL_TENSOR_DATA(v123);
        // pto: %195
        ;
        const int64_t v580 = 0;
        // pto: %195
        ;
        const int64_t v581 = 4096;
        // pto: %195
        ;
        pto::Shape<1, 1, 1, 32, 256> v582 = pto::Shape<1, 1, 1, 32, 256>();
        // pto: %195
        ;
        pto::Stride<131072, 131072, 131072, 4096, 1> v583 = pto::Stride<131072, 131072, 131072, 4096, 1>();
        // pto: %195
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND> v584 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND>(v579 + (v580 + v578 * v581 + v565), v582, v583);
        TLOAD(v576, v584);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %first_b_inline5871__tile_t
        ;
        Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v585 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v46);
        // pto: %first_b_inline5871__tile_t
        ;
        uint64_t v586 = (uint64_t) v40;
        TASSIGN(v585, v586);
        // pto: %first_a_inline5870__tile_Left
        ;
        Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v587 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v551, v62);
        // pto: %first_a_inline5870__tile_Left
        ;
        uint64_t v588 = (uint64_t) v41;
        TASSIGN(v587, v588);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        TMOV(v587, v562);
        // pto: %first_b_inline5871__tile_t_Right
        ;
        Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v589 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v46);
        // pto: %first_b_inline5871__tile_t_Right
        ;
        uint64_t v590 = (uint64_t) v41;
        TASSIGN(v589, v590);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        TMOV(v589, v585);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        // pto: %wide_tile_inline5872__tile
        ;
        Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v591 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v551, v46);
        // pto: %wide_tile_inline5872__tile
        ;
        uint64_t v592 = (uint64_t) v39;
        TASSIGN(v591, v592);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        TMATMUL(v591, v587, v589);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        for (int64_t v593 = v43; v593 < v44; v593 += v43) {
          // pto: %197, %k_block_inline5874__tile
          ;
          int32_t v594 = (v8)[(int64_t) ((uint64_t) v549 + (uint64_t) v593)];
          // pto: %198
          ;
          int64_t v595 = (int64_t) v594;
          // pto: %199
          ;
          int64_t v596 = v595 < v54 ? v54 : v595;
          // pto: %200
          ;
          int64_t v597 = (int64_t) ((uint64_t) v596 * (uint64_t) v62);
          // pto: %a_inline5876__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v598 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v551, v62);
          // pto: %a_inline5876__tile
          ;
          uint64_t v599 = (uint64_t) v39;
          TASSIGN(v598, v599);
          // pto: %202
          ;
          int64_t v600 = v597 < v54 ? v54 : v597;
          // pto: %203
          ;
          const int64_t v601 = 0;
          // pto: %203
          ;
          __gm__ bfloat16_t* v602 = PTOAS__GLOBAL_TENSOR_DATA(v115);
          // pto: %203
          ;
          const int64_t v603 = 1;
          // pto: %203
          ;
          const int64_t v604 = 1;
          // pto: %203
          ;
          const int64_t v605 = 1;
          // pto: %203
          ;
          int64_t v606 = v551 * v47;
          // pto: %203
          ;
          int64_t v607 = v605 * v606;
          // pto: %203
          ;
          pto::Shape<1, 1, 1, -1, 256> v608 = pto::Shape<1, 1, 1, -1, 256>(v603, v604, v605, v551, v62);
          // pto: %203
          ;
          pto::Stride<-1, -1, -1, -1, -1> v609 = pto::Stride<-1, -1, -1, -1, -1>(v604 * v607, v607, v606, v47, v43);
          // pto: %203
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v610 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v602 + (v601 + v564 * v47 + v600 * v43), v608, v609);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          TLOAD(v598, v610);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %b_inline5877__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v611 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v46, v62);
          // pto: %b_inline5877__tile
          ;
          uint64_t v612 = (uint64_t) v40;
          TASSIGN(v611, v612);
          // pto: %206
          ;
          __gm__ bfloat16_t* v613 = PTOAS__GLOBAL_TENSOR_DATA(v123);
          // pto: %206
          ;
          const int64_t v614 = 0;
          // pto: %206
          ;
          const int64_t v615 = 4096;
          // pto: %206
          ;
          pto::Shape<1, 1, 1, 32, 256> v616 = pto::Shape<1, 1, 1, 32, 256>();
          // pto: %206
          ;
          pto::Stride<131072, 131072, 131072, 4096, 1> v617 = pto::Stride<131072, 131072, 131072, 4096, 1>();
          // pto: %206
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND> v618 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND>(v613 + (v614 + v578 * v615 + v600), v616, v617);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          TLOAD(v611, v618);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %b_inline5877__tile_t
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v619 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v46);
          // pto: %b_inline5877__tile_t
          ;
          uint64_t v620 = (uint64_t) v40;
          TASSIGN(v619, v620);
          // pto: %a_inline5876__tile_Left
          ;
          Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v621 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v551, v62);
          // pto: %a_inline5876__tile_Left
          ;
          uint64_t v622 = (uint64_t) v41;
          TASSIGN(v621, v622);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          TMOV(v621, v598);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %b_inline5877__tile_t_Right
          ;
          Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v623 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v46);
          // pto: %b_inline5877__tile_t_Right
          ;
          uint64_t v624 = (uint64_t) v41;
          TASSIGN(v623, v624);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          TMOV(v623, v619);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          TMATMUL_ACC(v591, v591, v621, v623);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        };
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
        // pto: %accum__iter_v4_pview
        ;
        const int64_t v625 = 0;
        // pto: %accum__iter_v4_pview
        ;
        __gm__ float* v626 = PTOAS__GLOBAL_TENSOR_DATA(v132);
        // pto: %accum__iter_v4_pview
        ;
        const int64_t v627 = 1;
        // pto: %accum__iter_v4_pview
        ;
        const int64_t v628 = 1;
        // pto: %accum__iter_v4_pview
        ;
        const int64_t v629 = 1;
        // pto: %accum__iter_v4_pview
        ;
        int64_t v630 = v551 * v48;
        // pto: %accum__iter_v4_pview
        ;
        int64_t v631 = v629 * v630;
        // pto: %accum__iter_v4_pview
        ;
        pto::Shape<1, 1, 1, -1, 32> v632 = pto::Shape<1, 1, 1, -1, 32>(v627, v628, v629, v551, v46);
        // pto: %accum__iter_v4_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v633 = pto::Stride<-1, -1, -1, -1, -1>(v628 * v631, v631, v630, v48, v43);
        // pto: %accum__iter_v4_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v634 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v626 + (v625 + v564 * v48 + v578 * v43), v632, v633);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
        TSTORE(v634, v591);
      } else {
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
        for (int64_t v635 = v54; v635 < v56; v635 += v43) {
          // pto: %210, %211
          ;
          int64_t v636 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v548 + (uint64_t) v635) * (uint64_t) v44);
          // pto: %narrow_first_block_inline5881__tile
          ;
          int32_t v637 = (v8)[v636];
          // pto: %214
          ;
          int64_t v638 = (int64_t) v637;
          // pto: %215
          ;
          int64_t v639 = v638 < v54 ? v54 : v638;
          // pto: %216
          ;
          int64_t v640 = (int64_t) ((uint64_t) v639 * (uint64_t) v62);
          // pto: %narrow_first_a_inline5883__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v641 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v551, v62);
          // pto: %narrow_first_a_inline5883__tile
          ;
          uint64_t v642 = (uint64_t) v39;
          TASSIGN(v641, v642);
          // pto: %217
          ;
          int64_t v643 = v545 < v54 ? v54 : v545;
          // pto: %218
          ;
          int64_t v644 = v640 < v54 ? v54 : v640;
          // pto: %219
          ;
          const int64_t v645 = 0;
          // pto: %219
          ;
          __gm__ bfloat16_t* v646 = PTOAS__GLOBAL_TENSOR_DATA(v115);
          // pto: %219
          ;
          const int64_t v647 = 1;
          // pto: %219
          ;
          const int64_t v648 = 1;
          // pto: %219
          ;
          const int64_t v649 = 1;
          // pto: %219
          ;
          int64_t v650 = v551 * v47;
          // pto: %219
          ;
          int64_t v651 = v649 * v650;
          // pto: %219
          ;
          pto::Shape<1, 1, 1, -1, 256> v652 = pto::Shape<1, 1, 1, -1, 256>(v647, v648, v649, v551, v62);
          // pto: %219
          ;
          pto::Stride<-1, -1, -1, -1, -1> v653 = pto::Stride<-1, -1, -1, -1, -1>(v648 * v651, v651, v650, v47, v43);
          // pto: %219
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v654 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v646 + (v645 + v643 * v47 + v644 * v43), v652, v653);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          TLOAD(v641, v654);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %narrow_first_b_inline5884__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v655 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v62);
          // pto: %narrow_first_b_inline5884__tile
          ;
          uint64_t v656 = (uint64_t) v40;
          TASSIGN(v655, v656);
          // pto: %220
          ;
          int64_t v657 = v636 < v54 ? v54 : v636;
          // pto: %222
          ;
          __gm__ bfloat16_t* v658 = PTOAS__GLOBAL_TENSOR_DATA(v123);
          // pto: %222
          ;
          const int64_t v659 = 0;
          // pto: %222
          ;
          const int64_t v660 = 4096;
          // pto: %222
          ;
          pto::Shape<1, 1, 1, 16, 256> v661 = pto::Shape<1, 1, 1, 16, 256>();
          // pto: %222
          ;
          pto::Stride<65536, 65536, 65536, 4096, 1> v662 = pto::Stride<65536, 65536, 65536, 4096, 1>();
          // pto: %222
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v663 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v658 + (v659 + v657 * v660 + v644), v661, v662);
          TLOAD(v655, v663);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %narrow_first_b_inline5884__tile_t
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v664 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
          // pto: %narrow_first_b_inline5884__tile_t
          ;
          uint64_t v665 = (uint64_t) v40;
          TASSIGN(v664, v665);
          // pto: %narrow_first_a_inline5883__tile_Left
          ;
          Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v666 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v551, v62);
          // pto: %narrow_first_a_inline5883__tile_Left
          ;
          uint64_t v667 = (uint64_t) v41;
          TASSIGN(v666, v667);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          TMOV(v666, v641);
          // pto: %narrow_first_b_inline5884__tile_t_Right
          ;
          Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v668 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
          // pto: %narrow_first_b_inline5884__tile_t_Right
          ;
          uint64_t v669 = (uint64_t) v41;
          TASSIGN(v668, v669);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          TMOV(v668, v664);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          // pto: %narrow_tile_inline5885__tile
          ;
          Tile<TileType::Acc, float, 64, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v670 = Tile<TileType::Acc, float, 64, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v551, v44);
          // pto: %narrow_tile_inline5885__tile
          ;
          uint64_t v671 = (uint64_t) v39;
          TASSIGN(v670, v671);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          wait_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
          TMATMUL(v670, v666, v668);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          for (int64_t v672 = v43; v672 < v44; v672 += v43) {
            // pto: %224, %narrow_block_inline5887__tile
            ;
            int32_t v673 = (v8)[(int64_t) ((uint64_t) v636 + (uint64_t) v672)];
            // pto: %225
            ;
            int64_t v674 = (int64_t) v673;
            // pto: %226
            ;
            int64_t v675 = v674 < v54 ? v54 : v674;
            // pto: %227
            ;
            int64_t v676 = (int64_t) ((uint64_t) v675 * (uint64_t) v62);
            // pto: %narrow_a_inline5889__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v677 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v551, v62);
            // pto: %narrow_a_inline5889__tile
            ;
            uint64_t v678 = (uint64_t) v39;
            TASSIGN(v677, v678);
            // pto: %229
            ;
            int64_t v679 = v676 < v54 ? v54 : v676;
            // pto: %230
            ;
            const int64_t v680 = 0;
            // pto: %230
            ;
            __gm__ bfloat16_t* v681 = PTOAS__GLOBAL_TENSOR_DATA(v115);
            // pto: %230
            ;
            const int64_t v682 = 1;
            // pto: %230
            ;
            const int64_t v683 = 1;
            // pto: %230
            ;
            const int64_t v684 = 1;
            // pto: %230
            ;
            int64_t v685 = v551 * v47;
            // pto: %230
            ;
            int64_t v686 = v684 * v685;
            // pto: %230
            ;
            pto::Shape<1, 1, 1, -1, 256> v687 = pto::Shape<1, 1, 1, -1, 256>(v682, v683, v684, v551, v62);
            // pto: %230
            ;
            pto::Stride<-1, -1, -1, -1, -1> v688 = pto::Stride<-1, -1, -1, -1, -1>(v683 * v686, v686, v685, v47, v43);
            // pto: %230
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v689 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v681 + (v680 + v643 * v47 + v679 * v43), v687, v688);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            TLOAD(v677, v689);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %narrow_b_inline5890__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v690 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v62);
            // pto: %narrow_b_inline5890__tile
            ;
            uint64_t v691 = (uint64_t) v40;
            TASSIGN(v690, v691);
            // pto: %233
            ;
            __gm__ bfloat16_t* v692 = PTOAS__GLOBAL_TENSOR_DATA(v123);
            // pto: %233
            ;
            const int64_t v693 = 0;
            // pto: %233
            ;
            const int64_t v694 = 4096;
            // pto: %233
            ;
            pto::Shape<1, 1, 1, 16, 256> v695 = pto::Shape<1, 1, 1, 16, 256>();
            // pto: %233
            ;
            pto::Stride<65536, 65536, 65536, 4096, 1> v696 = pto::Stride<65536, 65536, 65536, 4096, 1>();
            // pto: %233
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v697 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v692 + (v693 + v657 * v694 + v679), v695, v696);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            TLOAD(v690, v697);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %narrow_b_inline5890__tile_t
            ;
            Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v698 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
            // pto: %narrow_b_inline5890__tile_t
            ;
            uint64_t v699 = (uint64_t) v40;
            TASSIGN(v698, v699);
            // pto: %narrow_a_inline5889__tile_Left
            ;
            Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v700 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v551, v62);
            // pto: %narrow_a_inline5889__tile_Left
            ;
            uint64_t v701 = (uint64_t) v41;
            TASSIGN(v700, v701);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
            TMOV(v700, v677);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            // pto: %narrow_b_inline5890__tile_t_Right
            ;
            Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v702 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
            // pto: %narrow_b_inline5890__tile_t_Right
            ;
            uint64_t v703 = (uint64_t) v41;
            TASSIGN(v702, v703);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            TMOV(v702, v698);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            TMATMUL_ACC(v670, v670, v700, v702);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %accum__iter_v7_pview
          ;
          const int64_t v704 = 0;
          // pto: %accum__iter_v7_pview
          ;
          __gm__ float* v705 = PTOAS__GLOBAL_TENSOR_DATA(v132);
          // pto: %accum__iter_v7_pview
          ;
          const int64_t v706 = 1;
          // pto: %accum__iter_v7_pview
          ;
          const int64_t v707 = 1;
          // pto: %accum__iter_v7_pview
          ;
          const int64_t v708 = 1;
          // pto: %accum__iter_v7_pview
          ;
          int64_t v709 = v551 * v48;
          // pto: %accum__iter_v7_pview
          ;
          int64_t v710 = v708 * v709;
          // pto: %accum__iter_v7_pview
          ;
          pto::Shape<1, 1, 1, -1, 16> v711 = pto::Shape<1, 1, 1, -1, 16>(v706, v707, v708, v551, v44);
          // pto: %accum__iter_v7_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v712 = pto::Stride<-1, -1, -1, -1, -1>(v707 * v710, v710, v709, v48, v43);
          // pto: %accum__iter_v7_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v713 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v705 + (v704 + v643 * v48 + v657 * v43), v711, v712);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
          TSTORE(v713, v670);
          set_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
        };
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
    };
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  // pto: %239
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  for (int64_t v714 = v153; v714 < ((int64_t) ((uint64_t) v467 * (uint64_t) v50)); v714 += v51) {
    // pto: %240
    ;
    const int64_t v715 = 1;
    // pto: %240
    ;
    const int64_t v716 = 0;
    // pto: %240
    ;
    int64_t v717 = v714 / v50;
    // pto: %240
    ;
    bool v718 = v714 < v716;
    // pto: %240
    ;
    bool v719 = v50 < v716;
    // pto: %240
    ;
    bool v720 = v718 == v719;
    // pto: %240
    ;
    bool v721 = v714 % v50 != v716 && v718 != v719;
    // pto: %240
    ;
    int64_t v722 = v721 ? v717 - v715 : v717;
    // pto: %241
    ;
    int64_t v723 = v714 % v50;
    // pto: %242, %243, %244
    ;
    int64_t v724 = v723 < v54 ? (int64_t) ((uint64_t) v723 + (uint64_t) v50) : v723;
    // pto: %245
    ;
    int64_t v725 = (int64_t) ((uint64_t) v722 * (uint64_t) v44);
    // pto: %246
    ;
    int64_t v726 = (int64_t) ((uint64_t) v724 * (uint64_t) v44);
    // pto: %247
    ;
    int64_t v727 = (int64_t) ((uint64_t) v32 - (uint64_t) v725);
    // pto: %248
    ;
    int64_t v728 = v727 < v44 ? v727 : v44;
    // pto: %tile_inline5899__tile
    ;
    Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v729 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v44);
    // pto: %tile_inline5899__tile
    ;
    uint64_t v730 = (uint64_t) v39;
    TASSIGN(v729, v730);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    for (int64_t v731 = v54; v731 < v44; v731 += v43) {
      // pto: %249, %250, %251, %252, %k_block_inline5901__tile
      ;
      int32_t v732 = (v12)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v722 * (uint64_t) v50) + (uint64_t) v724) * (uint64_t) v44) + (uint64_t) v731)];
      // pto: %253
      ;
      int64_t v733 = (int64_t) v732;
      // pto: %254
      ;
      int64_t v734 = v733 < v54 ? v54 : v733;
      // pto: %255
      ;
      int64_t v735 = (int64_t) ((uint64_t) v734 * (uint64_t) v62);
      // pto: %a_inline5903__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v736 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v728, v62);
      // pto: %a_inline5903__tile
      ;
      uint64_t v737 = (uint64_t) v39;
      TASSIGN(v736, v737);
      // pto: %256
      ;
      int64_t v738 = v725 < v54 ? v54 : v725;
      // pto: %257
      ;
      int64_t v739 = v735 < v54 ? v54 : v735;
      // pto: %258
      ;
      const int64_t v740 = 0;
      // pto: %258
      ;
      __gm__ bfloat16_t* v741 = PTOAS__GLOBAL_TENSOR_DATA(v115);
      // pto: %258
      ;
      const int64_t v742 = 1;
      // pto: %258
      ;
      const int64_t v743 = 1;
      // pto: %258
      ;
      const int64_t v744 = 1;
      // pto: %258
      ;
      int64_t v745 = v728 * v47;
      // pto: %258
      ;
      int64_t v746 = v744 * v745;
      // pto: %258
      ;
      pto::Shape<1, 1, 1, -1, 256> v747 = pto::Shape<1, 1, 1, -1, 256>(v742, v743, v744, v728, v62);
      // pto: %258
      ;
      pto::Stride<-1, -1, -1, -1, -1> v748 = pto::Stride<-1, -1, -1, -1, -1>(v743 * v746, v746, v745, v47, v43);
      // pto: %258
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v749 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v741 + (v740 + v738 * v47 + v739 * v43), v747, v748);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v736, v749);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %b_inline5904__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v750 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v62);
      // pto: %b_inline5904__tile
      ;
      uint64_t v751 = (uint64_t) v40;
      TASSIGN(v750, v751);
      // pto: %259
      ;
      int64_t v752 = v726 < v54 ? v54 : v726;
      // pto: %weights_proj__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v753 = PTOAS__GLOBAL_TENSOR_DATA(v140);
      // pto: %weights_proj__ssa_v0_pview
      ;
      const int64_t v754 = 0;
      // pto: %weights_proj__ssa_v0_pview
      ;
      const int64_t v755 = 4096;
      // pto: %weights_proj__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 256> v756 = pto::Shape<1, 1, 1, 16, 256>();
      // pto: %weights_proj__ssa_v0_pview
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v757 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %weights_proj__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v758 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v753 + (v754 + v752 * v755 + v739), v756, v757);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v750, v758);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %b_inline5904__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v759 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
      // pto: %b_inline5904__tile_t
      ;
      uint64_t v760 = (uint64_t) v40;
      TASSIGN(v759, v760);
      // pto: %a_inline5903__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v761 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v728, v62);
      // pto: %a_inline5903__tile_Left
      ;
      uint64_t v762 = (uint64_t) v41;
      TASSIGN(v761, v762);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      TMOV(v761, v736);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %b_inline5904__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v763 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
      // pto: %b_inline5904__tile_t_Right
      ;
      uint64_t v764 = (uint64_t) v41;
      TASSIGN(v763, v764);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      TMOV(v763, v759);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %261
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (v731 == v54) {
        TMATMUL(v729, v761, v763);
      } else {
        TMATMUL_ACC(v729, v729, v761, v763);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    };
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID6);
    // pto: %262
    ;
    int64_t v765 = v725 < v54 ? v54 : v725;
    // pto: %263
    ;
    int64_t v766 = v726 < v54 ? v54 : v726;
    // pto: %idx_accum__iter_v1_pview
    ;
    __gm__ float* v767 = PTOAS__GLOBAL_TENSOR_DATA(v149);
    // pto: %idx_accum__iter_v1_pview
    ;
    const int64_t v768 = 0;
    // pto: %idx_accum__iter_v1_pview
    ;
    const int64_t v769 = 64;
    // pto: %idx_accum__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 16> v770 = pto::Shape<1, 1, 1, 16, 16>();
    // pto: %idx_accum__iter_v1_pview
    ;
    pto::Stride<1024, 1024, 1024, 64, 1> v771 = pto::Stride<1024, 1024, 1024, 64, 1>();
    // pto: %idx_accum__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<1024, 1024, 1024, 64, 1>, pto::Layout::ND> v772 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<1024, 1024, 1024, 64, 1>, pto::Layout::ND>(v767 + (v768 + v765 * v769 + v766), v770, v771);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID6);
    pipe_barrier(PIPE_FIX);
    TSTORE(v772, v729);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void prepacked_prefix_indexer_vector(__gm__ float* v1, __gm__ float* v2, __gm__ bfloat16_t* v3, __gm__ bfloat16_t* v4, __gm__ float* v5, __gm__ bfloat16_t* v6, __gm__ bfloat16_t* v7, __gm__ int32_t* v8, __gm__ float* v9, __gm__ int64_t* v10, __gm__ bfloat16_t* v11, __gm__ int32_t* v12, __gm__ float* v13, __gm__ bfloat16_t* v14, __gm__ float* v15, __gm__ float* v16, __gm__ float* v17, __gm__ float* v18, __gm__ float* v19, __gm__ float* v20, __gm__ float* v21, __gm__ float* v22, __gm__ bfloat16_t* v23, __gm__ bfloat16_t* v24, __gm__ bfloat16_t* v25, __gm__ float* v26, __gm__ bfloat16_t* v27, __gm__ float* v28, __gm__ bfloat16_t* v29, __gm__ bfloat16_t* v30, __gm__ half* v31, int64_t v32, int64_t v33, int64_t v34, int64_t v35, int64_t v36, int32_t v37, int32_t v38, int32_t v39) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v40 = 12544;
  const int64_t v41 = 8448;
  const int64_t v42 = 4352;
  const int64_t v43 = 20;
  const int64_t v44 = 8388608;
  // pto: %c108288_i64
  const int64_t v45 = 108288;
  // pto: %c256_i64
  const int64_t v46 = 256;
  // pto: %c42752_i64
  const int64_t v47 = 42752;
  // pto: %c75520_i64
  const int64_t v48 = 75520;
  // pto: %c0_i64
  const int64_t v49 = 0;
  const int64_t v50 = 32;
  const int64_t v51 = 64;
  // pto: %c96_i64
  const int64_t v52 = 96;
  // pto: %c8448_i64
  const int64_t v53 = 8448;
  // pto: %c16640_i64
  const int64_t v54 = 16640;
  // pto: %c24832_i64
  const int64_t v55 = 24832;
  // pto: %c33024_i64
  const int64_t v56 = 33024;
  const int64_t v57 = 83712;
  const int64_t v58 = 79616;
  const int64_t v59 = 77568;
  const int64_t v60 = 76544;
  const int64_t v61 = 76032;
  const int64_t v62 = 75776;
  // pto: %c41216_i64
  const int64_t v63 = 41216;
  // pto: %c41472_i64
  const int64_t v64 = 41472;
  // pto: %c41728_i64
  const int64_t v65 = 41728;
  // pto: %c41984_i64
  const int64_t v66 = 41984;
  // pto: %c42240_i64
  const int64_t v67 = 42240;
  // pto: %c42496_i64
  const int64_t v68 = 42496;
  // pto: %c16384_index
  const int64_t v69 = 16384;
  // pto: %c1_index
  const int64_t v70 = 1;
  const int64_t v71 = 16;
  // pto: %c32768_index
  const int64_t v72 = 32768;
  // pto: %c32_index
  const int64_t v73 = 32;
  // pto: %c4096_index
  const int64_t v74 = 4096;
  const int64_t v75 = 512;
  // pto: %c64_index
  const int64_t v76 = 64;
  // pto: %c4_index
  const int64_t v77 = 4;
  // pto: %c24_index
  const int64_t v78 = 24;
  const int64_t v79 = 8;
  // pto: %c2_index
  const int64_t v80 = 2;
  // pto: %c48_index
  const int64_t v81 = 48;
  // pto: %c0_index
  const int64_t v82 = 0;
  // pto: %c256_index
  const int64_t v83 = 256;
  // pto: %cst_40
  const float v84 = 0.0f;
  // pto: %cst_41
  const bfloat16_t v85 = 0.0f;
  // pto: %c7_index
  const int64_t v86 = 7;
  // pto: %c192_index
  const int64_t v87 = 192;
  // pto: %c0_i32
  const int32_t v88 = 0;
  // pto: %c16_i32
  const int32_t v89 = 16;
  // pto: %c22_index
  const int64_t v90 = 22;
  // pto: %cst_47
  const float v91 = 6.10351563E-5f;
  // pto: %cst_48
  const float v92 = 9.99999997E-7f;
  // pto: %cst_49
  const float v93 = 1.0f;
  // pto: %cst_51
  const float v94 = 2.0f;
  // pto: %c8192_index
  const int64_t v95 = 8192;
  // pto: %c12288_index
  const int64_t v96 = 12288;
  // pto: %c2048_index
  const int64_t v97 = 2048;
  // pto: %c1024_index
  const int64_t v98 = 1024;
  // pto: %c128_index
  const int64_t v99 = 128;
  // pto: %cst_57
  const float v100 = 2.44140625E-4f;
  // pto: %c8388608_index
  const int64_t v101 = 8388608;
  // pto: %c2139095040_i64
  const int64_t v102 = 2139095040;
  // pto: %c2_i64
  const int64_t v103 = 2;
  // pto: %c152_i64
  const int64_t v104 = 152;
  // pto: %c1_i64
  const int64_t v105 = 1;
  const int64_t v106 = 12;
  // pto: %c18_index
  const int64_t v107 = 18;
  // pto: %c15_index
  const int64_t v108 = 15;
  // pto: %cst_66
  const float v109 = 0.0110485433f;
  // pto: %wide__ssa_v0_view
  const int64_t v110 = 1;
  // pto: %wide__ssa_v0_view
  const int64_t v111 = 1;
  // pto: %wide__ssa_v0_view
  const int64_t v112 = 1;
  // pto: %wide__ssa_v0_view
  int64_t v113 = (int64_t) v32;
  // pto: %wide__ssa_v0_view
  int64_t v114 = v113 * v69;
  // pto: %wide__ssa_v0_view
  int64_t v115 = v112 * v114;
  // pto: %wide__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v116 = pto::Shape<1, 1, 1, -1, -1>(v110, v111, v112, v113, v69);
  // pto: %wide__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v117 = pto::Stride<-1, -1, -1, -1, -1>(v111 * v115, v115, v114, v69, v70);
  // pto: %wide__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v118 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v116, v117);
  // pto: %packed_flat__ssa_v0_view
  const int64_t v119 = 1;
  // pto: %packed_flat__ssa_v0_view
  const int64_t v120 = 1;
  // pto: %packed_flat__ssa_v0_view
  const int64_t v121 = 1;
  // pto: %packed_flat__ssa_v0_view
  int64_t v122 = (int64_t) v34;
  // pto: %packed_flat__ssa_v0_view
  int64_t v123 = v122 * v72;
  // pto: %packed_flat__ssa_v0_view
  int64_t v124 = v121 * v123;
  // pto: %packed_flat__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v125 = pto::Shape<1, 1, 1, -1, -1>(v119, v120, v121, v122, v72);
  // pto: %packed_flat__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v126 = pto::Stride<-1, -1, -1, -1, -1>(v120 * v124, v124, v123, v72, v70);
  // pto: %packed_flat__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v127 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v125, v126);
  // pto: %normed__ssa_v0_view
  const int64_t v128 = 1;
  // pto: %normed__ssa_v0_view
  const int64_t v129 = 1;
  // pto: %normed__ssa_v0_view
  const int64_t v130 = 1;
  // pto: %normed__ssa_v0_view
  int64_t v131 = (int64_t) v32;
  // pto: %normed__ssa_v0_view
  int64_t v132 = v131 * v74;
  // pto: %normed__ssa_v0_view
  int64_t v133 = v130 * v132;
  // pto: %normed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v134 = pto::Shape<1, 1, 1, -1, -1>(v128, v129, v130, v131, v74);
  // pto: %normed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v135 = pto::Stride<-1, -1, -1, -1, -1>(v129 * v133, v133, v132, v74, v70);
  // pto: %normed__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v136 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v134, v135);
  // pto: %flat_hc__ssa_v0_view
  const int64_t v137 = 1;
  // pto: %flat_hc__ssa_v0_view
  const int64_t v138 = 1;
  // pto: %flat_hc__ssa_v0_view
  const int64_t v139 = 1;
  // pto: %flat_hc__ssa_v0_view
  int64_t v140 = (int64_t) v32;
  // pto: %flat_hc__ssa_v0_view
  int64_t v141 = v140 * v69;
  // pto: %flat_hc__ssa_v0_view
  int64_t v142 = v139 * v141;
  // pto: %flat_hc__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v143 = pto::Shape<1, 1, 1, -1, -1>(v137, v138, v139, v140, v69);
  // pto: %flat_hc__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v144 = pto::Stride<-1, -1, -1, -1, -1>(v138 * v142, v142, v141, v69, v70);
  // pto: %flat_hc__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v145 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v143, v144);
  // pto: %spmd_square_read__ssa_v0_view
  const int64_t v146 = 1;
  // pto: %spmd_square_read__ssa_v0_view
  const int64_t v147 = 1;
  // pto: %spmd_square_read__ssa_v0_view
  const int64_t v148 = 1;
  // pto: %spmd_square_read__ssa_v0_view
  int64_t v149 = (int64_t) v33;
  // pto: %spmd_square_read__ssa_v0_view
  int64_t v150 = v149 * v71;
  // pto: %spmd_square_read__ssa_v0_view
  int64_t v151 = v148 * v150;
  // pto: %spmd_square_read__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v152 = pto::Shape<1, 1, 1, -1, -1>(v146, v147, v148, v149, v71);
  // pto: %spmd_square_read__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v153 = pto::Stride<-1, -1, -1, -1, -1>(v147 * v151, v151, v150, v71, v70);
  // pto: %spmd_square_read__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v154 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v152, v153);
  // pto: %vec_ws__ssa_v0_view
  const int64_t v155 = 1;
  // pto: %vec_ws__ssa_v0_view
  const int64_t v156 = 1;
  // pto: %vec_ws__ssa_v0_view
  const int64_t v157 = 1;
  // pto: %vec_ws__ssa_v0_view
  int64_t v158 = (int64_t) v36;
  // pto: %vec_ws__ssa_v0_view
  int64_t v159 = v158 * v76;
  // pto: %vec_ws__ssa_v0_view
  int64_t v160 = v157 * v159;
  // pto: %vec_ws__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v161 = pto::Shape<1, 1, 1, -1, -1>(v155, v156, v157, v158, v76);
  // pto: %vec_ws__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v162 = pto::Stride<-1, -1, -1, -1, -1>(v156 * v160, v160, v159, v76, v70);
  // pto: %vec_ws__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v163 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v161, v162);
  // pto: %spmd_linear_read__ssa_v0_view
  const int64_t v164 = 1;
  // pto: %spmd_linear_read__ssa_v0_view
  const int64_t v165 = 1;
  // pto: %spmd_linear_read__ssa_v0_view
  const int64_t v166 = 1;
  // pto: %spmd_linear_read__ssa_v0_view
  int64_t v167 = (int64_t) v33;
  // pto: %spmd_linear_read__ssa_v0_view
  int64_t v168 = v167 * v73;
  // pto: %spmd_linear_read__ssa_v0_view
  int64_t v169 = v166 * v168;
  // pto: %spmd_linear_read__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v170 = pto::Shape<1, 1, 1, -1, -1>(v164, v165, v166, v167, v73);
  // pto: %spmd_linear_read__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v171 = pto::Stride<-1, -1, -1, -1, -1>(v165 * v169, v169, v168, v73, v70);
  // pto: %spmd_linear_read__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v172 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v17, v170, v171);
  // pto: %hc_attn_base__ssa_v0_view
  const int64_t v173 = 1;
  // pto: %hc_attn_base__ssa_v0_view
  const int64_t v174 = 1;
  // pto: %hc_attn_base__ssa_v0_view
  const int64_t v175 = 1;
  // pto: %hc_attn_base__ssa_v0_view
  const int64_t v176 = 1;
  // pto: %hc_attn_base__ssa_v0_view
  int64_t v177 = v78 * v70;
  // pto: %hc_attn_base__ssa_v0_view
  int64_t v178 = v176 * v177;
  // pto: %hc_attn_base__ssa_v0_view
  int64_t v179 = v175 * v178;
  // pto: %hc_attn_base__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v180 = pto::Shape<1, 1, 1, 1, -1>(v173, v174, v175, v176, v78);
  // pto: %hc_attn_base__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v181 = pto::Stride<-1, -1, -1, -1, -1>(v174 * v179, v179, v178, v177, v70);
  // pto: %hc_attn_base__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v182 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v19, v180, v181);
  // pto: %hc_base_2d__ssa_v0_view
  const int64_t v183 = 1;
  // pto: %hc_base_2d__ssa_v0_view
  const int64_t v184 = 1;
  // pto: %hc_base_2d__ssa_v0_view
  const int64_t v185 = 1;
  // pto: %hc_base_2d__ssa_v0_view
  int64_t v186 = v70 * v78;
  // pto: %hc_base_2d__ssa_v0_view
  int64_t v187 = v185 * v186;
  // pto: %hc_base_2d__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v188 = pto::Shape<1, 1, 1, -1, -1>(v183, v184, v185, v70, v78);
  // pto: %hc_base_2d__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v189 = pto::Stride<-1, -1, -1, -1, -1>(v184 * v187, v187, v186, v78, v70);
  // pto: %hc_base_2d__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v190 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v20, v188, v189);
  // pto: %post__ssa_v0_view
  const int64_t v191 = 1;
  // pto: %post__ssa_v0_view
  const int64_t v192 = 1;
  // pto: %post__ssa_v0_view
  const int64_t v193 = 1;
  // pto: %post__ssa_v0_view
  int64_t v194 = (int64_t) v32;
  // pto: %post__ssa_v0_view
  int64_t v195 = v194 * v77;
  // pto: %post__ssa_v0_view
  int64_t v196 = v193 * v195;
  // pto: %post__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v197 = pto::Shape<1, 1, 1, -1, -1>(v191, v192, v193, v194, v77);
  // pto: %post__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v198 = pto::Stride<-1, -1, -1, -1, -1>(v192 * v196, v196, v195, v77, v70);
  // pto: %post__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v199 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v21, v197, v198);
  // pto: %comb__ssa_v0_view
  const int64_t v200 = 1;
  // pto: %comb__ssa_v0_view
  const int64_t v201 = 1;
  // pto: %comb__ssa_v0_view
  const int64_t v202 = 1;
  // pto: %comb__ssa_v0_view
  int64_t v203 = (int64_t) v32;
  // pto: %comb__ssa_v0_view
  int64_t v204 = v203 * v71;
  // pto: %comb__ssa_v0_view
  int64_t v205 = v202 * v204;
  // pto: %comb__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v206 = pto::Shape<1, 1, 1, -1, -1>(v200, v201, v202, v203, v71);
  // pto: %comb__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v207 = pto::Stride<-1, -1, -1, -1, -1>(v201 * v205, v205, v204, v71, v70);
  // pto: %comb__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v208 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v22, v206, v207);
  // pto: %mixed__ssa_v0_view
  const int64_t v209 = 1;
  // pto: %mixed__ssa_v0_view
  const int64_t v210 = 1;
  // pto: %mixed__ssa_v0_view
  const int64_t v211 = 1;
  // pto: %mixed__ssa_v0_view
  int64_t v212 = (int64_t) v32;
  // pto: %mixed__ssa_v0_view
  int64_t v213 = v212 * v74;
  // pto: %mixed__ssa_v0_view
  int64_t v214 = v211 * v213;
  // pto: %mixed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v215 = pto::Shape<1, 1, 1, -1, -1>(v209, v210, v211, v212, v74);
  // pto: %mixed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v216 = pto::Stride<-1, -1, -1, -1, -1>(v210 * v214, v214, v213, v74, v70);
  // pto: %mixed__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v217 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v23, v215, v216);
  // pto: %mixed_tail__ssa_v0_view
  const int64_t v218 = 1;
  // pto: %mixed_tail__ssa_v0_view
  const int64_t v219 = 1;
  // pto: %mixed_tail__ssa_v0_view
  const int64_t v220 = 1;
  // pto: %mixed_tail__ssa_v0_view
  int64_t v221 = v79 * v74;
  // pto: %mixed_tail__ssa_v0_view
  int64_t v222 = v220 * v221;
  // pto: %mixed_tail__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v223 = pto::Shape<1, 1, 1, -1, -1>(v218, v219, v220, v79, v74);
  // pto: %mixed_tail__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v224 = pto::Stride<-1, -1, -1, -1, -1>(v219 * v222, v222, v221, v74, v70);
  // pto: %mixed_tail__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v225 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v24, v223, v224);
  // pto: %attn_norm_w__ssa_v0_view
  const int64_t v226 = 1;
  // pto: %attn_norm_w__ssa_v0_view
  const int64_t v227 = 1;
  // pto: %attn_norm_w__ssa_v0_view
  const int64_t v228 = 1;
  // pto: %attn_norm_w__ssa_v0_view
  const int64_t v229 = 1;
  // pto: %attn_norm_w__ssa_v0_view
  int64_t v230 = v74 * v70;
  // pto: %attn_norm_w__ssa_v0_view
  int64_t v231 = v229 * v230;
  // pto: %attn_norm_w__ssa_v0_view
  int64_t v232 = v228 * v231;
  // pto: %attn_norm_w__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v233 = pto::Shape<1, 1, 1, 1, -1>(v226, v227, v228, v229, v74);
  // pto: %attn_norm_w__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v234 = pto::Stride<-1, -1, -1, -1, -1>(v227 * v232, v232, v231, v230, v70);
  // pto: %attn_norm_w__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v235 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v25, v233, v234);
  // pto: %spmd_accum_read__ssa_v0_view
  const int64_t v236 = 1;
  // pto: %spmd_accum_read__ssa_v0_view
  const int64_t v237 = 1;
  // pto: %spmd_accum_read__ssa_v0_view
  const int64_t v238 = 1;
  // pto: %spmd_accum_read__ssa_v0_view
  int64_t v239 = (int64_t) v35;
  // pto: %spmd_accum_read__ssa_v0_view
  int64_t v240 = v239 * v75;
  // pto: %spmd_accum_read__ssa_v0_view
  int64_t v241 = v238 * v240;
  // pto: %spmd_accum_read__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v242 = pto::Shape<1, 1, 1, -1, -1>(v236, v237, v238, v239, v75);
  // pto: %spmd_accum_read__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v243 = pto::Stride<-1, -1, -1, -1, -1>(v237 * v241, v241, v240, v75, v70);
  // pto: %spmd_accum_read__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v244 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v26, v242, v243);
  // pto: %projected_kv__ssa_v0_view
  const int64_t v245 = 1;
  // pto: %projected_kv__ssa_v0_view
  const int64_t v246 = 1;
  // pto: %projected_kv__ssa_v0_view
  const int64_t v247 = 1;
  // pto: %projected_kv__ssa_v0_view
  int64_t v248 = (int64_t) v32;
  // pto: %projected_kv__ssa_v0_view
  int64_t v249 = v248 * v75;
  // pto: %projected_kv__ssa_v0_view
  int64_t v250 = v247 * v249;
  // pto: %projected_kv__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v251 = pto::Shape<1, 1, 1, -1, -1>(v245, v246, v247, v248, v75);
  // pto: %projected_kv__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v252 = pto::Stride<-1, -1, -1, -1, -1>(v246 * v250, v250, v249, v75, v70);
  // pto: %projected_kv__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v253 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v27, v251, v252);
  // pto: %spmd_idx_accum_read__ssa_v0_view
  const int64_t v254 = 1;
  // pto: %spmd_idx_accum_read__ssa_v0_view
  const int64_t v255 = 1;
  // pto: %spmd_idx_accum_read__ssa_v0_view
  const int64_t v256 = 1;
  // pto: %spmd_idx_accum_read__ssa_v0_view
  int64_t v257 = (int64_t) v34;
  // pto: %spmd_idx_accum_read__ssa_v0_view
  int64_t v258 = v257 * v76;
  // pto: %spmd_idx_accum_read__ssa_v0_view
  int64_t v259 = v256 * v258;
  // pto: %spmd_idx_accum_read__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v260 = pto::Shape<1, 1, 1, -1, -1>(v254, v255, v256, v257, v76);
  // pto: %spmd_idx_accum_read__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v261 = pto::Stride<-1, -1, -1, -1, -1>(v255 * v259, v259, v258, v76, v70);
  // pto: %spmd_idx_accum_read__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v262 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v28, v260, v261);
  // pto: %indexer_raw__ssa_v0_view
  const int64_t v263 = 1;
  // pto: %indexer_raw__ssa_v0_view
  const int64_t v264 = 1;
  // pto: %indexer_raw__ssa_v0_view
  const int64_t v265 = 1;
  // pto: %indexer_raw__ssa_v0_view
  int64_t v266 = (int64_t) v32;
  // pto: %indexer_raw__ssa_v0_view
  int64_t v267 = v266 * v76;
  // pto: %indexer_raw__ssa_v0_view
  int64_t v268 = v265 * v267;
  // pto: %indexer_raw__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v269 = pto::Shape<1, 1, 1, -1, -1>(v263, v264, v265, v266, v76);
  // pto: %indexer_raw__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v270 = pto::Stride<-1, -1, -1, -1, -1>(v264 * v268, v268, v267, v76, v70);
  // pto: %indexer_raw__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v271 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v29, v269, v270);
  // pto: %indexer_scaled__ssa_v0_view
  const int64_t v272 = 1;
  // pto: %indexer_scaled__ssa_v0_view
  const int64_t v273 = 1;
  // pto: %indexer_scaled__ssa_v0_view
  const int64_t v274 = 1;
  // pto: %indexer_scaled__ssa_v0_view
  int64_t v275 = (int64_t) v32;
  // pto: %indexer_scaled__ssa_v0_view
  int64_t v276 = v275 * v76;
  // pto: %indexer_scaled__ssa_v0_view
  int64_t v277 = v274 * v276;
  // pto: %indexer_scaled__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v278 = pto::Shape<1, 1, 1, -1, -1>(v272, v273, v274, v275, v76);
  // pto: %indexer_scaled__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v279 = pto::Stride<-1, -1, -1, -1, -1>(v273 * v277, v277, v276, v76, v70);
  // pto: %indexer_scaled__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v280 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v30, v278, v279);
  // pto: %indexer_weights__ssa_v0_view
  const int64_t v281 = 1;
  // pto: %indexer_weights__ssa_v0_view
  const int64_t v282 = 1;
  // pto: %indexer_weights__ssa_v0_view
  const int64_t v283 = 1;
  // pto: %indexer_weights__ssa_v0_view
  int64_t v284 = (int64_t) v32;
  // pto: %indexer_weights__ssa_v0_view
  int64_t v285 = v284 * v76;
  // pto: %indexer_weights__ssa_v0_view
  int64_t v286 = v283 * v285;
  // pto: %indexer_weights__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v287 = pto::Shape<1, 1, 1, -1, -1>(v281, v282, v283, v284, v76);
  // pto: %indexer_weights__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v288 = pto::Stride<-1, -1, -1, -1, -1>(v282 * v286, v286, v285, v76, v70);
  // pto: %indexer_weights__ssa_v0_view
  GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v289 = GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v31, v287, v288);
  uint64_t v290 = reinterpret_cast<uint64_t>(v10);
  set_ffts_base_addr(v290);
  // pto: %t__tmp_v0, %90, %91, %t__tmp_v1
  int64_t v291 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v37) * (uint64_t) v80) + (uint64_t) ((int64_t) v39));
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  set_flag(PIPE_S, PIPE_V, EVENT_ID5);
  for (int64_t v292 = v291; v292 < v32; v292 += v81) {
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    for (int64_t v293 = v82; v293 < v73; v293 += v80) {
      // pto: %92
      ;
      int64_t v294 = (int64_t) ((uint64_t) v293 * (uint64_t) v75);
      // pto: %94
      ;
      int64_t v295 = (int64_t) ((uint64_t) v294 + (uint64_t) v75);
      // pto: %t__tile
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v296 = Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
      // pto: %t__tile
      ;
      uint64_t v297 = (uint64_t) v45;
      TASSIGN(v296, v297);
      // pto: %95
      ;
      int64_t v298 = v292 < v82 ? v82 : v292;
      // pto: %96
      ;
      int64_t v299 = v294 < v82 ? v82 : v294;
      // pto: %flat_hc__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v300 = PTOAS__GLOBAL_TENSOR_DATA(v145);
      // pto: %flat_hc__ssa_v0_pview
      ;
      const int64_t v301 = 0;
      // pto: %flat_hc__ssa_v0_pview
      ;
      const int64_t v302 = 16384;
      // pto: %flat_hc__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v303 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %flat_hc__ssa_v0_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v304 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %flat_hc__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v305 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v300 + (v301 + v298 * v302 + v299), v303, v304);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      TLOAD(v296, v305);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %0
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v306 = Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
      // pto: %0
      ;
      uint64_t v307 = (uint64_t) v46;
      TASSIGN(v306, v307);
      // pto: %98
      ;
      int64_t v308 = v295 < v82 ? v82 : v295;
      // pto: %99
      ;
      __gm__ bfloat16_t* v309 = PTOAS__GLOBAL_TENSOR_DATA(v145);
      // pto: %99
      ;
      const int64_t v310 = 0;
      // pto: %99
      ;
      const int64_t v311 = 16384;
      // pto: %99
      ;
      pto::Shape<1, 1, 1, 1, 512> v312 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %99
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v313 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %99
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v314 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v309 + (v310 + v298 * v311 + v308), v312, v313);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      TLOAD(v306, v314);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %value_inline777__tile
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
      // pto: %value_inline777__tile
      ;
      uint64_t v316 = (uint64_t) v47;
      TASSIGN(v315, v316);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      RoundMode v317 = RoundMode::CAST_ROUND;
      SaturationMode v318 = SaturationMode::ON;
      TCVT(v315, v296, v317, v318);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      // pto: %wide__iter_v3_pview
      ;
      __gm__ float* v319 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %wide__iter_v3_pview
      ;
      const int64_t v320 = 0;
      // pto: %wide__iter_v3_pview
      ;
      const int64_t v321 = 16384;
      // pto: %wide__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v322 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %wide__iter_v3_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v323 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %wide__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v324 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v319 + (v320 + v298 * v321 + v299), v322, v323);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v324, v315);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      // pto: %1
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v325 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
      // pto: %1
      ;
      uint64_t v326 = (uint64_t) v48;
      TASSIGN(v325, v326);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      RoundMode v327 = RoundMode::CAST_ROUND;
      SaturationMode v328 = SaturationMode::ON;
      TCVT(v325, v306, v327, v328);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      // pto: %wide__tile_pview
      ;
      __gm__ float* v329 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %wide__tile_pview
      ;
      const int64_t v330 = 0;
      // pto: %wide__tile_pview
      ;
      const int64_t v331 = 16384;
      // pto: %wide__tile_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v332 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %wide__tile_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v333 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %wide__tile_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v334 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v329 + (v330 + v298 * v331 + v308), v332, v333);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v334, v325);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    };
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %105
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  if (v32 >= v76) {
    // pto: %107
    ;
    const int64_t v335 = 1;
    // pto: %107
    ;
    const int64_t v336 = 0;
    // pto: %107
    ;
    int64_t v337 = v34 / v71;
    // pto: %107
    ;
    bool v338 = v34 < v336;
    // pto: %107
    ;
    bool v339 = v71 < v336;
    // pto: %107
    ;
    bool v340 = v338 == v339;
    // pto: %107
    ;
    bool v341 = v34 % v71 != v336 && v338 != v339;
    // pto: %107
    ;
    int64_t v342 = v341 ? v337 - v335 : v337;
    // pto: %108
    ;
    int64_t v343 = (int64_t) ((uint64_t) v342 * (uint64_t) v76);
    // pto: %109
    ;
    const int64_t v344 = 1;
    // pto: %109
    ;
    const int64_t v345 = 0;
    // pto: %109
    ;
    int64_t v346 = v343 / v77;
    // pto: %109
    ;
    bool v347 = v343 < v345;
    // pto: %109
    ;
    bool v348 = v77 < v345;
    // pto: %109
    ;
    bool v349 = v347 == v348;
    // pto: %109
    ;
    bool v350 = v343 % v77 != v345 && v347 != v348;
    // pto: %109
    ;
    for (int64_t v351 = v291; v351 < (v350 ? v346 - v344 : v346); v351 += v81) {
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      for (int64_t v352 = v82; v352 < v77; v352 += v70) {
        // pto: %110, %111
        ;
        int64_t v353 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v351 * (uint64_t) v77) + (uint64_t) v352);
        // pto: %112
        ;
        const int64_t v354 = 1;
        // pto: %112
        ;
        const int64_t v355 = 0;
        // pto: %112
        ;
        int64_t v356 = v353 / v76;
        // pto: %112
        ;
        bool v357 = v353 < v355;
        // pto: %112
        ;
        bool v358 = v76 < v355;
        // pto: %112
        ;
        bool v359 = v357 == v358;
        // pto: %112
        ;
        bool v360 = v353 % v76 != v355 && v357 != v358;
        // pto: %112
        ;
        int64_t v361 = v360 ? v356 - v354 : v356;
        // pto: %113
        ;
        int64_t v362 = (int64_t) ((uint64_t) v361 * (uint64_t) v71);
        // pto: %114
        ;
        int64_t v363 = v353 % v76;
        // pto: %115, %116, %117
        ;
        int64_t v364 = v363 < v82 ? (int64_t) ((uint64_t) v363 + (uint64_t) v76) : v363;
        // pto: %118
        ;
        int64_t v365 = (int64_t) ((uint64_t) v364 * (uint64_t) v83);
        // pto: %119
        ;
        int64_t v366 = (int64_t) ((uint64_t) v32 - (uint64_t) v362);
        // pto: %120
        ;
        int64_t v367 = v366 < v71 ? v366 : v71;
        // pto: %panel64_values_inline786__ssa_v0
        ;
        Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v368 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v367, v83);
        // pto: %panel64_values_inline786__ssa_v0
        ;
        uint64_t v369 = (uint64_t) v47;
        TASSIGN(v368, v369);
        // pto: %121
        ;
        int64_t v370 = v362 < v82 ? v82 : v362;
        // pto: %122
        ;
        int64_t v371 = v365 < v82 ? v82 : v365;
        // pto: %wide_v1__ssa_v0_pview
        ;
        const int64_t v372 = 0;
        // pto: %wide_v1__ssa_v0_pview
        ;
        __gm__ float* v373 = PTOAS__GLOBAL_TENSOR_DATA(v118);
        // pto: %wide_v1__ssa_v0_pview
        ;
        const int64_t v374 = 1;
        // pto: %wide_v1__ssa_v0_pview
        ;
        const int64_t v375 = 1;
        // pto: %wide_v1__ssa_v0_pview
        ;
        const int64_t v376 = 1;
        // pto: %wide_v1__ssa_v0_pview
        ;
        int64_t v377 = v367 * v69;
        // pto: %wide_v1__ssa_v0_pview
        ;
        int64_t v378 = v376 * v377;
        // pto: %wide_v1__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v379 = pto::Shape<1, 1, 1, -1, 256>(v374, v375, v376, v367, v83);
        // pto: %wide_v1__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v380 = pto::Stride<-1, -1, -1, -1, -1>(v375 * v378, v378, v377, v69, v70);
        // pto: %wide_v1__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v381 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v373 + (v372 + v370 * v69 + v371 * v70), v379, v380);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        TLOAD(v368, v381);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        set_flag(PIPE_MTE2, PIPE_S, EVENT_ID1);
        wait_flag(PIPE_MTE2, PIPE_S, EVENT_ID1);
        for (int64_t v382 = v367; v382 < v71; v382 += v70) {
          for (int64_t v383 = v82; v383 < v83; v383 += v70) {
            // pto: %flat_offset_mul, %flat_offset
            ;
            int64_t v384 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v382 * (uint64_t) v83) + (uint64_t) v383);
            v368.SetValue(v384, v84);
          };
        };
        set_flag(PIPE_S, PIPE_V, EVENT_ID1);
        v368.SetValidShape(v71, v83);
        // pto: %panel64_values_v2_inline790__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v385 = Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v83);
        // pto: %panel64_values_v2_inline790__ssa_v0
        ;
        uint64_t v386 = (uint64_t) v47;
        TASSIGN(v385, v386);
        wait_flag(PIPE_S, PIPE_V, EVENT_ID1);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v387 = RoundMode::CAST_ROUND;
        SaturationMode v388 = SaturationMode::ON;
        TCVT(v385, v368, v387, v388);
        // pto: %transpose_tmp
        ;
        Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v389 = Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v83);
        // pto: %transpose_tmp
        ;
        uint64_t v390 = (uint64_t) v48;
        TASSIGN(v389, v390);
        // pto: %panel64_transposed_values_inline791__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v391 = Tile<TileType::Vec, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v71);
        // pto: %panel64_transposed_values_inline791__ssa_v0
        ;
        uint64_t v392 = (uint64_t) v45;
        TASSIGN(v391, v392);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
        TTRANS(v391, v385, v389);
        // pto: %panel64_packed_transposed_inline792__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v393 = Tile<TileType::Vec, bfloat16_t, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v75, v71);
        // pto: %panel64_packed_transposed_inline792__ssa_v0
        ;
        uint64_t v394 = (uint64_t) v47;
        TASSIGN(v393, v394);
        pipe_barrier(PIPE_V);
        TEXPANDS(v393, v85);
        for (int64_t v395 = v82; v395 < v73; v395 += v70) {
          // pto: %panel64_input8_inline794__ssa_v0
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v396 = Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v71);
          // pto: %panel64_input8_inline794__ssa_v0
          ;
          uint64_t v397 = (uint64_t) v45;
          TASSIGN(v396, v397);
          // pto: %slice_view
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v398;
          // pto: %127, %slice_view
          ;
          uint64_t v399 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v395 * (uint64_t) v79) * (uint64_t) v50) + (uint64_t) v45);
          TASSIGN(v398, v399);
          // pto: %128
          ;
          int64_t v400 = (int64_t) ((uint64_t) v395 * (uint64_t) v71);
          // pto: %assemble_view
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v401;
          // pto: %assemble_view
          ;
          uint64_t v402 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v400 * (uint64_t) v50) + (uint64_t) v47);
          TASSIGN(v401, v402);
          pipe_barrier(PIPE_V);
          TMOV(v401, v398);
          // pto: %131
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v403;
          // pto: %130, %131
          ;
          uint64_t v404 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v400 + (uint64_t) v79) * (uint64_t) v50) + (uint64_t) v47);
          TASSIGN(v403, v404);
          pipe_barrier(PIPE_V);
          TMOV(v403, v398);
        };
        // pto: %2
        ;
        Tile<TileType::Vec, bfloat16_t, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v405 = Tile<TileType::Vec, bfloat16_t, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v75, v71);
        // pto: %2
        ;
        uint64_t v406 = (uint64_t) v48;
        TASSIGN(v405, v406);
        // pto: %panel64_packed_values_inline795__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v407 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v75);
        // pto: %panel64_packed_values_inline795__ssa_v0
        ;
        uint64_t v408 = (uint64_t) v45;
        TASSIGN(v407, v408);
        pipe_barrier(PIPE_V);
        TTRANS(v407, v393, v405);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        int64_t v409 = (int64_t) ((uint64_t) v364 * (uint64_t) v75);
        // pto: %134
        ;
        int64_t v410 = v409 < v82 ? v82 : v409;
        // pto: %packed_flat__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v411 = PTOAS__GLOBAL_TENSOR_DATA(v127);
        // pto: %packed_flat__ssa_v0_pview
        ;
        const int64_t v412 = 0;
        // pto: %packed_flat__ssa_v0_pview
        ;
        const int64_t v413 = 32768;
        // pto: %packed_flat__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 16, 512> v414 = pto::Shape<1, 1, 1, 16, 512>();
        // pto: %packed_flat__ssa_v0_pview
        ;
        pto::Stride<524288, 524288, 524288, 32768, 1> v415 = pto::Stride<524288, 524288, 524288, 32768, 1>();
        // pto: %packed_flat__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND> v416 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND>(v411 + (v412 + v370 * v413 + v410), v414, v415);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        TSTORE(v416, v407);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      };
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    };
  } else {
    // pto: %136
    ;
    const int64_t v417 = 1;
    // pto: %136
    ;
    const int64_t v418 = 0;
    // pto: %136
    ;
    int64_t v419 = v34 / v71;
    // pto: %136
    ;
    bool v420 = v34 < v418;
    // pto: %136
    ;
    bool v421 = v71 < v418;
    // pto: %136
    ;
    bool v422 = v420 == v421;
    // pto: %136
    ;
    bool v423 = v34 % v71 != v418 && v420 != v421;
    // pto: %136
    ;
    int64_t v424 = v423 ? v419 - v417 : v419;
    // pto: %137
    ;
    for (int64_t v425 = v291; v425 < ((int64_t) ((uint64_t) v424 * (uint64_t) v76)); v425 += v81) {
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      // pto: %141
      ;
      const int64_t v426 = 1;
      // pto: %141
      ;
      const int64_t v427 = 0;
      // pto: %141
      ;
      int64_t v428 = v425 / v76;
      // pto: %141
      ;
      bool v429 = v425 < v427;
      // pto: %141
      ;
      bool v430 = v76 < v427;
      // pto: %141
      ;
      bool v431 = v429 == v430;
      // pto: %141
      ;
      bool v432 = v425 % v76 != v427 && v429 != v430;
      // pto: %141
      ;
      int64_t v433 = v432 ? v428 - v426 : v428;
      // pto: %142
      ;
      int64_t v434 = (int64_t) ((uint64_t) v433 * (uint64_t) v71);
      // pto: %143
      ;
      int64_t v435 = v425 % v76;
      // pto: %144, %145, %146
      ;
      int64_t v436 = v435 < v82 ? (int64_t) ((uint64_t) v435 + (uint64_t) v76) : v435;
      // pto: %147
      ;
      int64_t v437 = (int64_t) ((uint64_t) v436 * (uint64_t) v83);
      // pto: %148
      ;
      int64_t v438 = (int64_t) ((uint64_t) v32 - (uint64_t) v434);
      // pto: %149
      ;
      int64_t v439 = v438 < v71 ? v438 : v71;
      // pto: %panel64_values_inline804__ssa_v0
      ;
      Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v440 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v439, v83);
      // pto: %panel64_values_inline804__ssa_v0
      ;
      uint64_t v441 = (uint64_t) v47;
      TASSIGN(v440, v441);
      // pto: %150
      ;
      int64_t v442 = v434 < v82 ? v82 : v434;
      // pto: %151
      ;
      int64_t v443 = v437 < v82 ? v82 : v437;
      // pto: %154
      ;
      const int64_t v444 = 0;
      // pto: %154
      ;
      __gm__ float* v445 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %154
      ;
      const int64_t v446 = 1;
      // pto: %154
      ;
      const int64_t v447 = 1;
      // pto: %154
      ;
      const int64_t v448 = 1;
      // pto: %154
      ;
      int64_t v449 = v439 * v69;
      // pto: %154
      ;
      int64_t v450 = v448 * v449;
      // pto: %154
      ;
      pto::Shape<1, 1, 1, -1, 256> v451 = pto::Shape<1, 1, 1, -1, 256>(v446, v447, v448, v439, v83);
      // pto: %154
      ;
      pto::Stride<-1, -1, -1, -1, -1> v452 = pto::Stride<-1, -1, -1, -1, -1>(v447 * v450, v450, v449, v69, v70);
      // pto: %154
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v453 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v445 + (v444 + v442 * v69 + v443 * v70), v451, v452);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      TLOAD(v440, v453);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      set_flag(PIPE_MTE2, PIPE_S, EVENT_ID2);
      wait_flag(PIPE_MTE2, PIPE_S, EVENT_ID2);
      for (int64_t v454 = v439; v454 < v71; v454 += v70) {
        for (int64_t v455 = v82; v455 < v83; v455 += v70) {
          // pto: %157, %158
          ;
          int64_t v456 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v454 * (uint64_t) v83) + (uint64_t) v455);
          v440.SetValue(v456, v84);
        };
      };
      set_flag(PIPE_S, PIPE_V, EVENT_ID2);
      v440.SetValidShape(v71, v83);
      // pto: %3
      ;
      Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v457 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v83);
      // pto: %3
      ;
      uint64_t v458 = (uint64_t) v48;
      TASSIGN(v457, v458);
      // pto: %panel64_transposed_values_inline808__ssa_v0
      ;
      Tile<TileType::Vec, float, 256, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v459 = Tile<TileType::Vec, float, 256, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v71);
      // pto: %panel64_transposed_values_inline808__ssa_v0
      ;
      uint64_t v460 = (uint64_t) v45;
      TASSIGN(v459, v460);
      wait_flag(PIPE_S, PIPE_V, EVENT_ID2);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      TTRANS(v459, v440, v457);
      // pto: %panel64_packed_transposed_inline809__ssa_v0
      ;
      Tile<TileType::Vec, float, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v461 = Tile<TileType::Vec, float, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v75, v71);
      // pto: %panel64_packed_transposed_inline809__ssa_v0
      ;
      uint64_t v462 = (uint64_t) v47;
      TASSIGN(v461, v462);
      pipe_barrier(PIPE_V);
      TEXPANDS(v461, v84);
      for (int64_t v463 = v82; v463 < v73; v463 += v70) {
        // pto: %panel64_input8_inline811__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v464 = Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v71);
        // pto: %panel64_input8_inline811__ssa_v0
        ;
        uint64_t v465 = (uint64_t) v45;
        TASSIGN(v464, v465);
        // pto: %160
        ;
        Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v466;
        // pto: %159, %160
        ;
        uint64_t v467 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v463 * (uint64_t) v79) * (uint64_t) v51) + (uint64_t) v45);
        TASSIGN(v466, v467);
        // pto: %161
        ;
        int64_t v468 = (int64_t) ((uint64_t) v463 * (uint64_t) v71);
        // pto: %162
        ;
        Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v469;
        // pto: %162
        ;
        uint64_t v470 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v468 * (uint64_t) v51) + (uint64_t) v47);
        TASSIGN(v469, v470);
        pipe_barrier(PIPE_V);
        TMOV(v469, v466);
        // pto: %165
        ;
        Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v471;
        // pto: %164, %165
        ;
        uint64_t v472 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v468 + (uint64_t) v79) * (uint64_t) v51) + (uint64_t) v47);
        TASSIGN(v471, v472);
        pipe_barrier(PIPE_V);
        TMOV(v471, v466);
      };
      // pto: %4
      ;
      Tile<TileType::Vec, float, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v473 = Tile<TileType::Vec, float, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v75, v71);
      // pto: %4
      ;
      uint64_t v474 = (uint64_t) v48;
      TASSIGN(v473, v474);
      // pto: %panel64_packed_values_inline812__ssa_v0
      ;
      Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v475 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v75);
      // pto: %panel64_packed_values_inline812__ssa_v0
      ;
      uint64_t v476 = (uint64_t) v45;
      TASSIGN(v475, v476);
      pipe_barrier(PIPE_V);
      TTRANS(v475, v461, v473);
      // pto: %t__tmp_v4
      ;
      Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v477 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v75);
      // pto: %t__tmp_v4
      ;
      uint64_t v478 = (uint64_t) v47;
      TASSIGN(v477, v478);
      pipe_barrier(PIPE_V);
      RoundMode v479 = RoundMode::CAST_ROUND;
      SaturationMode v480 = SaturationMode::ON;
      TCVT(v477, v475, v479, v480);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      int64_t v481 = (int64_t) ((uint64_t) v436 * (uint64_t) v75);
      // pto: %168
      ;
      int64_t v482 = v481 < v82 ? v82 : v481;
      // pto: %169
      ;
      __gm__ bfloat16_t* v483 = PTOAS__GLOBAL_TENSOR_DATA(v127);
      // pto: %169
      ;
      const int64_t v484 = 0;
      // pto: %169
      ;
      const int64_t v485 = 32768;
      // pto: %169
      ;
      pto::Shape<1, 1, 1, 16, 512> v486 = pto::Shape<1, 1, 1, 16, 512>();
      // pto: %169
      ;
      pto::Stride<524288, 524288, 524288, 32768, 1> v487 = pto::Stride<524288, 524288, 524288, 32768, 1>();
      // pto: %169
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND> v488 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND>(v483 + (v484 + v442 * v485 + v482), v486, v487);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      TSTORE(v488, v477);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    };
  }
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %170
  int64_t v489 = (int64_t) ((uint64_t) v36 - (uint64_t) v79);
  // pto: %171
  int64_t v490 = (int64_t) ((uint64_t) v32 + (uint64_t) v86);
  // pto: %172
  const int64_t v491 = 1;
  // pto: %172
  const int64_t v492 = 0;
  // pto: %172
  int64_t v493 = v490 / v79;
  // pto: %172
  bool v494 = v490 < v492;
  // pto: %172
  bool v495 = v79 < v492;
  // pto: %172
  bool v496 = v494 == v495;
  // pto: %172
  bool v497 = v490 % v79 != v492 && v494 != v495;
  // pto: %172
  int64_t v498 = v497 ? v493 - v491 : v493;
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  for (int64_t v499 = v291; v499 < v498; v499 += v81) {
    // pto: %173
    ;
    int64_t v500 = (int64_t) ((uint64_t) v499 * (uint64_t) v79);
    // pto: %rms_lanes_inline818__ci_tmp_v0
    ;
    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v501 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v87);
    // pto: %rms_lanes_inline818__ci_tmp_v0
    ;
    uint64_t v502 = (uint64_t) v47;
    TASSIGN(v501, v502);
    // pto: %rms_lanes_inline818__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v503 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_lanes_inline818__tile
    ;
    uint64_t v504 = (uint64_t) v48;
    TASSIGN(v503, v504);
    // pto: %ci_tmp_view
    ;
    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v505;
    TRESHAPE(v505, v501);
    // pto: %ci_dst_view
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v506;
    TRESHAPE(v506, v503);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    TCI<Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v506, v88, v505);
    // pto: %rms_rows_inline819__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v507 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_rows_inline819__tile
    ;
    uint64_t v508 = (uint64_t) v47;
    TASSIGN(v507, v508);
    // pto: %174
    ;
    int32_t v509 = (int32_t) v500;
    pipe_barrier(PIPE_V);
    TADDS(v507, v503, v509);
    // pto: %rms_local_inline820__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v510 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_local_inline820__tile
    ;
    uint64_t v511 = (uint64_t) v48;
    TASSIGN(v510, v511);
    // pto: %175
    ;
    int64_t v512 = v500 % v71;
    // pto: %176, %177, %178
    ;
    int64_t v513 = v512 < v82 ? (int64_t) ((uint64_t) v512 + (uint64_t) v71) : v512;
    // pto: %179
    ;
    int32_t v514 = (int32_t) v513;
    pipe_barrier(PIPE_V);
    TADDS(v510, v503, v514);
    // pto: %5
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v515 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %5
    ;
    uint64_t v516 = (uint64_t) v47;
    TASSIGN(v515, v516);
    TMULS(v515, v507, v89);
    // pto: %rms_index_inline821__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v517 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_index_inline821__tile
    ;
    uint64_t v518 = (uint64_t) v47;
    TASSIGN(v517, v518);
    pipe_barrier(PIPE_V);
    TADD(v517, v515, v510);
    set_flag(PIPE_V, PIPE_S, EVENT_ID1);
    // pto: %rms_total_inline822__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v519 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_total_inline822__tile
    ;
    uint64_t v520 = (uint64_t) v48;
    TASSIGN(v519, v520);
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    const int64_t v521 = 0;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    __gm__ float* v522 = PTOAS__GLOBAL_TENSOR_DATA(v154);
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    const int64_t v523 = 1;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    const int64_t v524 = 1;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    const int64_t v525 = 1;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    int64_t v526 = (int64_t) v33;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    int64_t v527 = v526 * v71;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    int64_t v528 = v525 * v527;
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 16> v529 = pto::Shape<1, 1, 1, -1, 16>(v523, v524, v525, v526, v71);
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v530 = pto::Stride<-1, -1, -1, -1, -1>(v524 * v528, v528, v527, v71, v70);
    // pto: %spmd_square_read__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v531 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v522 + (v521 + v82 * v71 + v82 * v70), v529, v530);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID1);
    MGATHER<pto::Coalesce::Elem>(v519, v531, v517);
    set_flag(PIPE_S, PIPE_V, EVENT_ID4);
    for (int64_t v532 = v70; v532 < v90; v532 += v70) {
      // pto: %rms_part_index_inline824__tile
      ;
      Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v533 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %rms_part_index_inline824__tile
      ;
      uint64_t v534 = (uint64_t) v45;
      TASSIGN(v533, v534);
      // pto: %180, %181, %182
      ;
      int32_t v535 = (int32_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v532 * (uint64_t) v489) * (uint64_t) v71);
      pipe_barrier(PIPE_V);
      TADDS(v533, v517, v535);
      set_flag(PIPE_V, PIPE_S, EVENT_ID2);
      // pto: %rms_value_inline825__tile
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v536 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %rms_value_inline825__tile
      ;
      uint64_t v537 = (uint64_t) v46;
      TASSIGN(v536, v537);
      wait_flag(PIPE_V, PIPE_S, EVENT_ID2);
      MGATHER<pto::Coalesce::Elem>(v536, v531, v533);
      set_flag(PIPE_S, PIPE_V, EVENT_ID3);
      // pto: %6
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v538 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %6
      ;
      uint64_t v539 = (uint64_t) v48;
      TASSIGN(v538, v539);
      wait_flag(PIPE_S, PIPE_V, EVENT_ID3);
      TADD(v538, v519, v536);
    };
    // pto: %7
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v540 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %7
    ;
    uint64_t v541 = (uint64_t) v47;
    TASSIGN(v540, v541);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID4);
    TMULS(v540, v519, v91);
    // pto: %rms_variance_inline826__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v542 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_variance_inline826__tile
    ;
    uint64_t v543 = (uint64_t) v47;
    TASSIGN(v542, v543);
    pipe_barrier(PIPE_V);
    TADDS(v542, v540, v92);
    // pto: %rms_root_inline827__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v544 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_root_inline827__tile
    ;
    uint64_t v545 = (uint64_t) v47;
    TASSIGN(v544, v545);
    pipe_barrier(PIPE_V);
    TSQRT(v544, v542);
    // pto: %8
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v546 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %8
    ;
    uint64_t v547 = (uint64_t) v48;
    TASSIGN(v546, v547);
    TEXPANDS(v546, v93);
    // pto: %native_inverse_inline828__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v548 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %native_inverse_inline828__tile
    ;
    uint64_t v549 = (uint64_t) v47;
    TASSIGN(v548, v549);
    pipe_barrier(PIPE_V);
    TDIV(v548, v546, v544);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
    // pto: %184
    ;
    int64_t v550 = v500 < v82 ? v82 : v500;
    // pto: %vec_ws__iter_v1_pview
    ;
    __gm__ float* v551 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %vec_ws__iter_v1_pview
    ;
    const int64_t v552 = 40;
    // pto: %vec_ws__iter_v1_pview
    ;
    const int64_t v553 = 64;
    // pto: %vec_ws__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v554 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %vec_ws__iter_v1_pview
    ;
    pto::Stride<64, 64, 64, 64, 1> v555 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %vec_ws__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v556 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v551 + (v552 + v550 * v553), v554, v555);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
    TSTORE(v556, v548);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %186
  const int64_t v557 = 1;
  // pto: %186
  const int64_t v558 = 0;
  // pto: %186
  int64_t v559 = v489 / v71;
  // pto: %186
  bool v560 = v489 < v558;
  // pto: %186
  bool v561 = v71 < v558;
  // pto: %186
  bool v562 = v560 == v561;
  // pto: %186
  bool v563 = v489 % v71 != v558 && v560 != v561;
  // pto: %186
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  for (int64_t v564 = v291; v564 < (v563 ? v559 - v557 : v559); v564 += v81) {
    // pto: %187
    ;
    int64_t v565 = (int64_t) ((uint64_t) v564 * (uint64_t) v71);
    // pto: %mixes_total_inline832__tile
    ;
    Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v566 = Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v73);
    // pto: %mixes_total_inline832__tile
    ;
    uint64_t v567 = (uint64_t) v47;
    TASSIGN(v566, v567);
    // pto: %188
    ;
    int64_t v568 = v565 < v82 ? v82 : v565;
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    __gm__ float* v569 = PTOAS__GLOBAL_TENSOR_DATA(v172);
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    const int64_t v570 = 0;
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    const int64_t v571 = 32;
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 16, 32> v572 = pto::Shape<1, 1, 1, 16, 32>();
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    pto::Stride<512, 512, 512, 32, 1> v573 = pto::Stride<512, 512, 512, 32, 1>();
    // pto: %spmd_linear_read__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND> v574 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND>(v569 + (v570 + v568 * v571), v572, v573);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
    TLOAD(v566, v574);
    set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    for (int64_t v575 = v70; v575 < v90; v575 += v70) {
      // pto: %189, %190
      ;
      int64_t v576 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v575 * (uint64_t) v489) + (uint64_t) v565);
      // pto: %partial_tile_inline835__tile
      ;
      Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v577 = Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v73);
      // pto: %partial_tile_inline835__tile
      ;
      uint64_t v578 = (uint64_t) v48;
      TASSIGN(v577, v578);
      // pto: %191
      ;
      int64_t v579 = v576 < v82 ? v82 : v576;
      // pto: %192
      ;
      __gm__ float* v580 = PTOAS__GLOBAL_TENSOR_DATA(v172);
      // pto: %192
      ;
      const int64_t v581 = 0;
      // pto: %192
      ;
      const int64_t v582 = 32;
      // pto: %192
      ;
      pto::Shape<1, 1, 1, 16, 32> v583 = pto::Shape<1, 1, 1, 16, 32>();
      // pto: %192
      ;
      pto::Stride<512, 512, 512, 32, 1> v584 = pto::Stride<512, 512, 512, 32, 1>();
      // pto: %192
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND> v585 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND>(v580 + (v581 + v579 * v582), v583, v584);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      TLOAD(v577, v585);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      // pto: %9
      ;
      Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v586 = Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v73);
      // pto: %9
      ;
      uint64_t v587 = (uint64_t) v47;
      TASSIGN(v586, v587);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      TADD(v586, v566, v577);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    };
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    __gm__ float* v588 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    const int64_t v589 = 0;
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    const int64_t v590 = 64;
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 32> v591 = pto::Shape<1, 1, 1, 16, 32>();
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    pto::Stride<1024, 1024, 1024, 64, 1> v592 = pto::Stride<1024, 1024, 1024, 64, 1>();
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<1024, 1024, 1024, 64, 1>, pto::Layout::ND> v593 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<1024, 1024, 1024, 64, 1>, pto::Layout::ND>(v588 + (v589 + v568 * v590), v591, v592);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
    wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    TSTORE(v593, v566);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %scale0_inline838__tile
  float v594 = (v18)[v82];
  // pto: %scale1_inline839__tile
  float v595 = (v18)[v70];
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  for (int64_t v596 = v291; v596 < v498; v596 += v81) {
    // pto: %196
    ;
    int64_t v597 = (int64_t) ((uint64_t) v596 * (uint64_t) v79);
    // pto: %197
    ;
    int64_t v598 = (int64_t) ((uint64_t) v32 - (uint64_t) v597);
    // pto: %198
    ;
    int64_t v599 = v598 < v79 ? v598 : v79;
    // pto: %t__tmp_v10
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v600 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %t__tmp_v10
    ;
    uint64_t v601 = (uint64_t) v45;
    TASSIGN(v600, v601);
    // pto: %199
    ;
    int64_t v602 = v597 < v82 ? v82 : v597;
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    __gm__ float* v603 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    const int64_t v604 = 40;
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    const int64_t v605 = 64;
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v606 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    pto::Stride<64, 64, 64, 64, 1> v607 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v608 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v603 + (v604 + v602 * v605), v606, v607);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    TLOAD(v600, v608);
    // pto: %inv_col_inline843__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v609 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %inv_col_inline843__ssa_v0
    ;
    uint64_t v610 = (uint64_t) v45;
    TASSIGN(v609, v610);
    // pto: %t__tmp_v11
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v611 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %t__tmp_v11
    ;
    uint64_t v612 = (uint64_t) v46;
    TASSIGN(v611, v612);
    // pto: %hc_attn_base__ssa_v0_pview
    ;
    __gm__ float* v613 = PTOAS__GLOBAL_TENSOR_DATA(v182);
    // pto: %hc_attn_base__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v614 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %hc_attn_base__ssa_v0_pview
    ;
    pto::Stride<8, 8, 8, 8, 1> v615 = pto::Stride<8, 8, 8, 8, 1>();
    // pto: %hc_attn_base__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND> v616 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND>(v613, v614, v615);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    TLOAD(v611, v616);
    // pto: %pre_base_inline844__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v617 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %pre_base_inline844__ssa_v0
    ;
    uint64_t v618 = (uint64_t) v46;
    TASSIGN(v617, v618);
    // pto: %t__tmp_v12
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v619 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v12
    ;
    uint64_t v620 = (uint64_t) v47;
    TASSIGN(v619, v620);
    // pto: %201
    ;
    __gm__ float* v621 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %201
    ;
    const int64_t v622 = 0;
    // pto: %201
    ;
    const int64_t v623 = 64;
    // pto: %201
    ;
    pto::Shape<1, 1, 1, 8, 8> v624 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %201
    ;
    pto::Stride<512, 512, 512, 64, 1> v625 = pto::Stride<512, 512, 512, 64, 1>();
    // pto: %201
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v626 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v621 + (v622 + v602 * v623), v624, v625);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    TLOAD(v619, v626);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    // pto: %t__tmp_v13
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v627 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v13
    ;
    uint64_t v628 = (uint64_t) v47;
    TASSIGN(v627, v628);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    TROWEXPANDMUL(v627, v619, v609);
    // pto: %pre_scaled_inline845__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v629 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %pre_scaled_inline845__ssa_v0
    ;
    uint64_t v630 = (uint64_t) v47;
    TASSIGN(v629, v630);
    pipe_barrier(PIPE_V);
    TMULS(v629, v627, v594);
    // pto: %t__tmp_v14
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v631 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v14
    ;
    uint64_t v632 = (uint64_t) v48;
    TASSIGN(v631, v632);
    TCOLEXPAND(v631, v617);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %pre_logits_inline846__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v633 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %pre_logits_inline846__ssa_v0
    ;
    uint64_t v634 = (uint64_t) v47;
    TASSIGN(v633, v634);
    pipe_barrier(PIPE_V);
    TADD(v633, v629, v631);
    // pto: %t__tmp_v15
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v635 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v15
    ;
    uint64_t v636 = (uint64_t) v48;
    TASSIGN(v635, v636);
    pipe_barrier(PIPE_V);
    TEXPANDS(v635, v93);
    // pto: %t__tmp_v16
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v637 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v16
    ;
    uint64_t v638 = (uint64_t) v47;
    TASSIGN(v637, v638);
    TNEG(v637, v633);
    // pto: %t__tmp_v17
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v639 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v17
    ;
    uint64_t v640 = (uint64_t) v47;
    TASSIGN(v639, v640);
    pipe_barrier(PIPE_V);
    TEXP(v639, v637);
    // pto: %t__tmp_v18
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v641 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v18
    ;
    uint64_t v642 = (uint64_t) v47;
    TASSIGN(v641, v642);
    pipe_barrier(PIPE_V);
    TADDS(v641, v639, v93);
    // pto: %pre_sig_inline847__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v643 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %pre_sig_inline847__ssa_v0
    ;
    uint64_t v644 = (uint64_t) v47;
    TASSIGN(v643, v644);
    pipe_barrier(PIPE_V);
    TDIV(v643, v635, v641);
    // pto: %pre_val_inline848__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v645 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %pre_val_inline848__ssa_v0
    ;
    uint64_t v646 = (uint64_t) v47;
    TASSIGN(v645, v646);
    pipe_barrier(PIPE_V);
    TADDS(v645, v643, v92);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
    // pto: %203
    ;
    __gm__ float* v647 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %203
    ;
    const int64_t v648 = 32;
    // pto: %203
    ;
    const int64_t v649 = 64;
    // pto: %203
    ;
    pto::Shape<1, 1, 1, 8, 8> v650 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %203
    ;
    pto::Stride<512, 512, 512, 64, 1> v651 = pto::Stride<512, 512, 512, 64, 1>();
    // pto: %203
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v652 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v647 + (v648 + v602 * v649), v650, v651);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
    TSTORE(v652, v645);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    // pto: %t__tmp_v19
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v653 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %t__tmp_v19
    ;
    uint64_t v654 = (uint64_t) v46;
    TASSIGN(v653, v654);
    // pto: %204
    ;
    __gm__ float* v655 = PTOAS__GLOBAL_TENSOR_DATA(v182);
    // pto: %204
    ;
    unsigned v656 = 4;
    // pto: %204
    ;
    pto::Shape<1, 1, 1, 1, 8> v657 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %204
    ;
    pto::Stride<8, 8, 8, 8, 1> v658 = pto::Stride<8, 8, 8, 8, 1>();
    // pto: %204
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND> v659 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND>(v655 + v656, v657, v658);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v653, v659);
    // pto: %post_base_inline849__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v660 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %post_base_inline849__ssa_v0
    ;
    uint64_t v661 = (uint64_t) v46;
    TASSIGN(v660, v661);
    // pto: %t__tmp_v20
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v662 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v20
    ;
    uint64_t v663 = (uint64_t) v47;
    TASSIGN(v662, v663);
    // pto: %206
    ;
    __gm__ float* v664 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %206
    ;
    const int64_t v665 = 4;
    // pto: %206
    ;
    const int64_t v666 = 64;
    // pto: %206
    ;
    pto::Shape<1, 1, 1, 8, 8> v667 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %206
    ;
    pto::Stride<512, 512, 512, 64, 1> v668 = pto::Stride<512, 512, 512, 64, 1>();
    // pto: %206
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v669 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v664 + (v665 + v602 * v666), v667, v668);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    TLOAD(v662, v669);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
    // pto: %t__tmp_v21
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v670 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v21
    ;
    uint64_t v671 = (uint64_t) v47;
    TASSIGN(v670, v671);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
    TROWEXPANDMUL(v670, v662, v609);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    // pto: %post_scaled_inline850__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v672 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %post_scaled_inline850__ssa_v0
    ;
    uint64_t v673 = (uint64_t) v47;
    TASSIGN(v672, v673);
    pipe_barrier(PIPE_V);
    TMULS(v672, v670, v595);
    // pto: %t__tmp_v22
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v674 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v22
    ;
    uint64_t v675 = (uint64_t) v48;
    TASSIGN(v674, v675);
    TCOLEXPAND(v674, v660);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    // pto: %post_logits_inline851__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v676 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %post_logits_inline851__ssa_v0
    ;
    uint64_t v677 = (uint64_t) v47;
    TASSIGN(v676, v677);
    pipe_barrier(PIPE_V);
    TADD(v676, v672, v674);
    // pto: %t__tmp_v23
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v678 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v23
    ;
    uint64_t v679 = (uint64_t) v48;
    TASSIGN(v678, v679);
    pipe_barrier(PIPE_V);
    TEXPANDS(v678, v93);
    // pto: %t__tmp_v24
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v680 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v24
    ;
    uint64_t v681 = (uint64_t) v47;
    TASSIGN(v680, v681);
    TNEG(v680, v676);
    // pto: %t__tmp_v25
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v682 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v25
    ;
    uint64_t v683 = (uint64_t) v47;
    TASSIGN(v682, v683);
    pipe_barrier(PIPE_V);
    TEXP(v682, v680);
    // pto: %t__tmp_v26
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v684 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v26
    ;
    uint64_t v685 = (uint64_t) v47;
    TASSIGN(v684, v685);
    pipe_barrier(PIPE_V);
    TADDS(v684, v682, v93);
    // pto: %post_sig_inline852__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v686 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %post_sig_inline852__ssa_v0
    ;
    uint64_t v687 = (uint64_t) v47;
    TASSIGN(v686, v687);
    pipe_barrier(PIPE_V);
    TDIV(v686, v678, v684);
    // pto: %post_pad_inline853__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v688 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %post_pad_inline853__ssa_v0
    ;
    uint64_t v689 = (uint64_t) v47;
    TASSIGN(v688, v689);
    pipe_barrier(PIPE_V);
    TMULS(v688, v686, v94);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
    // pto: %207
    ;
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    if (v599 == v79) {
      // pto: %t__tmp_v27
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v690 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v77);
      // pto: %t__tmp_v27
      ;
      uint64_t v691 = (uint64_t) v47;
      TASSIGN(v690, v691);
      // pto: %208
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, 8, 4, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v692;
      // pto: %208
      ;
      uint64_t v693 = (uint64_t) v47;
      TASSIGN(v692, v693);
      // pto: %post__ssa_v0_pview
      ;
      __gm__ float* v694 = PTOAS__GLOBAL_TENSOR_DATA(v199);
      // pto: %post__ssa_v0_pview
      ;
      const int64_t v695 = 0;
      // pto: %post__ssa_v0_pview
      ;
      const int64_t v696 = 4;
      // pto: %post__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 4> v697 = pto::Shape<1, 1, 1, 8, 4>();
      // pto: %post__ssa_v0_pview
      ;
      pto::Stride<32, 32, 32, 4, 1> v698 = pto::Stride<32, 32, 32, 4, 1>();
      // pto: %post__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<32, 32, 32, 4, 1>, pto::Layout::ND> v699 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<32, 32, 32, 4, 1>, pto::Layout::ND>(v694 + (v695 + v602 * v696), v697, v698);
      TSTORE(v699, v692);
    } else {
      // pto: %211
      ;
      int64_t v700 = v489 < v82 ? v82 : v489;
      // pto: %212
      ;
      __gm__ float* v701 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %212
      ;
      const int64_t v702 = 0;
      // pto: %212
      ;
      const int64_t v703 = 64;
      // pto: %212
      ;
      pto::Shape<1, 1, 1, 8, 8> v704 = pto::Shape<1, 1, 1, 8, 8>();
      // pto: %212
      ;
      pto::Stride<512, 512, 512, 64, 1> v705 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %212
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v706 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v701 + (v702 + v700 * v703), v704, v705);
      TSTORE(v706, v688);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      // pto: %post_tile_inline854__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v707 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v599, v77);
      // pto: %post_tile_inline854__ssa_v0
      ;
      uint64_t v708 = (uint64_t) v47;
      TASSIGN(v707, v708);
      // pto: %215
      ;
      const int64_t v709 = 0;
      // pto: %215
      ;
      __gm__ float* v710 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %215
      ;
      const int64_t v711 = 1;
      // pto: %215
      ;
      const int64_t v712 = 1;
      // pto: %215
      ;
      const int64_t v713 = 1;
      // pto: %215
      ;
      int64_t v714 = v599 * v76;
      // pto: %215
      ;
      int64_t v715 = v713 * v714;
      // pto: %215
      ;
      pto::Shape<1, 1, 1, -1, 4> v716 = pto::Shape<1, 1, 1, -1, 4>(v711, v712, v713, v599, v77);
      // pto: %215
      ;
      pto::Stride<-1, -1, -1, -1, -1> v717 = pto::Stride<-1, -1, -1, -1, -1>(v712 * v715, v715, v714, v76, v70);
      // pto: %215
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v718 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v710 + (v709 + v700 * v76 + v82 * v70), v716, v717);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      TLOAD(v707, v718);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
      // pto: %217
      ;
      const int64_t v719 = 0;
      // pto: %217
      ;
      __gm__ float* v720 = PTOAS__GLOBAL_TENSOR_DATA(v199);
      // pto: %217
      ;
      const int64_t v721 = 1;
      // pto: %217
      ;
      const int64_t v722 = 1;
      // pto: %217
      ;
      const int64_t v723 = 1;
      // pto: %217
      ;
      int64_t v724 = v599 * v77;
      // pto: %217
      ;
      int64_t v725 = v723 * v724;
      // pto: %217
      ;
      pto::Shape<1, 1, 1, -1, 4> v726 = pto::Shape<1, 1, 1, -1, 4>(v721, v722, v723, v599, v77);
      // pto: %217
      ;
      pto::Stride<-1, -1, -1, -1, -1> v727 = pto::Stride<-1, -1, -1, -1, -1>(v722 * v725, v725, v724, v77, v70);
      // pto: %217
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v728 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v720 + (v719 + v602 * v77 + v82 * v70), v726, v727);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
      TSTORE(v728, v707);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v729 = v291; v729 < v498; v729 += v81) {
    // pto: %220
    ;
    int64_t v730 = (int64_t) ((uint64_t) v729 * (uint64_t) v79);
    // pto: %221
    ;
    int64_t v731 = (int64_t) ((uint64_t) v32 - (uint64_t) v730);
    // pto: %222
    ;
    int64_t v732 = v731 < v79 ? v731 : v79;
    // pto: %10
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v733 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %10
    ;
    uint64_t v734 = (uint64_t) v47;
    TASSIGN(v733, v734);
    // pto: %223
    ;
    int64_t v735 = v730 < v82 ? v82 : v730;
    // pto: %224
    ;
    __gm__ float* v736 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %224
    ;
    const int64_t v737 = 32;
    // pto: %224
    ;
    const int64_t v738 = 64;
    // pto: %224
    ;
    pto::Shape<1, 1, 1, 8, 8> v739 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %224
    ;
    pto::Stride<512, 512, 512, 64, 1> v740 = pto::Stride<512, 512, 512, 64, 1>();
    // pto: %224
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v741 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v736 + (v737 + v735 * v738), v739, v740);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v733, v741);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
    // pto: %11
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v742 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %11
    ;
    uint64_t v743 = (uint64_t) v48;
    TASSIGN(v742, v743);
    // pto: %pre_tile_t_inline861__tile
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v744 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %pre_tile_t_inline861__tile
    ;
    uint64_t v745 = (uint64_t) v49;
    TASSIGN(v744, v745);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
    TTRANS(v744, v733, v742);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    // pto: %12
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v746 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %12
    ;
    uint64_t v747 = (uint64_t) v49;
    TASSIGN(v746, v747);
    // pto: %pre0_inline862__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v748 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %pre0_inline862__tile
    ;
    uint64_t v749 = (uint64_t) v49;
    TASSIGN(v748, v749);
    // pto: %13
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v750 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %13
    ;
    uint64_t v751 = (uint64_t) v50;
    TASSIGN(v750, v751);
    // pto: %pre1_inline863__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v752 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %pre1_inline863__tile
    ;
    uint64_t v753 = (uint64_t) v50;
    TASSIGN(v752, v753);
    // pto: %14
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v754 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %14
    ;
    uint64_t v755 = (uint64_t) v51;
    TASSIGN(v754, v755);
    // pto: %pre2_inline864__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v756 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %pre2_inline864__tile
    ;
    uint64_t v757 = (uint64_t) v51;
    TASSIGN(v756, v757);
    // pto: %15
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v758 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %15
    ;
    uint64_t v759 = (uint64_t) v52;
    TASSIGN(v758, v759);
    // pto: %pre3_inline865__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v760 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %pre3_inline865__tile
    ;
    uint64_t v761 = (uint64_t) v52;
    TASSIGN(v760, v761);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    for (int64_t v762 = v82; v762 < v71; v762 += v80) {
      // pto: %229
      ;
      int64_t v763 = (int64_t) ((uint64_t) v762 * (uint64_t) v83);
      // pto: %232
      ;
      int64_t v764 = (int64_t) ((uint64_t) v763 + (uint64_t) v83);
      // pto: %x0_inline868__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v765 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %x0_inline868__tile
      ;
      uint64_t v766 = (uint64_t) v47;
      TASSIGN(v765, v766);
      // pto: %235
      ;
      int64_t v767 = v763 < v82 ? v82 : v763;
      // pto: %236
      ;
      const int64_t v768 = 0;
      // pto: %236
      ;
      __gm__ float* v769 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %236
      ;
      const int64_t v770 = 1;
      // pto: %236
      ;
      const int64_t v771 = 1;
      // pto: %236
      ;
      const int64_t v772 = 1;
      // pto: %236
      ;
      int64_t v773 = v732 * v69;
      // pto: %236
      ;
      int64_t v774 = v772 * v773;
      // pto: %236
      ;
      pto::Shape<1, 1, 1, -1, 256> v775 = pto::Shape<1, 1, 1, -1, 256>(v770, v771, v772, v732, v83);
      // pto: %236
      ;
      pto::Stride<-1, -1, -1, -1, -1> v776 = pto::Stride<-1, -1, -1, -1, -1>(v771 * v774, v774, v773, v69, v70);
      // pto: %236
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v777 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v769 + (v768 + v735 * v69 + v767 * v70), v775, v776);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      TLOAD(v765, v777);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %x1_inline869__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v778 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %x1_inline869__tile
      ;
      uint64_t v779 = (uint64_t) v48;
      TASSIGN(v778, v779);
      // pto: %238
      ;
      int64_t v780 = (int64_t) ((uint64_t) v763 + (uint64_t) v74);
      // pto: %239
      ;
      int64_t v781 = v780 < v82 ? v82 : v780;
      // pto: %240
      ;
      const int64_t v782 = 0;
      // pto: %240
      ;
      __gm__ float* v783 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %240
      ;
      const int64_t v784 = 1;
      // pto: %240
      ;
      const int64_t v785 = 1;
      // pto: %240
      ;
      const int64_t v786 = 1;
      // pto: %240
      ;
      int64_t v787 = v732 * v69;
      // pto: %240
      ;
      int64_t v788 = v786 * v787;
      // pto: %240
      ;
      pto::Shape<1, 1, 1, -1, 256> v789 = pto::Shape<1, 1, 1, -1, 256>(v784, v785, v786, v732, v83);
      // pto: %240
      ;
      pto::Stride<-1, -1, -1, -1, -1> v790 = pto::Stride<-1, -1, -1, -1, -1>(v785 * v788, v788, v787, v69, v70);
      // pto: %240
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v791 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v783 + (v782 + v735 * v69 + v781 * v70), v789, v790);
      TLOAD(v778, v791);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %x2_inline870__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v792 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %x2_inline870__tile
      ;
      uint64_t v793 = (uint64_t) v45;
      TASSIGN(v792, v793);
      // pto: %242
      ;
      int64_t v794 = (int64_t) ((uint64_t) v763 + (uint64_t) v95);
      // pto: %243
      ;
      int64_t v795 = v794 < v82 ? v82 : v794;
      // pto: %244
      ;
      const int64_t v796 = 0;
      // pto: %244
      ;
      __gm__ float* v797 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %244
      ;
      const int64_t v798 = 1;
      // pto: %244
      ;
      const int64_t v799 = 1;
      // pto: %244
      ;
      const int64_t v800 = 1;
      // pto: %244
      ;
      int64_t v801 = v732 * v69;
      // pto: %244
      ;
      int64_t v802 = v800 * v801;
      // pto: %244
      ;
      pto::Shape<1, 1, 1, -1, 256> v803 = pto::Shape<1, 1, 1, -1, 256>(v798, v799, v800, v732, v83);
      // pto: %244
      ;
      pto::Stride<-1, -1, -1, -1, -1> v804 = pto::Stride<-1, -1, -1, -1, -1>(v799 * v802, v802, v801, v69, v70);
      // pto: %244
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v805 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v797 + (v796 + v735 * v69 + v795 * v70), v803, v804);
      TLOAD(v792, v805);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %x3_inline871__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v806 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %x3_inline871__tile
      ;
      uint64_t v807 = (uint64_t) v46;
      TASSIGN(v806, v807);
      // pto: %246
      ;
      int64_t v808 = (int64_t) ((uint64_t) v763 + (uint64_t) v96);
      // pto: %247
      ;
      int64_t v809 = v808 < v82 ? v82 : v808;
      // pto: %248
      ;
      const int64_t v810 = 0;
      // pto: %248
      ;
      __gm__ float* v811 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %248
      ;
      const int64_t v812 = 1;
      // pto: %248
      ;
      const int64_t v813 = 1;
      // pto: %248
      ;
      const int64_t v814 = 1;
      // pto: %248
      ;
      int64_t v815 = v732 * v69;
      // pto: %248
      ;
      int64_t v816 = v814 * v815;
      // pto: %248
      ;
      pto::Shape<1, 1, 1, -1, 256> v817 = pto::Shape<1, 1, 1, -1, 256>(v812, v813, v814, v732, v83);
      // pto: %248
      ;
      pto::Stride<-1, -1, -1, -1, -1> v818 = pto::Stride<-1, -1, -1, -1, -1>(v813 * v816, v816, v815, v69, v70);
      // pto: %248
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v819 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v811 + (v810 + v735 * v69 + v809 * v70), v817, v818);
      TLOAD(v806, v819);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %16
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v820 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %16
      ;
      uint64_t v821 = (uint64_t) v53;
      TASSIGN(v820, v821);
      // pto: %250
      ;
      int64_t v822 = v764 < v82 ? v82 : v764;
      // pto: %251
      ;
      const int64_t v823 = 0;
      // pto: %251
      ;
      __gm__ float* v824 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %251
      ;
      const int64_t v825 = 1;
      // pto: %251
      ;
      const int64_t v826 = 1;
      // pto: %251
      ;
      const int64_t v827 = 1;
      // pto: %251
      ;
      int64_t v828 = v732 * v69;
      // pto: %251
      ;
      int64_t v829 = v827 * v828;
      // pto: %251
      ;
      pto::Shape<1, 1, 1, -1, 256> v830 = pto::Shape<1, 1, 1, -1, 256>(v825, v826, v827, v732, v83);
      // pto: %251
      ;
      pto::Stride<-1, -1, -1, -1, -1> v831 = pto::Stride<-1, -1, -1, -1, -1>(v826 * v829, v829, v828, v69, v70);
      // pto: %251
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v832 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v824 + (v823 + v735 * v69 + v822 * v70), v830, v831);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      TLOAD(v820, v832);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      // pto: %17
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v833 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %17
      ;
      uint64_t v834 = (uint64_t) v54;
      TASSIGN(v833, v834);
      int64_t v835 = (int64_t) ((uint64_t) v763 + (uint64_t) v42);
      // pto: %254
      ;
      int64_t v836 = v835 < v82 ? v82 : v835;
      // pto: %255
      ;
      const int64_t v837 = 0;
      // pto: %255
      ;
      __gm__ float* v838 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %255
      ;
      const int64_t v839 = 1;
      // pto: %255
      ;
      const int64_t v840 = 1;
      // pto: %255
      ;
      const int64_t v841 = 1;
      // pto: %255
      ;
      int64_t v842 = v732 * v69;
      // pto: %255
      ;
      int64_t v843 = v841 * v842;
      // pto: %255
      ;
      pto::Shape<1, 1, 1, -1, 256> v844 = pto::Shape<1, 1, 1, -1, 256>(v839, v840, v841, v732, v83);
      // pto: %255
      ;
      pto::Stride<-1, -1, -1, -1, -1> v845 = pto::Stride<-1, -1, -1, -1, -1>(v840 * v843, v843, v842, v69, v70);
      // pto: %255
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v846 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v838 + (v837 + v735 * v69 + v836 * v70), v844, v845);
      TLOAD(v833, v846);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      // pto: %18
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v847 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %18
      ;
      uint64_t v848 = (uint64_t) v55;
      TASSIGN(v847, v848);
      int64_t v849 = (int64_t) ((uint64_t) v763 + (uint64_t) v41);
      // pto: %258
      ;
      int64_t v850 = v849 < v82 ? v82 : v849;
      // pto: %259
      ;
      const int64_t v851 = 0;
      // pto: %259
      ;
      __gm__ float* v852 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %259
      ;
      const int64_t v853 = 1;
      // pto: %259
      ;
      const int64_t v854 = 1;
      // pto: %259
      ;
      const int64_t v855 = 1;
      // pto: %259
      ;
      int64_t v856 = v732 * v69;
      // pto: %259
      ;
      int64_t v857 = v855 * v856;
      // pto: %259
      ;
      pto::Shape<1, 1, 1, -1, 256> v858 = pto::Shape<1, 1, 1, -1, 256>(v853, v854, v855, v732, v83);
      // pto: %259
      ;
      pto::Stride<-1, -1, -1, -1, -1> v859 = pto::Stride<-1, -1, -1, -1, -1>(v854 * v857, v857, v856, v69, v70);
      // pto: %259
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v860 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v852 + (v851 + v735 * v69 + v850 * v70), v858, v859);
      TLOAD(v847, v860);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
      // pto: %19
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v861 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %19
      ;
      uint64_t v862 = (uint64_t) v56;
      TASSIGN(v861, v862);
      int64_t v863 = (int64_t) ((uint64_t) v763 + (uint64_t) v40);
      // pto: %262
      ;
      int64_t v864 = v863 < v82 ? v82 : v863;
      // pto: %263
      ;
      const int64_t v865 = 0;
      // pto: %263
      ;
      __gm__ float* v866 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %263
      ;
      const int64_t v867 = 1;
      // pto: %263
      ;
      const int64_t v868 = 1;
      // pto: %263
      ;
      const int64_t v869 = 1;
      // pto: %263
      ;
      int64_t v870 = v732 * v69;
      // pto: %263
      ;
      int64_t v871 = v869 * v870;
      // pto: %263
      ;
      pto::Shape<1, 1, 1, -1, 256> v872 = pto::Shape<1, 1, 1, -1, 256>(v867, v868, v869, v732, v83);
      // pto: %263
      ;
      pto::Stride<-1, -1, -1, -1, -1> v873 = pto::Stride<-1, -1, -1, -1, -1>(v868 * v871, v871, v870, v69, v70);
      // pto: %263
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v874 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v866 + (v865 + v735 * v69 + v864 * v70), v872, v873);
      TLOAD(v861, v874);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
      // pto: %y0_inline872__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v875 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %y0_inline872__tile
      ;
      uint64_t v876 = (uint64_t) v47;
      TASSIGN(v875, v876);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      TROWEXPANDMUL(v875, v765, v748);
      // pto: %y1_inline873__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v877 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %y1_inline873__tile
      ;
      uint64_t v878 = (uint64_t) v48;
      TASSIGN(v877, v878);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      TROWEXPANDMUL(v877, v778, v752);
      // pto: %y2_inline874__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v879 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %y2_inline874__tile
      ;
      uint64_t v880 = (uint64_t) v45;
      TASSIGN(v879, v880);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      TROWEXPANDMUL(v879, v792, v756);
      // pto: %y3_inline875__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v881 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %y3_inline875__tile
      ;
      uint64_t v882 = (uint64_t) v46;
      TASSIGN(v881, v882);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      TROWEXPANDMUL(v881, v806, v760);
      // pto: %20
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v883 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %20
      ;
      uint64_t v884 = (uint64_t) v47;
      TASSIGN(v883, v884);
      pipe_barrier(PIPE_V);
      TADD(v883, v875, v877);
      // pto: %21
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v885 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %21
      ;
      uint64_t v886 = (uint64_t) v47;
      TASSIGN(v885, v886);
      pipe_barrier(PIPE_V);
      TADD(v885, v883, v879);
      // pto: %y_tile_inline876__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v887 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %y_tile_inline876__tile
      ;
      uint64_t v888 = (uint64_t) v47;
      TASSIGN(v887, v888);
      pipe_barrier(PIPE_V);
      TADD(v887, v885, v881);
      // pto: %y_bf16_inline877__tile
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v889 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %y_bf16_inline877__tile
      ;
      uint64_t v890 = (uint64_t) v47;
      TASSIGN(v889, v890);
      pipe_barrier(PIPE_V);
      RoundMode v891 = RoundMode::CAST_RINT;
      SaturationMode v892 = SaturationMode::ON;
      TCVT(v889, v887, v891, v892);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      // pto: %264
      ;
      bool v893 = v732 == v79;
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      if (v893) {
        // pto: %mixed__iter_v3_pview
        ;
        const int64_t v894 = 0;
        // pto: %mixed__iter_v3_pview
        ;
        __gm__ bfloat16_t* v895 = PTOAS__GLOBAL_TENSOR_DATA(v217);
        // pto: %mixed__iter_v3_pview
        ;
        const int64_t v896 = 1;
        // pto: %mixed__iter_v3_pview
        ;
        const int64_t v897 = 1;
        // pto: %mixed__iter_v3_pview
        ;
        const int64_t v898 = 1;
        // pto: %mixed__iter_v3_pview
        ;
        int64_t v899 = v732 * v74;
        // pto: %mixed__iter_v3_pview
        ;
        int64_t v900 = v898 * v899;
        // pto: %mixed__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v901 = pto::Shape<1, 1, 1, -1, 256>(v896, v897, v898, v732, v83);
        // pto: %mixed__iter_v3_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v902 = pto::Stride<-1, -1, -1, -1, -1>(v897 * v900, v900, v899, v74, v70);
        // pto: %mixed__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v903 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v895 + (v894 + v735 * v74 + v767 * v70), v901, v902);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v903, v889);
      } else {
        // pto: %mixed_tail__iter_v3_pview
        ;
        const int64_t v904 = 0;
        // pto: %mixed_tail__iter_v3_pview
        ;
        __gm__ bfloat16_t* v905 = PTOAS__GLOBAL_TENSOR_DATA(v225);
        // pto: %mixed_tail__iter_v3_pview
        ;
        const int64_t v906 = 1;
        // pto: %mixed_tail__iter_v3_pview
        ;
        const int64_t v907 = 1;
        // pto: %mixed_tail__iter_v3_pview
        ;
        const int64_t v908 = 1;
        // pto: %mixed_tail__iter_v3_pview
        ;
        int64_t v909 = v732 * v74;
        // pto: %mixed_tail__iter_v3_pview
        ;
        int64_t v910 = v908 * v909;
        // pto: %mixed_tail__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v911 = pto::Shape<1, 1, 1, -1, 256>(v906, v907, v908, v732, v83);
        // pto: %mixed_tail__iter_v3_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v912 = pto::Stride<-1, -1, -1, -1, -1>(v907 * v910, v910, v909, v74, v70);
        // pto: %mixed_tail__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v913 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v905 + (v904 + v82 * v74 + v767 * v70), v911, v912);
        TSTORE(v913, v889);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        // pto: %y_out_inline878__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v914 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
        // pto: %y_out_inline878__ssa_v0
        ;
        uint64_t v915 = (uint64_t) v47;
        TASSIGN(v914, v915);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        TLOAD(v914, v913);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
        // pto: %271
        ;
        const int64_t v916 = 0;
        // pto: %271
        ;
        __gm__ bfloat16_t* v917 = PTOAS__GLOBAL_TENSOR_DATA(v217);
        // pto: %271
        ;
        const int64_t v918 = 1;
        // pto: %271
        ;
        const int64_t v919 = 1;
        // pto: %271
        ;
        const int64_t v920 = 1;
        // pto: %271
        ;
        int64_t v921 = v732 * v74;
        // pto: %271
        ;
        int64_t v922 = v920 * v921;
        // pto: %271
        ;
        pto::Shape<1, 1, 1, -1, 256> v923 = pto::Shape<1, 1, 1, -1, 256>(v918, v919, v920, v732, v83);
        // pto: %271
        ;
        pto::Stride<-1, -1, -1, -1, -1> v924 = pto::Stride<-1, -1, -1, -1, -1>(v919 * v922, v922, v921, v74, v70);
        // pto: %271
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v925 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v917 + (v916 + v735 * v74 + v767 * v70), v923, v924);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
        TSTORE(v925, v914);
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      // pto: %22
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v926 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %22
      ;
      uint64_t v927 = (uint64_t) v53;
      TASSIGN(v926, v927);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      TROWEXPANDMUL(v926, v820, v748);
      // pto: %23
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v928 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %23
      ;
      uint64_t v929 = (uint64_t) v54;
      TASSIGN(v928, v929);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      TROWEXPANDMUL(v928, v833, v752);
      // pto: %24
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v930 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %24
      ;
      uint64_t v931 = (uint64_t) v55;
      TASSIGN(v930, v931);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
      TROWEXPANDMUL(v930, v847, v756);
      // pto: %25
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v932 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %25
      ;
      uint64_t v933 = (uint64_t) v56;
      TASSIGN(v932, v933);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
      TROWEXPANDMUL(v932, v861, v760);
      // pto: %26
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v934 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %26
      ;
      uint64_t v935 = (uint64_t) v53;
      TASSIGN(v934, v935);
      pipe_barrier(PIPE_V);
      TADD(v934, v926, v928);
      // pto: %27
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v936 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %27
      ;
      uint64_t v937 = (uint64_t) v53;
      TASSIGN(v936, v937);
      pipe_barrier(PIPE_V);
      TADD(v936, v934, v930);
      // pto: %28
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v938 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %28
      ;
      uint64_t v939 = (uint64_t) v53;
      TASSIGN(v938, v939);
      pipe_barrier(PIPE_V);
      TADD(v938, v936, v932);
      // pto: %29
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v940 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
      // pto: %29
      ;
      uint64_t v941 = (uint64_t) v53;
      TASSIGN(v940, v941);
      pipe_barrier(PIPE_V);
      RoundMode v942 = RoundMode::CAST_RINT;
      SaturationMode v943 = SaturationMode::ON;
      TCVT(v940, v938, v942, v943);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      if (v893) {
        // pto: %mixed__phi_v6_pview
        ;
        const int64_t v944 = 0;
        // pto: %mixed__phi_v6_pview
        ;
        __gm__ bfloat16_t* v945 = PTOAS__GLOBAL_TENSOR_DATA(v217);
        // pto: %mixed__phi_v6_pview
        ;
        const int64_t v946 = 1;
        // pto: %mixed__phi_v6_pview
        ;
        const int64_t v947 = 1;
        // pto: %mixed__phi_v6_pview
        ;
        const int64_t v948 = 1;
        // pto: %mixed__phi_v6_pview
        ;
        int64_t v949 = v732 * v74;
        // pto: %mixed__phi_v6_pview
        ;
        int64_t v950 = v948 * v949;
        // pto: %mixed__phi_v6_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v951 = pto::Shape<1, 1, 1, -1, 256>(v946, v947, v948, v732, v83);
        // pto: %mixed__phi_v6_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v952 = pto::Stride<-1, -1, -1, -1, -1>(v947 * v950, v950, v949, v74, v70);
        // pto: %mixed__phi_v6_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v953 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v945 + (v944 + v735 * v74 + v822 * v70), v951, v952);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v953, v940);
      } else {
        // pto: %mixed_tail__phi_v6_pview
        ;
        const int64_t v954 = 0;
        // pto: %mixed_tail__phi_v6_pview
        ;
        __gm__ bfloat16_t* v955 = PTOAS__GLOBAL_TENSOR_DATA(v225);
        // pto: %mixed_tail__phi_v6_pview
        ;
        const int64_t v956 = 1;
        // pto: %mixed_tail__phi_v6_pview
        ;
        const int64_t v957 = 1;
        // pto: %mixed_tail__phi_v6_pview
        ;
        const int64_t v958 = 1;
        // pto: %mixed_tail__phi_v6_pview
        ;
        int64_t v959 = v732 * v74;
        // pto: %mixed_tail__phi_v6_pview
        ;
        int64_t v960 = v958 * v959;
        // pto: %mixed_tail__phi_v6_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v961 = pto::Shape<1, 1, 1, -1, 256>(v956, v957, v958, v732, v83);
        // pto: %mixed_tail__phi_v6_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v962 = pto::Stride<-1, -1, -1, -1, -1>(v957 * v960, v960, v959, v74, v70);
        // pto: %mixed_tail__phi_v6_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v963 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v955 + (v954 + v82 * v74 + v822 * v70), v961, v962);
        TSTORE(v963, v940);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        // pto: %30
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v964 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v732, v83);
        // pto: %30
        ;
        uint64_t v965 = (uint64_t) v53;
        TASSIGN(v964, v965);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        TLOAD(v964, v963);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID3);
        // pto: %282
        ;
        const int64_t v966 = 0;
        // pto: %282
        ;
        __gm__ bfloat16_t* v967 = PTOAS__GLOBAL_TENSOR_DATA(v217);
        // pto: %282
        ;
        const int64_t v968 = 1;
        // pto: %282
        ;
        const int64_t v969 = 1;
        // pto: %282
        ;
        const int64_t v970 = 1;
        // pto: %282
        ;
        int64_t v971 = v732 * v74;
        // pto: %282
        ;
        int64_t v972 = v970 * v971;
        // pto: %282
        ;
        pto::Shape<1, 1, 1, -1, 256> v973 = pto::Shape<1, 1, 1, -1, 256>(v968, v969, v970, v732, v83);
        // pto: %282
        ;
        pto::Stride<-1, -1, -1, -1, -1> v974 = pto::Stride<-1, -1, -1, -1, -1>(v969 * v972, v972, v971, v74, v70);
        // pto: %282
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v975 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v967 + (v966 + v735 * v74 + v822 * v70), v973, v974);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID3);
        TSTORE(v975, v964);
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    };
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v976 = v291; v976 < v32; v976 += v81) {
    // pto: %raw_inline881__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v977 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %raw_inline881__ssa_v0
    ;
    uint64_t v978 = (uint64_t) v48;
    TASSIGN(v977, v978);
    // pto: %283
    ;
    int64_t v979 = v976 < v82 ? v82 : v976;
    // pto: %mixed__ssa_v7_pview
    ;
    __gm__ bfloat16_t* v980 = PTOAS__GLOBAL_TENSOR_DATA(v217);
    // pto: %mixed__ssa_v7_pview
    ;
    const int64_t v981 = 0;
    // pto: %mixed__ssa_v7_pview
    ;
    const int64_t v982 = 4096;
    // pto: %mixed__ssa_v7_pview
    ;
    pto::Shape<1, 1, 1, 1, 4096> v983 = pto::Shape<1, 1, 1, 1, 4096>();
    // pto: %mixed__ssa_v7_pview
    ;
    pto::Stride<4096, 4096, 4096, 4096, 1> v984 = pto::Stride<4096, 4096, 4096, 4096, 1>();
    // pto: %mixed__ssa_v7_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v985 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v980 + (v981 + v979 * v982), v983, v984);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v977, v985);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %wide_inline882__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v986 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %wide_inline882__ssa_v0
    ;
    uint64_t v987 = (uint64_t) v47;
    TASSIGN(v986, v987);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
    RoundMode v988 = RoundMode::CAST_ROUND;
    SaturationMode v989 = SaturationMode::ON;
    TCVT(v986, v977, v988, v989);
    // pto: %square_inline883__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v990 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %square_inline883__ssa_v0
    ;
    uint64_t v991 = (uint64_t) v48;
    TASSIGN(v990, v991);
    pipe_barrier(PIPE_V);
    TMUL(v990, v986, v986);
    // pto: %t__tmp_v37
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v992 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v97);
    // pto: %t__tmp_v37
    ;
    uint64_t v993 = (uint64_t) v48;
    TASSIGN(v992, v993);
    // pto: %284
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v994;
    // pto: %284
    ;
    uint64_t v995 = (uint64_t) v48;
    TASSIGN(v994, v995);
    // pto: %t__tmp_v38
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v996 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v97);
    // pto: %t__tmp_v38
    ;
    uint64_t v997 = (uint64_t) v57;
    TASSIGN(v996, v997);
    // pto: %285
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v998;
    // pto: %285
    ;
    uint64_t v999 = (uint64_t) v57;
    TASSIGN(v998, v999);
    // pto: %fold2048_inline884__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1000 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v97);
    // pto: %fold2048_inline884__ssa_v0
    ;
    uint64_t v1001 = (uint64_t) v48;
    TASSIGN(v1000, v1001);
    pipe_barrier(PIPE_V);
    TADD(v1000, v994, v998);
    // pto: %t__tmp_v39
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1002 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v98);
    // pto: %t__tmp_v39
    ;
    uint64_t v1003 = (uint64_t) v48;
    TASSIGN(v1002, v1003);
    // pto: %286
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1004;
    // pto: %286
    ;
    uint64_t v1005 = (uint64_t) v48;
    TASSIGN(v1004, v1005);
    // pto: %t__tmp_v40
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1006 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v98);
    // pto: %t__tmp_v40
    ;
    uint64_t v1007 = (uint64_t) v58;
    TASSIGN(v1006, v1007);
    // pto: %287
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1008;
    // pto: %287
    ;
    uint64_t v1009 = (uint64_t) v58;
    TASSIGN(v1008, v1009);
    // pto: %fold1024_inline885__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1010 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v98);
    // pto: %fold1024_inline885__ssa_v0
    ;
    uint64_t v1011 = (uint64_t) v48;
    TASSIGN(v1010, v1011);
    pipe_barrier(PIPE_V);
    TADD(v1010, v1004, v1008);
    // pto: %t__tmp_v41
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1012 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
    // pto: %t__tmp_v41
    ;
    uint64_t v1013 = (uint64_t) v48;
    TASSIGN(v1012, v1013);
    // pto: %288
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1014;
    // pto: %288
    ;
    uint64_t v1015 = (uint64_t) v48;
    TASSIGN(v1014, v1015);
    // pto: %t__tmp_v42
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1016 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
    // pto: %t__tmp_v42
    ;
    uint64_t v1017 = (uint64_t) v59;
    TASSIGN(v1016, v1017);
    // pto: %289
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1018;
    // pto: %289
    ;
    uint64_t v1019 = (uint64_t) v59;
    TASSIGN(v1018, v1019);
    // pto: %fold512_inline886__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1020 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
    // pto: %fold512_inline886__ssa_v0
    ;
    uint64_t v1021 = (uint64_t) v48;
    TASSIGN(v1020, v1021);
    pipe_barrier(PIPE_V);
    TADD(v1020, v1014, v1018);
    // pto: %t__tmp_v43
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1022 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
    // pto: %t__tmp_v43
    ;
    uint64_t v1023 = (uint64_t) v48;
    TASSIGN(v1022, v1023);
    // pto: %290
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1024;
    // pto: %290
    ;
    uint64_t v1025 = (uint64_t) v48;
    TASSIGN(v1024, v1025);
    // pto: %t__tmp_v44
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1026 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
    // pto: %t__tmp_v44
    ;
    uint64_t v1027 = (uint64_t) v60;
    TASSIGN(v1026, v1027);
    // pto: %291
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1028;
    // pto: %291
    ;
    uint64_t v1029 = (uint64_t) v60;
    TASSIGN(v1028, v1029);
    // pto: %fold256_inline887__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1030 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
    // pto: %fold256_inline887__ssa_v0
    ;
    uint64_t v1031 = (uint64_t) v48;
    TASSIGN(v1030, v1031);
    pipe_barrier(PIPE_V);
    TADD(v1030, v1024, v1028);
    // pto: %t__tmp_v45
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1032 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v99);
    // pto: %t__tmp_v45
    ;
    uint64_t v1033 = (uint64_t) v48;
    TASSIGN(v1032, v1033);
    // pto: %292
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1034;
    // pto: %292
    ;
    uint64_t v1035 = (uint64_t) v48;
    TASSIGN(v1034, v1035);
    // pto: %t__tmp_v46
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1036 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v99);
    // pto: %t__tmp_v46
    ;
    uint64_t v1037 = (uint64_t) v61;
    TASSIGN(v1036, v1037);
    // pto: %293
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1038;
    // pto: %293
    ;
    uint64_t v1039 = (uint64_t) v61;
    TASSIGN(v1038, v1039);
    // pto: %fold128_inline888__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1040 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v99);
    // pto: %fold128_inline888__ssa_v0
    ;
    uint64_t v1041 = (uint64_t) v48;
    TASSIGN(v1040, v1041);
    pipe_barrier(PIPE_V);
    TADD(v1040, v1034, v1038);
    // pto: %t__tmp_v47
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1042 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v76);
    // pto: %t__tmp_v47
    ;
    uint64_t v1043 = (uint64_t) v48;
    TASSIGN(v1042, v1043);
    // pto: %294
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1044;
    // pto: %294
    ;
    uint64_t v1045 = (uint64_t) v48;
    TASSIGN(v1044, v1045);
    // pto: %t__tmp_v48
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1046 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v76);
    // pto: %t__tmp_v48
    ;
    uint64_t v1047 = (uint64_t) v62;
    TASSIGN(v1046, v1047);
    // pto: %295
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1048;
    // pto: %295
    ;
    uint64_t v1049 = (uint64_t) v62;
    TASSIGN(v1048, v1049);
    // pto: %fold64_inline889__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1050 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v76);
    // pto: %fold64_inline889__ssa_v0
    ;
    uint64_t v1051 = (uint64_t) v45;
    TASSIGN(v1050, v1051);
    pipe_barrier(PIPE_V);
    TADD(v1050, v1044, v1048);
    // pto: %t__tmp_v49
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1052 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v76);
    // pto: %t__tmp_v49
    ;
    uint64_t v1053 = (uint64_t) v48;
    TASSIGN(v1052, v1053);
    // pto: %repeated_inline890__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1054 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v76);
    // pto: %repeated_inline890__ssa_v0
    ;
    uint64_t v1055 = (uint64_t) v48;
    TASSIGN(v1054, v1055);
    pipe_barrier(PIPE_V);
    TCOLEXPAND(v1054, v1050);
    // pto: %t__tmp_v50
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1056 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v76);
    // pto: %t__tmp_v50
    ;
    uint64_t v1057 = (uint64_t) v45;
    TASSIGN(v1056, v1057);
    // pto: %total_inline891__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1058 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %total_inline891__ssa_v0
    ;
    uint64_t v1059 = (uint64_t) v46;
    TASSIGN(v1058, v1059);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID5);
    TROWSUM(v1058, v1054, v1056);
    set_flag(PIPE_V, PIPE_S, EVENT_ID3);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID3);
    // pto: %total_scalar_inline892__ssa_v0
    ;
    float v1060 = v1058.GetValue(v82);
    // pto: %31
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1061 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %31
    ;
    uint64_t v1062 = (uint64_t) v48;
    TASSIGN(v1061, v1062);
    pipe_barrier(PIPE_V);
    TEXPANDS(v1061, v93);
    // pto: %total_vector_inline893__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1063 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %total_vector_inline893__tile
    ;
    uint64_t v1064 = (uint64_t) v48;
    TASSIGN(v1063, v1064);
    pipe_barrier(PIPE_V);
    TMULS(v1063, v1061, v1060);
    // pto: %32
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1065 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %32
    ;
    uint64_t v1066 = (uint64_t) v48;
    TASSIGN(v1065, v1066);
    pipe_barrier(PIPE_V);
    TMULS(v1065, v1063, v100);
    // pto: %variance_inline894__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1067 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %variance_inline894__tile
    ;
    uint64_t v1068 = (uint64_t) v48;
    TASSIGN(v1067, v1068);
    pipe_barrier(PIPE_V);
    TADDS(v1067, v1065, v92);
    set_flag(PIPE_V, PIPE_S, EVENT_ID4);
    // pto: %root_value_inline895__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1069 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %root_value_inline895__tile
    ;
    uint64_t v1070 = (uint64_t) v45;
    TASSIGN(v1069, v1070);
    pipe_barrier(PIPE_V);
    TSQRT(v1069, v1067);
    set_flag(PIPE_V, PIPE_S, EVENT_ID5);
    // pto: %variance_bits_inline896__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1071 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %variance_bits_inline896__tile
    ;
    uint64_t v1072 = (uint64_t) v48;
    TASSIGN(v1071, v1072);
    // pto: %approx_bits_inline897__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1073 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %approx_bits_inline897__tile
    ;
    uint64_t v1074 = (uint64_t) v45;
    TASSIGN(v1073, v1074);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID4);
    // pto: %296
    ;
    int32_t v1075 = v1071.GetValue(v82);
    set_flag(PIPE_S, PIPE_V, EVENT_ID6);
    // pto: %297
    ;
    int64_t v1076 = (int64_t) v1075;
    wait_flag(PIPE_V, PIPE_S, EVENT_ID5);
    // pto: %298
    ;
    int32_t v1077 = v1073.GetValue(v82);
    set_flag(PIPE_S, PIPE_MTE2, EVENT_ID1);
    // pto: %299
    ;
    int64_t v1078 = (int64_t) v1077;
    // pto: %301, %302, %303
    ;
    // pto: %y_bits_inline899__phi_v7
    ;
    int64_t v1079;
    if ((int64_t) v1075 >= v101 & v1076 < v102) {
      // pto: %305
      ;
      const int64_t v1080 = 1;
      // pto: %305
      ;
      const int64_t v1081 = 0;
      // pto: %305
      ;
      int64_t v1082 = v1076 / v44;
      // pto: %305
      ;
      bool v1083 = v1076 < v1081;
      // pto: %305
      ;
      bool v1084 = v44 < v1081;
      // pto: %305
      ;
      bool v1085 = v1083 == v1084;
      // pto: %305
      ;
      bool v1086 = v1076 % v44 != v1081 && v1083 != v1084;
      // pto: %305
      ;
      int64_t v1087 = v1086 ? v1082 - v1080 : v1082;
      // pto: %307
      ;
      int64_t v1088 = v1076 % v44;
      // pto: %311, %308, %312, %313, %314
      ;
      int64_t v1089 = v1088 != v49 & v1088 < v49 ? (int64_t) ((uint64_t) v1088 + (uint64_t) v44) : v1088;
      // pto: %316
      ;
      int64_t v1090 = (int64_t) ((uint64_t) v1089 + (uint64_t) v44);
      // pto: %y_bits_inline899__rv_v2
      ;
      int64_t v1091;
      v1091 = v1078;
      for (int64_t v1092 = v82; v1092 < v80; v1092 += v70) {
        // pto: %318
        ;
        const int64_t v1093 = 1;
        // pto: %318
        ;
        const int64_t v1094 = 0;
        // pto: %318
        ;
        int64_t v1095 = v1091 / v44;
        // pto: %318
        ;
        int64_t v1096 = v1091 % v44;
        // pto: %318
        ;
        bool v1097 = v1091 < v1094;
        // pto: %318
        ;
        bool v1098 = v44 < v1094;
        // pto: %318
        ;
        bool v1099 = v1097 == v1098;
        // pto: %318
        ;
        bool v1100 = v1096 != v1094 && v1097 != v1098;
        // pto: %318
        ;
        int64_t v1101 = v1100 ? v1095 - v1093 : v1095;
        // pto: %320
        ;
        int64_t v1102 = v1091 % v44;
        // pto: %324, %321, %325, %326, %327
        ;
        int64_t v1103 = v1102 != v49 & v1102 < v49 ? (int64_t) ((uint64_t) v1102 + (uint64_t) v44) : v1102;
        // pto: %329, %330, %332
        ;
        int64_t v1104 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v1103 + (uint64_t) v44) * (uint64_t) v103) + (uint64_t) v70);
        // pto: %333
        ;
        int64_t v1105 = (int64_t) ((uint64_t) v1104 * (uint64_t) v1104);
        // pto: %339, %337, %334, %338
        ;
        int64_t v1106 = (int64_t) ((uint64_t) v1090 << (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v1087 - (uint64_t) ((int64_t) (uint64_t) v1101 * (uint64_t) v103)) + (uint64_t) v104));
        // pto: %340
        ;
        uint64_t v1107 = (uint64_t) v1091;
        // pto: %340
        ;
        int64_t v1108 = (int64_t) (v1107 - (uint64_t) v105);
        // pto: %342
        ;
        const int64_t v1109 = 1;
        // pto: %342
        ;
        const int64_t v1110 = 0;
        // pto: %342
        ;
        int64_t v1111 = v1108 / v44;
        // pto: %342
        ;
        bool v1112 = v1108 < v1110;
        // pto: %342
        ;
        bool v1113 = v44 < v1110;
        // pto: %342
        ;
        bool v1114 = v1112 == v1113;
        // pto: %342
        ;
        bool v1115 = v1108 % v44 != v1110 && v1112 != v1113;
        // pto: %342
        ;
        int64_t v1116 = v1115 ? v1111 - v1109 : v1111;
        // pto: %344
        ;
        int64_t v1117 = v1108 % v44;
        // pto: %348, %345, %349, %350, %351
        ;
        int64_t v1118 = v1117 != v49 & v1117 < v49 ? (int64_t) ((uint64_t) v1117 + (uint64_t) v44) : v1117;
        // pto: %353, %354, %356
        ;
        int64_t v1119 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v1118 + (uint64_t) v44) * (uint64_t) v103) + (uint64_t) v70);
        // pto: %357
        ;
        int64_t v1120 = (int64_t) ((uint64_t) v1119 * (uint64_t) v1119);
        // pto: %363, %361, %358, %362
        ;
        int64_t v1121 = (int64_t) ((uint64_t) v1090 << (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v1087 - (uint64_t) ((int64_t) (uint64_t) v1116 * (uint64_t) v103)) + (uint64_t) v104));
        // pto: %368
        ;
        int64_t v1122 = v1091 % v103;
        // pto: %369, %370, %371
        ;
        int64_t v1123 = v1122 < v49 ? (int64_t) ((uint64_t) v1122 + (uint64_t) v103) : v1122;
        // pto: %372
        ;
        bool v1124 = v1123 == v105;
        // pto: %365, %367, %373, %374
        ;
        // pto: %y_bits_inline899__phi_v6
        ;
        int64_t v1125;
        if (v1105 < v1106 | v1106 == v1105 & v1124) {
          // pto: %375
          ;
          uint64_t v1126 = (uint64_t) v1091;
          // pto: %375
          ;
          v1125 = (int64_t) (v1126 + (uint64_t) v105);
        } else {
          // pto: %377, %379, %385, %386
          ;
          bool v1127 = v1121 < v1120 | v1121 == v1120 & v1124;
          // pto: %y_bits_inline899__phi_v5
          ;
          int64_t v1128 = v1127 ? v1108 : v1091;
          v1125 = v1128;
        };
        v1091 = v1125;
      };
      v1079 = v1091;
    } else {
      v1079 = v1078;
    };
    // pto: %rounded_bits_inline915__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1129 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rounded_bits_inline915__tile
    ;
    uint64_t v1130 = (uint64_t) v48;
    TASSIGN(v1129, v1130);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID6);
    pipe_barrier(PIPE_V);
    TEXPANDS(v1129, v88);
    set_flag(PIPE_V, PIPE_S, EVENT_ID6);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID6);
    for (int64_t v1131 = v82; v1131 < v79; v1131 += v70) {
      // pto: %388
      ;
      int32_t v1132 = (int32_t) v1079;
      v1129.SetValue(v1131, v1132);
    };
    // pto: %rounded_root_inline917__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1133 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rounded_root_inline917__tile
    ;
    uint64_t v1134 = (uint64_t) v48;
    TASSIGN(v1133, v1134);
    // pto: %scalar_root_value_inline918__tile
    ;
    float v1135 = v1133.GetValue(v82);
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
    // pto: %391
    ;
    float v1136 = v93 / v1135;
    // pto: %33
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1137 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %33
    ;
    uint64_t v1138 = (uint64_t) v48;
    TASSIGN(v1137, v1138);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    TEXPANDS(v1137, v93);
    // pto: %inverse_inline920__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1139 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %inverse_inline920__tile
    ;
    uint64_t v1140 = (uint64_t) v46;
    TASSIGN(v1139, v1140);
    pipe_barrier(PIPE_V);
    TMULS(v1139, v1137, v1136);
    set_flag(PIPE_V, PIPE_S, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    __gm__ float* v1141 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    const int64_t v1142 = 48;
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    const int64_t v1143 = 64;
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v1144 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    pto::Stride<64, 64, 64, 64, 1> v1145 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v1146 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v1141 + (v1142 + v979 * v1143), v1144, v1145);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1146, v1139);
    // pto: %apply_value_inline921__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1147 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %apply_value_inline921__ssa_v0
    ;
    uint64_t v1148 = (uint64_t) v47;
    TASSIGN(v1147, v1148);
    // pto: %t__tmp_v56
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1149 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %t__tmp_v56
    ;
    uint64_t v1150 = (uint64_t) v45;
    TASSIGN(v1149, v1150);
    // pto: %attn_norm_w__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v1151 = PTOAS__GLOBAL_TENSOR_DATA(v235);
    // pto: %attn_norm_w__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 4096> v1152 = pto::Shape<1, 1, 1, 1, 4096>();
    // pto: %attn_norm_w__ssa_v0_pview
    ;
    pto::Stride<4096, 4096, 4096, 4096, 1> v1153 = pto::Stride<4096, 4096, 4096, 4096, 1>();
    // pto: %attn_norm_w__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v1154 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v1151, v1152, v1153);
    wait_flag(PIPE_S, PIPE_MTE2, EVENT_ID1);
    TLOAD(v1149, v1154);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %w_raw_inline922__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1155 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %w_raw_inline922__ssa_v0
    ;
    uint64_t v1156 = (uint64_t) v45;
    TASSIGN(v1155, v1156);
    // pto: %w_inline923__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1157 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %w_inline923__ssa_v0
    ;
    uint64_t v1158 = (uint64_t) v48;
    TASSIGN(v1157, v1158);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    pipe_barrier(PIPE_V);
    RoundMode v1159 = RoundMode::CAST_ROUND;
    SaturationMode v1160 = SaturationMode::ON;
    TCVT(v1157, v1155, v1159, v1160);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
    // pto: %inv_inline924__tile
    ;
    float v1161 = v1139.GetValue(v82);
    set_flag(PIPE_S, PIPE_V, EVENT_ID5);
    // pto: %scaled_inline925__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1162 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %scaled_inline925__ssa_v0
    ;
    uint64_t v1163 = (uint64_t) v47;
    TASSIGN(v1162, v1163);
    TMULS(v1162, v1147, v1161);
    // pto: %result_inline926__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1164 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %result_inline926__ssa_v0
    ;
    uint64_t v1165 = (uint64_t) v47;
    TASSIGN(v1164, v1165);
    pipe_barrier(PIPE_V);
    TCOLEXPANDMUL(v1164, v1162, v1157);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %t__tmp_v57
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1166 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %t__tmp_v57
    ;
    uint64_t v1167 = (uint64_t) v47;
    TASSIGN(v1166, v1167);
    pipe_barrier(PIPE_V);
    RoundMode v1168 = RoundMode::CAST_RINT;
    SaturationMode v1169 = SaturationMode::ON;
    TCVT(v1166, v1164, v1168, v1169);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %normed__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v1170 = PTOAS__GLOBAL_TENSOR_DATA(v136);
    // pto: %normed__ssa_v0_pview
    ;
    const int64_t v1171 = 0;
    // pto: %normed__ssa_v0_pview
    ;
    const int64_t v1172 = 4096;
    // pto: %normed__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 4096> v1173 = pto::Shape<1, 1, 1, 1, 4096>();
    // pto: %normed__ssa_v0_pview
    ;
    pto::Stride<4096, 4096, 4096, 4096, 1> v1174 = pto::Stride<4096, 4096, 4096, 4096, 1>();
    // pto: %normed__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v1175 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v1170 + (v1171 + v979 * v1172), v1173, v1174);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1175, v1166);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_S, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_S, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  for (int64_t v1176 = v291; v1176 < v498; v1176 += v81) {
    // pto: %scale2_inline930__tile
    ;
    float v1177 = (v18)[v80];
    // pto: %396
    ;
    int64_t v1178 = (int64_t) ((uint64_t) v1176 * (uint64_t) v79);
    // pto: %397
    ;
    int64_t v1179 = (int64_t) ((uint64_t) v32 - (uint64_t) v1178);
    // pto: %398
    ;
    int64_t v1180 = v1179 < v79 ? v1179 : v79;
    // pto: %t__tmp_v58
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1181 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %t__tmp_v58
    ;
    uint64_t v1182 = (uint64_t) v54;
    TASSIGN(v1181, v1182);
    // pto: %399
    ;
    int64_t v1183 = v1178 < v82 ? v82 : v1178;
    // pto: %vec_ws_v2__rv_v2_pview
    ;
    __gm__ float* v1184 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %vec_ws_v2__rv_v2_pview
    ;
    const int64_t v1185 = 40;
    // pto: %vec_ws_v2__rv_v2_pview
    ;
    const int64_t v1186 = 64;
    // pto: %vec_ws_v2__rv_v2_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v1187 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %vec_ws_v2__rv_v2_pview
    ;
    pto::Stride<64, 64, 64, 64, 1> v1188 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %vec_ws_v2__rv_v2_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v1189 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v1184 + (v1185 + v1183 * v1186), v1187, v1188);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v1181, v1189);
    // pto: %t__tmp_v59
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1190 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %t__tmp_v59
    ;
    uint64_t v1191 = (uint64_t) v54;
    TASSIGN(v1190, v1191);
    v1190.SetValidShape(v1180, v70);
    // pto: %mix_g0_inline935__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1192 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
    // pto: %mix_g0_inline935__ssa_v0
    ;
    uint64_t v1193 = (uint64_t) v47;
    TASSIGN(v1192, v1193);
    // pto: %402
    ;
    const int64_t v1194 = 0;
    // pto: %402
    ;
    __gm__ float* v1195 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %402
    ;
    const int64_t v1196 = 1;
    // pto: %402
    ;
    const int64_t v1197 = 1;
    // pto: %402
    ;
    const int64_t v1198 = 1;
    // pto: %402
    ;
    int64_t v1199 = v1180 * v76;
    // pto: %402
    ;
    int64_t v1200 = v1198 * v1199;
    // pto: %402
    ;
    pto::Shape<1, 1, 1, -1, 4> v1201 = pto::Shape<1, 1, 1, -1, 4>(v1196, v1197, v1198, v1180, v77);
    // pto: %402
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1202 = pto::Stride<-1, -1, -1, -1, -1>(v1197 * v1200, v1200, v1199, v76, v70);
    // pto: %402
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1203 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1195 + (v1194 + v1183 * v76 + v79 * v70), v1201, v1202);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    TLOAD(v1192, v1203);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %mix_g1_inline936__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1204 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
    // pto: %mix_g1_inline936__ssa_v0
    ;
    uint64_t v1205 = (uint64_t) v48;
    TASSIGN(v1204, v1205);
    // pto: %406
    ;
    const int64_t v1206 = 0;
    // pto: %406
    ;
    __gm__ float* v1207 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %406
    ;
    const int64_t v1208 = 1;
    // pto: %406
    ;
    const int64_t v1209 = 1;
    // pto: %406
    ;
    const int64_t v1210 = 1;
    // pto: %406
    ;
    int64_t v1211 = v1180 * v76;
    // pto: %406
    ;
    int64_t v1212 = v1210 * v1211;
    // pto: %406
    ;
    pto::Shape<1, 1, 1, -1, 4> v1213 = pto::Shape<1, 1, 1, -1, 4>(v1208, v1209, v1210, v1180, v77);
    // pto: %406
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1214 = pto::Stride<-1, -1, -1, -1, -1>(v1209 * v1212, v1212, v1211, v76, v70);
    // pto: %406
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1215 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1207 + (v1206 + v1183 * v76 + v106 * v70), v1213, v1214);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    TLOAD(v1204, v1215);
    // pto: %mix_g2_inline937__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1216 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
    // pto: %mix_g2_inline937__ssa_v0
    ;
    uint64_t v1217 = (uint64_t) v45;
    TASSIGN(v1216, v1217);
    // pto: %410
    ;
    const int64_t v1218 = 0;
    // pto: %410
    ;
    __gm__ float* v1219 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %410
    ;
    const int64_t v1220 = 1;
    // pto: %410
    ;
    const int64_t v1221 = 1;
    // pto: %410
    ;
    const int64_t v1222 = 1;
    // pto: %410
    ;
    int64_t v1223 = v1180 * v76;
    // pto: %410
    ;
    int64_t v1224 = v1222 * v1223;
    // pto: %410
    ;
    pto::Shape<1, 1, 1, -1, 4> v1225 = pto::Shape<1, 1, 1, -1, 4>(v1220, v1221, v1222, v1180, v77);
    // pto: %410
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1226 = pto::Stride<-1, -1, -1, -1, -1>(v1221 * v1224, v1224, v1223, v76, v70);
    // pto: %410
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1227 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1219 + (v1218 + v1183 * v76 + v71 * v70), v1225, v1226);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    TLOAD(v1216, v1227);
    // pto: %mix_g3_inline938__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1228 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
    // pto: %mix_g3_inline938__ssa_v0
    ;
    uint64_t v1229 = (uint64_t) v46;
    TASSIGN(v1228, v1229);
    // pto: %414
    ;
    const int64_t v1230 = 0;
    // pto: %414
    ;
    __gm__ float* v1231 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %414
    ;
    const int64_t v1232 = 1;
    // pto: %414
    ;
    const int64_t v1233 = 1;
    // pto: %414
    ;
    const int64_t v1234 = 1;
    // pto: %414
    ;
    int64_t v1235 = v1180 * v76;
    // pto: %414
    ;
    int64_t v1236 = v1234 * v1235;
    // pto: %414
    ;
    pto::Shape<1, 1, 1, -1, 4> v1237 = pto::Shape<1, 1, 1, -1, 4>(v1232, v1233, v1234, v1180, v77);
    // pto: %414
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1238 = pto::Stride<-1, -1, -1, -1, -1>(v1233 * v1236, v1236, v1235, v76, v70);
    // pto: %414
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1239 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1231 + (v1230 + v1183 * v76 + v43 * v70), v1237, v1238);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    TLOAD(v1228, v1239);
    // pto: %cb0_inline939__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1240 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v77);
    // pto: %cb0_inline939__ssa_v0
    ;
    uint64_t v1241 = (uint64_t) v55;
    TASSIGN(v1240, v1241);
    // pto: %hc_base_2d__ssa_v0_pview
    ;
    __gm__ float* v1242 = PTOAS__GLOBAL_TENSOR_DATA(v190);
    // pto: %hc_base_2d__ssa_v0_pview
    ;
    unsigned v1243 = 8;
    // pto: %hc_base_2d__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 4> v1244 = pto::Shape<1, 1, 1, 1, 4>();
    // pto: %hc_base_2d__ssa_v0_pview
    ;
    pto::Stride<24, 24, 24, 24, 1> v1245 = pto::Stride<24, 24, 24, 24, 1>();
    // pto: %hc_base_2d__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND> v1246 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND>(v1242 + v1243, v1244, v1245);
    TLOAD(v1240, v1246);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %cb1_inline940__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1247 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v77);
    // pto: %cb1_inline940__ssa_v0
    ;
    uint64_t v1248 = (uint64_t) v56;
    TASSIGN(v1247, v1248);
    // pto: %418
    ;
    __gm__ float* v1249 = PTOAS__GLOBAL_TENSOR_DATA(v190);
    // pto: %418
    ;
    unsigned v1250 = 12;
    // pto: %418
    ;
    pto::Shape<1, 1, 1, 1, 4> v1251 = pto::Shape<1, 1, 1, 1, 4>();
    // pto: %418
    ;
    pto::Stride<24, 24, 24, 24, 1> v1252 = pto::Stride<24, 24, 24, 24, 1>();
    // pto: %418
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND> v1253 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND>(v1249 + v1250, v1251, v1252);
    TLOAD(v1247, v1253);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    // pto: %cb2_inline941__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1254 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v77);
    // pto: %cb2_inline941__ssa_v0
    ;
    uint64_t v1255 = (uint64_t) v49;
    TASSIGN(v1254, v1255);
    // pto: %421
    ;
    __gm__ float* v1256 = PTOAS__GLOBAL_TENSOR_DATA(v190);
    // pto: %421
    ;
    unsigned v1257 = 16;
    // pto: %421
    ;
    pto::Shape<1, 1, 1, 1, 4> v1258 = pto::Shape<1, 1, 1, 1, 4>();
    // pto: %421
    ;
    pto::Stride<24, 24, 24, 24, 1> v1259 = pto::Stride<24, 24, 24, 24, 1>();
    // pto: %421
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND> v1260 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND>(v1256 + v1257, v1258, v1259);
    TLOAD(v1254, v1260);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    // pto: %cb3_inline942__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1261 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v77);
    // pto: %cb3_inline942__ssa_v0
    ;
    uint64_t v1262 = (uint64_t) v63;
    TASSIGN(v1261, v1262);
    // pto: %424
    ;
    __gm__ float* v1263 = PTOAS__GLOBAL_TENSOR_DATA(v190);
    // pto: %424
    ;
    unsigned v1264 = 20;
    // pto: %424
    ;
    pto::Shape<1, 1, 1, 1, 4> v1265 = pto::Shape<1, 1, 1, 1, 4>();
    // pto: %424
    ;
    pto::Stride<24, 24, 24, 24, 1> v1266 = pto::Stride<24, 24, 24, 24, 1>();
    // pto: %424
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND> v1267 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND>(v1263 + v1264, v1265, v1266);
    TLOAD(v1261, v1267);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    // pto: %t__tmp_v60
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1268 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
    // pto: %t__tmp_v60
    ;
    uint64_t v1269 = (uint64_t) v53;
    TASSIGN(v1268, v1269);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v1268, v1192, v1190);
    // pto: %t__tmp_v61
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1270 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
    // pto: %t__tmp_v61
    ;
    uint64_t v1271 = (uint64_t) v53;
    TASSIGN(v1270, v1271);
    pipe_barrier(PIPE_V);
    TMULS(v1270, v1268, v1177);
    // pto: %t__tmp_v62
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1272 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
    // pto: %t__tmp_v62
    ;
    uint64_t v1273 = (uint64_t) v47;
    TASSIGN(v1272, v1273);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    TCOLEXPAND(v1272, v1240);
    // pto: %row0_inline943__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1274 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
    // pto: %row0_inline943__ssa_v0
    ;
    uint64_t v1275 = (uint64_t) v47;
    TASSIGN(v1274, v1275);
    pipe_barrier(PIPE_V);
    TADD(v1274, v1270, v1272);
    // pto: %t__tmp_v63
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1276 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
    // pto: %t__tmp_v63
    ;
    uint64_t v1277 = (uint64_t) v53;
    TASSIGN(v1276, v1277);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v1276, v1204, v1190);
    // pto: %t__tmp_v64
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1278 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
    // pto: %t__tmp_v64
    ;
    uint64_t v1279 = (uint64_t) v53;
    TASSIGN(v1278, v1279);
    pipe_barrier(PIPE_V);
    TMULS(v1278, v1276, v1177);
    // pto: %t__tmp_v65
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1280 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
    // pto: %t__tmp_v65
    ;
    uint64_t v1281 = (uint64_t) v48;
    TASSIGN(v1280, v1281);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    TCOLEXPAND(v1280, v1247);
    // pto: %row1_inline944__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1282 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
    // pto: %row1_inline944__ssa_v0
    ;
    uint64_t v1283 = (uint64_t) v48;
    TASSIGN(v1282, v1283);
    pipe_barrier(PIPE_V);
    TADD(v1282, v1278, v1280);
    // pto: %t__tmp_v66
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1284 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
    // pto: %t__tmp_v66
    ;
    uint64_t v1285 = (uint64_t) v53;
    TASSIGN(v1284, v1285);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v1284, v1216, v1190);
    // pto: %t__tmp_v67
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1286 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
    // pto: %t__tmp_v67
    ;
    uint64_t v1287 = (uint64_t) v53;
    TASSIGN(v1286, v1287);
    pipe_barrier(PIPE_V);
    TMULS(v1286, v1284, v1177);
    // pto: %t__tmp_v68
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1288 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
    // pto: %t__tmp_v68
    ;
    uint64_t v1289 = (uint64_t) v45;
    TASSIGN(v1288, v1289);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    TCOLEXPAND(v1288, v1254);
    // pto: %row2_inline945__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1290 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
    // pto: %row2_inline945__ssa_v0
    ;
    uint64_t v1291 = (uint64_t) v45;
    TASSIGN(v1290, v1291);
    pipe_barrier(PIPE_V);
    TADD(v1290, v1286, v1288);
    // pto: %t__tmp_v69
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1292 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
    // pto: %t__tmp_v69
    ;
    uint64_t v1293 = (uint64_t) v53;
    TASSIGN(v1292, v1293);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v1292, v1228, v1190);
    // pto: %t__tmp_v70
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1294 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
    // pto: %t__tmp_v70
    ;
    uint64_t v1295 = (uint64_t) v53;
    TASSIGN(v1294, v1295);
    pipe_barrier(PIPE_V);
    TMULS(v1294, v1292, v1177);
    // pto: %t__tmp_v71
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1296 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
    // pto: %t__tmp_v71
    ;
    uint64_t v1297 = (uint64_t) v46;
    TASSIGN(v1296, v1297);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    TCOLEXPAND(v1296, v1261);
    // pto: %row3_inline946__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1298 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
    // pto: %row3_inline946__ssa_v0
    ;
    uint64_t v1299 = (uint64_t) v46;
    TASSIGN(v1298, v1299);
    pipe_barrier(PIPE_V);
    TADD(v1298, v1294, v1296);
    // pto: %row0_p_inline947__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1300 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row0_p_inline947__ssa_v0
    ;
    uint64_t v1301 = (uint64_t) v47;
    TASSIGN(v1300, v1301);
    TFILLPAD<pto::TFillPadMode::InPlace>(v1300, v1274);
    // pto: %row1_p_inline948__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1302 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row1_p_inline948__ssa_v0
    ;
    uint64_t v1303 = (uint64_t) v48;
    TASSIGN(v1302, v1303);
    TFILLPAD<pto::TFillPadMode::InPlace>(v1302, v1282);
    // pto: %row2_p_inline949__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1304 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row2_p_inline949__ssa_v0
    ;
    uint64_t v1305 = (uint64_t) v45;
    TASSIGN(v1304, v1305);
    TFILLPAD<pto::TFillPadMode::InPlace>(v1304, v1290);
    // pto: %row3_p_inline950__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1306 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row3_p_inline950__ssa_v0
    ;
    uint64_t v1307 = (uint64_t) v46;
    TASSIGN(v1306, v1307);
    pipe_barrier(PIPE_V);
    TFILLPAD<pto::TFillPadMode::InPlace>(v1306, v1298);
    // pto: %row_max_tmp_inline951__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1308 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %row_max_tmp_inline951__ssa_v0
    ;
    uint64_t v1309 = (uint64_t) v53;
    TASSIGN(v1308, v1309);
    // pto: %row_sum_tmp_inline952__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1310 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %row_sum_tmp_inline952__ssa_v0
    ;
    uint64_t v1311 = (uint64_t) v54;
    TASSIGN(v1310, v1311);
    // pto: %row0_max_inline953__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1312 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row0_max_inline953__ssa_v0
    ;
    uint64_t v1313 = (uint64_t) v55;
    TASSIGN(v1312, v1313);
    TROWMAX(v1312, v1300, v1308);
    // pto: %row1_max_inline954__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1314 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row1_max_inline954__ssa_v0
    ;
    uint64_t v1315 = (uint64_t) v56;
    TASSIGN(v1314, v1315);
    pipe_barrier(PIPE_V);
    TROWMAX(v1314, v1302, v1308);
    // pto: %row2_max_inline955__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1316 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row2_max_inline955__ssa_v0
    ;
    uint64_t v1317 = (uint64_t) v49;
    TASSIGN(v1316, v1317);
    pipe_barrier(PIPE_V);
    TROWMAX(v1316, v1304, v1308);
    // pto: %row3_max_inline956__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1318 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row3_max_inline956__ssa_v0
    ;
    uint64_t v1319 = (uint64_t) v63;
    TASSIGN(v1318, v1319);
    pipe_barrier(PIPE_V);
    TROWMAX(v1318, v1306, v1308);
    // pto: %t__tmp_v72
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1320 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v72
    ;
    uint64_t v1321 = (uint64_t) v47;
    TASSIGN(v1320, v1321);
    TROWEXPANDSUB(v1320, v1300, v1312);
    // pto: %row0_exp_inline957__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1322 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row0_exp_inline957__ssa_v0
    ;
    uint64_t v1323 = (uint64_t) v47;
    TASSIGN(v1322, v1323);
    pipe_barrier(PIPE_V);
    TEXP(v1322, v1320);
    // pto: %t__tmp_v73
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1324 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v73
    ;
    uint64_t v1325 = (uint64_t) v48;
    TASSIGN(v1324, v1325);
    TROWEXPANDSUB(v1324, v1302, v1314);
    // pto: %row1_exp_inline958__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1326 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row1_exp_inline958__ssa_v0
    ;
    uint64_t v1327 = (uint64_t) v48;
    TASSIGN(v1326, v1327);
    pipe_barrier(PIPE_V);
    TEXP(v1326, v1324);
    // pto: %t__tmp_v74
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1328 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v74
    ;
    uint64_t v1329 = (uint64_t) v45;
    TASSIGN(v1328, v1329);
    TROWEXPANDSUB(v1328, v1304, v1316);
    // pto: %row2_exp_inline959__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1330 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row2_exp_inline959__ssa_v0
    ;
    uint64_t v1331 = (uint64_t) v45;
    TASSIGN(v1330, v1331);
    pipe_barrier(PIPE_V);
    TEXP(v1330, v1328);
    // pto: %t__tmp_v75
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1332 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v75
    ;
    uint64_t v1333 = (uint64_t) v46;
    TASSIGN(v1332, v1333);
    TROWEXPANDSUB(v1332, v1306, v1318);
    // pto: %row3_exp_inline960__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1334 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row3_exp_inline960__ssa_v0
    ;
    uint64_t v1335 = (uint64_t) v46;
    TASSIGN(v1334, v1335);
    pipe_barrier(PIPE_V);
    TEXP(v1334, v1332);
    // pto: %row0_sum_inline961__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1336 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row0_sum_inline961__ssa_v0
    ;
    uint64_t v1337 = (uint64_t) v53;
    TASSIGN(v1336, v1337);
    TROWSUM(v1336, v1322, v1310);
    // pto: %row1_sum_inline962__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1338 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row1_sum_inline962__ssa_v0
    ;
    uint64_t v1339 = (uint64_t) v55;
    TASSIGN(v1338, v1339);
    pipe_barrier(PIPE_V);
    TROWSUM(v1338, v1326, v1310);
    // pto: %row2_sum_inline963__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1340 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row2_sum_inline963__ssa_v0
    ;
    uint64_t v1341 = (uint64_t) v56;
    TASSIGN(v1340, v1341);
    pipe_barrier(PIPE_V);
    TROWSUM(v1340, v1330, v1310);
    // pto: %row3_sum_inline964__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1342 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row3_sum_inline964__ssa_v0
    ;
    uint64_t v1343 = (uint64_t) v49;
    TASSIGN(v1342, v1343);
    pipe_barrier(PIPE_V);
    TROWSUM(v1342, v1334, v1310);
    // pto: %t__tmp_v76
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1344 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v76
    ;
    uint64_t v1345 = (uint64_t) v47;
    TASSIGN(v1344, v1345);
    TROWEXPANDDIV(v1344, v1322, v1336);
    // pto: %row0_soft_inline967__ssa_v1
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1346 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row0_soft_inline967__ssa_v1
    ;
    uint64_t v1347 = (uint64_t) v47;
    TASSIGN(v1346, v1347);
    pipe_barrier(PIPE_V);
    TADDS(v1346, v1344, v92);
    // pto: %t__tmp_v77
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1348 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v77
    ;
    uint64_t v1349 = (uint64_t) v48;
    TASSIGN(v1348, v1349);
    TROWEXPANDDIV(v1348, v1326, v1338);
    // pto: %row1_soft_inline970__ssa_v1
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1350 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row1_soft_inline970__ssa_v1
    ;
    uint64_t v1351 = (uint64_t) v48;
    TASSIGN(v1350, v1351);
    pipe_barrier(PIPE_V);
    TADDS(v1350, v1348, v92);
    // pto: %t__tmp_v78
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1352 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v78
    ;
    uint64_t v1353 = (uint64_t) v45;
    TASSIGN(v1352, v1353);
    TROWEXPANDDIV(v1352, v1330, v1340);
    // pto: %row2_soft_inline973__ssa_v1
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1354 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row2_soft_inline973__ssa_v1
    ;
    uint64_t v1355 = (uint64_t) v45;
    TASSIGN(v1354, v1355);
    pipe_barrier(PIPE_V);
    TADDS(v1354, v1352, v92);
    // pto: %t__tmp_v79
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1356 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v79
    ;
    uint64_t v1357 = (uint64_t) v46;
    TASSIGN(v1356, v1357);
    TROWEXPANDDIV(v1356, v1334, v1342);
    // pto: %row3_soft_inline976__ssa_v1
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v1358 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row3_soft_inline976__ssa_v1
    ;
    uint64_t v1359 = (uint64_t) v46;
    TASSIGN(v1358, v1359);
    pipe_barrier(PIPE_V);
    TADDS(v1358, v1356, v92);
    v1346.SetValidShape(v79, v77);
    v1350.SetValidShape(v79, v77);
    v1354.SetValidShape(v79, v77);
    v1358.SetValidShape(v79, v77);
    // pto: %row0_eff_inline981__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1360 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row0_eff_inline981__ssa_v0
    ;
    uint64_t v1361 = (uint64_t) v47;
    TASSIGN(v1360, v1361);
    TFILLPAD<pto::TFillPadMode::InPlace>(v1360, v1346);
    // pto: %row1_eff_inline982__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1362 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row1_eff_inline982__ssa_v0
    ;
    uint64_t v1363 = (uint64_t) v48;
    TASSIGN(v1362, v1363);
    TFILLPAD<pto::TFillPadMode::InPlace>(v1362, v1350);
    // pto: %row2_eff_inline983__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1364 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row2_eff_inline983__ssa_v0
    ;
    uint64_t v1365 = (uint64_t) v45;
    TASSIGN(v1364, v1365);
    TFILLPAD<pto::TFillPadMode::InPlace>(v1364, v1354);
    // pto: %row3_eff_inline984__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1366 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row3_eff_inline984__ssa_v0
    ;
    uint64_t v1367 = (uint64_t) v46;
    TASSIGN(v1366, v1367);
    pipe_barrier(PIPE_V);
    TFILLPAD<pto::TFillPadMode::InPlace>(v1366, v1358);
    // pto: %row_sum_tmp_iter_inline985__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1368 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %row_sum_tmp_iter_inline985__ssa_v0
    ;
    uint64_t v1369 = (uint64_t) v53;
    TASSIGN(v1368, v1369);
    // pto: %t__tmp_v80
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1370 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v80
    ;
    uint64_t v1371 = (uint64_t) v54;
    TASSIGN(v1370, v1371);
    TADD(v1370, v1360, v1362);
    // pto: %t__tmp_v81
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1372 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v81
    ;
    uint64_t v1373 = (uint64_t) v54;
    TASSIGN(v1372, v1373);
    pipe_barrier(PIPE_V);
    TADD(v1372, v1370, v1364);
    // pto: %col_sum_inline986__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1374 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %col_sum_inline986__ssa_v0
    ;
    uint64_t v1375 = (uint64_t) v54;
    TASSIGN(v1374, v1375);
    pipe_barrier(PIPE_V);
    TADD(v1374, v1372, v1366);
    // pto: %col_sum_v1_inline987__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1376 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %col_sum_v1_inline987__ssa_v0
    ;
    uint64_t v1377 = (uint64_t) v54;
    TASSIGN(v1376, v1377);
    pipe_barrier(PIPE_V);
    TADDS(v1376, v1374, v92);
    // pto: %row0_cur_inline988__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1378 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row0_cur_inline988__ssa_v0
    ;
    uint64_t v1379 = (uint64_t) v47;
    TASSIGN(v1378, v1379);
    pipe_barrier(PIPE_V);
    TDIV(v1378, v1360, v1376);
    // pto: %row1_cur_inline989__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1380 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row1_cur_inline989__ssa_v0
    ;
    uint64_t v1381 = (uint64_t) v48;
    TASSIGN(v1380, v1381);
    TDIV(v1380, v1362, v1376);
    // pto: %row2_cur_inline990__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1382 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row2_cur_inline990__ssa_v0
    ;
    uint64_t v1383 = (uint64_t) v45;
    TASSIGN(v1382, v1383);
    TDIV(v1382, v1364, v1376);
    // pto: %row3_cur_inline991__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1384 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row3_cur_inline991__ssa_v0
    ;
    uint64_t v1385 = (uint64_t) v46;
    TASSIGN(v1384, v1385);
    TDIV(v1384, v1366, v1376);
    for (int64_t v1386 = v82; v1386 < v107; v1386 += v80) {
      // pto: %t__tmp_v82
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1387 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %t__tmp_v82
      ;
      uint64_t v1388 = (uint64_t) v54;
      TASSIGN(v1387, v1388);
      pipe_barrier(PIPE_V);
      TROWSUM(v1387, v1378, v1368);
      // pto: %row0_rowsum_inline993__rm_a0_tmp_v0
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1389 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row0_rowsum_inline993__rm_a0_tmp_v0
      ;
      uint64_t v1390 = (uint64_t) v54;
      TASSIGN(v1389, v1390);
      // pto: %row0_rowsum_inline993__row_major_tmp_v1
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1391 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row0_rowsum_inline993__row_major_tmp_v1
      ;
      uint64_t v1392 = (uint64_t) v55;
      TASSIGN(v1391, v1392);
      pipe_barrier(PIPE_V);
      TADDS(v1391, v1389, v92);
      // pto: %row0_rowsum_inline993__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1393 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %row0_rowsum_inline993__ssa_v0
      ;
      uint64_t v1394 = (uint64_t) v55;
      TASSIGN(v1393, v1394);
      // pto: %t__tmp_v83
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1395 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %t__tmp_v83
      ;
      uint64_t v1396 = (uint64_t) v54;
      TASSIGN(v1395, v1396);
      pipe_barrier(PIPE_V);
      TROWSUM(v1395, v1380, v1368);
      // pto: %row1_rowsum_inline994__rm_a0_tmp_v2
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1397 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row1_rowsum_inline994__rm_a0_tmp_v2
      ;
      uint64_t v1398 = (uint64_t) v54;
      TASSIGN(v1397, v1398);
      // pto: %row1_rowsum_inline994__row_major_tmp_v3
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1399 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row1_rowsum_inline994__row_major_tmp_v3
      ;
      uint64_t v1400 = (uint64_t) v56;
      TASSIGN(v1399, v1400);
      pipe_barrier(PIPE_V);
      TADDS(v1399, v1397, v92);
      // pto: %row1_rowsum_inline994__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1401 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %row1_rowsum_inline994__ssa_v0
      ;
      uint64_t v1402 = (uint64_t) v56;
      TASSIGN(v1401, v1402);
      // pto: %t__tmp_v84
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1403 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %t__tmp_v84
      ;
      uint64_t v1404 = (uint64_t) v54;
      TASSIGN(v1403, v1404);
      pipe_barrier(PIPE_V);
      TROWSUM(v1403, v1382, v1368);
      // pto: %row2_rowsum_inline995__rm_a0_tmp_v4
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1405 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row2_rowsum_inline995__rm_a0_tmp_v4
      ;
      uint64_t v1406 = (uint64_t) v54;
      TASSIGN(v1405, v1406);
      // pto: %row2_rowsum_inline995__row_major_tmp_v5
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1407 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row2_rowsum_inline995__row_major_tmp_v5
      ;
      uint64_t v1408 = (uint64_t) v49;
      TASSIGN(v1407, v1408);
      pipe_barrier(PIPE_V);
      TADDS(v1407, v1405, v92);
      // pto: %row2_rowsum_inline995__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1409 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %row2_rowsum_inline995__ssa_v0
      ;
      uint64_t v1410 = (uint64_t) v49;
      TASSIGN(v1409, v1410);
      // pto: %t__tmp_v85
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1411 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %t__tmp_v85
      ;
      uint64_t v1412 = (uint64_t) v54;
      TASSIGN(v1411, v1412);
      pipe_barrier(PIPE_V);
      TROWSUM(v1411, v1384, v1368);
      // pto: %row3_rowsum_inline996__rm_a0_tmp_v6
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1413 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row3_rowsum_inline996__rm_a0_tmp_v6
      ;
      uint64_t v1414 = (uint64_t) v54;
      TASSIGN(v1413, v1414);
      // pto: %row3_rowsum_inline996__row_major_tmp_v7
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1415 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row3_rowsum_inline996__row_major_tmp_v7
      ;
      uint64_t v1416 = (uint64_t) v63;
      TASSIGN(v1415, v1416);
      pipe_barrier(PIPE_V);
      TADDS(v1415, v1413, v92);
      // pto: %row3_rowsum_inline996__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1417 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %row3_rowsum_inline996__ssa_v0
      ;
      uint64_t v1418 = (uint64_t) v63;
      TASSIGN(v1417, v1418);
      // pto: %row0_norm_inline997__ssa_v1
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1419 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row0_norm_inline997__ssa_v1
      ;
      uint64_t v1420 = (uint64_t) v54;
      TASSIGN(v1419, v1420);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v1419, v1378, v1393);
      // pto: %row1_norm_inline998__ssa_v1
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1421 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row1_norm_inline998__ssa_v1
      ;
      uint64_t v1422 = (uint64_t) v55;
      TASSIGN(v1421, v1422);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v1421, v1380, v1401);
      // pto: %row2_norm_inline999__ssa_v1
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1423 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row2_norm_inline999__ssa_v1
      ;
      uint64_t v1424 = (uint64_t) v56;
      TASSIGN(v1423, v1424);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v1423, v1382, v1409);
      // pto: %row3_norm_inline1000__ssa_v1
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1425 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row3_norm_inline1000__ssa_v1
      ;
      uint64_t v1426 = (uint64_t) v49;
      TASSIGN(v1425, v1426);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v1425, v1384, v1417);
      // pto: %t__tmp_v86
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1427 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %t__tmp_v86
      ;
      uint64_t v1428 = (uint64_t) v63;
      TASSIGN(v1427, v1428);
      pipe_barrier(PIPE_V);
      TADD(v1427, v1419, v1421);
      // pto: %t__tmp_v87
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1429 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %t__tmp_v87
      ;
      uint64_t v1430 = (uint64_t) v63;
      TASSIGN(v1429, v1430);
      pipe_barrier(PIPE_V);
      TADD(v1429, v1427, v1423);
      // pto: %col_sum_v1_inline987__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1431 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %col_sum_v1_inline987__ssa_v3
      ;
      uint64_t v1432 = (uint64_t) v63;
      TASSIGN(v1431, v1432);
      pipe_barrier(PIPE_V);
      TADD(v1431, v1429, v1425);
      // pto: %col_sum_v1_inline987__ssa_v4
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1433 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %col_sum_v1_inline987__ssa_v4
      ;
      uint64_t v1434 = (uint64_t) v63;
      TASSIGN(v1433, v1434);
      pipe_barrier(PIPE_V);
      TADDS(v1433, v1431, v92);
      // pto: %row0_cur_inline988__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1435 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row0_cur_inline988__ssa_v3
      ;
      uint64_t v1436 = (uint64_t) v54;
      TASSIGN(v1435, v1436);
      pipe_barrier(PIPE_V);
      TDIV(v1435, v1419, v1433);
      // pto: %row1_cur_inline989__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1437 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row1_cur_inline989__ssa_v3
      ;
      uint64_t v1438 = (uint64_t) v55;
      TASSIGN(v1437, v1438);
      TDIV(v1437, v1421, v1433);
      // pto: %row2_cur_inline990__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1439 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row2_cur_inline990__ssa_v3
      ;
      uint64_t v1440 = (uint64_t) v56;
      TASSIGN(v1439, v1440);
      TDIV(v1439, v1423, v1433);
      // pto: %row3_cur_inline991__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1441 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row3_cur_inline991__ssa_v3
      ;
      uint64_t v1442 = (uint64_t) v49;
      TASSIGN(v1441, v1442);
      TDIV(v1441, v1425, v1433);
      // pto: %34
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1443 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %34
      ;
      uint64_t v1444 = (uint64_t) v64;
      TASSIGN(v1443, v1444);
      pipe_barrier(PIPE_V);
      TROWSUM(v1443, v1435, v1368);
      // pto: %35
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1445 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %35
      ;
      uint64_t v1446 = (uint64_t) v64;
      TASSIGN(v1445, v1446);
      // pto: %36
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1447 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %36
      ;
      uint64_t v1448 = (uint64_t) v65;
      TASSIGN(v1447, v1448);
      pipe_barrier(PIPE_V);
      TADDS(v1447, v1445, v92);
      // pto: %37
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1449 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %37
      ;
      uint64_t v1450 = (uint64_t) v65;
      TASSIGN(v1449, v1450);
      // pto: %38
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1451 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %38
      ;
      uint64_t v1452 = (uint64_t) v64;
      TASSIGN(v1451, v1452);
      pipe_barrier(PIPE_V);
      TROWSUM(v1451, v1437, v1368);
      // pto: %39
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1453 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %39
      ;
      uint64_t v1454 = (uint64_t) v64;
      TASSIGN(v1453, v1454);
      // pto: %40
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1455 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %40
      ;
      uint64_t v1456 = (uint64_t) v66;
      TASSIGN(v1455, v1456);
      pipe_barrier(PIPE_V);
      TADDS(v1455, v1453, v92);
      // pto: %41
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1457 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %41
      ;
      uint64_t v1458 = (uint64_t) v66;
      TASSIGN(v1457, v1458);
      // pto: %42
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1459 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %42
      ;
      uint64_t v1460 = (uint64_t) v64;
      TASSIGN(v1459, v1460);
      pipe_barrier(PIPE_V);
      TROWSUM(v1459, v1439, v1368);
      // pto: %43
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1461 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %43
      ;
      uint64_t v1462 = (uint64_t) v64;
      TASSIGN(v1461, v1462);
      // pto: %44
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1463 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %44
      ;
      uint64_t v1464 = (uint64_t) v67;
      TASSIGN(v1463, v1464);
      pipe_barrier(PIPE_V);
      TADDS(v1463, v1461, v92);
      // pto: %45
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1465 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %45
      ;
      uint64_t v1466 = (uint64_t) v67;
      TASSIGN(v1465, v1466);
      // pto: %46
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1467 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %46
      ;
      uint64_t v1468 = (uint64_t) v64;
      TASSIGN(v1467, v1468);
      pipe_barrier(PIPE_V);
      TROWSUM(v1467, v1441, v1368);
      // pto: %47
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1469 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %47
      ;
      uint64_t v1470 = (uint64_t) v64;
      TASSIGN(v1469, v1470);
      // pto: %48
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1471 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %48
      ;
      uint64_t v1472 = (uint64_t) v68;
      TASSIGN(v1471, v1472);
      pipe_barrier(PIPE_V);
      TADDS(v1471, v1469, v92);
      // pto: %49
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1473 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %49
      ;
      uint64_t v1474 = (uint64_t) v68;
      TASSIGN(v1473, v1474);
      // pto: %50
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1475 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %50
      ;
      uint64_t v1476 = (uint64_t) v64;
      TASSIGN(v1475, v1476);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v1475, v1435, v1449);
      // pto: %51
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1477 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %51
      ;
      uint64_t v1478 = (uint64_t) v65;
      TASSIGN(v1477, v1478);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v1477, v1437, v1457);
      // pto: %52
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1479 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %52
      ;
      uint64_t v1480 = (uint64_t) v66;
      TASSIGN(v1479, v1480);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v1479, v1439, v1465);
      // pto: %53
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1481 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %53
      ;
      uint64_t v1482 = (uint64_t) v67;
      TASSIGN(v1481, v1482);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v1481, v1441, v1473);
      // pto: %54
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1483 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %54
      ;
      uint64_t v1484 = (uint64_t) v68;
      TASSIGN(v1483, v1484);
      pipe_barrier(PIPE_V);
      TADD(v1483, v1475, v1477);
      // pto: %55
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1485 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %55
      ;
      uint64_t v1486 = (uint64_t) v68;
      TASSIGN(v1485, v1486);
      pipe_barrier(PIPE_V);
      TADD(v1485, v1483, v1479);
      // pto: %56
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1487 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %56
      ;
      uint64_t v1488 = (uint64_t) v68;
      TASSIGN(v1487, v1488);
      pipe_barrier(PIPE_V);
      TADD(v1487, v1485, v1481);
      // pto: %57
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1489 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %57
      ;
      uint64_t v1490 = (uint64_t) v68;
      TASSIGN(v1489, v1490);
      pipe_barrier(PIPE_V);
      TADDS(v1489, v1487, v92);
      // pto: %58
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1491 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %58
      ;
      uint64_t v1492 = (uint64_t) v47;
      TASSIGN(v1491, v1492);
      pipe_barrier(PIPE_V);
      TDIV(v1491, v1475, v1489);
      // pto: %59
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1493 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %59
      ;
      uint64_t v1494 = (uint64_t) v48;
      TASSIGN(v1493, v1494);
      TDIV(v1493, v1477, v1489);
      // pto: %60
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1495 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %60
      ;
      uint64_t v1496 = (uint64_t) v45;
      TASSIGN(v1495, v1496);
      TDIV(v1495, v1479, v1489);
      // pto: %61
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1497 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %61
      ;
      uint64_t v1498 = (uint64_t) v46;
      TASSIGN(v1497, v1498);
      TDIV(v1497, v1481, v1489);
    };
    // pto: %62
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1499 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %62
    ;
    uint64_t v1500 = (uint64_t) v54;
    TASSIGN(v1499, v1500);
    pipe_barrier(PIPE_V);
    TROWSUM(v1499, v1378, v1368);
    // pto: %63
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1501 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %63
    ;
    uint64_t v1502 = (uint64_t) v54;
    TASSIGN(v1501, v1502);
    // pto: %64
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1503 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %64
    ;
    uint64_t v1504 = (uint64_t) v54;
    TASSIGN(v1503, v1504);
    pipe_barrier(PIPE_V);
    TADDS(v1503, v1501, v92);
    // pto: %65
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1505 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %65
    ;
    uint64_t v1506 = (uint64_t) v54;
    TASSIGN(v1505, v1506);
    // pto: %66
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1507 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %66
    ;
    uint64_t v1508 = (uint64_t) v55;
    TASSIGN(v1507, v1508);
    TROWSUM(v1507, v1380, v1368);
    // pto: %67
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1509 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %67
    ;
    uint64_t v1510 = (uint64_t) v55;
    TASSIGN(v1509, v1510);
    // pto: %68
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1511 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %68
    ;
    uint64_t v1512 = (uint64_t) v55;
    TASSIGN(v1511, v1512);
    pipe_barrier(PIPE_V);
    TADDS(v1511, v1509, v92);
    // pto: %69
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1513 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %69
    ;
    uint64_t v1514 = (uint64_t) v55;
    TASSIGN(v1513, v1514);
    // pto: %70
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1515 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %70
    ;
    uint64_t v1516 = (uint64_t) v56;
    TASSIGN(v1515, v1516);
    TROWSUM(v1515, v1382, v1368);
    // pto: %71
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1517 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %71
    ;
    uint64_t v1518 = (uint64_t) v56;
    TASSIGN(v1517, v1518);
    // pto: %72
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1519 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %72
    ;
    uint64_t v1520 = (uint64_t) v56;
    TASSIGN(v1519, v1520);
    pipe_barrier(PIPE_V);
    TADDS(v1519, v1517, v92);
    // pto: %73
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1521 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %73
    ;
    uint64_t v1522 = (uint64_t) v56;
    TASSIGN(v1521, v1522);
    // pto: %74
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1523 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %74
    ;
    uint64_t v1524 = (uint64_t) v49;
    TASSIGN(v1523, v1524);
    TROWSUM(v1523, v1384, v1368);
    // pto: %75
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1525 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %75
    ;
    uint64_t v1526 = (uint64_t) v49;
    TASSIGN(v1525, v1526);
    // pto: %76
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1527 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %76
    ;
    uint64_t v1528 = (uint64_t) v53;
    TASSIGN(v1527, v1528);
    pipe_barrier(PIPE_V);
    TADDS(v1527, v1525, v92);
    // pto: %77
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1529 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %77
    ;
    uint64_t v1530 = (uint64_t) v53;
    TASSIGN(v1529, v1530);
    // pto: %78
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1531 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %78
    ;
    uint64_t v1532 = (uint64_t) v47;
    TASSIGN(v1531, v1532);
    TROWEXPANDDIV(v1531, v1378, v1505);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %79
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1533 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %79
    ;
    uint64_t v1534 = (uint64_t) v48;
    TASSIGN(v1533, v1534);
    TROWEXPANDDIV(v1533, v1380, v1513);
    // pto: %80
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1535 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %80
    ;
    uint64_t v1536 = (uint64_t) v45;
    TASSIGN(v1535, v1536);
    TROWEXPANDDIV(v1535, v1382, v1521);
    // pto: %81
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1537 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %81
    ;
    uint64_t v1538 = (uint64_t) v46;
    TASSIGN(v1537, v1538);
    pipe_barrier(PIPE_V);
    TROWEXPANDDIV(v1537, v1384, v1529);
    // pto: %82
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1539 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %82
    ;
    uint64_t v1540 = (uint64_t) v53;
    TASSIGN(v1539, v1540);
    pipe_barrier(PIPE_V);
    TADD(v1539, v1531, v1533);
    // pto: %83
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1541 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %83
    ;
    uint64_t v1542 = (uint64_t) v53;
    TASSIGN(v1541, v1542);
    pipe_barrier(PIPE_V);
    TADD(v1541, v1539, v1535);
    // pto: %84
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1543 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %84
    ;
    uint64_t v1544 = (uint64_t) v53;
    TASSIGN(v1543, v1544);
    pipe_barrier(PIPE_V);
    TADD(v1543, v1541, v1537);
    // pto: %85
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1545 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %85
    ;
    uint64_t v1546 = (uint64_t) v53;
    TASSIGN(v1545, v1546);
    pipe_barrier(PIPE_V);
    TADDS(v1545, v1543, v92);
    // pto: %86
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1547 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %86
    ;
    uint64_t v1548 = (uint64_t) v47;
    TASSIGN(v1547, v1548);
    pipe_barrier(PIPE_V);
    TDIV(v1547, v1531, v1545);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %87
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1549 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %87
    ;
    uint64_t v1550 = (uint64_t) v48;
    TASSIGN(v1549, v1550);
    TDIV(v1549, v1533, v1545);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %88
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1551 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %88
    ;
    uint64_t v1552 = (uint64_t) v45;
    TASSIGN(v1551, v1552);
    TDIV(v1551, v1535, v1545);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
    // pto: %89
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1553 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %89
    ;
    uint64_t v1554 = (uint64_t) v46;
    TASSIGN(v1553, v1554);
    TDIV(v1553, v1537, v1545);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    // pto: %row0_cur_inline988__rv_v2
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1555 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row0_cur_inline988__rv_v2
    ;
    uint64_t v1556 = (uint64_t) v47;
    TASSIGN(v1555, v1556);
    // pto: %row1_cur_inline989__rv_v2
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1557 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row1_cur_inline989__rv_v2
    ;
    uint64_t v1558 = (uint64_t) v48;
    TASSIGN(v1557, v1558);
    // pto: %row2_cur_inline990__rv_v2
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1559 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row2_cur_inline990__rv_v2
    ;
    uint64_t v1560 = (uint64_t) v45;
    TASSIGN(v1559, v1560);
    // pto: %row3_cur_inline991__rv_v2
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1561 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row3_cur_inline991__rv_v2
    ;
    uint64_t v1562 = (uint64_t) v46;
    TASSIGN(v1561, v1562);
    // pto: %425
    ;
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
    if (v1180 == v79) {
      v1555.SetValidShape(v79, v77);
      v1557.SetValidShape(v79, v77);
      v1559.SetValidShape(v79, v77);
      v1561.SetValidShape(v79, v77);
      // pto: %comb__ssa_v0_pview
      ;
      __gm__ float* v1563 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %comb__ssa_v0_pview
      ;
      const int64_t v1564 = 0;
      // pto: %comb__ssa_v0_pview
      ;
      const int64_t v1565 = 16;
      // pto: %comb__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 4> v1566 = pto::Shape<1, 1, 1, 8, 4>();
      // pto: %comb__ssa_v0_pview
      ;
      pto::Stride<128, 128, 128, 16, 1> v1567 = pto::Stride<128, 128, 128, 16, 1>();
      // pto: %comb__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND> v1568 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND>(v1563 + (v1564 + v1183 * v1565), v1566, v1567);
      TSTORE(v1568, v1555);
      // pto: %428
      ;
      __gm__ float* v1569 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %428
      ;
      const int64_t v1570 = 4;
      // pto: %428
      ;
      const int64_t v1571 = 16;
      // pto: %428
      ;
      pto::Shape<1, 1, 1, 8, 4> v1572 = pto::Shape<1, 1, 1, 8, 4>();
      // pto: %428
      ;
      pto::Stride<128, 128, 128, 16, 1> v1573 = pto::Stride<128, 128, 128, 16, 1>();
      // pto: %428
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND> v1574 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND>(v1569 + (v1570 + v1183 * v1571), v1572, v1573);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1574, v1557);
      // pto: %430
      ;
      __gm__ float* v1575 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %430
      ;
      const int64_t v1576 = 8;
      // pto: %430
      ;
      const int64_t v1577 = 16;
      // pto: %430
      ;
      pto::Shape<1, 1, 1, 8, 4> v1578 = pto::Shape<1, 1, 1, 8, 4>();
      // pto: %430
      ;
      pto::Stride<128, 128, 128, 16, 1> v1579 = pto::Stride<128, 128, 128, 16, 1>();
      // pto: %430
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND> v1580 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND>(v1575 + (v1576 + v1183 * v1577), v1578, v1579);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1580, v1559);
      // pto: %432
      ;
      __gm__ float* v1581 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %432
      ;
      const int64_t v1582 = 12;
      // pto: %432
      ;
      const int64_t v1583 = 16;
      // pto: %432
      ;
      pto::Shape<1, 1, 1, 8, 4> v1584 = pto::Shape<1, 1, 1, 8, 4>();
      // pto: %432
      ;
      pto::Stride<128, 128, 128, 16, 1> v1585 = pto::Stride<128, 128, 128, 16, 1>();
      // pto: %432
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND> v1586 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND>(v1581 + (v1582 + v1183 * v1583), v1584, v1585);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1586, v1561);
    } else {
      // pto: %434
      ;
      int64_t v1587 = v489 < v82 ? v82 : v489;
      // pto: %435
      ;
      __gm__ float* v1588 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %435
      ;
      const int64_t v1589 = 8;
      // pto: %435
      ;
      const int64_t v1590 = 64;
      // pto: %435
      ;
      pto::Shape<1, 1, 1, 8, 8> v1591 = pto::Shape<1, 1, 1, 8, 8>();
      // pto: %435
      ;
      pto::Stride<512, 512, 512, 64, 1> v1592 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %435
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v1593 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v1588 + (v1589 + v1587 * v1590), v1591, v1592);
      TSTORE(v1593, v1555);
      // pto: %438
      ;
      __gm__ float* v1594 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %438
      ;
      const int64_t v1595 = 16;
      // pto: %438
      ;
      const int64_t v1596 = 64;
      // pto: %438
      ;
      pto::Shape<1, 1, 1, 8, 8> v1597 = pto::Shape<1, 1, 1, 8, 8>();
      // pto: %438
      ;
      pto::Stride<512, 512, 512, 64, 1> v1598 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %438
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v1599 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v1594 + (v1595 + v1587 * v1596), v1597, v1598);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1599, v1557);
      // pto: %441
      ;
      __gm__ float* v1600 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %441
      ;
      const int64_t v1601 = 24;
      // pto: %441
      ;
      const int64_t v1602 = 64;
      // pto: %441
      ;
      pto::Shape<1, 1, 1, 8, 8> v1603 = pto::Shape<1, 1, 1, 8, 8>();
      // pto: %441
      ;
      pto::Stride<512, 512, 512, 64, 1> v1604 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %441
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v1605 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v1600 + (v1601 + v1587 * v1602), v1603, v1604);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1605, v1559);
      // pto: %444
      ;
      __gm__ float* v1606 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %444
      ;
      const int64_t v1607 = 32;
      // pto: %444
      ;
      const int64_t v1608 = 64;
      // pto: %444
      ;
      pto::Shape<1, 1, 1, 8, 8> v1609 = pto::Shape<1, 1, 1, 8, 8>();
      // pto: %444
      ;
      pto::Stride<512, 512, 512, 64, 1> v1610 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %444
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v1611 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v1606 + (v1607 + v1587 * v1608), v1609, v1610);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1611, v1561);
      // pto: %row0_tail_inline1005__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1612 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
      // pto: %row0_tail_inline1005__ssa_v0
      ;
      uint64_t v1613 = (uint64_t) v47;
      TASSIGN(v1612, v1613);
      // pto: %447
      ;
      const int64_t v1614 = 0;
      // pto: %447
      ;
      __gm__ float* v1615 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %447
      ;
      const int64_t v1616 = 1;
      // pto: %447
      ;
      const int64_t v1617 = 1;
      // pto: %447
      ;
      const int64_t v1618 = 1;
      // pto: %447
      ;
      int64_t v1619 = v1180 * v76;
      // pto: %447
      ;
      int64_t v1620 = v1618 * v1619;
      // pto: %447
      ;
      pto::Shape<1, 1, 1, -1, 4> v1621 = pto::Shape<1, 1, 1, -1, 4>(v1616, v1617, v1618, v1180, v77);
      // pto: %447
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1622 = pto::Stride<-1, -1, -1, -1, -1>(v1617 * v1620, v1620, v1619, v76, v70);
      // pto: %447
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1623 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1615 + (v1614 + v1587 * v76 + v79 * v70), v1621, v1622);
      pipe_barrier(PIPE_ALL);
      TLOAD(v1612, v1623);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID4);
      // pto: %row1_tail_inline1006__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1624 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
      // pto: %row1_tail_inline1006__ssa_v0
      ;
      uint64_t v1625 = (uint64_t) v48;
      TASSIGN(v1624, v1625);
      // pto: %450
      ;
      const int64_t v1626 = 0;
      // pto: %450
      ;
      __gm__ float* v1627 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %450
      ;
      const int64_t v1628 = 1;
      // pto: %450
      ;
      const int64_t v1629 = 1;
      // pto: %450
      ;
      const int64_t v1630 = 1;
      // pto: %450
      ;
      int64_t v1631 = v1180 * v76;
      // pto: %450
      ;
      int64_t v1632 = v1630 * v1631;
      // pto: %450
      ;
      pto::Shape<1, 1, 1, -1, 4> v1633 = pto::Shape<1, 1, 1, -1, 4>(v1628, v1629, v1630, v1180, v77);
      // pto: %450
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1634 = pto::Stride<-1, -1, -1, -1, -1>(v1629 * v1632, v1632, v1631, v76, v70);
      // pto: %450
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1635 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1627 + (v1626 + v1587 * v76 + v71 * v70), v1633, v1634);
      TLOAD(v1624, v1635);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID5);
      // pto: %row2_tail_inline1007__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1636 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
      // pto: %row2_tail_inline1007__ssa_v0
      ;
      uint64_t v1637 = (uint64_t) v45;
      TASSIGN(v1636, v1637);
      // pto: %453
      ;
      const int64_t v1638 = 0;
      // pto: %453
      ;
      __gm__ float* v1639 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %453
      ;
      const int64_t v1640 = 1;
      // pto: %453
      ;
      const int64_t v1641 = 1;
      // pto: %453
      ;
      const int64_t v1642 = 1;
      // pto: %453
      ;
      int64_t v1643 = v1180 * v76;
      // pto: %453
      ;
      int64_t v1644 = v1642 * v1643;
      // pto: %453
      ;
      pto::Shape<1, 1, 1, -1, 4> v1645 = pto::Shape<1, 1, 1, -1, 4>(v1640, v1641, v1642, v1180, v77);
      // pto: %453
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1646 = pto::Stride<-1, -1, -1, -1, -1>(v1641 * v1644, v1644, v1643, v76, v70);
      // pto: %453
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1647 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1639 + (v1638 + v1587 * v76 + v78 * v70), v1645, v1646);
      TLOAD(v1636, v1647);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID6);
      // pto: %row3_tail_inline1008__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1648 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1180, v77);
      // pto: %row3_tail_inline1008__ssa_v0
      ;
      uint64_t v1649 = (uint64_t) v46;
      TASSIGN(v1648, v1649);
      // pto: %456
      ;
      const int64_t v1650 = 0;
      // pto: %456
      ;
      __gm__ float* v1651 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %456
      ;
      const int64_t v1652 = 1;
      // pto: %456
      ;
      const int64_t v1653 = 1;
      // pto: %456
      ;
      const int64_t v1654 = 1;
      // pto: %456
      ;
      int64_t v1655 = v1180 * v76;
      // pto: %456
      ;
      int64_t v1656 = v1654 * v1655;
      // pto: %456
      ;
      pto::Shape<1, 1, 1, -1, 4> v1657 = pto::Shape<1, 1, 1, -1, 4>(v1652, v1653, v1654, v1180, v77);
      // pto: %456
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1658 = pto::Stride<-1, -1, -1, -1, -1>(v1653 * v1656, v1656, v1655, v76, v70);
      // pto: %456
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1659 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1651 + (v1650 + v1587 * v76 + v73 * v70), v1657, v1658);
      TLOAD(v1648, v1659);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID7);
      // pto: %458
      ;
      const int64_t v1660 = 0;
      // pto: %458
      ;
      __gm__ float* v1661 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %458
      ;
      const int64_t v1662 = 1;
      // pto: %458
      ;
      const int64_t v1663 = 1;
      // pto: %458
      ;
      const int64_t v1664 = 1;
      // pto: %458
      ;
      int64_t v1665 = v1180 * v71;
      // pto: %458
      ;
      int64_t v1666 = v1664 * v1665;
      // pto: %458
      ;
      pto::Shape<1, 1, 1, -1, 4> v1667 = pto::Shape<1, 1, 1, -1, 4>(v1662, v1663, v1664, v1180, v77);
      // pto: %458
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1668 = pto::Stride<-1, -1, -1, -1, -1>(v1663 * v1666, v1666, v1665, v71, v70);
      // pto: %458
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1669 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1661 + (v1660 + v1183 * v71 + v82 * v70), v1667, v1668);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID4);
      TSTORE(v1669, v1612);
      // pto: %460
      ;
      const int64_t v1670 = 0;
      // pto: %460
      ;
      __gm__ float* v1671 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %460
      ;
      const int64_t v1672 = 1;
      // pto: %460
      ;
      const int64_t v1673 = 1;
      // pto: %460
      ;
      const int64_t v1674 = 1;
      // pto: %460
      ;
      int64_t v1675 = v1180 * v71;
      // pto: %460
      ;
      int64_t v1676 = v1674 * v1675;
      // pto: %460
      ;
      pto::Shape<1, 1, 1, -1, 4> v1677 = pto::Shape<1, 1, 1, -1, 4>(v1672, v1673, v1674, v1180, v77);
      // pto: %460
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1678 = pto::Stride<-1, -1, -1, -1, -1>(v1673 * v1676, v1676, v1675, v71, v70);
      // pto: %460
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1679 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1671 + (v1670 + v1183 * v71 + v77 * v70), v1677, v1678);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID5);
      TSTORE(v1679, v1624);
      // pto: %462
      ;
      const int64_t v1680 = 0;
      // pto: %462
      ;
      __gm__ float* v1681 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %462
      ;
      const int64_t v1682 = 1;
      // pto: %462
      ;
      const int64_t v1683 = 1;
      // pto: %462
      ;
      const int64_t v1684 = 1;
      // pto: %462
      ;
      int64_t v1685 = v1180 * v71;
      // pto: %462
      ;
      int64_t v1686 = v1684 * v1685;
      // pto: %462
      ;
      pto::Shape<1, 1, 1, -1, 4> v1687 = pto::Shape<1, 1, 1, -1, 4>(v1682, v1683, v1684, v1180, v77);
      // pto: %462
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1688 = pto::Stride<-1, -1, -1, -1, -1>(v1683 * v1686, v1686, v1685, v71, v70);
      // pto: %462
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1689 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1681 + (v1680 + v1183 * v71 + v79 * v70), v1687, v1688);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID6);
      TSTORE(v1689, v1636);
      // pto: %464
      ;
      const int64_t v1690 = 0;
      // pto: %464
      ;
      __gm__ float* v1691 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %464
      ;
      const int64_t v1692 = 1;
      // pto: %464
      ;
      const int64_t v1693 = 1;
      // pto: %464
      ;
      const int64_t v1694 = 1;
      // pto: %464
      ;
      int64_t v1695 = v1180 * v71;
      // pto: %464
      ;
      int64_t v1696 = v1694 * v1695;
      // pto: %464
      ;
      pto::Shape<1, 1, 1, -1, 4> v1697 = pto::Shape<1, 1, 1, -1, 4>(v1692, v1693, v1694, v1180, v77);
      // pto: %464
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1698 = pto::Stride<-1, -1, -1, -1, -1>(v1693 * v1696, v1696, v1695, v71, v70);
      // pto: %464
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1699 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1691 + (v1690 + v1183 * v71 + v106 * v70), v1697, v1698);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID7);
      TSTORE(v1699, v1648);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %465
  int64_t v1700 = (int64_t) ((uint64_t) v32 + (uint64_t) v108);
  // pto: %466
  const int64_t v1701 = 1;
  // pto: %466
  const int64_t v1702 = 0;
  // pto: %466
  int64_t v1703 = v1700 / v71;
  // pto: %466
  bool v1704 = v1700 < v1702;
  // pto: %466
  bool v1705 = v71 < v1702;
  // pto: %466
  bool v1706 = v1704 == v1705;
  // pto: %466
  bool v1707 = v1700 % v71 != v1702 && v1704 != v1705;
  // pto: %466
  int64_t v1708 = v1707 ? v1703 - v1701 : v1703;
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v1709 = v291; v1709 < v1708; v1709 += v81) {
    // pto: %467
    ;
    int64_t v1710 = (int64_t) ((uint64_t) v1709 * (uint64_t) v71);
    // pto: %468
    ;
    int64_t v1711 = (int64_t) ((uint64_t) v32 - (uint64_t) v1710);
    // pto: %469
    ;
    int64_t v1712 = v1711 < v71 ? v1711 : v71;
    // pto: %projected_inline1014__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1713 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1712, v75);
    // pto: %projected_inline1014__ssa_v0
    ;
    uint64_t v1714 = (uint64_t) v47;
    TASSIGN(v1713, v1714);
    // pto: %470
    ;
    int64_t v1715 = v1710 < v82 ? v82 : v1710;
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    const int64_t v1716 = 0;
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    __gm__ float* v1717 = PTOAS__GLOBAL_TENSOR_DATA(v244);
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    const int64_t v1718 = 1;
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    const int64_t v1719 = 1;
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    const int64_t v1720 = 1;
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    int64_t v1721 = v1712 * v75;
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    int64_t v1722 = v1720 * v1721;
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v1723 = pto::Shape<1, 1, 1, -1, 512>(v1718, v1719, v1720, v1712, v75);
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1724 = pto::Stride<-1, -1, -1, -1, -1>(v1719 * v1722, v1722, v1721, v75, v70);
    // pto: %spmd_accum_read__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1725 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1717 + (v1716 + v1715 * v75 + v82 * v70), v1723, v1724);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v1713, v1725);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %rounded_inline1015__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1726 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1712, v75);
    // pto: %rounded_inline1015__ssa_v0
    ;
    uint64_t v1727 = (uint64_t) v47;
    TASSIGN(v1726, v1727);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v1728 = RoundMode::CAST_RINT;
    SaturationMode v1729 = SaturationMode::ON;
    TCVT(v1726, v1713, v1728, v1729);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %projected_kv__ssa_v0_pview
    ;
    const int64_t v1730 = 0;
    // pto: %projected_kv__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v1731 = PTOAS__GLOBAL_TENSOR_DATA(v253);
    // pto: %projected_kv__ssa_v0_pview
    ;
    const int64_t v1732 = 1;
    // pto: %projected_kv__ssa_v0_pview
    ;
    const int64_t v1733 = 1;
    // pto: %projected_kv__ssa_v0_pview
    ;
    const int64_t v1734 = 1;
    // pto: %projected_kv__ssa_v0_pview
    ;
    int64_t v1735 = v1712 * v75;
    // pto: %projected_kv__ssa_v0_pview
    ;
    int64_t v1736 = v1734 * v1735;
    // pto: %projected_kv__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v1737 = pto::Shape<1, 1, 1, -1, 512>(v1732, v1733, v1734, v1712, v75);
    // pto: %projected_kv__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1738 = pto::Stride<-1, -1, -1, -1, -1>(v1733 * v1736, v1736, v1735, v75, v70);
    // pto: %projected_kv__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1739 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1731 + (v1730 + v1715 * v75 + v82 * v70), v1737, v1738);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1739, v1726);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v1740 = v291; v1740 < v1708; v1740 += v81) {
    // pto: %474
    ;
    int64_t v1741 = (int64_t) ((uint64_t) v1740 * (uint64_t) v71);
    // pto: %475
    ;
    int64_t v1742 = (int64_t) ((uint64_t) v32 - (uint64_t) v1741);
    // pto: %476
    ;
    int64_t v1743 = v1742 < v71 ? v1742 : v71;
    // pto: %value_inline1021__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1744 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1743, v76);
    // pto: %value_inline1021__ssa_v0
    ;
    uint64_t v1745 = (uint64_t) v47;
    TASSIGN(v1744, v1745);
    // pto: %477
    ;
    int64_t v1746 = v1741 < v82 ? v82 : v1741;
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    const int64_t v1747 = 0;
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    __gm__ float* v1748 = PTOAS__GLOBAL_TENSOR_DATA(v262);
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    const int64_t v1749 = 1;
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    const int64_t v1750 = 1;
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    const int64_t v1751 = 1;
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    int64_t v1752 = v1743 * v76;
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    int64_t v1753 = v1751 * v1752;
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 64> v1754 = pto::Shape<1, 1, 1, -1, 64>(v1749, v1750, v1751, v1743, v76);
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1755 = pto::Stride<-1, -1, -1, -1, -1>(v1750 * v1753, v1753, v1752, v76, v70);
    // pto: %spmd_idx_accum_read__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1756 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1748 + (v1747 + v1746 * v76 + v82 * v70), v1754, v1755);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v1744, v1756);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %projected_inline1022__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1757 = Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1743, v76);
    // pto: %projected_inline1022__ssa_v0
    ;
    uint64_t v1758 = (uint64_t) v48;
    TASSIGN(v1757, v1758);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    pipe_barrier(PIPE_V);
    RoundMode v1759 = RoundMode::CAST_RINT;
    SaturationMode v1760 = SaturationMode::ON;
    TCVT(v1757, v1744, v1759, v1760);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %indexer_raw__ssa_v0_pview
    ;
    const int64_t v1761 = 0;
    // pto: %indexer_raw__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v1762 = PTOAS__GLOBAL_TENSOR_DATA(v271);
    // pto: %indexer_raw__ssa_v0_pview
    ;
    const int64_t v1763 = 1;
    // pto: %indexer_raw__ssa_v0_pview
    ;
    const int64_t v1764 = 1;
    // pto: %indexer_raw__ssa_v0_pview
    ;
    const int64_t v1765 = 1;
    // pto: %indexer_raw__ssa_v0_pview
    ;
    int64_t v1766 = v1743 * v76;
    // pto: %indexer_raw__ssa_v0_pview
    ;
    int64_t v1767 = v1765 * v1766;
    // pto: %indexer_raw__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 64> v1768 = pto::Shape<1, 1, 1, -1, 64>(v1763, v1764, v1765, v1743, v76);
    // pto: %indexer_raw__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1769 = pto::Stride<-1, -1, -1, -1, -1>(v1764 * v1767, v1767, v1766, v76, v70);
    // pto: %indexer_raw__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1770 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1762 + (v1761 + v1746 * v76 + v82 * v70), v1768, v1769);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1770, v1757);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    // pto: %value_v1_inline1023__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1771 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1743, v76);
    // pto: %value_v1_inline1023__ssa_v0
    ;
    uint64_t v1772 = (uint64_t) v47;
    TASSIGN(v1771, v1772);
    pipe_barrier(PIPE_V);
    RoundMode v1773 = RoundMode::CAST_ROUND;
    SaturationMode v1774 = SaturationMode::ON;
    TCVT(v1771, v1757, v1773, v1774);
    // pto: %value_v2_inline1024__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1775 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1743, v76);
    // pto: %value_v2_inline1024__ssa_v0
    ;
    uint64_t v1776 = (uint64_t) v47;
    TASSIGN(v1775, v1776);
    pipe_barrier(PIPE_V);
    TMULS(v1775, v1771, v109);
    // pto: %weighted_inline1025__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1777 = Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1743, v76);
    // pto: %weighted_inline1025__ssa_v0
    ;
    uint64_t v1778 = (uint64_t) v48;
    TASSIGN(v1777, v1778);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    RoundMode v1779 = RoundMode::CAST_RINT;
    SaturationMode v1780 = SaturationMode::ON;
    TCVT(v1777, v1775, v1779, v1780);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    const int64_t v1781 = 0;
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v1782 = PTOAS__GLOBAL_TENSOR_DATA(v280);
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    const int64_t v1783 = 1;
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    const int64_t v1784 = 1;
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    const int64_t v1785 = 1;
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    int64_t v1786 = v1743 * v76;
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    int64_t v1787 = v1785 * v1786;
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 64> v1788 = pto::Shape<1, 1, 1, -1, 64>(v1783, v1784, v1785, v1743, v76);
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1789 = pto::Stride<-1, -1, -1, -1, -1>(v1784 * v1787, v1787, v1786, v76, v70);
    // pto: %indexer_scaled__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1790 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1782 + (v1781 + v1746 * v76 + v82 * v70), v1788, v1789);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1790, v1777);
    // pto: %result_inline1026__cast_fp32_tmp_v0
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1791 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1743, v76);
    // pto: %result_inline1026__cast_fp32_tmp_v0
    ;
    uint64_t v1792 = (uint64_t) v47;
    TASSIGN(v1791, v1792);
    pipe_barrier(PIPE_V);
    RoundMode v1793 = RoundMode::CAST_RINT;
    SaturationMode v1794 = SaturationMode::ON;
    TCVT(v1791, v1777, v1793, v1794);
    // pto: %result_inline1026__ssa_v0
    ;
    Tile<TileType::Vec, half, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1795 = Tile<TileType::Vec, half, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1743, v76);
    // pto: %result_inline1026__ssa_v0
    ;
    uint64_t v1796 = (uint64_t) v47;
    TASSIGN(v1795, v1796);
    pipe_barrier(PIPE_V);
    RoundMode v1797 = RoundMode::CAST_RINT;
    SaturationMode v1798 = SaturationMode::ON;
    TCVT(v1795, v1791, v1797, v1798);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %indexer_weights__ssa_v0_pview
    ;
    const int64_t v1799 = 0;
    // pto: %indexer_weights__ssa_v0_pview
    ;
    __gm__ half* v1800 = PTOAS__GLOBAL_TENSOR_DATA(v289);
    // pto: %indexer_weights__ssa_v0_pview
    ;
    const int64_t v1801 = 1;
    // pto: %indexer_weights__ssa_v0_pview
    ;
    const int64_t v1802 = 1;
    // pto: %indexer_weights__ssa_v0_pview
    ;
    const int64_t v1803 = 1;
    // pto: %indexer_weights__ssa_v0_pview
    ;
    int64_t v1804 = v1743 * v76;
    // pto: %indexer_weights__ssa_v0_pview
    ;
    int64_t v1805 = v1803 * v1804;
    // pto: %indexer_weights__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 64> v1806 = pto::Shape<1, 1, 1, -1, 64>(v1801, v1802, v1803, v1743, v76);
    // pto: %indexer_weights__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1807 = pto::Stride<-1, -1, -1, -1, -1>(v1802 * v1805, v1805, v1804, v76, v70);
    // pto: %indexer_weights__ssa_v0_pview
    ;
    GlobalTensor<half, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1808 = GlobalTensor<half, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1800 + (v1799 + v1746 * v76 + v82 * v70), v1806, v1807);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1808, v1795);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID5);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}