#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_a_bf16(__gm__ float* v1, __gm__ bfloat16_t* v2, int64_t v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v8 = 0;
  // pto: %c8192_index
  const int64_t v9 = 8192;
  // pto: %c1_index
  const int64_t v10 = 1;
  // pto: %c8_index
  const int64_t v11 = 8;
  // pto: %c16_index
  const int64_t v12 = 16;
  // pto: %c0_index
  const int64_t v13 = 0;
  // pto: %c1024_index
  const int64_t v14 = 1024;
  // pto: %c127_index
  const int64_t v15 = 127;
  // pto: %13
  int64_t v16 = (int64_t) ((uint64_t) v4 + (uint64_t) v15);
  // pto: %accum_inline5396__phi_v21_view
  const int64_t v17 = 1;
  // pto: %accum_inline5396__phi_v21_view
  const int64_t v18 = 1;
  // pto: %accum_inline5396__phi_v21_view
  const int64_t v19 = 1;
  // pto: %accum_inline5396__phi_v21_view
  int64_t v20 = v16 * v9;
  // pto: %accum_inline5396__phi_v21_view
  int64_t v21 = v19 * v20;
  // pto: %accum_inline5396__phi_v21_view
  pto::Shape<1, 1, 1, -1, -1> v22 = pto::Shape<1, 1, 1, -1, -1>(v17, v18, v19, v16, v9);
  // pto: %accum_inline5396__phi_v21_view
  pto::Stride<-1, -1, -1, -1, -1> v23 = pto::Stride<-1, -1, -1, -1, -1>(v18 * v21, v21, v20, v9, v10);
  // pto: %accum_inline5396__phi_v21_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v24 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v22, v23);
  // pto: %projected_o__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %projected_o__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %projected_o__ssa_v0_view
  const int64_t v27 = 1;
  // pto: %projected_o__ssa_v0_view
  int64_t v28 = (int64_t) v5;
  // pto: %projected_o__ssa_v0_view
  int64_t v29 = v28 * v9;
  // pto: %projected_o__ssa_v0_view
  int64_t v30 = v27 * v29;
  // pto: %projected_o__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v31 = pto::Shape<1, 1, 1, -1, -1>(v25, v26, v27, v28, v9);
  // pto: %projected_o__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v32 = pto::Stride<-1, -1, -1, -1, -1>(v26 * v30, v30, v29, v9, v10);
  // pto: %projected_o__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v33 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v31, v32);
  // pto: %block_inline5476__ssa_v0
  int64_t v34 = (int64_t) v6;
  // pto: %0
  const int64_t v35 = 1;
  // pto: %0
  const int64_t v36 = 0;
  // pto: %0
  int64_t v37 = v34 / v11;
  // pto: %0
  bool v38 = v34 < v36;
  // pto: %0
  bool v39 = v11 < v36;
  // pto: %0
  bool v40 = v38 == v39;
  // pto: %0
  bool v41 = v34 % v11 != v36 && v38 != v39;
  // pto: %0
  int64_t v42 = v41 ? v37 - v35 : v37;
  // pto: %1
  int64_t v43 = (int64_t) ((uint64_t) v42 * (uint64_t) v12);
  // pto: %2
  int64_t v44 = v34 % v11;
  // pto: %3, %4, %5
  int64_t v45 = v44 < v13 ? (int64_t) ((uint64_t) v44 + (uint64_t) v11) : v44;
  // pto: %6
  int64_t v46 = (int64_t) ((uint64_t) v45 * (uint64_t) v14);
  // pto: %7
  int64_t v47 = (int64_t) ((uint64_t) v4 - (uint64_t) v43);
  // pto: %8
  int64_t v48 = v47 < v12 ? v47 : v12;
  // pto: %oa_value_inline5480__ssa_v0
  Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v49 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v14);
  // pto: %oa_value_inline5480__ssa_v0
  uint64_t v50 = (uint64_t) v8;
  TASSIGN(v49, v50);
  // pto: %9
  int64_t v51 = v43 < v13 ? v13 : v43;
  // pto: %10
  int64_t v52 = v46 < v13 ? v13 : v46;
  // pto: %accum_inline5396__phi_v21_pview
  const int64_t v53 = 0;
  // pto: %accum_inline5396__phi_v21_pview
  __gm__ float* v54 = PTOAS__GLOBAL_TENSOR_DATA(v24);
  // pto: %accum_inline5396__phi_v21_pview
  const int64_t v55 = 1;
  // pto: %accum_inline5396__phi_v21_pview
  const int64_t v56 = 1;
  // pto: %accum_inline5396__phi_v21_pview
  const int64_t v57 = 1;
  // pto: %accum_inline5396__phi_v21_pview
  int64_t v58 = v48 * v9;
  // pto: %accum_inline5396__phi_v21_pview
  int64_t v59 = v57 * v58;
  // pto: %accum_inline5396__phi_v21_pview
  pto::Shape<1, 1, 1, -1, 1024> v60 = pto::Shape<1, 1, 1, -1, 1024>(v55, v56, v57, v48, v14);
  // pto: %accum_inline5396__phi_v21_pview
  pto::Stride<-1, -1, -1, -1, -1> v61 = pto::Stride<-1, -1, -1, -1, -1>(v56 * v59, v59, v58, v9, v10);
  // pto: %accum_inline5396__phi_v21_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v62 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v54 + (v53 + v51 * v9 + v52 * v10), v60, v61);
  TLOAD(v49, v62);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %t__tmp_v1013
  Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v63 = Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v14);
  // pto: %t__tmp_v1013
  uint64_t v64 = (uint64_t) v8;
  TASSIGN(v63, v64);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  RoundMode v65 = RoundMode::CAST_RINT;
  SaturationMode v66 = SaturationMode::ON;
  TCVT(v63, v49, v65, v66);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %projected_o__ssa_v0_pview
  const int64_t v67 = 0;
  // pto: %projected_o__ssa_v0_pview
  __gm__ bfloat16_t* v68 = PTOAS__GLOBAL_TENSOR_DATA(v33);
  // pto: %projected_o__ssa_v0_pview
  const int64_t v69 = 1;
  // pto: %projected_o__ssa_v0_pview
  const int64_t v70 = 1;
  // pto: %projected_o__ssa_v0_pview
  const int64_t v71 = 1;
  // pto: %projected_o__ssa_v0_pview
  int64_t v72 = v48 * v9;
  // pto: %projected_o__ssa_v0_pview
  int64_t v73 = v71 * v72;
  // pto: %projected_o__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 1024> v74 = pto::Shape<1, 1, 1, -1, 1024>(v69, v70, v71, v48, v14);
  // pto: %projected_o__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v75 = pto::Stride<-1, -1, -1, -1, -1>(v70 * v73, v73, v72, v9, v10);
  // pto: %projected_o__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v76 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v68 + (v67 + v51 * v9 + v52 * v10), v74, v75);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v76, v63);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}