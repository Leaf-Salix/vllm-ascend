#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void indexer_head_coefficients_0(__gm__ int32_t* v1, __gm__ int32_t* v2, __gm__ float* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ half* v6, int32_t v7, int32_t v8) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v9 = 384;
  // pto: %c0_i64
  const int64_t v10 = 0;
  // pto: %c4096_i64
  const int64_t v11 = 4096;
  // pto: %c4608_i64
  const int64_t v12 = 4608;
  // pto: %c1_index
  const int64_t v13 = 1;
  // pto: %c432_index
  const int64_t v14 = 432;
  // pto: %c64_index
  const int64_t v15 = 64;
  // pto: %c3456_index
  const int64_t v16 = 3456;
  // pto: %c128_index
  const int64_t v17 = 128;
  // pto: %c0_index
  const int64_t v18 = 0;
  // pto: %c48_index
  const int64_t v19 = 48;
  // pto: %c32_index
  const int64_t v20 = 32;
  // pto: %cst_11
  const half v21 = 0.0f;
  // pto: %c2_index
  const int64_t v22 = 2;
  // pto: %c16_index
  const int64_t v23 = 16;
  // pto: %coefficient_scales_inline4324__ssa_v0_view
  const int64_t v24 = 1;
  // pto: %coefficient_scales_inline4324__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %coefficient_scales_inline4324__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %coefficient_scales_inline4324__ssa_v0_view
  int64_t v27 = v14 * v15;
  // pto: %coefficient_scales_inline4324__ssa_v0_view
  int64_t v28 = v26 * v27;
  // pto: %coefficient_scales_inline4324__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v29 = pto::Shape<1, 1, 1, -1, -1>(v24, v25, v26, v14, v15);
  // pto: %coefficient_scales_inline4324__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v30 = pto::Stride<-1, -1, -1, -1, -1>(v25 * v28, v28, v27, v15, v13);
  // pto: %coefficient_scales_inline4324__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v31 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v29, v30);
  // pto: %weights_inline3741__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %weights_inline3741__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %weights_inline3741__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %weights_inline3741__ssa_v0_view
  int64_t v35 = v14 * v15;
  // pto: %weights_inline3741__ssa_v0_view
  int64_t v36 = v34 * v35;
  // pto: %weights_inline3741__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v37 = pto::Shape<1, 1, 1, -1, -1>(v32, v33, v34, v14, v15);
  // pto: %weights_inline3741__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v38 = pto::Stride<-1, -1, -1, -1, -1>(v33 * v36, v36, v35, v15, v13);
  // pto: %weights_inline3741__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v39 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v37, v38);
  // pto: %coefficients_inline4323__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %coefficients_inline4323__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %coefficients_inline4323__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %coefficients_inline4323__ssa_v0_view
  int64_t v43 = v16 * v17;
  // pto: %coefficients_inline4323__ssa_v0_view
  int64_t v44 = v42 * v43;
  // pto: %coefficients_inline4323__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v45 = pto::Shape<1, 1, 1, -1, -1>(v40, v41, v42, v16, v17);
  // pto: %coefficients_inline4323__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v46 = pto::Stride<-1, -1, -1, -1, -1>(v41 * v44, v44, v43, v17, v13);
  // pto: %coefficients_inline4323__ssa_v0_view
  GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v47 = GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v45, v46);
  // pto: %coefficient_rows_inline4330__phi_v2
  Tile<TileType::Vec, half, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v48 = Tile<TileType::Vec, half, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v15);
  // pto: %coefficient_rows_inline4330__phi_v2
  uint64_t v49 = (uint64_t) v10;
  TASSIGN(v48, v49);
  // pto: %coefficient_rows_inline4330__phi_v4
  Tile<TileType::Vec, half, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v50 = Tile<TileType::Vec, half, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v15);
  // pto: %coefficient_rows_inline4330__phi_v4
  uint64_t v51 = (uint64_t) v10;
  TASSIGN(v50, v51);
  // pto: %coefficient_worker_inline4327__ssa_v0
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  // pto: %t__tile
  int32_t v52 = (v1)[v18];
  // pto: %0
  for (int64_t v53 = (int64_t) v7; v53 < ((int64_t) v52); v53 += v19) {
    // pto: %coefficient_rows_inline4330__ssa_v0
    ;
    Tile<TileType::Vec, half, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v54 = Tile<TileType::Vec, half, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v15);
    // pto: %coefficient_rows_inline4330__ssa_v0
    ;
    uint64_t v55 = (uint64_t) v10;
    TASSIGN(v54, v55);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    TEXPANDS(v54, v21);
    // pto: %1
    ;
    int32_t v56 = (v2)[v53];
    // pto: %2
    ;
    int64_t v57 = (int64_t) v56;
    // pto: %query_scales_inline4332__ssa_v0
    ;
    Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v58 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v15);
    // pto: %query_scales_inline4332__ssa_v0
    ;
    uint64_t v59 = (uint64_t) v11;
    TASSIGN(v58, v59);
    // pto: %3
    ;
    int64_t v60 = v57 < v18 ? v18 : v57;
    // pto: %coefficient_scales_inline4324__ssa_v0_pview
    ;
    __gm__ float* v61 = PTOAS__GLOBAL_TENSOR_DATA(v31);
    // pto: %coefficient_scales_inline4324__ssa_v0_pview
    ;
    const int64_t v62 = 0;
    // pto: %coefficient_scales_inline4324__ssa_v0_pview
    ;
    const int64_t v63 = 64;
    // pto: %coefficient_scales_inline4324__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 2, 64> v64 = pto::Shape<1, 1, 1, 2, 64>();
    // pto: %coefficient_scales_inline4324__ssa_v0_pview
    ;
    pto::Stride<128, 128, 128, 64, 1> v65 = pto::Stride<128, 128, 128, 64, 1>();
    // pto: %coefficient_scales_inline4324__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 2, 64>, pto::Stride<128, 128, 128, 64, 1>, pto::Layout::ND> v66 = GlobalTensor<float, pto::Shape<1, 1, 1, 2, 64>, pto::Stride<128, 128, 128, 64, 1>, pto::Layout::ND>(v61 + (v62 + v60 * v63), v64, v65);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v58, v66);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %query_weights_inline4333__ssa_v0
    ;
    Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v67 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v15);
    // pto: %query_weights_inline4333__ssa_v0
    ;
    uint64_t v68 = (uint64_t) v12;
    TASSIGN(v67, v68);
    // pto: %weights_inline3741__ssa_v0_pview
    ;
    __gm__ float* v69 = PTOAS__GLOBAL_TENSOR_DATA(v39);
    // pto: %weights_inline3741__ssa_v0_pview
    ;
    const int64_t v70 = 0;
    // pto: %weights_inline3741__ssa_v0_pview
    ;
    const int64_t v71 = 64;
    // pto: %weights_inline3741__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 2, 64> v72 = pto::Shape<1, 1, 1, 2, 64>();
    // pto: %weights_inline3741__ssa_v0_pview
    ;
    pto::Stride<128, 128, 128, 64, 1> v73 = pto::Stride<128, 128, 128, 64, 1>();
    // pto: %weights_inline3741__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 2, 64>, pto::Stride<128, 128, 128, 64, 1>, pto::Layout::ND> v74 = GlobalTensor<float, pto::Shape<1, 1, 1, 2, 64>, pto::Stride<128, 128, 128, 64, 1>, pto::Layout::ND>(v69 + (v70 + v60 * v71), v72, v73);
    TLOAD(v67, v74);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %query_scale_half_inline4334__ssa_v0
    ;
    Tile<TileType::Vec, half, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v75 = Tile<TileType::Vec, half, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v15);
    // pto: %query_scale_half_inline4334__ssa_v0
    ;
    uint64_t v76 = (uint64_t) v11;
    TASSIGN(v75, v76);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v77 = RoundMode::CAST_RINT;
    SaturationMode v78 = SaturationMode::ON;
    TCVT(v75, v58, v77, v78);
    // pto: %query_weight_half_inline4335__ssa_v0
    ;
    Tile<TileType::Vec, half, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v79 = Tile<TileType::Vec, half, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v15);
    // pto: %query_weight_half_inline4335__ssa_v0
    ;
    uint64_t v80 = (uint64_t) v12;
    TASSIGN(v79, v80);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    RoundMode v81 = RoundMode::CAST_RINT;
    SaturationMode v82 = SaturationMode::ON;
    TCVT(v79, v67, v81, v82);
    // pto: %head_coefficients_inline4336__ssa_v0
    ;
    Tile<TileType::Vec, half, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v83 = Tile<TileType::Vec, half, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v15);
    // pto: %head_coefficients_inline4336__ssa_v0
    ;
    uint64_t v84 = (uint64_t) v11;
    TASSIGN(v83, v84);
    pipe_barrier(PIPE_V);
    TMUL(v83, v75, v79);
    // pto: %5
    ;
    int32_t v85 = (v5)[v53];
    // pto: %6, %7
    ;
    if ((int64_t) v85 > v18) {
      // pto: %head_coefficient_inline4338__ssa_v0
      ;
      Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v86 = Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v15);
      // pto: %head_coefficient_inline4338__ssa_v0
      ;
      uint64_t v87 = (uint64_t) v12;
      TASSIGN(v86, v87);
      pipe_barrier(PIPE_V);
      uint16_t v88 = static_cast<uint16_t>(v18);
      uint16_t v89 = static_cast<uint16_t>(v18);
      TEXTRACT(v86, v83, v88, v89);
      // pto: %assemble_view
      ;
      Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v90;
      // pto: %assemble_view
      ;
      uint64_t v91 = (uint64_t) v10;
      TASSIGN(v90, v91);
      pipe_barrier(PIPE_V);
      TMOV(v90, v86);
    };
    // pto: %8
    ;
    int32_t v92 = (v5)[v53];
    // pto: %9, %10
    ;
    if ((int64_t) v92 > v13) {
      // pto: %head_coefficient_inline4338__ssa_v1
      ;
      Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v15);
      // pto: %head_coefficient_inline4338__ssa_v1
      ;
      uint64_t v94 = (uint64_t) v12;
      TASSIGN(v93, v94);
      pipe_barrier(PIPE_V);
      uint16_t v95 = static_cast<uint16_t>(v13);
      uint16_t v96 = static_cast<uint16_t>(v18);
      TEXTRACT(v93, v83, v95, v96);
      // pto: %11
      ;
      Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v97;
      // pto: %11
      ;
      uint64_t v98 = (uint64_t) v9;
      TASSIGN(v97, v98);
      pipe_barrier(PIPE_V);
      TMOV(v97, v93);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %coefficient_matrix_inline4339__ssa_v0
    ;
    Tile<TileType::Vec, half, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Vec, half, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v17);
    // pto: %coefficient_matrix_inline4339__ssa_v0
    ;
    uint64_t v100 = (uint64_t) v10;
    TASSIGN(v99, v100);
    // pto: %12
    ;
    int64_t v101 = (int64_t) ((uint64_t) v53 * (uint64_t) v23);
    // pto: %13
    ;
    int64_t v102 = v101 < v18 ? v18 : v101;
    // pto: %coefficients_inline4323__ssa_v0_pview
    ;
    __gm__ half* v103 = PTOAS__GLOBAL_TENSOR_DATA(v47);
    // pto: %coefficients_inline4323__ssa_v0_pview
    ;
    const int64_t v104 = 0;
    // pto: %coefficients_inline4323__ssa_v0_pview
    ;
    const int64_t v105 = 128;
    // pto: %coefficients_inline4323__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 16, 128> v106 = pto::Shape<1, 1, 1, 16, 128>();
    // pto: %coefficients_inline4323__ssa_v0_pview
    ;
    pto::Stride<2048, 2048, 2048, 128, 1> v107 = pto::Stride<2048, 2048, 2048, 128, 1>();
    // pto: %coefficients_inline4323__ssa_v0_pview
    ;
    GlobalTensor<half, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<2048, 2048, 2048, 128, 1>, pto::Layout::ND> v108 = GlobalTensor<half, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<2048, 2048, 2048, 128, 1>, pto::Layout::ND>(v103 + (v104 + v102 * v105), v106, v107);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v108, v99);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}