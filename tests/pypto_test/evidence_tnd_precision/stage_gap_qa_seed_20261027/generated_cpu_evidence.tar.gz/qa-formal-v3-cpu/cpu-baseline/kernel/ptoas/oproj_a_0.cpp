#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_a_0(__gm__ float* v1, __gm__ int32_t* v2, __gm__ bfloat16_t* v3, __gm__ bfloat16_t* v4, int64_t v5, int64_t v6, int64_t v7, int64_t v8, int64_t v9, int32_t v10, int32_t v11) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c196608_i64
  const int64_t v12 = 196608;
  // pto: %c0_i64
  const int64_t v13 = 0;
  // pto: %c32768_i64
  const int64_t v14 = 32768;
  // pto: %c65536_i64
  const int64_t v15 = 65536;
  // pto: %c131072_i64
  const int64_t v16 = 131072;
  // pto: %c8192_index
  const int64_t v17 = 8192;
  // pto: %c1_index
  const int64_t v18 = 1;
  // pto: %c16_index
  const int64_t v19 = 16;
  // pto: %c8_index
  const int64_t v20 = 8;
  // pto: %c32768_index
  const int64_t v21 = 32768;
  const int64_t v22 = 64;
  // pto: %c256_index
  const int64_t v23 = 256;
  // pto: %c4194304_index
  const int64_t v24 = 4194304;
  // pto: %c65536_index
  const int64_t v25 = 65536;
  const int64_t v26 = 128;
  // pto: %c0_index
  const int64_t v27 = 0;
  // pto: %c7_index
  const int64_t v28 = 7;
  // pto: %c2_index
  const int64_t v29 = 2;
  // pto: %c3_index
  const int64_t v30 = 3;
  // pto: %c4_index
  const int64_t v31 = 4;
  // pto: %c5_index
  const int64_t v32 = 5;
  // pto: %c6_index
  const int64_t v33 = 6;
  // pto: %c4096_index
  const int64_t v34 = 4096;
  // pto: %c14_index
  const int64_t v35 = 14;
  // pto: %c240_index
  const int64_t v36 = 240;
  // pto: %c225_index
  const int64_t v37 = 225;
  // pto: %c241_index
  const int64_t v38 = 241;
  // pto: %c1024_index
  const int64_t v39 = 1024;
  // pto: %c127_index
  const int64_t v40 = 127;
  // pto: %337
  int64_t v41 = (int64_t) ((uint64_t) v8 + (uint64_t) v40);
  // pto: %accum_inline5396__iter_v11_view
  const int64_t v42 = 1;
  // pto: %accum_inline5396__iter_v11_view
  const int64_t v43 = 1;
  // pto: %accum_inline5396__iter_v11_view
  const int64_t v44 = 1;
  // pto: %accum_inline5396__iter_v11_view
  int64_t v45 = v41 * v17;
  // pto: %accum_inline5396__iter_v11_view
  int64_t v46 = v44 * v45;
  // pto: %accum_inline5396__iter_v11_view
  pto::Shape<1, 1, 1, -1, -1> v47 = pto::Shape<1, 1, 1, -1, -1>(v42, v43, v44, v41, v17);
  // pto: %accum_inline5396__iter_v11_view
  pto::Stride<-1, -1, -1, -1, -1> v48 = pto::Stride<-1, -1, -1, -1, -1>(v43 * v46, v46, v45, v17, v18);
  // pto: %accum_inline5396__iter_v11_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v49 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v47, v48);
  // pto: %heads__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v51 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v52 = 1;
  // pto: %heads__ssa_v0_view
  int64_t v53 = (int64_t) v9;
  // pto: %heads__ssa_v0_view
  int64_t v54 = v53 * v21;
  // pto: %heads__ssa_v0_view
  int64_t v55 = v52 * v54;
  // pto: %heads__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v56 = pto::Shape<1, 1, 1, -1, -1>(v50, v51, v52, v53, v21);
  // pto: %heads__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v57 = pto::Stride<-1, -1, -1, -1, -1>(v51 * v55, v55, v54, v21, v18);
  // pto: %heads__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v58 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v56, v57);
  // pto: %wo_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v59 = pto::Shape<-1, -1, -1, -1, -1>(v20, v22, v23, v19, v19);
  // pto: %wo_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v60 = pto::Stride<-1, -1, -1, -1, -1>(v24, v25, v23, v19, v18);
  // pto: %wo_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v61 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v4, v59, v60);
  // pto: %v4_wide_acc_inline5447__phi_v7
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v62 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v26);
  // pto: %v4_wide_acc_inline5447__phi_v7
  uint64_t v63 = (uint64_t) v13;
  TASSIGN(v62, v63);
  // pto: %190
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v64 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v26);
  // pto: %190
  uint64_t v65 = (uint64_t) v13;
  TASSIGN(v64, v65);
  // pto: %228
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v66 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v26);
  // pto: %228
  uint64_t v67 = (uint64_t) v13;
  TASSIGN(v66, v67);
  // pto: %v4_narrow_acc_inline5466__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v68 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v19, v26);
  // pto: %v4_narrow_acc_inline5466__phi_v7
  uint64_t v69 = (uint64_t) v13;
  TASSIGN(v68, v69);
  // pto: %v4_block_inline5435__ssa_v0
  int64_t v70 = (int64_t) v10;
  // pto: %38
  int64_t v71 = (int64_t) ((uint64_t) v70 * (uint64_t) v26);
  // pto: %39
  int64_t v72 = (int64_t) ((uint64_t) v5 + (uint64_t) v28);
  // pto: %40
  const int64_t v73 = 1;
  // pto: %40
  const int64_t v74 = 0;
  // pto: %40
  int64_t v75 = v72 / v20;
  // pto: %40
  bool v76 = v72 < v74;
  // pto: %40
  bool v77 = v20 < v74;
  // pto: %40
  bool v78 = v76 == v77;
  // pto: %40
  bool v79 = v72 % v20 != v74 && v76 != v77;
  // pto: %40
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  for (int64_t v80 = v27; v80 < (v79 ? v75 - v73 : v75); v80 += v18) {
    // pto: %41
    ;
    int64_t v81 = (int64_t) ((uint64_t) v80 * (uint64_t) v20);
    // pto: %flat_offset, %42, %43, %t__tile
    ;
    int32_t v82 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v80 * (uint64_t) v22) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
    // pto: %44
    ;
    int64_t v83 = (int64_t) v82;
    // pto: %45
    ;
    int64_t v84 = v83 < v27 ? v27 : v83;
    // pto: %46
    ;
    int64_t v85 = (int64_t) ((uint64_t) v81 + (uint64_t) v18);
    // pto: %47
    ;
    // pto: %v4_same_start_inline5440__phi_v3
    ;
    int64_t v86;
    if (v85 < v5) {
      // pto: %50, %51, %52, %53, %48
      ;
      int32_t v87 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v85 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
      // pto: %54
      ;
      int64_t v88 = (int64_t) v87;
      // pto: %55
      ;
      int64_t v89 = v88 < v27 ? v27 : v88;
      // pto: %56, %v4_same_start_inline5440__phi_v2
      ;
      v86 = v89 != v84 ? v27 : v18;
    } else {
      v86 = v18;
    };
    // pto: %57
    ;
    int64_t v90 = (int64_t) ((uint64_t) v81 + (uint64_t) v29);
    // pto: %58
    ;
    // pto: %v4_same_start_inline5440__phi_v6
    ;
    int64_t v91;
    if (v90 < v5) {
      // pto: %61, %62, %63, %64, %59
      ;
      int32_t v92 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v90 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
      // pto: %65
      ;
      int64_t v93 = (int64_t) v92;
      // pto: %66
      ;
      int64_t v94 = v93 < v27 ? v27 : v93;
      // pto: %67, %v4_same_start_inline5440__phi_v5
      ;
      int64_t v95 = v94 != v84 ? v27 : v86;
      v91 = v95;
    } else {
      v91 = v86;
    };
    // pto: %68
    ;
    int64_t v96 = (int64_t) ((uint64_t) v81 + (uint64_t) v30);
    // pto: %69
    ;
    // pto: %v4_same_start_inline5440__phi_v9
    ;
    int64_t v97;
    if (v96 < v5) {
      // pto: %72, %73, %74, %75, %70
      ;
      int32_t v98 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v96 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
      // pto: %76
      ;
      int64_t v99 = (int64_t) v98;
      // pto: %77
      ;
      int64_t v100 = v99 < v27 ? v27 : v99;
      // pto: %78, %v4_same_start_inline5440__phi_v8
      ;
      int64_t v101 = v100 != v84 ? v27 : v91;
      v97 = v101;
    } else {
      v97 = v91;
    };
    // pto: %79
    ;
    int64_t v102 = (int64_t) ((uint64_t) v81 + (uint64_t) v31);
    // pto: %80
    ;
    // pto: %v4_same_start_inline5440__phi_v12
    ;
    int64_t v103;
    if (v102 < v5) {
      // pto: %83, %84, %85, %86, %81
      ;
      int32_t v104 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v102 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
      // pto: %87
      ;
      int64_t v105 = (int64_t) v104;
      // pto: %88
      ;
      int64_t v106 = v105 < v27 ? v27 : v105;
      // pto: %89, %v4_same_start_inline5440__phi_v11
      ;
      int64_t v107 = v106 != v84 ? v27 : v97;
      v103 = v107;
    } else {
      v103 = v97;
    };
    // pto: %90
    ;
    int64_t v108 = (int64_t) ((uint64_t) v81 + (uint64_t) v32);
    // pto: %91
    ;
    // pto: %v4_same_start_inline5440__phi_v15
    ;
    int64_t v109;
    if (v108 < v5) {
      // pto: %94, %95, %96, %97, %92
      ;
      int32_t v110 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v108 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
      // pto: %98
      ;
      int64_t v111 = (int64_t) v110;
      // pto: %99
      ;
      int64_t v112 = v111 < v27 ? v27 : v111;
      // pto: %100, %v4_same_start_inline5440__phi_v14
      ;
      int64_t v113 = v112 != v84 ? v27 : v103;
      v109 = v113;
    } else {
      v109 = v103;
    };
    // pto: %101
    ;
    int64_t v114 = (int64_t) ((uint64_t) v81 + (uint64_t) v33);
    // pto: %102
    ;
    // pto: %v4_same_start_inline5440__phi_v18
    ;
    int64_t v115;
    if (v114 < v5) {
      // pto: %105, %106, %107, %108, %103
      ;
      int32_t v116 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v114 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
      // pto: %109
      ;
      int64_t v117 = (int64_t) v116;
      // pto: %110
      ;
      int64_t v118 = v117 < v27 ? v27 : v117;
      // pto: %111, %v4_same_start_inline5440__phi_v17
      ;
      int64_t v119 = v118 != v84 ? v27 : v109;
      v115 = v119;
    } else {
      v115 = v109;
    };
    // pto: %112
    ;
    int64_t v120 = (int64_t) ((uint64_t) v81 + (uint64_t) v28);
    // pto: %113
    ;
    // pto: %v4_same_start_inline5440__phi_v21
    ;
    int64_t v121;
    if (v120 < v5) {
      // pto: %116, %117, %118, %119, %114
      ;
      int32_t v122 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v120 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
      // pto: %120
      ;
      int64_t v123 = (int64_t) v122;
      // pto: %121
      ;
      int64_t v124 = v123 < v27 ? v27 : v123;
      // pto: %122, %v4_same_start_inline5440__phi_v20
      ;
      int64_t v125 = v124 != v84 ? v27 : v115;
      v121 = v125;
    } else {
      v121 = v115;
    };
    // pto: %123, %v4_same_start_inline5440__phi_v23
    ;
    int64_t v126 = v8 <= v19 ? v27 : v121;
    // pto: %124
    ;
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    if (v126 == v18) {
      int64_t v127 = (int64_t) ((uint64_t) v80 * (uint64_t) v26);
      // pto: %126
      ;
      int64_t v128 = (int64_t) ((uint64_t) v8 - (uint64_t) v127);
      // pto: %127
      ;
      int64_t v129 = v128 < v26 ? v128 : v26;
      // pto: %128
      ;
      int64_t v130 = v84 % v23;
      // pto: %129, %130, %131
      ;
      int64_t v131 = v130 < v27 ? (int64_t) ((uint64_t) v130 + (uint64_t) v23) : v130;
      // pto: %132
      ;
      int64_t v132 = (int64_t) ((uint64_t) v131 * (uint64_t) v19);
      // pto: %v4_wide_seed_x_inline5445__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v129, v19);
      // pto: %v4_wide_seed_x_inline5445__tile
      ;
      uint64_t v134 = (uint64_t) v12;
      TASSIGN(v133, v134);
      // pto: %133
      ;
      int64_t v135 = v127 < v27 ? v27 : v127;
      // pto: %134
      ;
      int64_t v136 = (int64_t) ((uint64_t) v6 * (uint64_t) v34);
      // pto: %135
      ;
      int64_t v137 = (int64_t) ((uint64_t) v136 + (uint64_t) v132);
      // pto: %136
      ;
      int64_t v138 = v137 < v27 ? v27 : v137;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v139 = 0;
      // pto: %heads__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v140 = PTOAS__GLOBAL_TENSOR_DATA(v58);
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v141 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v142 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v143 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      int64_t v144 = v129 * v21;
      // pto: %heads__ssa_v0_pview
      ;
      int64_t v145 = v143 * v144;
      // pto: %heads__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 16> v146 = pto::Shape<1, 1, 1, -1, 16>(v141, v142, v143, v129, v19);
      // pto: %heads__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v147 = pto::Stride<-1, -1, -1, -1, -1>(v142 * v145, v145, v144, v21, v18);
      // pto: %heads__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v148 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v140 + (v139 + v135 * v21 + v138 * v18), v146, v147);
      TLOAD(v133, v148);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %v4_wide_seed_w_inline5446__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v149 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
      // pto: %v4_wide_seed_w_inline5446__tile
      ;
      uint64_t v150 = (uint64_t) v13;
      TASSIGN(v149, v150);
      // pto: %137
      ;
      int64_t v151 = v6 < v27 ? v27 : v6;
      // pto: %138
      ;
      const int64_t v152 = 1;
      // pto: %138
      ;
      const int64_t v153 = 0;
      // pto: %138
      ;
      int64_t v154 = v71 / v19;
      // pto: %138
      ;
      bool v155 = v71 < v153;
      // pto: %138
      ;
      bool v156 = v19 < v153;
      // pto: %138
      ;
      bool v157 = v155 == v156;
      // pto: %138
      ;
      bool v158 = v71 % v19 != v153 && v155 != v156;
      // pto: %138
      ;
      int64_t v159 = v158 ? v154 - v152 : v154;
      // pto: %139
      ;
      int64_t v160 = v159 < v27 ? v27 : v159;
      // pto: %140
      ;
      const int64_t v161 = 1;
      // pto: %140
      ;
      const int64_t v162 = 0;
      // pto: %140
      ;
      int64_t v163 = v132 / v19;
      // pto: %140
      ;
      bool v164 = v132 < v162;
      // pto: %140
      ;
      bool v165 = v19 < v162;
      // pto: %140
      ;
      bool v166 = v164 == v165;
      // pto: %140
      ;
      bool v167 = v132 % v19 != v162 && v164 != v165;
      // pto: %140
      ;
      int64_t v168 = v167 ? v163 - v161 : v163;
      // pto: %141
      ;
      int64_t v169 = v168 < v27 ? v27 : v168;
      // pto: %wo_a__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v170 = PTOAS__GLOBAL_TENSOR_DATA(v61);
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v171 = 0;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v172 = 4194304;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v173 = 65536;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v174 = 256;
      // pto: %wo_a__ssa_v0_pview
      ;
      pto::Shape<1, 8, 1, 16, 16> v175 = pto::Shape<1, 8, 1, 16, 16>();
      // pto: %wo_a__ssa_v0_pview
      ;
      pto::Stride<4194304, 65536, 256, 16, 1> v176 = pto::Stride<4194304, 65536, 256, 16, 1>();
      // pto: %wo_a__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v177 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v170 + ((v171 + v151 * v172) + v160 * v173 + v169 * v174), v175, v176);
      TLOAD(v149, v177);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %lhs_slice_0_textract
      ;
      Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v178 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v129, v19);
      // pto: %lhs_slice_0_textract
      ;
      uint64_t v179 = (uint64_t) v13;
      TASSIGN(v178, v179);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      uint16_t v180 = static_cast<uint16_t>(v27);
      uint16_t v181 = static_cast<uint16_t>(v27);
      TEXTRACT(v178, v133, v180, v181);
      // pto: %rhs_slice_0_textract
      ;
      Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v182 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
      // pto: %rhs_slice_0_textract
      ;
      uint64_t v183 = (uint64_t) v13;
      TASSIGN(v182, v183);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      uint16_t v184 = static_cast<uint16_t>(v27);
      uint16_t v185 = static_cast<uint16_t>(v27);
      TEXTRACT(v182, v149, v184, v185);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %v4_wide_acc_inline5447__tile
      ;
      Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v186 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v129, v26);
      // pto: %v4_wide_acc_inline5447__tile
      ;
      uint64_t v187 = (uint64_t) v13;
      TASSIGN(v186, v187);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      TMATMUL(v186, v178, v182);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      for (int64_t v188 = v27; v188 < v35; v188 += v29) {
        // pto: %142
        ;
        int64_t v189 = (int64_t) ((uint64_t) v188 * (uint64_t) v19);
        // pto: %143, %144, %145
        ;
        int64_t v190 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v84 + (uint64_t) v189) + (uint64_t) v18) % v23;
        // pto: %146, %147, %148
        ;
        int64_t v191 = v190 < v27 ? (int64_t) ((uint64_t) v190 + (uint64_t) v23) : v190;
        // pto: %151, %150, %152, %153
        ;
        int64_t v192 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v84 + (uint64_t) ((int64_t) (uint64_t) v189 + (uint64_t) v19)) + (uint64_t) v18) % v23;
        // pto: %154, %155, %156
        ;
        int64_t v193 = v192 < v27 ? (int64_t) ((uint64_t) v192 + (uint64_t) v23) : v192;
        // pto: %157
        ;
        // pto: %158
        ;
        int64_t v194 = v129 < v26 ? v129 : v26;
        v62.SetValidShape(v194, v26);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        if (v191 <= v36) {
          // pto: %159
          ;
          int64_t v195 = (int64_t) ((uint64_t) v191 * (uint64_t) v19);
          // pto: %v4_wide_packet_x_inline5451__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v196 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v129, v23);
          // pto: %v4_wide_packet_x_inline5451__tile
          ;
          uint64_t v197 = (uint64_t) v12;
          TASSIGN(v196, v197);
          // pto: %162
          ;
          int64_t v198 = (int64_t) ((uint64_t) v136 + (uint64_t) v195);
          // pto: %163
          ;
          int64_t v199 = v198 < v27 ? v27 : v198;
          // pto: %164
          ;
          const int64_t v200 = 0;
          // pto: %164
          ;
          __gm__ bfloat16_t* v201 = PTOAS__GLOBAL_TENSOR_DATA(v58);
          // pto: %164
          ;
          const int64_t v202 = 1;
          // pto: %164
          ;
          const int64_t v203 = 1;
          // pto: %164
          ;
          const int64_t v204 = 1;
          // pto: %164
          ;
          int64_t v205 = v129 * v21;
          // pto: %164
          ;
          int64_t v206 = v204 * v205;
          // pto: %164
          ;
          pto::Shape<1, 1, 1, -1, 256> v207 = pto::Shape<1, 1, 1, -1, 256>(v202, v203, v204, v129, v23);
          // pto: %164
          ;
          pto::Stride<-1, -1, -1, -1, -1> v208 = pto::Stride<-1, -1, -1, -1, -1>(v203 * v206, v206, v205, v21, v18);
          // pto: %164
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v209 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v201 + (v200 + v135 * v21 + v199 * v18), v207, v208);
          TLOAD(v196, v209);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
          // pto: %v4_wide_packet_w_inline5452__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v210 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
          // pto: %v4_wide_packet_w_inline5452__tile
          ;
          uint64_t v211 = (uint64_t) v13;
          TASSIGN(v210, v211);
          // pto: %168
          ;
          const int64_t v212 = 1;
          // pto: %168
          ;
          const int64_t v213 = 0;
          // pto: %168
          ;
          int64_t v214 = v195 / v19;
          // pto: %168
          ;
          bool v215 = v195 < v213;
          // pto: %168
          ;
          bool v216 = v19 < v213;
          // pto: %168
          ;
          bool v217 = v215 == v216;
          // pto: %168
          ;
          bool v218 = v195 % v19 != v213 && v215 != v216;
          // pto: %168
          ;
          int64_t v219 = v218 ? v214 - v212 : v214;
          // pto: %169
          ;
          int64_t v220 = v219 < v27 ? v27 : v219;
          // pto: %170
          ;
          __gm__ bfloat16_t* v221 = PTOAS__GLOBAL_TENSOR_DATA(v61);
          // pto: %170
          ;
          const int64_t v222 = 0;
          // pto: %170
          ;
          const int64_t v223 = 4194304;
          // pto: %170
          ;
          const int64_t v224 = 65536;
          // pto: %170
          ;
          const int64_t v225 = 256;
          // pto: %170
          ;
          pto::Shape<1, 8, 16, 16, 16> v226 = pto::Shape<1, 8, 16, 16, 16>();
          // pto: %170
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v227 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %170
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v228 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v221 + ((v222 + v151 * v223) + v160 * v224 + v220 * v225), v226, v227);
          TLOAD(v210, v228);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
          // pto: %v4_wide_acc_inline5447__iter_v1_l0_a
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v229 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v129, v26);
          // pto: %v4_wide_acc_inline5447__iter_v1_l0_a
          ;
          uint64_t v230 = (uint64_t) v13;
          TASSIGN(v229, v230);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
          uint16_t v231 = static_cast<uint16_t>(v27);
          uint16_t v232 = static_cast<uint16_t>(v27);
          TEXTRACT(v229, v196, v231, v232);
          // pto: %v4_wide_acc_inline5447__iter_v1_l0_b
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v233 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %v4_wide_acc_inline5447__iter_v1_l0_b
          ;
          uint64_t v234 = (uint64_t) v13;
          TASSIGN(v233, v234);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
          uint16_t v235 = static_cast<uint16_t>(v27);
          uint16_t v236 = static_cast<uint16_t>(v27);
          TEXTRACT(v233, v210, v235, v236);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
          // pto: %0
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v237 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v129, v26);
          // pto: %0
          ;
          uint64_t v238 = (uint64_t) v14;
          TASSIGN(v237, v238);
          uint16_t v239 = static_cast<uint16_t>(v27);
          uint16_t v240 = static_cast<uint16_t>(v26);
          TEXTRACT(v237, v196, v239, v240);
          // pto: %1
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v241 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %1
          ;
          uint64_t v242 = (uint64_t) v14;
          TASSIGN(v241, v242);
          uint16_t v243 = static_cast<uint16_t>(v26);
          uint16_t v244 = static_cast<uint16_t>(v27);
          TEXTRACT(v241, v210, v243, v244);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v186, v186, v229, v233);
          pipe_barrier(PIPE_M);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
          TMATMUL_ACC(v186, v186, v237, v241);
        } else {
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
          for (int64_t v245 = v27; v245 < v19; v245 += v18) {
            // pto: %171, %172
            ;
            int64_t v246 = (int64_t) ((uint64_t) v191 + (uint64_t) v245) % v23;
            // pto: %173, %174, %175
            ;
            int64_t v247 = v246 < v27 ? (int64_t) ((uint64_t) v246 + (uint64_t) v23) : v246;
            // pto: %176
            ;
            int64_t v248 = (int64_t) ((uint64_t) v247 * (uint64_t) v19);
            // pto: %v4_wide_wrap_x_inline5455__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v249 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v129, v19);
            // pto: %v4_wide_wrap_x_inline5455__tile
            ;
            uint64_t v250 = (uint64_t) v12;
            TASSIGN(v249, v250);
            // pto: %179
            ;
            int64_t v251 = (int64_t) ((uint64_t) v136 + (uint64_t) v248);
            // pto: %180
            ;
            int64_t v252 = v251 < v27 ? v27 : v251;
            // pto: %181
            ;
            const int64_t v253 = 0;
            // pto: %181
            ;
            __gm__ bfloat16_t* v254 = PTOAS__GLOBAL_TENSOR_DATA(v58);
            // pto: %181
            ;
            const int64_t v255 = 1;
            // pto: %181
            ;
            const int64_t v256 = 1;
            // pto: %181
            ;
            const int64_t v257 = 1;
            // pto: %181
            ;
            int64_t v258 = v129 * v21;
            // pto: %181
            ;
            int64_t v259 = v257 * v258;
            // pto: %181
            ;
            pto::Shape<1, 1, 1, -1, 16> v260 = pto::Shape<1, 1, 1, -1, 16>(v255, v256, v257, v129, v19);
            // pto: %181
            ;
            pto::Stride<-1, -1, -1, -1, -1> v261 = pto::Stride<-1, -1, -1, -1, -1>(v256 * v259, v259, v258, v21, v18);
            // pto: %181
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v262 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v254 + (v253 + v135 * v21 + v252 * v18), v260, v261);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            TLOAD(v249, v262);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
            // pto: %v4_wide_wrap_w_inline5456__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v263 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %v4_wide_wrap_w_inline5456__tile
            ;
            uint64_t v264 = (uint64_t) v13;
            TASSIGN(v263, v264);
            // pto: %185
            ;
            const int64_t v265 = 1;
            // pto: %185
            ;
            const int64_t v266 = 0;
            // pto: %185
            ;
            int64_t v267 = v248 / v19;
            // pto: %185
            ;
            bool v268 = v248 < v266;
            // pto: %185
            ;
            bool v269 = v19 < v266;
            // pto: %185
            ;
            bool v270 = v268 == v269;
            // pto: %185
            ;
            bool v271 = v248 % v19 != v266 && v268 != v269;
            // pto: %185
            ;
            int64_t v272 = v271 ? v267 - v265 : v267;
            // pto: %186
            ;
            int64_t v273 = v272 < v27 ? v27 : v272;
            // pto: %187
            ;
            __gm__ bfloat16_t* v274 = PTOAS__GLOBAL_TENSOR_DATA(v61);
            // pto: %187
            ;
            const int64_t v275 = 0;
            // pto: %187
            ;
            const int64_t v276 = 4194304;
            // pto: %187
            ;
            const int64_t v277 = 65536;
            // pto: %187
            ;
            const int64_t v278 = 256;
            // pto: %187
            ;
            pto::Shape<1, 8, 1, 16, 16> v279 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %187
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v280 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %187
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v281 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v274 + ((v275 + v151 * v276) + v160 * v277 + v273 * v278), v279, v280);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
            TLOAD(v263, v281);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
            // pto: %3
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v282 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v129, v19);
            // pto: %3
            ;
            uint64_t v283 = (uint64_t) v13;
            TASSIGN(v282, v283);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
            uint16_t v284 = static_cast<uint16_t>(v27);
            uint16_t v285 = static_cast<uint16_t>(v27);
            TEXTRACT(v282, v249, v284, v285);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            // pto: %4
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v286 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %4
            ;
            uint64_t v287 = (uint64_t) v13;
            TASSIGN(v286, v287);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
            uint16_t v288 = static_cast<uint16_t>(v27);
            uint16_t v289 = static_cast<uint16_t>(v27);
            TEXTRACT(v286, v263, v288, v289);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v186, v186, v282, v286);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          };
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        };
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        // pto: %188
        ;
        v64.SetValidShape(v194, v26);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        if (v193 <= v36) {
          // pto: %191
          ;
          int64_t v290 = (int64_t) ((uint64_t) v193 * (uint64_t) v19);
          // pto: %5
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v291 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v129, v23);
          // pto: %5
          ;
          uint64_t v292 = (uint64_t) v15;
          TASSIGN(v291, v292);
          // pto: %194
          ;
          int64_t v293 = (int64_t) ((uint64_t) v136 + (uint64_t) v290);
          // pto: %195
          ;
          int64_t v294 = v293 < v27 ? v27 : v293;
          // pto: %196
          ;
          const int64_t v295 = 0;
          // pto: %196
          ;
          __gm__ bfloat16_t* v296 = PTOAS__GLOBAL_TENSOR_DATA(v58);
          // pto: %196
          ;
          const int64_t v297 = 1;
          // pto: %196
          ;
          const int64_t v298 = 1;
          // pto: %196
          ;
          const int64_t v299 = 1;
          // pto: %196
          ;
          int64_t v300 = v129 * v21;
          // pto: %196
          ;
          int64_t v301 = v299 * v300;
          // pto: %196
          ;
          pto::Shape<1, 1, 1, -1, 256> v302 = pto::Shape<1, 1, 1, -1, 256>(v297, v298, v299, v129, v23);
          // pto: %196
          ;
          pto::Stride<-1, -1, -1, -1, -1> v303 = pto::Stride<-1, -1, -1, -1, -1>(v298 * v301, v301, v300, v21, v18);
          // pto: %196
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v304 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v296 + (v295 + v135 * v21 + v294 * v18), v302, v303);
          TLOAD(v291, v304);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
          // pto: %6
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v305 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
          // pto: %6
          ;
          uint64_t v306 = (uint64_t) v16;
          TASSIGN(v305, v306);
          // pto: %200
          ;
          const int64_t v307 = 1;
          // pto: %200
          ;
          const int64_t v308 = 0;
          // pto: %200
          ;
          int64_t v309 = v290 / v19;
          // pto: %200
          ;
          bool v310 = v290 < v308;
          // pto: %200
          ;
          bool v311 = v19 < v308;
          // pto: %200
          ;
          bool v312 = v310 == v311;
          // pto: %200
          ;
          bool v313 = v290 % v19 != v308 && v310 != v311;
          // pto: %200
          ;
          int64_t v314 = v313 ? v309 - v307 : v309;
          // pto: %201
          ;
          int64_t v315 = v314 < v27 ? v27 : v314;
          // pto: %202
          ;
          __gm__ bfloat16_t* v316 = PTOAS__GLOBAL_TENSOR_DATA(v61);
          // pto: %202
          ;
          const int64_t v317 = 0;
          // pto: %202
          ;
          const int64_t v318 = 4194304;
          // pto: %202
          ;
          const int64_t v319 = 65536;
          // pto: %202
          ;
          const int64_t v320 = 256;
          // pto: %202
          ;
          pto::Shape<1, 8, 16, 16, 16> v321 = pto::Shape<1, 8, 16, 16, 16>();
          // pto: %202
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v322 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %202
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v323 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v316 + ((v317 + v151 * v318) + v160 * v319 + v315 * v320), v321, v322);
          TLOAD(v305, v323);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
          // pto: %7
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v324 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v129, v26);
          // pto: %7
          ;
          uint64_t v325 = (uint64_t) v13;
          TASSIGN(v324, v325);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
          uint16_t v326 = static_cast<uint16_t>(v27);
          uint16_t v327 = static_cast<uint16_t>(v27);
          TEXTRACT(v324, v291, v326, v327);
          // pto: %8
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v328 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %8
          ;
          uint64_t v329 = (uint64_t) v13;
          TASSIGN(v328, v329);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
          uint16_t v330 = static_cast<uint16_t>(v27);
          uint16_t v331 = static_cast<uint16_t>(v27);
          TEXTRACT(v328, v305, v330, v331);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
          // pto: %9
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v332 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v129, v26);
          // pto: %9
          ;
          uint64_t v333 = (uint64_t) v14;
          TASSIGN(v332, v333);
          uint16_t v334 = static_cast<uint16_t>(v27);
          uint16_t v335 = static_cast<uint16_t>(v26);
          TEXTRACT(v332, v291, v334, v335);
          // pto: %10
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v336 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %10
          ;
          uint64_t v337 = (uint64_t) v14;
          TASSIGN(v336, v337);
          uint16_t v338 = static_cast<uint16_t>(v26);
          uint16_t v339 = static_cast<uint16_t>(v27);
          TEXTRACT(v336, v305, v338, v339);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v62, v62, v324, v328);
          pipe_barrier(PIPE_M);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
          TMATMUL_ACC(v62, v62, v332, v336);
        } else {
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
          for (int64_t v340 = v27; v340 < v19; v340 += v18) {
            // pto: %204, %205
            ;
            int64_t v341 = (int64_t) ((uint64_t) v193 + (uint64_t) v340) % v23;
            // pto: %206, %207, %208
            ;
            int64_t v342 = v341 < v27 ? (int64_t) ((uint64_t) v341 + (uint64_t) v23) : v341;
            // pto: %209
            ;
            int64_t v343 = (int64_t) ((uint64_t) v342 * (uint64_t) v19);
            // pto: %13
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v344 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v129, v19);
            // pto: %13
            ;
            uint64_t v345 = (uint64_t) v15;
            TASSIGN(v344, v345);
            // pto: %212
            ;
            int64_t v346 = (int64_t) ((uint64_t) v136 + (uint64_t) v343);
            // pto: %213
            ;
            int64_t v347 = v346 < v27 ? v27 : v346;
            // pto: %214
            ;
            const int64_t v348 = 0;
            // pto: %214
            ;
            __gm__ bfloat16_t* v349 = PTOAS__GLOBAL_TENSOR_DATA(v58);
            // pto: %214
            ;
            const int64_t v350 = 1;
            // pto: %214
            ;
            const int64_t v351 = 1;
            // pto: %214
            ;
            const int64_t v352 = 1;
            // pto: %214
            ;
            int64_t v353 = v129 * v21;
            // pto: %214
            ;
            int64_t v354 = v352 * v353;
            // pto: %214
            ;
            pto::Shape<1, 1, 1, -1, 16> v355 = pto::Shape<1, 1, 1, -1, 16>(v350, v351, v352, v129, v19);
            // pto: %214
            ;
            pto::Stride<-1, -1, -1, -1, -1> v356 = pto::Stride<-1, -1, -1, -1, -1>(v351 * v354, v354, v353, v21, v18);
            // pto: %214
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v357 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v349 + (v348 + v135 * v21 + v347 * v18), v355, v356);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
            TLOAD(v344, v357);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %14
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v358 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %14
            ;
            uint64_t v359 = (uint64_t) v16;
            TASSIGN(v358, v359);
            // pto: %218
            ;
            const int64_t v360 = 1;
            // pto: %218
            ;
            const int64_t v361 = 0;
            // pto: %218
            ;
            int64_t v362 = v343 / v19;
            // pto: %218
            ;
            bool v363 = v343 < v361;
            // pto: %218
            ;
            bool v364 = v19 < v361;
            // pto: %218
            ;
            bool v365 = v363 == v364;
            // pto: %218
            ;
            bool v366 = v343 % v19 != v361 && v363 != v364;
            // pto: %218
            ;
            int64_t v367 = v366 ? v362 - v360 : v362;
            // pto: %219
            ;
            int64_t v368 = v367 < v27 ? v27 : v367;
            // pto: %220
            ;
            __gm__ bfloat16_t* v369 = PTOAS__GLOBAL_TENSOR_DATA(v61);
            // pto: %220
            ;
            const int64_t v370 = 0;
            // pto: %220
            ;
            const int64_t v371 = 4194304;
            // pto: %220
            ;
            const int64_t v372 = 65536;
            // pto: %220
            ;
            const int64_t v373 = 256;
            // pto: %220
            ;
            pto::Shape<1, 8, 1, 16, 16> v374 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %220
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v375 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %220
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v376 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v369 + ((v370 + v151 * v371) + v160 * v372 + v368 * v373), v374, v375);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
            TLOAD(v358, v376);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %15
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v377 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v129, v19);
            // pto: %15
            ;
            uint64_t v378 = (uint64_t) v13;
            TASSIGN(v377, v378);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
            uint16_t v379 = static_cast<uint16_t>(v27);
            uint16_t v380 = static_cast<uint16_t>(v27);
            TEXTRACT(v377, v344, v379, v380);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
            // pto: %16
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v381 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %16
            ;
            uint64_t v382 = (uint64_t) v13;
            TASSIGN(v381, v382);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            uint16_t v383 = static_cast<uint16_t>(v27);
            uint16_t v384 = static_cast<uint16_t>(v27);
            TEXTRACT(v381, v358, v383, v384);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v62, v62, v377, v381);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
          };
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        };
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      // pto: %221, %222
      ;
      int64_t v385 = (int64_t) ((uint64_t) v84 + (uint64_t) v37) % v23;
      // pto: %223, %224, %225
      ;
      int64_t v386 = v385 < v27 ? (int64_t) ((uint64_t) v385 + (uint64_t) v23) : v385;
      // pto: %226
      ;
      // pto: %227
      ;
      int64_t v387 = v129 < v26 ? v129 : v26;
      v66.SetValidShape(v387, v26);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      if (v386 <= v36) {
        // pto: %229
        ;
        int64_t v388 = (int64_t) ((uint64_t) v386 * (uint64_t) v19);
        // pto: %18
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v389 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v129, v23);
        // pto: %18
        ;
        uint64_t v390 = (uint64_t) v12;
        TASSIGN(v389, v390);
        // pto: %232
        ;
        int64_t v391 = (int64_t) ((uint64_t) v136 + (uint64_t) v388);
        // pto: %233
        ;
        int64_t v392 = v391 < v27 ? v27 : v391;
        // pto: %234
        ;
        const int64_t v393 = 0;
        // pto: %234
        ;
        __gm__ bfloat16_t* v394 = PTOAS__GLOBAL_TENSOR_DATA(v58);
        // pto: %234
        ;
        const int64_t v395 = 1;
        // pto: %234
        ;
        const int64_t v396 = 1;
        // pto: %234
        ;
        const int64_t v397 = 1;
        // pto: %234
        ;
        int64_t v398 = v129 * v21;
        // pto: %234
        ;
        int64_t v399 = v397 * v398;
        // pto: %234
        ;
        pto::Shape<1, 1, 1, -1, 256> v400 = pto::Shape<1, 1, 1, -1, 256>(v395, v396, v397, v129, v23);
        // pto: %234
        ;
        pto::Stride<-1, -1, -1, -1, -1> v401 = pto::Stride<-1, -1, -1, -1, -1>(v396 * v399, v399, v398, v21, v18);
        // pto: %234
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v402 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v394 + (v393 + v135 * v21 + v392 * v18), v400, v401);
        TLOAD(v389, v402);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %19
        ;
        Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v403 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
        // pto: %19
        ;
        uint64_t v404 = (uint64_t) v13;
        TASSIGN(v403, v404);
        // pto: %238
        ;
        const int64_t v405 = 1;
        // pto: %238
        ;
        const int64_t v406 = 0;
        // pto: %238
        ;
        int64_t v407 = v388 / v19;
        // pto: %238
        ;
        bool v408 = v388 < v406;
        // pto: %238
        ;
        bool v409 = v19 < v406;
        // pto: %238
        ;
        bool v410 = v408 == v409;
        // pto: %238
        ;
        bool v411 = v388 % v19 != v406 && v408 != v409;
        // pto: %238
        ;
        int64_t v412 = v411 ? v407 - v405 : v407;
        // pto: %239
        ;
        int64_t v413 = v412 < v27 ? v27 : v412;
        // pto: %240
        ;
        __gm__ bfloat16_t* v414 = PTOAS__GLOBAL_TENSOR_DATA(v61);
        // pto: %240
        ;
        const int64_t v415 = 0;
        // pto: %240
        ;
        const int64_t v416 = 4194304;
        // pto: %240
        ;
        const int64_t v417 = 65536;
        // pto: %240
        ;
        const int64_t v418 = 256;
        // pto: %240
        ;
        pto::Shape<1, 8, 16, 16, 16> v419 = pto::Shape<1, 8, 16, 16, 16>();
        // pto: %240
        ;
        pto::Stride<4194304, 65536, 256, 16, 1> v420 = pto::Stride<4194304, 65536, 256, 16, 1>();
        // pto: %240
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v421 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v414 + ((v415 + v151 * v416) + v160 * v417 + v413 * v418), v419, v420);
        TLOAD(v403, v421);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %20
        ;
        Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v422 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v129, v26);
        // pto: %20
        ;
        uint64_t v423 = (uint64_t) v13;
        TASSIGN(v422, v423);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        uint16_t v424 = static_cast<uint16_t>(v27);
        uint16_t v425 = static_cast<uint16_t>(v27);
        TEXTRACT(v422, v389, v424, v425);
        // pto: %21
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v426 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
        // pto: %21
        ;
        uint64_t v427 = (uint64_t) v13;
        TASSIGN(v426, v427);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v428 = static_cast<uint16_t>(v27);
        uint16_t v429 = static_cast<uint16_t>(v27);
        TEXTRACT(v426, v403, v428, v429);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        // pto: %22
        ;
        Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v430 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v129, v26);
        // pto: %22
        ;
        uint64_t v431 = (uint64_t) v14;
        TASSIGN(v430, v431);
        uint16_t v432 = static_cast<uint16_t>(v27);
        uint16_t v433 = static_cast<uint16_t>(v26);
        TEXTRACT(v430, v389, v432, v433);
        // pto: %23
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v434 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
        // pto: %23
        ;
        uint64_t v435 = (uint64_t) v14;
        TASSIGN(v434, v435);
        uint16_t v436 = static_cast<uint16_t>(v26);
        uint16_t v437 = static_cast<uint16_t>(v27);
        TEXTRACT(v434, v403, v436, v437);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v186, v186, v422, v426);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        TMATMUL_ACC(v186, v186, v430, v434);
      } else {
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        for (int64_t v438 = v27; v438 < v19; v438 += v18) {
          // pto: %242, %243
          ;
          int64_t v439 = (int64_t) ((uint64_t) v386 + (uint64_t) v438) % v23;
          // pto: %244, %245, %246
          ;
          int64_t v440 = v439 < v27 ? (int64_t) ((uint64_t) v439 + (uint64_t) v23) : v439;
          // pto: %247
          ;
          int64_t v441 = (int64_t) ((uint64_t) v440 * (uint64_t) v19);
          // pto: %26
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v442 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v129, v19);
          // pto: %26
          ;
          uint64_t v443 = (uint64_t) v12;
          TASSIGN(v442, v443);
          // pto: %250
          ;
          int64_t v444 = (int64_t) ((uint64_t) v136 + (uint64_t) v441);
          // pto: %251
          ;
          int64_t v445 = v444 < v27 ? v27 : v444;
          // pto: %252
          ;
          const int64_t v446 = 0;
          // pto: %252
          ;
          __gm__ bfloat16_t* v447 = PTOAS__GLOBAL_TENSOR_DATA(v58);
          // pto: %252
          ;
          const int64_t v448 = 1;
          // pto: %252
          ;
          const int64_t v449 = 1;
          // pto: %252
          ;
          const int64_t v450 = 1;
          // pto: %252
          ;
          int64_t v451 = v129 * v21;
          // pto: %252
          ;
          int64_t v452 = v450 * v451;
          // pto: %252
          ;
          pto::Shape<1, 1, 1, -1, 16> v453 = pto::Shape<1, 1, 1, -1, 16>(v448, v449, v450, v129, v19);
          // pto: %252
          ;
          pto::Stride<-1, -1, -1, -1, -1> v454 = pto::Stride<-1, -1, -1, -1, -1>(v449 * v452, v452, v451, v21, v18);
          // pto: %252
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v455 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v447 + (v446 + v135 * v21 + v445 * v18), v453, v454);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          TLOAD(v442, v455);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %27
          ;
          Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v456 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
          // pto: %27
          ;
          uint64_t v457 = (uint64_t) v13;
          TASSIGN(v456, v457);
          // pto: %256
          ;
          const int64_t v458 = 1;
          // pto: %256
          ;
          const int64_t v459 = 0;
          // pto: %256
          ;
          int64_t v460 = v441 / v19;
          // pto: %256
          ;
          bool v461 = v441 < v459;
          // pto: %256
          ;
          bool v462 = v19 < v459;
          // pto: %256
          ;
          bool v463 = v461 == v462;
          // pto: %256
          ;
          bool v464 = v441 % v19 != v459 && v461 != v462;
          // pto: %256
          ;
          int64_t v465 = v464 ? v460 - v458 : v460;
          // pto: %257
          ;
          int64_t v466 = v465 < v27 ? v27 : v465;
          // pto: %258
          ;
          __gm__ bfloat16_t* v467 = PTOAS__GLOBAL_TENSOR_DATA(v61);
          // pto: %258
          ;
          const int64_t v468 = 0;
          // pto: %258
          ;
          const int64_t v469 = 4194304;
          // pto: %258
          ;
          const int64_t v470 = 65536;
          // pto: %258
          ;
          const int64_t v471 = 256;
          // pto: %258
          ;
          pto::Shape<1, 8, 1, 16, 16> v472 = pto::Shape<1, 8, 1, 16, 16>();
          // pto: %258
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v473 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %258
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v474 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v467 + ((v468 + v151 * v469) + v160 * v470 + v466 * v471), v472, v473);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          TLOAD(v456, v474);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %28
          ;
          Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v475 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v129, v19);
          // pto: %28
          ;
          uint64_t v476 = (uint64_t) v13;
          TASSIGN(v475, v476);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
          uint16_t v477 = static_cast<uint16_t>(v27);
          uint16_t v478 = static_cast<uint16_t>(v27);
          TEXTRACT(v475, v442, v477, v478);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %29
          ;
          Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v479 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
          // pto: %29
          ;
          uint64_t v480 = (uint64_t) v13;
          TASSIGN(v479, v480);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          uint16_t v481 = static_cast<uint16_t>(v27);
          uint16_t v482 = static_cast<uint16_t>(v27);
          TEXTRACT(v479, v456, v481, v482);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v186, v186, v475, v479);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        };
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %v4_wide_acc_inline5447__rv_v2
      ;
      Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v483 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v129, v26);
      // pto: %v4_wide_acc_inline5447__rv_v2
      ;
      uint64_t v484 = (uint64_t) v13;
      TASSIGN(v483, v484);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      for (int64_t v485 = v38; v485 < v23; v485 += v18) {
        // pto: %259, %260
        ;
        int64_t v486 = (int64_t) ((uint64_t) v84 + (uint64_t) v485) % v23;
        // pto: %261, %262, %263
        ;
        int64_t v487 = v486 < v27 ? (int64_t) ((uint64_t) v486 + (uint64_t) v23) : v486;
        // pto: %264
        ;
        int64_t v488 = (int64_t) ((uint64_t) v487 * (uint64_t) v19);
        // pto: %v4_wide_tail_x_inline5459__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v489 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v129, v19);
        // pto: %v4_wide_tail_x_inline5459__tile
        ;
        uint64_t v490 = (uint64_t) v12;
        TASSIGN(v489, v490);
        // pto: %267
        ;
        int64_t v491 = (int64_t) ((uint64_t) v136 + (uint64_t) v488);
        // pto: %268
        ;
        int64_t v492 = v491 < v27 ? v27 : v491;
        // pto: %269
        ;
        const int64_t v493 = 0;
        // pto: %269
        ;
        __gm__ bfloat16_t* v494 = PTOAS__GLOBAL_TENSOR_DATA(v58);
        // pto: %269
        ;
        const int64_t v495 = 1;
        // pto: %269
        ;
        const int64_t v496 = 1;
        // pto: %269
        ;
        const int64_t v497 = 1;
        // pto: %269
        ;
        int64_t v498 = v129 * v21;
        // pto: %269
        ;
        int64_t v499 = v497 * v498;
        // pto: %269
        ;
        pto::Shape<1, 1, 1, -1, 16> v500 = pto::Shape<1, 1, 1, -1, 16>(v495, v496, v497, v129, v19);
        // pto: %269
        ;
        pto::Stride<-1, -1, -1, -1, -1> v501 = pto::Stride<-1, -1, -1, -1, -1>(v496 * v499, v499, v498, v21, v18);
        // pto: %269
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v502 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v494 + (v493 + v135 * v21 + v492 * v18), v500, v501);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v489, v502);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %v4_wide_tail_w_inline5460__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v503 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
        // pto: %v4_wide_tail_w_inline5460__tile
        ;
        uint64_t v504 = (uint64_t) v13;
        TASSIGN(v503, v504);
        // pto: %273
        ;
        const int64_t v505 = 1;
        // pto: %273
        ;
        const int64_t v506 = 0;
        // pto: %273
        ;
        int64_t v507 = v488 / v19;
        // pto: %273
        ;
        bool v508 = v488 < v506;
        // pto: %273
        ;
        bool v509 = v19 < v506;
        // pto: %273
        ;
        bool v510 = v508 == v509;
        // pto: %273
        ;
        bool v511 = v488 % v19 != v506 && v508 != v509;
        // pto: %273
        ;
        int64_t v512 = v511 ? v507 - v505 : v507;
        // pto: %274
        ;
        int64_t v513 = v512 < v27 ? v27 : v512;
        // pto: %275
        ;
        __gm__ bfloat16_t* v514 = PTOAS__GLOBAL_TENSOR_DATA(v61);
        // pto: %275
        ;
        const int64_t v515 = 0;
        // pto: %275
        ;
        const int64_t v516 = 4194304;
        // pto: %275
        ;
        const int64_t v517 = 65536;
        // pto: %275
        ;
        const int64_t v518 = 256;
        // pto: %275
        ;
        pto::Shape<1, 8, 1, 16, 16> v519 = pto::Shape<1, 8, 1, 16, 16>();
        // pto: %275
        ;
        pto::Stride<4194304, 65536, 256, 16, 1> v520 = pto::Stride<4194304, 65536, 256, 16, 1>();
        // pto: %275
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v521 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v514 + ((v515 + v151 * v516) + v160 * v517 + v513 * v518), v519, v520);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        TLOAD(v503, v521);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %31
        ;
        Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v522 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v129, v19);
        // pto: %31
        ;
        uint64_t v523 = (uint64_t) v13;
        TASSIGN(v522, v523);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v524 = static_cast<uint16_t>(v27);
        uint16_t v525 = static_cast<uint16_t>(v27);
        TEXTRACT(v522, v489, v524, v525);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        // pto: %32
        ;
        Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v526 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
        // pto: %32
        ;
        uint64_t v527 = (uint64_t) v13;
        TASSIGN(v526, v527);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v528 = static_cast<uint16_t>(v27);
        uint16_t v529 = static_cast<uint16_t>(v27);
        TEXTRACT(v526, v503, v528, v529);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v483, v483, v522, v526);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      // pto: %277, %278
      ;
      int64_t v530 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v39) + (uint64_t) v71);
      // pto: %279
      ;
      int64_t v531 = v530 < v27 ? v27 : v530;
      // pto: %accum_inline5396__iter_v13_pview
      ;
      const int64_t v532 = 0;
      // pto: %accum_inline5396__iter_v13_pview
      ;
      __gm__ float* v533 = PTOAS__GLOBAL_TENSOR_DATA(v49);
      // pto: %accum_inline5396__iter_v13_pview
      ;
      const int64_t v534 = 1;
      // pto: %accum_inline5396__iter_v13_pview
      ;
      const int64_t v535 = 1;
      // pto: %accum_inline5396__iter_v13_pview
      ;
      const int64_t v536 = 1;
      // pto: %accum_inline5396__iter_v13_pview
      ;
      int64_t v537 = v129 * v17;
      // pto: %accum_inline5396__iter_v13_pview
      ;
      int64_t v538 = v536 * v537;
      // pto: %accum_inline5396__iter_v13_pview
      ;
      pto::Shape<1, 1, 1, -1, 128> v539 = pto::Shape<1, 1, 1, -1, 128>(v534, v535, v536, v129, v26);
      // pto: %accum_inline5396__iter_v13_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v540 = pto::Stride<-1, -1, -1, -1, -1>(v535 * v538, v538, v537, v17, v18);
      // pto: %accum_inline5396__iter_v13_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v541 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v533 + (v532 + v135 * v17 + v531 * v18), v539, v540);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      TSTORE(v541, v483);
    } else {
      for (int64_t v542 = v27; v542 < v20; v542 += v18) {
        // pto: %280
        ;
        int64_t v543 = (int64_t) ((uint64_t) v81 + (uint64_t) v542);
        // pto: %281
        ;
        if (v543 < v5) {
          // pto: %282
          ;
          int64_t v544 = (int64_t) ((uint64_t) v543 * (uint64_t) v19);
          // pto: %283
          ;
          int64_t v545 = (int64_t) ((uint64_t) v8 - (uint64_t) v544);
          // pto: %284
          ;
          int64_t v546 = v545 < v19 ? v545 : v19;
          // pto: %286, %287, %288, %289, %285
          ;
          int32_t v547 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v543 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
          // pto: %290
          ;
          int64_t v548 = (int64_t) v547;
          // pto: %291
          ;
          int64_t v549 = v548 < v27 ? v27 : v548;
          // pto: %v4_narrow_acc_inline5466__tile
          ;
          Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v550 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v19, v26);
          // pto: %v4_narrow_acc_inline5466__tile
          ;
          uint64_t v551 = (uint64_t) v13;
          TASSIGN(v550, v551);
          wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          for (int64_t v552 = v27; v552 < v19; v552 += v18) {
            // pto: %292
            ;
            int64_t v553 = (int64_t) ((uint64_t) v552 * (uint64_t) v19);
            // pto: %293, %294
            ;
            int64_t v554 = (int64_t) ((uint64_t) v549 + (uint64_t) v553) % v23;
            // pto: %295, %296, %297
            ;
            int64_t v555 = v554 < v27 ? (int64_t) ((uint64_t) v554 + (uint64_t) v23) : v554;
            // pto: %298
            ;
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            if (v555 <= v36) {
              // pto: %299
              ;
              int64_t v556 = (int64_t) ((uint64_t) v555 * (uint64_t) v19);
              // pto: %v4_narrow_packet_x_inline5470__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v557 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v546, v23);
              // pto: %v4_narrow_packet_x_inline5470__tile
              ;
              uint64_t v558 = (uint64_t) v13;
              TASSIGN(v557, v558);
              // pto: %300
              ;
              int64_t v559 = v544 < v27 ? v27 : v544;
              // pto: %301, %302
              ;
              int64_t v560 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v34) + (uint64_t) v556);
              // pto: %303
              ;
              int64_t v561 = v560 < v27 ? v27 : v560;
              // pto: %304
              ;
              const int64_t v562 = 0;
              // pto: %304
              ;
              __gm__ bfloat16_t* v563 = PTOAS__GLOBAL_TENSOR_DATA(v58);
              // pto: %304
              ;
              const int64_t v564 = 1;
              // pto: %304
              ;
              const int64_t v565 = 1;
              // pto: %304
              ;
              const int64_t v566 = 1;
              // pto: %304
              ;
              int64_t v567 = v546 * v21;
              // pto: %304
              ;
              int64_t v568 = v566 * v567;
              // pto: %304
              ;
              pto::Shape<1, 1, 1, -1, 256> v569 = pto::Shape<1, 1, 1, -1, 256>(v564, v565, v566, v546, v23);
              // pto: %304
              ;
              pto::Stride<-1, -1, -1, -1, -1> v570 = pto::Stride<-1, -1, -1, -1, -1>(v565 * v568, v568, v567, v21, v18);
              // pto: %304
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v571 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v563 + (v562 + v559 * v21 + v561 * v18), v569, v570);
              TLOAD(v557, v571);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              // pto: %v4_narrow_packet_w_inline5471__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v572 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
              // pto: %v4_narrow_packet_w_inline5471__tile
              ;
              uint64_t v573 = (uint64_t) v12;
              TASSIGN(v572, v573);
              // pto: %305
              ;
              int64_t v574 = v6 < v27 ? v27 : v6;
              // pto: %306
              ;
              const int64_t v575 = 1;
              // pto: %306
              ;
              const int64_t v576 = 0;
              // pto: %306
              ;
              int64_t v577 = v71 / v19;
              // pto: %306
              ;
              bool v578 = v71 < v576;
              // pto: %306
              ;
              bool v579 = v19 < v576;
              // pto: %306
              ;
              bool v580 = v578 == v579;
              // pto: %306
              ;
              bool v581 = v71 % v19 != v576 && v578 != v579;
              // pto: %306
              ;
              int64_t v582 = v581 ? v577 - v575 : v577;
              // pto: %307
              ;
              int64_t v583 = v582 < v27 ? v27 : v582;
              // pto: %308
              ;
              const int64_t v584 = 1;
              // pto: %308
              ;
              const int64_t v585 = 0;
              // pto: %308
              ;
              int64_t v586 = v556 / v19;
              // pto: %308
              ;
              bool v587 = v556 < v585;
              // pto: %308
              ;
              bool v588 = v19 < v585;
              // pto: %308
              ;
              bool v589 = v587 == v588;
              // pto: %308
              ;
              bool v590 = v556 % v19 != v585 && v587 != v588;
              // pto: %308
              ;
              int64_t v591 = v590 ? v586 - v584 : v586;
              // pto: %309
              ;
              int64_t v592 = v591 < v27 ? v27 : v591;
              // pto: %310
              ;
              __gm__ bfloat16_t* v593 = PTOAS__GLOBAL_TENSOR_DATA(v61);
              // pto: %310
              ;
              const int64_t v594 = 0;
              // pto: %310
              ;
              const int64_t v595 = 4194304;
              // pto: %310
              ;
              const int64_t v596 = 65536;
              // pto: %310
              ;
              const int64_t v597 = 256;
              // pto: %310
              ;
              pto::Shape<1, 8, 16, 16, 16> v598 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %310
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v599 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %310
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v600 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v593 + ((v594 + v574 * v595) + v583 * v596 + v592 * v597), v598, v599);
              TLOAD(v572, v600);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              // pto: %v4_narrow_acc_inline5466__iter_v1_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v601 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v546, v26);
              // pto: %v4_narrow_acc_inline5466__iter_v1_l0_a
              ;
              uint64_t v602 = (uint64_t) v13;
              TASSIGN(v601, v602);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              uint16_t v603 = static_cast<uint16_t>(v27);
              uint16_t v604 = static_cast<uint16_t>(v27);
              TEXTRACT(v601, v557, v603, v604);
              // pto: %v4_narrow_acc_inline5466__iter_v1_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v605 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
              // pto: %v4_narrow_acc_inline5466__iter_v1_l0_b
              ;
              uint64_t v606 = (uint64_t) v13;
              TASSIGN(v605, v606);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              uint16_t v607 = static_cast<uint16_t>(v27);
              uint16_t v608 = static_cast<uint16_t>(v27);
              TEXTRACT(v605, v572, v607, v608);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              // pto: %33
              ;
              Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v609 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v546, v26);
              // pto: %33
              ;
              uint64_t v610 = (uint64_t) v14;
              TASSIGN(v609, v610);
              uint16_t v611 = static_cast<uint16_t>(v27);
              uint16_t v612 = static_cast<uint16_t>(v26);
              TEXTRACT(v609, v557, v611, v612);
              // pto: %34
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v613 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
              // pto: %34
              ;
              uint64_t v614 = (uint64_t) v14;
              TASSIGN(v613, v614);
              uint16_t v615 = static_cast<uint16_t>(v26);
              uint16_t v616 = static_cast<uint16_t>(v27);
              TEXTRACT(v613, v572, v615, v616);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              // pto: %311
              ;
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              if (v552 == v27) {
                pipe_barrier(PIPE_M);
                TMATMUL(v550, v601, v605);
              } else {
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v550, v550, v601, v605);
              };
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              TMATMUL_ACC(v550, v550, v609, v613);
            } else {
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              for (int64_t v617 = v27; v617 < v19; v617 += v18) {
                // pto: %312, %313
                ;
                int64_t v618 = (int64_t) ((uint64_t) v555 + (uint64_t) v617) % v23;
                // pto: %314, %315, %316
                ;
                int64_t v619 = v618 < v27 ? (int64_t) ((uint64_t) v618 + (uint64_t) v23) : v618;
                // pto: %317
                ;
                int64_t v620 = (int64_t) ((uint64_t) v619 * (uint64_t) v19);
                // pto: %v4_narrow_wrap_x_inline5474__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v621 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v546, v19);
                // pto: %v4_narrow_wrap_x_inline5474__tile
                ;
                uint64_t v622 = (uint64_t) v13;
                TASSIGN(v621, v622);
                // pto: %318
                ;
                int64_t v623 = v544 < v27 ? v27 : v544;
                // pto: %319, %320
                ;
                int64_t v624 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v34) + (uint64_t) v620);
                // pto: %321
                ;
                int64_t v625 = v624 < v27 ? v27 : v624;
                // pto: %322
                ;
                const int64_t v626 = 0;
                // pto: %322
                ;
                __gm__ bfloat16_t* v627 = PTOAS__GLOBAL_TENSOR_DATA(v58);
                // pto: %322
                ;
                const int64_t v628 = 1;
                // pto: %322
                ;
                const int64_t v629 = 1;
                // pto: %322
                ;
                const int64_t v630 = 1;
                // pto: %322
                ;
                int64_t v631 = v546 * v21;
                // pto: %322
                ;
                int64_t v632 = v630 * v631;
                // pto: %322
                ;
                pto::Shape<1, 1, 1, -1, 16> v633 = pto::Shape<1, 1, 1, -1, 16>(v628, v629, v630, v546, v19);
                // pto: %322
                ;
                pto::Stride<-1, -1, -1, -1, -1> v634 = pto::Stride<-1, -1, -1, -1, -1>(v629 * v632, v632, v631, v21, v18);
                // pto: %322
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v635 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v627 + (v626 + v623 * v21 + v625 * v18), v633, v634);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                TLOAD(v621, v635);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                // pto: %v4_narrow_wrap_w_inline5475__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v636 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
                // pto: %v4_narrow_wrap_w_inline5475__tile
                ;
                uint64_t v637 = (uint64_t) v12;
                TASSIGN(v636, v637);
                // pto: %323
                ;
                int64_t v638 = v6 < v27 ? v27 : v6;
                // pto: %324
                ;
                const int64_t v639 = 1;
                // pto: %324
                ;
                const int64_t v640 = 0;
                // pto: %324
                ;
                int64_t v641 = v71 / v19;
                // pto: %324
                ;
                bool v642 = v71 < v640;
                // pto: %324
                ;
                bool v643 = v19 < v640;
                // pto: %324
                ;
                bool v644 = v642 == v643;
                // pto: %324
                ;
                bool v645 = v71 % v19 != v640 && v642 != v643;
                // pto: %324
                ;
                int64_t v646 = v645 ? v641 - v639 : v641;
                // pto: %325
                ;
                int64_t v647 = v646 < v27 ? v27 : v646;
                // pto: %326
                ;
                const int64_t v648 = 1;
                // pto: %326
                ;
                const int64_t v649 = 0;
                // pto: %326
                ;
                int64_t v650 = v620 / v19;
                // pto: %326
                ;
                bool v651 = v620 < v649;
                // pto: %326
                ;
                bool v652 = v19 < v649;
                // pto: %326
                ;
                bool v653 = v651 == v652;
                // pto: %326
                ;
                bool v654 = v620 % v19 != v649 && v651 != v652;
                // pto: %326
                ;
                int64_t v655 = v654 ? v650 - v648 : v650;
                // pto: %327
                ;
                int64_t v656 = v655 < v27 ? v27 : v655;
                // pto: %328
                ;
                __gm__ bfloat16_t* v657 = PTOAS__GLOBAL_TENSOR_DATA(v61);
                // pto: %328
                ;
                const int64_t v658 = 0;
                // pto: %328
                ;
                const int64_t v659 = 4194304;
                // pto: %328
                ;
                const int64_t v660 = 65536;
                // pto: %328
                ;
                const int64_t v661 = 256;
                // pto: %328
                ;
                pto::Shape<1, 8, 1, 16, 16> v662 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %328
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v663 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %328
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v664 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v657 + ((v658 + v638 * v659) + v647 * v660 + v656 * v661), v662, v663);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                TLOAD(v636, v664);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                // pto: %36
                ;
                Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v665 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v546, v19);
                // pto: %36
                ;
                uint64_t v666 = (uint64_t) v13;
                TASSIGN(v665, v666);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                uint16_t v667 = static_cast<uint16_t>(v27);
                uint16_t v668 = static_cast<uint16_t>(v27);
                TEXTRACT(v665, v621, v667, v668);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                // pto: %37
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v669 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
                // pto: %37
                ;
                uint64_t v670 = (uint64_t) v13;
                TASSIGN(v669, v670);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                uint16_t v671 = static_cast<uint16_t>(v27);
                uint16_t v672 = static_cast<uint16_t>(v27);
                TEXTRACT(v669, v636, v671, v672);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                // pto: %330, %331
                ;
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                if ((int64_t) ((uint64_t) v553 + (uint64_t) v617) == v27) {
                  pipe_barrier(PIPE_M);
                  TMATMUL(v550, v665, v669);
                } else {
                  pipe_barrier(PIPE_M);
                  TMATMUL_ACC(v550, v550, v665, v669);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            };
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
          // pto: %333
          ;
          int64_t v673 = v544 < v27 ? v27 : v544;
          // pto: %334, %335
          ;
          int64_t v674 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v39) + (uint64_t) v71);
          // pto: %336
          ;
          int64_t v675 = v674 < v27 ? v27 : v674;
          // pto: %accum_inline5396__iter_v16_pview
          ;
          __gm__ float* v676 = PTOAS__GLOBAL_TENSOR_DATA(v49);
          // pto: %accum_inline5396__iter_v16_pview
          ;
          const int64_t v677 = 0;
          // pto: %accum_inline5396__iter_v16_pview
          ;
          const int64_t v678 = 8192;
          // pto: %accum_inline5396__iter_v16_pview
          ;
          pto::Shape<1, 1, 1, 16, 128> v679 = pto::Shape<1, 1, 1, 16, 128>();
          // pto: %accum_inline5396__iter_v16_pview
          ;
          pto::Stride<131072, 131072, 131072, 8192, 1> v680 = pto::Stride<131072, 131072, 131072, 8192, 1>();
          // pto: %accum_inline5396__iter_v16_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v681 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v676 + (v677 + v673 * v678 + v675), v679, v680);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
          pipe_barrier(PIPE_FIX);
          TSTORE(v681, v550);
          set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        };
      };
    };
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}