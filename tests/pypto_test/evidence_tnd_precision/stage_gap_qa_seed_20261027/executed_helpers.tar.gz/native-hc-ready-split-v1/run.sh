#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
label=${1:?}; batch=${2:?}; history=${3:?}; explicit_lengths=${4:?}
shift 4
reverse_capture=0
qualify_boundary=0
queue_device_seen=0
while (( $# )); do
  case "$1" in
    --reverse-capture) reverse_capture=1; shift ;;
    --qualify-boundary) qualify_boundary=1; shift ;;
    --device)
      if (( $# < 2 )) || [[ "$queue_device_seen" == 1 || "$2" != "$TASK_DEVICE" || ! "$2" =~ ^[0-9]+(,[0-9]+)*$ ]]; then exit 2; fi
      queue_device_seen=1
      shift 2 ;;
    *) echo "Unknown launch option: $1" >&2; exit 2 ;;
  esac
done
set --
if [[ "$reverse_capture" == 1 ]]; then set -- "$@" --reverse-capture; fi
if [[ "$qualify_boundary" == 1 ]]; then set -- "$@" --qualify-boundary; fi
[[ "$label" =~ ^[a-z0-9-]+$ && "$batch" =~ ^[0-9]+$ && "$history" =~ ^[0-9]+$ ]]
[[ "$explicit_lengths" =~ ^[1-6](,[1-6])*$ ]]
IFS=, read -r -a query_lengths <<< "$explicit_lengths"
if [[ "${#query_lengths[@]}" != "$batch" ]]; then
  echo "Expected batch $batch, actual query count ${#query_lengths[@]}" >&2
  exit 2
fi
tw_job_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source "$tw_job_root/env.sh"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
out="$tw_job_root/results/$label"
test ! -e "$out"
mkdir -p "$tw_job_root/results"
export PREFLIGHT_RECEIPT="$out-preflight.json"
export ASCEND_CACHE_PATH="$out-ascend-cache" ASCEND_PROCESS_LOG_PATH="$out-ascend-log" VLLM_CACHE_ROOT="$out-vllm-cache"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH"
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$SOURCE_ROOT/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$out-opp-env")
lengths="$explicit_lengths"
ccache -s > "$out-ccache.txt"
printf 'TASK_RUN_START %s\n' "$(date -Iseconds)"
trap 'printf "TASK_RUN_END %s\n" "$(date -Iseconds)"' EXIT
timeout --signal=TERM --kill-after=15s 750s python "$tw_job_root/device.py" --out "$out" --expected-batch "$batch" --lengths "$lengths" --layer 4 --history "$history" "$@" > "$out-run.log" 2>&1
