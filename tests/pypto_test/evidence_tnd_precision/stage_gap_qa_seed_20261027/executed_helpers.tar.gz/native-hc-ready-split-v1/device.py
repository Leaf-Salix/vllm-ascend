"""Bind the existing compatible SDK before importing the benchmark."""
from pathlib import Path
import runpy
import sys
root=Path(__file__).resolve().parent
args=sys.argv[1:]
runpy.run_path(str(root/'sdk_bind.py'),run_name='__sdk_preflight__')
sys.argv=[str(root/'probe_perf.py'),*args]
runpy.run_path(sys.argv[0],run_name='__main__')
