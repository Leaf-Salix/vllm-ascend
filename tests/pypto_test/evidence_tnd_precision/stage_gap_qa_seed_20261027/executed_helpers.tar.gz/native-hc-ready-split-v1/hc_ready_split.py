"""HC/Norm ready task plus independent projection-tail task; Native helper math unchanged."""
import pypto.language as pl
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.hc_prefix_indexer_stages import VEC_ROWS, indexer_projection_matmul, indexer_projection_round, packed_hc_comb, packed_hc_linear_reduce, packed_hc_mix, packed_hc_pre_post, packed_hc_rms, packed_norm_rows
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.hc_prefix_stages import P16, PARTIAL_ROWS, hc_linear, hc_pack_input, hc_pack_weight, hc_square, hc_widen
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.norm_wkv_stages import ACC_ROWS, T, wkv_matmul, wkv_round
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.rendezvous import GROUPS, handoff
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.input_layout import hc_pack_input_bf16

@pl.jit.incore
def hc_ready_cube(wide: pl.Tensor[[T, 16384], pl.FP32], square: pl.InOut[pl.Tensor[[PARTIAL_ROWS, 16], pl.FP32]], packed_weight: pl.Tensor[[32768, 32], pl.BF16], packed_flat: pl.Tensor[[P16, 32768], pl.BF16], linear: pl.InOut[pl.Tensor[[PARTIAL_ROWS, 32], pl.FP32]], ffts: pl.Tensor[[256], pl.INT64]):
    pl.system.set_ffts(ffts)
    worker = pl.tile.get_block_idx()
    handoff()
    square = hc_square(wide, square, worker)
    handoff()
    linear = hc_linear(wide, packed_flat, packed_weight, linear, worker)
    handoff()
    handoff()
    handoff()
    handoff()
    handoff()
    return (square, linear)

@pl.jit.incore
def hc_ready_vector(flat: pl.Tensor[[T, 16384], pl.BF16], wide: pl.InOut[pl.Tensor[[T, 16384], pl.FP32]], square_read: pl.Tensor[[PARTIAL_ROWS, 16], pl.FP32], vec_ws: pl.InOut[pl.Tensor[[VEC_ROWS, 64], pl.FP32]], packed_flat: pl.InOut[pl.Tensor[[P16, 32768], pl.BF16]], linear_read: pl.Tensor[[PARTIAL_ROWS, 32], pl.FP32], hc_scale: pl.Tensor[[3], pl.FP32], hc_base: pl.Tensor[[24], pl.FP32], post: pl.InOut[pl.Tensor[[T, 4], pl.FP32]], mixed: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]], mixed_tail: pl.InOut[pl.Tensor[[8, 4096], pl.BF16]], gamma: pl.Tensor[[4096], pl.BF16], normalized: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]], ffts: pl.Tensor[[256], pl.INT64]):
    pl.func_attr({'split_aiv': True})
    pl.system.set_ffts(ffts)
    worker = pl.tile.get_block_idx() * 2 + pl.tile.get_subblock_idx()
    wide = hc_widen(flat, wide, worker)
    handoff()
    if pl.tensor.dim(flat, 0) >= 64:
        packed_flat = hc_pack_input_bf16(wide, packed_flat, worker)
    else:
        packed_flat = hc_pack_input(wide, packed_flat, worker)
    handoff()
    vec_ws = packed_hc_rms(square_read, vec_ws, wide, worker)
    handoff()
    vec_ws = packed_hc_linear_reduce(linear_read, vec_ws, worker)
    handoff()
    vec_ws, post = packed_hc_pre_post(vec_ws, hc_scale, hc_base, post, worker)
    handoff()
    mixed, mixed_tail = packed_hc_mix(wide, vec_ws, mixed, mixed_tail, worker)
    handoff()
    normalized, vec_ws = packed_norm_rows(mixed, gamma, normalized, vec_ws, worker)
    handoff()
    return (wide, vec_ws, packed_flat, post, mixed, mixed_tail, normalized)

@pl.jit.inline(auto_scope=False)
def hc_ready_group(hc_scale: pl.Tensor[[3], pl.FP32], hc_base: pl.Tensor[[24], pl.FP32], gamma: pl.Tensor[[4096], pl.BF16], wide: pl.InOut[pl.Tensor[[T, 16384], pl.FP32]], square: pl.InOut[pl.Tensor[[PARTIAL_ROWS, 16], pl.FP32]], square_read: pl.Tensor[[PARTIAL_ROWS, 16], pl.FP32], vec_ws: pl.InOut[pl.Tensor[[VEC_ROWS, 64], pl.FP32]], packed_weight: pl.Tensor[[32768, 32], pl.BF16], packed_flat: pl.InOut[pl.Tensor[[P16, 32768], pl.BF16]], linear: pl.InOut[pl.Tensor[[PARTIAL_ROWS, 32], pl.FP32]], linear_read: pl.Tensor[[PARTIAL_ROWS, 32], pl.FP32], post: pl.InOut[pl.Tensor[[T, 4], pl.FP32]], mixed: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]], mixed_tail: pl.InOut[pl.Tensor[[8, 4096], pl.BF16]], normalized: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]], ffts: pl.Tensor[[256], pl.INT64], flat: pl.Tensor[[T, 16384], pl.BF16]):
    with pl.cluster(name_hint='precision_hc_ready_group'):
        square, linear = hc_ready_cube(wide, square, packed_weight, packed_flat, linear, ffts)
        wide, vec_ws, packed_flat, post, mixed, mixed_tail, normalized = hc_ready_vector(flat, wide, square_read, vec_ws, packed_flat, linear_read, hc_scale, hc_base, post, mixed, mixed_tail, gamma, normalized, ffts)
    return (square, linear, wide, vec_ws, packed_flat, post, mixed, mixed_tail, normalized)

@pl.jit.incore
def projection_tail_cube(normalized: pl.Tensor[[T, 4096], pl.BF16], weight: pl.Tensor[[512, 4096], pl.BF16], order: pl.Tensor[[32, 16], pl.INT32], accum: pl.InOut[pl.Tensor[[ACC_ROWS, 512], pl.FP32]], ffts: pl.Tensor[[256], pl.INT64], idx_weight: pl.Tensor[[64, 4096], pl.BF16], idx_order: pl.Tensor[[16, 4, 16], pl.INT32], idx_accum: pl.InOut[pl.Tensor[[P16, 64], pl.FP32]]):
    pl.system.set_ffts(ffts)
    worker = pl.tile.get_block_idx()
    accum = wkv_matmul(normalized, weight, order, accum, worker)
    idx_accum = indexer_projection_matmul(normalized, idx_weight, idx_order, idx_accum, worker)
    handoff()
    handoff()
    return (accum, idx_accum)

@pl.jit.incore
def projection_tail_vector(vec_ws: pl.InOut[pl.Tensor[[VEC_ROWS, 64], pl.FP32]], hc_scale: pl.Tensor[[3], pl.FP32], hc_base_2d: pl.Tensor[[1, 24], pl.FP32], comb: pl.InOut[pl.Tensor[[T, 16], pl.FP32]], accum_read: pl.Tensor[[ACC_ROWS, 512], pl.FP32], output: pl.InOut[pl.Tensor[[T, 512], pl.BF16]], ffts: pl.Tensor[[256], pl.INT64], idx_accum_read: pl.Tensor[[P16, 64], pl.FP32], idx_raw: pl.InOut[pl.Tensor[[T, 64], pl.BF16]], idx_scaled: pl.InOut[pl.Tensor[[T, 64], pl.BF16]], idx_output: pl.InOut[pl.Tensor[[T, 64], pl.FP16]]):
    pl.func_attr({'split_aiv': True})
    pl.system.set_ffts(ffts)
    worker = pl.tile.get_block_idx() * 2 + pl.tile.get_subblock_idx()
    vec_ws, comb = packed_hc_comb(vec_ws, hc_scale, hc_base_2d, comb, False, worker)
    handoff()
    output = wkv_round(accum_read, output, worker)
    idx_raw, idx_scaled, idx_output = indexer_projection_round(idx_accum_read, idx_raw, idx_scaled, idx_output, worker)
    handoff()
    return (vec_ws, comb, output, idx_raw, idx_scaled, idx_output)

@pl.jit.inline(auto_scope=False)
def projection_tail_group(hc_scale: pl.Tensor[[3], pl.FP32], weight: pl.Tensor[[512, 4096], pl.BF16], order: pl.Tensor[[32, 16], pl.INT32], vec_ws: pl.InOut[pl.Tensor[[VEC_ROWS, 64], pl.FP32]], comb: pl.InOut[pl.Tensor[[T, 16], pl.FP32]], normalized: pl.Tensor[[T, 4096], pl.BF16], accum: pl.InOut[pl.Tensor[[ACC_ROWS, 512], pl.FP32]], accum_read: pl.Tensor[[ACC_ROWS, 512], pl.FP32], output: pl.InOut[pl.Tensor[[T, 512], pl.BF16]], ffts: pl.Tensor[[256], pl.INT64], hc_base_2d: pl.Tensor[[1, 24], pl.FP32], idx_weight: pl.Tensor[[64, 4096], pl.BF16], idx_order: pl.Tensor[[16, 4, 16], pl.INT32], idx_accum: pl.InOut[pl.Tensor[[P16, 64], pl.FP32]], idx_accum_read: pl.Tensor[[P16, 64], pl.FP32], idx_raw: pl.InOut[pl.Tensor[[T, 64], pl.BF16]], idx_scaled: pl.InOut[pl.Tensor[[T, 64], pl.BF16]], idx_output: pl.InOut[pl.Tensor[[T, 64], pl.FP16]]):
    with pl.cluster(name_hint='precision_projection_tail_group'):
        accum, idx_accum = projection_tail_cube(normalized, weight, order, accum, ffts, idx_weight, idx_order, idx_accum)
        vec_ws, comb, output, idx_raw, idx_scaled, idx_output = projection_tail_vector(vec_ws, hc_scale, hc_base_2d, comb, accum_read, output, ffts, idx_accum_read, idx_raw, idx_scaled, idx_output)
    return (accum, idx_accum, vec_ws, comb, output, idx_raw, idx_scaled, idx_output)
