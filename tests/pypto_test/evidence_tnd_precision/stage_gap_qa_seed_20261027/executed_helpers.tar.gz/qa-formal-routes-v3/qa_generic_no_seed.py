"""QA preserves seed for atomic/split-K, omits dead pre-zero only for unique non-atomic writer."""
import pypto.language as pl
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.qkv_proj_rope import ATOMIC_ADD, BF16_WEIGHT_LAYOUT, D, QPROJ_MM_T_DYN, QR_DENSE_M_TILE, QR_K_TILE, QR_M_TILE, QR_NATIVE_K_BLOCKS, QR_NATIVE_N_GROUP, QR_NATIVE_PAIR_SHIFT, QR_NATIVE_SHIFT_GROUPS, QR_NATIVE_SHIFT_MAX_ROWS, QR_NATIVE_SHIFT_MIN_ROWS, QR_NATIVE_SHIFT_ROW_STEP, QR_N_TILE, QR_OK, QR_SPLIT_K_TILE, Q_LORA, STORE_ATOMIC, T_DYN

@pl.jit.inline(auto_scope=False)
def q_proj_qa(x: pl.Tensor[[T_DYN, D], pl.BF16], wq_a: pl.Tensor[[Q_LORA, D], pl.BF16, BF16_WEIGHT_LAYOUT], qr_fp32: pl.Out[pl.Tensor[[QPROJ_MM_T_DYN, Q_LORA], pl.FP32]], tile_base: pl.Scalar[pl.INDEX], tile_rows: pl.Scalar[pl.INDEX]):
    """Reference QA matmul, shared by the production QR and its diagnostic."""
    qa_tokens = pl.tensor.dim(x, 0)
    x_view = pl.reshape(x, [qa_tokens, D])
    qr_t_matmul = (tile_rows + QR_M_TILE - 1) // QR_M_TILE * QR_M_TILE
    qr_full_rows = tile_rows // QR_DENSE_M_TILE * QR_DENSE_M_TILE
    if ATOMIC_ADD or QR_OK != 1:
        with pl.at(level=pl.Level.CORE_GROUP, name_hint='qr_proj_seed'):
            for ts0 in pl.range(0, qr_t_matmul, QR_M_TILE):
                for nseed0 in pl.range(0, Q_LORA, QR_N_TILE):
                    qr_seed = pl.full([QR_M_TILE, QR_N_TILE], dtype=pl.FP32, value=0.0)
                    qr_fp32[ts0:ts0 + QR_M_TILE, nseed0:nseed0 + QR_N_TILE] = qr_seed
    for qbg_idx in pl.spmd(Q_LORA // QR_N_TILE * QR_OK, name_hint='qr_proj_matmul', allow_early_resolve=True):
        q_a_col0 = qbg_idx // QR_OK * QR_N_TILE
        qr_k_base = qbg_idx % QR_OK * QR_SPLIT_K_TILE
        qr_native_group = q_a_col0 // QR_NATIVE_N_GROUP
        for dense_t0 in pl.range(0, qr_full_rows, QR_DENSE_M_TILE):
            dense_x0 = tile_base + dense_t0
            dense_acc = pl.create_tensor([QR_DENSE_M_TILE, QR_N_TILE], dtype=pl.FP32)
            for dense_k in pl.pipeline(0, QR_SPLIT_K_TILE // QR_K_TILE, stage=2):
                dense_k_order = dense_k
                if tile_rows >= QR_NATIVE_SHIFT_MIN_ROWS and tile_rows <= QR_NATIVE_SHIFT_MAX_ROWS and (tile_rows % QR_NATIVE_SHIFT_ROW_STEP == 0) and (qr_native_group < QR_NATIVE_SHIFT_GROUPS):
                    dense_k_direction = dense_k
                    if qr_native_group % 2 == 1:
                        dense_k_direction = QR_NATIVE_K_BLOCKS - 1 - dense_k
                    dense_k_order = (qr_native_group // 2 * QR_NATIVE_PAIR_SHIFT + dense_k_direction) % QR_NATIVE_K_BLOCKS
                dense_d0 = qr_k_base + pl.max(dense_k_order, 0) * QR_K_TILE
                dense_x = x_view[dense_x0:dense_x0 + QR_DENSE_M_TILE, dense_d0:dense_d0 + QR_K_TILE]
                dense_w = wq_a[q_a_col0:q_a_col0 + QR_N_TILE, dense_d0:dense_d0 + QR_K_TILE]
                dense_acc = pl.matmul_acc(dense_acc, dense_x, dense_w, b_trans=True, init_cond=dense_k == 0)
            qr_fp32 = pl.assemble(qr_fp32, dense_acc, [dense_t0, q_a_col0], atomic=STORE_ATOMIC)
        for t0 in pl.range(qr_full_rows, qr_t_matmul, QR_M_TILE):
            q_acc = pl.create_tensor([QR_M_TILE, QR_N_TILE], dtype=pl.FP32)
            for db in pl.pipeline(QR_SPLIT_K_TILE // QR_K_TILE, stage=2):
                qr_k_order = db
                if tile_rows >= QR_NATIVE_SHIFT_MIN_ROWS and tile_rows <= QR_NATIVE_SHIFT_MAX_ROWS and (tile_rows % QR_NATIVE_SHIFT_ROW_STEP == 0) and (qr_native_group < QR_NATIVE_SHIFT_GROUPS):
                    qr_k_direction = db
                    if qr_native_group % 2 == 1:
                        qr_k_direction = QR_NATIVE_K_BLOCKS - 1 - db
                    qr_k_order = (qr_native_group // 2 * QR_NATIVE_PAIR_SHIFT + qr_k_direction) % QR_NATIVE_K_BLOCKS
                qr_d0 = qr_k_base + pl.max(qr_k_order, 0) * QR_K_TILE
                qr_rows = pl.min(QR_M_TILE, tile_rows - t0)
                x_t0 = tile_base + t0
                q_x_chunk_bf16 = pl.slice(x_view, [QR_M_TILE, QR_K_TILE], [x_t0, qr_d0], valid_shape=[qr_rows, QR_K_TILE])
                w_chunk = wq_a[q_a_col0:q_a_col0 + QR_N_TILE, qr_d0:qr_d0 + QR_K_TILE]
                q_acc = pl.matmul_acc(q_acc, q_x_chunk_bf16, w_chunk, b_trans=True, init_cond=db == 0)
            qr_fp32 = pl.assemble(qr_fp32, q_acc, [t0, q_a_col0], atomic=STORE_ATOMIC)
