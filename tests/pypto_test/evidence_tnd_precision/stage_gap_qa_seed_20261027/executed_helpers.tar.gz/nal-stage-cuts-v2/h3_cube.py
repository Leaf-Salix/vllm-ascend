# SPDX-License-Identifier: Apache-2.0
"""Single-SPMD HC/Norm/WKV/Indexer-weight prefix with a 32-tensor MIX ABI."""

import pypto.language as pl

from .hc_prefix_indexer_stages import (
    VEC_ROWS,
    indexer_projection_matmul,
    indexer_projection_round,
    packed_hc_comb,
    packed_hc_linear_reduce,
    packed_hc_mix,
    packed_hc_pre_post,
    packed_hc_rms,
    packed_norm_rows,
)
from .hc_prefix_stages import (
    P16,
    PARTIAL_ROWS,
    hc_linear,
    hc_pack_input,
    hc_pack_weight,
    hc_square,
    hc_widen,
)
from .norm_wkv_stages import ACC_ROWS, T, wkv_matmul, wkv_round
from .rendezvous import GROUPS, handoff


@pl.jit.incore
def packed_prefix_indexer_cube(
    wide: pl.Tensor[[T, 16384], pl.FP32],
    square: pl.InOut[pl.Tensor[[PARTIAL_ROWS, 16], pl.FP32]],
    packed_weight: pl.Tensor[[32768, 32], pl.BF16],
    packed_flat: pl.Tensor[[P16, 32768], pl.BF16],
    linear: pl.InOut[pl.Tensor[[PARTIAL_ROWS, 32], pl.FP32]],
    normalized: pl.Tensor[[T, 4096], pl.BF16],
    weight: pl.Tensor[[512, 4096], pl.BF16],
    order: pl.Tensor[[32, 16], pl.INT32],
    accum: pl.InOut[pl.Tensor[[ACC_ROWS, 512], pl.FP32]],
    ffts: pl.Tensor[[256], pl.INT64],
    idx_weight: pl.Tensor[[64, 4096], pl.BF16],
    idx_order: pl.Tensor[[16, 4, 16], pl.INT32],
    idx_accum: pl.InOut[pl.Tensor[[P16, 64], pl.FP32]],
):
    pl.system.set_ffts(ffts)
    worker = pl.tile.get_block_idx()
    handoff()
    square = hc_square(wide, square, worker)
    handoff()
    linear = hc_linear(wide, packed_flat, packed_weight, linear, worker)
    handoff()
    handoff()
    handoff()
    handoff()
    handoff()
    accum = wkv_matmul(normalized, weight, order, accum, worker)
    idx_accum = indexer_projection_matmul(normalized, idx_weight, idx_order, idx_accum, worker)
    handoff()
    handoff()
    return (square, linear, accum, idx_accum)
