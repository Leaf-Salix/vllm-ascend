#!/usr/bin/env bash
set -euo pipefail
tw_job_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
arm=${1:?}
source "$tw_job_root/env.sh"
export ASCEND_RT_VISIBLE_DEVICES="" PREFLIGHT_RECEIPT="$tw_job_root/compile-$arm-sdk.json"
mkdir -p "$tw_job_root/results"
ccache -s
timeout 700s python "$tw_job_root/compile.py" "$arm" > "$tw_job_root/compile-$arm.log" 2>&1
