"""Bind the actual V5 snapshot and all43 runtime sources; no device/model init."""
import hashlib,json,os,sys
from pathlib import Path
PACKAGES=('deepseek_v4_flash_csa_tnd_precision','deepseek_v4_flash_csa_tnd_full_precision')
def source_identity():
 here=Path(__file__).resolve().parent;binding=json.loads((here/'binding.json').read_text());source=Path(os.environ['SOURCE_ROOT']).resolve()
 assert str(source)==binding['source_root'] and source.name=='source' and source.parent.name=='snapshot'
 whole_helper=source.parent.parent
 assert all(Path(p or '.').resolve()!=whole_helper for p in sys.path),'whole helper must not contaminate single-layer runner'
 custom=sys.modules.get('sitecustomize')
 if custom is not None and getattr(custom,'__file__',None):assert Path(custom.__file__).resolve().parent!=whole_helper
 raw=(source.parent/'manifest.json').read_bytes();digest=hashlib.sha256(raw).hexdigest();assert digest==binding['source_manifest_sha256']
 manifest=json.loads(raw);assert len(manifest['files'])==binding['source_file_count']
 for rel,expected in manifest['files'].items():assert hashlib.sha256((source/rel).read_bytes()).hexdigest()==expected,rel
 paths={p for name in PACKAGES for p in (source/'vllm_ascend/ops/pypto'/name).rglob('*.py')};paths.update((source/'vllm_ascend/ops/pypto/variant.py',source/'vllm_ascend/ops/dsv4_csa.py'))
 tested={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
 assert len(tested)==43 and tested==binding['tested_sources'],'43 source SHA mismatch'
 assert all(manifest['files'].get(rel)==value for rel,value in tested.items())
 receipt_path=Path(binding['canonical_job'])/'compile-receipt.json'
 assert hashlib.sha256(receipt_path.read_bytes()).hexdigest()==binding['compile_receipt_sha256']
 receipt=json.loads(receipt_path.read_text())
 for flag in ('compiled','kernel_abi_pass','orchestration_compiled','prepare_compiled'):assert receipt[flag] is True
 assert receipt['npu_initialized_after'] is False and receipt['source_root']==str(source)
 assert receipt['source_manifest_sha256']==digest
 runtime_path=Path(binding['canonical_job'])/'runtime77.json'
 assert hashlib.sha256(runtime_path.read_bytes()).hexdigest()==binding['runtime77_sha256']==receipt['runtime77_sha256']
 runtime=json.loads(runtime_path.read_text())
 runtime_files=runtime['files'] if 'files' in runtime else runtime
 assert len(runtime_files)==77
 for rel,expected in runtime_files.items():assert hashlib.sha256((source/rel).read_bytes()).hexdigest()==expected,rel
 import importlib
 suffixes=('deepseek_v4_flash_csa_tnd_precision_spmd_overlap.decode_csa','deepseek_v4_flash_csa_tnd_precision_spmd_overlap.service','deepseek_v4_flash_csa_tnd_precision_spmd_overlap.native_adapter','deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.qkv_precision126')
 for suffix in suffixes:
  mod=importlib.import_module('vllm_ascend.ops.pypto.'+suffix)
  assert Path(mod.__file__).resolve().is_relative_to(source),(suffix,mod.__file__)
 assert mod.QA_NATIVE_PACKET_ROWS==126 and mod.QA_NATIVE_PACKET_ROWS_B28==168
 assert hashlib.sha256(Path(mod.__file__).read_bytes()).hexdigest()==binding['qa_sha256']==receipt['qa_sha256']
 return {'source_manifest_sha256':digest,'source_file_count':len(manifest['files']),'tested_sources':tested,'source_root':str(source),'whole_model_sitecustomize':False,'runtime77':runtime_files,'canonical_compile_receipt_sha256':binding['compile_receipt_sha256'],'qa_sha256':binding['qa_sha256'],'formal_math_commit':binding['formal_math_commit']}
