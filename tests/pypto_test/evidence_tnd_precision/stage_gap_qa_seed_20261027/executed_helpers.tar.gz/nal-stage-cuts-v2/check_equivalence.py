"""执行原Scalar和候选Vector的真实DSL AST；逐元素整数等价及表访问边界。"""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("checked_pair_ast", HERE.parent / "check_integer_equivalence.py")
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)


class VectorPL(old.ScalarPL):
    UINT32 = "uint32"
    FP32 = "float32"
    reshape = staticmethod(np.reshape)
    stores = 0
    fast_rows = 0

    @staticmethod
    def create_tile(shape, dtype):
        return np.zeros(shape, dtype=dtype)

    @staticmethod
    def cast(value, dtype):
        if isinstance(value, np.ndarray):
            return value.astype(dtype)
        return old.ScalarPL.cast(value, dtype)

    @staticmethod
    def load(table, offsets, shape, valid_shape=None):
        rows, cols = valid_shape or shape
        r, c = offsets
        assert r >= 0 and c >= 0 and r + rows <= table.shape[0] and c + cols <= table.shape[1]
        result = np.full(shape, -123456789, dtype=np.int32)
        result[:rows, :cols] = np.asarray(table.rows, dtype=np.int32)[r:r+rows, c:c+cols]
        return result

    @classmethod
    def store(cls, value, offsets, table):
        cls.stores += 1
        r, c = offsets
        assert r >= 0 and c >= 0 and r + value.shape[0] <= table.shape[0] and c + value.shape[1] <= table.shape[1]
        for i, row in enumerate(value):
            table.rows[r+i][c:c+len(row)] = row.tolist()

    @staticmethod
    def read(table, indices):
        if isinstance(table, np.ndarray):
            assert all(0 <= v < n for v, n in zip(indices, table.shape, strict=True))
            return table[tuple(indices)].item()
        return old.ScalarPL.read(table, indices)

    @staticmethod
    def row_max(value, scratch):
        return value.max(axis=1, keepdims=True)


def tile_write(tile, indices, value):
    tile[tuple(indices)] = value


def gather(src, indices, scratch):
    assert np.all(indices >= 0) and np.all(indices < src.size)
    return src.reshape(-1)[indices]


VectorPL.tile = SimpleNamespace(
    full=lambda shape, dtype, value: np.full(shape, value, dtype=dtype),
    ci=lambda start, shape, dtype: np.arange(start, start+np.prod(shape), dtype=dtype).reshape(shape),
    sel=lambda mask, lhs, rhs, tmp: np.where(mask, lhs, rhs),
    cmps=lambda lhs, rhs, cmp_type: [np.equal, np.not_equal, np.less, np.less_equal, np.greater, np.greater_equal][cmp_type](lhs, rhs),
    write=tile_write, gather=gather, maximums=np.maximum, minimums=np.minimum,
    shrs=np.right_shift, shls=np.left_shift, ands=np.bitwise_and,
    add=np.add, adds=np.add, sub=np.subtract, mul=np.multiply, muls=np.multiply,
)


def executable(path, implementation):
    tree = ast.parse(path.read_text())
    helpers = []
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in (
            "checked_compressed_index", "native_compressed_pair_swap", "vector_native_pair_indices"
        ):
            node = copy.deepcopy(node)
            node.decorator_list = []
            node.returns = None
            for arg in node.args.args:
                arg.annotation = None
            helpers.append(node)
    function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "sparse_attn_csa")
    loop = next(n for n in ast.walk(function) if isinstance(n, ast.For) and isinstance(n.target, ast.Name) and n.target.id == "checked_t")
    wrapper = ast.parse("def run(position_ids, token_request, seq_lens, cmp_block_table, idx_topk, cmp_sparse_indices):\n    checked_t = 0\n").body[0]
    wrapper.body.extend(copy.deepcopy(loop.body))
    module = ast.fix_missing_locations(ast.Module(body=helpers + [wrapper], type_ignores=[]))
    env = dict(pl=implementation, BLOCK_SIZE=32, HEAD_DIM=512, KV_ELEMENT_BYTES=2,
               KV_PAIR_MAX_STRIDE_BYTES=2**31-1, COMPRESS_RATIO=4, IDX_TOPK=512)
    exec(compile(module, str(path), "exec"), env)
    if "vector_native_pair_indices" in env:
        helper=env["vector_native_pair_indices"]
        def counted(*args):
            VectorPL.fast_rows+=1
            return helper(*args)
        env["vector_native_pair_indices"]=counted
    return env["run"]


def main():
    original = old.ORIGINAL
    candidate = HERE / "vector_sparse.py"
    reference = executable(original, old.ScalarPL)
    actual = executable(candidate, VectorPL)
    rng = np.random.default_rng(1024)
    count = 0
    for columns in (0, 1, 2, 17, 1026, 2048, 2049):
        for limit in (0, 1, 2, 31, 32, 33, 511, 512, 32768, 2**31-1, 2**31):
            for mode in range(8):
                pages = rng.choice(np.array([-2**31, -1, 0, 1, 65536, 65537, 2**24-1], dtype=np.int32), size=columns)
                if mode == 1 and columns:
                    pages[0] = 2**24
                if mode == 2 and columns:
                    pages[0] = 2**31-1
                request = -1 if mode == 3 else 1 if mode == 4 else 0
                length = 0 if mode == 5 else 1
                raw = rng.integers(-2, max(min(limit+2, 2**31-1), 2), size=512, dtype=np.int32)
                raw[:14] = [-1, -1, 1, 0, 0, 0, 31, 32, 32, 31, min(limit-1, 2**31-1), 0, 2**31-1, -2**31]
                args = (old.Table([[limit*4-1]]), old.Table([[request]]),
                        SimpleNamespace(shape=(1,), read=lambda idx: length if idx == [0] else (_ for _ in ()).throw(AssertionError(idx))),
                        old.Table([pages.tolist()]), old.Table([raw.tolist()]))
                a, b = old.Table([[99]*512]), old.Table([[99]*512])
                reference(*args, a)
                actual(*args, b)
                assert a.rows == b.rows, (columns, limit, mode, np.flatnonzero(np.asarray(a.rows) != b.rows)[:8])
                count += 1
    assert VectorPL.fast_rows > 50, "Fast Vector path was not exercised"
    record = dict(pass_=True, cases=count, pairs=count*256, fast_rows=VectorPL.fast_rows,
                  method="Execute actual Scalar/Vector AST; NumPy INT32 wraps, every table/gather access bounded; oversized pages/limits/width fallback", device_execution=False,
                  original_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),
                  candidate_sha256=hashlib.sha256(candidate.read_bytes()).hexdigest())
    record["pass"] = record.pop("pass_")
    (HERE / "INTEGER_EQUIVALENCE.json").write_text(json.dumps(record, indent=2)+"\n")
    print(json.dumps(record))


if __name__ == "__main__":
    main()
