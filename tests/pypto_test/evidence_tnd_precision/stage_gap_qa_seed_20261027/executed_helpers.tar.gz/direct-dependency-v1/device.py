from pathlib import Path
import hashlib,json,runpy,sys
here=Path(__file__).resolve().parent
assert all(hashlib.sha256((here/k).read_bytes()).hexdigest()==v for k,v in json.loads((here/'manifest.json').read_text()).items())
parent=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-sdk-alignment-20261026-codex/nal-stage-cuts-v2')
assert hashlib.sha256((parent/'probe_common.py').read_bytes()).hexdigest()=='0812c71873435e2012f44443961ee7373ccb31e2d5a7a17e8eaf2607648e4dd2'
sys.path.insert(0,str(parent))
runpy.run_path(str(parent/'sdk_bind.py'),run_name='__sdk_preflight__')
text=(here/'derived_probe.py').read_text()
assert hashlib.sha256(text.encode()).hexdigest()=='7df5a02fe5bb4dda6af911d7e5b64214641b1074c3b62a99a0ac9a7b990b907f'
exec(compile(text,str(parent/'probe_common.py'),'exec'),{'__name__':'__main__','__file__':str(parent/'probe_common.py'),'PARENT_SHA':'0812c71873435e2012f44443961ee7373ccb31e2d5a7a17e8eaf2607648e4dd2','DERIVED_SHA':'7df5a02fe5bb4dda6af911d7e5b64214641b1074c3b62a99a0ac9a7b990b907f'})
