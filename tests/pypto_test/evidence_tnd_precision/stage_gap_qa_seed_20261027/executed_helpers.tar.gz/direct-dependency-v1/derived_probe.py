"""8K真实权重、Native/TND完整CSA FULL图验收；首差停止。"""
import argparse
import contextlib
import hashlib
import importlib
import json
import os
import importlib.util
from pathlib import Path
import statistics
import sys
import types

import torch
import torch_npu
import pypto.torch
from vllm.config import CUDAGraphMode
from vllm.engine.arg_utils import EngineArgs
from vllm.forward_context import get_forward_context
from vllm.platforms import current_platform
from vllm_ascend.ascend_forward_context import set_ascend_forward_context
import vllm_ascend.ops.dsv4_csa
from dsv4_csa_native_case import native_session
from dsv4_csa_single_layer import make_layer, restore, collect_state, guard_checks
from ragged_fixture import make_ragged_fixture
from npugraph_ex._acl_concrete_graph.acl_graph import AclGraph

ROOT = Path(__file__).resolve().parent
BASE = Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
META_SHA = '863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--lengths', default='1,1,1,1')
parser.add_argument('--layer', type=int, default=4)
parser.add_argument('--history', type=int, default=8191)
parser.add_argument('--nal-metadata-producer',action='store_true')
parser.add_argument('--mode', choices=('dep',), required=True)
args = parser.parse_args()
lengths = list(map(int,args.lengths.split(',')))
tokens, batch = sum(lengths), len(lengths)
assert all(1<=q<=6 for q in lengths) and batch<=40 and tokens<=256
assert all(q==6 for q in lengths), 'four-arm comparison uses uniform S6: Nal NativeCSACall adapter requires it'
assert not (args.out/'result.json').exists()
args.out.mkdir(parents=True,exist_ok=True)
expected_helpers=json.loads((ROOT/'manifest.json').read_text())
helper_sha={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in expected_helpers}
assert helper_sha==expected_helpers,'helper source identity mismatch'
manifest_sha=hashlib.sha256((ROOT/'manifest.json').read_bytes()).hexdigest()
report = {'helper_sha':helper_sha,'manifest_sha256':manifest_sha,'complete':False,'pass':False,'scope':'cumulative Nal phase cuts; cut arms do not compute x_out and are not complete CSA or precision candidates',
          'lengths':lengths,'true_tokens':tokens,'physical_graph_tokens':tokens,'per_request_padding':0,
          'hypothetical_s6_tokens':batch*6,'hypothetical_s6_extra_rows':batch*6-tokens,
          'baseline_experiment':'Native direct HC-pre through HC-post', 'candidate_experiment':'Native-SK0/our-directpublish/nalinaly-c346573a-same-new-SDK',
          'candidate_variant':'three complete arms plus Nal topk/heads cumulative cuts; cut output excluded, seven prefix boundaries checked against full Nal','nal_metadata_producer_in_graph':args.nal_metadata_producer,
          'layer':args.layer,'history':args.history,'graphs':{},'comparisons':{},'static':{}}
def save():
    (args.out/'result.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
def exact(x,y):
    return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def metric(x,y):
    if x.shape!=y.shape or x.dtype!=y.dtype:
        return {'bit_equal':False,'shapes':[list(x.shape),list(y.shape)],'dtypes':[str(x.dtype),str(y.dtype)]}
    if x.is_floating_point():
        assert bool(torch.isfinite(x).all()) and bool(torch.isfinite(y).all()), 'nonfinite external float boundary'
    equal=exact(x,y)
    delta=x.float()-y.float()
    return {'bit_equal':equal,'different_elements':int((x!=y).sum()),'max_abs':float(delta.abs().max()),
            'relative_l2':float(torch.linalg.vector_norm(delta)/torch.linalg.vector_norm(y.float()).clamp_min(1e-30)),
            'first_coordinates':(x!=y).nonzero()[:6].tolist()}

from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_combined.native_adapter import CSAOperators
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.service import CSAServiceRuntime
from source_identity import source_identity
source_record=source_identity()
report.update(source_record)
current_sdk=json.loads(Path(os.environ['PREFLIGHT_RECEIPT']).read_text())
nal_cpu='nal8k' if batch==32 else 'nal128k'
assert (args.history,batch) in ((8192,32),(131072,16))
proof=json.loads((ROOT/('cpu-'+nal_cpu)/'receipt.json').read_text())
assert proof['pass'] and proof['device_execution'] is False and proof['npu_initialized'] is False
assert proof['helper_manifest_sha256']==manifest_sha
assert proof['arm']==nal_cpu and proof['source']==source_record
assert proof['nal_compatibility_sha256']==hashlib.sha256((ROOT/'NAL_COMPATIBILITY.json').read_bytes()).hexdigest()
for key in ('source_heads','binary_sha256','ptoas_binary_sha256'):
    assert proof['sdk'][key]==current_sdk[key],key
report['new_sdk_compile_proof']={nal_cpu:proof}
accepted=json.loads((ROOT/'cpu-ours/receipt.json').read_text())
assert accepted['helper_manifest_sha256']==manifest_sha
assert accepted['pass'] and accepted['root_tensors']==64
assert accepted['arm']=='ours' and accepted['source']==source_record
assert accepted['device_execution'] is False and accepted['npu_initialized'] is False
assert accepted['nal_compatibility_sha256']==hashlib.sha256((ROOT/'NAL_COMPATIBILITY.json').read_bytes()).hexdigest()
for key in ('source_heads','binary_sha256','ptoas_binary_sha256'):
    assert accepted['sdk'][key]==current_sdk[key],key
report['our_reused_compile_proof']=accepted
report['our_candidate']='direct-publish-v5; function-source hashes in SOURCE.json'
from load_candidate import operators_for

class NativeHalf(torch.nn.Module):
    def __init__(self,layer):
        super().__init__();self.layer=layer
    def forward(self,hidden,positions,output):
        l=self.layer
        mixed,post,comb=l.hc_pre(hidden,l.hc_attn_fn,l.hc_attn_scale,l.hc_attn_base)
        normed=l.input_layernorm(mixed)
        attended=l.self_attn(positions=positions,hidden_states=normed,llama_4_scaling=None)
        output.copy_(l.hc_post(attended,hidden,post,comb))
        return output

class PTOHalf(torch.nn.Module):
    def __init__(self,prefix):
        super().__init__();self.prefix=prefix
    def forward(self,hidden,positions,output):
        torch.ops.vllm.dsv4_csa_forward(hidden,positions,output,self.prefix)
        return output

class RequirePTO:
    def __init__(self,delegate):
        self.delegate,self.calls=delegate,0
    def eligible(self,*values):
        if not self.delegate.eligible(*values):
            raise RuntimeError('Unexpected PTO fallback')
        return True
    def __call__(self,*values,**kwargs):
        self.calls+=1
        return self.delegate(*values,**kwargs)

os.environ['VLLM_ASCEND_ENABLE_NZ']='2'
os.environ['VLLM_ASCEND_PTO_CSA_ATOMIC_ADD']='0'
reference=ROOT/'nal-packages'
private=types.ModuleType('nal_isolated');private.__path__=[str(reference)];sys.modules[private.__name__]=private
nal_adapter=importlib.import_module('nal_isolated.deepseek_v4_flash_csa.native_adapter')
nal_native=importlib.import_module('nal_isolated.deepseek_v4_flash_csa_spmd_tnd.native_adapter')
nal_binding=importlib.import_module('nal_isolated.deepseek_v4_flash_csa_spmd_tnd.binding')
reference_proof=json.loads((ROOT/'NAL_COMPATIBILITY.json').read_text())
assert all(hashlib.sha256((reference/name).read_bytes()).hexdigest()==sha for name,sha in reference_proof['packages'].items())
report['nal_source_proof']=reference_proof

current_platform.pre_register_and_update()
torch.npu.set_device(0)
torch.npu.config.allow_internal_format=True
torch.use_deterministic_algorithms(True)
torch_npu.npu.set_deterministic_level(1)
torch.set_num_threads(4)
from vllm_ascend.utils import enable_custom_op
assert enable_custom_op()
checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config=EngineArgs(model=str(checkpoint),tokenizer_mode='deepseek_v4',trust_remote_code=True,
 tensor_parallel_size=1,dtype='bfloat16',quantization='ascend',hf_overrides={'sliding_window':128},
 max_model_len=max(16384,args.history+128),max_num_seqs=40,max_num_batched_tokens=256,enable_prefix_caching=False,
 enforce_eager=False,block_size=32,speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},
 compilation_config={'cudagraph_mode':'FULL_DECODE_ONLY','cudagraph_capture_sizes':[tokens],'cache_dir':str(args.out/'vllm-cache')},
 additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,'fuse_norm_quant':True,'align_decode_capture_sizes':False},
 'enable_cpu_binding':False,'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False,'multistream_dsv4_dsa_overlap':True}).create_engine_config()

states, fixtures, rows, keepalive, b_states = {}, {}, {}, [], {}
nal_workspaces={}
nal_signals={}
def check_guards(arm, fixture):
    checks=guard_checks(fixture)
    assert all(value['status']=='PASS' for value in checks.values()),(arm,'external guards',checks)
    if arm in nal_workspaces:
        assert all(torch.all(v[:g].cpu()==37) and torch.all(v[-g:].cpu()==37)
                   for v,g in nal_workspaces[arm].values()),(arm,'workspace guards')
def signal_generation(arm):
    if arm not in nal_signals:return None
    values=nal_signals[arm].cpu().reshape(-1,72,128)
    assert torch.all(values[:,:,1:]==0),(arm,'signal isolation padding changed')
    generation=values[0,:,0]
    assert torch.all(generation==generation[0]) and int(generation[0])>0,(arm,'generation disagreement')
    return int(generation[0])
save()
try:
 with native_session(config,0),torch.inference_mode():
    layer,details=make_layer(config,checkpoint,torch.device('npu:0'),args.layer)
    report['weight_details']=details
    report['native_DSA_multistream_config']=bool(layer.self_attn.dsa_attn.dsa_attn.impl.multistream_dsv4_dsa_overlap)
    assert report['native_DSA_multistream_config']
    pypto.torch.init(enable_chip_swimlane=1 if args.mode=='dfx' else 0, enable_dep_gen=args.mode=='dep', output_dir=args.out/'dfx' if args.mode!='timing' else None)
    impl=layer.self_attn.dsa_attn.dsa_attn.impl
    observed={}
    original_qli=torch.ops._C_ascend.npu_vllm_quant_lightning_indexer
    def observe_qli(*values,**kwargs):
        result=original_qli(*values,**kwargs);observed['topk']=result[0];return result
    torch.ops._C_ascend.npu_vllm_quant_lightning_indexer=observe_qli
    # 保留原13包校验桥；只在首次真实reselect后复用选择，禁止捕获之后变更选择。
    selection=[]
    original_reselect=torch_npu.npu._aclnn_reselect_static_kernel
    def qualified_reselect(*values,**kwargs):
        assert hashlib.sha256((Path(os.environ['LOW_ACCEPTANCE_OFFICIAL_CACHE'])/'metadata.json').read_bytes()).hexdigest()==META_SHA
        assert not values and not kwargs
        if not selection:
            selection.append(original_reselect())
            report['static']['actual_reselect_count']=1
        else:
            report['static']['validated_reuses']=report['static'].get('validated_reuses',0)+1
        report['static']['metadata_sha256']=META_SHA
        return selection[0]
    # 框架可能已from-import compile_static_kernel；在实际API边界观测，避免漏掉别名调用。
    torch_npu.npu._aclnn_reselect_static_kernel=qualified_reselect

    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.native_adapter import CSAOperators as SerialOperators
    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.service import CSAServiceRuntime as SerialRuntime
    for arm in ('native','candidate'):
        assert torch.are_deterministic_algorithms_enabled()
        assert torch_npu._C._npu_get_deterministic_level()==1
        report.setdefault('determinism',{})[arm]={'torch_enabled':True,'npu_level':1,'HCCL_DETERMINISTIC':os.environ.get('HCCL_DETERMINISTIC')}
        print('ARM_START',arm,flush=True)
        torch._dynamo.reset()
        f=make_ragged_fixture(config,layer.self_attn,batch,args.history,1024,torch.device('npu:0'),lengths)
        scales=f['groups']['indexer']['views'][1]
        scale_rows=torch.arange(scales.numel(),dtype=torch.int64,device=scales.device)
        scales.copy_((0.00390625+((scale_rows*37)%251).float()/16384).to(scales.dtype).reshape(scales.shape))
        f['groups']['indexer']['initial']=f['groups']['indexer']['allocation'].cpu()
        fixtures[arm]=f
        if arm!='native':
            for field in ('hidden','positions'):
                assert exact(f[field],fixtures['native'][field]),(arm,field)
            for name,g in f['groups'].items():
                assert exact(g['initial'],fixtures['native']['groups'][name]['initial']),(arm,name)
            assert f['readonly'].keys()==fixtures['native']['readonly'].keys()
            for name,(_,snapshot) in f['readonly'].items():
                assert exact(snapshot,fixtures['native']['readonly'][name][1]),(arm,name,'metadata input differs')
            for name,parts in f['compact'].items():
                assert all(exact(x,y) for x,y in zip(parts,fixtures['native']['compact'][name])),(arm,name,'compact metadata differs')
        runtime=None
        if arm=='candidate':
            operators=operators_for('candidate')
            with torch.inference_mode(False), torch.enable_grad():
                keepalive.append(layer.hc_attn_fn)  # Retain captured Native weight storage.
                layer.hc_attn_fn=torch.nn.Parameter(layer.hc_attn_fn.detach().clone(),requires_grad=True)
                runtime=(SerialRuntime if arm=='serial' else CSAServiceRuntime)(layer.self_attn,operators,40,layer)
                report['model_loading_prepare_context']={'grad_enabled_after_constructor':torch.is_grad_enabled(),'source_requires_grad':layer.hc_attn_fn.requires_grad,'source_inference':torch.is_inference(layer.hc_attn_fn),'packed_requires_grad':runtime.weights['hc_packed_weight'].requires_grad}
                assert torch.is_grad_enabled() and layer.hc_attn_fn.requires_grad
                assert not runtime.weights['hc_packed_weight'].requires_grad

            from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.workspace import NORM_PARAMETERS
            norm_offset=0
            norm_packet_checks={}
            for name,size in NORM_PARAMETERS:
                norm_packet_checks[name]=exact(runtime.norm_packet[norm_offset:norm_offset+size].cpu(),runtime.weights[name].cpu())
                norm_offset+=size
            assert norm_offset==6272 and all(norm_packet_checks.values())
            order_checks={}
            for (w,i,o),packet in operators.workspace.order_packets.items():
                cpu=packet.cpu()
                order_checks[str((w,i,o))]=all((exact(cpu[:512],runtime.wkv_orders[w].cpu().reshape(-1)),
                    exact(cpu[512:1536],runtime.indexer_orders[i].cpu().reshape(-1)),
                    exact(cpu[1536:],runtime.oproj_starts[o].cpu().reshape(-1))))
            assert len(order_checks)==33 and all(order_checks.values())
            report['packet_checks']={'norm_byte_equal':norm_packet_checks,'order_byte_equal':order_checks,
                'norm_bytes_per_layer':runtime.norm_packet.numel()*runtime.norm_packet.element_size(),
                'order_bytes_per_model':sum(t.numel()*t.element_size() for t in operators.workspace.order_packets.values())}
            readonly_packets={'norm':runtime.norm_packet,'hc_packed':runtime.weights['hc_packed_weight'],**{str(k):v for k,v in operators.workspace.order_packets.items()}}
            packet_snapshots={k:v.cpu() for k,v in readonly_packets.items()}
            report['hc_weight_qualification']=dict(runtime.hc_weight_qualification)
            assert report['hc_weight_qualification']['version']==1
            assert selection,'Native graph did not install and select static packages'
            runtime.qualify_static_wkv(metadata_sha256=META_SHA,reselected=True)
        @contextlib.contextmanager
        def context():
            with set_ascend_forward_context(f['metadata'],config,num_tokens=tokens,num_actual_tokens=tokens,
                                            aclgraph_runtime_mode=CUDAGraphMode.FULL):
                assert get_forward_context().cudagraph_runtime_mode is CUDAGraphMode.FULL
                yield
        if runtime is not None:
            with context():
                eligible=runtime.eligible(get_forward_context(),f['hidden'],f['positions'])
            report.setdefault('entry',{})[arm]={'eligible':eligible,'route':'PTO' if eligible else 'Native fallback','metadata':{
                name:{'bounds':f['metadata'][g['prefix']].decode.query_start_loc.cpu().tolist(),
                      'max_q':f['metadata'][g['prefix']].decode.max_seqlen_q,
                      'num_decodes':f['metadata'][g['prefix']].num_decodes,
                      'actual_tokens':f['metadata'][g['prefix']].num_actual_tokens} for name,g in f['groups'].items()}}
            save()
            assert eligible, 'TND precision fallback is forbidden'
            guarded=RequirePTO(runtime)
            layer.self_attn.dsa_attn._pto_csa_runtime=guarded
        else:
            layer.self_attn.dsa_attn._pto_csa_runtime=None
        is_cut=arm in ('nal_topk','nal_heads')
        output=torch.zeros_like(f['hidden'])
        nal_call=None
        if arm.startswith('nal_'):
            groups={name:(f['metadata'][g['prefix']],g['views']) for name,g in f['groups'].items()}
            weights=nal_adapter.prepare_weights(layer.self_attn,groups['indexer'][0].hadamard,layer)
            topk_buffer=torch.empty((tokens,512),dtype=torch.int32,device='npu')
            score_buffer=torch.empty((tokens,512),dtype=torch.float32,device='npu')
            native=nal_native.bind_native_inputs(weights,f['hidden'],f['positions'],groups,
                layer_name=layer.self_attn.dsa_attn.dsa_attn.layer_name,
                compact_metadata=f['compact'],output=output,topk=topk_buffer,topk_scores=score_buffer)
            from pypto.runtime import CompileOptions
            nal_config=CompileOptions(platform='a2a3',output_dir=str(args.out/'nal-kernel'))
            allocations={}
            selected_binding=nal_binding
            if is_cut:
                cut_kind=arm.removeprefix('nal_')
                cut_package=types.ModuleType('isolated_'+cut_kind)
                cut_package.__path__=[str(ROOT/(cut_kind+'-packages'))]
                sys.modules[cut_package.__name__]=cut_package
                selected_binding=importlib.import_module(cut_package.__name__+'.deepseek_v4_flash_csa_spmd_tnd.binding')
                cut_proof=json.loads((ROOT/('cpu-'+cut_kind)/'receipt.json').read_text())
                assert cut_proof['pass'] and cut_proof['helper_manifest_sha256']==manifest_sha
                assert cut_proof['root_tensors']==57 and not cut_proof['npu_initialized']
                assert cut_proof['arm']==cut_kind and cut_proof['source']==source_record
                assert cut_proof['device_execution'] is False
                assert cut_proof['nal_compatibility_sha256']==proof['nal_compatibility_sha256']
                assert cut_proof['policy']==proof['policy']
                report.setdefault('cut_compile_proof',{})[arm]=cut_proof
                assert cut_proof['sdk']==proof['sdk'], 'cut/full CPU SDK identities differ'
            prepared=selected_binding.PreparedDynamicCSA(native,max_query_tokens=max(lengths),
                max_seq_len=args.history+max(lengths))
            report['nal_spmd_policy']=prepared.policy.constexprs()
            assert report['nal_spmd_policy']==report['new_sdk_compile_proof'][nal_cpu]['policy']
            assert not prepared.allocations
            report['nal_signal_lifecycle']='internal per-call zeroing and full sync; no external generation inspection'
            report['nal_internal_scratch_guards']='not externally inspectable; Native/cache guards and replay ABA checked'
            report['nal_entry']='decode_csa_spmd_debug; external TopK observation tensors'
            report['nal_root_tensor_args']=report['new_sdk_compile_proof'][nal_cpu]['root_tensors']
            def runner():
                compact={name:impl._compute_compressor_metadata(groups[name][0].decode)
                         for name in ('compressed','indexer')}
                info=report.setdefault('nal_metadata_checks',{'capture_calls':0,'eager_equal_checks':0})
                if torch.npu.is_current_stream_capturing():
                    info['capture_calls']+=2
                else:
                    assert all(exact(new.cpu(),old.cpu()) for name,parts in compact.items()
                               for new,old in zip(parts,f['compact'][name],strict=True)), 'Nal metadata producer differs from common fixture'
                    info['eager_equal_checks']+=1
                current=dict(native)
                for name,prefix,slot in (('compressed','cmp','cmp'),('indexer','inner','idx')):
                    cos,sin,slots=compact[name]
                    current[prefix+'_freqs_cos']=cos.view(-1,64)
                    current[prefix+'_freqs_sin']=sin.view(-1,64)
                    current[slot+'_slot_mapping']=slots
                prepared.rebind(current)
                return prepared(config=nal_config)
            for weight_name in ('wq_a','wq_b','wo_a','wo_b'):
                assert weights[weight_name].data_ptr()==getattr(layer.self_attn,weight_name).weight.data_ptr()
            restore(f);runner();torch.npu.synchronize()
            nal_eager_state=collect_state(f,output,topk_buffer)
            restore(f)
            stream=torch.npu.Stream();stream.wait_stream(torch.npu.current_stream())
            with torch.npu.stream(stream):
                graph=torch.npu.NPUGraph()
                with torch.npu.graph(graph,stream=stream):runner()
            torch.npu.synchronize()
            topk=topk_buffer;compiled=runner;module=None;owner=graph
            keepalive.append((prepared,runner,nal_config,allocations,native))
            report.setdefault('nal_guards',{})[arm]={'checked':False}
            report['nal_metadata_producer_in_graph']=True
        else:
            module=NativeHalf(layer) if arm=='native' else PTOHalf(layer.self_attn.dsa_attn.prefix)
            restore(f)
            with context():module(f['hidden'],f['positions'],output)
            torch.npu.synchronize()
            instances={}
            old_run=AclGraph.run
            def record(owner,key,*values,**kwargs):
                instances[(id(owner),key)]=owner
                return old_run(owner,key,*values,**kwargs)
            AclGraph.run=record
            options={'force_eager':False,'inplace_pass':True,'clone_input':False,'clone_output':False,
                     'static_kernel_compile':True,'super_kernel_optimize':False}
            torch.npu.set_compile_mode(jit_compile=False)
            try:
                compiled=torch.compile(module,backend='npugraph_ex',fullgraph=True,dynamic=False,options=options)
                restore(f)
                with context():compiled(f['hidden'],f['positions'],output)
                torch.npu.synchronize()
                assert len(instances)==1,(arm,'not exactly one actual graph',len(instances))
                (_,key),owner=next(iter(instances.items()))
                assert not owner._updated_node_infos
                graph=owner.graph[key]
            finally:
                AclGraph.run=old_run
            topk=runtime.topk[:tokens] if runtime is not None else observed['topk']
        compiled_state=collect_state(f,output,topk)
        if arm.startswith('nal_'):
            # Direct NPUGraph capture may only record the launch. Observe both
            # the pre-replay storage and the first actually executed replay.
            report.setdefault('nal_after_capture_vs_eager',{})[arm]={name:metric(value,nal_eager_state[name])
                                                for name,value in compiled_state.items()}
            save()
            restore(f);output.fill_(0.0 if is_cut else float('nan'));topk.fill_(-12345)
            graph.replay();torch.npu.synchronize()
            compiled_state=collect_state(f,output,topk)
            report.setdefault('nal_first_raw_vs_eager',{})[arm]={name:metric(value,nal_eager_state[name])
                                             for name,value in compiled_state.items()}
            save()
            assert all(exact(value,nal_eager_state[name]) for name,value in compiled_state.items()), 'Nal first actual graph replay/eager mismatch'
            report['nal_eager_raw_equal']=True
        restore(f);output.fill_(0.0 if is_cut else float('nan'));topk.fill_(-12345);graph.replay();torch.npu.synchronize()
        actual=collect_state(f,output,topk)
        assert all(exact(value,compiled_state[name]) for name,value in actual.items()),(arm,'compiled/raw mismatch')
        assert torch.isfinite(output).all()
        if arm.startswith('nal_'):
            assert all(torch.all(v[:g].cpu()==37) and torch.all(v[-g:].cpu()==37) for v,g in allocations.values()),(arm,'private workspace guard')
            report['nal_guards'][arm].update(checked=bool(allocations), external_allocations=len(allocations), internal_scratch='not externally inspectable')
        guards=guard_checks(f)
        assert all(value['status']=='PASS' for value in guards.values()),(arm,'guard',guards)
        states[arm]=actual
        rows[arm]=(graph,f,output,topk)
        if arm.startswith('nal_'):nal_workspaces[arm]=allocations
        keepalive.append((compiled,module,owner,runtime))
        report['graphs'][arm]={'actual_acl_graph':True,'fullgraph':True,'options':options if not arm.startswith('nal_') else {'capture':'direct warmed native JIT raw FULL NPUGraph'},
                                'true_tokens':tokens,'graph_tokens':tokens,'guards':guards,'compiled_raw_equal':True,
                                'topk_poison_replay_restored':True,'native_super_kernel_optimize':False}
        if arm!='native':
            checks={name:metric(value,states['native'][name]) for name,value in actual.items() if not (is_cut and name=='x_out')}
            if is_cut:
                cut_checks={name:metric(value,states['nal_spmd'][name]) for name,value in actual.items() if name!='x_out'}
                report.setdefault('cut_prefix_matches_full_A',{})[arm]=cut_checks
                assert len(cut_checks)==7 and all(m['bit_equal'] for m in cut_checks.values()), (arm,'cut/full A prefix drift')
            report['comparisons'][arm]=checks
            save()
            if arm=='candidate' and not all(check['bit_equal'] for check in checks.values()):
                report['first_failed_arm']=arm
                report['failed_boundaries']=[name for name,m in checks.items() if not m['bit_equal']]
                raise RuntimeError(arm+': first bit difference; stop matrix and timing')
        before=f['hidden'].clone()
        restore(f);f['hidden'].add_(0.125);graph.replay();torch.npu.synchronize()
        assert not exact((topk if is_cut else output).cpu(),actual['idx_topk' if is_cut else 'x_out']),(arm,'stale input graph')
        b_states[arm]=collect_state(f,output,topk)
        if arm!='native':
            b_checks={name:metric(value,b_states['native'][name]) for name,value in b_states[arm].items() if not (is_cut and name=='x_out')}
            if is_cut:
                cut_b={name:metric(value,b_states['nal_spmd'][name]) for name,value in b_states[arm].items() if name!='x_out'}
                report.setdefault('cut_prefix_matches_full_B',{})[arm]=cut_b
                assert len(cut_b)==7 and all(m['bit_equal'] for m in cut_b.values()), (arm,'cut/full B prefix drift')
            report.setdefault('B_comparisons',{})[arm]=b_checks;save()
            if arm=='candidate' and not all(check['bit_equal'] for check in b_checks.values()):
                torch.save(b_states,args.out/'first-B-difference.pt')
                raise RuntimeError('TND input B first bit difference; stop')
        assert all(value['status']=='PASS' for value in guard_checks(f).values()),(arm,'B guards')
        f['hidden'].copy_(before);restore(f);graph.replay();torch.npu.synchronize()
        restored=collect_state(f,output,topk)
        assert all(exact(value,actual[name]) for name,value in restored.items()),(arm,'A restore')
        check_guards(arm,f)
        report['graphs'][arm]['live_input_ABA']=True
        if runtime is not None:
            assert guarded.calls>0,'PTO runtime was never invoked'
            report['graphs'][arm]['pto_dispatch_calls']=guarded.calls
            schema=str(runtime.operators.attention._schema)
            expected_namespace=('dsv4_csa_tnd_precision_spmd_bf16layout::attention' if arm=='serial' else 'dsv4_csa_tnd_precision_spmd_combined::attention_combined')
            assert schema.startswith('csa_directpub_candidate::attention('),(arm,schema)
            assert schema.split(' -> ')[0].count('Tensor')==64,(arm,schema)
            report['graphs'][arm]['root_schema']=schema
            report['workspace_bytes']=sum(v.numel()*v.element_size() for v in operators.workspace.buffers.values())
            report['hc_packed_weight_bytes']=runtime.weights['hc_packed_weight'].numel()*runtime.weights['hc_packed_weight'].element_size()
            report['workspace_capture_stream']=operators.workspace.capture_stream
        save()
        print('ARM_PASS',arm,flush=True)
    report['scope']='Native/accepted Direct A/B8+ABA and actual dependency map only; no timing; no Nal kernel execution'
    report['dependency_generation']=True
    report['timing_executed']=False
    report['derived_parent_sha256']=PARENT_SHA
    report['derived_probe_sha256']=DERIVED_SHA
    report['kernel_maps']={}
    from load_candidate import entry_for
    for arm in ('candidate',):
        entry=entry_for(arm)
        artifacts=list(entry._cache.values())
        assert len(artifacts)==1
        artifact=artifacts[0];directory=Path(artifact.output_dir)
        manifest_file=directory/'binary_manifest.json';manifest=json.loads(manifest_file.read_text())
        report['kernel_maps'][arm]={'directory':str(directory),'identity':artifact.identity().hex(),
            'names':{str(k['func_id']):k['name'] for k in manifest['kernels']},
            'binary_sha256':{str(k['func_id']):k['binary']['sha256'] for k in manifest['kernels']}}
        cpu_arm='ours'
        cpu_manifest=json.loads((ROOT/('cpu-'+cpu_arm)/'kernel/binary_manifest.json').read_text())
        cpu_hashes={str(k['func_id']):k['binary']['sha256'] for k in cpu_manifest['kernels']}
        assert cpu_hashes==report['kernel_maps'][arm]['binary_sha256'],(arm,'CPU/JIT actual binary mismatch')
        orchestration_sha=manifest['orchestration']['binary']['sha256']
        import re
        
        # C++ lexemes that must remain byte-identical, including raw string delimiters.
        TOKENS = re.compile(
            r'(?P<protected>(?:u8|u|U|L)?R"(?P<delimiter>[^ ()\\\t\r\n]{0,16})\(.*?\)(?P=delimiter)"'
            r'|(?:u8|u|U|L)?"(?:\\.|[^"\\])*"'
            r"|(?:u8|u|U|L)?'(?:\\.|[^'\\])*'"
            r'|/\*.*?\*/|//[^\n]*|^[ \t]*\#(?:[^\n\\]|\\[^\n]|\\\n)*)'
            r'|(?P<identifier>\b[A-Za-z_]\w*\b)', re.DOTALL | re.MULTILINE)
        INLINE = re.compile(r'[A-Za-z_]\w*inline[0-9]+\w*\Z')
        DECL = re.compile(r'\b(?:int64_t|int32_t|uint32_t|uint64_t|float|Tensor|TensorCreateInfo|TaskOutputTensors|TaskId)(?:\s*&\s*|\s+)([A-Za-z_]\w*inline[0-9]+\w*)\b')
        
        
        def normalize_generated_identifiers(text):
            assert 'CSA_ALPHA_INLINE_' not in text, 'reserved placeholder collision'
            protected = []
            def mask(match):
                if match.group('protected') is not None:
                    protected.append(match.group())
                    return ''.join('\n' if c == '\n' else ' ' for c in match.group())
                return match.group()
            plain = TOKENS.sub(mask, text)
            declared = set(DECL.findall(plain))
            renamed = {m.group() for m in TOKENS.finditer(plain) if m.group('identifier') and INLINE.fullmatch(m.group())}
            assert renamed <= declared, ('non-local inline identifier', sorted(renamed-declared))
            mapping = {}
            def replace(match):
                word = match.group()
                if match.group('identifier') is None or not INLINE.fullmatch(word):
                    return word
                if word not in mapping:
                    stem = re.sub(r'inline[0-9]+', 'inline', word)
                    mapping[word] = f'CSA_ALPHA_INLINE_{len(mapping)}_{stem}'
                return mapping[word]
            return TOKENS.sub(replace, text), mapping, protected
        cpu_directory=ROOT/('cpu-'+cpu_arm)/'kernel'
        cpu_files=sorted((cpu_directory/'orchestration').glob('*.cpp'))
        actual_files=sorted((directory/'orchestration').glob('*.cpp'))
        assert len(cpu_files)==len(actual_files)==1
        cpu_text=cpu_files[0].read_text();actual_text=actual_files[0].read_text()
        cpu_normal,cpu_ids,cpu_protected=normalize_generated_identifiers(cpu_text)
        actual_normal,actual_ids,actual_protected=normalize_generated_identifiers(actual_text)
        assert cpu_protected==actual_protected and cpu_normal==actual_normal and len(cpu_ids)==len(actual_ids),(arm,'CPU/JIT orchestration is not alpha-equivalent')
        for metadata_file in ('kernel_config.py','compiled_meta.json'):
            assert (cpu_directory/metadata_file).read_bytes()==(directory/metadata_file).read_bytes()
        report['kernel_maps'][arm]['orchestration_proof']={
            'binary_sha256':orchestration_sha,'cpu_binary_sha256':cpu_manifest['orchestration']['binary']['sha256'],
            'actual_source_sha256':hashlib.sha256(actual_text.encode()).hexdigest(),
            'cpu_source_sha256':hashlib.sha256(cpu_text.encode()).hexdigest(),
            'alpha_equivalent':True,'normalized_sha256':hashlib.sha256(cpu_normal.encode()).hexdigest(),
            'cpu_identifier_bijection':cpu_ids,'actual_identifier_bijection':actual_ids,
            'scope':'Only complete generated inline identifiers are renamed; operators,literals,calls,ordering and all other text exact. Binary SHA differs; not claimed binary-identical.'}
    report['DFX']={'level':0,'enable_dep_gen':True,'windows':[]}
    for repeat in range(2):
        arm='candidate'
        graph,f,output,topk=rows[arm]
        restore(f)
        for live,snapshot in f['readonly'].values():live.copy_(snapshot)
        torch.npu.synchronize()
        pypto.torch.begin_dfx();graph.replay();pypto.torch.end_dfx()
        torch.npu.synchronize()
        actual=collect_state(f,output,topk)
        assert all(exact(v,states[arm][name]) for name,v in actual.items()), 'dependency run state drift'
        assert all(x['status']=='PASS' for x in guard_checks(f).values()), 'dependency guards'
        raw=args.out/'dfx'
        if repeat:raw=raw/f'window_{repeat}'
        raw=raw/'deps.json'
        value=json.loads(raw.read_text())
        assert value['tasks'] and all(str(fid) in report['kernel_maps'][arm]['names'] for row in value['tasks'] for fid in row['kernel_ids'] if fid>=0)
        report['DFX']['windows'].append({'arm':arm,'repeat':repeat,'raw':str(raw)})
    assert all(exact(v.cpu(),packet_snapshots[k]) for k,v in readonly_packets.items()), 'dependency readonly packets'
    report['complete']=report['pass']=True
    save()
except Exception as exc:
    report['error']=repr(exc)
    save()
    raise
print('DEPENDENCY_COMPLETE',report['pass'],flush=True)
