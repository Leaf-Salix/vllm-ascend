"""Native NZ INT8 indexer Q_B, identical arithmetic and rounding."""
import pypto.language as pl
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.decode_indexer import D, DEQUANT_T_TILE, DQ_ROPE_H_TILE, DQ_ROPE_WORKERS, IDX_HEAD_DIM, IDX_NOPE_HEAD_DIM, IDX_N_HEADS, QR_MM_N_TILE, QR_MM_ROW_TILE, QR_MM_T_PAD, QR_PROJ_WORKERS, Q_LORA, ROPE_HEAD_DIM, T_DYN, T_PAD, indexer_qr_hadamard_mm
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.qkv_proj_rope import QUANT_WEIGHT_LAYOUT

@pl.jit.inline(auto_scope=False)
def indexer_qr_rope(x: pl.Tensor[[T_DYN, D], pl.BF16], qr: pl.Tensor[[T_DYN, Q_LORA], pl.INT8], qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32], wq_b: pl.Tensor[[Q_LORA, IDX_N_HEADS * IDX_HEAD_DIM], pl.INT8, QUANT_WEIGHT_LAYOUT], wq_b_scale: pl.Tensor[[IDX_N_HEADS * IDX_HEAD_DIM], pl.FP32], cos: pl.Tensor[[T_DYN, ROPE_HEAD_DIM], pl.FP32], sin: pl.Tensor[[T_DYN, ROPE_HEAD_DIM], pl.FP32], qr_bf16: pl.Out[pl.Tensor[[T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], pl.BF16]]) -> pl.Scalar[pl.TASK_ID]:
    """Indexer query projection, dequant and RoPE -- everything before the hadamard."""
    bs = pl.tensor.dim(x, 0)
    row_blocks = (bs + QR_MM_ROW_TILE - 1) // QR_MM_ROW_TILE
    qr_acc_pad = pl.create_tensor([QR_MM_T_PAD, IDX_N_HEADS * IDX_HEAD_DIM], dtype=pl.INT32)
    with pl.spmd(QR_PROJ_WORKERS, name_hint='idx_qr_proj_matmul', allow_early_resolve=True) as idx_qr_mm_tid:
        qr_proj_worker = pl.tile.get_block_idx()
        for qr_col in pl.range(qr_proj_worker, IDX_N_HEADS * IDX_HEAD_DIM // QR_MM_N_TILE, QR_PROJ_WORKERS):
            o_base = qr_col * QR_MM_N_TILE
            wq_tile = wq_b[0:Q_LORA, o_base:o_base + QR_MM_N_TILE]
            for qr_rb in pl.range(row_blocks):
                qr_r0 = qr_rb * QR_MM_ROW_TILE
                qr_rows = pl.min(QR_MM_ROW_TILE, bs - qr_r0)
                qr_tile = pl.slice(qr, [QR_MM_ROW_TILE, Q_LORA], [qr_r0, 0], valid_shape=[qr_rows, Q_LORA])
                qr_acc = pl.matmul(qr_tile, wq_tile, out_dtype=pl.INT32)
                qr_acc_pad[qr_r0:qr_r0 + QR_MM_ROW_TILE, o_base:o_base + QR_MM_N_TILE] = qr_acc
    qr_bf16_2d = pl.reshape(qr_bf16, [T_PAD, IDX_N_HEADS * IDX_HEAD_DIM])
    dq_rope_units = (bs + DEQUANT_T_TILE - 1) // DEQUANT_T_TILE * (IDX_N_HEADS // DQ_ROPE_H_TILE)
    dq_rope_workers = pl.min(dq_rope_units, DQ_ROPE_WORKERS)
    for dq_rope_worker in pl.spmd(dq_rope_workers, name_hint='idx_qr_dequant_rope', allow_early_resolve=True):
        sw_ones = pl.full([DEQUANT_T_TILE, ROPE_HEAD_DIM], dtype=pl.FP32, value=1.0)
        sw_index = pl.cast(pl.arange(0, [1, ROPE_HEAD_DIM], dtype=pl.INT32), target_type=pl.FP32)
        sw_col = pl.col_expand_mul(sw_ones, sw_index)
        sw_dup_f = pl.cast(pl.cast(pl.mul(sw_col, 0.5), target_type=pl.INT32, mode='trunc'), target_type=pl.FP32)
        sw_lane = pl.sub(sw_col, pl.mul(sw_dup_f, 2.0))
        rope_swap_idx = pl.cast(pl.sub(pl.add(sw_col, 1.0), pl.mul(sw_lane, 2.0)), target_type=pl.INT32)
        for dq_unit in pl.range(dq_rope_worker, dq_rope_units, dq_rope_workers):
            hg = dq_unit % (IDX_N_HEADS // DQ_ROPE_H_TILE) * DQ_ROPE_H_TILE
            dq_t0 = dq_unit // (IDX_N_HEADS // DQ_ROPE_H_TILE) * DEQUANT_T_TILE
            if dq_t0 + DEQUANT_T_TILE <= bs:
                qr_scale_tile = qr_scale[dq_t0:dq_t0 + DEQUANT_T_TILE, :]
                cos_tile = cos[dq_t0:dq_t0 + DEQUANT_T_TILE, 0:ROPE_HEAD_DIM]
                sin_tile = sin[dq_t0:dq_t0 + DEQUANT_T_TILE, 0:ROPE_HEAD_DIM]
                for h_inner in pl.pipeline(DQ_ROPE_H_TILE, stage=2):
                    h0 = (hg + h_inner) * IDX_HEAD_DIM
                    wq_scale = pl.reshape(wq_b_scale[h0:h0 + IDX_HEAD_DIM], [1, IDX_HEAD_DIM])
                    acc_fp32 = pl.cast(qr_acc_pad[dq_t0:dq_t0 + DEQUANT_T_TILE, h0:h0 + IDX_HEAD_DIM], target_type=pl.FP32, mode='none')
                    qr_dequant_scale = pl.col_expand_mul(pl.row_expand_mul(pl.full([DEQUANT_T_TILE, IDX_HEAD_DIM], dtype=pl.FP32, value=1.0), qr_scale_tile), wq_scale)
                    qr_dequant = pl.mul(acc_fp32, qr_dequant_scale)
                    qr_dequant = pl.cast(pl.cast(qr_dequant, pl.BF16, mode='rint'), pl.FP32)
                    qr_nope_bf16 = pl.cast(qr_dequant[:, 0:IDX_NOPE_HEAD_DIM], target_type=pl.BF16, mode='rint')
                    qr_rope_slice = qr_dequant[:, IDX_NOPE_HEAD_DIM:IDX_HEAD_DIM]
                    qr_swapped = pl.gather(qr_rope_slice, dim=-1, index=rope_swap_idx)
                    rope_rot = pl.add(pl.mul(qr_rope_slice, cos_tile), pl.mul(qr_swapped, sin_tile))
                    rope_bf16 = pl.cast(rope_rot, target_type=pl.BF16, mode='rint')
                    qr_bf16_2d[dq_t0:dq_t0 + DEQUANT_T_TILE, h0:h0 + IDX_NOPE_HEAD_DIM] = qr_nope_bf16
                    qr_bf16_2d[dq_t0:dq_t0 + DEQUANT_T_TILE, h0 + IDX_NOPE_HEAD_DIM:h0 + IDX_HEAD_DIM] = rope_bf16
            else:
                tail_swap_idx = rope_swap_idx[0:1, :]
                for tail_t0 in pl.range(dq_t0, bs):
                    tail_qr_scale_value = pl.read(qr_scale, [tail_t0, 0])
                    tail_cos_tile = cos[tail_t0:tail_t0 + 1, 0:ROPE_HEAD_DIM]
                    tail_sin_tile = sin[tail_t0:tail_t0 + 1, 0:ROPE_HEAD_DIM]
                    for tail_h_inner in pl.pipeline(DQ_ROPE_H_TILE, stage=2):
                        tail_h0 = (hg + tail_h_inner) * IDX_HEAD_DIM
                        tail_wq_scale = pl.reshape(wq_b_scale[tail_h0:tail_h0 + IDX_HEAD_DIM], [1, IDX_HEAD_DIM])
                        tail_acc_fp32 = pl.cast(qr_acc_pad[tail_t0:tail_t0 + 1, tail_h0:tail_h0 + IDX_HEAD_DIM], target_type=pl.FP32, mode='none')
                        tail_qr_dequant_scale = pl.mul(tail_wq_scale, tail_qr_scale_value)
                        tail_qr_dequant = pl.mul(tail_acc_fp32, tail_qr_dequant_scale)
                        tail_qr_dequant = pl.cast(pl.cast(tail_qr_dequant, pl.BF16, mode='rint'), pl.FP32)
                        tail_qr_nope_bf16 = pl.cast(tail_qr_dequant[:, 0:IDX_NOPE_HEAD_DIM], target_type=pl.BF16, mode='rint')
                        tail_qr_rope_slice = tail_qr_dequant[:, IDX_NOPE_HEAD_DIM:IDX_HEAD_DIM]
                        tail_qr_swapped = pl.gather(tail_qr_rope_slice, dim=-1, index=tail_swap_idx)
                        tail_rope_rot = pl.add(pl.mul(tail_qr_rope_slice, tail_cos_tile), pl.mul(tail_qr_swapped, tail_sin_tile))
                        tail_rope_bf16 = pl.cast(tail_rope_rot, target_type=pl.BF16, mode='rint')
                        qr_bf16_2d[tail_t0:tail_t0 + 1, tail_h0:tail_h0 + IDX_NOPE_HEAD_DIM] = tail_qr_nope_bf16
                        qr_bf16_2d[tail_t0:tail_t0 + 1, tail_h0 + IDX_NOPE_HEAD_DIM:tail_h0 + IDX_HEAD_DIM] = tail_rope_bf16
    return idx_qr_mm_tid

@pl.jit.inline(auto_scope=False)
def indexer_qr_hadamard(x: pl.Tensor[[T_DYN, D], pl.BF16], qr: pl.Tensor[[T_DYN, Q_LORA], pl.INT8], qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32], wq_b: pl.Tensor[[Q_LORA, IDX_N_HEADS * IDX_HEAD_DIM], pl.INT8, QUANT_WEIGHT_LAYOUT], wq_b_scale: pl.Tensor[[IDX_N_HEADS * IDX_HEAD_DIM], pl.FP32], cos: pl.Tensor[[T_DYN, ROPE_HEAD_DIM], pl.FP32], sin: pl.Tensor[[T_DYN, ROPE_HEAD_DIM], pl.FP32], hadamard: pl.Tensor[[IDX_HEAD_DIM, IDX_HEAD_DIM], pl.BF16], qr_hadamard_i8: pl.Out[pl.Tensor[[T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], pl.INT8]], qr_hadamard_scale_dq: pl.Out[pl.Tensor[[T_PAD * IDX_N_HEADS, 1], pl.FP32]]):
    """Query half of the indexer: qr projection, rope, hadamard, and INT8 quant."""
    qr_bf16 = pl.create_tensor([T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], dtype=pl.BF16)
    idx_qr_mm_tid = indexer_qr_rope(x, qr, qr_scale, wq_b, wq_b_scale, cos, sin, qr_bf16)
    qh_mm_tid, qh_quant_tid = indexer_qr_hadamard_mm(x, qr_bf16, hadamard, qr_hadamard_i8, qr_hadamard_scale_dq, idx_qr_mm_tid)
    return (qh_mm_tid, qh_quant_tid, idx_qr_mm_tid)
