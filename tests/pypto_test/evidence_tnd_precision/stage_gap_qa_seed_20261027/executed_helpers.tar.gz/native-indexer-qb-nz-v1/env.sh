#!/usr/bin/env bash
set -euo pipefail
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/query-sort-perf-20261022-codex/env.sh"
sdk=/data/pyptouser/yejia/csa-nal-sdk-20261026
export PATH="/data/pyptouser/yejia/csa-spmd-sdk-20261020/sources/pypto/.venv/bin:$sdk/sources/ptoas/build-native/bin:$PATH"
export PTOAS_ROOT="$sdk/sources/ptoas/build-native"
export CCACHE_DIR="$sdk/sources/pypto/.ccache" CMAKE_BUILD_PARALLEL_LEVEL=4
export TORCH_DEVICE_BACKEND_AUTOLOAD=0 PYTHONNOUSERSITE=1 HCCL_DETERMINISTIC=true
export PYPTO_PROG_BUILD_DIR="/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-gap-20261026-codex/direct-publish-v5/build" PYPTO_CACHE_DIR="/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/combined-opt-20261023-codex/cache"
export VLLM_ASCEND_ENABLE_NZ=2 VLLM_ASCEND_PTO_CSA_ATOMIC_ADD=0

export PYPTO_PROG_BUILD_DIR="/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-gap-20261026-codex/same-sdk-threeway-v1/build"

export PYPTO_PROG_BUILD_DIR="/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-sdk-alignment-20261026-codex/native-indexer-qb-nz-v1/build"

export PYPTO_CACHE_DIR="/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-sdk-alignment-20261026-codex/cache"
