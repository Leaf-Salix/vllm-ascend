from common import *
import torch_npu
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program
from pypto.runtime._kernel_artifact import KernelArtifact
out=ROOT/'cpu';out.mkdir(exist_ok=False)
record={'pass':False,'device_execution':False,'source':IDENTITY,'manifest_sha256':hashlib.sha256((ROOT/'manifest.json').read_bytes()).hexdigest(),'sdk':json.loads(Path(os.environ['PREFLIGHT_RECEIPT']).read_text()),'kernels':{}}
for arm in ('baseline','candidate'):
 for route in ('generic','packet'):
  name=arm+'_'+route
  program=getattr(roots,name).specialize()
  abi=kernel_abi_for_program(program,platform='a2a3',runtime='tensormap_and_ringbuffer')
  assert len(abi.parameters)==3
  _compile_impl(program,output_dir=str(out/name),platform='a2a3',skip_ptoas=False,_kernel_abi=abi)
  artifact=KernelArtifact(out/name,abi);artifact.load()
  record['kernels'][name]={'artifact_identity':artifact.identity().hex(),'parameters':3}
assert not torch_npu.npu.is_initialized()
record.update(pass_=True,npu_initialized=False);record['pass']=True
(out/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
print('COMPLETE',record,flush=True)
