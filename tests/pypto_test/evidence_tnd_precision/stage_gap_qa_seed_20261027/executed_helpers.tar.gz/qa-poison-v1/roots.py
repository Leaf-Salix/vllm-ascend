import pypto.language as pl
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.qkv_proj_rope import T_DYN,D,Q_LORA,QPROJ_MM_T_DYN,BF16_WEIGHT_LAYOUT,q_proj_qa as baseline_generic_inline
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.qkv_precision126 import q_proj_qa_126 as baseline_packet_inline
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.gap_qa_generic_no_seed import q_proj_qa as candidate_generic_inline
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.gap_qa126_no_seed import q_proj_qa_126 as candidate_packet_inline

@pl.jit
def baseline_generic(x: pl.Tensor[[T_DYN,D],pl.BF16], w: pl.Tensor[[Q_LORA,D],pl.BF16,BF16_WEIGHT_LAYOUT], out: pl.Out[pl.Tensor[[QPROJ_MM_T_DYN,Q_LORA],pl.FP32]]):
    rows = pl.tensor.dim(x,0)
    baseline_generic_inline(x,w,out,0,rows)
    return out

@pl.jit
def baseline_packet(x: pl.Tensor[[T_DYN,D],pl.BF16], w: pl.Tensor[[Q_LORA,D],pl.BF16,BF16_WEIGHT_LAYOUT], out: pl.Out[pl.Tensor[[QPROJ_MM_T_DYN,Q_LORA],pl.FP32]]):
    rows = pl.tensor.dim(x,0)
    baseline_packet_inline(x,w,out,0,rows)
    return out

@pl.jit
def candidate_generic(x: pl.Tensor[[T_DYN,D],pl.BF16], w: pl.Tensor[[Q_LORA,D],pl.BF16,BF16_WEIGHT_LAYOUT], out: pl.Out[pl.Tensor[[QPROJ_MM_T_DYN,Q_LORA],pl.FP32]]):
    rows = pl.tensor.dim(x,0)
    candidate_generic_inline(x,w,out,0,rows)
    return out

@pl.jit
def candidate_packet(x: pl.Tensor[[T_DYN,D],pl.BF16], w: pl.Tensor[[Q_LORA,D],pl.BF16,BF16_WEIGHT_LAYOUT], out: pl.Out[pl.Tensor[[QPROJ_MM_T_DYN,Q_LORA],pl.FP32]]):
    rows = pl.tensor.dim(x,0)
    candidate_packet_inline(x,w,out,0,rows)
    return out
