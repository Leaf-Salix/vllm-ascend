#!/usr/bin/env bash
source /data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-sdk-alignment-20261026-codex/native-qa-no-seed-v2/env.sh
export PYPTO_PROG_BUILD_DIR=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-sdk-alignment-20261026-codex/qa-poison-v1/build
