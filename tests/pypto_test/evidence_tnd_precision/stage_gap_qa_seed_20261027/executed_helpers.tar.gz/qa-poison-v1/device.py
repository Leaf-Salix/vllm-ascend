from common import *
import torch,torch_npu,pypto.torch
from safetensors import safe_open
out=ROOT/'results'/sys.argv[1];out.mkdir(parents=True,exist_ok=False)
receipt=json.loads((ROOT/'cpu/receipt.json').read_text());assert receipt['pass'] and receipt['device_execution'] is False
assert receipt['source']==IDENTITY and receipt['manifest_sha256']==hashlib.sha256((ROOT/'manifest.json').read_bytes()).hexdigest()
for k in ('source_heads','binary_sha256','ptoas_binary_sha256'):assert receipt['sdk'][k]==json.loads(Path(os.environ['PREFLIGHT_RECEIPT']).read_text())[k]
torch.npu.set_device(0);torch.npu.config.allow_internal_format=True
torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1)
assert os.environ['HCCL_DETERMINISTIC']=='true'
pypto.torch.init(output_dir=out/'runtime')
model=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8');key='layers.4.attn.wq_a.weight'
shard=json.loads((model/'quant_model_weights.safetensors.index.json').read_text())['weight_map'][key]
with safe_open(model/shard,framework='pt',device='cpu') as f:w_cpu=f.get_tensor(key)
assert w_cpu.shape==(1024,4096) and w_cpu.dtype==torch.bfloat16
w=torch_npu.npu_format_cast(w_cpu.npu(),29);w_before=w.cpu();assert torch.equal(w_before,w_cpu)
ops={name:pypto.torch.register(getattr(roots,name),'qa_poison::'+name) for name in receipt['kernels']}
result={'pass':False,'complete':False,'scope':'QA overwrite/poison regression versus seeded accepted QA; not Native or whole model accuracy','manifest_sha256':receipt['manifest_sha256'],'source':IDENTITY,'weight':{'key':key,'shard':shard,'format':torch_npu.get_npu_format(w),'sha256':hashlib.sha256(w_cpu.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()},'cases':[]}
def save():(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
def exact(x,y):return torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
for rows,route in [(4,'generic'),(17,'generic'),(21,'generic'),(95,'packet'),(126,'packet'),(168,'packet'),(192,'generic'),(240,'generic'),(256,'generic')]:
 gen=torch.Generator().manual_seed(1729+rows);cpu=torch.randn((rows,4096),generator=gen,dtype=torch.float32).to(torch.bfloat16)
 x=cpu.npu();x_before=x.cpu();n=(rows+15)//16*16
 storage={arm:torch.full((n+2,1024),-173.0,device='npu',dtype=torch.float32) for arm in ('baseline','candidate')}
 outputs={arm:storage[arm][1:-1] for arm in storage};graphs={};eager={}
 for arm in ('baseline','candidate'):
  fn=ops[arm+'_'+route];outputs[arm].fill_(float('nan'));fn(x,w,outputs[arm]);torch.npu.synchronize();eager[arm]=outputs[arm].cpu();assert exact(x.cpu(),x_before) and exact(w.cpu(),w_before),'eager readonly changed'
  graph=torch.npu.NPUGraph()
  with torch.npu.graph(graph):fn(x,w,outputs[arm])
  graphs[arm]=graph
 assert exact(eager['baseline'],eager['candidate']) and torch.isfinite(eager['candidate']).all(),(rows,route,'eager first difference')
 a_reference=None
 for iteration,(phase,poison) in enumerate([('A',float('nan')),('B',float('inf')),('A',913.25)]):
  expected_x=cpu if phase=='A' else (cpu.float()+0.125).to(torch.bfloat16)
  x.copy_(expected_x.npu())
  for arm in ('baseline','candidate'):
   outputs[arm].fill_(poison);graphs[arm].replay();torch.npu.synchronize()
   assert exact(x.cpu(),expected_x) and exact(w.cpu(),w_before),(rows,route,phase,arm,'readonly changed')
  torch.npu.synchronize()
  for arm in storage:
   assert bool((storage[arm][0]==-173.0).all()) and bool((storage[arm][-1]==-173.0).all()),(rows,route,'guard')
  base,cand=(outputs[a].cpu() for a in ('baseline','candidate'))
  assert torch.isfinite(base).all() and torch.isfinite(cand).all(),(rows,route,phase,'nonfinite stale GM')
  assert exact(base,cand),(rows,route,phase,'QA first difference')
  if iteration==0:
   assert exact(base,eager['baseline']),'eager/FULL mismatch'
   a_reference=base.clone()
  if iteration==1:assert not exact(base,a_reference),'ineffective B input'
  if iteration==2:assert exact(base,a_reference),'ABA mismatch'
  result['cases'].append({'rows':rows,'physical_output_rows':n,'route':route,'phase':phase,'poison':str(poison),'full_output_bit_equal':True,'full_output_finite':True,'perimeter_guards':True,'eager_full_bit_equal':True if phase=='A' else None,'phase_input_and_weight_readonly':True})
  save()
 assert exact(x.cpu(),x_before) and exact(w.cpu(),w_before)
 print('CASE_PASS',rows,route,flush=True)
result.update(pass_=True,complete=True);result['pass']=True;save();print('COMPLETE',len(result['cases']),flush=True)
