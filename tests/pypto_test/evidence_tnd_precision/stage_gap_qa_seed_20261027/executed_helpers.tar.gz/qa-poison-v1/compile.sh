#!/usr/bin/env bash
set -euo pipefail
qp_job_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source "$qp_job_root/env.sh"
export ASCEND_RT_VISIBLE_DEVICES="" PREFLIGHT_RECEIPT="$qp_job_root/compile-sdk.json"
ccache -s
timeout 700s python "$qp_job_root/compile.py" > "$qp_job_root/compile.log" 2>&1
