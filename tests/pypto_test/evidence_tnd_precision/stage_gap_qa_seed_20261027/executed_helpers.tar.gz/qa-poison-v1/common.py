from pathlib import Path
import sys,runpy,json,hashlib,os
ROOT=Path(__file__).resolve().parent
PARENT=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-sdk-alignment-20261026-codex/native-qa-no-seed-v2')
sys.path.insert(0,str(PARENT))
manifest=json.loads((ROOT/'manifest.json').read_text())
for rel,sha in manifest.items():assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==sha,rel
parent_manifest=json.loads((PARENT/'manifest.json').read_text())
for rel,sha in parent_manifest.items():assert hashlib.sha256((PARENT/rel).read_bytes()).hexdigest()==sha,rel
assert hashlib.sha256((PARENT/'manifest.json').read_bytes()).hexdigest()=='cd735e7f7944c37d04537ac16f638ff3e27a06e97a3cdab3539582cbc3c82ef3'
runpy.run_path(str(PARENT/'sdk_bind.py'),run_name='__sdk_preflight__')
from source_identity import source_identity
IDENTITY=source_identity()
from load_candidate import entry_for
entry_for('candidate')
import roots
