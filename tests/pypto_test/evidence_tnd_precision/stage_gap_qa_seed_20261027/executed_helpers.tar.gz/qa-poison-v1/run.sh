#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?}"
label=${1:?}; shift
if (( $# )); then [[ $# == 2 && "$1" == --device && "$2" == "$TASK_DEVICE" ]]; fi
[[ "$label" =~ ^[a-z0-9-]+$ ]]
qp_job_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source "$qp_job_root/env.sh"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE" PREFLIGHT_RECEIPT="$qp_job_root/$label-sdk.json"
mkdir -p "$qp_job_root/results"
test ! -e "$qp_job_root/results/$label"
printf 'TASK_RUN_START %s\n' "$(date -Iseconds)"
trap 'printf "TASK_RUN_END %s\n" "$(date -Iseconds)"' EXIT
timeout --signal=TERM --kill-after=15s 750s python "$qp_job_root/device.py" "$label" > "$qp_job_root/results/$label.log" 2>&1
