#!/usr/bin/env bash
set -euo pipefail
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/query-sort-perf-20261022-codex/env.sh"
sdk=/data/pyptouser/yejia/csa-spmd-sdk-20261020
export PATH="$sdk/sources/pypto/.venv/bin:$sdk/toolchain-wheel/bin:$PATH"
export PTOAS_ROOT="$sdk/toolchain-wheel"
export CCACHE_DIR="$sdk/sources/pypto/.ccache" CMAKE_BUILD_PARALLEL_LEVEL=4
export TORCH_DEVICE_BACKEND_AUTOLOAD=0 PYTHONNOUSERSITE=1 HCCL_DETERMINISTIC=true
export PYPTO_PROG_BUILD_DIR="/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-sdk-alignment-20261026-codex/qa-whole-formal-v1/build" PYPTO_CACHE_DIR="/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/combined-opt-20261023-codex/cache"
export VLLM_ASCEND_ENABLE_NZ=2 VLLM_ASCEND_PTO_CSA_ATOMIC_ADD=0
