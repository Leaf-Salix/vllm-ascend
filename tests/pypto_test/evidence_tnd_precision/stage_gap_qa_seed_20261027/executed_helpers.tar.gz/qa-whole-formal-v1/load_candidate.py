"""Load the actual formal baseline and tuned package without patching kernels."""
import importlib
C='vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_combined'
T='vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_tuned'
def package_for(arm):
    assert arm in ('baseline','tuned')
    return C if arm=='baseline' else T
def entry_for(arm):
    return importlib.import_module(package_for(arm)+'.decode_csa').decode_csa_tp1_layer_test
def operators_for(arm):
    return importlib.import_module(package_for(arm)+'.native_adapter').CSAOperators.register()
