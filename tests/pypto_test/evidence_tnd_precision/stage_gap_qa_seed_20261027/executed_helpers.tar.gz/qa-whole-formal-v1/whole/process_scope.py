"""只在本轮模型入口与真实spawn worker安装测试hook。"""
from pathlib import Path


def should_activate(argv, original, environ):
    here = Path(__file__).resolve().parent
    if argv and Path(argv[0]).resolve() in {
        here / 'preflight.py', here / 'cache_worker_probe.py',
        Path(environ.get('SOURCE_ROOT', '/nonexistent')) / 'tests/pypto_test/offline_pd/run.py',
    }:
        return True
    if '-c' not in original or '--multiprocessing-fork' not in original:
        return False
    index = original.index('-c') + 1
    return index < len(original) and original[index].lstrip().startswith(
        'from multiprocessing.spawn import spawn_main;')
