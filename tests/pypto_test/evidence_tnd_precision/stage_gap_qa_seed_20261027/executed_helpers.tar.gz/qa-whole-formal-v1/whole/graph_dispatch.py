"""只记录实际已捕获图的回放分派，不改变执行路径。"""
def install_acl(module):
    original=module.ACLGraphWrapper.__call__
    def call(wrapper,*args,**kwargs):
        context=module.get_forward_context()
        routes=context.additional_kwargs.get('_fusion_actual_graph_routes')
        entry=wrapper.concrete_aclgraph_entries.get(context.batch_descriptor)
        valid=(context.cudagraph_runtime_mode==module.CUDAGraphMode.FULL
               and wrapper.runtime_mode==module.CUDAGraphMode.FULL
               and entry is not None and entry.aclgraph is not None)
        result=original(wrapper,*args,**kwargs)
        if routes is not None:
            routes.append({'kind':'ACLGraphWrapper','actual_full_replay':valid})
        return result
    module.ACLGraphWrapper.__call__=call


def install_npugraph(module):
    from vllm.forward_context import get_forward_context
    from vllm.config import CUDAGraphMode
    original=module.AclGraph.run
    def call(owner,key,*args,**kwargs):
        context=get_forward_context()
        routes=context.additional_kwargs.get('_fusion_actual_graph_routes')
        valid=context.cudagraph_runtime_mode==CUDAGraphMode.FULL and key in owner.graph
        result=original(owner,key,*args,**kwargs)
        if routes is not None:
            routes.append({'kind':'npugraph_ex.AclGraph','actual_full_replay':valid})
        return result
    module.AclGraph.run=call
