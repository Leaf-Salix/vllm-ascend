"""Private timing RPCs: CPU metadata, prewarmed events, no tensor D2H hooks."""
import math
import statistics


def allocation_plan(config):
    tensors = sorted([{'size':int(t.size),'shared_by':sorted(t.shared_by)} for t in config.kv_cache_tensors],key=lambda t:t['shared_by'])
    return {'num_blocks':int(config.num_blocks),'tensors':tensors,'aligned_allocation_upper_bytes':sum(t['size']+2*1024**2 for t in tensors)}


def cycle_stats(events, requests, metadata):
    samples, counts = [], []
    for index,(left, right) in enumerate(zip(events,events[1:])):
        if right['call'] != left['call']+1:
            raise ValueError('Nonconsecutive target forward cycles')
        value = left['begin'].elapsed_time(right['begin'])*1000
        rows = getattr(left.get('sample_output'), 'sampled_token_ids', None)
        if not math.isfinite(value) or value<=0 or not isinstance(rows,list) or len(rows)!=requests or not all(isinstance(row,list) and row and all(type(t)is int and t>=0 for t in row) for row in rows):
            raise ValueError('Invalid cycle timestamp or actual sampled output')
        a,b=metadata[index],metadata[index+1]
        if a['keys']!=b['keys']:raise ValueError('Cycle request order changed')
        advances=[b['positions_cpu'][q]-a['positions_cpu'][p] for p,q in zip(a['query_bounds'][:-1],b['query_bounds'][:-1],strict=True)]
        count=sum(map(len,rows))
        if not all(1<=v<=6 for v in advances) or sum(advances)!=count:raise ValueError('Async sample output does not match actual request position advance')
        samples.append(value);counts.append(count)
    return {'samples_us':samples,'actual_output_tokens':counts,'mean_us':statistics.mean(samples),
            'p50_us':statistics.median(samples),'actual_output_tokens_per_second':sum(counts)/(sum(samples)*1e-6),
            'scope':'Consecutive target model_forward begin-to-begin device events, includes logits, sampling, DSpark draft, scheduling gaps and CPU metadata observer overhead; excludes initial model/cache loading. Rank clocks not globally aligned.'}


def install(module):
    cls=module.OfflineCSAObserver
    def identity(self):
        import pypto
        from pypto._cache_config import cache_stats
        return {'cache_stats':vars(cache_stats()),'pypto_file':pypto.__file__,
                'capture_time_selection':{k:dict(v) for k,v in module._CSA_SELECTION.items()},
                'static_full_qualification':__import__('qualified_wkv').finish()}
    def begin(self, warmup, tokens, requests, steps):
        from vllm.forward_context import get_forward_context
        self.offline_begin_forward(warmup,tokens,requests,steps,False)
        runner=self.model_runner
        state, events, _, _=self._offline_forward
        execute_original, forward_original, sample_original=runner.execute_model,runner._model_forward,runner.sample_tokens
        capture={'scheduler':None,'keys':{},'metadata':[]}
        def execute(scheduled,*args,**kwargs):
            for req in scheduled.scheduled_new_reqs:
                capture['keys'][req.req_id]=req.sampling_params.extra_args['kv_transfer_params']['offline_key']
            capture['scheduler']=scheduled
            try:return execute_original(scheduled,*args,**kwargs)
            finally:capture['scheduler']=None
        def forward(padded,input_ids,positions,*args,**kwargs):
            scheduled=capture['scheduler']; index=state['seen_steps']-1
            measured=False
            if scheduled is not None and scheduled.total_num_scheduled_tokens==tokens and len(scheduled.num_scheduled_tokens)==requests and warmup<=index<warmup+steps:
                context=get_forward_context()
                measured=True
                assert context.cudagraph_runtime_mode.name=='FULL', 'Selected performance step fell back from FULL'
                assert int(padded)==int(__import__('os').environ['PERF_CAPTURE_BUCKET'])
                dp_tokens=context.dp_metadata.num_tokens_across_dp_cpu.tolist()
                assert len(dp_tokens)==16 and all(tokens<=q<=int(padded) for q in dp_tokens)
                graph_routes=[]
                context.additional_kwargs['_fusion_actual_graph_routes']=graph_routes
                rows=list(runner.input_batch.req_ids[:runner.input_batch.num_reqs])
                if set(rows)!=set(scheduled.num_scheduled_tokens):raise ValueError('Input batch differs from scheduler')
                meta=next((m for m in (context.attn_metadata or {}).values() if getattr(getattr(m,'decode',None),'query_start_loc_cpu',None)is not None),None)
                if meta is None:raise ValueError('Missing CPU query bounds')
                bounds=meta.decode.query_start_loc_cpu[:requests+1].tolist()
                if bounds[0]!=0 or bounds[-1]!=tokens or len(rows)!=requests:raise ValueError('Wrong measured workload')
                capture['metadata'].append({'index':index,'call':state['all_execute_calls']-1,'actual_tokens':tokens,'requests':requests,'padded_tokens':int(padded),
                    'actual_graph_routes':graph_routes,'graph_mode':context.cudagraph_runtime_mode.name,'keys':[capture['keys'][r] for r in rows],
                    'query_bounds':bounds,'positions_cpu':runner._dsa_positions_cpu_buf[:tokens].tolist(),
                    'input_ids_cpu':runner.input_ids.cpu[:tokens].tolist(),
                    'dp_tokens':context.dp_metadata.num_tokens_across_dp_cpu.tolist()})
            result=forward_original(padded,input_ids,positions,*args,**kwargs)
            if measured:
                assert any(q['actual_full_replay'] for q in graph_routes), 'No actual captured FULL graph dispatch'
            return result
        def sample(*args,**kwargs):
            result=sample_original(*args,**kwargs)
            if events and events[-1]['call']==state['all_execute_calls']-1 and 'sample_output' not in events[-1]:
                events[-1]['sample_output']=getattr(result,'_model_runner_output',result)
            return result
        runner.execute_model,runner._model_forward,runner.sample_tokens=execute,forward,sample
        self._real_perf=(capture,sample_original,requests,steps)
        return {'warmup':warmup,'tokens':tokens,'requests':requests,'steps':steps}
    def end(self):
        capture,original_sample,requests,steps=self._real_perf
        events=list(self._offline_forward[1])
        result=self.offline_end_forward()
        self.model_runner.sample_tokens=original_sample
        if not result['sufficient'] or len(capture['metadata'])!=steps:raise ValueError('Insufficient measured forward/metadata')
        result['metadata']=capture['metadata'];result['cycle']=cycle_stats(events,requests,capture['metadata'])
        if len(result['cycle']['samples_us'])!=steps-1:raise ValueError('Insufficient cycle samples')
        result['metadata_scope']='Existing CPU buffers only; no new GPU input copy or all-layer bit probe'
        result['identity']=identity(self)
        del self._real_perf
        return result
    cls.offline_perf_identity=identity
    cls.offline_begin_real_perf=begin
    cls.offline_end_real_perf=end
