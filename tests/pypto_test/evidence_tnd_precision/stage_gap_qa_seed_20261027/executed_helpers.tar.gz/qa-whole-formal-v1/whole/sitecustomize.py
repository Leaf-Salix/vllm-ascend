"""独立整模型fusion测试：只在模型/真实worker启用，异常立即退出。"""
import os
import sys
if os.environ.get('FUSION_WHOLE_ACTIVE') == '1':
    try:
        from process_scope import should_activate
        if should_activate(sys.argv, sys.orig_argv, os.environ):
            import importlib.util
            import os
            import sys
            from importlib.machinery import PathFinder
            
            from pathlib import Path
            import runpy
            from process_scope import should_activate
            assert os.environ.get('FUSION_WHOLE_ACTIVE') == '1'
            assert should_activate(sys.argv, sys.orig_argv, os.environ)
            HERE = Path(__file__).resolve().parent
            os.environ['PREFLIGHT_RECEIPT'] = str(Path(os.environ['PERF_OUTPUT']) / f'sdk-{os.getpid()}.json')
            runpy.run_path(str(HERE.parent / 'sdk_bind.py'), run_name='__whole_sdk__')
            spec = importlib.util.spec_from_file_location('fusion_runtime_bridge', HERE / 'runtime_bridge.py')
            existing = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(existing)
            from runtime_sizing import install
            install()
            # StaticFinder is the unchanged official bridge, retaining all 13 package checks.
            
            
            class WorkerLoader:
                def __init__(self, original):
                    self.original = original
            
                def create_module(self, spec):
                    return self.original.create_module(spec)
            
                def exec_module(self, module):
                    self.original.exec_module(module)
                    original = module.OfflineNPUWorker.initialize_from_config
            
                    def initialize(worker, config, *args, **kwargs):
                        import json
                        from pathlib import Path
                        import torch
                        from perf_probe import allocation_plan
                        plan = allocation_plan(config)
                        free, total = torch.npu.mem_get_info()
                        rank = worker.vllm_config.parallel_config.data_parallel_rank
                        report = dict(plan, free_bytes_before_allocation=free, total_bytes=total)
                        directory = Path(os.environ['PERF_OUTPUT'])
                        directory.mkdir(parents=True, exist_ok=True)
                        (directory / f'rank{rank}.capacity.json').write_text(json.dumps(report, indent=2)+'\n')
                        if plan['num_blocks'] != int(os.environ['LOW_ACCEPTANCE_GPU_BLOCKS']):
                            raise RuntimeError('Actual KV blocks do not match diagnostic request')
                        planned = plan['aligned_allocation_upper_bytes']
                        if planned > 21 * 1024**3 or planned + 2 * 1024**3 > free:
                            raise RuntimeError(f'Unsafe KV allocation plan: blocks={plan["num_blocks"]} upper={planned} free={free} limit={21 * 1024**3} reserve={2 * 1024**3}')
                        print(f'ADMISSION_KV_CAPACITY blocks={plan["num_blocks"]} aligned_upper_bytes={planned} free_bytes={free}', flush=True)
                        return original(worker, config, *args, **kwargs)
            
                    original_load = module.OfflineNPUWorker.load_model
                    def load(worker,*args,**kwargs):
                        result = original_load(worker,*args,**kwargs)
                        if os.environ['PERF_BACKEND'] == 'pto':
                            from qualified_wkv import install_service
                            install_service(worker.model_runner.model)
                        return result
                    module.OfflineNPUWorker.load_model = load
                    module.OfflineNPUWorker.initialize_from_config = initialize
            
            
            class Loader:
                def __init__(self, original, fullname): self.original, self.fullname = original, fullname
                def create_module(self, spec): return self.original.create_module(spec)
                def exec_module(self, module):
                    self.original.exec_module(module)
                    if self.fullname == 'vllm_ascend.compilation.acl_graph':
                        from graph_dispatch import install_acl
                        install_acl(module)
                    elif self.fullname == 'npugraph_ex._acl_concrete_graph.acl_graph':
                        from graph_dispatch import install_npugraph
                        install_npugraph(module)
                    elif self.fullname == 'offline_pd.observer':
                        from perf_probe import install
                        install(module)
                    else:
                        from mixed_perf import run_batches
                        module.run_batches = run_batches
            
            class Finder:
                @staticmethod
                def find_spec(fullname, path=None, target=None):
                    if fullname not in ('offline_pd.worker','offline_pd.observer','low_acceptance_20261001.mixed','vllm_ascend.compilation.acl_graph','npugraph_ex._acl_concrete_graph.acl_graph'): return None
                    spec = PathFinder.find_spec(fullname, path)
                    if spec:
                        spec.loader = WorkerLoader(spec.loader) if fullname == 'offline_pd.worker' else Loader(spec.loader, fullname)
                    return spec
            
            sys.meta_path.insert(0, Finder)
            
            class QualifiedStaticLoader:
                def __init__(self,original):self.original=original
                def create_module(self,spec):return self.original.create_module(spec)
                def exec_module(self,module):
                    self.original.exec_module(module)
                    from qualified_wkv import install_static
                    install_static(module)
            class QualifiedStaticFinder:
                @staticmethod
                def find_spec(fullname,path=None,target=None):
                    if not fullname.endswith('npugraph_ex._acl_concrete_graph.static_kernel'):return None
                    spec=existing.StaticFinder.find_spec(fullname,path,target)
                    if spec is not None:spec.loader=QualifiedStaticLoader(spec.loader)
                    return spec
            sys.meta_path.insert(0,QualifiedStaticFinder)
    except BaseException:
        import traceback
        print('FUSION_SITECUSTOMIZE_FATAL', file=sys.stderr, flush=True)
        traceback.print_exc()
        sys.stderr.flush()
        os._exit(70)
