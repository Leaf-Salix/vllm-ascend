"""Use the actual framework cached branch; keep installation and selection native."""
import hashlib
import json
import os
from pathlib import Path

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def install_bridge(module):
    original = module.compile_static_kernel
    def deny_compile(*args, **kwargs):
        raise RuntimeError('Official cache unexpectedly attempted fresh compilation')
    module.static_compile = deny_compile
    def cached(fx_func,*args,**kwargs):
        import torch
        import torch_npu
        import acl
        folder=Path(os.environ['LOW_ACCEPTANCE_OFFICIAL_CACHE'])
        metadata=json.loads((folder/'metadata.json').read_text())
        assert metadata['super_kernel'] is False and not kwargs.get('super_kernel_optimize')
        assert metadata['follow_op_params_jit'] is True
        assert acl.get_soc_name() == metadata['soc']
        assert metadata['deterministic']=='1' and torch.are_deterministic_algorithms_enabled()
        assert Path(os.environ['ASCEND_HOME_PATH']).resolve()==Path(metadata['cann_home']).resolve()
        assert torch_npu.npu.utils.get_cann_version()==metadata['cann_version']
        assert digest(module.__file__)==metadata['static_module_sha256']
        assert digest(metadata['compiler_path'])==metadata['compiler_sha256']
        assert metadata['packages']
        actual=set(map(str,folder.glob('static_kernel_compile_outputs/*_outputs/*.run')))
        assert actual==set(metadata['packages'])
        for source,expected in metadata['packages'].items():
            assert digest(source)==expected and os.access(source,os.X_OK)
        assert module._check_for_load_run_pkg(metadata['cann_version'],str(folder),'1')
        kwargs.update(use_cache_compile='1',cached_cann_version=metadata['cann_version'],compile_cache_dir=str(folder),cached_deterministic='1')
        print(f'OFFICIAL_STATIC_CACHE packages={len(actual)} metadata_sha={digest(folder/"metadata.json")} runtime_selection=native',flush=True)
        actual_reselect = torch_npu.npu._aclnn_reselect_static_kernel
        reselected = []
        def tracked_reselect(*values,**options):
            result = actual_reselect(*values,**options)
            reselected.append(True)
            print('OFFICIAL_STATIC_RESELECT success=1',flush=True)
            return result
        torch_npu.npu._aclnn_reselect_static_kernel = tracked_reselect
        try:
            result = original(fx_func,*args,**kwargs)
        finally:
            torch_npu.npu._aclnn_reselect_static_kernel = actual_reselect
        assert reselected, 'Official Native kernel reselection did not succeed'
        rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else 0
        if rank % int(os.environ.get('LOCAL_WORLD_SIZE','1')) == 0:
            expected = set(metadata['packages'].values())
            assert expected <= module._installed_run_pkgs, 'Official package installation incomplete'
            print(f'OFFICIAL_STATIC_INSTALLED verified_packages={len(expected)}',flush=True)
        return result
    module.compile_static_kernel=cached
