"""独立限定修正：原13包验证和实际reselect完成后才允许自然序T6。"""
import hashlib
import json
import os
from pathlib import Path

METADATA_SHA = '863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
runtimes = []
counts = {}
qualification = {'ready': False, 'metadata_sha': METADATA_SHA}


def install_static(module):
    original = module.compile_static_kernel
    selected_result = []

    def compile_qualified(*args, **kwargs):
        import torch_npu
        metadata = Path(os.environ['LOW_ACCEPTANCE_OFFICIAL_CACHE']) / 'metadata.json'
        assert hashlib.sha256(metadata.read_bytes()).hexdigest() == METADATA_SHA
        reuse = qualification['ready']
        if reuse:
            assert len(selected_result) == 1
            assert all(runtime.wkv_profile.metadata_sha256 == METADATA_SHA for runtime in runtimes)
        else:
            assert not any(runtime.wkv_profile.captured for runtime in runtimes), 'Do not reselect after capture'
        actual = torch_npu.npu._aclnn_reselect_static_kernel
        calls = []

        def tracked(*values, **options):
            # The pinned SDK API is a process-global, no-argument reselection.
            assert not values and not options, 'Unexpected static reselection ABI'
            if reuse:
                calls.append('reuse')
                return selected_result[0]
            assert not calls, 'Multiple initial static reselections'
            assert not any(runtime.wkv_profile.captured for runtime in runtimes), 'Do not reselect after capture'
            result = actual()
            selected_result.append(result)
            calls.append('actual')
            return result

        torch_npu.npu._aclnn_reselect_static_kernel = tracked
        try:
            # Every call retains all original 13-package/SDK/SOC/determinism checks.
            # After the first successful installation, the same selection is reused.
            result = original(*args, **kwargs)
        finally:
            torch_npu.npu._aclnn_reselect_static_kernel = actual
        assert calls, 'No static selection callback'
        if reuse:
            assert all(call == 'reuse' for call in calls)
            qualification['validated_reuses'] = qualification.get('validated_reuses', 0) + 1
            print('WKV_STATIC_SELECTION_REUSED after_original_package_validation=1', flush=True)
            return result
        assert calls == ['actual'], 'No unique actual static reselection'
        assert len(runtimes) == (21 if os.environ['PERF_BACKEND']=='pto' else 0)
        for runtime in runtimes:
            runtime.qualify_static_wkv(metadata_sha256=METADATA_SHA, reselected=True)
        qualification['ready'] = True
        qualification['actual_reselections'] = 1
        print('WKV_STATIC_QUALIFIED ' + json.dumps(qualification), flush=True)
        return result

    module.compile_static_kernel = compile_qualified


def install_service(model):
    import torch
    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_tuned import service
    if getattr(service.CSAServiceRuntime.__call__, '_qualified_wkv', False):
        return
    original = service.CSAServiceRuntime.__call__
    for layer in model.model.layers:
        runtime = getattr(layer.self_attn.dsa_attn, '_pto_csa_runtime', None)
        if runtime is not None:
            assert type(runtime) is service.CSAServiceRuntime
            runtimes.append(runtime)
    assert len(runtimes) == 21 and len({id(runtime) for runtime in runtimes}) == 21
    assert len({id(runtime.operators.workspace) for runtime in runtimes}) == 1
    import re
    indices = {int(re.search(r'\.layers\.(\d+)\.', runtime.layer_name).group(1)) for runtime in runtimes}
    assert indices == set(range(2, 43, 2))
    required = ('hc_pre', 'input_norm', 'wkv', 'indexer_weights', 'o_proj', 'hc_post')
    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_tuned.selection import CaptureAttention
    for runtime in runtimes:
        assert runtime.restored_modules == required
        assert runtime.single_pto_entry
        original_ops=runtime.operators
        router=original_ops.attention
        assert isinstance(router,CaptureAttention)
        schema=router._schema
        assert schema.name=='dsv4_csa_tnd_precision_spmd_tuned::attention'
        assert len(schema.arguments)==64
        assert schema.arguments[0].name=='x_hc' and schema.arguments[53].name=='x_out'
        assert str(router.baseline.small._schema).partition('(')[2]==str(schema).partition('(')[2]
        counts[runtime.layer_name]={}
        def projection(*args,_runtime=runtime,_router=router,**kwargs):
            tokens=args[0].shape[0]
            selected=_router.for_tokens(tokens)
            capturing=torch.npu.is_current_stream_capturing()
            assert qualification['ready'] and _runtime.wkv_profile.metadata_sha256==METADATA_SHA
            row=counts[_runtime.layer_name].setdefault(str(tokens),{'warmup':0,'capture':0})
            row['root_namespace']=selected._schema.name
            if capturing:
                assert row['warmup']>0,'Formal selected complete root was not warmed'
                row['capture']+=1
            else:row['warmup']+=1
            # Exercise the formal router; observer never registers or replaces kernels.
            return _router(*args,**kwargs)
        projection._schema=schema
        runtime.operators=type(original_ops)(projection,original_ops.workspace)
    def forward(runtime, context, hidden, positions, output, kv_cache):
        assert qualification['ready'], 'Full PTO CSA invoked before verified static installation'
        return original(runtime, context, hidden, positions, output, kv_cache)
    forward._qualified_wkv = True
    service.CSAServiceRuntime.__call__ = forward


def finish():
    from runtime_sizing import proof
    runtime_sizing = proof()
    assert qualification['ready'] and qualification['actual_reselections'] == 1
    assert qualification.get('validated_reuses', 0) > 0
    if os.environ['PERF_BACKEND'] in ('native', 'nal'):
        assert not runtimes and not counts
        return {'backend':os.environ['PERF_BACKEND'],'ready':True,'metadata_sha256':METADATA_SHA,
                'actual_reselections':1,'validated_reuses':qualification['validated_reuses'],
                'restored_modules':[],'single_root_counts':{}}
    assert os.environ['PERF_BACKEND'] == 'pto'
    assert len(counts) == 21 and len(runtimes) == 21
    for layer, sizes in counts.items():
        for tokens in (6,int(os.environ['PERF_CAPTURE_BUCKET'])):
            row = sizes.get(str(tokens), {})
            assert row.get('warmup', 0) > 0 and row.get('capture', 0) > 0, (layer, tokens, row)
    return {'runtime_sizing':runtime_sizing,'backend':'pto','ready':True,'metadata_sha256':METADATA_SHA,'actual_reselections':1,
            'validated_reuses':qualification['validated_reuses'],
            'restored_modules':list(runtimes[0].restored_modules),'single_root_counts':counts,
            'root_namespace':'formal capture router: original T<=16 / H3 T<96 / tuned T>=96','root_abi_tensors':64,'scope':'complete pure-DSL PTO runtime per-layer single root real capture and preceding warmup; replay uses captured graph'}
