"""Load only the new formal package/alias; preserve the immutable control snapshot."""
import hashlib
import importlib.abc
import importlib.util
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent
PACKAGE='vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_combined'
TUNED='vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_tuned'
VARIANT='vllm_ascend.ops.pypto.variant'
ENVS='vllm_ascend.envs'


def install():
    proof=json.loads((ROOT/'SOURCE.json').read_text())
    for rel,expected in proof['candidates'].items():
        assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==expected,rel
    if any(getattr(f,'_combined_overlay',False) for f in sys.meta_path):return
    assert TUNED not in sys.modules and PACKAGE not in sys.modules and VARIANT not in sys.modules and ENVS not in sys.modules, 'Overlay must install before framework imports'
    class Finder(importlib.abc.MetaPathFinder):
        _combined_overlay=True
        def find_spec(self,fullname,path=None,target=None):
            if fullname=='vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.gap_qa_no_seed':return importlib.util.spec_from_file_location(fullname,ROOT/'qa_generic.py')
            if fullname==ENVS:return importlib.util.spec_from_file_location(fullname,ROOT/'candidate_envs.py')
            if fullname==VARIANT:return importlib.util.spec_from_file_location(fullname,ROOT/'candidate_variant.py')
            if fullname==PACKAGE:
                return importlib.util.spec_from_file_location(fullname,ROOT/'candidate_package/__init__.py',submodule_search_locations=[str(ROOT/'candidate_package')])
            if fullname==TUNED:
                return importlib.util.spec_from_file_location(fullname,ROOT/'candidate_tuned/__init__.py',submodule_search_locations=[str(ROOT/'candidate_tuned')])
            return None
    sys.meta_path.insert(0,Finder())
