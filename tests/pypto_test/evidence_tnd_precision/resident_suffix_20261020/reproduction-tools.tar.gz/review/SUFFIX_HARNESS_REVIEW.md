# Resident 后缀精度/性能 Harness 独立审查

结论：**当前测量、数值与实际导入身份门禁无阻断，可在冻结CPU编译门禁通过后继续T18小任务。** 本次仅只读审查及AST/bash语法检查，未改脚本、未提交设备任务。精确被审SHA见`SUFFIX_HARNESS_REVIEW.json`。

## 通过项

- 从Native模型加载真实L4 WO-A/B与通道scale，检查矩阵shape/dtype/NZ29以及零offset。候选与冻结PTO共用相同heads/residual/post/comb和权重；输出及内部scratch独立。
- 初次eager门禁→FULL raw NPUGraph→A/B/A→12个交替窗口，每个窗口100次，两臂先后顺序交替。5边界逐bit比较：projected BF16、quantized INT8、token_scale FP32、attended BF16、HCpost output；float边界必须finite，首差落结果并立即抛出，不能继续性能测试。
- FULL replay前毒化全部5输出，B改变live heads且必须改变冻结输出，A恢复后所有5边界精确回到A。能防空图/未真正执行/捕获陈旧输入。报告的FULL应解释为“此后缀独立NPUGraph完整捕获”，不是已经走过vLLM整模型FULL scheduler。
- capture和计时均在同一专用stream的context；初始stream wait和全设备同步建立数据准备关系。新SDK torch adapter从当前stream提交kernel，Event start/end也在该context，无明显跨流漏计。每臂end_event.synchronize后取elapsed，未把之后CPU对拍/guard时间算进图耗时。
- generation每次检查所有72个begin及phase owner槽，未用槽/隔离区保持0；FULL_A增长1、每窗口resident100次增长100。任一少核未执行、错误推进或回放常量generation会失败。
- guard覆盖所有输出/scratch与signals首尾；readonly包含权重、scale、start、residual/post/comb，heads恢复后也严格SHA检查。rank3→rank2 residual/output检查了contiguous、data_ptr及storage_offset；两外部scratch按T+127/T+63分配，T18尾块充分。
- 同task两臂均为新SDK执行，构图前已有同shape eager warmup，不依赖capture内首次JIT。无DFX/depgen计时；750秒进程上限明确，调度780秒由提交侧负责。

## 身份与结果表述需补强

1. **实际导入身份建议已落实。** 新probe明确import两个完整模块名，解析`__file__`必须等于SOURCE_ROOT相应文件，且actual文件SHA等于proof sources。结果写入`baseline_actual_modules`。PyPTO/Simpler/adapter由sdk-preflight绑定，冻结后缀由该新门禁绑定，避免路径shadow。
2. **候选及收据建议已落实。** 候选SHA除与SOURCE_PROOF互检外，独立硬限定为`a31a78f89e1ed71c007de2b692434cc0a0f1bc35626b22188418b3e715edd022`。结果保存当前harness SHA、SDK preflight收据和PTOAS_ROOT，路径必须为本独立SDK/toolchain-wheel。提交侧仍应保留run/proof/helper的冻结SHA。上述是静态已见实现，不是设备执行结果。
3. readonly哈希当前只在局部字典使用，报告最后仅写`readonly=true`。建议把这些SHA及heads初始SHA/随机seed、OPROJ_TOKEN_MODES选中档位、实际SDK preflight身份写到result；便于后续跨commit复现，而非仅靠外部日志。
4. 本轮是**真实L4权重 + 合成 heads/residual/post/comb**、resident对冻结PTO后缀。没有调用Native的F.linear/Oproj/HCpost计算金值，不能将PASS写成“直接与Native后缀逐bit对齐”或真实模型精度完成。新SDK上原完整CSA的Native对拍是另一个任务，需独立报告，不能用它替代本任务五边界实际结果。
5. 仅T18初测，未覆盖rows>=192种子快路、T144特殊start、不等start、高249、zero/tiny。T18通过后再按原计划扩展；目前不能外推全T支持或整层/整模型性能。

## 小型非阻断建议

- run仅拒绝out存在，未拒绝同名out-opp-env；建议沿Native runner同样拒绝残留私有OPP目录。这里没有官方static kernel安装操作，风险主要是来源记录混淆，不是当前两臂数学问题。
- `per_request_s6_padding=0`在此后缀没有请求边界输入，只表明真T未做S6向上取整，不能单独当作混合请求TND验收。
- 100连replay的generation最大约1200级，远低于INT32溢出；signals当前只绑定resident图、单stream顺序执行，满足本候选的独占要求。

在冻结两入口的完整CPU编译/Artifact门禁通过且任务时限明确的前提下，可以先执行T18小门禁。仍须设备成功证明MIX信号可见性与无死锁；本静态review不预先授予这些结论。

## 补充：冻结CPU reference v1/v2状态

v1因`skip_ptoas=True`时没有kernel_config，而注册KernelArtifact路径要求完整产物而失败；没有执行数学/NPU，不能记作精度失败。新`check_suffix_references.py`改`skip_ptoas=False`完整编译Oproj/Hcpost两个入口，各核对9/5参数schema，再`KernelArtifact.load()`，最后明确NPU未初始化。方向正确，当前真实结果待主线程收集；没有用静态review冒充该CPU编译已通过。

本轮只读复核SHA：probe `4c7dbefdfc86dd3e52e8d90c3a362b7a9c63d2e9783e03cb74c02da8111212c9`，run `867281d8a9a4456daaa3c32d85a0e2bcf81668da0afa7780c8c2f231533031a3`。AST、bash-n通过。readonly各SHA写result在本次所读版本尚未见，保留为文档建议，不影响当前内存readonly检查执行。
