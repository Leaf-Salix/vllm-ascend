#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
source /data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/tnd-bsh-ragged-full-20261018/env.sh
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
out=/data/pyptouser/yejia/rf18/hc-first-v1
test ! -e "$out"
export PYPTO_PROG_BUILD_DIR="$job/hc-build"
python "$job/preflight.py" > "$job/hc-preflight.log" 2>&1
python "$job/probe_hc.py" --out "$out" --fixture /data/pyptouser/yejia/rf18/s6-b4-v3/first-difference.pt > "$job/hc-run.log" 2>&1
