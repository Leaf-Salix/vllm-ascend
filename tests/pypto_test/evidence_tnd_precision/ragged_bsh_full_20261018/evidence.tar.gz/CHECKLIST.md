# 8K单层Native / BSH / TND FULL graph对拍（2026-10-18）

- [x] 阅读工作区、checkout规则与karpathy-guidelines、227环境skill。
- [x] 只读检查227；当前无本轮运行任务，沿用原私有SDK与静态包。
- [x] 固定BSH历史精度源码84dc9a3f（完整pypto子树及依赖），当前TND数学2fc05d81e。
- [x] CPU执行原eligible及dispatcher函数：全S6、全S1、全S3、混合1..6；区分不支持与回退，不改生产准入。
- [x] 无设备环境、source/helper SHA、PTOAS/CANN/ATB及13包身份检查。
- [x] 首项B4/S6、history8191、真实L4权重、合成hidden/history：Native/TND/BSH独立cache，torch.compile fullgraph +实际ACLGraph replay。
- [x] 校验输出、TopK、全部cache/state、写区/只读保护、实时输入ABA；第一处bit差异保存诊断并停止后续配置。
- [ ] 通过才提交短query与混合1..6：不逐请求补S6；记录真实T、图桶容量、实际准入与回退。
- [ ] 精度通过才计时；交错次序、重复分组raw replay，restore在计时外；不把回退作为BSH kernel性能。
- [x] 如BSH原路径不支持，不强行构造补位kernel并声称生产实现；理论B×6仅为对照行数。
- [x] 每项task-submit max780秒，约5分钟内观察；不创建sche，不跑整模型/128K，不改SDK。
- [x] 对首差定位或最终结果写项目中文文档，完整记录未测项目、源码身份与复现入口。

本实验不承诺三方bit一致后才能看到全部结果；发现任何首差即暂停矩阵，先记录和定位。

## 终态

- 三方全S6任务：Native/TND八边界bit一致；BSH输出relative L2=0.0027760288，首差停止。
- 短query/混合NPU矩阵及计时未执行；CPU原入口测试确认BSH回退，不代表新NPU矩阵通过。
- 只追加同输入HC前缀定位：post72/96、comb383/384、normed215/98304不一致；不是唯一根因证明。
- 四项任务实际报告131、136、208、64秒；前两项助手失败单独保留，全部终态无本轮残余任务。
- 独立脚本/结果文档审查通过；项目Markdown和JSON增量pre-commit通过。
- 正式数学、原BSH、SDK、原已验收黄金均未修改。
