"""用原始准入/dispatcher AST执行CPU结构探针；不模拟NPU算术。"""
import ast
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace as NS

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'bsh-source/vllm_ascend/ops'
service = SOURCE / 'pypto/deepseek_v4_flash_dspark/service.py'
dispatcher = SOURCE / 'dsv4_csa.py'
# dsv4_csa.py不在pypto子树归档中；使用另外导出的同commit原件。
if not dispatcher.exists():
    dispatcher = ROOT / 'bsh-dsv4_csa.py'
tree = ast.parse(service.read_text())
method = next(n for c in tree.body if isinstance(c, ast.ClassDef)
              for n in c.body if isinstance(n, ast.FunctionDef) and n.name == 'eligible')
scope = {'torch': NS(bfloat16='bf16', int64='i64'), 'QUERY_TOKENS': 6}
exec(compile(ast.fix_missing_locations(ast.Module(body=[method], type_ignores=[])), str(service), 'exec'), scope)
forward = next(n for n in ast.parse(dispatcher.read_text()).body
               if isinstance(n, ast.FunctionDef) and n.name == 'dsv4_csa_forward')
forward.body = [n for n in forward.body if not isinstance(n, (ast.ImportFrom, ast.Import))]
for arg in forward.args.args:
    arg.annotation = None
forward.returns = None
exec(compile(ast.fix_missing_locations(ast.Module(body=[forward], type_ignores=[])), str(dispatcher), 'exec'), scope)

class Tensor:
    def __init__(self, shape, dtype='bf16'):
        self.shape, self.dtype, self.ndim = shape, dtype, len(shape)
    def numel(self):
        return self.shape[0]
    def is_contiguous(self):
        return True

rows = []
for lengths in ([6]*4, [1]*4, [3]*4, [1,2,3,6], [1,2,3,4,5,6]):
    tokens, batch = sum(lengths), len(lengths)
    metadata = {}
    for name in ('swa', 'compressed', 'state', 'indexer', 'indexer_state'):
        req = NS(seq_lens=Tensor((batch,)), query_start_loc=Tensor((batch+1,)),
                 max_seqlen_q=max(lengths), num_reqs_actual=batch, ori_win_right=0,
                 ori_win_left=127, dspark_swa_indices=None,
                 cos={'compressed': Tensor((tokens,512))})
        metadata[name] = NS(num_prefills=0, num_actual_tokens=tokens, num_decodes=batch, decode=req)
    events = []
    class Runtime:
        batch_capacity = 40
        prefixes = {name:name for name in metadata}
        layer_name = 'compressed'
        def eligible(self, *args):
            return scope['eligible'](self, *args)
        def __call__(self, *args):
            events.append('BSH')
    runtime = Runtime()
    context = NS(attn_metadata=metadata, no_compile_layers={'layer':NS(_pto_csa_runtime=runtime)})
    scope.update(get_forward_context=lambda:context,
                 _native_attention_half=lambda *args:events.append('Native'),
                 _build_kv_cache=lambda *args:())
    hidden, positions = Tensor((tokens,4,4096)), Tensor((tokens,), 'i64')
    eligible = runtime.eligible(context, hidden, positions)
    scope['dsv4_csa_forward'](hidden, positions, None, 'layer')
    assert events == (['BSH'] if eligible else ['Native'])
    assert eligible == all(q == 6 for q in lengths)
    rows.append(dict(lengths=lengths, tokens=tokens, eligible=eligible,
                     dispatch=events[0], automatic_request_padding=False))
result = {'scope':'CPU结构测试，真实原函数AST；不是NPU执行证据',
          'source_commit':'84dc9a3f7ccab364843940be0ac43986df2950bc',
          'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (service,dispatcher)},
          'cases':rows}
(ROOT/'entry-result.json').write_text(json.dumps(result, indent=2, ensure_ascii=False)+'\n')
print(json.dumps(result, indent=2, ensure_ascii=False))
