"""只定位已失败S6的HC前缀；不继续query矩阵，不改原算子。"""
import argparse
import importlib
import json
from pathlib import Path
import sys
import types

import torch
import torch_npu
import pypto.torch
from safetensors import safe_open
from vllm_ascend.utils import enable_custom_op

root=Path(__file__).parent
historical=types.ModuleType('historical_pypto')
historical.__path__=[str(root/'bsh-source/vllm_ascend/ops/pypto')]
sys.modules['historical_pypto']=historical
from bsh_hc_prefix import bsh_hc_prefix

p=argparse.ArgumentParser()
p.add_argument('--out',type=Path,required=True)
p.add_argument('--fixture',type=Path,required=True)
a=p.parse_args()
assert not a.out.exists()
a.out.mkdir()
torch.npu.set_device(0)
torch.use_deterministic_algorithms(True)
torch_npu.npu.set_deterministic_level(1)
assert enable_custom_op()
data=torch.load(a.fixture,map_location='cpu',weights_only=False)
hidden=data['inputs']['native']['hidden'].to('npu')
assert all(torch.equal(row['hidden'].view(torch.uint8),data['inputs']['native']['hidden'].view(torch.uint8)) for row in data['inputs'].values())
n=hidden.shape[0]
model=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config=json.loads((model/'config.json').read_text())
index=json.loads((model/'quant_model_weights.safetensors.index.json').read_text())['weight_map']
weights={}
for name in ('hc_attn_fn','hc_attn_scale','hc_attn_base','attn_norm.weight'):
    key='layers.4.'+name
    with safe_open(model/index[key],framework='pt',device='cpu') as handle:
        value=handle.get_tensor(key)
    weights[name]=value.to(device='npu',dtype=torch.bfloat16 if name=='attn_norm.weight' else torch.float32)
with torch.inference_mode():
    mixed,post,comb=torch.ops._C_ascend.npu_hc_pre_v2(hidden,weights['hc_attn_fn'],weights['hc_attn_scale'],weights['hc_attn_base'],4,config['hc_sinkhorn_iters'],config['rms_norm_eps'],config['hc_eps'])
    normed=torch_npu.npu_rms_norm(mixed,weights['attn_norm.weight'],config['rms_norm_eps'])[0]
    gold={'post':post.cpu(),'comb':comb.cpu().reshape(n,16),'normed':normed.cpu()}
    pypto.torch.init()
    op=pypto.torch.register(bsh_hc_prefix,'ragged_bsh_hc_84dc::prefix')
    outputs={'normed':torch.empty((n,4096),dtype=torch.bfloat16,device='npu'),
             'post':torch.empty((n,4),dtype=torch.float32,device='npu'),
             'comb':torch.empty((n,16),dtype=torch.float32,device='npu')}
    inv=torch.empty(((n+15)//16*16,1),dtype=torch.float32,device='npu')
    def run():
        op(hidden,weights['hc_attn_fn'],weights['hc_attn_scale'],weights['hc_attn_base'],weights['attn_norm.weight'],outputs['normed'],outputs['post'],outputs['comb'],inv)
    run()
    graph=torch.npu.NPUGraph()
    with torch.npu.graph(graph):run()
    for out in outputs.values():out.fill_(float('nan'))
    graph.replay();torch.npu.synchronize()
    actual={key:value.cpu() for key,value in outputs.items()}
    metrics={}
    for name in ('post','comb','normed'):
        x,y=actual[name],gold[name]
        assert torch.isfinite(x).all() and x.shape==y.shape
        bad=x.contiguous().view(torch.uint8)!=y.contiguous().view(torch.uint8)
        metrics[name]={'bit_equal':bool(~bad.any()),'different_elements':int((x!=y).sum()),
                       'max_abs':float((x.float()-y.float()).abs().max()),'first_coordinates':(x!=y).nonzero()[:6].tolist()}
    report={'complete':True,'scope':'diagnostic only: exact extracted BSH root HC prefix, same saved L4/T24 input, actual Native HC op; manual ACLGraph replay; no query matrix or timing',
            'root_graph_case':'s6-b4-v3','tokens':n,'metrics':metrics,
            'earliest_observed_stage':'HC-pre gates' if not (metrics['post']['bit_equal'] and metrics['comb']['bit_equal']) else 'not localized to HC-pre gates',
            'does_not_establish_unique_cause_of_full_output_error':True}
    (a.out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
    torch.save({'actual':actual,'native':gold,'hidden':hidden.cpu(),'weights':{k:v.cpu() for k,v in weights.items()}},a.out/'stages.pt')
    print(json.dumps(report,indent=2),flush=True)
