"""原BSH根的HC前缀逐语句提取；只把四个缓冲改成显式Out。"""
import pypto.language as pl
from historical_pypto.deepseek_v4_flash_dspark.decode_csa import *
ROWS_DYN = pl.dynamic("BSH_DIAGNOSTIC_ROWS")

@pl.jit(auto_scope=False)
def bsh_hc_prefix(
    x_hc: pl.Tensor[[T_DYN, HC_MULT, D], pl.BF16],
    hc_attn_fn: pl.Tensor[[MIX_HC, HC_DIM], pl.FP32],
    hc_attn_scale: pl.Tensor[[3], pl.FP32],
    hc_attn_base: pl.Tensor[[MIX_HC], pl.FP32],
    attn_norm_w: pl.Tensor[[D], pl.BF16],
    x_normed_t: pl.Out[pl.Tensor[[T_DYN, D], pl.BF16]],
    post_t: pl.Out[pl.Tensor[[T_DYN, HC_MULT], pl.FP32]],
    comb_t: pl.Out[pl.Tensor[[T_DYN, HC_MULT * HC_MULT], pl.FP32]],
    inv_rms: pl.Out[pl.Tensor[[ROWS_DYN, 1], pl.FP32]],
):
    x_hc.bind_dynamic(0, T_DYN)
    x_normed_t.bind_dynamic(0, T_DYN)
    post_t.bind_dynamic(0, T_DYN)
    comb_t.bind_dynamic(0, T_DYN)
    inv_rms.bind_dynamic(0, ROWS_DYN)
    t_dim = pl.tensor.dim(x_hc, 0)
    x_hc32 = pl.create_tensor([t_dim, HC_MULT, D], dtype=pl.FP32)
    x_hc_flat = pl.reshape(x_hc, [t_dim, HC_MULT * D])
    x_hc32_flat = pl.reshape(x_hc32, [t_dim, HC_MULT * D])
    widen_rows = (t_dim + HC_WIDEN_T_TILE - 1) // HC_WIDEN_T_TILE
    hc_padded_rows = (t_dim + LINEAR_T_TILE - 1) // LINEAR_T_TILE * LINEAR_T_TILE
    widen_tail = pl.create_tensor([HC_WIDEN_T_TILE, HC_MULT * D], dtype=pl.FP32)
    with pl.spmd(pl.min(widen_rows, HC_WIDEN_WORKERS), name_hint='hc_widen_rms', allow_early_resolve=True) as _widen_tid:
        for widen_blk in pl.range(pl.tile.get_block_idx(), widen_rows, pl.min(widen_rows, HC_WIDEN_WORKERS)):
            w_t0 = widen_blk * HC_WIDEN_T_TILE
            w_rows = pl.min(HC_WIDEN_T_TILE, t_dim - w_t0)
            w_sq_sum = pl.full([1, HC_WIDEN_T_TILE], dtype=pl.FP32, value=0.0)
            for w_db in pl.pipeline(HC_MULT * D // HC_WIDEN_D_TILE, stage=4):
                w_d0 = w_db * HC_WIDEN_D_TILE
                w_src = pl.slice(x_hc_flat, [HC_WIDEN_T_TILE, HC_WIDEN_D_TILE], [w_t0, w_d0], valid_shape=[w_rows, HC_WIDEN_D_TILE])
                w_val = pl.cast(w_src, pl.FP32)
                if w_rows == HC_WIDEN_T_TILE:
                    x_hc32_flat[w_t0:w_t0 + HC_WIDEN_T_TILE, w_d0:w_d0 + HC_WIDEN_D_TILE] = w_val
                    w_sq = pl.mul(w_val, w_val)
                    w_sq_row = pl.reshape(pl.row_sum(w_sq), [1, HC_WIDEN_T_TILE])
                    w_sq_sum = pl.add(w_sq_sum, w_sq_row)
                else:
                    w_valid = pl.set_validshape(w_val, w_rows, HC_WIDEN_D_TILE)
                    w_clean = pl.fillpad(w_valid, pad_value=pl.PadValue.zero)
                    w_sq_tail = pl.mul(w_clean, w_clean)
                    w_sq_row_tail = pl.reshape(pl.row_sum(w_sq_tail), [1, HC_WIDEN_T_TILE])
                    w_sq_sum = pl.add(w_sq_sum, w_sq_row_tail)
                    widen_tail[0:HC_WIDEN_T_TILE, w_d0:w_d0 + HC_WIDEN_D_TILE] = w_val
                    w_out = pl.load(widen_tail, [0, w_d0], [HC_WIDEN_T_TILE, HC_WIDEN_D_TILE], valid_shape=[w_rows, HC_WIDEN_D_TILE], target_memory=pl.MemorySpace.Vec)
                    pl.store(w_out, [w_t0, w_d0], x_hc32_flat)
            w_mean = pl.add(pl.mul(w_sq_sum, HC_DIM_INV), NORM_EPS)
            w_inv = pl.reshape(pl.rsqrt(w_mean, high_precision=True), [HC_WIDEN_T_TILE, 1])
            inv_rms[w_t0:w_t0 + HC_WIDEN_T_TILE, 0:1] = w_inv
    with pl.scope():
        pre_val_store = pl.create_tensor([hc_padded_rows, HC_PAD], dtype=pl.FP32)
        hc_pre_gates_from_rms(x_hc32, hc_attn_fn, hc_attn_scale, hc_attn_base, pre_val_store, post_t, comb_t, False, inv_rms)
        hc_mix_norm(x_hc32, pre_val_store, attn_norm_w, x_normed_t)
    return x_normed_t, post_t, comb_t, inv_rms
