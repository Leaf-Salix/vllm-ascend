# T126 QA 四臂单因素独立审查

2026-10-20。只读审查 `qa_variants.py` 与 `qa_variants_probe.py`；不改正式 shift 门、不操作远端或提交设备。

## 因素隔离：独立 AST 检查通过

以当前正式 `q_proj_qa` 为基准，独立规范化四个函数，逐完整 AST 验证：

| 候选 | 实际差异 | 恢复声明差异后 |
|---|---|---|
| base | 仅函数重命名 | 与正式完整 AST 相同 |
| m64tail | full_rows 向上取64倍数；dense input改显式valid rows的slice | 与正式完整 AST 相同（恰2处） |
| kshift | 原两个K-order谓词仅额外允许实验T126 | 与正式完整 AST 相同（恰2处） |
| both | 上述两因素组合 | 与正式完整 AST 相同（2＋2处） |

没有改系数、K块大小、累加顺序内部公式、初始条件、N分组、FP32输出或 BF16物化。正式源仍保持原资格，实验分支不能作为未经验证的修复交付。

## Padding 与容量

本次固定 T126，ceil16 与 ceil64 均为128。m64tail 的第二块从64开始，62行有效、物理64行；明确 `valid_shape=[min(64,tile_rows-dense_t0),256]`，没有要求从原126行输入实际读取最后两行。

输出 `owner[16:144]` 有128行，前后各16行guard，覆盖两种物理输出范围；base尾M16与新尾M64都不会因预期物理尺寸超出该区域。实际 masked load 的 lowering 仍应由两ABI编译和生成物确认，不能以Python表达式替代设备边界检查。该容量判断仅适用于当前固定126行测试，不是可用于任意T的通用runner。

## 观察/金值与证伪

使用保存的真实 Native QA BF16、同次 Norm输入和 WQA 权重；base必须在86/103两行精确复现原FULL导出的PTO QA，这一门禁正确。四臂对完整126×1024 Native QA比较，不能仅看两处已知错误修好就决定资格。

该 base 门禁只证明两行复现；不应写成全部126行的原FULL QA已经逐字一致。四臂都是QA-only，不能用其中任一结果直接宣称 QRscale、完整CSA或整模型已修复。

已知差异通道484/331分别位于历史96列组5/3，都是历史 reverse 分组；这只是值得验证的线索，不能代替完整矩阵实测，也不能据此直接扩资格。

## 建议补齐的小门禁

1. 显式锁定实际输入/金值/权重 shape为 `(126,4096)`、`(126,1024)`、`(1024,4096)`，并检查dtype。避免未来替换输入文件却仍套用固定128行输出。
2. ND→NZ29转换前后保留语义值逐字节比较，记录实际格式；不能只根据 `BF16_WEIGHT_LAYOUT is not None` 和最终format号声称转换保真。
3. 四臂前后验证输入和权重未变，防止一个错误候选污染后续对照。已有output guards继续保留。
4. 结果记录 Native输入文件SHA以外，也绑定当前候选源、probe和实际正式qkv源SHA；完整编译/注册门禁最好保存收据，避免实测结果与后续改动混淆。

结论：源级单因素设计正确、当前T126容量成立；补齐输入/权重与身份门禁并实际编译后，可以用于这一个QA诊断，不是正式精度验收。

## Compact seed 修正复核

masked 62 行尾板的非 compact Acc 被 verifier 拒绝后，私有 m64tail/both 将首个 K 块剥离为 `pl.matmul`，后续从 pipeline k=1 累加。已独立检查当前实际函数 AST：

- seed 的所有 K 映射、reverse、shift、地址和 masked load 子树，恰好等于原循环体将 `dense_k` 替换为0的子树。
- seed 为 `pl.matmul(dense_x,dense_w,out_dtype=pl.FP32,b_trans=True)`；后续 pipeline 范围为1至15，均为 `init_cond=False`。
- T126 下所有11个N组的 K256 顺序覆盖0～15恰好一次；无首块遗漏、重复首块、重新初始化或额外FP32加法。

因此源级累加顺序和初始化数学保持。实现形态变化应用于 m64tail/both 的所有 dense 板，包含首个完整64行；base/kshift 仍用原 create Acc + 首次initTrue循环。若要严格把结果归因于M64尾，仍须核对实际生成物中 seed 与原首次initTrue的MMAD类型、初始化flag和后续顺序一致，不能仅凭函数名认为平台逐 bit 一定相同。

已再次检查助手，新增输入/金值/权重 shape及dtype、NZ29转换前后字节保真、每臂后输入/权重不变、候选/助手源码SHA均存在；原FULL两行QA复现门禁保留。未发现新的源级阻断。

独立读取同 Native QA→原 PTO normalize 的结果记录：126×1024 QR INT8和126个FP32 scale差异均为0。这支持下一步集中验证 QA；本次没有重新读取该任务全部原始tensor，不把记录复核写成重跑Native或正式完整CSA通过。
