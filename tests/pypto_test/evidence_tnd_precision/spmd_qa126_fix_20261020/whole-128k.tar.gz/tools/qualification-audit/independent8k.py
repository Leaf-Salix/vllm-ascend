"""Independent read-only CPU audit; run with server Python, without NPU imports."""
import hashlib
import json
import statistics
from pathlib import Path
from audit_identity import arguments, formal_identity

args=arguments("8k")
root=args.root
native = Path("/data/pyptouser/yejia/lc128/perf-single-dsl-8k-native-20261018")
previous = Path("/data/pyptouser/yejia/lc128/perf-hcpanel-8k-pto-20261018")
native128 = Path("/data/pyptouser/yejia/lc128/perf-single-dsl-128k-native-20261018-v2")
load = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
config = load(root / "configuration.json")
reference_config = load(native / "configuration.json")
assert config["case"] == "8k" and config["batch"] == 40 and config["repeats"] == args.expected_repeats
assert config["capture_sizes"] == [6, 240] and config["active_requests_for_timing"] == 40
assert config["decode_tokens"] == config["warmup_tokens"] == 192
assert config["single_pto_entry"] and config["handwritten_cpp"] is False
for field in ("bank_plan_sha256", "runtime_manifest_sha256", "bank", "blocks", "capture_sizes",
              "batch", "decode_tokens", "warmup_tokens", "static_metadata_sha256"):
    assert config[field] == reference_config[field], field
assert not list(root.glob("**/*STOP.json"))
assert sha(config["snapshot_manifest"]) == config["source_manifest_sha256"]
source_files = load(config["snapshot_manifest"])["files"]
for name, digest in source_files.items():
    assert sha(Path(config["snapshot"]) / name) == digest, name
identity=formal_identity(config,args)
job = Path(config["snapshot"]).parents[1]
assert sha(job / "helper-manifest.json") == config["helper_manifest_sha256"]
for name, digest in load(job / "helper-manifest.json")["files"].items():
    assert sha(job / name) == digest, name


def geometry(rows):
    # Keep input_ids_cpu when present; only process-local execution call numbers
    # may differ between historical repeated Native windows.
    return [{k: v for k, v in row.items() if k != "call"} for row in rows]


total_tokens = total_events = 0
candidate_reports, native_reports, previous_reports = [], [], []
for rank in range(16):
    data = load(root / f"rank{rank}.real_perf.json")
    control = load(native / f"rank{rank}.real_perf.json")
    old = load(previous / f"rank{rank}.real_perf.json")
    assert data["rank"] == rank and data["batch"] == 40 and data["backend"] == "pto"
    assert data["variant"] == "pkg:deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout" and len(data["rounds"]) == config["repeats"]
    assert data["repeats"] == config["repeats"]
    assert [r["iteration"] for r in data["rounds"]] == list(range(1, config["repeats"] + 1))
    assert len(data["implementations"]) == len(data["worker_runtime_config"]) == 1
    runtime = data["worker_runtime_config"][0]
    assert runtime["deterministic_level"] == 1 and runtime["torch_deterministic"]
    assert runtime["hccl_deterministic"] == "true" and not runtime["dynamic_eplb"]
    assert runtime["cann_event_work_mode"] == 1
    implementations = data["implementations"][0]
    csa = [v for v in implementations if v["kind"] == "csa"]
    hca = [v for v in implementations if v["kind"] == "hca"]
    assert len(csa) == 21 and all(v["implementation"] == "pto" for v in csa)
    assert len(hca) == 20 and all(v["implementation"] == "native" for v in hca)
    gold_root = Path(config["gold"])
    gold = {r["key"]: r["output_token_ids"] for r in load(gold_root / f"rank{rank}.mixed.json")["requests"]}
    event_gold = {r["key"]: r["events"] for r in (
        json.loads(line) for line in (gold_root / f"request_stats_rank{rank}.jsonl").read_text().splitlines())}
    assert len(gold) == len(event_gold) == 40
    for request_list in [data["warmup"]["requests"]] + [r["requests"] for r in data["rounds"]]:
        assert len(request_list) == 40 and {r["key"] for r in request_list} == set(gold)
        for request in request_list:
            assert request["preemptions"] == 0
            assert len(request["output_token_ids"]) == 192
            assert request["output_token_ids"] == gold[request["key"]]
            assert request["events"] == event_gold[request["key"]]
            total_tokens += len(request["output_token_ids"])
            total_events += len(request["events"])
    for candidate_round in data["rounds"]:
        timing = candidate_round["timing"][0]
        assert timing["sufficient"] and timing["measured_steps"] == 20
        assert len(timing["metadata"]) == len(timing["forward"]["samples_us"]) == 20
        assert len(timing["cycle"]["samples_us"]) == 19
        qualification = timing["identity"]["static_full_qualification"]
        assert qualification["ready"] and qualification["actual_reselections"] == 1
        assert qualification["validated_reuses"] > 0
        assert qualification["metadata_sha256"] == config["static_metadata_sha256"]
        assert qualification["root_abi_tensors"] == 64
        assert qualification["root_namespace"] == "dsv4_csa_tnd_precision_spmd_bf16layout::attention"
        expected_layers = {f"model.layers.{i}.self_attn.attn" for i in range(2, 43, 2)}
        assert set(qualification["single_root_counts"]) == expected_layers
        for counts in qualification["single_root_counts"].values():
            for bucket in (6, 240):
                assert counts[str(bucket)]["warmup"] > 0 and counts[str(bucket)]["capture"] > 0
        assert set(timing["identity"]["capture_time_selection"]) == expected_layers
        for counts in timing["identity"]["capture_time_selection"].values():
            assert all(counts.get(f"pto_tokens{n}", 0) > 0 for n in (6, 40, 240))
        for metadata in timing["metadata"]:
            assert metadata["requests"] == 40 and metadata["actual_tokens"] == metadata["padded_tokens"] == 240
            assert metadata["graph_mode"] == "FULL" and metadata["dp_tokens"] == [240] * 16
        for native_round in control["rounds"]:
            assert geometry(timing["metadata"]) == geometry(native_round["timing"][0]["metadata"])
            assert {r["key"]: r["output_token_ids"] for r in native_round["requests"]} == gold
            assert {r["key"]: r["events"] for r in native_round["requests"]} == event_gold
        assert geometry(timing["metadata"]) == geometry(old["rounds"][0]["timing"][0]["metadata"])
        before = candidate_round["identity_before"][0]["cache_stats"]
        after = timing["identity"]["cache_stats"]
        for field in ("generation_builds", "binary_builds", "bypasses", "invalid_entries", "storage_errors", "forced_rebuilds"):
            assert before[field] == after[field], field
    candidate_reports.append(data)
    native_reports.append(control)
    previous_reports.append(old)


def max_rank_mean(reports,kind="forward"):
    values = []
    for round_id in range(len(reports[0]["rounds"])):
        samples = [r["rounds"][round_id]["timing"][0][kind]["samples_us"] for r in reports]
        width=len(samples[0])
        assert width==(20 if kind=="forward" else 19) and all(len(v)==width for v in samples)
        values.extend(max(rank_values[i] for rank_values in samples) for i in range(width))
    return statistics.mean(values)


candidate_us = max_rank_mean(candidate_reports)
native_us = max_rank_mean(native_reports)
previous_us = max_rank_mean(previous_reports)
result = {"pass": True, **identity, "root": str(root), "tokens_equal_native": total_tokens,
          "accept_events_equal_native": total_events, "zero_preemptions": True,
          "real_ranks": 16, "CSA_layers_per_worker": 21, "HCA_native_layers_per_worker": 20,
          "single_root_tensors": 64, "buckets": [6, 240],
          "all16_all3_native_rounds_metadata_equal": True,
          "geometry_fields_include": ["keys", "query_bounds", "positions_cpu", "input_ids_cpu", "dp_tokens"],
          "source_files_rehashed": len(source_files),
          "target_forward_ms": candidate_us / 1000,
          "target_cycle_ms":max_rank_mean(candidate_reports,"cycle")/1000,
          "Native_historical_cycle_ms":max_rank_mean(native_reports,"cycle")/1000,
          "Native_historical_forward_ms": native_us / 1000,
          "panel8_15a9_historical_forward_ms": previous_us / 1000,
          "reduction_vs_15a9_percent": (1 - candidate_us / previous_us) * 100,
          "candidate_over_native": candidate_us / native_us,
          "Native_8k_perf_root": str(native), "Native_128k_perf_root": str(native128),
          "Native_128k_exists": (native128 / "rank15.real_perf.json").exists(),
          "measured_repeats":config["repeats"],
          "scope": "Complete saved tokens/events and measured CPU workload geometry; not all internal tensor hooks; historical timings, no new Native2."}
print(json.dumps(result, indent=2))
