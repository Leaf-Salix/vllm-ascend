# BF16 / QA126 整模型独立快照生成器审查

2026-10-20，只读 `prepare_whole_bf16qa126.py`；没有执行生成器、访问设备或提交任务。

## 通过的静态检查

- 新 `whole-bf16qa126-v1` 拒绝覆写原目录，先校验正式program/kernel/Torch64及prepare/operators编译门禁，再校验当前八源与收据。
- 父 `whole-spmd-prepack-v3` 的3385文件逐SHA校验后原样复制，另加八源，最终3393。原43、SPMD14、预打包6源还分别对当前收据校验，防止基准被替换。
- 五包运行源枚举加公共variant/dsv4_csa两个源；独立在本机按转换后的枚举重算，实际为71个Python源，符合旧63＋新8。
- 原helper逐SHA校验后复制，原helper manifest另名保存；新helper manifest重算，包含父manifest见证，不覆写父身份。
- variant、namespace、SOURCE_ROOT与job目录更新为独立候选。旧Native golden、bank、capture sizes、GBS/入场口径、decode192、warm192、三轮测量、静态资格、零抢占和固定Native phase规则没有修改。
- 独立检查继承的run-case：8K提交40/活跃40/bucket240；128K提交24/活跃21/bucket144；原两档gold/bank路径、DP16、event mode1和内部750秒均保持。
- identity auditor保留原预打包/精度权重资格源码门禁，并增加新service空子类约束，没有以只验证一个pass字段代替完整后续tokens/events/metadata检查。
- `FINAL_SOURCE_BOUND` 明确 `NPU_executed=false`、whole-model pending，只是源绑定，不是假称新整模型通过。

## 建议补齐的前置门禁

目前两个单层 gate 仅根据目录名及 `complete/pass/candidate_sources` 判断。应再分别assert真实 `true_tokens==126/240`、`physical_graph_tokens`对应，以及 `per_request_padding==0`；否则CLI意外跑错参数仍可能被目录名掩盖。源码收据/助手SHA与实际结果的绑定仍应保留。

完成这个小加固后，静态方案可用于独立快照准备。生成出的实际helper/source manifest还需运行原无设备preflight与身份审计；然后按8K通过后128K的顺序验收。本文没有运行脚本，不授予实际快照生成、无hook单层或整模型通过结论。

## 2026-10-20 复核：前置门禁与复现CLI已补齐

现有生成器默认新目录为 `whole-bf16qa126-v2`。上面的建议已经落实：分别锁定126/240真实行与物理行、零逐请求padding、实际lengths、layer=4、history=8191，并继续校验complete/pass及八源收据。

- `--job-name` 仅允许 `whole-bf16qa126-` 后接非空ASCII小写字母、数字或连字符；两个case参数同样禁止斜杠、点和其他字符，不能逃逸 `EXP/results`。
- `assert not JOB.exists()` 在任何目录创建或复制之前；默认指向已有冻结目录时会拒绝覆写，复现应显式提供新名字。
- `gates` 由实际CLI的两个case构成；前置读取和 `single_layer_gate_result_sha256` 都遍历同一 `gates`，不存在校验新case却绑定旧默认result SHA的问题。
- 未运行生成器，没有更改当前冻结job。以上是静态复核通过，不替代生成后实际helper/source身份预检或NPU结果。
