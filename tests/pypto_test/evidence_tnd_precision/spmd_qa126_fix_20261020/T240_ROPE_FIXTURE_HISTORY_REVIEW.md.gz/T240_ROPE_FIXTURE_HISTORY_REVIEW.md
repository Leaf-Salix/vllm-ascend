# T240 跨 bucket RoPE fixture 修正独立审查

2026-10-20，只读现有同源 `bf16layout-full-tools/ragged_fixture.py` 与共享RoPE生命周期代码。当前本地尚未见拟新增的 `bf16qa126-full-tools-v2`，本结论为方案/原逻辑审查，不冒称已经核对v2实际字节。没有修改源码或提交设备。

## 为什么本次断言会失败

`make_ragged_fixture` 明确按每个请求构造 `history+j` 的positions；其readonly CPU快照在创建时保存，RoPE由同一个Native builder暴露可复用设备暂存view。

T240为40个S6请求，第一请求的前六行positions为 `history..history+5`。旧f6也是一个S6请求、同一history，因此写入相同共享RoPE storage前缀时，**值没有改变是合理结果**。`changed=set()` 不证明没有storage共享，也不证明候选数学错误；它说明测试“必须发生不同内容覆盖”的前提并未建立。

原T21混合1～6长度的前六行positions不同，历史测试中该前提偶然成立，不能推广到均匀S6。

## history+1 的方案是否合理

仅将第二f6的history改为 `args.history+1` 会构造与原bucket真正不同的六行位置。本例原第一六行为8191..8196，新f6为8192..8197；两份fixture的独立CPU readonly快照仍保留各自应有值。

保留以下全部门禁使其成为更有效的测试，而非放宽测试：

- `changed == {'rope.cos','rope.sin'}` 仍严格成立要求。
- 两RoPE view底层storage确实相同，不能以重新分配绕过覆盖。
- 新f6在已经静态资格成立后重新捕获实际Native FULL图，得到这份新历史的gold；不复用旧history的Native6结果。
- 跨流warmup/第二FULL捕获及交替replay全部不变。
- 每次replay前恢复当前fixture的所有readonly快照并检查guards，再逐byte比较对应Native gold。

第二fixture可能具有不同compact metadata/slot写入语义，这是预期的额外覆盖，必须由其自己的Native金值处理。原第一T240的Native A/B/gold完全不应重新生成或修改。

## 验收身份和状态

旧任务的Native/candidate A/B/ABA八边界通过，仅证明第一bucket部分；它在后续fixture断言失败，整体任务必须保留失败，不能标成完整生命周期通过。

复制新v2助手、只改第二fixture history及必要标签/路径、重算helper manifest，并使用新输出目录重跑，身份方案正确。应在报告明确这是测试fixture修正，不是PTO数学修复。仍须实际v2结果通过全部跨stream/交替replay，才可作为T240完整gate。

## 实际v2追加核查

随后实际目录 `bf16qa126-full-tools-v2` 已到本地，已核对全部5个manifest载荷SHA。与本地同源原helper的probe差分仅为：第二fixture history改+1、说明注释，以及在结果里记录second_history；strict changed集合、same_storage、readonly恢复、Native6 gold、跨流及交替replay比较均未改。runner实际指向v2 probe，仍拒绝覆写且内部timeout750秒。

另实际读取 `qa126-collected-results/formal-t240-fixture-stop-v1.json`：complete/pass均false，原8项A、8项B及两arm ABA确实逐bit通过，终止原因为 `unexpected readonly change, set()`。历史状态保留准确。

因此实际v2源码/身份复核无阻断；尚未在本审查中取得v2设备结果，不称整体gate已通过。
