"""No-device compilation of the separate precision-SPMD slice."""

import hashlib
import json
import os
import sys
from pathlib import Path

import pypto
import simpler
from pypto.runtime import RunConfig

import vllm_ascend.ops.pypto as namespace

experiment = Path(os.environ["SPMD_EXPERIMENT"])
source = experiment / "src/vllm_ascend/ops/pypto"
namespace.__path__.insert(0, str(source))

sys.path.insert(0, str(experiment))
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.decode_csa import decode_csa_tp1_layer_test as precision_hc_prefix

assert "low-acceptance-20261010/runtime-package/pypto" in pypto.__file__
assert "pypto-reference/runtime/python/simpler" in simpler.__file__
assert os.environ["ASCEND_RT_VISIBLE_DEVICES"] == ""
assert os.environ.get("PTOAS_ROOT") and os.environ.get("ASCEND_HOME_PATH")
package = source / "deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout"
record = {
    "scope": "Complete CSA draft with one-SPMD prefix; no hardware or real-model qualification",
    "hardware_executed": False,
    "parent_commit": "e9784b9e5c4e4de8daf9917d88c8571a0eabc626",
    "pypto": pypto.__file__,
    "simpler": simpler.__file__,
    "sources": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in package.glob("*.py")},
}
print(json.dumps(record), flush=True)
compiled = precision_hc_prefix.compile(
    config=RunConfig(platform="a2a3", dump_passes=True, save_kernels=True, save_kernels_dir=str(experiment / "full-csa-bf16layout-qa126-artifact"))
)
# Exercise the exact kernel-mode ABI gate used by torch.register as well.
# This is a diagnostic call into the installed SDK, not a framework change.
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program

program = precision_hc_prefix.specialize()
abi = kernel_abi_for_program(program, platform="a2a3", runtime="tensormap_and_ringbuffer")
_kernel = _compile_impl(program, output_dir=str(experiment / "full-csa-bf16layout-qa126-kernel-artifact"),
                        platform="a2a3", dump_passes=True, _kernel_abi=abi)
from pypto.runtime.kernel_compiler import KernelCompiler
KernelCompiler().compile_orchestration('tensormap_and_ringbuffer',str(experiment/'full-csa-bf16layout-qa126-artifact/orchestration/_full_csa_tnd_prepacked.cpp'))
record["kernel_mode_abi_pass"] = True
record["kernel_artifact_dir"] = str(experiment / "full-csa-bf16layout-qa126-kernel-artifact")
baseline=json.loads((experiment/'BASELINE.json').read_text())['baseline_runtime_sources']
assert all(hashlib.sha256((Path(os.environ['SOURCE_ROOT'])/n).read_bytes()).hexdigest()==h for n,h in baseline.items())
record['baseline_sources']=baseline
parent=json.loads((experiment/'compile-full-csa-packaged.json').read_text())['sources']
parent_package=source/'deepseek_v4_flash_csa_tnd_precision_spmd'
assert len(parent)==14 and all(hashlib.sha256((parent_package/n).read_bytes()).hexdigest()==h for n,h in parent.items())
record['parent_spmd_sources']=parent
assert len(record['sources'])==8
import pypto.torch
registered=pypto.torch.register(precision_hc_prefix, "dsv4_csa_tnd_prepack_abi_gate::attention")
assert len(registered._schema.arguments)==64
assert registered._schema.arguments[1].name=='hc_packed_weight'
record['torch_dispatcher_registration_pass']=True
record['torch_schema']=str(registered._schema)
record.update(
    compiled=True,
    output_dir=str(compiled.output_dir),
    runtime=compiled.runtime_name,
    generated={
        str(p.relative_to(compiled.output_dir)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in Path(compiled.output_dir).rglob("*")
        if p.is_file() and p.suffix in (".cpp", ".py", ".json")
    },
)
(experiment / "compile-full-csa-bf16layout.json").write_text(json.dumps(record, indent=2) + "\n")
print("PRECISION_SPMD_PREFIX_COMPILED", record["output_dir"], flush=True)

prepack=source/'deepseek_v4_flash_csa_tnd_precision_spmd_prepack'
record['parent_prepack_sources']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in prepack.glob('*.py')}
assert len(record['parent_prepack_sources'])==6
(experiment/'compile-full-csa-bf16layout.json').write_text(json.dumps(record,indent=2)+'\n')
