#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/vector-mte2-20261019-codex/full-csa-live-staging-v2/env.sh"
export SPMD_EXPERIMENT="$base/precision-spmd-20261019" ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE" PYTHONNOUSERSITE=1
export PYPTO_PROG_BUILD_DIR="$SPMD_EXPERIMENT/device-build" PYPTO_CACHE_DIR="$SPMD_EXPERIMENT/device-cache"
export CCACHE_DIR=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/pypto/.ccache CMAKE_BUILD_PARALLEL_LEVEL=4
timeout 750 python "$SPMD_EXPERIMENT/t126-fix-20261020/qr_normalize_isolation.py" > "$SPMD_EXPERIMENT/results/t126-qr-normalize-isolation-v2-run.log" 2>&1
