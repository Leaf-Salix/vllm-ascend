"""Finite cancellation queries of Native's actual T126 QA matmul order."""
import hashlib,json,os
from pathlib import Path
import torch,torch_npu
from torch.nn import functional as F
exp=Path(os.environ['SPMD_EXPERIMENT']);here=exp/'t126-fix-20261020'
assert os.environ['TASK_DEVICE'];torch.npu.set_device(0);torch.npu.config.allow_internal_format=True
torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4);torch.npu.set_compile_mode(jit_compile=False)
source=exp/'results/t126-qa-stage-v5/query-calibration.pt';d=torch.load(source,map_location='cpu',weights_only=False)
out=exp/'results/t126-native-qa-order-v1';out.mkdir(exist_ok=False)
record={'complete':False,'rows':126,'scope':'Native QA finite order queries, not end-to-end acceptance','fixture_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
def save():(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
def host(t):return torch_npu.npu_format_cast(t,2).cpu().contiguous()
try:
    real_x=d['normed'].npu();real_w=torch_npu.npu_format_cast(d['wq_a'].npu(),29)
    with torch.inference_mode():real=host(F.linear(real_x,real_w));repeat=host(F.linear(real_x,real_w))
    record['actual_fixture_native_different']=int((real!=d['native_qa']).sum());record['actual_fixture_repeat_exact']=torch.equal(real.view(torch.uint8),repeat.view(torch.uint8));save()
    assert record['actual_fixture_repeat_exact'] and record['actual_fixture_native_different']==0,'Native component did not reproduce actual FULL QA golden'
    orders=[]
    for width in (1,2,4,8,16):
        for direction in (1,-1):
            for start in range(16//width):
                order=tuple(((start+direction*i)%(16//width))*width+j for i in range(16//width) for j in range(width))
                if order not in orders:orders.append(order)
    triples=[(0,5,11),(6,7,8),(2,9,12),(4,6,14),(1,13,15),(3,10,11)]
    last={q:torch.tensor([max(q,key=o.index) for o in orders]) for q in triples}
    assert len(set(tuple(last[q][i].item() for q in triples) for i in range(len(orders))))==len(orders)
    candidates=torch.ones((126,64,len(orders)),dtype=torch.bool)
    x=torch.ones((126,4096),dtype=torch.bfloat16,device='npu')
    record['queries']=[]
    with torch.inference_mode():
        for q in triples:
            flags=[]
            for small in q:
                rest=[k for k in q if k!=small]
                w=torch.zeros((1024,4096),dtype=torch.bfloat16)
                w[:,rest[0]*256]=1.;w[:,rest[1]*256]=-1.;w[:,small*256]=2**-25
                weight=torch_npu.npu_format_cast(w.npu(),29)
                actual=host(F.linear(x,weight));again=host(F.linear(x,weight))
                assert torch.equal(actual.view(torch.uint8),again.view(torch.uint8)),'finite probe repeat differs'
                assert bool(((actual==0)|(actual==2**-25)).all()),'not finite serial cancellation result'
                assert torch.equal(actual,actual[:,::16].repeat_interleave(16,1)),'order differs within N16'
                flags.append(actual[:,::16]==2**-25)
            bits=torch.stack(flags)
            assert bool((bits.sum(0)==1).all()),'not exactly one last K256 block'
            observed=torch.tensor(q)[bits.long().argmax(0)]
            candidates &= last[q][None,None,:]==observed[:,:,None]
            count=candidates.sum(2);record['queries'].append({'triple':q,'min_candidates':int(count.min()),'max_candidates':int(count.max())});save()
            assert bool((count>0).all()),'K256 cyclic/block-order family rejected'
    assert bool((candidates.sum(2)==1).all()),'ambiguous order'
    selected=candidates.long().argmax(2)
    torch.save({'orders':orders,'selected':selected},out/'orders.pt')
    record.update(complete=True,orders=orders,row_invariant=torch.equal(selected,selected[:1].expand_as(selected)),selected_unique=selected.unique().tolist(),selected_by_row=selected.tolist())
    save();print('NATIVE_QA_ORDER_RESULT',{'row_invariant':record['row_invariant'],'selected_unique':record['selected_unique'],'row0':record['selected_by_row'][0]},flush=True)
except Exception as exc:
    record['error']=repr(exc);save();raise
