from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.qkv_proj_rope import *

@pl.jit.inline(auto_scope=False)
def qa_base(x: pl.Tensor[[T_DYN, D], pl.BF16], wq_a: pl.Tensor[[Q_LORA, D], pl.BF16, BF16_WEIGHT_LAYOUT], qr_fp32: pl.Out[pl.Tensor[[QPROJ_MM_T_DYN, Q_LORA], pl.FP32]], tile_base: pl.Scalar[pl.INDEX], tile_rows: pl.Scalar[pl.INDEX]):
    """Reference QA matmul, shared by the production QR and its diagnostic."""
    qa_tokens = pl.tensor.dim(x, 0)
    x_view = pl.reshape(x, [qa_tokens, D])
    qr_t_matmul = (tile_rows + QR_M_TILE - 1) // QR_M_TILE * QR_M_TILE
    qr_full_rows = tile_rows // QR_DENSE_M_TILE * QR_DENSE_M_TILE
    with pl.at(level=pl.Level.CORE_GROUP, name_hint='qr_proj_seed'):
        for ts0 in pl.range(0, qr_t_matmul, QR_M_TILE):
            for nseed0 in pl.range(0, Q_LORA, QR_N_TILE):
                qr_seed = pl.full([QR_M_TILE, QR_N_TILE], dtype=pl.FP32, value=0.0)
                qr_fp32[ts0:ts0 + QR_M_TILE, nseed0:nseed0 + QR_N_TILE] = qr_seed
    for qbg_idx in pl.spmd(Q_LORA // QR_N_TILE * QR_OK, name_hint='qr_proj_matmul', allow_early_resolve=True):
        q_a_col0 = qbg_idx // QR_OK * QR_N_TILE
        qr_k_base = qbg_idx % QR_OK * QR_SPLIT_K_TILE
        qr_native_group = q_a_col0 // QR_NATIVE_N_GROUP
        for dense_t0 in pl.range(0, qr_full_rows, QR_DENSE_M_TILE):
            dense_x0 = tile_base + dense_t0
            dense_acc = pl.create_tensor([QR_DENSE_M_TILE, QR_N_TILE], dtype=pl.FP32)
            for dense_k in pl.pipeline(0, QR_SPLIT_K_TILE // QR_K_TILE, stage=2):
                dense_k_order = dense_k
                if tile_rows >= QR_NATIVE_SHIFT_MIN_ROWS and tile_rows <= QR_NATIVE_SHIFT_MAX_ROWS and (tile_rows % QR_NATIVE_SHIFT_ROW_STEP == 0) and (qr_native_group < QR_NATIVE_SHIFT_GROUPS):
                    dense_k_direction = dense_k
                    if qr_native_group % 2 == 1:
                        dense_k_direction = QR_NATIVE_K_BLOCKS - 1 - dense_k
                    dense_k_order = (qr_native_group // 2 * QR_NATIVE_PAIR_SHIFT + dense_k_direction) % QR_NATIVE_K_BLOCKS
                dense_d0 = qr_k_base + pl.max(dense_k_order, 0) * QR_K_TILE
                dense_x = x_view[dense_x0:dense_x0 + QR_DENSE_M_TILE, dense_d0:dense_d0 + QR_K_TILE]
                dense_w = wq_a[q_a_col0:q_a_col0 + QR_N_TILE, dense_d0:dense_d0 + QR_K_TILE]
                dense_acc = pl.matmul_acc(dense_acc, dense_x, dense_w, b_trans=True, init_cond=dense_k == 0)
            qr_fp32 = pl.assemble(qr_fp32, dense_acc, [dense_t0, q_a_col0], atomic=STORE_ATOMIC)
        for t0 in pl.range(qr_full_rows, qr_t_matmul, QR_M_TILE):
            q_acc = pl.create_tensor([QR_M_TILE, QR_N_TILE], dtype=pl.FP32)
            for db in pl.pipeline(QR_SPLIT_K_TILE // QR_K_TILE, stage=2):
                qr_k_order = db
                if tile_rows >= QR_NATIVE_SHIFT_MIN_ROWS and tile_rows <= QR_NATIVE_SHIFT_MAX_ROWS and (tile_rows % QR_NATIVE_SHIFT_ROW_STEP == 0) and (qr_native_group < QR_NATIVE_SHIFT_GROUPS):
                    qr_k_direction = db
                    if qr_native_group % 2 == 1:
                        qr_k_direction = QR_NATIVE_K_BLOCKS - 1 - db
                    qr_k_order = (qr_native_group // 2 * QR_NATIVE_PAIR_SHIFT + qr_k_direction) % QR_NATIVE_K_BLOCKS
                qr_d0 = qr_k_base + pl.max(qr_k_order, 0) * QR_K_TILE
                qr_rows = pl.min(QR_M_TILE, tile_rows - t0)
                x_t0 = tile_base + t0
                q_x_chunk_bf16 = pl.slice(x_view, [QR_M_TILE, QR_K_TILE], [x_t0, qr_d0], valid_shape=[qr_rows, QR_K_TILE])
                w_chunk = wq_a[q_a_col0:q_a_col0 + QR_N_TILE, qr_d0:qr_d0 + QR_K_TILE]
                q_acc = pl.matmul_acc(q_acc, q_x_chunk_bf16, w_chunk, b_trans=True, init_cond=db == 0)
            qr_fp32 = pl.assemble(qr_fp32, q_acc, [t0, q_a_col0], atomic=STORE_ATOMIC)

@pl.jit
def qa_base_test(x: pl.Tensor[[T_DYN, D], pl.BF16], w: pl.Tensor[[Q_LORA, D], pl.BF16, BF16_WEIGHT_LAYOUT], output: pl.InOut[pl.Tensor[[QPROJ_MM_T_DYN, Q_LORA], pl.FP32]]):
    x.bind_dynamic(0, T_DYN)
    output.bind_dynamic(0, QPROJ_MM_T_DYN)
    rows = pl.tensor.dim(x, 0)
    qa_base(x, w, output, 0, rows)
    return output

@pl.jit.inline(auto_scope=False)
def qa_m64tail(x: pl.Tensor[[T_DYN, D], pl.BF16], wq_a: pl.Tensor[[Q_LORA, D], pl.BF16, BF16_WEIGHT_LAYOUT], qr_fp32: pl.Out[pl.Tensor[[QPROJ_MM_T_DYN, Q_LORA], pl.FP32]], tile_base: pl.Scalar[pl.INDEX], tile_rows: pl.Scalar[pl.INDEX]):
    """Reference QA matmul, shared by the production QR and its diagnostic."""
    qa_tokens = pl.tensor.dim(x, 0)
    x_view = pl.reshape(x, [qa_tokens, D])
    qr_t_matmul = (tile_rows + QR_M_TILE - 1) // QR_M_TILE * QR_M_TILE
    qr_full_rows = (tile_rows + QR_DENSE_M_TILE - 1) // QR_DENSE_M_TILE * QR_DENSE_M_TILE
    with pl.at(level=pl.Level.CORE_GROUP, name_hint='qr_proj_seed'):
        for ts0 in pl.range(0, qr_t_matmul, QR_M_TILE):
            for nseed0 in pl.range(0, Q_LORA, QR_N_TILE):
                qr_seed = pl.full([QR_M_TILE, QR_N_TILE], dtype=pl.FP32, value=0.0)
                qr_fp32[ts0:ts0 + QR_M_TILE, nseed0:nseed0 + QR_N_TILE] = qr_seed
    for qbg_idx in pl.spmd(Q_LORA // QR_N_TILE * QR_OK, name_hint='qr_proj_matmul', allow_early_resolve=True):
        q_a_col0 = qbg_idx // QR_OK * QR_N_TILE
        qr_k_base = qbg_idx % QR_OK * QR_SPLIT_K_TILE
        qr_native_group = q_a_col0 // QR_NATIVE_N_GROUP
        for dense_t0 in pl.range(0, qr_full_rows, QR_DENSE_M_TILE):
            dense_x0 = tile_base + dense_t0
            dense_k_order = 0
            if tile_rows >= QR_NATIVE_SHIFT_MIN_ROWS and tile_rows <= QR_NATIVE_SHIFT_MAX_ROWS and (tile_rows % QR_NATIVE_SHIFT_ROW_STEP == 0) and (qr_native_group < QR_NATIVE_SHIFT_GROUPS):
                dense_k_direction = 0
                if qr_native_group % 2 == 1:
                    dense_k_direction = QR_NATIVE_K_BLOCKS - 1 - 0
                dense_k_order = (qr_native_group // 2 * QR_NATIVE_PAIR_SHIFT + dense_k_direction) % QR_NATIVE_K_BLOCKS
            dense_d0 = qr_k_base + pl.max(dense_k_order, 0) * QR_K_TILE
            dense_x = pl.slice(x_view, [QR_DENSE_M_TILE, QR_K_TILE], [dense_x0, dense_d0], valid_shape=[pl.min(QR_DENSE_M_TILE, tile_rows - dense_t0), QR_K_TILE])
            dense_w = wq_a[q_a_col0:q_a_col0 + QR_N_TILE, dense_d0:dense_d0 + QR_K_TILE]
            dense_acc = pl.matmul(dense_x, dense_w, out_dtype=pl.FP32, b_trans=True)
            for dense_k in pl.pipeline(1, QR_SPLIT_K_TILE // QR_K_TILE, stage=2):
                dense_k_order = dense_k
                if tile_rows >= QR_NATIVE_SHIFT_MIN_ROWS and tile_rows <= QR_NATIVE_SHIFT_MAX_ROWS and (tile_rows % QR_NATIVE_SHIFT_ROW_STEP == 0) and (qr_native_group < QR_NATIVE_SHIFT_GROUPS):
                    dense_k_direction = dense_k
                    if qr_native_group % 2 == 1:
                        dense_k_direction = QR_NATIVE_K_BLOCKS - 1 - dense_k
                    dense_k_order = (qr_native_group // 2 * QR_NATIVE_PAIR_SHIFT + dense_k_direction) % QR_NATIVE_K_BLOCKS
                dense_d0 = qr_k_base + pl.max(dense_k_order, 0) * QR_K_TILE
                dense_x = pl.slice(x_view, [QR_DENSE_M_TILE, QR_K_TILE], [dense_x0, dense_d0], valid_shape=[pl.min(QR_DENSE_M_TILE, tile_rows - dense_t0), QR_K_TILE])
                dense_w = wq_a[q_a_col0:q_a_col0 + QR_N_TILE, dense_d0:dense_d0 + QR_K_TILE]
                dense_acc = pl.matmul_acc(dense_acc, dense_x, dense_w, b_trans=True, init_cond=False)
            qr_fp32 = pl.assemble(qr_fp32, dense_acc, [dense_t0, q_a_col0], atomic=STORE_ATOMIC)
        for t0 in pl.range(qr_full_rows, qr_t_matmul, QR_M_TILE):
            q_acc = pl.create_tensor([QR_M_TILE, QR_N_TILE], dtype=pl.FP32)
            for db in pl.pipeline(QR_SPLIT_K_TILE // QR_K_TILE, stage=2):
                qr_k_order = db
                if tile_rows >= QR_NATIVE_SHIFT_MIN_ROWS and tile_rows <= QR_NATIVE_SHIFT_MAX_ROWS and (tile_rows % QR_NATIVE_SHIFT_ROW_STEP == 0) and (qr_native_group < QR_NATIVE_SHIFT_GROUPS):
                    qr_k_direction = db
                    if qr_native_group % 2 == 1:
                        qr_k_direction = QR_NATIVE_K_BLOCKS - 1 - db
                    qr_k_order = (qr_native_group // 2 * QR_NATIVE_PAIR_SHIFT + qr_k_direction) % QR_NATIVE_K_BLOCKS
                qr_d0 = qr_k_base + pl.max(qr_k_order, 0) * QR_K_TILE
                qr_rows = pl.min(QR_M_TILE, tile_rows - t0)
                x_t0 = tile_base + t0
                q_x_chunk_bf16 = pl.slice(x_view, [QR_M_TILE, QR_K_TILE], [x_t0, qr_d0], valid_shape=[qr_rows, QR_K_TILE])
                w_chunk = wq_a[q_a_col0:q_a_col0 + QR_N_TILE, qr_d0:qr_d0 + QR_K_TILE]
                q_acc = pl.matmul_acc(q_acc, q_x_chunk_bf16, w_chunk, b_trans=True, init_cond=db == 0)
            qr_fp32 = pl.assemble(qr_fp32, q_acc, [t0, q_a_col0], atomic=STORE_ATOMIC)

@pl.jit
def qa_m64tail_test(x: pl.Tensor[[T_DYN, D], pl.BF16], w: pl.Tensor[[Q_LORA, D], pl.BF16, BF16_WEIGHT_LAYOUT], output: pl.InOut[pl.Tensor[[QPROJ_MM_T_DYN, Q_LORA], pl.FP32]]):
    x.bind_dynamic(0, T_DYN)
    output.bind_dynamic(0, QPROJ_MM_T_DYN)
    rows = pl.tensor.dim(x, 0)
    qa_m64tail(x, w, output, 0, rows)
    return output

@pl.jit.inline(auto_scope=False)
def qa_kshift(x: pl.Tensor[[T_DYN, D], pl.BF16], wq_a: pl.Tensor[[Q_LORA, D], pl.BF16, BF16_WEIGHT_LAYOUT], qr_fp32: pl.Out[pl.Tensor[[QPROJ_MM_T_DYN, Q_LORA], pl.FP32]], tile_base: pl.Scalar[pl.INDEX], tile_rows: pl.Scalar[pl.INDEX]):
    """Reference QA matmul, shared by the production QR and its diagnostic."""
    qa_tokens = pl.tensor.dim(x, 0)
    x_view = pl.reshape(x, [qa_tokens, D])
    qr_t_matmul = (tile_rows + QR_M_TILE - 1) // QR_M_TILE * QR_M_TILE
    qr_full_rows = tile_rows // QR_DENSE_M_TILE * QR_DENSE_M_TILE
    with pl.at(level=pl.Level.CORE_GROUP, name_hint='qr_proj_seed'):
        for ts0 in pl.range(0, qr_t_matmul, QR_M_TILE):
            for nseed0 in pl.range(0, Q_LORA, QR_N_TILE):
                qr_seed = pl.full([QR_M_TILE, QR_N_TILE], dtype=pl.FP32, value=0.0)
                qr_fp32[ts0:ts0 + QR_M_TILE, nseed0:nseed0 + QR_N_TILE] = qr_seed
    for qbg_idx in pl.spmd(Q_LORA // QR_N_TILE * QR_OK, name_hint='qr_proj_matmul', allow_early_resolve=True):
        q_a_col0 = qbg_idx // QR_OK * QR_N_TILE
        qr_k_base = qbg_idx % QR_OK * QR_SPLIT_K_TILE
        qr_native_group = q_a_col0 // QR_NATIVE_N_GROUP
        for dense_t0 in pl.range(0, qr_full_rows, QR_DENSE_M_TILE):
            dense_x0 = tile_base + dense_t0
            dense_acc = pl.create_tensor([QR_DENSE_M_TILE, QR_N_TILE], dtype=pl.FP32)
            for dense_k in pl.pipeline(0, QR_SPLIT_K_TILE // QR_K_TILE, stage=2):
                dense_k_order = dense_k
                if tile_rows >= QR_NATIVE_SHIFT_MIN_ROWS and tile_rows <= QR_NATIVE_SHIFT_MAX_ROWS and (tile_rows % QR_NATIVE_SHIFT_ROW_STEP == 0 or tile_rows == 126) and (qr_native_group < QR_NATIVE_SHIFT_GROUPS):
                    dense_k_direction = dense_k
                    if qr_native_group % 2 == 1:
                        dense_k_direction = QR_NATIVE_K_BLOCKS - 1 - dense_k
                    dense_k_order = (qr_native_group // 2 * QR_NATIVE_PAIR_SHIFT + dense_k_direction) % QR_NATIVE_K_BLOCKS
                dense_d0 = qr_k_base + pl.max(dense_k_order, 0) * QR_K_TILE
                dense_x = x_view[dense_x0:dense_x0 + QR_DENSE_M_TILE, dense_d0:dense_d0 + QR_K_TILE]
                dense_w = wq_a[q_a_col0:q_a_col0 + QR_N_TILE, dense_d0:dense_d0 + QR_K_TILE]
                dense_acc = pl.matmul_acc(dense_acc, dense_x, dense_w, b_trans=True, init_cond=dense_k == 0)
            qr_fp32 = pl.assemble(qr_fp32, dense_acc, [dense_t0, q_a_col0], atomic=STORE_ATOMIC)
        for t0 in pl.range(qr_full_rows, qr_t_matmul, QR_M_TILE):
            q_acc = pl.create_tensor([QR_M_TILE, QR_N_TILE], dtype=pl.FP32)
            for db in pl.pipeline(QR_SPLIT_K_TILE // QR_K_TILE, stage=2):
                qr_k_order = db
                if tile_rows >= QR_NATIVE_SHIFT_MIN_ROWS and tile_rows <= QR_NATIVE_SHIFT_MAX_ROWS and (tile_rows % QR_NATIVE_SHIFT_ROW_STEP == 0 or tile_rows == 126) and (qr_native_group < QR_NATIVE_SHIFT_GROUPS):
                    qr_k_direction = db
                    if qr_native_group % 2 == 1:
                        qr_k_direction = QR_NATIVE_K_BLOCKS - 1 - db
                    qr_k_order = (qr_native_group // 2 * QR_NATIVE_PAIR_SHIFT + qr_k_direction) % QR_NATIVE_K_BLOCKS
                qr_d0 = qr_k_base + pl.max(qr_k_order, 0) * QR_K_TILE
                qr_rows = pl.min(QR_M_TILE, tile_rows - t0)
                x_t0 = tile_base + t0
                q_x_chunk_bf16 = pl.slice(x_view, [QR_M_TILE, QR_K_TILE], [x_t0, qr_d0], valid_shape=[qr_rows, QR_K_TILE])
                w_chunk = wq_a[q_a_col0:q_a_col0 + QR_N_TILE, qr_d0:qr_d0 + QR_K_TILE]
                q_acc = pl.matmul_acc(q_acc, q_x_chunk_bf16, w_chunk, b_trans=True, init_cond=db == 0)
            qr_fp32 = pl.assemble(qr_fp32, q_acc, [t0, q_a_col0], atomic=STORE_ATOMIC)

@pl.jit
def qa_kshift_test(x: pl.Tensor[[T_DYN, D], pl.BF16], w: pl.Tensor[[Q_LORA, D], pl.BF16, BF16_WEIGHT_LAYOUT], output: pl.InOut[pl.Tensor[[QPROJ_MM_T_DYN, Q_LORA], pl.FP32]]):
    x.bind_dynamic(0, T_DYN)
    output.bind_dynamic(0, QPROJ_MM_T_DYN)
    rows = pl.tensor.dim(x, 0)
    qa_kshift(x, w, output, 0, rows)
    return output

@pl.jit.inline(auto_scope=False)
def qa_both(x: pl.Tensor[[T_DYN, D], pl.BF16], wq_a: pl.Tensor[[Q_LORA, D], pl.BF16, BF16_WEIGHT_LAYOUT], qr_fp32: pl.Out[pl.Tensor[[QPROJ_MM_T_DYN, Q_LORA], pl.FP32]], tile_base: pl.Scalar[pl.INDEX], tile_rows: pl.Scalar[pl.INDEX]):
    """Reference QA matmul, shared by the production QR and its diagnostic."""
    qa_tokens = pl.tensor.dim(x, 0)
    x_view = pl.reshape(x, [qa_tokens, D])
    qr_t_matmul = (tile_rows + QR_M_TILE - 1) // QR_M_TILE * QR_M_TILE
    qr_full_rows = (tile_rows + QR_DENSE_M_TILE - 1) // QR_DENSE_M_TILE * QR_DENSE_M_TILE
    with pl.at(level=pl.Level.CORE_GROUP, name_hint='qr_proj_seed'):
        for ts0 in pl.range(0, qr_t_matmul, QR_M_TILE):
            for nseed0 in pl.range(0, Q_LORA, QR_N_TILE):
                qr_seed = pl.full([QR_M_TILE, QR_N_TILE], dtype=pl.FP32, value=0.0)
                qr_fp32[ts0:ts0 + QR_M_TILE, nseed0:nseed0 + QR_N_TILE] = qr_seed
    for qbg_idx in pl.spmd(Q_LORA // QR_N_TILE * QR_OK, name_hint='qr_proj_matmul', allow_early_resolve=True):
        q_a_col0 = qbg_idx // QR_OK * QR_N_TILE
        qr_k_base = qbg_idx % QR_OK * QR_SPLIT_K_TILE
        qr_native_group = q_a_col0 // QR_NATIVE_N_GROUP
        for dense_t0 in pl.range(0, qr_full_rows, QR_DENSE_M_TILE):
            dense_x0 = tile_base + dense_t0
            dense_k_order = 0
            if tile_rows >= QR_NATIVE_SHIFT_MIN_ROWS and tile_rows <= QR_NATIVE_SHIFT_MAX_ROWS and (tile_rows % QR_NATIVE_SHIFT_ROW_STEP == 0 or tile_rows == 126) and (qr_native_group < QR_NATIVE_SHIFT_GROUPS):
                dense_k_direction = 0
                if qr_native_group % 2 == 1:
                    dense_k_direction = QR_NATIVE_K_BLOCKS - 1 - 0
                dense_k_order = (qr_native_group // 2 * QR_NATIVE_PAIR_SHIFT + dense_k_direction) % QR_NATIVE_K_BLOCKS
            dense_d0 = qr_k_base + pl.max(dense_k_order, 0) * QR_K_TILE
            dense_x = pl.slice(x_view, [QR_DENSE_M_TILE, QR_K_TILE], [dense_x0, dense_d0], valid_shape=[pl.min(QR_DENSE_M_TILE, tile_rows - dense_t0), QR_K_TILE])
            dense_w = wq_a[q_a_col0:q_a_col0 + QR_N_TILE, dense_d0:dense_d0 + QR_K_TILE]
            dense_acc = pl.matmul(dense_x, dense_w, out_dtype=pl.FP32, b_trans=True)
            for dense_k in pl.pipeline(1, QR_SPLIT_K_TILE // QR_K_TILE, stage=2):
                dense_k_order = dense_k
                if tile_rows >= QR_NATIVE_SHIFT_MIN_ROWS and tile_rows <= QR_NATIVE_SHIFT_MAX_ROWS and (tile_rows % QR_NATIVE_SHIFT_ROW_STEP == 0 or tile_rows == 126) and (qr_native_group < QR_NATIVE_SHIFT_GROUPS):
                    dense_k_direction = dense_k
                    if qr_native_group % 2 == 1:
                        dense_k_direction = QR_NATIVE_K_BLOCKS - 1 - dense_k
                    dense_k_order = (qr_native_group // 2 * QR_NATIVE_PAIR_SHIFT + dense_k_direction) % QR_NATIVE_K_BLOCKS
                dense_d0 = qr_k_base + pl.max(dense_k_order, 0) * QR_K_TILE
                dense_x = pl.slice(x_view, [QR_DENSE_M_TILE, QR_K_TILE], [dense_x0, dense_d0], valid_shape=[pl.min(QR_DENSE_M_TILE, tile_rows - dense_t0), QR_K_TILE])
                dense_w = wq_a[q_a_col0:q_a_col0 + QR_N_TILE, dense_d0:dense_d0 + QR_K_TILE]
                dense_acc = pl.matmul_acc(dense_acc, dense_x, dense_w, b_trans=True, init_cond=False)
            qr_fp32 = pl.assemble(qr_fp32, dense_acc, [dense_t0, q_a_col0], atomic=STORE_ATOMIC)
        for t0 in pl.range(qr_full_rows, qr_t_matmul, QR_M_TILE):
            q_acc = pl.create_tensor([QR_M_TILE, QR_N_TILE], dtype=pl.FP32)
            for db in pl.pipeline(QR_SPLIT_K_TILE // QR_K_TILE, stage=2):
                qr_k_order = db
                if tile_rows >= QR_NATIVE_SHIFT_MIN_ROWS and tile_rows <= QR_NATIVE_SHIFT_MAX_ROWS and (tile_rows % QR_NATIVE_SHIFT_ROW_STEP == 0 or tile_rows == 126) and (qr_native_group < QR_NATIVE_SHIFT_GROUPS):
                    qr_k_direction = db
                    if qr_native_group % 2 == 1:
                        qr_k_direction = QR_NATIVE_K_BLOCKS - 1 - db
                    qr_k_order = (qr_native_group // 2 * QR_NATIVE_PAIR_SHIFT + qr_k_direction) % QR_NATIVE_K_BLOCKS
                qr_d0 = qr_k_base + pl.max(qr_k_order, 0) * QR_K_TILE
                qr_rows = pl.min(QR_M_TILE, tile_rows - t0)
                x_t0 = tile_base + t0
                q_x_chunk_bf16 = pl.slice(x_view, [QR_M_TILE, QR_K_TILE], [x_t0, qr_d0], valid_shape=[qr_rows, QR_K_TILE])
                w_chunk = wq_a[q_a_col0:q_a_col0 + QR_N_TILE, qr_d0:qr_d0 + QR_K_TILE]
                q_acc = pl.matmul_acc(q_acc, q_x_chunk_bf16, w_chunk, b_trans=True, init_cond=db == 0)
            qr_fp32 = pl.assemble(qr_fp32, q_acc, [t0, q_a_col0], atomic=STORE_ATOMIC)

@pl.jit
def qa_both_test(x: pl.Tensor[[T_DYN, D], pl.BF16], w: pl.Tensor[[Q_LORA, D], pl.BF16, BF16_WEIGHT_LAYOUT], output: pl.InOut[pl.Tensor[[QPROJ_MM_T_DYN, Q_LORA], pl.FP32]]):
    x.bind_dynamic(0, T_DYN)
    output.bind_dynamic(0, QPROJ_MM_T_DYN)
    rows = pl.tensor.dim(x, 0)
    qa_both(x, w, output, 0, rows)
    return output


@pl.jit.inline(auto_scope=False)
def qa_observed256(x: pl.Tensor[[T_DYN, D], pl.BF16], wq_a: pl.Tensor[[Q_LORA, D], pl.BF16, BF16_WEIGHT_LAYOUT], qr_fp32: pl.Out[pl.Tensor[[QPROJ_MM_T_DYN, Q_LORA], pl.FP32]], tile_base: pl.Scalar[pl.INDEX], tile_rows: pl.Scalar[pl.INDEX]):
    """Reference QA matmul, shared by the production QR and its diagnostic."""
    qa_tokens = pl.tensor.dim(x, 0)
    x_view = pl.reshape(x, [qa_tokens, D])
    qr_t_matmul = (tile_rows + QR_M_TILE - 1) // QR_M_TILE * QR_M_TILE
    qr_full_rows = tile_rows // QR_DENSE_M_TILE * QR_DENSE_M_TILE
    with pl.at(level=pl.Level.CORE_GROUP, name_hint='qr_proj_seed'):
        for ts0 in pl.range(0, qr_t_matmul, QR_M_TILE):
            for nseed0 in pl.range(0, Q_LORA, QR_N_TILE):
                qr_seed = pl.full([QR_M_TILE, QR_N_TILE], dtype=pl.FP32, value=0.0)
                qr_fp32[ts0:ts0 + QR_M_TILE, nseed0:nseed0 + QR_N_TILE] = qr_seed
    for qbg_idx in pl.spmd(Q_LORA // QR_N_TILE * QR_OK, name_hint='qr_proj_matmul', allow_early_resolve=True):
        q_a_col0 = qbg_idx // QR_OK * QR_N_TILE
        qr_k_base = qbg_idx % QR_OK * QR_SPLIT_K_TILE
        qr_native_group = q_a_col0 // QR_NATIVE_N_GROUP
        for dense_t0 in pl.range(0, qr_full_rows, QR_DENSE_M_TILE):
            dense_x0 = tile_base + dense_t0
            dense_acc = pl.create_tensor([QR_DENSE_M_TILE, QR_N_TILE], dtype=pl.FP32)
            for dense_k in pl.pipeline(0, QR_SPLIT_K_TILE // QR_K_TILE, stage=2):
                dense_k_order = dense_k
                if tile_rows == 126 and qr_native_group < 9:
                    native_packet = dense_k // 2
                    if qr_native_group % 2 == 1:
                        native_packet = 7 - native_packet
                    dense_k_order = (qr_native_group // 2 + native_packet) % 8 * 2 + dense_k % 2
                dense_d0 = qr_k_base + pl.max(dense_k_order, 0) * QR_K_TILE
                dense_x = x_view[dense_x0:dense_x0 + QR_DENSE_M_TILE, dense_d0:dense_d0 + QR_K_TILE]
                dense_w = wq_a[q_a_col0:q_a_col0 + QR_N_TILE, dense_d0:dense_d0 + QR_K_TILE]
                dense_acc = pl.matmul_acc(dense_acc, dense_x, dense_w, b_trans=True, init_cond=dense_k == 0)
            qr_fp32 = pl.assemble(qr_fp32, dense_acc, [dense_t0, q_a_col0], atomic=STORE_ATOMIC)
        for t0 in pl.range(qr_full_rows, qr_t_matmul, QR_M_TILE):
            q_acc = pl.create_tensor([QR_M_TILE, QR_N_TILE], dtype=pl.FP32)
            for db in pl.pipeline(QR_SPLIT_K_TILE // QR_K_TILE, stage=2):
                qr_k_order = db
                if tile_rows == 126 and qr_native_group < 9:
                    native_packet = db // 2
                    if qr_native_group % 2 == 1:
                        native_packet = 7 - native_packet
                    qr_k_order = (qr_native_group // 2 + native_packet) % 8 * 2 + db % 2
                qr_d0 = qr_k_base + pl.max(qr_k_order, 0) * QR_K_TILE
                qr_rows = pl.min(QR_M_TILE, tile_rows - t0)
                x_t0 = tile_base + t0
                q_x_chunk_bf16 = pl.slice(x_view, [QR_M_TILE, QR_K_TILE], [x_t0, qr_d0], valid_shape=[qr_rows, QR_K_TILE])
                w_chunk = wq_a[q_a_col0:q_a_col0 + QR_N_TILE, qr_d0:qr_d0 + QR_K_TILE]
                q_acc = pl.matmul_acc(q_acc, q_x_chunk_bf16, w_chunk, b_trans=True, init_cond=db == 0)
            qr_fp32 = pl.assemble(qr_fp32, q_acc, [t0, q_a_col0], atomic=STORE_ATOMIC)


@pl.jit
def qa_observed256_test(x:pl.Tensor[[T_DYN,D],pl.BF16],w:pl.Tensor[[Q_LORA,D],pl.BF16,BF16_WEIGHT_LAYOUT],output:pl.InOut[pl.Tensor[[QPROJ_MM_T_DYN,Q_LORA],pl.FP32]]):
    x.bind_dynamic(0,T_DYN)
    output.bind_dynamic(0,QPROJ_MM_T_DYN)
    rows=pl.tensor.dim(x,0)
    qa_observed256(x,w,output,0,rows)
    return output


@pl.jit.inline(auto_scope=False)
def qa_observed512(x: pl.Tensor[[T_DYN, D], pl.BF16], wq_a: pl.Tensor[[Q_LORA, D], pl.BF16, BF16_WEIGHT_LAYOUT], qr_fp32: pl.Out[pl.Tensor[[QPROJ_MM_T_DYN, Q_LORA], pl.FP32]], tile_base: pl.Scalar[pl.INDEX], tile_rows: pl.Scalar[pl.INDEX]):
    """Reference QA matmul, shared by the production QR and its diagnostic."""
    qa_tokens = pl.tensor.dim(x, 0)
    x_view = pl.reshape(x, [qa_tokens, D])
    qr_t_matmul = (tile_rows + QR_M_TILE - 1) // QR_M_TILE * QR_M_TILE
    qr_full_rows = tile_rows // QR_DENSE_M_TILE * QR_DENSE_M_TILE
    with pl.at(level=pl.Level.CORE_GROUP, name_hint='qr_proj_seed'):
        for ts0 in pl.range(0, qr_t_matmul, QR_M_TILE):
            for nseed0 in pl.range(0, Q_LORA, QR_N_TILE):
                qr_seed = pl.full([QR_M_TILE, QR_N_TILE], dtype=pl.FP32, value=0.0)
                qr_fp32[ts0:ts0 + QR_M_TILE, nseed0:nseed0 + QR_N_TILE] = qr_seed
    for qbg_idx in pl.spmd(Q_LORA // QR_N_TILE * QR_OK, name_hint='qr_proj_matmul', allow_early_resolve=True):
        q_a_col0 = qbg_idx // QR_OK * QR_N_TILE
        qr_k_base = qbg_idx % QR_OK * QR_SPLIT_K_TILE
        qr_native_group = q_a_col0 // QR_NATIVE_N_GROUP
        for dense_t0 in pl.range(0, qr_full_rows, QR_DENSE_M_TILE):
            dense_x0 = tile_base + dense_t0
            dense_acc = pl.create_tensor([QR_DENSE_M_TILE, QR_N_TILE], dtype=pl.FP32)
            for dense_k in pl.pipeline(0, QR_SPLIT_K_TILE // 512, stage=2):
                dense_k_order = dense_k
                if tile_rows == 126 and qr_native_group < 9:
                    native_packet = dense_k
                    if qr_native_group % 2 == 1:
                        native_packet = 7 - native_packet
                    dense_k_order = (qr_native_group // 2 + native_packet) % 8
                dense_d0 = qr_k_base + pl.max(dense_k_order, 0) * 512
                dense_x = x_view[dense_x0:dense_x0 + QR_DENSE_M_TILE, dense_d0:dense_d0 + 512]
                dense_w = wq_a[q_a_col0:q_a_col0 + QR_N_TILE, dense_d0:dense_d0 + 512]
                dense_acc = pl.matmul_acc(dense_acc, dense_x, dense_w, b_trans=True, init_cond=dense_k == 0)
            qr_fp32 = pl.assemble(qr_fp32, dense_acc, [dense_t0, q_a_col0], atomic=STORE_ATOMIC)
        for t0 in pl.range(qr_full_rows, qr_t_matmul, QR_M_TILE):
            q_acc = pl.create_tensor([QR_M_TILE, QR_N_TILE], dtype=pl.FP32)
            for db in pl.pipeline(QR_SPLIT_K_TILE // 512, stage=2):
                qr_k_order = db
                if tile_rows == 126 and qr_native_group < 9:
                    native_packet = db
                    if qr_native_group % 2 == 1:
                        native_packet = 7 - native_packet
                    qr_k_order = (qr_native_group // 2 + native_packet) % 8
                qr_d0 = qr_k_base + pl.max(qr_k_order, 0) * 512
                qr_rows = pl.min(QR_M_TILE, tile_rows - t0)
                x_t0 = tile_base + t0
                q_x_chunk_bf16 = pl.slice(x_view, [QR_M_TILE, 512], [x_t0, qr_d0], valid_shape=[qr_rows, 512])
                w_chunk = wq_a[q_a_col0:q_a_col0 + QR_N_TILE, qr_d0:qr_d0 + 512]
                q_acc = pl.matmul_acc(q_acc, q_x_chunk_bf16, w_chunk, b_trans=True, init_cond=db == 0)
            qr_fp32 = pl.assemble(qr_fp32, q_acc, [t0, q_a_col0], atomic=STORE_ATOMIC)


@pl.jit
def qa_observed512_test(x:pl.Tensor[[T_DYN,D],pl.BF16],w:pl.Tensor[[Q_LORA,D],pl.BF16,BF16_WEIGHT_LAYOUT],output:pl.InOut[pl.Tensor[[QPROJ_MM_T_DYN,Q_LORA],pl.FP32]]):
    x.bind_dynamic(0,T_DYN)
    output.bind_dynamic(0,QPROJ_MM_T_DYN)
    rows=pl.tensor.dim(x,0)
    qa_observed512(x,w,output,0,rows)
    return output

