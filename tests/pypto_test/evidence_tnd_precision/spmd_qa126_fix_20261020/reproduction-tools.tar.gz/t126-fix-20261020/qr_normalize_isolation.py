"""Feed the actual Native QA BF16 boundary into the original PTO RMS/quant."""
import json,os,sys
from pathlib import Path
import torch
import pypto.language as pl
import pypto.torch
from pypto.runtime import RunConfig
import vllm_ascend.ops.pypto as ns
exp=Path(os.environ['SPMD_EXPERIMENT']);here=exp/'t126-fix-20261020'
ns.__path__.insert(0,str(exp/'src/vllm_ascend/ops/pypto'))
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.qkv_proj_rope import (
    T_DYN,QPROJ_MM_T_DYN,QPROJ_T_PAD,q_proj_qr_normalize,
)
@pl.jit
def normalize_test(
    qa:pl.Tensor[[QPROJ_MM_T_DYN,1024],pl.FP32],
    gamma:pl.Tensor[[1024],pl.BF16],
    qr:pl.Out[pl.Tensor[[T_DYN,1024],pl.INT8]],
    scale:pl.Out[pl.Tensor[[T_DYN,1],pl.FP32]],
    padded_qr:pl.InOut[pl.Tensor[[QPROJ_T_PAD,1024],pl.INT8]],
    padded_scale:pl.InOut[pl.Tensor[[QPROJ_T_PAD,1],pl.FP32]],
):
    qa.bind_dynamic(0,QPROJ_MM_T_DYN)
    qr.bind_dynamic(0,T_DYN);scale.bind_dynamic(0,T_DYN)
    rows=pl.tensor.dim(qr,0)
    q_proj_qr_normalize(qa,gamma,qr,scale,padded_qr,padded_scale,0,rows)
    return qr,scale

if __name__=='__main__':
    if '--compile' in sys.argv:
        assert os.environ['ASCEND_RT_VISIBLE_DEVICES']==''
        normalize_test.compile(config=RunConfig(platform='a2a3',save_kernels=True,save_kernels_dir=str(here/'qr-isolation-artifact')))
        from pypto.ir._kernel_compile import kernel_abi_for_program
        from pypto.ir.compile import _compile_impl
        program=normalize_test.specialize()
        abi=kernel_abi_for_program(program,platform='a2a3',runtime='tensormap_and_ringbuffer')
        _compile_impl(program,output_dir=str(here/'qr-isolation-kernel-artifact'),platform='a2a3',_kernel_abi=abi)
        from pypto.runtime.kernel_compiler import KernelCompiler
        KernelCompiler().compile_orchestration('tensormap_and_ringbuffer',str(here/'qr-isolation-artifact/orchestration/normalize_test.cpp'))
        op=pypto.torch.register(normalize_test,'t126_qr_isolation::run');assert len(op._schema.arguments)==6
        print('QR_NORMALIZE_ISOLATION_COMPILE_PASS',flush=True)
    else:
        import torch_npu
        assert os.environ['TASK_DEVICE'];torch.npu.set_device(0);torch.npu.config.allow_internal_format=True
        torch_npu.npu.set_deterministic_level(1);pypto.torch.init()
        d=torch.load(exp/'results/t126-qa-stage-v5/query-calibration.pt',map_location='cpu',weights_only=False)
        qa=torch.zeros((128,1024),dtype=torch.float32);qa[:126]=d['native_qa'].float()
        qr=torch.full((126,1024),-111,dtype=torch.int8,device='npu')
        scale=torch.full((126,1),float('nan'),device='npu')
        qp=torch.empty((QPROJ_T_PAD,1024),dtype=torch.int8,device='npu');sp=torch.empty((QPROJ_T_PAD,1),device='npu')
        op=pypto.torch.register(normalize_test,'t126_qr_isolation::run')
        with torch.inference_mode():op(qa.npu(),d['gamma_cq'].npu(),qr,scale,qp,sp)
        torch.npu.synchronize();qr=qr.cpu();scale=scale.cpu()
        assert bool(torch.isfinite(scale).all())
        record={'native_qa_input':True,'qr_different':int((qr!=d['native_qr']).sum()),'scale_different':int((scale!=d['native_qr_scale']).sum()),'scale_different_rows':(scale!=d['native_qr_scale']).any(1).nonzero().flatten().tolist(),'target_rows':{str(row):{'qr_different':int((qr[row]!=d['native_qr'][row]).sum()),'native_scale':float(d['native_qr_scale'][row]),'pto_scale':float(scale[row])} for row in (86,103)}}
        out=exp/'results/t126-qr-normalize-isolation-v2';out.mkdir(exist_ok=False)
        (out/'result.json').write_text(json.dumps(record,indent=2)+'\n');torch.save({'qr':qr,'scale':scale,'native':d},out/'isolation.pt')
        print('QR_NORMALIZE_SAME_NATIVE_QA_RESULT',record,flush=True)
