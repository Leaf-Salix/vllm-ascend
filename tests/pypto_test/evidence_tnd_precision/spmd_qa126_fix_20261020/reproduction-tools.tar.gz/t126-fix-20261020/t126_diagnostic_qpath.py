from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.qkv_proj_rope import *
from t126_diagnostic_exports import export_qa

@pl.jit.inline(auto_scope=False)
def q_proj_qr(x: pl.Tensor[[T_DYN, D], pl.BF16], wq_a: pl.Tensor[[Q_LORA, D], pl.BF16, BF16_WEIGHT_LAYOUT], gamma_cq: pl.Tensor[[Q_LORA], pl.BF16], qr: pl.Tensor[[T_DYN, Q_LORA], pl.INT8], qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32], qr_i8_matmul: pl.Out[pl.Tensor[[QPROJ_T_PAD, Q_LORA], pl.INT8]], qr_scale_pad_store: pl.Out[pl.Tensor[[QPROJ_T_PAD, 1], pl.FP32]], debug_packet: pl.InOut[pl.Tensor[[1048576], pl.INT32]]):
    """Q LoRA, RMSNorm and quantization -- the half the indexer query chain needs.

    The two staging tensors are held by the caller so the qproj half can be issued
    separately; they are rewritten per dense tile, so a caller that runs more than one
    tile iteration must let the qproj half finish before the next one starts. Every
    current caller has t_dim <= PREFILL_DENSE_TILE, i.e. a single iteration.
    """
    t_dim = pl.tensor.dim(x, 0)
    for tile_base in pl.range(0, t_dim, PREFILL_DENSE_TILE):
        tile_rows = pl.min(PREFILL_DENSE_TILE, t_dim - tile_base)
        with pl.scope():
            qr_t_matmul = (tile_rows + QR_M_TILE - 1) // QR_M_TILE * QR_M_TILE
            qr_fp32 = pl.create_tensor([qr_t_matmul, Q_LORA], dtype=pl.FP32)
            q_proj_qa(x, wq_a, qr_fp32, tile_base, tile_rows)
            export_qa(qr_fp32, debug_packet)
            q_proj_qr_normalize(qr_fp32, gamma_cq, qr, qr_scale, qr_i8_matmul, qr_scale_pad_store, tile_base, tile_rows)

@pl.jit.inline(auto_scope=False)
def q_proj_rope(x: pl.Tensor[[T_DYN, D], pl.BF16], wq_a: pl.Tensor[[Q_LORA, D], pl.BF16, BF16_WEIGHT_LAYOUT], wq_b: pl.Tensor[[Q_LORA, H * HEAD_DIM], pl.INT8, QUANT_WEIGHT_LAYOUT], wq_b_scale: pl.Tensor[[H * HEAD_DIM], pl.FP32], gamma_cq: pl.Tensor[[Q_LORA], pl.BF16], rope_cos_il: pl.Tensor[[T_DYN, ROPE_DIM], pl.FP32], rope_sin_signed: pl.Tensor[[T_DYN, ROPE_DIM], pl.FP32], rope_swap_idx: pl.Tensor[[T_DYN, ROPE_DIM], pl.INT32], q: pl.Tensor[[T_DYN, H, HEAD_DIM], pl.BF16], qr: pl.Tensor[[T_DYN, Q_LORA], pl.INT8], qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32], debug_packet: pl.InOut[pl.Tensor[[1048576], pl.INT32]]):
    """Q LoRA, RMSNorm, quantization, and RoPE over bounded dense tiles."""
    qr_i8_matmul = pl.create_tensor([QPROJ_T_PAD, Q_LORA], dtype=pl.INT8)
    qr_scale_pad_store = pl.create_tensor([QPROJ_T_PAD, 1], dtype=pl.FP32, manual_dep=True)
    q_proj_qr(x, wq_a, gamma_cq, qr, qr_scale, qr_i8_matmul, qr_scale_pad_store, debug_packet)
    q_seq_dep = pl.system.task_dummy(deps=[])
    q_proj_q(x, wq_b, wq_b_scale, rope_cos_il, rope_sin_signed, rope_swap_idx, q, qr_i8_matmul, qr_scale_pad_store, q_seq_dep)
