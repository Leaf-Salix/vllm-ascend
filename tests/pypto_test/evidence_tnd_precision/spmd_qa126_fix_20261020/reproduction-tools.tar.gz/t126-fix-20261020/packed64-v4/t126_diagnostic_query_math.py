"""CSA integration dependency adapted from pypto-lib 205255b4/decode_indexer.py."""
from t126_diagnostic_exports import export_irope, export_ihadamard_scaled
import math
import pypto.language as pl
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.config import BLOCK_SIZE, C4A_COMPRESSOR_BLOCK_SIZE, DECODE_BATCH, DECODE_SEQ, FP32_NEG_INF, INT8_AMAX_EPS, INT8_SCALE_MAX, TP
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.config import FLASH as M
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.layout import INDEXER_KEY_BYTES, INDEXER_PAGE_BYTES_DYN, INDEXER_TABLE_COLUMNS_DYN, QUERY_BOUNDS_DYN
INDEXER_NATIVE_CUBE_MIN_ROWS = 0
B_DYN = pl.dynamic('B_DYN')
T_DYN = pl.dynamic('T_DYN')
B = DECODE_BATCH // TP
S = DECODE_SEQ
T = B * S
D = M.hidden_size
Q_LORA = M.q_lora_rank
ROPE_HEAD_DIM = M.qk_rope_head_dim
IDX_N_HEADS = M.index_n_heads
IDX_HEAD_DIM = M.index_head_dim
HADAMARD_SCALE = IDX_HEAD_DIM ** (-0.5)
IDX_NOPE_HEAD_DIM = M.index_nope_head_dim
WEIGHTS_SCALE = M.index_weights_scale
MAX_SEQ_LEN = M.max_position_embeddings
COMPRESS_RATIO = 4
IDX_TOPK = M.index_topk
INNER_OVERLAP = COMPRESS_RATIO == 4
INNER_COFF = 1 + int(INNER_OVERLAP)
INNER_HEAD_DIM = IDX_HEAD_DIM
INNER_OUT_DIM = INNER_COFF * INNER_HEAD_DIM
INNER_STATE_BLOCK_SIZE = C4A_COMPRESSOR_BLOCK_SIZE
INNER_STATE_LEN = INNER_COFF * COMPRESS_RATIO
INNER_STATE_BLOCK_NUM_DYN = pl.dynamic('INNER_STATE_BLOCK_NUM_DYN')
INNER_STATE_DIM = 2 * INNER_OUT_DIM
IDX_MAX_ROWS = MAX_SEQ_LEN // COMPRESS_RATIO
IDX_MAX_BLOCKS = (IDX_MAX_ROWS + BLOCK_SIZE - 1) // BLOCK_SIZE
IDX_NATIVE_CACHE_BLOCK_NUM_DYN = pl.dynamic('IDX_NATIVE_CACHE_BLOCK_NUM_DYN')
CACHE_TILE = min(64, BLOCK_SIZE)
Q_TILE = 256
Q_OUT_TILE = 1024
T_PAD_ALIGN = 16 * S // math.gcd(16, S)
T_PAD = (T + S + T_PAD_ALIGN - 1) // T_PAD_ALIGN * T_PAD_ALIGN
QR_MM_ROW_TILE = 64
QR_MM_N_TILE = 256
QR_MM_T_PAD = (T_PAD + QR_MM_ROW_TILE - 1) // QR_MM_ROW_TILE * QR_MM_ROW_TILE
WEIGHTS_PROJECTION_N_TILE = 16
WEIGHTS_PROJECTION_K_TILE = 256
MM_ROW_TILE = 16
MM_N_TILE = min(512, 128 * 1024 // (MM_ROW_TILE * 4))
DEQUANT_T_TILE = min(T, 8)
HEAD_DIM_TILE = 32
WEIGHTS_OK = 4
WEIGHTS_K_TILE = D // WEIGHTS_OK
D_TILE = 512
QH_QUANT_TILE = 64
QH_QUANT_WORKERS = 48
QR_PROJ_WORKERS = 24
QH_MM_TILE = 64
QH_WORKERS = 24
WEIGHTS_WORKERS = 24
TP1_WEIGHTS_WORKERS = 8
QH_HEAD_DIM_TILE = 64
DQ_ROPE_H_TILE = 4
DQ_ROPE_WORKERS = 48
TOPK_PAIR_WIDTH = 2 * IDX_TOPK
TOPK_CANDIDATES_PER_LEAF = 8192
TOPK_MAX_CANDIDATES = IDX_MAX_ROWS
TOPK_MAX_LEAVES = (TOPK_MAX_CANDIDATES + TOPK_CANDIDATES_PER_LEAF - 1) // TOPK_CANDIDATES_PER_LEAF
TOPK_ROWS_PER_QUERY = TOPK_MAX_LEAVES * 2
TOPK_QUERY_WORKERS = 48
TOPK_MERGE_FAN_IN = 4
TOPK_ARENA_ROWS = T_PAD * TOPK_ROWS_PER_QUERY
TOPK_SCORE_WORKERS = 24
LONG_S6_MIN_REQUEST_GROUPS = 4
SCORE_TILE = 384
BUFFERED_SCORE_TILE = 768
BUFFERED_LONG_SCORE_TILE = 1024
BUFFERED_SCORE_LANE_TILE = BUFFERED_SCORE_TILE // 2
BUFFERED_SCORE_SCALE = 1024.0
NATIVE_QLI_WEIGHT_ROWS = 16
NATIVE_QLI_QK_COLS = 128
SCORE_READY_EVENT = 0
SCORE_CONSUMED_EVENT = 1
SCORE_LANE_ROWS = SCORE_TILE // 2
SCORE_MAX_QUERY_GROUP = S
SCORE_ARENA_ROWS = max(T_PAD, TOPK_SCORE_WORKERS * 2 * SCORE_MAX_QUERY_GROUP)
assert S % SCORE_MAX_QUERY_GROUP == 0 and T_PAD % SCORE_MAX_QUERY_GROUP == 0

@pl.jit.inline(auto_scope=False)
def indexer_qr_rope(x: pl.Tensor[[T_DYN, D], pl.BF16], qr: pl.Tensor[[T_DYN, Q_LORA], pl.INT8], qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32], wq_b: pl.Tensor[[Q_LORA, IDX_N_HEADS * IDX_HEAD_DIM], pl.INT8], wq_b_scale: pl.Tensor[[IDX_N_HEADS * IDX_HEAD_DIM], pl.FP32], cos: pl.Tensor[[T_DYN, ROPE_HEAD_DIM], pl.FP32], sin: pl.Tensor[[T_DYN, ROPE_HEAD_DIM], pl.FP32], qr_bf16: pl.Out[pl.Tensor[[T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], pl.BF16]]) -> pl.Scalar[pl.TASK_ID]:
    """Indexer query projection, dequant and RoPE -- everything before the hadamard."""
    bs = pl.tensor.dim(x, 0)
    row_blocks = (bs + QR_MM_ROW_TILE - 1) // QR_MM_ROW_TILE
    qr_acc_pad = pl.create_tensor([QR_MM_T_PAD, IDX_N_HEADS * IDX_HEAD_DIM], dtype=pl.INT32)
    with pl.spmd(QR_PROJ_WORKERS, name_hint='idx_qr_proj_matmul', allow_early_resolve=True) as idx_qr_mm_tid:
        qr_proj_worker = pl.tile.get_block_idx()
        for qr_col in pl.range(qr_proj_worker, IDX_N_HEADS * IDX_HEAD_DIM // QR_MM_N_TILE, QR_PROJ_WORKERS):
            o_base = qr_col * QR_MM_N_TILE
            wq_tile = wq_b[0:Q_LORA, o_base:o_base + QR_MM_N_TILE]
            for qr_rb in pl.range(row_blocks):
                qr_r0 = qr_rb * QR_MM_ROW_TILE
                qr_rows = pl.min(QR_MM_ROW_TILE, bs - qr_r0)
                qr_tile = pl.slice(qr, [QR_MM_ROW_TILE, Q_LORA], [qr_r0, 0], valid_shape=[qr_rows, Q_LORA])
                qr_acc = pl.matmul(qr_tile, wq_tile, out_dtype=pl.INT32)
                qr_acc_pad[qr_r0:qr_r0 + QR_MM_ROW_TILE, o_base:o_base + QR_MM_N_TILE] = qr_acc
    qr_bf16_2d = pl.reshape(qr_bf16, [T_PAD, IDX_N_HEADS * IDX_HEAD_DIM])
    dq_rope_units = (bs + DEQUANT_T_TILE - 1) // DEQUANT_T_TILE * (IDX_N_HEADS // DQ_ROPE_H_TILE)
    dq_rope_workers = pl.min(dq_rope_units, DQ_ROPE_WORKERS)
    for dq_rope_worker in pl.spmd(dq_rope_workers, name_hint='idx_qr_dequant_rope', allow_early_resolve=True):
        sw_ones = pl.full([DEQUANT_T_TILE, ROPE_HEAD_DIM], dtype=pl.FP32, value=1.0)
        sw_index = pl.cast(pl.arange(0, [1, ROPE_HEAD_DIM], dtype=pl.INT32), target_type=pl.FP32)
        sw_col = pl.col_expand_mul(sw_ones, sw_index)
        sw_dup_f = pl.cast(pl.cast(pl.mul(sw_col, 0.5), target_type=pl.INT32, mode='trunc'), target_type=pl.FP32)
        sw_lane = pl.sub(sw_col, pl.mul(sw_dup_f, 2.0))
        rope_swap_idx = pl.cast(pl.sub(pl.add(sw_col, 1.0), pl.mul(sw_lane, 2.0)), target_type=pl.INT32)
        for dq_unit in pl.range(dq_rope_worker, dq_rope_units, dq_rope_workers):
            hg = dq_unit % (IDX_N_HEADS // DQ_ROPE_H_TILE) * DQ_ROPE_H_TILE
            dq_t0 = dq_unit // (IDX_N_HEADS // DQ_ROPE_H_TILE) * DEQUANT_T_TILE
            if dq_t0 + DEQUANT_T_TILE <= bs:
                qr_scale_tile = qr_scale[dq_t0:dq_t0 + DEQUANT_T_TILE, :]
                cos_tile = cos[dq_t0:dq_t0 + DEQUANT_T_TILE, 0:ROPE_HEAD_DIM]
                sin_tile = sin[dq_t0:dq_t0 + DEQUANT_T_TILE, 0:ROPE_HEAD_DIM]
                for h_inner in pl.pipeline(DQ_ROPE_H_TILE, stage=2):
                    h0 = (hg + h_inner) * IDX_HEAD_DIM
                    wq_scale = pl.reshape(wq_b_scale[h0:h0 + IDX_HEAD_DIM], [1, IDX_HEAD_DIM])
                    acc_fp32 = pl.cast(qr_acc_pad[dq_t0:dq_t0 + DEQUANT_T_TILE, h0:h0 + IDX_HEAD_DIM], target_type=pl.FP32, mode='none')
                    qr_dequant_scale = pl.col_expand_mul(pl.row_expand_mul(pl.full([DEQUANT_T_TILE, IDX_HEAD_DIM], dtype=pl.FP32, value=1.0), qr_scale_tile), wq_scale)
                    qr_dequant = pl.mul(acc_fp32, qr_dequant_scale)
                    qr_dequant = pl.cast(pl.cast(qr_dequant, pl.BF16, mode='rint'), pl.FP32)
                    qr_nope_bf16 = pl.cast(qr_dequant[:, 0:IDX_NOPE_HEAD_DIM], target_type=pl.BF16, mode='rint')
                    qr_rope_slice = qr_dequant[:, IDX_NOPE_HEAD_DIM:IDX_HEAD_DIM]
                    qr_swapped = pl.gather(qr_rope_slice, dim=-1, index=rope_swap_idx)
                    rope_rot = pl.add(pl.mul(qr_rope_slice, cos_tile), pl.mul(qr_swapped, sin_tile))
                    rope_bf16 = pl.cast(rope_rot, target_type=pl.BF16, mode='rint')
                    qr_bf16_2d[dq_t0:dq_t0 + DEQUANT_T_TILE, h0:h0 + IDX_NOPE_HEAD_DIM] = qr_nope_bf16
                    qr_bf16_2d[dq_t0:dq_t0 + DEQUANT_T_TILE, h0 + IDX_NOPE_HEAD_DIM:h0 + IDX_HEAD_DIM] = rope_bf16
            else:
                tail_swap_idx = rope_swap_idx[0:1, :]
                for tail_t0 in pl.range(dq_t0, bs):
                    tail_qr_scale_value = pl.read(qr_scale, [tail_t0, 0])
                    tail_cos_tile = cos[tail_t0:tail_t0 + 1, 0:ROPE_HEAD_DIM]
                    tail_sin_tile = sin[tail_t0:tail_t0 + 1, 0:ROPE_HEAD_DIM]
                    for tail_h_inner in pl.pipeline(DQ_ROPE_H_TILE, stage=2):
                        tail_h0 = (hg + tail_h_inner) * IDX_HEAD_DIM
                        tail_wq_scale = pl.reshape(wq_b_scale[tail_h0:tail_h0 + IDX_HEAD_DIM], [1, IDX_HEAD_DIM])
                        tail_acc_fp32 = pl.cast(qr_acc_pad[tail_t0:tail_t0 + 1, tail_h0:tail_h0 + IDX_HEAD_DIM], target_type=pl.FP32, mode='none')
                        tail_qr_dequant_scale = pl.mul(tail_wq_scale, tail_qr_scale_value)
                        tail_qr_dequant = pl.mul(tail_acc_fp32, tail_qr_dequant_scale)
                        tail_qr_dequant = pl.cast(pl.cast(tail_qr_dequant, pl.BF16, mode='rint'), pl.FP32)
                        tail_qr_nope_bf16 = pl.cast(tail_qr_dequant[:, 0:IDX_NOPE_HEAD_DIM], target_type=pl.BF16, mode='rint')
                        tail_qr_rope_slice = tail_qr_dequant[:, IDX_NOPE_HEAD_DIM:IDX_HEAD_DIM]
                        tail_qr_swapped = pl.gather(tail_qr_rope_slice, dim=-1, index=tail_swap_idx)
                        tail_rope_rot = pl.add(pl.mul(tail_qr_rope_slice, tail_cos_tile), pl.mul(tail_qr_swapped, tail_sin_tile))
                        tail_rope_bf16 = pl.cast(tail_rope_rot, target_type=pl.BF16, mode='rint')
                        qr_bf16_2d[tail_t0:tail_t0 + 1, tail_h0:tail_h0 + IDX_NOPE_HEAD_DIM] = tail_qr_nope_bf16
                        qr_bf16_2d[tail_t0:tail_t0 + 1, tail_h0 + IDX_NOPE_HEAD_DIM:tail_h0 + IDX_HEAD_DIM] = tail_rope_bf16
    return idx_qr_mm_tid

@pl.jit.inline(auto_scope=False)
def indexer_qr_hadamard_mm(x: pl.Tensor[[T_DYN, D], pl.BF16], qr_bf16: pl.Tensor[[T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], pl.BF16], hadamard: pl.Tensor[[IDX_HEAD_DIM, IDX_HEAD_DIM], pl.BF16], qr_hadamard_i8: pl.Out[pl.Tensor[[T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], pl.INT8]], qr_hadamard_scale_dq: pl.Out[pl.Tensor[[T_PAD * IDX_N_HEADS, 1], pl.FP32]], qh_mm_dep: pl.Scalar[pl.TASK_ID], debug_packet: pl.InOut[pl.Tensor[[1048576], pl.INT32]]) -> tuple[pl.Scalar[pl.TASK_ID], pl.Scalar[pl.TASK_ID]]:
    """q @ hadamard and its INT8 quant, fenced behind the caller's cube ordering."""
    bs = pl.tensor.dim(x, 0)
    bs_heads = bs * IDX_N_HEADS
    qh_acc_gm = pl.create_tensor([bs_heads, IDX_HEAD_DIM], dtype=pl.FP32)
    with pl.spmd(QH_WORKERS, name_hint='qr_hadamard_matmul', deps=[qh_mm_dep], allow_early_resolve=True) as qh_mm_tid:
        qh_worker = pl.tile.get_block_idx()
        qh_hadamard = hadamard[0:IDX_HEAD_DIM, 0:IDX_HEAD_DIM]
        for idx in pl.range(qh_worker, bs_heads // QH_MM_TILE, QH_WORKERS):
            o0 = idx * QH_MM_TILE
            qh_acc = pl.matmul(qr_bf16[o0:o0 + QH_MM_TILE, :], qh_hadamard, out_dtype=pl.FP32)
            qh_acc_gm[o0:o0 + QH_MM_TILE, :] = qh_acc
    debug_hadamard = pl.reshape(qh_acc_gm, [bs, 8192])
    export_ihadamard_scaled(debug_hadamard, debug_packet)
    with pl.spmd(QH_QUANT_WORKERS, name_hint='qr_hadamard_quant', allow_early_resolve=True) as qh_quant_tid:
        qh_quant_worker = pl.tile.get_block_idx()
        for idx in pl.range(qh_quant_worker, bs_heads // QH_QUANT_TILE, QH_QUANT_WORKERS):
            o0 = idx * QH_QUANT_TILE
            qh_full_f32 = qh_acc_gm[o0:o0 + QH_QUANT_TILE, 0:IDX_HEAD_DIM]
            qh_full_f32 = pl.cast(pl.cast(qh_full_f32, pl.BF16, mode='rint'), pl.FP32)
            qh_full_f32 = pl.cast(pl.cast(pl.mul(qh_full_f32, HADAMARD_SCALE), pl.BF16, mode='rint'), pl.FP32)
            qh_amax = pl.full([1, QH_QUANT_TILE], dtype=pl.FP32, value=INT8_AMAX_EPS)
            for h0 in pl.range(0, IDX_HEAD_DIM, QH_HEAD_DIM_TILE):
                qh_a_f32 = qh_full_f32[:, h0:h0 + QH_HEAD_DIM_TILE]
                qh_a_neg = pl.neg(qh_a_f32)
                qh_a_abs = pl.maximum(qh_a_f32, qh_a_neg)
                qh_a_max_col = pl.row_max(qh_a_abs)
                qh_a_max = pl.reshape(qh_a_max_col, [1, QH_QUANT_TILE])
                qh_amax = pl.maximum(qh_amax, qh_a_max)
            qh_scale_numerator = pl.full([1, QH_QUANT_TILE], dtype=pl.FP32, value=INT8_SCALE_MAX)
            qh_scale_quant_row = pl.div(qh_scale_numerator, qh_amax)
            qh_scale_recip = pl.recip(qh_scale_quant_row)
            qh_scale_dq = pl.reshape(qh_scale_recip, [QH_QUANT_TILE, 1])
            qr_hadamard_scale_dq[o0:o0 + QH_QUANT_TILE, :] = pl.cast(pl.cast(qh_scale_dq, pl.FP16, mode='rint'), pl.FP32)
            qh_scale_quant = pl.reshape(qh_scale_quant_row, [QH_QUANT_TILE, 1])
            qh_q_scaled = pl.row_expand_mul(qh_full_f32, qh_scale_quant)
            qh_q_i32 = pl.cast(qh_q_scaled, target_type=pl.INT32, mode='rint')
            qh_q_half = pl.cast(qh_q_i32, target_type=pl.FP16, mode='round')
            qh_i8 = pl.cast(qh_q_half, target_type=pl.INT8, mode='trunc')
            qr_hadamard_i8[o0:o0 + QH_QUANT_TILE, 0:IDX_HEAD_DIM] = qh_i8
    return (qh_mm_tid, qh_quant_tid)

@pl.jit.inline(auto_scope=False)
def indexer_qr_hadamard(x: pl.Tensor[[T_DYN, D], pl.BF16], qr: pl.Tensor[[T_DYN, Q_LORA], pl.INT8], qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32], wq_b: pl.Tensor[[Q_LORA, IDX_N_HEADS * IDX_HEAD_DIM], pl.INT8], wq_b_scale: pl.Tensor[[IDX_N_HEADS * IDX_HEAD_DIM], pl.FP32], cos: pl.Tensor[[T_DYN, ROPE_HEAD_DIM], pl.FP32], sin: pl.Tensor[[T_DYN, ROPE_HEAD_DIM], pl.FP32], hadamard: pl.Tensor[[IDX_HEAD_DIM, IDX_HEAD_DIM], pl.BF16], qr_hadamard_i8: pl.Out[pl.Tensor[[T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], pl.INT8]], qr_hadamard_scale_dq: pl.Out[pl.Tensor[[T_PAD * IDX_N_HEADS, 1], pl.FP32]], debug_packet: pl.InOut[pl.Tensor[[1048576], pl.INT32]]):
    """Query half of the indexer: qr projection, rope, hadamard, and INT8 quant."""
    qr_bf16 = pl.create_tensor([T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], dtype=pl.BF16)
    idx_qr_mm_tid = indexer_qr_rope(x, qr, qr_scale, wq_b, wq_b_scale, cos, sin, qr_bf16)
    debug_irope = pl.reshape(qr_bf16, [T_PAD, 8192])
    export_irope(debug_irope, debug_packet)
    qh_mm_tid, qh_quant_tid = indexer_qr_hadamard_mm(x, qr_bf16, hadamard, qr_hadamard_i8, qr_hadamard_scale_dq, idx_qr_mm_tid, debug_packet)
    return (qh_mm_tid, qh_quant_tid, idx_qr_mm_tid)
