import pypto.language as pl
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.decode_csa import T_DYN,T_PAD

@pl.jit.inline(auto_scope=False)
def export_mixed(source: pl.Tensor[[T_DYN,4096],pl.BF16], packet: pl.InOut[pl.Tensor[[1048576],pl.INT32]]):
    packet2=pl.reshape(packet,[1,1048576])
    with pl.spmd(8,name_hint="debug_mixed"):
        for block in pl.range(pl.tile.get_block_idx(),32,8):
            row=86
            if block >= 16:
                row=103
            col=(block % 16)*256
            tile=pl.load(source,[row,col],[1,256],valid_shape=[1,pl.min(256,4096-col)])
            widened=pl.cast(tile,pl.FP32)
            bits=pl.tile.reinterpret_view(widened,pl.INT32)
            valid=pl.set_validshape(bits,1,pl.min(256,4096-col))
            pl.store(valid,[0,2816+block*256],packet2)

@pl.jit.inline(auto_scope=False)
def export_normed(source: pl.Tensor[[T_DYN,4096],pl.BF16], packet: pl.InOut[pl.Tensor[[1048576],pl.INT32]]):
    packet2=pl.reshape(packet,[1,1048576])
    with pl.spmd(8,name_hint="debug_normed"):
        for block in pl.range(pl.tile.get_block_idx(),32,8):
            row=86
            if block >= 16:
                row=103
            col=(block % 16)*256
            tile=pl.load(source,[row,col],[1,256],valid_shape=[1,pl.min(256,4096-col)])
            widened=pl.cast(tile,pl.FP32)
            bits=pl.tile.reinterpret_view(widened,pl.INT32)
            valid=pl.set_validshape(bits,1,pl.min(256,4096-col))
            pl.store(valid,[0,11264+block*256],packet2)

@pl.jit.inline(auto_scope=False)
def export_post(source: pl.Tensor[[T_DYN,4],pl.FP32], packet: pl.InOut[pl.Tensor[[1048576],pl.INT32]]):
    packet2=pl.reshape(packet,[1,1048576])
    with pl.spmd(8,name_hint="debug_post"):
        for block in pl.range(pl.tile.get_block_idx(),2,8):
            row=86
            if block >= 1:
                row=103
            col=(block % 1)*256
            tile=pl.load(source,[row,col],[1,256],valid_shape=[1,pl.min(256,4-col)])
            widened=tile
            bits=pl.tile.reinterpret_view(widened,pl.INT32)
            valid=pl.set_validshape(bits,1,pl.min(256,4-col))
            pl.store(valid,[0,19712+block*256],packet2)

@pl.jit.inline(auto_scope=False)
def export_comb(source: pl.Tensor[[T_DYN,16],pl.FP32], packet: pl.InOut[pl.Tensor[[1048576],pl.INT32]]):
    packet2=pl.reshape(packet,[1,1048576])
    with pl.spmd(8,name_hint="debug_comb"):
        for block in pl.range(pl.tile.get_block_idx(),2,8):
            row=86
            if block >= 1:
                row=103
            col=(block % 1)*256
            tile=pl.load(source,[row,col],[1,256],valid_shape=[1,pl.min(256,16-col)])
            widened=tile
            bits=pl.tile.reinterpret_view(widened,pl.INT32)
            valid=pl.set_validshape(bits,1,pl.min(256,16-col))
            pl.store(valid,[0,20480+block*256],packet2)

@pl.jit.inline(auto_scope=False)
def export_indexer_weights(source: pl.Tensor[[T_DYN,64],pl.FP16], packet: pl.InOut[pl.Tensor[[1048576],pl.INT32]]):
    packet2=pl.reshape(packet,[1,1048576])
    with pl.spmd(8,name_hint="debug_indexer_weights"):
        for block in pl.range(pl.tile.get_block_idx(),2,8):
            row=86
            if block >= 1:
                row=103
            col=(block % 1)*256
            tile=pl.load(source,[row,col],[1,256],valid_shape=[1,pl.min(256,64-col)])
            widened=pl.cast(tile,pl.FP32)
            bits=pl.tile.reinterpret_view(widened,pl.INT32)
            valid=pl.set_validshape(bits,1,pl.min(256,64-col))
            pl.store(valid,[0,21248+block*256],packet2)

@pl.jit.inline(auto_scope=False)
def export_q(source: pl.Tensor[[T_DYN,32768],pl.BF16], packet: pl.InOut[pl.Tensor[[1048576],pl.INT32]]):
    packet2=pl.reshape(packet,[1,1048576])
    with pl.spmd(8,name_hint="debug_q"):
        for block in pl.range(pl.tile.get_block_idx(),256,8):
            row=86
            if block >= 128:
                row=103
            col=(block % 128)*256
            tile=pl.load(source,[row,col],[1,256],valid_shape=[1,pl.min(256,32768-col)])
            widened=pl.cast(tile,pl.FP32)
            bits=pl.tile.reinterpret_view(widened,pl.INT32)
            valid=pl.set_validshape(bits,1,pl.min(256,32768-col))
            pl.store(valid,[0,22016+block*256],packet2)

@pl.jit.inline(auto_scope=False)
def export_heads(source: pl.Tensor[[T_DYN,32768],pl.BF16], packet: pl.InOut[pl.Tensor[[1048576],pl.INT32]]):
    packet2=pl.reshape(packet,[1,1048576])
    with pl.spmd(8,name_hint="debug_heads"):
        for block in pl.range(pl.tile.get_block_idx(),256,8):
            row=86
            if block >= 128:
                row=103
            col=(block % 128)*256
            tile=pl.load(source,[row,col],[1,256],valid_shape=[1,pl.min(256,32768-col)])
            widened=pl.cast(tile,pl.FP32)
            bits=pl.tile.reinterpret_view(widened,pl.INT32)
            valid=pl.set_validshape(bits,1,pl.min(256,32768-col))
            pl.store(valid,[0,87808+block*256],packet2)

@pl.jit.inline(auto_scope=False)
def export_projected_o(source: pl.Tensor[[T_DYN,8192],pl.BF16], packet: pl.InOut[pl.Tensor[[1048576],pl.INT32]]):
    packet2=pl.reshape(packet,[1,1048576])
    with pl.spmd(8,name_hint="debug_projected_o"):
        for block in pl.range(pl.tile.get_block_idx(),64,8):
            row=86
            if block >= 32:
                row=103
            col=(block % 32)*256
            tile=pl.load(source,[row,col],[1,256],valid_shape=[1,pl.min(256,8192-col)])
            widened=pl.cast(tile,pl.FP32)
            bits=pl.tile.reinterpret_view(widened,pl.INT32)
            valid=pl.set_validshape(bits,1,pl.min(256,8192-col))
            pl.store(valid,[0,153600+block*256],packet2)

@pl.jit.inline(auto_scope=False)
def export_attention_out(source: pl.Tensor[[T_DYN,4096],pl.BF16], packet: pl.InOut[pl.Tensor[[1048576],pl.INT32]]):
    packet2=pl.reshape(packet,[1,1048576])
    with pl.spmd(8,name_hint="debug_attention_out"):
        for block in pl.range(pl.tile.get_block_idx(),32,8):
            row=86
            if block >= 16:
                row=103
            col=(block % 16)*256
            tile=pl.load(source,[row,col],[1,256],valid_shape=[1,pl.min(256,4096-col)])
            widened=pl.cast(tile,pl.FP32)
            bits=pl.tile.reinterpret_view(widened,pl.INT32)
            valid=pl.set_validshape(bits,1,pl.min(256,4096-col))
            pl.store(valid,[0,170240+block*256],packet2)

@pl.jit.inline(auto_scope=False)
def export_iq(source: pl.Tensor[[T_PAD,8192],pl.INT8], packet: pl.InOut[pl.Tensor[[1048576],pl.INT32]]):
    packet2=pl.reshape(packet,[1,1048576])
    with pl.spmd(8,name_hint="debug_iq"):
        for block in pl.range(pl.tile.get_block_idx(),64,8):
            row=86
            if block >= 32:
                row=103
            col=(block % 32)*256
            tile=pl.load(source,[row,col],[1,256],valid_shape=[1,pl.min(256,8192-col)])
            widened=pl.cast(pl.cast(tile,pl.FP16),pl.FP32)
            bits=pl.tile.reinterpret_view(widened,pl.INT32)
            valid=pl.set_validshape(bits,1,pl.min(256,8192-col))
            pl.store(valid,[0,178688+block*256],packet2)

@pl.jit.inline(auto_scope=False)
def export_iscale(source: pl.Tensor[[T_PAD,64],pl.FP32], packet: pl.InOut[pl.Tensor[[1048576],pl.INT32]]):
    packet2=pl.reshape(packet,[1,1048576])
    with pl.spmd(8,name_hint="debug_iscale"):
        for block in pl.range(pl.tile.get_block_idx(),2,8):
            row=86
            if block >= 1:
                row=103
            col=(block % 1)*256
            tile=pl.load(source,[row,col],[1,256],valid_shape=[1,pl.min(256,64-col)])
            widened=tile
            bits=pl.tile.reinterpret_view(widened,pl.INT32)
            valid=pl.set_validshape(bits,1,pl.min(256,64-col))
            pl.store(valid,[0,195328+block*256],packet2)

@pl.jit.inline(auto_scope=False)
def export_qr(source: pl.Tensor[[T_DYN,1024],pl.INT8], packet: pl.InOut[pl.Tensor[[1048576],pl.INT32]]):
    packet2=pl.reshape(packet,[1,1048576])
    with pl.spmd(8,name_hint="debug_qr"):
        for block in pl.range(pl.tile.get_block_idx(),8,8):
            row=86
            if block >= 4:
                row=103
            col=(block % 4)*256
            tile=pl.load(source,[row,col],[1,256],valid_shape=[1,pl.min(256,1024-col)])
            widened=pl.cast(pl.cast(tile,pl.FP16),pl.FP32)
            bits=pl.tile.reinterpret_view(widened,pl.INT32)
            valid=pl.set_validshape(bits,1,pl.min(256,1024-col))
            pl.store(valid,[0,196096+block*256],packet2)

@pl.jit.inline(auto_scope=False)
def export_qr_scale(source: pl.Tensor[[T_DYN,1],pl.FP32], packet: pl.InOut[pl.Tensor[[1048576],pl.INT32]]):
    packet2=pl.reshape(packet,[1,1048576])
    flat_source=pl.reshape(source,[1,126])
    with pl.spmd(8,name_hint="debug_qr_scale"):
        for block in pl.range(pl.tile.get_block_idx(),2,8):
            row=86
            if block>=1:
                row=103
            value=pl.load(flat_source,[0,row],[1,8])
            bits=pl.tile.reinterpret_view(value,pl.INT32)
            pl.store(pl.set_validshape(bits,1,1),[0,198400+block*256],packet2)

@pl.jit.inline(auto_scope=False)
def export_irope(source: pl.Tensor[[T_PAD,8192],pl.BF16], packet: pl.InOut[pl.Tensor[[1048576],pl.INT32]]):
    packet2=pl.reshape(packet,[1,1048576])
    with pl.spmd(8,name_hint="debug_irope"):
        for block in pl.range(pl.tile.get_block_idx(),64,8):
            row=86
            if block >= 32:
                row=103
            col=(block % 32)*256
            tile=pl.load(source,[row,col],[1,256],valid_shape=[1,pl.min(256,8192-col)])
            widened=pl.cast(tile,pl.FP32)
            bits=pl.tile.reinterpret_view(widened,pl.INT32)
            valid=pl.set_validshape(bits,1,pl.min(256,8192-col))
            pl.store(valid,[0,199168+block*256],packet2)

@pl.jit.inline(auto_scope=False)
def export_ihadamard_scaled(source: pl.Tensor[[T_DYN,8192],pl.FP32], packet: pl.InOut[pl.Tensor[[1048576],pl.INT32]]):
    packet2=pl.reshape(packet,[1,1048576])
    with pl.spmd(8,name_hint="debug_ihadamard_scaled"):
        for block in pl.range(pl.tile.get_block_idx(),64,8):
            row=86
            if block >= 32:
                row=103
            col=(block % 32)*256
            tile=pl.load(source,[row,col],[1,256],valid_shape=[1,pl.min(256,8192-col)])
            widened=pl.cast(pl.cast(pl.mul(pl.cast(pl.cast(tile,pl.BF16,mode="rint"),pl.FP32),128**-0.5),pl.BF16,mode="rint"),pl.FP32)
            bits=pl.tile.reinterpret_view(widened,pl.INT32)
            valid=pl.set_validshape(bits,1,pl.min(256,8192-col))
            pl.store(valid,[0,215808+block*256],packet2)
