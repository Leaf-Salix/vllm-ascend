"""Retain observer invariance checks, add packet and native export guards."""
import hashlib,json
from pathlib import Path
r=Path(__file__).resolve().parent
p=r/'tools/probe_csa.py'
s=p.read_text()
# Preserve failed 75-argument helper.
b=r/'failed75/probe_csa.py'
if not b.exists():b.write_text(s)
s=b.read_text()
s=s.replace("native_debug={}; stage_debug={}; qli_kwargs={}; qli_buffers={}","""native_debug={}; qli_kwargs={}; qli_buffers={}; debug_allocations={}
layout=json.loads((experiment/'t126-fix-20261020/exports.json').read_text())
def guarded_debug(name,shape,dtype):
    count=1
    for d in shape:count*=d
    allocation=torch.full((count+128,),37,dtype=dtype,device='npu:0')
    view=allocation[64:64+count].view(shape)
    debug_allocations[name]=(allocation,view)
    return view
def check_debug_guards():
    for n,(allocation,view) in debug_allocations.items():
        assert bool((allocation[:64]==37).all()) and bool((allocation[-64:]==37).all()),('debug guard',n)
def poison_debug():
    for n,(allocation,view) in debug_allocations.items():
        if n=='packet':
            view[2560:].fill_(0x7fc00000)
        elif view.is_floating_point():view.fill_(float('nan'))
        else:view.fill_(-111)
""")
s=s.replace("        stage_debug[n]=torch.empty(shape,dtype=dtype,device='npu:0')\n        if n not in ('iq','iscale','indexer_weights'):native_debug[n]=torch.empty(shape,dtype=dtype,device='npu:0')", "        if n not in ('iq','iscale','indexer_weights'):native_debug[n]=guarded_debug(n,shape,dtype)\n    debug_packet=guarded_debug('packet',(layout['packet_size'],),torch.int32)")
s=s.replace("qli_buffers[n]=torch.empty_like(kwargs[n])","qli_buffers[n]=guarded_debug('qli_'+n,tuple(kwargs[n].shape),kwargs[n].dtype)")
s=s.replace("            export_names=list(specs)","            order_index=next(i for i,a in enumerate(probe_op._schema.arguments) if a.name=='order_packet')")
s=s.replace("                    return probe_op(*values,*[stage_debug[n] for n in export_names])", "                    debug_packet[:2560].copy_(values[order_index])\n                    self.selected_order=values[order_index]\n                    values=list(values);values[order_index]=debug_packet\n                    return probe_op(*values)")
s=s.replace('==75','==64')
s=s.replace("assert probe_receipt['compiled'] and probe_receipt['kernel_abi_pass']","assert probe_receipt['compiled'] and probe_receipt['kernel_abi_pass']\nassert probe_receipt['exports_sha256']==hashlib.sha256((experiment/'t126-fix-20261020/exports.json').read_bytes()).hexdigest()\nassert probe_receipt['formal_receipt_sha256']==hashlib.sha256((experiment/'compile-full-csa-bf16layout.json').read_bytes()).hexdigest()")
s=s.replace("restore(f);output.fill_(float('nan'));topk.fill_(-12345);graph.replay();torch.npu.synchronize()", "restore(f);output.fill_(float('nan'));topk.fill_(-12345);poison_debug();graph.replay();torch.npu.synchronize();check_debug_guards()")
s=s.replace("            pto_export={n:v.cpu().clone() for n,v in stage_debug.items()}\n            pto_export['iq']=pto_export['iq'][:tokens*64]\n            pto_export['iscale']=pto_export['iscale'][:tokens*64]", """            packet_cpu=debug_packet.cpu()\n            assert exact(packet_cpu[:2560],runtime.operators.attention.selected_order.cpu()),'original order payload changed'
            pto_export={}
            allowed=torch.zeros(layout['packet_size'],dtype=torch.bool);allowed[:2560]=True
            for n,entry in layout['stages'].items():
                off=entry['offset'];stride=entry['blocks']*256;width=entry['width']
                pto_export[n]=torch.stack([packet_cpu[off+j*stride:off+j*stride+width].view(torch.float32) for j in (0,1)])
                for j in (0,1):allowed[off+j*stride:off+j*stride+width]=True
                assert bool(torch.isfinite(pto_export[n]).all()),('missing or nonfinite export',n)
            assert bool((packet_cpu[~allowed]==0x7fc00000).all()),'packet gaps overwritten'
            native_export={n:v.reshape(tokens,-1)[[86,103]].float() for n,v in native_export.items()}
            report['debug_guards_pass']=True""")
s=s.replace("pto_export[n].reshape(tokens,-1)[row],native_export[n].reshape(tokens,-1)[row]", "pto_export[n][j],native_export[n][j]")
s=s.replace("for row in (86,103)}", "for j,row in enumerate((86,103))}")
p.write_text(s)
names=json.loads((r/'tools/manifest.json').read_text());(r/'tools/manifest.json').write_text(json.dumps({n:hashlib.sha256((r/'tools'/n).read_bytes()).hexdigest() for n in names},indent=2)+'\n')
print('PACKED_HELPER_READY')
