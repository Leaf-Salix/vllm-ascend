"""CPU analysis of saved actual stage data; never a fabricated Native golden."""
import json,os
from pathlib import Path
import torch
exp=Path(os.environ['SPMD_EXPERIMENT']);out=exp/'results/t126-query-stage-v3'
s=torch.load(out/'stages.pt',map_location='cpu',weights_only=False)
record={'stages':{}}
for n,a in s['native'].items():
 b=s['pto'][n];difference=a!=b
 record['stages'][n]={'rows':{str(row):{'count':int(difference[j].sum()),'coordinates':difference[j].nonzero().flatten()[:40].tolist()} for j,row in enumerate((86,103))}}
x=s['native_aux']['q_before_rms'].reshape(126,64,512).float()
y=s['native_aux']['q_after_rms'].reshape(126,64,512)
square=x*x
f04=square[:,:,:64]+square[:,:,256:320]
f15=square[:,:,64:128]+square[:,:,320:384]
f26=square[:,:,128:192]+square[:,:,384:448]
f37=square[:,:,192:256]+square[:,:,448:512]
f64=(f04+f26)+(f15+f37)
def halve(v):
 while v.shape[-1]>1:
  half=v.shape[-1]//2;v=v[...,:half]+v[...,half:]
 return v
variants={'cpu_sum':square.sum(-1,keepdim=True),'fold64_sum':f64.sum(-1,keepdim=True),'fold64_half':halve(f64),'fp64_round':square.double().sum(-1,keepdim=True).float()}
record['cpu_rms_reconstructions_not_native_goldens']={}
for n,total in variants.items():
 inv=torch.rsqrt(total*(1.0/512)+1e-6)
 reconstructed=(x*inv).bfloat16();d=reconstructed!=y
 record['cpu_rms_reconstructions_not_native_goldens'][n]={'total_different':int(d.sum()),'rows':{str(row):{'count':int(d[row].sum()),'heads':d[row].any(-1).nonzero().flatten().tolist()} for row in (86,103)}}
(out/'cpu-stage-analysis.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
