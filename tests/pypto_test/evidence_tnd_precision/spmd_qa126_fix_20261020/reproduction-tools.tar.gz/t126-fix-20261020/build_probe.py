"""Build a FULL observer with explicit original-output invariance guards."""
import hashlib
import json
import shutil
from pathlib import Path

here=Path(__file__).resolve().parent;r=here.parent
d=here/'tools';d.mkdir(exist_ok=False)
for p in (r/'bf16layout-full-tools').iterdir():
 if p.is_file():shutil.copy2(p,d/p.name)
p=d/'probe_csa.py';s=p.read_text()
needle="class NativeHalf(torch.nn.Module):"
extra="""native_debug={}; stage_debug={}; qli_kwargs={}; qli_buffers={}
sys.path.insert(0,str(experiment/'t126-fix-20261020'))
probe_name='vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.t126_diagnostic_root'
spec=importlib.util.spec_from_file_location(probe_name,experiment/'t126-fix-20261020/t126_diagnostic_root.py')
probe_root=importlib.util.module_from_spec(spec);sys.modules[probe_name]=probe_root;spec.loader.exec_module(probe_root)
probe_receipt=json.loads((experiment/'t126-fix-20261020/compile-receipt.json').read_text())
assert probe_receipt['compiled'] and probe_receipt['kernel_abi_pass']
for n,h in probe_receipt['sources'].items():assert hashlib.sha256((experiment/'t126-fix-20261020'/n).read_bytes()).hexdigest()==h
report['diagnostic_sources']=probe_receipt['sources']
"""
assert needle in s;s=s.replace(needle,extra+'\n'+needle)
needle='        normed=l.input_layernorm(mixed)'
s=s.replace(needle,"""        native_debug['mixed'].copy_(mixed)
        native_debug['post'].copy_(post.reshape(tokens,-1))
        native_debug['comb'].copy_(comb.reshape(tokens,-1))
        normed=l.input_layernorm(mixed)
        native_debug['normed'].copy_(normed)""")
s=s.replace('        output.copy_(l.hc_post(attended,hidden,post,comb))',"        native_debug['attention_out'].copy_(attended)\n        output.copy_(l.hc_post(attended,hidden,post,comb))")
needle="    original_qli=torch.ops._C_ascend.npu_vllm_quant_lightning_indexer"
extra="""    specs={
      'mixed':((tokens,4096),torch.bfloat16),'normed':((tokens,4096),torch.bfloat16),
      'post':((tokens,4),torch.float32),'comb':((tokens,16),torch.float32),
      'indexer_weights':((tokens,64),torch.float16),
      'q':((tokens,formal_root.H*formal_root.HEAD_DIM),torch.bfloat16),
      'heads':((tokens,formal_root.H*formal_root.HEAD_DIM),torch.bfloat16),
      'projected_o':((tokens,formal_root.O_GROUPS*formal_root.O_LORA),torch.bfloat16),
      'attention_out':((tokens,4096),torch.bfloat16),
      'iq':((probe_root.T_PAD*64,128),torch.int8),
      'iscale':((probe_root.T_PAD*64,1),torch.float32)}
    for n,(shape,dtype) in specs.items():
        stage_debug[n]=torch.empty(shape,dtype=dtype,device='npu:0')
        if n not in ('iq','iscale','indexer_weights'):native_debug[n]=torch.empty(shape,dtype=dtype,device='npu:0')
    original_get_attn=DeviceOperator.get_dsa_sparse_attn_op
    def get_observed_attn():
        op=original_get_attn()
        def observed_attn(q,*values,**kwargs):
            native_debug['q'].copy_(q.reshape(tokens,-1))
            return op(q,*values,**kwargs)
        return observed_attn
    DeviceOperator.get_dsa_sparse_attn_op=staticmethod(get_observed_attn)
    original_oproj=impl._forward_o_proj
    def observed_oproj(owner,heads,output):
        native_debug['heads'].copy_(heads.reshape(tokens,-1))
        return original_oproj(heads,output)
    impl._forward_o_proj=types.MethodType(observed_oproj,impl)
    original_b=impl.wo_b.forward
    def observed_b(owner,hidden,*values,**kwargs):
        native_debug['projected_o'].copy_(hidden.reshape(tokens,-1))
        return original_b(hidden,*values,**kwargs)
    impl.wo_b.forward=types.MethodType(observed_b,impl.wo_b)
"""
assert needle in s;s=s.replace(needle,extra+'\n'+needle)
s=s.replace('from dsv4_csa_native_case import native_session','from dsv4_csa_native_case import native_session\nfrom vllm_ascend.device.device_op import DeviceOperator')
needle="        result=original_qli(*values,**kwargs);observed['topk']=result[0];return result"
replacement="""        if not qli_kwargs:
            qli_kwargs.update(kwargs)
            for n in ('query','weights','query_dequant_scale'):qli_buffers[n]=torch.empty_like(kwargs[n])
        for n,v in qli_buffers.items():v.copy_(kwargs[n])
        result=original_qli(*values,**kwargs);observed['topk']=result[0];return result"""
assert needle in s;s=s.replace(needle,replacement)
needle='            operators=CSAOperators.register()'
extra="""            original_ops=CSAOperators.register()
            probe_op=pypto.torch.register(probe_root.decode_csa_tp1_layer_test,'t126_stage_probe::attention')
            export_names=list(specs)
            class DiagnosticAdapter:
                _schema=original_ops.attention._schema
                def __call__(self,*values):
                    return probe_op(*values,*[stage_debug[n] for n in export_names])
            operators=type(original_ops)(DiagnosticAdapter(),original_ops.workspace)
            report['diagnostic_actual_root_schema']=str(probe_op._schema)
            assert len(probe_op._schema.arguments)==75
"""
assert needle in s;s=s.replace(needle,extra)
needle="        if arm!='native':\n            checks={name:metric(value,states['native'][name]) for name,value in actual.items()}"
extra="""        reference=torch.load(experiment/'results/bf16layout-full-t126-v1/first-difference.pt',map_location='cpu',weights_only=False)
        invariant={n:exact(v,reference['states'][arm][n]) for n,v in actual.items()}
        report.setdefault('original_output_invariance',{})[arm]=invariant;save()
        assert all(invariant.values()),arm+': observer changed original outputs; invalid diagnostic'
        if arm=='native':
            native_export={n:v.cpu().clone() for n,v in native_debug.items()}
            native_export['indexer_weights']=qli_buffers['weights'].cpu().reshape(tokens,64)
            native_export['iq']=qli_buffers['query'].cpu().reshape(tokens*64,128)
            native_export['iscale']=qli_buffers['query_dequant_scale'].cpu().float().reshape(tokens*64,1)
        else:
            pto_export={n:v.cpu().clone() for n,v in stage_debug.items()}
            pto_export['iq']=pto_export['iq'][:tokens*64]
            pto_export['iscale']=pto_export['iscale'][:tokens*64]
            checks={n:metric(pto_export[n],native_export[n]) for n in native_export}
            report['stage_comparisons']=checks
            report['row_comparisons']={str(row):{n:metric(pto_export[n].reshape(tokens,-1)[row],native_export[n].reshape(tokens,-1)[row]) for n in native_export} for row in (86,103)}
            torch.save({'native':native_export,'pto':pto_export,'native_topk':states['native']['idx_topk'],'pto_topk':actual['idx_topk'],'pto_scores':runtime.scores[:tokens].cpu()},args.out/'stages.pt')
            report['diagnostic_complete']=True
            report['precision_pass']=False
            save();print('STAGES_EXPORTED',json.dumps(report['row_comparisons']),flush=True)
            break
"""
assert needle in s;s=s.replace(needle,extra+needle)
# This diagnostic deliberately stops after its same-input stage export.
start=s.index('    # Reproduce vLLM:')
end=s.index('except Exception as exc:',start)
s=s[:start]+"    save()\n"+s[end:]
p.write_text(s)
p=d/'run-full-csa.sh';p.write_text(p.read_text().replace('bf16layout-full-tools/probe_csa.py','t126-fix-20261020/tools/probe_csa.py'))
names=json.loads((d/'manifest.json').read_text());(d/'manifest.json').write_text(json.dumps({n:hashlib.sha256((d/n).read_bytes()).hexdigest() for n in names},indent=2)+'\n')
print('STAGE_PROBE_HELPER_READY')
