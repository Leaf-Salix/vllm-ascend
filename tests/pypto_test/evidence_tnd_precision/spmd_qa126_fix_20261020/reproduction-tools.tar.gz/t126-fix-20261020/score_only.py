"""Isolate original score/sort with saved actual Native QLI inputs."""
import hashlib,json,os,sys
from pathlib import Path
import torch
import pypto.language as pl
import pypto.torch
from pypto.runtime import RunConfig
import vllm_ascend.ops.pypto as ns
exp=Path(os.environ['SPMD_EXPERIMENT']);here=exp/'t126-fix-20261020'
ns.__path__.insert(0,str(exp/'src/vllm_ascend/ops/pypto'))
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.decode_indexer import (
    T_PAD,IDX_N_HEADS,IDX_HEAD_DIM,IDX_TOPK,T_DYN,B_DYN,QUERY_BOUNDS_DYN,
    IDX_NATIVE_CACHE_BLOCK_NUM_DYN,INDEXER_PAGE_BYTES_DYN,INDEXER_TABLE_COLUMNS_DYN,
    indexer_score_topk_forest,
)
@pl.jit

def score_test(
    query:pl.Tensor[[T_PAD*64,128],pl.INT8],
    scale:pl.Tensor[[T_PAD*64,1],pl.FP32],
    weight:pl.Tensor[[T_PAD,64],pl.FP32],
    cache:pl.Tensor[[IDX_NATIVE_CACHE_BLOCK_NUM_DYN,INDEXER_PAGE_BYTES_DYN],pl.INT8],
    table:pl.Tensor[[B_DYN,INDEXER_TABLE_COLUMNS_DYN],pl.INT32],
    position:pl.Tensor[[T_DYN],pl.INT64],
    lengths:pl.Tensor[[B_DYN],pl.INT32],
    request:pl.Tensor[[T_DYN],pl.INT32],
    bounds:pl.Tensor[[QUERY_BOUNDS_DYN],pl.INT32],
    scores:pl.Out[pl.Tensor[[T_DYN,IDX_TOPK],pl.FP32]],
    topk:pl.Out[pl.Tensor[[T_DYN,IDX_TOPK],pl.INT32]],
):
    cache.bind_dynamic(0,IDX_NATIVE_CACHE_BLOCK_NUM_DYN)
    cache.bind_dynamic(1,INDEXER_PAGE_BYTES_DYN)
    table.bind_dynamic(0,B_DYN);table.bind_dynamic(1,INDEXER_TABLE_COLUMNS_DYN)
    position.bind_dynamic(0,T_DYN);lengths.bind_dynamic(0,B_DYN)
    request.bind_dynamic(0,T_DYN);bounds.bind_dynamic(0,QUERY_BOUNDS_DYN)
    scores.bind_dynamic(0,T_DYN);topk.bind_dynamic(0,T_DYN)
    maximum=0
    for b in pl.range(pl.tensor.dim(lengths,0)):
        maximum=pl.max(maximum,pl.read(lengths,[b]))
    ready=pl.system.task_dummy(deps=[])
    indexer_score_topk_forest(query,scale,weight,cache,table,position,lengths,request,bounds,scores,topk,ready,ready,ready,maximum)
    return topk

if __name__=='__main__':
    if '--compile' in sys.argv:
        assert os.environ['ASCEND_RT_VISIBLE_DEVICES']==''
        score_test.compile(config=RunConfig(platform='a2a3',save_kernels=True,save_kernels_dir=str(here/'score-artifact')))
        from pypto.runtime.kernel_compiler import KernelCompiler
        p=here/'score-artifact/orchestration/score_test.cpp'
        KernelCompiler().compile_orchestration('tensormap_and_ringbuffer',str(p))
        op=pypto.torch.register(score_test,'t126_score_only::run')
        assert len(op._schema.arguments)==11
        print('SCORE_ACTUAL_COMPILE_PASS',flush=True)
    else:
        import torch_npu
        assert os.environ['TASK_DEVICE']
        torch.npu.set_device(0);torch_npu.npu.set_deterministic_level(1)
        torch.npu.config.allow_internal_format=True
        pypto.torch.init()
        d=torch.load(exp/'results/t126-packed-stage-v2/native-qli-inputs.pt',map_location='cpu',weights_only=False)
        s=torch.load(exp/'results/t126-packed-stage-v2/stages.pt',map_location='cpu',weights_only=False)
        q=d['query'];t=q.shape[0];pages=d['key'].shape[0]
        query=torch.zeros((T_PAD*64,128),dtype=torch.int8);query[:t*64].copy_(q.reshape(t*64,128))
        scale=torch.zeros((T_PAD*64,1));scale[:t*64].copy_(d['query_dequant_scale'].reshape(t*64,1))
        weight=torch.zeros((T_PAD,64));weight[:t].copy_(d['weights'])
        cache=torch.cat([d['key'].contiguous().reshape(pages,4096),d['key_dequant_scale'].contiguous().view(torch.int8).reshape(pages,64)],dim=1)
        bounds=torch.cat([torch.zeros(1,dtype=torch.int32),d['actual_seq_lengths_query']])
        lens=d['actual_seq_lengths_key']
        request=torch.repeat_interleave(torch.arange(len(lens),dtype=torch.int32),bounds[1:]-bounds[:-1])
        position=torch.cat([torch.arange(int(lens[i])-(int(bounds[i+1])-int(bounds[i])),int(lens[i]),dtype=torch.int64) for i in range(len(lens))])
        values=[x.npu() for x in (query,scale,weight,cache,d['block_table'],position,lens,request,bounds)]
        scores=torch.full((t,512),float('nan'),device='npu');topk=torch.full((t,512),-111,dtype=torch.int32,device='npu')
        assert position[86].item()==8192 and position[103].item()==8195,position[[86,103]]
        assert torch.equal(d['query'][[86,103]].reshape(2,-1).float(),s['native']['iq'])
        assert torch.equal(d['weights'][[86,103]].float(),s['native']['indexer_weights'])
        assert torch.equal(d['query_dequant_scale'][[86,103]].float(),s['native']['iscale'])
        op=pypto.torch.register(score_test,'t126_score_only::run')
        with torch.inference_mode():op(*values,scores,topk)
        torch.npu.synchronize();actual=topk.cpu();expected=s['native_topk'].reshape(t,512)
        record={'native_actual_graph_input_rows_verified':[86,103],'different_indices':int((actual!=expected).sum()),'different_rows':(actual!=expected).any(1).nonzero().flatten().tolist(),'positions_86_103':position[[86,103]].tolist(),'max_length':int(lens.max()),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
        target=exp/'results/t126-score-only-v1';target.mkdir(exist_ok=False)
        (target/'result.json').write_text(json.dumps(record,indent=2)+'\n');torch.save({'actual':actual,'expected':expected,'scores':scores.cpu()},target/'scores.pt')
        print('SCORE_SAME_NATIVE_INPUT_RESULT',record,flush=True)
