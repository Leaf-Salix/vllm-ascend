"""QA-only single-factor A/B against the saved actual Native BF16 boundary."""
import hashlib,json,os,sys
from pathlib import Path
import torch
import pypto.torch
from pypto.runtime import RunConfig
import vllm_ascend.ops.pypto as ns
exp=Path(os.environ['SPMD_EXPERIMENT']);here=exp/'t126-fix-20261020'
ns.__path__.insert(0,str(exp/'src/vllm_ascend/ops/pypto'));sys.path.insert(0,str(here))
import qa_variants as kernels
observed='--observed' in sys.argv
modes=('base','observed256','observed512') if observed else ('base','m64tail','kshift','both')
if '--compile' in sys.argv:
    assert os.environ['ASCEND_RT_VISIBLE_DEVICES']==''
    from pypto.ir.compile import _compile_impl
    from pypto.ir._kernel_compile import kernel_abi_for_program
    from pypto.runtime.kernel_compiler import KernelCompiler
    for mode in modes:
        entry=getattr(kernels,'qa_'+mode+'_test');out=here/('qa-'+mode+'-artifact')
        entry.compile(config=RunConfig(platform='a2a3',save_kernels=True,save_kernels_dir=str(out)))
        prog=entry.specialize();abi=kernel_abi_for_program(prog,platform='a2a3',runtime='tensormap_and_ringbuffer')
        _compile_impl(prog,output_dir=str(here/('qa-'+mode+'-kernel-artifact')),platform='a2a3',_kernel_abi=abi)
        KernelCompiler().compile_orchestration('tensormap_and_ringbuffer',str(out/'orchestration'/('qa_'+mode+'_test.cpp')))
        op=pypto.torch.register(entry,'qa_single_factor::'+mode);assert len(op._schema.arguments)==3
        print('QA_VARIANT_COMPILE_PASS',mode,flush=True)
else:
    import torch_npu
    assert os.environ['TASK_DEVICE'];torch.npu.set_device(0);torch.npu.config.allow_internal_format=True
    torch_npu.npu.set_deterministic_level(1);pypto.torch.init()
    source=exp/'results/t126-qa-stage-v5/query-calibration.pt';d=torch.load(source,map_location='cpu',weights_only=False)
    stages=torch.load(source.with_name('stages.pt'),map_location='cpu',weights_only=False)
    assert tuple(d['normed'].shape)==(126,4096) and d['normed'].dtype==torch.bfloat16
    assert tuple(d['native_qa'].shape)==(126,1024) and d['native_qa'].dtype==torch.bfloat16
    assert tuple(d['wq_a'].shape)==(1024,4096) and d['wq_a'].dtype==torch.bfloat16
    x=d['normed'].npu();w=d['wq_a'].npu()
    if kernels.BF16_WEIGHT_LAYOUT is not None:w=torch_npu.npu_format_cast(w,29)
    assert torch.equal(torch_npu.npu_format_cast(w,2).cpu().view(torch.uint8),d['wq_a'].view(torch.uint8))
    out=exp/('results/t126-qa-observed-order-v2' if observed else 'results/t126-qa-single-factor-v1');out.mkdir(exist_ok=False)
    record={'native_qa_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'weight_format':int(torch_npu.get_npu_format(w)),'cases':{},'scope':'QA only, no end-to-end acceptance','sources':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (here/'qa_variants.py',Path(__file__))}}
    saved={}
    for mode in modes:
        owner=torch.full((160,1024),37.,device='npu');value=owner[16:144];value.fill_(float('nan'))
        op=pypto.torch.register(getattr(kernels,'qa_'+mode+'_test'),'qa_single_factor::'+mode)
        with torch.inference_mode():op(x,w,value)
        torch.npu.synchronize();assert bool((owner[:16]==37).all()) and bool((owner[144:]==37).all())
        actual=value.cpu()[:126].bfloat16();expected=d['native_qa'];diff=actual!=expected
        assert bool(torch.isfinite(actual).all())
        if mode=='base':assert torch.equal(actual[[86,103]].float(),stages['pto']['qa']),'standalone QA does not reproduce original FULL observed QA'
        record['cases'][mode]={'different':int(diff.sum()),'different_rows':diff.any(1).nonzero().flatten().tolist(),'target_rows':{str(row):{'different':int(diff[row].sum()),'coordinates':diff[row].nonzero().flatten().tolist()} for row in (86,103)}}
        assert torch.equal(x.cpu().view(torch.uint8),d['normed'].view(torch.uint8))
        assert torch.equal(torch_npu.npu_format_cast(w,2).cpu().view(torch.uint8),d['wq_a'].view(torch.uint8))
        saved[mode]=value.cpu()
        (out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print('QA_SINGLE_FACTOR_RESULT',mode,record['cases'][mode],flush=True)
    torch.save(saved,out/'outputs.pt')
