"""Compile actual generated orchestration with existing SDK, without NPU."""
import hashlib,json,os
from pathlib import Path
from pypto.runtime.kernel_compiler import KernelCompiler
here=Path(os.environ['SPMD_EXPERIMENT'])/'t126-fix-20261020'
assert os.environ['ASCEND_RT_VISIBLE_DEVICES']==''
compiler=KernelCompiler(platform='a2a3')
record={}
for directory in ('stage-artifact','stage-kernel-artifact'):
 p=here/directory/'orchestration/_full_csa_tnd_prepacked.cpp'
 binary=compiler.compile_orchestration('tensormap_and_ringbuffer',str(p))
 record[directory]={'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'binary_bytes':len(binary)}
receipt=json.loads((here/'compile-receipt.json').read_text())
receipt['actual_orchestration_compile']=record
(here/'compile-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('ORCHESTRATION_ACTUAL_COMPILE_PASS',record,flush=True)
