"""Build a separate whole-model snapshot after the unhooked FULL gate passes."""
import argparse,ast,hashlib,json,re,shutil
from pathlib import Path
EXP=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-spmd-20261019')
REF=EXP/'whole-spmd-prepack-v3'
parser=argparse.ArgumentParser()
parser.add_argument('--job-name',default='whole-bf16qa126-v2')
parser.add_argument('--t126-case',default='bf16qa126-full-t126-v2')
parser.add_argument('--t240-case',default='bf16qa126-full-t240-v2')
args=parser.parse_args()
assert re.fullmatch(r'whole-bf16qa126-[a-z0-9-]+',args.job_name)
JOB=EXP/args.job_name
assert all(re.fullmatch(r'[a-z0-9-]+',n) for n in (args.t126_case,args.t240_case))
gates=((args.t126_case,126),(args.t240_case,240))
OLD='deepseek_v4_flash_csa_tnd_precision_spmd_prepack';NEW='deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not JOB.exists()
receipt=json.loads((EXP/'compile-full-csa-bf16layout.json').read_text())
assert all(receipt[k] for k in ('compiled','kernel_mode_abi_pass','torch_dispatcher_registration_pass','formal_prepare_program_compiled','formal_prepare_kernel_mode_abi_pass','formal_operators_registered'))
source=EXP/'src/vllm_ascend/ops/pypto'/NEW
assert {p.name:sha(p) for p in source.glob('*.py')}==receipt['sources']
for case,expected in gates:
 last=json.loads((EXP/'results'/case/'result.json').read_text())
 assert last['complete'] and last['pass'] and last['candidate_sources']==receipt['sources']
 assert last['true_tokens']==last['physical_graph_tokens']==expected and last['per_request_padding']==0
 assert last['lengths']==([1,2,3,4,5,6]*6 if expected==126 else [6]*40)
 assert last['layer']==4 and last['history']==8191
parent=json.loads((REF/'helper-manifest.json').read_text())['files']
assert all(sha(REF/n)==h for n,h in parent.items())
JOB.mkdir()
for name in parent:
 p=JOB/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(REF/name,p)
shutil.copytree(REF/'qualification-audit',JOB/'qualification-audit',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
shutil.copy2(REF/'helper-manifest.json',JOB/'bf16qa126-parent-helper-manifest.json')
m=json.loads((REF/'snapshot/manifest.json').read_text());files=m['files'];assert len(files)==3385
for name,digest in list(files.items()):
 assert sha(REF/'snapshot/source'/name)==digest,name
 p=JOB/'snapshot/source'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(REF/'snapshot/source'/name,p)
for name,digest in receipt['sources'].items():
 n='vllm_ascend/ops/pypto/'+NEW+'/'+name;assert n not in files
 p=JOB/'snapshot/source'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/name,p);files[n]=digest
for n,h in receipt['baseline_sources'].items():assert files[n]==h
for package,key in (('deepseek_v4_flash_csa_tnd_precision_spmd','parent_spmd_sources'),(OLD,'parent_prepack_sources')):
 for n,h in receipt[key].items():assert files['vllm_ascend/ops/pypto/'+package+'/'+n]==h
m['spmd_scope']='frozen63 plus independent BF16 layout and QA126 Native-order route; no stage hooks'
(JOB/'snapshot/manifest.json').write_text(json.dumps(m,indent=2)+'\n')
for name in ('env.sh','preflight.sh','run-case.sh','source_preflight.py','mixed_perf.py','qualified_wkv.py','test_static_qualification.py'):
 p=JOB/name;s=p.read_text().replace(str(REF),str(JOB)).replace(OLD,NEW).replace('dsv4_csa_tnd_precision_spmd_prepack::','dsv4_csa_tnd_precision_spmd_bf16layout::');p.write_text(s)
changes=json.loads((REF/'candidate-math.json').read_text());changes.update({n:h for n,h in files.items() if NEW+'/' in n});(JOB/'candidate-math.json').write_text(json.dumps(changes,indent=2)+'\n')
(JOB/'FINAL_SOURCE_BOUND.json').write_text(json.dumps({'pass':True,'NPU_executed':False,'scope':'source binding only; whole-model pending','root_ABI':64,'source_manifest_sha256':sha(JOB/'snapshot/manifest.json'),'candidate_sources':receipt['sources'],'preserved_parent_manifest_sha256':sha(REF/'snapshot/manifest.json'),'frozen43':receipt['baseline_sources'],'parent14':receipt['parent_spmd_sources'],'parent6':receipt['parent_prepack_sources'],'compile_receipt_sha256':sha(EXP/'compile-full-csa-bf16layout.json'),'single_layer_gate_result_sha256':{c:sha(EXP/'results'/c/'result.json') for c,_ in gates}},indent=2)+'\n')
for name in ('independent8k.py','independent128k.py'):
 p=JOB/'qualification-audit'/name;p.write_text(p.read_text().replace(OLD,NEW).replace('dsv4_csa_tnd_precision_spmd_prepack::','dsv4_csa_tnd_precision_spmd_bf16layout::'))
p=JOB/'qualification-audit/audit_identity.py';s=p.read_text().replace('default=3385','default=3393').replace("'deepseek_v4_flash_csa_tnd_precision_spmd_prepack')","'deepseek_v4_flash_csa_tnd_precision_spmd_prepack','deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout')").replace('assert len(tested)==63','assert len(tested)==71')
needle="    package=source/'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision'"
extra="""    bf16=ast.parse((source/'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout/service.py').read_text())
    bf16_class=next(n for n in bf16.body if isinstance(n,ast.ClassDef) and n.name=='CSAServiceRuntime')
    assert [ast.unparse(b) for b in bf16_class.bases]==['PrepackedRuntime']
    assert not any(isinstance(n,ast.FunctionDef) for n in bf16_class.body)
"""
assert needle in s;p.write_text(s.replace(needle,extra+needle))
names=[*parent,'bf16qa126-parent-helper-manifest.json']
(JOB/'helper-manifest.json').write_text(json.dumps({'files':{n:sha(JOB/n) for n in names}},indent=2)+'\n')
for p in list(JOB.glob('*.py'))+list((JOB/'qualification-audit').glob('*.py')):ast.parse(p.read_text())
assert len(files)==3393
print('WHOLE_BF16QA126_READY',JOB,'files',len(files),'manifest',sha(JOB/'snapshot/manifest.json'))
