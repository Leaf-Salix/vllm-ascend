"""Compile the export-only root in the existing runtime, without a device."""
import hashlib
import importlib.util
import json
import os
import sys
from pathlib import Path

import pypto
import pypto.torch
import simpler
from pypto.runtime import RunConfig
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program
import vllm_ascend.ops.pypto as namespace

exp=Path(os.environ['SPMD_EXPERIMENT']);here=exp/'t126-qa-fixed-full-v1'
assert os.environ['ASCEND_RT_VISIBLE_DEVICES']==''
assert 'low-acceptance-20261010/runtime-package/pypto' in pypto.__file__
assert 'pypto-reference/runtime/python/simpler' in simpler.__file__
namespace.__path__.insert(0,str(exp/'src/vllm_ascend/ops/pypto'));sys.path.insert(0,str(here))
name='vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.t126_diagnostic_root'
spec=importlib.util.spec_from_file_location(name,here/'t126_diagnostic_root.py');mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod)
entry=mod.decode_csa_tp1_layer_test
compiled=entry.compile(config=RunConfig(platform='a2a3',save_kernels=True,save_kernels_dir=str(here/'stage-artifact')))
program=entry.specialize();abi=kernel_abi_for_program(program,platform='a2a3',runtime='tensormap_and_ringbuffer')
_compile_impl(program,output_dir=str(here/'stage-kernel-artifact'),platform='a2a3',_kernel_abi=abi)
from pypto.runtime.kernel_compiler import KernelCompiler
KernelCompiler().compile_orchestration('tensormap_and_ringbuffer',str(here/'stage-artifact/orchestration/_full_csa_tnd_prepacked.cpp'))
op=pypto.torch.register(entry,'t126_stage_probe::attention')
assert len(op._schema.arguments)==64
record=dict(exports_sha256=hashlib.sha256((here/"exports.json").read_bytes()).hexdigest(),compiled=True,kernel_abi_pass=True,schema=str(op._schema),pypto=pypto.__file__,simpler=simpler.__file__,sources={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in list(here.glob('t126_diagnostic_*.py')) + [here/'qa_variants.py']},formal_receipt_sha256=hashlib.sha256((exp/'compile-full-csa-bf16layout.json').read_bytes()).hexdigest())
(here/'compile-receipt.json').write_text(json.dumps(record,indent=2)+'\n')
print('STAGE_PROBE_COMPILED',op._schema,flush=True)
