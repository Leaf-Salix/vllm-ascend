"""8K真实权重、Native/TND完整CSA FULL图验收；首差停止。"""
import argparse
import contextlib
import hashlib
import importlib
import json
import os
from pathlib import Path
import statistics
import sys
import types

import torch
import torch_npu
import pypto.torch
from vllm.config import CUDAGraphMode
from vllm.engine.arg_utils import EngineArgs
from vllm.forward_context import get_forward_context
from vllm.platforms import current_platform
from vllm_ascend.ascend_forward_context import set_ascend_forward_context
import vllm_ascend.ops.dsv4_csa
from dsv4_csa_native_case import native_session
from vllm_ascend.device.device_op import DeviceOperator
from dsv4_csa_single_layer import make_layer, restore, collect_state, guard_checks
from ragged_fixture import make_ragged_fixture
from npugraph_ex._acl_concrete_graph.acl_graph import AclGraph

ROOT = Path(__file__).resolve().parent
BASE = Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
META_SHA = '863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--lengths', default='1,1,1,1')
parser.add_argument('--layer', type=int, default=4)
parser.add_argument('--history', type=int, default=8191)
args = parser.parse_args()
lengths = list(map(int,args.lengths.split(',')))
tokens, batch = sum(lengths), len(lengths)
assert all(1<=q<=6 for q in lengths) and batch<=40 and tokens<=256
assert not (args.out/'result.json').exists()
args.out.mkdir(parents=True,exist_ok=True)
expected_helpers=json.loads((ROOT/'manifest.json').read_text())
helper_sha={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in expected_helpers}
assert helper_sha==expected_helpers,'helper source identity mismatch'
manifest_sha=hashlib.sha256((ROOT/'manifest.json').read_bytes()).hexdigest()
report = {'helper_sha':helper_sha,'manifest_sha256':manifest_sha,'complete':False,'pass':False,'scope':'real layer weights, synthetic hidden/history, Native/TND complete CSA half-layer FULL graph; not whole model',
          'lengths':lengths,'true_tokens':tokens,'physical_graph_tokens':tokens,'per_request_padding':0,
          'hypothetical_s6_tokens':batch*6,'hypothetical_s6_extra_rows':batch*6-tokens,
          'baseline_experiment':'Native direct HC-pre through HC-post', 'candidate_experiment':'t126-qa-fixed-full-v1',
          'candidate_variant':'one SPMD prefix, original PTO suffix; full HC-pre through HC-post',
          'layer':args.layer,'history':args.history,'graphs':{},'comparisons':{},'static':{}}
def save():
    (args.out/'result.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
def exact(x,y):
    return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def metric(x,y):
    if x.shape!=y.shape or x.dtype!=y.dtype:
        return {'bit_equal':False,'shapes':[list(x.shape),list(y.shape)],'dtypes':[str(x.dtype),str(y.dtype)]}
    if x.is_floating_point():
        assert bool(torch.isfinite(x).all()) and bool(torch.isfinite(y).all()), 'nonfinite external float boundary'
    equal=exact(x,y)
    delta=x.float()-y.float()
    return {'bit_equal':equal,'different_elements':int((x!=y).sum()),'max_abs':float(delta.abs().max()),
            'relative_l2':float(torch.linalg.vector_norm(delta)/torch.linalg.vector_norm(y.float()).clamp_min(1e-30)),
            'first_coordinates':(x!=y).nonzero()[:6].tolist()}

import vllm_ascend.ops.pypto as spmd_namespace
experiment=Path(os.environ['SPMD_EXPERIMENT'])
spmd_namespace.__path__.insert(0,str(experiment/'src/vllm_ascend/ops/pypto'))
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.native_adapter import CSAOperators
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.service import CSAServiceRuntime
from source_identity import source_identity
source_record=source_identity()
report.update(source_record)
import vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.decode_csa as formal_root
assert Path(formal_root.__file__).resolve().is_relative_to(experiment/'src')
package=Path(formal_root.__file__).resolve().parent
candidate_sources={q.name:hashlib.sha256(q.read_bytes()).hexdigest() for q in package.glob('*.py')}
receipt=json.loads((experiment/'compile-full-csa-bf16layout.json').read_text())
assert receipt['compiled'] and receipt['kernel_mode_abi_pass'] and receipt['torch_dispatcher_registration_pass']
assert receipt['formal_prepare_program_compiled'] and receipt['formal_prepare_kernel_mode_abi_pass'] and receipt['formal_operators_registered']
assert receipt['sources']==candidate_sources
assert receipt['baseline_sources']==source_record['tested_sources']
parent=package.with_name('deepseek_v4_flash_csa_tnd_precision_spmd')
assert {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in parent.glob('*.py')}==receipt['parent_spmd_sources']
report['parent_spmd_sources']=receipt['parent_spmd_sources']
parent_prepack=package.with_name('deepseek_v4_flash_csa_tnd_precision_spmd_prepack')
assert {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in parent_prepack.glob('*.py')}==receipt['parent_prepack_sources']
report['parent_prepack_sources']=receipt['parent_prepack_sources']
report['candidate_sources']=candidate_sources
report['candidate_package']=str(package)
report['compile_receipt_sha256']=hashlib.sha256((experiment/'compile-full-csa-bf16layout.json').read_bytes()).hexdigest()
report['formal_root_file']=formal_root.__file__

native_debug={}; qli_kwargs={}; qli_buffers={}; debug_allocations={}
layout=json.loads((experiment/'t126-qa-fixed-full-v1/exports.json').read_text())
def guarded_debug(name,shape,dtype):
    count=1
    for d in shape:count*=d
    allocation=torch.full((count+128,),37,dtype=dtype,device='npu:0')
    view=allocation[64:64+count].view(shape)
    debug_allocations[name]=(allocation,view)
    return view
def check_debug_guards():
    for n,(allocation,view) in debug_allocations.items():
        assert bool((allocation[:64]==37).all()) and bool((allocation[-64:]==37).all()),('debug guard',n)
def poison_debug():
    for n,(allocation,view) in debug_allocations.items():
        if n=='packet':
            view[2560:].fill_(0x7fc00000)
        elif view.is_floating_point():view.fill_(float('nan'))
        else:view.fill_(-111)

sys.path.insert(0,str(experiment/'t126-qa-fixed-full-v1'))
probe_name='vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.t126_diagnostic_root'
spec=importlib.util.spec_from_file_location(probe_name,experiment/'t126-qa-fixed-full-v1/t126_diagnostic_root.py')
probe_root=importlib.util.module_from_spec(spec);sys.modules[probe_name]=probe_root;spec.loader.exec_module(probe_root)
probe_receipt=json.loads((experiment/'t126-qa-fixed-full-v1/compile-receipt.json').read_text())
assert probe_receipt['compiled'] and probe_receipt['kernel_abi_pass']
assert probe_receipt['exports_sha256']==hashlib.sha256((experiment/'t126-qa-fixed-full-v1/exports.json').read_bytes()).hexdigest()
assert probe_receipt['formal_receipt_sha256']==hashlib.sha256((experiment/'compile-full-csa-bf16layout.json').read_bytes()).hexdigest()
for n,h in probe_receipt['sources'].items():assert hashlib.sha256((experiment/'t126-qa-fixed-full-v1'/n).read_bytes()).hexdigest()==h
report['diagnostic_sources']=probe_receipt['sources']

class NativeHalf(torch.nn.Module):
    def __init__(self,layer):
        super().__init__();self.layer=layer
    def forward(self,hidden,positions,output):
        l=self.layer
        mixed,post,comb=l.hc_pre(hidden,l.hc_attn_fn,l.hc_attn_scale,l.hc_attn_base)
        native_debug['mixed'].copy_(mixed)
        native_debug['post'].copy_(post.reshape(tokens,-1))
        native_debug['comb'].copy_(comb.reshape(tokens,-1))
        normed=l.input_layernorm(mixed)
        native_debug['normed'].copy_(normed)
        attended=l.self_attn(positions=positions,hidden_states=normed,llama_4_scaling=None)
        native_debug['attention_out'].copy_(attended)
        output.copy_(l.hc_post(attended,hidden,post,comb))
        return output

class PTOHalf(torch.nn.Module):
    def __init__(self,prefix):
        super().__init__();self.prefix=prefix
    def forward(self,hidden,positions,output):
        torch.ops.vllm.dsv4_csa_forward(hidden,positions,output,self.prefix)
        return output

class RequirePTO:
    def __init__(self,delegate):
        self.delegate,self.calls=delegate,0
    def eligible(self,*values):
        if not self.delegate.eligible(*values):
            raise RuntimeError('Unexpected PTO fallback')
        return True
    def __call__(self,*values,**kwargs):
        self.calls+=1
        return self.delegate(*values,**kwargs)

current_platform.pre_register_and_update()
torch.npu.set_device(0)
torch.npu.config.allow_internal_format=True
torch.use_deterministic_algorithms(True)
torch_npu.npu.set_deterministic_level(1)
torch.set_num_threads(4)
from vllm_ascend.utils import enable_custom_op
assert enable_custom_op()
checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config=EngineArgs(model=str(checkpoint),tokenizer_mode='deepseek_v4',trust_remote_code=True,
 tensor_parallel_size=1,dtype='bfloat16',quantization='ascend',hf_overrides={'sliding_window':128},
 max_model_len=16384,max_num_seqs=40,max_num_batched_tokens=256,enable_prefix_caching=False,
 enforce_eager=False,block_size=32,speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},
 compilation_config={'cudagraph_mode':'FULL_DECODE_ONLY','cudagraph_capture_sizes':[tokens],'cache_dir':str(args.out/'vllm-cache')},
 additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,'fuse_norm_quant':True,'align_decode_capture_sizes':False},
 'enable_cpu_binding':False,'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False}).create_engine_config()

states, fixtures, rows, keepalive, b_states = {}, {}, {}, [], {}
save()
try:
 with native_session(config,0),torch.inference_mode():
    layer,details=make_layer(config,checkpoint,torch.device('npu:0'),args.layer)
    report['weight_details']=details
    pypto.torch.init()
    impl=layer.self_attn.dsa_attn.dsa_attn.impl
    observed={}
    specs={
      'mixed':((tokens,4096),torch.bfloat16),'normed':((tokens,4096),torch.bfloat16),
      'post':((tokens,4),torch.float32),'comb':((tokens,16),torch.float32),
      'indexer_weights':((tokens,64),torch.float16),
      'q':((tokens,formal_root.H*formal_root.HEAD_DIM),torch.bfloat16),
      'heads':((tokens,formal_root.H*formal_root.HEAD_DIM),torch.bfloat16),
      'projected_o':((tokens,formal_root.O_GROUPS*formal_root.O_LORA),torch.bfloat16),
      'attention_out':((tokens,4096),torch.bfloat16),
      'iq':((probe_root.T_PAD*64,128),torch.int8),
      'iscale':((probe_root.T_PAD*64,1),torch.float32),
      'qa':((tokens,1024),torch.bfloat16),'qr':((tokens,1024),torch.int8),'qr_scale':((tokens,1),torch.float32),
      'irope':((tokens,8192),torch.bfloat16),'ihadamard_scaled':((tokens,8192),torch.bfloat16)}
    for n,(shape,dtype) in specs.items():
        if n not in ('iq','iscale','indexer_weights'):native_debug[n]=guarded_debug(n,shape,dtype)
    debug_packet=guarded_debug('packet',(layout['packet_size'],),torch.int32)
    original_fused_qr=torch.ops._C_ascend.npu_rms_norm_dynamic_quant
    def observed_fused_qr(*values,**kwargs):
        native_debug['qa'].copy_(values[0].reshape(tokens,1024))
        result=original_fused_qr(*values,**kwargs)
        native_debug['qr'].copy_(result[0].reshape(tokens,1024))
        native_debug['qr_scale'].copy_(result[1].reshape(tokens,1))
        return result
    torch.ops._C_ascend.npu_rms_norm_dynamic_quant=observed_fused_qr
    import vllm_ascend.attention.dsa_v1 as dsa_module
    original_rotate=dsa_module.rotate_activation
    def observed_rotate(x,hadamard):
        if x.numel()==tokens*8192:native_debug['irope'].copy_(x.reshape(tokens,8192))
        result=original_rotate(x,hadamard)
        if x.numel()==tokens*8192:native_debug['ihadamard_scaled'].copy_(result.reshape(tokens,8192))
        return result
    dsa_module.rotate_activation=observed_rotate
    native_aux={name:guarded_debug('aux_'+name,(tokens,32768),torch.bfloat16) for name in ('q_before_rms','q_after_rms')}
    original_q_rms=DeviceOperator.apply_dsa_q_rms
    def observed_q_rms(q,*values,**kwargs):
        native_aux['q_before_rms'].copy_(q.reshape(tokens,-1))
        result=original_q_rms(q,*values,**kwargs)
        native_aux['q_after_rms'].copy_(result.reshape(tokens,-1))
        return result
    DeviceOperator.apply_dsa_q_rms=staticmethod(observed_q_rms)
    original_hlinear=dsa_module.hadamard_linear
    original_hscale=dsa_module.hadamard_scale
    def observed_hlinear(x,*values,**kwargs):
        if x.numel()==tokens*8192:native_debug['irope'].copy_(x.reshape(tokens,8192))
        return original_hlinear(x,*values,**kwargs)
    def observed_hscale(x,*values,**kwargs):
        result=original_hscale(x,*values,**kwargs)
        if result.numel()==tokens*8192:native_debug['ihadamard_scaled'].copy_(result.reshape(tokens,8192))
        return result
    dsa_module.hadamard_linear=observed_hlinear
    dsa_module.hadamard_scale=observed_hscale
    report['native_multistream_overlap']=impl.multistream_dsv4_dsa_overlap
    original_get_attn=DeviceOperator.get_dsa_sparse_attn_op
    def get_observed_attn():
        op=original_get_attn()
        def observed_attn(q,*values,**kwargs):
            native_debug['q'].copy_(q.reshape(tokens,-1))
            return op(q,*values,**kwargs)
        return observed_attn
    DeviceOperator.get_dsa_sparse_attn_op=staticmethod(get_observed_attn)
    original_oproj=impl._forward_o_proj
    def observed_oproj(owner,heads,output):
        native_debug['heads'].copy_(heads.reshape(tokens,-1))
        return original_oproj(heads,output)
    impl._forward_o_proj=types.MethodType(observed_oproj,impl)
    original_b=impl.wo_b.forward
    def observed_b(owner,hidden,*values,**kwargs):
        native_debug['projected_o'].copy_(hidden.reshape(tokens,-1))
        return original_b(hidden,*values,**kwargs)
    impl.wo_b.forward=types.MethodType(observed_b,impl.wo_b)

    original_qli=torch.ops._C_ascend.npu_vllm_quant_lightning_indexer
    def observe_qli(*values,**kwargs):
        if not qli_kwargs:
            qli_kwargs.update(kwargs)
            for n in ('query','weights','query_dequant_scale'):qli_buffers[n]=guarded_debug('qli_'+n,tuple(kwargs[n].shape),kwargs[n].dtype)
        for n,v in qli_buffers.items():v.copy_(kwargs[n])
        result=original_qli(*values,**kwargs);observed['topk']=result[0];return result
    torch.ops._C_ascend.npu_vllm_quant_lightning_indexer=observe_qli
    # 保留原13包校验桥；只在首次真实reselect后复用选择，禁止捕获之后变更选择。
    selection=[]
    original_reselect=torch_npu.npu._aclnn_reselect_static_kernel
    def qualified_reselect(*values,**kwargs):
        assert hashlib.sha256((Path(os.environ['LOW_ACCEPTANCE_OFFICIAL_CACHE'])/'metadata.json').read_bytes()).hexdigest()==META_SHA
        assert not values and not kwargs
        if not selection:
            selection.append(original_reselect())
            report['static']['actual_reselect_count']=1
        else:
            report['static']['validated_reuses']=report['static'].get('validated_reuses',0)+1
        report['static']['metadata_sha256']=META_SHA
        return selection[0]
    # 框架可能已from-import compile_static_kernel；在实际API边界观测，避免漏掉别名调用。
    torch_npu.npu._aclnn_reselect_static_kernel=qualified_reselect

    for arm in ('native','candidate'):
        print('ARM_START',arm,flush=True)
        torch._dynamo.reset()
        f=make_ragged_fixture(config,layer.self_attn,batch,args.history,1024,torch.device('npu:0'),lengths)
        fixtures[arm]=f
        if arm!='native':
            for field in ('hidden','positions'):
                assert exact(f[field],fixtures['native'][field]),(arm,field)
            for name,g in f['groups'].items():
                assert exact(g['initial'],fixtures['native']['groups'][name]['initial']),(arm,name)
        runtime=None
        if arm!='native':
            original_ops=CSAOperators.register()
            probe_op=pypto.torch.register(probe_root.decode_csa_tp1_layer_test,'t126_stage_probe::attention')
            order_index=next(i for i,a in enumerate(probe_op._schema.arguments) if a.name=='order_packet')
            class DiagnosticAdapter:
                _schema=original_ops.attention._schema
                def __call__(self,*values):
                    debug_packet[:2560].copy_(values[order_index])
                    self.selected_order=values[order_index]
                    values=list(values);values[order_index]=debug_packet
                    return probe_op(*values)
            operators=type(original_ops)(DiagnosticAdapter(),original_ops.workspace)
            report['diagnostic_actual_root_schema']=str(probe_op._schema)
            assert len(probe_op._schema.arguments)==64

            with torch.inference_mode(False), torch.enable_grad():
                keepalive.append(layer.hc_attn_fn)  # Retain captured Native weight storage.
                layer.hc_attn_fn=torch.nn.Parameter(layer.hc_attn_fn.detach().clone(),requires_grad=True)
                runtime=CSAServiceRuntime(layer.self_attn,operators,40,layer)
                report['model_loading_prepare_context']={'grad_enabled_after_constructor':torch.is_grad_enabled(),'source_requires_grad':layer.hc_attn_fn.requires_grad,'source_inference':torch.is_inference(layer.hc_attn_fn),'packed_requires_grad':runtime.weights['hc_packed_weight'].requires_grad}
                assert torch.is_grad_enabled() and layer.hc_attn_fn.requires_grad
                assert not runtime.weights['hc_packed_weight'].requires_grad

            torch.save({'normed':native_debug['normed'].cpu(),'native_qa':native_debug['qa'].cpu(),
                        'native_qr':native_debug['qr'].cpu(),'native_qr_scale':native_debug['qr_scale'].cpu(),
                        'wq_a':runtime.weights['wq_a'].cpu(),'gamma_cq':runtime.weights['gamma_cq'].cpu()},args.out/'query-calibration.pt')
            from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.workspace import NORM_PARAMETERS
            norm_offset=0
            norm_packet_checks={}
            for name,size in NORM_PARAMETERS:
                norm_packet_checks[name]=exact(runtime.norm_packet[norm_offset:norm_offset+size].cpu(),runtime.weights[name].cpu())
                norm_offset+=size
            assert norm_offset==6272 and all(norm_packet_checks.values())
            order_checks={}
            for (w,i,o),packet in operators.workspace.order_packets.items():
                cpu=packet.cpu()
                order_checks[str((w,i,o))]=all((exact(cpu[:512],runtime.wkv_orders[w].cpu().reshape(-1)),
                    exact(cpu[512:1536],runtime.indexer_orders[i].cpu().reshape(-1)),
                    exact(cpu[1536:],runtime.oproj_starts[o].cpu().reshape(-1))))
            assert len(order_checks)==33 and all(order_checks.values())
            report['packet_checks']={'norm_byte_equal':norm_packet_checks,'order_byte_equal':order_checks,
                'norm_bytes_per_layer':runtime.norm_packet.numel()*runtime.norm_packet.element_size(),
                'order_bytes_per_model':sum(t.numel()*t.element_size() for t in operators.workspace.order_packets.values())}
            readonly_packets={'norm':runtime.norm_packet,'hc_packed':runtime.weights['hc_packed_weight'],**{str(k):v for k,v in operators.workspace.order_packets.items()}}
            packet_snapshots={k:v.cpu() for k,v in readonly_packets.items()}
            report['hc_weight_qualification']=dict(runtime.hc_weight_qualification)
            assert report['hc_weight_qualification']['version']==1
            assert selection,'Native graph did not install and select static packages'
            runtime.qualify_static_wkv(metadata_sha256=META_SHA,reselected=True)
        @contextlib.contextmanager
        def context():
            with set_ascend_forward_context(f['metadata'],config,num_tokens=tokens,num_actual_tokens=tokens,
                                            aclgraph_runtime_mode=CUDAGraphMode.FULL):
                assert get_forward_context().cudagraph_runtime_mode is CUDAGraphMode.FULL
                yield
        if runtime is not None:
            with context():
                eligible=runtime.eligible(get_forward_context(),f['hidden'],f['positions'])
            report.setdefault('entry',{})[arm]={'eligible':eligible,'route':'PTO' if eligible else 'Native fallback','metadata':{
                name:{'bounds':f['metadata'][g['prefix']].decode.query_start_loc.cpu().tolist(),
                      'max_q':f['metadata'][g['prefix']].decode.max_seqlen_q,
                      'num_decodes':f['metadata'][g['prefix']].num_decodes,
                      'actual_tokens':f['metadata'][g['prefix']].num_actual_tokens} for name,g in f['groups'].items()}}
            save()
            assert eligible, 'TND precision fallback is forbidden'
            guarded=RequirePTO(runtime)
            layer.self_attn.dsa_attn._pto_csa_runtime=guarded
        else:
            layer.self_attn.dsa_attn._pto_csa_runtime=None
        output=torch.empty_like(f['hidden'])
        module=NativeHalf(layer) if arm=='native' else PTOHalf(layer.self_attn.dsa_attn.prefix)
        restore(f)
        with context():module(f['hidden'],f['positions'],output)
        torch.npu.synchronize()
        instances={}
        old_run=AclGraph.run
        def record(owner,key,*values,**kwargs):
            instances[(id(owner),key)]=owner
            return old_run(owner,key,*values,**kwargs)
        AclGraph.run=record
        options={'force_eager':False,'inplace_pass':True,'clone_input':False,'clone_output':False,
                 'static_kernel_compile':True,'super_kernel_optimize':False}
        torch.npu.set_compile_mode(jit_compile=False)
        try:
            compiled=torch.compile(module,backend='npugraph_ex',fullgraph=True,dynamic=False,options=options)
            restore(f)
            with context():compiled(f['hidden'],f['positions'],output)
            torch.npu.synchronize()
            assert len(instances)==1,(arm,'not exactly one actual graph',len(instances))
            (_,key),owner=next(iter(instances.items()))
            assert not owner._updated_node_infos,'Host updated nodes invalidate raw replay test'
            graph=owner.graph[key]
        finally:
            AclGraph.run=old_run
        topk=runtime.topk[:tokens] if runtime is not None and report['entry'][arm]['eligible'] else observed['topk']
        compiled_state=collect_state(f,output,topk)
        restore(f);output.fill_(float('nan'));topk.fill_(-12345);poison_debug();graph.replay();torch.npu.synchronize();check_debug_guards()
        actual=collect_state(f,output,topk)
        assert all(exact(value,compiled_state[name]) for name,value in actual.items()),(arm,'compiled/raw mismatch')
        assert torch.isfinite(output).all()
        guards=guard_checks(f)
        assert all(value['status']=='PASS' for value in guards.values()),(arm,'guard',guards)
        states[arm]=actual
        rows[arm]=(graph,f,output,topk)
        keepalive.append((compiled,module,owner,runtime))
        report['graphs'][arm]={'actual_acl_graph':True,'fullgraph':True,'options':options,
                                'true_tokens':tokens,'graph_tokens':tokens,'guards':guards,'compiled_raw_equal':True,
                                'topk_poison_replay_restored':True,'native_super_kernel_optimize':False}
        reference=torch.load(experiment/'results/bf16layout-full-t126-v1/first-difference.pt',map_location='cpu',weights_only=False)
        invariant={n:exact(v,reference['states'][arm][n]) for n,v in actual.items()}
        report.setdefault('original_output_invariance',{})[arm]=invariant;save()
        if arm=='native':assert all(invariant.values()),'Native observer changed original outputs'
        if arm=='native':
            native_export={n:v.cpu().clone() for n,v in native_debug.items()}
            native_aux_export={n:v.cpu().clone() for n,v in native_aux.items()}
            assert all(bool(torch.isfinite(v).all()) for v in native_aux_export.values()),'Native Q RMS hook missing/nonfinite'
            native_export['indexer_weights']=qli_buffers['weights'].cpu().reshape(tokens,64)
            native_export['iq']=qli_buffers['query'].cpu().reshape(tokens*64,128)
            native_export['iscale']=qli_buffers['query_dequant_scale'].cpu().float().reshape(tokens*64,1)
        else:
            packet_cpu=debug_packet.cpu()
            assert exact(packet_cpu[:2560],runtime.operators.attention.selected_order.cpu()),'original order payload changed'
            pto_export={}
            allowed=torch.zeros(layout['packet_size'],dtype=torch.bool);allowed[:2560]=True
            for n,entry in layout['stages'].items():
                off=entry['offset'];stride=entry['blocks']*256;width=entry['width']
                pto_export[n]=torch.stack([packet_cpu[off+j*stride:off+j*stride+width].view(torch.float32) for j in (0,1)])
                for j in (0,1):allowed[off+j*stride:off+j*stride+width]=True
                assert bool(torch.isfinite(pto_export[n]).all()),('missing or nonfinite export',n)
            assert bool((packet_cpu[~allowed]==0x7fc00000).all()),'packet gaps overwritten'
            native_export={n:v.reshape(tokens,-1)[[86,103]].float() for n,v in native_export.items()}
            report['debug_guards_pass']=True
            checks={n:metric(pto_export[n],native_export[n]) for n in native_export}
            report['stage_comparisons']=checks
            report['row_comparisons']={str(row):{n:metric(pto_export[n][j],native_export[n][j]) for n in native_export} for j,row in enumerate((86,103))}
            torch.save({'native_aux':native_aux_export,'native':native_export,'pto':pto_export,'native_topk':states['native']['idx_topk'],'pto_topk':actual['idx_topk'],'pto_scores':runtime.scores[:tokens].cpu()},args.out/'stages.pt')
            torch.save({k:(qli_buffers[k].cpu() if k in qli_buffers else v.cpu() if isinstance(v,torch.Tensor) else v) for k,v in qli_kwargs.items()},args.out/'native-qli-inputs.pt')
            report['diagnostic_complete']=True
            report['precision_pass']=all(m['bit_equal'] for m in checks.values())
            save();print('STAGES_EXPORTED',json.dumps(report['row_comparisons']),flush=True)
            if not report['precision_pass']:raise RuntimeError('fixed QA candidate: first stage bit difference; stop')
        if arm!='native':
            checks={name:metric(value,states['native'][name]) for name,value in actual.items()}
            report['comparisons'][arm]=checks
            save()
            if not all(check['bit_equal'] for check in checks.values()):
                report['first_failed_arm']=arm
                report['failed_boundaries']=[name for name,m in checks.items() if not m['bit_equal']]
                raise RuntimeError(arm+': first bit difference; stop matrix and timing')
        before=f['hidden'].clone()
        restore(f);f['hidden'].add_(0.125);graph.replay();torch.npu.synchronize()
        assert not exact(output.cpu(),actual['x_out']),(arm,'stale input graph')
        b_states[arm]=collect_state(f,output,topk)
        if arm!='native':
            b_checks={name:metric(value,b_states['native'][name]) for name,value in b_states[arm].items()}
            report.setdefault('B_comparisons',{})[arm]=b_checks;save()
            if not all(check['bit_equal'] for check in b_checks.values()):
                torch.save(b_states,args.out/'first-B-difference.pt')
                raise RuntimeError('TND input B first bit difference; stop')
        assert all(value['status']=='PASS' for value in guard_checks(f).values()),(arm,'B guards')
        f['hidden'].copy_(before);restore(f);graph.replay();torch.npu.synchronize()
        restored=collect_state(f,output,topk)
        assert all(exact(value,actual[name]) for name,value in restored.items()),(arm,'A restore')
        report['graphs'][arm]['live_input_ABA']=True
        if runtime is not None:
            assert guarded.calls>0,'PTO runtime was never invoked'
            report['graphs'][arm]['pto_dispatch_calls']=guarded.calls
            schema=str(runtime.operators.attention._schema)
            expected_namespace='dsv4_csa_tnd_precision_spmd_bf16layout::attention'
            assert schema.startswith(expected_namespace+'('),(arm,schema)
            assert schema.split(' -> ')[0].count('Tensor')==64,(arm,schema)
            report['graphs'][arm]['root_schema']=schema
            report['workspace_bytes']=sum(v.numel()*v.element_size() for v in operators.workspace.buffers.values())
            report['hc_packed_weight_bytes']=runtime.weights['hc_packed_weight'].numel()*runtime.weights['hc_packed_weight'].element_size()
            report['workspace_capture_stream']=operators.workspace.capture_stream
        save()
        print('ARM_PASS',arm,flush=True)
    report['complete']=True;report['pass']=True
    save()
except Exception as exc:
    report['error']=repr(exc)
    save()
    torch.save({'states':states,'inputs':{arm:{'hidden':f['hidden'].cpu(),'positions':f['positions'].cpu(),
                    'initial':{name:g['initial'] for name,g in f['groups'].items()}} for arm,f in fixtures.items()}},args.out/'first-difference.pt')
    raise
print('COMPLETE',report['pass'],lengths,flush=True)
