"""Pack only selected text reports/oracles/helpers; never model/cache tensors."""
from pathlib import Path
import argparse,json,re,tarfile
base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
exp=base/'precision-spmd-20261019'
parser=argparse.ArgumentParser()
parser.add_argument('case',choices=('8k','128k'))
parser.add_argument('--job-name',default='whole-bf16qa126-v2')
args=parser.parse_args()
assert re.fullmatch(r'whole-bf16qa126-[a-z0-9-]+',args.job_name)
job=exp/args.job_name;case=args.case
root=job/f'results/{case}-pto'
audit=json.loads((job/f'audit-{case}.json').read_text());assert audit['pass']
assert not list(root.glob('*STOP.json'))
config=json.loads((root/'configuration.json').read_text())
paths={}
def add(relative,path):
 assert path.is_file(),str(path)
 paths[relative]=path
for p in root.iterdir():
 if p.is_file() and (p.name=='configuration.json' or p.name.endswith('.real_perf.json') or p.name in ('rank0.log','launch.log')):add('candidate/'+p.name,p)
add('audit.json',job/f'audit-{case}.json')
add('preflight.log',job/f'preflight-{case}.log')
add('baseline-environment.json',exp/'BASELINE.json')
add('source-manifest.json',job/'snapshot/manifest.json')
for name in json.loads((job/'helper-manifest.json').read_text())['files']:
 add('tools/'+name,job/name)
add('tools/helper-manifest.json',job/'helper-manifest.json')
for name in ('independent8k.py','independent128k.py','audit_identity.py'):add('tools/qualification-audit/'+name,job/'qualification-audit'/name)
add('formal-bf16qa126-compile.json',exp/'compile-full-csa-bf16layout.json')
add('single-layer-full-t126.json',exp/'results/bf16qa126-full-t126-v2/result.json')
add('single-layer-full-t240.json',exp/'results/bf16qa126-full-t240-v2/result.json')
gold=Path(config['gold'])
for rank in range(16):
 add(f'native-gold/rank{rank}.mixed.json',gold/f'rank{rank}.mixed.json')
 add(f'native-gold/request_stats_rank{rank}.jsonl',gold/f'request_stats_rank{rank}.jsonl')
for label,reference in {
 'native-historical':Path(audit['Native_8k_perf_root'] if case=='8k' else audit['Native_128k_perf_root']),
 'prepack-parent':exp/f'whole-spmd-prepack-v3/results/{case}-pto',
 'spmd-parent':exp/f'whole-spmd-static-v2/results/{case}-pto',
 'frozen-precision':Path(f'/data/pyptouser/yejia/lc128/perf-live-staging-20261019-v2-{case}-pto'),
}.items():
 add(f'{label}/configuration.json',reference/'configuration.json')
 for rank in range(16):add(f'{label}/rank{rank}.real_perf.json',reference/f'rank{rank}.real_perf.json')
for name in audit['tested_sources']:add('runtime-sources/'+name,Path(config['snapshot'])/name)
with tarfile.open(exp/f'{args.job_name}-{case}-evidence.tar.gz','w:gz') as out:
 for name,p in sorted(paths.items()):out.add(p,arcname=name)
print('PACKED',case,len(paths),(exp/f'{args.job_name}-{case}-evidence.tar.gz').stat().st_size)
