"""真实CSA整层FULL ACLGraph变长对拍；不冒充整模型调度器验收。"""
import argparse
import contextlib
import hashlib
import inspect
import json
import os
from pathlib import Path

import torch
import torch_npu
import pypto.torch
from pypto._cache_config import cache_stats
from vllm.config import CUDAGraphMode
from vllm.engine.arg_utils import EngineArgs
from vllm.platforms import current_platform
from vllm.forward_context import get_forward_context
from vllm_ascend.ascend_forward_context import set_ascend_forward_context
import vllm_ascend.ops.dsv4_csa
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.native_adapter import CSAOperators, decode_csa_tp1_layer_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.service import CSAServiceRuntime
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.service import CSAServiceRuntime as CandidateRuntime
from dsv4_csa_single_layer import make_layer, restore, collect_state, guard_checks
from dsv4_csa_native_case import native_session
from dummy_fixture import make_ragged_fixture
from npugraph_ex._acl_concrete_graph.acl_graph import AclGraph

p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args()
a.out.mkdir(exist_ok=True,parents=True);tokens=240
report={'pass':False,'complete':False,'scope':'single-L4 dummy geometry memory-safety only; no numerical golden and no full-model claim','hidden':'same synthetic row repeated; not actual model hidden','cache':'zero cache, shared page0; new allocations per shape, unlike production persistent cache','cases':[]}
def save():(a.out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
current_platform.pre_register_and_update();torch.npu.set_device(0);torch.npu.config.allow_internal_format=True
torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
from vllm_ascend.utils import enable_custom_op
assert enable_custom_op()
checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config=EngineArgs(model=str(checkpoint),tokenizer_mode='deepseek_v4',trust_remote_code=True,tensor_parallel_size=1,dtype='bfloat16',quantization='ascend',hf_overrides={'sliding_window':128},max_model_len=16384,max_num_seqs=40,max_num_batched_tokens=256,enable_prefix_caching=False,enforce_eager=False,block_size=32,speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},compilation_config={'cudagraph_mode':'FULL_DECODE_ONLY','cudagraph_capture_sizes':[tokens],'cache_dir':str(a.out/'vllm-cache')},additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,'fuse_norm_quant':True,'align_decode_capture_sizes':False},'enable_cpu_binding':False,'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False}).create_engine_config()

class PTOHalf(torch.nn.Module):
 def __init__(self,prefix):super().__init__();self.prefix=prefix
 def forward(self,hidden,positions,output):
  torch.ops.vllm.dsv4_csa_forward(hidden,positions,output,self.prefix);return output
class LoggedCall:
 def __init__(self,op,name):self.op=op;self.name=name
 def __getattr__(self,key):return getattr(self.op,key)
 def __call__(self,*args,**kwargs):
  capturing=torch.npu.is_current_stream_capturing()
  print('STAGE_BEGIN',self.name,'T',args[0].shape[0],'capturing',capturing,flush=True)
  if not capturing:torch.npu.synchronize()
  value=self.op(*args,**kwargs)
  if not capturing:torch.npu.synchronize()
  print('STAGE_END',self.name,'capturing',capturing,flush=True)
  return value
class RequirePTO:
 def __init__(self,runtime):self.runtime=runtime
 def eligible(self,*args):
  if not self.runtime.eligible(*args):raise RuntimeError('dummy runtime fallback is forbidden')
  return True
 def __call__(self,*args):return self.runtime(*args)
save()
try:
 with native_session(config,0),torch.inference_mode():
  layer,details=make_layer(config,checkpoint,torch.device('npu:0'),4)
  report['weight_details']=details
  pypto.torch.init()
  core=pypto.torch.register(decode_csa_tp1_layer_test,'diagnostic_dummy_runtime_20261016::forward')
  runtime=CandidateRuntime(layer.self_attn,CSAOperators(LoggedCall(core,'core')),40,layer)
  for name in ('pto_hc_pre','pto_input_norm','pto_hc_post'):setattr(runtime,name,LoggedCall(getattr(runtime,name),name))
  layer.self_attn.dsa_attn._pto_csa_runtime=RequirePTO(runtime)
  module=PTOHalf(layer.self_attn.dsa_attn.prefix);keep=[]
  for tokens,batch in ((240,40),(6,1)):
   f=make_ragged_fixture(config,layer.self_attn,batch,127,1024,torch.device('npu:0'),[6]*batch)
   f['hidden'].copy_(f['hidden'][:1].clone().expand_as(f['hidden']))
   case={'tokens':tokens,'batch':batch,'positions_unique':f['positions'].unique().cpu().tolist(),'metadata':{}}
   report['cases'].append(case);save()
   for name,g in f['groups'].items():
    req=f['metadata'][g['prefix']].decode
    before=None if req.slot_mapping is None else req.slot_mapping.clone()
    g['table'].slot_mapping.gpu.fill_(-1)
    case['metadata'][name]={'bounds':req.query_start_loc.cpu().tolist(),'seq_lens':req.seq_lens.cpu().tolist(),'slot_before_unique_rows':None if before is None else before.unique(dim=0).cpu().tolist(),'slot_after_unique_rows':None if req.slot_mapping is None else req.slot_mapping.unique(dim=0).cpu().tolist(),'compact_slot_unique_rows':f['compact'][name][2].unique(dim=0).cpu().tolist() if name in f['compact'] else None,'block_table_unique':req.block_table.unique().cpu().tolist()}
   save()
   @contextlib.contextmanager
   def context():
    with set_ascend_forward_context(f['metadata'],config,num_tokens=tokens,num_actual_tokens=tokens,aclgraph_runtime_mode=CUDAGraphMode.FULL):yield
   output=torch.empty_like(f['hidden'])
   with context():module(f['hidden'],f['positions'],output)
   torch.npu.synchronize();assert torch.isfinite(output).all(),'nonfinite warmup output';case['warmup_pass']=True;save()
   torch._dynamo.reset();torch.npu.set_compile_mode(jit_compile=False)
   compiled=torch.compile(module,backend='npugraph_ex',fullgraph=True,dynamic=False,options={'force_eager':False,'inplace_pass':True,'clone_input':False,'clone_output':False,'static_kernel_compile':True,'super_kernel_optimize':False})
   instances={};original_run=AclGraph.run
   def trace_run(owner,key,*args,**kwargs):
    instances[(id(owner),key)]=owner;return original_run(owner,key,*args,**kwargs)
   AclGraph.run=trace_run
   try:
    with context():compiled(f['hidden'],f['positions'],output)
    torch.npu.synchronize();assert torch.isfinite(output).all(),'nonfinite capture output'
   finally:AclGraph.run=original_run
   assert len(instances)==1, 'no unique actual graph'
   (_,key),owner=next(iter(instances.items()));graph=owner.graph[key]
   case['capture_pass']=True;save()
   graph.replay();torch.npu.synchronize()
   case['replay_pass']=True;case['output_finite']=bool(torch.isfinite(output).all())
   assert case['output_finite'], 'nonfinite raw replay output'
   save();keep.append((compiled,module,f,output,runtime,owner,graph))
  report['complete']=report['pass']=True;save()
except Exception as e:report['error']=repr(e);save();raise
