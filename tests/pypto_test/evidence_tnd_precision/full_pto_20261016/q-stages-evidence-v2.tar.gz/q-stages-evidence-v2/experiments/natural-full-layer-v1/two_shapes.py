import os,runpy,sys
from pathlib import Path
out=Path(sys.argv[1])
for label,lengths in [('t240',','.join(['6']*40)),('t6','1,2,3')]:
    print('SHAPE_START',label,flush=True)
    sys.argv=[str(Path(__file__).with_name('full_layer_probe.py')),'--out',str(out/label),'--lengths',lengths,'--layer','4','--history','127']
    runpy.run_path(sys.argv[0],run_name='__main__')
    print('SHAPE_PASS',label,flush=True)
