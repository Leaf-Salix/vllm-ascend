"""真实CSA整层FULL ACLGraph变长对拍；不冒充整模型调度器验收。"""
import argparse
import contextlib
import hashlib
import inspect
import json
import os
from pathlib import Path

import torch
import torch_npu
import pypto.torch
from pypto._cache_config import cache_stats
from vllm.config import CUDAGraphMode
from vllm.engine.arg_utils import EngineArgs
from vllm.platforms import current_platform
from vllm.forward_context import get_forward_context
from vllm_ascend.ascend_forward_context import set_ascend_forward_context
import vllm_ascend.ops.dsv4_csa
from stage_probe.native_adapter import CSAOperators, decode_csa_tp1_layer_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.service import CSAServiceRuntime
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.service import CSAServiceRuntime as CandidateRuntime
from dsv4_csa_single_layer import make_layer, restore, collect_state, guard_checks
from dsv4_csa_native_case import native_session
from ragged_fixture import make_ragged_fixture
from npugraph_ex._acl_concrete_graph.acl_graph import AclGraph

parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True);parser.add_argument('--lengths',default='1,2,3,5');parser.add_argument('--layer',type=int,default=4);parser.add_argument('--history',type=int,default=8191)
a=parser.parse_args();lengths=[int(q) for q in a.lengths.split(',')];tokens=sum(lengths);batch=len(lengths)
assert 1<=min(lengths)<=max(lengths)<=6 and batch<=40
assert tokens<=240 and a.history<16384
assert not (a.out/'result.json').exists();a.out.mkdir(parents=True,exist_ok=True)
report={'complete':False,'pass':False,'scope':'T240 then ragged T6 in one process, real L4 weights and Native metadata; FULL graph/runtime isolation, history127, no model/8K numerical claim','baseline_commit':'259cf9a5f; original hybrid math cbc810c8','restored_modules':['hc_pre','input_norm','hc_post'],'candidate_complete_full_pto':False,'single_factor':'Q_A K traversal natural, original final attention heads publication preserved','layer':a.layer,'history':a.history,'query_lengths':lengths,'tokens':tokens,'batch':batch,'per_request_s6_padding':False,'graphs':{},'comparisons':{},'task_device':os.environ['TASK_DEVICE']}
def save(): (a.out/'result.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
def exact(x,y):return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def compare(x,y):
    delta=x.float()-y.float()
    return {'bit_equal':exact(x,y),'mismatches':int((x!=y).sum()),'max_abs':float(delta.abs().max()) if delta.numel() else 0.,'first_coordinates':(x!=y).nonzero()[:8].tolist()}

current_platform.pre_register_and_update();torch.npu.set_device(0);torch.npu.config.allow_internal_format=True
torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
from vllm_ascend.utils import enable_custom_op
assert enable_custom_op()
checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config=EngineArgs(model=str(checkpoint),tokenizer_mode='deepseek_v4',trust_remote_code=True,tensor_parallel_size=1,dtype='bfloat16',quantization='ascend',hf_overrides={'sliding_window':128},max_model_len=16384,max_num_seqs=40,max_num_batched_tokens=256,enable_prefix_caching=False,enforce_eager=False,block_size=32,speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},compilation_config={'cudagraph_mode':'FULL_DECODE_ONLY','cudagraph_capture_sizes':[tokens],'cache_dir':str(a.out/'vllm-cache')},additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,'fuse_norm_quant':True,'align_decode_capture_sizes':False},'enable_cpu_binding':False,'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False}).create_engine_config()

class NativeHalf(torch.nn.Module):
    def __init__(self,layer):super().__init__();self.layer=layer
    def forward(self,hidden,positions,output):
        layer=self.layer;residual=hidden.clone()
        mixed,post,comb=layer.hc_pre(hidden,layer.hc_attn_fn,layer.hc_attn_scale,layer.hc_attn_base)
        normed=layer.input_layernorm(mixed)
        attended=layer.self_attn(positions=positions,hidden_states=normed,llama_4_scaling=None)
        output.copy_(layer.hc_post(attended,residual,post,comb));return output
class PTOHalf(torch.nn.Module):
    def __init__(self,prefix):super().__init__();self.prefix=prefix
    def forward(self,hidden,positions,output):
        torch.ops.vllm.dsv4_csa_forward(hidden,positions,output,self.prefix);return output
class RequirePTO:
    def __init__(self,runtime):self.delegate=runtime;self.calls=0
    def eligible(self,*args):
        if not self.delegate.eligible(*args):raise RuntimeError('ragged PTO fallback is forbidden')
        return True
    def __call__(self,*args,**kwargs):self.calls+=1;return self.delegate(*args,**kwargs)

save()
try:
 with native_session(config,0),torch.inference_mode():
    layer,details=make_layer(config,checkpoint,torch.device('npu:0'),a.layer);report['weight_details']=details
    assert layer.self_attn.compress_ratio==4
    pypto.torch.init()
    fixtures={};states={};b_states={};keepalive=[];observed={}
    impl=layer.self_attn.dsa_attn.dsa_attn.impl
    original_hc_post=layer.hc_post;original_hc_pre=layer.hc_pre
    original_norm_forward=layer.input_layernorm.forward
    def norm_hook(*args,**kwargs):
        value=original_norm_forward(*args,**kwargs);observed['normed']=value;return value
    layer.input_layernorm.forward=norm_hook
    original_qli=torch.ops._C_ascend.npu_vllm_quant_lightning_indexer;original_oproj=impl._forward_o_proj
    def qli_hook(*args,**kwargs):
        value=original_qli(*args,**kwargs);observed['topk']=value[0];return value
    def oproj_hook(heads,output):
        observed['heads']=heads;return original_oproj(heads,output)
    torch.ops._C_ascend.npu_vllm_quant_lightning_indexer=qli_hook;impl._forward_o_proj=oproj_hook
    try:
     for arm in ('native1','candidate'):
        torch._dynamo.reset();arm_lengths=lengths
        f=make_ragged_fixture(config,layer.self_attn,batch,a.history,1024,torch.device('npu:0'),arm_lengths);fixtures[arm]=f
        if arm!='native1':
            assert exact(f['hidden'],fixtures['native1']['hidden'])
            assert exact(f['positions'],fixtures['native1']['positions'])
            for name,g in f['groups'].items():
                assert exact(g['initial'],fixtures['native1']['groups'][name]['initial'])
                assert g['allocation'].data_ptr()!=fixtures['native1']['groups'][name]['allocation'].data_ptr()
        report.setdefault('metadata',{})[arm]={}
        expected=[0];expected.extend(torch.tensor(arm_lengths).cumsum(0).tolist())
        for name,g in f['groups'].items():
            req=f['metadata'][g['prefix']].decode
            bounds=req.query_start_loc.cpu().tolist()
            assert bounds==expected and f['tokens']==tokens,(name,bounds,expected)
            report['metadata'][arm][name]={'query_bounds':bounds,'num_actual_tokens':f['metadata'][g['prefix']].num_actual_tokens,'num_decodes':f['metadata'][g['prefix']].num_decodes,'max_query_len':req.max_seqlen_q}
        runtime=None
        if arm in ('baseline','candidate'):
            op=pypto.torch.register(decode_csa_tp1_layer_test,'diagnostic_natural_full_t240_t6_20261016::forward')
            runtime_type=CandidateRuntime if arm=='candidate' else CSAServiceRuntime
            runtime=runtime_type(layer.self_attn,CSAOperators(op),40,layer)
            if arm=='candidate':
                def reject_native_hc_post(*args,**kwargs):raise RuntimeError('candidate Native HC-post is forbidden')
                layer.hc_post=reject_native_hc_post
                def reject_native_hc_pre(*args,**kwargs):raise RuntimeError('candidate Native HC-pre is forbidden')
                layer.hc_pre=reject_native_hc_pre
                def reject_native_norm(*args,**kwargs):raise RuntimeError('candidate Native input Norm is forbidden')
                layer.input_layernorm.forward=reject_native_norm
            guarded=RequirePTO(runtime);layer.self_attn.dsa_attn._pto_csa_runtime=guarded
        else:layer.self_attn.dsa_attn._pto_csa_runtime=None
        output=torch.empty_like(f['hidden']);module=NativeHalf(layer) if runtime is None else PTOHalf(layer.self_attn.dsa_attn.prefix)
        @contextlib.contextmanager
        def context():
            with set_ascend_forward_context(f['metadata'],config,num_tokens=tokens,num_actual_tokens=tokens,aclgraph_runtime_mode=CUDAGraphMode.FULL):
                assert get_forward_context().cudagraph_runtime_mode is CUDAGraphMode.FULL
                yield
        restore(f)
        with context():module(f['hidden'],f['positions'],output)
        torch.npu.synchronize()
        warm_cache=vars(cache_stats()).copy()
        instances={};old_run=AclGraph.run
        def record_run(owner,key,*args,**kwargs):
            instances[(id(owner),key)]=owner;return old_run(owner,key,*args,**kwargs)
        AclGraph.run=record_run
        options={'force_eager':False,'inplace_pass':True,'clone_input':False,'clone_output':False,'static_kernel_compile':True,'super_kernel_optimize':False}
        torch.npu.set_compile_mode(jit_compile=False)
        try:
            compiled=torch.compile(module,backend='npugraph_ex',fullgraph=True,dynamic=False,options=options)
            restore(f)
            with context():compiled(f['hidden'],f['positions'],output)
            torch.npu.synchronize();assert len(instances)==1, (arm, 'no unique actual ACLGraph')
            (_,key),owner=next(iter(instances.items()));assert not owner._updated_node_infos,'host updated nodes forbidden'
            graph=owner.graph[key];keepalive.append((compiled,module,owner,graph,f,output,runtime))
            topk=lambda:runtime.topk[:tokens] if runtime is not None else observed['topk']
            heads=runtime.native_heads[:tokens] if runtime is not None else observed['heads']
            normed=runtime.normed[:tokens] if arm=='candidate' else observed['normed']
            keepalive.append((heads,topk(),normed))
            restore(f)
            with context():compiled(f['hidden'],f['positions'],output)
            torch.npu.synchronize();via_compiled=collect_state(f,output,topk());via_compiled['heads']=heads.cpu().reshape(tokens,-1);via_compiled['normed']=normed.cpu()
            assert all(v['status']=='PASS' for v in guard_checks(f).values()),(arm,'compiled A guard failure')
            restore(f);graph.replay();torch.npu.synchronize();actual=collect_state(f,output,topk());actual['heads']=heads.cpu().reshape(tokens,-1);actual['normed']=normed.cpu()
            assert all(v['status']=='PASS' for v in guard_checks(f).values()),(arm,'raw A guard failure')
            assert all(exact(v,via_compiled[k]) for k,v in actual.items()),(arm,'compiled/raw replay differs')
            states[arm]=actual
            if arm!='native1':
                comparisons={k:compare(v,states['native1'][k]) for k,v in actual.items()}
                report['comparisons'][arm]=comparisons;save()
                if not all(x['bit_equal'] for x in comparisons.values()):
                    torch.save(states,a.out/'first-difference.pt')
                    raise RuntimeError(f'{arm}: first bit difference; stop before later case')
            hidden_before=f['hidden'].clone();restore(f);f['hidden'].add_(0.125);graph.replay();torch.npu.synchronize()
            assert not exact(output.cpu(),actual['x_out']), (arm,'graph output is stale')
            b_actual=collect_state(f,output,topk());b_actual['heads']=heads.cpu().reshape(tokens,-1);b_actual['normed']=normed.cpu()
            assert not exact(b_actual['normed'],actual['normed']), (arm,'Norm observer is stale on B')
            b_guards=guard_checks(f)
            assert all(v['status']=='PASS' for v in b_guards.values()),(arm,'B guard failure',b_guards)
            assert torch.isfinite(output).all() and torch.isfinite(heads).all() and torch.isfinite(normed).all()
            b_states[arm]=b_actual
            if arm!='native1':
                b_checks={k:compare(v,b_states['native1'][k]) for k,v in b_actual.items()}
                report.setdefault('B_comparisons',{})[arm]=b_checks;save()
                if not all(v['bit_equal'] for v in b_checks.values()):
                    torch.save(b_states,a.out/'first-B-difference.pt')
                    raise RuntimeError(arm+': first B difference; stop')
            f['hidden'].copy_(hidden_before);restore(f);graph.replay();torch.npu.synchronize()
            restored=collect_state(f,output,topk());restored['heads']=heads.cpu().reshape(tokens,-1);restored['normed']=normed.cpu()
            assert all(exact(v,actual[k]) for k,v in restored.items()),(arm,'input ABA replay differs')
            guards=guard_checks(f);assert all(v['status']=='PASS' for v in guards.values()),(arm,'writes outside slots',guards)
            assert torch.isfinite(output).all() and torch.isfinite(heads).all() and torch.isfinite(normed).all()
            report['graphs'][arm]={'real_graph':True,'raw_replays':3,'fullgraph':True,'options':options,'host_updated_nodes':0,'compiled_raw_bit_equal':True,'live_input_ABA_pass':True,'B_state_guards_and_native_oracle':True,'metadata_ABA_tested':False,'pto_dispatch_calls':guarded.calls if runtime else 0,'guards_pass':True}
            if runtime is not None:
                assert guarded.calls>0
                stats=vars(cache_stats()).copy();report.setdefault('cache_stats',{})[arm]={'before_capture':warm_cache,'after_replay':stats}
                assert stats['object_hits']+stats['ready_hits'] > warm_cache['object_hits']+warm_cache['ready_hits'],(arm,'no warmed artifact reuse')
                for field in ('generation_builds','binary_builds','bypasses','invalid_entries','storage_errors','forced_rebuilds'):assert stats[field]==warm_cache[field],(arm,field,'build/cache change after warmup')
        finally:AclGraph.run=old_run
     assert len({id(row[3]) for row in keepalive if len(row)==7})==2
     for arm in ('candidate',):
        assert exact(fixtures[arm]['hidden'],fixtures['native1']['hidden']) and exact(fixtures[arm]['positions'],fixtures['native1']['positions'])
        for name,g in fixtures[arm]['groups'].items():assert exact(g['initial'],fixtures['native1']['groups'][name]['initial'])
     report['native_hc_post_forbidden_in_candidate']=True;report['native_hc_pre_forbidden_in_candidate']=True;report['native_input_norm_forbidden_in_candidate']=True
     assert 'execute op_compiler error' not in (a.out/'run.log').read_text(errors='replace'),'static kernel compilation failed'
     report['complete']=report['pass']=True;save()
    finally:
        torch.ops._C_ascend.npu_vllm_quant_lightning_indexer=original_qli;impl._forward_o_proj=original_oproj;layer.hc_post=original_hc_post;layer.hc_pre=original_hc_pre;layer.input_layernorm.forward=original_norm_forward
except Exception as exc:
    report['error']=repr(exc);save()
    if 'states' in locals():
        torch.save({'states':states,'inputs':{k:{'hidden':f['hidden'].cpu(),'positions':f['positions'].cpu(),'initial':{name:g['initial'] for name,g in f['groups'].items()}} for k,f in fixtures.items()}},a.out/'diagnostic-state.pt')
    raise
print(json.dumps({'pass':report['pass'],'tokens':tokens,'query_lengths':lengths,'graphs':list(report['graphs'])}),flush=True)
