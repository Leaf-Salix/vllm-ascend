#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/full-pto-precision-20261016/step01/env.sh"
experiment_dir="$base/full-pto-precision-20261016/dummy-runtime-v3-multicall"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE" LOCAL_WORLD_SIZE=1 OMP_NUM_THREADS=4
export PYTHONPATH="$experiment_dir:$PYTHONPATH"
python "$base/full-pto-precision-20261016/step01/check_frozen.py"
export SOURCE_ROOT="$base/full-pto-precision-20261016/step05/source"
export PYTHONPATH="$SOURCE_ROOT:$PYTHONPATH"
python "$experiment_dir/check_step05.py"
out="/data/pyptouser/yejia/fp16/${1:?}"
test ! -e "$out"
mkdir -p "$out"
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$SOURCE_ROOT/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$out/opp_env")
export PYPTO_PROG_BUILD_DIR="$out/build" VLLM_CACHE_ROOT="$out/vllm-cache"
export ASCEND_CACHE_PATH="$out/ascend-cache" ASCEND_PROCESS_LOG_PATH="$out/ascend"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/fphc.XXXXXX)
trap 'rmdir "$TMPDIR" 2>/dev/null || true' EXIT
cd "$out"
python "$experiment_dir/dummy_probe.py" --out "$out" > "$out/run.log" 2>&1
