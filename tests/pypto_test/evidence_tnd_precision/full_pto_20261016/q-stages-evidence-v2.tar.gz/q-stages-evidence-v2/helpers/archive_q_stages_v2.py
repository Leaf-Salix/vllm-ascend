"""归档T240缩小诊断；不包含权重或大张量，不宣称整模型根因已确定。"""
from pathlib import Path
import hashlib,json,shutil,tarfile
import torch
root=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/full-pto-precision-20261016')
dst=root/'q-stages-evidence-v2';dst.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(p,rel):
 out=dst/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,out)
labels={'shape-layer-v2':'shapelayer2','q-stage-v1':'qstage1','q-stage-v2':'qstage2','q-stage-v3':'qstage3','q-stage-v4-natural':'qstage4natural','natural-full-layer-v1':'naturalfull1','dummy-runtime-v1':'dummyruntime1','dummy-runtime-v2':'dummyruntime2','dummy-runtime-v3-multicall':'dummychain3'}
for exp,label in labels.items():
 for p in (root/exp).rglob('*'):
  if p.is_file() and p.suffix in ('.py','.sh','.cpp','.json') and '__pycache__' not in p.parts:copy(p,Path('experiments')/exp/p.relative_to(root/exp))
 folder=Path('/data/pyptouser/yejia/fp16')/label
 for p in folder.rglob('result.json'):copy(p,Path('results')/label/p.relative_to(folder))
 for extra in folder.rglob('postrun-log-gate-qualification.json'):copy(extra,Path('results')/label/extra.relative_to(folder))
 if (folder/'run.log').exists():copy(folder/'run.log',Path('results')/label/'run.log')
 p=folder/'q-stage.pt'
 if not p.exists():continue
 data=torch.load(p,map_location='cpu',weights_only=True)
 summary={'raw_snapshot_sha256':sha(p),'scope':'CPU summary of actual NPU snapshots, no CPU golden and no weights','pairs':{}}
 for kind in ('qa','qr','qr_scale','q','q_pre','normed'):
  l,r='native_'+kind,'pto_'+kind
  if l not in data:continue
  x,y=data[l],data[r];mask=x!=y
  def tensor_sha(v):return hashlib.sha256(v.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()
  coords=mask.nonzero()[:48]
  items=[]
  for c in coords.tolist():
   ix=tuple(c);items.append({'coordinate':c,'native':x[ix].item(),'pto':y[ix].item()})
  summary['pairs'][kind]={'shape':list(x.shape),'dtype':str(x.dtype),'native_sha256':tensor_sha(x),'pto_sha256':tensor_sha(y),'mismatch_count':int(mask.sum()),'different_rows':mask.flatten(1).any(1).nonzero().flatten().tolist(),'first_mismatches':items}
 out=dst/'results'/label/'snapshot-summary.json';out.write_text(json.dumps(summary,indent=2)+'\n')
copy(root/'archive_q_stages_v2.py','helpers/archive_q_stages_v2.py')
manifest={str(p.relative_to(dst)):sha(p) for p in sorted(dst.rglob('*')) if p.is_file()}
(dst/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
p=root/'q-stages-evidence-v2.tar.gz'
with tarfile.open(p,'w:gz') as tar:tar.add(dst,arcname=dst.name)
print(json.dumps({'sha256':sha(p),'files':len(manifest),'bytes':p.stat().st_size}))
