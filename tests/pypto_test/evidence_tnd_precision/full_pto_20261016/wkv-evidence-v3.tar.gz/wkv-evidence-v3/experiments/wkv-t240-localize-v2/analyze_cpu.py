"""CPU只读数值分析；FP64仅用于理解舍入，验收gold仍为Native。"""
import json,hashlib
from pathlib import Path
import torch
p=Path('/data/pyptouser/yejia/fp16/wkvm10shapes/t240/first-difference.pt')
torch.set_num_threads(4)
d=torch.load(p,map_location='cpu',weights_only=True)
x,w=d['norm_input'],d['projection_weight']
n,a=d['expected']['output'],d['actual']['output']
ref=x.double()@w.double().T;rounded=ref.bfloat16();via32=ref.float().bfloat16()
coords=(n!=a).nonzero().tolist()
rows=[]
for row,col in coords:
 exact=ref[row,col].item();nv=n[row,col].float().item();av=a[row,col].float().item()
 rows.append(dict(row=row,col=col,native=nv,pto=av,native_bits=int(n[row,col].view(torch.int16)),pto_bits=int(a[row,col].view(torch.int16)),fp64_dot=exact,fp64_rounded=float(rounded[row,col]),fp32_then_bf16=float(via32[row,col]),midpoint=(nv+av)/2,distance_to_midpoint=exact-(nv+av)/2))
report=dict(scope='CPU precision aid, no replacement of Native gold',snapshot_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),native_vs_fp64_round=int((n!=rounded).sum()),pto_vs_fp64_round=int((a!=rounded).sum()),native_vs_fp32_then_bf16=int((n!=via32).sum()),rows=rows)
(p.parent/'cpu-rounding-analysis.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='rows'}))
