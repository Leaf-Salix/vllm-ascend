"""Native-only常规矩阵数值分段；不同T分小任务执行。"""
import argparse,json
from pathlib import Path
import torch,torch_npu
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--first',type=int,required=True);p.add_argument('--last',type=int,required=True);a=p.parse_args();assert 1<=a.first<=a.last<=256 and a.last-a.first<64;a.out.mkdir(exist_ok=False,parents=True)
orders=[]
for width in (1,2,4,8,16):
 for direction in (1,-1):
  for start in range(16//width):
   order=tuple(((start+direction*i)%(16//width))*width+j for i in range(16//width) for j in range(width))
   if order not in orders:orders.append(order)
triples=[(0,5,11),(6,7,8),(2,9,12),(4,6,14),(1,13,15),(3,10,11)]
last={q:[max(q,key=o.index) for o in orders] for q in triples}
signatures=[tuple(last[q][i] for q in triples) for i in range(len(orders))];assert len(set(signatures))==len(orders)
r={'complete':False,'scope':'Native-only finite matrices BF16 T x4096 x512; 44-family hypothesis, not actual-weight accuracy proof','first':a.first,'last':a.last,'orders':[list(o) for o in orders],'triples':[list(q) for q in triples],'cases':[]}
def save():(a.out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def exact(x,y):return torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
torch.npu.set_device(0);torch.npu.config.allow_internal_format=True
torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
save()
try:
 with torch.inference_mode():
  full_x=torch.ones((256,4096),dtype=torch.bfloat16,device='npu');weights={}
  for q in triples:
   for small in q:
    rest=[k for k in q if k!=small];w=torch.zeros((512,4096),dtype=torch.bfloat16)
    w[:,rest[0]*256]=1;w[:,rest[1]*256]=-1;w[:,small*256]=2**-25
    weights[q,small]=torch_npu.npu_format_cast(w.to('npu'),29)
  for tokens in range(a.first,a.last+1):
   case={'tokens':tokens,'complete':False,'queries':[]};r['cases'].append(case);save()
   x=full_x[:tokens];candidates=[set(range(len(orders))) for _ in range(16)]
   for q in triples:
    flags=[]
    for small in q:
     native=torch.nn.functional.linear(x,weights[q,small]);repeat=torch.nn.functional.linear(x,weights[q,small])
     torch.npu.synchronize();v=native.cpu();assert exact(v,repeat.cpu()),'Native repeat mismatch'
     assert bool(((v==0)|(v==2**-25)).all()),'unexpected numeric value'
     assert exact(v,v[0:1].expand_as(v).contiguous()),'row-dependent order needs separate diagnosis'
     assert exact(v[0].reshape(16,32),v[0,::32,None].expand(16,32).contiguous()),'sub-32-column variation needs separate diagnosis'
     flags.append(v[0,::32]==2**-25)
    bits=torch.stack(flags);assert bool((bits.sum(0)==1).all()),'not a single serial last-block relation'
    observed=[q[int(i)] for i in bits.to(torch.int64).argmax(0)]
    candidates=[{i for i in c if last[q][i]==value} for c,value in zip(candidates,observed)]
    case['queries'].append({'triple':list(q),'last_by_column_group':observed,'candidate_counts':[len(c) for c in candidates]});save()
    assert all(candidates),'44-family hypothesis rejected'
   assert all(len(c)==1 for c in candidates),'ambiguous order'
   case['column_group_order_ids']=[next(iter(c)) for c in candidates];case['complete']=True;save()
  r['complete']=True;save()
except Exception as e:r['error']=repr(e);r['stopped_at']=case['tokens'] if 'case' in globals() else None;save();raise
