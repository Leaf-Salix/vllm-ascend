"""普通矩阵乘数值单测：定位累加顺序，不能替代真实权重验收。"""
import argparse,json
from pathlib import Path
import torch,torch_npu,pypto.torch
from wkv import wkv_test
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(exist_ok=False,parents=True)
r={'complete':False,'cases':[],'scope':'same T11/4096/512 and BF16, three nonzero products; first Native/PTO difference stops; synthetic localization only'}
def save():(a.out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def exact(x,y):return torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
torch.npu.set_device(0);torch.npu.config.allow_internal_format=True
torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
with torch.inference_mode():
 x=torch.ones((11,4096),dtype=torch.bfloat16,device='npu');w=torch.zeros((512,4096),dtype=torch.bfloat16,device='npu')
 out=torch.empty((11,512),dtype=torch.bfloat16,device='npu')
 pypto.torch.init(device=0,platform='a2a3',runtime='tensormap_and_ringbuffer')
 op=pypto.torch.register(wkv_test,'diagnostic_wkv_order_case_v9_20261017::forward')
 save()
 try:
  for positive,small,negative in ((0,2048,1),(0,256,1),(0,128,1),(0,64,1),(0,16,1),(0,1,2),(0,16,32),(0,128,256),(0,2048,4095)):
   cpu=torch.zeros((512,4096),dtype=torch.bfloat16);cpu[:,positive]=1;cpu[:,small]=2**-25;cpu[:,negative]=-1
   w.copy_(cpu)
   nz=torch_npu.npu_format_cast(w,29)
   native=torch.nn.functional.linear(x,nz);native2=torch.nn.functional.linear(x,nz)
   torch.npu.synchronize();n=native.cpu();assert exact(n,native2.cpu()),'Native repeat mismatch'
   op(x,w,out);torch.npu.synchronize();v=out.cpu()
   case={'positions':[positive,small,negative],'exact_real_sum':2**-25,'bit_equal':exact(n,v),'different_elements':int((n!=v).sum()),'native_row0':n[0].float().tolist(),'pto_row0':v[0].float().tolist()}
   r['cases'].append(case);save()
   if not case['bit_equal']:
    torch.save({'native':n,'pto':v},a.out/'first-difference.pt')
    r['first_difference']=case['positions'];save();raise RuntimeError('FIRST_REDUCTION_ORDER_DIFFERENCE')
  r['complete']=True;save()
 except Exception as e:r['error']=repr(e);save();raise
