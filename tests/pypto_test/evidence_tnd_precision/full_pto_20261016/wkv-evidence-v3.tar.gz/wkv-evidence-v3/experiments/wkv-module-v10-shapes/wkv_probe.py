"""实际Native HC-pre输入和正式Norm权重；首个模块差异后退出。"""
import argparse,hashlib,json,os
from pathlib import Path
import torch,torch_npu,pypto.torch
from safetensors import safe_open
from vllm_ascend.utils import enable_custom_op
from wkv import wkv_test
from vllm.engine.arg_utils import EngineArgs
from vllm.platforms import current_platform
from dsv4_csa_single_layer import make_layer
from dsv4_csa_native_case import native_session
import contextlib
current_platform.pre_register_and_update()
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--tokens',type=int,required=True);p.add_argument('--layer',type=int,default=4);p.add_argument('--seed',type=int,default=17);a=p.parse_args();assert 1<=a.tokens<=240 and a.layer%2==0 and 2<=a.layer<=42
a.out.mkdir(exist_ok=False,parents=True)
r={'pass':False,'complete':False,'module':'WKV projection BF16 boundary, dynamic T N32 K512 pair-rotation candidate','layer':a.layer,'tokens':a.tokens,'seed':a.seed,'scope':'actual selected-layer Native HCpre+Norm input, actual self_attn.wkv gold; real complete layer loaded; no full-model claim','comparisons':[],'task_device':os.environ['TASK_DEVICE'],'production_modified':False}
def save(): (a.out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def exact(x,y): return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def snapshot(values):
    torch.npu.synchronize();return {k:v.cpu() for k,v in values.items()}
def check(label,actual,expected):
    results={}
    for k,x in actual.items():
        y=expected[k];assert torch.isfinite(x).all() and torch.isfinite(y).all(),(label,k,'nonfinite');diff=x.float()-y.float()
        results[k]={'bit_equal':exact(x,y),'different_elements':int((x!=y).sum()),'max_abs':float(diff.abs().max()),'rel_l2':float(diff.norm()/y.float().norm()),'first_coordinates':(x!=y).nonzero()[:8].tolist()}
    r['comparisons'].append({'label':label,'metrics':results});save()
    if not all(v['bit_equal'] for v in results.values()):
        torch.save({'actual':actual,'expected':expected,'norm_input':x_norm.cpu(),'projection_weight':weight.cpu()},a.out/'first-difference.pt')
        raise RuntimeError('FIRST_BIT_DIFFERENCE '+label)

torch.npu.set_device(0);torch.npu.config.allow_internal_format=True;torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
assert enable_custom_op()
tokens=a.tokens
checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config=EngineArgs(model=str(checkpoint),tokenizer_mode='deepseek_v4',trust_remote_code=True,tensor_parallel_size=1,dtype='bfloat16',quantization='ascend',hf_overrides={'sliding_window':128},max_model_len=16384,max_num_seqs=40,max_num_batched_tokens=256,enable_prefix_caching=False,enforce_eager=False,block_size=32,speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},compilation_config={'cudagraph_mode':'FULL_DECODE_ONLY','cudagraph_capture_sizes':[tokens],'cache_dir':str(a.out/'vllm-cache')},additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,'fuse_norm_quant':True,'align_decode_capture_sizes':False},'enable_cpu_binding':False,'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False}).create_engine_config()
keep_native=contextlib.ExitStack();keep_native.enter_context(native_session(config,0))
with torch.inference_mode():
 layer,details=make_layer(config,checkpoint,torch.device('npu:0'),a.layer)
r['weight_details']=details
wkv_layer=layer.self_attn.wkv
r['native_WKV']={'class':type(wkv_layer).__name__,'quant_method':type(wkv_layer.quant_method).__name__,'weight_dtype':str(wkv_layer.weight.dtype),'weight_shape':list(wkv_layer.weight.shape),'weight_format':int(torch_npu.get_npu_format(wkv_layer.weight))}
assert wkv_layer.weight.dtype==torch.bfloat16 and tuple(wkv_layer.weight.shape)==(512,4096)
assert wkv_layer.bias is None
# Only layout preparation for PTO, no dtype change or numerical preprocessing.
weight_nd=torch_npu.npu_format_cast(wkv_layer.weight.detach(),2).contiguous()
weight=weight_nd;weight_before=weight.clone()
hidden=torch.randn((tokens,4,4096),generator=torch.Generator().manual_seed(a.seed),dtype=torch.bfloat16).to('npu')
original_hidden=hidden.clone()
def mixed():return layer.input_layernorm(layer.hc_pre(hidden,layer.hc_attn_fn,layer.hc_attn_scale,layer.hc_attn_base)[0])
with torch.inference_mode():
 x_norm=mixed();input_a=x_norm.clone()
def native():return {'output':wkv_layer(x_norm)}
save()
try:
 with torch.inference_mode():
    gold=snapshot(native());check('native_repeat_A',snapshot(native()),gold)
    check('native_ND_layout_control_A',snapshot({'output':torch.nn.functional.linear(x_norm,weight_nd)}),gold)
    graph=torch.npu.NPUGraph()
    with torch.npu.graph(graph): native_outputs=native()
    graph_keep=(graph,native_outputs)
    for phase in ('A','B','A_restored'):
        hidden.copy_(original_hidden)
        if phase=='B':hidden.add_(0.125)
        x_norm.copy_(mixed())
        expected=snapshot(native());check('native_repeat_'+phase,snapshot(native()),expected)
        for v in native_outputs.values():v.fill_(float('nan'))
        graph.replay();check('native_graph_'+phase,snapshot(native_outputs),expected)
        if phase=='B':
            assert not exact(x_norm,input_a)
            assert any(not exact(expected[k],gold[k]) for k in expected), 'Native B output unchanged'
        else:check('native_restored_'+phase,expected,gold)
    r['native_qualification_pass']=True;save()
    pypto.torch.init(device=0,platform='a2a3',runtime='tensormap_and_ringbuffer')
    op=pypto.torch.register(wkv_test,'diagnostic_full_pto_wkv_v10_20261017::k128_forward')
    owners={'output':torch.full((tokens+2,512),.0625,dtype=torch.bfloat16,device='npu')}
    outputs={k:v[1:-1] for k,v in owners.items()}
    def run():op(x_norm,weight,outputs['output'])
    def actual():
        values=snapshot(outputs)
        assert all(bool((v[0]==.0625).all() & (v[-1]==.0625).all()) for v in owners.values())
        assert exact(weight,weight_before)
        return values
    for v in outputs.values():v.fill_(float('nan'))
    eager_before=x_norm.clone();run();observed=actual()
    assert exact(eager_before,x_norm), 'PTO eager changed input'
    r['eager_input_and_guard_checks_pass']=True;save()
    check('PTO_eager_A',observed,gold)
    graph=torch.npu.NPUGraph()
    with torch.npu.graph(graph):run()
    graph_keep_pto=(graph,op,owners,x_norm,weight)
    for phase in ('A','B','A_restored'):
        hidden.copy_(original_hidden)
        if phase=='B':hidden.add_(0.125)
        x_norm.copy_(mixed());before=x_norm.clone();expected=snapshot(native())
        check('native_repeat_pto_'+phase,snapshot(native()),expected)
        for v in outputs.values():v.fill_(float('nan'))
        graph.replay();check('PTO_graph_'+phase,actual(),expected)
        assert exact(before,x_norm)
    r.update({'pass':True,'complete':True,'raw_graph_ABA_pass':True});save()
except Exception as e:r['error']=repr(e);save();raise

finally:keep_native.close()
