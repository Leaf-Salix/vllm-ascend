"""已保存真实权重与归一化输入的行数边界复核；第一bit差异即退出。"""
import argparse,json
from pathlib import Path
import torch,torch_npu,pypto.torch
from wkv import wkv_test
import hashlib
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(exist_ok=False,parents=True)
r={'complete':False,'pass':False,'scope':'saved L4 real WKV weight, Native-normalized rows reused across shapes; operator-only, not whole model','cases':[],'device_name':None}
def save():(a.out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def exact(x,y):return torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def host(x):torch.npu.synchronize();return x.cpu()
def check(label,actual,expected):
 assert torch.isfinite(actual).all() and torch.isfinite(expected).all()
 diff=actual.float()-expected.float()
 m={'label':label,'bit_equal':exact(actual,expected),'different_elements':int((actual!=expected).sum()),'max_abs':float(diff.abs().max()),'first_coordinates':(actual!=expected).nonzero()[:8].tolist()}
 case['comparisons'].append(m);save()
 if not m['bit_equal']:
  torch.save({'actual':actual,'expected':expected,'input':x.cpu(),'weight':w.cpu(),'order':order.cpu()},a.out/'first-difference.pt')
  raise RuntimeError('FIRST_BIT_DIFFERENCE '+label)
def load_order(tokens):
 root=Path('/data/pyptouser/yejia/fp16')
 if tokens<=64:
  p=root/'wkvmap1to64/result/result.json';grain=32
 elif tokens<=128:
  p=root/'wkvmap65to128v2/result/result.json';grain=16
 else:
  assert tokens==240
  p=root/'wkvt240order1/result/result.json';grain=1
 data=json.loads(p.read_text());assert data['complete']
 if grain==1:
  rows=data['column_orders'];assert len(rows)==512
  for group in range(32):assert all(rows[group*16]==v for v in rows[group*16:(group+1)*16])
  table=[rows[group*16] for group in range(32)]
 else:
  c=next(c for c in data['cases'] if c['tokens']==tokens);assert c['complete']
  ids=c['column_group_order_ids'];table=[data['orders'][ids[col//grain]] for col in range(0,512,16)]
 assert len(table)==32 and all(sorted(row)==list(range(16)) for row in table)
 return torch.tensor(table,dtype=torch.int32),{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
torch.npu.set_device(0);torch.npu.config.allow_internal_format=True
torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
d=torch.load('/data/pyptouser/yejia/fp16/wkvm10shapes/t240/first-difference.pt',map_location='cpu',weights_only=True)
save()
try:
 with torch.inference_mode():
  w=d['projection_weight'].to('npu');nz=torch_npu.npu_format_cast(w,29);saved=d['norm_input']
  assert exact(host(torch.nn.functional.linear(saved.to('npu'),nz)),d['expected']['output']),'saved Native gold changed'
  pypto.torch.init(device=0,platform='a2a3',runtime='tensormap_and_ringbuffer')
  op=pypto.torch.register(wkv_test,'diagnostic_wkv_v16_order_input::forward')
  r['device_name']=torch.npu.get_device_name(0)
  keep=[]
  for tokens in (11,16,64,65,80,128,240):
   case={'tokens':tokens,'candidate':'N16 K256 Native order input','comparisons':[]};r['cases'].append(case);save()
   cpu=saved[:tokens] if tokens<=240 else torch.cat((saved,saved[:tokens-240]))
   x=cpu.contiguous().to('npu');initial=x.clone();weight_before=w.clone()
   owner=torch.full((tokens+2,512),.0625,dtype=torch.bfloat16,device='npu');out=owner[1:-1]
   order_cpu,identity=load_order(tokens)
   case['order_source']=identity;save()
   order=order_cpu.to('npu');order_before=order.clone()
   def native():return torch.nn.functional.linear(x,nz)
   def run():op(x,w,order,out)
   expected=host(native());gold=expected.clone();check('Native_repeat_A',host(native()),expected)
   check('Native_ND_A',host(torch.nn.functional.linear(x,w)),expected)
   run();check('PTO_eager_A',host(out),expected)
   assert exact(x,initial) and exact(w,weight_before) and exact(order,order_before)
   ng=torch.npu.NPUGraph()
   with torch.npu.graph(ng):native_out=native()
   pg=torch.npu.NPUGraph()
   with torch.npu.graph(pg):run()
   keep.append((ng,native_out,pg,owner,x,w,order,op))
   for phase in ('A','B','A_restored'):
    x.copy_(initial)
    if phase=='B':x.copy_(initial.roll(1,dims=1));x.add_(.03125)
    before=x.clone();expected=host(native());check('Native_repeat_'+phase,host(native()),expected)
    if phase=='B':assert not exact(expected,gold), 'Native B did not change'
    else:check('Native_restore_'+phase,expected,gold)
    native_out.fill_(float('nan'));ng.replay();check('Native_graph_'+phase,host(native_out),expected)
    out.fill_(float('nan'));pg.replay();check('PTO_graph_'+phase,host(out),expected)
    assert exact(x,before) and exact(w,weight_before) and exact(order,order_before)
    assert bool((owner[0]==.0625).all() & (owner[-1]==.0625).all())
   case['pass']=True;save()
  r.update(complete=True);r['pass']=True;save()
except Exception as e:r['error']=repr(e);save();raise
