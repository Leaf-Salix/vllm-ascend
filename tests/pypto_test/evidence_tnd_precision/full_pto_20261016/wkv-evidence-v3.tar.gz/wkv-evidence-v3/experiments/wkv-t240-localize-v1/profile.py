"""对同一已保存WKV输入，确认Native ND/NZ输出并记录实际矩阵核。"""
import argparse,json
from pathlib import Path
import torch,torch_npu
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(exist_ok=False,parents=True)
torch.npu.set_device(0);torch.npu.config.allow_internal_format=True
torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
d=torch.load('/data/pyptouser/yejia/fp16/wkvm10shapes/t240/first-difference.pt',map_location='cpu',weights_only=True)
with torch.inference_mode():
 x=d['norm_input'].to('npu');w=d['projection_weight'].contiguous().to('npu');nz=torch_npu.npu_format_cast(w,29)
 def check(v):
  torch.npu.synchronize();assert torch.equal(v.cpu().view(torch.uint8),d['expected']['output'].contiguous().view(torch.uint8)), 'Native snapshot mismatch'
 check(torch.nn.functional.linear(x,w));check(torch.nn.functional.linear(x,nz))
 graph=torch.npu.NPUGraph()
 with torch.npu.graph(graph):output=torch.nn.functional.linear(x,nz)
 graph.replay();check(output)
 with torch_npu.profiler.profile(
  activities=[torch_npu.profiler.ProfilerActivity.CPU,torch_npu.profiler.ProfilerActivity.NPU],
  schedule=torch_npu.profiler.schedule(wait=0,warmup=0,active=1,repeat=1),
  record_shapes=True,profile_memory=False,with_stack=False,with_modules=False,
  experimental_config=torch_npu.profiler._ExperimentalConfig(profiler_level=torch_npu.profiler.ProfilerLevel.Level1),
  on_trace_ready=torch_npu.profiler.tensorboard_trace_handler(str(a.out/'profile'))
 ) as trace:
  graph.replay();torch.npu.synchronize();trace.step()
 check(output)
 (a.out/'result.json').write_text(json.dumps(dict(passed=True,native_ND_NZ_graph_snapshot_bit_equal=True,scope='Native WKV exact saved L4/T240 inputs, graph replay profile; not full-model Native2 or timing comparison'),indent=2)+'\n')
