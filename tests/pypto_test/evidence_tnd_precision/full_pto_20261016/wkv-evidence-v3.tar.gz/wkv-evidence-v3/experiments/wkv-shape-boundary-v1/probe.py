"""已保存真实权重与归一化输入的行数边界复核；第一bit差异即退出。"""
import argparse,json
from pathlib import Path
import torch,torch_npu,pypto.torch
from wkv_small import wkv_test as small
from wkv_large import wkv_test as large
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(exist_ok=False,parents=True)
r={'complete':False,'pass':False,'scope':'saved L4 real WKV weight, Native-normalized rows reused across shapes; operator-only, not whole model','cases':[]}
def save():(a.out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def exact(x,y):return torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def host(x):torch.npu.synchronize();return x.cpu()
def check(label,actual,expected):
 diff=actual.float()-expected.float()
 m={'label':label,'bit_equal':exact(actual,expected),'different_elements':int((actual!=expected).sum()),'max_abs':float(diff.abs().max()),'first_coordinates':(actual!=expected).nonzero()[:8].tolist()}
 case['comparisons'].append(m);save()
 if not m['bit_equal']:
  torch.save({'actual':actual,'expected':expected,'input':x.cpu(),'weight':w.cpu()},a.out/'first-difference.pt')
  raise RuntimeError('FIRST_BIT_DIFFERENCE '+label)
torch.npu.set_device(0);torch.npu.config.allow_internal_format=True
torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
d=torch.load('/data/pyptouser/yejia/fp16/wkvm10shapes/t240/first-difference.pt',map_location='cpu',weights_only=True)
save()
try:
 with torch.inference_mode():
  w=d['projection_weight'].to('npu');nz=torch_npu.npu_format_cast(w,29);saved=d['norm_input']
  assert exact(host(torch.nn.functional.linear(saved.to('npu'),nz)),d['expected']['output']),'saved Native gold changed'
  pypto.torch.init(device=0,platform='a2a3',runtime='tensormap_and_ringbuffer')
  ops=[pypto.torch.register(small,'diagnostic_wkv_shape_v1::small'),pypto.torch.register(large,'diagnostic_wkv_shape_v1::large')]
  keep=[]
  for tokens in (1,18,64,128,256):
   case={'tokens':tokens,'candidate':'small' if tokens<=128 else 'large','comparisons':[]};r['cases'].append(case);save()
   cpu=saved[:tokens] if tokens<=240 else torch.cat((saved,saved[:tokens-240]))
   x=cpu.contiguous().to('npu');initial=x.clone();weight_before=w.clone()
   owner=torch.full((tokens+2,512),.0625,dtype=torch.bfloat16,device='npu');out=owner[1:-1]
   op=ops[0 if tokens<=128 else 1]
   def native():return torch.nn.functional.linear(x,nz)
   def run():op(x,w,out)
   expected=host(native());check('Native_repeat_A',host(native()),expected)
   check('Native_ND_A',host(torch.nn.functional.linear(x,w)),expected)
   run();check('PTO_eager_A',host(out),expected)
   assert exact(x,initial) and exact(w,weight_before)
   ng=torch.npu.NPUGraph()
   with torch.npu.graph(ng):native_out=native()
   pg=torch.npu.NPUGraph()
   with torch.npu.graph(pg):run()
   keep.append((ng,native_out,pg,owner,x,w,op))
   for phase in ('A','B','A_restored'):
    x.copy_(initial)
    if phase=='B':x.mul_(.5)
    before=x.clone();expected=host(native());check('Native_repeat_'+phase,host(native()),expected)
    native_out.fill_(float('nan'));ng.replay();check('Native_graph_'+phase,host(native_out),expected)
    out.fill_(float('nan'));pg.replay();check('PTO_graph_'+phase,host(out),expected)
    assert exact(x,before) and exact(w,weight_before)
    assert bool((owner[0]==.0625).all() & (owner[-1]==.0625).all())
   case['pass']=True;save()
  r.update(complete=True,pass_=True);r['pass']=True;save()
except Exception as e:r['error']=repr(e);save();raise
