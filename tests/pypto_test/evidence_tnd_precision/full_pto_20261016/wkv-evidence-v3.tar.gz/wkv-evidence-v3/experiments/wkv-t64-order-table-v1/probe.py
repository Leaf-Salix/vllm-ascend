"""普通有限值矩阵单测：区分循环K块次序；不改变设备状态或正式源码。"""
import argparse,itertools,json
from pathlib import Path
import torch,torch_npu
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(exist_ok=False,parents=True)
r={'complete':False,'scope':'Native-only T64 BF16 4096x512, finite sum-order localization, cyclic-order hypothesis only','queries':[],'tokens':64,'k_block':256,'max_queries':20}
def save():(a.out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def exact(x,y):return torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
orders=[]
for width in (1,2,4,8,16):
 for direction in (1,-1):
  for start in range(16//width):
   order=tuple((((start+direction*i)%(16//width))*width+j) for i in range(16//width) for j in range(width))
   if order not in orders:orders.append(order)
r['candidate_order_count']=len(orders)
r['candidate_families']='cyclic/reverse K256/512/1024/2048/4096 blocks, natural sub-blocks'

triples=list(itertools.combinations(range(16),3))
last={q:[max(q,key=order.index) for order in orders] for q in triples}
candidates=[set(range(len(orders))) for _ in range(512)]
torch.npu.set_device(0);torch.npu.config.allow_internal_format=True
torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
save()
try:
 with torch.inference_mode():
  x=torch.ones((64,4096),dtype=torch.bfloat16,device='npu')
  used=set()
  for iteration in range(20):
   active=set(frozenset(c) for c in candidates if len(c)>1)
   if not active:break
   def score(q):
    return sum(len(c)-max(sum(last[q][i]==v for i in c) for v in q) for c in active)
   q=max((q for q in triples if q not in used),key=score);assert score(q)>0,'cyclic orders indistinguishable'
   used.add(q);observed=[]
   for small in q:
    remaining=[k for k in q if k!=small]
    weight=torch.zeros((512,4096),dtype=torch.bfloat16)
    weight[:,remaining[0]*256]=1;weight[:,remaining[1]*256]=-1;weight[:,small*256]=2**-25
    nz=torch_npu.npu_format_cast(weight.to('npu'),29)
    native=torch.nn.functional.linear(x,nz);repeat=torch.nn.functional.linear(x,nz)
    torch.npu.synchronize();v=native.cpu();assert exact(v,repeat.cpu()),'Native repeated values differ'
    assert bool(((v==0)|(v==2**-25)).all()),'unexpected finite sum'
    assert exact(v,v[0:1].expand_as(v).contiguous()),'row-dependent order requires separate analysis'
    observed.append(v[0]==2**-25)
   bits=torch.stack(observed);assert bool((bits.sum(0)==1).all()),'not a single serial last-block relation'
   selected=[q[int(i)] for i in bits.to(torch.int64).argmax(0)]
   for col,value in enumerate(selected):candidates[col]={i for i in candidates[col] if last[q][i]==value}
   record={'triple':list(q),'small_is_last_by_column':selected,'remaining_count_by_column':[len(c) for c in candidates]}
   r['queries'].append(record);save()
   assert all(candidates),'contiguous-block cyclic hypothesis rejected'
  assert all(len(c)==1 for c in candidates),'query budget reached before unique order'
  r['column_orders']=[list(orders[next(iter(c))]) for c in candidates]
  r['complete']=True;save()
except Exception as e:r['error']=repr(e);save();raise
