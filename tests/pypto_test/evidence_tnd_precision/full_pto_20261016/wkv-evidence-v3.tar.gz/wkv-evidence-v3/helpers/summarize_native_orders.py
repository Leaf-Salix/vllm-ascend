"""CPU汇总已完成Native分段，校验原查询及T64/T240独立定位，输出限定范围的次序表。"""
from pathlib import Path
import json,hashlib
base=Path('/data/pyptouser/yejia/fp16')
root=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/full-pto-precision-20261017')
labels=('wkvmap1to64','wkvmap65to128v2','wkvmap129to192','wkvmap193to256')
all_rows={};sources={};master_orders=None
for label in labels:
 p=base/label/'result/result.json';d=json.loads(p.read_text());assert d['complete']
 sources[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
 if master_orders is None:master_orders=d['orders']
 assert master_orders==d['orders']
 grain=d.get('column_grain',32)
 for c in d['cases']:
  assert c['complete'] and len(c['queries'])==6 and c['tokens'] not in all_rows
  ids=c['column_group_order_ids'];assert len(ids)*grain==512
  for q in c['queries']:
   assert all(v==1 for v in q['candidate_counts']) if q is c['queries'][-1] else True
   assert [max(q['triple'],key=master_orders[i].index) for i in ids]==q['last_by_column_group']
  table=[master_orders[ids[col//grain]] for col in range(0,512,16)]
  assert all(sorted(v)==list(range(16)) for v in table)
  all_rows[c['tokens']]=table
assert sorted(all_rows)==list(range(1,257))
for tokens,label in ((64,'wkvt64order1'),(240,'wkvt240order1')):
 p=base/label/'result/result.json';d=json.loads(p.read_text());assert d['complete']
 sources[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
 assert all_rows[tokens]==[d['column_orders'][col] for col in range(0,512,16)]
modes=[];token_modes=[]
for t in range(1,257):
 table=all_rows[t]
 if table not in modes:modes.append(table)
 token_modes.append(modes.index(table))
r={'scope':'Ascend910_9392 CANN9.2 Native finite-matrix order qualification, not arbitrary-weight or full-model proof','sources':sources,'first_tokens':1,'last_tokens':256,'column_grain':16,'k_block':256,'tokens_to_mode':token_modes,'modes':modes}
p=root/'native_wkv_order_map.json';p.write_text(json.dumps(r,indent=2)+'\n')
print('map',len(modes),'modes',p,'sha256',hashlib.sha256(p.read_bytes()).hexdigest())
for mode in range(len(modes)):
 ts=[t for t,i in enumerate(token_modes,1) if i==mode];print(mode,ts)
