"""保存普通WKV数值实验，不打包权重或大型Tensor快照。"""
from pathlib import Path
import json,hashlib,shutil,tarfile
root=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/full-pto-precision-20261017')
dst=root/'wkv-evidence-v3';dst.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(p,n):
 q=dst/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
labels={'wkv-module-v2':'wkvm2','wkv-module-v3':'wkvm3','wkv-module-v4-nt':'wkvm4nt','wkv-module-v5-k256':'wkvm5k256','wkv-module-v6-n32':'wkvm6n32','wkv-module-v7-split2':'wkvm7split2','wkv-module-v8-native-order':'wkvm8native','wkv-native-profile-v1':'wkvnativeprof1','wkv-order-case-v1':'wkvorder1','wkv-module-v9-order512':'wkvm9order512','wkv-module-v10-shapes':'wkvm10shapes','wkv-t240-localize-v1':'wkvt240loc1','wkv-t240-localize-v2':'wkvt240loc2','wkv-module-v11-t240':'wkvm11t240','wkv-t240-order-table-v1':'wkvt240order1','wkv-module-v12-t240-table':'wkvm12t240','wkv-module-v13-layers240':'wkvm13layers','wkv-shape-boundary-v1':'wkvshapes1','wkv-t64-order-table-v1':'wkvt64order1','wkv-module-v15-t64':'wkvm15t64','wkv-native-shape-map-v1':'wkvmap1to64','wkv-native-shape-map-v2':'wkvmap65to128v2','wkv-module-v16-order-input':'wkvm16table','wkv-module-v17-all-shapes':'wkvm17t1to64'}
for exp,label in labels.items():
 for p in (root/exp).iterdir():
  if p.is_file() and p.suffix in ('.py','.sh','.log'):copy(p,Path('experiments')/exp/p.name)
 folder=Path('/data/pyptouser/yejia/fp16')/label
 for pattern in ('run.log','order.log','profile.log','profile-result/*.json','profile-result/profile/**/kernel_details.csv','profile-result/profile/**/op_statistic.csv','order/*.json','result/*.json','t*.log','t*/*.json','l*.log','l*/*.json','result/profile/**/kernel_details.csv','result/profile/**/op_statistic.csv'):
  for p in folder.glob(pattern):
   if p.is_file():copy(p,Path('results')/label/p.relative_to(folder))
 for pattern in ('result/first-difference.pt','order/first-difference.pt','t*/first-difference.pt','l*/first-difference.pt'):
  for p in folder.glob(pattern):
   q=dst/'results'/label/p.relative_to(folder).with_suffix('.identity.json');q.parent.mkdir(parents=True,exist_ok=True);q.write_text(json.dumps({'sha256':sha(p),'bytes':p.stat().st_size,'excluded':'may include model weight; not archived'},indent=2)+'\n')
for label in ('wkvmap65to128','wkvmap129to192','wkvmap193to256','wkvm17t65to128','wkvm17t129to192','wkvm17t193to256'):
 folder=Path('/data/pyptouser/yejia/fp16')/label
 for pattern in ('run.log','result/*.json'):
  for p in folder.glob(pattern):
   if p.is_file():copy(p,Path('results')/label/p.relative_to(folder))
early=root.parent/'full-pto-precision-20261016/wkv-module-v1'
assert early.is_dir()
for p in early.iterdir():
 if p.is_file() and p.suffix in ('.py','.sh','.log'):copy(p,Path('experiments/wkv-module-v1')/p.name)
copy(root/'collect_wkv_v3.py','helpers/collect_wkv_v3.py')
copy(root/'wkv-task-map-v3.json','helpers/wkv-task-map-v3.json')
copy(root/'summarize_native_orders.py','helpers/summarize_native_orders.py')
copy(root/'native_wkv_order_map.json','helpers/native_wkv_order_map.json')
manifest={str(p.relative_to(dst)):sha(p) for p in sorted(dst.rglob('*')) if p.is_file()}
(dst/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
p=root/'wkv-evidence-v3.tar.gz'
with tarfile.open(p,'w:gz') as t:t.add(dst,arcname=dst.name)
print(json.dumps(dict(sha256=sha(p),files=len(manifest),bytes=p.stat().st_size)))
