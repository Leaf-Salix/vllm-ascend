import importlib.util
from pathlib import Path
import pytest
p=Path(__file__).with_name('mixed.py')
spec=importlib.util.spec_from_file_location('mixed_diagnostic',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def rows(variant='tnd_full_precision',backend='pto'):
 package='deepseek_v4_flash_csa_'+variant+'.service'
 return [[{'kind':'csa','implementation':backend,'runtime_class':'vllm_ascend.ops.pypto.'+package if backend=='pto' else None} for _ in range(21)]+[{'kind':'hca','implementation':'native','runtime_class':None} for _ in range(20)]]
@pytest.mark.parametrize('variant',['tnd_precision','tnd_full_precision'])
def test_allowed_exact_runtime(variant):m.validate_implementations(rows(variant),'pto',variant)
def test_native():m.validate_implementations(rows(backend='native'),'native','tnd_full_precision')
@pytest.mark.parametrize('kind',['wrong_package','missing_csa','hca_replaced','unknown_variant','native_contains_pto','none_package','missing_hca','empty','empty_worker'])
def test_reject(kind):
 r=rows();backend='pto';variant='tnd_full_precision'
 if kind=='wrong_package':r[0][0]['runtime_class']='vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.service'
 if kind=='missing_csa':r[0].pop(0)
 if kind=='hca_replaced':r[0][-1]['implementation']='pto'
 if kind=='unknown_variant':variant='tnd_performance'
 if kind=='native_contains_pto':backend='native'
 if kind=='none_package':r[0][0]['runtime_class']=None
 if kind=='missing_hca':r[0].pop()
 if kind=='empty':r=[]
 if kind=='empty_worker':r=[[]]
 with pytest.raises((AssertionError,ValueError)):m.validate_implementations(r,backend,variant)
