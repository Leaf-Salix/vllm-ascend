"""保存两臂全部数值原件，不含模型权重/venv/大型设备dump。"""
from pathlib import Path
import hashlib,json,shutil,tarfile,subprocess
base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
job=base/'full-pto-model-8k-b40-20261016';h=job/'production-v1'
dst=h/'production1-evidence';dst.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(p,n):
 q=dst/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
for arm,label in (('native','full-pto8k-native-20261016'),('csa','full-pto8k-production1-20261017')):
 root=Path('/data/pyptouser/yejia/lc128')/label
 for pattern in ('configuration.json','launch.log','rank*.mixed.json','rank*.log','request_stats_rank*.jsonl','input-trace/*.json','input-trace/*.jsonl','full-probe/*.json','full-probe/*.jsonl','acceptance.json'):
  for p in root.glob(pattern):copy(p,Path('results')/arm/p.relative_to(root))
for folder in (job,h,job/'reference',job/'native1-generation-reference',job/'native1-generation-reference/input-trace',job/'native1-generation-reference/full-probe'):
 for p in folder.iterdir():
  if p.is_file() and p.suffix in ('.py','.sh','.json','.jsonl'):
   copy(p,Path('helpers')/p.relative_to(job))
for stage in ('step05','step06','step07'):
 p=base/'full-pto-precision-20261016'/stage/'manifest.json';copy(p,Path('snapshots')/stage/'manifest.json')
cpp='vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision/input_norm_sum.cpp'
copy(base/'full-pto-precision-20261016/step07/source'/cpp,Path('source')/cpp)
raw=subprocess.run(['task-submit','--list'],capture_output=True,text=True,check=True).stdout
lines=[x for x in raw.splitlines() if 'task_20261017_002449_25681559404' in x]
(dst/'task-status.txt').write_text('\n'.join(lines)+'\n')
manifest={str(p.relative_to(dst)):sha(p) for p in sorted(dst.rglob('*')) if p.is_file()}
(dst/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
p=h/'production1-evidence.tar.gz'
with tarfile.open(p,'w:gz') as t:t.add(dst,arcname=dst.name)
print(json.dumps(dict(sha256=sha(p),files=len(manifest),bytes=p.stat().st_size,task=lines)))
