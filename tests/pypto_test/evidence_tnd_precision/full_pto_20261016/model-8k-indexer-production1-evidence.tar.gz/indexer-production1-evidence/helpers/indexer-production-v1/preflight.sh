#!/usr/bin/env bash
set -euo pipefail
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
job="$base/full-pto-model-8k-b40-20261016"
source "$job/env.sh"
export SOURCE_ROOT="$base/full-pto-precision-20261017/step09/source"
export PYTHONPATH="$SOURCE_ROOT:$SOURCE_ROOT/tests/pypto_test:$job:$PYTHONPATH"
export CMAKE_BUILD_PARALLEL_LEVEL=4
export CCACHE_DIR=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/pypto/.ccache
ccache -s
python "$job/source_preflight.py"
python "$job/check_bank.py"
python "$job/indexer-production-v1/compile_formal_indexer.py"
