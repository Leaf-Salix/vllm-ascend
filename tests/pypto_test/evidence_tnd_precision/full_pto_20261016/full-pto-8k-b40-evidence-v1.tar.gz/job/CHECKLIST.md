# 完整PTO CSA真实8K/B40/192-token复测

- [x] 核验正式425ae1f11、冻结Native1、bank与派生入场/outer基准SHA；不跑Native2或128K。
- [x] 新建独立源码与helper快照，保留旧baseline与历史输出。
- [x] 无设备检查imports/SDK/ATB/编译器/静态包与全部源SHA；复用现有依赖与编译缓存。
- [x] 首差实时门禁：全rank实际输入和入场；rank0 hidden/aux/MTP；完整token/acceptance事件。
- [x] 验证21CSA层FULL6/FULL240实际PTO捕获及O-proj执行；HCA保留Native。
- [x] 独立审查助手和CPU回归后提交16卡任务，max-time780秒，持续监控，不开sche。
- [x] 首差即停，先保存证据/同输入定位，不扩大配置。
- [ ] 结果与复现方案写入项目MD，保存原始证据，commit并正常push。
