# 完整PTO CSA真实8K/B40/192-token复测

## 冻结身份

- 正式commit：425ae1f11；原性能/精度基准保留。
- Native1：task_20261016_192621_7066592194，259cf9a5f；不跑Native2/128K。
- 新任务：task_20261018_010753_36803907165，16卡，max-time=780。
- 新输出：/data/pyptouser/yejia/lc128/full-pto8k-oproj-formal-20261018。
- 新独立step12：17个正式精度包文件逐字节绑定425ae；沿用旧运行overlay其余文件，不宣称完整Git树。
- 源清单SHA：56d688b218d0d634024aed98a1568adac982f6005e5cd87373dd7553df8e6496。
- helper清单SHA：4c631c8075c5538ef49b7a5af0e2953c8abcf4ca609b5878e99cb273921e1758。
- Native派生清单SHA：be6ba496d189c91f9c40fcea5d8d73c68577d646fb34ea203add5612297c2834。

## 已完成

- bank输入、Native原始及派生证据SHA、正式包、助手哈希和环境无设备预检通过。
- 正式O-proj纯CPU lower/compile通过，复用现有工具链和缓存。
- 助手独立审查通过，离线入口默认路径问题已修正。
- 助手CPU测试3项通过。
- 保留原8K入场、outer、尾轮和完整token/event门禁；新增21层O-proj各T6/T240暖身/捕获及静态资格检查。
- 01:07:53提交；持续监控。尚无数值结论。

## 操作记录

- 只读队列查询误写成task-submit status，产生无卡命令task_20261018_010655_366378426511，立即exit127；未占NPU，不属于验证任务。已确认正确--status语法并记录通用mistake。

- 01:10左右获得16卡；01:13进入实际DP16模型加载，无首差。

## 首次启动失败与v2修正

- 任务task_20261018_010753_36803907165 exit1，在第二档位调用compile_static_kernel时触发Do not reselect after capture；未进入生成，没有数值结果。
- 独立helper-v2保留v1不改：首次真实reselect一次并授权21runtime；后续原bridge仍校验13包/SDK/SOC/确定性，拦截无参底层reselect返回首轮结果，避免改变旧图。元数据或runtime资格不符直接拒绝。
- 这属于bootstrap生命周期修正，数学源码425ae/原bank/所有原数值门禁不变。Native原流程每档真实reselect，与v2不同；仅以冻结旧Native结果作为数值oracle，不宣称启动流程逐调用相同。
- 原bridge仍打印OFFICIAL_STATIC_RESELECT success=1，实际底层API次数只认新增actual_reselections=1和validated_reuses>0，不按旧日志行数计算。
- 新CPU6项和独立审查通过。v2 helper清单SHA=6407401173ad8762dd8f1e90a0f25ea9f90cdfd81c2038d9518b519c884ca480。

- v2预检通过。01:21:34重提task_20261018_012134_402497631259，16卡max780；新输出full-pto8k-oproj-formal-v2-20261018，仍未有数值结论。

## 最终结果

- task_20261018_012134_402497631259 exit0，提交到完成9m29s（含排队），max780；不跑Native2/128K。
- 严格CPU资格numeric_pass=true。全640×192=122880token、完整接受事件、16rank实际入场/输入51有效轮均与Native1一致。
- rank0 hidden/aux/MTP位摘要51轮一致；每rank实际峰值40，零抢占，50次FULL240。
- 全16rank×21层×T6/T240 O-proj暖身/捕获成立；真实reselect1次、校验复用1次。
- rank5生成/二进制各5次，rank9各2次，其余0；缓存错误项全0，strict READY=false。未重装/重编译框架。
- 本地独立复核资格/计数断言通过，待归档并提交文档。
