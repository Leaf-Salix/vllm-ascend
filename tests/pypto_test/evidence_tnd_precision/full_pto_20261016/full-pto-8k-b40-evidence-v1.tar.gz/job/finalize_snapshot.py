import json,hashlib
from pathlib import Path
base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
step=base/'full-pto-8k-b40-20261018/step12'
p=step/'manifest.json'
m=json.loads(p.read_text())
old=json.loads((base/'full-pto-model-8k-b40-20261016/step07/manifest.json').read_text()) if False else None
config=json.loads(Path('/data/pyptouser/yejia/lc128/full-pto8k-native-20261016/configuration.json').read_text())
old=json.loads(Path(config['snapshot_manifest']).read_text())
added=set(m['files'])-set(old['files'])
changed={f for f in old['files'] if m['files'].get(f)!=old['files'][f]}
assert len(added)==7 and len(changed)==3,(added,changed)
for f,d in m['files'].items():
    assert hashlib.sha256((step/'source'/f).read_bytes()).hexdigest()==d,f
m.pop('changed_from_step08',None)
m['overlay_files']={f:m['files'][f] for f in sorted(added|changed)}
m['overlay_relative_to_native1_manifest']=config['snapshot_manifest']
m['changed_from_native1']=sorted(changed)
m['added_from_native1']=sorted(added)
p.write_text(json.dumps(m,indent=2)+'\n')
print('FINAL_SOURCE_MANIFEST',hashlib.sha256(p.read_bytes()).hexdigest(),'files',len(m['files']),'added',len(added),'changed',len(changed))
