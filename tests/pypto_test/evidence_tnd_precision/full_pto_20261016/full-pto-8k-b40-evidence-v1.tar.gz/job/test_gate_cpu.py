"""CPU checks for the new observer-only bootstrap and the unchanged first-diff oracles."""
import importlib.util
import sys
from pathlib import Path
from types import ModuleType, SimpleNamespace

import pytest

ROOT = Path(__file__).parent
H = ROOT/'helper-v1'


def test_input_outer_and_tail_gates_unchanged():
    old = ROOT.parent/'dsv4-full-pto-model-regression-20261016'
    for name in ('admission_trace.py','full_probe.py','generation_window.py','capture_boundaries.py','audit_alignment.py','qualify192.py'):
        assert (old/name).read_bytes() == (H/name).read_bytes()


def load(monkeypatch):
    flag = SimpleNamespace(capture=False)
    torch = ModuleType('torch')
    torch.npu = SimpleNamespace(is_current_stream_capturing=lambda: flag.capture)
    monkeypatch.setitem(sys.modules,'torch',torch)
    name = 'vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision'
    package = ModuleType(name)
    class Runtime:
        restored_modules = ('hc_pre','input_norm','wkv','indexer_weights','o_proj','hc_post')
        def __init__(self, index):
            self.layer_name = f'model.layers.{index}.self_attn.attn'
            self.wkv_profile = SimpleNamespace(metadata_sha256=None)
            self.pto_o_proj = lambda *a, **k: 'pto'
        def __call__(self,*args):return 'forward'
    package.service = SimpleNamespace(CSAServiceRuntime=Runtime)
    monkeypatch.setitem(sys.modules,name,package)
    spec=importlib.util.spec_from_file_location('qualified_test',H/'qualified_wkv.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    rs=[Runtime(i) for i in range(2,43,2)]
    model=SimpleNamespace(model=SimpleNamespace(layers=[SimpleNamespace(self_attn=SimpleNamespace(dsa_attn=SimpleNamespace(_pto_csa_runtime=r))) for r in rs]))
    module.install_service(model)
    return module,rs,flag


def test_unqualified_and_unwarmed_capture_rejected(monkeypatch):
    m,rs,flag=load(monkeypatch)
    x=SimpleNamespace(shape=(6,32768))
    with pytest.raises(AssertionError):rs[0].pto_o_proj(x)
    m.qualification.update(ready=True,actual_reselections=1)
    for r in rs:r.wkv_profile.metadata_sha256=m.METADATA_SHA
    flag.capture=True
    with pytest.raises(AssertionError,match='not warmed'):rs[0].pto_o_proj(x)
    with pytest.raises(AssertionError):m.finish()


def test_all_21_layers_need_both_warmups_and_captures(monkeypatch):
    m,rs,flag=load(monkeypatch)
    m.qualification.update(ready=True,actual_reselections=1)
    for r in rs:
        r.wkv_profile.metadata_sha256=m.METADATA_SHA
        for t in (6,240):
            flag.capture=False;assert r.pto_o_proj(SimpleNamespace(shape=(t,32768)))=='pto'
            flag.capture=True;assert r.pto_o_proj(SimpleNamespace(shape=(t,32768)))=='pto'
    result=m.finish()
    assert result['ready'] and len(result['oproj_counts'])==21
    result['oproj_counts'][rs[-1].layer_name]['240']['capture']=0
    with pytest.raises(AssertionError):m.finish()
