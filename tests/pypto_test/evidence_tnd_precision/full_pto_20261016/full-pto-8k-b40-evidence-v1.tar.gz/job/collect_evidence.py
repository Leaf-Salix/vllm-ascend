"""Archive only bounded own-run evidence; no model tensors or package installs."""
from pathlib import Path
import hashlib,json,tarfile
BASE=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
job=BASE/'full-pto-8k-b40-20261018'
old=BASE/'full-pto-model-8k-b40-20261016'
right=Path('/data/pyptouser/yejia/lc128/full-pto8k-oproj-formal-v2-20261018')
left=Path('/data/pyptouser/yejia/lc128/full-pto8k-native-20261016')
files={}
def add(p,name):
    if p.is_file():
        assert p.stat().st_size < 40*1024**2,(p,p.stat().st_size)
        files[name]=p
for root,name in ((left,'native'),(right,'full-pto'),(Path('/data/pyptouser/yejia/lc128/full-pto8k-oproj-formal-20261018'),'failed-v1')):
    for pattern in ('*.json','*.jsonl','*.log','input-trace/*','full-probe/*.json','full-probe/*.jsonl'):
        for p in root.glob(pattern): add(p,name+'/'+str(p.relative_to(root)))
for p in (old/'native1-generation-reference').rglob('*'):
    add(p,'native-reference/'+str(p.relative_to(old/'native1-generation-reference')))
for helper in ('helper-v1','helper-v2'):
    for p in (job/helper).iterdir():
        if p.suffix in ('.py','.sh','.json'):add(p,helper+'/'+p.name)
for name in ('preflight.log','preflight-final.log','preflight-v2.log','test_gate_cpu.py','test_gate_v2_cpu.py','CHECKLIST.md','PROGRESS.md','compile-oproj.log','qualified.json','qualify.log','task-status.txt','task-log.txt','finalize_snapshot.py','collect_evidence.py'):
    add(job/name,'job/'+name)
add(job/'step12/manifest.json','source/manifest.json')
m=json.loads((job/'step12/manifest.json').read_text())
for name in sorted(set(m['production_package_files'])|set(m['overlay_files'])):
    add(job/'step12/source'/name,'source/'+name)
config=json.loads((left/'configuration.json').read_text())
add(Path(config['snapshot_manifest']),'native/source-manifest.json')
for name in ('mixed-original.py','mixed.py','qualify_production.py'):
    add(old/'indexer-production-v1'/name,'old-indexer-helper/'+name)
add(old/'reference/baseline.json','old-reference/baseline.json')
add(BASE/'low-acceptance-20261010/official-static-cache/metadata.json','assets/static-metadata.json')
add(BASE/'low-acceptance-20261010/banks/fixed8192/plan.json','assets/bank-plan.json')
index={name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for name,p in sorted(files.items())}
manifest=job/'evidence-files.json'
manifest.write_text(json.dumps(index,indent=2)+'\n')
archive=job/'full-pto-8k-b40-evidence-v1.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
    tar.add(manifest,arcname='evidence-files.json')
print(json.dumps({'archive':str(archive),'files':len(files),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
