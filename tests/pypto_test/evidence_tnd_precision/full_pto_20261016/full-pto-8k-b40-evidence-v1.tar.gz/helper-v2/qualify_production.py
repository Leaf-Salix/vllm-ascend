"""Single-Native vs normal asynchronous CSA: exact inputs/tokens/outer.

The prior verified entry/guard fixes plus PTO WKV and Indexer projection differ; no performance qualification.

No Native2 or internal layer-stage qualification is claimed.
"""
import argparse
import hashlib
import json
from pathlib import Path
from audit_alignment import audit
from qualify192 import COMMON, source_identity, read_rows


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def cache_qualification(root):
    rows=[]
    for rank in range(16):
        data=json.loads((root/f'rank{rank}.mixed.json').read_text())
        stats=data['observation'][0]['pypto_cache_stats']
        for field in ('bypasses','invalid_entries','storage_errors','forced_rebuilds'):
            if stats[field]!=0:raise ValueError(f'rank{rank}: numeric cache error {field}')
        ready=stats['ready_hits']>0 and stats['generation_builds']==0 and stats['binary_builds']==0
        rows.append({'rank':rank,'strict_ready_reuse':ready,'cache_stats':stats})
    return rows


def qualify(left_root,right_root,job):
    old_job=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/full-pto-model-8k-b40-20261016')
    debug=old_job/'indexer-production-v1'
    if left_root.resolve()==right_root.resolve():raise ValueError('Independent arms required')
    left,ltrace,loutputs,laccept,lobs=audit(left_root,require_ready_reuse=False)
    right,rtrace,routputs,raccept,robs=audit(right_root,require_ready_reuse=False)
    if left['backend']!='native' or right['backend']!='pto':raise ValueError('Wrong experiment arms')
    if any(left[k]!=right[k] for k in COMMON if k not in ('snapshot','snapshot_manifest','source_manifest_sha256','production_git_commit','bootstrap_sha256')):raise ValueError('Common experiment identity differs')
    if left['variant']!='tnd_full_precision' or left['production_git_commit']!='259cf9a5f' or right['production_git_commit']!='425ae1f11':raise ValueError('Wrong candidate checkpoint')
    for root,config in ((left_root,left),(right_root,right)):
        source_identity(config)
        if config['full_probe_mode']!='control' or config['stage_reference'] is not None or (root/'full-probe/stages.jsonl').exists():
            raise ValueError('This run has no layer-stage witness qualification')
        for key,name in (('bootstrap_sha256','sitecustomize.py'),('full_probe_sha256','full_probe.py'),('witness_sha256','capture_boundaries.py'),('trace_helper_sha256','admission_trace.py'),('generation_window_sha256','generation_window.py')):
            path=(old_job if root==left_root else job)/name
            if config[key]!=sha(path):raise ValueError('Wrong/changed helper '+name)
    lmanifest=json.loads(Path(left['snapshot_manifest']).read_text())
    rmanifest=json.loads(Path(right['snapshot_manifest']).read_text())
    rel='vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision/input_norm_sum.cpp'
    prefix='vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision/'
    added={prefix+n for n in ('wkv.py','wkv_order_data.py','wkv_profile.py','indexer_projection.py','indexer_order_data.py','o_proj.py','oproj_order_data.py')}
    if set(rmanifest['files'])-set(lmanifest['files'])!=added or set(lmanifest['files'])-set(rmanifest['files']):raise ValueError('Unexpected source file set')
    changes=[n for n in lmanifest['files'] if lmanifest['files'][n]!=rmanifest['files'][n]]
    mixed='tests/pypto_test/low_acceptance_20261001/mixed.py'
    if set(changes)!={rel,mixed,prefix+'service.py'}:raise ValueError('Unexpected source changes')
    if right.get('wkv_restored') is not True or right.get('wkv_order_map_sha256')!='ba7885227b29b521f7dcbde69ff79bc4bf6c706c1942c59985a01ee323ae7255':raise ValueError('Wrong WKV qualification')
    if right.get('indexer_projection_restored') is not True or right.get('indexer_order_map_sha256')!='700c26586fe104bf92ffbb5d6eba74d307ba4c67df9eeac08363c729d2ec71fc':raise ValueError('Wrong Indexer qualification')
    package=json.loads((job/'production-package.json').read_text())
    if package['git_commit']!='425ae1f11' or rmanifest['production_package_files']!=package['files']:raise ValueError('Wrong production package manifest')
    for name,digest in package['files'].items():
        if sha(Path(right['snapshot'])/name)!=digest:raise ValueError('Production package changed '+name)
    if right.get('oproj_restored') is not True or right.get('oproj_order_map_sha256')!='2c6ed88f69024a894543228a818cc5e7a4081ffacbceebb9fec5452a2b187686':raise ValueError('Wrong O-proj qualification')
    if right['qualified_helper_sha256']!=sha(job/'qualified_wkv.py') or right['helper_manifest_sha256']!=sha(job/'helper-manifest.json'):raise ValueError('Wrong qualified bootstrap')
    for name,digest in json.loads((job/'helper-manifest.json').read_text())['files'].items():
        if sha(job/name)!=digest:raise ValueError('Helper changed '+name)
    old=(Path(left['snapshot'])/rel).read_bytes()
    new=(Path(right['snapshot'])/rel).read_bytes()
    if old.count(b'  set_atomic_none();')!=1 or new!=old.replace(b'  set_atomic_none();',b'  set_atomic_none();\n  set_mask_norm();\n  set_vector_mask(-1, -1);'):raise ValueError('Wrong entry initialization patch')
    if (Path(left['snapshot'])/mixed).read_bytes()!=(debug/'mixed-original.py').read_bytes() or (Path(right['snapshot'])/mixed).read_bytes()!=(debug/'mixed.py').read_bytes():raise ValueError('Wrong tested runtime identity guard')
    import ast
    original=ast.parse((debug/'mixed-original.py').read_text())
    patched=ast.parse((debug/'mixed.py').read_text())
    for name in ('wait_for_generation_peers','collect'):
        get=lambda tree:next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
        if ast.dump(get(original))!=ast.dump(get(patched)):raise ValueError('Numerical/peer gate changed')
    oldrun=next(n for n in original.body if isinstance(n,ast.FunctionDef) and n.name=='run_batches')
    newrun=next(n for n in patched.body if isinstance(n,ast.FunctionDef) and n.name=='run_batches')
    # The old worker-identity loop becomes one validated helper call; batching is identical.
    remove=lambda fn:[n for n in fn.body if not (isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='worker') and not (isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='validate_implementations')]
    if [ast.dump(n) for n in remove(oldrun)]!=[ast.dump(n) for n in remove(newrun)]:raise ValueError('Generation/observation changed')
    if right.get('initialization_diagnostic') is not None or (right_root/'init-stage').exists():raise ValueError('Unexpected diagnostic stage synchronization')
    if right.get('test_harness_patch')!='full PTO CSA and verified static qualification; unchanged 8K input/outer/tail gates':raise ValueError('Wrong harness declaration')
    reference=old_job/'native1-generation-reference'
    if right['generation_reference_manifest_sha256']!=sha(reference/'manifest.json'):raise ValueError('Wrong derived reference identity')
    if Path(right['trace_reference']).resolve()!=(reference/'input-trace').resolve() or Path(right['outer_reference']).resolve()!=(reference/'full-probe').resolve():raise ValueError('Wrong live oracle directory')
    binding=json.loads((reference/'manifest.json').read_text())
    if Path(binding['raw_source']).resolve()!=left_root.resolve():raise ValueError('Reference not bound to this Native')
    for rel,digest in binding['source_sha256'].items():
        if sha(left_root/rel)!=digest:raise ValueError('Native evidence changed '+rel)
    for rel,digest in binding['derived_sha256'].items():
        if sha(reference/rel)!=digest:raise ValueError('Derived reference changed '+rel)
    if ltrace!=rtrace:raise ValueError('Actual GPU inputs or admissions differ')
    if loutputs!=routputs or laccept!=raccept:raise ValueError('Complete tokens/acceptance events differ')
    count=len(ltrace[0])
    louter=read_rows(left_root,'outer.jsonl','control',count)
    router=read_rows(right_root,'outer.jsonl','control',count)
    if louter!=router:raise ValueError('Rank0 hidden/aux/MTP bits differ')
    for step,(outer,trace) in enumerate(zip(router,rtrace[0],strict=True)):
        if outer['forward_index']!=step or outer['actual_tokens']!=trace['actual_tokens']:raise ValueError('Outer/input binding differs')
    for rank in range(16):
        data=json.loads((right_root/f'rank{rank}.mixed.json').read_text())
        selected=data['observation'][0]['capture_time_selection']
        for layer in range(2,43,2):
            counts=selected[f'model.layers.{layer}.self_attn.attn']
            # This pinned npugraph_ex executes one uncaptured warmup and one capture per bucket.
            # The shared counter may also include Native profiling calls with no metadata.
            if any(counts.get(f'pto_tokens{t}',0)<2 for t in (6,240)):
                raise ValueError('CSA bucket fell back to Native')
    full_pto=[]
    for rank in range(16):
        q=json.loads((right_root/f'rank{rank}.mixed.json').read_text())['observation'][0]['full_pto_qualification']
        if not q['ready'] or q['actual_reselections']!=1 or q.get('validated_reuses',0)<=0 or q['metadata_sha256']!=right['official_static_cache_sha256']:raise ValueError('PTO static qualification missing')
        if q['restored_modules']!=['hc_pre','input_norm','wkv','indexer_weights','o_proj','hc_post']:raise ValueError('PTO replacement incomplete')
        if set(q['oproj_counts'])!={f'model.layers.{i}.self_attn.attn' for i in range(2,43,2)}:raise ValueError('Wrong CSA layer set')
        for layer,counts in q['oproj_counts'].items():
            if any(counts.get(str(t),{}).get('warmup',0)<=0 or counts.get(str(t),{}).get('capture',0)<=0 for t in (6,240)):raise ValueError('PTO O-proj not warmed/captured')
        full_pto.append({'rank':rank,**q})
    caches=cache_qualification(right_root)
    return {'numeric_pass':True,'oproj_restored':True,'full_pto_qualification':full_pto,'wkv_restored':True,'wkv_module_rows_qualified':256,'indexer_projection_restored':True,'indexer_module_rows_qualified':256,'indexer_module_real_weight_layers_qualified':21,'production_async_initialization_qualified':True,'test_harness_patch':right['test_harness_patch'],'strict_ready_reuse':all(x['strict_ready_reuse'] for x in caches),'native_runs':1,'native_repeat_tested':False,'internal_layer_stages_tested':False,'rank0_outer_hidden_aux_mtp_bit_equal':True,'all16_gpu_inputs_and_admissions_equal':True,'all16_complete_tokens_and_events_equal':True,'requests':binding['output_requests'],'tokens':binding['output_tokens'],'generation_records':count,'production_git_commit':right['production_git_commit'],'source_manifest_sha256':right['source_manifest_sha256'],'acceptance':{k:v for k,v in raccept.items() if k!='requests'},'native_observed':lobs,'csa_observed':robs,'cache':caches,'scope':'fixed8192 real model TP1 DP=EP16 B40,192 output tokens,FULL[6,240],HCpre-to-HCpost complete PTO CSA; no Native2, internal stage or performance claim'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('native',type=Path);p.add_argument('csa',type=Path);p.add_argument('--job',type=Path,default=Path(__file__).resolve().parent);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    result=qualify(a.native,a.csa,a.job)
    with a.output.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('cache','native_observed','csa_observed','full_pto_qualification')},ensure_ascii=False))
