"""Compile the production O-proj on CPU using the existing toolchain/cache."""
from pathlib import Path
import json
from pypto.ir._kernel_compile import kernel_signature_for_program
from pypto.runtime import RunConfig
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.o_proj import o_proj_test
params, aliases = kernel_signature_for_program(o_proj_test.specialize())
compiled = o_proj_test.compile(config=RunConfig(platform='a2a3'))
Path(__file__).with_name('compile-oproj-result.json').write_text(json.dumps({'output_dir':str(compiled.output_dir),'parameters':[p.name for p in params],'aliases':list(aliases)},indent=2)+'\n')
print('FORMAL_OPROJ_CPU_LOWER_OK',compiled.output_dir)
