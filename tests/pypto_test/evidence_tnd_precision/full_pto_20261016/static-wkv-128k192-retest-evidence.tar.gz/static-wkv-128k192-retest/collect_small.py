"""在227只收集当前复核和保存Native的小型证据，不读取模型/cache大tensor。"""
import argparse
import hashlib
import json
import tarfile
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--label',required=True);p.add_argument('--output',required=True,type=Path);a=p.parse_args()
assert Path(a.label).name==a.label
base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
candidate=Path('/data/pyptouser/yejia/lc128')/a.label
native=Path('/data/pyptouser/yejia/lc128/retest192-native1-b24000')
reference=base/'retest192-20261016/native1-generation-reference'
stages=Path('/data/pyptouser/yejia/lc128/retest192-native2-b24000/full-probe')
files=[]
for root,prefix in [(candidate,'candidate'),(reference,'native-window')]:
 for f in root.iterdir():
  if f.is_file() and (f.suffix in ('.json','.jsonl','.log') or f.name.endswith('.mixed.json')):files.append((f,prefix+'/'+f.name))
 for sub in ('input-trace','full-probe'):
  folder=root/sub
  if folder.is_dir():
   for f in folder.iterdir():
    if f.is_file() and f.suffix in ('.json','.jsonl'):files.append((f,prefix+'/'+sub+'/'+f.name))
for f in [native/'configuration.json',*sorted(native.glob('rank*.mixed.json')),*sorted(native.glob('request_stats_rank*.jsonl'))]:
 files.append((f,'native-raw/'+f.name))
for name in ('complete.json','stages.jsonl'):
 files.append((stages/name,'native-stages/'+name))
assert all(f.is_file() and f.stat().st_size<20*1024**2 for f,_ in files)
assert len({name for _,name in files})==len(files)
manifest={name:hashlib.sha256(f.read_bytes()).hexdigest() for f,name in files}
with tarfile.open(a.output,'w:gz') as tar:
 for f,name in files:tar.add(f,arcname=name)
manifest_file=a.output.with_name(a.output.name.replace('.tar.gz','-manifest.json'))
manifest_file.write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(files),'bytes':a.output.stat().st_size,'sha256':hashlib.sha256(a.output.read_bytes()).hexdigest()}))
