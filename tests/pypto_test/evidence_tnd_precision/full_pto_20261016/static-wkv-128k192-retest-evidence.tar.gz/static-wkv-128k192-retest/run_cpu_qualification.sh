#!/usr/bin/env bash
# 在227上复用实际资格命令；CPU、无可见NPU，输出路径必须是新文件。
set -euo pipefail
label=${1:?provide existing result label}
result=${2:?provide a new qualification JSON path}
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
job="$base/retest128k-wkv-20261017/witness-v1"
out="/data/pyptouser/yejia/lc128/$label"
export LOW_ACCEPTANCE_GPU_BLOCKS=24000 LOW_ACCEPTANCE_OFFICIAL_CACHE="$base/low-acceptance-20261010/official-static-cache"
export LOW_ACCEPTANCE_RUNTIME_PACKAGE="$base/low-acceptance-20261010/runtime-package"
source "$job/env.sh"
export ASCEND_RT_VISIBLE_DEVICES='' TORCH_DEVICE_BACKEND_AUTOLOAD=0 PYTHONNOUSERSITE=1
export PYTHONPATH="$job:$SOURCE_ROOT:$SOURCE_ROOT/tests/pypto_test:$PYTHONPATH"
python - "$job" <<'PY'
import hashlib,json,sys
from pathlib import Path
job=Path(sys.argv[1]);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(job/'helper-manifest.json')=='c3841880a1aff68a7c8a56a9c5cb93940ca66d84601462e7456bcfcbbb9134a0'
old=job.parents[1]/'full6-localization-20261017/static-wkv-service-v1'
assert sha(old/'helper-manifest.json')=='8efcf4cc87af2549bde0d9f6d7bf9519769c87b80104e513c221455b2a666e0f'
assert sha(job/'qualified_wkv.py')==json.loads((old/'helper-manifest.json').read_text())['files']['qualified_wkv.py']
PY
python "$job/qualify_full.py" "$out" --output "$result"
