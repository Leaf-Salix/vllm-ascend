# 128K/B24静态WKV修正候选完整复核（2026-10-17）

- 基准：正式数学c1ef141ae、step09冻结清单d997d410...1638不改；候选沿用已验证static-wkv-service-v1的qualified_wkv，按真实13包验证+reselect后选T6自然序。
- 参数：同fixed131072真实模型bank、TP1/DP=EP16、提交B24、192 token、FULL[6,144]；旧Native1输入/输出/接受事件及保存Native内部78轮为参考，不跑新Native2，不扩档位。
- 每个NPU任务task-submit auto device-num16 max-time780；提交后持续跟踪，不开schedule，不触碰别人的任务/服务/锁。

## 顺序

- [x] 只读核验磁盘、队列、完整Native参考。
- [x] 复制独立helper，仅去掉首FULL6主动退出；原首差门禁、输入对齐、全部阶段精度门禁保留。qualified_wkv与已通过候选逐字节一致。
- [x] 本地syntax与控制流检查，独立review。
- [x] rsync至227自有新目录；相同env下preflight无设备检查全部冻结文件和导入路径。
- [x] 提交单项16卡，max780；发现首差立即退出并保存内部原值。
- [x] 若通过，CPU完整审计all16输入轨迹、384请求/73728输出token及接受事件；rank0全部78轮43层阶段/outer逐bit，并核static资格/21CSA实际capture。
- [ ] 如失败，先分析第一差异模块，不跑后续大配置。
- [ ] 中文记录复现方法、结果和范围，归档小证据与helper，增量precommit，commit push Leaf-Salix当前branch。

## 准备记录

- Native两份full-probe complete均78轮，磁盘6.5T可用；初查CI占8卡，未干预。
- 创建独立parent前首次rsync因父目录不存在失败，随后过早preflight报脚本缺失；均未占卡、不计数值失败。已建本人新目录、上传并重新预检。
- helper manifest c3841880a1aff68a7c8a56a9c5cb93940ca66d84601462e7456bcfcbbb9134a0。
- 本地syntax通过；5种完整轮次门禁测试通过（checkpoint-only/75伪complete/78未完成/78完整/79多余）；WKV/admission/capture/l20 helper逐字节不变，stop/before/finish/load_reference AST不变。
- 独立运行审查无阻断；完整CPU资格器另行独立审查。

- 无设备预检exit0：PYPTO_TOOLCHAIN_USABLE、module paths及CANN/ATB/PTOAS、frozen源码/Native/reference/helper所有SHA通过，bootstrap_NO_DEVICE_OK；未装框架。
- task_20261017_183144_34519299596已提交auto16、max780，标签retest128k-wkv192-1-20261017。不新增Native2；首差停止。

- 专用完整CPU资格器也已独立review无阻断；当前任务pending，不把已通过checkpoint当本轮完整结果。

- 依仓库规则执行format.sh ci（日志format-ci.log），仍失败于既有归档generated/log/style/import问题；其346个无关formatter改动均恢复HEAD，当前tracked tree无改动。没有改写原始历史证据或放宽门禁。

- 19:04:07（Asia/Shanghai）状态running、已运行15秒，16卡均分配给本任务；此前约32分钟均为pending，不占卡。max780生效。

- task exit0，78轮完整门禁通过，19:12:28已关闭Engine；锁0..15全部释放。
- CPU无可见NPU资格器exit0；固定c384helper与旧qualified WKV hash绑定通过。all16输入、完整384请求/73728tokens/接受事件全部一致；rank0全78轮43层及outer逐bit；前75与上一候选一致。mean accepted3.8264033264，零抢占；strict READY复用=false单独记录，不作性能结论。

- 原始两臂177小文件SHA在本地全部核验；无Torch独立verify_local.py再次复算384/73728 token差异0、event差异0、all16输入78窗口、rank0stage/outer全等。

- 独立最终复核确认数值通过；缓存细节保留：rank5 generation/binary各4，rank13各2，其余0；全部ready_hits0，错误计数0。不得概括所有rank构建为0。完整原始qualified.json已记录。
