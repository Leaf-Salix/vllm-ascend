# 同128K/B24、192 token的静态WKV修正候选复核

## 已知基准

- Git分支dev/pypto-dsv4-csa-nalinaly-tnd-20261008-codex，记录提交fa2d1541b；正式数学c1ef141ae。
- 先前完整模型首差在forward74、首次FULL6、L20 heads；静态Native WKV比PTO一元素相邻BF16差异。
- 独立qualified候选只在官方13包/版本/SHA/确定性验证及真实reselect成功后将T6选至已有自然K256 mode1；前75轮服务已通过，已存证据不动。
- 本次继续同一128K配置至完整192 token，不跑Native2，不扩后续档位，暂不测性能。

## 验收

- 运行时all16输入/实际入场逐轮对旧Native；rank0 43层边界及hidden/aux/MTP outer逐bit；首差立即停止并保存snapshot。
- 首FULL6 checkpoint仍保留，但它不能构成完整通过。最终full-probe complete必须78轮，实际生成窗口需all16都78轮。
- CPU沿用collect/extract完整输出事件检查：384请求、73728输出token；all16完整token序列与接受事件逐项比较Native1。
- 静态资格、实际CSA/HCA选择、确定性和容量检查沿用既有门禁；21CSA捕获layer集合精确2..42 step2，6/144需实际PTO选择记录。
- capture fresh epoch/poison/actual position门禁保持；未改WKV、输入trace和copy_boundary实现。
- 静态源码/helper/frozenSDK与旧Native资产逐项SHA绑定，原baseline及performance版本不改。
- 冷编译/READY复用单独记录，不把READY与精度混为一谈。
- 每项task-submit max780秒，队列等待不计占卡，不干预其他用户任务/锁/服务；提交后持续跟踪。
