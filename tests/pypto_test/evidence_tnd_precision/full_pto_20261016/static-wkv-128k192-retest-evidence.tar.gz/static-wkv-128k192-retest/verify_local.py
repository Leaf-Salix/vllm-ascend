"""本地独立复算两臂token/事件及轨迹/阶段，不依赖Torch/NPU。"""
import hashlib
import json
import sys
from pathlib import Path

root=Path(__file__).parent;data=root/'evidence'
manifest=json.loads((root/'small-evidence-v2-manifest.json').read_text())
for name,digest in manifest.items():
 assert hashlib.sha256((data/name).read_bytes()).hexdigest()==digest,name
sys.path.insert(0,str(root/'witness-v1'))
from generation_window import generation_window
read=lambda path:[json.loads(line) for line in path.read_text().splitlines()]
actual=data/'candidate';native=data/'native-raw';reference=data/'native-window'
prefix,window=generation_window([read(actual/f'input-trace/rank{i}.trace.jsonl') for i in range(16)])
assert all(len(rows)==78 for rows in prefix)
for rank,rows in enumerate(prefix):
 expected=read(reference/f'input-trace/rank{rank}.trace.jsonl')
 assert [{k:v for k,v in row.items() if k!='execute_index'} for row in rows]==[{k:v for k,v in row.items() if k!='execute_index'} for row in expected]

def outputs(folder):
 result={}
 for rank in range(16):
  events={row['key']:row['events'] for row in read(folder/f'request_stats_rank{rank}.jsonl')}
  raw=json.loads((folder/f'rank{rank}.mixed.json').read_text())
  for row in raw['requests']:
   key=(rank,row['key']);assert key not in result and len(row['output_token_ids'])==192
   result[key]={'tokens':row['output_token_ids'],'events':events[row['key']]}
 return result
left=outputs(native);right=outputs(actual)
assert len(left)==len(right)==384 and left==right
assert sum(len(row['tokens']) for row in right.values())==73728
stages=read(actual/'full-probe/stages.jsonl');gold=read(data/'native-stages/stages.jsonl')
assert len(stages)==78 and stages==gold
assert read(actual/'full-probe/outer.jsonl')==read(reference/'full-probe/outer.jsonl')
assert json.loads((actual/'full-probe/complete.json').read_text())['complete']
hist=[sum(event[1]==n for row in right.values() for event in row['events']) for n in range(6)]
accepted=sum(event[1] for row in right.values() for event in row['events'])
drafts=sum(len(row['events']) for row in right.values())
assert accepted==58896 and drafts==15392 and hist==[1200,1392,864,1216,1472,9248]
report={'pass':True,'files_verified':len(manifest),'requests':len(right),'tokens':73728,'token_differences':0,'event_differences':0,'rank0_stage_records':78,'layers':43,'all16_input_windows_equal':True,'accepted':accepted,'drafts':drafts,'mean_accepted':accepted/drafts,'histogram':hist}
(root/'local-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
