"""CPU门禁：首次FULL6 checkpoint不能冒充完整78轮。"""
import importlib.util
import json
import tempfile
from pathlib import Path

helper=Path(__file__).parent/'witness-v1'
spec=importlib.util.spec_from_file_location('saved_reference',helper/'saved_reference.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with tempfile.TemporaryDirectory() as folder:
 root=Path(folder);probe=root/'full-probe';probe.mkdir()
 (probe/'FIRST_FULL6_QUALIFIED.json').write_text('{"pass":true,"complete":true}')
 try:m.read_rows(root,'stages.jsonl','witness',78)
 except FileNotFoundError:pass
 else:raise AssertionError('checkpoint accepted without complete record')
 for actual,complete,accepted in [(75,True,False),(78,False,False),(78,True,True),(79,True,False)]:
  (probe/'complete.json').write_text(json.dumps({'complete':complete,'mode':'witness','records':actual}))
  (probe/'stages.jsonl').write_text(''.join(json.dumps({'forward_index':i,'actual_tokens':6})+'\n' for i in range(actual)))
  try:result=m.read_rows(root,'stages.jsonl','witness',78)
  except ValueError:assert not accepted,(actual,complete)
  else:assert accepted and len(result)==78,(actual,complete)
print('PASS: checkpoint-only, incomplete75, incomplete78, full78, extra79 gates')
