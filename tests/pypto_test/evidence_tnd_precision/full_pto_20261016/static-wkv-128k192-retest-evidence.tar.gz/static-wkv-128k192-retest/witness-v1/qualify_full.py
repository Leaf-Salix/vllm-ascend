"""完整128K复核：保存Native参考、全部实际输入、token/事件及rank0内部逐bit。"""
import argparse
import json
from pathlib import Path

import regex as re

from audit_alignment import audit
from check_inputs import BASE, JOB, NATIVE, REFERENCE, SOURCE, sha, verify
from saved_reference import read_rows, source_identity

STATIC_SHA = '863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
SEMANTIC_KEYS = (
    'attention', 'bank', 'batch', 'decode_tokens', 'event_work_mode',
    'num_gpu_blocks_override', 'gpu_memory_utilization',
    'official_static_cache_sha256', 'bank_plan_sha256',
    'runtime_package_manifest_sha256', 'runtime_package',
)


def qualify(root):
    verify()
    original_helper = BASE/'full6-localization-20261017/static-wkv-service-v1'
    assert (JOB/'qualified_wkv.py').read_bytes() == (original_helper/'qualified_wkv.py').read_bytes()
    assert sha(original_helper/'helper-manifest.json') == '8efcf4cc87af2549bde0d9f6d7bf9519769c87b80104e513c221455b2a666e0f'
    left, left_trace, left_output, left_accept, left_observed = audit(NATIVE, require_ready_reuse=False)
    right, right_trace, right_output, right_accept, right_observed = audit(root, require_ready_reuse=False)
    assert left['backend'] == 'native' and right['backend'] == 'pto'
    assert all(left[key] == right[key] for key in SEMANTIC_KEYS)
    assert right['variant'] == 'tnd_full_precision' and right['production_git_commit'] == 'c1ef141ae'
    assert right['source_manifest_sha256'] == 'd997d41080882209007134564ca488ce19cfe7f136397b6fd0e389c929001638'
    assert Path(right['snapshot']).resolve() == (SOURCE/'source').resolve()
    assert right['capture_sizes'] == [6, 144] and right['max_num_batched_tokens'] == 400
    assert right['wkv_restored'] and right['indexer_projection_restored']
    assert right['wkv_order_map_sha256'] == 'ba7885227b29b521f7dcbde69ff79bc4bf6c706c1942c59985a01ee323ae7255'
    assert right['indexer_order_map_sha256'] == '700c26586fe104bf92ffbb5d6eba74d307ba4c67df9eeac08363c729d2ec71fc'
    for key, name in (
        ('bootstrap_sha256', 'sitecustomize.py'), ('witness_sha256', 'capture_boundaries.py'),
        ('trace_helper_sha256', 'admission_trace.py'), ('full_probe_sha256', 'full_probe.py'),
        ('generation_window_sha256', 'generation_window.py'),
    ):
        assert right[key] == sha(JOB/name), name
    for config in (left, right):
        source_identity(config)
    assert left['full_probe_mode'] == 'control' and right['full_probe_mode'] == 'witness'
    assert Path(right['trace_reference']).resolve() == (REFERENCE/'input-trace').resolve()
    assert Path(right['outer_reference']).resolve() == (REFERENCE/'full-probe').resolve()
    saved_native = Path('/data/pyptouser/yejia/lc128/retest192-native2-b24000')
    assert Path(right['stage_reference']).resolve() == (saved_native/'full-probe').resolve()
    assert sha(saved_native/'full-probe/stages.jsonl') == '87fa6b787a138a58cafc9b18ddb10554c8ce08b9064f831ecd0a6a105d8a5945'
    assert right['generation_reference_manifest_sha256'] == sha(REFERENCE/'manifest.json')
    assert right['official_static_cache_sha256'] == STATIC_SHA
    assert not (root/'full-probe/STOP.json').exists()
    assert left_trace == right_trace, 'Actual input/admission first differs'
    assert left_output == right_output, 'Complete output token or acceptance event differs'
    assert left_accept == right_accept, 'Complete acceptance counters differ'
    count = len(left_trace[0])
    assert count == 78
    stages = read_rows(root, 'stages.jsonl', 'witness', count)
    gold = read_rows(saved_native, 'stages.jsonl', 'witness', count)
    outer = read_rows(root, 'outer.jsonl', 'witness', count)
    assert stages == gold, 'Internal boundary first differs'
    assert outer == read_rows(NATIVE, 'outer.jsonl', 'control', count), 'Rank0 outer first differs'
    previous = Path('/data/pyptouser/yejia/lc128/full6-static-wkv1/full-probe')
    previous_stages = [json.loads(row) for row in (previous/'stages.jsonl').read_text().splitlines()]
    assert len(previous_stages) == 75 and stages[:75] == previous_stages
    checkpoint = json.loads((root/'full-probe/FIRST_FULL6_QUALIFIED.json').read_text())
    qualification = checkpoint['qualification']
    assert checkpoint['complete'] and checkpoint['pass'] and checkpoint['forward_index'] == 74
    assert all(qualification[key] for key in ('ready', 'capture6', 'live6'))
    assert qualification['metadata_sha'] == STATIC_SHA
    expected_layers = set(range(2, 43, 2))
    captures, caches = [], []
    for rank, trace in enumerate(right_trace):
        assert len(trace) == 78
        assert next(row['forward_index'] for row in trace
                    if row['graph_mode'] == 'FULL' and row['padded_tokens'] == 6) == 74
        log = (root/f'rank{rank}.log').read_text()
        assert 'WKV_STATIC_QUALIFIED ' in log and 'OFFICIAL_STATIC_RESELECT success=1' in log
        records = [json.loads(line.split('WKV_SERVICE_SELECTION ', 1)[1])
                   for line in log.splitlines() if 'WKV_SERVICE_SELECTION ' in line]
        selected = {record['layer'] for record in records if record['capture']}
        indices = {int(re.search(r'\.layers\.(\d+)\.', name).group(1)) for name in selected}
        assert indices == expected_layers and len(selected) == 21
        assert all(record['ready'] and record['mode'] == 1 for record in records if record['capture'])
        captures.append({'rank': rank, 'layers': sorted(indices), 'static_qualified': True})
        observation = json.loads((root/f'rank{rank}.mixed.json').read_text())['observation'][0]
        for layer in expected_layers:
            counts = observation['capture_time_selection'][f'model.layers.{layer}.self_attn.attn']
            assert all(counts.get(f'pto_tokens{size}', 0) >= 2 for size in (6, 144))
        stats = observation['pypto_cache_stats']
        assert all(stats[key] == 0 for key in ('bypasses', 'invalid_entries', 'storage_errors', 'forced_rebuilds'))
        caches.append({'rank': rank, 'stats': stats,
                       'strict_ready_reuse': stats['ready_hits'] > 0 and stats['generation_builds'] == stats['binary_builds'] == 0})
    for index, stage in enumerate(stages):
        rows = right_trace[0][index]['actual_tokens']
        assert stage['forward_index'] == index and stage['actual_tokens'] == rows
        assert set(stage['layers']) == {str(layer) for layer in range(43)}
        for layer, fields in stage['layers'].items():
            expected = {'input', 'output', 'positions'}
            if int(layer) in expected_layers:
                expected.update(('normed', 'heads', 'oproj', 'attention_half'))
            assert set(fields) == expected
    binding = json.loads((REFERENCE/'manifest.json').read_text())
    assert binding['output_requests'] == 384 and binding['output_tokens'] == 73728
    return {'numeric_pass': True, 'production_git_commit': right['production_git_commit'],
            'source_manifest_sha256': right['source_manifest_sha256'], 'helper_manifest_sha256': sha(JOB/'helper-manifest.json'),
            'native_runs_this_round': 0, 'native2_run': False, 'generation_records': count,
            'all16_inputs_equal': True, 'all16_complete_tokens_and_events_equal': True,
            'rank0_all43_layer_boundaries_bit_equal': True, 'rank0_outer_bit_equal': True,
            'previous_first75_unchanged': True, 'requests': 384, 'tokens': 73728,
            'acceptance': {key: value for key, value in right_accept.items() if key != 'requests'},
            'capture_qualifications': captures, 'cache': caches,
            'strict_ready_reuse': all(item['strict_ready_reuse'] for item in caches),
            'native_observed': left_observed, 'csa_observed': right_observed,
            'scope': 'same fixed131072 real model TP1 DP=EP16 B24 submitted; complete192 outputs; rank0 float stages only; static-qualified independent WKV T6 repair; no performance/default-code-change claim'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('root', type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    report = qualify(args.root)
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({key: value for key, value in report.items()
                      if key not in ('capture_qualifications', 'cache', 'native_observed', 'csa_observed')}, ensure_ascii=False))
