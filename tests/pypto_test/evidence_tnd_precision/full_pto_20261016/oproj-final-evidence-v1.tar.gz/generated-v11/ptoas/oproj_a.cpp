#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_a(__gm__ float* v1, __gm__ int32_t* v2, __gm__ bfloat16_t* v3, __gm__ bfloat16_t* v4, int64_t v5, int64_t v6, int64_t v7, int64_t v8, int64_t v9, int32_t v10, int32_t v11) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v12 = 0;
  // pto: %c512_i64
  const int64_t v13 = 512;
  // pto: %c8192_index
  const int64_t v14 = 8192;
  // pto: %c1_index
  const int64_t v15 = 1;
  // pto: %c16_index
  const int64_t v16 = 16;
  // pto: %c8_index
  const int64_t v17 = 8;
  // pto: %c32768_index
  const int64_t v18 = 32768;
  // pto: %c64_index
  const int64_t v19 = 64;
  // pto: %c256_index
  const int64_t v20 = 256;
  // pto: %c4194304_index
  const int64_t v21 = 4194304;
  // pto: %c65536_index
  const int64_t v22 = 65536;
  // pto: %c128_index
  const int64_t v23 = 128;
  // pto: %c0_index
  const int64_t v24 = 0;
  // pto: %c4096_index
  const int64_t v25 = 4096;
  // pto: %c1024_index
  const int64_t v26 = 1024;
  // pto: %40
  int64_t v27 = (int64_t) ((uint64_t) v8 * (uint64_t) v16);
  // pto: %accum__iter_v1_view
  const int64_t v28 = 1;
  // pto: %accum__iter_v1_view
  const int64_t v29 = 1;
  // pto: %accum__iter_v1_view
  const int64_t v30 = 1;
  // pto: %accum__iter_v1_view
  int64_t v31 = v27 * v14;
  // pto: %accum__iter_v1_view
  int64_t v32 = v30 * v31;
  // pto: %accum__iter_v1_view
  pto::Shape<1, 1, 1, -1, -1> v33 = pto::Shape<1, 1, 1, -1, -1>(v28, v29, v30, v27, v14);
  // pto: %accum__iter_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v34 = pto::Stride<-1, -1, -1, -1, -1>(v29 * v32, v32, v31, v14, v15);
  // pto: %accum__iter_v1_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v35 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v33, v34);
  // pto: %heads__ssa_v0_view
  const int64_t v36 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v37 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v38 = 1;
  // pto: %heads__ssa_v0_view
  int64_t v39 = (int64_t) v9;
  // pto: %heads__ssa_v0_view
  int64_t v40 = v39 * v18;
  // pto: %heads__ssa_v0_view
  int64_t v41 = v38 * v40;
  // pto: %heads__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v42 = pto::Shape<1, 1, 1, -1, -1>(v36, v37, v38, v39, v18);
  // pto: %heads__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v43 = pto::Stride<-1, -1, -1, -1, -1>(v37 * v41, v41, v40, v18, v15);
  // pto: %heads__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v44 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v42, v43);
  // pto: %wo_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v45 = pto::Shape<-1, -1, -1, -1, -1>(v17, v19, v20, v16, v16);
  // pto: %wo_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v46 = pto::Stride<-1, -1, -1, -1, -1>(v21, v22, v20, v16, v15);
  // pto: %wo_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v47 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v4, v45, v46);
  // pto: %block__ssa_v0
  int64_t v48 = (int64_t) v10;
  // pto: %4
  int64_t v49 = (int64_t) ((uint64_t) v48 * (uint64_t) v23);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  for (int64_t v50 = v24; v50 < v8; v50 += v15) {
    // pto: %5
    ;
    int64_t v51 = (int64_t) ((uint64_t) v50 * (uint64_t) v16);
    // pto: %6
    ;
    int64_t v52 = (int64_t) ((uint64_t) v9 - (uint64_t) v51);
    // pto: %7
    ;
    int64_t v53 = v52 < v16 ? v52 : v16;
    // pto: %flat_offset_mul, %flat_offset, %8, %9, %t__tile
    ;
    int32_t v54 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v50 * (uint64_t) v17) + (uint64_t) v7) * (uint64_t) v17) + (uint64_t) v48)];
    // pto: %10
    ;
    int64_t v55 = (int64_t) v54;
    // pto: %11
    ;
    int64_t v56 = v55 < v24 ? v24 : v55;
    // pto: %12
    ;
    int64_t v57 = (int64_t) ((uint64_t) v56 * (uint64_t) v16);
    // pto: %x__tile
    ;
    Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v58 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v16);
    // pto: %x__tile
    ;
    uint64_t v59 = (uint64_t) v12;
    TASSIGN(v58, v59);
    // pto: %13
    ;
    int64_t v60 = v51 < v24 ? v24 : v51;
    // pto: %14
    ;
    int64_t v61 = (int64_t) ((uint64_t) v7 * (uint64_t) v25);
    // pto: %15
    ;
    int64_t v62 = (int64_t) ((uint64_t) v61 + (uint64_t) v57);
    // pto: %16
    ;
    int64_t v63 = v62 < v24 ? v24 : v62;
    // pto: %heads__ssa_v0_pview
    ;
    const int64_t v64 = 0;
    // pto: %heads__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v65 = PTOAS__GLOBAL_TENSOR_DATA(v44);
    // pto: %heads__ssa_v0_pview
    ;
    const int64_t v66 = 1;
    // pto: %heads__ssa_v0_pview
    ;
    const int64_t v67 = 1;
    // pto: %heads__ssa_v0_pview
    ;
    const int64_t v68 = 1;
    // pto: %heads__ssa_v0_pview
    ;
    int64_t v69 = v53 * v18;
    // pto: %heads__ssa_v0_pview
    ;
    int64_t v70 = v68 * v69;
    // pto: %heads__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 16> v71 = pto::Shape<1, 1, 1, -1, 16>(v66, v67, v68, v53, v16);
    // pto: %heads__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v67 * v70, v70, v69, v18, v15);
    // pto: %heads__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v73 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v65 + (v64 + v60 * v18 + v63 * v15), v71, v72);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v58, v73);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    // pto: %w__tile
    ;
    Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v74 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v23);
    // pto: %w__tile
    ;
    uint64_t v75 = (uint64_t) v13;
    TASSIGN(v74, v75);
    // pto: %17
    ;
    int64_t v76 = v7 < v24 ? v24 : v7;
    // pto: %18
    ;
    int64_t v77 = v49 / v16;
    // pto: %19
    ;
    int64_t v78 = v77 < v24 ? v24 : v77;
    // pto: %20
    ;
    int64_t v79 = v57 / v16;
    // pto: %21
    ;
    int64_t v80 = v79 < v24 ? v24 : v79;
    // pto: %wo_a__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v81 = PTOAS__GLOBAL_TENSOR_DATA(v47);
    // pto: %wo_a__ssa_v0_pview
    ;
    const int64_t v82 = 0;
    // pto: %wo_a__ssa_v0_pview
    ;
    const int64_t v83 = 4194304;
    // pto: %wo_a__ssa_v0_pview
    ;
    const int64_t v84 = 65536;
    // pto: %wo_a__ssa_v0_pview
    ;
    const int64_t v85 = 256;
    // pto: %wo_a__ssa_v0_pview
    ;
    pto::Shape<1, 8, 1, 16, 16> v86 = pto::Shape<1, 8, 1, 16, 16>();
    // pto: %wo_a__ssa_v0_pview
    ;
    pto::Stride<4194304, 65536, 256, 16, 1> v87 = pto::Stride<4194304, 65536, 256, 16, 1>();
    // pto: %wo_a__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v88 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v81 + ((v82 + v76 * v83) + v78 * v84 + v80 * v85), v86, v87);
    TLOAD(v74, v88);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    // pto: %lhs_slice_0_textract
    ;
    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v89 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v53, v16);
    // pto: %lhs_slice_0_textract
    ;
    uint64_t v90 = (uint64_t) v12;
    TASSIGN(v89, v90);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    uint16_t v91 = static_cast<uint16_t>(v24);
    uint16_t v92 = static_cast<uint16_t>(v24);
    TEXTRACT(v89, v58, v91, v92);
    // pto: %rhs_slice_0_textract
    ;
    Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v16, v23);
    // pto: %rhs_slice_0_textract
    ;
    uint64_t v94 = (uint64_t) v12;
    TASSIGN(v93, v94);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    uint16_t v95 = static_cast<uint16_t>(v24);
    uint16_t v96 = static_cast<uint16_t>(v24);
    TEXTRACT(v93, v74, v95, v96);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    // pto: %acc__tile
    ;
    Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v97 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v53, v23);
    // pto: %acc__tile
    ;
    uint64_t v98 = (uint64_t) v12;
    TASSIGN(v97, v98);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    TMATMUL(v97, v89, v93);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    for (int64_t v99 = v15; v99 < v20; v99 += v15) {
      // pto: %22, %23, %24
      ;
      int64_t v100 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v56 + (uint64_t) v99) % v20) * (uint64_t) v16);
      // pto: %0
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v16);
      // pto: %0
      ;
      uint64_t v102 = (uint64_t) v12;
      TASSIGN(v101, v102);
      // pto: %27
      ;
      int64_t v103 = (int64_t) ((uint64_t) v61 + (uint64_t) v100);
      // pto: %28
      ;
      int64_t v104 = v103 < v24 ? v24 : v103;
      // pto: %29
      ;
      const int64_t v105 = 0;
      // pto: %29
      ;
      __gm__ bfloat16_t* v106 = PTOAS__GLOBAL_TENSOR_DATA(v44);
      // pto: %29
      ;
      const int64_t v107 = 1;
      // pto: %29
      ;
      const int64_t v108 = 1;
      // pto: %29
      ;
      const int64_t v109 = 1;
      // pto: %29
      ;
      int64_t v110 = v53 * v18;
      // pto: %29
      ;
      int64_t v111 = v109 * v110;
      // pto: %29
      ;
      pto::Shape<1, 1, 1, -1, 16> v112 = pto::Shape<1, 1, 1, -1, 16>(v107, v108, v109, v53, v16);
      // pto: %29
      ;
      pto::Stride<-1, -1, -1, -1, -1> v113 = pto::Stride<-1, -1, -1, -1, -1>(v108 * v111, v111, v110, v18, v15);
      // pto: %29
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v114 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v106 + (v105 + v60 * v18 + v104 * v15), v112, v113);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v101, v114);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      // pto: %1
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v115 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v23);
      // pto: %1
      ;
      uint64_t v116 = (uint64_t) v13;
      TASSIGN(v115, v116);
      // pto: %33
      ;
      int64_t v117 = v100 / v16;
      // pto: %34
      ;
      int64_t v118 = v117 < v24 ? v24 : v117;
      // pto: %35
      ;
      __gm__ bfloat16_t* v119 = PTOAS__GLOBAL_TENSOR_DATA(v47);
      // pto: %35
      ;
      const int64_t v120 = 0;
      // pto: %35
      ;
      const int64_t v121 = 4194304;
      // pto: %35
      ;
      const int64_t v122 = 65536;
      // pto: %35
      ;
      const int64_t v123 = 256;
      // pto: %35
      ;
      pto::Shape<1, 8, 1, 16, 16> v124 = pto::Shape<1, 8, 1, 16, 16>();
      // pto: %35
      ;
      pto::Stride<4194304, 65536, 256, 16, 1> v125 = pto::Stride<4194304, 65536, 256, 16, 1>();
      // pto: %35
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v126 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v119 + ((v120 + v76 * v121) + v78 * v122 + v118 * v123), v124, v125);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v115, v126);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %2
      ;
      Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v127 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v53, v16);
      // pto: %2
      ;
      uint64_t v128 = (uint64_t) v12;
      TASSIGN(v127, v128);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      uint16_t v129 = static_cast<uint16_t>(v24);
      uint16_t v130 = static_cast<uint16_t>(v24);
      TEXTRACT(v127, v101, v129, v130);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      // pto: %3
      ;
      Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v16, v23);
      // pto: %3
      ;
      uint64_t v132 = (uint64_t) v12;
      TASSIGN(v131, v132);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      uint16_t v133 = static_cast<uint16_t>(v24);
      uint16_t v134 = static_cast<uint16_t>(v24);
      TEXTRACT(v131, v115, v133, v134);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v97, v97, v127, v131);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    };
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %37, %38
    ;
    int64_t v135 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v7 * (uint64_t) v26) + (uint64_t) v49);
    // pto: %39
    ;
    int64_t v136 = v135 < v24 ? v24 : v135;
    // pto: %accum__iter_v3_pview
    ;
    const int64_t v137 = 0;
    // pto: %accum__iter_v3_pview
    ;
    __gm__ float* v138 = PTOAS__GLOBAL_TENSOR_DATA(v35);
    // pto: %accum__iter_v3_pview
    ;
    const int64_t v139 = 1;
    // pto: %accum__iter_v3_pview
    ;
    const int64_t v140 = 1;
    // pto: %accum__iter_v3_pview
    ;
    const int64_t v141 = 1;
    // pto: %accum__iter_v3_pview
    ;
    int64_t v142 = v53 * v14;
    // pto: %accum__iter_v3_pview
    ;
    int64_t v143 = v141 * v142;
    // pto: %accum__iter_v3_pview
    ;
    pto::Shape<1, 1, 1, -1, 128> v144 = pto::Shape<1, 1, 1, -1, 128>(v139, v140, v141, v53, v23);
    // pto: %accum__iter_v3_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v145 = pto::Stride<-1, -1, -1, -1, -1>(v140 * v143, v143, v142, v14, v15);
    // pto: %accum__iter_v3_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v146 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v138 + (v137 + v60 * v14 + v136 * v15), v144, v145);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    TSTORE(v146, v97);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}