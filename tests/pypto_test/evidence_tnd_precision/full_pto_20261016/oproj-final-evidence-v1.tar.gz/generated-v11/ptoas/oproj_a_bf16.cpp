#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_a_bf16(__gm__ float* v1, __gm__ bfloat16_t* v2, int64_t v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v8 = 0;
  // pto: %c8192_index
  const int64_t v9 = 8192;
  // pto: %c1_index
  const int64_t v10 = 1;
  // pto: %c8_index
  const int64_t v11 = 8;
  // pto: %c16_index
  const int64_t v12 = 16;
  // pto: %c1024_index
  const int64_t v13 = 1024;
  // pto: %c0_index
  const int64_t v14 = 0;
  // pto: %10
  int64_t v15 = (int64_t) ((uint64_t) v4 * (uint64_t) v12);
  // pto: %accum__rv_v2_view
  const int64_t v16 = 1;
  // pto: %accum__rv_v2_view
  const int64_t v17 = 1;
  // pto: %accum__rv_v2_view
  const int64_t v18 = 1;
  // pto: %accum__rv_v2_view
  int64_t v19 = v15 * v9;
  // pto: %accum__rv_v2_view
  int64_t v20 = v18 * v19;
  // pto: %accum__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v21 = pto::Shape<1, 1, 1, -1, -1>(v16, v17, v18, v15, v9);
  // pto: %accum__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v22 = pto::Stride<-1, -1, -1, -1, -1>(v17 * v20, v20, v19, v9, v10);
  // pto: %accum__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v23 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v21, v22);
  // pto: %projected__ssa_v0_view
  const int64_t v24 = 1;
  // pto: %projected__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %projected__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %projected__ssa_v0_view
  int64_t v27 = (int64_t) v5;
  // pto: %projected__ssa_v0_view
  int64_t v28 = v27 * v9;
  // pto: %projected__ssa_v0_view
  int64_t v29 = v26 * v28;
  // pto: %projected__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v30 = pto::Shape<1, 1, 1, -1, -1>(v24, v25, v26, v27, v9);
  // pto: %projected__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v31 = pto::Stride<-1, -1, -1, -1, -1>(v25 * v29, v29, v28, v9, v10);
  // pto: %projected__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v32 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v30, v31);
  // pto: %block__ssa_v0
  int64_t v33 = (int64_t) v6;
  // pto: %0, %1
  int64_t v34 = (int64_t) ((uint64_t) (v33 / v11) * (uint64_t) v12);
  // pto: %2, %3
  int64_t v35 = (int64_t) ((uint64_t) (v33 % v11) * (uint64_t) v13);
  // pto: %4
  int64_t v36 = (int64_t) ((uint64_t) v5 - (uint64_t) v34);
  // pto: %5
  int64_t v37 = v36 < v12 ? v36 : v12;
  // pto: %oa_value__ssa_v0
  Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v38 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v13);
  // pto: %oa_value__ssa_v0
  uint64_t v39 = (uint64_t) v8;
  TASSIGN(v38, v39);
  // pto: %6
  int64_t v40 = v34 < v14 ? v14 : v34;
  // pto: %7
  int64_t v41 = v35 < v14 ? v14 : v35;
  // pto: %accum__rv_v2_pview
  const int64_t v42 = 0;
  // pto: %accum__rv_v2_pview
  __gm__ float* v43 = PTOAS__GLOBAL_TENSOR_DATA(v23);
  // pto: %accum__rv_v2_pview
  const int64_t v44 = 1;
  // pto: %accum__rv_v2_pview
  const int64_t v45 = 1;
  // pto: %accum__rv_v2_pview
  const int64_t v46 = 1;
  // pto: %accum__rv_v2_pview
  int64_t v47 = v37 * v9;
  // pto: %accum__rv_v2_pview
  int64_t v48 = v46 * v47;
  // pto: %accum__rv_v2_pview
  pto::Shape<1, 1, 1, -1, 1024> v49 = pto::Shape<1, 1, 1, -1, 1024>(v44, v45, v46, v37, v13);
  // pto: %accum__rv_v2_pview
  pto::Stride<-1, -1, -1, -1, -1> v50 = pto::Stride<-1, -1, -1, -1, -1>(v45 * v48, v48, v47, v9, v10);
  // pto: %accum__rv_v2_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v51 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v43 + (v42 + v40 * v9 + v41 * v10), v49, v50);
  TLOAD(v38, v51);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %t__tmp_v1
  Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v52 = Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v13);
  // pto: %t__tmp_v1
  uint64_t v53 = (uint64_t) v8;
  TASSIGN(v52, v53);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  RoundMode v54 = RoundMode::CAST_RINT;
  SaturationMode v55 = SaturationMode::ON;
  TCVT(v52, v38, v54, v55);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %projected__ssa_v0_pview
  const int64_t v56 = 0;
  // pto: %projected__ssa_v0_pview
  __gm__ bfloat16_t* v57 = PTOAS__GLOBAL_TENSOR_DATA(v32);
  // pto: %projected__ssa_v0_pview
  const int64_t v58 = 1;
  // pto: %projected__ssa_v0_pview
  const int64_t v59 = 1;
  // pto: %projected__ssa_v0_pview
  const int64_t v60 = 1;
  // pto: %projected__ssa_v0_pview
  int64_t v61 = v37 * v9;
  // pto: %projected__ssa_v0_pview
  int64_t v62 = v60 * v61;
  // pto: %projected__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 1024> v63 = pto::Shape<1, 1, 1, -1, 1024>(v58, v59, v60, v37, v13);
  // pto: %projected__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v64 = pto::Stride<-1, -1, -1, -1, -1>(v59 * v62, v62, v61, v9, v10);
  // pto: %projected__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v65 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v57 + (v56 + v40 * v9 + v41 * v10), v63, v64);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v65, v52);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}