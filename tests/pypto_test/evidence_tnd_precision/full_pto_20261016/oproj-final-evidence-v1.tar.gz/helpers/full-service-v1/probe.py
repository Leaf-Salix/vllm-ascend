"""Use saved real Native FULL6 inputs; stop at first module bit difference."""
import argparse,contextlib,hashlib,json,os
from pathlib import Path
import torch,torch_npu,pypto.torch
from vllm.engine.arg_utils import EngineArgs
from vllm.platforms import current_platform
from vllm_ascend.utils import enable_custom_op
from dsv4_csa_single_layer import make_layer
from dsv4_csa_native_case import native_session
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.hc_pre import hc_pre_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.input_norm import input_norm_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv import wkv_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.indexer_projection import indexer_projection
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv_order_data import WKV_COLUMN_ORDERS,WKV_K_ORDERS,WKV_TOKEN_MODES
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.indexer_order_data import INDEXER_K_ORDERS,INDEXER_TILE_ORDERS,INDEXER_TOKEN_MODES

p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--snapshot-sha',required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
r={'pass':False,'complete':False,'cases':[],'source_commit':'57cb732f6 + PTO O-proj overlay','saved_step':74,'scope':'actual formal service HC-pre through HC-post, same saved real FULL6 input/cache, no new Native2'}
def save():(a.out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def exact(x,y):return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def host(x):
 if x.device.type!='cpu':
  torch.npu.synchronize()
  if torch_npu.get_npu_format(x) not in (0,2):x=torch_npu.npu_format_cast(x,2)
 return x.detach().cpu().contiguous()
def check(label,actual,expected):
 actual=host(actual) if actual.device.type!='cpu' else actual
 expected=host(expected) if expected.device.type!='cpu' else expected
 assert actual.shape==expected.shape and actual.dtype==expected.dtype
 assert torch.isfinite(actual).all() and torch.isfinite(expected).all()
 different=(actual.contiguous().view(torch.int8 if actual.element_size()==1 else (torch.int16 if actual.element_size()==2 else torch.int32))!=expected.contiguous().view(torch.int8 if expected.element_size()==1 else (torch.int16 if expected.element_size()==2 else torch.int32)))
 m={'label':label,'bit_equal':exact(actual,expected),'different_elements':int(different.sum()),'max_abs':float((actual.float()-expected.float()).abs().max()),'first_coordinates':different.nonzero()[:8].tolist()}
 case['comparisons'].append(m);save()
 if not m['bit_equal']:
  m['first_values']=[{'index':idx,'actual':actual[tuple(idx)].item(),'expected':expected[tuple(idx)].item()} for idx in m['first_coordinates']];save()
  torch.save({'layer':layer_index,'stage':label,'input':cpu_input,'actual':actual,'expected':expected},a.out/'first-difference.pt')
  raise RuntimeError('FIRST_BIT_DIFFERENCE '+str(layer_index)+' '+label)

base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
native=Path('/data/pyptouser/yejia/lc128/retest192-native2-b24000/full-probe')
payload=native/'step074.pt';r['native_snapshot_sha256']=hashlib.sha256(payload.read_bytes()).hexdigest()
stage_bytes=(native/'stages.jsonl').read_bytes();assert hashlib.sha256(stage_bytes).hexdigest()=='87fa6b787a138a58cafc9b18ddb10554c8ce08b9064f831ecd0a6a105d8a5945'
stages=[json.loads(line) for line in stage_bytes.splitlines()];stage=stages[74]
assert stage['forward_index']==74 and stage['actual_tokens']==6
fixture=torch.load(payload,map_location='cpu',weights_only=True)
for i,fields in fixture.items():
 for name,value in fields.items():
  d={'shape':list(value.shape),'dtype':str(value.dtype),'sha256':hashlib.sha256(value.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()}
  assert d==stage['layers'][str(i)][name],(i,name)
r['native_snapshot_all_fields_match_saved_stage']=True;save()
torch.npu.set_device(0);torch.npu.config.allow_internal_format=True;torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
current_platform.pre_register_and_update();assert enable_custom_op()
checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config=EngineArgs(model=str(checkpoint),tokenizer_mode='deepseek_v4',trust_remote_code=True,tensor_parallel_size=1,dtype='bfloat16',quantization='ascend',hf_overrides={'sliding_window':128},max_model_len=16384,max_num_seqs=40,max_num_batched_tokens=256,enable_prefix_caching=False,enforce_eager=False,block_size=32,speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,'fuse_norm_quant':True,'align_decode_capture_sizes':False},'enable_cpu_binding':False,'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False}).create_engine_config()
stack=contextlib.ExitStack();stack.enter_context(native_session(config,0))
try:
 with torch.inference_mode():
  from scipy.linalg import hadamard
  from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.native_adapter import prepare_weights,CSAOperators
  pypto.torch.init(device=0,platform='a2a3',runtime='tensormap_and_ringbuffer')
  layer_index=20;case={'layer':20,'comparisons':[]};r['cases'].append(case);save()
  layer,details=make_layer(config,checkpoint,torch.device('npu:0'),20)
  dump=Path('/data/pyptouser/yejia/lc128/full6-hook2/full-probe/l20-after.pt')
  r['snapshot_sha256']=hashlib.sha256(dump.read_bytes()).hexdigest();assert r['snapshot_sha256']==a.snapshot_sha
  after=torch.load(dump,map_location='cpu',weights_only=True)
  r['before_snapshot_sha256']=hashlib.sha256(dump.with_name('l20-before.pt').read_bytes()).hexdigest()
  assert r['before_snapshot_sha256']=='3faf46510b167e259013dddc7a6f59412313b112502ca02a64f796abe4eec04f'
  before=torch.load(dump.with_name('l20-before.pt'),map_location='cpu',weights_only=True)
  assert after['qualified'] and after['record']==before['record'] and after['page_ids'].keys()==before['page_ids'].keys()
  for name in after['page_ids']:assert exact(after['page_ids'][name],before['page_ids'][name])
  cpu_input=fixture[20]['input'];check('actual_graph_norm_saved_gold',after['producers']['normed'],fixture[20]['normed'])
  h=torch.tensor(hadamard(128,dtype=float),dtype=torch.float32,device='npu')
  weights=prepare_weights(layer.self_attn,h,layer)
  # Native compressed/state and indexer/inner_state are alternative typed
  # descriptors of the same physical allocation. Preserve aliases and page IDs.
  carriers={};caches={};guarded_carriers={}
  for name,spec in before['cache_specs'].items():
   dtype=before['caches'][name].dtype;page_bytes=before['caches'][name][0].numel()*before['caches'][name].element_size()
   key=spec['data_ptr'];shape=(spec['shape'][0],page_bytes)
   if key not in carriers:
    import math
    guard_bytes=math.lcm(page_bytes,512)
    owner=torch.full((shape[0]*page_bytes+2*guard_bytes,),37,dtype=torch.int8,device='npu')
    guarded_carriers[key]=(owner,guard_bytes)
    carriers[key]=owner[guard_bytes:-guard_bytes].reshape(shape);carriers[key].zero_()
   assert tuple(carriers[key].shape)==shape
   caches[name]=carriers[key].view(dtype).reshape(spec['shape'])
   assert list(caches[name].stride())==spec['stride']
  for left,ls in before['cache_specs'].items():
   for right,rs in before['cache_specs'].items():
    assert (caches[left].data_ptr()==caches[right].data_ptr()) == (ls['data_ptr']==rs['data_ptr'])
  ids={name:pages.to('npu') for name,pages in before['page_ids'].items()}
  initial={name:value.to('npu') for name,value in before['caches'].items()}
  def restore():
   for name,value in initial.items():caches[name].index_copy_(0,ids[name],value)
  args={**weights,**{name:value.to('npu') for name,value in after['metadata'].items()},**caches}
  args.update(x_hc=cpu_input.reshape(6,4,4096).to('npu'),native_normed=after['producers']['normed'].to('npu'),native_kv_projected=after['producers']['wkv_projected'].to('npu'),native_indexer_weights=after['producers']['indexer_weights'].to('npu'),native_heads=torch.empty((6,32768),dtype=torch.bfloat16,device='npu'),idx_topk=torch.empty((6,512),dtype=torch.int32,device='npu'),idx_topk_scores=torch.empty((6,512),dtype=torch.float32,device='npu'),x_out=torch.empty((6,4,4096),dtype=torch.bfloat16,device='npu'))
  from types import SimpleNamespace
  from vllm_ascend.ascend_forward_context import set_ascend_forward_context
  impl=layer.self_attn.dsa_attn.dsa_attn.impl
  def move(value,key=None):
   if isinstance(value,torch.Tensor):return value.clone() if key=='query_start_loc_cpu' else value.to('npu')
   if isinstance(value,dict):return {k:move(v,k) for k,v in value.items()}
   if isinstance(value,list):return [move(v) for v in value]
   return value
  requests={name:SimpleNamespace(**move(fields)) for name,fields in before['req'].items()}
  prefix=layer.self_attn.dsa_attn.dsa_attn.layer_name
  cos=args['freqs_cos'].view(6,1,1,64);sin=args['freqs_sin'].view(6,1,1,64)
  metadata={name:SimpleNamespace(decode=req,hadamard=h.to(torch.bfloat16)) for name,req in requests.items()}
  for item in requests.values():item.cos={prefix:cos};item.sin={prefix:sin}
  state=caches['compress_state'];inner=caches['inner_compress_state'];packed=caches['idx_native_kv_cache']
  state_view=state.as_strided((24000,2,1,2048),(state.stride(0),2048,2048,1),state.storage_offset())
  inner_view=inner.as_strided((24000,2,1,512),(inner.stride(0),512,512,1),inner.storage_offset())
  key=packed.as_strided((24000,32,1,128),(packed.stride(0),128,128,1),packed.storage_offset())
  scale_storage=packed.view(torch.float16)
  scale=scale_storage.as_strided((24000,32,1,1),(packed.stride(0)//2,1,1,1),scale_storage.storage_offset()+2048)
  kv=(caches['cmp_kv'],caches['kv_cache'],state_view,inner_view,key,scale)
  ordered_meta=[metadata[name] for name in ('compressed','state','indexer_state','indexer','swa')]

  for item in metadata.values():
   item.num_prefills=0;item.num_decodes=1;item.num_decode_tokens=6;item.num_actual_tokens=6
  from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.service import CSAServiceRuntime
  from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv_profile import QUALIFIED_STATIC_METADATA_SHA256
  torch.npu.set_compile_mode(jit_compile=False)
  from npugraph_ex._acl_concrete_graph import static_kernel
  static_kernel.compile_static_kernel(lambda:None)
  assert len(static_kernel._installed_run_pkgs)==13
  assert hashlib.sha256((Path(os.environ['LOW_ACCEPTANCE_OFFICIAL_CACHE'])/'metadata.json').read_bytes()).hexdigest()==QUALIFIED_STATIC_METADATA_SHA256
  runtime=CSAServiceRuntime(layer.self_attn,CSAOperators.register(),40,layer)
  runtime.qualify_static_wkv(metadata_sha256=QUALIFIED_STATIC_METADATA_SHA256,reselected=True)
  context=SimpleNamespace(attn_metadata={runtime.prefixes[name]:metadata[name] for name in runtime.prefixes},additional_kwargs={})
  hidden=args['x_hc'];positions=args['position_ids'].reshape(6)
  owner=torch.full((8,4,4096),0.0625,dtype=torch.bfloat16,device='npu');output=owner[1:7]
  assert runtime.eligible(context,hidden,positions)
  target_path=Path('/data/pyptouser/yejia/f6/staticcore1/result/native-components.pt')
  assert hashlib.sha256(target_path.read_bytes()).hexdigest()=='5db189411b6da8ade71c5cc30bacead04eb5a4d21de81f2f55ab6cb5ef9fff09'
  target=torch.load(target_path,map_location='cpu',weights_only=True)
  frozen={name:host(value).clone() for name,value in args.items() if name not in caches and name not in ('native_heads','idx_topk','idx_topk_scores','x_out')}
  def guards():
   assert all(bool((value[:count]==37).all() & (value[-count:]==37).all()) for value,count in guarded_carriers.values())
   assert bool((owner[0]==0.0625).all() & (owner[-1]==0.0625).all())
   assert all(exact(host(args[name]),value) for name,value in frozen.items())
  def invoke():
   context.additional_kwargs.clear()
   with set_ascend_forward_context({},config,num_tokens=6,num_actual_tokens=6):
    runtime(context,hidden,positions,output,kv)
  def verify(label):
   guards()
   check(label+'_normed',runtime.normed[:6],fixture[20]['normed'])
   check(label+'_wkv',runtime.wkv_projected[:6],target['q_stages']['wkv'])
   check(label+'_indexer_weights',runtime.indexer_weights[:6],after['producers']['indexer_weights'])
   check(label+'_heads',runtime.native_heads[:6],fixture[20]['heads'].reshape(6,32768))
   check(label+'_oproj',runtime.native_attention_out[:6],fixture[20]['oproj'])
   check(label+'_HCpre_to_HCpost',output,fixture[20]['attention_half'].reshape(6,4,4096))
   check(label+'_topk',runtime.topk[:6],target['topk'])
  # A Native fallback is a failure, including inside a captured graph.
  def forbidden(*values,**options):raise RuntimeError('FORMAL_O_PROJ_CALLED_NATIVE')
  impl._forward_o_proj=forbidden
  restore();output.fill_(float('nan'));invoke();torch.npu.synchronize();verify('formal_eager')
  restore();g=torch.npu.NPUGraph()
  with torch.npu.graph(g):invoke()
  for repeat in range(2):
   restore();output.fill_(float('nan'));g.replay();torch.npu.synchronize();verify('formal_graph_'+str(repeat))
  assert runtime.wkv_profile.captured
  r.update(complete=True);r['pass']=True;r['native_oproj_calls']=0;r['restored_modules']=runtime.restored_modules;save()
except Exception as e:r['error']=repr(e);save();raise
finally:stack.close()
