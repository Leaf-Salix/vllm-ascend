#!/usr/bin/env bash
set -euo pipefail
label=${1:?}
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/wkv-production-oproj-20261017
for layer in 2 42; do
  bash "$base/oproj-sweep-v1/run.sh" "$label-layer$layer" \
    --layer "$layer" --step 10 --pad 144 --sizes 6,144 \
    --orders-sha 2c6ed88f69024a894543228a818cc5e7a4081ffacbceebb9fec5452a2b187686
done
