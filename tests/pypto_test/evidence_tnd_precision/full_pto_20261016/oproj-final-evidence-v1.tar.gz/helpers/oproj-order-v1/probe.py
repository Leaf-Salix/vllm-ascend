"""真实 FULL6 heads 的 PTO WO-A 首阶段逐 bit 对拍；首差立即停止。"""
import argparse, contextlib, hashlib, json, os
from pathlib import Path
import torch, torch_npu, pypto.torch
from vllm.engine.arg_utils import EngineArgs
from vllm.platforms import current_platform
from vllm_ascend.utils import enable_custom_op
from dsv4_csa_single_layer import make_layer
from dsv4_csa_native_case import native_session
from o_proj import o_proj_test
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--device',type=int);p.add_argument('--layer',type=int,default=20);p.add_argument('--step',type=int,default=74);p.add_argument('--pad',type=int,default=6);a=p.parse_args();a.out.mkdir(parents=True)
r={'pass':False,'complete':False,'scope':'saved real model L20 first FULL6 heads, not a new Native2 model run','comparisons':[]}
def save():(a.out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def host(x):
 torch.npu.synchronize()
 if x.device.type!='cpu' and torch_npu.get_npu_format(x) not in (0,2):x=torch_npu.npu_format_cast(x,2)
 return x.detach().cpu().contiguous()
def check(label,x,y):
 x,y=host(x),host(y)
 assert x.shape==y.shape and x.dtype==y.dtype and torch.isfinite(x).all() and torch.isfinite(y).all()
 itype={1:torch.int8,2:torch.int16,4:torch.int32}[x.element_size()]
 diff=x.view(itype)!=y.view(itype)
 m={'label':label,'bit_equal':not bool(diff.any()),'different_elements':int(diff.sum()),'max_abs':float((x.float()-y.float()).abs().max()),'first_coordinates':diff.nonzero()[:8].tolist()}
 r['comparisons'].append(m);save()
 if not m['bit_equal']:
  m['first_values']=[{'index':idx,'pto':x[tuple(idx)].item(),'native':y[tuple(idx)].item()} for idx in m['first_coordinates']];save()
  torch.save({'stage':label,'heads':fixture[a.layer]['heads'],'actual':x,'expected':y},a.out/'first-difference.pt')
  raise RuntimeError('FIRST_BIT_DIFFERENCE '+label)
torch.npu.set_device(0);torch.npu.config.allow_internal_format=True;torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
current_platform.pre_register_and_update();assert enable_custom_op()
checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config=EngineArgs(model=str(checkpoint),tokenizer_mode='deepseek_v4',trust_remote_code=True,tensor_parallel_size=1,dtype='bfloat16',quantization='ascend',hf_overrides={'sliding_window':128},max_model_len=16384,max_num_seqs=40,max_num_batched_tokens=256,enable_prefix_caching=False,enforce_eager=False,block_size=32,speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,'fuse_norm_quant':True,'align_decode_capture_sizes':False},'enable_cpu_binding':False,'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False}).create_engine_config()

stack=contextlib.ExitStack();stack.enter_context(native_session(config,0))
try:
 with torch.inference_mode():
  pypto.torch.init(device=0,platform='a2a3',runtime='tensormap_and_ringbuffer')
  layer,details=make_layer(config,checkpoint,torch.device('npu:0'),a.layer)
  impl=layer.self_attn.dsa_attn.dsa_attn.impl
  native=Path('/data/pyptouser/yejia/lc128/retest192-native2-b24000/full-probe')
  payload=native/f'step{a.step:03d}.pt'
  r['fixture_sha256']=hashlib.sha256(payload.read_bytes()).hexdigest()
  if a.step==74:assert r['fixture_sha256']=='5b873509016a7419abf5639a808da58950eb2d3d3bd332c00ed8625e00174481'
  fixture=torch.load(payload,map_location='cpu',weights_only=True)
  stages=[json.loads(line) for line in (native/'stages.jsonl').read_text().splitlines()]
  for name in ('heads','oproj'):
   value=fixture[a.layer][name].contiguous()
   assert hashlib.sha256(value.view(torch.uint8).numpy().tobytes()).hexdigest()==stages[a.step]['layers'][str(a.layer)][name]['sha256']
  actual_rows=fixture[a.layer]['heads'].shape[0];rows=max(actual_rows,a.pad)
  assert 1<=actual_rows<=rows<=256
  initial=torch.zeros((rows,32768),dtype=torch.bfloat16)
  initial[:actual_rows]=fixture[a.layer]['heads'].reshape(actual_rows,32768)
  r.update(layer=a.layer,step=a.step,actual_rows=actual_rows,padded_rows=rows,scope='same saved real model heads, zero padded to captured bucket, same-input Native component and full model prefix gold')
  heads=initial.to('npu')
  torch.npu.set_compile_mode(jit_compile=False)
  from npugraph_ex._acl_concrete_graph import static_kernel
  static_kernel.compile_static_kernel(lambda:None)
  assert len(static_kernel._installed_run_pkgs)==13
  r['static_package_count']=13
  r['static_metadata_sha256']=hashlib.sha256((Path(os.environ['LOW_ACCEPTANCE_OFFICIAL_CACHE'])/'metadata.json').read_bytes()).hexdigest()
  assert r['static_metadata_sha256']=='863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
  micro=torch.zeros((3,8192),dtype=torch.bfloat16,device='npu')
  micro[1].fill_(2**-40);micro[2].fill_(2**-20)
  mq,ms=torch_npu.npu_dynamic_quant(micro,dst_type=torch.int8)
  r['native_quant_micro']={'scale':host(ms).flatten().tolist(),'quant_unique':[host(row).unique().tolist() for row in mq]};save()
  # Reuse exactly the service's original ND/NZ layout descriptors and scale, no new weight conversion.
  from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.native_adapter import prepare_weights
  weights=prepare_weights(layer.self_attn,None,layer)
  wa,wb,ws=(weights[k] for k in ('wo_a','wo_b','wo_b_scale'))
  frozen=[hashlib.sha256(host(w).view(torch.uint8).numpy().tobytes()).hexdigest() for w in (wa,wb,ws)]
  def guarded(shape,dtype):
   owner=torch.full((shape[0]+16,*shape[1:]),0.0625 if dtype.is_floating_point else 37,dtype=dtype,device='npu')
   return owner,owner[8:-8]
  owners=[];outputs=[]
  for shape,dtype in (((rows,8192),torch.bfloat16),((rows,8192),torch.int8),((rows,1),torch.float32),((rows,4096),torch.bfloat16)):
   owner,out=guarded(shape,dtype);owners.append(owner);outputs.append(out)
  oa,qi,scale,output=outputs
  op=pypto.torch.register(o_proj_test,'full_precision_probe::oproj_v6')
  def call():op(heads,wa,wb,ws,*outputs)
  native_output=torch.empty((rows,4096),dtype=torch.bfloat16,device='npu')
  def reference(value,label):
   heads.copy_(value)
   observed={}
   bmm0=torch_npu.npu_transpose_batchmatmul;quant0=torch_npu.npu_dynamic_quant
   def bmm(*args,**kwargs):
    result=bmm0(*args,**kwargs);observed['oa']=result.clone().reshape(rows,8192);return result
   def quant(*args,**kwargs):
    result=quant0(*args,**kwargs);observed['qi']=result[0].clone();observed['scale']=result[1].clone().reshape(rows,1);return result
   impl._forward_o_proj(heads.view(rows,64,512),native_output)
   unhooked=native_output.clone()
   torch_npu.npu_transpose_batchmatmul=bmm;torch_npu.npu_dynamic_quant=quant
   try:impl._forward_o_proj(heads.view(rows,64,512),native_output)
   finally:torch_npu.npu_transpose_batchmatmul=bmm0;torch_npu.npu_dynamic_quant=quant0
   check(label+'_hook_fidelity',native_output,unhooked)
   observed['output']=native_output.clone()
   if label=='A':check('Native_same_heads_vs_saved_whole_model',native_output[:actual_rows],fixture[a.layer]['oproj'])
   return observed
  def check_all(label,ref,value):
   # Numerical order is deliberate. Never inspect/qualify later stages after a first difference.
   for key,actual in zip(('oa','qi','scale','output'),outputs):check(label+'_'+key,actual,ref[key])
   check(label+'_input_unchanged',heads,value)
   for owner in owners:
    sentinel=0.0625 if owner.dtype.is_floating_point else 37
    assert bool((owner[:8]==sentinel).all() & (owner[-8:]==sentinel).all()),'output guard modified'
   assert frozen==[hashlib.sha256(host(w).view(torch.uint8).numpy().tobytes()).hexdigest() for w in (wa,wb,ws)]
  refa=reference(initial,'A')
  assert rows==144 and actual_rows==126
  orders=[]
  for width in (1,2,4,8,16):
   for direction in (1,-1):
    for start in range(16//width):
     order=tuple(((start+direction*i)%(16//width))*width+j for i in range(16//width) for j in range(width))
     if order not in orders:orders.append(order)
  triples=[(0,5,11),(6,7,8),(2,9,12),(4,6,14),(1,13,15),(3,10,11)]
  last={q:torch.tensor([max(q,key=o.index) for o in orders]) for q in triples}
  assert len(set(tuple(last[q][i].item() for q in triples) for i in range(len(orders))))==len(orders)
  candidates=torch.ones((rows,8,64,len(orders)),dtype=torch.bool)
  native_x=torch.ones((rows,8,4096),dtype=torch.bfloat16,device='npu')
  r['native_order_queries']=[]
  for q in triples:
   flags=[]
   for small in q:
    rest=[k for k in q if k!=small]
    weight_cpu=torch.zeros((8,4096,1024),dtype=torch.bfloat16)
    weight_cpu[:,rest[0]*256,:]=1;weight_cpu[:,rest[1]*256,:]=-1;weight_cpu[:,small*256,:]=2**-25
    nw=torch_npu.npu_format_cast(weight_cpu.to('npu'),29)
    assert torch_npu.get_npu_format(nw)==29
    def native_bmm():return torch_npu.npu_transpose_batchmatmul(native_x,nw,bias=None,scale=None,perm_x1=(1,0,2),perm_x2=(0,1,2),perm_y=(1,0,2),batch_split_factor=1)
    value=host(native_bmm());repeat=host(native_bmm())
    assert torch.equal(value.view(torch.uint8),repeat.view(torch.uint8)), 'Native finite query repeat differs'
    assert bool(((value==0)|(value==2**-25)).all()), 'unexpected non-serial finite result'
    assert torch.equal(value,value[:,:,::16].repeat_interleave(16,2)), 'sub16 N order differs'
    flags.append(value[:,:,::16]==2**-25)
   bits=torch.stack(flags)
   if not bool((bits.sum(0)==1).all()):
    torch.save({'triple':q,'bits':bits},a.out/'nonserial.pt')
    raise RuntimeError('Not one serial last K256 block')
   observed=torch.tensor(q)[bits.long().argmax(0)]
   candidates &= last[q][None,None,None,:]==observed[:,:,:,None]
   count=candidates.sum(3)
   r['native_order_queries'].append({'triple':list(q),'min_candidates':int(count.min()),'max_candidates':int(count.max()),'last_values':observed.unique().tolist()});save()
   assert bool((count>0).all()), '44-order K256 family rejected'
  assert bool((candidates.sum(3)==1).all()), 'ambiguous order'
  selected=candidates.long().argmax(3)
  torch.save({'orders':orders,'selected':selected,'rows':rows,'column_width':16},a.out/'native-orders.pt')
  r['orders']=orders
  r['selected_unique']=selected.unique().tolist()
  r['row_invariant']=torch.equal(selected,selected[0:1].expand_as(selected))
  r['group_invariant']=torch.equal(selected,selected[:,0:1].expand_as(selected))
  r['selected_by_row']=selected[:,0,:].tolist()
  r.update(complete=True);r['pass']=True;r['scope']='Native K256 44-family finite queries only; actual real heads still require candidate verification';save()
except Exception as e:r['error']=repr(e);save();raise
finally:stack.close()
