#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void hc_post(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, __gm__ float* v4, __gm__ float* v5, int64_t v6, int64_t v7, int32_t v8, int32_t v9) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c16384_i64
  const int64_t v10 = 16384;
  // pto: %c32768_i64
  const int64_t v11 = 32768;
  // pto: %c49152_i64
  const int64_t v12 = 49152;
  // pto: %c65536_i64
  const int64_t v13 = 65536;
  // pto: %c81920_i64
  const int64_t v14 = 81920;
  // pto: %c0_i64
  const int64_t v15 = 0;
  // pto: %c98304_i64
  const int64_t v16 = 98304;
  // pto: %c114688_i64
  const int64_t v17 = 114688;
  // pto: %c122880_i64
  const int64_t v18 = 122880;
  // pto: %c16384_index
  const int64_t v19 = 16384;
  // pto: %c1_index
  const int64_t v20 = 1;
  // pto: %c4096_index
  const int64_t v21 = 4096;
  // pto: %c4_index
  const int64_t v22 = 4;
  // pto: %c16_index
  const int64_t v23 = 16;
  // pto: %c2_index
  const int64_t v24 = 2;
  // pto: %c0_index
  const int64_t v25 = 0;
  // pto: %c8_index
  const int64_t v26 = 8;
  // pto: %c12_index
  const int64_t v27 = 12;
  // pto: %c5_index
  const int64_t v28 = 5;
  // pto: %c9_index
  const int64_t v29 = 9;
  // pto: %c13_index
  const int64_t v30 = 13;
  // pto: %c6_index
  const int64_t v31 = 6;
  // pto: %c10_index
  const int64_t v32 = 10;
  // pto: %c14_index
  const int64_t v33 = 14;
  // pto: %c3_index
  const int64_t v34 = 3;
  // pto: %c7_index
  const int64_t v35 = 7;
  // pto: %c11_index
  const int64_t v36 = 11;
  // pto: %c15_index
  const int64_t v37 = 15;
  // pto: %c8192_index
  const int64_t v38 = 8192;
  // pto: %c12288_index
  const int64_t v39 = 12288;
  // pto: %cn1_index
  const int64_t v40 = -1;
  // pto: %y_flat__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %y_flat__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %y_flat__ssa_v0_view
  const int64_t v43 = 1;
  // pto: %y_flat__ssa_v0_view
  int64_t v44 = (int64_t) v7;
  // pto: %y_flat__ssa_v0_view
  int64_t v45 = v44 * v19;
  // pto: %y_flat__ssa_v0_view
  int64_t v46 = v43 * v45;
  // pto: %y_flat__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v47 = pto::Shape<1, 1, 1, -1, -1>(v41, v42, v43, v44, v19);
  // pto: %y_flat__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v48 = pto::Stride<-1, -1, -1, -1, -1>(v42 * v46, v46, v45, v19, v20);
  // pto: %y_flat__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v49 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v47, v48);
  // pto: %x__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %x__ssa_v0_view
  const int64_t v51 = 1;
  // pto: %x__ssa_v0_view
  const int64_t v52 = 1;
  // pto: %x__ssa_v0_view
  int64_t v53 = (int64_t) v7;
  // pto: %x__ssa_v0_view
  int64_t v54 = v53 * v21;
  // pto: %x__ssa_v0_view
  int64_t v55 = v52 * v54;
  // pto: %x__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v56 = pto::Shape<1, 1, 1, -1, -1>(v50, v51, v52, v53, v21);
  // pto: %x__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v57 = pto::Stride<-1, -1, -1, -1, -1>(v51 * v55, v55, v54, v21, v20);
  // pto: %x__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v58 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v56, v57);
  // pto: %residual_flat__ssa_v0_view
  const int64_t v59 = 1;
  // pto: %residual_flat__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %residual_flat__ssa_v0_view
  const int64_t v61 = 1;
  // pto: %residual_flat__ssa_v0_view
  int64_t v62 = (int64_t) v7;
  // pto: %residual_flat__ssa_v0_view
  int64_t v63 = v62 * v19;
  // pto: %residual_flat__ssa_v0_view
  int64_t v64 = v61 * v63;
  // pto: %residual_flat__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v65 = pto::Shape<1, 1, 1, -1, -1>(v59, v60, v61, v62, v19);
  // pto: %residual_flat__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v66 = pto::Stride<-1, -1, -1, -1, -1>(v60 * v64, v64, v63, v19, v20);
  // pto: %residual_flat__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v67 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v65, v66);
  // pto: %token_block__ssa_v0, %145
  int64_t v68 = (int64_t) ((uint64_t) ((int64_t) v8) * (uint64_t) v22);
  // pto: %146
  int64_t v69 = (int64_t) ((uint64_t) v68 + (uint64_t) v22);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  for (int64_t v70 = v68; v70 < v69; v70 += v24) {
    // pto: %147
    ;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    if (v70 < v7) {
      // pto: %flat_offset_mul
      ;
      int64_t v71 = (int64_t) ((uint64_t) v70 * (uint64_t) v22);
      // pto: %post_scalar_inline16__tile
      ;
      float v72 = (v4)[v71];
      // pto: %148
      ;
      int64_t v73 = (int64_t) ((uint64_t) v70 * (uint64_t) v23);
      // pto: %comb_scalar_0_inline4__tile
      ;
      float v74 = (v5)[v73];
      // pto: %151, %comb_scalar_1_inline19__tile
      ;
      float v75 = (v5)[(int64_t) ((uint64_t) v73 + (uint64_t) v22)];
      // pto: %153, %comb_scalar_2_inline10__tile
      ;
      float v76 = (v5)[(int64_t) ((uint64_t) v73 + (uint64_t) v26)];
      // pto: %155, %comb_scalar_3_inline2__tile
      ;
      float v77 = (v5)[(int64_t) ((uint64_t) v73 + (uint64_t) v27)];
      // pto: %158, %156
      ;
      float v78 = (v4)[(int64_t) ((uint64_t) v71 + (uint64_t) v20)];
      // pto: %161, %159
      ;
      float v79 = (v5)[(int64_t) ((uint64_t) v73 + (uint64_t) v20)];
      // pto: %164, %162
      ;
      float v80 = (v5)[(int64_t) ((uint64_t) v73 + (uint64_t) v28)];
      // pto: %167, %165
      ;
      float v81 = (v5)[(int64_t) ((uint64_t) v73 + (uint64_t) v29)];
      // pto: %170, %168
      ;
      float v82 = (v5)[(int64_t) ((uint64_t) v73 + (uint64_t) v30)];
      // pto: %173, %171
      ;
      float v83 = (v4)[(int64_t) ((uint64_t) v71 + (uint64_t) v24)];
      // pto: %176, %174
      ;
      float v84 = (v5)[(int64_t) ((uint64_t) v73 + (uint64_t) v24)];
      // pto: %179, %177
      ;
      float v85 = (v5)[(int64_t) ((uint64_t) v73 + (uint64_t) v31)];
      // pto: %182, %180
      ;
      float v86 = (v5)[(int64_t) ((uint64_t) v73 + (uint64_t) v32)];
      // pto: %185, %183
      ;
      float v87 = (v5)[(int64_t) ((uint64_t) v73 + (uint64_t) v33)];
      // pto: %188, %186
      ;
      float v88 = (v4)[(int64_t) ((uint64_t) v71 + (uint64_t) v34)];
      // pto: %191, %189
      ;
      float v89 = (v5)[(int64_t) ((uint64_t) v73 + (uint64_t) v34)];
      // pto: %194, %192
      ;
      float v90 = (v5)[(int64_t) ((uint64_t) v73 + (uint64_t) v35)];
      // pto: %197, %195
      ;
      float v91 = (v5)[(int64_t) ((uint64_t) v73 + (uint64_t) v36)];
      // pto: %200, %198
      ;
      float v92 = (v5)[(int64_t) ((uint64_t) v73 + (uint64_t) v37)];
      // pto: %x_block__tile
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %x_block__tile
      ;
      uint64_t v94 = (uint64_t) v10;
      TASSIGN(v93, v94);
      // pto: %201
      ;
      int64_t v95 = v70 < v25 ? v25 : v70;
      // pto: %x__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v96 = PTOAS__GLOBAL_TENSOR_DATA(v58);
      // pto: %x__ssa_v0_pview
      ;
      const int64_t v97 = 0;
      // pto: %x__ssa_v0_pview
      ;
      const int64_t v98 = 4096;
      // pto: %x__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 4096> v99 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %x__ssa_v0_pview
      ;
      pto::Stride<4096, 4096, 4096, 4096, 1> v100 = pto::Stride<4096, 4096, 4096, 4096, 1>();
      // pto: %x__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v101 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v96 + (v97 + v95 * v98), v99, v100);
      TLOAD(v93, v101);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %202
      ;
      int64_t v102 = (int64_t) ((uint64_t) v7 - (uint64_t) v70);
      // pto: %203
      ;
      int64_t v103 = v102 < v25 ? v25 : v102;
      // pto: %204
      ;
      int64_t v104 = v103 < v20 ? v103 : v20;
      // pto: %t__tile
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v105 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %t__tile
      ;
      uint64_t v106 = (uint64_t) v11;
      TASSIGN(v105, v106);
      // pto: %residual_flat__ssa_v0_pview
      ;
      const int64_t v107 = 0;
      // pto: %residual_flat__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v108 = PTOAS__GLOBAL_TENSOR_DATA(v67);
      // pto: %residual_flat__ssa_v0_pview
      ;
      const int64_t v109 = 1;
      // pto: %residual_flat__ssa_v0_pview
      ;
      const int64_t v110 = 1;
      // pto: %residual_flat__ssa_v0_pview
      ;
      const int64_t v111 = 1;
      // pto: %residual_flat__ssa_v0_pview
      ;
      int64_t v112 = v104 * v19;
      // pto: %residual_flat__ssa_v0_pview
      ;
      int64_t v113 = v111 * v112;
      // pto: %residual_flat__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 4096> v114 = pto::Shape<1, 1, 1, -1, 4096>(v109, v110, v111, v104, v21);
      // pto: %residual_flat__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v115 = pto::Stride<-1, -1, -1, -1, -1>(v110 * v113, v113, v112, v19, v20);
      // pto: %residual_flat__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v116 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v108 + (v107 + v95 * v19 + v25 * v20), v114, v115);
      TLOAD(v105, v116);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %0
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %0
      ;
      uint64_t v118 = (uint64_t) v12;
      TASSIGN(v117, v118);
      // pto: %216
      ;
      const int64_t v119 = 0;
      // pto: %216
      ;
      __gm__ bfloat16_t* v120 = PTOAS__GLOBAL_TENSOR_DATA(v67);
      // pto: %216
      ;
      const int64_t v121 = 1;
      // pto: %216
      ;
      const int64_t v122 = 1;
      // pto: %216
      ;
      const int64_t v123 = 1;
      // pto: %216
      ;
      int64_t v124 = v104 * v19;
      // pto: %216
      ;
      int64_t v125 = v123 * v124;
      // pto: %216
      ;
      pto::Shape<1, 1, 1, -1, 4096> v126 = pto::Shape<1, 1, 1, -1, 4096>(v121, v122, v123, v104, v21);
      // pto: %216
      ;
      pto::Stride<-1, -1, -1, -1, -1> v127 = pto::Stride<-1, -1, -1, -1, -1>(v122 * v125, v125, v124, v19, v20);
      // pto: %216
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v128 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v120 + (v119 + v95 * v19 + v21 * v20), v126, v127);
      TLOAD(v117, v128);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %1
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %1
      ;
      uint64_t v130 = (uint64_t) v13;
      TASSIGN(v129, v130);
      // pto: %224
      ;
      const int64_t v131 = 0;
      // pto: %224
      ;
      __gm__ bfloat16_t* v132 = PTOAS__GLOBAL_TENSOR_DATA(v67);
      // pto: %224
      ;
      const int64_t v133 = 1;
      // pto: %224
      ;
      const int64_t v134 = 1;
      // pto: %224
      ;
      const int64_t v135 = 1;
      // pto: %224
      ;
      int64_t v136 = v104 * v19;
      // pto: %224
      ;
      int64_t v137 = v135 * v136;
      // pto: %224
      ;
      pto::Shape<1, 1, 1, -1, 4096> v138 = pto::Shape<1, 1, 1, -1, 4096>(v133, v134, v135, v104, v21);
      // pto: %224
      ;
      pto::Stride<-1, -1, -1, -1, -1> v139 = pto::Stride<-1, -1, -1, -1, -1>(v134 * v137, v137, v136, v19, v20);
      // pto: %224
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v140 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v132 + (v131 + v95 * v19 + v38 * v20), v138, v139);
      TLOAD(v129, v140);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %2
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v141 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %2
      ;
      uint64_t v142 = (uint64_t) v14;
      TASSIGN(v141, v142);
      // pto: %232
      ;
      const int64_t v143 = 0;
      // pto: %232
      ;
      __gm__ bfloat16_t* v144 = PTOAS__GLOBAL_TENSOR_DATA(v67);
      // pto: %232
      ;
      const int64_t v145 = 1;
      // pto: %232
      ;
      const int64_t v146 = 1;
      // pto: %232
      ;
      const int64_t v147 = 1;
      // pto: %232
      ;
      int64_t v148 = v104 * v19;
      // pto: %232
      ;
      int64_t v149 = v147 * v148;
      // pto: %232
      ;
      pto::Shape<1, 1, 1, -1, 4096> v150 = pto::Shape<1, 1, 1, -1, 4096>(v145, v146, v147, v104, v21);
      // pto: %232
      ;
      pto::Stride<-1, -1, -1, -1, -1> v151 = pto::Stride<-1, -1, -1, -1, -1>(v146 * v149, v149, v148, v19, v20);
      // pto: %232
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v152 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v144 + (v143 + v95 * v19 + v39 * v20), v150, v151);
      TLOAD(v141, v152);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      // pto: %x_f32_inline3__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v153 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %x_f32_inline3__tile
      ;
      uint64_t v154 = (uint64_t) v15;
      TASSIGN(v153, v154);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      RoundMode v155 = RoundMode::CAST_ROUND;
      SaturationMode v156 = SaturationMode::ON;
      TCVT(v153, v93, v155, v156);
      // pto: %res_0_inline6__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %res_0_inline6__tile
      ;
      uint64_t v158 = (uint64_t) v10;
      TASSIGN(v157, v158);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      RoundMode v159 = RoundMode::CAST_ROUND;
      SaturationMode v160 = SaturationMode::ON;
      TCVT(v157, v105, v159, v160);
      // pto: %res_1_inline7__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v161 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %res_1_inline7__tile
      ;
      uint64_t v162 = (uint64_t) v11;
      TASSIGN(v161, v162);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      RoundMode v163 = RoundMode::CAST_ROUND;
      SaturationMode v164 = SaturationMode::ON;
      TCVT(v161, v117, v163, v164);
      // pto: %res_2_inline8__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v165 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %res_2_inline8__tile
      ;
      uint64_t v166 = (uint64_t) v12;
      TASSIGN(v165, v166);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      RoundMode v167 = RoundMode::CAST_ROUND;
      SaturationMode v168 = SaturationMode::ON;
      TCVT(v165, v129, v167, v168);
      // pto: %res_3_inline9__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %res_3_inline9__tile
      ;
      uint64_t v170 = (uint64_t) v13;
      TASSIGN(v169, v170);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      RoundMode v171 = RoundMode::CAST_ROUND;
      SaturationMode v172 = SaturationMode::ON;
      TCVT(v169, v141, v171, v172);
      // pto: %single_y_inline14__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v173 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %single_y_inline14__tile
      ;
      uint64_t v174 = (uint64_t) v14;
      TASSIGN(v173, v174);
      pipe_barrier(PIPE_V);
      TMULS(v173, v153, v72);
      // pto: %single_weighted_0_inline20__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %single_weighted_0_inline20__tile
      ;
      uint64_t v176 = (uint64_t) v16;
      TASSIGN(v175, v176);
      TMULS(v175, v157, v74);
      // pto: %single_y_v1_inline11__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %single_y_v1_inline11__tile
      ;
      uint64_t v178 = (uint64_t) v14;
      TASSIGN(v177, v178);
      pipe_barrier(PIPE_V);
      TADD(v177, v173, v175);
      // pto: %single_weighted_1_inline12__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v179 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %single_weighted_1_inline12__tile
      ;
      uint64_t v180 = (uint64_t) v16;
      TASSIGN(v179, v180);
      pipe_barrier(PIPE_V);
      TMULS(v179, v161, v75);
      // pto: %single_y_v2_inline18__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %single_y_v2_inline18__tile
      ;
      uint64_t v182 = (uint64_t) v14;
      TASSIGN(v181, v182);
      pipe_barrier(PIPE_V);
      TADD(v181, v177, v179);
      // pto: %single_weighted_2_inline15__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %single_weighted_2_inline15__tile
      ;
      uint64_t v184 = (uint64_t) v16;
      TASSIGN(v183, v184);
      pipe_barrier(PIPE_V);
      TMULS(v183, v165, v76);
      // pto: %single_y_v3_inline17__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v185 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %single_y_v3_inline17__tile
      ;
      uint64_t v186 = (uint64_t) v14;
      TASSIGN(v185, v186);
      pipe_barrier(PIPE_V);
      TADD(v185, v181, v183);
      // pto: %single_weighted_3_inline1__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v187 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %single_weighted_3_inline1__tile
      ;
      uint64_t v188 = (uint64_t) v16;
      TASSIGN(v187, v188);
      pipe_barrier(PIPE_V);
      TMULS(v187, v169, v77);
      // pto: %single_y_v4_inline0__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v189 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %single_y_v4_inline0__tile
      ;
      uint64_t v190 = (uint64_t) v14;
      TASSIGN(v189, v190);
      pipe_barrier(PIPE_V);
      TADD(v189, v185, v187);
      // pto: %single_result_inline5__tile
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v191 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %single_result_inline5__tile
      ;
      uint64_t v192 = (uint64_t) v17;
      TASSIGN(v191, v192);
      pipe_barrier(PIPE_V);
      RoundMode v193 = RoundMode::CAST_RINT;
      SaturationMode v194 = SaturationMode::ON;
      TCVT(v191, v189, v193, v194);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      v191.SetValidShape(v20, v21);
      // pto: %4
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v195 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %4
      ;
      uint64_t v196 = (uint64_t) v14;
      TASSIGN(v195, v196);
      pipe_barrier(PIPE_V);
      TMULS(v195, v153, v78);
      // pto: %5
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v197 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %5
      ;
      uint64_t v198 = (uint64_t) v16;
      TASSIGN(v197, v198);
      TMULS(v197, v157, v79);
      // pto: %6
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v199 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %6
      ;
      uint64_t v200 = (uint64_t) v14;
      TASSIGN(v199, v200);
      pipe_barrier(PIPE_V);
      TADD(v199, v195, v197);
      // pto: %7
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v201 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %7
      ;
      uint64_t v202 = (uint64_t) v16;
      TASSIGN(v201, v202);
      pipe_barrier(PIPE_V);
      TMULS(v201, v161, v80);
      // pto: %8
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v203 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %8
      ;
      uint64_t v204 = (uint64_t) v14;
      TASSIGN(v203, v204);
      pipe_barrier(PIPE_V);
      TADD(v203, v199, v201);
      // pto: %9
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v205 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %9
      ;
      uint64_t v206 = (uint64_t) v16;
      TASSIGN(v205, v206);
      pipe_barrier(PIPE_V);
      TMULS(v205, v165, v81);
      // pto: %10
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %10
      ;
      uint64_t v208 = (uint64_t) v14;
      TASSIGN(v207, v208);
      pipe_barrier(PIPE_V);
      TADD(v207, v203, v205);
      // pto: %11
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v209 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %11
      ;
      uint64_t v210 = (uint64_t) v16;
      TASSIGN(v209, v210);
      pipe_barrier(PIPE_V);
      TMULS(v209, v169, v82);
      // pto: %12
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %12
      ;
      uint64_t v212 = (uint64_t) v14;
      TASSIGN(v211, v212);
      pipe_barrier(PIPE_V);
      TADD(v211, v207, v209);
      // pto: %13
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v213 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %13
      ;
      uint64_t v214 = (uint64_t) v18;
      TASSIGN(v213, v214);
      pipe_barrier(PIPE_V);
      RoundMode v215 = RoundMode::CAST_RINT;
      SaturationMode v216 = SaturationMode::ON;
      TCVT(v213, v211, v215, v216);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      v213.SetValidShape(v20, v21);
      // pto: %15
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %15
      ;
      uint64_t v218 = (uint64_t) v14;
      TASSIGN(v217, v218);
      pipe_barrier(PIPE_V);
      TMULS(v217, v153, v83);
      // pto: %16
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v219 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %16
      ;
      uint64_t v220 = (uint64_t) v16;
      TASSIGN(v219, v220);
      TMULS(v219, v157, v84);
      // pto: %17
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v221 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %17
      ;
      uint64_t v222 = (uint64_t) v14;
      TASSIGN(v221, v222);
      pipe_barrier(PIPE_V);
      TADD(v221, v217, v219);
      // pto: %18
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v223 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %18
      ;
      uint64_t v224 = (uint64_t) v16;
      TASSIGN(v223, v224);
      pipe_barrier(PIPE_V);
      TMULS(v223, v161, v85);
      // pto: %19
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v225 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %19
      ;
      uint64_t v226 = (uint64_t) v14;
      TASSIGN(v225, v226);
      pipe_barrier(PIPE_V);
      TADD(v225, v221, v223);
      // pto: %20
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v227 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %20
      ;
      uint64_t v228 = (uint64_t) v16;
      TASSIGN(v227, v228);
      pipe_barrier(PIPE_V);
      TMULS(v227, v165, v86);
      // pto: %21
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v229 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %21
      ;
      uint64_t v230 = (uint64_t) v14;
      TASSIGN(v229, v230);
      pipe_barrier(PIPE_V);
      TADD(v229, v225, v227);
      // pto: %22
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v231 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %22
      ;
      uint64_t v232 = (uint64_t) v16;
      TASSIGN(v231, v232);
      pipe_barrier(PIPE_V);
      TMULS(v231, v169, v87);
      // pto: %23
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v233 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %23
      ;
      uint64_t v234 = (uint64_t) v14;
      TASSIGN(v233, v234);
      pipe_barrier(PIPE_V);
      TADD(v233, v229, v231);
      // pto: %24
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v235 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %24
      ;
      uint64_t v236 = (uint64_t) v14;
      TASSIGN(v235, v236);
      pipe_barrier(PIPE_V);
      RoundMode v237 = RoundMode::CAST_RINT;
      SaturationMode v238 = SaturationMode::ON;
      TCVT(v235, v233, v237, v238);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      v235.SetValidShape(v20, v21);
      // pto: %26
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v239 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %26
      ;
      uint64_t v240 = (uint64_t) v15;
      TASSIGN(v239, v240);
      TMULS(v239, v153, v88);
      // pto: %27
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v241 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %27
      ;
      uint64_t v242 = (uint64_t) v10;
      TASSIGN(v241, v242);
      TMULS(v241, v157, v89);
      // pto: %28
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v243 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %28
      ;
      uint64_t v244 = (uint64_t) v15;
      TASSIGN(v243, v244);
      pipe_barrier(PIPE_V);
      TADD(v243, v239, v241);
      // pto: %29
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v245 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %29
      ;
      uint64_t v246 = (uint64_t) v10;
      TASSIGN(v245, v246);
      pipe_barrier(PIPE_V);
      TMULS(v245, v161, v90);
      // pto: %30
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v247 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %30
      ;
      uint64_t v248 = (uint64_t) v15;
      TASSIGN(v247, v248);
      pipe_barrier(PIPE_V);
      TADD(v247, v243, v245);
      // pto: %31
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v249 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %31
      ;
      uint64_t v250 = (uint64_t) v10;
      TASSIGN(v249, v250);
      pipe_barrier(PIPE_V);
      TMULS(v249, v165, v91);
      // pto: %32
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v251 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %32
      ;
      uint64_t v252 = (uint64_t) v15;
      TASSIGN(v251, v252);
      pipe_barrier(PIPE_V);
      TADD(v251, v247, v249);
      // pto: %33
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v253 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v104, v21);
      // pto: %33
      ;
      uint64_t v254 = (uint64_t) v10;
      TASSIGN(v253, v254);
      pipe_barrier(PIPE_V);
      TMULS(v253, v169, v92);
      // pto: %34
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v255 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %34
      ;
      uint64_t v256 = (uint64_t) v15;
      TASSIGN(v255, v256);
      pipe_barrier(PIPE_V);
      TADD(v255, v251, v253);
      // pto: %35
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v257 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %35
      ;
      uint64_t v258 = (uint64_t) v15;
      TASSIGN(v257, v258);
      pipe_barrier(PIPE_V);
      RoundMode v259 = RoundMode::CAST_RINT;
      SaturationMode v260 = SaturationMode::ON;
      TCVT(v257, v255, v259, v260);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      v257.SetValidShape(v20, v21);
      // pto: %y_flat__iter_v1_pview
      ;
      __gm__ bfloat16_t* v261 = PTOAS__GLOBAL_TENSOR_DATA(v49);
      // pto: %y_flat__iter_v1_pview
      ;
      const int64_t v262 = 0;
      // pto: %y_flat__iter_v1_pview
      ;
      const int64_t v263 = 16384;
      // pto: %y_flat__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, 1, 4096> v264 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %y_flat__iter_v1_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v265 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %y_flat__iter_v1_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v266 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v261 + (v262 + v95 * v263), v264, v265);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v266, v191);
      // pto: %y_flat__tile_pview
      ;
      __gm__ bfloat16_t* v267 = PTOAS__GLOBAL_TENSOR_DATA(v49);
      // pto: %y_flat__tile_pview
      ;
      const int64_t v268 = 4096;
      // pto: %y_flat__tile_pview
      ;
      const int64_t v269 = 16384;
      // pto: %y_flat__tile_pview
      ;
      pto::Shape<1, 1, 1, 1, 4096> v270 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %y_flat__tile_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v271 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %y_flat__tile_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v272 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v267 + (v268 + v95 * v269), v270, v271);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      TSTORE(v272, v213);
      // pto: %298
      ;
      __gm__ bfloat16_t* v273 = PTOAS__GLOBAL_TENSOR_DATA(v49);
      // pto: %298
      ;
      const int64_t v274 = 8192;
      // pto: %298
      ;
      const int64_t v275 = 16384;
      // pto: %298
      ;
      pto::Shape<1, 1, 1, 1, 4096> v276 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %298
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v277 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %298
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v278 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v273 + (v274 + v95 * v275), v276, v277);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      TSTORE(v278, v235);
      // pto: %301
      ;
      __gm__ bfloat16_t* v279 = PTOAS__GLOBAL_TENSOR_DATA(v49);
      // pto: %301
      ;
      const int64_t v280 = 12288;
      // pto: %301
      ;
      const int64_t v281 = 16384;
      // pto: %301
      ;
      pto::Shape<1, 1, 1, 1, 4096> v282 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %301
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v283 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %301
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v284 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v279 + (v280 + v95 * v281), v282, v283);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      TSTORE(v284, v257);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    // pto: %302
    ;
    int64_t v285 = (int64_t) ((uint64_t) v70 + (uint64_t) v20);
    // pto: %303
    ;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    if (v285 < v7) {
      // pto: %306
      ;
      int64_t v286 = (int64_t) ((uint64_t) v285 * (uint64_t) v22);
      // pto: %304
      ;
      float v287 = (v4)[v286];
      // pto: %310
      ;
      int64_t v288 = (int64_t) ((uint64_t) v285 * (uint64_t) v23);
      // pto: %308
      ;
      float v289 = (v5)[v288];
      // pto: %315, %312
      ;
      float v290 = (v5)[(int64_t) ((uint64_t) v288 + (uint64_t) v22)];
      // pto: %319, %316
      ;
      float v291 = (v5)[(int64_t) ((uint64_t) v288 + (uint64_t) v26)];
      // pto: %323, %320
      ;
      float v292 = (v5)[(int64_t) ((uint64_t) v288 + (uint64_t) v27)];
      // pto: %327, %324
      ;
      float v293 = (v4)[(int64_t) ((uint64_t) v286 + (uint64_t) v20)];
      // pto: %331, %328
      ;
      float v294 = (v5)[(int64_t) ((uint64_t) v288 + (uint64_t) v20)];
      // pto: %335, %332
      ;
      float v295 = (v5)[(int64_t) ((uint64_t) v288 + (uint64_t) v28)];
      // pto: %339, %336
      ;
      float v296 = (v5)[(int64_t) ((uint64_t) v288 + (uint64_t) v29)];
      // pto: %343, %340
      ;
      float v297 = (v5)[(int64_t) ((uint64_t) v288 + (uint64_t) v30)];
      // pto: %347, %344
      ;
      float v298 = (v4)[(int64_t) ((uint64_t) v286 + (uint64_t) v24)];
      // pto: %351, %348
      ;
      float v299 = (v5)[(int64_t) ((uint64_t) v288 + (uint64_t) v24)];
      // pto: %355, %352
      ;
      float v300 = (v5)[(int64_t) ((uint64_t) v288 + (uint64_t) v31)];
      // pto: %359, %356
      ;
      float v301 = (v5)[(int64_t) ((uint64_t) v288 + (uint64_t) v32)];
      // pto: %363, %360
      ;
      float v302 = (v5)[(int64_t) ((uint64_t) v288 + (uint64_t) v33)];
      // pto: %367, %364
      ;
      float v303 = (v4)[(int64_t) ((uint64_t) v286 + (uint64_t) v34)];
      // pto: %371, %368
      ;
      float v304 = (v5)[(int64_t) ((uint64_t) v288 + (uint64_t) v34)];
      // pto: %375, %372
      ;
      float v305 = (v5)[(int64_t) ((uint64_t) v288 + (uint64_t) v35)];
      // pto: %379, %376
      ;
      float v306 = (v5)[(int64_t) ((uint64_t) v288 + (uint64_t) v36)];
      // pto: %383, %380
      ;
      float v307 = (v5)[(int64_t) ((uint64_t) v288 + (uint64_t) v37)];
      // pto: %37
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v308 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %37
      ;
      uint64_t v309 = (uint64_t) v10;
      TASSIGN(v308, v309);
      // pto: %385
      ;
      int64_t v310 = v285 < v25 ? v25 : v285;
      // pto: %386
      ;
      __gm__ bfloat16_t* v311 = PTOAS__GLOBAL_TENSOR_DATA(v58);
      // pto: %386
      ;
      const int64_t v312 = 0;
      // pto: %386
      ;
      const int64_t v313 = 4096;
      // pto: %386
      ;
      pto::Shape<1, 1, 1, 1, 4096> v314 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %386
      ;
      pto::Stride<4096, 4096, 4096, 4096, 1> v315 = pto::Stride<4096, 4096, 4096, 4096, 1>();
      // pto: %386
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v316 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v311 + (v312 + v310 * v313), v314, v315);
      TLOAD(v308, v316);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      // pto: %387, %388
      ;
      int64_t v317 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v7 - (uint64_t) v70) + (uint64_t) v40);
      // pto: %389
      ;
      int64_t v318 = v317 < v25 ? v25 : v317;
      // pto: %390
      ;
      int64_t v319 = v318 < v20 ? v318 : v20;
      // pto: %38
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v320 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %38
      ;
      uint64_t v321 = (uint64_t) v11;
      TASSIGN(v320, v321);
      // pto: %397
      ;
      const int64_t v322 = 0;
      // pto: %397
      ;
      __gm__ bfloat16_t* v323 = PTOAS__GLOBAL_TENSOR_DATA(v67);
      // pto: %397
      ;
      const int64_t v324 = 1;
      // pto: %397
      ;
      const int64_t v325 = 1;
      // pto: %397
      ;
      const int64_t v326 = 1;
      // pto: %397
      ;
      int64_t v327 = v319 * v19;
      // pto: %397
      ;
      int64_t v328 = v326 * v327;
      // pto: %397
      ;
      pto::Shape<1, 1, 1, -1, 4096> v329 = pto::Shape<1, 1, 1, -1, 4096>(v324, v325, v326, v319, v21);
      // pto: %397
      ;
      pto::Stride<-1, -1, -1, -1, -1> v330 = pto::Stride<-1, -1, -1, -1, -1>(v325 * v328, v328, v327, v19, v20);
      // pto: %397
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v331 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v323 + (v322 + v310 * v19 + v25 * v20), v329, v330);
      TLOAD(v320, v331);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
      // pto: %39
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v332 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %39
      ;
      uint64_t v333 = (uint64_t) v12;
      TASSIGN(v332, v333);
      // pto: %408
      ;
      const int64_t v334 = 0;
      // pto: %408
      ;
      __gm__ bfloat16_t* v335 = PTOAS__GLOBAL_TENSOR_DATA(v67);
      // pto: %408
      ;
      const int64_t v336 = 1;
      // pto: %408
      ;
      const int64_t v337 = 1;
      // pto: %408
      ;
      const int64_t v338 = 1;
      // pto: %408
      ;
      int64_t v339 = v319 * v19;
      // pto: %408
      ;
      int64_t v340 = v338 * v339;
      // pto: %408
      ;
      pto::Shape<1, 1, 1, -1, 4096> v341 = pto::Shape<1, 1, 1, -1, 4096>(v336, v337, v338, v319, v21);
      // pto: %408
      ;
      pto::Stride<-1, -1, -1, -1, -1> v342 = pto::Stride<-1, -1, -1, -1, -1>(v337 * v340, v340, v339, v19, v20);
      // pto: %408
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v343 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v335 + (v334 + v310 * v19 + v21 * v20), v341, v342);
      TLOAD(v332, v343);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
      // pto: %40
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v344 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %40
      ;
      uint64_t v345 = (uint64_t) v13;
      TASSIGN(v344, v345);
      // pto: %419
      ;
      const int64_t v346 = 0;
      // pto: %419
      ;
      __gm__ bfloat16_t* v347 = PTOAS__GLOBAL_TENSOR_DATA(v67);
      // pto: %419
      ;
      const int64_t v348 = 1;
      // pto: %419
      ;
      const int64_t v349 = 1;
      // pto: %419
      ;
      const int64_t v350 = 1;
      // pto: %419
      ;
      int64_t v351 = v319 * v19;
      // pto: %419
      ;
      int64_t v352 = v350 * v351;
      // pto: %419
      ;
      pto::Shape<1, 1, 1, -1, 4096> v353 = pto::Shape<1, 1, 1, -1, 4096>(v348, v349, v350, v319, v21);
      // pto: %419
      ;
      pto::Stride<-1, -1, -1, -1, -1> v354 = pto::Stride<-1, -1, -1, -1, -1>(v349 * v352, v352, v351, v19, v20);
      // pto: %419
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v355 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v347 + (v346 + v310 * v19 + v38 * v20), v353, v354);
      TLOAD(v344, v355);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %41
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v356 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %41
      ;
      uint64_t v357 = (uint64_t) v14;
      TASSIGN(v356, v357);
      // pto: %430
      ;
      const int64_t v358 = 0;
      // pto: %430
      ;
      __gm__ bfloat16_t* v359 = PTOAS__GLOBAL_TENSOR_DATA(v67);
      // pto: %430
      ;
      const int64_t v360 = 1;
      // pto: %430
      ;
      const int64_t v361 = 1;
      // pto: %430
      ;
      const int64_t v362 = 1;
      // pto: %430
      ;
      int64_t v363 = v319 * v19;
      // pto: %430
      ;
      int64_t v364 = v362 * v363;
      // pto: %430
      ;
      pto::Shape<1, 1, 1, -1, 4096> v365 = pto::Shape<1, 1, 1, -1, 4096>(v360, v361, v362, v319, v21);
      // pto: %430
      ;
      pto::Stride<-1, -1, -1, -1, -1> v366 = pto::Stride<-1, -1, -1, -1, -1>(v361 * v364, v364, v363, v19, v20);
      // pto: %430
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v367 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v359 + (v358 + v310 * v19 + v39 * v20), v365, v366);
      TLOAD(v356, v367);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %42
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v368 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %42
      ;
      uint64_t v369 = (uint64_t) v15;
      TASSIGN(v368, v369);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      RoundMode v370 = RoundMode::CAST_ROUND;
      SaturationMode v371 = SaturationMode::ON;
      TCVT(v368, v308, v370, v371);
      // pto: %43
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v372 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %43
      ;
      uint64_t v373 = (uint64_t) v10;
      TASSIGN(v372, v373);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
      RoundMode v374 = RoundMode::CAST_ROUND;
      SaturationMode v375 = SaturationMode::ON;
      TCVT(v372, v320, v374, v375);
      // pto: %44
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v376 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %44
      ;
      uint64_t v377 = (uint64_t) v11;
      TASSIGN(v376, v377);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
      RoundMode v378 = RoundMode::CAST_ROUND;
      SaturationMode v379 = SaturationMode::ON;
      TCVT(v376, v332, v378, v379);
      // pto: %45
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v380 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %45
      ;
      uint64_t v381 = (uint64_t) v12;
      TASSIGN(v380, v381);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      RoundMode v382 = RoundMode::CAST_ROUND;
      SaturationMode v383 = SaturationMode::ON;
      TCVT(v380, v344, v382, v383);
      // pto: %46
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v384 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %46
      ;
      uint64_t v385 = (uint64_t) v13;
      TASSIGN(v384, v385);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      RoundMode v386 = RoundMode::CAST_ROUND;
      SaturationMode v387 = SaturationMode::ON;
      TCVT(v384, v356, v386, v387);
      // pto: %47
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v388 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %47
      ;
      uint64_t v389 = (uint64_t) v14;
      TASSIGN(v388, v389);
      pipe_barrier(PIPE_V);
      TMULS(v388, v368, v287);
      // pto: %48
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v390 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %48
      ;
      uint64_t v391 = (uint64_t) v16;
      TASSIGN(v390, v391);
      TMULS(v390, v372, v289);
      // pto: %49
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v392 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %49
      ;
      uint64_t v393 = (uint64_t) v14;
      TASSIGN(v392, v393);
      pipe_barrier(PIPE_V);
      TADD(v392, v388, v390);
      // pto: %50
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v394 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %50
      ;
      uint64_t v395 = (uint64_t) v16;
      TASSIGN(v394, v395);
      pipe_barrier(PIPE_V);
      TMULS(v394, v376, v290);
      // pto: %51
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v396 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %51
      ;
      uint64_t v397 = (uint64_t) v14;
      TASSIGN(v396, v397);
      pipe_barrier(PIPE_V);
      TADD(v396, v392, v394);
      // pto: %52
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v398 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %52
      ;
      uint64_t v399 = (uint64_t) v16;
      TASSIGN(v398, v399);
      pipe_barrier(PIPE_V);
      TMULS(v398, v380, v291);
      // pto: %53
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v400 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %53
      ;
      uint64_t v401 = (uint64_t) v14;
      TASSIGN(v400, v401);
      pipe_barrier(PIPE_V);
      TADD(v400, v396, v398);
      // pto: %54
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v402 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %54
      ;
      uint64_t v403 = (uint64_t) v16;
      TASSIGN(v402, v403);
      pipe_barrier(PIPE_V);
      TMULS(v402, v384, v292);
      // pto: %55
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v404 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %55
      ;
      uint64_t v405 = (uint64_t) v14;
      TASSIGN(v404, v405);
      pipe_barrier(PIPE_V);
      TADD(v404, v400, v402);
      // pto: %56
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v406 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %56
      ;
      uint64_t v407 = (uint64_t) v17;
      TASSIGN(v406, v407);
      pipe_barrier(PIPE_V);
      RoundMode v408 = RoundMode::CAST_RINT;
      SaturationMode v409 = SaturationMode::ON;
      TCVT(v406, v404, v408, v409);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
      v406.SetValidShape(v20, v21);
      // pto: %58
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v410 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %58
      ;
      uint64_t v411 = (uint64_t) v14;
      TASSIGN(v410, v411);
      pipe_barrier(PIPE_V);
      TMULS(v410, v368, v293);
      // pto: %59
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v412 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %59
      ;
      uint64_t v413 = (uint64_t) v16;
      TASSIGN(v412, v413);
      TMULS(v412, v372, v294);
      // pto: %60
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v414 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %60
      ;
      uint64_t v415 = (uint64_t) v14;
      TASSIGN(v414, v415);
      pipe_barrier(PIPE_V);
      TADD(v414, v410, v412);
      // pto: %61
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v416 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %61
      ;
      uint64_t v417 = (uint64_t) v16;
      TASSIGN(v416, v417);
      pipe_barrier(PIPE_V);
      TMULS(v416, v376, v295);
      // pto: %62
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v418 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %62
      ;
      uint64_t v419 = (uint64_t) v14;
      TASSIGN(v418, v419);
      pipe_barrier(PIPE_V);
      TADD(v418, v414, v416);
      // pto: %63
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v420 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %63
      ;
      uint64_t v421 = (uint64_t) v16;
      TASSIGN(v420, v421);
      pipe_barrier(PIPE_V);
      TMULS(v420, v380, v296);
      // pto: %64
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v422 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %64
      ;
      uint64_t v423 = (uint64_t) v14;
      TASSIGN(v422, v423);
      pipe_barrier(PIPE_V);
      TADD(v422, v418, v420);
      // pto: %65
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v424 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %65
      ;
      uint64_t v425 = (uint64_t) v16;
      TASSIGN(v424, v425);
      pipe_barrier(PIPE_V);
      TMULS(v424, v384, v297);
      // pto: %66
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v426 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %66
      ;
      uint64_t v427 = (uint64_t) v14;
      TASSIGN(v426, v427);
      pipe_barrier(PIPE_V);
      TADD(v426, v422, v424);
      // pto: %67
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v428 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %67
      ;
      uint64_t v429 = (uint64_t) v18;
      TASSIGN(v428, v429);
      pipe_barrier(PIPE_V);
      RoundMode v430 = RoundMode::CAST_RINT;
      SaturationMode v431 = SaturationMode::ON;
      TCVT(v428, v426, v430, v431);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
      v428.SetValidShape(v20, v21);
      // pto: %69
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v432 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %69
      ;
      uint64_t v433 = (uint64_t) v14;
      TASSIGN(v432, v433);
      pipe_barrier(PIPE_V);
      TMULS(v432, v368, v298);
      // pto: %70
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v434 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %70
      ;
      uint64_t v435 = (uint64_t) v16;
      TASSIGN(v434, v435);
      TMULS(v434, v372, v299);
      // pto: %71
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v436 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %71
      ;
      uint64_t v437 = (uint64_t) v14;
      TASSIGN(v436, v437);
      pipe_barrier(PIPE_V);
      TADD(v436, v432, v434);
      // pto: %72
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v438 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %72
      ;
      uint64_t v439 = (uint64_t) v16;
      TASSIGN(v438, v439);
      pipe_barrier(PIPE_V);
      TMULS(v438, v376, v300);
      // pto: %73
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v440 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %73
      ;
      uint64_t v441 = (uint64_t) v14;
      TASSIGN(v440, v441);
      pipe_barrier(PIPE_V);
      TADD(v440, v436, v438);
      // pto: %74
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v442 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %74
      ;
      uint64_t v443 = (uint64_t) v16;
      TASSIGN(v442, v443);
      pipe_barrier(PIPE_V);
      TMULS(v442, v380, v301);
      // pto: %75
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v444 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %75
      ;
      uint64_t v445 = (uint64_t) v14;
      TASSIGN(v444, v445);
      pipe_barrier(PIPE_V);
      TADD(v444, v440, v442);
      // pto: %76
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v446 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %76
      ;
      uint64_t v447 = (uint64_t) v16;
      TASSIGN(v446, v447);
      pipe_barrier(PIPE_V);
      TMULS(v446, v384, v302);
      // pto: %77
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v448 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %77
      ;
      uint64_t v449 = (uint64_t) v14;
      TASSIGN(v448, v449);
      pipe_barrier(PIPE_V);
      TADD(v448, v444, v446);
      // pto: %78
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v450 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %78
      ;
      uint64_t v451 = (uint64_t) v14;
      TASSIGN(v450, v451);
      pipe_barrier(PIPE_V);
      RoundMode v452 = RoundMode::CAST_RINT;
      SaturationMode v453 = SaturationMode::ON;
      TCVT(v450, v448, v452, v453);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
      v450.SetValidShape(v20, v21);
      // pto: %80
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v454 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %80
      ;
      uint64_t v455 = (uint64_t) v15;
      TASSIGN(v454, v455);
      TMULS(v454, v368, v303);
      // pto: %81
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v456 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %81
      ;
      uint64_t v457 = (uint64_t) v10;
      TASSIGN(v456, v457);
      TMULS(v456, v372, v304);
      // pto: %82
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v458 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %82
      ;
      uint64_t v459 = (uint64_t) v15;
      TASSIGN(v458, v459);
      pipe_barrier(PIPE_V);
      TADD(v458, v454, v456);
      // pto: %83
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v460 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %83
      ;
      uint64_t v461 = (uint64_t) v10;
      TASSIGN(v460, v461);
      pipe_barrier(PIPE_V);
      TMULS(v460, v376, v305);
      // pto: %84
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v462 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %84
      ;
      uint64_t v463 = (uint64_t) v15;
      TASSIGN(v462, v463);
      pipe_barrier(PIPE_V);
      TADD(v462, v458, v460);
      // pto: %85
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v464 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %85
      ;
      uint64_t v465 = (uint64_t) v10;
      TASSIGN(v464, v465);
      pipe_barrier(PIPE_V);
      TMULS(v464, v380, v306);
      // pto: %86
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v466 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %86
      ;
      uint64_t v467 = (uint64_t) v15;
      TASSIGN(v466, v467);
      pipe_barrier(PIPE_V);
      TADD(v466, v462, v464);
      // pto: %87
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v468 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v319, v21);
      // pto: %87
      ;
      uint64_t v469 = (uint64_t) v10;
      TASSIGN(v468, v469);
      pipe_barrier(PIPE_V);
      TMULS(v468, v384, v307);
      // pto: %88
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v470 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %88
      ;
      uint64_t v471 = (uint64_t) v15;
      TASSIGN(v470, v471);
      pipe_barrier(PIPE_V);
      TADD(v470, v466, v468);
      // pto: %89
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v472 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %89
      ;
      uint64_t v473 = (uint64_t) v15;
      TASSIGN(v472, v473);
      pipe_barrier(PIPE_V);
      RoundMode v474 = RoundMode::CAST_RINT;
      SaturationMode v475 = SaturationMode::ON;
      TCVT(v472, v470, v474, v475);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
      v472.SetValidShape(v20, v21);
      // pto: %y_flat__phi_v7_pview
      ;
      __gm__ bfloat16_t* v476 = PTOAS__GLOBAL_TENSOR_DATA(v49);
      // pto: %y_flat__phi_v7_pview
      ;
      const int64_t v477 = 0;
      // pto: %y_flat__phi_v7_pview
      ;
      const int64_t v478 = 16384;
      // pto: %y_flat__phi_v7_pview
      ;
      pto::Shape<1, 1, 1, 1, 4096> v479 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %y_flat__phi_v7_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v480 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %y_flat__phi_v7_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v481 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v476 + (v477 + v310 * v478), v479, v480);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
      TSTORE(v481, v406);
      // pto: %517
      ;
      __gm__ bfloat16_t* v482 = PTOAS__GLOBAL_TENSOR_DATA(v49);
      // pto: %517
      ;
      const int64_t v483 = 4096;
      // pto: %517
      ;
      const int64_t v484 = 16384;
      // pto: %517
      ;
      pto::Shape<1, 1, 1, 1, 4096> v485 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %517
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v486 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %517
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v487 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v482 + (v483 + v310 * v484), v485, v486);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
      TSTORE(v487, v428);
      // pto: %521
      ;
      __gm__ bfloat16_t* v488 = PTOAS__GLOBAL_TENSOR_DATA(v49);
      // pto: %521
      ;
      const int64_t v489 = 8192;
      // pto: %521
      ;
      const int64_t v490 = 16384;
      // pto: %521
      ;
      pto::Shape<1, 1, 1, 1, 4096> v491 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %521
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v492 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %521
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v493 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v488 + (v489 + v310 * v490), v491, v492);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
      TSTORE(v493, v450);
      // pto: %525
      ;
      __gm__ bfloat16_t* v494 = PTOAS__GLOBAL_TENSOR_DATA(v49);
      // pto: %525
      ;
      const int64_t v495 = 12288;
      // pto: %525
      ;
      const int64_t v496 = 16384;
      // pto: %525
      ;
      pto::Shape<1, 1, 1, 1, 4096> v497 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %525
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v498 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %525
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v499 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v494 + (v495 + v310 * v496), v497, v498);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
      TSTORE(v499, v472);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  // pto: %526, %527, %528
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  if ((int64_t) ((uint64_t) ((int64_t) (uint64_t) v68 - (uint64_t) v69) + (uint64_t) v22) == v20) {
    // pto: %529
    ;
    if (v69 < v7) {
      // pto: %91
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v500 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %91
      ;
      uint64_t v501 = (uint64_t) v10;
      TASSIGN(v500, v501);
      // pto: %530
      ;
      int64_t v502 = v69 < v25 ? v25 : v69;
      // pto: %531
      ;
      __gm__ bfloat16_t* v503 = PTOAS__GLOBAL_TENSOR_DATA(v58);
      // pto: %531
      ;
      const int64_t v504 = 0;
      // pto: %531
      ;
      const int64_t v505 = 4096;
      // pto: %531
      ;
      pto::Shape<1, 1, 1, 1, 4096> v506 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %531
      ;
      pto::Stride<4096, 4096, 4096, 4096, 1> v507 = pto::Stride<4096, 4096, 4096, 4096, 1>();
      // pto: %531
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v508 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v503 + (v504 + v502 * v505), v506, v507);
      TLOAD(v500, v508);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %92
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v509 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %92
      ;
      uint64_t v510 = (uint64_t) v15;
      TASSIGN(v509, v510);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      RoundMode v511 = RoundMode::CAST_ROUND;
      SaturationMode v512 = SaturationMode::ON;
      TCVT(v509, v500, v511, v512);
      // pto: %532
      ;
      int64_t v513 = (int64_t) ((uint64_t) v7 - (uint64_t) v69);
      // pto: %533
      ;
      int64_t v514 = v513 < v25 ? v25 : v513;
      // pto: %534
      ;
      int64_t v515 = v514 < v20 ? v514 : v20;
      // pto: %93
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v516 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %93
      ;
      uint64_t v517 = (uint64_t) v11;
      TASSIGN(v516, v517);
      // pto: %539
      ;
      const int64_t v518 = 0;
      // pto: %539
      ;
      __gm__ bfloat16_t* v519 = PTOAS__GLOBAL_TENSOR_DATA(v67);
      // pto: %539
      ;
      const int64_t v520 = 1;
      // pto: %539
      ;
      const int64_t v521 = 1;
      // pto: %539
      ;
      const int64_t v522 = 1;
      // pto: %539
      ;
      int64_t v523 = v515 * v19;
      // pto: %539
      ;
      int64_t v524 = v522 * v523;
      // pto: %539
      ;
      pto::Shape<1, 1, 1, -1, 4096> v525 = pto::Shape<1, 1, 1, -1, 4096>(v520, v521, v522, v515, v21);
      // pto: %539
      ;
      pto::Stride<-1, -1, -1, -1, -1> v526 = pto::Stride<-1, -1, -1, -1, -1>(v521 * v524, v524, v523, v19, v20);
      // pto: %539
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v527 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v519 + (v518 + v502 * v19 + v25 * v20), v525, v526);
      TLOAD(v516, v527);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %94
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v528 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %94
      ;
      uint64_t v529 = (uint64_t) v10;
      TASSIGN(v528, v529);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      pipe_barrier(PIPE_V);
      RoundMode v530 = RoundMode::CAST_ROUND;
      SaturationMode v531 = SaturationMode::ON;
      TCVT(v528, v516, v530, v531);
      // pto: %95
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v532 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %95
      ;
      uint64_t v533 = (uint64_t) v12;
      TASSIGN(v532, v533);
      // pto: %550
      ;
      const int64_t v534 = 0;
      // pto: %550
      ;
      __gm__ bfloat16_t* v535 = PTOAS__GLOBAL_TENSOR_DATA(v67);
      // pto: %550
      ;
      const int64_t v536 = 1;
      // pto: %550
      ;
      const int64_t v537 = 1;
      // pto: %550
      ;
      const int64_t v538 = 1;
      // pto: %550
      ;
      int64_t v539 = v515 * v19;
      // pto: %550
      ;
      int64_t v540 = v538 * v539;
      // pto: %550
      ;
      pto::Shape<1, 1, 1, -1, 4096> v541 = pto::Shape<1, 1, 1, -1, 4096>(v536, v537, v538, v515, v21);
      // pto: %550
      ;
      pto::Stride<-1, -1, -1, -1, -1> v542 = pto::Stride<-1, -1, -1, -1, -1>(v537 * v540, v540, v539, v19, v20);
      // pto: %550
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v543 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v535 + (v534 + v502 * v19 + v21 * v20), v541, v542);
      TLOAD(v532, v543);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %96
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v544 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %96
      ;
      uint64_t v545 = (uint64_t) v11;
      TASSIGN(v544, v545);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      pipe_barrier(PIPE_V);
      RoundMode v546 = RoundMode::CAST_ROUND;
      SaturationMode v547 = SaturationMode::ON;
      TCVT(v544, v532, v546, v547);
      // pto: %97
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v548 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %97
      ;
      uint64_t v549 = (uint64_t) v13;
      TASSIGN(v548, v549);
      // pto: %561
      ;
      const int64_t v550 = 0;
      // pto: %561
      ;
      __gm__ bfloat16_t* v551 = PTOAS__GLOBAL_TENSOR_DATA(v67);
      // pto: %561
      ;
      const int64_t v552 = 1;
      // pto: %561
      ;
      const int64_t v553 = 1;
      // pto: %561
      ;
      const int64_t v554 = 1;
      // pto: %561
      ;
      int64_t v555 = v515 * v19;
      // pto: %561
      ;
      int64_t v556 = v554 * v555;
      // pto: %561
      ;
      pto::Shape<1, 1, 1, -1, 4096> v557 = pto::Shape<1, 1, 1, -1, 4096>(v552, v553, v554, v515, v21);
      // pto: %561
      ;
      pto::Stride<-1, -1, -1, -1, -1> v558 = pto::Stride<-1, -1, -1, -1, -1>(v553 * v556, v556, v555, v19, v20);
      // pto: %561
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v559 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v551 + (v550 + v502 * v19 + v38 * v20), v557, v558);
      TLOAD(v548, v559);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %98
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v560 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %98
      ;
      uint64_t v561 = (uint64_t) v12;
      TASSIGN(v560, v561);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      pipe_barrier(PIPE_V);
      RoundMode v562 = RoundMode::CAST_ROUND;
      SaturationMode v563 = SaturationMode::ON;
      TCVT(v560, v548, v562, v563);
      // pto: %99
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v564 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %99
      ;
      uint64_t v565 = (uint64_t) v14;
      TASSIGN(v564, v565);
      // pto: %572
      ;
      const int64_t v566 = 0;
      // pto: %572
      ;
      __gm__ bfloat16_t* v567 = PTOAS__GLOBAL_TENSOR_DATA(v67);
      // pto: %572
      ;
      const int64_t v568 = 1;
      // pto: %572
      ;
      const int64_t v569 = 1;
      // pto: %572
      ;
      const int64_t v570 = 1;
      // pto: %572
      ;
      int64_t v571 = v515 * v19;
      // pto: %572
      ;
      int64_t v572 = v570 * v571;
      // pto: %572
      ;
      pto::Shape<1, 1, 1, -1, 4096> v573 = pto::Shape<1, 1, 1, -1, 4096>(v568, v569, v570, v515, v21);
      // pto: %572
      ;
      pto::Stride<-1, -1, -1, -1, -1> v574 = pto::Stride<-1, -1, -1, -1, -1>(v569 * v572, v572, v571, v19, v20);
      // pto: %572
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v575 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v567 + (v566 + v502 * v19 + v39 * v20), v573, v574);
      TLOAD(v564, v575);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %100
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v576 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %100
      ;
      uint64_t v577 = (uint64_t) v13;
      TASSIGN(v576, v577);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      pipe_barrier(PIPE_V);
      RoundMode v578 = RoundMode::CAST_ROUND;
      SaturationMode v579 = SaturationMode::ON;
      TCVT(v576, v564, v578, v579);
      // pto: %577
      ;
      int64_t v580 = (int64_t) ((uint64_t) v69 * (uint64_t) v22);
      // pto: %576
      ;
      float v581 = (v4)[v580];
      // pto: %101
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v582 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %101
      ;
      uint64_t v583 = (uint64_t) v14;
      TASSIGN(v582, v583);
      pipe_barrier(PIPE_V);
      TMULS(v582, v509, v581);
      // pto: %580
      ;
      int64_t v584 = (int64_t) ((uint64_t) v69 * (uint64_t) v23);
      // pto: %579
      ;
      float v585 = (v5)[v584];
      // pto: %102
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v586 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %102
      ;
      uint64_t v587 = (uint64_t) v16;
      TASSIGN(v586, v587);
      TMULS(v586, v528, v585);
      // pto: %103
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v588 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %103
      ;
      uint64_t v589 = (uint64_t) v14;
      TASSIGN(v588, v589);
      pipe_barrier(PIPE_V);
      TADD(v588, v582, v586);
      // pto: %587, %585
      ;
      float v590 = (v5)[(int64_t) ((uint64_t) v584 + (uint64_t) v22)];
      // pto: %104
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v591 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %104
      ;
      uint64_t v592 = (uint64_t) v16;
      TASSIGN(v591, v592);
      pipe_barrier(PIPE_V);
      TMULS(v591, v544, v590);
      // pto: %105
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v593 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %105
      ;
      uint64_t v594 = (uint64_t) v14;
      TASSIGN(v593, v594);
      pipe_barrier(PIPE_V);
      TADD(v593, v588, v591);
      // pto: %593, %591
      ;
      float v595 = (v5)[(int64_t) ((uint64_t) v584 + (uint64_t) v26)];
      // pto: %106
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v596 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %106
      ;
      uint64_t v597 = (uint64_t) v16;
      TASSIGN(v596, v597);
      pipe_barrier(PIPE_V);
      TMULS(v596, v560, v595);
      // pto: %107
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v598 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %107
      ;
      uint64_t v599 = (uint64_t) v14;
      TASSIGN(v598, v599);
      pipe_barrier(PIPE_V);
      TADD(v598, v593, v596);
      // pto: %599, %597
      ;
      float v600 = (v5)[(int64_t) ((uint64_t) v584 + (uint64_t) v27)];
      // pto: %108
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v601 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %108
      ;
      uint64_t v602 = (uint64_t) v16;
      TASSIGN(v601, v602);
      pipe_barrier(PIPE_V);
      TMULS(v601, v576, v600);
      // pto: %109
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v603 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %109
      ;
      uint64_t v604 = (uint64_t) v14;
      TASSIGN(v603, v604);
      pipe_barrier(PIPE_V);
      TADD(v603, v598, v601);
      // pto: %110
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v605 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %110
      ;
      uint64_t v606 = (uint64_t) v14;
      TASSIGN(v605, v606);
      pipe_barrier(PIPE_V);
      RoundMode v607 = RoundMode::CAST_RINT;
      SaturationMode v608 = SaturationMode::ON;
      TCVT(v605, v603, v607, v608);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      v605.SetValidShape(v20, v21);
      // pto: %y_flat__rv_v2_main_pview
      ;
      __gm__ bfloat16_t* v609 = PTOAS__GLOBAL_TENSOR_DATA(v49);
      // pto: %y_flat__rv_v2_main_pview
      ;
      const int64_t v610 = 0;
      // pto: %y_flat__rv_v2_main_pview
      ;
      const int64_t v611 = 16384;
      // pto: %y_flat__rv_v2_main_pview
      ;
      pto::Shape<1, 1, 1, 1, 4096> v612 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %y_flat__rv_v2_main_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v613 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %y_flat__rv_v2_main_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v614 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v609 + (v610 + v502 * v611), v612, v613);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v614, v605);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
      // pto: %607, %605
      ;
      float v615 = (v4)[(int64_t) ((uint64_t) v580 + (uint64_t) v20)];
      // pto: %112
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v616 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %112
      ;
      uint64_t v617 = (uint64_t) v14;
      TASSIGN(v616, v617);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
      TMULS(v616, v509, v615);
      // pto: %610, %608
      ;
      float v618 = (v5)[(int64_t) ((uint64_t) v584 + (uint64_t) v20)];
      // pto: %113
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v619 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %113
      ;
      uint64_t v620 = (uint64_t) v16;
      TASSIGN(v619, v620);
      TMULS(v619, v528, v618);
      // pto: %114
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v621 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %114
      ;
      uint64_t v622 = (uint64_t) v14;
      TASSIGN(v621, v622);
      pipe_barrier(PIPE_V);
      TADD(v621, v616, v619);
      // pto: %616, %614
      ;
      float v623 = (v5)[(int64_t) ((uint64_t) v584 + (uint64_t) v28)];
      // pto: %115
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v624 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %115
      ;
      uint64_t v625 = (uint64_t) v16;
      TASSIGN(v624, v625);
      pipe_barrier(PIPE_V);
      TMULS(v624, v544, v623);
      // pto: %116
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v626 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %116
      ;
      uint64_t v627 = (uint64_t) v14;
      TASSIGN(v626, v627);
      pipe_barrier(PIPE_V);
      TADD(v626, v621, v624);
      // pto: %622, %620
      ;
      float v628 = (v5)[(int64_t) ((uint64_t) v584 + (uint64_t) v29)];
      // pto: %117
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v629 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %117
      ;
      uint64_t v630 = (uint64_t) v16;
      TASSIGN(v629, v630);
      pipe_barrier(PIPE_V);
      TMULS(v629, v560, v628);
      // pto: %118
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v631 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %118
      ;
      uint64_t v632 = (uint64_t) v14;
      TASSIGN(v631, v632);
      pipe_barrier(PIPE_V);
      TADD(v631, v626, v629);
      // pto: %628, %626
      ;
      float v633 = (v5)[(int64_t) ((uint64_t) v584 + (uint64_t) v30)];
      // pto: %119
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v634 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %119
      ;
      uint64_t v635 = (uint64_t) v16;
      TASSIGN(v634, v635);
      pipe_barrier(PIPE_V);
      TMULS(v634, v576, v633);
      // pto: %120
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v636 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %120
      ;
      uint64_t v637 = (uint64_t) v14;
      TASSIGN(v636, v637);
      pipe_barrier(PIPE_V);
      TADD(v636, v631, v634);
      // pto: %121
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v638 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %121
      ;
      uint64_t v639 = (uint64_t) v14;
      TASSIGN(v638, v639);
      pipe_barrier(PIPE_V);
      RoundMode v640 = RoundMode::CAST_RINT;
      SaturationMode v641 = SaturationMode::ON;
      TCVT(v638, v636, v640, v641);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      v638.SetValidShape(v20, v21);
      // pto: %634
      ;
      __gm__ bfloat16_t* v642 = PTOAS__GLOBAL_TENSOR_DATA(v49);
      // pto: %634
      ;
      const int64_t v643 = 4096;
      // pto: %634
      ;
      const int64_t v644 = 16384;
      // pto: %634
      ;
      pto::Shape<1, 1, 1, 1, 4096> v645 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %634
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v646 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %634
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v647 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v642 + (v643 + v502 * v644), v645, v646);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v647, v638);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      // pto: %637, %635
      ;
      float v648 = (v4)[(int64_t) ((uint64_t) v580 + (uint64_t) v24)];
      // pto: %123
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v649 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %123
      ;
      uint64_t v650 = (uint64_t) v14;
      TASSIGN(v649, v650);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      TMULS(v649, v509, v648);
      // pto: %640, %638
      ;
      float v651 = (v5)[(int64_t) ((uint64_t) v584 + (uint64_t) v24)];
      // pto: %124
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v652 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %124
      ;
      uint64_t v653 = (uint64_t) v16;
      TASSIGN(v652, v653);
      TMULS(v652, v528, v651);
      // pto: %125
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v654 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %125
      ;
      uint64_t v655 = (uint64_t) v14;
      TASSIGN(v654, v655);
      pipe_barrier(PIPE_V);
      TADD(v654, v649, v652);
      // pto: %646, %644
      ;
      float v656 = (v5)[(int64_t) ((uint64_t) v584 + (uint64_t) v31)];
      // pto: %126
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v657 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %126
      ;
      uint64_t v658 = (uint64_t) v16;
      TASSIGN(v657, v658);
      pipe_barrier(PIPE_V);
      TMULS(v657, v544, v656);
      // pto: %127
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v659 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %127
      ;
      uint64_t v660 = (uint64_t) v14;
      TASSIGN(v659, v660);
      pipe_barrier(PIPE_V);
      TADD(v659, v654, v657);
      // pto: %652, %650
      ;
      float v661 = (v5)[(int64_t) ((uint64_t) v584 + (uint64_t) v32)];
      // pto: %128
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v662 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %128
      ;
      uint64_t v663 = (uint64_t) v16;
      TASSIGN(v662, v663);
      pipe_barrier(PIPE_V);
      TMULS(v662, v560, v661);
      // pto: %129
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v664 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %129
      ;
      uint64_t v665 = (uint64_t) v14;
      TASSIGN(v664, v665);
      pipe_barrier(PIPE_V);
      TADD(v664, v659, v662);
      // pto: %658, %656
      ;
      float v666 = (v5)[(int64_t) ((uint64_t) v584 + (uint64_t) v33)];
      // pto: %130
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v667 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %130
      ;
      uint64_t v668 = (uint64_t) v16;
      TASSIGN(v667, v668);
      pipe_barrier(PIPE_V);
      TMULS(v667, v576, v666);
      // pto: %131
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v669 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %131
      ;
      uint64_t v670 = (uint64_t) v14;
      TASSIGN(v669, v670);
      pipe_barrier(PIPE_V);
      TADD(v669, v664, v667);
      // pto: %132
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v671 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %132
      ;
      uint64_t v672 = (uint64_t) v14;
      TASSIGN(v671, v672);
      pipe_barrier(PIPE_V);
      RoundMode v673 = RoundMode::CAST_RINT;
      SaturationMode v674 = SaturationMode::ON;
      TCVT(v671, v669, v673, v674);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      v671.SetValidShape(v20, v21);
      // pto: %664
      ;
      __gm__ bfloat16_t* v675 = PTOAS__GLOBAL_TENSOR_DATA(v49);
      // pto: %664
      ;
      const int64_t v676 = 8192;
      // pto: %664
      ;
      const int64_t v677 = 16384;
      // pto: %664
      ;
      pto::Shape<1, 1, 1, 1, 4096> v678 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %664
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v679 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %664
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v680 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v675 + (v676 + v502 * v677), v678, v679);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v680, v671);
      // pto: %667, %665
      ;
      float v681 = (v4)[(int64_t) ((uint64_t) v580 + (uint64_t) v34)];
      // pto: %134
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v682 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %134
      ;
      uint64_t v683 = (uint64_t) v15;
      TASSIGN(v682, v683);
      TMULS(v682, v509, v681);
      // pto: %670, %668
      ;
      float v684 = (v5)[(int64_t) ((uint64_t) v584 + (uint64_t) v34)];
      // pto: %135
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v685 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %135
      ;
      uint64_t v686 = (uint64_t) v10;
      TASSIGN(v685, v686);
      TMULS(v685, v528, v684);
      // pto: %136
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v687 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %136
      ;
      uint64_t v688 = (uint64_t) v15;
      TASSIGN(v687, v688);
      pipe_barrier(PIPE_V);
      TADD(v687, v682, v685);
      // pto: %676, %674
      ;
      float v689 = (v5)[(int64_t) ((uint64_t) v584 + (uint64_t) v35)];
      // pto: %137
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v690 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %137
      ;
      uint64_t v691 = (uint64_t) v10;
      TASSIGN(v690, v691);
      pipe_barrier(PIPE_V);
      TMULS(v690, v544, v689);
      // pto: %138
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v692 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %138
      ;
      uint64_t v693 = (uint64_t) v15;
      TASSIGN(v692, v693);
      pipe_barrier(PIPE_V);
      TADD(v692, v687, v690);
      // pto: %682, %680
      ;
      float v694 = (v5)[(int64_t) ((uint64_t) v584 + (uint64_t) v36)];
      // pto: %139
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v695 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %139
      ;
      uint64_t v696 = (uint64_t) v10;
      TASSIGN(v695, v696);
      pipe_barrier(PIPE_V);
      TMULS(v695, v560, v694);
      // pto: %140
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v697 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %140
      ;
      uint64_t v698 = (uint64_t) v15;
      TASSIGN(v697, v698);
      pipe_barrier(PIPE_V);
      TADD(v697, v692, v695);
      // pto: %688, %686
      ;
      float v699 = (v5)[(int64_t) ((uint64_t) v584 + (uint64_t) v37)];
      // pto: %141
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v700 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v515, v21);
      // pto: %141
      ;
      uint64_t v701 = (uint64_t) v10;
      TASSIGN(v700, v701);
      pipe_barrier(PIPE_V);
      TMULS(v700, v576, v699);
      // pto: %142
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v702 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %142
      ;
      uint64_t v703 = (uint64_t) v15;
      TASSIGN(v702, v703);
      pipe_barrier(PIPE_V);
      TADD(v702, v697, v700);
      // pto: %143
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v704 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v21);
      // pto: %143
      ;
      uint64_t v705 = (uint64_t) v15;
      TASSIGN(v704, v705);
      pipe_barrier(PIPE_V);
      RoundMode v706 = RoundMode::CAST_RINT;
      SaturationMode v707 = SaturationMode::ON;
      TCVT(v704, v702, v706, v707);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      v704.SetValidShape(v20, v21);
      // pto: %694
      ;
      __gm__ bfloat16_t* v708 = PTOAS__GLOBAL_TENSOR_DATA(v49);
      // pto: %694
      ;
      const int64_t v709 = 12288;
      // pto: %694
      ;
      const int64_t v710 = 16384;
      // pto: %694
      ;
      pto::Shape<1, 1, 1, 1, 4096> v711 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %694
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v712 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %694
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v713 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v708 + (v709 + v502 * v710), v711, v712);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v713, v704);
    };
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}