from pathlib import Path
from simpler.task_interface import ArgDirection as _D
_ROOT_DIR = Path(__file__).parent
KERNELS = [{'func_id': 0, 'name': 'hc_post', 'source': 'kernels/aiv/hc_post.cpp', 'core_type': 'aiv', 'signature': ['OUT', 'IN', 'IN', 'IN', 'IN']}]
ORCHESTRATION = {'source': 'orchestration/_hc_post.cpp', 'function_name': 'aicpu_orchestration_entry', 'signature': ['IN', 'IN', 'IN', 'IN', 'OUT']}
RUNTIME_CONFIG = {'runtime': 'tensormap_and_ringbuffer', 'aicpu_thread_num': 0}
for _entry in [*KERNELS, ORCHESTRATION]:
    _entry['source'] = str(_ROOT_DIR / _entry['source'])
    _entry['signature'] = [getattr(_D, s) for s in _entry['signature']]
    if 'extra_include_dirs' in _entry:
        _entry['extra_include_dirs'] = [
            str(_ROOT_DIR / p) for p in _entry['extra_include_dirs']]
