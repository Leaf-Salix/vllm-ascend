"""占卡任务前仅校验已冻结源码和脚本，不安装或修改环境。"""
import hashlib,json
from pathlib import Path
j=Path(__file__).resolve().parent
m=json.loads((j/'frozen-manifest.json').read_text())
for group,root in (('source',j/'source'),('helpers',j)):
    for rel,sha in m[group].items():
        assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==sha,(group,rel)
print('FROZEN_SOURCE_AND_HELPERS_OK',len(m['source']),len(m['helpers']),flush=True)
