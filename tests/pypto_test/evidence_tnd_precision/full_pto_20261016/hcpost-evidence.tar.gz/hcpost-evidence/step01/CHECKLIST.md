# 完整PTO TND精度恢复：2026-10-16

- 基准：5d5ab1c6c；生产数学cbc810c8；原tnd_precision包保持不变，SHA见baseline-files.json。
- 目标：HC-pre至HC-post完整PTO替换，真实query bounds/TND不退回BSH。nalinaly只参考替换范围，算术以实际Native为金标准。
- 不测128K；逐模块对拍，首差停后续配置，先定位再继续；每个NPU任务max-time780秒，间隔约5分钟查，不留任务结束对话。
- 当前第一步：HC-post。A3 hc_post_d_split.h：FP32 post*x，再按0/1/2/3单独Mul/Add，最后BF16 RINT；与现有未接入的PTO hc_post数学顺序相同，先复用并实测。
- 新包tnd_full_precision仅候选；未完成模块仍Native，不能称完整替换完成。

## 门禁

- [ ] 原包SHA不变、新variant不改默认。
- [ ] 无设备实际imports/toolchain校验、编译，生成代码Mul/Add/RINT顺序检查。
- [ ] 单卡HC-post同输入Native1/Native2/PTO，首差保存原值。
- [ ] graph raw replay和输入A/B/A含gate内容更新，输出毒化及输入/guard检查。
- [ ] 真实第4层权重、不等长B4/T11 FULL attention半层，Native/原基准/候选逐bit，禁止fallback。
- [ ] 结果记录、独立review、增量precommit、commit push。

后续顺序按已定位误差决定：HC-pre/Norm、WKV、Indexer权重、O-proj。每一步先做同输入模块检查，不提前批量提交后续大配置。
