"""HC-post单模块实际Native对拍；首差保存并退出，不涉及整模型结论。"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import torch
import torch_npu
import pypto.torch
from vllm_ascend.utils import enable_custom_op
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.hc_post import hc_post_test

p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--tokens',type=int,default=11);p.add_argument('--seed',type=int,default=17);a=p.parse_args()
a.out.mkdir(exist_ok=False,parents=True)
report={'pass':False,'complete':False,'module':'hc_post','scope':'synthetic module inputs, actual installed Native HcPost; no full-layer or model claim','tokens':a.tokens,'seed':a.seed,'checks':[],'task_device':os.environ['TASK_DEVICE']}
def save(): (a.out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
def exact(x,y):return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def check(label,actual,expected):
    x,y=actual.cpu(),expected.cpu()
    result={'label':label,'bit_equal':exact(x,y),'mismatches':int((x.view(torch.int16)!=y.view(torch.int16)).sum()),'max_abs':float((x.float()-y.float()).abs().max())}
    report['checks'].append(result);save()
    if not result['bit_equal']:
        torch.save({'actual':x,'expected':y,'inputs':[v.cpu() for v in values]},a.out/'first-difference.pt')
        raise RuntimeError('FIRST_BIT_DIFFERENCE '+label)

torch.npu.set_device(0);torch_npu.npu.set_deterministic_level(1);torch.use_deterministic_algorithms(True)
assert enable_custom_op()
torch.manual_seed(a.seed);torch.npu.manual_seed(a.seed)
pypto.torch.init(device=0,platform='a2a3',runtime='tensormap_and_ringbuffer')
op=pypto.torch.register(hc_post_test,'dsv4_csa_tnd_full_precision::hc_post')
t=a.tokens;d=4096
values=[torch.randn((t,d),device='npu',dtype=torch.bfloat16),torch.randn((t,4,d),device='npu',dtype=torch.bfloat16),torch.rand((t,4),device='npu',dtype=torch.float32),torch.softmax(torch.randn((t,4,4),device='npu',dtype=torch.float32),dim=-1)]
original=[v.clone() for v in values]
storage=torch.full((t+2,4,d),0.0625,device='npu',dtype=torch.bfloat16);output=storage[1:-1]
def native():
    x,res,post,comb=values
    return torch.ops._C_ascend.npu_hc_post(x.unsqueeze(0),res.unsqueeze(0),post.unsqueeze(0),comb.unsqueeze(0)).squeeze(0)
def pto():return op(values[0],values[1],values[2],values[3].view(t,16),output)
save()
try:
    with torch.inference_mode():
        n1=native();n2=native();torch.npu.synchronize();check('native_repeat',n2,n1)
        pto();torch.npu.synchronize();check('pto_eager_A',output,n1)
        # Warm both paths before capture. All later changes update the same live inputs.
        for _ in range(2):native();pto()
        torch.npu.synchronize()
        stream=torch.npu.Stream()
        native_graph=torch.npu.NPUGraph();pto_graph=torch.npu.NPUGraph()
        with torch.npu.graph(native_graph,stream=stream):native_output=native()
        with torch.npu.graph(pto_graph,stream=stream):pto()
        torch.npu.synchronize()
        for phase in ('A','post_only','comb_only','B','A_restored'):
            for x,y in zip(values,original):x.copy_(y)
            if phase=='post_only':values[2].mul_(0.75)
            elif phase=='comb_only':values[3].add_(0.05)
            elif phase=='B':
                values[0].add_(0.125);values[1].mul_(0.5);values[2].mul_(0.75);values[3].add_(0.05)
            elif phase=='A_restored':
                for x,y in zip(values,original):x.copy_(y)
            before=[v.clone() for v in values]
            fresh=native();torch.npu.synchronize()
            output.fill_(float('nan'));native_graph.replay();pto_graph.replay();torch.npu.synchronize()
            check('native_graph_'+phase,native_output,fresh);check('pto_graph_'+phase,output,fresh)
            if phase not in ('A','A_restored'):assert not exact(output,n1),'non-discriminating '+phase
            else:check('restored_'+phase,output,n1)
            assert all(exact(x,y) for x,y in zip(values,before)), 'input mutated'
            assert bool((storage[0]==0.0625).all()) and bool((storage[-1]==0.0625).all()),'output guard changed'
        assert all(exact(x,y) for x,y in zip(values,original))
        report['pass']=report['complete']=True;report['raw_graph_replays_per_arm']=5;report['phases']=['A','post_only','comb_only','B','A_restored'];report['live_input_and_gate_ABA']=True;report['guards_pass']=True
        save();print(json.dumps(report),flush=True)
except Exception as exc:
    report['error']=repr(exc);save();raise
