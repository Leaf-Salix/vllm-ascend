#!/usr/bin/env bash
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
job="$base/full-pto-precision-20261016/step01"
source "$base/root-fix-20261016/env.sh"
export SOURCE_ROOT="$job/source"
export PYTHONPATH="$SOURCE_ROOT:$SOURCE_ROOT/tests/pypto_test:$job:$PYTHONPATH"
export PTO_CSA_VARIANT=tnd_full_precision
export VLLM_ASCEND_PTO_CSA_ATOMIC_ADD=0
export LOCAL_WORLD_SIZE=1 OMP_NUM_THREADS=4 OMP_PROC_BIND=false
unset FULL_PROBE_DIR FULL_PROBE_MODE ADMISSION_TRACE_DIR LOW_ACCEPTANCE_FIRST_STEP_DIR
