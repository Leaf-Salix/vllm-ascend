"""无设备验证实际环境、基准SHA及HC-post签名/lowering。"""
import hashlib
import importlib
import json
import os
from pathlib import Path
from pypto.runtime import RunConfig
from pypto.ir._kernel_compile import kernel_signature_for_program
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.hc_post import hc_post_test
from vllm_ascend.ops.pypto.variant import variant_package
job=Path(__file__).resolve().parent
source=job/'source'
for rel,digest in json.loads((job/'baseline-files.json').read_text()).items():
    assert hashlib.sha256((source/rel).read_bytes()).hexdigest()==digest,rel
modules={}
for name in ('torch','torch_npu','vllm','vllm_ascend','pypto','simpler'):
    m=importlib.import_module(name);modules[name]={'file':m.__file__,'version':getattr(m,'__version__',None)}
assert str(source) in modules['vllm_ascend']['file']
assert '/low-acceptance-20261010/runtime-package/' in modules['pypto']['file']
assert variant_package().endswith('deepseek_v4_flash_csa_tnd_full_precision')
assert os.environ['PYTHONNOUSERSITE']=='1'
assert 'cann-9.2.0-beta.2' in os.environ['ASCEND_HOME_PATH']
assert Path(os.environ['PTOAS_ROOT'],'ptoas').is_file()
assert Path(os.environ['ATB_HOME_PATH'],'lib/libatb.so').is_file()
params,aliases=kernel_signature_for_program(hc_post_test.specialize())
assert len(params)==5 and len(aliases)==1 and params[next(iter(aliases))].name=='y'
compiled=hc_post_test.compile(config=RunConfig(platform='a2a3'))
record={'baseline_unchanged':True,'modules':modules,'output_dir':str(compiled.output_dir),'aliases':list(aliases),'env':{k:os.environ.get(k) for k in ('ASCEND_HOME_PATH','ATB_HOME_PATH','PTOAS_ROOT','PTO_CSA_VARIANT')}}
(job/'compile-hcpost.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
