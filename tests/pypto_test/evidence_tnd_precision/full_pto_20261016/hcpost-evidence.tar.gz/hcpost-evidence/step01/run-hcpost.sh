#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
job="$base/full-pto-precision-20261016/step01"
source "$job/env.sh"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
python "$job/check_frozen.py"
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$SOURCE_ROOT/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$job/opp_env")
label=${1:?};tokens=${2:-11};seed=${3:-17}
out="$job/results/$label"
test ! -e "$out"
mkdir -p "$job/results"
export PYPTO_PROG_BUILD_DIR="$job/build" ASCEND_CACHE_PATH="$job/ascend-cache" ASCEND_PROCESS_LOG_PATH="$job/ascend"
export VLLM_CACHE_ROOT="$job/vllm-cache"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH"
python "$job/hcpost_probe.py" --out "$out" --tokens "$tokens" --seed "$seed" > "$job/results/$label.log" 2>&1
