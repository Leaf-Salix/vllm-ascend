"""真实 FULL6 heads 的 PTO WO-A 首阶段逐 bit 对拍；首差立即停止。"""
import argparse, contextlib, hashlib, json, os
from pathlib import Path
import torch, torch_npu, pypto.torch
from vllm.engine.arg_utils import EngineArgs
from vllm.platforms import current_platform
from vllm_ascend.utils import enable_custom_op
from dsv4_csa_single_layer import make_layer
from dsv4_csa_native_case import native_session
from oa import oa_test
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True)
r={'pass':False,'complete':False,'scope':'saved real model L20 first FULL6 heads, not a new Native2 model run','comparisons':[]}
def save():(a.out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def host(x):
 torch.npu.synchronize()
 if x.device.type!='cpu' and torch_npu.get_npu_format(x) not in (0,2):x=torch_npu.npu_format_cast(x,2)
 return x.detach().cpu().contiguous()
def check(label,x,y):
 x,y=host(x),host(y)
 assert x.shape==y.shape and x.dtype==y.dtype and torch.isfinite(x).all() and torch.isfinite(y).all()
 diff=x.view(torch.int16)!=y.view(torch.int16)
 m={'label':label,'bit_equal':not bool(diff.any()),'different_elements':int(diff.sum()),'max_abs':float((x.float()-y.float()).abs().max()),'first_coordinates':diff.nonzero()[:8].tolist()}
 r['comparisons'].append(m);save()
 if not m['bit_equal']:
  m['first_values']=[{'index':idx,'pto':x[tuple(idx)].item(),'native':y[tuple(idx)].item()} for idx in m['first_coordinates']];save()
  torch.save({'stage':label,'heads':fixture[20]['heads'],'actual':x,'expected':y},a.out/'first-difference.pt')
  raise RuntimeError('FIRST_BIT_DIFFERENCE '+label)
torch.npu.set_device(0);torch.npu.config.allow_internal_format=True;torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
current_platform.pre_register_and_update();assert enable_custom_op()
checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config=EngineArgs(model=str(checkpoint),tokenizer_mode='deepseek_v4',trust_remote_code=True,tensor_parallel_size=1,dtype='bfloat16',quantization='ascend',hf_overrides={'sliding_window':128},max_model_len=16384,max_num_seqs=40,max_num_batched_tokens=256,enable_prefix_caching=False,enforce_eager=False,block_size=32,speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,'fuse_norm_quant':True,'align_decode_capture_sizes':False},'enable_cpu_binding':False,'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False}).create_engine_config()

stack=contextlib.ExitStack();stack.enter_context(native_session(config,0))
try:
 with torch.inference_mode():
  pypto.torch.init(device=0,platform='a2a3',runtime='tensormap_and_ringbuffer')
  layer,details=make_layer(config,checkpoint,torch.device('npu:0'),20)
  impl=layer.self_attn.dsa_attn.dsa_attn.impl
  native=Path('/data/pyptouser/yejia/lc128/retest192-native2-b24000/full-probe')
  payload=native/'step074.pt'
  r['fixture_sha256']=hashlib.sha256(payload.read_bytes()).hexdigest()
  assert r['fixture_sha256']=='5b873509016a7419abf5639a808da58950eb2d3d3bd332c00ed8625e00174481'
  fixture=torch.load(payload,map_location='cpu',weights_only=True)
  heads=fixture[20]['heads'].view(6,32768).to('npu')
  opp=Path(os.environ['ASCEND_OPP_PATH']).resolve()
  assert not (opp/'static_kernel').exists()
  torch.npu.set_compile_mode(jit_compile=False)
  from npugraph_ex._acl_concrete_graph import static_kernel
  static_kernel.compile_static_kernel(lambda:None)
  assert len(static_kernel._installed_run_pkgs)==13
  r['static_package_count']=13
  r['static_metadata_sha256']=hashlib.sha256((Path(os.environ['LOW_ACCEPTANCE_OFFICIAL_CACHE'])/'metadata.json').read_bytes()).hexdigest()
  assert r['static_metadata_sha256']=='863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
  from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv_profile import WKVProfile
  from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv import wkv_test
  from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv_order_data import WKV_TOKEN_MODES,WKV_COLUMN_ORDERS,WKV_K_ORDERS
  profile=WKVProfile()
  assert profile.select(6,WKV_TOKEN_MODES,capturing=False,static_requested=True)==0
  profile.qualify_static(metadata_sha256=r['static_metadata_sha256'],reselected=True)
  mode=profile.select(6,WKV_TOKEN_MODES,capturing=True,static_requested=True)
  assert mode==1
  order=torch.tensor([WKV_K_ORDERS[i] for i in WKV_COLUMN_ORDERS[mode]],dtype=torch.int32,device='npu')
  wx=fixture[20]['normed'].to('npu')
  ww=torch_npu.npu_format_cast(impl.wkv.weight.detach(),2).contiguous()
  wy=torch.empty((6,512),dtype=torch.bfloat16,device='npu')
  wop=pypto.torch.register(wkv_test,'full_precision_probe::formal_wkv')
  wref=torch.nn.functional.linear(wx,impl.wkv.weight)
  wop(wx,ww,order,wy);check('formal_WKV_profile_eager',wy,wref)
  wg=torch.npu.NPUGraph()
  with torch.npu.graph(wg):wop(wx,ww,order,wy)
  wy.fill_(float('nan'));wg.replay();torch.npu.synchronize()
  check('formal_WKV_profile_graph',wy,wref)
  output=torch.empty((6,4096),dtype=torch.bfloat16,device='npu')
  impl._forward_o_proj(heads.view(6,64,512),output)
  check('Native_same_heads_vs_saved_whole_model',output,fixture[20]['oproj'])
  wa=impl.wo_a.weight
  original_bmm=torch_npu.npu_transpose_batchmatmul
  observed={}
  def bmm(*args,**kwargs):
   value=original_bmm(*args,**kwargs);observed['oa']=value.clone();return value
  torch_npu.npu_transpose_batchmatmul=bmm
  try:impl._forward_o_proj(heads.view(6,64,512),output)
  finally:torch_npu.npu_transpose_batchmatmul=original_bmm
  ref=observed['oa'].reshape(6,8192)
  wa=torch_npu.npu_format_cast(wa,2).contiguous()
  oa=torch.empty_like(ref)
  op=pypto.torch.register(oa_test,'full_precision_probe::oa_v1')
  op(heads,wa,oa);torch.npu.synchronize()
  check('PTO_WO_A_eager',oa,ref)
  g=torch.npu.NPUGraph()
  with torch.npu.graph(g):op(heads,wa,oa)
  oa.fill_(float('nan'));g.replay();torch.npu.synchronize()
  check('PTO_WO_A_graph',oa,ref)
  torch.save({'heads':host(heads),'native_oa':host(ref),'pto_oa':host(oa)},a.out/'stages.pt')
  r.update(complete=True);r['pass']=True;save()
except Exception as e:r['error']=repr(e);save();raise
finally:stack.close()
