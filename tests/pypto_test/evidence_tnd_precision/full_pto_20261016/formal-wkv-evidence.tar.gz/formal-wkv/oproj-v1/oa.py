"""先独立验证 WO-A 的 Native BF16 发布边界，不接入正式 service。"""
import pypto.language as pl

T = pl.dynamic("OA_T")


@pl.jit
def oa_test(
    heads: pl.Tensor[[T, 32768], pl.BF16],
    weight: pl.Tensor[[8, 4096, 1024], pl.BF16],
    output: pl.Out[pl.Tensor[[T, 8192], pl.BF16]],
):
    heads.bind_dynamic(0, T)
    output.bind_dynamic(0, T)
    rows = pl.tensor.dim(heads, 0)
    row_tiles = (rows + 15) // 16
    accum = pl.create_tensor([row_tiles * 16, 8192], dtype=pl.FP32)
    for worker in pl.spmd(row_tiles * 8 * 8, name_hint="oproj_a"):
        rb = worker // 64
        group = worker // 8 % 8
        nf = worker % 8
        row = rb * 16
        col = nf * 128
        valid = pl.min(16, rows - row)
        first_x = pl.slice(heads, [16, 256], [row, group * 4096], valid_shape=[valid, 256])
        first_w = weight[group:group + 1, 0:256, col:col + 128]
        acc = pl.matmul(first_x, first_w, out_dtype=pl.FP32)
        for step in pl.range(1, 16):
            k = step * 256
            x = pl.slice(heads, [16, 256], [row, group * 4096 + k], valid_shape=[valid, 256])
            w = weight[group:group + 1, k:k + 256, col:col + 128]
            acc = pl.matmul_acc(acc, x, w)
        accum = pl.assemble(accum, acc, [row, group * 1024 + col])
    for worker in pl.spmd(row_tiles * 8, name_hint="oproj_a_bf16"):
        row = worker // 8 * 16
        col = worker % 8 * 1024
        valid = pl.min(16, rows - row)
        value = pl.load(accum, [row, col], [16, 1024], valid_shape=[valid, 1024])
        pl.store(pl.cast(value, pl.BF16, mode="rint"), [row, col], output)
    return output
