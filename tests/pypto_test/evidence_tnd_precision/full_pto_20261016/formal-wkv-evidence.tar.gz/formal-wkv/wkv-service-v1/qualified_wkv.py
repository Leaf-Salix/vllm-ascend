"""独立限定修正：原13包验证和实际reselect完成后才允许自然序T6。"""
import hashlib
import json
import os
from pathlib import Path

METADATA_SHA = '863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
runtimes = []
qualification = {'ready': False, 'capture6': False, 'live6': False, 'metadata_sha': METADATA_SHA}


def install_static(module):
    original = module.compile_static_kernel

    def compile_qualified(*args, **kwargs):
        import torch_npu
        metadata = Path(os.environ['LOW_ACCEPTANCE_OFFICIAL_CACHE']) / 'metadata.json'
        assert not any(runtime.wkv_profile.captured for runtime in runtimes), 'Do not reselect after capture'
        assert hashlib.sha256(metadata.read_bytes()).hexdigest() == METADATA_SHA
        actual = torch_npu.npu._aclnn_reselect_static_kernel
        reselected = []

        def tracked(*values, **options):
            result = actual(*values, **options)
            reselected.append(True)
            return result

        torch_npu.npu._aclnn_reselect_static_kernel = tracked
        try:
            # Original bridge validates exact packages/SDK/determinism and denies fresh compilation.
            result = original(*args, **kwargs)
        finally:
            torch_npu.npu._aclnn_reselect_static_kernel = actual
        assert reselected, 'No actual static reselection'
        assert len(runtimes) == 21
        for runtime in runtimes:
            runtime.qualify_static_wkv(metadata_sha256=METADATA_SHA, reselected=True)
        qualification['ready'] = True
        print('WKV_STATIC_QUALIFIED ' + json.dumps(qualification), flush=True)
        return result

    module.compile_static_kernel = compile_qualified


def install_service(model):
    import torch
    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision import service
    if getattr(service.CSAServiceRuntime.__call__, '_qualified_wkv', False):
        return
    original = service.CSAServiceRuntime.__call__
    for layer in model.model.layers:
        runtime = getattr(layer.self_attn.dsa_attn, '_pto_csa_runtime', None)
        if runtime is not None:
            assert type(runtime) is service.CSAServiceRuntime
            runtimes.append(runtime)
    assert len(runtimes) == 21 and len({id(runtime) for runtime in runtimes}) == 21
    import re
    indices = {int(re.search(r'\.layers\.(\d+)\.', runtime.layer_name).group(1)) for runtime in runtimes}
    assert indices == set(range(2, 43, 2))
    seen = set()

    def forward(runtime, context, hidden, positions, output, kv_cache):
        tokens = hidden.shape[0]
        capture = torch.npu.is_current_stream_capturing()
        # Before actual installation eager warmup retains the original qualification.
        mode = runtime.wkv_profile.select(tokens, service.WKV_TOKEN_MODES, capturing=capture, static_requested=runtime.wkv_static_requested)
        if tokens == 6:
            if capture:
                assert qualification['ready'], 'FULL6 capture before verified static reselection'
                qualification['capture6'] = True
            elif qualification['capture6']:
                qualification['live6'] = True
            key = (runtime.layer_name, qualification['ready'], capture)
            if key not in seen:
                seen.add(key)
                print('WKV_SERVICE_SELECTION ' + json.dumps({'layer': runtime.layer_name,
                      'tokens': tokens, 'capture': capture, 'ready': qualification['ready'],
                      'mode': mode}), flush=True)
        return original(runtime, context, hidden, positions, output, kv_cache)

    forward._qualified_wkv = True
    service.CSAServiceRuntime.__call__ = forward
