"""Read only the real captured L20 tensors around the already known first差."""
from pathlib import Path
import torch


def install(runner, directory):
    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision import service

    root = Path(directory)
    runtime = runner.get_model().model.layers[20].self_attn.dsa_attn._pto_csa_runtime
    original = service.NativeCSACall
    calls = {}
    state = {}
    cache_tables = {
        'kv_cache': 'ori_block_table', 'cmp_kv': 'cmp_block_table',
        'compress_state': 'state_block_table', 'inner_compress_state': 'inner_state_block_table',
        'idx_native_kv_cache': 'idx_block_table',
    }

    def bind(*args, **kwargs):
        call = original(*args, **kwargs)
        if kwargs['layer_name'] == runtime.layer_name and torch.npu.is_current_stream_capturing():
            calls[call.args['x_hc'].shape[0]] = call
        return call

    service.NativeCSACall = bind

    def cpu(value):
        if isinstance(value, torch.Tensor):
            return value.detach().cpu().contiguous().clone()
        if isinstance(value, dict):
            return {key: cpu(item) for key, item in value.items()}
        if isinstance(value, (tuple, list)):
            return [cpu(item) for item in value]
        if value is None or isinstance(value, (int, float, str, bool)):
            return value
        raise TypeError(type(value))

    def caches(call, ids):
        return {name: cpu(call.args[name].index_select(0, pages.to(call.args[name].device)))
                for name, pages in ids.items()}

    def writer_pages(call, name):
        slot_names = {'kv_cache': 'ori_slot_mapping', 'cmp_kv': 'cmp_slot_mapping',
                      'compress_state': 'state_slot_mapping', 'inner_compress_state': 'inner_state_slot_mapping',
                      'idx_native_kv_cache': 'idx_slot_mapping'}
        group_names = {'kv_cache': 'swa', 'cmp_kv': 'compressed', 'compress_state': 'state',
                       'inner_compress_state': 'indexer_state', 'idx_native_kv_cache': 'indexer'}
        # Compact outputs are produced inside the upcoming graph. Include all
        # source slots as well as the previous compact descriptor before replay.
        rows = [cpu(call.args[slot_names[name]])]
        source = call.req[group_names[name]].slot_mapping
        if source is not None:
            rows.append(cpu(source))
        pages = []
        for slots in rows:
            assert slots.ndim == 2 and slots.shape[1] == 2
            pages.extend(slots[(slots >= 0).all(dim=1), 0].tolist())
        return torch.tensor(pages, dtype=torch.int64)

    def before(record):
        if record['forward_index'] != 74:
            return
        assert record['actual_tokens'] == record['padded_tokens'] == 6
        assert record['keys'] == ['h131072_q21'] and record['query_bounds'] == [0, 6]
        assert 6 in calls, 'FULL6 original call descriptor was not recorded during capture'
        call = calls[6]
        assert call.args['native_normed'].data_ptr() == runtime.normed.data_ptr()
        assert cpu(call.args['position_ids']).flatten().tolist() == record['positions']
        assert cpu(call.args['query_start_loc']).tolist() == record['query_bounds']
        ids = {}
        for name, table in cache_tables.items():
            pages = torch.unique(cpu(call.args[table][:1]).flatten().to(torch.int64))
            pages = torch.unique(torch.cat((pages, writer_pages(call, name))))
            pages = pages[pages >= 0]
            assert pages.numel() and int(pages.max()) < call.args[name].shape[0]
            ids[name] = pages
        sizes = {name: pages.numel() * call.args[name][0].numel() * call.args[name].element_size()
                 for name, pages in ids.items()}
        assert sum(sizes.values()) <= 512 * 1024**2, sizes
        specs = {name: {'shape': list(call.args[name].shape), 'stride': list(call.args[name].stride()),
                        'dtype': str(call.args[name].dtype), 'storage_offset': call.args[name].storage_offset(),
                        'data_ptr': call.args[name].data_ptr(), 'bytes': sizes[name]}
                 for name in ids}
        # Query/table/position owners are the exact buffers bound to FULL6.
        metadata = {name: cpu(value) for name, value in call.args.items()
                    if name not in runtime.weights and name not in ids
                    and name not in ('x_hc', 'x_out', 'idx_topk', 'idx_topk_scores')
                    and not name.startswith('native_')}
        req = {name: cpu({key: value for key, value in vars(item).items()
                          if key not in ('cos', 'sin')}) for name, item in call.req.items()}
        payload = {'record': record, 'cache_specs': specs, 'page_ids': ids,
                   'caches': caches(call, ids), 'metadata': metadata, 'req': req}
        torch.save(payload, root/'l20-before.pt')
        state.update(call=call, ids=ids, specs=specs)

    def after(record, snapshot):
        if record['forward_index'] != 74:
            return
        assert state and snapshot is not None
        call = state['call']
        for name, pages in state['ids'].items():
            assert torch.isin(writer_pages(call, name), pages).all(), ('unsaved writer page', name)
        producers = {name: cpu(getattr(runtime, name)[:6]) for name in (
            'hc_mixed', 'hc_post_gates', 'hc_comb_gates', 'normed', 'norm_rstd',
            'wkv_projected', 'indexer_projection_raw', 'indexer_projection_scaled',
            'indexer_weights', 'topk', 'scores', 'native_heads', 'native_attention_out')}
        for actual, expected in ((cpu(call.args['x_hc']).reshape(6, -1), snapshot[20]['input']),
                                 (producers['normed'], snapshot[20]['normed']),
                                 (producers['native_heads'], snapshot[20]['heads'])):
            assert torch.equal(actual.view(torch.uint8), expected.view(torch.uint8)), 'L20 descriptor/witness mismatch'
        metadata = {name: cpu(value) for name, value in call.args.items()
                    if name not in runtime.weights and name not in state['ids']
                    and name not in ('x_hc', 'x_out', 'idx_topk', 'idx_topk_scores')
                    and not name.startswith('native_')}
        torch.save({'qualified': True, 'qualification': 'original candidate outer unchanged; original L20 heads first差',
                    'record': record, 'producers': producers, 'metadata': metadata,
                    'page_ids': state['ids'], 'cache_specs': state['specs'],
                    'caches': caches(call, state['ids'])}, root/'l20-after.pt')
    return before, after
