"""Reuse the existing private runtime selection and add trace-only hooks."""
import importlib.util
import os
import sys
from importlib.machinery import PathFinder

old = '/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/low-acceptance-20261010/sitecustomize.py'
spec = importlib.util.spec_from_file_location('original_private_sitecustomize', old)
existing = importlib.util.module_from_spec(spec)
spec.loader.exec_module(existing)


class ObserverLoader:
    def __init__(self, original):
        self.original = original

    def create_module(self, spec):
        return self.original.create_module(spec)

    def exec_module(self, module):
        self.original.exec_module(module)
        original_begin = module.OfflineCSAObserver.offline_begin_observation
        original_end = module.OfflineCSAObserver.offline_end_observation

        def begin(observer, *args, **kwargs):
            result = original_begin(observer, *args, **kwargs)
            from admission_trace import install
            install(observer, os.environ['ADMISSION_TRACE_DIR'], os.environ.get('ADMISSION_REFERENCE'))
            from full_probe import install as install_full_probe
            install_full_probe(observer, os.environ['FULL_PROBE_DIR'])
            return result

        def end(observer, *args, **kwargs):
            full = observer._full_probe_finish()
            audit = observer._admission_trace_finish()
            result = original_end(observer, *args, **kwargs)
            result['admission_trace'] = audit
            result['full_probe'] = full
            return result

        module.OfflineCSAObserver.offline_begin_observation = begin
        module.OfflineCSAObserver.offline_end_observation = end


class WorkerLoader:
    def __init__(self, original):
        self.original = original

    def create_module(self, spec):
        return self.original.create_module(spec)

    def exec_module(self, module):
        self.original.exec_module(module)
        original = module.OfflineNPUWorker.initialize_from_config

        def initialize(worker, config, *args, **kwargs):
            import json
            from pathlib import Path
            import torch
            from admission_trace import allocation_plan
            plan = allocation_plan(config)
            free, total = torch.npu.mem_get_info()
            rank = worker.vllm_config.parallel_config.data_parallel_rank
            report = dict(plan, free_bytes_before_allocation=free, total_bytes=total)
            directory = Path(os.environ['ADMISSION_TRACE_DIR'])
            directory.mkdir(parents=True, exist_ok=True)
            (directory / f'rank{rank}.capacity.json').write_text(json.dumps(report, indent=2)+'\n')
            if plan['num_blocks'] != int(os.environ['LOW_ACCEPTANCE_GPU_BLOCKS']):
                raise RuntimeError('Actual KV blocks do not match diagnostic request')
            planned = plan['aligned_allocation_upper_bytes']
            if planned > 21 * 1024**3 or planned + 2 * 1024**3 > free:
                raise RuntimeError(f'Unsafe KV allocation plan: blocks={plan["num_blocks"]} upper={planned} free={free} limit={21 * 1024**3} reserve={2 * 1024**3}')
            print(f'ADMISSION_KV_CAPACITY blocks={plan["num_blocks"]} aligned_upper_bytes={planned} free_bytes={free}', flush=True)
            return original(worker, config, *args, **kwargs)

        original_load = module.OfflineNPUWorker.load_model

        def load(worker, *args, **kwargs):
            result = original_load(worker, *args, **kwargs)
            from qualified_wkv import install_service
            install_service(worker.model_runner.model)
            if os.environ['FULL_PROBE_MODE'] == 'witness' and worker.vllm_config.parallel_config.data_parallel_rank == 0:
                import json
                from capture_boundaries import install
                report = install(worker.model_runner)
                print('FULL_GRAPH_WITNESS_ALLOCATED ' + json.dumps(report), flush=True)
            return result

        module.OfflineNPUWorker.load_model = load
        original_barrier = module.OfflineNPUWorker.offline_batch_barrier

        def barrier(worker, *args, **kwargs):
            result = original_barrier(worker, *args, **kwargs)
            worker.model_runner._admission_trace_arm()
            return result

        module.OfflineNPUWorker.offline_batch_barrier = barrier
        module.OfflineNPUWorker.initialize_from_config = initialize


class ObserverFinder:
    @staticmethod
    def find_spec(fullname, path=None, target=None):
        if fullname not in ('offline_pd.observer', 'offline_pd.worker') or not os.environ.get('ADMISSION_TRACE_DIR'):
            return None
        spec = PathFinder.find_spec(fullname, path)
        if spec is not None:
            loader = ObserverLoader if fullname == 'offline_pd.observer' else WorkerLoader
            spec.loader = loader(spec.loader)
        return spec


sys.meta_path.insert(0, ObserverFinder)

# Delegate through the original verified bridge, then observe actual reselect.
class QualifiedStaticLoader:
    def __init__(self, original): self.original = original
    def create_module(self, spec): return self.original.create_module(spec)
    def exec_module(self, module):
        self.original.exec_module(module)
        from qualified_wkv import install_static
        install_static(module)

class QualifiedStaticFinder:
    @staticmethod
    def find_spec(fullname, path=None, target=None):
        if not fullname.endswith("npugraph_ex._acl_concrete_graph.static_kernel"):
            return None
        spec = existing.StaticFinder.find_spec(fullname, path, target)
        if spec is not None:
            spec.loader = QualifiedStaticLoader(spec.loader)
        return spec

sys.meta_path.insert(0, QualifiedStaticFinder)
