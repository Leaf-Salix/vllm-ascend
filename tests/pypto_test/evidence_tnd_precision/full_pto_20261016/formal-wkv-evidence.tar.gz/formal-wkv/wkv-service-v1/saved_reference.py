"""复用既有完整轮次与冻结源码身份门禁。"""
import hashlib
import json
from pathlib import Path


def read_rows(root, name, mode, count):
    folder = root/'full-probe'
    complete = json.loads((folder/'complete.json').read_text())
    records = [json.loads(line) for line in (folder/name).read_text().splitlines()]
    if (not complete['complete'] or complete['mode'] != mode
            or len(records) != complete['records'] or len(records) < count
            or (mode == 'witness' and len(records) != count)):
        raise ValueError('Incomplete FULL witness/control')
    if any(row['forward_index'] != index or row['actual_tokens'] != 0
           for index,row in enumerate(records[count:], count)):
        raise ValueError('Only verified empty control suffix may lie outside generation window')
    return records[:count]

def source_identity(config):
    manifest_path = Path(config['snapshot_manifest'])
    if (manifest_path.parent/'source').resolve() != Path(config['snapshot']).resolve():
        raise ValueError('Source snapshot is not bound to manifest')
    if hashlib.sha256(manifest_path.read_bytes()).hexdigest() != config['source_manifest_sha256']:
        raise ValueError('Source manifest differs from tested task')
    manifest = json.loads(manifest_path.read_text())
    for filename, digest in manifest['files'].items():
        if hashlib.sha256((Path(config['snapshot'])/filename).read_bytes()).hexdigest() != digest:
            raise ValueError('Snapshot changed since testing: '+filename)
