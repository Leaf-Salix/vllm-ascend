"""Persistent graph witnesses for later selected-step module diagnosis.

This helper is not enabled by the admission-only experiment. Install after
weight loading and before profile/capture; snapshots are read outside the graph.
"""

import torch


@torch.library.custom_op('csa_diagnostic::copy_boundary', mutates_args=('destination', 'stamp'))
def copy_boundary(destination: torch.Tensor, stamp: torch.Tensor, value: torch.Tensor,
                  epoch: torch.Tensor, capacity: int) -> None:
    if value.dtype != destination.dtype:
        raise ValueError('Graph witness must preserve boundary dtype')
    count = value.shape[0]
    # The opaque diagnostic op computes this bound at execution time. Dynamo
    # must not specialize the branch using a smaller tracing input.
    rows = min(count, capacity)
    destination[:rows].copy_(value[:rows].reshape(rows, -1))
    stamp[:1].copy_(epoch)
    # Preserve the actual row count so snapshot rejects overcapacity profiles.
    stamp[1:].fill_(count)


@copy_boundary.register_fake
def _fake_copy_boundary(destination, stamp, value, epoch, capacity):
    return None


def install(runner, capacity=144):
    import os
    import torch

    if getattr(runner, '_diagnostic_boundary_storage', None) is not None:
        raise RuntimeError('Graph witnesses already installed')
    model = runner.get_model()
    device = next(model.parameters()).device
    buffers, stamps, handles, originals = {}, {}, [], []
    epoch = torch.zeros((1,), dtype=torch.int64, device=device)
    from l20_snapshot import install as install_l20
    runner._diagnostic_l20_before, runner._diagnostic_l20_after = install_l20(runner, os.environ['FULL_PROBE_DIR'])

    def tensor(rows, columns, dtype=torch.bfloat16):
        return torch.empty((rows, columns), dtype=dtype, device=device)

    def copy(destination, stamp, value):
        copy_boundary(destination, stamp, value, epoch, capacity)

    def attach(index, layer):
        fields = {'input': tensor(capacity, 16384), 'output': tensor(capacity, 16384),
                  'positions': tensor(capacity, 1, torch.int64)}
        buffers[index] = fields
        tags = stamps[index] = {}

        def save(name, value):
            copy(fields[name], tags[name], value)

        def before(module, args, kwargs):
            hidden = kwargs['hidden_states'] if 'hidden_states' in kwargs else args[1]
            positions = kwargs['positions'] if 'positions' in kwargs else args[0]
            save('input', hidden)
            save('positions', positions)

        def after(module, args, kwargs, output):
            save('output', output[0])

        handles.append(layer.register_forward_pre_hook(before, with_kwargs=True))
        handles.append(layer.register_forward_hook(after, with_kwargs=True))
        if layer.self_attn.compress_ratio != 4:
            tags.update({key: torch.full((2,), -1, dtype=torch.int64, device=device) for key in fields})
            return
        fields.update(normed=tensor(capacity, 4096), heads=tensor(capacity, 32768),
                      oproj=tensor(capacity, 4096), attention_half=tensor(capacity, 16384))

        def normed(module, args, output):
            save('normed', output)

        handles.append(layer.input_layernorm.register_forward_hook(normed))
        # Full-PTO Norm bypasses the Native module hook. Copy its real output
        # after the actual PTO op; do not recompute or inject a reference value.
        runtime = getattr(layer.self_attn.dsa_attn, '_pto_csa_runtime', None)
        if runtime is None or not type(runtime).__module__.endswith('deepseek_v4_flash_csa_tnd_full_precision.service'):
            raise RuntimeError('Expected the current full-precision runtime')
        original_norm_op = runtime.pto_input_norm

        def pto_norm(*args):
            result = original_norm_op(*args)
            save('normed', args[2])
            return result

        originals.append((runtime, 'pto_input_norm', original_norm_op))
        runtime.pto_input_norm = pto_norm

        impl = layer.self_attn.dsa_attn.dsa_attn.impl
        original = impl._forward_o_proj

        def projection(heads, output):
            save('heads', heads)
            result = original(heads, output)
            save('oproj', output)
            return result

        tags.update({key: torch.full((2,), -1, dtype=torch.int64, device=device) for key in fields})
        originals.append((impl, '_forward_o_proj', original))
        impl._forward_o_proj = projection
        original_pre = layer.hc_pre

        def hc_pre(value, weight, scale, base):
            if weight is layer.hc_ffn_fn:
                save('attention_half', value)
            return original_pre(value, weight, scale, base)

        originals.append((layer, 'hc_pre', original_pre))
        layer.hc_pre = hc_pre

    def cleanup():
        for handle in handles:
            handle.remove()
        for owner, name, original in originals:
            setattr(owner, name, original)
        for name in ('_diagnostic_boundary_snapshot', '_diagnostic_boundary_begin',
                     '_diagnostic_boundary_storage', '_diagnostic_boundary_uninstall'):
            if hasattr(runner, name):
                delattr(runner, name)

    try:
        for index, layer in enumerate(model.model.layers):
            attach(index, layer)
        if len(buffers) != 43 or sum('heads' in fields for fields in buffers.values()) != 21:
            raise ValueError('Unexpected target model/layer layout')
    except BaseException:
        cleanup()
        raise
    addresses = {index: {key: value.data_ptr() for key, value in fields.items()}
                 for index, fields in buffers.items()}

    def begin(step, actual_tokens):
        if step <= 0 or actual_tokens > capacity:
            raise ValueError('Invalid diagnostic step/target shape')
        epoch.fill_(step)
        # Poison private witnesses so a fresh stamp alone cannot hide an omitted
        # data copy. These buffers never alias model inputs, outputs or KV cache.
        for fields in buffers.values():
            for key, value in fields.items():
                value.fill_(torch.iinfo(torch.int64).min if key == 'positions' else float('nan'))

    def snapshot(positions, expected_epoch):
        count = len(positions)
        if count > capacity:
            raise ValueError('Witness capacity exceeded')
        output = {}
        for index, fields in buffers.items():
            if any(value.data_ptr() != addresses[index][key] for key, value in fields.items()):
                raise RuntimeError('Graph witness allocation changed')
            for key, tag in stamps[index].items():
                observed_epoch, captured_rows = tag.cpu().tolist()
                if observed_epoch != expected_epoch or not count <= captured_rows <= capacity:
                    raise RuntimeError(f'layer{index}/{key}: stale/overcapacity graph witness')
            values = {key: value[:count].detach().cpu().clone() for key, value in fields.items()}
            if any(not torch.isfinite(value).all() for key, value in values.items() if key != 'positions'):
                raise RuntimeError(f'layer{index}: nonfinite or uncopied witness')
            if values['positions'].flatten().tolist() != positions:
                raise RuntimeError(f'layer{index}: graph witness was not refreshed for current positions')
            output[index] = values
        return output

    runner._diagnostic_boundary_snapshot = snapshot
    runner._diagnostic_boundary_begin = begin
    runner._diagnostic_boundary_uninstall = cleanup
    runner._diagnostic_boundary_storage = (buffers, stamps, handles, originals, epoch)
    allocated = sum(value.numel() * value.element_size() for fields in buffers.values() for value in fields.values())
    allocated += sum(tag.numel() * tag.element_size() for tags in stamps.values() for tag in tags.values())
    return {'addresses': addresses, 'allocated_bytes': allocated}
