"""归档全部Indexer模块实验源/数值JSON与日志；PT只保留SHA，不复制权重。"""
from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/indexer-projection-20261017')
tasks=json.loads((root/'task-map.json').read_text());dst=root/'indexer-evidence-v1';dst.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(p,n):
 q=dst/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
for folder in sorted(root.iterdir()):
 if folder.is_dir() and (folder.name.startswith('v') and folder.name[1:].isdigit() or folder.name=='native-order-v1'):
  for p in sorted(folder.iterdir()):
   if p.is_file() and p.suffix in ('.py','.sh','.json','.log'):copy(p,Path('experiments')/folder.name/p.name)
for name in ('task-map.json','native_indexer_order_map.json','summarize_native_orders.py','qualify_modules.py','qualified-modules.json','collect_evidence.py','freeze_step09.py'):
 copy(root/name,Path('helpers')/name)
payloads={}
for task in tasks:
 label=task['label'];r=Path('/data/pyptouser/yejia/fp16')/label
 for pattern in ('run.log','result/*.json'):
  for p in sorted(r.glob(pattern)):copy(p,Path('results')/label/p.relative_to(r))
 for p in r.glob('result/*.pt'):payloads[str(p)]={'sha256':sha(p),'bytes':p.stat().st_size}
(dst/'payload-metadata.json').write_text(json.dumps(payloads,indent=2)+'\n')
source=root.parent/'full-pto-precision-20261017/step08/manifest.json';copy(source,Path('snapshots')/'step08-manifest.json')
raw=subprocess.run(['task-submit','--list'],capture_output=True,text=True,check=True).stdout
ids={row['task'] for row in tasks};lines=[s for s in raw.splitlines() if any(i in s for i in ids)]
(dst/'task-status.txt').write_text('\n'.join(lines)+'\n')
manifest={str(p.relative_to(dst)):sha(p) for p in sorted(dst.rglob('*')) if p.is_file()}
(dst/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
p=root/'indexer-evidence-v1.tar.gz'
with tarfile.open(p,'w:gz') as bundle:bundle.add(dst,arcname=dst.name)
print(json.dumps({'sha256':sha(p),'bytes':p.stat().st_size,'files':len(manifest),'tasks':lines}))
