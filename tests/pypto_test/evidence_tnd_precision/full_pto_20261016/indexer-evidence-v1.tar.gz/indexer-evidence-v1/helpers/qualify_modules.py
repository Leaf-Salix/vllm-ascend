"""CPU严格检查全部已结束Indexer模块结果，拒绝空结果/缺阶段/未完成形状。"""
from pathlib import Path
import hashlib,json
root=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/indexer-projection-20261017')
base=Path('/data/pyptouser/yejia/fp16')
labels=[f'idxprojm6t{first}to{first+63}' for first in (1,65,129,193)]
expected_labels={'Native_repeat_A','Native_ND_A','PTO_eager_A','Native_restored_A','Native_graph_A','PTO_graph_A','Native_repeat_B','Native_graph_B','PTO_graph_B','Native_repeat_A_restored','Native_restored_A_restored','Native_graph_A_restored','PTO_graph_A_restored'}
sources={};cases=0
def load(label):
 p=base/label/'result/result.json';d=json.loads(p.read_text());sources[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
 assert d['complete'] and d['pass'] and not d.get('error') and d['device_name']=='Ascend910_9392'
 assert d['cross_shape_first_last']
 return d
def validate(case):
 assert case['pass'] and expected_labels<={x['label'] for x in case['comparisons']}
 for row in case['comparisons']:
  assert set(row['metrics'])=={'raw','scaled','output'}
  assert all(m['bit_equal'] and m['different_elements']==0 and m['max_abs']==0 and not m['first_coordinates'] for m in row['metrics'].values())
 if case.get('cross_shape_pass'):
  assert {'Native_graph_cross_shape_A','PTO_graph_cross_shape_A'}<={x['label'] for x in case['comparisons']}
for first,label in zip((1,65,129,193),labels,strict=True):
 d=load(label);assert [c['tokens'] for c in d['cases']]==list(range(first,first+64))
 assert d['native']['weight_sha256']=='b46991cf5a8a032ec111ede4af54fe7df5e54fa32d167bedc315fca869d44a5e'
 assert d['cases'][0]['cross_shape_pass'] and d['cases'][-1]['cross_shape_pass']
 for c in d['cases']:validate(c);cases+=1
layers=[]
for first,last,label in ((2,14,'idxprojlayers2to14v8'),(16,28,'idxprojlayers16to28'),(30,42,'idxprojlayers30to42')):
 d=load(label);expected=list(range(first,last+1,2));assert d['qualified_layers']==expected
 assert [(c['layer'],c['tokens']) for c in d['cases']]==[(i,t) for i in expected for t in (40,240)]
 for c in d['cases']:validate(c);assert c['cross_shape_pass'];cases+=1
 for native in d['native']:
  assert native['layer'] in expected and native['class']=='AscendReplicatedLinear' and native['quant_method']=='AscendUnquantizedLinearMethod'
  assert native['dtype']=='torch.bfloat16' and native['shape']==[64,4096] and native['format']==29 and native['scale']==0.011048543456039806
 layers.extend(expected)
assert cases==298 and layers==list(range(2,43,2))
data={'pass':True,'module_cases':cases,'l4_all_tokens':256,'real_weight_csa_layers':layers,'layer_tokens':[40,240],'stages':['raw_bf16','scaled_bf16','output_fp16'],'graph_ABA':True,'cross_shape_first_last':True,'scope':'real checkpoint weights; fixed synthetic-hidden L4 Native-normalized rows and constructed B; not whole model','sources_sha256':sources}
p=root/'qualified-modules.json';p.write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data))
