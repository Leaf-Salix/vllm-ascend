"""在CPU重算全部查询关系，冻结Indexer限定环境下的T1..256 K次序。"""
from pathlib import Path
import hashlib,json
root=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/indexer-projection-20261017')
base=Path('/data/pyptouser/yejia/fp16')
labels=('idxmap1to64','idxmap65to128','idxmap129to192','idxmap193to256')
rows={};sources={};orders=None
for label in labels:
 p=base/label/'result/result.json';d=json.loads(p.read_text());assert d['complete']
 sources[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
 if orders is None:orders=d['orders']
 assert orders==d['orders']
 for c in d['cases']:
  tokens=c['tokens'];assert c['complete'] and len(c['queries'])==6 and tokens not in rows
  ids=c['tile_order_ids'];assert len(ids)==(tokens+15)//16 and all(len(row)==4 for row in ids)
  flat=[i for row in ids for i in row]
  assert all(0<=i<len(orders) for i in flat)
  candidates=[set(range(len(orders))) for _ in flat]
  for q in c['queries']:
   assert [max(q['triple'],key=orders[i].index) for i in flat]==q['last_by_tile']
   candidates=[{i for i in pool if max(q['triple'],key=orders[i].index)==value} for pool,value in zip(candidates,q['last_by_tile'],strict=True)]
   assert [len(pool) for pool in candidates]==q['candidate_counts']
  assert all(pool=={i} for pool,i in zip(candidates,flat,strict=True))
  assert all(v==1 for v in c['queries'][-1]['candidate_counts'])
  table=[[orders[i] for i in row] for row in ids]
  table.extend([[list(range(16)) for _ in range(4)] for _ in range(16-len(table))])
  assert all(sorted(order)==list(range(16)) for row in table for order in row)
  rows[tokens]=table
assert sorted(rows)==list(range(1,257))
p=base/'idxordt40/result/result.json';d=json.loads(p.read_text());assert d['complete']
sources[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
assert rows[40][:3]==[[d['orders'][i] for i in row] for row in d['cases'][0]['tile_order_ids']]
modes=[];token_modes=[]
for tokens in range(1,257):
 table=rows[tokens]
 if table not in modes:modes.append(table)
 token_modes.append(modes.index(table))
data={'scope':'current A3 CANN9.2 BF16 Native T x4096 x64; 44-family finite-matrix diagnostics only, not arbitrary-input or model proof','sources':sources,'first_tokens':1,'last_tokens':256,'row_grain':16,'column_grain':16,'k_block':256,'tokens_to_mode':token_modes,'modes':modes}
p=root/'native_indexer_order_map.json';p.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'modes':len(modes),'unique_orders':len({tuple(v) for table in modes for row in table for v in row})}))
