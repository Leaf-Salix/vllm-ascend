"""以3359份已冻结旧源构建独立step09；仅接入已验证Indexer三文件。"""
from pathlib import Path
import hashlib,json,shutil,sys
base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
root=base/'full-pto-precision-20261017';old=root/'step08';new=root/'step09'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if sys.argv[1]=='init':
 assert sha(old/'manifest.json')=='d3525c39033a5c88933bb33177caae9fa75d351c561ff54e3b7b6e64a8500580'
 data=json.loads((old/'manifest.json').read_text());new.mkdir(exist_ok=False);source=new/'source';source.mkdir()
 for name,digest in data['files'].items():
  p=old/'source'/name;assert sha(p)==digest,name
  q=source/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
 shutil.copyfile(old/'manifest.json',new/'parent-manifest.json')
 print('INIT',len(data['files']))
elif sys.argv[1]=='final':
 commit=sys.argv[2];assert len(commit)==9
 data=json.loads((new/'parent-manifest.json').read_text())
 prefix='vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision/'
 added={prefix+'indexer_projection.py',prefix+'indexer_order_data.py'}
 changed={prefix+'service.py'}
 names=set(data['files'])|added
 files={name:sha(new/'source'/name) for name in sorted(names)}
 assert {name for name,digest in data['files'].items() if digest!=files[name]}==changed
 overlay={prefix+n:files[prefix+n] for n in ('service.py','wkv.py','wkv_order_data.py','indexer_projection.py','indexer_order_data.py')}
 manifest={'codex_commit':commit,'scope':'step08 plus Native-aligned PTO Indexer projection; pinned test-only runtime guard retained','snapshot_kind':'controlled source overlay; old tests and Native baseline preserved','parent_manifest_sha256':sha(new/'parent-manifest.json'),'changed_from_step08':sorted(changed|added),'overlay_files':overlay,'files':files}
 (new/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 (new/'frozen-source.json').write_text(json.dumps(files,indent=2)+'\n')
 print(json.dumps({'files':len(files),'manifest_sha256':sha(new/'manifest.json'),'overlay_files':overlay}))
else:raise ValueError('init or final required')
