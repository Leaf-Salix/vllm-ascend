"""真实Native Indexer权重投影；逐阶段首差停止，不改正式服务。"""
import argparse,contextlib,hashlib,json,os
from pathlib import Path
import torch,torch_npu,pypto.torch
from indexer_projection import indexer_projection
from vllm.engine.arg_utils import EngineArgs
from vllm.platforms import current_platform
from vllm_ascend.utils import enable_custom_op
from dsv4_csa_single_layer import make_layer
from dsv4_csa_native_case import native_session

p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(exist_ok=False,parents=True)
r={'complete':False,'pass':False,'cases':[],'scope':'actual L4 Native weights_proj, saved Native-normalized rows; module-only; old precision/performance unchanged','task_device':os.environ['TASK_DEVICE']}
def save():(a.out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def exact(x,y):return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def host(values):torch.npu.synchronize();return {k:v.cpu() for k,v in values.items()}
def check(label,actual,expected):
 metrics={}
 for name in ('raw','scaled','output'):
  v,g=actual[name],expected[name];assert torch.isfinite(v).all() and torch.isfinite(g).all()
  d=v.float()-g.float();bits=v.contiguous().view(torch.int16)!=g.contiguous().view(torch.int16);metrics[name]={'bit_equal':exact(v,g),'different_elements':int(bits.sum()),'max_abs':float(d.abs().max()),'first_coordinates':bits.nonzero()[:8].tolist()}
  if not metrics[name]['bit_equal']:
   case['comparisons'].append({'label':label,'metrics':metrics});save()
   torch.save({'actual':actual,'expected':expected,'input':x.cpu(),'weight':w.cpu(),'order':order.cpu()},a.out/'first-difference.pt')
   raise RuntimeError('FIRST_BIT_DIFFERENCE '+label+' '+name)
 case['comparisons'].append({'label':label,'metrics':metrics});save()
def old_order(tokens):
 table=[]
 for rb in range(16):
  groups=[]
  for group in range(4):
   seq=[]
   for step in range(16):
    k=step
    if tokens==24:k=((group//2*4+(7-step//2 if group%2 else step//2))%8)*2+step%2
    elif tokens==48:k=(group//2*8+(15-step if group%2 else step))%16
    elif tokens in (96,144,192,240):
     shift=rb//2*5
     if tokens==144:shift=(rb%8)//2*4
     elif tokens==192:shift=rb//2*2
     elif tokens==240:shift=(rb%14)//2*2
     k=(shift+(15-step if rb%2 else step))%16
    seq.append(k)
   groups.append(seq)
  table.append(groups)
 return torch.tensor(table,dtype=torch.int32)

torch.npu.set_device(0);torch.npu.config.allow_internal_format=True;torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
current_platform.pre_register_and_update();assert enable_custom_op()
checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config=EngineArgs(model=str(checkpoint),tokenizer_mode='deepseek_v4',trust_remote_code=True,tensor_parallel_size=1,dtype='bfloat16',quantization='ascend',hf_overrides={'sliding_window':128},max_model_len=16384,max_num_seqs=40,max_num_batched_tokens=256,enable_prefix_caching=False,enforce_eager=False,block_size=32,speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,'fuse_norm_quant':True,'align_decode_capture_sizes':False},'enable_cpu_binding':False,'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False}).create_engine_config()
stack=contextlib.ExitStack();stack.enter_context(native_session(config,0))
save()
try:
 with torch.inference_mode():
  layer,details=make_layer(config,checkpoint,torch.device('npu:0'),4)
  from vllm_ascend.device.device_op import DeviceOperator
  impl=layer.self_attn.dsa_attn.impl;projection=impl.weights_proj
  assert projection is layer.self_attn.indexer.weights_proj
  assert projection.bias is None and projection.weight.dtype==torch.bfloat16 and tuple(projection.weight.shape)==(64,4096)
  w=torch_npu.npu_format_cast(projection.weight.detach(),2).contiguous();w_before=w.clone()
  scale=impl.indexer_softmax_scale*impl.indexer_heads**-0.5
  assert scale==0.011048543456039806
  r['native']={'class':type(projection).__name__,'quant_method':type(projection.quant_method).__name__,'dtype':str(projection.weight.dtype),'shape':list(projection.weight.shape),'format':int(torch_npu.get_npu_format(projection.weight)),'scale':scale,'weight_sha256':hashlib.sha256(w.cpu().view(torch.uint8).numpy().tobytes()).hexdigest(),'details':details}
  fixture=Path('/data/pyptouser/yejia/fp16/wkvm10shapes/t240/first-difference.pt')
  assert hashlib.sha256(fixture.read_bytes()).hexdigest()=='8e9d647b13e5eee5586395a08b648fa62327a01a1dd6934a7e0ab9efaaa013a4'
  saved=torch.load(fixture,map_location='cpu',weights_only=True)['norm_input']
  torch.save({'weight':w.cpu(),'norm_input':saved,'native_identity':r['native']},a.out/'native-fixture.pt')
  pypto.torch.init(device=0,platform='a2a3',runtime='tensormap_and_ringbuffer')
  op=pypto.torch.register(indexer_projection,'diagnostic_indexer_projection_v2::forward')
  keep=[]
  for tokens in (40,240,11):
   case={'tokens':tokens,'comparisons':[]};r['cases'].append(case);save()
   x=saved[:tokens].contiguous().to('npu');initial=x.clone();order=old_order(tokens).to('npu');order_before=order.clone()
   owners={name:torch.full((tokens+2,64),.0625,dtype=dtype,device='npu') for name,dtype in (('raw',torch.bfloat16),('scaled',torch.bfloat16),('output',torch.float16))}
   outputs={name:v[1:-1] for name,v in owners.items()}
   def native(nd=False):
    raw=torch.nn.functional.linear(x,w) if nd else projection(x)
    scaled=raw*scale
    return {'raw':raw,'scaled':scaled,'output':DeviceOperator.prepare_dsa_indexer_weights(scaled)}
   def run():op(x,w,order,outputs['raw'],outputs['scaled'],outputs['output'])
   def observed():
    result=host(outputs)
    assert exact(x,before) and exact(w,w_before) and exact(order,order_before)
    assert all(bool((v[0]==.0625).all() & (v[-1]==.0625).all()) for v in owners.values())
    return result
   expected=host(native());gold=expected
   check('Native_repeat_A',host(native()),expected);check('Native_ND_A',host(native(True)),expected)
   before=x.clone()
   for v in outputs.values():v.fill_(float('nan'))
   run();check('PTO_eager_A',observed(),expected)
   ng=torch.npu.NPUGraph()
   with torch.npu.graph(ng):native_out=native()
   pg=torch.npu.NPUGraph()
   with torch.npu.graph(pg):run()
   keep.append((ng,pg,native_out,outputs,owners,x,order))
   for phase in ('A','B','A_restored'):
    x.copy_(initial)
    if phase=='B':x.copy_(initial.roll(1,dims=1));x.add_(.03125)
    before=x.clone();expected=host(native());check('Native_repeat_'+phase,host(native()),expected)
    if phase=='B':assert not exact(expected['raw'],gold['raw'])
    else:check('Native_restored_'+phase,expected,gold)
    for v in native_out.values():v.fill_(float('nan'))
    ng.replay();check('Native_graph_'+phase,host(native_out),expected)
    for v in outputs.values():v.fill_(float('nan'))
    pg.replay();check('PTO_graph_'+phase,observed(),expected)
   case['pass']=True;save()
  r.update(complete=True,pass_=True);r['pass']=True;save()
except Exception as e:r['error']=repr(e);save();raise
finally:stack.close()
