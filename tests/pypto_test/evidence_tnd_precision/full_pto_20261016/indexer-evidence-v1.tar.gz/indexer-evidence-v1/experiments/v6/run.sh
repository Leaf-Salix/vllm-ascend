#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
label=${1:?}; first=${2:?}; last=${3:?}; layer=${4:-4}
[[ "$first" =~ ^[0-9]+$ && "$last" =~ ^[0-9]+$ && "$layer" =~ ^[0-9]+$ ]]
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/full-pto-precision-20261016/step01/env.sh"
export SOURCE_ROOT="$base/full-pto-precision-20261017/step08/source"
export PYTHONPATH="$SOURCE_ROOT:$SOURCE_ROOT/tests/pypto_test:$PYTHONPATH"
python "$base/full-pto-model-8k-b40-20261016/source_preflight.py"
export PYPTO_CACHE=0
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE" LOCAL_WORLD_SIZE=1 OMP_NUM_THREADS=4
export TMPDIR
TMPDIR=$(mktemp -d /tmp/idxproj.XXXXXX)
trap 'rmdir "$TMPDIR" 2>/dev/null || true' EXIT
out="/data/pyptouser/yejia/fp16/$label"
test ! -e "$out"
mkdir -p "$out"
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$SOURCE_ROOT/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$out/opp_env")
export ASCEND_CACHE_PATH="$out/cache" ASCEND_PROCESS_LOG_PATH="$out/logs"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH"
cd "$out"
python "$base/indexer-projection-20261017/v6/probe.py" --first "$first" --last "$last" --layer "$layer" --out "$out/result" > "$out/run.log" 2>&1
