"""Use saved real Native FULL6 inputs; stop at first module bit difference."""
import argparse,contextlib,hashlib,json,os
from pathlib import Path
import torch,torch_npu,pypto.torch
from vllm.engine.arg_utils import EngineArgs
from vllm.platforms import current_platform
from vllm_ascend.utils import enable_custom_op
from dsv4_csa_single_layer import make_layer
from dsv4_csa_native_case import native_session
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.hc_pre import hc_pre_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.input_norm import input_norm_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv import wkv_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.indexer_projection import indexer_projection
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv_order_data import WKV_COLUMN_ORDERS,WKV_K_ORDERS,WKV_TOKEN_MODES
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.indexer_order_data import INDEXER_K_ORDERS,INDEXER_TILE_ORDERS,INDEXER_TOKEN_MODES

p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--snapshot-sha',required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
r={'pass':False,'complete':False,'cases':[],'source_commit':'c1ef141ae','saved_step':74,'scope':'L20 real first FULL6 core replay with original selected physical pages; gate original PTO heads/cache before Native component reference, no model Native2'}
def save():(a.out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def exact(x,y):return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def host(x):
 if x.device.type!='cpu':
  torch.npu.synchronize()
  if torch_npu.get_npu_format(x) not in (0,2):x=torch_npu.npu_format_cast(x,2)
 return x.detach().cpu().contiguous()
def check(label,actual,expected):
 actual=host(actual) if actual.device.type!='cpu' else actual
 expected=host(expected) if expected.device.type!='cpu' else expected
 assert actual.shape==expected.shape and actual.dtype==expected.dtype
 assert torch.isfinite(actual).all() and torch.isfinite(expected).all()
 different=(actual.contiguous().view(torch.int8 if actual.element_size()==1 else (torch.int16 if actual.element_size()==2 else torch.int32))!=expected.contiguous().view(torch.int8 if expected.element_size()==1 else (torch.int16 if expected.element_size()==2 else torch.int32)))
 m={'label':label,'bit_equal':exact(actual,expected),'different_elements':int(different.sum()),'max_abs':float((actual.float()-expected.float()).abs().max()),'first_coordinates':different.nonzero()[:8].tolist()}
 case['comparisons'].append(m);save()
 if not m['bit_equal']:
  m['first_values']=[{'index':idx,'actual':actual[tuple(idx)].item(),'expected':expected[tuple(idx)].item()} for idx in m['first_coordinates']];save()
  torch.save({'layer':layer_index,'stage':label,'input':cpu_input,'actual':actual,'expected':expected},a.out/'first-difference.pt')
  raise RuntimeError('FIRST_BIT_DIFFERENCE '+str(layer_index)+' '+label)

base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
native=Path('/data/pyptouser/yejia/lc128/retest192-native2-b24000/full-probe')
payload=native/'step074.pt';r['native_snapshot_sha256']=hashlib.sha256(payload.read_bytes()).hexdigest()
stage_bytes=(native/'stages.jsonl').read_bytes();assert hashlib.sha256(stage_bytes).hexdigest()=='87fa6b787a138a58cafc9b18ddb10554c8ce08b9064f831ecd0a6a105d8a5945'
stages=[json.loads(line) for line in stage_bytes.splitlines()];stage=stages[74]
assert stage['forward_index']==74 and stage['actual_tokens']==6
fixture=torch.load(payload,map_location='cpu',weights_only=True)
for i,fields in fixture.items():
 for name,value in fields.items():
  d={'shape':list(value.shape),'dtype':str(value.dtype),'sha256':hashlib.sha256(value.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()}
  assert d==stage['layers'][str(i)][name],(i,name)
r['native_snapshot_all_fields_match_saved_stage']=True;save()
torch.npu.set_device(0);torch.npu.config.allow_internal_format=True;torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
current_platform.pre_register_and_update();assert enable_custom_op()
checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config=EngineArgs(model=str(checkpoint),tokenizer_mode='deepseek_v4',trust_remote_code=True,tensor_parallel_size=1,dtype='bfloat16',quantization='ascend',hf_overrides={'sliding_window':128},max_model_len=16384,max_num_seqs=40,max_num_batched_tokens=256,enable_prefix_caching=False,enforce_eager=False,block_size=32,speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,'fuse_norm_quant':True,'align_decode_capture_sizes':False},'enable_cpu_binding':False,'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False}).create_engine_config()
stack=contextlib.ExitStack();stack.enter_context(native_session(config,0))
try:
 with torch.inference_mode():
  from scipy.linalg import hadamard
  from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.native_adapter import prepare_weights,CSAOperators
  pypto.torch.init(device=0,platform='a2a3',runtime='tensormap_and_ringbuffer')
  layer_index=20;case={'layer':20,'comparisons':[]};r['cases'].append(case);save()
  layer,details=make_layer(config,checkpoint,torch.device('npu:0'),20)
  dump=Path('/data/pyptouser/yejia/lc128/full6-hook2/full-probe/l20-after.pt')
  r['snapshot_sha256']=hashlib.sha256(dump.read_bytes()).hexdigest();assert r['snapshot_sha256']==a.snapshot_sha
  after=torch.load(dump,map_location='cpu',weights_only=True)
  r['before_snapshot_sha256']=hashlib.sha256(dump.with_name('l20-before.pt').read_bytes()).hexdigest()
  assert r['before_snapshot_sha256']=='3faf46510b167e259013dddc7a6f59412313b112502ca02a64f796abe4eec04f'
  before=torch.load(dump.with_name('l20-before.pt'),map_location='cpu',weights_only=True)
  assert after['qualified'] and after['record']==before['record'] and after['page_ids'].keys()==before['page_ids'].keys()
  for name in after['page_ids']:assert exact(after['page_ids'][name],before['page_ids'][name])
  cpu_input=fixture[20]['input'];check('actual_graph_norm_saved_gold',after['producers']['normed'],fixture[20]['normed'])
  h=torch.tensor(hadamard(128,dtype=float),dtype=torch.float32,device='npu')
  weights=prepare_weights(layer.self_attn,h,layer)
  # Native compressed/state and indexer/inner_state are alternative typed
  # descriptors of the same physical allocation. Preserve aliases and page IDs.
  carriers={};caches={};guarded_carriers={}
  for name,spec in before['cache_specs'].items():
   dtype=before['caches'][name].dtype;page_bytes=before['caches'][name][0].numel()*before['caches'][name].element_size()
   key=spec['data_ptr'];shape=(spec['shape'][0],page_bytes)
   if key not in carriers:
    import math
    guard_bytes=math.lcm(page_bytes,512)
    owner=torch.full((shape[0]*page_bytes+2*guard_bytes,),37,dtype=torch.int8,device='npu')
    guarded_carriers[key]=(owner,guard_bytes)
    carriers[key]=owner[guard_bytes:-guard_bytes].reshape(shape);carriers[key].zero_()
   assert tuple(carriers[key].shape)==shape
   caches[name]=carriers[key].view(dtype).reshape(spec['shape'])
   assert list(caches[name].stride())==spec['stride']
  for left,ls in before['cache_specs'].items():
   for right,rs in before['cache_specs'].items():
    assert (caches[left].data_ptr()==caches[right].data_ptr()) == (ls['data_ptr']==rs['data_ptr'])
  ids={name:pages.to('npu') for name,pages in before['page_ids'].items()}
  initial={name:value.to('npu') for name,value in before['caches'].items()}
  def restore():
   for name,value in initial.items():caches[name].index_copy_(0,ids[name],value)
  args={**weights,**{name:value.to('npu') for name,value in after['metadata'].items()},**caches}
  args.update(x_hc=cpu_input.reshape(6,4,4096).to('npu'),native_normed=after['producers']['normed'].to('npu'),native_kv_projected=after['producers']['wkv_projected'].to('npu'),native_indexer_weights=after['producers']['indexer_weights'].to('npu'),native_heads=torch.empty((6,32768),dtype=torch.bfloat16,device='npu'),idx_topk=torch.empty((6,512),dtype=torch.int32,device='npu'),idx_topk_scores=torch.empty((6,512),dtype=torch.float32,device='npu'),x_out=torch.empty((6,4,4096),dtype=torch.bfloat16,device='npu'))
  op=CSAOperators.register().attention
  names=[v.name for v in op._schema.arguments];ordered=[args[name] for name in names]
  frozen={name:host(value).clone() for name,value in args.items() if name not in caches and name not in ('native_heads','idx_topk','idx_topk_scores','x_out')}
  def check_carrier_guards():
   assert all(bool((owner[:count]==37).all() & (owner[-count:]==37).all()) for owner,count in guarded_carriers.values()),'page carrier guard modified'
  def check_replay(label):
   check_carrier_guards()
   assert all(exact(host(args[name]),value) for name,value in frozen.items()),'input/metadata/weight mutation'
   check(label+'_heads',args['native_heads'],after['producers']['native_heads'])
   check(label+'_topk',args['idx_topk'],after['producers']['topk'])
   for name in caches:
    value=host(caches[name].index_select(0,ids[name]));expected=after['caches'][name]
    if name in ('compress_state','inner_compress_state'):
     table='state_block_table' if name=='compress_state' else 'inner_state_block_table'
     other_slot='cmp_slot_mapping' if name=='compress_state' else 'idx_slot_mapping'
     positions=after['record']['positions'];assert after['record']['query_bounds']==[0,6]
     assert positions==list(range(positions[0],positions[0]+6))
     # A conservative superset of the actual C4 8-token pool reads and six
     # commits. Full table tails contain stale pages belonging to other groups.
     active=after['metadata'][table][0,max(0,positions[0]-8)//2:positions[-1]//2+1].to(torch.int64)
     slots=after['metadata'][other_slot];alias_writes=slots[(slots>=0).all(1),0].to(torch.int64)
     active=torch.unique(torch.cat((active,alias_writes)));active=active[active>=0]
     direct_slot='state_slot_mapping' if name=='compress_state' else 'inner_state_slot_mapping'
     writers=after['metadata'][direct_slot];writers=writers[(writers>=0).all(1),0].to(torch.int64)
     assert torch.isin(writers,active).all(),('state writer outside declared window',name)
     all_pages=before['page_ids'][name];assert torch.isin(active,all_pages).all()
     mask=torch.isin(all_pages,active)
     assert exact(value[~mask],before['caches'][name][~mask]),('unexpected write outside active state/alias pages',name)
     case.setdefault('ownership',{})[name]={'active_and_alias_write_pages':active.tolist(),'unaccessed_pages_unchanged_from_pre':True,'original_model_post_unaccessed_may_change':not exact(expected[~mask],before['caches'][name][~mask])};save()
     value=value[mask];expected=expected[mask]
    different=value.contiguous().view(torch.uint8)!=expected.contiguous().view(torch.uint8)
    item={'label':label+'_'+name,'bit_equal':exact(value,expected),'different_bytes':int(different.sum()),'scope':'physical bytes, including typed alias/padding; no FP32 finite/numeric claim'}
    case['comparisons'].append(item);save()
    if not item['bit_equal']:
     torch.save({'stage':item['label'],'actual':value,'expected':expected},a.out/'first-cache-difference.pt')
     raise RuntimeError('STANDALONE_PTO_FIDELITY_CACHE '+name)
  restore();args['native_heads'].fill_(float('nan'));args['idx_topk'].fill_(-777);op(*ordered);torch.npu.synchronize();check_replay('PTO_eager_original_fidelity')
  restore();g=torch.npu.NPUGraph()
  with torch.npu.graph(g):op(*ordered)
  restore();args['native_heads'].fill_(float('nan'));args['idx_topk'].fill_(-777)
  g.replay();torch.npu.synchronize();check_replay('PTO_rawgraph_original_fidelity')
  from types import SimpleNamespace
  from vllm_ascend.ascend_forward_context import set_ascend_forward_context
  impl=layer.self_attn.dsa_attn.dsa_attn.impl
  def move(value,key=None):
   if isinstance(value,torch.Tensor):return value.clone() if key=='query_start_loc_cpu' else value.to('npu')
   if isinstance(value,dict):return {k:move(v,k) for k,v in value.items()}
   if isinstance(value,list):return [move(v) for v in value]
   return value
  requests={name:SimpleNamespace(**move(fields)) for name,fields in before['req'].items()}
  prefix=layer.self_attn.dsa_attn.dsa_attn.layer_name
  cos=args['freqs_cos'].view(6,1,1,64);sin=args['freqs_sin'].view(6,1,1,64)
  metadata={name:SimpleNamespace(decode=req,hadamard=h.to(torch.bfloat16)) for name,req in requests.items()}
  for item in requests.values():item.cos={prefix:cos};item.sin={prefix:sin}
  state=caches['compress_state'];inner=caches['inner_compress_state'];packed=caches['idx_native_kv_cache']
  state_view=state.as_strided((24000,2,1,2048),(state.stride(0),2048,2048,1),state.storage_offset())
  inner_view=inner.as_strided((24000,2,1,512),(inner.stride(0),512,512,1),inner.storage_offset())
  key=packed.as_strided((24000,32,1,128),(packed.stride(0),128,128,1),packed.storage_offset())
  scale_storage=packed.view(torch.float16)
  scale=scale_storage.as_strided((24000,32,1,1),(packed.stride(0)//2,1,1,1),scale_storage.storage_offset()+2048)
  kv=(caches['cmp_kv'],caches['kv_cache'],state_view,inner_view,key,scale)
  ordered_meta=[metadata[name] for name in ('compressed','state','indexer_state','indexer','swa')]
  # Same cached static packages as the old whole-model Native. The task's
  # private ASCEND_OPP_PATH prevents modifying the shared CANN payload.
  opp=Path(os.environ['ASCEND_OPP_PATH']).resolve()
  assert opp==a.out.parent/'opp_env/opp' and not (opp/'static_kernel').exists()
  torch.npu.set_compile_mode(jit_compile=False)
  r['explicit_jit_compile']=False;save()
  uq,us=impl.cv_wq_a.quantize(args['native_normed']);uncompiled_qa=host(impl.cv_wq_a.matmul(uq,us))
  from npugraph_ex._acl_concrete_graph import static_kernel
  static_kernel.compile_static_kernel(lambda:None)
  assert (opp/'static_kernel').is_dir(), 'static packages not installed in private task OPP'
  r['static_package_metadata_sha256']=hashlib.sha256((Path(os.environ['LOW_ACCEPTANCE_OFFICIAL_CACHE'])/'metadata.json').read_bytes()).hexdigest()
  assert r['static_package_metadata_sha256']=='863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
  r['private_static_kernel_entries']=sorted(v.name for v in (opp/'static_kernel').iterdir())
  r['static_package_count']=len(static_kernel._installed_run_pkgs);assert r['static_package_count']==13;save()
  observed={};original_qli=torch.ops._C_ascend.npu_vllm_quant_lightning_indexer
  original_sparse=torch.ops._C_ascend.npu_sparse_attn_sharedkv
  original_compact=impl._compute_compressor_metadata
  original_rms=torch.ops._C_ascend.npu_rms_norm_dynamic_quant
  original_wkv=impl.cv_wkv.matmul
  def rms_hook(*inputs,**kwargs):
   value=original_rms(*inputs,**kwargs)
   observed['qa']=inputs[0].clone();observed['qr']=value[0].clone();observed['qr_scale']=value[1].clone()
   return value
  def wkv_hook(*inputs,**kwargs):
   value=original_wkv(*inputs,**kwargs);observed['wkv']=value.clone();return value
  def compact_hook(req):
   value=original_compact(req)
   name='inner' if req is requests['indexer'] else 'cmp'
   observed[name+'_compact']=value;return value
  def qli_hook(*inputs,**kwargs):
   value=original_qli(*inputs,**kwargs);observed['topk']=value[0];observed['qli_inputs']={name:kwargs[name] for name in ('query','weights','query_dequant_scale','actual_seq_lengths_query','actual_seq_lengths_key')};return value
  def sparse_hook(*inputs,**kwargs):
   observed['q']=inputs[0];return original_sparse(*inputs,**kwargs)
  torch.ops._C_ascend.npu_vllm_quant_lightning_indexer=qli_hook;torch.ops._C_ascend.npu_sparse_attn_sharedkv=sparse_hook
  impl._compute_compressor_metadata=compact_hook
  torch.ops._C_ascend.npu_rms_norm_dynamic_quant=rms_hook;impl.cv_wkv.matmul=wkv_hook
  try:
   restore();check_carrier_guards()
   with set_ascend_forward_context({},config,num_tokens=6,num_actual_tokens=6):
    result=impl._forward_decode(prefix,args['native_normed'],kv,ordered_meta)
   torch.npu.synchronize()
   torch.ops._C_ascend.inplace_partial_rotary_mul(result.unsqueeze(1),cos,-sin,rotary_mode='interleave',partial_slice=[448,512])
   torch.npu.synchronize()
  finally:
   torch.ops._C_ascend.npu_vllm_quant_lightning_indexer=original_qli;torch.ops._C_ascend.npu_sparse_attn_sharedkv=original_sparse
   impl._compute_compressor_metadata=original_compact
   torch.ops._C_ascend.npu_rms_norm_dynamic_quant=original_rms;impl.cv_wkv.matmul=original_wkv
  check_carrier_guards()
  assert all(exact(host(args[name]),value) for name,value in frozen.items()),'Native changed immutable original root inputs'
  actual={name:host(value.index_select(0,ids[name])) for name,value in caches.items()}
  actual.update(heads=host(result).reshape(6,32768),topk=host(observed['topk']).reshape(6,512),q=host(observed['q']),qli_inputs={name:host(value) for name,value in observed['qli_inputs'].items()})
  actual['q_stages']={name:host(observed[name]) for name in ('qa','qr','qr_scale','wkv')}
  actual['compact']={tag:[host(v) for v in observed[tag+'_compact']] for tag in ('inner','cmp')}
  torch.save(actual,a.out/'native-components.pt')
  r['Native_components_heads_match_saved_model_gold']=exact(actual['heads'],fixture[20]['heads'])
  r['Native_components_heads_match_original_PTO']=exact(actual['heads'],after['producers']['native_heads']);save()
  # Preserve all outputs above before the first stage equality gate.
  qkvpath=Path('/data/pyptouser/yejia/f6/qkv3/result/qkv.pt')
  qkvresult=json.loads(qkvpath.with_name('result.json').read_text())
  assert qkvresult['pass'] and qkvresult['snapshot_sha256']==a.snapshot_sha
  qkv=torch.load(qkvpath,map_location='cpu',weights_only=True)['native']
  check('STATIC_Q_A_vs_uncompiled_Q_A',actual['q_stages']['qa'],uncompiled_qa)
  check('STATIC_QR_vs_verified_original_PTO_QR',actual['q_stages']['qr'],qkv['qr'])
  check('STATIC_QR_scale_vs_verified_original_PTO_QR_scale',actual['q_stages']['qr_scale'].reshape(6,1),qkv['qr_scale'])
  check('STATIC_Q_vs_verified_original_PTO_Q',actual['q'],qkv['q'])
  check('STATIC_WKV_vs_actual_PTO_WKV',actual['q_stages']['wkv'],after['producers']['wkv_projected'])
  check('STATIC_Indexer_weights_vs_actual_PTO_Indexer',actual['qli_inputs']['weights'],after['producers']['indexer_weights'])
  for tag,slot_name,rope_name in (('inner','idx_slot_mapping','inner_freqs'),('cmp','cmp_slot_mapping','cmp_freqs')):
   c,s,slots=actual['compact'][tag];check('Native_metadata_'+tag+'_slots',slots,after['metadata'][slot_name])
   valid=(slots>=0).all(1)
   check('Native_metadata_'+tag+'_cos_valid',c.reshape(-1,64)[valid],after['metadata'][rope_name+'_cos'][valid])
   check('Native_metadata_'+tag+'_sin_valid',s.reshape(-1,64)[valid],after['metadata'][rope_name+'_sin'][valid])
  # Native decode runs Q/KV, Indexer compressor/QLI, main compressor, attention.
  # Cache physical bytes are compared before downstream heads. Stop at first差.
  for name in ('kv_cache','inner_compress_state','idx_native_kv_cache','compress_state','cmp_kv'):
   value=actual[name];expected=after['caches'][name]
   if name in ('compress_state','inner_compress_state'):
    active=torch.tensor(case['ownership'][name]['active_and_alias_write_pages'],dtype=torch.int64)
    mask=torch.isin(before['page_ids'][name],active)
    assert exact(value[~mask],before['caches'][name][~mask]),('Native unexpected write outside active state/alias pages',name)
    value=value[mask];expected=expected[mask]
   different=value.contiguous().view(torch.uint8)!=expected.contiguous().view(torch.uint8)
   item={'label':'Native_vs_PTO_'+name,'bit_equal':exact(value,expected),'different_bytes':int(different.sum()),'scope':'same original PTO pre-cache; physical bytes'};case['comparisons'].append(item);save()
   if not item['bit_equal']:raise RuntimeError('FIRST_COMPONENT_CACHE_DIFFERENCE '+name)
  check('Native_vs_PTO_topk',actual['topk'],after['producers']['topk'])
  check('Native_vs_PTO_heads',actual['heads'],after['producers']['native_heads'])
  r.update(complete=True);r['pass']=True;r['qualification']='single current Native component execution and original PTO root from the same saved pre-cache; not model Native2';save()
except Exception as e:r['error']=repr(e);save();raise
finally:stack.close()
