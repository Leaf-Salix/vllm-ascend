# 首次FULL6内部精度定位（2026-10-17）

起点6a57a93df；保留step09/c1ef141ae、旧Native1/Native内部快照和原性能版。

- [x] 阅读规则、现有首差证据、HC-pre/Norm/投影实现及观测脚本。
- [x] 固定Native既有step074快照，并核验其与Native stage摘要、实际输入及Native1的绑定。
- [x] 单卡同输入模块对拍，按HC-pre→Norm→WKV→Indexer顺序；第一个差异立即停，max780。
- [x] 图内内部hook只读复制真实输出，检查epoch/地址/poison，沿原入场轨迹复现；不跑Native2或扩大配置。
- [ ] 最早模块证据充分后，对照Native计算/舍入修正独立候选，保持当前基准；CPU/单卡回归再决定原配置复测。
- [ ] 独立审查、记录全部任务和首差/修正结果、完整证据与复现说明。

所有NPU任务通过task-submit、每项max-time780秒；自有目录内工作，不改共享服务/其他用户任务，不开自动调度。

单卡modules1 task_20261017_142207_17398486912 exit0，占卡2m2s：21层×23项=483项全bit0；真实Native step074.pt SHA5b873509016a7419abf5639a808da58950eb2d3d3bd332c00ed8625e00174481，全部field匹配已归档Native stage SHA87fa6b...。范围仅各层Native真实输入的HCpre/Norm BF16/WKV/Indexer三边界，eager与同A rawgraph；不是整模型执行、不包含HCpost/cache、ABA或原FULL144→FULL6切换。


## 继续诊断

- 原轨迹内部hook task_20261017_142615_185987930096，16卡，max780，输出lc128/full6-hook1；当前pending，因已有CI占8卡，未开始占卡。保持队列不改服务/不联系其他线程。
- hook-v1独立review通过，helper manifest ea7a4953be5ad379e910cfd25dbd84a3c2413680ea9a3f5ae4b5b3c9c2f4ed04；无设备preflight exit0。Norm wrapper只在真实PTO op后拷贝其Out，epoch/poison/address/清理沿旧hook；gold为已归档Native2 stage SHA87fa6b...，不新跑Native2。先硬比原失败候选outer前75轮SHAf22dcc...，探针改变输出则停止，不能当修正。
- HCpost-only task_20261017_142936_201817221913，单卡max780，exit0，占卡1m50s。21层×4=84项同真实首差Native input/oproj与NativeHCpre gates，Native先比saved attention_half，再PTO eager/rawgraph，全部bit0。仅同A，不含跨图切换。
- shared-graphs-v1 task_20261017_143400_215743116134，单卡max780，输出f6/shared1。6/144同input/output slab地址、不同有效shape，T6使用真实首差input，144为其重复，仅上下文proxy。先图6与Native6 gold，再74次图144→立即图6无其它GPU操作，再两轮inactive rows6..143 NaN poison后图144→图6；小图8个输出必须gold0且inactive byte不变。范围不含CSA core/cache/Oproj/HCpost或21runtime interleave；不能当原轨迹根因证明。

shared1 task_20261017_143400_215743116134 exit0，占卡1m53s：21层×41=861项bit0，9个输出同base/不同shape已记录，inactive NaN byte guard通过。74次大图后立即小图也bit0，未模拟CSA core/cache/跨层ring/完整Native144输入。原16卡hook仍pending，尚无原轨迹内部首差模块，不做猜测修正。

CPU核对aux实际取样：读取Native step074各层output，BF16 mean后逐一匹配原首差expected aux SHA，精确匹配aux0→L40、aux1→L41、aux2→L42（不是默认EAGLE3的早层公式）。实际采样以此数据绑定为准，不据默认配置推测首差早于CSA。

16卡hook在既有CI完成后已开始运行（约14:39），之前pending约13分钟不占卡。当前无其他自有NPU新任务。

## 原轨迹首差（hook-v1）

任务task_20261017_142615_185987930096按首差exit1，仍为forward74、FULL6、q21。hook outer前75轮与原失败candidate相同；Native阶段首差L20/heads，同层input/positions/normed及之前所有已观测边界相同。heads不同1011/196608，max_abs0.015625，max BF16 ULP237，各行不同数[0,0,357,176,225,253]。尚不能归因为某一attention子模块。任务列表21m39包含约13分钟排队，占卡约9分钟；max-time780秒保持。

prefix-v1任务task_20261017_150141_277081821021 exit0，1m33s。绑定Native stage与rank0原trace SHA，L20真实前75帧按原global bucket NONE21/FULL144/FULL6逐帧扫描，75×9=675比较全bit0。每帧fresh Native Norm先比历史saved gold，再PTO HCpre/Norm/WKV/Indexer；不是新整模型Native2。Native gold操作插在帧间，因此这是逐帧数值扫描，不是无干扰真实cache轨迹。

## hook-v2与QKV子阶段

- hook-v2 task_20261017_150820_28943064164，8m27s，exit1，原L20/heads首差。全部16rank75轮input与Native前缀相同，outer75轮与原失败candidate相同。l20-after.pt已qualified；原捕获descriptor、真实位置、Norm、heads以及读写页覆盖门禁通过。保存cache共有alias：cmp_kv与compress_state同base/page32KB；indexer与inner_state同base/page4160B。
- after SHA782f75c8ccbce27810d56ba16c9969990f0ab7ccb90bb41953fb255f0a77ea42；before SHA3faf46510b167e259013dddc7a6f59412313b112502ca02a64f796abe4eec04f。大快照仅留远端，不放Git。
- qkv-v1 task_20261017_151903_315087018314，1m6s，诊断wrapper的task_dummy缺deps参数，parser退出。actual graph norm/WKV/indexer raw先行对比均bit0；无QKV数值结论。
- qkv-v2 task_20261017_152131_32070925168，1m29s，QKV编译/运行后守卫直接对NZ权重view(uint8)触发TorchNPU Identity/TransData错误；不是QKV数值失败。已在本地qkv-v3改为保持dtype转ND后CPU逐byte核验，不降低数值门禁。
- qkv-v3准备同一快照重测，提交命令未返回任务ID（SSH被服务端关闭）；不假定已提交或通过。core-v1只做后续同cache根重放保真，尚未提交。
- CPU检查真实TopK各行512项唯一、全部在对应可见范围；compact slots含[-1,31]，仅凭负slot存在不能认定Native scatter bug。仓库no-sort/large-index路径有linearIndex范围门禁，实际装载二进制行为仍需证据。

## 同cache进一步隔离

- qkv-v3 task_20261017_152744_333581926588 exit0，1m29：Q/QR/KV/scale eager/rawgraph均bit0。
- core-v1 task_20261017_152950_337800222538，1m44：heads/TopK一致，但整模型结束时未访问的state页有其它阶段写入，不属于独立L20更新。保留该失败记录。
- core-v2 task_20261017_153908_355084717040 exit0，1m30：active state+共享alias写入对original post；未访问页对original pre，PTO保真全部通过。
- native-core-v2 task_20261017_154203_36070664597 exit0，1m29：同actual pre-cache，Native metadata有效行、所有相关cache更新、TopK与heads全部和PTO逐bit一致，但二者均不等于旧整模型Native gold。不能据此修attention数学。
- CPU bank历史核查：q21/L20初始history131346之前32836条压缩KV、Indexer key和scale与actual pre74逐字节一致。仅排除初始历史区损坏，不排除suffix生成cache、物理页布局或原Native graph差异。
- native-graph-v1：新增同pre-cache Native eager/rawgraph单层控制。独立审查已完成；immutables门禁前移到heads之前，不宣称原Native全模型graph已重建。

## 历史写入边界

- Native-graph-v1 task_20261017_155133_377374325645 exit0，1m31：同pre-cache Native eager/rawgraph heads/cache连续两轮bit0，仍不等于旧模型gold。
- raw-history-v1 task_20261017_155808_390762910011 exit0：q21在pre74滑窗内127条历史rawKV，追踪所有query（含被拒绝草稿）的last write，使用真实已存normed和原M144 Native WKV/RMS/RoPE复算，全部bit0。只证明producer重放与PTO缓存当前值一致，不声称已取到旧Native原cache。
- compressor-history-v1待审查：以原bank的q21 state起点、真实step35..73输入、原FULL_DECODE_ONLY均匀padding B24/M144，单层Native compressor生成suffix。私有16页环映射，不能称复制旧Native原物理布局；先gate当前Native compact cos/sin。比较45条续写压缩KV、8条近期state，首差停，不跑新整模型Native2。

- compressor-history-v1 task_20261017_160259_407098313477 exit0：45条续写compressed KV和8条近期主state全bit0；bank seed覆盖、首step35/start131346、compact cos/sin有效行gate均通过。私有16页ring不等于旧Native物理页布局，scope维持限制。
- indexer-history-v1已审查：同历史输入/原M144，inner state stride1040、BF16 Hadamard→INT8动态量化→FP16scale对原生；45条key/scale和8条innerstate首差停。
- 原Native root-fix与当前step09 Native代码核验：DSA/model/device_op/rope/connector相同；worker唯一差异为can_replay允许tnd_full_precision枚举，原tnd_precision和当前full_precision均variable_queries=True。尚未拿到旧Native物理页或metadata直接快照，不能宣称所有运行上下文等价。

- indexer-history-v1 task_20261017_160722_2143614959 exit0：45条历史key、45条FP16scale和8条innerstate全bit0。尚不能代表旧Native物理cache内容直接观测。
- layout-v1已独立审查：空页0不动，对有效物理页作全局双射，同时映射所有typed carrier、root/req tables和slots。每臂先恢复并校验逻辑pre-cache字节相同，再Native/PTO cache/TopK/heads首差门禁；记录Native原/新布局差异，不冒称旧Native实际布局已证实。

- layout-v1 task_20261017_161108_13427332583 exit0：全局物理页反序后逻辑数据硬门禁通过，Native/PTO cache、TopK、heads仍bit0，Native自身前后heads也是0差。本单因素未解释旧gold差异，不把它写成根因。
- 顶层importlib查询不足：初始未导入TorchNPU时npugraph_ex/torchair为None；后续源码证实TorchNPU内嵌两包，经lazy alias加载。不能由顶层None推断没安装或未启用。实际差异是原Native调用13静态缓存包install/reselect，而单层helper此前未执行装载。
- native-forward-v1已审查：先比已保存Native heads→NativeOproj是否复现已存oproj，再实际PTO heads→NativeOproj；然后真实impl.forward（含decode输出copy再inverseRoPE）与精简component对比，避免漏掉真实调用边界。仍为单层同pre-cache，不是新Native2。

- native-forward-v1 task_20261017_161506_22796420172 exit0：saved Native heads→NativeOproj复现savedoproj，actual PTOheads→NativeOproj也复现actualoproj；完整Native.forward（copy后inverseRoPE）仍与component/PTO逐bit一致，仍不匹配oldNativegold。
- static-core-v1待审查：设置OFFICIAL_CACHE，借用同13既有run包，限定任务private opp_env/opp；官方bridge禁止fresh compile并验证manifest、CANN、determinism及包摘要。装载后同precache重拍Q_A→QR→Q→WKV/Indexerweights→cache→heads，首差停，输出先保存是否匹配oldgold。

- static-core-v1 task_20261017_162129_4471475432已提交单卡max780；日志已进入官方13包cache分支，尚待reselect/数值结果。原Native2 rank0.log208/211/212行明确13包加载、真实reselect和installed13，230/233/234在capture阶段再次复用。前述“裸graph”控制与该条件不同，范围已修正，不据其通过宣称整模型精度通过。

## 静态核首差已找到

- staticcore1 task_20261017_162129_4471475432 exit1为数值首差停止。13包cache、真实reselect与installed13通过后，Native heads匹配旧整模型Native gold，PTO原heads不匹配。先保存所有产物，再Q_A/QR/scale/Q门禁均bit0；WKV第[2,204]一元素首差，Native -0.162109375、PTO -0.1630859375，maxabs0.0009765625。后续Index/cache检查未执行，不记通过。
- static-wkv-order-v1待审查：仅原T6、原真实输入/权重、相同13静态包，先Native真实WKV复现该target，再44-family有限数值查询约束K256次序。原wkv_test只换order，真实A+Graph A/B/A及守卫；新WKV送回原root graph，同precache对staticNative cache/TopK/旧Nativeheads。正式数学保持c1ef141ae。

- static-wkv-order-v1 task_20261017_162829_62585030363 exit0，1m55s：32组自然K256序；实际A+Graph A/B/A与Native静态WKV bit0；仅新WKV送原core后cache、TopK、旧gold heads全bit0。正式源码不改。静态配置不足以区分真实装载，后续服务候选必须真实13包验证及actual reselect成功后启用，capture前未知则拒绝。

- static-wkv-service-v1无设备preflight exit0，manifest8efcf4cc87af2549bde0d9f6d7bf9519769c87b80104e513c221455b2a666e0f；独立review无提交阻断。task_20261017_163643_86278520385已提交16卡max780，只走原首FULL6，以savedNative gold验收并主动停止。正式源码、step09及旧表不改。

- 调度参数失误：task_20261017_163643_86278520385 exit1，--device all无效，未占卡/未启动helper。已查task-submit --help，改为--device auto --device-num16重提，保留失败记录。

- 既有WKV CPU3项通过。增量precommit+manualMD lint通过；按仓库要求all-files format.sh ci失败于既有generated/log/import问题，自动修改346个无关tracked文件已全部恢复HEAD。仅保留本次文档+独立证据包。

- static-wkv-service-v1 task_20261017_163746_897257146：FIRST_FULL6_QUALIFIED成立后故意exit1；实际日志16:51:37→17:01:00约9m23s，含清理约10分钟，列表23m27含pending。CPU独立audit exit0：all16 rank各75轮与Native input相同且首FULL6=74、零抢占；每rank精确21CSA capture ready/mode1；rank0全部43层75轮stage+outer与旧Native bit0，前74仍旧candidate不变。所有NPU释放。正式数学仍c1ef，修正限定独立qualified候选，未继续192/后续配置。
