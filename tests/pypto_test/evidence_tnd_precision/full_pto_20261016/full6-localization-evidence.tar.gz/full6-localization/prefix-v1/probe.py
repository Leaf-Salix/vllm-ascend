"""Use saved real Native FULL6 inputs; stop at first module bit difference."""
import argparse,contextlib,hashlib,json,os
from pathlib import Path
import torch,torch_npu,pypto.torch
from vllm.engine.arg_utils import EngineArgs
from vllm.platforms import current_platform
from vllm_ascend.utils import enable_custom_op
from dsv4_csa_single_layer import make_layer
from dsv4_csa_native_case import native_session
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.hc_pre import hc_pre_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.input_norm import input_norm_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv import wkv_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.indexer_projection import indexer_projection
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv_order_data import WKV_COLUMN_ORDERS,WKV_K_ORDERS,WKV_TOKEN_MODES
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.indexer_order_data import INDEXER_K_ORDERS,INDEXER_TILE_ORDERS,INDEXER_TOKEN_MODES

p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
r={'pass':False,'complete':False,'cases':[],'source_commit':'c1ef141ae','saved_step':74,'scope':'L20 real Native prefix frames0..74; padded global bucket, valid rows exact; producer-only replay, no CSA/cache or new Native2'}
def save():(a.out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def exact(x,y):return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def host(x):torch.npu.synchronize();return x.detach().cpu().contiguous()
def check(label,actual,expected):
 actual=host(actual) if actual.device.type!='cpu' else actual
 expected=host(expected) if expected.device.type!='cpu' else expected
 assert actual.shape==expected.shape and actual.dtype==expected.dtype
 assert torch.isfinite(actual).all() and torch.isfinite(expected).all()
 different=(actual.contiguous().view(torch.int16 if actual.element_size()==2 else torch.int32)!=expected.contiguous().view(torch.int16 if expected.element_size()==2 else torch.int32))
 m={'label':label,'bit_equal':exact(actual,expected),'different_elements':int(different.sum()),'max_abs':float((actual.float()-expected.float()).abs().max()),'first_coordinates':different.nonzero()[:8].tolist()}
 case['comparisons'].append(m);save()
 if not m['bit_equal']:
  m['first_values']=[{'index':idx,'actual':actual[tuple(idx)].item(),'expected':expected[tuple(idx)].item()} for idx in m['first_coordinates']];save()
  torch.save({'layer':layer_index,'stage':label,'input':cpu_input,'actual':actual,'expected':expected},a.out/'first-difference.pt')
  raise RuntimeError('FIRST_BIT_DIFFERENCE '+str(layer_index)+' '+label)

base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
native=Path('/data/pyptouser/yejia/lc128/retest192-native2-b24000/full-probe')
payload=native/'step074.pt';r['native_snapshot_sha256']=hashlib.sha256(payload.read_bytes()).hexdigest()
stage_bytes=(native/'stages.jsonl').read_bytes();assert hashlib.sha256(stage_bytes).hexdigest()=='87fa6b787a138a58cafc9b18ddb10554c8ce08b9064f831ecd0a6a105d8a5945'
stages=[json.loads(line) for line in stage_bytes.splitlines()];stage=stages[74]
assert stage['forward_index']==74 and stage['actual_tokens']==6
fixture=torch.load(payload,map_location='cpu',weights_only=True)
for i,fields in fixture.items():
 for name,value in fields.items():
  d={'shape':list(value.shape),'dtype':str(value.dtype),'sha256':hashlib.sha256(value.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()}
  assert d==stage['layers'][str(i)][name],(i,name)
r['native_snapshot_all_fields_match_saved_stage']=True;save()
torch.npu.set_device(0);torch.npu.config.allow_internal_format=True;torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
current_platform.pre_register_and_update();assert enable_custom_op()
checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config=EngineArgs(model=str(checkpoint),tokenizer_mode='deepseek_v4',trust_remote_code=True,tensor_parallel_size=1,dtype='bfloat16',quantization='ascend',hf_overrides={'sliding_window':128},max_model_len=16384,max_num_seqs=40,max_num_batched_tokens=256,enable_prefix_caching=False,enforce_eager=False,block_size=32,speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,'fuse_norm_quant':True,'align_decode_capture_sizes':False},'enable_cpu_binding':False,'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False}).create_engine_config()
stack=contextlib.ExitStack();stack.enter_context(native_session(config,0))
try:
 with torch.inference_mode():
  from vllm_ascend.device.device_op import DeviceOperator
  pypto.torch.init(device=0,platform='a2a3',runtime='tensormap_and_ringbuffer')
  ops={name:pypto.torch.register(fn,'full6_prefix_v1::'+name) for name,fn in (('hc_pre',hc_pre_test),('norm',input_norm_test),('wkv',wkv_test),('indexer',indexer_projection))}
  layer_index=20
  layer,details=make_layer(config,checkpoint,torch.device('npu:0'),layer_index)
  impl=layer.self_attn.dsa_attn.dsa_attn.impl;nwkv=layer.self_attn.wkv;nidx=impl.weights_proj
  wkv=torch_npu.npu_format_cast(nwkv.weight.detach(),2).contiguous();widx=torch_npu.npu_format_cast(nidx.weight.detach(),2).contiguous()
  wo_all=torch.tensor([[WKV_K_ORDERS[i] for i in mode] for mode in WKV_COLUMN_ORDERS],dtype=torch.int32,device='npu')
  io_all=torch.tensor([[[INDEXER_K_ORDERS[i] for i in row] for row in mode] for mode in INDEXER_TILE_ORDERS],dtype=torch.int32,device='npu')
  params=[layer.hc_attn_fn,layer.hc_attn_scale,layer.hc_attn_base,layer.input_layernorm.weight,wkv,widx,wo_all,io_all];frozen=[x.clone() for x in params]
  x_owner=torch.zeros((146,4,4096),dtype=torch.bfloat16,device='npu')
  shapes=(('mixed',4096,torch.bfloat16),('post',4,torch.float32),('comb',16,torch.float32),('normed',4096,torch.bfloat16),('rstd',8,torch.float32),('wkv',512,torch.bfloat16),('indexer_raw',64,torch.bfloat16),('indexer_scaled',64,torch.bfloat16),('indexer_weights',64,torch.float16))
  owners={name:torch.full((146,width),.0625,dtype=dtype,device='npu') for name,width,dtype in shapes}
  views={t:{name:value[1:1+t] for name,value in owners.items()} for t in (6,21,144)};xviews={t:x_owner[:t] for t in views}
  def run(t):
   b=views[t]
   ops['hc_pre'](xviews[t],layer.hc_attn_fn,layer.hc_attn_scale,layer.hc_attn_base,b['mixed'],b['post'],b['comb'])
   ops['norm'](b['mixed'],layer.input_layernorm.weight,b['normed'],b['rstd'])
   ops['wkv'](b['normed'],wkv,wo_all[WKV_TOKEN_MODES[t-1]],b['wkv'])
   ops['indexer'](b['normed'],widx,io_all[INDEXER_TOKEN_MODES[t-1]],b['indexer_raw'],b['indexer_scaled'],b['indexer_weights'])
  graphs={}
  for t in (144,6):
   run(t);torch.npu.synchronize();g=torch.npu.NPUGraph()
   with torch.npu.graph(g):run(t)
   graphs[t]=g
  trace_bytes=(base/'retest192-20261016/native1-generation-reference/input-trace/rank0.trace.jsonl').read_bytes()
  r['native_trace_sha256']=hashlib.sha256(trace_bytes).hexdigest()
  assert r['native_trace_sha256']=='c39ed2c21f2a07aae2ca061af037c8614c242450305c281b76c5d3b8badbf09f'
  traces=[json.loads(line) for line in trace_bytes.splitlines()]
  assert len(traces)==78
  for step in range(75):
   trace=traces[step];n=trace['actual_tokens'];t=trace['padded_tokens'];assert t in (6,21,144)
   assert trace['graph_mode'] in ('NONE','FULL')
   assert (trace['graph_mode']=='NONE' and t==21) or (trace['graph_mode']=='FULL' and t in (6,144))
   case={'layer':20,'forward_index':step,'actual_rows':n,'padded_rows':t,'graph_mode':trace['graph_mode'],'positions':trace['positions'],'keys':trace['keys'],'comparisons':[]};r['cases'].append(case);save()
   state=torch.load(native/f'step{step:03d}.pt',map_location='cpu',weights_only=True,mmap=True)[20]
   for name in ('input','normed'):
    value=state[name];digest={'shape':list(value.shape),'dtype':str(value.dtype),'sha256':hashlib.sha256(value.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()}
    assert digest==stages[step]['layers']['20'][name]
   cpu_input=torch.zeros((t,4,4096),dtype=torch.bfloat16);cpu_input[:n].copy_(state['input'].reshape(n,4,4096));x=xviews[t];x.copy_(cpu_input)
   before=x.clone()
   nm,np,nc=layer.hc_pre(x,layer.hc_attn_fn,layer.hc_attn_scale,layer.hc_attn_base);nn=layer.input_layernorm(nm)
   check('Native_norm_saved_boundary',nn[:n],state['normed'])
   nk=nwkv(nn);ni=nidx(nn);ns=ni*(impl.indexer_softmax_scale*impl.indexer_heads**-0.5)
   gold={'mixed':host(nm[:n]),'post':host(np.reshape(t,4)[:n]),'comb':host(nc.reshape(t,16)[:n]),'normed':host(nn[:n]),'wkv':host(nk[:n]),'indexer_raw':host(ni[:n]),'indexer_scaled':host(ns[:n]),'indexer_weights':host(DeviceOperator.prepare_dsa_indexer_weights(ns)[:n])}
   for name in gold:views[t][name].fill_(float('nan'))
   inactive={name:value[t+1:-1].clone() for name,value in owners.items()}
   if trace['graph_mode']=='NONE':run(t)
   else:graphs[t].replay()
   torch.npu.synchronize()
   assert exact(x,before) and all(exact(v,f) for v,f in zip(params,frozen,strict=True))
   assert all(bool((v[0]==.0625).all() & (v[-1]==.0625).all()) for v in owners.values())
   assert all(exact(owners[name][t+1:-1],old) for name,old in inactive.items())
   for name in gold:check('PTO_'+trace['graph_mode']+'_'+name,views[t][name][:n],gold[name])
   case['pass']=True;save()
  r.update(complete=True);r['pass']=True;save()
except Exception as e:r['error']=repr(e);save();raise
finally:stack.close()
