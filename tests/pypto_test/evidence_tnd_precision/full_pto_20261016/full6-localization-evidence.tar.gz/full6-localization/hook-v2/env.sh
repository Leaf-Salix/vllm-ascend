#!/usr/bin/env bash
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/root-fix-20261016/env.sh"
export PYTHONPATH="$base/full6-localization-20261017/hook-v2:$PYTHONPATH"

export SOURCE_ROOT="$base/full-pto-precision-20261017/step09/source"
export PYTHONPATH="$base/full6-localization-20261017/hook-v2:$SOURCE_ROOT:$SOURCE_ROOT/tests/pypto_test:$PYTHONPATH"
export PTO_CSA_VARIANT=tnd_full_precision
export OMP_NUM_THREADS=10 OMP_PROC_BIND=false
unset LOCAL_WORLD_SIZE
