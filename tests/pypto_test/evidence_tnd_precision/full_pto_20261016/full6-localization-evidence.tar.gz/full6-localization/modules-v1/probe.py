"""Use saved real Native FULL6 inputs; stop at first module bit difference."""
import argparse,contextlib,hashlib,json,os
from pathlib import Path
import torch,torch_npu,pypto.torch
from vllm.engine.arg_utils import EngineArgs
from vllm.platforms import current_platform
from vllm_ascend.utils import enable_custom_op
from dsv4_csa_single_layer import make_layer
from dsv4_csa_native_case import native_session
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.hc_pre import hc_pre_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.input_norm import input_norm_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv import wkv_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.indexer_projection import indexer_projection
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv_order_data import WKV_COLUMN_ORDERS,WKV_K_ORDERS,WKV_TOKEN_MODES
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.indexer_order_data import INDEXER_K_ORDERS,INDEXER_TILE_ORDERS,INDEXER_TOKEN_MODES

p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
r={'pass':False,'complete':False,'cases':[],'source_commit':'c1ef141ae','saved_step':74,'scope':'module-only real Native FULL6 per-layer input, no new Native2/model run/cache comparison'}
def save():(a.out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def exact(x,y):return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def host(x):torch.npu.synchronize();return x.detach().cpu().contiguous()
def check(label,actual,expected):
 actual=host(actual) if actual.device.type!='cpu' else actual
 expected=host(expected) if expected.device.type!='cpu' else expected
 assert actual.shape==expected.shape and actual.dtype==expected.dtype
 assert torch.isfinite(actual).all() and torch.isfinite(expected).all()
 different=(actual.contiguous().view(torch.int16 if actual.element_size()==2 else torch.int32)!=expected.contiguous().view(torch.int16 if expected.element_size()==2 else torch.int32))
 m={'label':label,'bit_equal':exact(actual,expected),'different_elements':int(different.sum()),'max_abs':float((actual.float()-expected.float()).abs().max()),'first_coordinates':different.nonzero()[:8].tolist()}
 case['comparisons'].append(m);save()
 if not m['bit_equal']:
  m['first_values']=[{'index':idx,'actual':actual[tuple(idx)].item(),'expected':expected[tuple(idx)].item()} for idx in m['first_coordinates']];save()
  torch.save({'layer':layer_index,'stage':label,'input':cpu_input,'actual':actual,'expected':expected},a.out/'first-difference.pt')
  raise RuntimeError('FIRST_BIT_DIFFERENCE '+str(layer_index)+' '+label)

base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
native=Path('/data/pyptouser/yejia/lc128/retest192-native2-b24000/full-probe')
payload=native/'step074.pt';r['native_snapshot_sha256']=hashlib.sha256(payload.read_bytes()).hexdigest()
stage_bytes=(native/'stages.jsonl').read_bytes();assert hashlib.sha256(stage_bytes).hexdigest()=='87fa6b787a138a58cafc9b18ddb10554c8ce08b9064f831ecd0a6a105d8a5945'
stages=[json.loads(line) for line in stage_bytes.splitlines()];stage=stages[74]
assert stage['forward_index']==74 and stage['actual_tokens']==6
fixture=torch.load(payload,map_location='cpu',weights_only=True)
for i,fields in fixture.items():
 for name,value in fields.items():
  d={'shape':list(value.shape),'dtype':str(value.dtype),'sha256':hashlib.sha256(value.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()}
  assert d==stage['layers'][str(i)][name],(i,name)
r['native_snapshot_all_fields_match_saved_stage']=True;save()
torch.npu.set_device(0);torch.npu.config.allow_internal_format=True;torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
current_platform.pre_register_and_update();assert enable_custom_op()
checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config=EngineArgs(model=str(checkpoint),tokenizer_mode='deepseek_v4',trust_remote_code=True,tensor_parallel_size=1,dtype='bfloat16',quantization='ascend',hf_overrides={'sliding_window':128},max_model_len=16384,max_num_seqs=40,max_num_batched_tokens=256,enable_prefix_caching=False,enforce_eager=False,block_size=32,speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,'fuse_norm_quant':True,'align_decode_capture_sizes':False},'enable_cpu_binding':False,'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False}).create_engine_config()
stack=contextlib.ExitStack();stack.enter_context(native_session(config,0))
try:
 with torch.inference_mode():
  from vllm_ascend.device.device_op import DeviceOperator
  pypto.torch.init(device=0,platform='a2a3',runtime='tensormap_and_ringbuffer')
  ops={name:pypto.torch.register(fn,'full6_modules_v1::'+name) for name,fn in (('hc_pre',hc_pre_test),('norm',input_norm_test),('wkv',wkv_test),('indexer',indexer_projection))}
  for layer_index in range(2,43,2):
   case={'layer':layer_index,'comparisons':[]};r['cases'].append(case);save()
   layer,details=make_layer(config,checkpoint,torch.device('npu:0'),layer_index)
   cpu_input=fixture[layer_index]['input'];assert tuple(cpu_input.shape)==(6,16384)
   x=cpu_input.to('npu').view(6,4,4096);x_before=x.clone();impl=layer.self_attn.dsa_attn.dsa_attn.impl
   owners={};outputs={}
   def output(name,width,dtype):
    owner=torch.full((8,width),.0625,dtype=dtype,device='npu');owners[name]=owner;outputs[name]=owner[1:-1];return outputs[name]
   mix=output('mixed',4096,torch.bfloat16);post=output('post',4,torch.float32);comb=output('comb',16,torch.float32)
   norm=output('normed',4096,torch.bfloat16);rstd=output('rstd',8,torch.float32);kv=output('wkv',512,torch.bfloat16)
   raw=output('indexer_raw',64,torch.bfloat16);scaled=output('indexer_scaled',64,torch.bfloat16);iw=output('indexer_weights',64,torch.float16)
   nwkv=layer.self_attn.wkv;nidx=impl.weights_proj
   wkv=torch_npu.npu_format_cast(nwkv.weight.detach(),2).contiguous();widx=torch_npu.npu_format_cast(nidx.weight.detach(),2).contiguous()
   wo=torch.tensor([[WKV_K_ORDERS[i] for i in mode] for mode in WKV_COLUMN_ORDERS],dtype=torch.int32,device='npu')[WKV_TOKEN_MODES[5]]
   io=torch.tensor([[[INDEXER_K_ORDERS[i] for i in row] for row in mode] for mode in INDEXER_TILE_ORDERS],dtype=torch.int32,device='npu')[INDEXER_TOKEN_MODES[5]]
   params=[layer.hc_attn_fn,layer.hc_attn_scale,layer.hc_attn_base,layer.input_layernorm.weight,wkv,widx,wo,io]
   frozen=[v.clone() for v in params]
   def guards():
    assert exact(x,x_before)
    assert all(exact(v,old) for v,old in zip(params,frozen,strict=True))
    assert all(bool((v[0]==.0625).all() & (v[-1]==.0625).all()) for v in owners.values())
   native_mix,native_post,native_comb=layer.hc_pre(x,layer.hc_attn_fn,layer.hc_attn_scale,layer.hc_attn_base)
   expected={'mixed':native_mix,'post':native_post.reshape(6,4),'comb':native_comb.reshape(6,16)}
   repeated=layer.hc_pre(x,layer.hc_attn_fn,layer.hc_attn_scale,layer.hc_attn_base)
   for name,value in zip(('mixed','post','comb'),repeated,strict=True):check('Native_repeat_hc_pre_'+name,value.reshape(expected[name].shape),expected[name])
   def hpre():ops['hc_pre'](x,layer.hc_attn_fn,layer.hc_attn_scale,layer.hc_attn_base,mix,post,comb)
   def validate(label,names,run,gold):
    for name in names:outputs[name].fill_(float('nan'))
    run()
    guards()
    for name in names:check(label+'_'+name,outputs[name],gold[name])
   validate('PTO_eager_hc_pre',('mixed','post','comb'),hpre,expected)
   hg=torch.npu.NPUGraph()
   with torch.npu.graph(hg):hpre()
   validate('PTO_graph_hc_pre',('mixed','post','comb'),hg.replay,expected)
   native_norm=layer.input_layernorm(native_mix)
   check('Native_norm_saved_boundary',native_norm,fixture[layer_index]['normed'])
   check('Native_repeat_norm',layer.input_layernorm(native_mix),native_norm)
   def nr():ops['norm'](mix,layer.input_layernorm.weight,norm,rstd)
   validate('PTO_eager_norm',('normed',),nr,{'normed':native_norm})
   ng=torch.npu.NPUGraph()
   with torch.npu.graph(ng):nr()
   validate('PTO_graph_norm',('normed',),ng.replay,{'normed':native_norm})
   native_kv=nwkv(native_norm);check('Native_repeat_wkv',nwkv(native_norm),native_kv)
   def wk():ops['wkv'](norm,wkv,wo,kv)
   validate('PTO_eager_wkv',('wkv',),wk,{'wkv':native_kv})
   wg=torch.npu.NPUGraph()
   with torch.npu.graph(wg):wk()
   validate('PTO_graph_wkv',('wkv',),wg.replay,{'wkv':native_kv})
   raw_gold=nidx(native_norm);scaled_gold=raw_gold*(impl.indexer_softmax_scale*impl.indexer_heads**-0.5);weight_gold=DeviceOperator.prepare_dsa_indexer_weights(scaled_gold)
   check('Native_repeat_indexer',nidx(native_norm),raw_gold)
   def idx():ops['indexer'](norm,widx,io,raw,scaled,iw)
   igold={'indexer_raw':raw_gold,'indexer_scaled':scaled_gold,'indexer_weights':weight_gold}
   validate('PTO_eager_indexer',tuple(igold),idx,igold)
   ig=torch.npu.NPUGraph()
   with torch.npu.graph(ig):idx()
   validate('PTO_graph_indexer',tuple(igold),ig.replay,igold)
   case['pass']=True;save()
  r.update(complete=True,pass_result=True);r['pass']=True;save()
except Exception as e:r['error']=repr(e);save();raise
finally:stack.close()
