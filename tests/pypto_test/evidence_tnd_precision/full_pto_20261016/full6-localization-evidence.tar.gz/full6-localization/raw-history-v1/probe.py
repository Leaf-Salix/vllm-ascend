"""Use saved real Native FULL6 inputs; stop at first module bit difference."""
import argparse,contextlib,hashlib,json,os
from pathlib import Path
import torch,torch_npu,pypto.torch
from vllm.engine.arg_utils import EngineArgs
from vllm.platforms import current_platform
from vllm_ascend.utils import enable_custom_op
from dsv4_csa_single_layer import make_layer
from dsv4_csa_native_case import native_session
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.hc_pre import hc_pre_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.input_norm import input_norm_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv import wkv_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.indexer_projection import indexer_projection
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv_order_data import WKV_COLUMN_ORDERS,WKV_K_ORDERS,WKV_TOKEN_MODES
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.indexer_order_data import INDEXER_K_ORDERS,INDEXER_TILE_ORDERS,INDEXER_TOKEN_MODES

p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--snapshot-sha',required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
r={'pass':False,'complete':False,'cases':[],'source_commit':'c1ef141ae','saved_step':74,'scope':'L20 live rawKV history producer against real saved prior write inputs, no model Native2'}
def save():(a.out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def exact(x,y):return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def host(x):
 if x.device.type!='cpu':
  torch.npu.synchronize()
  if torch_npu.get_npu_format(x) not in (0,2):x=torch_npu.npu_format_cast(x,2)
 return x.detach().cpu().contiguous()
def check(label,actual,expected):
 actual=host(actual) if actual.device.type!='cpu' else actual
 expected=host(expected) if expected.device.type!='cpu' else expected
 assert actual.shape==expected.shape and actual.dtype==expected.dtype
 assert torch.isfinite(actual).all() and torch.isfinite(expected).all()
 different=(actual.contiguous().view(torch.int8 if actual.element_size()==1 else (torch.int16 if actual.element_size()==2 else torch.int32))!=expected.contiguous().view(torch.int8 if expected.element_size()==1 else (torch.int16 if expected.element_size()==2 else torch.int32)))
 m={'label':label,'bit_equal':exact(actual,expected),'different_elements':int(different.sum()),'max_abs':float((actual.float()-expected.float()).abs().max()),'first_coordinates':different.nonzero()[:8].tolist()}
 case['comparisons'].append(m);save()
 if not m['bit_equal']:
  m['first_values']=[{'index':idx,'actual':actual[tuple(idx)].item(),'expected':expected[tuple(idx)].item()} for idx in m['first_coordinates']];save()
  torch.save({'layer':layer_index,'stage':label,'input':cpu_input,'actual':actual,'expected':expected},a.out/'first-difference.pt')
  raise RuntimeError('FIRST_BIT_DIFFERENCE '+str(layer_index)+' '+label)

base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
native=Path('/data/pyptouser/yejia/lc128/retest192-native2-b24000/full-probe')
payload=native/'step074.pt';r['native_snapshot_sha256']=hashlib.sha256(payload.read_bytes()).hexdigest()
stage_bytes=(native/'stages.jsonl').read_bytes();assert hashlib.sha256(stage_bytes).hexdigest()=='87fa6b787a138a58cafc9b18ddb10554c8ce08b9064f831ecd0a6a105d8a5945'
stages=[json.loads(line) for line in stage_bytes.splitlines()];stage=stages[74]
assert stage['forward_index']==74 and stage['actual_tokens']==6
fixture=torch.load(payload,map_location='cpu',weights_only=True)
for i,fields in fixture.items():
 for name,value in fields.items():
  d={'shape':list(value.shape),'dtype':str(value.dtype),'sha256':hashlib.sha256(value.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()}
  assert d==stage['layers'][str(i)][name],(i,name)
r['native_snapshot_all_fields_match_saved_stage']=True;save()
torch.npu.set_device(0);torch.npu.config.allow_internal_format=True;torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
current_platform.pre_register_and_update();assert enable_custom_op()
checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config=EngineArgs(model=str(checkpoint),tokenizer_mode='deepseek_v4',trust_remote_code=True,tensor_parallel_size=1,dtype='bfloat16',quantization='ascend',hf_overrides={'sliding_window':128},max_model_len=16384,max_num_seqs=40,max_num_batched_tokens=256,enable_prefix_caching=False,enforce_eager=False,block_size=32,speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,'fuse_norm_quant':True,'align_decode_capture_sizes':False},'enable_cpu_binding':False,'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False}).create_engine_config()
stack=contextlib.ExitStack();stack.enter_context(native_session(config,0))
try:
 with torch.inference_mode():
  from vllm_ascend.ops.rope_dsv4 import get_cos_and_sin_dsa
  layer_index=20;case={'layer':20,'comparisons':[]};r['cases'].append(case);save()
  layer,details=make_layer(config,checkpoint,torch.device('npu:0'),20)
  impl=layer.self_attn.dsa_attn.dsa_attn.impl
  dump=Path('/data/pyptouser/yejia/lc128/full6-hook2/full-probe/l20-after.pt')
  assert hashlib.sha256(dump.read_bytes()).hexdigest()==a.snapshot_sha
  after=torch.load(dump,map_location='cpu',weights_only=True)
  assert after['qualified']
  before_path=dump.with_name('l20-before.pt')
  assert hashlib.sha256(before_path.read_bytes()).hexdigest()=='3faf46510b167e259013dddc7a6f59412313b112502ca02a64f796abe4eec04f'
  before=torch.load(before_path,map_location='cpu',weights_only=True,mmap=True)
  prefix=layer.self_attn.dsa_attn.dsa_attn.layer_name
  positions=after['metadata']['position_ids'].to('npu')
  c,s=get_cos_and_sin_dsa(positions)
  c=c[prefix].reshape(6,64);s=s[prefix].reshape(6,64)
  cpu_input=fixture[20]['normed']
  check('Native_rope_cos_original_actual',c,after['metadata']['freqs_cos'])
  check('Native_rope_sin_original_actual',s,after['metadata']['freqs_sin'])
  trace_bytes=(base/'retest192-20261016/native1-generation-reference/input-trace/rank0.trace.jsonl').read_bytes()
  assert hashlib.sha256(trace_bytes).hexdigest()=='c39ed2c21f2a07aae2ca061af037c8614c242450305c281b76c5d3b8badbf09f'
  trace=[json.loads(line) for line in trace_bytes.splitlines()]
  first=before['record']['positions'][0];window=128
  latest={}
  for step,row in enumerate(trace[:74]):
   if 'h131072_q21' not in row['keys']:continue
   k=row['keys'].index('h131072_q21');lo,hi=row['query_bounds'][k:k+2]
   for i in range(lo,hi):latest[row['positions'][i]]=(step,i)
  live=list(range(first-window+1,first))
  assert all(pos in latest for pos in live)
  table=before['metadata']['ori_block_table'][0]
  selected=before['page_ids']['kv_cache']
  cache=before['caches']['kv_cache']
  count=0
  for step in sorted({latest[pos][0] for pos in live}):
   row=trace[step];n=row['actual_tokens'];t=row['padded_tokens']
   assert row['graph_mode']=='FULL' and t==144
   original=torch.load(native/f'step{step:03d}.pt',map_location='cpu',weights_only=True,mmap=True)[20]['normed']
   digest={'shape':list(original.shape),'dtype':str(original.dtype),'sha256':hashlib.sha256(original.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()}
   assert digest==stages[step]['layers']['20']['normed']
   x=torch.zeros((t,4096),dtype=torch.bfloat16,device='npu');x[:n].copy_(original)
   projected=impl.wkv(x);kv=impl.kv_norm(projected).view(t,1,512)
   pc,ps=get_cos_and_sin_dsa(torch.tensor(row['padded_positions'],dtype=torch.int64,device='npu'))
   torch.ops._C_ascend.inplace_partial_rotary_mul(kv.unsqueeze(1),pc[prefix],ps[prefix],rotary_mode='interleave',partial_slice=[448,512])
   expected=host(kv).reshape(t,512)
   chosen=[pos for pos in live if latest[pos][0]==step]
   values=[]
   for pos in chosen:
    page=table[pos//32].to(torch.int64);j=torch.searchsorted(selected,page)
    assert int(j)<selected.numel() and selected[j]==page
    values.append(cache[j,pos%32,0])
   actual=torch.stack(values)
   native_value=expected[torch.tensor([latest[pos][1] for pos in chosen])]
   case={'layer':20,'forward_index':step,'positions':chosen,'comparisons':[]};r['cases'].append(case);save()
   check('original_PTO_history_rawKV_vs_Native_'+str(step),actual,native_value)
   count+=len(chosen)
  assert count==127
  r.update(complete=True,pass_scope='127 live rawKV history rows, each compared with Native WKV+RMSNorm+RoPE using its last original write input and original padded M=144',rows=count)
  r['pass']=True;save()
except Exception as e:r['error']=repr(e);save();raise
finally:stack.close()
