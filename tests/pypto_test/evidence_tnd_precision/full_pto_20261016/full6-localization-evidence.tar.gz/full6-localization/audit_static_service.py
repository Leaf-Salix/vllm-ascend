"""首次FULL6独立修正候选的CPU审计；不把主动停止当完整192通过。"""
import argparse
import hashlib
import json
import re
import runpy
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--label',required=True);a=p.parse_args()
base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
root=Path('/data/pyptouser/yejia/lc128')/a.label
reference=base/'retest192-20261016/native1-generation-reference'
native=Path('/data/pyptouser/yejia/lc128/retest192-native2-b24000/full-probe')
original=Path('/data/pyptouser/yejia/lc128/full-pto128k-indexer-production1-20261017/full-probe')
read=lambda p:[json.loads(x) for x in p.read_text().splitlines()]
helper=base/'full6-localization-20261017/static-wkv-service-v1'
assert hashlib.sha256((helper/'helper-manifest.json').read_bytes()).hexdigest()=='8efcf4cc87af2549bde0d9f6d7bf9519769c87b80104e513c221455b2a666e0f'
runpy.run_path(str(helper/'check_inputs.py'))['verify']()
configuration=json.loads((root/'configuration.json').read_text())
assert configuration['production_git_commit']=='c1ef141ae'
assert configuration['source_manifest_sha256']=='d997d41080882209007134564ca488ce19cfe7f136397b6fd0e389c929001638'
for key,name in [('bootstrap_sha256','sitecustomize.py'),('witness_sha256','capture_boundaries.py'),('full_probe_sha256','full_probe.py')]:
 assert configuration[key]==hashlib.sha256((helper/name).read_bytes()).hexdigest()
manifest=json.loads((base/'full-pto-precision-20261017/step09/manifest.json').read_text())
for name,digest in manifest['files'].items():
 assert hashlib.sha256((base/'full-pto-precision-20261017/step09/source'/name).read_bytes()).hexdigest()==digest,name
expected_static_sha='863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
assert configuration['official_static_cache_sha256']==expected_static_sha
expected_csa={int(i) for i,fields in read(native/'stages.jsonl')[74]['layers'].items() if 'normed' in fields}
assert len(expected_csa)==21
report={'pass':False,'scope':'all16 input prefix; rank0 all watched stages/outer through first FULL6 only','traces':{},'captures':{}}
assert hashlib.sha256((native/'stages.jsonl').read_bytes()).hexdigest()=='87fa6b787a138a58cafc9b18ddb10554c8ce08b9064f831ecd0a6a105d8a5945'
assert not (root/'full-probe/STOP.json').exists()
success=json.loads((root/'full-probe/FIRST_FULL6_QUALIFIED.json').read_text())
assert success['complete'] and success['pass'] and success['forward_index']==74 and success['records']==75
assert success['qualification']['ready'] and success['qualification']['capture6'] and success['qualification']['live6']
assert success['qualification']['metadata_sha']==expected_static_sha
for rank in range(16):
 actual=read(root/f'input-trace/rank{rank}.trace.jsonl')
 expected=read(reference/f'input-trace/rank{rank}.trace.jsonl')
 assert len(actual)>=75
 for i in range(len(actual)):
  assert {k:v for k,v in actual[i].items() if k!='execute_index'}=={k:v for k,v in expected[i].items() if k!='execute_index'},(rank,i)
 assert not any(x['preempted_keys'] for x in actual)
 assert actual[74]['graph_mode']=='FULL' and actual[74]['actual_tokens']==actual[74]['padded_tokens']==6
 selections=[]
 log=(root/f'rank{rank}.log').read_text()
 assert 'OFFICIAL_STATIC_CACHE packages=13 metadata_sha='+expected_static_sha in log
 assert 'OFFICIAL_STATIC_RESELECT success=1' in log and 'WKV_STATIC_QUALIFIED ' in log
 if rank==0:assert 'OFFICIAL_STATIC_INSTALLED verified_packages=13' in log
 for line in log.splitlines():
  prefix='WKV_SERVICE_SELECTION '
  if prefix in line:selections.append(json.loads(line.split(prefix,1)[1]))
 captured={x['layer'] for x in selections if x['capture']}
 indices={int(re.search(r'\.layers\.(\d+)\.',name).group(1)) for name in captured}
 assert indices==expected_csa and len(captured)==len(expected_csa),(rank,indices)
 assert all(x['ready'] and x['mode']==1 for x in selections if x['capture'])
 first_full6=next(x['forward_index'] for x in actual if x['graph_mode']=='FULL' and x['padded_tokens']==6)
 assert first_full6==74,(rank,first_full6)
 report['traces'][rank]={'records':len(actual),'first_FULL6':next(x['forward_index'] for x in actual if x['graph_mode']=='FULL' and x['padded_tokens']==6),'preemptions':0}
 report['captures'][rank]=sorted(captured)
stages=read(root/'full-probe/stages.jsonl');gold=read(native/'stages.jsonl')
outer=read(root/'full-probe/outer.jsonl');expected=read(reference/'full-probe/outer.jsonl')
assert len(stages)==len(outer)==75
assert stages==gold[:75]
assert outer==expected[:75]
assert outer[:74]==read(original/'outer.jsonl')[:74]
report.update(pass_=True,rank0_stages=75,watched_layers=43,rank0_outer_equal=True,original_first74_unchanged=True,qualification=success['qualification'])
report['pass']=report.pop('pass_')
(root/'first-full6-qualified-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
