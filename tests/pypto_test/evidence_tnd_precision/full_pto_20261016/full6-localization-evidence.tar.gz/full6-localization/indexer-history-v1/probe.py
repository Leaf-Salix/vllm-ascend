"""Use saved real Native FULL6 inputs; stop at first module bit difference."""
import argparse,contextlib,hashlib,json,os
from pathlib import Path
import torch,torch_npu,pypto.torch
from vllm.engine.arg_utils import EngineArgs
from vllm.platforms import current_platform
from vllm_ascend.utils import enable_custom_op
from dsv4_csa_single_layer import make_layer
from dsv4_csa_native_case import native_session
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.hc_pre import hc_pre_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.input_norm import input_norm_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv import wkv_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.indexer_projection import indexer_projection
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv_order_data import WKV_COLUMN_ORDERS,WKV_K_ORDERS,WKV_TOKEN_MODES
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.indexer_order_data import INDEXER_K_ORDERS,INDEXER_TILE_ORDERS,INDEXER_TOKEN_MODES

p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--snapshot-sha',required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
r={'pass':False,'complete':False,'cases':[],'source_commit':'c1ef141ae','saved_step':74,'scope':'L20 Native Indexer key compressor history reconstruction against original PTO pre74, no model Native2'}
def save():(a.out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def exact(x,y):return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def host(x):
 if x.device.type!='cpu':
  torch.npu.synchronize()
  if torch_npu.get_npu_format(x) not in (0,2):x=torch_npu.npu_format_cast(x,2)
 return x.detach().cpu().contiguous()
def check(label,actual,expected):
 actual=host(actual) if actual.device.type!='cpu' else actual
 expected=host(expected) if expected.device.type!='cpu' else expected
 assert actual.shape==expected.shape and actual.dtype==expected.dtype
 assert torch.isfinite(actual).all() and torch.isfinite(expected).all()
 different=(actual.contiguous().view(torch.int8 if actual.element_size()==1 else (torch.int16 if actual.element_size()==2 else torch.int32))!=expected.contiguous().view(torch.int8 if expected.element_size()==1 else (torch.int16 if expected.element_size()==2 else torch.int32)))
 m={'label':label,'bit_equal':exact(actual,expected),'different_elements':int(different.sum()),'max_abs':float((actual.float()-expected.float()).abs().max()),'first_coordinates':different.nonzero()[:8].tolist()}
 case['comparisons'].append(m);save()
 if not m['bit_equal']:
  m['first_values']=[{'index':idx,'actual':actual[tuple(idx)].item(),'expected':expected[tuple(idx)].item()} for idx in m['first_coordinates']];save()
  torch.save({'layer':layer_index,'stage':label,'input':cpu_input,'actual':actual,'expected':expected},a.out/'first-difference.pt')
  raise RuntimeError('FIRST_BIT_DIFFERENCE '+str(layer_index)+' '+label)

base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
native=Path('/data/pyptouser/yejia/lc128/retest192-native2-b24000/full-probe')
payload=native/'step074.pt';r['native_snapshot_sha256']=hashlib.sha256(payload.read_bytes()).hexdigest()
stage_bytes=(native/'stages.jsonl').read_bytes();assert hashlib.sha256(stage_bytes).hexdigest()=='87fa6b787a138a58cafc9b18ddb10554c8ce08b9064f831ecd0a6a105d8a5945'
stages=[json.loads(line) for line in stage_bytes.splitlines()];stage=stages[74]
assert stage['forward_index']==74 and stage['actual_tokens']==6
fixture=torch.load(payload,map_location='cpu',weights_only=True)
for i,fields in fixture.items():
 for name,value in fields.items():
  d={'shape':list(value.shape),'dtype':str(value.dtype),'sha256':hashlib.sha256(value.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()}
  assert d==stage['layers'][str(i)][name],(i,name)
r['native_snapshot_all_fields_match_saved_stage']=True;save()
torch.npu.set_device(0);torch.npu.config.allow_internal_format=True;torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
current_platform.pre_register_and_update();assert enable_custom_op()
checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config=EngineArgs(model=str(checkpoint),tokenizer_mode='deepseek_v4',trust_remote_code=True,tensor_parallel_size=1,dtype='bfloat16',quantization='ascend',hf_overrides={'sliding_window':128},max_model_len=16384,max_num_seqs=40,max_num_batched_tokens=256,enable_prefix_caching=False,enforce_eager=False,block_size=32,speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,'fuse_norm_quant':True,'align_decode_capture_sizes':False},'enable_cpu_binding':False,'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False}).create_engine_config()
stack=contextlib.ExitStack();stack.enter_context(native_session(config,0))
try:
 with torch.inference_mode():
  from safetensors import safe_open
  from scipy.linalg import hadamard
  from vllm_ascend.attention.dsa_v1 import rotate_activation
  from vllm_ascend.device.device_op import DeviceOperator
  from vllm_ascend.ops.rope_dsv4 import get_full_cos_and_sin_dsa
  layer_index=20;case={'layer':20,'comparisons':[]};r['cases'].append(case);save()
  layer,details=make_layer(config,checkpoint,torch.device('npu:0'),20)
  impl=layer.self_attn.dsa_attn.dsa_attn.impl
  dump=Path('/data/pyptouser/yejia/lc128/full6-hook2/full-probe/l20-after.pt')
  assert hashlib.sha256(dump.read_bytes()).hexdigest()==a.snapshot_sha
  after=torch.load(dump,map_location='cpu',weights_only=True);assert after['qualified']
  prepath=dump.with_name('l20-before.pt')
  assert hashlib.sha256(prepath.read_bytes()).hexdigest()=='3faf46510b167e259013dddc7a6f59412313b112502ca02a64f796abe4eec04f'
  before=torch.load(prepath,map_location='cpu',weights_only=True,mmap=True)
  bank=base/'low-acceptance-128k-b24-20261014/banks/fixed131072/h131072_q21/tp0'
  manifest=json.loads((bank/'manifest.json').read_text());assert manifest['history']==131346
  trace_bytes=(base/'retest192-20261016/native1-generation-reference/input-trace/rank0.trace.jsonl').read_bytes()
  assert hashlib.sha256(trace_bytes).hexdigest()=='c39ed2c21f2a07aae2ca061af037c8614c242450305c281b76c5d3b8badbf09f'
  trace=[json.loads(line) for line in trace_bytes.splitlines()]
  key='h131072_q21';owner_index=21;columns=65785;pages_per_key=16;pages=1+24*pages_per_key
  storage=torch.zeros((pages,1040),dtype=torch.float32,device='npu')
  state=storage.as_strided((pages,2,512),(1040,512,1))
  h=torch.tensor(hadamard(128,dtype=float),dtype=torch.bfloat16,device='npu')
  full_columns=torch.arange(columns,dtype=torch.int32)
  owners={f'h131072_q{i:02d}':1+i*pages_per_key+(full_columns%pages_per_key) for i in range(24)}
  name='model.layers.20.self_attn.indexer.compressor.state_cache__0';entry=manifest['entries'][name]
  with safe_open(str(bank/'cache.safetensors'),framework='pt',device='cpu') as handle:initial=handle.get_tensor(name)
  first_row=next(row for row in trace[:74] if key in row['keys'])
  first_q=first_row['keys'].index(key)
  assert first_row['forward_index']==35 and first_row['positions'][first_q*6]==manifest['history']
  assert initial.dtype==torch.float32 and list(initial.shape)==[len(entry['logical_blocks']),2,1,512]
  needed={pos//2 for pos in range(manifest['history']-7,manifest['history'])}
  assert needed.issubset(set(entry['logical_blocks'])),('missing initial pooling state',needed)
  r['bank_manifest_sha256']=hashlib.sha256((bank/'manifest.json').read_bytes()).hexdigest()
  r['seed_tensor_sha256']=hashlib.sha256(initial.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()
  r['first_q21_step']=35;r['first_q21_position']=manifest['history'];r['seed_required_logical_pages']=sorted(needed);save()
  seed_pages=owners[key][torch.tensor(entry['logical_blocks'])].to(torch.int64)
  assert torch.unique(seed_pages).numel()==len(entry['logical_blocks'])
  state.index_copy_(0,seed_pages.to('npu'),initial.squeeze(2).to('npu'))
  assert exact(host(state.index_select(0,seed_pages.to('npu'))),initial.squeeze(2))
  full_cos,full_sin=get_full_cos_and_sin_dsa('c4')
  full_cos=full_cos.reshape(-1,64);full_sin=full_sin.reshape(-1,64)
  # Verify the exact Native full-cache rows at the captured first FULL6 gate.
  c,s,slots=torch.ops._C_ascend.compressor_metadata(full_cos,full_sin,after['metadata']['query_start_loc'].to('npu'),torch.tensor([131524],dtype=torch.int32,device='npu'),after['metadata']['idx_block_table'].to('npu'),32,DeviceOperator.get_dsa_compressor_slot_mapping_format(),4,2,1)
  valid=(host(slots)>=0).all(1)
  cpu_input=fixture[20]['normed']
  check('Native_compact_cos_actual_gate',host(c).reshape(-1,64)[valid],after['metadata']['inner_freqs_cos'][valid])
  check('Native_compact_sin_actual_gate',host(s).reshape(-1,64)[valid],after['metadata']['inner_freqs_sin'][valid])
  bounds=torch.arange(25,dtype=torch.int32,device='npu')*6
  generated={};sources={};history=[]
  for step,row in enumerate(trace[:74]):
   if key not in row['keys']:continue
   n=row['actual_tokens'];t=row['padded_tokens'];keys=row['keys'];q=keys.index(key)
   assert row['graph_mode']=='FULL' and t==144 and all(v==6 for v in row['query_lengths'])
   # Original full_decode_only path pads uniform batches to B=144/6.
   assert n==len(keys)*6 and row['query_bounds']==list(range(0,n+1,6))
   original=torch.load(native/f'step{step:03d}.pt',map_location='cpu',weights_only=True,mmap=True)[20]['normed']
   digest={'shape':list(original.shape),'dtype':str(original.dtype),'sha256':hashlib.sha256(original.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()}
   assert digest==stages[step]['layers']['20']['normed']
   x=torch.zeros((144,4096),dtype=torch.bfloat16,device='npu');x[:n].copy_(original)
   starts=torch.zeros((24,),dtype=torch.int32);table=torch.zeros((24,columns),dtype=torch.int32)
   for i,k in enumerate(keys):
    starts[i]=row['positions'][i*6];table[i]=owners[k]
   table=table.to('npu');starts=starts.to('npu')
   comp_table=torch.zeros((24,1028),dtype=torch.int32,device='npu');comp_table[q].copy_(torch.arange(1,1029,dtype=torch.int32,device='npu'))
   c,s,slots=torch.ops._C_ascend.compressor_metadata(full_cos,full_sin,bounds,starts,comp_table,32,DeviceOperator.get_dsa_compressor_slot_mapping_format(),4,60,len(keys))
   value=torch.ops._C_ascend.compressor(x,impl.indexcom_wkv.weight,impl.indexcom_wgate.weight,state,impl.indexcom_ape,impl.indexcom_norm.weight,s.reshape(-1,64),c.reshape(-1,64),state_block_table=table,cu_seqlens=bounds,seqused=None,start_pos=starts,rope_head_dim=64,cmp_ratio=4,coff=2,norm_eps=impl.compressor_norm_eps,rotary_mode=2,cache_mode=1)
   if impl.indexcom_rotate:value=rotate_activation(value,h)
   key_values,scales=torch_npu.npu_dynamic_quant(value,dst_type=torch.int8)
   scales=scales.to(torch.float16).reshape(-1)
   torch.npu.synchronize();value=host(key_values);scales=host(scales);slots=host(slots)
   assert value.shape[0]==slots.shape[0]
   records=[]
   for i,(page,offset) in enumerate(slots.tolist()):
    if page>0 and offset>=0:
     index=(page-1)*32+offset
     generated[index]={'key':value[i].clone(),'scale':scales[i].clone()};sources[index]=step;records.append(index)
   history.append({'step':step,'q21_start':row['positions'][q*6],'compressed_rows':records})
   r['progress_step']=step;save()
  expected_indices=list(range(manifest['history']//4,131524//4))
  assert sorted(generated)==expected_indices,(sorted(generated),expected_indices)
  torch.save({'generated':generated,'sources':sources,'history':history,'final_state':host(state.index_select(0,owners[key][torch.arange(65758,65762)].to('npu').long()))},a.out/'native-history.pt')
  r['history']=history;r['scope']='q21 Native Indexer compressor/Hadamard/dynamic quant suffix reconstruction with original M144/B24 uniform padded grouping and saved per-frame normed inputs; private ring page IDs; not original Native full graph cache';save()
  for index in expected_indices:
   page=before['metadata']['idx_block_table'][0,index//32].long();selected=before['page_ids']['idx_native_kv_cache'];j=torch.searchsorted(selected,page)
   assert int(j)<selected.numel() and selected[j]==page
   packed=before['caches']['idx_native_kv_cache'][j]
   actual=packed[:4096].reshape(32,128)[index%32]
   actual_scale=packed[4096:].contiguous().view(torch.float16)[index%32:index%32+1]
   case={'layer':20,'compressed_index':index,'last_write_step':sources[index],'comparisons':[]};r['cases'].append(case);save()
   check('original_PTO_Indexer_key_history_vs_Native_'+str(index),actual,generated[index]['key'])
   check('original_PTO_Indexer_scale_history_vs_Native_'+str(index),actual_scale,generated[index]['scale'].reshape(1))
  for pos in range(131516,131524):
   oldpage=before['metadata']['inner_state_block_table'][0,pos//2].long();selected=before['page_ids']['inner_compress_state'];j=torch.searchsorted(selected,oldpage)
   assert int(j)<selected.numel() and selected[j]==oldpage
   actual=before['caches']['inner_compress_state'][j,(pos%2)*512:(pos%2+1)*512]
   newpage=owners[key][pos//2].item()
   expected=host(state[newpage,pos%2])
   case={'layer':20,'state_position':pos,'comparisons':[]};r['cases'].append(case);save()
   check('original_PTO_inner_state_history_vs_Native_'+str(pos),actual,expected)
  r.update(complete=True,compressed_rows=len(expected_indices),state_rows=8);r['pass']=True;save()
except Exception as e:r['error']=repr(e);save();raise
finally:stack.close()
