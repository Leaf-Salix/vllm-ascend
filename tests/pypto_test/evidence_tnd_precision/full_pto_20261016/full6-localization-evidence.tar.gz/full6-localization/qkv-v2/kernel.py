"""直接复用当前正式Q/KV inline函数，只发布它的边界。"""
import pypto.language as pl
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.qkv_proj_rope import qkv_proj_rope
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.nz_mode import BF16_WEIGHT_LAYOUT, QUANT_WEIGHT_LAYOUT

T = pl.dynamic('FULL6_PROBE_QKV_T')


@pl.jit
def qkv_probe(
    x: pl.Tensor[[T, 4096], pl.BF16],
    wq_a: pl.Tensor[[1024, 4096], pl.BF16, BF16_WEIGHT_LAYOUT],
    wq_b: pl.Tensor[[1024, 32768], pl.INT8, QUANT_WEIGHT_LAYOUT],
    wq_b_scale: pl.Tensor[[32768], pl.FP32],
    wkv: pl.Tensor[[4096, 512], pl.BF16],
    cos: pl.Tensor[[T, 64], pl.FP32],
    sin: pl.Tensor[[T, 64], pl.FP32],
    gamma_q: pl.Tensor[[1024], pl.BF16],
    gamma_kv: pl.Tensor[[512], pl.BF16],
    projected: pl.Tensor[[T, 512], pl.BF16],
    q: pl.Out[pl.Tensor[[T, 64, 512], pl.BF16]],
    kv: pl.Out[pl.Tensor[[T, 512], pl.BF16]],
    qr: pl.Out[pl.Tensor[[T, 1024], pl.INT8]],
    qr_scale: pl.Out[pl.Tensor[[T, 1], pl.FP32]],
):
    x.bind_dynamic(0, T)
    q.bind_dynamic(0, T)
    kv.bind_dynamic(0, T)
    qr.bind_dynamic(0, T)
    qr_scale.bind_dynamic(0, T)
    dep = pl.system.task_dummy(deps=[])
    q, marker = qkv_proj_rope(x, wq_a, wq_b, wq_b_scale, wkv, cos, sin, gamma_q, gamma_kv,
                              q, kv, qr, qr_scale, dep, projected)
    return q, kv, qr, qr_scale
