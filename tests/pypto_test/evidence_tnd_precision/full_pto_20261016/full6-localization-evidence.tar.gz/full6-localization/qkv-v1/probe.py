"""Use saved real Native FULL6 inputs; stop at first module bit difference."""
import argparse,contextlib,hashlib,json,os
from pathlib import Path
import torch,torch_npu,pypto.torch
from vllm.engine.arg_utils import EngineArgs
from vllm.platforms import current_platform
from vllm_ascend.utils import enable_custom_op
from dsv4_csa_single_layer import make_layer
from dsv4_csa_native_case import native_session
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.hc_pre import hc_pre_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.input_norm import input_norm_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv import wkv_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.indexer_projection import indexer_projection
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv_order_data import WKV_COLUMN_ORDERS,WKV_K_ORDERS,WKV_TOKEN_MODES
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.indexer_order_data import INDEXER_K_ORDERS,INDEXER_TILE_ORDERS,INDEXER_TOKEN_MODES

p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--snapshot-sha',required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
r={'pass':False,'complete':False,'cases':[],'source_commit':'c1ef141ae','saved_step':74,'scope':'L20 actual first FULL6 normed/producer/rope; QKV primitive eager/rawgraph against same Native operations; not a new model Native2'}
def save():(a.out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def exact(x,y):return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def host(x):torch.npu.synchronize();return x.detach().cpu().contiguous()
def check(label,actual,expected):
 actual=host(actual) if actual.device.type!='cpu' else actual
 expected=host(expected) if expected.device.type!='cpu' else expected
 assert actual.shape==expected.shape and actual.dtype==expected.dtype
 assert torch.isfinite(actual).all() and torch.isfinite(expected).all()
 different=(actual.contiguous().view(torch.int8 if actual.element_size()==1 else (torch.int16 if actual.element_size()==2 else torch.int32))!=expected.contiguous().view(torch.int8 if expected.element_size()==1 else (torch.int16 if expected.element_size()==2 else torch.int32)))
 m={'label':label,'bit_equal':exact(actual,expected),'different_elements':int(different.sum()),'max_abs':float((actual.float()-expected.float()).abs().max()),'first_coordinates':different.nonzero()[:8].tolist()}
 case['comparisons'].append(m);save()
 if not m['bit_equal']:
  m['first_values']=[{'index':idx,'actual':actual[tuple(idx)].item(),'expected':expected[tuple(idx)].item()} for idx in m['first_coordinates']];save()
  torch.save({'layer':layer_index,'stage':label,'input':cpu_input,'actual':actual,'expected':expected},a.out/'first-difference.pt')
  raise RuntimeError('FIRST_BIT_DIFFERENCE '+str(layer_index)+' '+label)

base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
native=Path('/data/pyptouser/yejia/lc128/retest192-native2-b24000/full-probe')
payload=native/'step074.pt';r['native_snapshot_sha256']=hashlib.sha256(payload.read_bytes()).hexdigest()
stage_bytes=(native/'stages.jsonl').read_bytes();assert hashlib.sha256(stage_bytes).hexdigest()=='87fa6b787a138a58cafc9b18ddb10554c8ce08b9064f831ecd0a6a105d8a5945'
stages=[json.loads(line) for line in stage_bytes.splitlines()];stage=stages[74]
assert stage['forward_index']==74 and stage['actual_tokens']==6
fixture=torch.load(payload,map_location='cpu',weights_only=True)
for i,fields in fixture.items():
 for name,value in fields.items():
  d={'shape':list(value.shape),'dtype':str(value.dtype),'sha256':hashlib.sha256(value.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()}
  assert d==stage['layers'][str(i)][name],(i,name)
r['native_snapshot_all_fields_match_saved_stage']=True;save()
torch.npu.set_device(0);torch.npu.config.allow_internal_format=True;torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
current_platform.pre_register_and_update();assert enable_custom_op()
checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config=EngineArgs(model=str(checkpoint),tokenizer_mode='deepseek_v4',trust_remote_code=True,tensor_parallel_size=1,dtype='bfloat16',quantization='ascend',hf_overrides={'sliding_window':128},max_model_len=16384,max_num_seqs=40,max_num_batched_tokens=256,enable_prefix_caching=False,enforce_eager=False,block_size=32,speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,'fuse_norm_quant':True,'align_decode_capture_sizes':False},'enable_cpu_binding':False,'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False}).create_engine_config()
stack=contextlib.ExitStack();stack.enter_context(native_session(config,0))
try:
 with torch.inference_mode():
  from kernel import qkv_probe
  from vllm_ascend.device.device_op import DeviceOperator
  from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.native_adapter import prepare_weights
  pypto.torch.init(device=0,platform='a2a3',runtime='tensormap_and_ringbuffer')
  layer_index=20;case={'layer':20,'comparisons':[]};r['cases'].append(case);save()
  layer,details=make_layer(config,checkpoint,torch.device('npu:0'),20)
  impl=layer.self_attn.dsa_attn.dsa_attn.impl
  dump=Path('/data/pyptouser/yejia/lc128/full6-hook2/full-probe/l20-after.pt')
  r['snapshot_sha256']=hashlib.sha256(dump.read_bytes()).hexdigest();assert r['snapshot_sha256']==a.snapshot_sha
  values=torch.load(dump,map_location='cpu',weights_only=True)
  assert values['qualified'] and values['record']['forward_index']==74
  cpu_input=fixture[20]['input'];check('actual_graph_norm_saved_gold',values['producers']['normed'],fixture[20]['normed'])
  x=values['producers']['normed'].to('npu');projected=values['producers']['wkv_projected'].to('npu')
  cos=values['metadata']['freqs_cos'].to('npu');sin=values['metadata']['freqs_sin'].to('npu')
  check('actual_graph_WKV_Native',projected,impl.wkv(x))
  for key,actual in (('indexer_projection_raw',impl.weights_proj(x)),):check('actual_graph_'+key,values['producers'][key],actual)
  weights=prepare_weights(layer.self_attn,None,layer)
  qa=impl.wq_a(x)
  nqr,nscale=torch.ops._C_ascend.npu_rms_norm_dynamic_quant(qa,impl.q_norm.weight,epsilon=impl.eps)
  nq=torch_npu.npu_quant_matmul(nqr,impl.wq_b.weight,impl.wq_b.weight_scale,pertoken_scale=nscale,bias=impl.wq_b.bias,output_dtype=x.dtype).unflatten(-1,(64,512))
  nq=DeviceOperator.apply_dsa_q_rms(nq,impl.eps,impl.q_norm_without_weight)
  native_cos=cos.view(6,1,1,64);native_sin=sin.view(6,1,1,64)
  torch.ops._C_ascend.inplace_partial_rotary_mul(nq.unsqueeze(1),native_cos,native_sin,rotary_mode='interleave',partial_slice=[448,512])
  nk=impl.kv_norm(projected).view(6,1,512)
  torch.ops._C_ascend.inplace_partial_rotary_mul(nk.unsqueeze(1),native_cos,native_sin,rotary_mode='interleave',partial_slice=[448,512])
  gold={'qr':host(nqr),'qr_scale':host(nscale).reshape(6,1),'kv':host(nk).reshape(6,512),'q':host(nq)}
  owners={name:torch.full((8,*value.shape[1:]),-117 if value.dtype==torch.int8 else .0625,dtype=value.dtype,device='npu') for name,value in gold.items()}
  outputs={name:value[1:7] for name,value in owners.items()}
  args=(x,weights['wq_a'],weights['wq_b'],weights['wq_b_scale'],weights['wkv'],cos,sin,weights['gamma_cq'],weights['gamma_ckv'],projected,*[outputs[k] for k in ('q','kv','qr','qr_scale')])
  frozen=[v.clone() for v in args[:10]]
  op=pypto.torch.register(qkv_probe,'full6_qkv_v1::qkv')
  def poison():
   for name,value in outputs.items():
    if value.dtype==torch.int8:value.copy_(torch.bitwise_xor(gold[name],127).to('npu'))
    else:value.fill_(float('nan'))
  def guard():
   assert all(exact(v,old) for v,old in zip(args[:10],frozen,strict=True))
   assert all(bool((v[0]==(-117 if v.dtype==torch.int8 else .0625)).all() & (v[-1]==(-117 if v.dtype==torch.int8 else .0625)).all()) for v in owners.values())
  poison();op(*args);torch.npu.synchronize();guard()
  for name in ('qr','qr_scale','kv','q'):check('eager_'+name,outputs[name],gold[name])
  g=torch.npu.NPUGraph()
  with torch.npu.graph(g):op(*args)
  poison()
  g.replay();torch.npu.synchronize();guard()
  for name in ('qr','qr_scale','kv','q'):check('graph_'+name,outputs[name],gold[name])
  torch.save({'native':gold,'pto':{k:host(v) for k,v in outputs.items()},'record':values['record']},a.out/'qkv.pt')
  r.update(complete=True);r['pass']=True;save()
except Exception as e:r['error']=repr(e);save();raise
finally:stack.close()
