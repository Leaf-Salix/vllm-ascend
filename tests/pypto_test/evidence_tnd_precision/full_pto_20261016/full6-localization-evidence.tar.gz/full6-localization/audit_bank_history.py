"""CPU-only: compare untouched L20 prefix cache with the original q21 bank."""
import hashlib
import json
from pathlib import Path

import torch
from safetensors import safe_open

base = Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
bank = base / 'low-acceptance-128k-b24-20261014/banks/fixed131072/h131072_q21/tp0'
manifest_bytes = (bank / 'manifest.json').read_bytes()
manifest = json.loads(manifest_bytes)
snapshot = Path('/data/pyptouser/yejia/lc128/full6-hook2/full-probe/l20-before.pt')
before = torch.load(snapshot, map_location='cpu', weights_only=True, mmap=True)
r = {'scope': 'Only immutable prefix rows preceding initial bank history; actual original PTO pre-step74 snapshot, CPU only',
     'history': manifest['history'], 'manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(), 'comparisons': []}
# Compact data retain all historical rows. State and SWA data have already been
# overwritten by the real suffix and cannot be compared directly to this bank.
items = [('attn__0', 'cmp_kv', 'cmp_block_table', None),
         ('indexer.k_cache__0', 'idx_native_kv_cache', 'idx_block_table', 'key'),
         ('indexer.k_cache__1', 'idx_native_kv_cache', 'idx_block_table', 'scale')]
with safe_open(str(bank / 'cache.safetensors'), framework='pt', device='cpu') as handle:
    for suffix, cache_name, table_name, part in items:
        name = 'model.layers.20.self_attn.' + suffix
        entry = manifest['entries'][name]
        reference = handle.get_tensor(name)
        packed = before['caches'][cache_name]
        if part == 'key':
            current = packed[:, :4096].reshape(-1, 32, 1, 128)
        elif part == 'scale':
            current = packed[:, 4096:].contiguous().view(torch.float16).reshape(-1, 32, 1, 1)
        else:
            current = packed
        table = before['metadata'][table_name][0].to(torch.int64)
        logical = torch.tensor(entry['logical_blocks'], dtype=torch.int64)
        physical = table[logical]
        selected = before['page_ids'][cache_name]
        offsets = torch.searchsorted(selected, physical)
        assert bool((offsets < selected.numel()).all())
        assert torch.equal(selected[offsets], physical)
        actual = current.index_select(0, offsets)
        valid = logical[:, None] * entry['block_size'] + torch.arange(entry['block_size'])[None, :] < manifest['history'] // entry['compress_ratio']
        actual = actual[valid].contiguous()
        expected = reference[valid].contiguous()
        assert actual.shape == expected.shape and actual.dtype == expected.dtype
        diff = actual.view(torch.uint8).reshape(actual.shape[0], -1) != expected.view(torch.uint8).reshape(expected.shape[0], -1)
        r['comparisons'].append({'name': name, 'rows': actual.shape[0], 'bit_equal': torch.equal(actual.view(torch.uint8), expected.view(torch.uint8)),
                                 'different_rows': int(diff.any(1).sum()), 'different_bytes': int(diff.sum()),
                                 'first_rows': diff.any(1).nonzero().flatten()[:12].tolist()})
r['pass'] = all(item['bit_equal'] for item in r['comparisons'])
print(json.dumps(r, indent=2))
