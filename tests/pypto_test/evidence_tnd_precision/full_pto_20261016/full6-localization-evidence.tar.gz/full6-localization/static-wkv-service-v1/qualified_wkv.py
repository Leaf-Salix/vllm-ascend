"""独立限定修正：原13包验证和实际reselect完成后才允许自然序T6。"""
import hashlib
import json
import os
from pathlib import Path

METADATA_SHA = '863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
qualification = {'ready': False, 'capture6': False, 'live6': False, 'metadata_sha': METADATA_SHA}


def install_static(module):
    original = module.compile_static_kernel

    def compile_qualified(*args, **kwargs):
        import torch_npu
        metadata = Path(os.environ['LOW_ACCEPTANCE_OFFICIAL_CACHE']) / 'metadata.json'
        assert hashlib.sha256(metadata.read_bytes()).hexdigest() == METADATA_SHA
        actual = torch_npu.npu._aclnn_reselect_static_kernel
        reselected = []

        def tracked(*values, **options):
            result = actual(*values, **options)
            reselected.append(True)
            return result

        torch_npu.npu._aclnn_reselect_static_kernel = tracked
        try:
            # Original bridge validates exact packages/SDK/determinism and denies fresh compilation.
            result = original(*args, **kwargs)
        finally:
            torch_npu.npu._aclnn_reselect_static_kernel = actual
        assert reselected, 'No actual static reselection'
        qualification['ready'] = True
        print('WKV_STATIC_QUALIFIED ' + json.dumps(qualification), flush=True)
        return result

    module.compile_static_kernel = compile_qualified


def install_service():
    import torch
    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision import service
    if getattr(service.CSAServiceRuntime.__call__, '_qualified_wkv', False):
        return
    original = service.CSAServiceRuntime.__call__
    baseline = service.WKV_TOKEN_MODES
    assert baseline[5] == 0
    assert service.WKV_COLUMN_ORDERS[1] == (0,) * 32
    assert service.WKV_K_ORDERS[0] == tuple(range(16))
    corrected = baseline[:5] + (1,) + baseline[6:]
    seen = set()

    def forward(runtime, context, hidden, positions, output, kv_cache):
        tokens = hidden.shape[0]
        capture = torch.npu.is_current_stream_capturing()
        # Before actual installation eager warmup retains the original qualification.
        service.WKV_TOKEN_MODES = corrected if qualification['ready'] else baseline
        if tokens == 6:
            if capture:
                assert qualification['ready'], 'FULL6 capture before verified static reselection'
                qualification['capture6'] = True
            elif qualification['capture6']:
                qualification['live6'] = True
            key = (runtime.layer_name, qualification['ready'], capture)
            if key not in seen:
                seen.add(key)
                print('WKV_SERVICE_SELECTION ' + json.dumps({'layer': runtime.layer_name,
                      'tokens': tokens, 'capture': capture, 'ready': qualification['ready'],
                      'mode': service.WKV_TOKEN_MODES[5]}), flush=True)
        return original(runtime, context, hidden, positions, output, kv_cache)

    forward._qualified_wkv = True
    service.CSAServiceRuntime.__call__ = forward
