"""Bind the untouched 128K bank, Native1 and current source before execution."""
import hashlib
import json
from pathlib import Path

BASE = Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
JOB = BASE/'full6-localization-20261017/static-wkv-service-v1'
NATIVE = Path('/data/pyptouser/yejia/lc128/retest192-native1-b24000')
REFERENCE = BASE/'retest192-20261016/native1-generation-reference'
SOURCE = BASE/'full-pto-precision-20261017/step09'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def verify():
    assert sha(SOURCE/'manifest.json') == 'd997d41080882209007134564ca488ce19cfe7f136397b6fd0e389c929001638'
    assert sha(REFERENCE/'manifest.json') == '347b452c4eed32897b54bd05305a317708fbea987ffeab1ad1ac1461f9153dac'
    config = json.loads((NATIVE/'configuration.json').read_text())
    assert config['backend'] == 'native' and config['batch'] == 24
    assert config['num_gpu_blocks_override'] == 24000 and config['decode_tokens'] == 192
    bank = Path(config['bank'])
    assert sha(bank/'plan.json') == config['bank_plan_sha256'] == 'b4ca67ee33bdf5f1ddadcd9578e437865e15bacfcb6fdf45094f431abb704a1e'
    plan = json.loads((bank/'plan.json').read_text())
    assert [case['key'] for case in plan['cases']] == [f'h131072_q{i:02d}' for i in range(24)]
    for case in plan['cases']:
        assert (bank/case['tokens']).is_file()
    binding = json.loads((REFERENCE/'manifest.json').read_text())
    assert Path(binding['raw_source']) == NATIVE
    for name, digest in binding['source_sha256'].items():
        assert sha(NATIVE/name) == digest, name
    for name, digest in binding['derived_sha256'].items():
        assert sha(REFERENCE/name) == digest, name
    assert sha(Path('/data/pyptouser/yejia/lc128/retest192-native2-b24000/full-probe/stages.jsonl')) == '87fa6b787a138a58cafc9b18ddb10554c8ce08b9064f831ecd0a6a105d8a5945'
    identity = json.loads((JOB/'helper-manifest.json').read_text())
    for name, digest in identity['files'].items():
        assert sha(JOB/name) == digest, name
    print(json.dumps({'bank':str(bank),'native':str(NATIVE),'reference':str(REFERENCE),'source_manifest_sha256':sha(SOURCE/'manifest.json'),'helper_manifest_sha256':sha(JOB/'helper-manifest.json'),'scope':'plan and token files; Native evidence and derived reference fully hashed; bank tensor payloads not rehashed'}))

if __name__ == '__main__':
    verify()
