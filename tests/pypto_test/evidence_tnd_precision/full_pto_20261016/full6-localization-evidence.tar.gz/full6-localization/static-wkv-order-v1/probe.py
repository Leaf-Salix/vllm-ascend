"""Use saved real Native FULL6 inputs; stop at first module bit difference."""
import argparse,contextlib,hashlib,json,os
from pathlib import Path
import torch,torch_npu,pypto.torch
from vllm.engine.arg_utils import EngineArgs
from vllm.platforms import current_platform
from vllm_ascend.utils import enable_custom_op
from dsv4_csa_single_layer import make_layer
from dsv4_csa_native_case import native_session
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.hc_pre import hc_pre_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.input_norm import input_norm_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv import wkv_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.indexer_projection import indexer_projection
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv_order_data import WKV_COLUMN_ORDERS,WKV_K_ORDERS,WKV_TOKEN_MODES
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.indexer_order_data import INDEXER_K_ORDERS,INDEXER_TILE_ORDERS,INDEXER_TOKEN_MODES

p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--snapshot-sha',required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
r={'pass':False,'complete':False,'cases':[],'source_commit':'c1ef141ae','saved_step':74,'scope':'L20 real first FULL6 core replay with original selected physical pages; gate original PTO heads/cache before Native component reference, no model Native2'}
def save():(a.out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def exact(x,y):return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def host(x):
 if x.device.type!='cpu':
  torch.npu.synchronize()
  if torch_npu.get_npu_format(x) not in (0,2):x=torch_npu.npu_format_cast(x,2)
 return x.detach().cpu().contiguous()
def check(label,actual,expected):
 actual=host(actual) if actual.device.type!='cpu' else actual
 expected=host(expected) if expected.device.type!='cpu' else expected
 assert actual.shape==expected.shape and actual.dtype==expected.dtype
 assert torch.isfinite(actual).all() and torch.isfinite(expected).all()
 different=(actual.contiguous().view(torch.int8 if actual.element_size()==1 else (torch.int16 if actual.element_size()==2 else torch.int32))!=expected.contiguous().view(torch.int8 if expected.element_size()==1 else (torch.int16 if expected.element_size()==2 else torch.int32)))
 m={'label':label,'bit_equal':exact(actual,expected),'different_elements':int(different.sum()),'max_abs':float((actual.float()-expected.float()).abs().max()),'first_coordinates':different.nonzero()[:8].tolist()}
 case['comparisons'].append(m);save()
 if not m['bit_equal']:
  m['first_values']=[{'index':idx,'actual':actual[tuple(idx)].item(),'expected':expected[tuple(idx)].item()} for idx in m['first_coordinates']];save()
  torch.save({'layer':layer_index,'stage':label,'input':cpu_input,'actual':actual,'expected':expected},a.out/'first-difference.pt')
  raise RuntimeError('FIRST_BIT_DIFFERENCE '+str(layer_index)+' '+label)

base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
native=Path('/data/pyptouser/yejia/lc128/retest192-native2-b24000/full-probe')
payload=native/'step074.pt';r['native_snapshot_sha256']=hashlib.sha256(payload.read_bytes()).hexdigest()
stage_bytes=(native/'stages.jsonl').read_bytes();assert hashlib.sha256(stage_bytes).hexdigest()=='87fa6b787a138a58cafc9b18ddb10554c8ce08b9064f831ecd0a6a105d8a5945'
stages=[json.loads(line) for line in stage_bytes.splitlines()];stage=stages[74]
assert stage['forward_index']==74 and stage['actual_tokens']==6
fixture=torch.load(payload,map_location='cpu',weights_only=True)
for i,fields in fixture.items():
 for name,value in fields.items():
  d={'shape':list(value.shape),'dtype':str(value.dtype),'sha256':hashlib.sha256(value.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()}
  assert d==stage['layers'][str(i)][name],(i,name)
r['native_snapshot_all_fields_match_saved_stage']=True;save()
torch.npu.set_device(0);torch.npu.config.allow_internal_format=True;torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
current_platform.pre_register_and_update();assert enable_custom_op()
checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config=EngineArgs(model=str(checkpoint),tokenizer_mode='deepseek_v4',trust_remote_code=True,tensor_parallel_size=1,dtype='bfloat16',quantization='ascend',hf_overrides={'sliding_window':128},max_model_len=16384,max_num_seqs=40,max_num_batched_tokens=256,enable_prefix_caching=False,enforce_eager=False,block_size=32,speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,'fuse_norm_quant':True,'align_decode_capture_sizes':False},'enable_cpu_binding':False,'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False}).create_engine_config()
stack=contextlib.ExitStack();stack.enter_context(native_session(config,0))
try:
 with torch.inference_mode():
  from scipy.linalg import hadamard
  from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.native_adapter import prepare_weights,CSAOperators
  pypto.torch.init(device=0,platform='a2a3',runtime='tensormap_and_ringbuffer')
  layer_index=20;case={'layer':20,'comparisons':[]};r['cases'].append(case);save()
  layer,details=make_layer(config,checkpoint,torch.device('npu:0'),20)
  dump=Path('/data/pyptouser/yejia/lc128/full6-hook2/full-probe/l20-after.pt')
  r['snapshot_sha256']=hashlib.sha256(dump.read_bytes()).hexdigest();assert r['snapshot_sha256']==a.snapshot_sha
  after=torch.load(dump,map_location='cpu',weights_only=True)
  r['before_snapshot_sha256']=hashlib.sha256(dump.with_name('l20-before.pt').read_bytes()).hexdigest()
  assert r['before_snapshot_sha256']=='3faf46510b167e259013dddc7a6f59412313b112502ca02a64f796abe4eec04f'
  before=torch.load(dump.with_name('l20-before.pt'),map_location='cpu',weights_only=True)
  assert after['qualified'] and after['record']==before['record'] and after['page_ids'].keys()==before['page_ids'].keys()
  for name in after['page_ids']:assert exact(after['page_ids'][name],before['page_ids'][name])
  cpu_input=fixture[20]['input'];check('actual_graph_norm_saved_gold',after['producers']['normed'],fixture[20]['normed'])
  h=torch.tensor(hadamard(128,dtype=float),dtype=torch.float32,device='npu')
  weights=prepare_weights(layer.self_attn,h,layer)
  # Native compressed/state and indexer/inner_state are alternative typed
  # descriptors of the same physical allocation. Preserve aliases and page IDs.
  carriers={};caches={};guarded_carriers={}
  for name,spec in before['cache_specs'].items():
   dtype=before['caches'][name].dtype;page_bytes=before['caches'][name][0].numel()*before['caches'][name].element_size()
   key=spec['data_ptr'];shape=(spec['shape'][0],page_bytes)
   if key not in carriers:
    import math
    guard_bytes=math.lcm(page_bytes,512)
    owner=torch.full((shape[0]*page_bytes+2*guard_bytes,),37,dtype=torch.int8,device='npu')
    guarded_carriers[key]=(owner,guard_bytes)
    carriers[key]=owner[guard_bytes:-guard_bytes].reshape(shape);carriers[key].zero_()
   assert tuple(carriers[key].shape)==shape
   caches[name]=carriers[key].view(dtype).reshape(spec['shape'])
   assert list(caches[name].stride())==spec['stride']
  for left,ls in before['cache_specs'].items():
   for right,rs in before['cache_specs'].items():
    assert (caches[left].data_ptr()==caches[right].data_ptr()) == (ls['data_ptr']==rs['data_ptr'])
  ids={name:pages.to('npu') for name,pages in before['page_ids'].items()}
  initial={name:value.to('npu') for name,value in before['caches'].items()}
  def restore():
   for name,value in initial.items():caches[name].index_copy_(0,ids[name],value)
  args={**weights,**{name:value.to('npu') for name,value in after['metadata'].items()},**caches}
  args.update(x_hc=cpu_input.reshape(6,4,4096).to('npu'),native_normed=after['producers']['normed'].to('npu'),native_kv_projected=after['producers']['wkv_projected'].to('npu'),native_indexer_weights=after['producers']['indexer_weights'].to('npu'),native_heads=torch.empty((6,32768),dtype=torch.bfloat16,device='npu'),idx_topk=torch.empty((6,512),dtype=torch.int32,device='npu'),idx_topk_scores=torch.empty((6,512),dtype=torch.float32,device='npu'),x_out=torch.empty((6,4,4096),dtype=torch.bfloat16,device='npu'))
  op=CSAOperators.register().attention
  names=[v.name for v in op._schema.arguments];ordered=[args[name] for name in names]
  frozen={name:host(value).clone() for name,value in args.items() if name not in caches and name not in ('native_heads','idx_topk','idx_topk_scores','x_out')}
  def check_carrier_guards():
   assert all(bool((owner[:count]==37).all() & (owner[-count:]==37).all()) for owner,count in guarded_carriers.values()),'page carrier guard modified'
  def check_replay(label):
   check_carrier_guards()
   assert all(exact(host(args[name]),value) for name,value in frozen.items()),'input/metadata/weight mutation'
   check(label+'_heads',args['native_heads'],after['producers']['native_heads'])
   check(label+'_topk',args['idx_topk'],after['producers']['topk'])
   for name in caches:
    value=host(caches[name].index_select(0,ids[name]));expected=after['caches'][name]
    if name in ('compress_state','inner_compress_state'):
     table='state_block_table' if name=='compress_state' else 'inner_state_block_table'
     other_slot='cmp_slot_mapping' if name=='compress_state' else 'idx_slot_mapping'
     positions=after['record']['positions'];assert after['record']['query_bounds']==[0,6]
     assert positions==list(range(positions[0],positions[0]+6))
     # A conservative superset of the actual C4 8-token pool reads and six
     # commits. Full table tails contain stale pages belonging to other groups.
     active=after['metadata'][table][0,max(0,positions[0]-8)//2:positions[-1]//2+1].to(torch.int64)
     slots=after['metadata'][other_slot];alias_writes=slots[(slots>=0).all(1),0].to(torch.int64)
     active=torch.unique(torch.cat((active,alias_writes)));active=active[active>=0]
     direct_slot='state_slot_mapping' if name=='compress_state' else 'inner_state_slot_mapping'
     writers=after['metadata'][direct_slot];writers=writers[(writers>=0).all(1),0].to(torch.int64)
     assert torch.isin(writers,active).all(),('state writer outside declared window',name)
     all_pages=before['page_ids'][name];assert torch.isin(active,all_pages).all()
     mask=torch.isin(all_pages,active)
     assert exact(value[~mask],before['caches'][name][~mask]),('unexpected write outside active state/alias pages',name)
     case.setdefault('ownership',{})[name]={'active_and_alias_write_pages':active.tolist(),'unaccessed_pages_unchanged_from_pre':True,'original_model_post_unaccessed_may_change':not exact(expected[~mask],before['caches'][name][~mask])};save()
     value=value[mask];expected=expected[mask]
    different=value.contiguous().view(torch.uint8)!=expected.contiguous().view(torch.uint8)
    item={'label':label+'_'+name,'bit_equal':exact(value,expected),'different_bytes':int(different.sum()),'scope':'physical bytes, including typed alias/padding; no FP32 finite/numeric claim'}
    case['comparisons'].append(item);save()
    if not item['bit_equal']:
     torch.save({'stage':item['label'],'actual':value,'expected':expected},a.out/'first-cache-difference.pt')
     raise RuntimeError('STANDALONE_PTO_FIDELITY_CACHE '+name)
  restore();args['native_heads'].fill_(float('nan'));args['idx_topk'].fill_(-777);op(*ordered);torch.npu.synchronize();check_replay('PTO_eager_original_fidelity')
  restore();g=torch.npu.NPUGraph()
  with torch.npu.graph(g):op(*ordered)
  restore();args['native_heads'].fill_(float('nan'));args['idx_topk'].fill_(-777)
  g.replay();torch.npu.synchronize();check_replay('PTO_rawgraph_original_fidelity')
  from types import SimpleNamespace
  from vllm_ascend.ascend_forward_context import set_ascend_forward_context
  impl=layer.self_attn.dsa_attn.dsa_attn.impl
  def move(value,key=None):
   if isinstance(value,torch.Tensor):return value.clone() if key=='query_start_loc_cpu' else value.to('npu')
   if isinstance(value,dict):return {k:move(v,k) for k,v in value.items()}
   if isinstance(value,list):return [move(v) for v in value]
   return value
  requests={name:SimpleNamespace(**move(fields)) for name,fields in before['req'].items()}
  prefix=layer.self_attn.dsa_attn.dsa_attn.layer_name
  cos=args['freqs_cos'].view(6,1,1,64);sin=args['freqs_sin'].view(6,1,1,64)
  metadata={name:SimpleNamespace(decode=req,hadamard=h.to(torch.bfloat16)) for name,req in requests.items()}
  for item in requests.values():item.cos={prefix:cos};item.sin={prefix:sin}
  state=caches['compress_state'];inner=caches['inner_compress_state'];packed=caches['idx_native_kv_cache']
  state_view=state.as_strided((24000,2,1,2048),(state.stride(0),2048,2048,1),state.storage_offset())
  inner_view=inner.as_strided((24000,2,1,512),(inner.stride(0),512,512,1),inner.storage_offset())
  key=packed.as_strided((24000,32,1,128),(packed.stride(0),128,128,1),packed.storage_offset())
  scale_storage=packed.view(torch.float16)
  scale=scale_storage.as_strided((24000,32,1,1),(packed.stride(0)//2,1,1,1),scale_storage.storage_offset()+2048)
  kv=(caches['cmp_kv'],caches['kv_cache'],state_view,inner_view,key,scale)
  ordered_meta=[metadata[name] for name in ('compressed','state','indexer_state','indexer','swa')]
  # Same cached static packages as the old whole-model Native. The task's
  # private ASCEND_OPP_PATH prevents modifying the shared CANN payload.
  opp=Path(os.environ['ASCEND_OPP_PATH']).resolve()
  assert opp==a.out.parent/'opp_env/opp' and not (opp/'static_kernel').exists()
  torch.npu.set_compile_mode(jit_compile=False)
  r['explicit_jit_compile']=False;save()
  uq,us=impl.cv_wq_a.quantize(args['native_normed']);uncompiled_qa=host(impl.cv_wq_a.matmul(uq,us))
  from npugraph_ex._acl_concrete_graph import static_kernel
  static_kernel.compile_static_kernel(lambda:None)
  assert (opp/'static_kernel').is_dir(), 'static packages not installed in private task OPP'
  r['static_package_metadata_sha256']=hashlib.sha256((Path(os.environ['LOW_ACCEPTANCE_OFFICIAL_CACHE'])/'metadata.json').read_bytes()).hexdigest()
  assert r['static_package_metadata_sha256']=='863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
  r['private_static_kernel_entries']=sorted(v.name for v in (opp/'static_kernel').iterdir())
  r['static_package_count']=len(static_kernel._installed_run_pkgs);assert r['static_package_count']==13;save()
  root_case=case
  original_core_graph=g
  target_path=Path('/data/pyptouser/yejia/f6/staticcore1/result/native-components.pt')
  assert hashlib.sha256(target_path.read_bytes()).hexdigest()=='5db189411b6da8ade71c5cc30bacead04eb5a4d21de81f2f55ab6cb5ef9fff09'
  assert hashlib.sha256(target_path.with_name('result.json').read_bytes()).hexdigest()=='790800d2bf297a8f644a7c6fe913f3a128cf8cd010bf6a996781d94f50525603'
  target_report=json.loads(target_path.with_name('result.json').read_text())
  assert target_report['snapshot_sha256']==a.snapshot_sha and target_report['Native_components_heads_match_saved_model_gold']
  assert target_report['static_package_count']==13 and target_report['static_package_metadata_sha256']==r['static_package_metadata_sha256']
  target=torch.load(target_path,map_location='cpu',weights_only=True)
  x=args['native_normed'];original_x=host(x)
  nq,ns=impl.cv_wkv.quantize(x);current=impl.cv_wkv.matmul(nq,ns)
  check('cached_static_WKV_reproduces_first_difference_target',current,target['q_stages']['wkv'])
  check('Flinear_is_same_static_Native_WKV_boundary',torch.nn.functional.linear(x,impl.wkv.weight),target['q_stages']['wkv'])
  orders=[]
  for width in (1,2,4,8,16):
   for direction in (1,-1):
    for start in range(16//width):
     order=tuple(((start+direction*i)%(16//width))*width+j for i in range(16//width) for j in range(width))
     if order not in orders:orders.append(order)
  triples=[(0,5,11),(6,7,8),(2,9,12),(4,6,14),(1,13,15),(3,10,11)]
  last={q:[max(q,key=o.index) for o in orders] for q in triples}
  signatures=[tuple(last[q][i] for q in triples) for i in range(len(orders))];assert len(set(signatures))==len(orders)
  case={'layer':20,'phase':'finite_Native_order_queries','comparisons':[],'queries':[]};r['cases'].append(case);save()
  candidates=[set(range(len(orders))) for _ in range(32)]
  full_x=torch.ones((6,4096),dtype=torch.bfloat16,device='npu')
  for q in triples:
   flags=[]
   for small in q:
    rest=[k for k in q if k!=small];w=torch.zeros((512,4096),dtype=torch.bfloat16)
    w[:,rest[0]*256]=1;w[:,rest[1]*256]=-1;w[:,small*256]=2**-25
    weight=torch_npu.npu_format_cast(w.to('npu'),29)
    value=torch.nn.functional.linear(full_x,weight);repeat=torch.nn.functional.linear(full_x,weight)
    check('Native_order_repeat_'+str(q)+'_'+str(small),value,repeat)
    v=host(value)
    assert bool(((v==0)|(v==2**-25)).all()),'unexpected finite query value'
    assert exact(v,v[0:1].expand_as(v).contiguous()),'row dependent reduction'
    assert exact(v[0].reshape(32,16),v[0,::16,None].expand(32,16).contiguous()),'sub16 column variation'
    flags.append(v[0,::16]==2**-25)
   bits=torch.stack(flags);assert bool((bits.sum(0)==1).all()),'not one serial last block'
   observed=[q[int(i)] for i in bits.to(torch.int64).argmax(0)]
   candidates=[{i for i in c if last[q][i]==v} for c,v in zip(candidates,observed)]
   case['queries'].append({'triple':list(q),'last_by_column_group':observed,'candidate_counts':[len(c) for c in candidates]});save()
   assert all(candidates),'44-family order hypothesis rejected'
  assert all(len(c)==1 for c in candidates),'ambiguous order'
  selected=[list(orders[next(iter(c))]) for c in candidates]
  r['static_T6_order']=selected;r['order_hypothesis']='44 unique cycles of contiguous K256 groups; constrained by finite queries, not a universal source proof';save()
  from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv import wkv_test
  wkv_op=pypto.torch.register(wkv_test,'full6_static_wkv_order_v1::candidate')
  order_tensor=torch.tensor(selected,dtype=torch.int32,device='npu')
  weight=torch_npu.npu_format_cast(impl.wkv.weight.detach(),2).contiguous()
  output_owner=torch.full((8,512),.0625,dtype=torch.bfloat16,device='npu');output=output_owner[1:7]
  frozen_weight=host(weight);frozen_order=host(order_tensor)
  def wkv_guard(expected_input):
   assert exact(host(x),expected_input) and exact(host(weight),frozen_weight) and exact(host(order_tensor),frozen_order)
   assert bool((output_owner[0]==.0625).all() & (output_owner[-1]==.0625).all()),'candidate WKV output guard modified'
  output.fill_(float('nan'));wkv_op(x,weight,order_tensor,output);torch.npu.synchronize()
  wkv_guard(original_x)
  check('candidate_actual_A_eager_WKV',output,target['q_stages']['wkv'])
  input_b=torch.roll(original_x,1,1)+torch.tensor(.03125,dtype=torch.bfloat16)
  gold_b=host(torch.nn.functional.linear(input_b.to('npu'),impl.wkv.weight))
  assert not exact(input_b,original_x) and not exact(gold_b,target['q_stages']['wkv']),'B phase has no observable effect'
  g=torch.npu.NPUGraph()
  with torch.npu.graph(g):wkv_op(x,weight,order_tensor,output)
  for label,value,gold in (('A',original_x,target['q_stages']['wkv']),('B',input_b,gold_b),('A2',original_x,target['q_stages']['wkv'])):
   x.copy_(value);output.fill_(float('nan'));g.replay();torch.npu.synchronize()
   wkv_guard(value)
   check('candidate_actual_graph_'+label,output,gold)
  assert exact(host(x),original_x)
  # Apply exactly the candidate WKV output at the existing root argument.
  args['native_kv_projected'].copy_(output)
  candidate_frozen={name:host(args[name]).clone() for name in frozen}
  case={'layer':20,'phase':'single_factor_WKV_corrected_original_core','comparisons':[]};r['cases'].append(case);save()
  restore();args['native_heads'].fill_(float('nan'));args['idx_topk'].fill_(-777);original_core_graph.replay();torch.npu.synchronize();check_carrier_guards()
  assert all(exact(host(args[name]),value) for name,value in candidate_frozen.items()),'candidate mutated immutable root input'
  actual={name:host(value.index_select(0,ids[name])) for name,value in caches.items()}
  actual.update(heads=host(args['native_heads']),topk=host(args['idx_topk']))
  torch.save(actual,a.out/'candidate-root.pt')
  for name in ('kv_cache','inner_compress_state','idx_native_kv_cache','compress_state','cmp_kv'):
   value=actual[name];expected=target[name]
   if name in ('compress_state','inner_compress_state'):
    active=torch.tensor(root_case['ownership'][name]['active_and_alias_write_pages'],dtype=torch.int64)
    mask=torch.isin(before['page_ids'][name],active)
    assert exact(value[~mask],before['caches'][name][~mask]),('candidate changed unaccessed page',name)
    value=value[mask];expected=expected[mask]
   item={'label':'WKV_fixed_root_vs_static_Native_'+name,'bit_equal':exact(value,expected),'different_bytes':int((value.contiguous().view(torch.uint8)!=expected.contiguous().view(torch.uint8)).sum())}
   case['comparisons'].append(item);save()
   if not item['bit_equal']:raise RuntimeError('FIRST_WKV_CANDIDATE_CACHE_DIFFERENCE '+name)
  check('WKV_fixed_root_TopK_vs_static_Native',actual['topk'],target['topk'])
  check('WKV_fixed_root_heads_vs_old_model_Native_gold',actual['heads'],fixture[20]['heads'])
  r.update(complete=True);r['pass']=True;r['qualification']='only WKV K256 order changed; original input/metadata/pre-cache and core retained; current first FULL6 same-input single-layer proof, not full model192';save()
except Exception as e:r['error']=repr(e);save();raise
finally:stack.close()
