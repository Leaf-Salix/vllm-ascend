"""核验原失败、hook失败和保存Native的共同执行前缀；仅CPU JSON。"""
import argparse
import hashlib
import json
from pathlib import Path

root = Path('/data/pyptouser/yejia/lc128')
parser = argparse.ArgumentParser()
parser.add_argument('--label', choices=('full6-hook1', 'full6-hook2'), default='full6-hook1')
probe = root/parser.parse_args().label
native = root/'retest192-native2-b24000/full-probe'
reference = Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/retest192-20261016/native1-generation-reference')
original = root/'full-pto128k-indexer-production1-20261017/full-probe'
read = lambda p: [json.loads(line) for line in p.read_text().splitlines()]
report = {'traces': {}, 'scope': 'same original candidate first75 outer; all16 actual Native input prefixes; original first L20/heads'}
assert hashlib.sha256((original/'outer.jsonl').read_bytes()).hexdigest() == 'f22dcc8944fa476a0688b61f546482210a5065f727628659d10c4c3a423dbcd2'
assert hashlib.sha256((native/'stages.jsonl').read_bytes()).hexdigest() == '87fa6b787a138a58cafc9b18ddb10554c8ce08b9064f831ecd0a6a105d8a5945'
assert read(probe/'full-probe/outer.jsonl') == read(original/'outer.jsonl')
for rank in range(16):
    actual = read(probe/f'input-trace/rank{rank}.trace.jsonl')
    expected = read(reference/f'input-trace/rank{rank}.trace.jsonl')
    assert len(actual) >= 75
    for step in range(len(actual)):
        assert {k:v for k,v in actual[step].items() if k != 'execute_index'} == {k:v for k,v in expected[step].items() if k != 'execute_index'}, (rank, step)
    report['traces'][rank] = len(actual)
stages = read(probe/'full-probe/stages.jsonl')
gold = read(native/'stages.jsonl')
assert len(stages) == 75
first = None
for step, actual in enumerate(stages):
    assert actual['forward_index'] == step and actual['actual_tokens'] == gold[step]['actual_tokens']
    for layer in range(43):
        fields = actual['layers'][str(layer)]
        assert set(fields) == set(gold[step]['layers'][str(layer)])
        for name in ('input', 'positions', 'normed', 'heads', 'oproj', 'attention_half', 'output'):
            if name in fields and fields[name] != gold[step]['layers'][str(layer)][name]:
                first = {'step': step, 'layer': layer, 'stage': name}
                break
        if first:
            break
    if first:
        break
assert first == {'step':74, 'layer':20, 'stage':'heads'}
report.update(first=first, original_candidate_outer_records=75, passed=True)
out = probe/'first-prefix-audit.json'
out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
