from pathlib import Path
import json
from o_proj import o_proj_test
from pypto.ir._kernel_compile import kernel_signature_for_program
from pypto.runtime import RunConfig
params,aliases=kernel_signature_for_program(o_proj_test.specialize())
print('OPROJ_V3_CPU_SIGNATURE_OK',params,aliases,flush=True)
compiled=o_proj_test.compile(config=RunConfig(platform='a2a3'))
Path(__file__).with_name('compile-result.json').write_text(json.dumps({'output_dir':str(compiled.output_dir),'params':[p.name for p in params],'aliases':list(aliases)},indent=2)+'\n')
print('OPROJ_V3_CPU_LOWER_OK',compiled.output_dir,flush=True)
