"""Independent WKV projection probe; no service changes."""
import pypto.language as pl
T=pl.dynamic('WKV_INPUT_T')
@pl.jit
def wkv_test(x:pl.Tensor[[T,4096],pl.BF16],weight:pl.Tensor[[512,4096],pl.BF16],output:pl.Out[pl.Tensor[[T,512],pl.BF16]]):
    x.bind_dynamic(0,T);output.bind_dynamic(0,T)
    rows=pl.tensor.dim(x,0)
    row_tiles=(rows+15)//16
    accum=pl.create_tensor([2*row_tiles*16,512],dtype=pl.FP32)
    for worker in pl.spmd(2*row_tiles*8,name_hint='wkv_matmul'):
        part=worker//(row_tiles*8)
        output_worker=worker%(row_tiles*8)
        row=output_worker//8*16
        col=output_worker%8*64
        valid=pl.min(16,rows-row)
        tile=pl.create_tensor([16,64],dtype=pl.FP32)
        for step in pl.range(8):
            a=pl.slice(x,[16,256],[row,part*2048+step*256],valid_shape=[valid,256])
            b=weight[col:col+64,part*2048+step*256:part*2048+(step+1)*256]
            tile=pl.matmul_acc(tile,a,b,b_trans=True,init_cond=(step==0))
        accum[part*row_tiles*16+row:part*row_tiles*16+row+16,col:col+64]=tile
    for block in pl.spmd(row_tiles,name_hint='wkv_round'):
        out_row=block*16
        out_rows=pl.min(16,rows-out_row)
        projected=pl.load(accum,[out_row,0],[16,512],valid_shape=[out_rows,512])
        other=pl.load(accum,[row_tiles*16+out_row,0],[16,512],valid_shape=[out_rows,512])
        combined=pl.add(projected,other)
        rounded=pl.cast(combined,pl.BF16,mode='rint')
        pl.store(rounded,[out_row,0],output)
    return output
