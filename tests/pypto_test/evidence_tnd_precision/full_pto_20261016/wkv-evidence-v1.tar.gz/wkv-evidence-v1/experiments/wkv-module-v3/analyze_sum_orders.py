"""CPU诊断辅助：比对顺序求和与二分求和；不能据匹配推定Native实现。"""
import json
from pathlib import Path
import numpy as np
import torch
p=Path('/data/pyptouser/yejia/fp16/wkvm3/result/first-difference.pt')
torch.set_num_threads(4);d=torch.load(p,map_location='cpu',weights_only=True)
x=d['norm_input'].float().numpy();w=d['projection_weight'].float().numpy();n=d['expected']['output'];a=d['actual']['output']
seq=[];tree=[]
for row in x:
 terms=row[:,None]*w
 seq.append(np.cumsum(terms,axis=0,dtype=np.float32)[-1])
 while len(terms)>1:terms=terms[:len(terms)//2]+terms[len(terms)//2:]
 tree.append(terms[0])
report={'scope':'CPU order aids only, not Native implementation identification','pairs':{}}
for key,data in (('sequential_fp32',seq),('half_tree_fp32',tree)):
 v=torch.from_numpy(np.stack(data)).bfloat16()
 report['pairs'][key]={'native_mismatch':int((v!=n).sum()),'pto_mismatch':int((v!=a).sum()),'first_vs_native':(v!=n).nonzero()[:10].tolist()}
(p.parent/'cpu-sum-orders.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
