"""保存普通WKV数值实验，不打包权重或大型Tensor快照。"""
from pathlib import Path
import json,hashlib,shutil,tarfile
root=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/full-pto-precision-20261017')
dst=root/'wkv-evidence-v1';dst.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(p,n):
 q=dst/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
labels={'wkv-module-v2':'wkvm2','wkv-module-v3':'wkvm3','wkv-module-v4-nt':'wkvm4nt','wkv-module-v5-k256':'wkvm5k256','wkv-module-v6-n32':'wkvm6n32','wkv-module-v7-split2':'wkvm7split2','wkv-module-v8-native-order':'wkvm8native','wkv-native-profile-v1':'wkvnativeprof1','wkv-order-case-v1':'wkvorder1'}
for exp,label in labels.items():
 for p in (root/exp).iterdir():
  if p.is_file() and p.suffix in ('.py','.sh','.log'):copy(p,Path('experiments')/exp/p.name)
 folder=Path('/data/pyptouser/yejia/fp16')/label
 for pattern in ('run.log','order.log','order/*.json','result/*.json','result/profile/**/kernel_details.csv','result/profile/**/op_statistic.csv'):
  for p in folder.glob(pattern):
   if p.is_file():copy(p,Path('results')/label/p.relative_to(folder))
 p=folder/'result/first-difference.pt'
 if p.exists():
  q=dst/'results'/label/'snapshot-identity.json';q.parent.mkdir(parents=True,exist_ok=True);q.write_text(json.dumps({'sha256':sha(p),'bytes':p.stat().st_size,'excluded':'may include model weight; not archived'},indent=2)+'\n')
copy(root/'collect_wkv.py','helpers/collect_wkv.py')
manifest={str(p.relative_to(dst)):sha(p) for p in sorted(dst.rglob('*')) if p.is_file()}
(dst/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
p=root/'wkv-evidence-v1.tar.gz'
with tarfile.open(p,'w:gz') as t:t.add(dst,arcname=dst.name)
print(json.dumps(dict(sha256=sha(p),files=len(manifest),bytes=p.stat().st_size)))
