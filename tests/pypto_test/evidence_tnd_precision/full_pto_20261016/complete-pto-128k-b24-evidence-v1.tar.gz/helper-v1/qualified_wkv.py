"""独立限定修正：原13包验证和实际reselect完成后才允许自然序T6。"""
import hashlib
import json
import os
from pathlib import Path

METADATA_SHA = '863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
runtimes = []
counts = {}
qualification = {'ready': False, 'metadata_sha': METADATA_SHA}


def install_static(module):
    original = module.compile_static_kernel
    selected_result = []

    def compile_qualified(*args, **kwargs):
        import torch_npu
        metadata = Path(os.environ['LOW_ACCEPTANCE_OFFICIAL_CACHE']) / 'metadata.json'
        assert hashlib.sha256(metadata.read_bytes()).hexdigest() == METADATA_SHA
        reuse = qualification['ready']
        if reuse:
            assert len(selected_result) == 1
            assert all(runtime.wkv_profile.metadata_sha256 == METADATA_SHA for runtime in runtimes)
        else:
            assert not any(runtime.wkv_profile.captured for runtime in runtimes), 'Do not reselect after capture'
        actual = torch_npu.npu._aclnn_reselect_static_kernel
        calls = []

        def tracked(*values, **options):
            # The pinned SDK API is a process-global, no-argument reselection.
            assert not values and not options, 'Unexpected static reselection ABI'
            if reuse:
                calls.append('reuse')
                return selected_result[0]
            assert not calls, 'Multiple initial static reselections'
            assert not any(runtime.wkv_profile.captured for runtime in runtimes), 'Do not reselect after capture'
            result = actual()
            selected_result.append(result)
            calls.append('actual')
            return result

        torch_npu.npu._aclnn_reselect_static_kernel = tracked
        try:
            # Every call retains all original 13-package/SDK/SOC/determinism checks.
            # After the first successful installation, the same selection is reused.
            result = original(*args, **kwargs)
        finally:
            torch_npu.npu._aclnn_reselect_static_kernel = actual
        assert calls, 'No static selection callback'
        if reuse:
            assert all(call == 'reuse' for call in calls)
            qualification['validated_reuses'] = qualification.get('validated_reuses', 0) + 1
            print('WKV_STATIC_SELECTION_REUSED after_original_package_validation=1', flush=True)
            return result
        assert calls == ['actual'], 'No unique actual static reselection'
        assert len(runtimes) == 21
        for runtime in runtimes:
            runtime.qualify_static_wkv(metadata_sha256=METADATA_SHA, reselected=True)
        qualification['ready'] = True
        qualification['actual_reselections'] = 1
        print('WKV_STATIC_QUALIFIED ' + json.dumps(qualification), flush=True)
        return result

    module.compile_static_kernel = compile_qualified


def install_service(model):
    import torch
    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision import service
    if getattr(service.CSAServiceRuntime.__call__, '_qualified_wkv', False):
        return
    original = service.CSAServiceRuntime.__call__
    for layer in model.model.layers:
        runtime = getattr(layer.self_attn.dsa_attn, '_pto_csa_runtime', None)
        if runtime is not None:
            assert type(runtime) is service.CSAServiceRuntime
            runtimes.append(runtime)
    assert len(runtimes) == 21 and len({id(runtime) for runtime in runtimes}) == 21
    import re
    indices = {int(re.search(r'\.layers\.(\d+)\.', runtime.layer_name).group(1)) for runtime in runtimes}
    assert indices == set(range(2, 43, 2))
    required = ('hc_pre', 'input_norm', 'wkv', 'indexer_weights', 'o_proj', 'hc_post')
    for runtime in runtimes:
        assert runtime.restored_modules == required
        original_op = runtime.pto_o_proj
        counts[runtime.layer_name] = {}
        def projection(*args, _runtime=runtime, _original=original_op, **kwargs):
            tokens = args[0].shape[0]
            capturing = torch.npu.is_current_stream_capturing()
            assert qualification['ready'] and _runtime.wkv_profile.metadata_sha256 == METADATA_SHA
            row = counts[_runtime.layer_name].setdefault(str(tokens), {'warmup': 0, 'capture': 0})
            if capturing:
                assert row['warmup'] > 0, 'PTO O-proj was not warmed before capture'
                row['capture'] += 1
            else:
                row['warmup'] += 1
            return _original(*args, **kwargs)
        runtime.pto_o_proj = projection
    def forward(runtime, context, hidden, positions, output, kv_cache):
        assert qualification['ready'], 'Full PTO CSA invoked before verified static installation'
        return original(runtime, context, hidden, positions, output, kv_cache)
    forward._qualified_wkv = True
    service.CSAServiceRuntime.__call__ = forward


def finish():
    assert qualification['ready'] and qualification['actual_reselections'] == 1
    assert qualification.get('validated_reuses', 0) > 0
    assert len(counts) == 21 and len(runtimes) == 21
    for layer, sizes in counts.items():
        for tokens in (6,144):
            row = sizes.get(str(tokens), {})
            assert row.get('warmup', 0) > 0 and row.get('capture', 0) > 0, (layer, tokens, row)
    return {'ready':True,'metadata_sha256':METADATA_SHA,'actual_reselections':qualification['actual_reselections'],'validated_reuses':qualification.get('validated_reuses',0),
            'restored_modules':list(runtimes[0].restored_modules),'oproj_counts':counts,
            'scope':'exact full-PTO runtime, per-layer O-proj calls during real capture and preceding noncapture warmup; replay uses captured graph'}
