#!/usr/bin/env bash
set -euo pipefail
job=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/full-pto-128k-b24-20261018/helper-v1
export LOW_ACCEPTANCE_GPU_BLOCKS=24000
export LOW_ACCEPTANCE_RUNTIME_PACKAGE=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/low-acceptance-20261010/runtime-package
export LOW_ACCEPTANCE_OFFICIAL_CACHE=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/low-acceptance-20261010/official-static-cache
source "$job/env.sh"
export ASCEND_RT_VISIBLE_DEVICES="" TORCH_DEVICE_BACKEND_AUTOLOAD=0 FULL_PROBE_MODE=control
export ADMISSION_TRACE_DIR="$job/preflight-unused"
export CMAKE_BUILD_PARALLEL_LEVEL=4
export CCACHE_DIR=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/pypto/.ccache
ccache -s
python "$job/source_preflight.py"
python "$job/check_inputs.py"
python - <<'PY'
import offline_pd.observer as m
from offline_pd.worker import OfflineNPUWorker
from vllm.entrypoints.llm import LLM
assert m.OfflineCSAObserver.offline_begin_observation.__module__ == 'sitecustomize'
assert LLM.__init__.__module__ == 'original_private_sitecustomize'
assert OfflineNPUWorker.initialize_from_config.__module__ == 'sitecustomize'
assert OfflineNPUWorker.load_model.__module__ == 'sitecustomize'
print('128K_TRACE_CAPACITY_BOOTSTRAP_NO_DEVICE_OK')
PY
