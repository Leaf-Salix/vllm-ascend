"""完整128K整模型验收：原Native1、完整PTO、全rank token/events与rank0 outer。"""
import argparse
import json
from pathlib import Path
from audit_alignment import audit
from check_inputs import JOB, NATIVE, REFERENCE, SOURCE, SOURCE_SHA, STATIC_SHA, sha, verify
from saved_reference import source_identity, read_rows

SEMANTIC_KEYS = ('attention','bank','batch','decode_tokens','event_work_mode',
                 'num_gpu_blocks_override','gpu_memory_utilization','official_static_cache_sha256',
                 'bank_plan_sha256','runtime_package_manifest_sha256','runtime_package')

def qualify(root):
    verify()
    assert root.resolve() != NATIVE.resolve()
    left,lt,lo,la,lv = audit(NATIVE,require_ready_reuse=False)
    right,rt,ro,ra,rv = audit(root,require_ready_reuse=False)
    assert left['backend'] == 'native' and right['backend'] == 'pto'
    assert all(left[k] == right[k] for k in SEMANTIC_KEYS)
    assert right['variant'] == 'tnd_full_precision' and right['production_git_commit'] == '425ae1f11'
    assert right['source_manifest_sha256'] == SOURCE_SHA
    assert Path(right['snapshot']).resolve() == (SOURCE/'source').resolve()
    assert right['capture_sizes'] == [6,144] and right['max_num_batched_tokens'] == 400
    assert right['wkv_restored'] and right['indexer_projection_restored'] and right['oproj_restored']
    for name,digest in (
        ('wkv_order_map_sha256','ba7885227b29b521f7dcbde69ff79bc4bf6c706c1942c59985a01ee323ae7255'),
        ('indexer_order_map_sha256','700c26586fe104bf92ffbb5d6eba74d307ba4c67df9eeac08363c729d2ec71fc'),
        ('oproj_order_map_sha256','2c6ed88f69024a894543228a818cc5e7a4081ffacbceebb9fec5452a2b187686'),
    ):assert right[name] == digest
    for key,name in (('bootstrap_sha256','sitecustomize.py'),('witness_sha256','capture_boundaries.py'),
                     ('trace_helper_sha256','admission_trace.py'),('full_probe_sha256','full_probe.py'),
                     ('generation_window_sha256','generation_window.py'),('qualified_helper_sha256','qualified_wkv.py'),
                     ('helper_manifest_sha256','helper-manifest.json')):
        assert right[key] == sha(JOB/name),name
    assert right['test_harness_patch'] == 'complete PTO CSA with verified static selection reuse; unchanged 128K input and generation gates; outer control first-difference stop'
    for config in (left,right):source_identity(config)
    assert left['full_probe_mode'] == right['full_probe_mode'] == 'control'
    assert right['stage_reference'] is None and not (root/'full-probe/stages.jsonl').exists()
    assert Path(right['trace_reference']).resolve() == (REFERENCE/'input-trace').resolve()
    assert Path(right['outer_reference']).resolve() == (REFERENCE/'full-probe').resolve()
    assert right['generation_reference_manifest_sha256'] == sha(REFERENCE/'manifest.json')
    assert right['official_static_cache_sha256'] == STATIC_SHA
    assert not list(root.glob('**/STOP.json'))
    assert lt == rt, 'Actual input/admission first differs'
    assert lo == ro, 'Complete token or acceptance event first differs'
    assert la == ra, 'Complete acceptance counters differ'
    assert all(len(trace) == 78 for trace in rt)
    outer = read_rows(root,'outer.jsonl','control',78)
    assert outer == read_rows(NATIVE,'outer.jsonl','control',78), 'Rank0 outer first differs'
    full_pto,caches = [],[]
    for rank,trace in enumerate(rt):
        assert next(row['forward_index'] for row in trace if row['graph_mode']=='FULL' and row['padded_tokens']==6) == 74
        for i,(row,bits) in enumerate(zip(trace,outer,strict=True)):
            if rank == 0:assert bits['forward_index']==i and bits['actual_tokens']==row['actual_tokens']
        data = json.loads((root/f'rank{rank}.mixed.json').read_text())['observation'][0]
        q = data['full_pto_qualification']
        assert q['ready'] and q['actual_reselections']==1 and q['validated_reuses']>0
        assert q['metadata_sha256'] == STATIC_SHA
        assert q['restored_modules'] == ['hc_pre','input_norm','wkv','indexer_weights','o_proj','hc_post']
        expected = {f'model.layers.{i}.self_attn.attn' for i in range(2,43,2)}
        assert set(q['oproj_counts']) == expected
        for layer,counts in q['oproj_counts'].items():
            for t in (6,144):
                assert counts[str(t)]['warmup']>0 and counts[str(t)]['capture']>0
                assert data['capture_time_selection'][layer].get(f'pto_tokens{t}',0)>=2
        full_pto.append({'rank':rank,**q})
        stats = data['pypto_cache_stats']
        assert all(stats[k]==0 for k in ('bypasses','invalid_entries','storage_errors','forced_rebuilds'))
        caches.append({'rank':rank,'stats':stats,'strict_ready_reuse':stats['ready_hits']>0 and stats['generation_builds']==stats['binary_builds']==0})
    return {'numeric_pass':True,'production_git_commit':right['production_git_commit'],
            'source_manifest_sha256':right['source_manifest_sha256'],'helper_manifest_sha256':sha(JOB/'helper-manifest.json'),
            'native_runs_this_round':0,'native2_run':False,'generation_records':78,
            'all16_inputs_equal':True,'all16_complete_tokens_and_events_equal':True,
            'rank0_outer_bit_equal':True,'internal_layer_stages_tested':False,'requests':384,'tokens':73728,
            'oproj_restored':True,'complete_pto_csa':True,'full_pto_qualification':full_pto,
            'acceptance':{k:v for k,v in ra.items() if k!='requests'},'cache':caches,
            'strict_ready_reuse':all(x['strict_ready_reuse'] for x in caches),
            'native_observed':lv,'csa_observed':rv,
            'scope':'Real model fixed128K bank,TP1 DP=EP16 B24 submitted,192 output tokens,FULL6/144,complete HCpre-to-HCpost PTO CSA; reuse Native1, no new Native2 or internal stage/performance claim'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    r=qualify(a.root)
    with a.output.open('x') as f:json.dump(r,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in r.items() if k not in ('cache','full_pto_qualification','native_observed','csa_observed')},ensure_ascii=False))
