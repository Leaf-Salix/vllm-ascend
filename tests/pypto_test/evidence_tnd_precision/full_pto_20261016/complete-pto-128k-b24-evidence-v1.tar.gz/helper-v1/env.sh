#!/usr/bin/env bash
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/root-fix-20261016/env.sh"
export PYTHONPATH="/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/full-pto-128k-b24-20261018/helper-v1:$PYTHONPATH"

export SOURCE_ROOT="/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/full-pto-8k-b40-20261018/step12/source"
export PYTHONPATH="/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/full-pto-128k-b24-20261018/helper-v1:$SOURCE_ROOT:$SOURCE_ROOT/tests/pypto_test:$PYTHONPATH"
export PTO_CSA_VARIANT=tnd_full_precision
export OMP_NUM_THREADS=10 OMP_PROC_BIND=false
unset LOCAL_WORLD_SIZE
