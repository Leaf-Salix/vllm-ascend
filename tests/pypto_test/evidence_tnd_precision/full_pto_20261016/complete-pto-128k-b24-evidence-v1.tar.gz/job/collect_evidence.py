"""仅归档自有128K小证据，不含权重、bank张量或NPU内存快照。"""
import hashlib,json,tarfile
from pathlib import Path
BASE=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
job=BASE/'full-pto-128k-b24-20261018'
source=BASE/'full-pto-8k-b40-20261018/step12'
native=Path('/data/pyptouser/yejia/lc128/retest192-native1-b24000')
current=Path('/data/pyptouser/yejia/lc128/full-pto128k-complete1-20261018')
reference=BASE/'retest192-20261016/native1-generation-reference'
files={}
def add(path,name):
    if path.is_file():
        assert path.stat().st_size<40*1024**2,(path,path.stat().st_size)
        files[name]=path
for root,name in ((native,'native'),(current,'complete-pto')):
    for pattern in ('*.json','*.jsonl','*.log','input-trace/*','full-probe/*.json','full-probe/*.jsonl'):
        for p in root.glob(pattern):add(p,name+'/'+str(p.relative_to(root)))
for p in reference.rglob('*'):add(p,'native-reference/'+str(p.relative_to(reference)))
for p in (job/'helper-v1').iterdir():
    if p.suffix in ('.py','.sh','.json'):add(p,'helper-v1/'+p.name)
for name in ('CHECKLIST.md','PROGRESS.md','preflight.log','qualify.log','qualified.json','task-status.txt','task-log.txt','collect_evidence.py','test_gate_cpu.py'):
    add(job/name,'job/'+name)
add(source/'manifest.json','source/manifest.json')
m=json.loads((source/'manifest.json').read_text())
for name in sorted(set(m['production_package_files'])|set(m['overlay_files'])):add(source/'source'/name,'source/'+name)
c=json.loads((native/'configuration.json').read_text());add(Path(c['snapshot_manifest']),'native/source-manifest.json')
add(BASE/'low-acceptance-20261010/official-static-cache/metadata.json','assets/static-metadata.json')
add(Path(c['bank'])/'plan.json','assets/bank-plan.json')
add(BASE/'low-acceptance-20261010/sitecustomize.py','assets/private-sitecustomize.py')
add(BASE/'low-acceptance-20261010/official-static-cache.py','assets/official-static-cache.py')
index={n:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for n,p in sorted(files.items())}
manifest=job/'evidence-files.json';manifest.write_text(json.dumps(index,indent=2)+'\n')
archive=job/'complete-pto-128k-b24-evidence-v1.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for name,path in sorted(files.items()):tar.add(path,arcname=name,recursive=False)
    tar.add(manifest,arcname='evidence-files.json')
print(json.dumps({'archive':str(archive),'files':len(files),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
