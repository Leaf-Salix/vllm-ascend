# 完整PTO CSA 128K/B24/192-token对照

- 用户在8K通过后批准128K对照；复用原Native1，不运行Native2。
- 候选数学425ae1f11完整精度17文件；直接复用8K已通过的冻结step12/source，不修改源码、基准或环境。
- source SHA=56d688b218d0d634024aed98a1568adac982f6005e5cd87373dd7553df8e6496。
- 新helper：full-pto-128k-b24-20261018/helper-v1；manifest SHA=9f84e645c8d282581c6e1b0a790add5daa60cbdd9fb73f988a4b7d536f6e3170。
- Native1：retest192-native1-b24000，原commit cbc810c8afab47c2425068049440424f014dcde3；固定128K bank/24请求；完整384×192=73728token/78有效轮参考。
- TP1/DP=EP16、B24每rank、FULL[6,144]、KV24000/util.97/EPLBoff，允许等候入场、检查实际并发与零抢占。
- 原all16入场/window/audit/saved_reference逐字节保留；outer gate沿用8Kv2原代码，不安装内部stage witness。
- 静态桥与8Kv2相同：首次真实reselect一次，后续13包/SDK/SOC/确定性验证后复用；只改finish要求为6/144。
- CPU6项、bash语法、py_compile及独立review通过；新助手无设备预检进行中，尚未提交NPU。

- 无设备预检通过。01:41:55提交task_20261018_014155_28865031713，16卡max780，输出full-pto128k-complete1-20261018。尚无数值结果。

## 最终数值结论

- task_20261018_014155_28865031713 exit0，提交至完成9m16（含排队），max780。
- CPU严格numeric_pass=true：384×192=73728token、全部接受事件、16rank入场/设备输入78轮精确相同，rank0全部78轮outer位摘要一致。
- 首FULL6 index74及后续77全部通过；每rank实际73FULL144、peak21、零抢占、raw79含1合法空尾。
- 全16rank×21CSA层T21实际PTO非捕获调用各1；两桶6/144暖身+捕获各1；实际reselect1+验证复用1。
- 冷构建rank3各3、rank11各4，cache错误0，strict READY=false；不报告性能。
- 未运行新的Native1/Native2，无正式源码修改，待归档/独立原始数据审查/提交。
