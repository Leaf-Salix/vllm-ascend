"""CPU checks for the new observer-only bootstrap and the unchanged first-diff oracles."""
import importlib.util
import sys
from pathlib import Path
from types import ModuleType, SimpleNamespace

import pytest

ROOT = Path(__file__).parent
H = ROOT/'helper-v1'


def test_input_outer_and_tail_gates_unchanged():
    old = ROOT.parent/'dsv4-128k-wkv-retest-20261017'/'witness-v1'
    for name in ('admission_trace.py','generation_window.py','audit_alignment.py','saved_reference.py'):
        assert (old/name).read_bytes() == (H/name).read_bytes()


def load(monkeypatch):
    flag = SimpleNamespace(capture=False)
    torch = ModuleType('torch')
    torch.npu = SimpleNamespace(is_current_stream_capturing=lambda: flag.capture)
    monkeypatch.setitem(sys.modules,'torch',torch)
    name = 'vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision'
    package = ModuleType(name)
    class Runtime:
        restored_modules = ('hc_pre','input_norm','wkv','indexer_weights','o_proj','hc_post')
        def __init__(self, index):
            self.layer_name = f'model.layers.{index}.self_attn.attn'
            self.wkv_profile = SimpleNamespace(metadata_sha256=None,captured=False)
            self.pto_o_proj = lambda *a, **k: 'pto'
        def qualify_static_wkv(self,metadata_sha256,reselected):
            assert reselected and not self.wkv_profile.captured
            self.wkv_profile.metadata_sha256=metadata_sha256
        def __call__(self,*args):return 'forward'
    package.service = SimpleNamespace(CSAServiceRuntime=Runtime)
    monkeypatch.setitem(sys.modules,name,package)
    spec=importlib.util.spec_from_file_location('qualified_test',H/'qualified_wkv.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    rs=[Runtime(i) for i in range(2,43,2)]
    model=SimpleNamespace(model=SimpleNamespace(layers=[SimpleNamespace(self_attn=SimpleNamespace(dsa_attn=SimpleNamespace(_pto_csa_runtime=r))) for r in rs]))
    module.install_service(model)
    return module,rs,flag


def test_unqualified_and_unwarmed_capture_rejected(monkeypatch):
    m,rs,flag=load(monkeypatch)
    x=SimpleNamespace(shape=(6,32768))
    with pytest.raises(AssertionError):rs[0].pto_o_proj(x)
    m.qualification.update(ready=True,actual_reselections=1,validated_reuses=1)
    for r in rs:r.wkv_profile.metadata_sha256=m.METADATA_SHA
    flag.capture=True
    with pytest.raises(AssertionError,match='not warmed'):rs[0].pto_o_proj(x)
    with pytest.raises(AssertionError):m.finish()


def test_all_21_layers_need_both_warmups_and_captures(monkeypatch):
    m,rs,flag=load(monkeypatch)
    m.qualification.update(ready=True,actual_reselections=1,validated_reuses=1)
    for r in rs:
        r.wkv_profile.metadata_sha256=m.METADATA_SHA
        for t in (6,144):
            flag.capture=False;assert r.pto_o_proj(SimpleNamespace(shape=(t,32768)))=='pto'
            flag.capture=True;assert r.pto_o_proj(SimpleNamespace(shape=(t,32768)))=='pto'
    result=m.finish()
    assert result['ready'] and len(result['oproj_counts'])==21
    result['oproj_counts'][rs[-1].layer_name]['144']['capture']=0
    with pytest.raises(AssertionError):m.finish()


def static_fixture(monkeypatch,tmp_path):
    import hashlib
    m,rs,flag=load(monkeypatch)
    metadata=tmp_path/'metadata.json';metadata.write_bytes(b'fixed package identity')
    m.METADATA_SHA=hashlib.sha256(metadata.read_bytes()).hexdigest()
    monkeypatch.setenv('LOW_ACCEPTANCE_OFFICIAL_CACHE',str(tmp_path))
    calls=[]
    torch_npu=ModuleType('torch_npu')
    def actual():calls.append('actual');return 17
    torch_npu.npu=SimpleNamespace(_aclnn_reselect_static_kernel=actual)
    monkeypatch.setitem(sys.modules,'torch_npu',torch_npu)
    validated=[]
    def original(*args,**kwargs):
        validated.append('validated')
        return torch_npu.npu._aclnn_reselect_static_kernel()
    bridge=SimpleNamespace(compile_static_kernel=original)
    m.install_static(bridge)
    return m,rs,bridge,calls,validated,metadata,torch_npu,actual


def test_second_bucket_revalidates_without_reselection(monkeypatch,tmp_path):
    m,rs,b,calls,validated,meta,npu,actual=static_fixture(monkeypatch,tmp_path)
    assert b.compile_static_kernel()==17
    assert calls==['actual'] and validated==['validated']
    assert all(r.wkv_profile.metadata_sha256==m.METADATA_SHA for r in rs)
    for r in rs:r.wkv_profile.captured=True
    assert b.compile_static_kernel()==17
    assert calls==['actual'] and len(validated)==2
    assert m.qualification['actual_reselections']==1 and m.qualification['validated_reuses']==1
    assert npu.npu._aclnn_reselect_static_kernel is actual


def test_changed_metadata_rejected_after_capture(monkeypatch,tmp_path):
    m,rs,b,calls,validated,meta,npu,actual=static_fixture(monkeypatch,tmp_path)
    b.compile_static_kernel()
    for r in rs:r.wkv_profile.captured=True
    meta.write_bytes(b'changed package identity')
    with pytest.raises(AssertionError):b.compile_static_kernel()
    assert calls==['actual'] and len(validated)==1
    assert npu.npu._aclnn_reselect_static_kernel is actual


def test_missing_runtime_identity_rejected_before_reuse(monkeypatch,tmp_path):
    m,rs,b,calls,validated,meta,npu,actual=static_fixture(monkeypatch,tmp_path)
    b.compile_static_kernel()
    rs[-1].wkv_profile.metadata_sha256='different'
    with pytest.raises(AssertionError):b.compile_static_kernel()
    assert calls==['actual'] and len(validated)==1
