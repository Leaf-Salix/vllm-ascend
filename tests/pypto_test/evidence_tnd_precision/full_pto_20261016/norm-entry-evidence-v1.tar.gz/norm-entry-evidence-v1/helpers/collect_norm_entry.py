from pathlib import Path
import hashlib,json,shutil,tarfile
base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
r=base/'full-pto-precision-20261017';dst=r/'norm-entry-evidence-v1';dst.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(p,n):
 q=dst/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
p=Path('/data/pyptouser/yejia/lc128/full-pto8k-initdebug1-20261016')
for pattern in ('configuration.json','rank*.log','init-stage/rank*.jsonl'):
 for f in p.glob(pattern):copy(f,Path('initdebug1')/f.relative_to(p))
for exp,label in (('norm-entry-v1','normentry1'),('norm-entry-v2','normentry2')):
 for f in (r/exp).iterdir():
  if f.is_file() and f.suffix in ('.py','.cpp','.sh'):copy(f,Path('experiments')/exp/f.name)
 p=Path('/data/pyptouser/yejia/fp16')/label
 for f in (p/'run.log',p/'result/result.json'):copy(f,Path('results')/label/f.relative_to(p))
p=base/'full-pto-model-8k-b40-20261016/init-debug-v1'
for f in p.glob('*'):
 if f.is_file() and f.suffix in ('.py','.sh'):copy(f,Path('experiments/init-debug-v1')/f.name)
rows=[]
for f in sorted((dst/'initdebug1/init-stage').glob('rank*.jsonl')):
 d=[json.loads(x) for x in f.read_text().splitlines()]
 rows.append(dict(rank=d[-1]['rank'],last=d[-1],completed=sum(x['event']=='stage_completed' for x in d)))
(dst/'initialization-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
copy(r/'collect_norm_entry.py','helpers/collect_norm_entry.py')
manifest={str(p.relative_to(dst)):sha(p) for p in sorted(dst.rglob('*')) if p.is_file()}
(dst/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
p=r/'norm-entry-evidence-v1.tar.gz'
with tarfile.open(p,'w:gz') as tar:tar.add(dst,arcname=dst.name)
print(json.dumps(dict(sha256=sha(p),files=len(manifest),bytes=p.stat().st_size)))
