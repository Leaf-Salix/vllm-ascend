"""标准Vector入口初始化修正；必须逐bit对齐Native。"""
import argparse
import importlib
import json
from pathlib import Path

import pypto.torch
import torch
import torch_npu
from safetensors import safe_open

p = argparse.ArgumentParser()
p.add_argument('--out', type=Path, required=True)
a = p.parse_args()
a.out.mkdir(exist_ok=False, parents=True)
report = dict(complete=False, passed=False, tokens=6, layer=42, cases={},
              scope='standard entry initialization in standalone Norm; not full-model UB root proof')
def save():
    (a.out/'result.json').write_text(json.dumps(report, indent=2)+'\n')
def exact(x,y):
    return torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def metric(x,y):
    return dict(bit_equal=exact(x,y),different_elements=int((x!=y).sum()),finite=bool(torch.isfinite(x).all()))

torch.npu.set_device(0)
torch.use_deterministic_algorithms(True)
torch_npu.npu.set_deterministic_level(1)
torch.set_num_threads(4)
model=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
name='layers.42.attn_norm.weight'
index=json.loads((model/'quant_model_weights.safetensors.index.json').read_text())['weight_map']
with safe_open(model/index[name],framework='pt',device='cpu') as reader:
    weight=reader.get_tensor(name).to('npu',dtype=torch.bfloat16)
x=torch.randn((6,4096),generator=torch.Generator().manual_seed(17),dtype=torch.bfloat16).to('npu')
x.add_(1.25)
original=x.clone()
pypto.torch.init(device=0,platform='a2a3',runtime='tensormap_and_ringbuffer')
save()
try:
 with torch.inference_mode():
  for variant in ('fixed',):
    op=pypto.torch.register(importlib.import_module(variant).input_norm_test,
                           f'diagnostic_norm_entry_v2_20261017::{variant}')
    output=torch.empty_like(x)
    rstd=torch.empty((6,8),dtype=torch.float32,device='npu')
    def run():op(x,weight,output,rstd)
    rows=[]
    report['cases'][variant]=rows
    x.copy_(original)
    native,native_rstd=torch_npu.npu_rms_norm(x,weight,1e-6)
    run();torch.npu.synchronize()
    observed=dict(output=metric(output,native),rstd=metric(rstd[:,:1],native_rstd.reshape(6,1)))
    rows.append(dict(phase='eager_A',**observed));save()
    assert all(v['bit_equal'] and v['finite'] for v in observed.values()),('FIRST_BIT_DIFFERENCE',variant)
    graph=torch.npu.NPUGraph()
    with torch.npu.graph(graph):run()
    for phase in ('A','B','A_restored'):
        x.copy_(original)
        if phase=='B':x.add_(0.125)
        native,native_rstd=torch_npu.npu_rms_norm(x,weight,1e-6)
        output.fill_(float('nan'));rstd.fill_(float('nan'))
        graph.replay();torch.npu.synchronize()
        observed=dict(output=metric(output,native),rstd=metric(rstd[:,:1],native_rstd.reshape(6,1)))
        rows.append(dict(phase=phase,**observed));save()
        assert all(v['bit_equal'] and v['finite'] for v in observed.values()),('FIRST_BIT_DIFFERENCE',variant,phase)
  report.update(complete=True,passed=True);save()
except Exception as e:
 report['error']=repr(e);save();raise
