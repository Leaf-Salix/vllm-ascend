import importlib.util
from pathlib import Path
from types import SimpleNamespace

spec=importlib.util.spec_from_file_location('init_stage_probe',Path(__file__).with_name('init_stage_probe.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class Fake:
 def __init__(self,capturing=False):
  self.capturing=capturing;self.syncs=0;self.events=[];self.active=True
  self.torch=SimpleNamespace(npu=SimpleNamespace(is_current_stream_capturing=lambda:self.capturing,synchronize=self.sync))
 def sync(self):self.syncs+=1
 def record(self,event,**fields):self.events.append(event)

def test_noncapture_sync():
 p=Fake();calls=[]
 def op(x):calls.append(x);return 3
 op._schema='schema'
 w=m.LoggedCall(op,p,'L2','core')
 assert w(4)==3 and calls==[4] and p.syncs==2
 assert w._schema=='schema' and p.events==['prior_work_sync_begin','stage_begin','stage_completed']

def test_capture_no_device_sync():
 p=Fake(True);w=m.LoggedCall(lambda x:x,p,'L2','core')
 assert w(4)==4 and p.syncs==0 and p.events==['capture_stage_begin','capture_stage_enqueued']

def test_inactive_no_probe():
 p=Fake();p.active=False
 assert m.LoggedCall(lambda:9,p,'L2','core')()==9 and p.events==[] and p.syncs==0

def test_failed_stage_not_completed():
 p=Fake()
 def op():raise ValueError('first fault')
 import pytest
 with pytest.raises(ValueError,match='first fault'):m.LoggedCall(op,p,'L2','core')()
 assert p.syncs==1 and p.events==['prior_work_sync_begin','stage_begin']
