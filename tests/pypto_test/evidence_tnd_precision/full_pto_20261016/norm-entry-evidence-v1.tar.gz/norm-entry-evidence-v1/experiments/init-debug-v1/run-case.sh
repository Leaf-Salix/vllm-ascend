#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
old="$base/low-acceptance-20261010"
job="$base/full-pto-model-8k-b40-20261016"
source_job="$base/full-pto-precision-20261016/step05"
debug="$job/init-debug-v1"
bank="$old/banks/fixed8192"
phase=${1:?}; label=${2:?}
case "$phase" in
 native-control) export FULL_PROBE_MODE=control; unset FULL_PROBE_OUTER_REFERENCE FULL_PROBE_STAGE_REFERENCE ;;
 precision-witness) export FULL_PROBE_MODE=control FULL_PROBE_OUTER_REFERENCE=$job/native1-generation-reference/full-probe; unset FULL_PROBE_STAGE_REFERENCE ;;
 *) exit 2 ;;
esac
out="/data/pyptouser/yejia/lc128/$label"
mkdir "$out"
export LOW_ACCEPTANCE_RUNTIME_PACKAGE="$old/runtime-package"
export LOW_ACCEPTANCE_GPU_BLOCKS=22000 LOW_ACCEPTANCE_OFFICIAL_CACHE="$old/official-static-cache"
unset LOW_ACCEPTANCE_STATIC_MANIFEST
source "$job/env.sh"
export PYTHONPATH="$debug:$job:$PYTHONPATH"
export INIT_STAGE_DIR="$out/init-stage"
export ADMISSION_TRACE_DIR="$out/input-trace" FULL_PROBE_DIR="$out/full-probe"
if [[ "$phase" == native-control ]]; then
 unset ADMISSION_REFERENCE
else
 export ADMISSION_REFERENCE="$job/native1-generation-reference/input-trace"
fi
python "$job/source_preflight.py"
python "$job/check_bank.py"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/align128.XXXXXX)
trap 'rmdir "$TMPDIR" 2>/dev/null || true' EXIT
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$SOURCE_ROOT/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$out/opp_env")
export PYPTO_PROG_BUILD_DIR="$out/build" ASCEND_CACHE_PATH="$out/ascend-cache"
export ASCEND_PROCESS_LOG_PATH="$out/ascend" VLLM_CACHE_ROOT="$out/vllm-cache"
mkdir -p "$ASCEND_PROCESS_LOG_PATH" "$ASCEND_CACHE_PATH"
backend=native
if [[ "$phase" == precision-witness ]]; then backend=pto; fi
python - "$out" "$backend" "$bank" "$SOURCE_ROOT" "$old" "$job" "$source_job" <<'PYMETA'
import hashlib,json,sys,os
from pathlib import Path
out,backend,bank,source,old,job,source_job=sys.argv[1:]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
config={'backend':backend,'attention':'csa','variant':'tnd_full_precision','bank':bank,'batch':40,'snapshot':source,'snapshot_manifest':str(Path(source_job)/'manifest.json'),'production_git_commit':'259cf9a5f','decode_tokens':192,'event_work_mode':1,'num_gpu_blocks_override':22000,'gpu_memory_utilization':0.95,'source_manifest_sha256':sha(Path(source_job)/'manifest.json'),'official_static_cache_sha256':sha(Path(old)/'official-static-cache/metadata.json'),'bank_plan_sha256':sha(Path(bank)/'plan.json'),'bank_input_proof_sha256':sha(Path(job)/'bank-input-qualified.json'),'reference_baseline_sha256':sha(Path(job)/'reference/baseline.json'),'capture_sizes':[6,240],'max_num_batched_tokens':400,'runtime_package_manifest_sha256':sha(Path(os.environ['LOW_ACCEPTANCE_RUNTIME_PACKAGE'])/'manifest.json'),'runtime_package':os.environ['LOW_ACCEPTANCE_RUNTIME_PACKAGE'],'generation_window_sha256':sha(Path(job)/'generation_window.py'),'generation_reference_manifest_sha256':sha(Path(job)/'native1-generation-reference/manifest.json') if os.environ.get('ADMISSION_REFERENCE') else None,'trace_helper_sha256':sha(Path(job)/'admission_trace.py'),'bootstrap_sha256':sha(Path(job)/'init-debug-v1/sitecustomize.py'),'initialization_diagnostic':{'stage_probe_sha256':sha(Path(job)/'init-debug-v1/init_stage_probe.py'),'noncapture_stage_sync':True,'no_performance_claim':True},'trace_reference':os.environ.get('ADMISSION_REFERENCE'),'full_probe_mode':os.environ['FULL_PROBE_MODE'],'full_probe_sha256':sha(Path(job)/'full_probe.py'),'witness_sha256':sha(Path(job)/'capture_boundaries.py'),'outer_reference':os.environ.get('FULL_PROBE_OUTER_REFERENCE'),'stage_reference':os.environ.get('FULL_PROBE_STAGE_REFERENCE')}
(Path(out)/'configuration.json').write_text(json.dumps(config,indent=2)+'\n')
PYMETA
cd "$out"
python "$SOURCE_ROOT/tests/pypto_test/offline_pd/run.py" decode --output "$out" --backend "$backend" \
 --pto-attention csa --mixed-requests --batch 40 --decode-dp 16 --max-num-batched-tokens 400 \
 --weight-nz-mode 2 --deterministic --port 30981 --gpu-memory-utilization 0.95 --event-work-mode 1 \
 --bank "$bank" --decode-tokens 192 --graph-mode full_decode_only --capture-sizes 6 240 > "$out/launch.log" 2>&1
python "$SOURCE_ROOT/tests/pypto_test/low_acceptance_20261001/mixed.py" \
 --root "$out" --bank "$bank" --batch 40 --tokens 192 > "$out/acceptance_summary.log"
