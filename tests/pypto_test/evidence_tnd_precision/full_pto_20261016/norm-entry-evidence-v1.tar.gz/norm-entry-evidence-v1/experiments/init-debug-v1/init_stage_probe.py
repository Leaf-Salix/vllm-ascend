"""真实模型初始化诊断：仅在非capture边界同步，不修改算术或已冻结源码。"""
import json
import time
from pathlib import Path


class Probe:
    def __init__(self, rank, directory, torch):
        self.rank, self.torch = rank, torch
        self.active = True
        self.seen = set()
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        self.file = (directory / f'rank{rank}.jsonl').open('x', buffering=1)
        self.index = 0

    def record(self, event, **fields):
        self.file.write(json.dumps(dict(index=self.index, time=time.time(), event=event, rank=self.rank, **fields))+'\n')
        self.index += 1

    def disable(self):
        self.record('generation_begin_probe_disabled')
        self.active = False


class LoggedCall:
    def __init__(self, operation, probe, layer, stage):
        self.operation, self.probe, self.layer, self.stage = operation, probe, layer, stage

    def __getattr__(self, name):
        return getattr(self.operation, name)

    def __call__(self, *args, **kwargs):
        p = self.probe
        if not p.active:
            return self.operation(*args, **kwargs)
        capturing = p.torch.npu.is_current_stream_capturing()
        fields = dict(layer=self.layer, stage=self.stage, capturing=capturing,
                      argument_shapes=[list(x.shape) if hasattr(x, 'shape') else None for x in args])
        # A fault here belongs to earlier queued work, not necessarily this stage.
        p.record('prior_work_sync_begin' if not capturing else 'capture_stage_begin', **fields)
        if not capturing:
            p.torch.npu.synchronize()
            p.record('stage_begin', **fields)
        result = self.operation(*args, **kwargs)
        if not capturing:
            p.torch.npu.synchronize()
        p.record('stage_completed' if not capturing else 'capture_stage_enqueued', **fields)
        return result


def install(rank, directory):
    import torch
    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.service import CSAServiceRuntime
    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.native_adapter import CSAOperators

    probe = Probe(rank, directory, torch)
    original = CSAServiceRuntime.__call__

    def call(runtime, context, hidden, positions, output, kv_cache):
        if not getattr(runtime, '_initialization_probe_wrapped', False):
            # Operators is otherwise shared by all model layers; use a private descriptor.
            runtime.operators = CSAOperators(LoggedCall(runtime.operators.attention, probe, runtime.layer_name, 'attention'))
            for name in ('pto_hc_pre', 'pto_input_norm', 'pto_hc_post'):
                setattr(runtime, name, LoggedCall(getattr(runtime, name), probe, runtime.layer_name, name))
            runtime._initialization_probe_wrapped = True
        if probe.active:
            capturing = torch.npu.is_current_stream_capturing()
            fields = dict(layer=runtime.layer_name, tokens=hidden.shape[0], capturing=capturing)
            probe.record('runtime_begin', **fields)
            key = (runtime.layer_name, hidden.shape[0])
            if rank == 0 and not capturing and key not in probe.seen:
                torch.npu.synchronize()
                groups = {}
                for name, prefix in runtime.prefixes.items():
                    meta = context.attn_metadata[prefix]
                    req = meta.decode
                    groups[name] = dict(num_decodes=meta.num_decodes, num_actual_tokens=meta.num_actual_tokens,
                        bounds=req.query_start_loc.cpu().tolist(), seq_lens=req.seq_lens.cpu().tolist(),
                        slots=None if req.slot_mapping is None else req.slot_mapping.cpu().tolist(),
                        table_shape=list(req.block_table.shape))
                probe.record('metadata', **fields, positions=positions.cpu().tolist(), groups=groups)
                probe.seen.add(key)
        result = original(runtime, context, hidden, positions, output, kv_cache)
        if probe.active:
            probe.record('runtime_returned', **fields)
        return result

    CSAServiceRuntime.__call__ = call
    probe.record('installed')
    return probe
