"""归档本轮Norm源码/首差/日志；不导出模型权重或环境。"""
from pathlib import Path
import hashlib,json,shutil,tarfile
import torch
base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
root=base/'full-pto-precision-20261016'
dst=root/'norm-evidence';dst.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(src,rel):
 target=dst/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,target)
for folder in sorted(root.glob('input-norm-*')):
 if not folder.is_dir():continue
 for src in folder.iterdir():
  if src.is_file() and src.suffix in ('.py','.cpp','.sh','.log','.json'):copy(src,Path('experiments')/folder.name/src.name)
 for src in (folder/'build_output').rglob('input_rms_*.cpp'):
  if src.parent.name=='aiv':copy(src,Path('generated')/folder.name/src.name)
labels=('inormext2','inormsd3','inormobs4','inormhalf5','inormround7','inormformal8','inormlayer1')
for label in labels:
 folder=Path('/data/pyptouser/yejia/fp16')/label
 assert folder.is_dir(),label
 for src in [folder/'run.log',folder/'result.json',folder/'result/result.json']:
  if src.is_file():copy(src,Path('results')/label/src.relative_to(folder))
 p=folder/'result/first-difference.pt'
 if p.is_file():
  data=torch.load(p,map_location='cpu',weights_only=True)
  out=dst/'results'/label/'result/first-difference-outputs-only.pt';out.parent.mkdir(parents=True,exist_ok=True)
  torch.save({k:data[k] for k in ('actual','expected')},out)
  (out.parent/'snapshot-identity.json').write_text(json.dumps({'original_sha256':sha(p),'retained_keys':['actual','expected'],'excluded_keys':['norm_input','norm_weight'],'input_sha256':hashlib.sha256(data['norm_input'].contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()},indent=2)+'\n')
 p=folder/'result/stage-values.pt'
 if p.is_file():
  data=torch.load(p,map_location='cpu',weights_only=True)
  summary={'original_sha256':sha(p),'scope':'debug sqrt and scalar_inverse are uncorrected diagnostics, not v7 participating corrected root','input_sha256':hashlib.sha256(data['input'].contiguous().view(torch.uint8).numpy().tobytes()).hexdigest(),'native_rstd_bits':data['native']['rstd'].flatten().view(torch.int32).tolist(),'debug_first_column_bits':{k:v[:,0].contiguous().view(torch.int32).tolist() for k,v in data['debug'].items()}}
  q=dst/'results'/label/'result/stage-bits.json';q.write_text(json.dumps(summary,indent=2)+'\n')
for src in (root/'norm-layer-v1').iterdir():
 if src.is_file() and src.suffix in ('.py','.sh','.json'):copy(src,Path('experiments/norm-layer-v1')/src.name)
copy(root/'step05/frozen-source.json','frozen/step05/frozen-source.json')
for name in ('__init__.py','service.py','input_norm.py','input_norm_sum.cpp'):
 copy(root/'step05/source/vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision'/name,Path('source-overlay')/name)
copy(root/'archive_norm.py','helpers/archive_norm.py')
manifest={str(p.relative_to(dst)):sha(p) for p in sorted(dst.rglob('*')) if p.is_file()}
(dst/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=root/'norm-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:tar.add(dst,arcname=dst.name)
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(manifest)}))
