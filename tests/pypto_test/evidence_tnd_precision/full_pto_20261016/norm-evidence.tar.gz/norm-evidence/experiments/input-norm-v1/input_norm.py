"""输入Norm单模块：只补齐核内归约tile，不改变实际TND token行或请求边界。"""
import pypto.language as pl
T=pl.dynamic('INPUT_NORM_T')
@pl.jit
def input_norm_test(
    x:pl.Tensor[[T,4096],pl.BF16],
    weight:pl.Tensor[[4096],pl.BF16],
    output:pl.Out[pl.Tensor[[T,4096],pl.BF16]],
    rstd:pl.Out[pl.Tensor[[T,8],pl.FP32]],
):
    x.bind_dynamic(0,T)
    output.bind_dynamic(0,T)
    rstd.bind_dynamic(0,T)
    rows=pl.tensor.dim(x,0)
    # Reduction result is col-major and requires 8 allocated FP32 rows.
    # Each task has only one valid token; zero-filled rows never escape this tile.
    for row in pl.spmd(rows,name_hint='input_rms_stat',allow_early_resolve=True):
        src=pl.slice(x,[8,4096],[row,0],valid_shape=[1,4096])
        widened=pl.cast(src,pl.FP32)
        value=pl.fillpad(pl.set_validshape(widened,1,4096),pad_value=pl.PadValue.zero)
        square=pl.mul(value,value)
        total=pl.row_sum(square)
        variance=pl.add(pl.mul(total,1.0/4096.0),1e-6)
        inverse=pl.rsqrt(variance,high_precision=True)
        inv_rows=pl.row_expand_mul(pl.full([8,8],dtype=pl.FP32,value=1.0),inverse)
        rstd[row:row+1,0:8]=pl.set_validshape(inv_rows,1,8)
    for row in pl.spmd(rows,name_hint='input_rms_apply',allow_early_resolve=True):
        apply_value=pl.cast(x[row:row+1,0:4096],pl.FP32)
        w=pl.cast(pl.reshape(weight,[1,4096]),pl.FP32)
        inv=pl.read(rstd,[row,0])
        scaled=pl.mul(apply_value,inv)
        result=pl.col_expand_mul(scaled,w)
        output[row:row+1,0:4096]=pl.cast(result,pl.BF16,mode='rint')
    return output,rstd
