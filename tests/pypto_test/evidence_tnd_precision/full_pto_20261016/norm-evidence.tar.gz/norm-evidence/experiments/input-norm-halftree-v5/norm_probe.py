"""实际Native HC-pre输入和正式Norm权重；首个模块差异后退出。"""
import argparse,hashlib,json,os
from pathlib import Path
import torch,torch_npu,pypto.torch
from safetensors import safe_open
from vllm_ascend.utils import enable_custom_op
from input_norm import input_norm_test
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args()
a.out.mkdir(exist_ok=False,parents=True)
r={'pass':False,'complete':False,'module':'input_norm stage localization (known A rstd mismatch)','layer':4,'tokens':11,'seed':17,'scope':'actual Native HC-pre mixed, real L4 stored Norm weight copied to BF16 as Native loader; no full-model claim','comparisons':[],'task_device':os.environ['TASK_DEVICE'],'production_modified':False}
def save(): (a.out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def exact(x,y): return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def snapshot(values):
    torch.npu.synchronize();return {k:v.cpu() for k,v in values.items()}
def check(label,actual,expected):
    results={}
    for k,x in actual.items():
        y=expected[k];assert torch.isfinite(x).all() and torch.isfinite(y).all(),(label,k,'nonfinite');diff=x.float()-y.float()
        results[k]={'bit_equal':exact(x,y),'different_elements':int((x!=y).sum()),'max_abs':float(diff.abs().max()),'rel_l2':float(diff.norm()/y.float().norm()),'first_coordinates':(x!=y).nonzero()[:8].tolist()}
    r['comparisons'].append({'label':label,'metrics':results});save()
    if not all(v['bit_equal'] for v in results.values()):
        torch.save({'actual':actual,'expected':expected,'norm_input':x_norm.cpu(),'norm_weight':weight.cpu()},a.out/'first-difference.pt')
        raise RuntimeError('FIRST_BIT_DIFFERENCE '+label)

torch.npu.set_device(0);torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
assert enable_custom_op()
model=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8');config=json.loads((model/'config.json').read_text())
assert config['rms_norm_eps']==1e-6,config['rms_norm_eps']
index=json.loads((model/'quant_model_weights.safetensors.index.json').read_text())['weight_map']
values={}
for name in ('hc_attn_fn','hc_attn_scale','hc_attn_base','attn_norm.weight'):
    key='layers.4.'+name
    with safe_open(model/index[key],framework='pt',device='cpu') as reader:cpu=reader.get_tensor(key)
    values[name]=cpu.to('npu',dtype=torch.bfloat16 if name=='attn_norm.weight' else cpu.dtype)
    r.setdefault('weights',{})[key]={'stored_dtype':str(cpu.dtype),'loaded_dtype':str(values[name].dtype),'sha256':hashlib.sha256(cpu.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest(),'shard':index[key]}
weight=values['attn_norm.weight'];weight_before=weight.clone()
hidden=torch.randn((11,4,4096),generator=torch.Generator().manual_seed(17),dtype=torch.bfloat16).to('npu')
original_hidden=hidden.clone()
def mixed():return torch.ops._C_ascend.npu_hc_pre_v2(hidden,values['hc_attn_fn'],values['hc_attn_scale'],values['hc_attn_base'],4,config['hc_sinkhorn_iters'],config['rms_norm_eps'],config['hc_eps'])[0]
x_norm=mixed();input_a=x_norm.clone()
def native():
    output,inv=torch_npu.npu_rms_norm(x_norm,weight,1e-6)
    return {'output':output,'rstd':inv.reshape(11,1)}
save()
try:
 with torch.inference_mode():
    gold=snapshot(native());check('native_repeat_A',snapshot(native()),gold)
    graph=torch.npu.NPUGraph()
    with torch.npu.graph(graph): native_outputs=native()
    graph_keep=(graph,native_outputs)
    for phase in ('A','B','A_restored'):
        hidden.copy_(original_hidden)
        if phase=='B':hidden.add_(0.125)
        x_norm.copy_(mixed())
        expected=snapshot(native());check('native_repeat_'+phase,snapshot(native()),expected)
        for v in native_outputs.values():v.fill_(float('nan'))
        graph.replay();check('native_graph_'+phase,snapshot(native_outputs),expected)
        if phase=='B':
            assert not exact(x_norm,input_a)
            assert any(not exact(expected[k],gold[k]) for k in expected), 'Native B output unchanged'
        else:check('native_restored_'+phase,expected,gold)
    r['native_qualification_pass']=True;save()
    pypto.torch.init(device=0,platform='a2a3',runtime='tensormap_and_ringbuffer')
    op=pypto.torch.register(input_norm_test,'diagnostic_full_pto_norm_20261016::halftree_forward')
    owners={'output':torch.full((13,4096),.0625,dtype=torch.bfloat16,device='npu'),'rstd':torch.full((13,8),.0625,dtype=torch.float32,device='npu')}
    for k,cols in (('sums',8),('variance',8),('sqrt',8),('scalar_inverse',16)):
        owners[k]=torch.full((13,cols),.0625,dtype=torch.float32,device='npu')
    outputs={k:v[1:-1] for k,v in owners.items()}
    def run():op(x_norm,weight,outputs['output'],outputs['rstd'],outputs['sums'],outputs['variance'],outputs['sqrt'],outputs['scalar_inverse'])
    def actual():
        values=snapshot(outputs)
        debug={k:values.pop(k) for k in ('sums','variance','sqrt','scalar_inverse')}
        assert all(torch.isfinite(v).all() for v in debug.values())
        torch.save({'debug':debug,'actual':values,'native':gold,'input':x_norm.cpu()},a.out/'stage-values.pt')
        assert torch.isfinite(values['rstd']).all()
        assert exact(values['rstd'],values['rstd'][:,0:1].expand(-1,8).contiguous())
        values['rstd']=values['rstd'][:,0:1].contiguous()
        assert all(bool((v[0]==.0625).all() & (v[-1]==.0625).all()) for v in owners.values())
        assert exact(weight,weight_before)
        return values
    for v in outputs.values():v.fill_(float('nan'))
    eager_before=x_norm.clone();run();observed=actual()
    assert exact(eager_before,x_norm), 'PTO eager changed input'
    r['eager_input_and_guard_checks_pass']=True;save()
    check('PTO_eager_A',observed,gold)
    graph=torch.npu.NPUGraph()
    with torch.npu.graph(graph):run()
    graph_keep_pto=(graph,op,owners,x_norm,weight)
    for phase in ('A','B','A_restored'):
        hidden.copy_(original_hidden)
        if phase=='B':hidden.add_(0.125)
        x_norm.copy_(mixed());before=x_norm.clone();expected=snapshot(native())
        check('native_repeat_pto_'+phase,snapshot(native()),expected)
        for v in outputs.values():v.fill_(float('nan'))
        graph.replay();check('PTO_graph_'+phase,actual(),expected)
        assert exact(before,x_norm)
    r.update({'pass':True,'complete':True,'raw_graph_ABA_pass':True});save()
except Exception as e:r['error']=repr(e);save();raise
