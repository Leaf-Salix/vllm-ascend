"""单行full-width归约，显式PTO结果tile避免frontend col-major对齐/UB膨胀。"""
import pypto.language as pl
T=pl.dynamic('INPUT_NORM_T')
@pl.jit.extern(source='input_norm_sum.cpp',core_type='aiv')
def square_sum(x:pl.Tensor[[T,4096],pl.BF16],sums:pl.Out[pl.Tensor[[T,8],pl.FP32]]) -> pl.Tensor[[T,8],pl.FP32]: ...
@pl.jit
def input_norm_test(x:pl.Tensor[[T,4096],pl.BF16],weight:pl.Tensor[[4096],pl.BF16],output:pl.Out[pl.Tensor[[T,4096],pl.BF16]],rstd:pl.Out[pl.Tensor[[T,8],pl.FP32]],sums:pl.Out[pl.Tensor[[T,8],pl.FP32]],variance_out:pl.Out[pl.Tensor[[T,8],pl.FP32]],root_out:pl.Out[pl.Tensor[[T,8],pl.FP32]],scalar_inverse:pl.Out[pl.Tensor[[T,16],pl.FP32]]):
    x.bind_dynamic(0,T);output.bind_dynamic(0,T);rstd.bind_dynamic(0,T)
    rows=pl.tensor.dim(x,0)
    with pl.spmd(rows):sums=square_sum(x,sums)
    for row in pl.spmd(rows,name_hint='input_rms_inverse',allow_early_resolve=True):
        total=pl.read(sums,[row,0])
        total_vector=pl.mul(pl.full([1,8],dtype=pl.FP32,value=1.0),total)
        variance=pl.add(pl.mul(total_vector,1.0/4096.0),1e-6)
        root_value=pl.sqrt(variance)
        variance_out[row:row+1,0:8]=variance
        root_out[row:row+1,0:8]=root_value
        inverse=pl.div(pl.full([1,8],dtype=pl.FP32,value=1.0),root_value)
        rstd[row:row+1,0:8]=inverse
    for row in pl.spmd(rows,name_hint='input_rms_apply',allow_early_resolve=True):
        apply_value=pl.cast(x[row:row+1,0:4096],pl.FP32)
        w=pl.cast(pl.reshape(weight,[1,4096]),pl.FP32)
        inv=pl.read(rstd,[row,0])
        scaled=pl.mul(apply_value,inv)
        result=pl.col_expand_mul(scaled,w)
        output[row:row+1,0:4096]=pl.cast(result,pl.BF16,mode='rint')
    # Each scalar writer owns a whole 64B cache line, unlike the 32B vector rows.
    for scalar_row in pl.spmd(rows,name_hint='input_rms_scalar_div',allow_early_resolve=True):
        scalar_root=pl.read(root_out,[scalar_row,0])
        for lane in pl.range(16):
            pl.write(scalar_inverse,[scalar_row,lane],1.0/scalar_root)
    return output,rstd,sums,variance_out,root_out,scalar_inverse
