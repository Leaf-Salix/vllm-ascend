from pathlib import Path
from pypto.runtime import RunConfig
from pypto.runtime.kernel_compiler import KernelCompiler
from input_norm import input_norm_test
out=Path(__file__).parent/'precompile';out.mkdir(exist_ok=False)
p=input_norm_test.compile(config=RunConfig(platform='a2a3'))
files=[q for q in Path(p.output_dir).rglob('input_rms_*.cpp') if q.parent.name=='aiv']
assert len(files)==1,files
files.extend([Path(__file__).parent/'input_norm_sum.cpp',Path(__file__).parent/'input_norm_inverse.cpp'])
isa='/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/build/pto-isa'
for source in files:
    binary=KernelCompiler('a2a3').compile_incore(str(source),core_type='aiv',pto_isa_root=isa,runtime_name='tensormap_and_ringbuffer',build_dir=str(out))
    (out/(source.stem+'.elf')).write_bytes(binary)
    print('INPUT_NORM_LOWER_CCEC_OK',source.name,len(binary),p.output_dir,flush=True)
