// Device scalar FP32 sqrt/division, matching the Native RMSNorm source boundary.
#include <cstdint>
#include <pto/pto-inst.hpp>
#include <tensor.h>
#include <intrinsic.h>
using namespace pto;
extern "C" __aicore__ __attribute__((always_inline)) void kernel_entry(__gm__ int64_t* args) {
#if defined(__DAV_VEC__)
    set_atomic_none();
    const int row=get_block_idx(args);
    auto in_desc=reinterpret_cast<__gm__ Tensor*>(args[0]);
    auto out_desc=reinterpret_cast<__gm__ Tensor*>(args[1]);
    auto in=reinterpret_cast<__gm__ float*>(in_desc->buffer.addr)+in_desc->start_offset;
    auto out=reinterpret_cast<__gm__ float*>(out_desc->buffer.addr)+out_desc->start_offset;
    using RowShape=Shape<1,1,1,1,8>;
    using RowStride=Stride<8,8,8,8,1>;
    GlobalTensor<float,RowShape,RowStride,Layout::ND> input(in+row*8,RowShape(),RowStride());
    GlobalTensor<float,RowShape,RowStride,Layout::ND> output(out+row*8,RowShape(),RowStride());
    Tile<TileType::Vec,float,1,8,BLayout::RowMajor,-1,-1,SLayout::NoneBox,512,PadValue::Null,CompactMode::Null> total(1,8),inverse(1,8);
    TASSIGN(total,0);TASSIGN(inverse,32);
    TLOAD(total,input);
    set_flag(PIPE_MTE2,PIPE_S,EVENT_ID0);wait_flag(PIPE_MTE2,PIPE_S,EVENT_ID0);
    const float sum=*reinterpret_cast<__ubuf__ float*>(0);
    const float variance=sum*(1.0f/4096.0f)+1e-6f;
    const float rstd=1.0f/__builtin_sqrtf(variance);
    set_flag(PIPE_S,PIPE_V,EVENT_ID0);wait_flag(PIPE_S,PIPE_V,EVENT_ID0);
    TEXPANDS(inverse,rstd);
    set_flag(PIPE_V,PIPE_MTE3,EVENT_ID0);wait_flag(PIPE_V,PIPE_MTE3,EVENT_ID0);
    TSTORE(output,inverse);
    set_flag(PIPE_MTE3,PIPE_S,EVENT_ID0);wait_flag(PIPE_MTE3,PIPE_S,EVENT_ID0);
    pipe_barrier(PIPE_ALL);
#endif
}
