#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/full-pto-precision-20261016/step01/env.sh"
experiment_dir="$base/full-pto-precision-20261016/input-norm-sqrtdiv-v3"
python "$base/full-pto-precision-20261016/step01/check_frozen.py"
export PYPTO_CACHE=0
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE" LOCAL_WORLD_SIZE=1 OMP_NUM_THREADS=4
export TMPDIR
TMPDIR=$(mktemp -d /tmp/fppre.XXXXXX)
trap 'rmdir "$TMPDIR" 2>/dev/null || true' EXIT
out="/data/pyptouser/yejia/fp16/${1:?}"
test ! -e "$out"
mkdir -p "$out"
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$SOURCE_ROOT/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$out/opp_env")
export ASCEND_CACHE_PATH="$out/cache" ASCEND_PROCESS_LOG_PATH="$out/logs"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH"
cd "$out"
python "$experiment_dir/norm_probe.py" --out "$out/result" > "$out/run.log" 2>&1
