"""无设备确认正式WKV的编译产物；不安装或重编框架。"""
from pathlib import Path
from pypto.runtime import RunConfig
from pypto.runtime.kernel_compiler import KernelCompiler
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv import wkv_test
out=Path(__file__).parent/'precompile';out.mkdir(exist_ok=False)
p=wkv_test.compile(config=RunConfig(platform='a2a3'))
files=[q for q in Path(p.output_dir).rglob('wkv_*.cpp') if q.parent.name in ('aiv','aic')]
assert len(files)==2,files
isa='/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/build/pto-isa'
for source in files:
 binary=KernelCompiler('a2a3').compile_incore(str(source),core_type=source.parent.name,pto_isa_root=isa,runtime_name='tensormap_and_ringbuffer',build_dir=str(out))
 (out/(source.stem+'.elf')).write_bytes(binary)
 print('FORMAL_WKV_LOWER_CCEC_OK',source.name,len(binary),p.output_dir,flush=True)
