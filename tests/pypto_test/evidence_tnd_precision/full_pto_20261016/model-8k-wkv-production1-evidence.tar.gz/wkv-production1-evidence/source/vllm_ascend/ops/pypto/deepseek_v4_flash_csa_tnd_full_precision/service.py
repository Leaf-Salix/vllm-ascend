# SPDX-License-Identifier: Apache-2.0
"""完整PTO TND的分阶段候选：当前恢复HC-pre、输入Norm、WKV及HC-post。"""

import torch
import torch_npu

from vllm_ascend.device.device_op import DeviceOperator

from ..deepseek_v4_flash_csa_tnd_precision.native_adapter import NativeCSACall
from ..deepseek_v4_flash_csa_tnd_precision.service import CSAServiceRuntime as BaselineRuntime
from .hc_post import hc_post_test
from .hc_pre import hc_pre_test
from .input_norm import input_norm_test
from .wkv import wkv_test
from .wkv_order_data import WKV_COLUMN_ORDERS, WKV_K_ORDERS, WKV_TOKEN_MODES


class CSAServiceRuntime(BaselineRuntime):
    """原基准保持可运行；剩余Native边界须后续逐项对拍再恢复。"""

    restored_modules = ("hc_pre", "input_norm", "wkv", "hc_post")
    # Native mDim changes above 256 rows; the current K32/22 partition is for mDim1.
    max_hc_pre_tokens = 256

    def eligible(self, context, hidden, positions):
        return hidden.shape[0] <= self.max_hc_pre_tokens and super().eligible(context, hidden, positions)

    def __init__(self, attention, operators, max_num_seqs, layer=None):
        super().__init__(attention, operators, max_num_seqs, layer)
        import pypto.torch

        self.pto_hc_pre = pypto.torch.register(hc_pre_test, "dsv4_csa_tnd_full_precision::hc_pre")
        for parameter, shape in (
            (layer.hc_attn_fn, (24, 16384)),
            (layer.hc_attn_scale, (3,)),
            (layer.hc_attn_base, (24,)),
        ):
            if parameter.dtype != torch.float32 or tuple(parameter.shape) != shape or not parameter.is_contiguous():
                raise ValueError("PTO HC-pre requires original contiguous FP32 Native HC parameters")
            if torch_npu.get_npu_format(parameter) not in (0, 2):
                raise ValueError("PTO HC-pre requires original ND Native HC parameters")
        tokens = self.native_attention_out.shape[0]
        device = self.native_attention_out.device
        norm = layer.input_layernorm
        if norm.variance_epsilon != 1e-6 or norm.bias_loaded:
            raise ValueError("PTO input Norm requires Native epsilon=1e-6 without a loaded bias")
        norm_weight = norm.weight
        if norm_weight.dtype != torch.bfloat16 or tuple(norm_weight.shape) != (4096,):
            raise ValueError("PTO input Norm requires original Native BF16 [4096] weight")
        if not norm_weight.is_contiguous() or torch_npu.get_npu_format(norm_weight) not in (0, 2):
            raise ValueError("PTO input Norm requires original contiguous ND weight")
        self.pto_input_norm = pypto.torch.register(input_norm_test, "dsv4_csa_tnd_full_precision::input_norm")
        self.normed = torch.empty((tokens, 4096), dtype=torch.bfloat16, device=device)
        self.norm_rstd = torch.empty((tokens, 8), dtype=torch.float32, device=device)
        wkv = layer.self_attn.wkv
        weight = wkv.weight.detach()
        if wkv.bias is not None or weight.dtype != torch.bfloat16 or tuple(weight.shape) != (512, 4096):
            raise ValueError("PTO WKV requires the original unbiased BF16 [512, 4096] Native weight")
        # 仅加载期整理布局；不改dtype、不反量化，也不改变权重数值。
        if torch_npu.get_npu_format(weight) not in (0, 2):
            weight = torch_npu.npu_format_cast(weight, 2)
        self.wkv_weight = weight.contiguous()
        self.wkv_projected = torch.empty((tokens, 512), dtype=torch.bfloat16, device=device)
        self.wkv_orders = torch.tensor(
            [[WKV_K_ORDERS[index] for index in mode] for mode in WKV_COLUMN_ORDERS],
            dtype=torch.int32,
            device=device,
        )
        self.pto_wkv = pypto.torch.register(wkv_test, "dsv4_csa_tnd_full_precision::wkv")
        self.hc_mixed = torch.empty((tokens, 4096), dtype=torch.bfloat16, device=device)
        self.hc_post_gates = torch.empty((tokens, 4), dtype=torch.float32, device=device)
        self.hc_comb_gates = torch.empty((tokens, 16), dtype=torch.float32, device=device)
        self.pto_hc_post = pypto.torch.register(hc_post_test, "dsv4_csa_tnd_full_precision::hc_post")

    def __call__(self, context, hidden, positions, output, kv_cache):
        from vllm_ascend.attention.utils import (
            maybe_save_kv_layer_to_connector,
            notify_kv_cache_written,
            wait_for_kv_layer_from_connector,
        )
        from vllm_ascend.memcache_comm_fence import record_attention_compute_start

        metadata = {name: context.attn_metadata[prefix] for name, prefix in self.prefixes.items()}
        hadamard = metadata["indexer"].hadamard
        if hadamard is None:
            raise ValueError("Native indexer metadata did not provide the Hadamard matrix")
        if self._hadamard is not hadamard:
            if torch.npu.is_current_stream_capturing():
                raise RuntimeError("PTO CSA requires Native metadata warmup before graph capture")
            self.weights["hadamard_idx"] = hadamard.detach().T.to(torch.bfloat16).contiguous()
            self._hadamard = hadamard

        wait_for_kv_layer_from_connector(self.layer_name)
        compact = {name: self._compact_metadata(context, metadata[name].decode) for name in ("compressed", "indexer")}
        compressed, swa, state, indexer_state, indexer_key, indexer_scale = kv_cache
        groups = {
            "swa": (metadata["swa"], (swa,)),
            "compressed": (metadata["compressed"], (compressed,)),
            "state": (metadata["state"], (state,)),
            "indexer": (metadata["indexer"], (indexer_key, indexer_scale)),
            "indexer_state": (metadata["indexer_state"], (indexer_state,)),
        }
        tokens = hidden.shape[0]
        if not 1 <= tokens <= self.max_hc_pre_tokens:
            raise ValueError("PTO HC-pre currently supports the Native mDim1 range, 1..256 token rows")
        mixed, post, comb = self.hc_mixed[:tokens], self.hc_post_gates[:tokens], self.hc_comb_gates[:tokens]
        self.pto_hc_pre(
            hidden, self.layer.hc_attn_fn, self.layer.hc_attn_scale, self.layer.hc_attn_base, mixed, post, comb
        )
        normed = self.normed[:tokens]
        self.pto_input_norm(mixed, self.layer.input_layernorm.weight, normed, self.norm_rstd[:tokens])
        kv_projected = self.wkv_projected[:tokens]
        order = self.wkv_orders[WKV_TOKEN_MODES[tokens - 1]]
        self.pto_wkv(normed, self.wkv_weight, order, kv_projected)
        if kv_projected.dtype != torch.bfloat16 or tuple(kv_projected.shape) != (tokens, 512):
            raise ValueError("PTO WKV must publish BF16 [tokens, 512]")
        if not kv_projected.is_contiguous() or torch_npu.get_npu_format(kv_projected) not in (0, 2):
            raise ValueError("PTO WKV must publish contiguous ND storage")
        impl = self.wrapper.dsa_attn.impl
        native_indexer_weights = DeviceOperator.prepare_dsa_indexer_weights(
            impl.weights_proj(normed) * (impl.indexer_softmax_scale * impl.indexer_heads**-0.5)
        )
        if native_indexer_weights.dtype != torch.float16 or tuple(native_indexer_weights.shape) != (tokens, 64):
            raise ValueError("Native Indexer weights must publish FP16 [tokens, 64]")
        if not native_indexer_weights.is_contiguous() or torch_npu.get_npu_format(native_indexer_weights) not in (0, 2):
            raise ValueError("Native Indexer weights must publish contiguous ND storage")
        call_weights = dict(
            self.weights,
            native_normed=normed,
            # 保留CSA内部的历史边界名称，实际producer已改为PTO。
            native_kv_projected=kv_projected,
            native_indexer_weights=native_indexer_weights,
            native_heads=self.native_heads[:tokens],
        )
        call = NativeCSACall(
            self.operators,
            call_weights,
            hidden,
            positions,
            groups,
            layer_name=self.layer_name,
            compact_metadata=compact,
            buffers={"idx_topk_scores": self.scores[:tokens], "idx_topk": self.topk[:tokens], "x_out": output},
        )
        record_attention_compute_start()
        call()
        impl._forward_o_proj(self.native_heads[:tokens].view(tokens, 64, 512), self.native_attention_out[:tokens])
        # Directly publish into the caller's output; no Native HC-post call remains.
        self.pto_hc_post(self.native_attention_out[:tokens], hidden, post, comb.view(tokens, 16), output)
        notify_kv_cache_written(self.layer_name)
        maybe_save_kv_layer_to_connector(self.layer_name, list(kv_cache))
