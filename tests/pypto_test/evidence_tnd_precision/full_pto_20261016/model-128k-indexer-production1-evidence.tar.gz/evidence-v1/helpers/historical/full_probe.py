"""Rank0 FULL replay witnesses, gated by actual input trace alignment."""
import hashlib
import json
import os
from pathlib import Path


def tensor_digest(value, rows):
    import torch

    if value.ndim == 0 or value.shape[0] < rows:
        raise ValueError('Unexpected target boundary shape')
    cpu = value[:rows].detach().cpu().contiguous()
    return {'shape': list(cpu.shape), 'dtype': str(cpu.dtype),
            'sha256': hashlib.sha256(cpu.view(torch.uint8).numpy().tobytes()).hexdigest()}


def tree_digest(value, rows):
    import torch

    if isinstance(value, torch.Tensor):
        return tensor_digest(value, rows)
    if isinstance(value, (list, tuple)):
        return [tree_digest(item, rows) for item in value]
    raise TypeError(f'Unexpected target output: {type(value)}')


def load_reference(directory, filename):
    root = Path(directory)
    audit = json.loads((root / 'complete.json').read_text())
    records = [json.loads(row) for row in (root / filename).read_text().splitlines()]
    if not audit['complete'] or not records or audit['records'] != len(records):
        raise ValueError('Incomplete FULL probe reference')
    return records


def install(observer, directory):
    import torch

    if observer.vllm_config.parallel_config.data_parallel_rank != 0:
        observer._full_probe_finish = lambda: {'rank': observer.vllm_config.parallel_config.data_parallel_rank,
                                              'scope': 'rank0 witnesses only'}
        return
    root = Path(directory)
    root.mkdir(parents=True, exist_ok=False)
    runner = observer.model_runner
    mode = os.environ['FULL_PROBE_MODE']
    outer_reference = os.environ.get('FULL_PROBE_OUTER_REFERENCE')
    stage_reference = os.environ.get('FULL_PROBE_STAGE_REFERENCE')
    expected_outer = load_reference(outer_reference, 'outer.jsonl') if outer_reference else None
    expected_stages = load_reference(stage_reference, 'stages.jsonl') if stage_reference else None
    if mode not in ('control', 'witness') or (mode == 'control' and stage_reference):
        raise ValueError('Invalid FULL probe mode')
    if mode == 'witness' and not hasattr(runner, '_diagnostic_boundary_snapshot'):
        raise RuntimeError('Graph witnesses were not installed before capture')
    outer_file = (root / 'outer.jsonl').open('x', buffering=1)
    stage_file = (root / 'stages.jsonl').open('x', buffering=1) if mode == 'witness' else None
    state = {'records': 0, 'failed': False}

    def stop(reason, record, details, snapshot=None):
        state['failed'] = True
        failure = {'reason': reason, 'forward_index': record['forward_index'],
                   'graph_mode': record['graph_mode'], 'actual_tokens': record['actual_tokens'],
                   'keys': record['keys'], 'details': details}
        with (root / 'STOP.json').open('x') as stream:
            json.dump(failure, stream, indent=2)
        if snapshot is not None:
            with (root / 'first-module-difference.pt').open('xb') as stream:
                torch.save(snapshot, stream)
        print('FULL_PROBE_STOP ' + json.dumps(failure), flush=True)
        raise RuntimeError(f'FULL_PROBE_FIRST_DIFFERENCE {reason} forward={record["forward_index"]}')

    def before(record):
        if state['failed']:
            raise RuntimeError('FULL_PROBE_STOPPED')
        if mode == 'witness':
            runner._diagnostic_boundary_begin(record['forward_index'] + 1, record['actual_tokens'])

    def after(record, result):
        step, rows = record['forward_index'], record['actual_tokens']
        model = runner.get_model().model
        # Include the actual residual buffer consumed by the MTP draft, beyond
        # the final hidden and auxiliary features returned by the target model.
        observed = {'forward_index': step, 'actual_tokens': rows,
                    'result': tree_digest(result, rows),
                    'mtp_hidden': tensor_digest(model._mtp_hidden_buffer, rows)}
        outer_file.write(json.dumps(observed) + '\n')
        state['records'] += 1
        if mode == 'control':
            return
        snapshot = runner._diagnostic_boundary_snapshot(record['positions'], step + 1)
        digests = {str(index): {key: tensor_digest(value, rows) for key, value in fields.items()}
                   for index, fields in snapshot.items()}
        stages = {'forward_index': step, 'actual_tokens': rows, 'layers': digests}
        stage_file.write(json.dumps(stages) + '\n')
        if expected_stages is None:
            if expected_outer is None or step >= len(expected_outer) or observed != expected_outer[step]:
                stop('native_instrumentation_changed_target_or_draft_hidden', record,
                     {'actual': observed, 'expected': expected_outer[step] if expected_outer and step < len(expected_outer) else None}, snapshot)
            # Preserve Native values for immediate ULP/error localization once
            # PTO first diverges; only rank0 and real active rows are saved.
            with (root / f'step{step:03d}.pt').open('xb') as stream:
                torch.save(snapshot, stream)
            return
        if step >= len(expected_stages):
            stop('missing_native_stage_reference', record, {}, snapshot)
        reference = expected_stages[step]
        if reference['forward_index'] != step or reference['actual_tokens'] != rows:
            stop('native_stage_reference_shape', record, reference, snapshot)
        # The ordering follows each layer's forward. Missing/extra stages fail
        # qualification rather than silently skipping a boundary.
        for index in sorted(snapshot):
            actual = digests[str(index)]
            native = reference['layers'].get(str(index))
            if native is None or set(native) != set(actual):
                stop('native_stage_layout', record, {'layer': index}, snapshot)
            for name in ('input', 'positions', 'normed', 'heads', 'oproj', 'attention_half', 'output'):
                if name in actual and actual[name] != native[name]:
                    stop('module_boundary', record, {'layer': index, 'stage': name,
                                                    'actual': actual[name], 'expected': native[name]}, snapshot)
        if expected_outer is None or step >= len(expected_outer) or observed != expected_outer[step]:
            stop('after_decoder_layers_or_draft_features', record,
                 {'actual': observed, 'expected': expected_outer[step] if expected_outer and step < len(expected_outer) else None}, snapshot)

    def finish():
        outer_file.close()
        if stage_file is not None:
            stage_file.close()
        expected_count = len(expected_outer) if expected_outer is not None else state['records']
        complete = state['records'] > 0 and not state['failed'] and state['records'] == expected_count
        report = {'complete': complete, 'records': state['records'], 'mode': mode,
                  'outer_reference': outer_reference, 'stage_reference': stage_reference,
                  'scope': 'rank0 real rows; FULL stage freshness enforced; outer hidden/aux/MTP fidelity'}
        (root / 'complete.json').write_text(json.dumps(report, indent=2) + '\n')
        del runner._diagnostic_before_forward
        del runner._diagnostic_after_forward
        if mode == 'witness':
            runner._diagnostic_boundary_uninstall()
        if not complete:
            raise RuntimeError('FULL probe incomplete or failed')
        return report

    runner._diagnostic_before_forward = before
    runner._diagnostic_after_forward = after
    observer._full_probe_finish = finish
