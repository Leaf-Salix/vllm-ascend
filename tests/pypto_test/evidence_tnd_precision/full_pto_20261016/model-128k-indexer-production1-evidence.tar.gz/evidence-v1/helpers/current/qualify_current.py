"""Exact current PTO vs untouched single Native1; no layer-stage/performance claim."""
import argparse
import ast
import json
from pathlib import Path

from audit_alignment import audit
from check_inputs import BASE, JOB, NATIVE, REFERENCE, SOURCE, sha, verify
from qualify192 import read_rows, source_identity

COMMON = ('attention','bank','batch','decode_tokens','event_work_mode',
          'num_gpu_blocks_override','gpu_memory_utilization',
          'official_static_cache_sha256','bank_plan_sha256',
          'runtime_package_manifest_sha256','runtime_package',
          'bootstrap_sha256','witness_sha256')

def qualify(right_root):
    verify()
    left,ltrace,loutput,laccept,lobs = audit(NATIVE,require_ready_reuse=False)
    right,rtrace,routput,raccept,robs = audit(right_root,require_ready_reuse=False)
    assert left['backend']=='native' and right['backend']=='pto'
    assert all(left[k]==right[k] for k in COMMON)
    assert left['variant']=='tnd_precision' and right['variant']=='tnd_full_precision'
    assert left['production_git_commit']=='cbc810c8afab47c2425068049440424f014dcde3'
    assert right['production_git_commit']=='c1ef141ae'
    assert right['source_manifest_sha256']=='d997d41080882209007134564ca488ce19cfe7f136397b6fd0e389c929001638'
    assert Path(right['snapshot']).resolve()==(SOURCE/'source').resolve()
    for config in (left,right):
        source_identity(config)
        assert config['full_probe_mode']=='control' and config['stage_reference'] is None
    assert not (right_root/'full-probe/stages.jsonl').exists()
    assert right['capture_sizes']==[6,144] and right['max_num_batched_tokens']==400
    assert right['wkv_restored'] is True and right['indexer_projection_restored'] is True
    assert right['wkv_order_map_sha256']=='ba7885227b29b521f7dcbde69ff79bc4bf6c706c1942c59985a01ee323ae7255'
    assert right['indexer_order_map_sha256']=='700c26586fe104bf92ffbb5d6eba74d307ba4c67df9eeac08363c729d2ec71fc'
    for key,name in (('bootstrap_sha256','sitecustomize.py'),('witness_sha256','capture_boundaries.py'),('trace_helper_sha256','admission_trace.py'),('generation_window_sha256','generation_window.py'),('full_probe_sha256','full_probe.py')):
        assert right[key]==sha(JOB/name),name
    # The Native trace predates the already reviewed strict empty-tail transition.
    transition=json.loads((BASE/'retest192-20261016/diagnostic-window-transition.json').read_text())
    assert left['trace_helper_sha256']==transition['admission_trace_before_sha256']
    assert right['trace_helper_sha256']==transition['admission_trace_after_sha256']
    assert left['full_probe_sha256']==sha(BASE/'retest192-20261016/full_probe.py')
    assert right['full_probe_sha256']==sha(BASE/'full-pto-model-8k-b40-20261016/full_probe.py')
    assert right['generation_reference_manifest_sha256']==sha(REFERENCE/'manifest.json')
    assert Path(right['trace_reference']).resolve()==(REFERENCE/'input-trace').resolve()
    assert Path(right['outer_reference']).resolve()==(REFERENCE/'full-probe').resolve()
    # Check the same tested identity-only harness patch, leaving numerical gates intact.
    debug=BASE/'full-pto-model-8k-b40-20261016/indexer-production-v1'
    mixed='tests/pypto_test/low_acceptance_20261001/mixed.py'
    assert (SOURCE/'source'/mixed).read_bytes()==(debug/'mixed.py').read_bytes()
    original=ast.parse((debug/'mixed-original.py').read_text())
    patched=ast.parse((debug/'mixed.py').read_text())
    for name in ('wait_for_generation_peers','collect'):
        before=[n for n in original.body if isinstance(n,ast.FunctionDef) and n.name==name]
        after=[n for n in patched.body if isinstance(n,ast.FunctionDef) and n.name==name]
        assert len(before)==len(after)==1 and ast.dump(before[0])==ast.dump(after[0])
    oldrun=next(n for n in original.body if isinstance(n,ast.FunctionDef) and n.name=='run_batches')
    newrun=next(n for n in patched.body if isinstance(n,ast.FunctionDef) and n.name=='run_batches')
    remove=lambda fn:[n for n in fn.body if not (isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='worker') and not (isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='validate_implementations')]
    assert [ast.dump(n) for n in remove(oldrun)]==[ast.dump(n) for n in remove(newrun)]
    # Baseline references are checked against every raw source/derived file in verify().
    assert ltrace==rtrace,'Actual inputs/admission first differ'
    assert loutput==routput and laccept==raccept,'Complete tokens/events first differ'
    count=len(ltrace[0])
    lo=read_rows(NATIVE,'outer.jsonl','control',count)
    ro=read_rows(right_root,'outer.jsonl','control',count)
    assert lo==ro,'Rank0 hidden/aux/MTP bits first differ'
    for step,(outer,trace) in enumerate(zip(ro,rtrace[0],strict=True)):
        assert outer['forward_index']==step and outer['actual_tokens']==trace['actual_tokens']
    caches=[]
    for rank in range(16):
        data=json.loads((right_root/f'rank{rank}.mixed.json').read_text())
        obs=data['observation'][0]
        for layer in range(2,43,2):
            counts=obs['capture_time_selection'][f'model.layers.{layer}.self_attn.attn']
            assert all(counts.get(f'pto_tokens{t}',0)>=2 for t in (6,144)),(rank,layer)
        stats=obs['pypto_cache_stats']
        assert all(stats[k]==0 for k in ('bypasses','invalid_entries','storage_errors','forced_rebuilds'))
        ready=stats['ready_hits']>0 and stats['generation_builds']==stats['binary_builds']==0
        caches.append({'rank':rank,'strict_ready_reuse':ready,'cache_stats':stats})
    binding=json.loads((REFERENCE/'manifest.json').read_text())
    return {'numeric_pass':True,'wkv_restored':True,'indexer_projection_restored':True,
            'production_git_commit':right['production_git_commit'],
            'source_manifest_sha256':right['source_manifest_sha256'],
            'helper_manifest_sha256':sha(JOB/'helper-manifest.json'),
            'native_runs_this_round':0,'native2_run':False,'internal_layer_stages_tested':False,
            'all16_gpu_inputs_and_admissions_equal':True,'all16_complete_tokens_and_events_equal':True,
            'rank0_outer_hidden_aux_mtp_bit_equal':True,'generation_records':count,
            'requests':binding['output_requests'],'tokens':binding['output_tokens'],
            'acceptance':{k:v for k,v in raccept.items() if k!='requests'},
            'native_observed':lobs,'csa_observed':robs,'cache':caches,
            'strict_ready_reuse':all(c['strict_ready_reuse'] for c in caches),
            'scope':'fixed131072 real model TP1 DP=EP16; B24 submitted with waiting; 192 output tokens; FULL[6,144]; no new Native2/internal-stage/performance claim'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('csa',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    result=qualify(a.csa)
    with a.output.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('cache','native_observed','csa_observed')},ensure_ascii=False))
