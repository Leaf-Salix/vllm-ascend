"""Collect small raw evidence for both arms; omit weights and cache tensors."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
job=base/'full-pto-model-128k-b24-20261017'
dst=job/'evidence-v1'
dst.mkdir(exist_ok=False)

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def copy(p,name):
    target=dst/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(p,target)

for arm,label in (('native','retest192-native1-b24000'),('csa','full-pto128k-indexer-production1-20261017')):
    root=Path('/data/pyptouser/yejia/lc128')/label
    for pattern in ('configuration.json','launch.log','rank*.mixed.json','rank*.log','request_stats_rank*.jsonl','input-trace/*.json','input-trace/*.jsonl','full-probe/*.json','full-probe/*.jsonl','acceptance.json','acceptance_summary.log'):
        for p in root.glob(pattern):
            copy(p,Path('results')/arm/p.relative_to(root))
for p in job.iterdir():
    if p.is_file() and p.suffix in ('.py','.sh','.json','.log'):
        copy(p,Path('helpers/current')/p.name)
old=base/'retest192-20261016'
for name in ('diagnostic-window-transition.json','audit_alignment.py','full_probe.py','qualify192.py','generation_window.py','admission_trace.py','sitecustomize.py','native-repeat-qualified.json'):
    copy(old/name,Path('helpers/historical')/name)
ref=old/'native1-generation-reference'
for p in ref.rglob('*'):
    if p.is_file() and p.suffix in ('.json','.jsonl'):
        copy(p,Path('native1-generation-reference')/p.relative_to(ref))
source=base/'full-pto-precision-20261017/step09'
for name in ('manifest.json','parent-manifest.json','frozen-source.json'):
    copy(source/name,Path('snapshots/step09')/name)
copy(base/'root-fix-20261016/manifest.json',Path('snapshots/native')/'manifest.json')
prefix='vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision/'
for name in ('service.py','input_norm_sum.cpp','wkv.py','wkv_order_data.py','indexer_projection.py','indexer_order_data.py'):
    copy(source/'source'/(prefix+name),Path('source')/(prefix+name))
bank=base/'low-acceptance-128k-b24-20261014/banks/fixed131072'
copy(bank/'plan.json',Path('bank/plan.json'))
for case in json.loads((bank/'plan.json').read_text())['cases']:
    copy(bank/case['tokens'],Path('bank')/case['tokens'])
task='task_20261017_130310_40506967427'
raw=subprocess.run(['task-submit','--list'],capture_output=True,text=True,check=True).stdout
lines=[x for x in raw.splitlines() if task in x]
(dst/'task-status.txt').write_text('\n'.join(lines)+'\n')
manifest={str(p.relative_to(dst)):sha(p) for p in sorted(dst.rglob('*')) if p.is_file()}
(dst/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=job/'evidence-v1.tar.gz'
with tarfile.open(archive,'w:gz') as t:
    t.add(dst,arcname=dst.name)
print(json.dumps({'sha256':sha(archive),'files':len(manifest),'bytes':archive.stat().st_size,'task_status':lines}))
