import hashlib, json, os, inspect
from pathlib import Path
import importlib
s=Path(os.environ["SOURCE_ROOT"]);r=s.parent
m=json.loads((r/"manifest.json").read_text())
for f,d in m["files"].items():
    assert hashlib.sha256((s/f).read_bytes()).hexdigest()==d, f
modules={}
for name in ("torch","torch_npu","vllm","vllm_ascend","pypto","simpler","npugraph_ex"):
    mod=importlib.import_module(name); modules[name]={"file":mod.__file__,"version":getattr(mod,"__version__",None)}
if os.environ.get('LOW_ACCEPTANCE_RUNTIME_PACKAGE'):
    package=Path(os.environ['LOW_ACCEPTANCE_RUNTIME_PACKAGE']).resolve()
    assert Path(modules['pypto']['file']).resolve().is_relative_to(package/'pypto')
    from pypto.jit._toolchain import capture_toolchain
    assert capture_toolchain('a2a3','tensormap_and_ringbuffer').usable
    print('PYPTO_TOOLCHAIN_USABLE=1',flush=True)
assert str(s) in modules["vllm_ascend"]["file"]
from vllm_ascend.ops.pypto.variant import variant_package
assert variant_package().endswith("deepseek_v4_flash_csa_tnd_full_precision")
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.service import CSAServiceRuntime
assert CSAServiceRuntime.variable_query_lengths
from offline_pd.connector import OfflineDSV4Connector
assert "return history, False" in inspect.getsource(OfflineDSV4Connector.get_num_new_matched_tokens)
from low_acceptance_20261001.prepare_mixed import questions
assert len(questions())==40 and len(set(q for _,q in questions()))==40
model=Path("/data/model/DeepSeek-V4-Flash-0731-w8a8");idx=json.loads((model/"quant_model_weights.safetensors.index.json").read_text())
shards=set(idx["weight_map"].values());assert len(shards)==75 and all((model/f).is_file() for f in shards)
for name in ("ASCEND_HOME_PATH","ATB_HOME_PATH","PTOAS_ROOT"):
    assert os.environ.get(name),name
assert os.environ["HCCL_DETERMINISTIC"]=="true"
print(json.dumps({"modules":modules,"commit":m["codex_commit"],"env":{k:os.environ.get(k) for k in ("ASCEND_HOME_PATH","ATB_HOME_PATH","PTOAS_ROOT","PTO_CSA_VARIANT","PTO_CSA_RUNTIME")},"model_shards":len(shards),"sync_bank_load":True,"variable_query_lengths":True},indent=2))
