"""Strict generation-prefix qualification; keep every raw post-completion row."""
IGNORED_TAIL_FIELDS = {'execute_index', 'forward_index'}


def validate_empty_tail(row, prototype=None, world=16):
    empty = ('keys', 'query_lengths', 'scheduled_tokens', 'input_ids', 'positions',
             'seq_lens', 'new_keys', 'finished_keys', 'preempted_keys')
    if (row['active'] or row['actual_tokens'] != 0 or row['query_bounds'] != [0]
            or any(row[key] != [] for key in empty)
            or row['graph_mode'] != 'FULL' or row['padded_tokens'] != 6
            or row['dp_tokens_across_ranks'] != [6]*world
            or len(row['padded_input_ids']) != 6 or len(row['padded_positions']) != 6):
        raise ValueError('Not a verified post-generation empty tail')
    if prototype is not None:
        normalize = lambda value: {k:v for k,v in value.items() if k not in IGNORED_TAIL_FIELDS}
        if normalize(row) != normalize(prototype):
            raise ValueError('Empty-tail inputs differ from qualified prototype')


def generation_window(traces, world=16):
    from admission_trace import validate_joint
    if len(traces) != world or any(not rows for rows in traces):
        raise ValueError('Missing raw rank trace')
    end = max((index+1 for rows in traces for index,row in enumerate(rows)
               if row['active'] or row['actual_tokens'] != 0), default=0)
    if end == 0 or any(len(rows) < end for rows in traces):
        raise ValueError('Incomplete joint generation prefix')
    prefix = [rows[:end] for rows in traces]
    validate_joint(prefix, world)
    summary=[]
    for rank,rows in enumerate(traces):
        prototype=rows[end] if len(rows)>end else None
        for index,row in enumerate(rows):
            if row['rank'] != rank or row['forward_index'] != index:
                raise ValueError('Raw rank/round identity differs')
            if index >= end:
                validate_empty_tail(row, prototype, world)
        summary.append({'rank':rank,'raw_records':len(rows),'window_records':end,
                        'tail_records':len(rows)-end,'tail_prototype':prototype})
    return prefix, summary
