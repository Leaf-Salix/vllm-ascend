#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/full-pto-precision-20261016/step01/env.sh"
experiment_dir="$base/full-pto-precision-20261016/hcpre-native-probe-v2"
python "$base/full-pto-precision-20261016/step01/check_frozen.py"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE" LOCAL_WORLD_SIZE=1 OMP_NUM_THREADS=4
native_dir="$base/full-pto-precision-20261016/hcpre-native-v2a"
export HCPRE_BRIDGE="$native_dir/bridge-build/dsv4_hcpre_observe16_bridge.so"
test -f "$HCPRE_BRIDGE"
vendor=$(python - "$native_dir" <<'PYV'
import sys
from pathlib import Path
paths=list((Path(sys.argv[1])/'install/packages/vendors').glob('*/op_api/lib/libcust_opapi.so'))
assert len(paths)==1,paths
vendor=paths[0].parents[2]
assert (vendor/'op_impl/ai_core/tbe/kernel/config/ascend910_93/hc_pre_full_diag.json').is_file(), 'missing generated op config index'
assert (vendor/'op_impl/ai_core/tbe/kernel/config/ascend910_93/binary_info_config.json').is_file()
print(vendor)
PYV
)
export ASCEND_CUSTOM_OPP_PATH="$vendor:${ASCEND_CUSTOM_OPP_PATH:-}"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/fppre.XXXXXX)
trap 'rmdir "$TMPDIR" 2>/dev/null || true' EXIT
out="/data/pyptouser/yejia/fp16/${1:?}"
test ! -e "$out"
mkdir -p "$out"
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$SOURCE_ROOT/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$out/opp_env")
export ASCEND_CACHE_PATH="$out/cache" ASCEND_PROCESS_LOG_PATH="$out/logs"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH"
cd "$out"
python "$experiment_dir/hcpre_probe.py" --out "$out/result" > "$out/run.log" 2>&1
