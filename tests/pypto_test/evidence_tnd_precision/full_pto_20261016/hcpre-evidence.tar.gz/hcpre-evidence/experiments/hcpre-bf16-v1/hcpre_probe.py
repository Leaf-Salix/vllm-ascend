"""HC-pre实际fused Native黄金及旧PTO首次差异；单模块，不改生产源。"""
import argparse
import hashlib
import json
import os
from pathlib import Path

import torch
import torch_npu
import pypto.torch
from safetensors import safe_open
from vllm_ascend.utils import enable_custom_op
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.hc_pre import hc_pre_test

p = argparse.ArgumentParser()
p.add_argument('--out', type=Path, required=True)
p.add_argument('--tokens', type=int, default=11)
p.add_argument('--seed', type=int, default=17)
p.add_argument('--layer', type=int, default=4)
a = p.parse_args()
assert 0 < a.tokens <= 256, 'diagnostic Native mDim=1 scope only'
a.out.mkdir(exist_ok=False, parents=True)
report = {'complete': False, 'pass': False, 'module': 'hc_pre', 'tokens': a.tokens,
          'seed': a.seed, 'layer': a.layer, 'scope': 'real HC weights, synthetic hidden; independent module only',
          'native_gold': 'actual installed npu_hc_pre_v2', 'comparisons': [],
          'production_modified': False, 'mode': 'PTO BF16 widening + extern HF32 + Native-order DSL, original weights, no compiler interception', 'task_device': os.environ['TASK_DEVICE']}
def save():
    (a.out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
def exact(x, y):
    return x.shape == y.shape and x.dtype == y.dtype and torch.equal(x.contiguous().view(torch.uint8), y.contiguous().view(torch.uint8))
def metric(x, y):
    x, y = x.cpu(), y.cpu()
    diff = x.float() - y.float()
    return {'bit_equal': exact(x, y), 'different_elements': int((x != y).sum()),
            'max_abs': float(diff.abs().max()), 'rel_l2': float(diff.norm() / y.float().norm()),
            'first_coordinates': (x != y).nonzero()[:8].tolist()}
def check(label, actual, expected):
    metrics = {k: metric(x, expected[k]) for k, x in actual.items()}
    report['comparisons'].append({'label': label, 'metrics': metrics}); save()
    if not all(v['bit_equal'] for v in metrics.values()):
        torch.save({'actual': actual, 'expected': expected, 'hidden': hidden.cpu(),
                    'weights': {k: v.cpu() for k, v in weights.items()}}, a.out / 'first-difference.pt')
        raise RuntimeError('FIRST_BIT_DIFFERENCE ' + label)

torch.npu.set_device(0)
torch.use_deterministic_algorithms(True)
torch_npu.npu.set_deterministic_level(1)
torch.set_num_threads(4)
assert enable_custom_op()
checkpoint = Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config = json.loads((checkpoint / 'config.json').read_text())
weight_map = json.loads((checkpoint / 'quant_model_weights.safetensors.index.json').read_text())['weight_map']
weights = {}
for name in ('hc_attn_fn', 'hc_attn_scale', 'hc_attn_base'):
    key = f'layers.{a.layer}.{name}'
    with safe_open(checkpoint / weight_map[key], framework='pt', device='cpu') as reader:
        cpu = reader.get_tensor(key)
    assert cpu.dtype == torch.float32
    weights[name] = cpu.to('npu')
    report.setdefault('weights', {})[key] = {'shape': list(cpu.shape), 'shard': weight_map[key],
        'sha256': hashlib.sha256(cpu.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()}
gen = torch.Generator().manual_seed(a.seed)
hidden = torch.randn((a.tokens, 4, 4096), generator=gen, dtype=torch.bfloat16).to('npu')
original = hidden.clone()
inputs_before = [v.clone() for v in weights.values()]
names = ('mixed', 'post', 'comb')
def native():
    values = torch.ops._C_ascend.npu_hc_pre_v2(hidden, *weights.values(), config['hc_mult'],
        config['hc_sinkhorn_iters'], config['rms_norm_eps'], config['hc_eps'])
    return {k: v for k, v in zip(names, values)}
def snapshot(values):
    torch.npu.synchronize()
    return {k: v.cpu() for k, v in values.items()}
save()
try:
    with torch.inference_mode():
        first = snapshot(native())
        assert all(torch.isfinite(v).all() for v in first.values())
        check('native_repeat_A', snapshot(native()), first)
        graph = torch.npu.NPUGraph()
        with torch.npu.graph(graph):
            native_outputs = native()
        torch.npu.synchronize()
        graph_keepalive = (graph, native_outputs)
        for phase in ('A', 'B', 'A_restored'):
            hidden.copy_(original)
            if phase == 'B': hidden.add_(0.125)
            before = hidden.clone()
            gold = snapshot(native())
            for value in native_outputs.values(): value.fill_(float('nan'))
            graph.replay()
            actual = snapshot(native_outputs)
            check('native_graph_' + phase, actual, gold)
            if phase == 'B': assert not exact(actual['mixed'], first['mixed']), 'stale or nondiscriminating input'
            else: check('native_restore_' + phase, actual, first)
            assert exact(hidden, before), 'Native changed input'
            assert all(exact(x, y) for x, y in zip(weights.values(), inputs_before)), 'Native changed weights'
        report['native_qualification_pass'] = True; save()
        # First legacy-PTO difference ends this case. No later shape or model runs.
        pypto.torch.init(device=0, platform='a2a3', runtime='tensormap_and_ringbuffer')
        op = pypto.torch.register(hc_pre_test, 'diagnostic_full_pto_hcpre_20261016::external_bf16_hf32')
        report['compiler_interceptor_enabled'] = False
        call_weights = list(weights.values())
        owners = {'mixed': torch.full((a.tokens + 2, 4096), 0.0625, dtype=torch.bfloat16, device='npu'),
                  'post': torch.full((a.tokens + 2, 4), 0.0625, dtype=torch.float32, device='npu'),
                  'comb': torch.full((a.tokens + 2, 16), 0.0625, dtype=torch.float32, device='npu')}
        outputs = {k: v[1:-1] for k, v in owners.items()}
        for value in outputs.values(): value.fill_(float('nan'))
        op(hidden, *call_weights, *outputs.values())
        actual = snapshot(outputs)
        actual['comb'] = actual['comb'].reshape(a.tokens, 4, 4)
        assert all(torch.isfinite(v).all() for v in actual.values()), 'unwritten/nonfinite legacy output'
        assert all(bool((owner[0] == 0.0625).all() & (owner[-1] == 0.0625).all()) for owner in owners.values()), 'output guard'
        assert exact(hidden, original), 'PTO changed hidden'
        assert all(exact(x, y) for x, y in zip(weights.values(), inputs_before)), 'PTO changed weights'
        report['legacy_guards_pass'] = True
        check('external_hf32_vs_native_A', actual, first)
        graph = torch.npu.NPUGraph()
        with torch.npu.graph(graph): op(hidden, *call_weights, *outputs.values())
        graph_keepalive_pto = (graph, hidden, owners, op)
        for phase in ('A', 'B', 'A_restored'):
            hidden.copy_(original)
            if phase == 'B': hidden.add_(0.125)
            phase_gold = snapshot(native())
            check('native_repeat_' + phase, snapshot(native()), phase_gold)
            for value in outputs.values(): value.fill_(float('nan'))
            graph.replay()
            phase_actual = snapshot(outputs)
            phase_actual['comb'] = phase_actual['comb'].reshape(a.tokens, 4, 4)
            assert all(bool((owner[0] == 0.0625).all() & (owner[-1] == 0.0625).all()) for owner in owners.values())
            assert all(exact(x, y) for x, y in zip(weights.values(), inputs_before))
            check('packed_pto_graph_' + phase, phase_actual, phase_gold)
        report['raw_graph_ABA_pass'] = True
        report['complete'] = report['pass'] = True; save()
except Exception as exc:
    report['error'] = repr(exc); save(); raise
