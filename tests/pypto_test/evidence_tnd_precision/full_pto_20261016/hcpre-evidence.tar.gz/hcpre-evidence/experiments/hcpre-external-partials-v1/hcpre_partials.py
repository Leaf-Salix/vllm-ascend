"""仅供T11原语定位：768/22须先由实际Native header核验，不是通用生产实现。"""
import pypto.language as pl

@pl.jit.extern(source='hcpre_ab_hf32.cpp', core_type='aic')
def hcpre_ab_external(
    flat: pl.Tensor[[11, 16384], pl.FP32],
    weight: pl.Tensor[[24, 16384], pl.FP32],
    ab: pl.Out[pl.Tensor[[352, 32], pl.FP32]],
) -> pl.Tensor[[352, 32], pl.FP32]: ...

@pl.jit
def hcpre_partials(
    x: pl.Tensor[[11, 4, 4096], pl.FP32],
    weight: pl.Tensor[[24, 16384], pl.FP32],
    ab: pl.Out[pl.Tensor[[352, 32], pl.FP32]],
    a2: pl.Out[pl.Tensor[[352, 16], pl.FP32]],
):
    flat = pl.reshape(x, [11, 16384])
    with pl.spmd(22):
        ab = hcpre_ab_external(flat, weight, ab)
    for part in pl.spmd(22, name_hint='hcpre_a2_partial', allow_early_resolve=True):
        count = pl.min(768, 16384 - part * 768) // 32
        a2_acc = pl.create_tensor([16, 16], dtype=pl.FP32)
        for kb in pl.pipeline(0, count, stage=2):
            k = part * 768 + kb * 32
            lhs = pl.slice(flat, [16, 32], [0, k], valid_shape=[11, 32])
            a2_acc = pl.matmul_acc(a2_acc, lhs, lhs, b_trans=True, init_cond=(kb == 0))
        a2[part * 16:part * 16 + 16, 0:16] = a2_acc
    return ab, a2
