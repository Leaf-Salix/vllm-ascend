"""HC-pre实际fused Native黄金及旧PTO首次差异；单模块，不改生产源。"""
import argparse
import hashlib
import json
import os
from pathlib import Path

import torch
import torch_npu
import pypto.torch
from safetensors import safe_open
from vllm_ascend.utils import enable_custom_op
from hcpre_partials import hcpre_partials
from hf32_patch import install
from read_hcpre_workspace import read_workspace

p = argparse.ArgumentParser()
p.add_argument('--out', type=Path, required=True)
p.add_argument('--tokens', type=int, default=11)
p.add_argument('--seed', type=int, default=17)
p.add_argument('--layer', type=int, default=4)
a = p.parse_args()
a.out.mkdir(exist_ok=False, parents=True)
report = {'complete': False, 'pass': False, 'module': 'hc_pre_K32_partials', 'tokens': a.tokens,
          'seed': a.seed, 'layer': a.layer, 'scope': 'real HC weights, synthetic hidden; independent module only',
          'native_gold': 'actual installed npu_hc_pre_v2', 'comparisons': [],
          'production_modified': False, 'scope_partial_only': True, 'task_device': os.environ['TASK_DEVICE']}
def save():
    (a.out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
def exact(x, y):
    return x.shape == y.shape and x.dtype == y.dtype and torch.equal(x.contiguous().view(torch.uint8), y.contiguous().view(torch.uint8))
def metric(x, y):
    x, y = x.cpu(), y.cpu()
    diff = x.float() - y.float()
    return {'bit_equal': exact(x, y), 'different_elements': int((x != y).sum()),
            'max_abs': float(diff.abs().max()), 'rel_l2': float(diff.norm() / y.float().norm()),
            'first_coordinates': (x != y).nonzero()[:8].tolist()}
def check(label, actual, expected):
    metrics = {k: metric(x, expected[k]) for k, x in actual.items()}
    report['comparisons'].append({'label': label, 'metrics': metrics}); save()
    if not all(v['bit_equal'] for v in metrics.values()):
        torch.save({'actual': actual, 'expected': expected, 'hidden': hidden.cpu(),
                    'weights': {k: v.cpu() for k, v in weights.items()}}, a.out / 'first-difference.pt')
        raise RuntimeError('FIRST_BIT_DIFFERENCE ' + label)

torch.npu.set_device(0)
torch.use_deterministic_algorithms(True)
torch_npu.npu.set_deterministic_level(1)
torch.set_num_threads(4)
assert enable_custom_op()
checkpoint = Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config = json.loads((checkpoint / 'config.json').read_text())
weight_map = json.loads((checkpoint / 'quant_model_weights.safetensors.index.json').read_text())['weight_map']
weights = {}
for name in ('hc_attn_fn', 'hc_attn_scale', 'hc_attn_base'):
    key = f'layers.{a.layer}.{name}'
    with safe_open(checkpoint / weight_map[key], framework='pt', device='cpu') as reader:
        cpu = reader.get_tensor(key)
    assert cpu.dtype == torch.float32
    weights[name] = cpu.to('npu')
    report.setdefault('weights', {})[key] = {'shape': list(cpu.shape), 'shard': weight_map[key],
        'sha256': hashlib.sha256(cpu.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()}
gen = torch.Generator().manual_seed(a.seed)
hidden = torch.randn((a.tokens, 4, 4096), generator=gen, dtype=torch.bfloat16).to('npu')
original = hidden.clone()
inputs_before = [v.clone() for v in weights.values()]
names = ('mixed', 'post', 'comb')
def native():
    values = torch.ops._C_ascend.npu_hc_pre_v2(hidden, *weights.values(), config['hc_mult'],
        config['hc_sinkhorn_iters'], config['rms_norm_eps'], config['hc_eps'])
    return {k: v for k, v in zip(names, values)}
def snapshot(values):
    torch.npu.synchronize()
    return {k: v.cpu() for k, v in values.items()}
save()
try:
    with torch.inference_mode():
        assert a.tokens == 11
        gold = snapshot(native()); check('native_repeat_A', snapshot(native()), gold)
        torch.ops.load_library(os.environ['HCPRE_BRIDGE'])
        def reference(label):
            expected = snapshot(native())
            values = torch.ops.dsv4_hcpre_observe17.forward(hidden, *weights.values(), config['hc_mult'],
                config['hc_sinkhorn_iters'], config['rms_norm_eps'], config['hc_eps'])
            check('observer_fidelity_' + label, snapshot(dict(zip(names, values[:3]))), expected)
            result = read_workspace(values[3], hidden)
            t = result['header']
            assert (t['cubeBlockDimK'], t['multCoreSplitKSize'], t['mL1Size'], t['kL1Size']) == (22, 768, 16, 1024)
            return result
        ref = reference('A')
        cpu_weight = weights['hc_attn_fn'].cpu().contiguous()
        assert torch.isfinite(cpu_weight).all()
        nz=cpu_weight.abs()[cpu_weight != 0]
        assert (nz >= torch.finfo(torch.float32).tiny).all()
        prepared_cpu = torch.bitwise_and(cpu_weight.view(torch.int32) + 2047, -4096).view(torch.float32)
        assert torch.isfinite(prepared_cpu).all()
        prepared = prepared_cpu.to('npu')
        report['conversion'] = '11-fraction nearest/ties-toward-zero before unchanged HF32 MAD'
        report['prepared_sha256'] = hashlib.sha256(prepared_cpu.view(torch.uint8).numpy().tobytes()).hexdigest()
        patches = install(a.out)
        pypto.torch.init(device=0, platform='a2a3', runtime='tensormap_and_ringbuffer')
        op = pypto.torch.register(hcpre_partials, 'diagnostic_hcpre_partials_20261016::prepared_forward')
        wide = hidden.float()
        owners = {'ab': torch.full((354,32), 0.0625, dtype=torch.float32, device='npu'),
                  'a2': torch.full((354,16), 0.0625, dtype=torch.float32, device='npu')}
        outputs = {k:v[1:-1] for k,v in owners.items()}
        def run():
            op(wide, prepared, outputs['ab'], outputs['a2'])
        saved = {}
        def partial_check(label, expected):
            torch.npu.synchronize()
            full = {k:v.cpu() for k,v in outputs.items()}
            assert all(torch.isfinite(v).all() for v in full.values())
            assert all(bool((v[0] == 0.0625).all() & (v[-1] == 0.0625).all()) for v in owners.values())
            assert exact(wide, hidden.float()) and all(exact(x,y) for x,y in zip(weights.values(),inputs_before))
            actual = {'ab': full['ab'].reshape(22,16,32)[:,:11,:24].contiguous(),
                      'a2_diagonal': full['a2'].reshape(22,16,16).diagonal(dim1=1,dim2=2)[:,:11].contiguous()}
            expected = {k: expected[k] for k in actual}
            saved[label] = {'actual':actual,'expected':expected}
            torch.save(saved, a.out/'partial-values.pt')
            check(label, actual, expected)
        for value in outputs.values():value.fill_(float('nan'))
        run();partial_check('pto_eager_A',ref)
        assert len(patches) == 1, patches
        graph = torch.npu.NPUGraph()
        with torch.npu.graph(graph):run()
        keepalive = (graph,wide,owners,op)
        for phase in ('A','B','A_restored'):
            hidden.copy_(original)
            if phase=='B':hidden.add_(0.125)
            wide.copy_(hidden.float())
            expected = reference(phase)
            for value in outputs.values():value.fill_(float('nan'))
            graph.replay();partial_check('pto_graph_'+phase,expected)
        report['pass']=report['complete']=True
        report['hf32_patches']=patches
        report['raw_graph_ABA_pass']=True
        report['restored_production_modules']=[]
        save()
except Exception as exc:
    report['error']=repr(exc);save();raise
