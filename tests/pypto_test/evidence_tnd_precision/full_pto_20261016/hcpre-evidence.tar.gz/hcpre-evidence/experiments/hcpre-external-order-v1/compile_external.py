from pathlib import Path
from pypto.runtime import RunConfig
from pypto.runtime.kernel_compiler import KernelCompiler
from hcpre_native_order import hc_pre_test
job=Path(__file__).resolve().parent
out=job/'precompile'
out.mkdir(exist_ok=False)
program=hc_pre_test.compile(config=RunConfig(platform='a2a3'))
isa='/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/build/pto-isa'
binary=KernelCompiler('a2a3').compile_incore(str(job/'hc_pre_linear_hf32.cpp'),core_type='aic',pto_isa_root=isa,runtime_name='tensormap_and_ringbuffer',build_dir=str(out))
(out/'checked.elf').write_bytes(binary)
print('EXTERNAL_LOWER_CCEC_OK',len(binary),program.output_dir,flush=True)
