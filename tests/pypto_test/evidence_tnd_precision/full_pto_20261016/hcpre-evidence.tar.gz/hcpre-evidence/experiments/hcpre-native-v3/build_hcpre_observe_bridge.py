"""只编译私有小bridge，复用当前torch/torch_npu，不安装框架。"""
import hashlib
import json
import os
from pathlib import Path
import torch
import torch_npu
from torch.utils.cpp_extension import load

b = Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/full-pto-precision-20261016/hcpre-native-v3')
npu = Path(torch_npu.__file__).parent
cann = Path(os.environ['ASCEND_HOME_PATH'])
(b / 'bridge-build').mkdir(exist_ok=True)
os.environ['MAX_JOBS'] = '4'
os.environ['CCACHE_DIR'] = str(b / '.ccache')
wrapper = b / 'cxx-ccache'
wrapper.write_text('#!/bin/sh\nexec ccache /usr/bin/c++ "$@"\n')
wrapper.chmod(0o755)
os.environ['CXX'] = str(wrapper)
includes = [str(b / 'source/csrc'), str(npu / 'include'), str(npu / 'include/torch_npu/csrc/aten'),
            str(npu / 'include/torch_npu/csrc/core/npu'), str(cann / 'include')]
lib = load(name='dsv4_hcpre_observe17_bridge', sources=[str(b / 'bridge.cpp'),
    str(b / 'source/csrc/aclnn_torch_adapter/NPUBridge.cpp')], extra_include_paths=includes,
    extra_cflags=['-O2'], extra_ldflags=['-L' + str(npu / 'lib'), '-ltorch_npu',
    '-L' + str(cann / 'lib64'), '-lascendcl'], build_directory=str(b / 'bridge-build'),
    is_python_module=False, verbose=True)
(b / 'bridge-identity.json').write_text(json.dumps({'path': lib,
    'sha256': hashlib.sha256(Path(lib).read_bytes()).hexdigest(),
    'schema': str(torch.ops.dsv4_hcpre_observe17.forward.default._schema)}, indent=2) + '\n')
print('BRIDGE_LOAD_OK', lib)
