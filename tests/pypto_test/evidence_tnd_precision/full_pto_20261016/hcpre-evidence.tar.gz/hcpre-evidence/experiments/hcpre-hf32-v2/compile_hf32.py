"""无设备检查HF32诊断改写及CCEC；不更新正式包或已有缓存。"""
from pathlib import Path
from pypto.runtime import RunConfig
from pypto.runtime.kernel_compiler import KernelCompiler
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.hc_pre import hc_pre_test
from hf32_patch import install
job = Path(__file__).resolve().parent
out = job / 'precompile-v2'
out.mkdir(exist_ok=False)
records = install(out)
program = hc_pre_test.compile(config=RunConfig(platform='a2a3'))
sources = [p for p in Path(program.output_dir).rglob('hc_pre_linear.cpp') if p.parent.name == 'aic']
assert len(sources) == 1, sources
isa = '/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/build/pto-isa'
binary = KernelCompiler('a2a3').compile_incore(str(sources[0]), core_type='aic',
    pto_isa_root=isa, runtime_name='tensormap_and_ringbuffer', build_dir=str(out))
(out / 'checked.elf').write_bytes(binary)
assert len(records) == 1
print('CCEC_HF32_OK', len(binary), flush=True)
