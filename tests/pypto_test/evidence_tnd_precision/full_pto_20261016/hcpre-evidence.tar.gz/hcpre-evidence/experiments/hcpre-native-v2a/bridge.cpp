// Private diagnostic only. The renamed Native op has unchanged arithmetic.
#include <torch/extension.h>
#include <torch/library.h>
#include <torch_npu/csrc/framework/OpCommand.h>
#include "aclnn_torch_adapter/op_api_common.h"
#include "capture_exec.h"

namespace dsv4_hcpre_observe16 {
std::tuple<at::Tensor, at::Tensor, at::Tensor, at::Tensor> forward(
    const at::Tensor& x, const at::Tensor& fn, const at::Tensor& scale,
    const at::Tensor& base, int64_t mult, int64_t iters, double norm_eps, double hc_eps)
{
    TORCH_CHECK(x.dim() == 3 && x.size(1) == mult && x.size(2) == 4096 && mult == 4);
    auto y = at::empty({x.size(0), x.size(2)}, x.options());
    auto post = at::empty({x.size(0), mult}, x.options().dtype(at::kFloat));
    auto comb = at::empty({x.size(0), mult, mult}, x.options().dtype(at::kFloat));
    at::Tensor observed_owner, observed_workspace;
    EXEC_NPU_CMD_CAPTURE(aclnnHcPreFullDiag, x, fn, scale, base, mult, iters, hc_eps, norm_eps, y, post, comb);
    return {y, post, comb, observed_workspace};
}
}
TORCH_LIBRARY(dsv4_hcpre_observe16, ops) {
    ops.def("forward(Tensor x, Tensor fn, Tensor scale, Tensor base, int mult, int iters, float norm_eps, float hc_eps) -> (Tensor, Tensor, Tensor, Tensor)");
    ops.impl("forward", torch::kPrivateUse1, &dsv4_hcpre_observe16::forward);
}
