"""只按显式header及原生源码布局读取有效partials，不用近似数值猜地址。"""
import numpy as np
import torch

FIELDS = ('magic', 'schema', 'self', 'kernel_workspace', 'bs', 'hcMix', 'hcMult', 'd',
          'cubeCoreNum', 'mL1Size', 'kL1Size', 'cubeBlockDimM', 'cubeBlockDimK',
          'multCoreSplitKSize', 'multCoreSplitMSize', 'cvLoopKSize', 'secondUsedCoreNum',
          'stage2RowFactor', 'k', 'xCastBytes')

def read_workspace(workspace, hidden):
    assert workspace.dtype == torch.uint8 and workspace.is_contiguous()
    assert workspace.storage_offset() == 512
    size = workspace.numel()
    owner = workspace.as_strided((size + 1024,), (1,), storage_offset=0)
    assert bool((owner[:512].cpu() == 167).all())
    assert bool((owner[-512:].cpu() == 167).all())
    raw = workspace.cpu().numpy()
    assert raw.size % 8 == 0
    words = raw.view(np.uint64)
    indices = np.flatnonzero(words == np.uint64(0x4850435052453136))
    assert len(indices) == 1, ('missing/nonunique declared header', indices.tolist())
    index = int(indices[0]); offset = index * 8
    assert offset % 512 == 0 and offset + 512 <= size
    header = words[index:index + 64].copy()
    assert len(header) == 64 and int(header[1]) == 1 and int(header[28]) == 512
    assert int(header[2]) == workspace.data_ptr() + offset, 'device/host address domain mismatch'
    assert workspace.data_ptr() <= int(header[3]) < workspace.data_ptr() + size
    current = hidden.cpu().contiguous().view(torch.uint16).flatten()[:8].tolist()
    assert header[20:28].tolist() == current, 'stale header input marker'
    t = {name: int(header[i]) for i, name in enumerate(FIELDS)}
    assert t['bs'] == hidden.shape[0] and 1 <= t['bs'] <= 16
    assert (t['hcMix'], t['hcMult'], t['d'], t['k']) == (24, 4, 4096, 16384)
    assert t['cubeBlockDimM'] == 1 and t['cubeCoreNum'] == 24
    assert t['mL1Size'] == t['multCoreSplitMSize'] == 16
    assert t['cvLoopKSize'] == 1024
    parts = t['cubeBlockDimK']; rows = t['bs']
    assert 0 < parts <= t['cubeCoreNum']
    assert parts == (t['k'] + t['multCoreSplitKSize'] - 1) // t['multCoreSplitKSize']
    xcast = t['cubeCoreNum'] * 2 * t['mL1Size'] * ((t['cvLoopKSize'] + 127) // 128 * 128) * 4
    assert xcast == t['xCastBytes'] and xcast >= 512
    # MM_CACHE_LINE_BYTES=512 => AB physical row stride128 FP32, only24 valid.
    ab_byte = offset + xcast
    ab_bytes = parts * rows * 128 * 4
    a2_byte = ab_byte + (ab_bytes + 511) // 512 * 512
    a2_stride = (rows + 15) // 16 * 16 * 16
    assert a2_byte + parts * a2_stride * 4 <= size
    floats = raw.view(np.float32)
    ab = floats[ab_byte // 4:ab_byte // 4 + parts * rows * 128].reshape(parts, rows, 128)[:, :, :24].copy()
    diagonal = np.arange(rows) * 16 + np.arange(rows) % 16
    a2 = np.stack([floats[a2_byte // 4 + part * a2_stride + diagonal] for part in range(parts)])
    # This calibration uses exact one-hot rows in K partition0, not random hidden.
    # Check the stronger known diagonal rather than random-input positivity.
    assert np.isfinite(ab).all() and np.isfinite(a2).all()
    assert np.array_equal(a2[0], np.ones(rows, dtype=np.float32))
    assert np.count_nonzero(a2[1:]) == 0
    return {'header': t, 'input_marker': current, 'workspace_size': size, 'user_workspace_offset': offset,
            'guards_pass': True, 'ab': torch.from_numpy(ab), 'a2_diagonal': torch.from_numpy(a2.copy())}
