"""HC-pre实际fused Native黄金及旧PTO首次差异；单模块，不改生产源。"""
import argparse
import hashlib
import json
import os
from pathlib import Path

import torch
import torch_npu
from safetensors import safe_open
from vllm_ascend.utils import enable_custom_op

p = argparse.ArgumentParser()
p.add_argument('--out', type=Path, required=True)
p.add_argument('--tokens', type=int, default=11)
p.add_argument('--seed', type=int, default=17)
p.add_argument('--layer', type=int, default=4)
a = p.parse_args()
a.out.mkdir(exist_ok=False, parents=True)
report = {'complete': False, 'pass': False, 'module': 'hc_pre', 'tokens': a.tokens,
          'seed': a.seed, 'layer': a.layer, 'scope': 'real HC weights, synthetic hidden; independent module only',
          'native_gold': 'actual installed npu_hc_pre_v2', 'comparisons': [],
          'production_modified': False, 'uninstrumented_clone': False, 'workspace_observation_only': True, 'task_device': os.environ['TASK_DEVICE']}
def save():
    (a.out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
def exact(x, y):
    return x.shape == y.shape and x.dtype == y.dtype and torch.equal(x.contiguous().view(torch.uint8), y.contiguous().view(torch.uint8))
def metric(x, y):
    x, y = x.cpu(), y.cpu()
    diff = x.float() - y.float()
    return {'bit_equal': exact(x, y), 'different_elements': int((x != y).sum()),
            'max_abs': float(diff.abs().max()), 'rel_l2': float(diff.norm() / y.float().norm()),
            'first_coordinates': (x != y).nonzero()[:8].tolist()}
def check(label, actual, expected):
    metrics = {k: metric(x, expected[k]) for k, x in actual.items()}
    report['comparisons'].append({'label': label, 'metrics': metrics}); save()
    if not all(v['bit_equal'] for v in metrics.values()):
        torch.save({'actual': actual, 'expected': expected, 'hidden': hidden.cpu(),
                    'weights': {k: v.cpu() for k, v in weights.items()}}, a.out / 'first-difference.pt')
        raise RuntimeError('FIRST_BIT_DIFFERENCE ' + label)

torch.npu.set_device(0)
torch.use_deterministic_algorithms(True)
torch_npu.npu.set_deterministic_level(1)
torch.set_num_threads(4)
assert enable_custom_op()
checkpoint = Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config = json.loads((checkpoint / 'config.json').read_text())
weight_map = json.loads((checkpoint / 'quant_model_weights.safetensors.index.json').read_text())['weight_map']
weights = {}
for name in ('hc_attn_fn', 'hc_attn_scale', 'hc_attn_base'):
    key = f'layers.{a.layer}.{name}'
    with safe_open(checkpoint / weight_map[key], framework='pt', device='cpu') as reader:
        cpu = reader.get_tensor(key)
    assert cpu.dtype == torch.float32
    weights[name] = cpu.to('npu')
    report.setdefault('weights', {})[key] = {'shape': list(cpu.shape), 'shard': weight_map[key],
        'sha256': hashlib.sha256(cpu.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()}
gen = torch.Generator().manual_seed(a.seed)
hidden = torch.randn((a.tokens, 4, 4096), generator=gen, dtype=torch.bfloat16).to('npu')
original = hidden.clone()
inputs_before = [v.clone() for v in weights.values()]
names = ('mixed', 'post', 'comb')
def native():
    values = torch.ops._C_ascend.npu_hc_pre_v2(hidden, *weights.values(), config['hc_mult'],
        config['hc_sinkhorn_iters'], config['rms_norm_eps'], config['hc_eps'])
    return {k: v for k, v in zip(names, values)}
def snapshot(values):
    torch.npu.synchronize()
    return {k: v.cpu() for k, v in values.items()}
save()
try:
    with torch.inference_mode():
        assert a.tokens == 11
        offsets=[0,1,1023,1024,1025,2047,2048,2049,3071,3072,3073,4095,4096,4097,6143,6144,6145,8191,8192,8193,12287,12288,12289,16383,16384,16385]
        input_bits=torch.tensor([0x3c000000 + offsets[i % len(offsets)] + ((i // len(offsets)) % 3)*0x800000 + (0x80000000 if i>=132 else 0) for i in range(264)],dtype=torch.int64).to(torch.int32).reshape(11,24)
        samples=input_bits.view(torch.float32).contiguous()
        synthetic_fn=torch.zeros_like(weights['hc_attn_fn'],device='cpu')
        synthetic_fn[:,:11]=samples.T
        weights['hc_attn_fn'].copy_(synthetic_fn)
        inputs_before=[v.clone() for v in weights.values()]
        hidden.zero_()
        hidden.view(11,-1)[:,:11].copy_(torch.eye(11,device='npu',dtype=torch.bfloat16))
        original=hidden.clone()
        gold=snapshot(native());check('actual_native_repeat',snapshot(native()),gold)
        torch.ops.load_library(os.environ['HCPRE_BRIDGE'])
        values=torch.ops.dsv4_hcpre_observe17.forward(hidden,*weights.values(),config['hc_mult'],config['hc_sinkhorn_iters'],config['rms_norm_eps'],config['hc_eps'])
        check('observer_fidelity',snapshot(dict(zip(names,values[:3]))),gold)
        from read_hcpre_workspace import read_workspace
        observed=read_workspace(values[3],hidden)
        assert (observed['header']['cubeBlockDimK'],observed['header']['multCoreSplitKSize'])==(22,768)
        converted=observed['ab'][0]
        assert not torch.count_nonzero(observed['ab'][1:])
        assert torch.equal(observed['a2_diagonal'][0],torch.ones(11))
        assert not torch.count_nonzero(observed['a2_diagonal'][1:])
        raw=input_bits.to(torch.int64)&0xffffffff
        models=[]
        for removed in range(1,17):
            mask=~((1<<removed)-1)
            for mode in ('truncate','nearest_zero','nearest_away','nearest_even'):
                bias=0 if mode=='truncate' else ((1<<(removed-1))-1 if mode in ('nearest_zero','nearest_even') else 1<<(removed-1))
                extra=((raw>>removed)&1) if mode=='nearest_even' else 0
                prepared=((raw+bias+extra)&mask).to(torch.int32).view(torch.float32)
                different=int((prepared.view(torch.int32)!=converted.view(torch.int32)).sum())
                models.append({'removed_bits':removed,'mode':mode,'different':different})
        report.update({'scope':'synthetic one-hot hidden and synthetic FP32 weight samples; actual Native conversion observation',
          'synthetic_weight_override':True,'exact_models':[m for m in models if m['different']==0],
          'models':models,'observed_tiling':observed['header'], 'workspace_guards_and_live_marker_pass':True})
        torch.save({'input':samples,'input_bits':input_bits,'converted':converted,'converted_bits':converted.view(torch.int32)},a.out/'conversion.pt')
        assert exact(hidden,original)
        assert all(exact(x,y) for x,y in zip(weights.values(),inputs_before))
        report['complete']=report['pass']=True;save()
except Exception as exc:
    report['error']=repr(exc);save();raise
