"""诊断专用：只在HC-pre linear的MAD处启用Native A3 HF32向零模式。"""
import hashlib
import json
from pathlib import Path
import re

from pypto.runtime.kernel_compiler import KernelCompiler

def install(output):
    original = KernelCompiler.compile_incore
    records = []
    def compile_patched(self, source_path, *args, **kwargs):
        source = Path(source_path)
        text = source.read_text()
        if source.stem != 'hc_pre_linear':
            return original(self, source_path, *args, **kwargs)
        assert kwargs.get('core_type') == 'aic', kwargs
        assert len(re.findall(r'#include [<"]pto/pto-inst.hpp[>"]', text)) == 1
        # Installed CANN asc/impl/basic_api/kernel_macros.h: mode46/trans47.
        # kernel_reg.h uses exactly set_ctrl(sbitset1(get_ctrl(), bit)).
        pattern = r'(?m)^(\s*)(TMATMUL(?:_ACC)?\([^\n]+\);)$'
        def replace(match):
            indent, call = match.groups()
            return (indent + '{\n' + indent + 'const uint64_t hcpre_saved_ctrl = get_ctrl();\n'
                    + indent + 'set_ctrl(sbitset1(sbitset1(hcpre_saved_ctrl, 46), 47));\n'
                    + indent + call + '\n' + indent + 'set_ctrl(hcpre_saved_ctrl);\n' + indent + '}')
        patched, count = re.subn(pattern, replace, text)
        assert count == 6, (source, count, 'unexpected code shape')
        destination = Path(output) / 'patched' / source.name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(patched)
        (destination.parent / ('original-' + source.name)).write_text(text)
        records.append({'source_sha256': hashlib.sha256(text.encode()).hexdigest(),
                        'patched_sha256': hashlib.sha256(patched.encode()).hexdigest(),
                        'calls_changed': count, 'path': str(destination)})
        (Path(output) / 'hf32-patches.json').write_text(json.dumps(records, indent=2) + '\n')
        return original(self, str(destination), *args, **kwargs)
    KernelCompiler.compile_incore = compile_patched
    return records
