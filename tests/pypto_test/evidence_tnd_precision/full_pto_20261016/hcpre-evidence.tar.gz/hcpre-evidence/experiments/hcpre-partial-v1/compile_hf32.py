"""无设备检查HF32诊断改写及CCEC；不更新正式包或已有缓存。"""
from pathlib import Path
from pypto.runtime import RunConfig
from pypto.runtime.kernel_compiler import KernelCompiler
from hcpre_partials import hcpre_partials
from hf32_patch import install
job = Path(__file__).resolve().parent
out = job / 'precompile-v5'
out.mkdir(exist_ok=False)
records = install(out)
program = hcpre_partials.compile(config=RunConfig(platform='a2a3'))
sources = [p for p in Path(program.output_dir).rglob('hcpre_ab_partial.cpp') if p.parent.name == 'aic']
assert len(sources) == 1, sources
isa = '/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/build/pto-isa'
binary = KernelCompiler('a2a3').compile_incore(str(sources[0]), core_type='aic',
    pto_isa_root=isa, runtime_name='tensormap_and_ringbuffer', build_dir=str(out))
(out / 'checked.elf').write_bytes(binary)
other = [p for p in Path(program.output_dir).rglob('hcpre_a2_partial.cpp') if p.parent.name == 'aic']
assert len(other) == 1
a2_binary = KernelCompiler('a2a3').compile_incore(str(other[0]), core_type='aic',
    pto_isa_root=isa, runtime_name='tensormap_and_ringbuffer', build_dir=str(out))
(out / 'checked-a2.elf').write_bytes(a2_binary)
assert len(records) == 1
print('CCEC_HF32_OK', len(binary), flush=True)
