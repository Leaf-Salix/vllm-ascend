from pathlib import Path
import hashlib,json,os
source=Path(os.environ['SOURCE_ROOT'])
manifest=json.loads((source.parent/'frozen-source.json').read_text())
for relative,digest in manifest.items():
    assert hashlib.sha256((source/relative).read_bytes()).hexdigest()==digest,relative
print('STEP04_FROZEN_OK',len(manifest),flush=True)
