#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/full-pto-precision-20261016/step01/env.sh"
experiment_dir="$base/full-pto-precision-20261016/hcpre-layer-v3"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE" LOCAL_WORLD_SIZE=1 OMP_NUM_THREADS=4
export PYTHONPATH="$experiment_dir:$PYTHONPATH"
python "$base/full-pto-precision-20261016/step01/check_frozen.py"
export SOURCE_ROOT="$base/full-pto-precision-20261016/step04/source"
export PYTHONPATH="$SOURCE_ROOT:$PYTHONPATH"
python "$experiment_dir/check_step04.py"
out="/data/pyptouser/yejia/fp16/${1:?}"
test ! -e "$out"
mkdir -p "$out"
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$SOURCE_ROOT/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$out/opp_env")
export PYPTO_PROG_BUILD_DIR="$out/build" VLLM_CACHE_ROOT="$out/vllm-cache"
export ASCEND_CACHE_PATH="$out/ascend-cache" ASCEND_PROCESS_LOG_PATH="$out/ascend"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/fphc.XXXXXX)
trap 'rmdir "$TMPDIR" 2>/dev/null || true' EXIT
cd "$out"
# This task is exactly the declared L4/T11 case; no implicit positional defaults.
probe_query_lengths=1,2,3,5
probe_layer_id=4
probe_history_tokens=8191
printf 'PROBE_CONFIG lengths=%s layer=%s history=%s\n' "$probe_query_lengths" "$probe_layer_id" "$probe_history_tokens"
python "$experiment_dir/full_layer_probe.py" --out="$out" --lengths="$probe_query_lengths" --layer="$probe_layer_id" --history="$probe_history_tokens" > "$out/run.log" 2>&1
