"""第二阶段私有观测：只写废弃xCast区，不改AB/A2和原三输出算术。"""
from pathlib import Path
import hashlib
import json
import shutil

root = Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/full-pto-precision-20261016')
old = root / 'hcpre-native-v1'
new = root / 'hcpre-native-v2a'
new.mkdir(exist_ok=True)
assert not (new / 'observer-manifest.json').exists(), 'completed observer must stay immutable'
def ignore(path, names):
    if Path(path) == old / 'source/csrc':
        return {'build_out', 'third_party', 'build'}.intersection(names)
    return {'__pycache__'}.intersection(names)
if not (new / 'source').exists():
    shutil.copytree(old / 'source', new / 'source', symlinks=True, ignore=ignore)
dependency = new / 'source/csrc/third_party'
if not dependency.is_symlink():
    dependency.symlink_to(old / 'source/csrc/third_party', target_is_directory=True)
for rel, digest in json.loads((old / 'manifest.json').read_text())['clone_files'].items():
    assert hashlib.sha256((new / 'source' / rel).read_bytes()).hexdigest() == digest, rel
kernel = new / 'source/csrc/moe/hc_pre_full_diag/op_kernel/hc_pre_full_diag.cpp'
text = kernel.read_text()
needle = 'using namespace AscendC;\n'
assert text.count(needle) == 1
text = text.replace(needle, needle + '\n#include "hcpre_stamp.hpp"\n')
# This exact block belongs to the A3 key0 path, after Part1's original SyncAll.
needle = '''            HcPreFullDiag::HcPreFullDiagMembaseKSplitCorePart1<DTYPE_X> op;
            op.Init(x, hc_fn, userWs, tilingData, &pipe);
            op.Process();

            pipe.Destroy();'''
assert text.count(needle) == 1
text = text.replace(needle, needle + '\n            StampHcPreWorkspace(userWs, workspace, x, tilingData);')
kernel.write_text(text)
shutil.copyfile(root / 'hcpre_stamp.hpp', kernel.parent / 'hcpre_stamp.hpp')
# Preserve original EXEC_NPU_CMD semantics; only retain the actual workspace owner.
header = (old / 'source/csrc/aclnn_torch_adapter/op_api_common.h').read_text()
macro = header[header.index('#define EXEC_NPU_CMD('):header.rindex('\n#endif')].strip()
macro = macro.replace('#define EXEC_NPU_CMD(', '#define EXEC_NPU_CMD_CAPTURE(')
needle = '''      auto workspace_tensor =                                                 \\
          at::empty({workspace_size}, options.dtype(kByte));'''
assert macro.count(needle) == 1
replacement = '''      observed_owner = at::empty({static_cast<int64_t>(workspace_size) + 1024}, options.dtype(kByte)); \\
      observed_owner.narrow(0, 0, 512).fill_(167);                             \\
      observed_owner.narrow(0, workspace_size + 512, 512).fill_(167);           \\
      observed_workspace = observed_owner.narrow(0, 512, workspace_size);      \\
      auto workspace_tensor = observed_workspace;'''
macro = macro.replace(needle, replacement)
(new / 'capture_exec.h').write_text(macro + '\n')
bridge = (old / 'bridge.cpp').read_text()
bridge = bridge.replace('"aclnn_torch_adapter/op_api_common.h"', '"aclnn_torch_adapter/op_api_common.h"\n#include "capture_exec.h"')
bridge = bridge.replace('dsv4_hcpre_diag16', 'dsv4_hcpre_observe16')
bridge = bridge.replace('std::tuple<at::Tensor, at::Tensor, at::Tensor>', 'std::tuple<at::Tensor, at::Tensor, at::Tensor, at::Tensor>')
bridge = bridge.replace('    EXEC_NPU_CMD(', '    at::Tensor observed_owner, observed_workspace;\n    EXEC_NPU_CMD_CAPTURE(')
bridge = bridge.replace('return {y, post, comb};', 'return {y, post, comb, observed_workspace};')
bridge = bridge.replace('-> (Tensor, Tensor, Tensor)', '-> (Tensor, Tensor, Tensor, Tensor)')
(new / 'bridge.cpp').write_text(bridge)
manifest = {'observed_only': '512-byte header in retired xCast area after original Part1 barrier',
            'original_clone': str(old), 'files': {}}
for p in [kernel, kernel.parent / 'hcpre_stamp.hpp', new / 'capture_exec.h', new / 'bridge.cpp']:
    manifest['files'][str(p.relative_to(new))] = hashlib.sha256(p.read_bytes()).hexdigest()
(new / 'observer-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('OBSERVER_PREPARED')
