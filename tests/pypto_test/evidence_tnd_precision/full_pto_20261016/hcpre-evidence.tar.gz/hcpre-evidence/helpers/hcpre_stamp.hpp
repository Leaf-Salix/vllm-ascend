// Diagnostic header only, stored in the retired xCast workspace region.
// Part2 reads original x + AB/A2 workspace, never this xCast prefix.
template <typename Tiling>
static __aicore__ inline void StampHcPreWorkspace(
    GM_ADDR userWs, GM_ADDR kernelWs, GM_ADDR x, const Tiling* t)
{
    if ASCEND_IS_AIV {
        if (AscendC::GetBlockIdx() != 0) return;
        const uint64_t xCastBytes = t->cubeCoreNum * 2 * t->mL1Size *
            ((t->cvLoopKSize + 127) / 128 * 128) * sizeof(float);
        if (xCastBytes < 512) return;
        AscendC::TPipe stampPipe;
        AscendC::TBuf<AscendC::TPosition::VECCALC> buf;
        stampPipe.InitBuffer(buf, 512);
        auto h = buf.Get<uint64_t>();
        for (uint32_t i = 0; i < 64; ++i) h.SetValue(i, 0);
        h.SetValue(0, 0x4850435052453136ULL);
        h.SetValue(1, 1);
        h.SetValue(2, reinterpret_cast<uint64_t>(userWs));
        h.SetValue(3, reinterpret_cast<uint64_t>(kernelWs));
        h.SetValue(4, t->bs);
        h.SetValue(5, t->hcMix);
        h.SetValue(6, t->hcMult);
        h.SetValue(7, t->d);
        h.SetValue(8, t->cubeCoreNum);
        h.SetValue(9, t->mL1Size);
        h.SetValue(10, t->kL1Size);
        h.SetValue(11, t->cubeBlockDimM);
        h.SetValue(12, t->cubeBlockDimK);
        h.SetValue(13, t->multCoreSplitKSize);
        h.SetValue(14, t->multCoreSplitMSize);
        h.SetValue(15, t->cvLoopKSize);
        h.SetValue(16, t->secondUsedCoreNum);
        h.SetValue(17, t->stage2RowFactor);
        h.SetValue(18, t->k);
        h.SetValue(19, xCastBytes);
        AscendC::GlobalTensor<uint16_t> rawX;
        rawX.SetGlobalBuffer(reinterpret_cast<__gm__ uint16_t*>(x));
        for (uint32_t i = 0; i < 8; ++i) h.SetValue(20 + i, rawX.GetValue(i));
        h.SetValue(28, 512);
        AscendC::GlobalTensor<uint64_t> dst;
        dst.SetGlobalBuffer(reinterpret_cast<__gm__ uint64_t*>(userWs));
        AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
        AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
        AscendC::DataCopy(dst, h, 64);
        AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
        AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
        stampPipe.Destroy();
    }
}
