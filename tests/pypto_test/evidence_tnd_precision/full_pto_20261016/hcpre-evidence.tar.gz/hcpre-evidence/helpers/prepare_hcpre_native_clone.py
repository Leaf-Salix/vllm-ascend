"""私有改名HCpre；第一阶段只改符号与构建范围，严格保持数学源码。"""
from pathlib import Path
import hashlib
import json
import shutil

base = Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/full-pto-precision-20261016/hcpre-native-v1')
installed = Path('/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/vllm-ascend')
source = base / 'source'
source.mkdir(parents=True, exist_ok=True)
assert not (source / 'csrc').exists(), 'new isolated source required'
shutil.copytree(installed / 'csrc', source / 'csrc', symlinks=True)
shutil.copytree(installed / 'cmake', source / 'cmake', symlinks=True)
old = source / 'csrc/moe/hc_pre'
new = source / 'csrc/moe/hc_pre_full_diag'
shutil.copytree(old, new)
original = {str(p.relative_to(old)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in old.rglob('*') if p.is_file()}
for p in sorted(new.rglob('*'), key=lambda p: len(p.parts), reverse=True):
    if p.is_file():
        p.write_text(p.read_text().replace('HcPre', 'HcPreFullDiag').replace('hc_pre', 'hc_pre_full_diag'))
    name = p.name.replace('hc_pre', 'hc_pre_full_diag')
    if name != p.name: p.rename(p.with_name(name))
# Same restricted build approach as the already validated native-debug-v39.
(source / 'csrc/attention/CMakeLists.txt').write_text('# No attention operators in this private package.\n')
p = source / 'csrc/CMakeLists.txt'
remove = ['add_subdirectory(moe)', 'add_subdirectory(ffn)', 'add_subdirectory(gmm)',
          'add_subdirectory(mc2)', 'list(APPEND OP_LIST "moe_', 'list(APPEND OP_LIST "ffn")',
          'list(APPEND OP_DIR_LIST ${CMAKE_CURRENT_SOURCE_DIR}/moe/',
          'list(APPEND OP_DIR_LIST ${CMAKE_CURRENT_SOURCE_DIR}/ffn/']
p.write_text(''.join(line for line in p.read_text().splitlines(keepends=True)
                     if not any(item in line for item in remove)))
for rel in original:
    renamed = rel.replace('hc_pre', 'hc_pre_full_diag')
    normalized = (new / renamed).read_text().replace('hc_pre_full_diag', 'hc_pre').replace('HcPreFullDiag', 'HcPre')
    assert normalized == (old / rel).read_text(), rel
manifest = {'diagnostic_only': True, 'instrumented': False, 'normalized_math_equal': True,
            'installed_source': str(installed), 'original_files': original,
            'clone_files': {str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest()
                            for p in new.rglob('*') if p.is_file()}}
(base / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('UNINSTRUMENTED_HCPRE_CLONE_OK', len(original))
