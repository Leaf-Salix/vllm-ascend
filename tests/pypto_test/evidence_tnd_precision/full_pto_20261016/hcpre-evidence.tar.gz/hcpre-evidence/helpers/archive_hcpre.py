"""归档声明的HC-pre诊断；不包含权重、venv、共享环境或208MiB workspace。"""
from pathlib import Path
import hashlib
import json
import shutil
import tarfile
import torch

base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
root=base/'full-pto-precision-20261016'
dst=root/'hcpre-evidence'
dst.mkdir(exist_ok=False)
def copy(src,rel):
    target=dst/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,target)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
# Explicit small source/helper files. Do not recursively include builds or weights.
for src in root.iterdir():
    if src.is_file() and (src.name.startswith('hcpre') or src.name.startswith(('prepare_hcpre','build_hcpre','read_hcpre'))) and src.suffix in ('.py','.cpp','.h','.hpp','.sh','.json','.log'):
        copy(src,Path('helpers')/src.name)
for folder in root.iterdir():
    if not folder.is_dir() or not folder.name.startswith('hcpre-') or folder.name in ('hcpre-results','hcpre-evidence'):continue
    for src in folder.iterdir():
        if src.is_file() and (src.suffix in ('.py','.sh','.json','.log','.cpp','.h','.hpp','.txt') or src.name == 'cxx-ccache'):
            copy(src,Path('experiments')/folder.name/src.name)
    for pre in folder.glob('precompile*'):
        if pre.is_dir():
            for src in pre.rglob('*'):
                if src.is_file() and src.suffix in ('.cpp','.json','.log'):
                    copy(src,Path('experiments')/folder.name/src.relative_to(folder))
    # Native renamed op source only, not generic framework, third_party or binaries.
    own=folder/'source/csrc/moe/hc_pre_full_diag'
    if own.is_dir():
        for src in own.rglob('*'):
            if src.is_file() and src.suffix in ('.cpp','.h','.hpp','.txt','.json','.py'):
                copy(src,Path('native-source')/folder.name/src.relative_to(folder/'source'))
labels=('hpregold1','hprehf32v2','hpredivv3','hpreclone1','hpreobserve2','hpreobserve3','hprepartial1','hpreorder1','hprepacked1','hprepackedn2','hpreprep2','hpreconv1','hpreconv2','hpreconv3','hprepackeda3','hpreprepaway3','hprepf32p4','hpreextp1','hpreexto1','hprebf16v1','hprelayer1','hprelayer2','hprelayer3')
for label in labels:
    folder=Path('/data/pyptouser/yejia/fp16')/label
    assert folder.is_dir(),label
    for source_dir,prefix in ((folder,Path('results')/label),(folder/'result',Path('results')/label/'result')):
        if not source_dir.is_dir():continue
        for src in source_dir.iterdir():
            if src.is_file() and src.suffix in ('.json','.log'):copy(src,prefix/src.name)
        for name in ('partial-values.pt','observed-partials.pt','conversion.pt'):
            if (source_dir/name).is_file():copy(source_dir/name,prefix/name)
        p=source_dir/'first-difference.pt'
        if p.is_file():
            r=torch.load(p,map_location='cpu',weights_only=False)
            filtered={k:r[k] for k in ('actual','expected')}
            out=dst/prefix/'first-difference-outputs-only.pt';out.parent.mkdir(parents=True,exist_ok=True)
            torch.save(filtered,out)
            (out.parent/'redacted-snapshot.json').write_text(json.dumps({'original_sha256':sha(p),'retained_keys':['actual','expected'],'excluded':['hidden','weights']},indent=2)+'\n')
    for sub in ('result/patched',):
        for src in (folder/sub).glob('*'):
            if src.is_file() and src.suffix in ('.cpp','.json'):copy(src,Path('results')/label/sub/src.name)
for stage in ('step02','step03','step04'):
    copy(root/stage/'frozen-source.json',Path('frozen')/stage/'frozen-source.json')
    source=root/stage/'source';prior=root/'step01/source'
    for src in source.rglob('*'):
        if not src.is_file() or '__pycache__' in src.parts or src.suffix=='.pyc':continue
        rel=src.relative_to(source);old=prior/rel
        if not old.exists() or sha(src)!=sha(old):copy(src,Path('source-overlay')/stage/rel)
copy(root/'archive_hcpre.py','helpers/archive_hcpre.py')
manifest={str(p.relative_to(dst)):sha(p) for p in sorted(dst.rglob('*')) if p.is_file()}
(dst/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=root/'hcpre-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:tar.add(dst,arcname=dst.name)
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(manifest)}))
