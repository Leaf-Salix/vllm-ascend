"""归档整模型回归状态、辅助脚本和首错日志；不导出模型权重或大张量。"""
from pathlib import Path
import hashlib,json,shutil,tarfile
base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
job=base/'full-pto-model-8k-b40-20261016'
root=base/'full-pto-precision-20261016'
dst=job/'regression-evidence-v1';dst.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(p,rel):
 out=dst/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,out)
for p in job.iterdir():
 if p.is_file() and p.suffix in ('.py','.sh','.json'):copy(p,Path('helpers')/p.name)
for p in (job/'reference').rglob('*'):
 if p.is_file() and p.suffix in ('.py','.sh','.json'):copy(p,Path('reference')/p.relative_to(job/'reference'))
for name in ('manifest.json','frozen-source.json'):copy(root/'step05'/name,Path('source')/name)
copy(job/'native1-generation-reference/manifest.json','native/reference-manifest.json')
for arm,label in [('native','full-pto8k-native-20261016'),('csa','full-pto8k-csa-20261016')]:
 folder=Path('/data/pyptouser/yejia/lc128')/label
 identities={}
 for p in folder.rglob('*'):
  if p.is_file() and (p.suffix in ('.json','.jsonl') or p.name in ('rank0.log','launch.log')) and not any(k in p.parts for k in ('build','ascend-cache','opp_env','vllm-cache')):
   identities[str(p.relative_to(folder))]={'sha256':sha(p),'bytes':p.stat().st_size}
 (dst/arm).mkdir(exist_ok=True)
 (dst/arm/'raw-file-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
 for name in ('configuration.json','rank0.mixed.json','acceptance_summary.log'):
  if (folder/name).is_file():copy(folder/name,Path(arm)/name)
 log=folder/'rank0.log'
 if log.exists():
  lines=log.read_text(errors='replace').splitlines()
  if arm=='csa':
   index=next((i for i,s in enumerate(lines) if '507015' in s or 'exception occurred' in s),len(lines)-1)
   kept=lines[max(0,index-20):index+75]
  else:kept=lines[-35:]
  (dst/arm/'rank0-excerpt.log').write_text('\n'.join(kept)+'\n')
for exp,label in [('input-norm-t6-zero-v9','inormt6zero9'),('hcpre-shape-zero-v4','hcpret6t240zero4')]:
 for p in (root/exp).iterdir():
  if p.is_file() and p.suffix in ('.py','.cpp','.sh'):copy(p,Path('localization')/exp/p.name)
 folder=Path('/data/pyptouser/yejia/fp16')/label
 for p in folder.rglob('result.json'):copy(p,Path('localization-results')/label/p.relative_to(folder))
 for p in folder.glob('*.log'):copy(p,Path('localization-results')/label/p.name)
manifest={str(p.relative_to(dst)):sha(p) for p in sorted(dst.rglob('*')) if p.is_file()}
(dst/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=job/'regression-evidence-v1.tar.gz'
with tarfile.open(archive,'w:gz') as tar:tar.add(dst,arcname=dst.name)
print(json.dumps({'path':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'files':len(manifest)}))
