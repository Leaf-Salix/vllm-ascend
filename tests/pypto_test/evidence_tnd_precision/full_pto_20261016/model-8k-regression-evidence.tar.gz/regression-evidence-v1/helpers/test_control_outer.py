"""Control-mode reference comparison must stop on the first output difference."""
import json
import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import torch
from full_probe import install, tensor_digest, tree_digest

class ControlOuter(unittest.TestCase):
    def run_case(self, change=False, mtp_change=False):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);reference=root/'reference';reference.mkdir()
            result=torch.tensor([[1.,2.]],dtype=torch.bfloat16)
            mtp=torch.tensor([[3.,4.]],dtype=torch.bfloat16)
            golden={'forward_index':0,'actual_tokens':1,'result':tree_digest(result,1),'mtp_hidden':tensor_digest(mtp,1)}
            (reference/'outer.jsonl').write_text(json.dumps(golden)+'\n')
            (reference/'complete.json').write_text(json.dumps({'complete':True,'records':1}))
            runner=SimpleNamespace(get_model=lambda:SimpleNamespace(model=SimpleNamespace(_mtp_hidden_buffer=mtp)))
            observer=SimpleNamespace(model_runner=runner,vllm_config=SimpleNamespace(parallel_config=SimpleNamespace(data_parallel_rank=0)))
            env={'FULL_PROBE_MODE':'control','FULL_PROBE_OUTER_REFERENCE':str(reference)}
            with patch.dict(os.environ,env,clear=True):install(observer,root/'actual')
            record={'forward_index':0,'actual_tokens':1,'graph_mode':'FULL','keys':['q0']}
            runner._diagnostic_before_forward(record)
            if change:result.view(torch.int16)[0,0]+=1
            if mtp_change:mtp.view(torch.int16)[0,0]+=1
            if change or mtp_change:
                with self.assertRaisesRegex(RuntimeError,'FIRST_DIFFERENCE'):runner._diagnostic_after_forward(record,result)
                self.assertEqual(json.loads((root/'actual/STOP.json').read_text())['reason'],'target_or_draft_hidden')
                with self.assertRaisesRegex(RuntimeError,'incomplete'):observer._full_probe_finish()
            else:
                runner._diagnostic_after_forward(record,result)
                self.assertTrue(observer._full_probe_finish()['complete'])
    def test_equal(self):self.run_case()
    def test_first_target_bit_difference(self):self.run_case(change=True)
    def test_first_mtp_bit_difference(self):self.run_case(mtp_change=True)
if __name__=='__main__':unittest.main(verbosity=2)
