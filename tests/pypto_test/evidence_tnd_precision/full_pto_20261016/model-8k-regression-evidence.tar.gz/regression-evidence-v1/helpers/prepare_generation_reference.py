"""Derive a complete generation window without altering the raw control."""
import hashlib
import json
from pathlib import Path

from audit_alignment import audit
from generation_window import generation_window
from qualify192 import source_identity

raw=Path('/data/pyptouser/yejia/lc128/full-pto8k-native-20261016')
job=Path(__file__).resolve().parent
destination=job/'native1-generation-reference'
config, _, outputs, acceptance, observed=audit(raw)
source_identity(config)
traces=[[json.loads(line) for line in (raw/f'input-trace/rank{rank}.trace.jsonl').read_text().splitlines()] for rank in range(16)]
prefix, windows=generation_window(traces)
count=len(prefix[0])
outer=[json.loads(line) for line in (raw/'full-probe/outer.jsonl').read_text().splitlines()]
complete=json.loads((raw/'full-probe/complete.json').read_text())
if (not complete['complete'] or complete['mode']!='control' or complete['records']!=len(outer)
        or len(outer)!=len(traces[0])):
    raise ValueError('Raw control output observation is incomplete')
for step,row in enumerate(outer):
    if row['forward_index']!=step or row['actual_tokens']!=traces[0][step]['actual_tokens']:
        raise ValueError('Raw outer/trace binding failed')
source_files=['configuration.json','full-probe/outer.jsonl','full-probe/complete.json']
source_files += [f'input-trace/rank{rank}.{suffix}' for rank in range(16) for suffix in ('trace.jsonl','audit.json')]
source_files += [f'rank{rank}.mixed.json' for rank in range(16)]
source_files += [f'request_stats_rank{rank}.jsonl' for rank in range(16)]
source_hashes={name:hashlib.sha256((raw/name).read_bytes()).hexdigest() for name in source_files}
destination.mkdir(exist_ok=False)
(destination/'input-trace').mkdir()
(destination/'full-probe').mkdir()
for rank,rows in enumerate(prefix):
    info=json.loads((raw/f'input-trace/rank{rank}.audit.json').read_text())
    if windows[rank]['tail_prototype'] is None:
        raise ValueError('No control empty-tail prototype')
    info.update({'records':count,'scope_generation_window':True,
                 'raw_source_records':len(traces[rank]),'generation_end_exclusive':count,
                 'tail_prototype':windows[rank]['tail_prototype'],
                 'raw_source_sha256':source_hashes[f'input-trace/rank{rank}.trace.jsonl']})
    (destination/f'input-trace/rank{rank}.trace.jsonl').write_text(''.join(json.dumps(row)+'\n' for row in rows))
    (destination/f'input-trace/rank{rank}.audit.json').write_text(json.dumps(info,indent=2)+'\n')
(destination/'full-probe/outer.jsonl').write_text(''.join(json.dumps(row)+'\n' for row in outer[:count]))
(destination/'full-probe/complete.json').write_text(json.dumps({'complete':True,'records':count,'mode':'control','derived_from':str(raw),'raw_source_records':len(outer),'scope':'all generation rounds, including internal idle; strict post-completion tail audited separately'},indent=2)+'\n')
manifest={'derived':True,'raw_source':str(raw),'source_sha256':source_hashes,
          'window_records':count,'windows':windows,
          'output_requests':len(outputs),'output_tokens':sum(len(row['tokens']) for row in outputs),
          'acceptance':{k:v for k,v in acceptance.items() if k!='requests'},
          'derived_sha256':{str(path.relative_to(destination)):hashlib.sha256(path.read_bytes()).hexdigest() for path in destination.rglob('*') if path.is_file()}}
(destination/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'pass':True,'window_records':count,'requests':len(outputs),'output_tokens':manifest['output_tokens'],'raw_counts':[len(rows) for rows in traces],'tail_counts':[item['tail_records'] for item in windows],'manifest_sha256':hashlib.sha256((destination/'manifest.json').read_bytes()).hexdigest()}))
