#!/usr/bin/env bash
set -euo pipefail
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
old="$base/low-acceptance-20261010"
job="$base/full-pto-model-8k-b40-20261016"
export LOW_ACCEPTANCE_RUNTIME_PACKAGE="$old/runtime-package"
export LOW_ACCEPTANCE_GPU_BLOCKS=22000 LOW_ACCEPTANCE_OFFICIAL_CACHE="$old/official-static-cache"
source "$job/env.sh"
export ASCEND_RT_VISIBLE_DEVICES="" PYTHONPATH="$job:$PYTHONPATH"
export FULL_PROBE_MODE=control
export ADMISSION_TRACE_DIR="$job/preflight-no-device-unused"
python "$job/source_preflight.py"
python - <<'PY'
import offline_pd.observer as m
from vllm.entrypoints.llm import LLM
from offline_pd.worker import OfflineNPUWorker
assert m.OfflineCSAObserver.offline_begin_observation.__module__ == 'sitecustomize'
assert LLM.__init__.__module__ == 'original_private_sitecustomize'
assert OfflineNPUWorker.initialize_from_config.__module__ == 'sitecustomize'
assert OfflineNPUWorker.load_model.__module__ == 'sitecustomize'
assert OfflineNPUWorker.offline_batch_barrier.__module__ == 'sitecustomize'
print('ADMISSION_TRACE_BOOTSTRAP_OK; FIXED_CAPACITY_BOOTSTRAP_OK; NO_DEVICE_LAUNCH')
PY

python "$job/test_full_probe.py"

python "$job/test_admission_trace.py"

python "$job/test_generation_window.py"
python "$job/check_bank.py"
