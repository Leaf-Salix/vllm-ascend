"""Cold compilation and cache errors have different qualification outcomes."""
import json
import tempfile
import unittest
from pathlib import Path
from qualify_two_arm import cache_qualification

class CacheGate(unittest.TestCase):
    def test_cold_build_is_recorded_without_erasing_numeric_errors(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            stats={'ready_hits':0,'generation_builds':1,'binary_builds':1,'bypasses':0,'invalid_entries':0,'storage_errors':0,'forced_rebuilds':0}
            for rank in range(16):(root/f'rank{rank}.mixed.json').write_text(json.dumps({'observation':[{'pypto_cache_stats':stats}]}))
            qualified=cache_qualification(root)
            self.assertEqual(len(qualified),16)
            self.assertFalse(any(r['strict_ready_reuse'] for r in qualified))
            # Even when the run is cold, each independent error remains fatal.
            path=root/'rank15.mixed.json'
            for field in ('bypasses','invalid_entries','storage_errors','forced_rebuilds'):
                with self.subTest(field=field):
                    modified=dict(stats,**{field:1})
                    path.write_text(json.dumps({'observation':[{'pypto_cache_stats':modified}]}))
                    with self.assertRaisesRegex(ValueError,field):cache_qualification(root)
            path.unlink()
            with self.assertRaises(FileNotFoundError):cache_qualification(root)

if __name__=='__main__':unittest.main(verbosity=2)
