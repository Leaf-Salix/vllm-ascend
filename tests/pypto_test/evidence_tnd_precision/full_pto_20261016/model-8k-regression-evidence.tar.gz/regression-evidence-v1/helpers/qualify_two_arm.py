"""Single-Native vs CSA regression: exact inputs, tokens/events and rank0 outer.

No Native2 or internal layer-stage qualification is claimed.
"""
import argparse
import hashlib
import json
from pathlib import Path
from audit_alignment import audit
from qualify192 import COMMON, source_identity, read_rows


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def cache_qualification(root):
    rows=[]
    for rank in range(16):
        data=json.loads((root/f'rank{rank}.mixed.json').read_text())
        stats=data['observation'][0]['pypto_cache_stats']
        for field in ('bypasses','invalid_entries','storage_errors','forced_rebuilds'):
            if stats[field]!=0:raise ValueError(f'rank{rank}: numeric cache error {field}')
        ready=stats['ready_hits']>0 and stats['generation_builds']==0 and stats['binary_builds']==0
        rows.append({'rank':rank,'strict_ready_reuse':ready,'cache_stats':stats})
    return rows


def qualify(left_root,right_root,job):
    if left_root.resolve()==right_root.resolve():raise ValueError('Independent arms required')
    left,ltrace,loutputs,laccept,lobs=audit(left_root,require_ready_reuse=False)
    right,rtrace,routputs,raccept,robs=audit(right_root,require_ready_reuse=False)
    if left['backend']!='native' or right['backend']!='pto':raise ValueError('Wrong experiment arms')
    if any(left[k]!=right[k] for k in COMMON):raise ValueError('Common experiment identity differs')
    if left['variant']!='tnd_full_precision' or left['production_git_commit']!='259cf9a5f':raise ValueError('Wrong candidate checkpoint')
    for root,config in ((left_root,left),(right_root,right)):
        source_identity(config)
        if config['full_probe_mode']!='control' or config['stage_reference'] is not None or (root/'full-probe/stages.jsonl').exists():
            raise ValueError('This run has no layer-stage witness qualification')
        for key,name in (('bootstrap_sha256','sitecustomize.py'),('full_probe_sha256','full_probe.py'),('witness_sha256','capture_boundaries.py'),('trace_helper_sha256','admission_trace.py'),('generation_window_sha256','generation_window.py')):
            if config[key]!=sha(job/name):raise ValueError('Wrong/changed helper '+name)
    reference=job/'native1-generation-reference'
    if right['generation_reference_manifest_sha256']!=sha(reference/'manifest.json'):raise ValueError('Wrong derived reference identity')
    if Path(right['trace_reference']).resolve()!=(reference/'input-trace').resolve() or Path(right['outer_reference']).resolve()!=(reference/'full-probe').resolve():raise ValueError('Wrong live oracle directory')
    binding=json.loads((reference/'manifest.json').read_text())
    if Path(binding['raw_source']).resolve()!=left_root.resolve():raise ValueError('Reference not bound to this Native')
    for rel,digest in binding['source_sha256'].items():
        if sha(left_root/rel)!=digest:raise ValueError('Native evidence changed '+rel)
    for rel,digest in binding['derived_sha256'].items():
        if sha(reference/rel)!=digest:raise ValueError('Derived reference changed '+rel)
    if ltrace!=rtrace:raise ValueError('Actual GPU inputs or admissions differ')
    if loutputs!=routputs or laccept!=raccept:raise ValueError('Complete tokens/acceptance events differ')
    count=len(ltrace[0])
    louter=read_rows(left_root,'outer.jsonl','control',count)
    router=read_rows(right_root,'outer.jsonl','control',count)
    if louter!=router:raise ValueError('Rank0 hidden/aux/MTP bits differ')
    for step,(outer,trace) in enumerate(zip(router,rtrace[0],strict=True)):
        if outer['forward_index']!=step or outer['actual_tokens']!=trace['actual_tokens']:raise ValueError('Outer/input binding differs')
    caches=cache_qualification(right_root)
    return {'numeric_pass':True,'strict_ready_reuse':all(x['strict_ready_reuse'] for x in caches),'native_runs':1,'native_repeat_tested':False,'internal_layer_stages_tested':False,'rank0_outer_hidden_aux_mtp_bit_equal':True,'all16_gpu_inputs_and_admissions_equal':True,'all16_complete_tokens_and_events_equal':True,'requests':binding['output_requests'],'tokens':binding['output_tokens'],'generation_records':count,'production_git_commit':right['production_git_commit'],'source_manifest_sha256':right['source_manifest_sha256'],'acceptance':{k:v for k,v in raccept.items() if k!='requests'},'native_observed':lobs,'csa_observed':robs,'cache':caches,'scope':'fixed8192 real model TP1 DP=EP16 B40,192 output tokens,FULL[6,240]; no Native2, internal module or performance claim'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('native',type=Path);p.add_argument('csa',type=Path);p.add_argument('--job',type=Path,default=Path(__file__).resolve().parent);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    result=qualify(a.native,a.csa,a.job)
    with a.output.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('cache','native_observed','csa_observed')},ensure_ascii=False))
