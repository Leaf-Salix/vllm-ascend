"""CPU tests reject interior omissions and any active post-reference call."""
import copy
import json
import tempfile
import unittest
from pathlib import Path

import test_admission_trace as old
from generation_window import generation_window


def row(rank, step, active, world=2):
    return {'rank':rank,'forward_index':step,'execute_index':step,'active':active,
            'actual_tokens':1 if active else 0,'graph_mode':'FULL','padded_tokens':6,
            'dp_tokens_across_ranks':[6]*world,'keys':['q'] if active else [],
            'query_bounds':[0,1] if active else [0], 'query_lengths':[1] if active else [],
            'scheduled_tokens':[1] if active else [], 'input_ids':[12] if active else [],
            'positions':[42] if active else [],'seq_lens':[43] if active else [],
            'padded_input_ids':[0]*6,'padded_positions':[127]*6,
            'new_keys':[],'finished_keys':[],'preempted_keys':[]}


class WindowTest(unittest.TestCase):
    def test_different_empty_tail_counts_preserve_interior_idle(self):
        traces=[[row(rank,i,active) for i,active in enumerate([True,False,True]+[False]*(rank+1))]
                for rank in range(2)]
        prefix,summary=generation_window(traces,2)
        self.assertEqual([len(rows) for rows in prefix],[3,3])
        self.assertFalse(prefix[0][1]['active'])
        self.assertEqual([x['tail_records'] for x in summary],[1,2])

    def test_missing_interior_idle_and_active_suffix_are_rejected(self):
        traces=[[row(rank,i,active) for i,active in enumerate([True,False,True,False])]
                for rank in range(2)]
        traces[1].pop(1)
        with self.assertRaises(ValueError):
            generation_window(traces,2)
        traces=[[row(rank,i,active) for i,active in enumerate([True,False])]
                for rank in range(2)]
        traces[1].append(row(1,2,True))
        with self.assertRaises(ValueError):
            generation_window(traces,2)

    def test_nonempty_tail_event_or_changed_padding_is_rejected(self):
        for kind in ('new_keys','padded_input_ids'):
            traces=[[row(rank,i,active) for i,active in enumerate([True,False,False])]
                    for rank in range(2)]
            traces[0][2][kind]=['unexpected'] if kind=='new_keys' else [1]*6
            with self.assertRaises(ValueError):
                generation_window(traces,2)

    def make_derived(self, root):
        fixture=old.TraceTest()
        runner,observer,scheduled,_=fixture.run_trace(root/'first')
        runner.execute_model(scheduled)
        runner._model_forward(6,old.Tensor([0]*6),old.Tensor([127]*6))
        observer._admission_trace_finish()
        path=root/'first/rank0.trace.jsonl'
        rows=[json.loads(line) for line in path.read_text().splitlines()]
        path.write_text(json.dumps(rows[0])+'\n')
        path=root/'first/rank0.audit.json'
        audit=json.loads(path.read_text())
        audit.update(records=1,scope_generation_window=True,tail_prototype=rows[1])
        path.write_text(json.dumps(audit))
        return fixture

    def test_verified_tail_calls_model_but_skips_diagnostic_callbacks(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            fixture=self.make_derived(root)
            runner,observer,scheduled,calls=fixture.run_trace(root/'next',root/'first')
            callbacks=[]
            runner._diagnostic_after_forward=lambda record,result:callbacks.append(record['forward_index'])
            runner.execute_model(scheduled)
            for _ in range(2):
                runner._model_forward(6,old.Tensor([0]*6),old.Tensor([127]*6))
            report=observer._admission_trace_finish()
            self.assertEqual((report['records'],report['window_records'],report['tail_records']),(3,1,2))
            self.assertEqual(callbacks,[0])
            self.assertEqual(calls,['model']*3)
            self.assertTrue(report['complete'])

    def test_active_after_reference_stops_before_model_and_latches(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            fixture=self.make_derived(root)
            runner,observer,scheduled,calls=fixture.run_trace(root/'next',root/'first')
            runner.execute_model(scheduled)
            with self.assertRaisesRegex(ValueError,'post-generation'):
                runner.execute_model(scheduled)
            with self.assertRaisesRegex(RuntimeError,'INPUT_TRACE_STOPPED'):
                runner.execute_model(scheduled)
            self.assertEqual(calls,['model'])
            with self.assertRaises(RuntimeError):
                observer._admission_trace_finish()

    def test_changed_tail_padding_stops_before_model(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            fixture=self.make_derived(root)
            runner,observer,scheduled,calls=fixture.run_trace(root/'next',root/'first')
            runner.execute_model(scheduled)
            with self.assertRaisesRegex(ValueError,'prototype'):
                runner._model_forward(6,old.Tensor([1]*6),old.Tensor([127]*6))
            self.assertEqual(calls,['model'])
            with self.assertRaises(RuntimeError):
                observer._admission_trace_finish()


if __name__=='__main__':
    unittest.main(verbosity=2)
