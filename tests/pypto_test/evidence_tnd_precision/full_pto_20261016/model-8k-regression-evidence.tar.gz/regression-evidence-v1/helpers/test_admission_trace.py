"""CPU regression tests for request ordering and fail-fast trace comparison."""
import importlib.util
import json
import sys
import tempfile
import types
import unittest
from pathlib import Path

module = types.ModuleType('vllm.forward_context')
sys.modules['vllm'] = types.ModuleType('vllm')
sys.modules['vllm.forward_context'] = module
spec = importlib.util.spec_from_file_location('trace_helper', Path(__file__).with_name('admission_trace.py'))
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
N = types.SimpleNamespace


class Tensor:
    ndim = 1

    def __init__(self, values):
        self.values = values

    def __getitem__(self, item):
        return Tensor(self.values[item])

    def detach(self):
        return self

    def cpu(self):
        return self

    def tolist(self):
        return self.values


class TraceTest(unittest.TestCase):
    def run_trace(self, root, reference=None, order=('b', 'a'), values=(20, 10), kv_size=128, arm=True):
        calls = []
        batch = N(req_ids=list(order), num_reqs=2)
        req = N(num_reqs_actual=2, query_start_loc_cpu=Tensor([0, 1, 2]), seq_lens=Tensor([9, 8]))
        context = N(capturing=False, cudagraph_runtime_mode=N(name='FULL'),
                    attn_metadata={'csa': N(decode=req, num_decodes=2)},
                    dp_metadata=N(num_tokens_across_dp_cpu=Tensor([6]*16)))
        module.get_forward_context = lambda: context
        runner = N(input_batch=batch, kv_cache_config=N(num_blocks=22000,
                   kv_cache_tensors=[N(size=kv_size, shared_by=['cache'])]))
        runner._test_contexts = []
        runner._model_forward = lambda *args, **kwargs: (calls.append('model'), runner._test_contexts.append(getattr(runner, '_admission_trace_current', None)))
        runner.execute_model = lambda scheduled: runner._model_forward(6, Tensor(list(values)+[0]*4), Tensor([8, 7]+[0]*4))
        observer = N(model_runner=runner, vllm_config=N(parallel_config=N(data_parallel_rank=0, data_parallel_size=16)))
        helper.install(observer, root, reference)
        if arm:
            runner._admission_trace_arm()
        new = [N(req_id=x, sampling_params=N(extra_args={'kv_transfer_params': {'offline_key': x}}))
               for x in ('a', 'b')]
        scheduled = N(scheduled_new_reqs=new, num_scheduled_tokens={'a': 1, 'b': 1},
                      total_num_scheduled_tokens=2, finished_req_ids=set(), preempted_req_ids=set())
        return runner, observer, scheduled, calls

    def test_actual_order_and_independent_equal_run(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            runner, observer, scheduled, calls = self.run_trace(root / 'first')
            runner.execute_model(scheduled)
            self.assertTrue(observer._admission_trace_finish()['complete'])
            row = json.loads((root / 'first/rank0.trace.jsonl').read_text())
            self.assertEqual(row['keys'], ['b', 'a'])
            self.assertEqual(row['input_ids'], [20, 10])
            runner, observer, scheduled, calls = self.run_trace(root / 'second', root / 'first')
            runner.execute_model(scheduled)
            self.assertEqual(observer._admission_trace_finish()['matched_records'], 1)
            self.assertEqual(calls, ['model'])

    def test_first_changed_input_never_launches_model(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            runner, observer, scheduled, calls = self.run_trace(root / 'first')
            runner.execute_model(scheduled)
            observer._admission_trace_finish()
            runner, observer, scheduled, calls = self.run_trace(root / 'second', root / 'first', values=(21, 10))
            with self.assertRaisesRegex(RuntimeError, 'FIRST_DIFFERENCE'):
                runner.execute_model(scheduled)
            self.assertEqual(calls, [])
            stopped = json.loads((root / 'second/rank0.STOP.json').read_text())
            self.assertIn('input_ids', stopped['fields'])
            first_stop = (root / 'second/rank0.STOP.json').read_bytes()
            with self.assertRaisesRegex(RuntimeError, 'INPUT_TRACE_STOPPED'):
                runner.execute_model(scheduled)
            self.assertEqual((root / 'second/rank0.STOP.json').read_bytes(), first_stop)
            self.assertEqual(len((root / 'second/rank0.trace.jsonl').read_text().splitlines()), 1)
            self.assertEqual(calls, [])
            with self.assertRaisesRegex(RuntimeError, 'incomplete or differs'):
                observer._admission_trace_finish()

    def test_empty_baseline_is_not_complete(self):
        with tempfile.TemporaryDirectory() as directory:
            runner, observer, scheduled, calls = self.run_trace(Path(directory) / 'empty')
            with self.assertRaisesRegex(RuntimeError, 'incomplete or differs'):
                observer._admission_trace_finish()
            with self.assertRaisesRegex(RuntimeError, 'empty, incomplete or failed'):
                self.run_trace(Path(directory) / 'invalid', Path(directory) / 'empty')

    def test_allocation_plan_difference_is_not_aligned(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            runner, observer, scheduled, calls = self.run_trace(root / 'first')
            runner.execute_model(scheduled)
            observer._admission_trace_finish()
            with self.assertRaisesRegex(RuntimeError, 'allocation plans differ'):
                self.run_trace(root / 'different', root / 'first', kv_size=129)
            self.assertFalse((root / 'different/rank0.trace.jsonl').exists())

    def test_missing_reference_tail_is_not_equal(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            runner, observer, scheduled, calls = self.run_trace(root / 'first')
            runner.execute_model(scheduled)
            observer._admission_trace_finish()
            runner, observer, scheduled, calls = self.run_trace(root / 'second', root / 'first')
            with self.assertRaisesRegex(RuntimeError, 'incomplete or differs'):
                observer._admission_trace_finish()

    def test_pre_barrier_forward_excluded_but_idle_after_barrier_recorded(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            runner, observer, scheduled, calls = self.run_trace(root, arm=False)
            runner.execute_model(scheduled)
            self.assertEqual((root / 'rank0.trace.jsonl').read_text(), '')
            runner._admission_trace_arm()
            runner.execute_model(scheduled)
            # Idle model execution can be invoked outside execute_model.
            runner._model_forward(6, Tensor([0]*6), Tensor([127]*6))
            report = observer._admission_trace_finish()
            rows = [json.loads(x) for x in (root / 'rank0.trace.jsonl').read_text().splitlines()]
            self.assertEqual(report['records'], 2)
            self.assertEqual(report['active_forwards'], 1)
            self.assertFalse(rows[1]['active'])
            self.assertEqual(rows[1]['padded_input_ids'], [0]*6)

    def test_idle_insertion_stops_before_model(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            runner, observer, scheduled, calls = self.run_trace(root / 'first')
            runner.execute_model(scheduled)
            observer._admission_trace_finish()
            runner, observer, scheduled, calls = self.run_trace(root / 'second', root / 'first')
            try:
                with self.assertRaisesRegex(RuntimeError, 'FIRST_DIFFERENCE'):
                    runner._model_forward(6, Tensor([0]*6), Tensor([127]*6))
                self.assertEqual(calls, [])
            finally:
                with self.assertRaises(RuntimeError):
                    observer._admission_trace_finish()

    def test_joint_audit_rejects_phase_or_missing_vector(self):
        traces = [[{'rank': r, 'forward_index': 0, 'dp_tokens_across_ranks': [6]*2,
                    'padded_tokens': 6}] for r in range(2)]
        self.assertEqual(helper.validate_joint(traces, world=2), 1)
        traces[1][0]['forward_index'] = 1
        with self.assertRaisesRegex(ValueError, 'round mismatch'):
            helper.validate_joint(traces, world=2)
        traces[1][0]['forward_index'] = 0
        traces[1][0]['dp_tokens_across_ranks'] = None
        with self.assertRaisesRegex(ValueError, 'round mismatch'):
            helper.validate_joint(traces, world=2)

    def test_current_context_only_during_matched_forward(self):
        with tempfile.TemporaryDirectory() as directory:
            runner, observer, scheduled, calls = self.run_trace(Path(directory))
            self.assertIsNone(runner._admission_trace_current)
            runner.execute_model(scheduled)
            self.assertIsNone(runner._admission_trace_current)
            self.assertEqual(runner._test_contexts[0]['forward_index'], 0)
            self.assertTrue(runner._test_contexts[0]['active'])
            observer._admission_trace_finish()
            self.assertFalse(hasattr(runner, '_admission_trace_current'))

    def test_module_callback_error_latches_before_next_model(self):
        with tempfile.TemporaryDirectory() as directory:
            runner, observer, scheduled, calls = self.run_trace(Path(directory))
            def failed(record, output):
                raise RuntimeError('module-mismatch')
            runner._diagnostic_after_forward = failed
            with self.assertRaisesRegex(RuntimeError, 'module-mismatch'):
                runner.execute_model(scheduled)
            with self.assertRaisesRegex(RuntimeError, 'INPUT_TRACE_STOPPED'):
                runner.execute_model(scheduled)
            self.assertEqual(calls, ['model'])
            with self.assertRaises(RuntimeError):
                observer._admission_trace_finish()


if __name__ == '__main__':
    unittest.main(verbosity=2)
