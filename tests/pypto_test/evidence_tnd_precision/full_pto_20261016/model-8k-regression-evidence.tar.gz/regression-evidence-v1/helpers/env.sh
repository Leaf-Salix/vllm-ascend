#!/usr/bin/env bash
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/root-fix-20261016/env.sh"
export PYTHONPATH="$base/full-pto-model-8k-b40-20261016:$PYTHONPATH"

export SOURCE_ROOT="$base/full-pto-precision-20261016/step05/source"
export PYTHONPATH="$base/full-pto-model-8k-b40-20261016:$SOURCE_ROOT:$SOURCE_ROOT/tests/pypto_test:$PYTHONPATH"
export PTO_CSA_VARIANT=tnd_full_precision
export OMP_NUM_THREADS=10 OMP_PROC_BIND=false
unset LOCAL_WORLD_SIZE
