#!/usr/bin/env bash
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
old="$base/low-acceptance-20261010"
export LOW_ACCEPTANCE_RUNTIME_PACKAGE="$old/runtime-package"
source "$old/env.sh"
export SOURCE_ROOT="$base/root-fix-20261016/source"
export PYTHONPATH="$base/root-fix-20261016:$SOURCE_ROOT:$SOURCE_ROOT/tests/pypto_test:$PYTHONPATH"
