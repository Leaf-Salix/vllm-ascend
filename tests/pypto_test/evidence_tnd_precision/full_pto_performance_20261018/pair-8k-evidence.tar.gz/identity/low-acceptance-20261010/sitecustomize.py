"""Select reused runtime; defer Torch shutdown glue until its module is imported."""
import sys
from importlib.machinery import PathFinder
sys.path.insert(0, "/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-ab")
import runtime_select
import os
if os.environ.get('LOW_ACCEPTANCE_RUNTIME_PACKAGE'):
    import runtime_package_select

class GateLoader:
    def __init__(self, original): self.original = original
    def create_module(self, spec): return self.original.create_module(spec)
    def exec_module(self, module):
        self.original.exec_module(module)
        original = module.require_supported_framework
        def gate(framework):
            if framework.__version__.split("+")[0] not in ("2.10.0.post2", "2.10.0.post4"):
                return original(framework)
            for name in ("_npu_shutdown_synchronize", "_npu_shutdown"):
                assert callable(getattr(framework._C, name, None)), name
        module.require_supported_framework = gate

class GateFinder:
    @staticmethod
    def find_spec(fullname, path=None, target=None):
        if fullname != "pypto.torch.shutdown": return None
        spec = PathFinder.find_spec(fullname, path)
        if spec is not None: spec.loader = GateLoader(spec.loader)
        return spec

sys.meta_path.insert(0, GateFinder)

# Activate only for the explicitly selected private offline-package experiment.
import os
if os.environ.get("LOW_ACCEPTANCE_STATIC_MANIFEST") or os.environ.get("LOW_ACCEPTANCE_OFFICIAL_CACHE"):
    class StaticLoader:
        def __init__(self, original): self.original=original
        def create_module(self,spec): return self.original.create_module(spec)
        def exec_module(self,module):
            self.original.exec_module(module)
            import importlib.util
            from pathlib import Path
            spec=importlib.util.spec_from_file_location("low_acceptance_reuse_static",Path(__file__).parent/("official-static-cache.py" if os.environ.get("LOW_ACCEPTANCE_OFFICIAL_CACHE") else "reuse-static.py"))
            helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
            helper.install_bridge(module)
    class StaticFinder:
        @staticmethod
        def find_spec(fullname,path=None,target=None):
            if not fullname.endswith("npugraph_ex._acl_concrete_graph.static_kernel"): return None
            spec=PathFinder.find_spec(fullname,path)
            if spec is not None: spec.loader=StaticLoader(spec.loader)
            return spec
    sys.meta_path.insert(0,StaticFinder)

# Freeze Native/PTO test KV capacity so unrelated startup memory fluctuations do
# not change static cache descriptors between independent processes.
if os.environ.get('LOW_ACCEPTANCE_GPU_BLOCKS'):
    class FixedKVLoader:
        def __init__(self, original): self.original = original
        def create_module(self, spec): return self.original.create_module(spec)
        def exec_module(self, module):
            self.original.exec_module(module)
            original = module.LLM.__init__
            def initialize(instance, *args, **kwargs):
                blocks = int(os.environ['LOW_ACCEPTANCE_GPU_BLOCKS'])
                assert blocks > 0
                assert kwargs.get('num_gpu_blocks_override') in (None, blocks)
                kwargs['num_gpu_blocks_override'] = blocks
                print(f'LOW_ACCEPTANCE_FIXED_KV_BLOCKS={blocks}', flush=True)
                return original(instance, *args, **kwargs)
            module.LLM.__init__ = initialize
    class FixedKVFinder:
        @staticmethod
        def find_spec(fullname, path=None, target=None):
            if fullname != 'vllm.entrypoints.llm': return None
            spec = PathFinder.find_spec(fullname, path)
            if spec is not None: spec.loader = FixedKVLoader(spec.loader)
            return spec
    sys.meta_path.insert(0, FixedKVFinder)
