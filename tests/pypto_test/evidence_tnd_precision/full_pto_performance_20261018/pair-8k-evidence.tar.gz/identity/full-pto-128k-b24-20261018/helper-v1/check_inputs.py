"""只读绑定原128K bank/Native1和8K已通过的正式完整精度包。"""
import hashlib
import json
from pathlib import Path

BASE = Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
JOB = Path(__file__).resolve().parent
NATIVE = Path('/data/pyptouser/yejia/lc128/retest192-native1-b24000')
REFERENCE = BASE/'retest192-20261016/native1-generation-reference'
SOURCE = BASE/'full-pto-8k-b40-20261018/step12'
SOURCE_SHA = '56d688b218d0d634024aed98a1568adac982f6005e5cd87373dd7553df8e6496'
STATIC_SHA = '863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def verify():
    assert sha(SOURCE/'manifest.json') == SOURCE_SHA
    assert sha(REFERENCE/'manifest.json') == '347b452c4eed32897b54bd05305a317708fbea987ffeab1ad1ac1461f9153dac'
    config = json.loads((NATIVE/'configuration.json').read_text())
    assert config['backend'] == 'native' and config['batch'] == 24
    assert config['production_git_commit'] == 'cbc810c8afab47c2425068049440424f014dcde3'
    assert config['source_manifest_sha256'] == 'e4de4927d2e5758df65784bddc412d1d90227b56ed978ad2218df50c2bd540ca'
    assert config['num_gpu_blocks_override'] == 24000 and config['decode_tokens'] == 192
    bank = Path(config['bank'])
    assert sha(bank/'plan.json') == config['bank_plan_sha256'] == 'b4ca67ee33bdf5f1ddadcd9578e437865e15bacfcb6fdf45094f431abb704a1e'
    plan = json.loads((bank/'plan.json').read_text())
    assert [case['key'] for case in plan['cases']] == [f'h131072_q{i:02d}' for i in range(24)]
    for case in plan['cases']:
        assert (bank/case['tokens']).is_file()
    binding = json.loads((REFERENCE/'manifest.json').read_text())
    assert Path(binding['raw_source']) == NATIVE
    assert binding['window_records'] == 78 and binding['output_requests'] == 384 and binding['output_tokens'] == 73728
    for name, digest in binding['source_sha256'].items():
        assert sha(NATIVE/name) == digest, name
    for name, digest in binding['derived_sha256'].items():
        assert sha(REFERENCE/name) == digest, name
    package = json.loads((JOB/'production-package.json').read_text())
    assert package['git_commit'] == '425ae1f11' and len(package['files']) == 17
    manifest = json.loads((SOURCE/'manifest.json').read_text())
    assert manifest['production_package_files'] == package['files']
    for name,digest in package['files'].items():assert sha(SOURCE/'source'/name) == digest, name
    assert sha(BASE/'low-acceptance-20261010/official-static-cache/metadata.json') == STATIC_SHA
    identity = json.loads((JOB/'helper-manifest.json').read_text())
    for name, digest in identity['files'].items():assert sha(JOB/name) == digest, name
    old128 = BASE/'retest128k-wkv-20261017/witness-v1'
    for name in ('admission_trace.py','generation_window.py','audit_alignment.py','saved_reference.py'):
        assert (JOB/name).read_bytes() == (old128/name).read_bytes(), name
    old8 = BASE/'full-pto-8k-b40-20261018/helper-v2'
    assert (JOB/'full_probe.py').read_bytes() == (old8/'full_probe.py').read_bytes()
    assert (JOB/'qualified_wkv.py').read_text() == (old8/'qualified_wkv.py').read_text().replace('(6,240)','(6,144)')
    print(json.dumps({'bank':str(bank),'native':str(NATIVE),'reference':str(REFERENCE),'source_manifest_sha256':sha(SOURCE/'manifest.json'),'helper_manifest_sha256':sha(JOB/'helper-manifest.json'),'scope':'fixed128K plan and token files; Native evidence and reference fully hashed; original bank tensor payloads not rehashed; complete 425ae precision package; no Native2'}))

if __name__ == '__main__':verify()
