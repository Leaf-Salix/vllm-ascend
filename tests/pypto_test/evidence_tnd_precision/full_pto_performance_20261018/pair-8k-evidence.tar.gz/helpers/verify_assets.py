"""只读核查当前完整精度源码、两种已验收Native黄金结果及助手身份。"""
import hashlib,json,os,runpy
from pathlib import Path
B=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
J=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
S=B/'full-pto-8k-b40-20261018/step12'
assert sha(S/'manifest.json')=='56d688b218d0d634024aed98a1568adac982f6005e5cd87373dd7553df8e6496'
p=json.loads((J/'production-package.json').read_text())
assert p['git_commit']=='425ae1f11' and len(p['files'])==17
for name,digest in p['files'].items():assert sha(S/'source'/name)==digest,name
for name,digest in json.loads((J/'helper-manifest.json').read_text())['files'].items():assert sha(J/name)==digest,name
case=os.environ['PERF_CASE']
if case=='8k':runpy.run_path(str(B/'full-pto-8k-b40-20261018/helper-v2/verify_assets.py'),run_name='__main__')
elif case=='128k':runpy.run_path(str(B/'full-pto-128k-b24-20261018/helper-v1/check_inputs.py'),run_name='__main__')
else:raise ValueError('Wrong performance case')
print('PERFORMANCE_ASSETS_VERIFIED complete425ae Native-gold '+case)
