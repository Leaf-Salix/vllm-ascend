# 完整PTO精度版：真实整模型性能对照

- [ ] 先8K/B40 Native → PTO，精度/性能配对验收通过后再128K/B24 Native → PTO。
- [ ] 同一冻结step12/source（完整数学425ae）和同一SDK、bank、Native黄金token/events。
- [ ] 真实TP1 DP=EP16，192 token；每臂96 token预热，再3轮192 token，每轮8步预热+20连续forward样本。
- [ ] 无DFX/profiler/模块hook/逐轮D2H位摘要；预热计时事件、结束后统一同步。
- [ ] 全rank完整输出/接受事件逐轮gold比较，零抢占；测量CPU请求几何/positions/图桶/DP向量一致。
- [ ] Native/PTO均首次实际静态选择、后续验证后复用；PTO完整21层两桶捕获资格，不得回退冒充通过。
- [ ] 测量轮开始/结束cache统计无新增编译或错误；每个NPU任务max780，持续监控，不开sche。
- [ ] 先无设备预检和CPU门禁/独立review，再按序提交。
- [ ] 记录整模型forward、解码周期、分布与三轮结果，不把bank IO/加载或单层CSA混入主指标。
- [ ] 原始证据与完整复现文档commit/push。
