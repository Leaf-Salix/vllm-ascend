"""Different real questions, restored Native bank, three profiler-free repeats."""
import json
import os
import time
from pathlib import Path


def run_batches(llm,args,cases):
    from offline_pd.batch import generate_aligned_batch
    from offline_pd.run import spec_decode_metrics,write_json
    from low_acceptance_20261001.mixed import wait_for_generation_peers
    from vllm import SamplingParams
    chosen=cases[:args.batch]
    if len(chosen)!=args.batch:raise ValueError('Not enough distinct bank questions')
    implementations=llm.collective_rpc('offline_attention_implementations')
    for worker in implementations:
        csa=[v for v in worker if v['kind']=='csa'];hca=[v for v in worker if v['kind']=='hca']
        if len(csa)!=21 or len(hca)!=20 or any(v['implementation']!='native' for v in hca):raise ValueError('Wrong attention layer selection')
        expected='pto' if args.backend=='pto' else 'native'
        if any(v['implementation']!=expected for v in csa):raise ValueError('Wrong CSA arm')
        if expected=='pto' and any(not v['runtime_class'].endswith('.deepseek_v4_flash_csa_tnd_full_precision.service') for v in csa):raise ValueError('Wrong PTO variant')
    gold=json.loads((Path(os.environ['PERF_GOLD'])/f'rank{args.rank}.mixed.json').read_text())
    gold_tokens={v['key']:v['output_token_ids'] for v in gold['requests']}
    gold_events={v['key']:v for v in [json.loads(s) for s in (Path(os.environ['PERF_GOLD'])/f'request_stats_rank{args.rank}.jsonl').read_text().splitlines()]}
    log=args.output/f'request_stats_rank{args.rank}.jsonl'
    report={'backend':args.backend,'batch':args.batch,'decode_tokens':192,'rank':args.rank,'implementations':implementations,
            'worker_runtime_config':args.worker_runtime_config,'variant':os.environ['PTO_CSA_VARIANT'],'warmup':None,'rounds':[],'scope':'Real mixed-question model; no profiler, stage hooks, D2H trace or raw tensor dump'}
    for iteration in range(4):
        limit=96 if iteration==0 else 192
        prompts=[{'prompt_token_ids':json.loads((args.bank/c['tokens']).read_text())} for c in chosen]
        params=[SamplingParams(temperature=0,max_tokens=limit,ignore_eos=True,extra_args={'kv_transfer_params':{'offline_key':c['key']}}) for c in chosen]
        before_lines=len(log.read_text().splitlines()) if log.exists() else 0
        before=spec_decode_metrics(llm)
        identity=llm.collective_rpc('offline_perf_identity')
        if iteration:
            expected_requests=int(os.environ['PERF_ACTIVE_REQUESTS'])
            llm.collective_rpc('offline_begin_real_perf',args=(8,expected_requests*6,expected_requests,20))
        start=time.perf_counter()
        outputs=generate_aligned_batch(llm,prompts,params)
        elapsed=time.perf_counter()-start
        wait_for_generation_peers(args.output,args.rank,iteration)
        timing=llm.collective_rpc('offline_end_real_perf') if iteration else None
        events=[json.loads(s) for s in log.read_text().splitlines()[before_lines:]]
        metrics=spec_decode_metrics(llm,before)
        if len(outputs)!=args.batch or len(events)!=args.batch:raise ValueError('Incomplete request outputs/stats')
        by_key={v['key']:v for v in events}
        if len(by_key)!=args.batch:raise ValueError('Duplicate/missing request events')
        for case,output in zip(chosen,outputs):
            key=case['key'];actual=list(output.outputs[0].token_ids);record=by_key[key]
            if len(actual)!=limit or record['output_tokens']!=limit or record['preemptions']!=0:raise ValueError('Wrong token count or preemption')
            if actual!=gold_tokens[key][:limit] or (iteration and record['events']!=gold_events[key]['events']):
                write_json(args.output/f'rank{args.rank}.STOP.json',{'key':key,'iteration':iteration,'reason':'token/events differ from precision-qualified Native gold'})
                raise ValueError('PERF_TOKEN_FIRST_DIFFERENCE')
        if iteration:
            for before_id, after_id in zip(identity,[w['identity'] for w in timing],strict=True):
                for field in ('generation_builds','binary_builds','bypasses','invalid_entries','storage_errors','forced_rebuilds'):
                    if after_id['cache_stats'][field]!=before_id['cache_stats'][field]:raise ValueError('Compile/cache change in measured round: '+field)
        row={'iteration':iteration,'elapsed_batch_including_cache_io_seconds':elapsed,'timing':timing,'identity_before':identity,
             'spec_decode':metrics,'requests':[{'key':c['key'],'output_token_ids':list(o.outputs[0].token_ids),'events':by_key[c['key']]['events'],'preemptions':by_key[c['key']]['preemptions']} for c,o in zip(chosen,outputs)]}
        if iteration:report['rounds'].append(row)
        else:report['warmup']={'decode_tokens':96,'elapsed_batch_including_cache_io_seconds':elapsed,'spec_decode':metrics}
        write_json(args.output/f'rank{args.rank}.real_perf.json',report)
        print(f'REAL_PERF_ROUND_DONE rank={args.rank} iteration={iteration}',flush=True)
