"""Small immutable performance evidence archive, no model/tensor/cache payloads."""
import argparse,hashlib,io,json,subprocess,tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--labels',nargs='+',required=True);p.add_argument('--tasks',nargs='+',required=True);p.add_argument('--name',required=True);a=p.parse_args()
job=Path(__file__).resolve().parent.parent
files={}
for label in a.labels:
 if label not in ('perf-full-real-8k-native-20261018','perf-full-real-8k-pto-20261018','perf-full-real-128k-native-20261018','perf-full-real-128k-pto-20261018'):raise ValueError('Explicit own results only')
 root=Path('/data/pyptouser/yejia/lc128')/label
 for f in root.iterdir():
  if f.is_file() and f.suffix in ('.json','.log','.jsonl'):files[f'results/{label}/{f.name}']=f
for f in job.rglob('*'):
 if f.is_file() and f.suffix in ('.py','.sh','.json','.md') and '__pycache__' not in f.parts:files[f'helpers/{f.relative_to(job)}']=f
base=job.parent
for rel in ('root-fix-20261016/manifest.json','root-fix-20261016/env.sh','full-pto-8k-b40-20261018/step12/manifest.json','low-acceptance-20261010/runtime-package/manifest.json','low-acceptance-20261010/official-static-cache/metadata.json','low-acceptance-20261010/sitecustomize.py','low-acceptance-20261010/official-static-cache.py','full-pto-8k-b40-20261018/helper-v2/verify_assets.py','full-pto-128k-b24-20261018/helper-v1/check_inputs.py'):
 files['identity/'+rel]=base/rel
status={}
for task in a.tasks:
 result=subprocess.run(['task-submit','--status',task],check=True,text=True,capture_output=True)
 if not result.stdout.strip().startswith('completed'):raise ValueError('Do not archive unfinished task as final')
 status[task]=result.stdout
 log=subprocess.run(['task-submit','--log',task],check=True,text=True,capture_output=True)
 log_path=job/(task+'.task.log');log_path.write_text(log.stdout)
 files['task-logs/'+log_path.name]=log_path
manifest={name:hashlib.sha256(f.read_bytes()).hexdigest() for name,f in files.items()}
archive=job/(a.name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for name,f in sorted(files.items()):tar.add(f,arcname=name,recursive=False)
 for name,data in (('evidence-manifest.json',manifest),('task-statuses.json',status)):
  raw=(json.dumps(data,indent=2)+'\n').encode();item=tarfile.TarInfo(name);item.size=len(raw);tar.addfile(item,io.BytesIO(raw))
print(json.dumps({'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(files),'bytes':archive.stat().st_size}))
