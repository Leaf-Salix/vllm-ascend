from pathlib import Path
import hashlib,json,runpy,sys
here=Path(__file__).resolve().parent
manifest=here/'manifest.json'
assert all(hashlib.sha256((here/k).read_bytes()).hexdigest()==v for k,v in json.loads(manifest.read_text()).items())
parent=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-sdk-alignment-20261026-codex/hc-owner-chain-v2')
assert hashlib.sha256((parent/'probe_perf.py').read_bytes()).hexdigest()=='1a20801e66cf0d1769459e9691366913b5640385653da2695bd679e12fbbbecc'
sys.path.insert(0,str(parent));sys.path.insert(0,str(here))
runpy.run_path(str(parent/'sdk_bind.py'),run_name='__sdk_preflight__')
s=(here/'derived_probe.py').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='6acba8a2d4a6dd88ed247bc75c0e13bfc26c47367714613d1ec0c98d707991fd'
exec(compile(s,str(parent/'probe_perf.py'),'exec'),{'__name__':'__main__','__file__':str(parent/'probe_perf.py'),'PARENT_SHA':'1a20801e66cf0d1769459e9691366913b5640385653da2695bd679e12fbbbecc','OBSERVER_MANIFEST_SHA':hashlib.sha256(manifest.read_bytes()).hexdigest()})
