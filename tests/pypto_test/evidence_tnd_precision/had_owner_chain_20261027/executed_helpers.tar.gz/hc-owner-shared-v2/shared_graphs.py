"""以相同64个物理实参诊断FULL root；不改数学或正式接入图。"""
import contextlib

import torch
from torch._subclasses.fake_tensor import FakeTensor
from vllm.config import CUDAGraphMode
from vllm_ascend.ascend_forward_context import set_ascend_forward_context
from npugraph_ex._acl_concrete_graph.acl_graph import AclGraph


class ArgumentSpy:
    def __init__(self, operator):
        self.operator = operator
        self.values = None

    def __getattr__(self, name):
        return getattr(self.operator, name)

    def __call__(self, *values):
        if all(isinstance(v, torch.Tensor) and not isinstance(v, FakeTensor) for v in values):
            assert len(values) == 64
            self.values = tuple(values)
        return self.operator(*values)


class SharedRoot(torch.nn.Module):
    def __init__(self, operator, values):
        super().__init__()
        self.operator = operator
        self.values = values

    def arguments(self, hidden, positions, output):
        values = list(self.values)
        values[0], values[40], values[53] = hidden, positions, output
        return values

    def forward(self, hidden, positions, output):
        self.operator(*self.arguments(hidden, positions, output))
        return output


def identity(value):
    return dict(pointer=value.data_ptr(), shape=list(value.shape), stride=list(value.stride()),
                offset=value.storage_offset(), dtype=str(value.dtype), device=str(value.device),
                storage_pointer=value.untyped_storage().data_ptr())


def prepare_shared(namespace, spies):
    n = namespace
    rows, fixtures, states = n['rows'], n['fixtures'], n['states']
    report, keepalive = n['report'], n['keepalive']
    restore, collect, exact, guards = n['restore'], n['collect_state'], n['exact'], n['guard_checks']
    tokens, config = n['tokens'], n['config']
    original_rows = dict(rows)
    f = fixtures['baseline']
    values = spies['baseline'].values
    assert values is not None and len(values) == 64
    graph, _, output, _ = rows['baseline']
    assert values[0].data_ptr() == f['hidden'].data_ptr()
    assert values[40].data_ptr() == f['positions'].data_ptr()
    assert values[53].data_ptr() == output.data_ptr()
    topk = values[51][:tokens]
    assert topk.data_ptr() == rows['baseline'][3].data_ptr()
    packets = n['packets_by_arm']['baseline']
    original_states = {arm: {k: v.clone() for k, v in states[arm].items()} for arm in ('baseline', 'candidate')}

    def reset():
        torch.npu.synchronize()
        restore(f)
        for live, expected in f['readonly'].values():
            live.copy_(expected)
        live, expected = packets
        for key, value in live.items():
            value.copy_(expected[key])
        torch.npu.synchronize()

    @contextlib.contextmanager
    def context():
        with set_ascend_forward_context(f['metadata'], config, num_tokens=tokens,
                                       num_actual_tokens=tokens, aclgraph_runtime_mode=CUDAGraphMode.FULL):
            yield

    report['measurement_scope'] = 'shared-args direct-root FULL; original service graphs only qualify initialization'
    report['shared_arguments'] = {'identities': [identity(v) for v in values], 'same_arm_checks': {}, 'order': []}
    @contextlib.contextmanager
    def observe_enqueue(arm):
        # Read the actual CallFrame immediately before the unchanged native enqueue.
        # This observer is removed before all timing and graph replay windows.
        from pypto.torch import launch
        old_enqueue = launch._enqueue_frame
        expected = report['actual_execution_identity'][arm]['registration']['identity']
        snapshots = []

        def record(registration, frame):
            if registration.identity.hex() == expected:
                names = [p.name for p in registration.artifact.kernel_abi.parameters]
                assert len(frame.tensors) == 64 and not frame.scalars
                assert [names[i] for i in (0, 40, 53)] == ['x_hc', 'position_ids', 'x_out']
                actual = [identity(t.tensor) for t in frame.tensors]
                assert actual == report['shared_arguments']['identities'], (arm, 'actual enqueue args differ')
                capture_id = launch._load_native().check_call(frame.stream.stream_id, frame.device_index)
                snapshots.append({'capture_id': capture_id or 0, 'all_64_identity_equal': True,
                                  'registration_identity': expected})
            return old_enqueue(registration, frame)

        launch._enqueue_frame = record
        try:
            yield
        finally:
            launch._enqueue_frame = old_enqueue
        assert snapshots and any(row['capture_id'] for row in snapshots), (arm, 'no actual capture enqueue observed')
        report['shared_arguments'].setdefault('actual_capture_enqueue', {})[arm] = snapshots

    reference_arguments = None
    for arm in [a for a in report['actual_capture_order'] if a != 'native']:
        spy = spies[arm]
        assert spy.values is not None
        module = SharedRoot(spy.operator, values)
        actual_arguments = [identity(v) for v in module.arguments(f['hidden'], f['positions'], output)]
        assert actual_arguments == report['shared_arguments']['identities']
        if reference_arguments is None:
            reference_arguments = actual_arguments
        else:
            assert reference_arguments == actual_arguments
        reset()
        with context():
            module(f['hidden'], f['positions'], output)
        torch.npu.synchronize()
        observed = collect(f, output, topk)
        assert len(observed) == 8
        assert all(exact(v, original_states[arm][key]) for key, v in observed.items()), (arm, 'shared eager changes behavior')
        instances = {}
        old_run = AclGraph.run

        def record(owner, key, *args, **kwargs):
            instances[(id(owner), key)] = owner
            return old_run(owner, key, *args, **kwargs)

        AclGraph.run = record
        torch._dynamo.reset()
        options = report['graphs'][arm]['options']
        try:
            compiled = torch.compile(module, backend='npugraph_ex', fullgraph=True, dynamic=False, options=options)
            reset()
            with observe_enqueue(arm), context():
                compiled(f['hidden'], f['positions'], output)
            torch.npu.synchronize()
            assert len(instances) == 1
            (_, key), owner = next(iter(instances.items()))
            assert not owner._updated_node_infos
            graph = owner.graph[key]
        finally:
            AclGraph.run = old_run
        reset()
        output.fill_(float('nan'))
        topk.fill_(-12345)
        graph.replay()
        torch.npu.synchronize()
        assert bool(torch.isfinite(output).all()) and not bool((topk == -12345).any())
        observed = collect(f, output, topk)
        assert all(exact(v, original_states[arm][key]) for key, v in observed.items()), (arm, 'shared graph changes behavior')
        assert all(v['status'] == 'PASS' for v in guards(f).values())
        assert all(exact(v.cpu(), packets[1][key]) for key, v in packets[0].items())
        report['shared_arguments']['same_arm_checks'][arm] = {'eager_8': True, 'FULL_8': True, 'poison_written': True}
        report['shared_arguments']['order'].append(arm)
        rows[arm] = (graph, f, output, topk)
        fixtures[arm] = f
        n['packets_by_arm'][arm] = packets
        report['graphs'][arm]['shared_root_actual_acl_graph'] = True
        keepalive.append((compiled, module, owner, original_rows[arm], original_states[arm], spy.values))
    assert all(rows['baseline'][i] is rows['candidate'][i] for i in (1, 2, 3))
    from identity import verify_actual
    from load_candidate import entry_for
    report['shared_actual_execution_identity'] = verify_actual(entry_for, n['ROOT'])
    n['save']()
