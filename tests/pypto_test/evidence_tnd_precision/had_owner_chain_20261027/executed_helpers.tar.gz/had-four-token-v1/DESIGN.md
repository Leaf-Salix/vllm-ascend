# Hadamard四token行合并单因素

2026-10-27。直接借用nalinaly1685 projection_overlap_stages.py::_query_hadamard_four_tokens主体，仅重命名输入/输出/worker变量并放进原独立Hadamard任务；T<4保留原M64路径。T>=4为M256/K128，末块按真实T*64行valid裁剪，没有每请求补S6。

原量化任务源码、unscaled BF16 matmul→BF16→scale→BF16→FP16 scale及INT8 round顺序全部保留；不复制其其他量化/softmax边界，不组合失败候选。原QH_WORKERS与qh_mm_dep、task边界/allocator scope均保持。精度需硬件验证，不能只凭源码认为相同。

占卡前双臂CPU64/load/NPUfalse、检查生成MMA/tail/L0/L1资源与非Had leaf一致；先8K/B32双向性能，赢后Native A/B八边界和ABA。计时前只读实际Worker READY/PID/generation/owner注册产物，对每臂完整CPU leaf/strictalpha编排/meta/config做门禁，记录每次实际artifact身份。DFX计时不启dep-gen，模块依赖另采。每任务outer780/inner750秒。
