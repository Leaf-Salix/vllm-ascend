# Copyright (c) PyPTO Contributors.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# -----------------------------------------------------------------------------------------------------------

"""直接借用nalinaly1685四token行合并；保留Native量化、短T及任务边界。"""
import pypto.language as pl
from ..deepseek_v4_flash_csa_tnd_precision.decode_indexer import *
@pl.jit.inline(auto_scope=False)
def indexer_qr_hadamard_mm(x: pl.Tensor[[T_DYN, D], pl.BF16], qr_bf16: pl.Tensor[[T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], pl.BF16], hadamard: pl.Tensor[[IDX_HEAD_DIM, IDX_HEAD_DIM], pl.BF16], qr_hadamard_i8: pl.Out[pl.Tensor[[T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], pl.INT8]], qr_hadamard_scale_dq: pl.Out[pl.Tensor[[T_PAD * IDX_N_HEADS, 1], pl.FP32]], qh_mm_dep: pl.Scalar[pl.TASK_ID]) -> tuple[pl.Scalar[pl.TASK_ID], pl.Scalar[pl.TASK_ID]]:
    """q @ hadamard and its INT8 quant, fenced behind the caller's cube ordering."""
    bs = pl.tensor.dim(x, 0)
    bs_heads = bs * IDX_N_HEADS
    qh_acc_gm = pl.create_tensor([bs_heads, IDX_HEAD_DIM], dtype=pl.FP32)
    with pl.spmd(QH_WORKERS, name_hint='qr_hadamard_matmul', deps=[qh_mm_dep], allow_early_resolve=True) as qh_mm_tid:
        qh_worker = pl.tile.get_block_idx()
        if bs < 4:
            qh_hadamard = hadamard[0:IDX_HEAD_DIM, 0:IDX_HEAD_DIM]
            for idx in pl.range(qh_worker, bs_heads // QH_MM_TILE, QH_WORKERS):
                o0 = idx * QH_MM_TILE
                qh_acc = pl.matmul(qr_bf16[o0:o0 + QH_MM_TILE, :], qh_hadamard, out_dtype=pl.FP32)
                qh_acc_gm[o0:o0 + QH_MM_TILE, :] = qh_acc
        else:
            rows = bs * 64
            weight = hadamard[0:128, 0:128]
            for block in pl.range(qh_worker, (rows + 255) // 256, QH_WORKERS):
                first = block * 256
                valid = pl.min(256, rows - first)
                source = pl.slice(qr_bf16, [256, 128], [first, 0], valid_shape=[valid, 128])
                result = pl.matmul(source, weight, out_dtype=pl.FP32)
                qh_acc_gm = pl.assemble(qh_acc_gm, result, [first, 0])
    with pl.spmd(QH_QUANT_WORKERS, name_hint='qr_hadamard_quant', allow_early_resolve=True) as qh_quant_tid:
        qh_quant_worker = pl.tile.get_block_idx()
        for idx in pl.range(qh_quant_worker, bs_heads // QH_QUANT_TILE, QH_QUANT_WORKERS):
            o0 = idx * QH_QUANT_TILE
            qh_full_f32 = qh_acc_gm[o0:o0 + QH_QUANT_TILE, 0:IDX_HEAD_DIM]
            qh_full_f32 = pl.cast(pl.cast(qh_full_f32, pl.BF16, mode='rint'), pl.FP32)
            qh_full_f32 = pl.cast(pl.cast(pl.mul(qh_full_f32, HADAMARD_SCALE), pl.BF16, mode='rint'), pl.FP32)
            qh_amax = pl.full([1, QH_QUANT_TILE], dtype=pl.FP32, value=INT8_AMAX_EPS)
            for h0 in pl.range(0, IDX_HEAD_DIM, QH_HEAD_DIM_TILE):
                qh_a_f32 = qh_full_f32[:, h0:h0 + QH_HEAD_DIM_TILE]
                qh_a_neg = pl.neg(qh_a_f32)
                qh_a_abs = pl.maximum(qh_a_f32, qh_a_neg)
                qh_a_max_col = pl.row_max(qh_a_abs)
                qh_a_max = pl.reshape(qh_a_max_col, [1, QH_QUANT_TILE])
                qh_amax = pl.maximum(qh_amax, qh_a_max)
            qh_scale_numerator = pl.full([1, QH_QUANT_TILE], dtype=pl.FP32, value=INT8_SCALE_MAX)
            qh_scale_quant_row = pl.div(qh_scale_numerator, qh_amax)
            qh_scale_recip = pl.recip(qh_scale_quant_row)
            qh_scale_dq = pl.reshape(qh_scale_recip, [QH_QUANT_TILE, 1])
            qr_hadamard_scale_dq[o0:o0 + QH_QUANT_TILE, :] = pl.cast(pl.cast(qh_scale_dq, pl.FP16, mode='rint'), pl.FP32)
            qh_scale_quant = pl.reshape(qh_scale_quant_row, [QH_QUANT_TILE, 1])
            qh_q_scaled = pl.row_expand_mul(qh_full_f32, qh_scale_quant)
            qh_q_i32 = pl.cast(qh_q_scaled, target_type=pl.INT32, mode='rint')
            qh_q_half = pl.cast(qh_q_i32, target_type=pl.FP16, mode='round')
            qh_i8 = pl.cast(qh_q_half, target_type=pl.INT8, mode='trunc')
            qr_hadamard_i8[o0:o0 + QH_QUANT_TILE, 0:IDX_HEAD_DIM] = qh_i8
    return (qh_mm_tid, qh_quant_tid)

@pl.jit.inline(auto_scope=False)
def indexer_qr_hadamard(x: pl.Tensor[[T_DYN, D], pl.BF16], qr: pl.Tensor[[T_DYN, Q_LORA], pl.INT8], qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32], wq_b: pl.Tensor[[Q_LORA, IDX_N_HEADS * IDX_HEAD_DIM], pl.INT8], wq_b_scale: pl.Tensor[[IDX_N_HEADS * IDX_HEAD_DIM], pl.FP32], cos: pl.Tensor[[T_DYN, ROPE_HEAD_DIM], pl.FP32], sin: pl.Tensor[[T_DYN, ROPE_HEAD_DIM], pl.FP32], hadamard: pl.Tensor[[IDX_HEAD_DIM, IDX_HEAD_DIM], pl.BF16], qr_hadamard_i8: pl.Out[pl.Tensor[[T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], pl.INT8]], qr_hadamard_scale_dq: pl.Out[pl.Tensor[[T_PAD * IDX_N_HEADS, 1], pl.FP32]]):
    """Query half of the indexer: qr projection, rope, hadamard, and INT8 quant."""
    qr_bf16 = pl.create_tensor([T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], dtype=pl.BF16)
    idx_qr_mm_tid = indexer_qr_rope(x, qr, qr_scale, wq_b, wq_b_scale, cos, sin, qr_bf16)
    qh_mm_tid, qh_quant_tid = indexer_qr_hadamard_mm(x, qr_bf16, hadamard, qr_hadamard_i8, qr_hadamard_scale_dq, idx_qr_mm_tid)
    return (qh_mm_tid, qh_quant_tid, idx_qr_mm_tid)
