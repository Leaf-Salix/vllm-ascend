from pathlib import Path
import hashlib,json,runpy,sys
here=Path(__file__).resolve().parent
manifest=here/'manifest.json'
assert all(hashlib.sha256((here/k).read_bytes()).hexdigest()==v for k,v in json.loads(manifest.read_text()).items())
parent=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-sdk-alignment-20261026-codex/had-four-token-v1')
assert hashlib.sha256((parent/'probe_perf.py').read_bytes()).hexdigest()=='6f55ba43f4e937fe49627cd9a03b56e3fe704d17755e162cb7f2a0ad7be6a270'
sys.path.insert(0,str(parent));sys.path.insert(0,str(here))
runpy.run_path(str(parent/'sdk_bind.py'),run_name='__sdk_preflight__')
s=(here/'derived_probe.py').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='85e460c7cf13b9c35980a5d0b710ed29c5246aff52260d7b970aee8c7725c65f'
exec(compile(s,str(parent/'probe_perf.py'),'exec'),{'__name__':'__main__','__file__':str(parent/'probe_perf.py'),'PARENT_SHA':'6f55ba43f4e937fe49627cd9a03b56e3fe704d17755e162cb7f2a0ad7be6a270','OBSERVER_MANIFEST_SHA':hashlib.sha256(manifest.read_bytes()).hexdigest()})
