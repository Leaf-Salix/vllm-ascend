import re,ast,json,hashlib
from pathlib import Path
TOKENS = re.compile(
    r'(?P<protected>(?:u8|u|U|L)?R"(?P<delimiter>[^ ()\\\t\r\n]{0,16})\(.*?\)(?P=delimiter)"'
    r'|(?:u8|u|U|L)?"(?:\\.|[^"\\])*"'
    r"|(?:u8|u|U|L)?'(?:\\.|[^'\\])*'"
    r"|/\*.*?\*/|//[^\n]*|^[ \t]*\#(?:[^\n\\]|\\[^\n]|\\\n)*)"
    r"|(?P<identifier>\b[A-Za-z_]\w*\b)",
    re.DOTALL | re.MULTILINE,
)
INLINE = re.compile(r"[A-Za-z_]\w*inline[0-9]+\w*\Z")
DECL = re.compile(
    r"\b(?:int64_t|int32_t|uint32_t|uint64_t|float|Tensor|TensorCreateInfo|TaskOutputTensors|TaskId)"
    r"(?:\s*&\s*|\s+)([A-Za-z_]\w*inline[0-9]+\w*)\b"
)


def normalize(text):
    assert "CSA_ALPHA_INLINE_" not in text
    protected = []

    def mask(match):
        if match.group("protected") is not None:
            protected.append(match.group())
            return "".join("\n" if c == "\n" else " " for c in match.group())
        return match.group()

    plain = TOKENS.sub(mask, text)
    declared = set(DECL.findall(plain))
    renamed = {m.group() for m in TOKENS.finditer(plain) if m.group("identifier") and INLINE.fullmatch(m.group())}
    assert renamed <= declared, ("non-local identifier", sorted(renamed - declared))
    mapping = {}

    def replace(match):
        word = match.group()
        if match.group("identifier") is None or not INLINE.fullmatch(word):
            return word
        if word not in mapping:
            stem = re.sub(r"inline[0-9]+", "inline", word)
            mapping[word] = f"CSA_ALPHA_INLINE_{len(mapping)}_{stem}"
        return mapping[word]

    return TOKENS.sub(replace, text), protected, mapping


def leaf_maps(manifest):
    return (
        {str(k["func_id"]): k["name"] for k in manifest["kernels"]},
        {str(k["func_id"]): k["binary"]["sha256"] for k in manifest["kernels"]},
    )


def configuration(text):
    """解析两种已知生成配置，不执行模块或导入 simpler。"""
    tree = ast.parse(text)
    values = {}

    def value(node):
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.List):
            return [value(n) for n in node.elts]
        if isinstance(node, ast.Dict):
            return {value(k): value(v) for k, v in zip(node.keys, node.values, strict=True)}
        if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name) and node.value.id == "_D":
            assert node.attr in ("IN", "OUT", "INOUT")
            return node.attr
        if isinstance(node, ast.Name) and node.id == "_ROOT_DIR":
            return ""
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Div):
            left, right = value(node.left), value(node.right)
            assert isinstance(left, str) and isinstance(right, str)
            return left + ("/" if left else "") + right
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id == "str"
            and len(node.args) == 1
            and not node.keywords
        ):
            return value(node.args[0])
        raise AssertionError(("unexpected configuration expression", ast.dump(node)))

    expected_root = ast.parse("_ROOT_DIR = Path(__file__).parent").body[0]
    expected_imports = {"from pathlib import Path", "from simpler.task_interface import ArgDirection as _D"}
    expected_tail = ast.parse("""for _entry in [*KERNELS, ORCHESTRATION]:
    _entry['source'] = str(_ROOT_DIR / _entry['source'])
    _entry['signature'] = [getattr(_D, s) for s in _entry['signature']]
    if 'extra_include_dirs' in _entry:
        _entry['extra_include_dirs'] = [str(_ROOT_DIR / p) for p in _entry['extra_include_dirs']]
""").body[0]
    for node in tree.body:
        if isinstance(node, ast.ImportFrom):
            assert ast.unparse(node) in expected_imports
        elif isinstance(node, ast.Assign):
            assert len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
            name = node.targets[0].id
            if name == "_ROOT_DIR":
                assert ast.dump(node) == ast.dump(expected_root)
            else:
                assert name in ("KERNELS", "ORCHESTRATION", "RUNTIME_CONFIG") and name not in values
                values[name] = value(node.value)
        elif isinstance(node, ast.For):
            assert ast.dump(node) == ast.dump(expected_tail)
        else:
            raise AssertionError(("unexpected configuration statement", ast.dump(node)))
    assert values.keys() == {"KERNELS", "ORCHESTRATION", "RUNTIME_CONFIG"}
    assert all("extra_include_dirs" not in e for e in [*values["KERNELS"], values["ORCHESTRATION"]])
    return values



def prepared_artifact(entry):
    from pypto.runtime.kernel.context import get_process_kernel_state
    state = get_process_kernel_state()
    with state._condition:
        registrations = [registration for key, registration in state._specializations.items() if isinstance(key, tuple) and len(key) == 3 and (key[0] is entry)]
        assert len(registrations) == 1, ('expected one actually prepared root', len(registrations))
        registration = registrations[0]
        state.require_registration(registration)
        artifact=registration.artifact
        assert artifact._loaded is not None
        assert registration.callable is artifact._loaded[0]
        assert registration.identity==artifact.loaded_identity()
        return artifact,{'pid':registration.pid,'generation':registration.generation,
            'identity':registration.identity.hex(),'registered_callable_is_loaded_object':True}
def verify_children(callable_,cpu,manifest):
    import ctypes
    from simpler.task_interface import ArgDirection,CoreCallable,ChipCallable
    entries=manifest['kernels'];expected={k['func_id']:k for k in entries}
    assert len(expected)==len(entries)==callable_.child_count
    children=[]
    for entry in entries:
        raw=(cpu/entry['binary']['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==entry['binary']['sha256']
        child=CoreCallable.build(signature=[getattr(ArgDirection,v) for v in entry['signature']],binary=raw)
        children.append((entry['func_id'],child))
    orch=manifest['orchestration'];raw=(cpu/orch['binary']['path']).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==orch['binary']['sha256']
    expected_parent=ChipCallable.build(signature=[getattr(ArgDirection,v) for v in orch['signature']],
        func_name=orch['function_name'],binary=raw,children=children)
    assert callable_.sig_count==expected_parent.sig_count
    assert all(callable_.sig(i)==expected_parent.sig(i) for i in range(callable_.sig_count))
    assert callable_.func_name==expected_parent.func_name and callable_.config_name==expected_parent.config_name
    proof={}
    for index in range(callable_.child_count):
        fid=callable_.child_func_id(index)
        assert fid==expected_parent.child_func_id(index) and fid in expected and str(fid) not in proof
        entry=expected[fid]
        child=callable_.child(index);wanted=expected_parent.child(index)
        assert child.sig_count==wanted.sig_count and child.binary_size==wanted.binary_size
        assert all(child.sig(i)==wanted.sig(i) for i in range(child.sig_count))
        assert child.buffer_size()==wanted.buffer_size()>0
        actual_blob=ctypes.string_at(child.buffer_ptr(),child.buffer_size())
        expected_blob=ctypes.string_at(wanted.buffer_ptr(),wanted.buffer_size())
        assert actual_blob==expected_blob,(fid,entry['name'],'registered child bytes mismatch')
        proof[str(fid)]={'name':entry['name'],'CPU_binary_sha256':entry['binary']['sha256'],
            'serialized_child_sha256':hashlib.sha256(actual_blob).hexdigest(),
            'serialized_child_bytes':len(actual_blob),'CPU_serialized_child_byte_equal':True,
            'padding':'both children extracted from SDK-built parent; all padding bytes compared'}
    assert {int(fid) for fid in proof}==expected.keys()
    return proof

def verify_actual(entry_for,parent):
    result={}
    for arm in ('baseline','candidate'):
        cpu=Path(parent)/('cpu-'+arm)/'kernel'
        artifact,registration=prepared_artifact(entry_for(arm));actual=Path(artifact.output_dir)
        assert artifact._loaded is not None,'actual registered artifact must already be loaded'
        callable_=artifact._loaded[0]
        loaded_identity=artifact.loaded_identity();assert loaded_identity is not None
        cm=json.loads((cpu/'binary_manifest.json').read_text())
        assert [callable_.child_func_id(i) for i in range(callable_.child_count)]==[k['func_id'] for k in cm['kernels']]
        children=verify_children(callable_,cpu,cm)
        cf=list((cpu/'orchestration').glob('*.cpp'));af=list((actual/'orchestration').glob('*.cpp'))
        assert len(cf)==len(af)==1
        cn,cp,ci=normalize(cf[0].read_text());an,ap,ai=normalize(af[0].read_text())
        assert cn==an and cp==ap and len(ci)==len(ai),(arm,'CPU/actual orchestration mismatch')
        assert (cpu/'compiled_meta.json').read_bytes()==(actual/'compiled_meta.json').read_bytes()
        assert configuration((cpu/'kernel_config.py').read_text())==configuration((actual/'kernel_config.py').read_text())
        result[arm]={'artifact_directory':str(actual),'artifact_identity':loaded_identity.hex(),
            'SDK_require_registration_checked_ready_PID_generation_owner':True,'registration':registration,
            'registered_children':children,'CPU_all_registered_child_bytes_equal':True,
            'orchestration_strict_alpha_equal':True,'normalized_orchestration_sha256':hashlib.sha256(an.encode()).hexdigest(),
            'compiled_meta_byte_equal':True,'kernel_config_AST_equal':True,
            'observer_file':__file__,'observer_SHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    return result
