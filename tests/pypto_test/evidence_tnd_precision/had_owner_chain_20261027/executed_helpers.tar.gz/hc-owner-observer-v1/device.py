from pathlib import Path
import hashlib,json,runpy,sys
here=Path(__file__).resolve().parent
manifest=here/'manifest.json'
assert all(hashlib.sha256((here/k).read_bytes()).hexdigest()==v for k,v in json.loads(manifest.read_text()).items())
parent=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-sdk-alignment-20261026-codex/hc-owner-chain-v1')
assert hashlib.sha256((parent/'probe_perf.py').read_bytes()).hexdigest()=='1a20801e66cf0d1769459e9691366913b5640385653da2695bd679e12fbbbecc'
sys.path.insert(0,str(parent));sys.path.insert(0,str(here))
runpy.run_path(str(parent/'sdk_bind.py'),run_name='__sdk_preflight__')
s=(here/'derived_probe.py').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='609134d9d8b5536fd3dfb0e8eba43672c94750272f295af6690a9c02872e2346'
exec(compile(s,str(parent/'probe_perf.py'),'exec'),{'__name__':'__main__','__file__':str(parent/'probe_perf.py'),'PARENT_SHA':'1a20801e66cf0d1769459e9691366913b5640385653da2695bd679e12fbbbecc','OBSERVER_MANIFEST_SHA':hashlib.sha256(manifest.read_bytes()).hexdigest()})
