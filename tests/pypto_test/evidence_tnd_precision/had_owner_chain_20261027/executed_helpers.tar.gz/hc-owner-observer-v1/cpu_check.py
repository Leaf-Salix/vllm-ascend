from pathlib import Path
import hashlib,json,runpy,sys,ctypes
here=Path(__file__).resolve().parent
parent=here.parent/'hc-owner-chain-v1'
sys.path.insert(0,str(parent));sys.path.insert(0,str(here))
runpy.run_path(str(parent/'sdk_bind.py'),run_name='__sdk_preflight__')
from pypto._kernel_abi import KernelABI
from pypto.runtime._kernel_artifact import KernelArtifact
from simpler.task_interface import CoreCallable,ChipCallable,ArgDirection
from identity import verify_children
import torch_npu,_task_interface
assert _task_interface.__build_commit__=='57e499238fd4ee3548947ad860be456aaeeb16b5'
assert not torch_npu.npu.is_initialized()
record={'pass':False,'device_execution':False,'simpler_revision':_task_interface.__build_commit__,'arms':{}}
for arm in ('baseline','candidate'):
    cpu=parent/('cpu-'+arm)/'kernel'
    abi=KernelABI.from_record(json.loads((cpu/'compiled_meta.json').read_text())['kernel_abi'])
    artifact=KernelArtifact(cpu,abi);artifact.load()
    callable_=artifact._loaded[0]
    manifest=json.loads((cpu/'binary_manifest.json').read_text())
    first=verify_children(callable_,cpu,manifest)
    second=verify_children(callable_,cpu,manifest)
    assert first==second
    entries=manifest['kernels'];children=[]
    for k in entries:
        raw=(cpu/k['binary']['path']).read_bytes()
        if k['func_id']==31:raw=raw[:-1]+bytes([raw[-1]^1])
        children.append((k['func_id'],CoreCallable.build(signature=[getattr(ArgDirection,v) for v in k['signature']],binary=raw)))
    orch=manifest['orchestration']
    damaged=ChipCallable.build(signature=[getattr(ArgDirection,v) for v in orch['signature']],func_name=orch['function_name'],binary=(cpu/orch['binary']['path']).read_bytes(),children=children)
    rejected=False
    try:verify_children(damaged,cpu,manifest)
    except AssertionError as error:
        assert 'registered child bytes mismatch' in str(error)
        rejected=True
    assert rejected
    record['arms'][arm]={'children':len(first),'two_independent_expected_serializations_exact':True,'single_byte_mutation_in_actual_child_rejected':True}
assert not torch_npu.npu.is_initialized()
record['pass']=True;record['npu_initialized']=False
(here/'cpu-serialization-check.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2),flush=True)
