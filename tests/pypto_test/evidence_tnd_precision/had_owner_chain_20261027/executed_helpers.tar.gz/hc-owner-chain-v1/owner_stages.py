# SPDX-License-Identifier: Apache-2.0
"""HC逐元素部分和按M8 owner衔接；保留原22分片加法次序。"""
import pypto.language as pl
from .hc_prefix_indexer_stages import VEC_ROWS, MIX_PAD, LINEAR_OK, T_TILE
@pl.jit.inline(auto_scope=False)
def packed_hc_linear_reduce(mixes_partials: pl.Tensor[[PARTIAL_ROWS, MIX_PAD], pl.FP32], vec_ws: pl.InOut[pl.Tensor[[VEC_ROWS, 64], pl.FP32]], worker: pl.Scalar[pl.INDEX]):
    t_linear = pl.tensor.dim(vec_ws, 0) - 8
    for linear_block in pl.range(worker, t_linear // T_TILE, 48):
        linear_t0 = linear_block * T_TILE
        mixes_total = mixes_partials[linear_t0:linear_t0 + T_TILE, 0:MIX_PAD]
        for linear_split in pl.range(1, LINEAR_OK):
            partial_t0 = linear_split * t_linear + linear_t0
            partial_tile = mixes_partials[partial_t0:partial_t0 + T_TILE, 0:MIX_PAD]
            mixes_total = pl.add(mixes_total, partial_tile)
        vec_ws[linear_t0:linear_t0 + T_TILE, 0:MIX_PAD] = mixes_total
    return vec_ws
