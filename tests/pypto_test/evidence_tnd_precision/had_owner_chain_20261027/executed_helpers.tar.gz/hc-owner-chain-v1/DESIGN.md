# HC行owner链单因素候选

借鉴nalinaly按实际owner衔接的SPMD思路，不复制其不同数值的HC数学。原packed_hc_linear_reduce的M16独立元素逐分片加法改M8，与rms/pre_post的8行owner一致。22个分片仍按原顺序逐元素FP32相加，raw0:32/inverse40:48不重叠。H3仍等待Cube写linear；H4只替换成local bar_all/cacheinvalid/fence，Cube删除对应空H4；H5仍等待全部pre供跨owner mix读取。其他8次全体同步及Norm/WKV/Indexer/后续任务均保持。

不是删除量化或改变Norm归约，不改变真正TND边界，也没有新增每请求padding。线性仍读已分配round16物理行，最后8行可能只写pad、不被pre_post消费。须审查M8生成TSTORE与本owner下一TLOAD之间的local排空，所有参与者syncall次数一致。

先CPU64/load/noNPU及生成资源/依赖审查，只HC Cube/Vector叶可变；性能双向稳定后再Native A/B8+ABA和短T/混长，最后真实8K/128K token。每任务780/750秒，原11b精度基准不改。
