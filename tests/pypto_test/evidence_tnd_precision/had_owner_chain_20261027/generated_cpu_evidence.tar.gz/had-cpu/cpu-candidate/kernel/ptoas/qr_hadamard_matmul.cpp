#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qr_hadamard_matmul(__gm__ bfloat16_t* v1, __gm__ float* v2, __gm__ bfloat16_t* v3, int64_t v4, int64_t v5, int64_t v6, int32_t v7, int32_t v8) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v9 = 0;
  // pto: %c65536_i64
  const int64_t v10 = 65536;
  // pto: %c128_index
  const int64_t v11 = 128;
  // pto: %c1_index
  const int64_t v12 = 1;
  // pto: %c27648_index
  const int64_t v13 = 27648;
  // pto: %c4_index
  const int64_t v14 = 4;
  // pto: %c0_index
  const int64_t v15 = 0;
  // pto: %c64_index
  const int64_t v16 = 64;
  // pto: %c24_index
  const int64_t v17 = 24;
  // pto: %c255_index
  const int64_t v18 = 255;
  // pto: %c256_index
  const int64_t v19 = 256;
  // pto: %hadamard_idx__ssa_v0_view
  const int64_t v20 = 1;
  // pto: %hadamard_idx__ssa_v0_view
  const int64_t v21 = 1;
  // pto: %hadamard_idx__ssa_v0_view
  const int64_t v22 = 1;
  // pto: %hadamard_idx__ssa_v0_view
  int64_t v23 = v11 * v11;
  // pto: %hadamard_idx__ssa_v0_view
  int64_t v24 = v22 * v23;
  // pto: %hadamard_idx__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v25 = pto::Shape<1, 1, 1, -1, -1>(v20, v21, v22, v11, v11);
  // pto: %hadamard_idx__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v26 = pto::Stride<-1, -1, -1, -1, -1>(v21 * v24, v24, v23, v11, v12);
  // pto: %hadamard_idx__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v27 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v25, v26);
  // pto: %qh_acc_gm_inline3628__ssa_v0_view
  const int64_t v28 = 1;
  // pto: %qh_acc_gm_inline3628__ssa_v0_view
  const int64_t v29 = 1;
  // pto: %qh_acc_gm_inline3628__ssa_v0_view
  const int64_t v30 = 1;
  // pto: %qh_acc_gm_inline3628__ssa_v0_view
  int64_t v31 = (int64_t) v6;
  // pto: %qh_acc_gm_inline3628__ssa_v0_view
  int64_t v32 = v31 * v11;
  // pto: %qh_acc_gm_inline3628__ssa_v0_view
  int64_t v33 = v30 * v32;
  // pto: %qh_acc_gm_inline3628__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v34 = pto::Shape<1, 1, 1, -1, -1>(v28, v29, v30, v31, v11);
  // pto: %qh_acc_gm_inline3628__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v35 = pto::Stride<-1, -1, -1, -1, -1>(v29 * v33, v33, v32, v11, v12);
  // pto: %qh_acc_gm_inline3628__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v36 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v34, v35);
  // pto: %qr_bf16_inline3563__ssa_v0_view
  const int64_t v37 = 1;
  // pto: %qr_bf16_inline3563__ssa_v0_view
  const int64_t v38 = 1;
  // pto: %qr_bf16_inline3563__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %qr_bf16_inline3563__ssa_v0_view
  int64_t v40 = v13 * v11;
  // pto: %qr_bf16_inline3563__ssa_v0_view
  int64_t v41 = v39 * v40;
  // pto: %qr_bf16_inline3563__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v42 = pto::Shape<1, 1, 1, -1, -1>(v37, v38, v39, v13, v11);
  // pto: %qr_bf16_inline3563__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v43 = pto::Stride<-1, -1, -1, -1, -1>(v38 * v41, v41, v40, v11, v12);
  // pto: %qr_bf16_inline3563__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v44 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v42, v43);
  // pto: %qh_worker_inline3630__ssa_v0
  int64_t v45 = (int64_t) v7;
  // pto: %0
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  if (v4 < v14) {
    // pto: %qh_hadamard_inline3631__tile
    ;
    Tile<TileType::Mat, bfloat16_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v46 = Tile<TileType::Mat, bfloat16_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v11, v11);
    // pto: %qh_hadamard_inline3631__tile
    ;
    uint64_t v47 = (uint64_t) v9;
    TASSIGN(v46, v47);
    // pto: %hadamard_idx__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v48 = PTOAS__GLOBAL_TENSOR_DATA(v27);
    // pto: %hadamard_idx__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 128, 128> v49 = pto::Shape<1, 1, 1, 128, 128>();
    // pto: %hadamard_idx__ssa_v0_pview
    ;
    pto::Stride<16384, 16384, 16384, 128, 1> v50 = pto::Stride<16384, 16384, 16384, 128, 1>();
    // pto: %hadamard_idx__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 128>, pto::Stride<16384, 16384, 16384, 128, 1>, pto::Layout::ND> v51 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 128>, pto::Stride<16384, 16384, 16384, 128, 1>, pto::Layout::ND>(v48, v49, v50);
    TLOAD(v46, v51);
    // pto: %1
    ;
    const int64_t v52 = 1;
    // pto: %1
    ;
    const int64_t v53 = 0;
    // pto: %1
    ;
    int64_t v54 = v6 / v16;
    // pto: %1
    ;
    bool v55 = v6 < v53;
    // pto: %1
    ;
    bool v56 = v16 < v53;
    // pto: %1
    ;
    bool v57 = v55 == v56;
    // pto: %1
    ;
    bool v58 = v6 % v16 != v53 && v55 != v56;
    // pto: %1
    ;
    for (int64_t v59 = v45; v59 < (v58 ? v54 - v52 : v54); v59 += v17) {
      // pto: %2
      ;
      int64_t v60 = (int64_t) ((uint64_t) v59 * (uint64_t) v16);
      // pto: %t__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v61 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v11);
      // pto: %t__tile
      ;
      uint64_t v62 = (uint64_t) v10;
      TASSIGN(v61, v62);
      // pto: %3
      ;
      int64_t v63 = v60 < v15 ? v15 : v60;
      // pto: %qr_bf16_inline3563__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v64 = PTOAS__GLOBAL_TENSOR_DATA(v44);
      // pto: %qr_bf16_inline3563__ssa_v0_pview
      ;
      const int64_t v65 = 0;
      // pto: %qr_bf16_inline3563__ssa_v0_pview
      ;
      const int64_t v66 = 128;
      // pto: %qr_bf16_inline3563__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 64, 128> v67 = pto::Shape<1, 1, 1, 64, 128>();
      // pto: %qr_bf16_inline3563__ssa_v0_pview
      ;
      pto::Stride<8192, 8192, 8192, 128, 1> v68 = pto::Stride<8192, 8192, 8192, 128, 1>();
      // pto: %qr_bf16_inline3563__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND> v69 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND>(v64 + (v65 + v63 * v66), v67, v68);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v61, v69);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %t__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v70 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v16, v11);
      // pto: %t__tile_Left
      ;
      uint64_t v71 = (uint64_t) v9;
      TASSIGN(v70, v71);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      TMOV(v70, v61);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %qh_hadamard_inline3631__tile_Right
      ;
      Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v72 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v11, v11);
      // pto: %qh_hadamard_inline3631__tile_Right
      ;
      uint64_t v73 = (uint64_t) v9;
      TASSIGN(v72, v73);
      TMOV(v72, v46);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %qh_acc_inline3634__tile
      ;
      Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v74 = Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v16, v11);
      // pto: %qh_acc_inline3634__tile
      ;
      uint64_t v75 = (uint64_t) v9;
      TASSIGN(v74, v75);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
      TMATMUL(v74, v70, v72);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      // pto: %qh_acc_gm_inline3628__iter_v1_pview
      ;
      __gm__ float* v76 = PTOAS__GLOBAL_TENSOR_DATA(v36);
      // pto: %qh_acc_gm_inline3628__iter_v1_pview
      ;
      const int64_t v77 = 0;
      // pto: %qh_acc_gm_inline3628__iter_v1_pview
      ;
      const int64_t v78 = 128;
      // pto: %qh_acc_gm_inline3628__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, 64, 128> v79 = pto::Shape<1, 1, 1, 64, 128>();
      // pto: %qh_acc_gm_inline3628__iter_v1_pview
      ;
      pto::Stride<8192, 8192, 8192, 128, 1> v80 = pto::Stride<8192, 8192, 8192, 128, 1>();
      // pto: %qh_acc_gm_inline3628__iter_v1_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND> v81 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND>(v76 + (v77 + v63 * v78), v79, v80);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      TSTORE(v81, v74);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    };
  } else {
    // pto: %5
    ;
    int64_t v82 = (int64_t) ((uint64_t) v4 * (uint64_t) v16);
    // pto: %weight_inline3636__tile
    ;
    Tile<TileType::Mat, bfloat16_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v83 = Tile<TileType::Mat, bfloat16_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v11, v11);
    // pto: %weight_inline3636__tile
    ;
    uint64_t v84 = (uint64_t) v10;
    TASSIGN(v83, v84);
    // pto: %6
    ;
    __gm__ bfloat16_t* v85 = PTOAS__GLOBAL_TENSOR_DATA(v27);
    // pto: %6
    ;
    pto::Shape<1, 1, 1, 128, 128> v86 = pto::Shape<1, 1, 1, 128, 128>();
    // pto: %6
    ;
    pto::Stride<16384, 16384, 16384, 128, 1> v87 = pto::Stride<16384, 16384, 16384, 128, 1>();
    // pto: %6
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 128>, pto::Stride<16384, 16384, 16384, 128, 1>, pto::Layout::ND> v88 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 128>, pto::Stride<16384, 16384, 16384, 128, 1>, pto::Layout::ND>(v85, v86, v87);
    TLOAD(v83, v88);
    // pto: %7
    ;
    int64_t v89 = (int64_t) ((uint64_t) v82 + (uint64_t) v18);
    // pto: %8
    ;
    const int64_t v90 = 1;
    // pto: %8
    ;
    const int64_t v91 = 0;
    // pto: %8
    ;
    int64_t v92 = v89 / v19;
    // pto: %8
    ;
    bool v93 = v89 < v91;
    // pto: %8
    ;
    bool v94 = v19 < v91;
    // pto: %8
    ;
    bool v95 = v93 == v94;
    // pto: %8
    ;
    bool v96 = v89 % v19 != v91 && v93 != v94;
    // pto: %8
    ;
    for (int64_t v97 = v45; v97 < (v96 ? v92 - v90 : v92); v97 += v17) {
      // pto: %9
      ;
      int64_t v98 = (int64_t) ((uint64_t) v97 * (uint64_t) v19);
      // pto: %10
      ;
      int64_t v99 = (int64_t) ((uint64_t) v82 - (uint64_t) v98);
      // pto: %11
      ;
      int64_t v100 = v99 < v19 ? v99 : v19;
      // pto: %source_inline3640__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v100, v11);
      // pto: %source_inline3640__tile
      ;
      uint64_t v102 = (uint64_t) v9;
      TASSIGN(v101, v102);
      // pto: %12
      ;
      int64_t v103 = v98 < v15 ? v15 : v98;
      // pto: %13
      ;
      const int64_t v104 = 0;
      // pto: %13
      ;
      __gm__ bfloat16_t* v105 = PTOAS__GLOBAL_TENSOR_DATA(v44);
      // pto: %13
      ;
      const int64_t v106 = 1;
      // pto: %13
      ;
      const int64_t v107 = 1;
      // pto: %13
      ;
      const int64_t v108 = 1;
      // pto: %13
      ;
      int64_t v109 = v100 * v11;
      // pto: %13
      ;
      int64_t v110 = v108 * v109;
      // pto: %13
      ;
      pto::Shape<1, 1, 1, -1, 128> v111 = pto::Shape<1, 1, 1, -1, 128>(v106, v107, v108, v100, v11);
      // pto: %13
      ;
      pto::Stride<-1, -1, -1, -1, -1> v112 = pto::Stride<-1, -1, -1, -1, -1>(v107 * v110, v110, v109, v11, v12);
      // pto: %13
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v113 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v105 + (v104 + v103 * v11 + v15 * v12), v111, v112);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v101, v113);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %source_inline3640__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v114 = Tile<TileType::Left, bfloat16_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v100, v11);
      // pto: %source_inline3640__tile_Left
      ;
      uint64_t v115 = (uint64_t) v9;
      TASSIGN(v114, v115);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      TMOV(v114, v101);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %weight_inline3636__tile_Right
      ;
      Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v11, v11);
      // pto: %weight_inline3636__tile_Right
      ;
      uint64_t v117 = (uint64_t) v9;
      TASSIGN(v116, v117);
      TMOV(v116, v83);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      // pto: %result_inline3641__tile
      ;
      Tile<TileType::Acc, float, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v118 = Tile<TileType::Acc, float, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v100, v11);
      // pto: %result_inline3641__tile
      ;
      uint64_t v119 = (uint64_t) v9;
      TASSIGN(v118, v119);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
      TMATMUL(v118, v114, v116);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %qh_acc_gm_inline3628__iter_v4_pview
      ;
      const int64_t v120 = 0;
      // pto: %qh_acc_gm_inline3628__iter_v4_pview
      ;
      __gm__ float* v121 = PTOAS__GLOBAL_TENSOR_DATA(v36);
      // pto: %qh_acc_gm_inline3628__iter_v4_pview
      ;
      const int64_t v122 = 1;
      // pto: %qh_acc_gm_inline3628__iter_v4_pview
      ;
      const int64_t v123 = 1;
      // pto: %qh_acc_gm_inline3628__iter_v4_pview
      ;
      const int64_t v124 = 1;
      // pto: %qh_acc_gm_inline3628__iter_v4_pview
      ;
      int64_t v125 = v100 * v11;
      // pto: %qh_acc_gm_inline3628__iter_v4_pview
      ;
      int64_t v126 = v124 * v125;
      // pto: %qh_acc_gm_inline3628__iter_v4_pview
      ;
      pto::Shape<1, 1, 1, -1, 128> v127 = pto::Shape<1, 1, 1, -1, 128>(v122, v123, v124, v100, v11);
      // pto: %qh_acc_gm_inline3628__iter_v4_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v128 = pto::Stride<-1, -1, -1, -1, -1>(v123 * v126, v126, v125, v11, v12);
      // pto: %qh_acc_gm_inline3628__iter_v4_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v129 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v121 + (v120 + v103 * v11 + v15 * v12), v127, v128);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      TSTORE(v129, v118);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
    };
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}