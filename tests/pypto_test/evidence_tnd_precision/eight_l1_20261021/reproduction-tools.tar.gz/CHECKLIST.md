# 八档完整CSA L1口径实测（2026-10-21）

- [x] 用户授权按截图方法实测；保留纯DSL精度基准，不改SDK/正式算子。
- [x] 直接GitHub提交API/代码搜索/分支查询：a241fa61与八档摘要未命中相关公开记录；搜索结果保存，不冒称完全复现该未核实版本。
- [x] 固定公开Nal91c4400e的run_device.py/l1_compare.py/README；完整L1最早incore→最晚结束、恢复窗外、窗口中位数。
- [x] 记录与公开Nal方法的必要差异：Native确定性level1、无dep_gen、禁止C++轮询退避；同输入Native逐位门禁额外保留。
- [x] 复用已验收原SDK与完整overlap64根；实际导入/编译器/环境/源码SHA预检。
- [x] 独立审查脚本；无设备语法/导入/注册门禁。
- [x] 先8K/B16（history8192、seed1024、L4/S6/NZ2/page32），Native与我方八边界A/B/A逐位，首差停。
- [x] 确认5窗×1次FULL raw graph、warm3、L1=1、dep=false，实际覆盖72core；L1保存全部样本。
- [x] 其余七档依次完成；七档PASS/35窗，128K/B28首次A对Native失败，未计时，停止矩阵。
- [x] 每任务内750/外780秒，每≤5分钟观察，不开自动化、不留任务。
- [ ] 原始结果/源码/SHA/限制/复现与截图表对照写入项目文档，增量lint、独立审查、正常commit/push。

## 首差结果

- [x] B28失败raw已取回，六cache/state逐byte；TopK仅row86排列不同，排序集合相同。
- [x] CPU首差摘要：x_out行86/103不同，row103 TopK相同；不能说只修TopK即可。未修数学或跑后续NPU。
- [x] 八项均终态并释放，launcher132–159秒；SSH一度断开，正常退避后恢复。
- [x] 七成功包35raw窗经两套CPU核验；B28失败单列，不记精度通过，不填L1。
- [x] 独立核验器随包manifest可移植修复，临时目录CPU smoke PASS。
