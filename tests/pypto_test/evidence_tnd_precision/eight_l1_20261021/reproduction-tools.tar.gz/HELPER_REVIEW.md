# 八档L1新助手：设备前独立审查

## 结论

最终更新版本源码PASS，未发现阻断首轮8K/B16/history8192测试的问题。建议的四项小门禁已全部按实际源码复核落实。文件SHA及manifest结果见JSON。没有修改助手、SDK或正式源，没有编译/设备操作。

## 已核

- 与旧dfx-tools diff只扩历史max_model_len、显式确定性、公开fixture非均匀Indexer scale、warm3/5窗L1和报告；冻结源43、overlap及相邻包receipt仍验证。
- max_model_len=max(16384,history+128)覆盖131072历史；各档T<=256符合当前资格范围。8K起点用8192，不冒用旧8191测量。
- 同层正式L4权重，make_ragged_fixture seed1024；全S6时与公开make_fixture的bounds/positions/随机顺序及逆序原页布局一致。scale按公开公式覆盖并刷新initial，没有把正确scale当非法cache写区。
- Native先执行并静态SK0捕获，candidate要求eligible及真正PTO调用、根namespace/64ABI正确；A/B各8个状态对Native逐位首差立即失败，A→B→A检查及readonly/合法cache写区保留。
- HC权重clone保留旧Native storage，编译module/graph/runtime对象持有，不影响已捕获的Native参数来源。
- DFX启用level1且depgenFalse，warmup3后5窗各1回放；每窗恢复和同步在begin_dfx外；时间取所有记录idx3/4最早/最晚并按实际freq换µs，保留5样本median/min/max。未混12×100事件计时。
- 每窗实际state等于本臂Native已验收gold，guard重新检查；没有以旧结果跳过本次首差门禁。
- run.sh在CANN source前保存case/batch/history，随后生成S6 lengths，避免前轮位置参数覆盖；指定原build/cache、独立输出与750秒timeout，不修改源码或SDK。
- preflight实际Python3.12/Torch2.10cpu/NPUpost2/vLLM0.25.1及六个import绝对路径均硬断言；source_identity验证原snapshot/43源，预检前后NPU均未初始化。未将新宽参数SDK混进原SDK基准。

## 已落实的门禁

1. `lengths`显式全6断言，当前parser仍允许1～6但protocol固定写S6；规定run.sh会传S6，新增断言可防复现误标签。
2. 候选对Native的所有readonly快照与compact cos/sin/slots逐位等值断言，当前只断言hidden/positions和初始cache相同。几何同seed应相同，但应以实际数据绑定。
3. A恢复回放后，以及warm3后立刻guard/readonly检查，再允许restore_readonly。当前这两阶段的损坏可能在下一次恢复前被覆盖；每个DFX窗后原有检查是正确的。
4. raw metadata明确24AIC/48AIV、dropped_run_boundaries=0。完整root当前每窗一次apply，应验证实际run_boundaries匹配一次根提交；这不是“两条起止对”。72core联合覆盖本身不能证明末端记录完整。多task根不要求恰72条aicore_tasks。

## 报告限定

参考公开91c脚本，而非缺失a241/TND截图工具。保留level1、depgen关闭、原SDK、无100tick C++等待hook的必要差异；截图数据不是本任务同卡对照。Native metadata虽在我方raw graph中执行，Simpler L1统计仅PTO incore，不代表图或服务端到端延迟。每档独立通过才推进矩阵；首差保存并停后续，不把已编译或计划档记成测完。

## 最终设备前确认

已重新读取当前源：全S6断言、readonly键集合与快照/compact严格zip逐位比较、A恢复后guard、warm3后state+guard、24AIC/48AIV类型、零dropped boundaries、1次root run boundary均已具备。formula仍为全记录首incore至末结束，5窗1replay、depgen关闭。helper manifest、Python AST及preflight/run身份已复核；最终SHA更新在JSON。无SDK/代码变更要求，无待解决执行阻断。此结论是源级设备前资格，不提前宣称实际NPU或任一八档通过。
