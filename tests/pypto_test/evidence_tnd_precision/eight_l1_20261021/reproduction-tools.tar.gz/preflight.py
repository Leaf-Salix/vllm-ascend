"""原环境只读精确预检；不分配或初始化NPU。"""
import json
import os
import sys
from pathlib import Path
import pypto
import simpler
import torch
import torch_npu
import vllm
import vllm_ascend
sys.path.insert(0, str(Path(__file__).resolve().parent/'tools'))
from source_identity import source_identity
assert not torch.npu.is_initialized()
assert os.environ.get('PYTHONNOUSERSITE') == '1'
assert '9.2' in os.environ['ASCEND_HOME_PATH']
assert Path(os.environ['PTOAS_ROOT']).is_dir()
assert sys.version_info[:2] == (3, 12)
assert torch.__version__ == '2.10.0+cpu'
assert torch_npu.__version__ == '2.10.0.post2'
assert vllm.__version__ == '0.25.1'
record = {m.__name__: {'file': str(Path(m.__file__).resolve()), 'version': getattr(m, '__version__', None)}
          for m in (pypto, simpler, torch, torch_npu, vllm, vllm_ascend)}
expected={
 'pypto':'/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/low-acceptance-20261010/runtime-package/pypto/__init__.py',
 'simpler':'/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/python/simpler/__init__.py',
 'torch':'/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/env/lib/python3.12/site-packages/torch/__init__.py',
 'torch_npu':'/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/env/lib/python3.12/site-packages/torch_npu/__init__.py',
 'vllm':'/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/vllm/vllm/__init__.py',
 'vllm_ascend':str(Path(os.environ['SOURCE_ROOT'])/'vllm_ascend/__init__.py')}
assert {k:v['file'] for k,v in record.items()}==expected
record['source'] = source_identity()
record['environment'] = {n: os.environ[n] for n in ('ASCEND_HOME_PATH', 'PTOAS_ROOT', 'CCACHE_DIR', 'CMAKE_BUILD_PARALLEL_LEVEL')}
record['npu_initialized'] = torch.npu.is_initialized()
assert not record['npu_initialized']
print(json.dumps(record, ensure_ascii=False, indent=2))
