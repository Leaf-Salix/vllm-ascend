"""只读本次自身保存的CPU首差文件；不初始化NPU。"""
import json
from pathlib import Path
import torch
root=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/eight-l1-20261021-codex/results/eight-l1-128k-b28-v1')
saved=torch.load(root/'first-difference.pt',map_location='cpu',weights_only=True,mmap=True)
assert 'native' in saved['states'] and 'candidate' in saved['states']
a,b=(saved['states'][arm]['idx_topk'] for arm in ('native','candidate'))
rows=(a!=b).any(1).nonzero().flatten().tolist()
output={'scope':'CPU-only saved first-difference tensor; no new NPU run',
        'topk_different_rows':rows,'topk_different_positions':int((a!=b).sum()),'rows':[]}
for row in rows:
 aa,bb=a[row],b[row]
 positions=(aa!=bb).nonzero().flatten()
 same_set=torch.equal(aa.sort().values,bb.sort().values)
 same_pair_members=torch.equal(aa.reshape(-1,2).sort(1).values,bb.reshape(-1,2).sort(1).values)
 output['rows'].append({'row':row,'request':row//6,'query_offset':row%6,
      'same_sorted_topk':same_set,'same_members_per_adjacent_pair':same_pair_members,
      'positions':positions.tolist(),'native_ids':aa[positions].tolist(),'candidate_ids':bb[positions].tolist()})
x,y=(saved['states'][arm]['x_out'] for arm in ('native','candidate'))
output['output_different_rows']=(x!=y).flatten(1).any(1).nonzero().flatten().tolist()
output['output_row_metrics']=[]
for row in output['output_different_rows']:
 xx,yy=x[row].float(),y[row].float()
 ux=x[row].view(torch.int16).to(torch.int32)&65535
 uy=y[row].view(torch.int16).to(torch.int32)&65535
 ox=torch.where((ux&32768)!=0,32768-(ux&32767),32768+ux)
 oy=torch.where((uy&32768)!=0,32768-(uy&32767),32768+uy)
 output['output_row_metrics'].append({'row':row,'different_elements':int((xx!=yy).sum()),'max_abs':float((xx-yy).abs().max()),'relative_l2':float(torch.linalg.vector_norm(xx-yy)/torch.linalg.vector_norm(xx).clamp_min(1e-30)),'max_output_BF16_ULP':int((ox-oy).abs().max()),'first_coordinates':(xx!=yy).nonzero()[:8].tolist()})
output['all_cache_states_byte_equal']={name:torch.equal(v.contiguous().view(torch.uint8),saved['states']['native'][name].contiguous().view(torch.uint8))
                                      for name,v in saved['states']['candidate'].items() if name not in ('idx_topk','x_out')}
print(json.dumps(output,indent=2))
