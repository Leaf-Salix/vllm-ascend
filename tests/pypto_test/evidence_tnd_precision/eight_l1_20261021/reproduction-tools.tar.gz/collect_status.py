"""只查询本次八个自有任务的最终状态与日志。"""
import json,subprocess
tasks=['task_20261021_110417_8691182981', 'task_20261021_110754_102956721682', 'task_20261021_111059_123601218316', 'task_20261021_111345_136436017901', 'task_20261021_111657_161001416888', 'task_20261021_112026_18055493262', 'task_20261021_112446_206901413743', 'task_20261021_112831_224465013915']
result=[]
for task in tasks:
 status=subprocess.run(['task-submit','--status',task],text=True,capture_output=True,check=True).stdout.strip()
 log=subprocess.run(['task-submit','--log',task],text=True,capture_output=True,check=True).stdout
 result.append({'task':task,'status':status,'log':log})
print(json.dumps(result,indent=2))
