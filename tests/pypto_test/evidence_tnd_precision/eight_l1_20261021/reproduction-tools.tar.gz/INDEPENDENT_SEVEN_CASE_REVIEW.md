# 八档矩阵：前七份原始包独立复核

截至本报告，已独立重新执行`independent_recheck.py`读取前七份原始tar，全部CPU退出0/PASS。没有访问设备、改正式算子或重新运行模型。

| 配置 | 完整PTO L1 median µs | 每窗core记录 | 每窗task数 |
| --- | ---: | ---: | ---: |
| 8K/B16 | 1213.20 | 1219 | 53 |
| 8K/B32 | 1793.44 | 1502 | 53 |
| 128K/B1 | 668.08 | 852 | 53 |
| 128K/B4 | 850.94 | 937 | 53 |
| 128K/B8 | 1038.86 | 1006 | 53 |
| 128K/B16 | 1419.38 | 1187 | 53 |
| 128K/B24 | 2033.90 | 1355 | 53 |

35份raw均为5窗×1replay、24AIC+48AIV联合72core、无dropped boundary、1次root提交。各窗记录数/task数与结果字段一致；从真实freq及idx3/4独立重算所有样本和median，保留全部样本。

七档均核对Native A/B八边界逐位、compiled/raw、A/B/A、poison、合法cache写区/readonly guards、真实64参数overlap根、无fallback。原SDK路径、helper/43控制源和6个overlap源身份均一致，不能用源码同名代替SHA。预检NPU未初始化；测量数据来自已有任务。

来源、SHA及每档5样本详见`INDEPENDENT_SEVEN_CASE_SUMMARY.json`。128K/B28还没有原始包，此报告不将其计作通过，不生成八档总体几何平均或“八档完成”标签。

公开方法来源仍是91c固定源码：真实L4/seed1024/非均匀Indexer scale、S6、history8192/131072、5窗L1首incore至末结束；本轮保留level1、无depgen、纯DSL不启用100tick C++等待hook、原精度SDK等必要差异。截图a241fa61/TND commit/完整工具链尚不明确，数据只能作为用户参考，不能声称同卡受控性能AB或复现截图全部设置。

本轮没有新整模型token或192-token回归，也未新增ragged配置验证。S6只是矩阵输入，不表示已把实现改为每请求补6行；旧whole模型精度范围与本单层测试分别陈述。
