"""独立重读八档证据：只用Python标准库，不导入Torch或NPU。"""
import argparse
import hashlib
import json
import statistics
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('archive', type=Path)
parser.add_argument('--batch', type=int, required=True)
parser.add_argument('--history', type=int, required=True)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
result = {'pass': False, 'scope': 'CPU saved-evidence audit only; not a new hardware run or whole-model token test'}
try:
    with tarfile.open(args.archive) as archive:
        members = [m for m in archive if m.isfile()]
        assert len({m.name for m in members}) == len(members), 'duplicate archive members'
        payloads = {m.name: archive.extractfile(m).read() for m in members}
    names = [n for n in payloads if n.endswith('/result.json')]
    assert len(names) == 1
    case = names[0].rsplit('/', 1)[0]
    report = json.loads(payloads[names[0]])
    assert report['complete'] and report['pass']
    assert report['layer'] == 4 and report['history'] == args.history
    assert report['lengths'] == [6] * args.batch
    assert report['true_tokens'] == report['physical_graph_tokens'] == args.batch * 6
    assert report['per_request_padding'] == report['hypothetical_s6_extra_rows'] == 0
    helpers = json.loads((ROOT / 'tools/manifest.json').read_text())
    assert report['helper_sha'] == helpers
    assert report['manifest_sha256'] == hashlib.sha256((ROOT / 'tools/manifest.json').read_bytes()).hexdigest()
    assert all(hashlib.sha256((ROOT / 'tools' / name).read_bytes()).hexdigest() == sha for name, sha in helpers.items())
    binding = json.loads((ROOT / 'tools/binding.json').read_text())
    assert report['source_manifest_sha256'] == binding['source_manifest_sha256']
    assert report['source_file_count'] == binding['source_file_count']
    assert report['source_root'] == binding['source_root']
    assert report['tested_sources'] == binding['tested_sources']
    formal_sources = ROOT / 'FORMAL_CANDIDATE_SOURCES.json'
    assert report['candidate_sources'] == json.loads(formal_sources.read_text())
    preflight_name = case + '-preflight.json'
    text = payloads[preflight_name].decode()
    start = text.index('\n{') + 1 if '\n{' in text else 0
    preflight, _ = json.JSONDecoder().raw_decode(text[start:])
    assert preflight['npu_initialized'] is False
    expected_paths = {
        'pypto': '/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/low-acceptance-20261010/runtime-package/pypto/__init__.py',
        'simpler': '/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/python/simpler/__init__.py',
        'torch': '/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/env/lib/python3.12/site-packages/torch/__init__.py',
        'torch_npu': '/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/env/lib/python3.12/site-packages/torch_npu/__init__.py',
        'vllm': '/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/vllm/vllm/__init__.py',
        'vllm_ascend': binding['source_root'] + '/vllm_ascend/__init__.py',
    }
    assert all(preflight[name]['file'] == path for name, path in expected_paths.items())
    assert preflight['torch']['version'] == '2.10.0+cpu'
    assert preflight['torch_npu']['version'] == '2.10.0.post2'
    assert preflight['vllm']['version'] == '0.25.1'
    for key in ('source_manifest_sha256', 'source_file_count', 'tested_sources', 'source_root'):
        assert preflight['source'][key] == report[key]
    assert '9.2' in preflight['environment']['ASCEND_HOME_PATH']
    boundaries = {'x_out', 'idx_topk', 'swa.0', 'compressed.0', 'state.0', 'indexer.0', 'indexer.1', 'indexer_state.0'}
    for key in ('comparisons', 'B_comparisons'):
        checks = report[key]['candidate']
        assert set(checks) == boundaries
        assert all(c['bit_equal'] and c['different_elements'] == 0 and c['max_abs'] == 0 and c['relative_l2'] == 0 for c in checks.values())
    for arm in ('native', 'candidate'):
        graph = report['graphs'][arm]
        assert graph['actual_acl_graph'] and graph['fullgraph'] and graph['compiled_raw_equal']
        assert graph['topk_poison_replay_restored'] and graph['live_input_ABA']
        assert graph['true_tokens'] == graph['graph_tokens'] == args.batch * 6
        assert graph['options']['super_kernel_optimize'] is False
        assert all(c['status'] == 'PASS' and c.get('outside_slot_bytes', 0) == 0 for c in graph['guards'].values())
    entry = report['entry']['candidate']
    assert entry['eligible'] and entry['route'] == 'PTO'
    schema = report['graphs']['candidate']['root_schema']
    assert schema.startswith('dsv4_csa_tnd_precision_spmd_overlap::attention(')
    assert schema.split(' -> ')[0].count('Tensor') == 64
    assert report['graphs']['candidate']['pto_dispatch_calls'] > 0
    assert report['packet_checks']['readonly_after_replay']
    assert all(report['packet_checks']['norm_byte_equal'].values()) and all(report['packet_checks']['order_byte_equal'].values())
    protocol = report['protocol']
    assert protocol['fixture_seed'] == 1024 and protocol['S'] == 6 and protocol['page'] == 32 and protocol['NZ'] == 2
    assert protocol['deterministic_level'] == 1 and protocol['dep_gen'] is False and protocol['wait_backoff'] is False
    assert protocol['indexer_scale'] == '0.00390625+((row*37)%251)/16384'
    dfx = report['DFX']
    assert dfx['level'] == 1 and dfx['enable_dep_gen'] is False
    assert dfx['warmup'] == 3 and dfx['replays_per_window'] == 1 and len(dfx['windows']) == 5
    raw_names = {n for n in payloads if n.endswith('chip_swimlane_records.json')}
    assert len(raw_names) == 5
    windows = []
    for i, recorded in enumerate(dfx['windows']):
        suffix = 'dfx/' + (f'window_{i}/' if i else '') + 'chip_swimlane_records.json'
        name = case + '/' + suffix
        raw = json.loads(payloads[name])
        meta, rows = raw['metadata'], raw['aicore_tasks']
        assert raw['chip_swimlane_level'] == 1 and meta['clock_freq_hz'] > 0
        assert meta['num_cores'] == 72 and meta['core_types'] == ['aic'] * 24 + ['aiv'] * 48
        assert meta['dropped_run_boundaries'] == 0 and len(meta['run_boundaries']) == 1
        assert rows and all(len(row) == 6 and 0 < row[3] <= row[4] for row in rows)
        assert {row[0] for row in rows} == set(range(72))
        span = (max(row[4] for row in rows) - min(row[3] for row in rows)) * 1e6 / meta['clock_freq_hz']
        task_count = len({row[1] for row in rows})
        assert recorded['repeat'] == i and recorded['incore_span_us'] == span
        assert recorded['records'] == len(rows) and recorded['tasks'] == task_count
        assert recorded['cores'] == 72 and recorded['clock_freq_hz'] == meta['clock_freq_hz']
        windows.append({'repeat': i, 'span_us': span, 'records': len(rows), 'tasks': task_count, 'raw_sha256': hashlib.sha256(payloads[name]).hexdigest()})
    assert len({(w['records'], w['tasks']) for w in windows}) == 1
    values = [w['span_us'] for w in windows]
    assert report['l1'] == {'samples_us': values, 'median_us': statistics.median(values), 'min_us': min(values), 'max_us': max(values)}
    result.update(pass_=True, archive_sha256=hashlib.sha256(args.archive.read_bytes()).hexdigest(), case=case, batch=args.batch, history=args.history,
                  result_sha256=hashlib.sha256(payloads[names[0]]).hexdigest(), preflight_sha256=hashlib.sha256(payloads[preflight_name]).hexdigest(),
                  windows=windows, l1=report['l1'], precision='A/B eight external boundaries Native bit exact; ABA/guards/rawgraph/64ABI passed',
                  source_manifest_sha256=report['source_manifest_sha256'], helper_manifest_sha256=report['manifest_sha256'])
    result['pass'] = True
except BaseException as error:
    result['error'] = repr(error)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    raise
args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'pass': result['pass'], 'case': result['case'], 'l1': result['l1']}, ensure_ascii=False))
