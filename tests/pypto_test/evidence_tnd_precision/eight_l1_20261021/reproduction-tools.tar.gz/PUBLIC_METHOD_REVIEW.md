# 八档S6完整L1：公开方法独立审查

## 结论

原已验收SDK、overlap64完整精度根，先8K/B16/history8192、全S6，warmup3后5个独立L1窗口每窗1次回放、输入恢复在外、dep-gen关闭、Native逐位首差停，方案合理。其余七档必须在首个配置通过后顺次执行，任务不超过15分钟。

这能尽量对齐公开方法的输入与L1统计，**尚不能声称完全复现用户截图a241fa61**：该BSH对象、截图TND commit/工具与原始样本未取得。公开91c的默认SPMD与截图版本不是同一身份，不能悄悄替换。此次只读取已在本地的91c Git对象，不执行fetch、编译或设备；源SHA见JSON。

## 公开入口及确定的fixture

公开方法位于`tests/pypto_test/csa_multishape_spmd_20261016/dynamic_full_pipeline_20261017/`的README、run_device.py、l1_compare.py；公共fixture是`tests/pypto_test/dsv4_csa_single_layer.py::make_fixture`。

- 实际加载第4层正式权重，不加载MoE，属于完整CSA attention half，不是整模型。
- run_device显式调用make_fixture(..., **seed1024**)。fixture入口同时torch.manual_seed和torch.npu.manual_seed；hidden为BF16[T,4,4096]随机张量，T=B×6。
- query bounds=[0,6,...6B]，seq_len=history+6；每请求positions为history..history+5。8K采用8192，128K采用131072；此前8191控制点不是同输入，模4/128边界会改变有效压缩工作，不应沿用旧1203.68作本矩阵实测。
- 页32；compressed/indexer每请求按完整历史容量分配独占页，SWA/state按原有限页循环。原page table为请求独占区内逆序循环映射；`indexer_page_pattern='original'`。ascending/fragmented是功能实验，不并入原七档成绩。
- INT8 cache随机[-64,64)，其余float cache/state normal(0,0.5)，indexer scale在fixture内初始0.01。
- **run_device随后覆盖indexer scale**：`0.00390625+((flat_row*37)%251)/16384`，并重存allocation initial。若仅复用make_fixture默认0.01，并未对齐真正公开性能输入。旧R20三方fixture用0.01也不能冒称其分数已是相同数据。
- Native builder生成metadata、slot mapping和compact RoPE，顺序必须在最终页序设定后。cos/sin/slot、初始cache、hidden与positions应各记录实际SHA；相同seed跨不同PyTorch/NPU版本并不保证随机数据bit相同。

公开动态目录没有顶层compile.py；此review没有把其它历史results/compile.py当作本入口seed来源。所核历史离线compile.py只恢复包并compile/load，不生成这里的随机fixture。除非取得截图脚本的精确路径，已证据化的seed应写run_device→make_fixture的1024，不臆造“编译seed”。

## L1统计如何对齐

l1_compare对完整entry捕获raw NPUGraph；先完整输出/TopK/cache/guard验收，再warmup3，随后每窗reset、stream同步、begin_dfx、graph.replay一次、end_dfx。reset/输入恢复和CPU检查均在采样外。

原始记录是六列，idx3/4是incore开始/结束；窗口延迟为`(max(end)-min(start))*1e6/clock_freq_hz`，含核内等待、阶段间隙。不是submit/finish或root run_boundaries差，也不是event的12×100均值。5窗保留全部样本并取median，另报min/max；不删离群值。

原公开helper核对72个physical core，单SPMD要求72条/1 runtime token；我方完整根是多个tasks，不能沿用单MIX“恰72条”断言，只核24AIC/48AIV联合覆盖及实际token合法映射。检查dropped records/boundaries，实际root次数和clock frequency。Native图不产Simpler泳道，其精度门禁与PTO L1要分清。

公开README明确metadata producer在图外；我方正式service仍含Nativeproducer时，L1仅记录PTO incore，应注明外围producer未被计入该跨度，并保留图/stream身份。不能将本轮L1称完整服务端到端延迟，也不能沿用common-metadata图event与其相除。

## 必要保留的差异

| 项目 | 91c公开方法 | 本轮必要选择 |
| --- | --- | --- |
| Determinism | run_device level0 | level1+HCCL，保证Native bit金值，明确不同 |
| 等待实现 | README性能启用100tick测试编译hook | 严格纯DSL，保留原SDK等待，不使用C++改写 |
| Dep-gen | 原runner L1模式同时开启 | DFX计时关闭；依赖图另任务 |
| SDK | Nal独立依赖/宽参数SPMD | 保留我方已验收旧SDK/overlap64；报告实际import与二进制 |
| 参考版本 | 公开91c，七档历史多种策略/原型 | 截图BSH a241fa61、TND commit未知，等待其原始入口 |
| 精度gold | 公开runner对原dynamic PTO | 本轮对Native，第一bit差即停；不弱化到Nal已知误差 |

公开README的复现命令明确l1-windows5，但这只证明公开方法允许/使用5窗，不能证明截图634.16等八个数字也由同脚本同窗口生成。公开历史性能含100tick hook，不能在我方没有该hook时承诺相同调度效率。

## 八档执行及结果呈现

先8K/B16(h8192)，再剩余8K/B32及128K/B1/B4/B8/B16/B24/B28(h131072)，每档S6真实T分别96/192和6/24/48/96/144/168。所有T<=256，仍应逐档检查Native静态资格、根ABI、页表/compact容量与真实图capture，不从一个T的PASS推导其它T。

各档单独任务，失败先保存首差并停止后续矩阵，不将部分编译/排队算NPU测试；运行日志记录START/END和队列最终状态。5个L1原始窗口、输入/权重/metadata/cache身份、源码/SDK与协议检查齐全再汇总。

结果表分为“用户截图参考”和“我方本轮实测”，不要把空项填旧数据。若未得到a241/TND精确工具，任何相对截图比值只作不同条件参考，不能命名受控加速比；八档等权几何平均同样需明确并非同硬件对拍。稳定优化与真实模型token验收仍是后续独立门槛。
