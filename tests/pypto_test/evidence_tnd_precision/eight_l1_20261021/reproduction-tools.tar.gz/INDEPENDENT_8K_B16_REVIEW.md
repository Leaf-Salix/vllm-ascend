# 8K/B16首档：独立原始证据复核

结果PASS。仅CPU读取已保存材料，未执行NPU、修改正式源或改变候选。

- 配置：真实L4权重，history8192、B16、T96、全S6；非均匀Indexer scale、seed1024。
- Native/我方输入A、B各8类外部边界逐位一致；compiled/raw、A/B/A、合法cache写区与readonly guard均通过。实际eligible为PTO，无回退；root schema为overlap64个Tensor。
- preflight日志实际绑定原PyPTO/Simpler/Torch等绝对路径，NPU未初始化；43控制源与6个overlap源身份、helper manifest与已审版本一致。preflight文件前有vLLM日志，不是整文件纯JSON，核验器从独立JSON对象解析。
- 五个raw均为level1、24AIC+48AIV、72core、无dropped run boundary、每窗1次完整root；每窗1219条core记录、53个task，与结果字段相同。
- 从raw idx3/4及50MHz时钟重算：1234.64、1213.20、1199.38、1220.92、1209.92µs；median **1213.20µs**，min1199.38、max1234.64，未删样本。

保存复核：[INDEPENDENT_8K_B16_RECHECK.json](INDEPENDENT_8K_B16_RECHECK.json)。

可复用纯标准库核验器：

```bash
python3 reports/dsv4-tnd-eight-l1-20261021/independent_recheck.py \
  reports/dsv4-tnd-eight-l1-20261021/eight-l1-8k-b16-v1-evidence.tar.gz \
  --batch 16 --history 8192 \
  --out reports/dsv4-tnd-eight-l1-20261021/INDEPENDENT_8K_B16_RECHECK.json
```

后续每包改实际archive/batch/history/out即可，保持被测助手冻结；脚本不导入Torch或NPU。它严格拒绝SHA/门禁不符，不把失败包当作计时PASS。

这是首个单层完整PTO L1点，不是新增整模型token、192-token或EPLB开启资格。用户截图634.16µs缺少完整同环境来源，只能列参考，不能写本轮受控相对差距。其它七档不由此PASS自动推广。
