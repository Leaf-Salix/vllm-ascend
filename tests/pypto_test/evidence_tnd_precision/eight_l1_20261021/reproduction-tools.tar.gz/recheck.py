"""直接重算每档原始L1和逐位门禁；不导入NPU。"""
import hashlib
import json
import statistics
import tarfile
from pathlib import Path

root=Path(__file__).resolve().parent
manifest=json.loads((root/'tools/manifest.json').read_text())
results=[]
failures=[]
for path in sorted(root.glob('*-evidence.tar.gz')):
    with tarfile.open(path) as tar:
        members=[m for m in tar if m.isfile()]
        assert len({m.name for m in members})==len(members)
        data={m.name:tar.extractfile(m).read() for m in members}
    name=next(k for k in data if k.endswith('/result.json'))
    case=name.split('/')[0]
    r=json.loads(data[name])
    if not r['pass']:
        assert case=='eight-l1-128k-b28-v1' and not r['complete']
        assert r['history']==131072 and r['lengths']==[6]*28
        assert r['helper_sha']==manifest
        assert r['candidate_sources']==json.loads((root/'FORMAL_CANDIDATE_SOURCES.json').read_text())
        assert r['failed_boundaries']==['x_out','idx_topk']
        assert 'first bit difference' in r['error'] and 'DFX' not in r and 'l1' not in r
        checks=r['comparisons']['candidate']
        assert checks['x_out']['different_elements']==1731 and checks['idx_topk']['different_elements']==88
        assert all(v['bit_equal'] for k,v in checks.items() if k not in ('x_out','idx_topk'))
        failures.append({'case':case,'precision_pass':False,'l1_measured':False,'failed_boundaries':r['failed_boundaries'],'metrics':checks,'archive_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
        continue
    assert r['complete'] and r['pass']
    assert r['helper_sha']==manifest
    assert r['candidate_sources']==json.loads((root/'FORMAL_CANDIDATE_SOURCES.json').read_text())
    assert r['layer']==4 and set(r['lengths'])=={6}
    assert r['true_tokens']==r['physical_graph_tokens']==6*len(r['lengths'])
    assert r['per_request_padding']==0
    assert r['DFX']['level']==1 and not r['DFX']['enable_dep_gen']
    assert r['DFX']['warmup']==3 and r['DFX']['replays_per_window']==1
    assert len(r['DFX']['windows'])==5
    assert r['protocol']['deterministic_level']==1 and not r['protocol']['wait_backoff']
    for section in ('comparisons','B_comparisons'):
        checks=r[section]['candidate']
        assert len(checks)==8 and all(v['bit_equal'] for v in checks.values())
    for arm in ('native','candidate'):
        g=r['graphs'][arm]
        assert g['actual_acl_graph'] and g['fullgraph'] and g['compiled_raw_equal'] and g['live_input_ABA']
        assert all(v['status']=='PASS' for v in g['guards'].values())
    schema=r['graphs']['candidate']['root_schema']
    assert schema.startswith('dsv4_csa_tnd_precision_spmd_overlap::attention(')
    assert schema.split(' -> ')[0].count('Tensor')==64
    assert r['graphs']['candidate']['pto_dispatch_calls']>0
    assert r['packet_checks']['readonly_after_replay']
    values=[]
    for i,window in enumerate(r['DFX']['windows']):
        stem=f'{case}/dfx/'+(f'window_{i}/' if i else '')
        raw=json.loads(data[stem+'chip_swimlane_records.json'])
        meta=raw['metadata'];rows=raw['aicore_tasks']
        assert raw['chip_swimlane_level']==1 and meta['clock_freq_hz']>0
        assert meta['core_types']==['aic']*24+['aiv']*48
        assert meta['dropped_run_boundaries']==0 and len(meta['run_boundaries'])==1
        assert {x[0] for x in rows}==set(range(72))
        assert all(len(x)==6 and 0<x[3]<=x[4] for x in rows)
        span=(max(x[4] for x in rows)-min(x[3] for x in rows))*1e6/meta['clock_freq_hz']
        assert span==window['incore_span_us']
        assert len(rows)==window['records'] and len({x[1] for x in rows})==window['tasks']
        values.append(span)
    assert values==r['l1']['samples_us'] and statistics.median(values)==r['l1']['median_us']
    preflight_raw=data[case+'-preflight.json'].decode()
    decoder=json.JSONDecoder()
    preflight=None
    for i,c in enumerate(preflight_raw):
        if c=='{':
            try:
                obj,_=decoder.raw_decode(preflight_raw[i:])
                if 'npu_initialized' in obj:preflight=obj;break
            except json.JSONDecodeError:pass
    assert preflight is not None and not preflight['npu_initialized']
    assert preflight['source']['tested_sources']==r['tested_sources']
    results.append({'case':case,'history':r['history'],'batch':len(r['lengths']),
                    'L1_samples_us':values,'L1_median_us':statistics.median(values),
                    'A_and_B_all_8_boundaries_bit_equal':True,'root_tensors':64,
                    'pass':True,'archive_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
output={'available_successful_evidence_pass':True,'full_matrix_pass':False,'expected_cases':8,'validated_cases':len(results),'retrieved_cases':len(results)+len(failures),'failed_cases':failures,'scope':'Saved single-layer graph states and raw hardware L1, not new whole-model token validation','cases':results}
(root/'RECHECK.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(output,ensure_ascii=False,indent=2))
