# 参照公开Nal方法的八档测试方案

当前正式实现保留；测试完整HC-pre到HC-post、单PTO根、纯DSL、真实TND的overlap精度候选。
本次只测正式第4层权重和合成hidden/history；不构造MoE或新的192-token整模型任务。

## 已固定的执行协议

- S6，TP1，Native page32，NZ2；8K/128K分别使用history8192/131072。
- Seed1024；Native和PTO独立cache，使用相同hidden、positions、metadata、compact RoPE、逆序循环页表和非均匀Indexer scale。
- 比较Native与PTO八类外部边界的A/B输入，检查A恢复、compiled/raw、保护区、真实64参数根、无回退；首个byte差即停。
- FULL raw graph，warm3，5个独立L1窗，各1次回放；restore和同步在窗外。
- 从原始六列记录[3]/[4]取所有72核最早incore开始至最晚结束，依实际clock_freq转换µs，再取5窗中位数；含内部等待/空隙，保留全部样本。
- Native确定性level1、HCCL/Torch开启；DFX=1，dep_gen=false，无生成C++替换或wait-backoff。
- 原SDK和缓存复用；每个独立单卡任务内750/外780秒。先8K/B16/B32，再128K/B1/B4/B8/B16/B24/B28。

## 与公开参考的必要差异

公开91c4400e的README说明性能启用100tick C++等待hook，run_device在L1时同时开dep_gen并设level0。
按本会话约束保留纯DSL、level1且dep关闭，不能把这些协议差异隐藏。
截图BSH a241fa61、其TND候选及具体依赖当前未从GitHub定位，因此只有计时方法和公开fixture约定对齐，不能称截图的逐项完全复现。

## 下一步

先完成八档完整L1与Native逐位门禁，保存原始记录和版本；本轮不同时改算法。
测试结果不直接替代整模型token验收。后续优化逐项验证，稳定更快后再8K/B40到128K/B24的192-token回归。
