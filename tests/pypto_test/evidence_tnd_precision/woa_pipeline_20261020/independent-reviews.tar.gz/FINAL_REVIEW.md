# 本轮最终报告与原始结果独立审查

## 结论

**通过，无发布阻断，无必要修正文案。** 审查对象为本目录 REPORT_DRAFT.md、REPRODUCTION.md、AB_VALIDATION.json、RUNS.json，并独立读取11项AB原始JSON、15任务回执归档、PMU原始9CSV及L1原始9窗复核。

报告准确表达了“局部方向改善，但没有快过同任务冻结后缀，因此不接完整CSA、不启动整模型”。没有把源级数学等价、旧候选资格或部分模块收益写成正式交付收益。

本次只读审查，未运行设备，未修改被冻结源码/原始结果。正式checkout在审阅时HEAD为a3b9d0dd8，变更仅新增测试报告与证据，无运行源码修改。

## 11项AB重新计算

没有运行会重写 AB_VALIDATION.json 的分析入口；用独立只读Python读取原始样本，重新确认：

- 11项均pass/complete/actual_acl_graph/guards/readonly为true；每项160指标逐bit且different_elements=0，共1760指标。
- 每项两个常驻臂最终generation均1204。
- 每臂12个正样本，100次回放/窗，不删样；min/mean/median/max与原报告逐项一致。
- 直接parent、tokens与RUNS一致；实际候选文件、harness及parent proof的SHA都与原result匹配。
- 所有改善窗数及相对父版变化重算一致；**11项全部132个new-vs-frozen窗口均较慢**。不满足正式接入条件的结论充分。
- 正式AB probe时间范围92.0827…108.0241秒，与报告92.1…108.0秒一致；这是probe时间，未混为排队或整任务时间。

| 组合 | T | frozen μs | owner2父版 μs | new μs | 相对父版 | 相对冻结 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 完整heads-tail实现增量 | 126 | 408.821392 | 525.539093 | 476.129513 | -9.401695% | +16.463943% |
| K128增量 | 240 | 474.170399 | 536.739197 | 505.177212 | -5.880320% | +6.539171% |

报告表格按两位小数显示准确。明确T126增量包含显式Mat表达及预载，不是假称只改一条DMA；没有相加不同任务的单因素百分比，也没有用跨任务的父基线漂移证明候选排名。

tailboth相对tailpreload回退2.804415%、0/12改善；nopipe回退2.490541%、0/12改善，淘汰口径正确。其它12/12只限定本任务窗口方向，报告已明确不等于跨设备/独立重复/整模型资格。

## 任务及版本收据

RUNS有15个唯一task，全部completed；归档的task-status逐项与清单一致：12项exit0、3项exit1。11项AB归档result与本地对应JSON内容相同，未发现删掉失败或改绿状态。

三项观测失败分别保留DFX不存在API、DFX重复init、PMU footer NameError。CPU历史失败与设备数值失败分开，没有把未完成lowering的split/pipeline当作NPU精度失败。

AB模式实际选择的脚本SHA已与原result重新匹配：ab_probe.py、ab_probe_v2.py、ab_probe_owner2.py、ab_probe_v3.py。v3祖先链和直接parent关系与前序源码审查一致。被测候选不是仅改报告名称的旧parent模块。

## PMU失败数据的限定

独立从原始归档读9份kernel_details.csv，仅选parent/new各3条同名MIX设备行，所有保存数值及逐字段中位数与PMU_DEVICE_VALIDATION一致。重新确认parent/new AICore637.099/592.786μs、MAC75.588/77.112、MTE1 88.297/87.798、MTE2 291.630/289.836。

原PMU result的pass/complete均为false，错误正是footer samples未定义；其70项逐bit检查全部通过。历史harness SHA `0339c086…` 与 ab_probe_pmu_v1.py匹配。原result没有最终guards/readonly/actual_acl_graph成功字段，报告也没有据此冒认整个PMU任务通过。

报告只确认已产出的设备计数有效，明确不将Scalar全部叫signal等待，不把可重叠busy相加或从跨度相减求stall。“符合重叠/流水空隙改善的解释”同时保留非唯一因果限定，未作过强归因。

## L1单回放与连续计时

独立读取原始9窗，重新核对6列schema、24AIC/48AIV、50MHz、dropped=0、每窗记录数以及root launch数。frozen522条/2root，其它72条/1root，run_boundaries按开始标记解释正确。

| 中位span μs | frozen | phase1 | K128 |
| --- | ---: | ---: | ---: |
| total | 510.04 | 441.54 | 475.18 |
| AIC | 275.60 | 384.68 | 417.58 |
| AIV | 390.88 | 441.54 | 475.18 |

逐窗重算与原result完全一致。报告保留K128在该DFX单回放条件下比phase1慢的事实，没有为了迎合连续12×100结果删去反向观测。插桩、批量和缓存/调度条件不同，以及角色包络不可相加的限定充分；没有将结果解释成已唯一定位等待或搬运瓶颈。

## 复现与发布材料

REPRODUCTION准确列出各mode的实际脚本/parent关系，区分当前修好PMU脚本与失败时v1，且明确不能用当前SHA冒认旧任务。正式AB复现命令使用独立case、task-submit、780秒外限/750秒内限，未建议直接占设备或覆盖旧输出。

身份表明确实际PTOAS为隔离0.66 wheel、调度0.63仅入口标签；未杜撰wheel的Git源提交。源码/DSO实际收据、真实L4权重但合成输入、冻结PTO金值及非新Native/整模型验收的范围一致。

审查时已迁入项目的14个发布文件SHA全部匹配SHA256.json；raw-results的32条RAW_SHA256逐条对应原包字节。复现tools含最终与历史入口，没有模型张量或.so/.whl/.o。报告相对链接与项目迁入位置匹配。

本审查文件若随后加入independent-reviews归档，正常重封该归档并更新发布SHA即可，不应重写被测源和raw JSON。没有需要追加设备任务才能发布当前窄结论的风险。

## 第16任务、第12项AB补充独立复核

上面的原15任务/11项AB结果审查保持原样。本节独立审查随后新增的 `woa-ab-m256range-t240-v1.json`，不把它追记为前序已有结果。

**补充通过，无发布阻断；不推广、不扩大T256的结论准确。** 新case为T240、直接parent=m128range；实际harness SHA为 `6e2025488cfe8ac30089ac35175c4bf8999d6c6f76a6816c00b2499795262ab7`，与独立保存的 ab_probe_m256range.py 相同。实际候选 `2547042f…`、父版 `40978d9a…` 及向上经k128owner2/owner2/phase1的祖先文件和proof SHA全部吻合，没有偷换成流水M128父版。

重新读取160项五边界指标均bit_equal=true、different_elements=0；FULL graph、guards、readonly、pass、complete均true，双generation为1204。12窗×100、无删样，三个arm的min/mean/median/max及全部窗口方向独立重算一致：

| frozen μs | M128-range μs | M256-range μs | 相对直接父版 | 相对冻结 | 父改善窗 / 快过冻结窗 |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 465.517292 | 590.307293 | 532.195797 | -9.844279% | +14.323529% | 12/12 / 0/12 |

probe为96.585677秒；原task.log的TASK_RUN_START/END为20:34:50→20:36:44，脚本窗口114秒，未把两种时长或排队时长混为一谈。

v2收据 `woa-pipeline-run-receipts-v2.tar.gz` SHA为 `6b22c72b94779c6990746f46180c6246775e3eeb53f1bd27a9d39d704d469b50`。逐项核对16个唯一task的最终status与RUNS相同，总计13项exit0、3项exit1；新case归档result与本地JSON相同。归档同时保留v10 Left131072>65536的真实CPU失败，以及v11两根完整lowering通过，未拿失败的stage2 M256作设备资格。

新raw JSON SHA为 `1783f040442a9acfe036e514c636d49c77fde1ff101ac74e6893832d5b5e18e6`。加上原11项，现共12项AB、1920个逐bit指标；所有144个new-vs-frozen paired窗均慢于冻结后缀，没有新增正式接入资格。

REPORT新增单独M256章节，将“同为range的行复用净改善”与“对流水K128或冻结的总体净收益”分开，保留仍慢冻结14.32%及未做四臂直接测量的限制，表格与新raw一致。没有将取消流水的复合变化全部归因于M256，也没有用跨任务绝对值宣称更优。

复现材料的收据版本差异已反馈并修正：REPRO指向最终16任务的v2，发布器同时保留原15任务v1及其原始字节，README区分CPU1…9与CPU1…11。后续正常更新发布包SHA，不改前序raw。无需追加设备即可发布当前“实验有局部收益、但不晋升正式实现”的结论。
