# 尾部 L1 驻留 v7 实际生成物独立审查

## 结论

**通过，无静态阻断。** 本次核对 `generated/woa-pipeline-cpu-v7/{matbase,tailpreload}/ptoas/` 的实际 PTO 与 C++。result.json 记录两根完整编译/Artifact load 成功、16 Tensor ABI、device_execution=false。源身份沿用 TAIL_RESIDENCY_REVIEW.md 的修后 matbase `2bae7369…` 与 tailpreload `0074a416…`。

这只补齐生成物资格；未代替硬件五边界/FULL A/B/A 或性能门禁。审查未运行设备，未改 SDK/候选/正式源码。

## 动态 slice 的实际地址

PTO 保留：

```text
521 = tail_index - 240
522 = 521 * 16
slice_view = subview tail_heads[0,522] sizes[128,16]
```

没有将动态偏移丢成 0。实际 C++ 的 v829 是该 Mat subview，v830 为 `((tail_index-240)*16)*256`，随后 TASSIGN(v829,v830)。常量 256 是 Mat ColMajor/512B fractal 下每逻辑列对应的物理字节步幅；所以 tail=241…255 的地址是 4096、8192、…、61440 B。最后一片 4096 B 到 65536 B 为止，始终在父 64 KiB tile 内。

此处 slice 横跨完整 M128 行，只改变 K 列块，不存在需要保留额外 parent M 步幅而被缩成 M16 的情况。v829 的 valid rows 仍是原 `min(128,rows-row)`，valid col=16。

## 父 L1 存活与 GM 访问

tailpreload 在 tail loop 外有且只有一次 heads K256 TLOAD，目标是 Mat `[0,65536)`，形状 128×256 BF16。loop 内只剩一次 weight TLOAD，目标 Mat `[65536,69632)`，形状 16×128 BF16；未见对父 heads 范围的写入，也未见隐藏的 heads GM 重载或 GM 暂存复制。

PTO/C++ 的 slice 是父 Mat 的同址视图，再 TMOV 到 L0A；**不是所有层次都零拷贝**，L1→L0A 的必要 operand 搬运仍存在。没有额外 L1→GM→L1 路径。

matbase 的 tail loop 则保持每次一个 heads TLOAD、一个 weight TLOAD。两者对比实现了预期的 heads 命令 15→1，而不是两臂实际都用同一个预载入口。

原驻留方案多读未消费的第一个 K16：总 K256 对原 K240，名义字节增加 6.67%。实际 command 数和连续访问改变是否收益仍须实测，不能写成流量减少。

## 权重 NZ reshape 与舍入

K16 weight load 的实际 GM view 是 NZ `Shape<1,8,1,16,16>`、stride `4194304,65536,256,16,1`；原 group、Nblock/16、K/16 五轴索引保持。K256 包对应同一 NZ 结构的 K=16 个 fractal 块。

leading dimension 1 的 reshape 在 PTO/C++ 仅产生同址 Mat descriptor：load 暂存与最终 weight tile 都指向 65536。未生成新的 weight 数据重排拷贝，也没有 BF16/FP32 cast。随后原 K128 EXTRACT 或 K16 TMOV 进入 L0B，权重物理布局与原 NZ load 语义一致。

## MMA 与同步

- matbase/tailpreload 都保留 seed K16 初始化；连续 K256 包在生成物中仍是有序两条 K128 MMA；包内跨端仍是原有序 K16。
- tail loop 仍是 241…255、step1，每次一条 K16 TMATMUL_ACC。C++ tailpreload 全程对 v722 累加，其物理 L0C 地址为 0、128×128 FP32=64 KiB；没有恢复旧 Acc 或新建另一个 Acc 来替代最终值。
- 尾部 L0A 128×16 BF16、L0B 16×128 BF16 各 4 KiB；每侧地址 0，各自属于不同硬件空间，不与 Mat0 或 Acc0 混为同一片物理存储。
- 父 TLOAD 后有 MTE2→MTE1 的完成等待；loop 内 weight load 完成后才 TMOV。M→MTE1 保护上一轮 L0 消费，MTE1→MTE2 保护 weight 槽回用，MTE1→M 保护 MMA 输入准备。
- loop 结束等待最后 MMA/L0 消费后，再经 M→FIX 完成最终 Acc store；父 Mat 在最后一次 TMOV 之前未被下一阶段覆盖。
- 真实行数传播到父 Mat、subview、L0A、Acc 和 GM store；store 只写真实 valid rows。未观察到将物理尾行扩成公开输出，或为驻留新增 GM workspace/根参数。

未发现同步或缓冲 alias 阻断。完整正确性仍必须由新硬件任务验证，不因编译成功推断逐 bit。

## 固定生成物 SHA256

| 对象 | SHA256 |
| --- | --- |
| v7 生成物 archive | 551955339787a46cad41887ef6414b08f88018dc682ce246e1f6413bdf6c2b50 |
| matbase PTO | cf85e81aeaf396eaec3859722dc15dae8573701626d36cf7adcb97ab52302791 |
| matbase C++ | fda1ba19659e75b723100491c548443af9b2e0aae79348abafe13115a26a161f |
| matbase perf_hints | 3a252e46ced9f141e0a0ccd57b555c781712f1796280b37108dd9efe44f291d9 |
| tailpreload PTO | 5e4eef12645680edb6801f9645bec121641906d7cdde8fcc7c5f4e7ff3d9dff3 |
| tailpreload C++ | 46031df658764d160afa1a9f4a04df14adc2e03c1d6c712d1b74ba71cad8e691 |
| tailpreload perf_hints | 7806f17877520dbc69511fe42f6ae5ac539e05e12d66a60eb4913b91a5dcde28 |

后续结果须分别标明 matbase→phase1、tailpreload→matbase 的同任务 paired 比较。此前未通过 lowering 的 v6 仍是失败历史，不得与本份 v7 生成物或后续硬件结果混用。
