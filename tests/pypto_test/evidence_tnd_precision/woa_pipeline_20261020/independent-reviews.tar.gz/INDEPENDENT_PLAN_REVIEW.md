# WO-A搬运/流水实验独立设计审查

## 结论

以phase1八owner版f22d7d8d为唯一新基准，保留冻结PTO为性能/精度控制，分开做最小实验。**优先接受主线程当前路线：T126先外提wrap分支、再独立加流水；T240另做带严格起点gate的K128流水。** 不改Native K次序、MMA分组/舍入、全8192量化及phase1协议。

本审查只读Nal固定beaefa6f、phase1源及已归档生成PTO/hints；做纯CPU序列证明，不编译或运行设备，不修改正式源码/SDK。

## 从Nal能借鉴的内容

Nal NZ WO-A采用M128、K256按递增K流水，N由策略选择128/256，动态group/N/行块所有权；每个逻辑块一份连续accumulator。可借鉴的是连续load/compute循环、减少热循环分支、明确L1驻留与预取。

不能照搬其K起点0、每1024组独立scale、WO-B分组INT32 partial反量化链；本轮也不改变N128或M128/worker所有权，以免同时改变phase1的8-owner证明。N256会涉及相邻N块不同Native K起点、owner/负载与L0容量，不作为本轮最小实验。

## 归档生成物实际说明了什么

已直接读`woa/ptoas/incore_woa.pto`与`perf_hints.log`，不是只看DSL上的stage=2文字。

| 存储空间 | 归档地址/块形状 | 实际占用包络 |
| --- | --- | ---: |
| L1 Mat | 0/65536/131072/196608；M128×K256与K256×N128 BF16，各64KiB | 最大256KiB |
| L0A Left | 0及32768；M128×K128 BF16，各32KiB | 64KiB |
| L0B Right | 0及32768；K128×N128 BF16，各32KiB | 64KiB |
| L0C Acc | 0；M128×N128 FP32 | 64KiB（窄M16为8KiB） |

K256的单次高层matmul在实际PTO中拆为**顺序两条K128**，共用同一Acc。seed先TMATMUL(K128)、再TMATMUL_ACC(K128)；后续packet是两条ACC(K128)。对应证据如PTO行263/264、307/308；低T的v4 packet行816/817同样两条K128。

perf hints的PH-MR-001明确说Left/Right请求外层depth2，每stage32KiB，但只有一个外层buffer可用。原因是一个K256本身已占两个K128 L0槽，外层stage2与内部K分块共同争用64KiB空间。

**不能说整个stage2完全没有流水。** L1确有四个64KiB区域，代表GM→L1双缓冲仍存在；被串行化的是特定L0外层pipeline buffer。提示还来自函数包含的多pipeline分支，不能仅按group编号当作运行次数。

T126实际执行v4 range路径，T≥192的seed_fast才使用当前pipeline2。因此不能把这个stage2提示直接当T126慢的已证原因。完整resident的资源规划也可能不同于隔离woa root；后续候选须读其actual完整生成物，不照搬隔离峰值。

逻辑N128 BF16 innermost=256B的PH001提示只是一条访问粒度线索。权重是NZ，物理分形/stride不是普通ND每行256B，不能由提示断言只有一半cache line有效或每次都走HBM。当前不据此盲目扩大N。

## T126实验A：仅外提K256跨端wrap分支

原v4链严格保持：K16 seed → 15个packet（连续时K256，跨端时16×K16）→ 15个K16 tail。只将packet循环里的if拆成连续before、原wrap、连续after，先都用range；seed/tail/init条件及所有loads/MatMul宽度原样。

令`b0=(first_start+1)%256`。15包中：

- 如果`b0%16==0`，所有包起点均为0/16/…240，**不存在包内跨端**；从240到0只是包间环绕，不能误插16×K16。
- 否则最多一个包的起点>240；其index可写成`min(15,max(0,(240-b0)//16+1))`。值15表示该跨端包不在这15包中。

重点反例：s=15/31/255时无跨端包；s=0时跨端在第15包外；s=240时第一packet为241，跨端index0。检测必须先归一化b0，不能只拿未取模s+1算。

独立CPU穷举s=0..255，before/wrap/after包序与原0..14完全相同，且比较了**MMA宽度+K起点**：连续K256按实际PTO视作2×K128，跨端仍16×K16。只展开成K16 token轨迹相同不够，可能掩盖舍入分组变化。

潜在收益是去掉常规热循环中的条件/分支，利于后续load流水。没有降低名义operand总字节或MMA数量，不能承诺明显加速。先T126三臂(frozen/phase1/hoist)测清楚。

## T126实验B：在A基础上只加before/after pipeline2

如果A编译/精度通过，在A基准上仅把两段连续range改为pipeline(stage=2)，wrap的16×K16仍原range、seed/tail原样。这样可以分别判断分支外提与预取的贡献，不能同时改两个因素后直接称为纯流水收益。

必须在生成物证明：

- K128/K16 MMA与init/acc顺序完全相同，所有路径同一个Acc；
- 两个pipeline片段与中间wrap不产生divergent L0C phi、额外Acc GM spill或复制后丢状态；
- 双buffer地址不同，LOAD→EXTRACT→MMA与跨迭代覆盖的真实event依赖合法；
- PH-MR-001是否仍出现及L1/Left/Right各自哪些缓冲实际并行，不把stage2声明当作成功。

此处仍可能L0不足或遭遇已有SSA/MemoryReuse限制。若失败先保留失败证据、简化现有DSL结构，不改SDK/codegen，不用不精确重算绕过。

## T240独立实验：对齐起点的K128 packet流水

只在原seed_fast已满足全部资格、且`first_start%16==0`时启用新K128路径；不均匀start、高start>240、窄M16/低T路径全部保留旧实现。这是运行资格gate，不是把真实请求padding或改变TND布局。

该gate保证所有原K256 packet起点都是16的倍数且≤240，不会执行包内16×K16 wrap。原16个K256（含seed）实际恰为32条K128，顺序起点是：

```text
K128块 j: ((s + 8*j) % 256)*16, j=0..31
j0为TMATMUL初始化，其后31条均为TMATMUL_ACC
```

独立CPU验证s=0,16,…240：原实际PTO两条K128/包展开序列与新32包序列逐项相同，包括seed init/acc属性。因此gate加上primitive序列证明足够支持源级等价方向；最终还需actual新PTO/ISA和硬件逐位验证。

**不能去掉gate就泛化。** 对未对齐s，原K256跨端分支是16×K16；直接把它改成两个K128可能保持元素顺序却改变MMA分组/舍入。若未来要扩大，必须保留原wrap分组，另立证明和门禁。

K128名义资源：每stage A/B各32KiB，L1双缓冲共128KiB；L0每侧两份32KiB共64KiB；Acc仍64KiB。它可能避开“外层depth2×内层2块”的L0重订阅。实际allocator是否仍因其它共存值退为1、GM load命令变多是否抵消收益，必须看新生成物和性能。

### 可选最小控制

若需判断现有K256 stage2净作用，可另只将seed_fast pipeline2改range，数学和packet完全不变。这是比改K宽更小的控制，但当前已有T126 A/B及T240 K128路线，不必额外提交；只在结果难解释时考虑，避免增加无依据实验。

## 共同验证门禁

1. 冻结phase1 f22d为parent；只读收据证明Nal参考、PyPTO2dfa/Simpler57e/ISA327/PTOAS wheel身份。不以旧环境或别任务parent绝对值排名。
2. CPU全s=0..255/全T1..256/实际calibration与非均匀start回退：逐row/N块有效写入唯一覆盖，MMA宽度/K起点/init类型逐项一致，尾行保留valid_shape，所有其它数学/phase1获取与publish AST原样。
3. 完整CPU GCC/PTOAS/CCEC及actual资源/event/别名review，不仅编译孤立helper。记录fallback与新路径实际触发计数或可审计条件，不能跑到旧分支后误称优化已执行。
4. 原真实L4五边界、eager/FULL A/B/A、整数反码/NaN poison、readonly、所有scratch/signal guard、双generation、首差停止全部保留。必要forced start用旧PTO/parent作该同序gold，并清楚区分人工顺序与Native校准顺序；恢复真实表后再做正式门禁。
5. 无插桩同任务12×100位置平衡、全部paired窗；DFX/PMU分开。先T126或T240目标档，稳定后才扩其它档，每任务≤15分钟。
6. 候选须先快过同任务冻结后缀，且精度不回退，再考虑完整CSA集成/zero成本和8K、128K整模型token。仅比慢resident快不足以晋升。

## 当前证据身份

- `suffix-diagnosis-20261020/candidate-phase1.py`：`f22d7d8dd6ef2a48f640b88511c6c32c672ade0b116fa922f18c6a6a23237fe6`
- `vllm_ascend/ops/pypto/deepseek_v4_flash_csa_spmd/output_projection_a_stages.py`：`0875df14c79482242bf00a665006ac8e30e98c91a3f50650d75d6cec9843b739`
- `suffix-diagnosis-20261020/suffix-stage-cpu-v1-evidence.tar.gz`：`8e13b1f1deef8a169567974553fdc34b1513ee5ac8fb2918073b419466f82365`
- 包内`incore_woa.pto`：`25951ced7cd7b71677f47366ed09e6368585e90337bac5ebc3e504440942a438`
- 包内`perf_hints.log`：`2f9caefc1017805d8ab7270125ec5baa0d0a227d7db8c7cfe59561b3c60c1ba5`
