# phase2 八 cast-owner 获取方案独立设计审查

## 结论

**设计合理，CPU 依赖枚举通过，可作为 phase1 基线上的独立单因素。** 本文只评审设计，未生成候选、未运行设备，也不赋予实际实现/编译/收益资格。不与 K128 组合初测是正确的控制方式。

只改变 quant 之前的 phase2 获取集合，不改变任何投影、BF16 cast、全 8192 amax/量化、token_scale 或其它数学和 publish；无需 SDK 改动。必须保持真实 TND，不按每请求 S6 补齐。

## 依赖推导

当前 cast 的实际分配为：

```text
cast_block = cast_worker + 48*k
rb = cast_block//8                 # 一个块16行
group = cast_block%8               # 一组1024列
cast_owner = (8*rb+group)%48
```

当前 quant 每个块处理 8 行，但按全部 8 个 group 顺序计算共同 amax、共同 scale，然后统一量化。T≤256 时 `quant_rows=ceil(T/8)≤32<48`，因此活跃 quant worker 恰好处理一个块 q=worker，不存在第二轮 `worker+48*k`。

第 q 块的 8 行永不跨 16 行 rb 边界：rb=q//2，其所需全部 8192 列的 producer 集合正好是：

```text
owner[g] = (8*(worker//2)+g)%48, g=0…7
```

这 8 个 owner 不重复。每个 producer 在其全部 cast 工作完成后才 publish phase2，因此一次等待能保守覆盖本块所需行；不是细化成逐行完成信号。两个相邻 quant worker 共享同一个 rb，因此等待同一组 8 个 owner，读取互不相交的上下两个 8 行区域。

## 独立 CPU 枚举

使用本机 `.venv311/bin/python`，从实际 cast 的 `block%48` 归属及 quant 实际读取的每行反向构建 owner 集合，再与提案公式比较。遍历 T=1…256、全部 48 个逻辑 AIV：

- 12288 个 consumer 场景全部相等；
- 共 33792 条实际 cast→quant 依赖；
- 每个活跃 quant worker 恰需 8 个 owner；无 quant 工作的 worker 需要 0 个；
- 所有 owner 都有本 rb 的实际有效 producer；尾部只取真实行，仍不跨 rb；
- signal 地址均在原 phase2 代际区域内。

| T | 活跃 quant worker | cast 块数 | 原全体 wait 调用数 | 新必要 wait 调用数 |
| --- | ---: | ---: | ---: | ---: |
| 6 | 1 | 8 | 2304 | 8 |
| 18 | 3 | 16 | 2304 | 24 |
| 126 | 16 | 64 | 2304 | 128 |
| 240 | 30 | 120 | 2304 | 240 |
| 256 | 32 | 128 | 2304 | 256 |

wait 数是源码协议调用数，不是未满足轮询次数、DDR transaction 数或可直接折算的耗时。不能把减少的调用乘微基准单次成本后当作性能结论。

## 最小实现约束

先在 vector 中绑定 `quant_rows=(rows+7)//8`，再仅对 `worker<quant_rows` 等待上述 8 个 owner，最后保留原 acquire 的 `fence/cacheinvalid/fence`。原 quant loop 和所有数学语句不动。

owner 公式产生的是 **0…47 的逻辑 AIV 编号**。真实 signal core 为 24+owner，因此地址必须使用：

```text
(2*CORES + 24 + owner)*STRIDE
```

不能误用 phase1 的 AIC 地址 `(CORES+owner)*STRIDE`，也不能漏掉 core 的 24 偏移。位于本 worker 自己的 owner 也要按同一协议等待，不需要特殊绕过；自身 phase2 publish 已在获取之前发生。

**48 个 worker 的 publish2、publish3 都必须原样保留。** 无 quant 的 worker 仍可能有 cast：例如 T240 的 worker32…47 虽不量化，却会生产某些 rb/group 的 projected 数据，活跃 quant 可能必须等它们的 phase2。不能把 producer publish 也误包进 quant-active 条件。其空 quant 的 publish3 依然是 Cube 原 phase3 全集合等待的一部分。

## 内存可见性与无死锁

producer 的 publish2 原 bar/fence/cache 维护不可省，consumer 最后一个必要 signal 后仍 acquire payload。无 quant 核可以跳获取及其 acquire，因为该阶段没有 projected 读取；publish3 自身的维护和代际仍保留。

projected 的每个 rb/group 由唯一 cast owner 写入。本调用后续没有其它阶段回写 projected；提前读取自身已就绪行不影响仍在写其它行/group 的 producer。group 的 1024 BF16 列为 2048B、每行8192 BF16为16KiB，所需有效块与无关 cast 不重叠。

token_scale 的 8 行块为32B，quantized 的每块为64KiB。该输出粒度和所有 store 均原样，不引入新地址重叠；但 quant 完成时序变了，仍须真实硬件守卫/位比较确认既有 MTE3 与 cache 维护协议，不用纯数学证明替代硬件可见性检查。

DAG 仍为 AIC WOA→phase1→cast→phase2→quant→phase3→AIC WOB→phase4→dequant。AIC 发布 phase1 不依赖 quant，全部 cast producer 在等待 phase2 前已完成自己的发布，所以没有新增反向等待环。相邻 graph 调用仍须顺序独占 workspace/signals；phase2 不能作为上一代 consumer 已读完的 ACK。

## 可以与不可以据此推断的性能机制

该方案可能减少无关 cast owner 的等待、重复 signal 读取和消费者提前忙等的争用；也可能让不同 rb 的 quant 与尚未结束的其它 rb cast 重叠。收益大小需要实测。

在当前 phase1 八 AIC owner 协议下，每个 quant 所需 8 个 cast group 的 phase1 AIC 依赖并集仍是 **全部24 AIC**。独立 CPU 枚举对此也全部通过。因此，任何 quant 真正开始之前仍须全部 WO-A producer 发布 phase1；**不能将此优化宣称为让 quant 与尚未完成的 WO-A 计算重叠。** 可能变化的是后面的 cast/quant 排程及轮询干扰。

早起的 quant 也会与无关 cast 争用 GM/L2/MTE、执行不同 cache 维护；不保证删除 wait 一定加速，更不能预先唯一归因于 signal DDR 热点。需要同任务冻结/phase1/new 位置平衡窗口和独立 DFX 佐证。

## 后续门禁

1. 对实际候选 AST 核只替换 phase2 获取块，phase1/全部数学/publish2、publish3 完全保留。
2. 无设备完整 compile/Artifact load 后，核实际 signal 地址、acquire、active 条件、8 次循环及 producer store→publish 顺序。
3. 独立单因素先 T126，再 T240；保持真实 L4、五边界逐 bit、FULL A/B/A、poison、只读/guard、双代际、12×100 交替无插桩计时，首差停，每任务<15分钟。
4. DFX/PMU 与正式延迟分开，不相减 isolated 阶段来冒认纯等待；先比较同任务 phase1→new 的净效果，再看是否快于 frozen。
5. 即使本项有效，也不把它与不同任务 K128 收益相加。只有单因素通过后才考虑组合增量测试，完整 CSA/整模型资格另验。
