# 下一轮驻留及 owner2 增量候选独立审查

## 结论

- **tailowner2、k128owner2：源级组合、三臂 harness 及 v9 实际生成物审查通过。** 不继承其它 root 的设备资格，硬件精度/性能另验。
- **tailboth：初审的 Mat 行切片步幅风险已由 v9 实际 TEXTRACT 消除，无静态上卡阻断。** 编译器直接从完整父 Mat 提取到 Right，没有压缩子 Mat 步幅。下文保留原风险推导和实际解除证据，不把逻辑地址证明冒认为物理证明。

本审查只读，没有改候选/SDK、没有提交设备，也没有审计本轮 PMU 原始 CSV。当前报告不将前序单因素百分比相加预测组合效果。

## 绑定实际源

| 对象 | SHA256 |
| --- | --- |
| owner2 | 399dbc67a1709a5e2fda636afb245d6e6478a5f1cec20763471caae6fd98e54b |
| tailpreload | 0074a416b54dcbb1b779b8f852814c04f16e42dd9aac9fb650d566f9f3204a90 |
| k128narrow | b5ee93a611e8774dab5b18338af6e74dbf25c43a81491f372f0ea5e9d64128ea |
| tailboth | fdbcb04191e1b62cdb7f69bba4d4e7b115d7c878c276ab3f655644df3a162389 |
| tailowner2 | f4baff8954e941a5d0bfe95f3a0744755835c80c17c926a60aa28afaa89c5805 |
| k128owner2 | b215fe84554ac35ea12e85dfa22846840bcba386cec43c074aa170052b5897a5 |
| ab_probe_v3.py | 4913fbebc48707c24810a7887627514bec92d00efccf86ca1bb9b98c8b6f85ed |
| run-v3.sh | f02cc45d523b531e91fefdd7f85be1ee885a43f12edb43eb74154c950b88fdf2 |
| prepare_next.py | 3ca6b1ec1dceb41fa61a664a3be0cb8fa92922e057134f10a594b7ac900a35fb |

JSON 的实际文件 SHA 与 parent_sha256 独立核对相符。formal reference 仍是 48c58ce7c，未安装正式路径。

## 两个增量组合的精确范围

实际 AST 比较通过：

```text
tailowner2.cube == tailpreload.cube
k128owner2.cube == k128narrow.cube
tailowner2.vector == k128owner2.vector == owner2.vector
tailboth.vector == phase1.vector
```

因此组合没有重新书写 WO-A/WO-B/量化数学。owner2 仍只在 quant-active worker 获取 phase2 八个必要 cast producer，所有 phase2/3 发布、cache 获取、全8192统一量化及后续流程原样。

tailowner2 相对 owner2 加入的是**整个已验证显式 Mat+heads 尾预载实现**，不是仅孤立新增一次 load；其中包含 matbase 形式和 aligned eligibility。该综合增量需要对 owner2 直接测净收益。不能用 tailpreload 对 matbase 的约10%来预测组合，也不能忽略 matbase 对 phase1 的回退。

k128owner2 相对 owner2 加入已测 K128 的高 T 资格与搬运方式；低 T 保留原路径，未对齐起点仍使用原 M16 fallback。owner2 改变执行时序/资源干扰，可能与 K128 有非线性交互，所以不能把两个不同任务的改善百分比相加。

## tailboth 逻辑正确性与布局风险

新增 weight 预载为 `[1,256,128]→[256,128]`，其 K 起点和 heads 相同：`base=(s+240)%256*16`。对齐 s 下 base≤3840，完整 K256 在 group 的 K4096 内；每个 tail 的 K16 offset 为 `(i-240)*16`。独立枚举全部16个对齐 s 与 i=241…255，预载局部逻辑行与原 weight K16 load 地址逐项一致。

weight 的每次数学消费仍是一条原 K16 MMA，没有增加 cast 或改变累加次序。从逻辑窗口看该方案成立。

**初审时指出的物理风险：逻辑窗口不能直接证明布局。** 父 weights Mat 是 ColMajor/512B fractal 的 `[256,128]`，新的子 view 是 `[16,128]`，裁掉的是父 K 行维；这与 v7 已验收 heads 保留完整 M128、只裁 K 列的 slice 不同。

原 NZ/Mat 的相邻 N16 块跨完整 K256：物理步幅8192B。若后端只给子 Tile `[16,128]` 换 base 并 TMOV，子类型的相邻 N16 块步幅会变成512B。例如 tail 第一片 row offset16，在 N16 块1应读取8192+512=8704B，压缩的子描述符却可能读取512+512=1024B，导致读错权重。对齐及不越界检查不能排除这个错误；编译成功也不自动排除。

因此 v9 必须具有下列一种实际实现；本次实际观察到第2种：

1. 正确保留父 Mat 物理 N 步幅的 slice；或
2. 从完整父 Mat 用正确 row offset 提取/重排到独立 L0B，且保留原15条K16 MMA。

若生成物只见 `subview→Tile<Mat,16,128> + TASSIGN(base+offset)→TMOV` 且无父步幅或正确提取，应判为阻断。**本次没有出现该错误模式。**

初审曾建议必要时使用现有 `pl.tile.extract(...,target_memory=Right)`；实际无需修改源码或 SDK，编译器已将当前 slice+matmul 自动折叠成同一类正确 TEXTRACT。

## 资源与同步检查项

tailboth 两个驻留父 Mat 各64KiB，不能互相覆盖；weights row-slice 若还要独立 carrier，必须按实际生成物核峰值。heads 和 weights 整个15次循环都存活，loop内不得因复用旧 weight slot 覆写父 weights。Acc 仍64KiB L0C，最后 store 的有效行必须是真 T。

tailowner2/k128owner2 组合仅改变现有 producer/consumer 的等待时序，但也应检查完整新 root 生成物是否保持两模块已验收的 L1/L0 地址及 fence、信号 core/phase 偏移、所有发布点。不能仅拼装 source AST 后免去完整编译。

## AB v3 身份与门禁

CLI 固定：tailboth→tailpreload；tailowner2/k128owner2→owner2。前两者 16<T<192，K128组合192≤T≤256。实际 parent 模块从对应文件导入并注册。

新增祖先链逐层检查 candidate 实际 SHA、parent 文件 SHA与 parent_sha256，最终必须到硬 pin 的 phase1，再接原 a31→冻结 source proof；长度上限防止循环祖先无止境。candidate 的 parent/parent_sha256 另与实际选中父臂匹配，报告保留 comparison_parent_lineage。没有把 tailboth 的 parent 错写成 phase1。

与 v2 的 diff 只涉及新CLI与祖先链，执行、五边界逐 bit/finite、首差停、eager/FULL A/B/A、poison、只读与所有 guard、双 generation、12×100 rotate/reverse 无插桩计时均保留。工作区仍每臂独立，accum=T+127、integer=T+63，不需要为本轮 WO-A 驻留引入 WO-B M128 容量。

计时中的 resident 键随任务分别表示 tailpreload 或 owner2；统计必须读取 comparison_parent，不能统一贴 phase1/a31 标签。frozen 是共同控制，仍是已验收冻结 PTO 金值；这不是本次直接 Native 整层或整模型验证。

## v9 实际生成物续审

`generated/woa-pipeline-cpu-v9/result.json` 三项均 pass=true、lowering=true、skip_ptoas=false、device_execution=false，各根16 Tensor ABI，记录完整编译与 Artifact load。未运行本报告设备。

### tailboth 步幅、存活与累加

- PTO 的 tail weights load/reshape 保留完整 `[256,128]` Mat，地址65536；heads 父 Mat `[128,256]` 地址0。两者各64KiB，地址不重叠，整个15次循环均未被其它 GM load 覆写。
- weight 没有产生压缩 `[16,128]` Mat subview。PTO 直接 `textract(full_weights, (tail-240)*16, 0)` 到独立 Right `[16,128]`。
- C++ 的完整父 v837 是 `Tile<Mat,bfloat16,256,128,ColMajor>`，地址65536；动态 v842 为 `(tail-240)*16`，然后 `TEXTRACT(v845,v837,v842,0)`。原父 K256 的 N16 物理步幅由完整 descriptor 保留，已排除初审8704B/1024B错误取址风险。
- 原 heads 子 view 动态列16…240仍保留；L1→L0A TMOV 与 weight TEXTRACT 都是必要 operand 搬运，没有新 GM copy、没有新增 cast/数值舍入。
- 每次一条原 K16 MMA，顺序241…255、step1。Acc C++ v722 始终物理L0C0，尾部结束后才最终 store；valid rows 保留原真实 T。
- L0A/Right各4KiB、L0C64KiB；父load完成后有MTE2→MTE1等待，Right/Left复用前有M→MTE1等待，每次MTE1准备完成才MMA。末迭代drain后M→FIX再store。未发现提前覆盖或跨phase逃逸。

### 两个组合的物理数学等价

独立提取实际 PTO 的 cube/vector 函数，移除仅源文件定位 loc 后，对 SSA 标识符按首次出现顺序作双射归一化；**所有常量数值、类型、物理地址、layout、控制结构及指令顺序都保留比较**。结果：

```text
v9 tailowner2.cube == v7 tailpreload.cube
v9 k128owner2.cube == v5 k128narrow.cube
v9 tailowner2.vector == v9 k128owner2.vector
```

因而两个组合没有在 lowering 中夹带新的加法树、MMA宽度/顺序、Acc地址或Cube缓冲变化。相应v7尾heads生命周期、v5 K128双buffer/fence结论可按实际PTO等价复用；不是只靠源代码标签。

实际 vector 的 phase2 gate 为 worker<ceil(T/8)，8次signal地址为 `21504+128*owner`，即 `(2*72+24+owner)*128`，随后原fence/cacheinvalid/fence。所有phase2/3 publish在gate之外，quant仍顺序读取8组1024列、统一scale。两组合只有各自Cube搬运方案不同，owner2同步实现相同。

### 实际生成物 SHA256

| 对象 | SHA256 |
| --- | --- |
| tailboth PTO | 3b7408009caa818f972577fa4d5d92c62ed91aba7eca577e00b2c36953bf984d |
| tailboth C++ | a17557c77903100ec0c3932bd1532327ebc1db03ab9377b3025505afd795f4f1 |
| tailowner2 PTO | 51822425dacd3448dcdd4b9ba6d1e01e480f8a145657002ca242cc847bc2ab8c |
| tailowner2 C++ | 872b4eac4b3459c69b42467476dc7b20a4ae3d5b5361a6dbb7300a0e2295bc28 |
| k128owner2 PTO | ba9208ca8533f2fd8d1f5781fe721084c1233e310c436ab4a7cc576c5609d1aa |
| k128owner2 C++ | 2e95e8f79c4db37df17b5846bde1b597072342baf48741cb818dd808bb5c627b |

## 验收与选择

三项 v9 编译与本次生成物审查通过，tailboth布局风险已解除；硬件仍按单个目标T独立门禁，五边界首差停止。本报告不把编译通过或前序不同root的硬件结果写成当前候选已逐bit通过。

tailboth 判定 weight 驻留相对 heads 驻留的净效果；tailowner2/k128owner2 判定在 owner2 上增加对应搬运实现的净效果。只保留各自同任务中稳定收益的增量；即使组合比最初 a31 快，也不足以证明应保留比 owner2 更慢的成分。快过 frozen 之前，不晋升完整 CSA/整模型。
