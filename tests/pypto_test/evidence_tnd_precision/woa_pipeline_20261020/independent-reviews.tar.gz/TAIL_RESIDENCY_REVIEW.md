# 低 T WO-A 尾部 L1 驻留独立审查

## 状态与已修正阻断

**修正后的当前 v7 源码及独立 harness 源级通过；实际 lowering/资源及设备门禁待完成。** 本审查不提交设备、不改候选或 SDK。

初读发现并通知主线程：v6 的转换器把 `pl.slice(heads,shape,offsets)` 直接改名为 load，未交换后两个参数；实际 SDK 的签名是 `load(tensor,offsets,shapes,...)`，会导致错误 tile shape/地址。主线程同时在 CPU v6 定位并修正，保留失败版，未上卡。下面仅审交换参数后的版本，不将旧版失败包装成测试通过。

| 对象 | 当前 SHA256 |
| --- | --- |
| parent-phase1.py | f22d7d8dd6ef2a48f640b88511c6c32c672ade0b116fa922f18c6a6a23237fe6 |
| candidate-matbase.py | 2bae73692bd7eb62d2b0362438aa84264f35be431c2c2d0946c662149e402195 |
| candidate-tailpreload.py | 0074a416b54dcbb1b779b8f852814c04f16e42dd9aac9fb650d566f9f3204a90 |
| prepare_tail.py | 81e0307f710b5e52ca3bc73bf27acd68cd7738c925262dd104e2d85be271c1d0 |
| ab_probe_v2.py | 403a6921cad50b9ace583c041d01edc512c68fa76e2441f8844e5994cd235618 |
| run-v2.sh | c25da32bfc9b15bbf83ea9dcfbb229260f445b6551144bedd6d36debca95fd00 |

## 两个因素的分离

matbase 只在原低 T 的同起点 wide 分支显式使用 Mat load、权重 `[1,K,128]→[K,128]` reshape、末端 store，并增加起点 16 对齐资格；没有改变 seed K16、15 个 K256 包的分支/包内 K16 wrap、15 个 K16 tail 或 FP32 Acc 顺序。未对齐起点复用原 M16 fallback，不能称作保留原 M128 路径。

tailpreload 的父臂明确是 matbase：除尾部 heads 的一次 K256 load 及 15 个 tile.slice 外，权重 load、每个 MMA 的宽度/次序、Acc 和最终 store 都沿用 matbase。这样先测显式 Mat 控制因素，再测驻留净作用，不把二者打包后都归因于复用。

T126 冻结标定表的有效起点都是 0/32/…/224，且每个 group/Nblock 在行间相同，能实际触发两个新分支；此表事实不等于所有人工起点硬件覆盖。高 T 路径与非 cube 函数仍原样；真实 TND 布局没有变成每请求 S6 padding。

## 地址、valid rows 与逐行运算

以实际候选 AST 提取 `v4_same_start==1` 的语句执行，替身记录 heads/weight 的逻辑地址、形状、matmul init/acc 与 GM store，不依赖生成器自己的地址证明。遍历：

- 16 个对齐起点 0…240；
- valid rows 的全部 1…128；
- group=0 与 group=7、Nblock 最后一块 col=896。

共 4096 组实际 AST 路径，parent、修后 matbase、tailpreload 的每次 MMA 输入逻辑地址/宽度/init 累加次序与唯一输出 store 都相同。权重 load 的 leading dimension 1 仅 reshape 为二维，无 cast、无重排求和、无额外数值舍入。当前 load 的 offsets/shapes 顺序均正确。

令 s 为对齐后的起点。`base=(s+240)%256` 一定不大于 240，故整 K256 heads load 不跨本组 K=4096 边界。tail i=241…255 的本地偏移为 `(i-240)*16`，范围 16…240，且偏移+16≤256。原地址 `(s+i)%256*16` 与 `base*16+offset` 完全相同。

尾部父 Mat tile 的 valid rows 与每个子 tile 都显式使用原 `v4_wide_valid=min(128,rows-row)`；slice 的列有效范围完整。未扩大有效行，也未改变最后 Acc store 的有效行。子 tile 不发生 FP32/BF16 cast，因而驻留本身没有新增数值舍入边界。

## 仍须实际生成物确认的事项

源级相同不等于后端一定按期望保留 Mat residency。编译就绪后至少检查：

1. tails 之前恰一次 `[valid_rows,256]` heads GM→L1 load；tail loop 不再生成 15 次 heads GM load。
2. `tile.slice` 的动态列偏移没有丢失；实际 K16 EXTRACT/slice 来源是父 K256 tile 的列 16、32、…、240，不能全退成列 0。此前相邻实验曾出现 tile view 偏移丢失，应按生成物核实而非仅靠 CPU 地址证明。
3. NZ 权重 `[1,K,128]→[K,128]` 的实际 load/reshape 仍对应原 group/K/N 顺序；检查真实 NZ 分区索引、layout 与 EXTRACT，不能把普通 ND flatten 假定到 NZ。
4. resident heads 为 128×256 BF16，即 64 KiB L1；每个 K16 weight 为 16×128 BF16，即 4 KiB。父 heads 在整个 15 次循环都活着，必须与循环 weight 及其它 co-live carrier 不重叠；若 allocator 复制 slice 或发生布局转换，需据实记录，不提前声称零拷贝。
5. 15 次 K16 MMA 必须仍逐条累加同一个 FP32 Acc，不能自动合并为新 K256、换求和树，或在 store 前恢复旧 Acc。真实 valid rows、consumer 完成后的 L1 回用 fence 同样要核。

这项首先减少的是 **GM load 命令/调度次数**，不是减少请求字节：原 15 个 K16 heads 共 K240，新 K256 多读一个未消费的 K16，名义数据量增加 1/15≈6.67%。它可能受益于连续载入/复用，但不能先称为带宽量下降；最终看 matbase→tailpreload 的同任务实测。

## harness 与可解释性

ab_probe_v2 另存，不修改已排队 v5 的 ab_probe。CLI 强制 matbase→phase1、tailpreload→matbase，16<T<192。实际 parent 文件由参数选取并检查 SHA，candidate proof 的 parent 与 parent_sha256 一起绑定，tailpreload 不会悄悄对到 phase1。

与已审 ab_probe 相比，仅新增两个 variant、matbase parent 选项与文件路径选择；五边界逐 bit/finite、首差停、FULL A/B/A、NaN/反码 poison、只读与外围 guard、双 generation、12×100 轮换计时均未改。run-v2 实际执行 ab_probe_v2，并保留 timeout750s 和任务起止记录。

五边界金值仍是冻结 PTO O-proj+HC-post，输入为真实 L4 权重与合成 heads/residual；不是本次直接 Native 整层、真实请求混合长度或整模型 token 验证。需先过 matbase 自身精度控制，再对拍 tailpreload；后者若不稳定收益，不保留驻留改动。

截至本报告，仅已完成源级独立检查。新版本的完整 CPU 编译/实际生成物与硬件结果不能从 v5 的结果继承。
