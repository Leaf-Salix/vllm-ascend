# WO-A 三候选与三臂对拍独立审查

## 结论与版本

**当前 v4 源码和 harness 源级审查通过，无阻断。** 可以继续完整无设备编译及生成物审查；这不等于已经通过设备精度或性能门禁。本审查未运行 NPU、未改候选/SDK/正式运行源码。

本次审的是 `CHECK_HISTORY.md` 第 4 项之后的实际文件：split 使用零次/16 次 wrap 循环，K128 在两个分支内部各自 assemble。不是此前的条件 Acc 合并失败版本。

| 文件 | SHA256 |
| --- | --- |
| parent-phase1.py | f22d7d8dd6ef2a48f640b88511c6c32c672ade0b116fa922f18c6a6a23237fe6 |
| candidate-split.py | 54ac8282ab9e36f7f226a41f945183d4b2e1518a0e5b99a1a82c17e7970e9783 |
| candidate-pipeline.py | d0869eace3d448db749f6dd4eae99d561273d6eead0561db1ebbbc9cc8a5e03a |
| candidate-k128.py | 05f271067543f9cb6fbdfca40bd9d0a584eb8bbcdae1287b22229bc88b3ea280 |
| ab_probe.py | 4bdc91fe7a3518c779b99885727943ccba9ad06e86696f7a83e0cbd806a827fa |
| run-ab.sh | 49bed4e9b845a1403d5a336fcc95b23f37adb72b7ad659b7d587f2e87cd12dcf |
| prepare_candidates.py | 41422ef27866e718b2b02a5250c2b3e7f8e6e38bde588a0effd2c716f250fbdb |
| check_candidates.py | 63ad4c505d08cec033fc48c66e5f2297d54be0810628e4037ec12ed9d3e16c91 |

## 独立检查方法与结果

没有仅复述生成器的 `TRACE_PROOF.json`。以本机 `.venv311/bin/python` 解析四份实际源 AST，提取原/新 `v4_same_start == 1` 与 `seed_same_start == 1` 的真实语句；使用只记录 slice、matmul/acc、assemble 的替身执行这些 AST。pl.range 与 pl.pipeline 在该 CPU 检查中只表达相同的顺序迭代，不能证明流水后端调度。

- 低 T：全部 256 个起点，各测 valid rows 为 1、15、16、17、48、63、64、127、128。split/pipeline 与 parent 的每条 `(init/acc, K 起点, K 宽度)` 完全相同；每行总 K=4096，所有 load 均在本组 4096 K 内，每条路径恰一次 GM assemble。
- 高 T：全部 241 个允许进入旧 wide 路径的起点 0…240，及上述 9 种尾行大小。未对齐起点的 K128 候选逐条保留旧源宽度/顺序；16 对齐起点与原 K256 依实际旧 PTO 拆成两个 K128 后逐条一致。
- 对四个模块做 AST 比较：除 cube 外所有函数、常量与公开入口完全相同。split/pipeline 的高 T 分支与 parent 一致；K128 的低 T 分支与 parent 一致；各候选 WO-A 分支之后的 WO-B 与所有同步代码一致。
- 将 pipeline 两个迭代器的 `pl.pipeline(..., stage=2)` 恢复成 pl.range 后，整个模块 AST 与 split 相同，未夹带别的数学修改。

这些结果证明源级地址、MMA 分组和累加顺序的意图正确，不证明新生成物没有改变 MMA 切分或发生 L0C/事件错误。

## split 与 pipeline 的边界

令 `base=(s+1)%256`。base 可被 16 整除时，原 15 个 K256 包不会发生包内跨端，`pre_count=15`；跨端只可能发生在包与包之间。因此当前 wrap 循环次数为零，post 循环也为零，正确保留原 K256 分组。

其它余数时，pre_count 为跨端包之前的完整包数，范围 0…15。若小于 15，wrap_base=`240+base%16` 正是唯一跨端包起点：以原 16 个 K16 处理；其后 `max(0,14-pre_count)` 个 K256 从 `base%16` 接续。不会把跨端 K16 组合成新的 K256，也没有改变 seed K16 与 tail 15 个 K16。

v4 通过零次数循环避免原条件 Acc phi，但零次循环的 loop-carried Acc 仍须在实际生成物确认。pipeline 的两个连续片段还必须核对真实 L1/L0 双缓冲、LOAD/EXTRACT/MMA 顺序与覆盖 fence；stage=2 文本本身不是生效证据。

## K128 资格与资源风险

新路径同时受原 rows≥192、每个有效 M16 子块起点相同、first_start≤240 以及新增 first_start%16==0 约束；原 unequal/high-start fallback 没有放开。低 T 全部原样。

在该资格内，原 16 个 K256 包不会包内跨端，旧实际 PTO 每包为两个顺序 K128。新路径为首个 K128 matmul、随后 31 个 K128 matmul_acc，起点 `((s+8*j)%256)*16`，正好保持该 primitive 序列。未对齐起点保留原路径，避免把原 16×K16 wrap 偷换为 K128。

当前 v4 两个分支分别 assemble，Acc 不再在 Python 源级逃出分支；仍须实际 MemoryReuse、PTOAS/CCEC、Acc 有效形状和 GM store 检查。K128 下每侧 L0 双份 128×128 BF16 合计 64 KiB，Acc 128×128 FP32 为 64 KiB；是否存在额外同存 carrier 或 allocator 降级，不能凭容量估算判定。

只读解析冻结正式起点表：T126、T240 的有效起点集合都是 0/32/64/96/128/160/192/224，64 个 group/Nblock 在有效 M16 行间全部相同。因此 T126 应实际进入 split/pipeline wide 路径，T240 应实际进入新增 aligned K128 路径；不是默认跑回旧分支。该结论限定当前冻结标定表，不赋予所有人工起点硬件资格。

## harness 身份与比较公平性

显式比较关系正确：split→phase1，pipeline→split，K128→phase1；CLI 对不匹配组合直接拒绝。parent 实际 Python 模块从对应文件路径导入，再注册其 resident_suffix，不是仅更改报告标签。

身份链同时核对 phase1 实际 SHA 的硬 pin、phase1→a31 原数学 proof、parent 实际 SHA、candidate 实际 SHA及 candidate.parent/parent_sha256。冻结 O-proj/HC-post 的实际 import 路径和 SHA 也核对。报告保留 comparison_parent，后续汇总必须读取它，不能把所有 resident 键统一叫 a31 或 phase1。

三臂为 frozen / 显式 parent / new，各自五输出、accum、integer、signal 独立，16 个工作区/输出地址唯一性断言保留。WO-A 只改搬运，parent/new integer 均为 T+63，accum 均为 T+127；无需随 WO-A 增加 WO-B M128 容量。M128 WO-A 最大物理尾容量由 T+127 兜住，公开输出仍真实 T。source flat 与 TND 请求布局均未改变。

本 harness 使用真实 L4 权重与合成 heads/residual，冻结 PTO 为金值；它没有直接执行 Native O-proj。因此可宣称“相对已验收冻结数学五边界逐 bit”，不能将本次单任务扩写成新的 Native 整层或整模型资格。

## 精度与计时门禁

与上一轮已审 ab_probe 的 diff 只涉及参数/实际 parent 绑定、相应 proof 路径和不再需要的 M128 integer 配置；执行、比较、graph、事件、代际与窗口循环未弱化。

- 保留 eager、FULL A/B/A，NaN/整数逐元素反码 poison，五边界 finite+逐 bit，首差停，恢复 A 的实际输出检查。
- scratch/signal 外围 guard、只读权重/起点/residual/post/comb、heads 恢复 SHA、used/unused signal 槽与双代际检查保留。
- 同一 stream 捕获/回放及事件计时，12 窗×100，三臂 rotate/reverse 每个位置均衡，无 DFX/PMU，全部样本保留。检查在事件区间之外。
- generation 每窗两常驻臂各 +100，compare 要求两臂代际相等；正常终值应为 1204。不是只比较静态首次输出。
- run-ab 使用当前独立 SDK/PTOAS 与私有 OPP 根，内层 timeout750s；外层 task 上限仍由提交命令保证，不能仅凭本脚本声称已设 780s。

当前强门禁仅使用真实起点表；人工不均匀/非对齐/高起点是 CPU 源级覆盖，不应在后续报告写成新增硬件覆盖。

## 晋升条件

完整无设备编译通过后，先看实际 MMA 宽度/累加顺序、有效尾行、Acc owner、L1/L0 资源与跨迭代 fence，再按目标 T 逐任务硬件对拍。pipeline 的净作用须对 split 统计；K128 须对 phase1 统计；同时保留 frozen 控制。不要从跨任务绝对延迟拼出两个优化的组合收益。

精度与 12 窗同任务收益均成立、且新后缀快过 frozen 后，才讨论完整 CSA 接入及后续整模型验证。本审查没有提前认定收益、没有建议修改 SDK 或以 S6 padding 换效率。
