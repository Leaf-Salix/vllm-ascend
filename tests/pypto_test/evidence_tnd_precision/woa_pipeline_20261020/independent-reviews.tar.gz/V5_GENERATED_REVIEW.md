# WO-A v5 源码、实际生成物与对拍入口独立审查

## 结论

**两项通过本次只读源级/生成物审查，无阻断。** `generated/woa-pipeline-cpu-v5/result.json` 记录完整 lowering、PTOAS、Artifact load 成功，两个根都是 16 Tensor ABI，未初始化 NPU。旧 v1…v4 的 NZ/L0C 失败不赋予设备资格；本报告不将旧失败版本写成已经实测。

当前只能进入对应目标档硬件精度与性能门禁，不能提前认定逐 bit 或速度收益。审查未提交任务、未改源码/SDK。

## 源码身份及改动范围

| 文件 | SHA256 |
| --- | --- |
| parent-phase1.py | f22d7d8dd6ef2a48f640b88511c6c32c672ade0b116fa922f18c6a6a23237fe6 |
| candidate-nopipe.py | 3cef7f7a11e0603151db83638dd5f50655915b46b15e56b75ececee412a2126f |
| candidate-k128narrow.py | b5ee93a611e8774dab5b18338af6e74dbf25c43a81491f372f0ea5e9d64128ea |
| ab_probe.py | 33fe0412560e11c92655b10749192e552e9907f43d5f1ca34c86ba704372f388 |
| run-ab.sh | 49bed4e9b845a1403d5a336fcc95b23f37adb72b7ad659b7d587f2e87cd12dcf |

实际 AST 独立检查通过：

- nopipe 仅将 seed_fast_packet 的 `pl.pipeline(1,16,stage=2)` 改为 `pl.range(1,16)`。把该 iterator 恢复后，整模块 AST 与 phase1 相同。
- k128narrow 仅在高 T 的原 same-start wide 资格中增加 `first_start%16==0`，并把该路径改为首 K128、后 31 个 K128。原 M16 fallback 的完整 AST 没变；低 T 分支、WO-A 之后的 WO-B/同步和全部其它函数 AST 没变。
- 新两项没有更改 phase1 八 owner 的等待协议、全 8192 统一量化、BF16 边界、WO-B 整数累加、HC-post 或真实 TND 行格式。

这里要区分 v4 的保留未对齐 wide 分支与 v5：**v5 未对齐起点主动走原 M16 fallback。** 它是有意缩小 wide 资格，不能再称为未对齐起点保持旧 M128 执行。该 fallback 本身源码原样；本轮实际 T240 的 64 组有效起点均为 0/32/…/224，且行间相同，因此目标任务不会因这个 gate 全部回退。

## nopipe 实际 PTO/C++

审查对象为 `generated/woa-pipeline-cpu-v5/nopipe/ptoas/` 的实际文件。

- 首 K256 load 后，PTO 从 A 的列 0/128、B 的行 0/128 依次抽取两个 K128；第一条 matmul 初始化，第二条 matmul.acc 累加。
- 后续原 1…15 循环为 step1：连续 K256 仍依次两条 K128；包内跨端仍原 16×K16，起点与顺序没有被简化掉。
- 首次初始化的 Acc、循环内连续/跨端 Acc 和最终 store 的 carrier 地址均为 L0C 0，128×128 FP32、64 KiB。不同 SSA 名没有变成不同物理 Acc。
- 连续 K256 的 L1 A/B 分别为 0…64 KiB 与 64…128 KiB；跨端 K16 在相同地址范围内复用较小 tile。L0A、L0B 各有 0/32 KiB 两个 K128 槽，总各 64 KiB。没有新增 GM Acc spill。
- C++ 的 load/extract/MMA 以及回用事件保留，range 的性能意义只能由同任务与 phase1 的 paired 数据决定，不能把去 pipeline 直接解释成更快。

## k128narrow 实际 PTO/C++

审查对象为 `generated/woa-pipeline-cpu-v5/k128narrow/ptoas/` 的实际文件。

### MMA 与舍入次序

PTO 首条为 K128 matmul；pipeline 的主体是 `1 to 31 step 2`，每次先后两条 K128 matmul.acc，随后 epilogue 再处理第 31 个 K128。因此执行恰为 0 初始化、1…31 顺序累加，没有漏末包或重做首包。

合法 wide 起点 s=0,16,…240 下，旧 K256 实际每包两条 K128 的序列与新序列同为 `((s+8*j)%256)*16, j=0…31`。独立 CPU 再比较 16 个合法 s 的 primitive 起点/宽度/init 轨迹，完全一致。原 `first_start≤240` 及 same-start gate 保留，未对齐起点进入旧 M16 路径，避免把旧跨端 16×K16 强行改成 K128。

实际 C++ 初始化与两条循环累加、epilogue 全部操作同一个 `v232` Acc，其地址 0、64 KiB；末尾 store 只是同址 Acc descriptor，没有复制旧值覆盖新累加。

### 缓冲与依赖

- 每个 K128 的 A/B 都是 128×128 BF16，即各 32 KiB。
- 真实 L1 四槽地址分别为 0、32768、65536、131072；合计使用 128 KiB，地址高水位 163840 B。中间空隙不能按紧密 128 KiB 内存布局陈述。
- L0A/B 各分别使用 0 与 32768 两个独立槽，各总 64 KiB；L0C 仍 64 KiB。没有在分支后再合并两个不同 matmul seed，规避了旧 v3/v4 的跨 aligned-if Acc phi。
- 实际 C++ 有 MTE2→MTE1 的 load 完成事件、MTE1→M 的 extract 完成事件、M→MTE1 的 L0 消费保护、MTE1→MTE2 的 L1 回用保护。两槽分别使用事件，循环末 drain 后才做末包/最终 store，未发现同槽提前覆盖。
- 真实 valid rows 由 `min(128,rows-panel_row)` 同时传入 A、Acc、GM store。T240 的末 panel 只写 112 行，公开输出仍真 T；T+127 父 GM 容量足够物理尾 tile，未增 scratch ABI。

perf_hints 在新两项只剩 Vec 的已有 PH-MR-001；未再看到 WO-A Left/Right group 的 depth2→1 提示。结合实际双 L0 槽可确认此路径确有两份 operand 存储，但不能仅据此断言一定形成理想传算重叠。PH001 的逻辑 256B 行提示也不能直接换算成实际 NZ 的 DDR 浪费比例。

## harness 最终 CLI 与门禁

`--variant nopipe/k128narrow` 都限定 192≤T≤256，且 `--parent` 必须为 phase1。两臂实际模块来自显式文件与 proof SHA，不会把报告 parent 改名后仍调用 a31。candidate proof 还要求 parent_sha256 与 phase1 一致。

与前份已审 harness 相比，新增两项 CLI 不改以下执行与检查：

- frozen/phase1/new 三臂五个外部边界逐 bit，finite、首差停；真实 L4 权重、当前标定 K 起点、合成 heads/residual。
- eager、FULL A/B/A、NaN/整数反码 poison、恢复 A、所有 scratch/signal guard、只读 SHA、独立地址及零拷贝输出。
- 两个常驻臂的 generation 相等、每计时窗各 +100，used/unused signal 槽检查；12 窗×100、rotate/reverse、全部样本保留，无 DFX/PMU。
- parent/new accum 均 T+127、integer 均 T+63，五个真 T 输出及 signal 独立。本轮没有混入 WO-B M128。
- 内 timeout750s，外任务时限由提交参数约束；此审查不提交设备。

新两项的 resident 报告键表示 phase1，不是 a31。可报告“相对 phase1 的后缀增量及相对 frozen 的差距”；这里的金值是已验收 frozen PTO，不是本任务直接执行 Native，也不是整层/整模型 token 验收。

## 生成物收据

| 对象 | SHA256 |
| --- | --- |
| nopipe PTO | 1070b43c9155b84bd14322ef0e478b0048ee9d8db5206c923b36ac2610c4305e |
| nopipe C++ | b28210d132bc65d918d5685d0251a0236d2bd656cb35fe119bc9b8f489cab4d5 |
| nopipe perf_hints | d5cabed1559a61ade83cd6475207a52c95fd6ad556c8cfb765dea1c09dba9b83 |
| k128narrow PTO | 03a78567008ad1a8ec4c605da8134ed280917b810e6f75ff77ad5d2433fce325 |
| k128narrow C++ | f5456554cf8f61633f0ab065d102b3319b9132c7b01e3714c6cafc90114d3ca6 |
| k128narrow perf_hints | 9d509a31a123540d5144f6eb37dc32566ef0a3d238a77e23a998fdb37a1f715c |

这些固定本次实际审阅生成物。完整编译通过、源级序列及物理资源审查不会替代随后硬件五边界门禁；未测的未对齐/不均匀人工起点不得被写成新增设备覆盖。
