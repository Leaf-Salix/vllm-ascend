# M128/M256 同为 K128 range 的独立审查

## 结论

**v11 两臂源码、harness 与实际生成物通过，无上卡阻断。** 可仅做一次 T240 的 frozen / M128-range / M256-range 三臂逐位优先测试，发现首差即停。本审查不提交任务、不改源码/SDK。

stage2 M256 的 v10 已因 Left131072B>65536B 被CPU资格门禁拦住，无NPU结果。v11取消该路径双缓冲，必须以同样无流水的 M128-range 为直接父臂，才能隔离合并行面板本身；不能把相对旧流水版的差异称作单个 M256 因素。

## 实际身份及父链

| 对象 | SHA256 |
| --- | --- |
| k128owner2 | b215fe84554ac35ea12e85dfa22846840bcba386cec43c074aa170052b5897a5 |
| m128range | 40978d9a85ccfbe50d969a4ace46e4036a36549e483e73e65e514c9657566521 |
| m256range | 2547042f698cfa097e6024d71acbc5fa26efd89ad566594834310c61f365205c |
| ab_probe_m256range.py | 6e2025488cfe8ac30089ac35175c4bf8999d6c6f76a6816c00b2499795262ab7 |
| prepare_m256_range.py | 42af7e2c9dd380a2d445d0242e463747125597577c48b290f77d6b2447c7660b |

直接父链为 m256range→m128range→k128owner2→owner2→phase1→原a31/冻结数学。CLI强制当前variant及parent，不会继续对owner2贴M128-range标签。实际根、工作区及五输出继承三臂独立分配，祖先SHA逐层核对。

## 源级覆盖及数学

高 T 行panel由8个M16变16个M16，全部有效16个start均检查相同、16对齐且≤240。所有start读取先判断rb<row_tiles，不访问无效尾rb。资格不满足时回退循环也同步从8改16，仍逐rb检查边界和使用其自身K起点。

T192…256仅需一个M256 panel；64个group/N128逻辑工作仍由worker+24轮转，输出列归属不变。有效行是 min(256,rows-row)，公开输出不补到256。低T分支、WO-B、vector/owner2/量化/HC-post的AST完全未改。

独立执行实际高T AST，以记录slice/MMA/store的替身遍历：

- T192…256全部65种行数；
- uniform0、uniform240、全负start、unaligned17、high252、上下半panel不同起点、最后有效rb起点不同，共7种模式；
- 每种遍历全部24 AIC与64个逻辑group/N块。

共455组路径均满足真实行/N128唯一写入、无空洞；每行规范化K128/K16 primitive链、初始化及总K4096与原k128owner2/M128-range一致。包括合并资格失败而两半原先分别wide的情形。原M16 K256按已知实际lowering的两条K128展开比较，跨端K16不合并。

这证明源级每行K序及归属，不等于M256设备数学已经逐位通过；仍需真实输入五边界验证。

## 容量与实际生成物

v11 result.json记录两项完整PTOAS/CCEC/Artifact load成功、16Tensor ABI、device_execution=false。

| fast路径实际空间 | M128-range | M256-range |
| --- | --- | --- |
| Mat A | 0…32768B | 0…65536B |
| Mat B | 65536…98304B | 65536…98304B |
| L0A | 0…32768B | 0…65536B |
| L0B | 0…32768B | 0…32768B |
| L0C | 0…65536B | 0…131072B |

M256已经占满本路径可用的64KiB L0A与128KiB L0C，因此不能再直接声称能保留原stage2双Left缓冲；v10失败确有资源依据。两臂Mat A/B不重叠。

实际PTO为首K128 matmul初始化，再 `range(1,32,step1)` 中31条K128 matmul.acc。M256真实指令形状是256×128乘128×128到256×128，没有在该生成物中改成新的K分块。Acc始终地址0，末端直接同一Acc store，没有Acc phi分歧或回写旧值。

源行数的min(256,rows-row)贯穿load、L0A、Acc和GM store；T240只写240行，T256写256行。harness仍分配accum=T+127：T≥192时最少319行，足以容纳本项最多256物理行，无需扩大根ABI或改其它consumer stride。

实际C++保留load完成MTE2→MTE1、extract完成MTE1→M、L0消费M→MTE1、Mat回用MTE1→MTE2，以及最后M→FIX等待。单缓冲每次必须等前轮operand消费后复用，未发现提前覆盖。已有Vec流水提示不是WO-A重新拥有双缓冲的证据。

## harness与解释边界

ab_probe_m256range相对已审v3只变variant/parent及192≤T≤256限制，五边界逐bit/finite、首差停、FULL A/B/A、poison、guard、readonly、双generation、12×100rotate/reverse无插桩计时全部保留。实际三臂是冻结PTO、m128range、m256range，仍是真实L4权重与合成后缀输入，不是本次Native整层或整模型资格。

若M256比M128-range快，也可能只是弥补取消pipeline的代价。保留前仍须对已测k128owner2/冻结路径取得同任务净收益，不能以较慢新父版衬托相对改善；不得拿不同行绝对数值直接算组合收益。

此前15任务和FINAL_REVIEW.md的结论保持原样。本项是后续新增实验，成功/失败都应另列，不回填成原15项已有证据。若硬件首差或无净收益，停止本方向，不以SDK修改扩大范围。

## 固定生成物

| 对象 | SHA256 |
| --- | --- |
| M128-range PTO | dcad4ca5e0691018a78243fadd07d162fc2db991b676fb9d68cbb251dc17e863 |
| M128-range C++ | fed5ebb2979dced42eb924e9a6a9feb2f4e60df44edafd436541a411dde3039f |
| M256-range PTO | 27fad8c5a59bf798e0c8f0a52d98dbd2ae0d477748f3744009d9cc8b917ec553 |
| M256-range C++ | 17e1a2da37372c971cdcf04dcc8c3ed906b7112bea873f9d56a0a1c74ef2b84d |
