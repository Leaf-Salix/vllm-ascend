#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void cube(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ bfloat16_t* v6, __gm__ int8_t* v7, __gm__ float* v8, __gm__ bfloat16_t* v9, __gm__ bfloat16_t* v10, __gm__ float* v11, __gm__ float* v12, __gm__ bfloat16_t* v13, __gm__ float* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int32_t v22 = 1;
  // pto: %c0_i64
  const int64_t v23 = 0;
  // pto: %c65536_i64
  const int64_t v24 = 65536;
  // pto: %c32768_i64
  const int64_t v25 = 32768;
  // pto: %c32768_index
  const int64_t v26 = 32768;
  // pto: %c1_index
  const int64_t v27 = 1;
  // pto: %c8_index
  const int64_t v28 = 8;
  const int64_t v29 = 64;
  // pto: %c256_index
  const int64_t v30 = 256;
  // pto: %c16_index
  const int64_t v31 = 16;
  // pto: %c4194304_index
  const int64_t v32 = 4194304;
  // pto: %c65536_index
  const int64_t v33 = 65536;
  const int64_t v34 = 128;
  // pto: %c512_index
  const int64_t v35 = 512;
  // pto: %c32_index
  const int64_t v36 = 32;
  // pto: %c33554432_index
  const int64_t v37 = 33554432;
  // pto: %c262144_index
  const int64_t v38 = 262144;
  // pto: %c4096_index
  const int64_t v39 = 4096;
  // pto: %c8192_index
  const int64_t v40 = 8192;
  // pto: %c4_index
  const int64_t v41 = 4;
  // pto: %c55296_index
  const int64_t v42 = 55296;
  // pto: %c0_index
  const int64_t v43 = 0;
  // pto: %c15_index
  const int64_t v44 = 15;
  // pto: %c192_index
  const int64_t v45 = 192;
  // pto: %c24_index
  const int64_t v46 = 24;
  // pto: %c7_index
  const int64_t v47 = 7;
  // pto: %c2_index
  const int64_t v48 = 2;
  // pto: %c3_index
  const int64_t v49 = 3;
  // pto: %c5_index
  const int64_t v50 = 5;
  // pto: %c6_index
  const int64_t v51 = 6;
  // pto: %c240_index
  const int64_t v52 = 240;
  // pto: %c1024_index
  const int64_t v53 = 1024;
  // pto: %c241_index
  const int64_t v54 = 241;
  // pto: %c9216_index
  const int64_t v55 = 9216;
  // pto: %c72_index
  const int64_t v56 = 72;
  // pto: %c27648_index
  const int64_t v57 = 27648;
  // pto: %c63_index
  const int64_t v58 = 63;
  // pto: %c36864_index
  const int64_t v59 = 36864;
  // pto: %heads__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v61 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v62 = 1;
  // pto: %heads__ssa_v0_view
  int64_t v63 = (int64_t) v17;
  // pto: %heads__ssa_v0_view
  int64_t v64 = v63 * v26;
  // pto: %heads__ssa_v0_view
  int64_t v65 = v62 * v64;
  // pto: %heads__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v66 = pto::Shape<1, 1, 1, -1, -1>(v60, v61, v62, v63, v26);
  // pto: %heads__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v67 = pto::Stride<-1, -1, -1, -1, -1>(v61 * v65, v65, v64, v26, v27);
  // pto: %heads__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v68 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v66, v67);
  // pto: %wo_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v69 = pto::Shape<-1, -1, -1, -1, -1>(v28, v29, v30, v31, v31);
  // pto: %wo_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v70 = pto::Stride<-1, -1, -1, -1, -1>(v32, v33, v30, v31, v27);
  // pto: %wo_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v71 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v2, v69, v70);
  // pto: %wo_b__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v72 = pto::Shape<-1, -1, -1, -1, -1>(v27, v34, v35, v31, v36);
  // pto: %wo_b__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v73 = pto::Stride<-1, -1, -1, -1, -1>(v37, v38, v35, v36, v27);
  // pto: %wo_b__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v74 = GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v3, v72, v73);
  // pto: %quantized__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %quantized__ssa_v0_view
  int64_t v78 = (int64_t) v17;
  // pto: %quantized__ssa_v0_view
  int64_t v79 = v78 * v40;
  // pto: %quantized__ssa_v0_view
  int64_t v80 = v77 * v79;
  // pto: %quantized__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v81 = pto::Shape<1, 1, 1, -1, -1>(v75, v76, v77, v78, v40);
  // pto: %quantized__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v82 = pto::Stride<-1, -1, -1, -1, -1>(v76 * v80, v80, v79, v40, v27);
  // pto: %quantized__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v83 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v81, v82);
  // pto: %accum__ssa_v0_view
  const int64_t v84 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v85 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %accum__ssa_v0_view
  int64_t v87 = (int64_t) v18;
  // pto: %accum__ssa_v0_view
  int64_t v88 = v87 * v40;
  // pto: %accum__ssa_v0_view
  int64_t v89 = v86 * v88;
  // pto: %accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v90 = pto::Shape<1, 1, 1, -1, -1>(v84, v85, v86, v87, v40);
  // pto: %accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v91 = pto::Stride<-1, -1, -1, -1, -1>(v85 * v89, v89, v88, v40, v27);
  // pto: %accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v92 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v90, v91);
  // pto: %integer_accum__ssa_v0_view
  const int64_t v93 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v94 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %integer_accum__ssa_v0_view
  int64_t v96 = (int64_t) v19;
  // pto: %integer_accum__ssa_v0_view
  int64_t v97 = v96 * v39;
  // pto: %integer_accum__ssa_v0_view
  int64_t v98 = v95 * v97;
  // pto: %integer_accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v99 = pto::Shape<1, 1, 1, -1, -1>(v93, v94, v95, v96, v39);
  // pto: %integer_accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v100 = pto::Stride<-1, -1, -1, -1, -1>(v94 * v98, v98, v97, v39, v27);
  // pto: %integer_accum__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v101 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v99, v100);
  // pto: %signals__ssa_v0_view
  const int64_t v102 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v103 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v104 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v105 = 1;
  // pto: %signals__ssa_v0_view
  int64_t v106 = v42 * v27;
  // pto: %signals__ssa_v0_view
  int64_t v107 = v105 * v106;
  // pto: %signals__ssa_v0_view
  int64_t v108 = v104 * v107;
  // pto: %signals__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v109 = pto::Shape<1, 1, 1, 1, -1>(v102, v103, v104, v105, v42);
  // pto: %signals__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v110 = pto::Stride<-1, -1, -1, -1, -1>(v103 * v108, v108, v107, v106, v27);
  // pto: %signals__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v111 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v109, v110);
  // pto: %seed_fast_acc__phi_v7
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v112 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v34, v34);
  // pto: %seed_fast_acc__phi_v7
  uint64_t v113 = (uint64_t) v23;
  TASSIGN(v112, v113);
  // pto: %seed_narrow_acc__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v114 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v31, v34);
  // pto: %seed_narrow_acc__phi_v7
  uint64_t v115 = (uint64_t) v23;
  TASSIGN(v114, v115);
  // pto: %v4_wide_acc__phi_v7
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v116 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v34, v34);
  // pto: %v4_wide_acc__phi_v7
  uint64_t v117 = (uint64_t) v23;
  TASSIGN(v116, v117);
  // pto: %v4_narrow_acc__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v118 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v31, v34);
  // pto: %v4_narrow_acc__phi_v7
  uint64_t v119 = (uint64_t) v23;
  TASSIGN(v118, v119);
  // pto: %worker__ssa_v0
  int64_t v120 = (int64_t) v20;
  // pto: %37
  int64_t v121 = (int64_t) ((uint64_t) v120 * (uint64_t) v34);
  // pto: %38
  int64_t v122 = v121 < v43 ? v43 : v121;
  // pto: %signals__ssa_v0_pview
  __gm__ int32_t* v123 = PTOAS__GLOBAL_TENSOR_DATA(v111);
  // pto: %signals__ssa_v0_pview
  const int64_t v124 = 0;
  // pto: %signals__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 1> v125 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  pto::Stride<1, 1, 1, 1, 1> v126 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v127 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v123 + (v124 + v122), v125, v126);
  __gm__ int32_t* v128 = PTOAS__GLOBAL_TENSOR_DATA(v127);
  PTOAS__DCCI_SINGLE_CACHE_LINE(v128);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
  // pto: %t__tile
  int32_t v129 = (v16)[v121];
  // pto: %40
  int32_t v130 = (int32_t) ((uint32_t) v129 + (uint32_t) v22);
  pipe_barrier(PIPE_ALL);
  pto::comm::NotifyOp v131 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v127, v130, v131);
  // pto: %42, %43
  int64_t v132 = (int64_t) ((uint64_t) v17 + (uint64_t) v44) / v31;
  // pto: %44
  if (v17 >= v45) {
    for (int64_t v133 = v120; v133 < v29; v133 += v46) {
      // pto: %45
      ;
      int64_t v134 = v133 / v28;
      // pto: %46
      ;
      int64_t v135 = v133 % v28;
      // pto: %47, %48, %49
      ;
      int64_t v136 = v135 < v43 ? (int64_t) ((uint64_t) v135 + (uint64_t) v28) : v135;
      // pto: %50
      ;
      int64_t v137 = (int64_t) ((uint64_t) v136 * (uint64_t) v34);
      // pto: %51, %52
      ;
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v138 = v43; v138 < ((int64_t) ((uint64_t) v132 + (uint64_t) v47) / v28); v138 += v27) {
        // pto: %53
        ;
        int64_t v139 = (int64_t) ((uint64_t) v138 * (uint64_t) v28);
        // pto: %flat_offset, %55, %56, %54
        ;
        int32_t v140 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v138 * (uint64_t) v29) + (uint64_t) v134) * (uint64_t) v28) + (uint64_t) v136)];
        // pto: %57
        ;
        int64_t v141 = (int64_t) v140;
        // pto: %58
        ;
        int64_t v142 = v141 < v43 ? v43 : v141;
        // pto: %59
        ;
        int64_t v143 = (int64_t) ((uint64_t) v139 + (uint64_t) v27);
        // pto: %60
        ;
        // pto: %seed_same_start__phi_v3
        ;
        int64_t v144;
        if (v143 < v132) {
          // pto: %63, %64, %65, %66, %61
          ;
          int32_t v145 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v143 * (uint64_t) v28) + (uint64_t) v134) * (uint64_t) v28) + (uint64_t) v136)];
          // pto: %67
          ;
          int64_t v146 = (int64_t) v145;
          // pto: %68
          ;
          int64_t v147 = v146 < v43 ? v43 : v146;
          // pto: %69, %seed_same_start__phi_v2
          ;
          v144 = v147 != v142 ? v43 : v27;
        } else {
          v144 = v27;
        };
        // pto: %70
        ;
        int64_t v148 = (int64_t) ((uint64_t) v139 + (uint64_t) v48);
        // pto: %71
        ;
        // pto: %seed_same_start__phi_v6
        ;
        int64_t v149;
        if (v148 < v132) {
          // pto: %74, %75, %76, %77, %72
          ;
          int32_t v150 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v148 * (uint64_t) v28) + (uint64_t) v134) * (uint64_t) v28) + (uint64_t) v136)];
          // pto: %78
          ;
          int64_t v151 = (int64_t) v150;
          // pto: %79
          ;
          int64_t v152 = v151 < v43 ? v43 : v151;
          // pto: %80, %seed_same_start__phi_v5
          ;
          int64_t v153 = v152 != v142 ? v43 : v144;
          v149 = v153;
        } else {
          v149 = v144;
        };
        // pto: %81
        ;
        int64_t v154 = (int64_t) ((uint64_t) v139 + (uint64_t) v49);
        // pto: %82
        ;
        // pto: %seed_same_start__phi_v9
        ;
        int64_t v155;
        if (v154 < v132) {
          // pto: %85, %86, %87, %88, %83
          ;
          int32_t v156 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v154 * (uint64_t) v28) + (uint64_t) v134) * (uint64_t) v28) + (uint64_t) v136)];
          // pto: %89
          ;
          int64_t v157 = (int64_t) v156;
          // pto: %90
          ;
          int64_t v158 = v157 < v43 ? v43 : v157;
          // pto: %91, %seed_same_start__phi_v8
          ;
          int64_t v159 = v158 != v142 ? v43 : v149;
          v155 = v159;
        } else {
          v155 = v149;
        };
        // pto: %92
        ;
        int64_t v160 = (int64_t) ((uint64_t) v139 + (uint64_t) v41);
        // pto: %93
        ;
        // pto: %seed_same_start__phi_v12
        ;
        int64_t v161;
        if (v160 < v132) {
          // pto: %96, %97, %98, %99, %94
          ;
          int32_t v162 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v160 * (uint64_t) v28) + (uint64_t) v134) * (uint64_t) v28) + (uint64_t) v136)];
          // pto: %100
          ;
          int64_t v163 = (int64_t) v162;
          // pto: %101
          ;
          int64_t v164 = v163 < v43 ? v43 : v163;
          // pto: %102, %seed_same_start__phi_v11
          ;
          int64_t v165 = v164 != v142 ? v43 : v155;
          v161 = v165;
        } else {
          v161 = v155;
        };
        // pto: %103
        ;
        int64_t v166 = (int64_t) ((uint64_t) v139 + (uint64_t) v50);
        // pto: %104
        ;
        // pto: %seed_same_start__phi_v15
        ;
        int64_t v167;
        if (v166 < v132) {
          // pto: %107, %108, %109, %110, %105
          ;
          int32_t v168 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v166 * (uint64_t) v28) + (uint64_t) v134) * (uint64_t) v28) + (uint64_t) v136)];
          // pto: %111
          ;
          int64_t v169 = (int64_t) v168;
          // pto: %112
          ;
          int64_t v170 = v169 < v43 ? v43 : v169;
          // pto: %113, %seed_same_start__phi_v14
          ;
          int64_t v171 = v170 != v142 ? v43 : v161;
          v167 = v171;
        } else {
          v167 = v161;
        };
        // pto: %114
        ;
        int64_t v172 = (int64_t) ((uint64_t) v139 + (uint64_t) v51);
        // pto: %115
        ;
        // pto: %seed_same_start__phi_v18
        ;
        int64_t v173;
        if (v172 < v132) {
          // pto: %118, %119, %120, %121, %116
          ;
          int32_t v174 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v172 * (uint64_t) v28) + (uint64_t) v134) * (uint64_t) v28) + (uint64_t) v136)];
          // pto: %122
          ;
          int64_t v175 = (int64_t) v174;
          // pto: %123
          ;
          int64_t v176 = v175 < v43 ? v43 : v175;
          // pto: %124, %seed_same_start__phi_v17
          ;
          int64_t v177 = v176 != v142 ? v43 : v167;
          v173 = v177;
        } else {
          v173 = v167;
        };
        // pto: %125
        ;
        int64_t v178 = (int64_t) ((uint64_t) v139 + (uint64_t) v47);
        // pto: %126
        ;
        // pto: %seed_same_start__phi_v21
        ;
        int64_t v179;
        if (v178 < v132) {
          // pto: %129, %130, %131, %132, %127
          ;
          int32_t v180 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v178 * (uint64_t) v28) + (uint64_t) v134) * (uint64_t) v28) + (uint64_t) v136)];
          // pto: %133
          ;
          int64_t v181 = (int64_t) v180;
          // pto: %134
          ;
          int64_t v182 = v181 < v43 ? v43 : v181;
          // pto: %135, %seed_same_start__phi_v20
          ;
          int64_t v183 = v182 != v142 ? v43 : v173;
          v179 = v183;
        } else {
          v179 = v173;
        };
        // pto: %136, %seed_same_start__phi_v25
        ;
        int64_t v184 = v142 > v52 ? v43 : v179;
        // pto: %137
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        if (v184 == v27) {
          int64_t v185 = (int64_t) ((uint64_t) v138 * (uint64_t) v34);
          // pto: %139
          ;
          int64_t v186 = (int64_t) ((uint64_t) v17 - (uint64_t) v185);
          // pto: %140
          ;
          int64_t v187 = v186 < v34 ? v186 : v34;
          // pto: %141
          ;
          int64_t v188 = (int64_t) ((uint64_t) v142 * (uint64_t) v31);
          // pto: %seed_fast_seed_x__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v189 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v187, v30);
          // pto: %seed_fast_seed_x__tile
          ;
          uint64_t v190 = (uint64_t) v23;
          TASSIGN(v189, v190);
          // pto: %142
          ;
          int64_t v191 = v185 < v43 ? v43 : v185;
          // pto: %143
          ;
          int64_t v192 = (int64_t) ((uint64_t) v134 * (uint64_t) v39);
          // pto: %144
          ;
          int64_t v193 = (int64_t) ((uint64_t) v192 + (uint64_t) v188);
          // pto: %145
          ;
          int64_t v194 = v193 < v43 ? v43 : v193;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v195 = 0;
          // pto: %heads__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v196 = PTOAS__GLOBAL_TENSOR_DATA(v68);
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v197 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v198 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v199 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          int64_t v200 = v187 * v26;
          // pto: %heads__ssa_v0_pview
          ;
          int64_t v201 = v199 * v200;
          // pto: %heads__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, -1, 256> v202 = pto::Shape<1, 1, 1, -1, 256>(v197, v198, v199, v187, v30);
          // pto: %heads__ssa_v0_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v203 = pto::Stride<-1, -1, -1, -1, -1>(v198 * v201, v201, v200, v26, v27);
          // pto: %heads__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v204 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v196 + (v195 + v191 * v26 + v194 * v27), v202, v203);
          TLOAD(v189, v204);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %seed_fast_seed_w__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v205 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v30, v34);
          // pto: %seed_fast_seed_w__tile
          ;
          uint64_t v206 = (uint64_t) v24;
          TASSIGN(v205, v206);
          // pto: %146
          ;
          int64_t v207 = v134 < v43 ? v43 : v134;
          // pto: %147
          ;
          int64_t v208 = v137 / v31;
          // pto: %148
          ;
          int64_t v209 = v208 < v43 ? v43 : v208;
          // pto: %149
          ;
          int64_t v210 = v188 / v31;
          // pto: %150
          ;
          int64_t v211 = v210 < v43 ? v43 : v210;
          // pto: %wo_a__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v212 = PTOAS__GLOBAL_TENSOR_DATA(v71);
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v213 = 0;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v214 = 4194304;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v215 = 65536;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v216 = 256;
          // pto: %wo_a__ssa_v0_pview
          ;
          pto::Shape<1, 8, 16, 16, 16> v217 = pto::Shape<1, 8, 16, 16, 16>();
          // pto: %wo_a__ssa_v0_pview
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v218 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %wo_a__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v219 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v212 + ((v213 + v207 * v214) + v209 * v215 + v211 * v216), v217, v218);
          TLOAD(v205, v219);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %seed_fast_acc__tile_l0_init_storage
          ;
          Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v220 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v34, v34);
          // pto: %seed_fast_acc__tile_l0_init_storage
          ;
          uint64_t v221 = (uint64_t) v23;
          TASSIGN(v220, v221);
          v220.SetValidShape(v187, v34);
          // pto: %seed_fast_acc__tile_l0_a
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v222 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v187, v34);
          // pto: %seed_fast_acc__tile_l0_a
          ;
          uint64_t v223 = (uint64_t) v23;
          TASSIGN(v222, v223);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          uint16_t v224 = static_cast<uint16_t>(v43);
          uint16_t v225 = static_cast<uint16_t>(v43);
          TEXTRACT(v222, v189, v224, v225);
          // pto: %seed_fast_acc__tile_l0_b
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v226 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v34, v34);
          // pto: %seed_fast_acc__tile_l0_b
          ;
          uint64_t v227 = (uint64_t) v23;
          TASSIGN(v226, v227);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          uint16_t v228 = static_cast<uint16_t>(v43);
          uint16_t v229 = static_cast<uint16_t>(v43);
          TEXTRACT(v226, v205, v228, v229);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          // pto: %0
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v230 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v187, v34);
          // pto: %0
          ;
          uint64_t v231 = (uint64_t) v25;
          TASSIGN(v230, v231);
          uint16_t v232 = static_cast<uint16_t>(v43);
          uint16_t v233 = static_cast<uint16_t>(v34);
          TEXTRACT(v230, v189, v232, v233);
          // pto: %1
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v234 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v34, v34);
          // pto: %1
          ;
          uint64_t v235 = (uint64_t) v25;
          TASSIGN(v234, v235);
          uint16_t v236 = static_cast<uint16_t>(v34);
          uint16_t v237 = static_cast<uint16_t>(v43);
          TEXTRACT(v234, v205, v236, v237);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          TMATMUL(v220, v222, v226);
          pipe_barrier(PIPE_M);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
          TMATMUL_ACC(v220, v220, v230, v234);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          for (int64_t v238 = v27; v238 < v31; v238 += v27) {
            // pto: %152, %151, %153
            ;
            int64_t v239 = (int64_t) ((uint64_t) v142 + (uint64_t) ((int64_t) (uint64_t) v238 * (uint64_t) v31)) % v30;
            // pto: %154, %155, %156
            ;
            int64_t v240 = v239 < v43 ? (int64_t) ((uint64_t) v239 + (uint64_t) v30) : v239;
            // pto: %157
            ;
            // pto: %158
            ;
            int64_t v241 = v187 < v34 ? v187 : v34;
            v112.SetValidShape(v241, v34);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
            if (v240 <= v52) {
              // pto: %159
              ;
              int64_t v242 = (int64_t) ((uint64_t) v240 * (uint64_t) v31);
              // pto: %seed_fast_packet_x__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v243 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v187, v30);
              // pto: %seed_fast_packet_x__tile
              ;
              uint64_t v244 = (uint64_t) v23;
              TASSIGN(v243, v244);
              // pto: %162
              ;
              int64_t v245 = (int64_t) ((uint64_t) v192 + (uint64_t) v242);
              // pto: %163
              ;
              int64_t v246 = v245 < v43 ? v43 : v245;
              // pto: %164
              ;
              const int64_t v247 = 0;
              // pto: %164
              ;
              __gm__ bfloat16_t* v248 = PTOAS__GLOBAL_TENSOR_DATA(v68);
              // pto: %164
              ;
              const int64_t v249 = 1;
              // pto: %164
              ;
              const int64_t v250 = 1;
              // pto: %164
              ;
              const int64_t v251 = 1;
              // pto: %164
              ;
              int64_t v252 = v187 * v26;
              // pto: %164
              ;
              int64_t v253 = v251 * v252;
              // pto: %164
              ;
              pto::Shape<1, 1, 1, -1, 256> v254 = pto::Shape<1, 1, 1, -1, 256>(v249, v250, v251, v187, v30);
              // pto: %164
              ;
              pto::Stride<-1, -1, -1, -1, -1> v255 = pto::Stride<-1, -1, -1, -1, -1>(v250 * v253, v253, v252, v26, v27);
              // pto: %164
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v256 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v248 + (v247 + v191 * v26 + v246 * v27), v254, v255);
              TLOAD(v243, v256);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
              // pto: %seed_fast_packet_w__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v257 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v30, v34);
              // pto: %seed_fast_packet_w__tile
              ;
              uint64_t v258 = (uint64_t) v24;
              TASSIGN(v257, v258);
              // pto: %168
              ;
              int64_t v259 = v242 / v31;
              // pto: %169
              ;
              int64_t v260 = v259 < v43 ? v43 : v259;
              // pto: %170
              ;
              __gm__ bfloat16_t* v261 = PTOAS__GLOBAL_TENSOR_DATA(v71);
              // pto: %170
              ;
              const int64_t v262 = 0;
              // pto: %170
              ;
              const int64_t v263 = 4194304;
              // pto: %170
              ;
              const int64_t v264 = 65536;
              // pto: %170
              ;
              const int64_t v265 = 256;
              // pto: %170
              ;
              pto::Shape<1, 8, 16, 16, 16> v266 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %170
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v267 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %170
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v268 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v261 + ((v262 + v207 * v263) + v209 * v264 + v260 * v265), v266, v267);
              TLOAD(v257, v268);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
              // pto: %seed_fast_acc__iter_v1_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v269 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v187, v34);
              // pto: %seed_fast_acc__iter_v1_l0_a
              ;
              uint64_t v270 = (uint64_t) v23;
              TASSIGN(v269, v270);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
              uint16_t v271 = static_cast<uint16_t>(v43);
              uint16_t v272 = static_cast<uint16_t>(v43);
              TEXTRACT(v269, v243, v271, v272);
              // pto: %seed_fast_acc__iter_v1_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v273 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v34, v34);
              // pto: %seed_fast_acc__iter_v1_l0_b
              ;
              uint64_t v274 = (uint64_t) v23;
              TASSIGN(v273, v274);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
              uint16_t v275 = static_cast<uint16_t>(v43);
              uint16_t v276 = static_cast<uint16_t>(v43);
              TEXTRACT(v273, v257, v275, v276);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
              // pto: %3
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v277 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v187, v34);
              // pto: %3
              ;
              uint64_t v278 = (uint64_t) v25;
              TASSIGN(v277, v278);
              uint16_t v279 = static_cast<uint16_t>(v43);
              uint16_t v280 = static_cast<uint16_t>(v34);
              TEXTRACT(v277, v243, v279, v280);
              // pto: %4
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v281 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v34, v34);
              // pto: %4
              ;
              uint64_t v282 = (uint64_t) v25;
              TASSIGN(v281, v282);
              uint16_t v283 = static_cast<uint16_t>(v34);
              uint16_t v284 = static_cast<uint16_t>(v43);
              TEXTRACT(v281, v257, v283, v284);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v220, v220, v269, v273);
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
              TMATMUL_ACC(v220, v220, v277, v281);
            } else {
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
              for (int64_t v285 = v43; v285 < v31; v285 += v27) {
                // pto: %171, %172
                ;
                int64_t v286 = (int64_t) ((uint64_t) v240 + (uint64_t) v285) % v30;
                // pto: %173, %174, %175
                ;
                int64_t v287 = v286 < v43 ? (int64_t) ((uint64_t) v286 + (uint64_t) v30) : v286;
                // pto: %176
                ;
                int64_t v288 = (int64_t) ((uint64_t) v287 * (uint64_t) v31);
                // pto: %seed_fast_wrap_x__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v289 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v187, v31);
                // pto: %seed_fast_wrap_x__tile
                ;
                uint64_t v290 = (uint64_t) v23;
                TASSIGN(v289, v290);
                // pto: %179
                ;
                int64_t v291 = (int64_t) ((uint64_t) v192 + (uint64_t) v288);
                // pto: %180
                ;
                int64_t v292 = v291 < v43 ? v43 : v291;
                // pto: %181
                ;
                const int64_t v293 = 0;
                // pto: %181
                ;
                __gm__ bfloat16_t* v294 = PTOAS__GLOBAL_TENSOR_DATA(v68);
                // pto: %181
                ;
                const int64_t v295 = 1;
                // pto: %181
                ;
                const int64_t v296 = 1;
                // pto: %181
                ;
                const int64_t v297 = 1;
                // pto: %181
                ;
                int64_t v298 = v187 * v26;
                // pto: %181
                ;
                int64_t v299 = v297 * v298;
                // pto: %181
                ;
                pto::Shape<1, 1, 1, -1, 16> v300 = pto::Shape<1, 1, 1, -1, 16>(v295, v296, v297, v187, v31);
                // pto: %181
                ;
                pto::Stride<-1, -1, -1, -1, -1> v301 = pto::Stride<-1, -1, -1, -1, -1>(v296 * v299, v299, v298, v26, v27);
                // pto: %181
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v302 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v294 + (v293 + v191 * v26 + v292 * v27), v300, v301);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                TLOAD(v289, v302);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
                // pto: %seed_fast_wrap_w__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v303 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v31, v34);
                // pto: %seed_fast_wrap_w__tile
                ;
                uint64_t v304 = (uint64_t) v24;
                TASSIGN(v303, v304);
                // pto: %185
                ;
                int64_t v305 = v288 / v31;
                // pto: %186
                ;
                int64_t v306 = v305 < v43 ? v43 : v305;
                // pto: %187
                ;
                __gm__ bfloat16_t* v307 = PTOAS__GLOBAL_TENSOR_DATA(v71);
                // pto: %187
                ;
                const int64_t v308 = 0;
                // pto: %187
                ;
                const int64_t v309 = 4194304;
                // pto: %187
                ;
                const int64_t v310 = 65536;
                // pto: %187
                ;
                const int64_t v311 = 256;
                // pto: %187
                ;
                pto::Shape<1, 8, 1, 16, 16> v312 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %187
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v313 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %187
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v314 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v307 + ((v308 + v207 * v309) + v209 * v310 + v306 * v311), v312, v313);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
                TLOAD(v303, v314);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
                // pto: %lhs_slice_0_textract
                ;
                Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v315 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v187, v31);
                // pto: %lhs_slice_0_textract
                ;
                uint64_t v316 = (uint64_t) v23;
                TASSIGN(v315, v316);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
                uint16_t v317 = static_cast<uint16_t>(v43);
                uint16_t v318 = static_cast<uint16_t>(v43);
                TEXTRACT(v315, v289, v317, v318);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                // pto: %rhs_slice_0_textract
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v319 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v31, v34);
                // pto: %rhs_slice_0_textract
                ;
                uint64_t v320 = (uint64_t) v23;
                TASSIGN(v319, v320);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
                uint16_t v321 = static_cast<uint16_t>(v43);
                uint16_t v322 = static_cast<uint16_t>(v43);
                TEXTRACT(v319, v303, v321, v322);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v220, v220, v315, v319);
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
              };
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            };
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
          // pto: %189, %190
          ;
          int64_t v323 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v134 * (uint64_t) v53) + (uint64_t) v137);
          // pto: %191
          ;
          int64_t v324 = v323 < v43 ? v43 : v323;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v325 = 0;
          // pto: %accum__ssa_v0_pview
          ;
          __gm__ float* v326 = PTOAS__GLOBAL_TENSOR_DATA(v92);
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v327 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v328 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v329 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          int64_t v330 = v187 * v40;
          // pto: %accum__ssa_v0_pview
          ;
          int64_t v331 = v329 * v330;
          // pto: %accum__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, -1, 128> v332 = pto::Shape<1, 1, 1, -1, 128>(v327, v328, v329, v187, v34);
          // pto: %accum__ssa_v0_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v333 = pto::Stride<-1, -1, -1, -1, -1>(v328 * v331, v331, v330, v40, v27);
          // pto: %accum__ssa_v0_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v334 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v326 + (v325 + v191 * v40 + v324 * v27), v332, v333);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
          TSTORE(v334, v220);
        } else {
          for (int64_t v335 = v43; v335 < v28; v335 += v27) {
            // pto: %192
            ;
            int64_t v336 = (int64_t) ((uint64_t) v139 + (uint64_t) v335);
            // pto: %193
            ;
            if (v336 < v132) {
              // pto: %194
              ;
              int64_t v337 = (int64_t) ((uint64_t) v336 * (uint64_t) v31);
              // pto: %195
              ;
              int64_t v338 = (int64_t) ((uint64_t) v17 - (uint64_t) v337);
              // pto: %196
              ;
              int64_t v339 = v338 < v31 ? v338 : v31;
              // pto: %198, %199, %200, %201, %197
              ;
              int32_t v340 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v336 * (uint64_t) v28) + (uint64_t) v134) * (uint64_t) v28) + (uint64_t) v136)];
              // pto: %202
              ;
              int64_t v341 = (int64_t) v340;
              // pto: %203
              ;
              int64_t v342 = v341 < v43 ? v43 : v341;
              // pto: %seed_narrow_acc__tile
              ;
              Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v343 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v31, v34);
              // pto: %seed_narrow_acc__tile
              ;
              uint64_t v344 = (uint64_t) v23;
              TASSIGN(v343, v344);
              wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
              for (int64_t v345 = v43; v345 < v31; v345 += v27) {
                // pto: %204
                ;
                int64_t v346 = (int64_t) ((uint64_t) v345 * (uint64_t) v31);
                // pto: %205, %206
                ;
                int64_t v347 = (int64_t) ((uint64_t) v342 + (uint64_t) v346) % v30;
                // pto: %207, %208, %209
                ;
                int64_t v348 = v347 < v43 ? (int64_t) ((uint64_t) v347 + (uint64_t) v30) : v347;
                // pto: %210
                ;
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
                if (v348 <= v52) {
                  // pto: %211
                  ;
                  int64_t v349 = (int64_t) ((uint64_t) v348 * (uint64_t) v31);
                  // pto: %seed_narrow_packet_x__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v350 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v339, v30);
                  // pto: %seed_narrow_packet_x__tile
                  ;
                  uint64_t v351 = (uint64_t) v24;
                  TASSIGN(v350, v351);
                  // pto: %212
                  ;
                  int64_t v352 = v337 < v43 ? v43 : v337;
                  // pto: %213, %214
                  ;
                  int64_t v353 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v134 * (uint64_t) v39) + (uint64_t) v349);
                  // pto: %215
                  ;
                  int64_t v354 = v353 < v43 ? v43 : v353;
                  // pto: %216
                  ;
                  const int64_t v355 = 0;
                  // pto: %216
                  ;
                  __gm__ bfloat16_t* v356 = PTOAS__GLOBAL_TENSOR_DATA(v68);
                  // pto: %216
                  ;
                  const int64_t v357 = 1;
                  // pto: %216
                  ;
                  const int64_t v358 = 1;
                  // pto: %216
                  ;
                  const int64_t v359 = 1;
                  // pto: %216
                  ;
                  int64_t v360 = v339 * v26;
                  // pto: %216
                  ;
                  int64_t v361 = v359 * v360;
                  // pto: %216
                  ;
                  pto::Shape<1, 1, 1, -1, 256> v362 = pto::Shape<1, 1, 1, -1, 256>(v357, v358, v359, v339, v30);
                  // pto: %216
                  ;
                  pto::Stride<-1, -1, -1, -1, -1> v363 = pto::Stride<-1, -1, -1, -1, -1>(v358 * v361, v361, v360, v26, v27);
                  // pto: %216
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v364 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v356 + (v355 + v352 * v26 + v354 * v27), v362, v363);
                  TLOAD(v350, v364);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
                  // pto: %seed_narrow_packet_w__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v365 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v30, v34);
                  // pto: %seed_narrow_packet_w__tile
                  ;
                  uint64_t v366 = (uint64_t) v23;
                  TASSIGN(v365, v366);
                  // pto: %217
                  ;
                  int64_t v367 = v134 < v43 ? v43 : v134;
                  // pto: %218
                  ;
                  int64_t v368 = v137 / v31;
                  // pto: %219
                  ;
                  int64_t v369 = v368 < v43 ? v43 : v368;
                  // pto: %220
                  ;
                  int64_t v370 = v349 / v31;
                  // pto: %221
                  ;
                  int64_t v371 = v370 < v43 ? v43 : v370;
                  // pto: %222
                  ;
                  __gm__ bfloat16_t* v372 = PTOAS__GLOBAL_TENSOR_DATA(v71);
                  // pto: %222
                  ;
                  const int64_t v373 = 0;
                  // pto: %222
                  ;
                  const int64_t v374 = 4194304;
                  // pto: %222
                  ;
                  const int64_t v375 = 65536;
                  // pto: %222
                  ;
                  const int64_t v376 = 256;
                  // pto: %222
                  ;
                  pto::Shape<1, 8, 16, 16, 16> v377 = pto::Shape<1, 8, 16, 16, 16>();
                  // pto: %222
                  ;
                  pto::Stride<4194304, 65536, 256, 16, 1> v378 = pto::Stride<4194304, 65536, 256, 16, 1>();
                  // pto: %222
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v379 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v372 + ((v373 + v367 * v374) + v369 * v375 + v371 * v376), v377, v378);
                  TLOAD(v365, v379);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
                  // pto: %seed_narrow_acc__iter_v1_l0_a
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v380 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v339, v34);
                  // pto: %seed_narrow_acc__iter_v1_l0_a
                  ;
                  uint64_t v381 = (uint64_t) v23;
                  TASSIGN(v380, v381);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
                  uint16_t v382 = static_cast<uint16_t>(v43);
                  uint16_t v383 = static_cast<uint16_t>(v43);
                  TEXTRACT(v380, v350, v382, v383);
                  // pto: %seed_narrow_acc__iter_v1_l0_b
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v384 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v34, v34);
                  // pto: %seed_narrow_acc__iter_v1_l0_b
                  ;
                  uint64_t v385 = (uint64_t) v23;
                  TASSIGN(v384, v385);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
                  uint16_t v386 = static_cast<uint16_t>(v43);
                  uint16_t v387 = static_cast<uint16_t>(v43);
                  TEXTRACT(v384, v365, v386, v387);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
                  // pto: %6
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v388 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v339, v34);
                  // pto: %6
                  ;
                  uint64_t v389 = (uint64_t) v25;
                  TASSIGN(v388, v389);
                  uint16_t v390 = static_cast<uint16_t>(v43);
                  uint16_t v391 = static_cast<uint16_t>(v34);
                  TEXTRACT(v388, v350, v390, v391);
                  // pto: %7
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v392 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v34, v34);
                  // pto: %7
                  ;
                  uint64_t v393 = (uint64_t) v25;
                  TASSIGN(v392, v393);
                  uint16_t v394 = static_cast<uint16_t>(v34);
                  uint16_t v395 = static_cast<uint16_t>(v43);
                  TEXTRACT(v392, v365, v394, v395);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
                  // pto: %223
                  ;
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
                  if (v345 == v43) {
                    pipe_barrier(PIPE_M);
                    TMATMUL(v343, v380, v384);
                  } else {
                    pipe_barrier(PIPE_M);
                    TMATMUL_ACC(v343, v343, v380, v384);
                  };
                  pipe_barrier(PIPE_M);
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
                  TMATMUL_ACC(v343, v343, v388, v392);
                } else {
                  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
                  for (int64_t v396 = v43; v396 < v31; v396 += v27) {
                    // pto: %224, %225
                    ;
                    int64_t v397 = (int64_t) ((uint64_t) v348 + (uint64_t) v396) % v30;
                    // pto: %226, %227, %228
                    ;
                    int64_t v398 = v397 < v43 ? (int64_t) ((uint64_t) v397 + (uint64_t) v30) : v397;
                    // pto: %229
                    ;
                    int64_t v399 = (int64_t) ((uint64_t) v398 * (uint64_t) v31);
                    // pto: %seed_narrow_wrap_x__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v400 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v339, v31);
                    // pto: %seed_narrow_wrap_x__tile
                    ;
                    uint64_t v401 = (uint64_t) v24;
                    TASSIGN(v400, v401);
                    // pto: %230
                    ;
                    int64_t v402 = v337 < v43 ? v43 : v337;
                    // pto: %231, %232
                    ;
                    int64_t v403 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v134 * (uint64_t) v39) + (uint64_t) v399);
                    // pto: %233
                    ;
                    int64_t v404 = v403 < v43 ? v43 : v403;
                    // pto: %234
                    ;
                    const int64_t v405 = 0;
                    // pto: %234
                    ;
                    __gm__ bfloat16_t* v406 = PTOAS__GLOBAL_TENSOR_DATA(v68);
                    // pto: %234
                    ;
                    const int64_t v407 = 1;
                    // pto: %234
                    ;
                    const int64_t v408 = 1;
                    // pto: %234
                    ;
                    const int64_t v409 = 1;
                    // pto: %234
                    ;
                    int64_t v410 = v339 * v26;
                    // pto: %234
                    ;
                    int64_t v411 = v409 * v410;
                    // pto: %234
                    ;
                    pto::Shape<1, 1, 1, -1, 16> v412 = pto::Shape<1, 1, 1, -1, 16>(v407, v408, v409, v339, v31);
                    // pto: %234
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v413 = pto::Stride<-1, -1, -1, -1, -1>(v408 * v411, v411, v410, v26, v27);
                    // pto: %234
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v414 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v406 + (v405 + v402 * v26 + v404 * v27), v412, v413);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
                    TLOAD(v400, v414);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    // pto: %seed_narrow_wrap_w__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v415 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v31, v34);
                    // pto: %seed_narrow_wrap_w__tile
                    ;
                    uint64_t v416 = (uint64_t) v23;
                    TASSIGN(v415, v416);
                    // pto: %235
                    ;
                    int64_t v417 = v134 < v43 ? v43 : v134;
                    // pto: %236
                    ;
                    int64_t v418 = v137 / v31;
                    // pto: %237
                    ;
                    int64_t v419 = v418 < v43 ? v43 : v418;
                    // pto: %238
                    ;
                    int64_t v420 = v399 / v31;
                    // pto: %239
                    ;
                    int64_t v421 = v420 < v43 ? v43 : v420;
                    // pto: %240
                    ;
                    __gm__ bfloat16_t* v422 = PTOAS__GLOBAL_TENSOR_DATA(v71);
                    // pto: %240
                    ;
                    const int64_t v423 = 0;
                    // pto: %240
                    ;
                    const int64_t v424 = 4194304;
                    // pto: %240
                    ;
                    const int64_t v425 = 65536;
                    // pto: %240
                    ;
                    const int64_t v426 = 256;
                    // pto: %240
                    ;
                    pto::Shape<1, 8, 1, 16, 16> v427 = pto::Shape<1, 8, 1, 16, 16>();
                    // pto: %240
                    ;
                    pto::Stride<4194304, 65536, 256, 16, 1> v428 = pto::Stride<4194304, 65536, 256, 16, 1>();
                    // pto: %240
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v429 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v422 + ((v423 + v417 * v424) + v419 * v425 + v421 * v426), v427, v428);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
                    TLOAD(v415, v429);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    // pto: %9
                    ;
                    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v430 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v339, v31);
                    // pto: %9
                    ;
                    uint64_t v431 = (uint64_t) v23;
                    TASSIGN(v430, v431);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
                    uint16_t v432 = static_cast<uint16_t>(v43);
                    uint16_t v433 = static_cast<uint16_t>(v43);
                    TEXTRACT(v430, v400, v432, v433);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
                    // pto: %10
                    ;
                    Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v434 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v31, v34);
                    // pto: %10
                    ;
                    uint64_t v435 = (uint64_t) v23;
                    TASSIGN(v434, v435);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    uint16_t v436 = static_cast<uint16_t>(v43);
                    uint16_t v437 = static_cast<uint16_t>(v43);
                    TEXTRACT(v434, v415, v436, v437);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
                    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
                    // pto: %242, %243
                    ;
                    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
                    if ((int64_t) ((uint64_t) v346 + (uint64_t) v396) == v43) {
                      pipe_barrier(PIPE_M);
                      TMATMUL(v343, v430, v434);
                    } else {
                      pipe_barrier(PIPE_M);
                      TMATMUL_ACC(v343, v343, v430, v434);
                    };
                    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
                  };
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
                  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
              };
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
              set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
              // pto: %244
              ;
              int64_t v438 = v337 < v43 ? v43 : v337;
              // pto: %245, %246
              ;
              int64_t v439 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v134 * (uint64_t) v53) + (uint64_t) v137);
              // pto: %247
              ;
              int64_t v440 = v439 < v43 ? v43 : v439;
              // pto: %248
              ;
              __gm__ float* v441 = PTOAS__GLOBAL_TENSOR_DATA(v92);
              // pto: %248
              ;
              const int64_t v442 = 0;
              // pto: %248
              ;
              const int64_t v443 = 8192;
              // pto: %248
              ;
              pto::Shape<1, 1, 1, 16, 128> v444 = pto::Shape<1, 1, 1, 16, 128>();
              // pto: %248
              ;
              pto::Stride<131072, 131072, 131072, 8192, 1> v445 = pto::Stride<131072, 131072, 131072, 8192, 1>();
              // pto: %248
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v446 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v441 + (v442 + v438 * v443 + v440), v444, v445);
              wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
              pipe_barrier(PIPE_FIX);
              TSTORE(v446, v343);
              set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
            };
          };
        };
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    };
  } else {
    for (int64_t v447 = v120; v447 < v29; v447 += v46) {
      // pto: %250
      ;
      int64_t v448 = v447 / v28;
      // pto: %251
      ;
      int64_t v449 = v447 % v28;
      // pto: %252, %253, %254
      ;
      int64_t v450 = v449 < v43 ? (int64_t) ((uint64_t) v449 + (uint64_t) v28) : v449;
      // pto: %255
      ;
      int64_t v451 = (int64_t) ((uint64_t) v450 * (uint64_t) v34);
      // pto: %256, %257
      ;
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      for (int64_t v452 = v43; v452 < ((int64_t) ((uint64_t) v132 + (uint64_t) v47) / v28); v452 += v27) {
        // pto: %258
        ;
        int64_t v453 = (int64_t) ((uint64_t) v452 * (uint64_t) v28);
        // pto: %261, %262, %263, %259
        ;
        int32_t v454 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v452 * (uint64_t) v29) + (uint64_t) v448) * (uint64_t) v28) + (uint64_t) v450)];
        // pto: %264
        ;
        int64_t v455 = (int64_t) v454;
        // pto: %265
        ;
        int64_t v456 = v455 < v43 ? v43 : v455;
        // pto: %266
        ;
        int64_t v457 = (int64_t) ((uint64_t) v453 + (uint64_t) v27);
        // pto: %267
        ;
        // pto: %v4_same_start__phi_v3
        ;
        int64_t v458;
        if (v457 < v132) {
          // pto: %270, %271, %272, %273, %268
          ;
          int32_t v459 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v457 * (uint64_t) v28) + (uint64_t) v448) * (uint64_t) v28) + (uint64_t) v450)];
          // pto: %274
          ;
          int64_t v460 = (int64_t) v459;
          // pto: %275
          ;
          int64_t v461 = v460 < v43 ? v43 : v460;
          // pto: %276, %v4_same_start__phi_v2
          ;
          v458 = v461 != v456 ? v43 : v27;
        } else {
          v458 = v27;
        };
        // pto: %277
        ;
        int64_t v462 = (int64_t) ((uint64_t) v453 + (uint64_t) v48);
        // pto: %278
        ;
        // pto: %v4_same_start__phi_v6
        ;
        int64_t v463;
        if (v462 < v132) {
          // pto: %281, %282, %283, %284, %279
          ;
          int32_t v464 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v462 * (uint64_t) v28) + (uint64_t) v448) * (uint64_t) v28) + (uint64_t) v450)];
          // pto: %285
          ;
          int64_t v465 = (int64_t) v464;
          // pto: %286
          ;
          int64_t v466 = v465 < v43 ? v43 : v465;
          // pto: %287, %v4_same_start__phi_v5
          ;
          int64_t v467 = v466 != v456 ? v43 : v458;
          v463 = v467;
        } else {
          v463 = v458;
        };
        // pto: %288
        ;
        int64_t v468 = (int64_t) ((uint64_t) v453 + (uint64_t) v49);
        // pto: %289
        ;
        // pto: %v4_same_start__phi_v9
        ;
        int64_t v469;
        if (v468 < v132) {
          // pto: %292, %293, %294, %295, %290
          ;
          int32_t v470 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v468 * (uint64_t) v28) + (uint64_t) v448) * (uint64_t) v28) + (uint64_t) v450)];
          // pto: %296
          ;
          int64_t v471 = (int64_t) v470;
          // pto: %297
          ;
          int64_t v472 = v471 < v43 ? v43 : v471;
          // pto: %298, %v4_same_start__phi_v8
          ;
          int64_t v473 = v472 != v456 ? v43 : v463;
          v469 = v473;
        } else {
          v469 = v463;
        };
        // pto: %299
        ;
        int64_t v474 = (int64_t) ((uint64_t) v453 + (uint64_t) v41);
        // pto: %300
        ;
        // pto: %v4_same_start__phi_v12
        ;
        int64_t v475;
        if (v474 < v132) {
          // pto: %303, %304, %305, %306, %301
          ;
          int32_t v476 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v474 * (uint64_t) v28) + (uint64_t) v448) * (uint64_t) v28) + (uint64_t) v450)];
          // pto: %307
          ;
          int64_t v477 = (int64_t) v476;
          // pto: %308
          ;
          int64_t v478 = v477 < v43 ? v43 : v477;
          // pto: %309, %v4_same_start__phi_v11
          ;
          int64_t v479 = v478 != v456 ? v43 : v469;
          v475 = v479;
        } else {
          v475 = v469;
        };
        // pto: %310
        ;
        int64_t v480 = (int64_t) ((uint64_t) v453 + (uint64_t) v50);
        // pto: %311
        ;
        // pto: %v4_same_start__phi_v15
        ;
        int64_t v481;
        if (v480 < v132) {
          // pto: %314, %315, %316, %317, %312
          ;
          int32_t v482 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v480 * (uint64_t) v28) + (uint64_t) v448) * (uint64_t) v28) + (uint64_t) v450)];
          // pto: %318
          ;
          int64_t v483 = (int64_t) v482;
          // pto: %319
          ;
          int64_t v484 = v483 < v43 ? v43 : v483;
          // pto: %320, %v4_same_start__phi_v14
          ;
          int64_t v485 = v484 != v456 ? v43 : v475;
          v481 = v485;
        } else {
          v481 = v475;
        };
        // pto: %321
        ;
        int64_t v486 = (int64_t) ((uint64_t) v453 + (uint64_t) v51);
        // pto: %322
        ;
        // pto: %v4_same_start__phi_v18
        ;
        int64_t v487;
        if (v486 < v132) {
          // pto: %325, %326, %327, %328, %323
          ;
          int32_t v488 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v486 * (uint64_t) v28) + (uint64_t) v448) * (uint64_t) v28) + (uint64_t) v450)];
          // pto: %329
          ;
          int64_t v489 = (int64_t) v488;
          // pto: %330
          ;
          int64_t v490 = v489 < v43 ? v43 : v489;
          // pto: %331, %v4_same_start__phi_v17
          ;
          int64_t v491 = v490 != v456 ? v43 : v481;
          v487 = v491;
        } else {
          v487 = v481;
        };
        // pto: %332
        ;
        int64_t v492 = (int64_t) ((uint64_t) v453 + (uint64_t) v47);
        // pto: %333
        ;
        // pto: %v4_same_start__phi_v21
        ;
        int64_t v493;
        if (v492 < v132) {
          // pto: %336, %337, %338, %339, %334
          ;
          int32_t v494 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v492 * (uint64_t) v28) + (uint64_t) v448) * (uint64_t) v28) + (uint64_t) v450)];
          // pto: %340
          ;
          int64_t v495 = (int64_t) v494;
          // pto: %341
          ;
          int64_t v496 = v495 < v43 ? v43 : v495;
          // pto: %342, %v4_same_start__phi_v20
          ;
          int64_t v497 = v496 != v456 ? v43 : v487;
          v493 = v497;
        } else {
          v493 = v487;
        };
        // pto: %343, %v4_same_start__phi_v23
        ;
        int64_t v498 = v17 <= v31 ? v43 : v493;
        // pto: %344
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        if (v498 == v27) {
          int64_t v499 = (int64_t) ((uint64_t) v452 * (uint64_t) v34);
          // pto: %346
          ;
          int64_t v500 = (int64_t) ((uint64_t) v17 - (uint64_t) v499);
          // pto: %347
          ;
          int64_t v501 = v500 < v34 ? v500 : v34;
          // pto: %348
          ;
          int64_t v502 = v456 % v30;
          // pto: %349, %350, %351
          ;
          int64_t v503 = v502 < v43 ? (int64_t) ((uint64_t) v502 + (uint64_t) v30) : v502;
          // pto: %352
          ;
          int64_t v504 = (int64_t) ((uint64_t) v503 * (uint64_t) v31);
          // pto: %v4_wide_seed_x__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v505 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v501, v31);
          // pto: %v4_wide_seed_x__tile
          ;
          uint64_t v506 = (uint64_t) v23;
          TASSIGN(v505, v506);
          // pto: %353
          ;
          int64_t v507 = v499 < v43 ? v43 : v499;
          // pto: %354
          ;
          int64_t v508 = (int64_t) ((uint64_t) v448 * (uint64_t) v39);
          // pto: %355
          ;
          int64_t v509 = (int64_t) ((uint64_t) v508 + (uint64_t) v504);
          // pto: %356
          ;
          int64_t v510 = v509 < v43 ? v43 : v509;
          // pto: %357
          ;
          const int64_t v511 = 0;
          // pto: %357
          ;
          __gm__ bfloat16_t* v512 = PTOAS__GLOBAL_TENSOR_DATA(v68);
          // pto: %357
          ;
          const int64_t v513 = 1;
          // pto: %357
          ;
          const int64_t v514 = 1;
          // pto: %357
          ;
          const int64_t v515 = 1;
          // pto: %357
          ;
          int64_t v516 = v501 * v26;
          // pto: %357
          ;
          int64_t v517 = v515 * v516;
          // pto: %357
          ;
          pto::Shape<1, 1, 1, -1, 16> v518 = pto::Shape<1, 1, 1, -1, 16>(v513, v514, v515, v501, v31);
          // pto: %357
          ;
          pto::Stride<-1, -1, -1, -1, -1> v519 = pto::Stride<-1, -1, -1, -1, -1>(v514 * v517, v517, v516, v26, v27);
          // pto: %357
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v520 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v512 + (v511 + v507 * v26 + v510 * v27), v518, v519);
          TLOAD(v505, v520);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %v4_wide_seed_w__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v521 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v31, v34);
          // pto: %v4_wide_seed_w__tile
          ;
          uint64_t v522 = (uint64_t) v24;
          TASSIGN(v521, v522);
          // pto: %358
          ;
          int64_t v523 = v448 < v43 ? v43 : v448;
          // pto: %359
          ;
          int64_t v524 = v451 / v31;
          // pto: %360
          ;
          int64_t v525 = v524 < v43 ? v43 : v524;
          // pto: %361
          ;
          int64_t v526 = v504 / v31;
          // pto: %362
          ;
          int64_t v527 = v526 < v43 ? v43 : v526;
          // pto: %363
          ;
          __gm__ bfloat16_t* v528 = PTOAS__GLOBAL_TENSOR_DATA(v71);
          // pto: %363
          ;
          const int64_t v529 = 0;
          // pto: %363
          ;
          const int64_t v530 = 4194304;
          // pto: %363
          ;
          const int64_t v531 = 65536;
          // pto: %363
          ;
          const int64_t v532 = 256;
          // pto: %363
          ;
          pto::Shape<1, 8, 1, 16, 16> v533 = pto::Shape<1, 8, 1, 16, 16>();
          // pto: %363
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v534 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %363
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v535 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v528 + ((v529 + v523 * v530) + v525 * v531 + v527 * v532), v533, v534);
          TLOAD(v521, v535);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %11
          ;
          Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v536 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v501, v31);
          // pto: %11
          ;
          uint64_t v537 = (uint64_t) v23;
          TASSIGN(v536, v537);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          uint16_t v538 = static_cast<uint16_t>(v43);
          uint16_t v539 = static_cast<uint16_t>(v43);
          TEXTRACT(v536, v505, v538, v539);
          // pto: %12
          ;
          Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v540 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v31, v34);
          // pto: %12
          ;
          uint64_t v541 = (uint64_t) v23;
          TASSIGN(v540, v541);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          uint16_t v542 = static_cast<uint16_t>(v43);
          uint16_t v543 = static_cast<uint16_t>(v43);
          TEXTRACT(v540, v521, v542, v543);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %v4_wide_acc__tile
          ;
          Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v544 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v501, v34);
          // pto: %v4_wide_acc__tile
          ;
          uint64_t v545 = (uint64_t) v23;
          TASSIGN(v544, v545);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          TMATMUL(v544, v536, v540);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
          for (int64_t v546 = v43; v546 < v44; v546 += v27) {
            // pto: %365, %364, %366, %367
            ;
            int64_t v547 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v456 + (uint64_t) ((int64_t) (uint64_t) v546 * (uint64_t) v31)) + (uint64_t) v27) % v30;
            // pto: %368, %369, %370
            ;
            int64_t v548 = v547 < v43 ? (int64_t) ((uint64_t) v547 + (uint64_t) v30) : v547;
            // pto: %371
            ;
            // pto: %372
            ;
            int64_t v549 = v501 < v34 ? v501 : v34;
            v116.SetValidShape(v549, v34);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
            if (v548 <= v52) {
              // pto: %373
              ;
              int64_t v550 = (int64_t) ((uint64_t) v548 * (uint64_t) v31);
              // pto: %v4_wide_packet_x__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v551 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v501, v30);
              // pto: %v4_wide_packet_x__tile
              ;
              uint64_t v552 = (uint64_t) v23;
              TASSIGN(v551, v552);
              // pto: %376
              ;
              int64_t v553 = (int64_t) ((uint64_t) v508 + (uint64_t) v550);
              // pto: %377
              ;
              int64_t v554 = v553 < v43 ? v43 : v553;
              // pto: %378
              ;
              const int64_t v555 = 0;
              // pto: %378
              ;
              __gm__ bfloat16_t* v556 = PTOAS__GLOBAL_TENSOR_DATA(v68);
              // pto: %378
              ;
              const int64_t v557 = 1;
              // pto: %378
              ;
              const int64_t v558 = 1;
              // pto: %378
              ;
              const int64_t v559 = 1;
              // pto: %378
              ;
              int64_t v560 = v501 * v26;
              // pto: %378
              ;
              int64_t v561 = v559 * v560;
              // pto: %378
              ;
              pto::Shape<1, 1, 1, -1, 256> v562 = pto::Shape<1, 1, 1, -1, 256>(v557, v558, v559, v501, v30);
              // pto: %378
              ;
              pto::Stride<-1, -1, -1, -1, -1> v563 = pto::Stride<-1, -1, -1, -1, -1>(v558 * v561, v561, v560, v26, v27);
              // pto: %378
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v564 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v556 + (v555 + v507 * v26 + v554 * v27), v562, v563);
              TLOAD(v551, v564);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              // pto: %v4_wide_packet_w__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v565 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v30, v34);
              // pto: %v4_wide_packet_w__tile
              ;
              uint64_t v566 = (uint64_t) v24;
              TASSIGN(v565, v566);
              // pto: %382
              ;
              int64_t v567 = v550 / v31;
              // pto: %383
              ;
              int64_t v568 = v567 < v43 ? v43 : v567;
              // pto: %384
              ;
              __gm__ bfloat16_t* v569 = PTOAS__GLOBAL_TENSOR_DATA(v71);
              // pto: %384
              ;
              const int64_t v570 = 0;
              // pto: %384
              ;
              const int64_t v571 = 4194304;
              // pto: %384
              ;
              const int64_t v572 = 65536;
              // pto: %384
              ;
              const int64_t v573 = 256;
              // pto: %384
              ;
              pto::Shape<1, 8, 16, 16, 16> v574 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %384
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v575 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %384
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v576 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v569 + ((v570 + v523 * v571) + v525 * v572 + v568 * v573), v574, v575);
              TLOAD(v565, v576);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              // pto: %v4_wide_acc__iter_v1_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v577 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v501, v34);
              // pto: %v4_wide_acc__iter_v1_l0_a
              ;
              uint64_t v578 = (uint64_t) v23;
              TASSIGN(v577, v578);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              uint16_t v579 = static_cast<uint16_t>(v43);
              uint16_t v580 = static_cast<uint16_t>(v43);
              TEXTRACT(v577, v551, v579, v580);
              // pto: %v4_wide_acc__iter_v1_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v581 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v34, v34);
              // pto: %v4_wide_acc__iter_v1_l0_b
              ;
              uint64_t v582 = (uint64_t) v23;
              TASSIGN(v581, v582);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              uint16_t v583 = static_cast<uint16_t>(v43);
              uint16_t v584 = static_cast<uint16_t>(v43);
              TEXTRACT(v581, v565, v583, v584);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              // pto: %13
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v585 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v501, v34);
              // pto: %13
              ;
              uint64_t v586 = (uint64_t) v25;
              TASSIGN(v585, v586);
              uint16_t v587 = static_cast<uint16_t>(v43);
              uint16_t v588 = static_cast<uint16_t>(v34);
              TEXTRACT(v585, v551, v587, v588);
              // pto: %14
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v589 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v34, v34);
              // pto: %14
              ;
              uint64_t v590 = (uint64_t) v25;
              TASSIGN(v589, v590);
              uint16_t v591 = static_cast<uint16_t>(v34);
              uint16_t v592 = static_cast<uint16_t>(v43);
              TEXTRACT(v589, v565, v591, v592);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v544, v544, v577, v581);
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              TMATMUL_ACC(v544, v544, v585, v589);
            } else {
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              for (int64_t v593 = v43; v593 < v31; v593 += v27) {
                // pto: %385, %386
                ;
                int64_t v594 = (int64_t) ((uint64_t) v548 + (uint64_t) v593) % v30;
                // pto: %387, %388, %389
                ;
                int64_t v595 = v594 < v43 ? (int64_t) ((uint64_t) v594 + (uint64_t) v30) : v594;
                // pto: %390
                ;
                int64_t v596 = (int64_t) ((uint64_t) v595 * (uint64_t) v31);
                // pto: %v4_wide_wrap_x__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v597 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v501, v31);
                // pto: %v4_wide_wrap_x__tile
                ;
                uint64_t v598 = (uint64_t) v23;
                TASSIGN(v597, v598);
                // pto: %393
                ;
                int64_t v599 = (int64_t) ((uint64_t) v508 + (uint64_t) v596);
                // pto: %394
                ;
                int64_t v600 = v599 < v43 ? v43 : v599;
                // pto: %395
                ;
                const int64_t v601 = 0;
                // pto: %395
                ;
                __gm__ bfloat16_t* v602 = PTOAS__GLOBAL_TENSOR_DATA(v68);
                // pto: %395
                ;
                const int64_t v603 = 1;
                // pto: %395
                ;
                const int64_t v604 = 1;
                // pto: %395
                ;
                const int64_t v605 = 1;
                // pto: %395
                ;
                int64_t v606 = v501 * v26;
                // pto: %395
                ;
                int64_t v607 = v605 * v606;
                // pto: %395
                ;
                pto::Shape<1, 1, 1, -1, 16> v608 = pto::Shape<1, 1, 1, -1, 16>(v603, v604, v605, v501, v31);
                // pto: %395
                ;
                pto::Stride<-1, -1, -1, -1, -1> v609 = pto::Stride<-1, -1, -1, -1, -1>(v604 * v607, v607, v606, v26, v27);
                // pto: %395
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v610 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v602 + (v601 + v507 * v26 + v600 * v27), v608, v609);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                TLOAD(v597, v610);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                // pto: %v4_wide_wrap_w__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v611 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v31, v34);
                // pto: %v4_wide_wrap_w__tile
                ;
                uint64_t v612 = (uint64_t) v24;
                TASSIGN(v611, v612);
                // pto: %399
                ;
                int64_t v613 = v596 / v31;
                // pto: %400
                ;
                int64_t v614 = v613 < v43 ? v43 : v613;
                // pto: %401
                ;
                __gm__ bfloat16_t* v615 = PTOAS__GLOBAL_TENSOR_DATA(v71);
                // pto: %401
                ;
                const int64_t v616 = 0;
                // pto: %401
                ;
                const int64_t v617 = 4194304;
                // pto: %401
                ;
                const int64_t v618 = 65536;
                // pto: %401
                ;
                const int64_t v619 = 256;
                // pto: %401
                ;
                pto::Shape<1, 8, 1, 16, 16> v620 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %401
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v621 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %401
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v622 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v615 + ((v616 + v523 * v617) + v525 * v618 + v614 * v619), v620, v621);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                TLOAD(v611, v622);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                // pto: %16
                ;
                Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v623 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v501, v31);
                // pto: %16
                ;
                uint64_t v624 = (uint64_t) v23;
                TASSIGN(v623, v624);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                uint16_t v625 = static_cast<uint16_t>(v43);
                uint16_t v626 = static_cast<uint16_t>(v43);
                TEXTRACT(v623, v597, v625, v626);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                // pto: %17
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v627 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v31, v34);
                // pto: %17
                ;
                uint64_t v628 = (uint64_t) v23;
                TASSIGN(v627, v628);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                uint16_t v629 = static_cast<uint16_t>(v43);
                uint16_t v630 = static_cast<uint16_t>(v43);
                TEXTRACT(v627, v611, v629, v630);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v544, v544, v623, v627);
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            };
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
          for (int64_t v631 = v54; v631 < v30; v631 += v27) {
            // pto: %402, %403
            ;
            int64_t v632 = (int64_t) ((uint64_t) v456 + (uint64_t) v631) % v30;
            // pto: %404, %405, %406
            ;
            int64_t v633 = v632 < v43 ? (int64_t) ((uint64_t) v632 + (uint64_t) v30) : v632;
            // pto: %407
            ;
            int64_t v634 = (int64_t) ((uint64_t) v633 * (uint64_t) v31);
            // pto: %v4_wide_tail_x__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v635 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v501, v31);
            // pto: %v4_wide_tail_x__tile
            ;
            uint64_t v636 = (uint64_t) v23;
            TASSIGN(v635, v636);
            // pto: %410
            ;
            int64_t v637 = (int64_t) ((uint64_t) v508 + (uint64_t) v634);
            // pto: %411
            ;
            int64_t v638 = v637 < v43 ? v43 : v637;
            // pto: %412
            ;
            const int64_t v639 = 0;
            // pto: %412
            ;
            __gm__ bfloat16_t* v640 = PTOAS__GLOBAL_TENSOR_DATA(v68);
            // pto: %412
            ;
            const int64_t v641 = 1;
            // pto: %412
            ;
            const int64_t v642 = 1;
            // pto: %412
            ;
            const int64_t v643 = 1;
            // pto: %412
            ;
            int64_t v644 = v501 * v26;
            // pto: %412
            ;
            int64_t v645 = v643 * v644;
            // pto: %412
            ;
            pto::Shape<1, 1, 1, -1, 16> v646 = pto::Shape<1, 1, 1, -1, 16>(v641, v642, v643, v501, v31);
            // pto: %412
            ;
            pto::Stride<-1, -1, -1, -1, -1> v647 = pto::Stride<-1, -1, -1, -1, -1>(v642 * v645, v645, v644, v26, v27);
            // pto: %412
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v648 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v640 + (v639 + v507 * v26 + v638 * v27), v646, v647);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            TLOAD(v635, v648);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %v4_wide_tail_w__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v649 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v31, v34);
            // pto: %v4_wide_tail_w__tile
            ;
            uint64_t v650 = (uint64_t) v24;
            TASSIGN(v649, v650);
            // pto: %416
            ;
            int64_t v651 = v634 / v31;
            // pto: %417
            ;
            int64_t v652 = v651 < v43 ? v43 : v651;
            // pto: %418
            ;
            __gm__ bfloat16_t* v653 = PTOAS__GLOBAL_TENSOR_DATA(v71);
            // pto: %418
            ;
            const int64_t v654 = 0;
            // pto: %418
            ;
            const int64_t v655 = 4194304;
            // pto: %418
            ;
            const int64_t v656 = 65536;
            // pto: %418
            ;
            const int64_t v657 = 256;
            // pto: %418
            ;
            pto::Shape<1, 8, 1, 16, 16> v658 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %418
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v659 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %418
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v660 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v653 + ((v654 + v523 * v655) + v525 * v656 + v652 * v657), v658, v659);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            TLOAD(v649, v660);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %18
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v661 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v501, v31);
            // pto: %18
            ;
            uint64_t v662 = (uint64_t) v23;
            TASSIGN(v661, v662);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
            uint16_t v663 = static_cast<uint16_t>(v43);
            uint16_t v664 = static_cast<uint16_t>(v43);
            TEXTRACT(v661, v635, v663, v664);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            // pto: %19
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v665 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v31, v34);
            // pto: %19
            ;
            uint64_t v666 = (uint64_t) v23;
            TASSIGN(v665, v666);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            uint16_t v667 = static_cast<uint16_t>(v43);
            uint16_t v668 = static_cast<uint16_t>(v43);
            TEXTRACT(v665, v649, v667, v668);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v544, v544, v661, v665);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
          // pto: %420, %421
          ;
          int64_t v669 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v448 * (uint64_t) v53) + (uint64_t) v451);
          // pto: %422
          ;
          int64_t v670 = v669 < v43 ? v43 : v669;
          // pto: %423
          ;
          const int64_t v671 = 0;
          // pto: %423
          ;
          __gm__ float* v672 = PTOAS__GLOBAL_TENSOR_DATA(v92);
          // pto: %423
          ;
          const int64_t v673 = 1;
          // pto: %423
          ;
          const int64_t v674 = 1;
          // pto: %423
          ;
          const int64_t v675 = 1;
          // pto: %423
          ;
          int64_t v676 = v501 * v40;
          // pto: %423
          ;
          int64_t v677 = v675 * v676;
          // pto: %423
          ;
          pto::Shape<1, 1, 1, -1, 128> v678 = pto::Shape<1, 1, 1, -1, 128>(v673, v674, v675, v501, v34);
          // pto: %423
          ;
          pto::Stride<-1, -1, -1, -1, -1> v679 = pto::Stride<-1, -1, -1, -1, -1>(v674 * v677, v677, v676, v40, v27);
          // pto: %423
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v680 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v672 + (v671 + v507 * v40 + v670 * v27), v678, v679);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
          TSTORE(v680, v544);
        } else {
          for (int64_t v681 = v43; v681 < v28; v681 += v27) {
            // pto: %424
            ;
            int64_t v682 = (int64_t) ((uint64_t) v453 + (uint64_t) v681);
            // pto: %425
            ;
            if (v682 < v132) {
              // pto: %426
              ;
              int64_t v683 = (int64_t) ((uint64_t) v682 * (uint64_t) v31);
              // pto: %427
              ;
              int64_t v684 = (int64_t) ((uint64_t) v17 - (uint64_t) v683);
              // pto: %428
              ;
              int64_t v685 = v684 < v31 ? v684 : v31;
              // pto: %430, %431, %432, %433, %429
              ;
              int32_t v686 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v682 * (uint64_t) v28) + (uint64_t) v448) * (uint64_t) v28) + (uint64_t) v450)];
              // pto: %434
              ;
              int64_t v687 = (int64_t) v686;
              // pto: %435
              ;
              int64_t v688 = v687 < v43 ? v43 : v687;
              // pto: %v4_narrow_acc__tile
              ;
              Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v689 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v31, v34);
              // pto: %v4_narrow_acc__tile
              ;
              uint64_t v690 = (uint64_t) v23;
              TASSIGN(v689, v690);
              wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
              for (int64_t v691 = v43; v691 < v31; v691 += v27) {
                // pto: %436
                ;
                int64_t v692 = (int64_t) ((uint64_t) v691 * (uint64_t) v31);
                // pto: %437, %438
                ;
                int64_t v693 = (int64_t) ((uint64_t) v688 + (uint64_t) v692) % v30;
                // pto: %439, %440, %441
                ;
                int64_t v694 = v693 < v43 ? (int64_t) ((uint64_t) v693 + (uint64_t) v30) : v693;
                // pto: %442
                ;
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
                if (v694 <= v52) {
                  // pto: %443
                  ;
                  int64_t v695 = (int64_t) ((uint64_t) v694 * (uint64_t) v31);
                  // pto: %v4_narrow_packet_x__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v696 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v685, v30);
                  // pto: %v4_narrow_packet_x__tile
                  ;
                  uint64_t v697 = (uint64_t) v24;
                  TASSIGN(v696, v697);
                  // pto: %444
                  ;
                  int64_t v698 = v683 < v43 ? v43 : v683;
                  // pto: %445, %446
                  ;
                  int64_t v699 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v448 * (uint64_t) v39) + (uint64_t) v695);
                  // pto: %447
                  ;
                  int64_t v700 = v699 < v43 ? v43 : v699;
                  // pto: %448
                  ;
                  const int64_t v701 = 0;
                  // pto: %448
                  ;
                  __gm__ bfloat16_t* v702 = PTOAS__GLOBAL_TENSOR_DATA(v68);
                  // pto: %448
                  ;
                  const int64_t v703 = 1;
                  // pto: %448
                  ;
                  const int64_t v704 = 1;
                  // pto: %448
                  ;
                  const int64_t v705 = 1;
                  // pto: %448
                  ;
                  int64_t v706 = v685 * v26;
                  // pto: %448
                  ;
                  int64_t v707 = v705 * v706;
                  // pto: %448
                  ;
                  pto::Shape<1, 1, 1, -1, 256> v708 = pto::Shape<1, 1, 1, -1, 256>(v703, v704, v705, v685, v30);
                  // pto: %448
                  ;
                  pto::Stride<-1, -1, -1, -1, -1> v709 = pto::Stride<-1, -1, -1, -1, -1>(v704 * v707, v707, v706, v26, v27);
                  // pto: %448
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v710 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v702 + (v701 + v698 * v26 + v700 * v27), v708, v709);
                  TLOAD(v696, v710);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  // pto: %v4_narrow_packet_w__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v711 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v30, v34);
                  // pto: %v4_narrow_packet_w__tile
                  ;
                  uint64_t v712 = (uint64_t) v23;
                  TASSIGN(v711, v712);
                  // pto: %449
                  ;
                  int64_t v713 = v448 < v43 ? v43 : v448;
                  // pto: %450
                  ;
                  int64_t v714 = v451 / v31;
                  // pto: %451
                  ;
                  int64_t v715 = v714 < v43 ? v43 : v714;
                  // pto: %452
                  ;
                  int64_t v716 = v695 / v31;
                  // pto: %453
                  ;
                  int64_t v717 = v716 < v43 ? v43 : v716;
                  // pto: %454
                  ;
                  __gm__ bfloat16_t* v718 = PTOAS__GLOBAL_TENSOR_DATA(v71);
                  // pto: %454
                  ;
                  const int64_t v719 = 0;
                  // pto: %454
                  ;
                  const int64_t v720 = 4194304;
                  // pto: %454
                  ;
                  const int64_t v721 = 65536;
                  // pto: %454
                  ;
                  const int64_t v722 = 256;
                  // pto: %454
                  ;
                  pto::Shape<1, 8, 16, 16, 16> v723 = pto::Shape<1, 8, 16, 16, 16>();
                  // pto: %454
                  ;
                  pto::Stride<4194304, 65536, 256, 16, 1> v724 = pto::Stride<4194304, 65536, 256, 16, 1>();
                  // pto: %454
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v725 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v718 + ((v719 + v713 * v720) + v715 * v721 + v717 * v722), v723, v724);
                  TLOAD(v711, v725);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  // pto: %v4_narrow_acc__iter_v1_l0_a
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v726 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v685, v34);
                  // pto: %v4_narrow_acc__iter_v1_l0_a
                  ;
                  uint64_t v727 = (uint64_t) v23;
                  TASSIGN(v726, v727);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  uint16_t v728 = static_cast<uint16_t>(v43);
                  uint16_t v729 = static_cast<uint16_t>(v43);
                  TEXTRACT(v726, v696, v728, v729);
                  // pto: %v4_narrow_acc__iter_v1_l0_b
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v730 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v34, v34);
                  // pto: %v4_narrow_acc__iter_v1_l0_b
                  ;
                  uint64_t v731 = (uint64_t) v23;
                  TASSIGN(v730, v731);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  uint16_t v732 = static_cast<uint16_t>(v43);
                  uint16_t v733 = static_cast<uint16_t>(v43);
                  TEXTRACT(v730, v711, v732, v733);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  // pto: %20
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v734 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v685, v34);
                  // pto: %20
                  ;
                  uint64_t v735 = (uint64_t) v25;
                  TASSIGN(v734, v735);
                  uint16_t v736 = static_cast<uint16_t>(v43);
                  uint16_t v737 = static_cast<uint16_t>(v34);
                  TEXTRACT(v734, v696, v736, v737);
                  // pto: %21
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v738 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v34, v34);
                  // pto: %21
                  ;
                  uint64_t v739 = (uint64_t) v25;
                  TASSIGN(v738, v739);
                  uint16_t v740 = static_cast<uint16_t>(v34);
                  uint16_t v741 = static_cast<uint16_t>(v43);
                  TEXTRACT(v738, v711, v740, v741);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  // pto: %455
                  ;
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  if (v691 == v43) {
                    pipe_barrier(PIPE_M);
                    TMATMUL(v689, v726, v730);
                  } else {
                    pipe_barrier(PIPE_M);
                    TMATMUL_ACC(v689, v689, v726, v730);
                  };
                  pipe_barrier(PIPE_M);
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  TMATMUL_ACC(v689, v689, v734, v738);
                } else {
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                  for (int64_t v742 = v43; v742 < v31; v742 += v27) {
                    // pto: %456, %457
                    ;
                    int64_t v743 = (int64_t) ((uint64_t) v694 + (uint64_t) v742) % v30;
                    // pto: %458, %459, %460
                    ;
                    int64_t v744 = v743 < v43 ? (int64_t) ((uint64_t) v743 + (uint64_t) v30) : v743;
                    // pto: %461
                    ;
                    int64_t v745 = (int64_t) ((uint64_t) v744 * (uint64_t) v31);
                    // pto: %v4_narrow_wrap_x__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v746 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v685, v31);
                    // pto: %v4_narrow_wrap_x__tile
                    ;
                    uint64_t v747 = (uint64_t) v24;
                    TASSIGN(v746, v747);
                    // pto: %462
                    ;
                    int64_t v748 = v683 < v43 ? v43 : v683;
                    // pto: %463, %464
                    ;
                    int64_t v749 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v448 * (uint64_t) v39) + (uint64_t) v745);
                    // pto: %465
                    ;
                    int64_t v750 = v749 < v43 ? v43 : v749;
                    // pto: %466
                    ;
                    const int64_t v751 = 0;
                    // pto: %466
                    ;
                    __gm__ bfloat16_t* v752 = PTOAS__GLOBAL_TENSOR_DATA(v68);
                    // pto: %466
                    ;
                    const int64_t v753 = 1;
                    // pto: %466
                    ;
                    const int64_t v754 = 1;
                    // pto: %466
                    ;
                    const int64_t v755 = 1;
                    // pto: %466
                    ;
                    int64_t v756 = v685 * v26;
                    // pto: %466
                    ;
                    int64_t v757 = v755 * v756;
                    // pto: %466
                    ;
                    pto::Shape<1, 1, 1, -1, 16> v758 = pto::Shape<1, 1, 1, -1, 16>(v753, v754, v755, v685, v31);
                    // pto: %466
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v759 = pto::Stride<-1, -1, -1, -1, -1>(v754 * v757, v757, v756, v26, v27);
                    // pto: %466
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v760 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v752 + (v751 + v748 * v26 + v750 * v27), v758, v759);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    TLOAD(v746, v760);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    // pto: %v4_narrow_wrap_w__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v761 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v31, v34);
                    // pto: %v4_narrow_wrap_w__tile
                    ;
                    uint64_t v762 = (uint64_t) v23;
                    TASSIGN(v761, v762);
                    // pto: %467
                    ;
                    int64_t v763 = v448 < v43 ? v43 : v448;
                    // pto: %468
                    ;
                    int64_t v764 = v451 / v31;
                    // pto: %469
                    ;
                    int64_t v765 = v764 < v43 ? v43 : v764;
                    // pto: %470
                    ;
                    int64_t v766 = v745 / v31;
                    // pto: %471
                    ;
                    int64_t v767 = v766 < v43 ? v43 : v766;
                    // pto: %472
                    ;
                    __gm__ bfloat16_t* v768 = PTOAS__GLOBAL_TENSOR_DATA(v71);
                    // pto: %472
                    ;
                    const int64_t v769 = 0;
                    // pto: %472
                    ;
                    const int64_t v770 = 4194304;
                    // pto: %472
                    ;
                    const int64_t v771 = 65536;
                    // pto: %472
                    ;
                    const int64_t v772 = 256;
                    // pto: %472
                    ;
                    pto::Shape<1, 8, 1, 16, 16> v773 = pto::Shape<1, 8, 1, 16, 16>();
                    // pto: %472
                    ;
                    pto::Stride<4194304, 65536, 256, 16, 1> v774 = pto::Stride<4194304, 65536, 256, 16, 1>();
                    // pto: %472
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v775 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v768 + ((v769 + v763 * v770) + v765 * v771 + v767 * v772), v773, v774);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                    TLOAD(v761, v775);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    // pto: %23
                    ;
                    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v776 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v685, v31);
                    // pto: %23
                    ;
                    uint64_t v777 = (uint64_t) v23;
                    TASSIGN(v776, v777);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                    uint16_t v778 = static_cast<uint16_t>(v43);
                    uint16_t v779 = static_cast<uint16_t>(v43);
                    TEXTRACT(v776, v746, v778, v779);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    // pto: %24
                    ;
                    Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v780 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v31, v34);
                    // pto: %24
                    ;
                    uint64_t v781 = (uint64_t) v23;
                    TASSIGN(v780, v781);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    uint16_t v782 = static_cast<uint16_t>(v43);
                    uint16_t v783 = static_cast<uint16_t>(v43);
                    TEXTRACT(v780, v761, v782, v783);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    // pto: %474, %475
                    ;
                    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    if ((int64_t) ((uint64_t) v692 + (uint64_t) v742) == v43) {
                      pipe_barrier(PIPE_M);
                      TMATMUL(v689, v776, v780);
                    } else {
                      pipe_barrier(PIPE_M);
                      TMATMUL_ACC(v689, v689, v776, v780);
                    };
                    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                  };
                  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
              // pto: %476
              ;
              int64_t v784 = v683 < v43 ? v43 : v683;
              // pto: %477, %478
              ;
              int64_t v785 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v448 * (uint64_t) v53) + (uint64_t) v451);
              // pto: %479
              ;
              int64_t v786 = v785 < v43 ? v43 : v785;
              // pto: %480
              ;
              __gm__ float* v787 = PTOAS__GLOBAL_TENSOR_DATA(v92);
              // pto: %480
              ;
              const int64_t v788 = 0;
              // pto: %480
              ;
              const int64_t v789 = 8192;
              // pto: %480
              ;
              pto::Shape<1, 1, 1, 16, 128> v790 = pto::Shape<1, 1, 1, 16, 128>();
              // pto: %480
              ;
              pto::Stride<131072, 131072, 131072, 8192, 1> v791 = pto::Stride<131072, 131072, 131072, 8192, 1>();
              // pto: %480
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v792 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v787 + (v788 + v784 * v789 + v786), v790, v791);
              wait_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
              pipe_barrier(PIPE_FIX);
              TSTORE(v792, v689);
              set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
            };
          };
        };
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    };
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %482
  int64_t v793 = (int64_t) ((uint64_t) v121 + (uint64_t) v55);
  // pto: %483
  int64_t v794 = v793 < v43 ? v43 : v793;
  // pto: %signals__ssa_v1_signal_pview
  __gm__ int32_t* v795 = PTOAS__GLOBAL_TENSOR_DATA(v111);
  // pto: %signals__ssa_v1_signal_pview
  const int64_t v796 = 0;
  // pto: %signals__ssa_v1_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v797 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v798 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v799 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v795 + (v796 + v794), v797, v798);
  pto::comm::NotifyOp v800 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v799, v130, v800);
  for (int64_t v801 = v46; v801 < v56; v801 += v27) {
    // pto: %484, %485
    ;
    int64_t v802 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v801 * (uint64_t) v34) + (uint64_t) v57);
    // pto: %486
    ;
    int64_t v803 = v802 < v43 ? v43 : v802;
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v804 = PTOAS__GLOBAL_TENSOR_DATA(v111);
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    const int64_t v805 = 0;
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v806 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v807 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v808 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v804 + (v805 + v803), v806, v807);
    pto::comm::WaitCmp v809 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v808, v130, v809);
  }
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %487
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
  if (v17 <= v31) {
    // pto: %488
    ;
    for (int64_t v810 = v120; v810 < ((int64_t) ((uint64_t) v132 * (uint64_t) v36)); v810 += v46) {
      // pto: %489, %490
      ;
      int64_t v811 = (int64_t) ((uint64_t) (v810 / v36) * (uint64_t) v31);
      // pto: %491
      ;
      int64_t v812 = v810 % v36;
      // pto: %492, %493, %494
      ;
      int64_t v813 = v812 < v43 ? (int64_t) ((uint64_t) v812 + (uint64_t) v36) : v812;
      // pto: %495
      ;
      int64_t v814 = (int64_t) ((uint64_t) v813 * (uint64_t) v34);
      // pto: %496
      ;
      int64_t v815 = (int64_t) ((uint64_t) v17 - (uint64_t) v811);
      // pto: %497
      ;
      int64_t v816 = v815 < v31 ? v815 : v31;
      // pto: %b_acc__tile
      ;
      Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v817 = Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v31, v34);
      // pto: %b_acc__tile
      ;
      uint64_t v818 = (uint64_t) v23;
      TASSIGN(v817, v818);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      for (int64_t v819 = v43; v819 < v31; v819 += v27) {
        // pto: %498
        ;
        int64_t v820 = (int64_t) ((uint64_t) v819 * (uint64_t) v35);
        // pto: %b_input__tile
        ;
        Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v821 = Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v816, v35);
        // pto: %b_input__tile
        ;
        uint64_t v822 = (uint64_t) v24;
        TASSIGN(v821, v822);
        // pto: %499
        ;
        int64_t v823 = v811 < v43 ? v43 : v811;
        // pto: %500
        ;
        int64_t v824 = v820 < v43 ? v43 : v820;
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v825 = 0;
        // pto: %quantized__ssa_v0_pview
        ;
        __gm__ int8_t* v826 = PTOAS__GLOBAL_TENSOR_DATA(v83);
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v827 = 1;
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v828 = 1;
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v829 = 1;
        // pto: %quantized__ssa_v0_pview
        ;
        int64_t v830 = v816 * v40;
        // pto: %quantized__ssa_v0_pview
        ;
        int64_t v831 = v829 * v830;
        // pto: %quantized__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 512> v832 = pto::Shape<1, 1, 1, -1, 512>(v827, v828, v829, v816, v35);
        // pto: %quantized__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v833 = pto::Stride<-1, -1, -1, -1, -1>(v828 * v831, v831, v830, v40, v27);
        // pto: %quantized__ssa_v0_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v834 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v826 + (v825 + v823 * v40 + v824 * v27), v832, v833);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        TLOAD(v821, v834);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %b_weight__tile
        ;
        Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v835 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v35, v34);
        // pto: %b_weight__tile
        ;
        uint64_t v836 = (uint64_t) v23;
        TASSIGN(v835, v836);
        // pto: %501
        ;
        int64_t v837 = v814 / v36;
        // pto: %502
        ;
        int64_t v838 = v837 < v43 ? v43 : v837;
        // pto: %503
        ;
        int64_t v839 = v820 / v31;
        // pto: %504
        ;
        int64_t v840 = v839 < v43 ? v43 : v839;
        // pto: %wo_b__ssa_v0_pview
        ;
        __gm__ int8_t* v841 = PTOAS__GLOBAL_TENSOR_DATA(v74);
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v842 = 0;
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v843 = 262144;
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v844 = 512;
        // pto: %wo_b__ssa_v0_pview
        ;
        pto::Shape<1, 4, 32, 16, 32> v845 = pto::Shape<1, 4, 32, 16, 32>();
        // pto: %wo_b__ssa_v0_pview
        ;
        pto::Stride<33554432, 262144, 512, 32, 1> v846 = pto::Stride<33554432, 262144, 512, 32, 1>();
        // pto: %wo_b__ssa_v0_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v847 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v841 + (v842 + v838 * v843 + v840 * v844), v845, v846);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v835, v847);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %b_acc__tile_l0_a
        ;
        Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v848 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v816, v30);
        // pto: %b_acc__tile_l0_a
        ;
        uint64_t v849 = (uint64_t) v23;
        TASSIGN(v848, v849);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        uint16_t v850 = static_cast<uint16_t>(v43);
        uint16_t v851 = static_cast<uint16_t>(v43);
        TEXTRACT(v848, v821, v850, v851);
        // pto: %b_acc__tile_l0_b
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v852 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v34);
        // pto: %b_acc__tile_l0_b
        ;
        uint64_t v853 = (uint64_t) v23;
        TASSIGN(v852, v853);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v854 = static_cast<uint16_t>(v43);
        uint16_t v855 = static_cast<uint16_t>(v43);
        TEXTRACT(v852, v835, v854, v855);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %25
        ;
        Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v856 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v816, v30);
        // pto: %25
        ;
        uint64_t v857 = (uint64_t) v25;
        TASSIGN(v856, v857);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v858 = static_cast<uint16_t>(v43);
        uint16_t v859 = static_cast<uint16_t>(v30);
        TEXTRACT(v856, v821, v858, v859);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        // pto: %26
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v860 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v34);
        // pto: %26
        ;
        uint64_t v861 = (uint64_t) v25;
        TASSIGN(v860, v861);
        uint16_t v862 = static_cast<uint16_t>(v30);
        uint16_t v863 = static_cast<uint16_t>(v43);
        TEXTRACT(v860, v835, v862, v863);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %505
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        if (v819 == v43) {
          pipe_barrier(PIPE_M);
          TMATMUL(v817, v848, v852);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v817, v817, v848, v852);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v817, v817, v856, v860);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
      // pto: %506
      ;
      int64_t v864 = v811 < v43 ? v43 : v811;
      // pto: %507
      ;
      int64_t v865 = v814 < v43 ? v43 : v814;
      // pto: %integer_accum__ssa_v0_pview
      ;
      __gm__ int32_t* v866 = PTOAS__GLOBAL_TENSOR_DATA(v101);
      // pto: %integer_accum__ssa_v0_pview
      ;
      const int64_t v867 = 0;
      // pto: %integer_accum__ssa_v0_pview
      ;
      const int64_t v868 = 4096;
      // pto: %integer_accum__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 128> v869 = pto::Shape<1, 1, 1, 16, 128>();
      // pto: %integer_accum__ssa_v0_pview
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v870 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %integer_accum__ssa_v0_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v871 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v866 + (v867 + v864 * v868 + v865), v869, v870);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
      pipe_barrier(PIPE_FIX);
      TSTORE(v871, v817);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
    };
  } else {
    // pto: %508, %509, %510
    ;
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    for (int64_t v872 = v120; v872 < ((int64_t) ((uint64_t) ((int64_t) ((uint64_t) v17 + (uint64_t) v58) / v29) * (uint64_t) v36)); v872 += v46) {
      // pto: %511, %512
      ;
      int64_t v873 = (int64_t) ((uint64_t) (v872 / v36) * (uint64_t) v29);
      // pto: %513
      ;
      int64_t v874 = v872 % v36;
      // pto: %514, %515, %516
      ;
      int64_t v875 = v874 < v43 ? (int64_t) ((uint64_t) v874 + (uint64_t) v36) : v874;
      // pto: %517
      ;
      int64_t v876 = (int64_t) ((uint64_t) v875 * (uint64_t) v34);
      // pto: %518
      ;
      int64_t v877 = (int64_t) ((uint64_t) v17 - (uint64_t) v873);
      // pto: %519
      ;
      int64_t v878 = v877 < v29 ? v877 : v29;
      // pto: %wide_first_input__tile
      ;
      Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v879 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v878, v35);
      // pto: %wide_first_input__tile
      ;
      uint64_t v880 = (uint64_t) v24;
      TASSIGN(v879, v880);
      // pto: %520
      ;
      int64_t v881 = v873 < v43 ? v43 : v873;
      // pto: %521
      ;
      const int64_t v882 = 0;
      // pto: %521
      ;
      __gm__ int8_t* v883 = PTOAS__GLOBAL_TENSOR_DATA(v83);
      // pto: %521
      ;
      const int64_t v884 = 1;
      // pto: %521
      ;
      const int64_t v885 = 1;
      // pto: %521
      ;
      const int64_t v886 = 1;
      // pto: %521
      ;
      int64_t v887 = v878 * v40;
      // pto: %521
      ;
      int64_t v888 = v886 * v887;
      // pto: %521
      ;
      pto::Shape<1, 1, 1, -1, 512> v889 = pto::Shape<1, 1, 1, -1, 512>(v884, v885, v886, v878, v35);
      // pto: %521
      ;
      pto::Stride<-1, -1, -1, -1, -1> v890 = pto::Stride<-1, -1, -1, -1, -1>(v885 * v888, v888, v887, v40, v27);
      // pto: %521
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v891 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v883 + (v882 + v881 * v40 + v43 * v27), v889, v890);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v879, v891);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %wide_first_weight__tile
      ;
      Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v892 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v35, v34);
      // pto: %wide_first_weight__tile
      ;
      uint64_t v893 = (uint64_t) v23;
      TASSIGN(v892, v893);
      // pto: %522
      ;
      int64_t v894 = v876 / v36;
      // pto: %523
      ;
      int64_t v895 = v894 < v43 ? v43 : v894;
      // pto: %524
      ;
      __gm__ int8_t* v896 = PTOAS__GLOBAL_TENSOR_DATA(v74);
      // pto: %524
      ;
      const int64_t v897 = 0;
      // pto: %524
      ;
      const int64_t v898 = 262144;
      // pto: %524
      ;
      pto::Shape<1, 4, 32, 16, 32> v899 = pto::Shape<1, 4, 32, 16, 32>();
      // pto: %524
      ;
      pto::Stride<33554432, 262144, 512, 32, 1> v900 = pto::Stride<33554432, 262144, 512, 32, 1>();
      // pto: %524
      ;
      GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v901 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v896 + (v897 + v895 * v898), v899, v900);
      TLOAD(v892, v901);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %wide_b_acc__tile_l0_init_storage
      ;
      Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v902 = Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v29, v34);
      // pto: %wide_b_acc__tile_l0_init_storage
      ;
      uint64_t v903 = (uint64_t) v23;
      TASSIGN(v902, v903);
      v902.SetValidShape(v878, v34);
      // pto: %wide_b_acc__tile_l0_a
      ;
      Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v904 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v878, v30);
      // pto: %wide_b_acc__tile_l0_a
      ;
      uint64_t v905 = (uint64_t) v23;
      TASSIGN(v904, v905);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      uint16_t v906 = static_cast<uint16_t>(v43);
      uint16_t v907 = static_cast<uint16_t>(v43);
      TEXTRACT(v904, v879, v906, v907);
      // pto: %wide_b_acc__tile_l0_b
      ;
      Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v908 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v34);
      // pto: %wide_b_acc__tile_l0_b
      ;
      uint64_t v909 = (uint64_t) v23;
      TASSIGN(v908, v909);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      uint16_t v910 = static_cast<uint16_t>(v43);
      uint16_t v911 = static_cast<uint16_t>(v43);
      TEXTRACT(v908, v892, v910, v911);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %28
      ;
      Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v912 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v878, v30);
      // pto: %28
      ;
      uint64_t v913 = (uint64_t) v25;
      TASSIGN(v912, v913);
      uint16_t v914 = static_cast<uint16_t>(v43);
      uint16_t v915 = static_cast<uint16_t>(v30);
      TEXTRACT(v912, v879, v914, v915);
      // pto: %29
      ;
      Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v916 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v34);
      // pto: %29
      ;
      uint64_t v917 = (uint64_t) v25;
      TASSIGN(v916, v917);
      uint16_t v918 = static_cast<uint16_t>(v30);
      uint16_t v919 = static_cast<uint16_t>(v43);
      TEXTRACT(v916, v892, v918, v919);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
      TMATMUL(v902, v904, v908);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v902, v902, v912, v916);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      for (int64_t v920 = v27; v920 < v31; v920 += v27) {
        // pto: %525
        ;
        int64_t v921 = (int64_t) ((uint64_t) v920 * (uint64_t) v35);
        // pto: %wide_b_input__tile
        ;
        Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v922 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v878, v35);
        // pto: %wide_b_input__tile
        ;
        uint64_t v923 = (uint64_t) v24;
        TASSIGN(v922, v923);
        // pto: %527
        ;
        int64_t v924 = v921 < v43 ? v43 : v921;
        // pto: %528
        ;
        const int64_t v925 = 0;
        // pto: %528
        ;
        __gm__ int8_t* v926 = PTOAS__GLOBAL_TENSOR_DATA(v83);
        // pto: %528
        ;
        const int64_t v927 = 1;
        // pto: %528
        ;
        const int64_t v928 = 1;
        // pto: %528
        ;
        const int64_t v929 = 1;
        // pto: %528
        ;
        int64_t v930 = v878 * v40;
        // pto: %528
        ;
        int64_t v931 = v929 * v930;
        // pto: %528
        ;
        pto::Shape<1, 1, 1, -1, 512> v932 = pto::Shape<1, 1, 1, -1, 512>(v927, v928, v929, v878, v35);
        // pto: %528
        ;
        pto::Stride<-1, -1, -1, -1, -1> v933 = pto::Stride<-1, -1, -1, -1, -1>(v928 * v931, v931, v930, v40, v27);
        // pto: %528
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v934 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v926 + (v925 + v881 * v40 + v924 * v27), v932, v933);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v922, v934);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %wide_b_weight__tile
        ;
        Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v935 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v35, v34);
        // pto: %wide_b_weight__tile
        ;
        uint64_t v936 = (uint64_t) v23;
        TASSIGN(v935, v936);
        // pto: %531
        ;
        int64_t v937 = v921 / v31;
        // pto: %532
        ;
        int64_t v938 = v937 < v43 ? v43 : v937;
        // pto: %533
        ;
        __gm__ int8_t* v939 = PTOAS__GLOBAL_TENSOR_DATA(v74);
        // pto: %533
        ;
        const int64_t v940 = 0;
        // pto: %533
        ;
        const int64_t v941 = 262144;
        // pto: %533
        ;
        const int64_t v942 = 512;
        // pto: %533
        ;
        pto::Shape<1, 4, 32, 16, 32> v943 = pto::Shape<1, 4, 32, 16, 32>();
        // pto: %533
        ;
        pto::Stride<33554432, 262144, 512, 32, 1> v944 = pto::Stride<33554432, 262144, 512, 32, 1>();
        // pto: %533
        ;
        GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v945 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v939 + (v940 + v895 * v941 + v938 * v942), v943, v944);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        TLOAD(v935, v945);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %31
        ;
        Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v946 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v878, v30);
        // pto: %31
        ;
        uint64_t v947 = (uint64_t) v23;
        TASSIGN(v946, v947);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v948 = static_cast<uint16_t>(v43);
        uint16_t v949 = static_cast<uint16_t>(v43);
        TEXTRACT(v946, v922, v948, v949);
        // pto: %32
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v950 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v34);
        // pto: %32
        ;
        uint64_t v951 = (uint64_t) v23;
        TASSIGN(v950, v951);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v952 = static_cast<uint16_t>(v43);
        uint16_t v953 = static_cast<uint16_t>(v43);
        TEXTRACT(v950, v935, v952, v953);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %33
        ;
        Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v954 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v878, v30);
        // pto: %33
        ;
        uint64_t v955 = (uint64_t) v25;
        TASSIGN(v954, v955);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v956 = static_cast<uint16_t>(v43);
        uint16_t v957 = static_cast<uint16_t>(v30);
        TEXTRACT(v954, v922, v956, v957);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        // pto: %34
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v958 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v34);
        // pto: %34
        ;
        uint64_t v959 = (uint64_t) v25;
        TASSIGN(v958, v959);
        uint16_t v960 = static_cast<uint16_t>(v30);
        uint16_t v961 = static_cast<uint16_t>(v43);
        TEXTRACT(v958, v935, v960, v961);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v902, v902, v946, v950);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v902, v902, v954, v958);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
      // pto: %535
      ;
      int64_t v962 = v876 < v43 ? v43 : v876;
      // pto: %536
      ;
      const int64_t v963 = 0;
      // pto: %536
      ;
      __gm__ int32_t* v964 = PTOAS__GLOBAL_TENSOR_DATA(v101);
      // pto: %536
      ;
      const int64_t v965 = 1;
      // pto: %536
      ;
      const int64_t v966 = 1;
      // pto: %536
      ;
      const int64_t v967 = 1;
      // pto: %536
      ;
      int64_t v968 = v878 * v39;
      // pto: %536
      ;
      int64_t v969 = v967 * v968;
      // pto: %536
      ;
      pto::Shape<1, 1, 1, -1, 128> v970 = pto::Shape<1, 1, 1, -1, 128>(v965, v966, v967, v878, v34);
      // pto: %536
      ;
      pto::Stride<-1, -1, -1, -1, -1> v971 = pto::Stride<-1, -1, -1, -1, -1>(v966 * v969, v969, v968, v39, v27);
      // pto: %536
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v972 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v964 + (v963 + v881 * v39 + v962 * v27), v970, v971);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
      TSTORE(v972, v902);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
    };
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %538
  int64_t v973 = (int64_t) ((uint64_t) v121 + (uint64_t) v59);
  // pto: %539
  int64_t v974 = v973 < v43 ? v43 : v973;
  // pto: %signals_v2__ssa_v0_signal_pview
  __gm__ int32_t* v975 = PTOAS__GLOBAL_TENSOR_DATA(v111);
  // pto: %signals_v2__ssa_v0_signal_pview
  const int64_t v976 = 0;
  // pto: %signals_v2__ssa_v0_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v977 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals_v2__ssa_v0_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v978 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals_v2__ssa_v0_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v979 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v975 + (v976 + v974), v977, v978);
  pto::comm::NotifyOp v980 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v979, v130, v980);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void vector(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ bfloat16_t* v6, __gm__ int8_t* v7, __gm__ float* v8, __gm__ bfloat16_t* v9, __gm__ bfloat16_t* v10, __gm__ float* v11, __gm__ float* v12, __gm__ bfloat16_t* v13, __gm__ float* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21, int32_t v22) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int32_t v23 = 1;
  // pto: %c0_i64
  const int64_t v24 = 0;
  // pto: %c32768_i64
  const int64_t v25 = 32768;
  // pto: %c65536_i64
  const int64_t v26 = 65536;
  // pto: %c65568_i64
  const int64_t v27 = 65568;
  // pto: %c32_i64
  const int64_t v28 = 32;
  // pto: %c64_i64
  const int64_t v29 = 64;
  // pto: %c49152_i64
  const int64_t v30 = 49152;
  // pto: %c67584_i64
  const int64_t v31 = 67584;
  // pto: %c16384_i64
  const int64_t v32 = 16384;
  // pto: %c81920_i64
  const int64_t v33 = 81920;
  // pto: %c98304_i64
  const int64_t v34 = 98304;
  // pto: %c114688_i64
  const int64_t v35 = 114688;
  // pto: %c122880_i64
  const int64_t v36 = 122880;
  // pto: %c1_index
  const int64_t v37 = 1;
  // pto: %c8_index
  const int64_t v38 = 8;
  // pto: %c16_index
  const int64_t v39 = 16;
  // pto: %c128_index
  const int64_t v40 = 128;
  // pto: %c512_index
  const int64_t v41 = 512;
  // pto: %c4096_index
  const int64_t v42 = 4096;
  // pto: %c8192_index
  const int64_t v43 = 8192;
  // pto: %c16384_index
  const int64_t v44 = 16384;
  // pto: %c4_index
  const int64_t v45 = 4;
  // pto: %c55296_index
  const int64_t v46 = 55296;
  // pto: %c2_index
  const int64_t v47 = 2;
  // pto: %c24_index
  const int64_t v48 = 24;
  // pto: %c0_index
  const int64_t v49 = 0;
  // pto: %c15_index
  const int64_t v50 = 15;
  // pto: %c9216_index
  const int64_t v51 = 9216;
  // pto: %c48_index
  const int64_t v52 = 48;
  // pto: %c1024_index
  const int64_t v53 = 1024;
  // pto: %c18432_index
  const int64_t v54 = 18432;
  // pto: %c72_index
  const int64_t v55 = 72;
  // pto: %c7_index
  const int64_t v56 = 7;
  // pto: %cst_41
  const float v57 = 0.00787401571f;
  // pto: %cst_42
  const float v58 = 0.0f;
  // pto: %cst_43
  const float v59 = 1.0f;
  // pto: %cst_44
  const float v60 = 127.0f;
  // pto: %c27648_index
  const int64_t v61 = 27648;
  // pto: %c36864_index
  const int64_t v62 = 36864;
  // pto: %c46080_index
  const int64_t v63 = 46080;
  // pto: %c3_index
  const int64_t v64 = 3;
  // pto: %c12_index
  const int64_t v65 = 12;
  // pto: %c5_index
  const int64_t v66 = 5;
  // pto: %c9_index
  const int64_t v67 = 9;
  // pto: %c13_index
  const int64_t v68 = 13;
  // pto: %c6_index
  const int64_t v69 = 6;
  // pto: %c10_index
  const int64_t v70 = 10;
  // pto: %c14_index
  const int64_t v71 = 14;
  // pto: %c11_index
  const int64_t v72 = 11;
  // pto: %c12288_index
  const int64_t v73 = 12288;
  // pto: %cn1_index
  const int64_t v74 = -1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v78 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v79 = v42 * v37;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v80 = v78 * v79;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v81 = v77 * v80;
  // pto: %wo_b_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v82 = pto::Shape<1, 1, 1, 1, -1>(v75, v76, v77, v78, v42);
  // pto: %wo_b_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v83 = pto::Stride<-1, -1, -1, -1, -1>(v76 * v81, v81, v80, v79, v37);
  // pto: %wo_b_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v84 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v82, v83);
  // pto: %projected__ssa_v0_view
  const int64_t v85 = 1;
  // pto: %projected__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %projected__ssa_v0_view
  const int64_t v87 = 1;
  // pto: %projected__ssa_v0_view
  int64_t v88 = (int64_t) v17;
  // pto: %projected__ssa_v0_view
  int64_t v89 = v88 * v43;
  // pto: %projected__ssa_v0_view
  int64_t v90 = v87 * v89;
  // pto: %projected__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v91 = pto::Shape<1, 1, 1, -1, -1>(v85, v86, v87, v88, v43);
  // pto: %projected__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v92 = pto::Stride<-1, -1, -1, -1, -1>(v86 * v90, v90, v89, v43, v37);
  // pto: %projected__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v93 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v91, v92);
  // pto: %quantized__ssa_v0_view
  const int64_t v94 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v96 = 1;
  // pto: %quantized__ssa_v0_view
  int64_t v97 = (int64_t) v17;
  // pto: %quantized__ssa_v0_view
  int64_t v98 = v97 * v43;
  // pto: %quantized__ssa_v0_view
  int64_t v99 = v96 * v98;
  // pto: %quantized__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v100 = pto::Shape<1, 1, 1, -1, -1>(v94, v95, v96, v97, v43);
  // pto: %quantized__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v101 = pto::Stride<-1, -1, -1, -1, -1>(v95 * v99, v99, v98, v43, v37);
  // pto: %quantized__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v102 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v100, v101);
  // pto: %token_scale__ssa_v0_view
  const int64_t v103 = 1;
  // pto: %token_scale__ssa_v0_view
  const int64_t v104 = 1;
  // pto: %token_scale__ssa_v0_view
  const int64_t v105 = 1;
  // pto: %token_scale__ssa_v0_view
  int64_t v106 = (int64_t) v17;
  // pto: %token_scale__ssa_v0_view
  int64_t v107 = v106 * v37;
  // pto: %token_scale__ssa_v0_view
  int64_t v108 = v105 * v107;
  // pto: %token_scale__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v109 = pto::Shape<1, 1, 1, -1, -1>(v103, v104, v105, v106, v37);
  // pto: %token_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v110 = pto::Stride<-1, -1, -1, -1, -1>(v104 * v108, v108, v107, v37, (int64_t) v17);
  // pto: %token_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v111 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v8, v109, v110);
  // pto: %attended__ssa_v0_view
  const int64_t v112 = 1;
  // pto: %attended__ssa_v0_view
  const int64_t v113 = 1;
  // pto: %attended__ssa_v0_view
  const int64_t v114 = 1;
  // pto: %attended__ssa_v0_view
  int64_t v115 = (int64_t) v17;
  // pto: %attended__ssa_v0_view
  int64_t v116 = v115 * v42;
  // pto: %attended__ssa_v0_view
  int64_t v117 = v114 * v116;
  // pto: %attended__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v118 = pto::Shape<1, 1, 1, -1, -1>(v112, v113, v114, v115, v42);
  // pto: %attended__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v119 = pto::Stride<-1, -1, -1, -1, -1>(v113 * v117, v117, v116, v42, v37);
  // pto: %attended__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v120 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v118, v119);
  // pto: %residual__ssa_v0_view
  const int64_t v121 = 1;
  // pto: %residual__ssa_v0_view
  const int64_t v122 = 1;
  // pto: %residual__ssa_v0_view
  const int64_t v123 = 1;
  // pto: %residual__ssa_v0_view
  int64_t v124 = (int64_t) v17;
  // pto: %residual__ssa_v0_view
  int64_t v125 = v124 * v44;
  // pto: %residual__ssa_v0_view
  int64_t v126 = v123 * v125;
  // pto: %residual__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v127 = pto::Shape<1, 1, 1, -1, -1>(v121, v122, v123, v124, v44);
  // pto: %residual__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v128 = pto::Stride<-1, -1, -1, -1, -1>(v122 * v126, v126, v125, v44, v37);
  // pto: %residual__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v129 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v10, v127, v128);
  // pto: %output__ssa_v0_view
  const int64_t v130 = 1;
  // pto: %output__ssa_v0_view
  const int64_t v131 = 1;
  // pto: %output__ssa_v0_view
  const int64_t v132 = 1;
  // pto: %output__ssa_v0_view
  int64_t v133 = (int64_t) v17;
  // pto: %output__ssa_v0_view
  int64_t v134 = v133 * v44;
  // pto: %output__ssa_v0_view
  int64_t v135 = v132 * v134;
  // pto: %output__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v136 = pto::Shape<1, 1, 1, -1, -1>(v130, v131, v132, v133, v44);
  // pto: %output__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v137 = pto::Stride<-1, -1, -1, -1, -1>(v131 * v135, v135, v134, v44, v37);
  // pto: %output__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v138 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v136, v137);
  // pto: %accum__ssa_v0_view
  const int64_t v139 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v140 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v141 = 1;
  // pto: %accum__ssa_v0_view
  int64_t v142 = (int64_t) v18;
  // pto: %accum__ssa_v0_view
  int64_t v143 = v142 * v43;
  // pto: %accum__ssa_v0_view
  int64_t v144 = v141 * v143;
  // pto: %accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v145 = pto::Shape<1, 1, 1, -1, -1>(v139, v140, v141, v142, v43);
  // pto: %accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v146 = pto::Stride<-1, -1, -1, -1, -1>(v140 * v144, v144, v143, v43, v37);
  // pto: %accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v147 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v145, v146);
  // pto: %integer_accum__ssa_v0_view
  const int64_t v148 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v149 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v150 = 1;
  // pto: %integer_accum__ssa_v0_view
  int64_t v151 = (int64_t) v19;
  // pto: %integer_accum__ssa_v0_view
  int64_t v152 = v151 * v42;
  // pto: %integer_accum__ssa_v0_view
  int64_t v153 = v150 * v152;
  // pto: %integer_accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v154 = pto::Shape<1, 1, 1, -1, -1>(v148, v149, v150, v151, v42);
  // pto: %integer_accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v155 = pto::Stride<-1, -1, -1, -1, -1>(v149 * v153, v153, v152, v42, v37);
  // pto: %integer_accum__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v156 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v154, v155);
  // pto: %signals__ssa_v0_view
  const int64_t v157 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v158 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v159 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v160 = 1;
  // pto: %signals__ssa_v0_view
  int64_t v161 = v46 * v37;
  // pto: %signals__ssa_v0_view
  int64_t v162 = v160 * v161;
  // pto: %signals__ssa_v0_view
  int64_t v163 = v159 * v162;
  // pto: %signals__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v164 = pto::Shape<1, 1, 1, 1, -1>(v157, v158, v159, v160, v46);
  // pto: %signals__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v165 = pto::Stride<-1, -1, -1, -1, -1>(v158 * v163, v163, v162, v161, v37);
  // pto: %signals__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v166 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v164, v165);
  // pto: %t__tmp_v0, %145, %146, %t__tmp_v1
  int64_t v167 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v20) * (uint64_t) v47) + (uint64_t) ((int64_t) v22));
  // pto: %147, %148
  int64_t v168 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v167 + (uint64_t) v48) * (uint64_t) v40);
  // pto: %149
  int64_t v169 = v168 < v49 ? v49 : v168;
  // pto: %signals__ssa_v0_pview
  __gm__ int32_t* v170 = PTOAS__GLOBAL_TENSOR_DATA(v166);
  // pto: %signals__ssa_v0_pview
  const int64_t v171 = 0;
  // pto: %signals__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 1> v172 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  pto::Stride<1, 1, 1, 1, 1> v173 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v174 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v170 + (v171 + v169), v172, v173);
  __gm__ int32_t* v175 = PTOAS__GLOBAL_TENSOR_DATA(v174);
  PTOAS__DCCI_SINGLE_CACHE_LINE(v175);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  // pto: %150
  int32_t v176 = (v16)[v168];
  // pto: %152
  int32_t v177 = (int32_t) ((uint32_t) v176 + (uint32_t) v23);
  pipe_barrier(PIPE_ALL);
  pto::comm::NotifyOp v178 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v174, v177, v178);
  // pto: %154, %155, %156
  int64_t v179 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v17 + (uint64_t) v50) / v39) * (uint64_t) v38);
  // pto: %157
  if (v167 < v179) {
    for (int64_t v180 = v49; v180 < v38; v180 += v37) {
      // pto: %158
      ;
      int64_t v181 = v167 % v38;
      // pto: %159, %160, %161
      ;
      int64_t v182 = v181 < v49 ? (int64_t) ((uint64_t) v181 + (uint64_t) v38) : v181;
      // pto: %162, %163, %164
      ;
      int64_t v183 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v182 * (uint64_t) v38) + (uint64_t) v180) % v48;
      // pto: %165, %166, %167
      ;
      int64_t v184 = v183 < v49 ? (int64_t) ((uint64_t) v183 + (uint64_t) v48) : v183;
      // pto: %168, %169
      ;
      int64_t v185 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v184 * (uint64_t) v40) + (uint64_t) v51);
      // pto: %170
      ;
      int64_t v186 = v185 < v49 ? v49 : v185;
      // pto: %signals__ssa_v1_signal_pview
      ;
      __gm__ int32_t* v187 = PTOAS__GLOBAL_TENSOR_DATA(v166);
      // pto: %signals__ssa_v1_signal_pview
      ;
      const int64_t v188 = 0;
      // pto: %signals__ssa_v1_signal_pview
      ;
      pto::Shape<1, 1, 1, 1, 1> v189 = pto::Shape<1, 1, 1, 1, 1>();
      // pto: %signals__ssa_v1_signal_pview
      ;
      pto::Stride<1, 1, 1, 1, 1> v190 = pto::Stride<1, 1, 1, 1, 1>();
      // pto: %signals__ssa_v1_signal_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v191 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v187 + (v188 + v186), v189, v190);
      pto::comm::WaitCmp v192 = pto::comm::WaitCmp::GE;
      pto::comm::TWAIT(v191, v177, v192);
    };
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
  }
  for (int64_t v193 = v167; v193 < v179; v193 += v52) {
    // pto: %172, %173
    ;
    int64_t v194 = (int64_t) ((uint64_t) (v193 / v38) * (uint64_t) v39);
    // pto: %174
    ;
    int64_t v195 = v193 % v38;
    // pto: %175, %176, %177
    ;
    int64_t v196 = v195 < v49 ? (int64_t) ((uint64_t) v195 + (uint64_t) v38) : v195;
    // pto: %178
    ;
    int64_t v197 = (int64_t) ((uint64_t) v196 * (uint64_t) v53);
    // pto: %179
    ;
    int64_t v198 = (int64_t) ((uint64_t) v17 - (uint64_t) v194);
    // pto: %180
    ;
    int64_t v199 = v198 < v39 ? v198 : v39;
    // pto: %oa_value__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v200 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v199, v53);
    // pto: %oa_value__ssa_v0
    ;
    uint64_t v201 = (uint64_t) v24;
    TASSIGN(v200, v201);
    // pto: %181
    ;
    int64_t v202 = v194 < v49 ? v49 : v194;
    // pto: %182
    ;
    int64_t v203 = v197 < v49 ? v49 : v197;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v204 = 0;
    // pto: %accum__ssa_v0_pview
    ;
    __gm__ float* v205 = PTOAS__GLOBAL_TENSOR_DATA(v147);
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v206 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v207 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v208 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    int64_t v209 = v199 * v43;
    // pto: %accum__ssa_v0_pview
    ;
    int64_t v210 = v208 * v209;
    // pto: %accum__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1024> v211 = pto::Shape<1, 1, 1, -1, 1024>(v206, v207, v208, v199, v53);
    // pto: %accum__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v212 = pto::Stride<-1, -1, -1, -1, -1>(v207 * v210, v210, v209, v43, v37);
    // pto: %accum__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v213 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v205 + (v204 + v202 * v43 + v203 * v37), v211, v212);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v200, v213);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %t__tmp_v3
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v214 = Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v199, v53);
    // pto: %t__tmp_v3
    ;
    uint64_t v215 = (uint64_t) v24;
    TASSIGN(v214, v215);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v216 = RoundMode::CAST_RINT;
    SaturationMode v217 = SaturationMode::ON;
    TCVT(v214, v200, v216, v217);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v218 = 0;
    // pto: %projected__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v219 = PTOAS__GLOBAL_TENSOR_DATA(v93);
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v220 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v221 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v222 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    int64_t v223 = v199 * v43;
    // pto: %projected__ssa_v0_pview
    ;
    int64_t v224 = v222 * v223;
    // pto: %projected__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1024> v225 = pto::Shape<1, 1, 1, -1, 1024>(v220, v221, v222, v199, v53);
    // pto: %projected__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v226 = pto::Stride<-1, -1, -1, -1, -1>(v221 * v224, v224, v223, v43, v37);
    // pto: %projected__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v227 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v219 + (v218 + v202 * v43 + v203 * v37), v225, v226);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v227, v214);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %186
  int64_t v228 = (int64_t) ((uint64_t) v168 + (uint64_t) v54);
  // pto: %187
  int64_t v229 = v228 < v49 ? v49 : v228;
  // pto: %188
  __gm__ int32_t* v230 = PTOAS__GLOBAL_TENSOR_DATA(v166);
  // pto: %188
  const int64_t v231 = 0;
  // pto: %188
  pto::Shape<1, 1, 1, 1, 1> v232 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %188
  pto::Stride<1, 1, 1, 1, 1> v233 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %188
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v234 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v230 + (v231 + v229), v232, v233);
  pto::comm::NotifyOp v235 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v234, v177, v235);
  for (int64_t v236 = v48; v236 < v55; v236 += v37) {
    // pto: %189, %190
    ;
    int64_t v237 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v236 * (uint64_t) v40) + (uint64_t) v54);
    // pto: %191
    ;
    int64_t v238 = v237 < v49 ? v49 : v237;
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v239 = PTOAS__GLOBAL_TENSOR_DATA(v166);
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    const int64_t v240 = 0;
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v241 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v242 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v243 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v239 + (v240 + v238), v241, v242);
    pto::comm::WaitCmp v244 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v243, v177, v244);
  }
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %192, %193
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  for (int64_t v245 = v167; v245 < ((int64_t) ((uint64_t) v17 + (uint64_t) v56) / v38); v245 += v52) {
    // pto: %195
    ;
    int64_t v246 = (int64_t) ((uint64_t) v245 * (uint64_t) v38);
    // pto: %196
    ;
    int64_t v247 = (int64_t) ((uint64_t) v17 - (uint64_t) v246);
    // pto: %197
    ;
    int64_t v248 = v247 < v38 ? v247 : v38;
    // pto: %first_quant__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v249 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
    // pto: %first_quant__ssa_v0
    ;
    uint64_t v250 = (uint64_t) v25;
    TASSIGN(v249, v250);
    // pto: %198
    ;
    int64_t v251 = v246 < v49 ? v49 : v246;
    // pto: %199
    ;
    const int64_t v252 = 0;
    // pto: %199
    ;
    __gm__ bfloat16_t* v253 = PTOAS__GLOBAL_TENSOR_DATA(v93);
    // pto: %199
    ;
    const int64_t v254 = 1;
    // pto: %199
    ;
    const int64_t v255 = 1;
    // pto: %199
    ;
    const int64_t v256 = 1;
    // pto: %199
    ;
    int64_t v257 = v248 * v43;
    // pto: %199
    ;
    int64_t v258 = v256 * v257;
    // pto: %199
    ;
    pto::Shape<1, 1, 1, -1, 1024> v259 = pto::Shape<1, 1, 1, -1, 1024>(v254, v255, v256, v248, v53);
    // pto: %199
    ;
    pto::Stride<-1, -1, -1, -1, -1> v260 = pto::Stride<-1, -1, -1, -1, -1>(v255 * v258, v258, v257, v43, v37);
    // pto: %199
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v261 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v253 + (v252 + v251 * v43 + v49 * v37), v259, v260);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v249, v261);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %t__tmp_v4
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v262 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
    // pto: %t__tmp_v4
    ;
    uint64_t v263 = (uint64_t) v24;
    TASSIGN(v262, v263);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    pipe_barrier(PIPE_V);
    RoundMode v264 = RoundMode::CAST_ROUND;
    SaturationMode v265 = SaturationMode::ON;
    TCVT(v262, v249, v264, v265);
    // pto: %first_abs__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v266 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
    // pto: %first_abs__ssa_v0
    ;
    uint64_t v267 = (uint64_t) v24;
    TASSIGN(v266, v267);
    pipe_barrier(PIPE_V);
    TABS(v266, v262);
    // pto: %t__tmp_v5
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v268 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v53);
    // pto: %t__tmp_v5
    ;
    uint64_t v269 = (uint64_t) v25;
    TASSIGN(v268, v269);
    // pto: %amax__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v270 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v37);
    // pto: %amax__ssa_v0
    ;
    uint64_t v271 = (uint64_t) v26;
    TASSIGN(v270, v271);
    pipe_barrier(PIPE_V);
    TROWMAX(v270, v266, v268);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    for (int64_t v272 = v37; v272 < v38; v272 += v37) {
      // pto: %q_bf16__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v273 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
      // pto: %q_bf16__ssa_v0
      ;
      uint64_t v274 = (uint64_t) v25;
      TASSIGN(v273, v274);
      // pto: %201
      ;
      int64_t v275 = (int64_t) ((uint64_t) v272 * (uint64_t) v53);
      // pto: %202
      ;
      int64_t v276 = v275 < v49 ? v49 : v275;
      // pto: %203
      ;
      const int64_t v277 = 0;
      // pto: %203
      ;
      __gm__ bfloat16_t* v278 = PTOAS__GLOBAL_TENSOR_DATA(v93);
      // pto: %203
      ;
      const int64_t v279 = 1;
      // pto: %203
      ;
      const int64_t v280 = 1;
      // pto: %203
      ;
      const int64_t v281 = 1;
      // pto: %203
      ;
      int64_t v282 = v248 * v43;
      // pto: %203
      ;
      int64_t v283 = v281 * v282;
      // pto: %203
      ;
      pto::Shape<1, 1, 1, -1, 1024> v284 = pto::Shape<1, 1, 1, -1, 1024>(v279, v280, v281, v248, v53);
      // pto: %203
      ;
      pto::Stride<-1, -1, -1, -1, -1> v285 = pto::Stride<-1, -1, -1, -1, -1>(v280 * v283, v283, v282, v43, v37);
      // pto: %203
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v286 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v278 + (v277 + v251 * v43 + v276 * v37), v284, v285);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      TLOAD(v273, v286);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %q_fp32__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v287 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
      // pto: %q_fp32__ssa_v0
      ;
      uint64_t v288 = (uint64_t) v24;
      TASSIGN(v287, v288);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      pipe_barrier(PIPE_V);
      RoundMode v289 = RoundMode::CAST_ROUND;
      SaturationMode v290 = SaturationMode::ON;
      TCVT(v287, v273, v289, v290);
      // pto: %t__tmp_v6
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v291 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
      // pto: %t__tmp_v6
      ;
      uint64_t v292 = (uint64_t) v24;
      TASSIGN(v291, v292);
      pipe_barrier(PIPE_V);
      TABS(v291, v287);
      // pto: %t__tmp_v7
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v293 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v53);
      // pto: %t__tmp_v7
      ;
      uint64_t v294 = (uint64_t) v25;
      TASSIGN(v293, v294);
      // pto: %t__tmp_v8
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v295 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v37);
      // pto: %t__tmp_v8
      ;
      uint64_t v296 = (uint64_t) v27;
      TASSIGN(v295, v296);
      pipe_barrier(PIPE_V);
      TROWMAX(v295, v291, v293);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      // pto: %amax__rm_a0_tmp_v0
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v297 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
      // pto: %amax__rm_a0_tmp_v0
      ;
      uint64_t v298 = (uint64_t) v26;
      TASSIGN(v297, v298);
      // pto: %amax__rm_a1_tmp_v1
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v299 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
      // pto: %amax__rm_a1_tmp_v1
      ;
      uint64_t v300 = (uint64_t) v27;
      TASSIGN(v299, v300);
      // pto: %amax__row_major_tmp_v2
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v301 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
      // pto: %amax__row_major_tmp_v2
      ;
      uint64_t v302 = (uint64_t) v24;
      TASSIGN(v301, v302);
      pipe_barrier(PIPE_V);
      TMAX(v301, v297, v299);
      // pto: %amax__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v303 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v37);
      // pto: %amax__ssa_v3
      ;
      uint64_t v304 = (uint64_t) v24;
      TASSIGN(v303, v304);
      // pto: %amax__ssa_v3_mv
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v305 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v37);
      // pto: %amax__ssa_v3_mv
      ;
      uint64_t v306 = (uint64_t) v26;
      TASSIGN(v305, v306);
      pipe_barrier(PIPE_V);
      TMOV(v305, v303);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    // pto: %dequant__rm_a0_tmp_v3
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v307 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
    // pto: %dequant__rm_a0_tmp_v3
    ;
    uint64_t v308 = (uint64_t) v26;
    TASSIGN(v307, v308);
    // pto: %dequant__row_major_tmp_v4
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
    // pto: %dequant__row_major_tmp_v4
    ;
    uint64_t v310 = (uint64_t) v24;
    TASSIGN(v309, v310);
    pipe_barrier(PIPE_V);
    TMULS(v309, v307, v57);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %dequant__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v311 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v37);
    // pto: %dequant__ssa_v0
    ;
    uint64_t v312 = (uint64_t) v24;
    TASSIGN(v311, v312);
    // pto: %denominator__rm_a0_tmp_v5
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
    // pto: %denominator__rm_a0_tmp_v5
    ;
    uint64_t v314 = (uint64_t) v26;
    TASSIGN(v313, v314);
    // pto: %denominator__row_major_tmp_v6
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
    // pto: %denominator__row_major_tmp_v6
    ;
    uint64_t v316 = (uint64_t) v28;
    TASSIGN(v315, v316);
    TADDS(v315, v313, v58);
    set_flag(PIPE_V, PIPE_S, EVENT_ID0);
    // pto: %denominator__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v317 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v37);
    // pto: %denominator__ssa_v0
    ;
    uint64_t v318 = (uint64_t) v28;
    TASSIGN(v317, v318);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
    for (int64_t v319 = v49; v319 < v248; v319 += v37) {
      // pto: %magnitude__ssa_v0
      ;
      float v320 = v317.GetValue(v319);
      // pto: %204
      ;
      bool v321 = v320 != v320 || v58 != v58;
      // pto: %204
      ;
      if ((v320 == v320 && v58 == v58) && v320 == v58) {
        v317.SetValue(v319, v59);
      };
    };
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
    // pto: %t__rm_a0_tmp_v7
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v322 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
    // pto: %t__rm_a0_tmp_v7
    ;
    uint64_t v323 = (uint64_t) v26;
    TASSIGN(v322, v323);
    // pto: %t__row_major_tmp_v8
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v324 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
    // pto: %t__row_major_tmp_v8
    ;
    uint64_t v325 = (uint64_t) v29;
    TASSIGN(v324, v325);
    TMULS(v324, v322, v58);
    // pto: %t__tmp_v9
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v326 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v37);
    // pto: %t__tmp_v9
    ;
    uint64_t v327 = (uint64_t) v29;
    TASSIGN(v326, v327);
    // pto: %t__rm_a0_tmp_v9
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v328 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
    // pto: %t__rm_a0_tmp_v9
    ;
    uint64_t v329 = (uint64_t) v29;
    TASSIGN(v328, v329);
    // pto: %t__row_major_tmp_v10
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v330 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
    // pto: %t__row_major_tmp_v10
    ;
    uint64_t v331 = (uint64_t) v29;
    TASSIGN(v330, v331);
    pipe_barrier(PIPE_V);
    TADDS(v330, v328, v60);
    // pto: %t__tmp_v10
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v332 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v37);
    // pto: %t__tmp_v10
    ;
    uint64_t v333 = (uint64_t) v29;
    TASSIGN(v332, v333);
    // pto: %multiplier__rm_a0_tmp_v11
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v334 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
    // pto: %multiplier__rm_a0_tmp_v11
    ;
    uint64_t v335 = (uint64_t) v29;
    TASSIGN(v334, v335);
    // pto: %multiplier__rm_a1_tmp_v12
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v336 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
    // pto: %multiplier__rm_a1_tmp_v12
    ;
    uint64_t v337 = (uint64_t) v28;
    TASSIGN(v336, v337);
    // pto: %multiplier__row_major_tmp_v13
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v338 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
    // pto: %multiplier__row_major_tmp_v13
    ;
    uint64_t v339 = (uint64_t) v30;
    TASSIGN(v338, v339);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    TDIV(v338, v334, v336);
    // pto: %multiplier__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v340 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v37);
    // pto: %multiplier__ssa_v0
    ;
    uint64_t v341 = (uint64_t) v30;
    TASSIGN(v340, v341);
    v311.SetValidShape(v248, v37);
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v342 = (int64_t) v17;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v343 = 0;
    // pto: %token_scale__ssa_v0_pview
    ;
    __gm__ float* v344 = PTOAS__GLOBAL_TENSOR_DATA(v111);
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v345 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v346 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v347 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v348 = v248 * v37;
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v349 = v347 * v348;
    // pto: %token_scale__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1> v350 = pto::Shape<1, 1, 1, -1, 1>(v345, v346, v347, v248, v37);
    // pto: %token_scale__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v351 = pto::Stride<-1, -1, -1, -1, -1>(v346 * v349, v349, v348, v37, v342);
    // pto: %token_scale__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v352 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v344 + (v343 + v251 * v37 + v49 * v342), v350, v351);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    TSTORE(v352, v311);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    for (int64_t v353 = v49; v353 < v38; v353 += v37) {
      // pto: %209
      ;
      int64_t v354 = (int64_t) ((uint64_t) v353 * (uint64_t) v53);
      // pto: %quant_bf16__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v355 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
      // pto: %quant_bf16__ssa_v0
      ;
      uint64_t v356 = (uint64_t) v25;
      TASSIGN(v355, v356);
      // pto: %211
      ;
      int64_t v357 = v354 < v49 ? v49 : v354;
      // pto: %212
      ;
      const int64_t v358 = 0;
      // pto: %212
      ;
      __gm__ bfloat16_t* v359 = PTOAS__GLOBAL_TENSOR_DATA(v93);
      // pto: %212
      ;
      const int64_t v360 = 1;
      // pto: %212
      ;
      const int64_t v361 = 1;
      // pto: %212
      ;
      const int64_t v362 = 1;
      // pto: %212
      ;
      int64_t v363 = v248 * v43;
      // pto: %212
      ;
      int64_t v364 = v362 * v363;
      // pto: %212
      ;
      pto::Shape<1, 1, 1, -1, 1024> v365 = pto::Shape<1, 1, 1, -1, 1024>(v360, v361, v362, v248, v53);
      // pto: %212
      ;
      pto::Stride<-1, -1, -1, -1, -1> v366 = pto::Stride<-1, -1, -1, -1, -1>(v361 * v364, v364, v363, v43, v37);
      // pto: %212
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v367 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v359 + (v358 + v251 * v43 + v357 * v37), v365, v366);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      TLOAD(v355, v367);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %t__tmp_v12
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v368 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
      // pto: %t__tmp_v12
      ;
      uint64_t v369 = (uint64_t) v24;
      TASSIGN(v368, v369);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      RoundMode v370 = RoundMode::CAST_ROUND;
      SaturationMode v371 = SaturationMode::ON;
      TCVT(v368, v355, v370, v371);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      // pto: %quant_scaled__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v372 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
      // pto: %quant_scaled__ssa_v0
      ;
      uint64_t v373 = (uint64_t) v24;
      TASSIGN(v372, v373);
      pipe_barrier(PIPE_V);
      TROWEXPANDMUL(v372, v368, v340);
      // pto: %integer__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v374 = Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
      // pto: %integer__ssa_v0
      ;
      uint64_t v375 = (uint64_t) v24;
      TASSIGN(v374, v375);
      pipe_barrier(PIPE_V);
      RoundMode v376 = RoundMode::CAST_RINT;
      SaturationMode v377 = SaturationMode::ON;
      TCVT(v374, v372, v376, v377);
      // pto: %half__ssa_v0
      ;
      Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v378 = Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
      // pto: %half__ssa_v0
      ;
      uint64_t v379 = (uint64_t) v24;
      TASSIGN(v378, v379);
      pipe_barrier(PIPE_V);
      RoundMode v380 = RoundMode::CAST_ROUND;
      SaturationMode v381 = SaturationMode::ON;
      TCVT(v378, v374, v380, v381);
      // pto: %result__ssa_v0
      ;
      Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v382 = Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
      // pto: %result__ssa_v0
      ;
      uint64_t v383 = (uint64_t) v24;
      TASSIGN(v382, v383);
      pipe_barrier(PIPE_V);
      RoundMode v384 = RoundMode::CAST_TRUNC;
      SaturationMode v385 = SaturationMode::ON;
      TCVT(v382, v378, v384, v385);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      v382.SetValidShape(v248, v53);
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v386 = 0;
      // pto: %quantized__ssa_v0_pview
      ;
      __gm__ int8_t* v387 = PTOAS__GLOBAL_TENSOR_DATA(v102);
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v388 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v389 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v390 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      int64_t v391 = v248 * v43;
      // pto: %quantized__ssa_v0_pview
      ;
      int64_t v392 = v390 * v391;
      // pto: %quantized__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 1024> v393 = pto::Shape<1, 1, 1, -1, 1024>(v388, v389, v390, v248, v53);
      // pto: %quantized__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v394 = pto::Stride<-1, -1, -1, -1, -1>(v389 * v392, v392, v391, v43, v37);
      // pto: %quantized__ssa_v0_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v395 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v387 + (v386 + v251 * v43 + v357 * v37), v393, v394);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      TSTORE(v395, v382);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %216
  int64_t v396 = (int64_t) ((uint64_t) v168 + (uint64_t) v61);
  // pto: %217
  int64_t v397 = v396 < v49 ? v49 : v396;
  // pto: %signals_v2__ssa_v0_signal_pview
  __gm__ int32_t* v398 = PTOAS__GLOBAL_TENSOR_DATA(v166);
  // pto: %signals_v2__ssa_v0_signal_pview
  const int64_t v399 = 0;
  // pto: %signals_v2__ssa_v0_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v400 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals_v2__ssa_v0_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v401 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals_v2__ssa_v0_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v402 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v398 + (v399 + v397), v400, v401);
  pto::comm::NotifyOp v403 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v402, v177, v403);
  for (int64_t v404 = v49; v404 < v48; v404 += v37) {
    // pto: %218, %219
    ;
    int64_t v405 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v404 * (uint64_t) v40) + (uint64_t) v62);
    // pto: %220
    ;
    int64_t v406 = v405 < v49 ? v49 : v405;
    // pto: %signals_v3__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v407 = PTOAS__GLOBAL_TENSOR_DATA(v166);
    // pto: %signals_v3__ssa_v0_signal_pview
    ;
    const int64_t v408 = 0;
    // pto: %signals_v3__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v409 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v3__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v410 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v3__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v411 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v407 + (v408 + v406), v409, v410);
    pto::comm::WaitCmp v412 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v411, v177, v412);
  }
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  for (int64_t v413 = v167; v413 < v179; v413 += v52) {
    // pto: %223, %224
    ;
    int64_t v414 = (int64_t) ((uint64_t) (v413 / v38) * (uint64_t) v39);
    // pto: %225
    ;
    int64_t v415 = v413 % v38;
    // pto: %226, %227, %228
    ;
    int64_t v416 = v415 < v49 ? (int64_t) ((uint64_t) v415 + (uint64_t) v38) : v415;
    // pto: %229
    ;
    int64_t v417 = (int64_t) ((uint64_t) v416 * (uint64_t) v41);
    // pto: %230
    ;
    int64_t v418 = (int64_t) ((uint64_t) v17 - (uint64_t) v414);
    // pto: %231
    ;
    int64_t v419 = v418 < v39 ? v418 : v39;
    // pto: %ob_integer__ssa_v0
    ;
    Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v420 = Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v419, v41);
    // pto: %ob_integer__ssa_v0
    ;
    uint64_t v421 = (uint64_t) v24;
    TASSIGN(v420, v421);
    // pto: %232
    ;
    int64_t v422 = v414 < v49 ? v49 : v414;
    // pto: %233
    ;
    int64_t v423 = v417 < v49 ? v49 : v417;
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v424 = 0;
    // pto: %integer_accum__ssa_v0_pview
    ;
    __gm__ int32_t* v425 = PTOAS__GLOBAL_TENSOR_DATA(v156);
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v426 = 1;
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v427 = 1;
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v428 = 1;
    // pto: %integer_accum__ssa_v0_pview
    ;
    int64_t v429 = v419 * v42;
    // pto: %integer_accum__ssa_v0_pview
    ;
    int64_t v430 = v428 * v429;
    // pto: %integer_accum__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v431 = pto::Shape<1, 1, 1, -1, 512>(v426, v427, v428, v419, v41);
    // pto: %integer_accum__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v432 = pto::Stride<-1, -1, -1, -1, -1>(v427 * v430, v430, v429, v42, v37);
    // pto: %integer_accum__ssa_v0_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v433 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v425 + (v424 + v422 * v42 + v423 * v37), v431, v432);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    TLOAD(v420, v433);
    // pto: %t__tmp_v14
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v434 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v41);
    // pto: %t__tmp_v14
    ;
    uint64_t v435 = (uint64_t) v26;
    TASSIGN(v434, v435);
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    __gm__ float* v436 = PTOAS__GLOBAL_TENSOR_DATA(v84);
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    const int64_t v437 = 0;
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 512> v438 = pto::Shape<1, 1, 1, 1, 512>();
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    pto::Stride<512, 512, 512, 512, 1> v439 = pto::Stride<512, 512, 512, 512, 1>();
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v440 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v436 + (v437 + v423), v438, v439);
    TLOAD(v434, v440);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    // pto: %channel__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v441 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v41);
    // pto: %channel__ssa_v0
    ;
    uint64_t v442 = (uint64_t) v26;
    TASSIGN(v441, v442);
    // pto: %scale__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v443 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v419, v37);
    // pto: %scale__ssa_v0
    ;
    uint64_t v444 = (uint64_t) v31;
    TASSIGN(v443, v444);
    // pto: %236
    ;
    int64_t v445 = (int64_t) v17;
    // pto: %236
    ;
    const int64_t v446 = 0;
    // pto: %236
    ;
    __gm__ float* v447 = PTOAS__GLOBAL_TENSOR_DATA(v111);
    // pto: %236
    ;
    const int64_t v448 = 1;
    // pto: %236
    ;
    const int64_t v449 = 1;
    // pto: %236
    ;
    const int64_t v450 = 1;
    // pto: %236
    ;
    int64_t v451 = v419 * v37;
    // pto: %236
    ;
    int64_t v452 = v450 * v451;
    // pto: %236
    ;
    pto::Shape<1, 1, 1, -1, 1> v453 = pto::Shape<1, 1, 1, -1, 1>(v448, v449, v450, v419, v37);
    // pto: %236
    ;
    pto::Stride<-1, -1, -1, -1, -1> v454 = pto::Stride<-1, -1, -1, -1, -1>(v449 * v452, v452, v451, v37, v445);
    // pto: %236
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v455 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v447 + (v446 + v422 * v37 + v49 * v445), v453, v454);
    TLOAD(v443, v455);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    // pto: %coefficient_one__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v456 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v39, v41);
    // pto: %coefficient_one__ssa_v0
    ;
    uint64_t v457 = (uint64_t) v25;
    TASSIGN(v456, v457);
    pipe_barrier(PIPE_V);
    TEXPANDS(v456, v59);
    // pto: %coefficient_channel__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v458 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v39, v41);
    // pto: %coefficient_channel__ssa_v0
    ;
    uint64_t v459 = (uint64_t) v25;
    TASSIGN(v458, v459);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    TCOLEXPANDMUL(v458, v456, v441);
    // pto: %coefficient__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v460 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v39, v41);
    // pto: %coefficient__ssa_v0
    ;
    uint64_t v461 = (uint64_t) v25;
    TASSIGN(v460, v461);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    TROWEXPANDMUL(v460, v458, v443);
    // pto: %t__tmp_v15
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v462 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v419, v41);
    // pto: %t__tmp_v15
    ;
    uint64_t v463 = (uint64_t) v24;
    TASSIGN(v462, v463);
    RoundMode v464 = RoundMode::CAST_ROUND;
    SaturationMode v465 = SaturationMode::ON;
    TCVT(v462, v420, v464, v465);
    // pto: %ob_scaled__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v466 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v419, v41);
    // pto: %ob_scaled__ssa_v0
    ;
    uint64_t v467 = (uint64_t) v24;
    TASSIGN(v466, v467);
    pipe_barrier(PIPE_V);
    TMUL(v466, v462, v460);
    // pto: %t__tmp_v16
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v468 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v419, v41);
    // pto: %t__tmp_v16
    ;
    uint64_t v469 = (uint64_t) v24;
    TASSIGN(v468, v469);
    pipe_barrier(PIPE_V);
    RoundMode v470 = RoundMode::CAST_RINT;
    SaturationMode v471 = SaturationMode::ON;
    TCVT(v468, v466, v470, v471);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v472 = 0;
    // pto: %attended__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v473 = PTOAS__GLOBAL_TENSOR_DATA(v120);
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v474 = 1;
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v475 = 1;
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v476 = 1;
    // pto: %attended__ssa_v0_pview
    ;
    int64_t v477 = v419 * v42;
    // pto: %attended__ssa_v0_pview
    ;
    int64_t v478 = v476 * v477;
    // pto: %attended__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v479 = pto::Shape<1, 1, 1, -1, 512>(v474, v475, v476, v419, v41);
    // pto: %attended__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v480 = pto::Stride<-1, -1, -1, -1, -1>(v475 * v478, v478, v477, v42, v37);
    // pto: %attended__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v481 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v473 + (v472 + v422 * v42 + v423 * v37), v479, v480);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    TSTORE(v481, v468);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %240
  int64_t v482 = (int64_t) ((uint64_t) v168 + (uint64_t) v63);
  // pto: %241
  int64_t v483 = v482 < v49 ? v49 : v482;
  // pto: %signals_v4__ssa_v0_signal_pview
  __gm__ int32_t* v484 = PTOAS__GLOBAL_TENSOR_DATA(v166);
  // pto: %signals_v4__ssa_v0_signal_pview
  const int64_t v485 = 0;
  // pto: %signals_v4__ssa_v0_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v486 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals_v4__ssa_v0_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v487 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals_v4__ssa_v0_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v488 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v484 + (v485 + v483), v486, v487);
  pto::comm::NotifyOp v489 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v488, v177, v489);
  for (int64_t v490 = v48; v490 < v55; v490 += v37) {
    // pto: %242, %243
    ;
    int64_t v491 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v490 * (uint64_t) v40) + (uint64_t) v63);
    // pto: %244
    ;
    int64_t v492 = v491 < v49 ? v49 : v491;
    // pto: %signals_v5__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v493 = PTOAS__GLOBAL_TENSOR_DATA(v166);
    // pto: %signals_v5__ssa_v0_signal_pview
    ;
    const int64_t v494 = 0;
    // pto: %signals_v5__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v495 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v5__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v496 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v5__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v497 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v493 + (v494 + v492), v495, v496);
    pto::comm::WaitCmp v498 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v497, v177, v498);
  }
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %245, %246
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  for (int64_t v499 = v167; v499 < ((int64_t) ((uint64_t) v17 + (uint64_t) v64) / v45); v499 += v52) {
    // pto: %247
    ;
    int64_t v500 = (int64_t) ((uint64_t) v499 * (uint64_t) v45);
    // pto: %248
    ;
    int64_t v501 = (int64_t) ((uint64_t) v500 + (uint64_t) v45);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    for (int64_t v502 = v500; v502 < v501; v502 += v47) {
      // pto: %249
      ;
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      if (v502 < v17) {
        // pto: %250
        ;
        int64_t v503 = (int64_t) ((uint64_t) v502 * (uint64_t) v45);
        // pto: %post_scalar__tile
        ;
        float v504 = (v11)[v503];
        // pto: %252
        ;
        int64_t v505 = (int64_t) ((uint64_t) v502 * (uint64_t) v39);
        // pto: %comb_scalar_0__tile
        ;
        float v506 = (v12)[v505];
        // pto: %255, %comb_scalar_1__tile
        ;
        float v507 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v45)];
        // pto: %257, %comb_scalar_2__tile
        ;
        float v508 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v38)];
        // pto: %259, %comb_scalar_3__tile
        ;
        float v509 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v65)];
        // pto: %262, %260
        ;
        float v510 = (v11)[(int64_t) ((uint64_t) v503 + (uint64_t) v37)];
        // pto: %265, %263
        ;
        float v511 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v37)];
        // pto: %268, %266
        ;
        float v512 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v66)];
        // pto: %271, %269
        ;
        float v513 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v67)];
        // pto: %274, %272
        ;
        float v514 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v68)];
        // pto: %277, %275
        ;
        float v515 = (v11)[(int64_t) ((uint64_t) v503 + (uint64_t) v47)];
        // pto: %280, %278
        ;
        float v516 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v47)];
        // pto: %283, %281
        ;
        float v517 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v69)];
        // pto: %286, %284
        ;
        float v518 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v70)];
        // pto: %289, %287
        ;
        float v519 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v71)];
        // pto: %292, %290
        ;
        float v520 = (v11)[(int64_t) ((uint64_t) v503 + (uint64_t) v64)];
        // pto: %295, %293
        ;
        float v521 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v64)];
        // pto: %298, %296
        ;
        float v522 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v56)];
        // pto: %301, %299
        ;
        float v523 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v72)];
        // pto: %304, %302
        ;
        float v524 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v50)];
        // pto: %x_block__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v525 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %x_block__tile
        ;
        uint64_t v526 = (uint64_t) v32;
        TASSIGN(v525, v526);
        // pto: %305
        ;
        int64_t v527 = v502 < v49 ? v49 : v502;
        // pto: %x__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v528 = PTOAS__GLOBAL_TENSOR_DATA(v120);
        // pto: %x__ssa_v0_pview
        ;
        const int64_t v529 = 0;
        // pto: %x__ssa_v0_pview
        ;
        const int64_t v530 = 4096;
        // pto: %x__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v531 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %x__ssa_v0_pview
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v532 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %x__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v533 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v528 + (v529 + v527 * v530), v531, v532);
        TLOAD(v525, v533);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        // pto: %306
        ;
        int64_t v534 = (int64_t) ((uint64_t) v17 - (uint64_t) v502);
        // pto: %307
        ;
        int64_t v535 = v534 < v49 ? v49 : v534;
        // pto: %308
        ;
        int64_t v536 = v535 < v37 ? v535 : v37;
        // pto: %t__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v537 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %t__tile
        ;
        uint64_t v538 = (uint64_t) v25;
        TASSIGN(v537, v538);
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v539 = 0;
        // pto: %residual_flat__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v540 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v541 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v542 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v543 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        int64_t v544 = v536 * v44;
        // pto: %residual_flat__ssa_v0_pview
        ;
        int64_t v545 = v543 * v544;
        // pto: %residual_flat__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 4096> v546 = pto::Shape<1, 1, 1, -1, 4096>(v541, v542, v543, v536, v42);
        // pto: %residual_flat__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v547 = pto::Stride<-1, -1, -1, -1, -1>(v542 * v545, v545, v544, v44, v37);
        // pto: %residual_flat__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v548 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v540 + (v539 + v527 * v44 + v49 * v37), v546, v547);
        TLOAD(v537, v548);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        // pto: %0
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v549 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %0
        ;
        uint64_t v550 = (uint64_t) v30;
        TASSIGN(v549, v550);
        // pto: %320
        ;
        const int64_t v551 = 0;
        // pto: %320
        ;
        __gm__ bfloat16_t* v552 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %320
        ;
        const int64_t v553 = 1;
        // pto: %320
        ;
        const int64_t v554 = 1;
        // pto: %320
        ;
        const int64_t v555 = 1;
        // pto: %320
        ;
        int64_t v556 = v536 * v44;
        // pto: %320
        ;
        int64_t v557 = v555 * v556;
        // pto: %320
        ;
        pto::Shape<1, 1, 1, -1, 4096> v558 = pto::Shape<1, 1, 1, -1, 4096>(v553, v554, v555, v536, v42);
        // pto: %320
        ;
        pto::Stride<-1, -1, -1, -1, -1> v559 = pto::Stride<-1, -1, -1, -1, -1>(v554 * v557, v557, v556, v44, v37);
        // pto: %320
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v560 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v552 + (v551 + v527 * v44 + v42 * v37), v558, v559);
        TLOAD(v549, v560);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %1
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v561 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %1
        ;
        uint64_t v562 = (uint64_t) v26;
        TASSIGN(v561, v562);
        // pto: %328
        ;
        const int64_t v563 = 0;
        // pto: %328
        ;
        __gm__ bfloat16_t* v564 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %328
        ;
        const int64_t v565 = 1;
        // pto: %328
        ;
        const int64_t v566 = 1;
        // pto: %328
        ;
        const int64_t v567 = 1;
        // pto: %328
        ;
        int64_t v568 = v536 * v44;
        // pto: %328
        ;
        int64_t v569 = v567 * v568;
        // pto: %328
        ;
        pto::Shape<1, 1, 1, -1, 4096> v570 = pto::Shape<1, 1, 1, -1, 4096>(v565, v566, v567, v536, v42);
        // pto: %328
        ;
        pto::Stride<-1, -1, -1, -1, -1> v571 = pto::Stride<-1, -1, -1, -1, -1>(v566 * v569, v569, v568, v44, v37);
        // pto: %328
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v572 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v564 + (v563 + v527 * v44 + v43 * v37), v570, v571);
        TLOAD(v561, v572);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %2
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v573 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %2
        ;
        uint64_t v574 = (uint64_t) v33;
        TASSIGN(v573, v574);
        // pto: %336
        ;
        const int64_t v575 = 0;
        // pto: %336
        ;
        __gm__ bfloat16_t* v576 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %336
        ;
        const int64_t v577 = 1;
        // pto: %336
        ;
        const int64_t v578 = 1;
        // pto: %336
        ;
        const int64_t v579 = 1;
        // pto: %336
        ;
        int64_t v580 = v536 * v44;
        // pto: %336
        ;
        int64_t v581 = v579 * v580;
        // pto: %336
        ;
        pto::Shape<1, 1, 1, -1, 4096> v582 = pto::Shape<1, 1, 1, -1, 4096>(v577, v578, v579, v536, v42);
        // pto: %336
        ;
        pto::Stride<-1, -1, -1, -1, -1> v583 = pto::Stride<-1, -1, -1, -1, -1>(v578 * v581, v581, v580, v44, v37);
        // pto: %336
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v584 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v576 + (v575 + v527 * v44 + v73 * v37), v582, v583);
        TLOAD(v573, v584);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %x_f32__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v585 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %x_f32__tile
        ;
        uint64_t v586 = (uint64_t) v24;
        TASSIGN(v585, v586);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        RoundMode v587 = RoundMode::CAST_ROUND;
        SaturationMode v588 = SaturationMode::ON;
        TCVT(v585, v525, v587, v588);
        // pto: %res_0__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v589 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %res_0__tile
        ;
        uint64_t v590 = (uint64_t) v32;
        TASSIGN(v589, v590);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        RoundMode v591 = RoundMode::CAST_ROUND;
        SaturationMode v592 = SaturationMode::ON;
        TCVT(v589, v537, v591, v592);
        // pto: %res_1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v593 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %res_1__tile
        ;
        uint64_t v594 = (uint64_t) v25;
        TASSIGN(v593, v594);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v595 = RoundMode::CAST_ROUND;
        SaturationMode v596 = SaturationMode::ON;
        TCVT(v593, v549, v595, v596);
        // pto: %res_2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v597 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %res_2__tile
        ;
        uint64_t v598 = (uint64_t) v30;
        TASSIGN(v597, v598);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        RoundMode v599 = RoundMode::CAST_ROUND;
        SaturationMode v600 = SaturationMode::ON;
        TCVT(v597, v561, v599, v600);
        // pto: %res_3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v601 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %res_3__tile
        ;
        uint64_t v602 = (uint64_t) v26;
        TASSIGN(v601, v602);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v603 = RoundMode::CAST_ROUND;
        SaturationMode v604 = SaturationMode::ON;
        TCVT(v601, v573, v603, v604);
        // pto: %single_y__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v605 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_y__tile
        ;
        uint64_t v606 = (uint64_t) v33;
        TASSIGN(v605, v606);
        pipe_barrier(PIPE_V);
        TMULS(v605, v585, v504);
        // pto: %single_weighted_0__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v607 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %single_weighted_0__tile
        ;
        uint64_t v608 = (uint64_t) v34;
        TASSIGN(v607, v608);
        TMULS(v607, v589, v506);
        // pto: %single_y_v1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v609 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_y_v1__tile
        ;
        uint64_t v610 = (uint64_t) v33;
        TASSIGN(v609, v610);
        pipe_barrier(PIPE_V);
        TADD(v609, v605, v607);
        // pto: %single_weighted_1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v611 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %single_weighted_1__tile
        ;
        uint64_t v612 = (uint64_t) v34;
        TASSIGN(v611, v612);
        pipe_barrier(PIPE_V);
        TMULS(v611, v593, v507);
        // pto: %single_y_v2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v613 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_y_v2__tile
        ;
        uint64_t v614 = (uint64_t) v33;
        TASSIGN(v613, v614);
        pipe_barrier(PIPE_V);
        TADD(v613, v609, v611);
        // pto: %single_weighted_2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v615 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %single_weighted_2__tile
        ;
        uint64_t v616 = (uint64_t) v34;
        TASSIGN(v615, v616);
        pipe_barrier(PIPE_V);
        TMULS(v615, v597, v508);
        // pto: %single_y_v3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v617 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_y_v3__tile
        ;
        uint64_t v618 = (uint64_t) v33;
        TASSIGN(v617, v618);
        pipe_barrier(PIPE_V);
        TADD(v617, v613, v615);
        // pto: %single_weighted_3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v619 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %single_weighted_3__tile
        ;
        uint64_t v620 = (uint64_t) v34;
        TASSIGN(v619, v620);
        pipe_barrier(PIPE_V);
        TMULS(v619, v601, v509);
        // pto: %single_y_v4__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v621 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_y_v4__tile
        ;
        uint64_t v622 = (uint64_t) v33;
        TASSIGN(v621, v622);
        pipe_barrier(PIPE_V);
        TADD(v621, v617, v619);
        // pto: %single_result__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v623 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_result__tile
        ;
        uint64_t v624 = (uint64_t) v35;
        TASSIGN(v623, v624);
        pipe_barrier(PIPE_V);
        RoundMode v625 = RoundMode::CAST_RINT;
        SaturationMode v626 = SaturationMode::ON;
        TCVT(v623, v621, v625, v626);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        v623.SetValidShape(v37, v42);
        // pto: %4
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v627 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %4
        ;
        uint64_t v628 = (uint64_t) v33;
        TASSIGN(v627, v628);
        pipe_barrier(PIPE_V);
        TMULS(v627, v585, v510);
        // pto: %5
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v629 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %5
        ;
        uint64_t v630 = (uint64_t) v34;
        TASSIGN(v629, v630);
        TMULS(v629, v589, v511);
        // pto: %6
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v631 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %6
        ;
        uint64_t v632 = (uint64_t) v33;
        TASSIGN(v631, v632);
        pipe_barrier(PIPE_V);
        TADD(v631, v627, v629);
        // pto: %7
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v633 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %7
        ;
        uint64_t v634 = (uint64_t) v34;
        TASSIGN(v633, v634);
        pipe_barrier(PIPE_V);
        TMULS(v633, v593, v512);
        // pto: %8
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v635 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %8
        ;
        uint64_t v636 = (uint64_t) v33;
        TASSIGN(v635, v636);
        pipe_barrier(PIPE_V);
        TADD(v635, v631, v633);
        // pto: %9
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v637 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %9
        ;
        uint64_t v638 = (uint64_t) v34;
        TASSIGN(v637, v638);
        pipe_barrier(PIPE_V);
        TMULS(v637, v597, v513);
        // pto: %10
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v639 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %10
        ;
        uint64_t v640 = (uint64_t) v33;
        TASSIGN(v639, v640);
        pipe_barrier(PIPE_V);
        TADD(v639, v635, v637);
        // pto: %11
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v641 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %11
        ;
        uint64_t v642 = (uint64_t) v34;
        TASSIGN(v641, v642);
        pipe_barrier(PIPE_V);
        TMULS(v641, v601, v514);
        // pto: %12
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v643 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %12
        ;
        uint64_t v644 = (uint64_t) v33;
        TASSIGN(v643, v644);
        pipe_barrier(PIPE_V);
        TADD(v643, v639, v641);
        // pto: %13
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v645 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %13
        ;
        uint64_t v646 = (uint64_t) v36;
        TASSIGN(v645, v646);
        pipe_barrier(PIPE_V);
        RoundMode v647 = RoundMode::CAST_RINT;
        SaturationMode v648 = SaturationMode::ON;
        TCVT(v645, v643, v647, v648);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        v645.SetValidShape(v37, v42);
        // pto: %15
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v649 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %15
        ;
        uint64_t v650 = (uint64_t) v33;
        TASSIGN(v649, v650);
        pipe_barrier(PIPE_V);
        TMULS(v649, v585, v515);
        // pto: %16
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v651 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %16
        ;
        uint64_t v652 = (uint64_t) v34;
        TASSIGN(v651, v652);
        TMULS(v651, v589, v516);
        // pto: %17
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v653 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %17
        ;
        uint64_t v654 = (uint64_t) v33;
        TASSIGN(v653, v654);
        pipe_barrier(PIPE_V);
        TADD(v653, v649, v651);
        // pto: %18
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v655 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %18
        ;
        uint64_t v656 = (uint64_t) v34;
        TASSIGN(v655, v656);
        pipe_barrier(PIPE_V);
        TMULS(v655, v593, v517);
        // pto: %19
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v657 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %19
        ;
        uint64_t v658 = (uint64_t) v33;
        TASSIGN(v657, v658);
        pipe_barrier(PIPE_V);
        TADD(v657, v653, v655);
        // pto: %20
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v659 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %20
        ;
        uint64_t v660 = (uint64_t) v34;
        TASSIGN(v659, v660);
        pipe_barrier(PIPE_V);
        TMULS(v659, v597, v518);
        // pto: %21
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v661 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %21
        ;
        uint64_t v662 = (uint64_t) v33;
        TASSIGN(v661, v662);
        pipe_barrier(PIPE_V);
        TADD(v661, v657, v659);
        // pto: %22
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v663 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %22
        ;
        uint64_t v664 = (uint64_t) v34;
        TASSIGN(v663, v664);
        pipe_barrier(PIPE_V);
        TMULS(v663, v601, v519);
        // pto: %23
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v665 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %23
        ;
        uint64_t v666 = (uint64_t) v33;
        TASSIGN(v665, v666);
        pipe_barrier(PIPE_V);
        TADD(v665, v661, v663);
        // pto: %24
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v667 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %24
        ;
        uint64_t v668 = (uint64_t) v33;
        TASSIGN(v667, v668);
        pipe_barrier(PIPE_V);
        RoundMode v669 = RoundMode::CAST_RINT;
        SaturationMode v670 = SaturationMode::ON;
        TCVT(v667, v665, v669, v670);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        v667.SetValidShape(v37, v42);
        // pto: %26
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v671 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %26
        ;
        uint64_t v672 = (uint64_t) v24;
        TASSIGN(v671, v672);
        TMULS(v671, v585, v520);
        // pto: %27
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v673 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %27
        ;
        uint64_t v674 = (uint64_t) v32;
        TASSIGN(v673, v674);
        TMULS(v673, v589, v521);
        // pto: %28
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v675 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %28
        ;
        uint64_t v676 = (uint64_t) v24;
        TASSIGN(v675, v676);
        pipe_barrier(PIPE_V);
        TADD(v675, v671, v673);
        // pto: %29
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v677 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %29
        ;
        uint64_t v678 = (uint64_t) v32;
        TASSIGN(v677, v678);
        pipe_barrier(PIPE_V);
        TMULS(v677, v593, v522);
        // pto: %30
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v679 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %30
        ;
        uint64_t v680 = (uint64_t) v24;
        TASSIGN(v679, v680);
        pipe_barrier(PIPE_V);
        TADD(v679, v675, v677);
        // pto: %31
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v681 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %31
        ;
        uint64_t v682 = (uint64_t) v32;
        TASSIGN(v681, v682);
        pipe_barrier(PIPE_V);
        TMULS(v681, v597, v523);
        // pto: %32
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v683 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %32
        ;
        uint64_t v684 = (uint64_t) v24;
        TASSIGN(v683, v684);
        pipe_barrier(PIPE_V);
        TADD(v683, v679, v681);
        // pto: %33
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v685 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %33
        ;
        uint64_t v686 = (uint64_t) v32;
        TASSIGN(v685, v686);
        pipe_barrier(PIPE_V);
        TMULS(v685, v601, v524);
        // pto: %34
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v687 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %34
        ;
        uint64_t v688 = (uint64_t) v24;
        TASSIGN(v687, v688);
        pipe_barrier(PIPE_V);
        TADD(v687, v683, v685);
        // pto: %35
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v689 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %35
        ;
        uint64_t v690 = (uint64_t) v24;
        TASSIGN(v689, v690);
        pipe_barrier(PIPE_V);
        RoundMode v691 = RoundMode::CAST_RINT;
        SaturationMode v692 = SaturationMode::ON;
        TCVT(v689, v687, v691, v692);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        v689.SetValidShape(v37, v42);
        // pto: %y_flat__iter_v3_pview
        ;
        __gm__ bfloat16_t* v693 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %y_flat__iter_v3_pview
        ;
        const int64_t v694 = 0;
        // pto: %y_flat__iter_v3_pview
        ;
        const int64_t v695 = 16384;
        // pto: %y_flat__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v696 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__iter_v3_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v697 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v698 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v693 + (v694 + v527 * v695), v696, v697);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        TSTORE(v698, v623);
        // pto: %y_flat__tile_pview
        ;
        __gm__ bfloat16_t* v699 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %y_flat__tile_pview
        ;
        const int64_t v700 = 4096;
        // pto: %y_flat__tile_pview
        ;
        const int64_t v701 = 16384;
        // pto: %y_flat__tile_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v702 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__tile_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v703 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__tile_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v704 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v699 + (v700 + v527 * v701), v702, v703);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        TSTORE(v704, v645);
        // pto: %402
        ;
        __gm__ bfloat16_t* v705 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %402
        ;
        const int64_t v706 = 8192;
        // pto: %402
        ;
        const int64_t v707 = 16384;
        // pto: %402
        ;
        pto::Shape<1, 1, 1, 1, 4096> v708 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %402
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v709 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %402
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v710 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v705 + (v706 + v527 * v707), v708, v709);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        TSTORE(v710, v667);
        // pto: %405
        ;
        __gm__ bfloat16_t* v711 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %405
        ;
        const int64_t v712 = 12288;
        // pto: %405
        ;
        const int64_t v713 = 16384;
        // pto: %405
        ;
        pto::Shape<1, 1, 1, 1, 4096> v714 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %405
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v715 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %405
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v716 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v711 + (v712 + v527 * v713), v714, v715);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        TSTORE(v716, v689);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      // pto: %406
      ;
      int64_t v717 = (int64_t) ((uint64_t) v502 + (uint64_t) v37);
      // pto: %407
      ;
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      if (v717 < v17) {
        // pto: %410
        ;
        int64_t v718 = (int64_t) ((uint64_t) v717 * (uint64_t) v45);
        // pto: %408
        ;
        float v719 = (v11)[v718];
        // pto: %414
        ;
        int64_t v720 = (int64_t) ((uint64_t) v717 * (uint64_t) v39);
        // pto: %412
        ;
        float v721 = (v12)[v720];
        // pto: %419, %416
        ;
        float v722 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v45)];
        // pto: %423, %420
        ;
        float v723 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v38)];
        // pto: %427, %424
        ;
        float v724 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v65)];
        // pto: %431, %428
        ;
        float v725 = (v11)[(int64_t) ((uint64_t) v718 + (uint64_t) v37)];
        // pto: %435, %432
        ;
        float v726 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v37)];
        // pto: %439, %436
        ;
        float v727 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v66)];
        // pto: %443, %440
        ;
        float v728 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v67)];
        // pto: %447, %444
        ;
        float v729 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v68)];
        // pto: %451, %448
        ;
        float v730 = (v11)[(int64_t) ((uint64_t) v718 + (uint64_t) v47)];
        // pto: %455, %452
        ;
        float v731 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v47)];
        // pto: %459, %456
        ;
        float v732 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v69)];
        // pto: %463, %460
        ;
        float v733 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v70)];
        // pto: %467, %464
        ;
        float v734 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v71)];
        // pto: %471, %468
        ;
        float v735 = (v11)[(int64_t) ((uint64_t) v718 + (uint64_t) v64)];
        // pto: %475, %472
        ;
        float v736 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v64)];
        // pto: %479, %476
        ;
        float v737 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v56)];
        // pto: %483, %480
        ;
        float v738 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v72)];
        // pto: %487, %484
        ;
        float v739 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v50)];
        // pto: %37
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v740 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %37
        ;
        uint64_t v741 = (uint64_t) v32;
        TASSIGN(v740, v741);
        // pto: %489
        ;
        int64_t v742 = v717 < v49 ? v49 : v717;
        // pto: %490
        ;
        __gm__ bfloat16_t* v743 = PTOAS__GLOBAL_TENSOR_DATA(v120);
        // pto: %490
        ;
        const int64_t v744 = 0;
        // pto: %490
        ;
        const int64_t v745 = 4096;
        // pto: %490
        ;
        pto::Shape<1, 1, 1, 1, 4096> v746 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %490
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v747 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %490
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v748 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v743 + (v744 + v742 * v745), v746, v747);
        TLOAD(v740, v748);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %491, %492
        ;
        int64_t v749 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v17 - (uint64_t) v502) + (uint64_t) v74);
        // pto: %493
        ;
        int64_t v750 = v749 < v49 ? v49 : v749;
        // pto: %494
        ;
        int64_t v751 = v750 < v37 ? v750 : v37;
        // pto: %38
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v752 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %38
        ;
        uint64_t v753 = (uint64_t) v25;
        TASSIGN(v752, v753);
        // pto: %501
        ;
        const int64_t v754 = 0;
        // pto: %501
        ;
        __gm__ bfloat16_t* v755 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %501
        ;
        const int64_t v756 = 1;
        // pto: %501
        ;
        const int64_t v757 = 1;
        // pto: %501
        ;
        const int64_t v758 = 1;
        // pto: %501
        ;
        int64_t v759 = v751 * v44;
        // pto: %501
        ;
        int64_t v760 = v758 * v759;
        // pto: %501
        ;
        pto::Shape<1, 1, 1, -1, 4096> v761 = pto::Shape<1, 1, 1, -1, 4096>(v756, v757, v758, v751, v42);
        // pto: %501
        ;
        pto::Stride<-1, -1, -1, -1, -1> v762 = pto::Stride<-1, -1, -1, -1, -1>(v757 * v760, v760, v759, v44, v37);
        // pto: %501
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v763 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v755 + (v754 + v742 * v44 + v49 * v37), v761, v762);
        TLOAD(v752, v763);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %39
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v764 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %39
        ;
        uint64_t v765 = (uint64_t) v30;
        TASSIGN(v764, v765);
        // pto: %512
        ;
        const int64_t v766 = 0;
        // pto: %512
        ;
        __gm__ bfloat16_t* v767 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %512
        ;
        const int64_t v768 = 1;
        // pto: %512
        ;
        const int64_t v769 = 1;
        // pto: %512
        ;
        const int64_t v770 = 1;
        // pto: %512
        ;
        int64_t v771 = v751 * v44;
        // pto: %512
        ;
        int64_t v772 = v770 * v771;
        // pto: %512
        ;
        pto::Shape<1, 1, 1, -1, 4096> v773 = pto::Shape<1, 1, 1, -1, 4096>(v768, v769, v770, v751, v42);
        // pto: %512
        ;
        pto::Stride<-1, -1, -1, -1, -1> v774 = pto::Stride<-1, -1, -1, -1, -1>(v769 * v772, v772, v771, v44, v37);
        // pto: %512
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v775 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v767 + (v766 + v742 * v44 + v42 * v37), v773, v774);
        TLOAD(v764, v775);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %40
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v776 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %40
        ;
        uint64_t v777 = (uint64_t) v26;
        TASSIGN(v776, v777);
        // pto: %523
        ;
        const int64_t v778 = 0;
        // pto: %523
        ;
        __gm__ bfloat16_t* v779 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %523
        ;
        const int64_t v780 = 1;
        // pto: %523
        ;
        const int64_t v781 = 1;
        // pto: %523
        ;
        const int64_t v782 = 1;
        // pto: %523
        ;
        int64_t v783 = v751 * v44;
        // pto: %523
        ;
        int64_t v784 = v782 * v783;
        // pto: %523
        ;
        pto::Shape<1, 1, 1, -1, 4096> v785 = pto::Shape<1, 1, 1, -1, 4096>(v780, v781, v782, v751, v42);
        // pto: %523
        ;
        pto::Stride<-1, -1, -1, -1, -1> v786 = pto::Stride<-1, -1, -1, -1, -1>(v781 * v784, v784, v783, v44, v37);
        // pto: %523
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v787 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v779 + (v778 + v742 * v44 + v43 * v37), v785, v786);
        TLOAD(v776, v787);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        // pto: %41
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v788 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %41
        ;
        uint64_t v789 = (uint64_t) v33;
        TASSIGN(v788, v789);
        // pto: %534
        ;
        const int64_t v790 = 0;
        // pto: %534
        ;
        __gm__ bfloat16_t* v791 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %534
        ;
        const int64_t v792 = 1;
        // pto: %534
        ;
        const int64_t v793 = 1;
        // pto: %534
        ;
        const int64_t v794 = 1;
        // pto: %534
        ;
        int64_t v795 = v751 * v44;
        // pto: %534
        ;
        int64_t v796 = v794 * v795;
        // pto: %534
        ;
        pto::Shape<1, 1, 1, -1, 4096> v797 = pto::Shape<1, 1, 1, -1, 4096>(v792, v793, v794, v751, v42);
        // pto: %534
        ;
        pto::Stride<-1, -1, -1, -1, -1> v798 = pto::Stride<-1, -1, -1, -1, -1>(v793 * v796, v796, v795, v44, v37);
        // pto: %534
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v799 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v791 + (v790 + v742 * v44 + v73 * v37), v797, v798);
        TLOAD(v788, v799);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        // pto: %42
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v800 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %42
        ;
        uint64_t v801 = (uint64_t) v24;
        TASSIGN(v800, v801);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v802 = RoundMode::CAST_ROUND;
        SaturationMode v803 = SaturationMode::ON;
        TCVT(v800, v740, v802, v803);
        // pto: %43
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v804 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %43
        ;
        uint64_t v805 = (uint64_t) v32;
        TASSIGN(v804, v805);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        RoundMode v806 = RoundMode::CAST_ROUND;
        SaturationMode v807 = SaturationMode::ON;
        TCVT(v804, v752, v806, v807);
        // pto: %44
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v808 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %44
        ;
        uint64_t v809 = (uint64_t) v25;
        TASSIGN(v808, v809);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v810 = RoundMode::CAST_ROUND;
        SaturationMode v811 = SaturationMode::ON;
        TCVT(v808, v764, v810, v811);
        // pto: %45
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v812 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %45
        ;
        uint64_t v813 = (uint64_t) v30;
        TASSIGN(v812, v813);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        RoundMode v814 = RoundMode::CAST_ROUND;
        SaturationMode v815 = SaturationMode::ON;
        TCVT(v812, v776, v814, v815);
        // pto: %46
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v816 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %46
        ;
        uint64_t v817 = (uint64_t) v26;
        TASSIGN(v816, v817);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        RoundMode v818 = RoundMode::CAST_ROUND;
        SaturationMode v819 = SaturationMode::ON;
        TCVT(v816, v788, v818, v819);
        // pto: %47
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v820 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %47
        ;
        uint64_t v821 = (uint64_t) v33;
        TASSIGN(v820, v821);
        pipe_barrier(PIPE_V);
        TMULS(v820, v800, v719);
        // pto: %48
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v822 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %48
        ;
        uint64_t v823 = (uint64_t) v34;
        TASSIGN(v822, v823);
        TMULS(v822, v804, v721);
        // pto: %49
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v824 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %49
        ;
        uint64_t v825 = (uint64_t) v33;
        TASSIGN(v824, v825);
        pipe_barrier(PIPE_V);
        TADD(v824, v820, v822);
        // pto: %50
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v826 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %50
        ;
        uint64_t v827 = (uint64_t) v34;
        TASSIGN(v826, v827);
        pipe_barrier(PIPE_V);
        TMULS(v826, v808, v722);
        // pto: %51
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v828 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %51
        ;
        uint64_t v829 = (uint64_t) v33;
        TASSIGN(v828, v829);
        pipe_barrier(PIPE_V);
        TADD(v828, v824, v826);
        // pto: %52
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v830 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %52
        ;
        uint64_t v831 = (uint64_t) v34;
        TASSIGN(v830, v831);
        pipe_barrier(PIPE_V);
        TMULS(v830, v812, v723);
        // pto: %53
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v832 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %53
        ;
        uint64_t v833 = (uint64_t) v33;
        TASSIGN(v832, v833);
        pipe_barrier(PIPE_V);
        TADD(v832, v828, v830);
        // pto: %54
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v834 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %54
        ;
        uint64_t v835 = (uint64_t) v34;
        TASSIGN(v834, v835);
        pipe_barrier(PIPE_V);
        TMULS(v834, v816, v724);
        // pto: %55
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v836 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %55
        ;
        uint64_t v837 = (uint64_t) v33;
        TASSIGN(v836, v837);
        pipe_barrier(PIPE_V);
        TADD(v836, v832, v834);
        // pto: %56
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v838 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %56
        ;
        uint64_t v839 = (uint64_t) v35;
        TASSIGN(v838, v839);
        pipe_barrier(PIPE_V);
        RoundMode v840 = RoundMode::CAST_RINT;
        SaturationMode v841 = SaturationMode::ON;
        TCVT(v838, v836, v840, v841);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v838.SetValidShape(v37, v42);
        // pto: %58
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v842 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %58
        ;
        uint64_t v843 = (uint64_t) v33;
        TASSIGN(v842, v843);
        pipe_barrier(PIPE_V);
        TMULS(v842, v800, v725);
        // pto: %59
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v844 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %59
        ;
        uint64_t v845 = (uint64_t) v34;
        TASSIGN(v844, v845);
        TMULS(v844, v804, v726);
        // pto: %60
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v846 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %60
        ;
        uint64_t v847 = (uint64_t) v33;
        TASSIGN(v846, v847);
        pipe_barrier(PIPE_V);
        TADD(v846, v842, v844);
        // pto: %61
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v848 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %61
        ;
        uint64_t v849 = (uint64_t) v34;
        TASSIGN(v848, v849);
        pipe_barrier(PIPE_V);
        TMULS(v848, v808, v727);
        // pto: %62
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v850 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %62
        ;
        uint64_t v851 = (uint64_t) v33;
        TASSIGN(v850, v851);
        pipe_barrier(PIPE_V);
        TADD(v850, v846, v848);
        // pto: %63
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v852 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %63
        ;
        uint64_t v853 = (uint64_t) v34;
        TASSIGN(v852, v853);
        pipe_barrier(PIPE_V);
        TMULS(v852, v812, v728);
        // pto: %64
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v854 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %64
        ;
        uint64_t v855 = (uint64_t) v33;
        TASSIGN(v854, v855);
        pipe_barrier(PIPE_V);
        TADD(v854, v850, v852);
        // pto: %65
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v856 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %65
        ;
        uint64_t v857 = (uint64_t) v34;
        TASSIGN(v856, v857);
        pipe_barrier(PIPE_V);
        TMULS(v856, v816, v729);
        // pto: %66
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v858 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %66
        ;
        uint64_t v859 = (uint64_t) v33;
        TASSIGN(v858, v859);
        pipe_barrier(PIPE_V);
        TADD(v858, v854, v856);
        // pto: %67
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v860 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %67
        ;
        uint64_t v861 = (uint64_t) v36;
        TASSIGN(v860, v861);
        pipe_barrier(PIPE_V);
        RoundMode v862 = RoundMode::CAST_RINT;
        SaturationMode v863 = SaturationMode::ON;
        TCVT(v860, v858, v862, v863);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        v860.SetValidShape(v37, v42);
        // pto: %69
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v864 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %69
        ;
        uint64_t v865 = (uint64_t) v33;
        TASSIGN(v864, v865);
        pipe_barrier(PIPE_V);
        TMULS(v864, v800, v730);
        // pto: %70
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v866 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %70
        ;
        uint64_t v867 = (uint64_t) v34;
        TASSIGN(v866, v867);
        TMULS(v866, v804, v731);
        // pto: %71
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v868 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %71
        ;
        uint64_t v869 = (uint64_t) v33;
        TASSIGN(v868, v869);
        pipe_barrier(PIPE_V);
        TADD(v868, v864, v866);
        // pto: %72
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v870 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %72
        ;
        uint64_t v871 = (uint64_t) v34;
        TASSIGN(v870, v871);
        pipe_barrier(PIPE_V);
        TMULS(v870, v808, v732);
        // pto: %73
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v872 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %73
        ;
        uint64_t v873 = (uint64_t) v33;
        TASSIGN(v872, v873);
        pipe_barrier(PIPE_V);
        TADD(v872, v868, v870);
        // pto: %74
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v874 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %74
        ;
        uint64_t v875 = (uint64_t) v34;
        TASSIGN(v874, v875);
        pipe_barrier(PIPE_V);
        TMULS(v874, v812, v733);
        // pto: %75
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v876 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %75
        ;
        uint64_t v877 = (uint64_t) v33;
        TASSIGN(v876, v877);
        pipe_barrier(PIPE_V);
        TADD(v876, v872, v874);
        // pto: %76
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v878 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %76
        ;
        uint64_t v879 = (uint64_t) v34;
        TASSIGN(v878, v879);
        pipe_barrier(PIPE_V);
        TMULS(v878, v816, v734);
        // pto: %77
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v880 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %77
        ;
        uint64_t v881 = (uint64_t) v33;
        TASSIGN(v880, v881);
        pipe_barrier(PIPE_V);
        TADD(v880, v876, v878);
        // pto: %78
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v882 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %78
        ;
        uint64_t v883 = (uint64_t) v33;
        TASSIGN(v882, v883);
        pipe_barrier(PIPE_V);
        RoundMode v884 = RoundMode::CAST_RINT;
        SaturationMode v885 = SaturationMode::ON;
        TCVT(v882, v880, v884, v885);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        v882.SetValidShape(v37, v42);
        // pto: %80
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v886 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %80
        ;
        uint64_t v887 = (uint64_t) v24;
        TASSIGN(v886, v887);
        TMULS(v886, v800, v735);
        // pto: %81
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v888 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %81
        ;
        uint64_t v889 = (uint64_t) v32;
        TASSIGN(v888, v889);
        TMULS(v888, v804, v736);
        // pto: %82
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v890 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %82
        ;
        uint64_t v891 = (uint64_t) v24;
        TASSIGN(v890, v891);
        pipe_barrier(PIPE_V);
        TADD(v890, v886, v888);
        // pto: %83
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v892 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %83
        ;
        uint64_t v893 = (uint64_t) v32;
        TASSIGN(v892, v893);
        pipe_barrier(PIPE_V);
        TMULS(v892, v808, v737);
        // pto: %84
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v894 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %84
        ;
        uint64_t v895 = (uint64_t) v24;
        TASSIGN(v894, v895);
        pipe_barrier(PIPE_V);
        TADD(v894, v890, v892);
        // pto: %85
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v896 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %85
        ;
        uint64_t v897 = (uint64_t) v32;
        TASSIGN(v896, v897);
        pipe_barrier(PIPE_V);
        TMULS(v896, v812, v738);
        // pto: %86
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v898 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %86
        ;
        uint64_t v899 = (uint64_t) v24;
        TASSIGN(v898, v899);
        pipe_barrier(PIPE_V);
        TADD(v898, v894, v896);
        // pto: %87
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v900 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %87
        ;
        uint64_t v901 = (uint64_t) v32;
        TASSIGN(v900, v901);
        pipe_barrier(PIPE_V);
        TMULS(v900, v816, v739);
        // pto: %88
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v902 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %88
        ;
        uint64_t v903 = (uint64_t) v24;
        TASSIGN(v902, v903);
        pipe_barrier(PIPE_V);
        TADD(v902, v898, v900);
        // pto: %89
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v904 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %89
        ;
        uint64_t v905 = (uint64_t) v24;
        TASSIGN(v904, v905);
        pipe_barrier(PIPE_V);
        RoundMode v906 = RoundMode::CAST_RINT;
        SaturationMode v907 = SaturationMode::ON;
        TCVT(v904, v902, v906, v907);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        v904.SetValidShape(v37, v42);
        // pto: %y_flat__phi_v9_pview
        ;
        __gm__ bfloat16_t* v908 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %y_flat__phi_v9_pview
        ;
        const int64_t v909 = 0;
        // pto: %y_flat__phi_v9_pview
        ;
        const int64_t v910 = 16384;
        // pto: %y_flat__phi_v9_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v911 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__phi_v9_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v912 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__phi_v9_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v913 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v908 + (v909 + v742 * v910), v911, v912);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v913, v838);
        // pto: %621
        ;
        __gm__ bfloat16_t* v914 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %621
        ;
        const int64_t v915 = 4096;
        // pto: %621
        ;
        const int64_t v916 = 16384;
        // pto: %621
        ;
        pto::Shape<1, 1, 1, 1, 4096> v917 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %621
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v918 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %621
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v919 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v914 + (v915 + v742 * v916), v917, v918);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v919, v860);
        // pto: %625
        ;
        __gm__ bfloat16_t* v920 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %625
        ;
        const int64_t v921 = 8192;
        // pto: %625
        ;
        const int64_t v922 = 16384;
        // pto: %625
        ;
        pto::Shape<1, 1, 1, 1, 4096> v923 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %625
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v924 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %625
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v925 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v920 + (v921 + v742 * v922), v923, v924);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        TSTORE(v925, v882);
        // pto: %629
        ;
        __gm__ bfloat16_t* v926 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %629
        ;
        const int64_t v927 = 12288;
        // pto: %629
        ;
        const int64_t v928 = 16384;
        // pto: %629
        ;
        pto::Shape<1, 1, 1, 1, 4096> v929 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %629
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v930 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %629
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v931 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v926 + (v927 + v742 * v928), v929, v930);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        TSTORE(v931, v904);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    // pto: %630, %631, %632
    ;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    if ((int64_t) ((uint64_t) ((int64_t) (uint64_t) v500 - (uint64_t) v501) + (uint64_t) v45) == v37) {
      // pto: %633
      ;
      if (v501 < v17) {
        // pto: %91
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v932 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %91
        ;
        uint64_t v933 = (uint64_t) v32;
        TASSIGN(v932, v933);
        // pto: %634
        ;
        int64_t v934 = v501 < v49 ? v49 : v501;
        // pto: %635
        ;
        __gm__ bfloat16_t* v935 = PTOAS__GLOBAL_TENSOR_DATA(v120);
        // pto: %635
        ;
        const int64_t v936 = 0;
        // pto: %635
        ;
        const int64_t v937 = 4096;
        // pto: %635
        ;
        pto::Shape<1, 1, 1, 1, 4096> v938 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %635
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v939 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %635
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v940 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v935 + (v936 + v934 * v937), v938, v939);
        TLOAD(v932, v940);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %92
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v941 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %92
        ;
        uint64_t v942 = (uint64_t) v24;
        TASSIGN(v941, v942);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v943 = RoundMode::CAST_ROUND;
        SaturationMode v944 = SaturationMode::ON;
        TCVT(v941, v932, v943, v944);
        // pto: %636
        ;
        int64_t v945 = (int64_t) ((uint64_t) v17 - (uint64_t) v501);
        // pto: %637
        ;
        int64_t v946 = v945 < v49 ? v49 : v945;
        // pto: %638
        ;
        int64_t v947 = v946 < v37 ? v946 : v37;
        // pto: %93
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v948 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %93
        ;
        uint64_t v949 = (uint64_t) v25;
        TASSIGN(v948, v949);
        // pto: %643
        ;
        const int64_t v950 = 0;
        // pto: %643
        ;
        __gm__ bfloat16_t* v951 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %643
        ;
        const int64_t v952 = 1;
        // pto: %643
        ;
        const int64_t v953 = 1;
        // pto: %643
        ;
        const int64_t v954 = 1;
        // pto: %643
        ;
        int64_t v955 = v947 * v44;
        // pto: %643
        ;
        int64_t v956 = v954 * v955;
        // pto: %643
        ;
        pto::Shape<1, 1, 1, -1, 4096> v957 = pto::Shape<1, 1, 1, -1, 4096>(v952, v953, v954, v947, v42);
        // pto: %643
        ;
        pto::Stride<-1, -1, -1, -1, -1> v958 = pto::Stride<-1, -1, -1, -1, -1>(v953 * v956, v956, v955, v44, v37);
        // pto: %643
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v959 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v951 + (v950 + v934 * v44 + v49 * v37), v957, v958);
        TLOAD(v948, v959);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %94
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v960 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %94
        ;
        uint64_t v961 = (uint64_t) v32;
        TASSIGN(v960, v961);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v962 = RoundMode::CAST_ROUND;
        SaturationMode v963 = SaturationMode::ON;
        TCVT(v960, v948, v962, v963);
        // pto: %95
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v964 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %95
        ;
        uint64_t v965 = (uint64_t) v30;
        TASSIGN(v964, v965);
        // pto: %654
        ;
        const int64_t v966 = 0;
        // pto: %654
        ;
        __gm__ bfloat16_t* v967 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %654
        ;
        const int64_t v968 = 1;
        // pto: %654
        ;
        const int64_t v969 = 1;
        // pto: %654
        ;
        const int64_t v970 = 1;
        // pto: %654
        ;
        int64_t v971 = v947 * v44;
        // pto: %654
        ;
        int64_t v972 = v970 * v971;
        // pto: %654
        ;
        pto::Shape<1, 1, 1, -1, 4096> v973 = pto::Shape<1, 1, 1, -1, 4096>(v968, v969, v970, v947, v42);
        // pto: %654
        ;
        pto::Stride<-1, -1, -1, -1, -1> v974 = pto::Stride<-1, -1, -1, -1, -1>(v969 * v972, v972, v971, v44, v37);
        // pto: %654
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v975 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v967 + (v966 + v934 * v44 + v42 * v37), v973, v974);
        TLOAD(v964, v975);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %96
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v976 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %96
        ;
        uint64_t v977 = (uint64_t) v25;
        TASSIGN(v976, v977);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v978 = RoundMode::CAST_ROUND;
        SaturationMode v979 = SaturationMode::ON;
        TCVT(v976, v964, v978, v979);
        // pto: %97
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v980 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %97
        ;
        uint64_t v981 = (uint64_t) v26;
        TASSIGN(v980, v981);
        // pto: %665
        ;
        const int64_t v982 = 0;
        // pto: %665
        ;
        __gm__ bfloat16_t* v983 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %665
        ;
        const int64_t v984 = 1;
        // pto: %665
        ;
        const int64_t v985 = 1;
        // pto: %665
        ;
        const int64_t v986 = 1;
        // pto: %665
        ;
        int64_t v987 = v947 * v44;
        // pto: %665
        ;
        int64_t v988 = v986 * v987;
        // pto: %665
        ;
        pto::Shape<1, 1, 1, -1, 4096> v989 = pto::Shape<1, 1, 1, -1, 4096>(v984, v985, v986, v947, v42);
        // pto: %665
        ;
        pto::Stride<-1, -1, -1, -1, -1> v990 = pto::Stride<-1, -1, -1, -1, -1>(v985 * v988, v988, v987, v44, v37);
        // pto: %665
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v991 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v983 + (v982 + v934 * v44 + v43 * v37), v989, v990);
        TLOAD(v980, v991);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %98
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v992 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %98
        ;
        uint64_t v993 = (uint64_t) v30;
        TASSIGN(v992, v993);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v994 = RoundMode::CAST_ROUND;
        SaturationMode v995 = SaturationMode::ON;
        TCVT(v992, v980, v994, v995);
        // pto: %99
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v996 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %99
        ;
        uint64_t v997 = (uint64_t) v33;
        TASSIGN(v996, v997);
        // pto: %676
        ;
        const int64_t v998 = 0;
        // pto: %676
        ;
        __gm__ bfloat16_t* v999 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %676
        ;
        const int64_t v1000 = 1;
        // pto: %676
        ;
        const int64_t v1001 = 1;
        // pto: %676
        ;
        const int64_t v1002 = 1;
        // pto: %676
        ;
        int64_t v1003 = v947 * v44;
        // pto: %676
        ;
        int64_t v1004 = v1002 * v1003;
        // pto: %676
        ;
        pto::Shape<1, 1, 1, -1, 4096> v1005 = pto::Shape<1, 1, 1, -1, 4096>(v1000, v1001, v1002, v947, v42);
        // pto: %676
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1006 = pto::Stride<-1, -1, -1, -1, -1>(v1001 * v1004, v1004, v1003, v44, v37);
        // pto: %676
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1007 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v999 + (v998 + v934 * v44 + v73 * v37), v1005, v1006);
        TLOAD(v996, v1007);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %100
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1008 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %100
        ;
        uint64_t v1009 = (uint64_t) v26;
        TASSIGN(v1008, v1009);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v1010 = RoundMode::CAST_ROUND;
        SaturationMode v1011 = SaturationMode::ON;
        TCVT(v1008, v996, v1010, v1011);
        // pto: %681
        ;
        int64_t v1012 = (int64_t) ((uint64_t) v501 * (uint64_t) v45);
        // pto: %680
        ;
        float v1013 = (v11)[v1012];
        // pto: %101
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1014 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %101
        ;
        uint64_t v1015 = (uint64_t) v33;
        TASSIGN(v1014, v1015);
        pipe_barrier(PIPE_V);
        TMULS(v1014, v941, v1013);
        // pto: %684
        ;
        int64_t v1016 = (int64_t) ((uint64_t) v501 * (uint64_t) v39);
        // pto: %683
        ;
        float v1017 = (v12)[v1016];
        // pto: %102
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1018 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %102
        ;
        uint64_t v1019 = (uint64_t) v34;
        TASSIGN(v1018, v1019);
        TMULS(v1018, v960, v1017);
        // pto: %103
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1020 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %103
        ;
        uint64_t v1021 = (uint64_t) v33;
        TASSIGN(v1020, v1021);
        pipe_barrier(PIPE_V);
        TADD(v1020, v1014, v1018);
        // pto: %691, %689
        ;
        float v1022 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v45)];
        // pto: %104
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1023 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %104
        ;
        uint64_t v1024 = (uint64_t) v34;
        TASSIGN(v1023, v1024);
        pipe_barrier(PIPE_V);
        TMULS(v1023, v976, v1022);
        // pto: %105
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1025 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %105
        ;
        uint64_t v1026 = (uint64_t) v33;
        TASSIGN(v1025, v1026);
        pipe_barrier(PIPE_V);
        TADD(v1025, v1020, v1023);
        // pto: %697, %695
        ;
        float v1027 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v38)];
        // pto: %106
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1028 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %106
        ;
        uint64_t v1029 = (uint64_t) v34;
        TASSIGN(v1028, v1029);
        pipe_barrier(PIPE_V);
        TMULS(v1028, v992, v1027);
        // pto: %107
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1030 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %107
        ;
        uint64_t v1031 = (uint64_t) v33;
        TASSIGN(v1030, v1031);
        pipe_barrier(PIPE_V);
        TADD(v1030, v1025, v1028);
        // pto: %703, %701
        ;
        float v1032 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v65)];
        // pto: %108
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1033 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %108
        ;
        uint64_t v1034 = (uint64_t) v34;
        TASSIGN(v1033, v1034);
        pipe_barrier(PIPE_V);
        TMULS(v1033, v1008, v1032);
        // pto: %109
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1035 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %109
        ;
        uint64_t v1036 = (uint64_t) v33;
        TASSIGN(v1035, v1036);
        pipe_barrier(PIPE_V);
        TADD(v1035, v1030, v1033);
        // pto: %110
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1037 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %110
        ;
        uint64_t v1038 = (uint64_t) v33;
        TASSIGN(v1037, v1038);
        pipe_barrier(PIPE_V);
        RoundMode v1039 = RoundMode::CAST_RINT;
        SaturationMode v1040 = SaturationMode::ON;
        TCVT(v1037, v1035, v1039, v1040);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1037.SetValidShape(v37, v42);
        // pto: %y_flat__rv_v4_main_pview
        ;
        __gm__ bfloat16_t* v1041 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %y_flat__rv_v4_main_pview
        ;
        const int64_t v1042 = 0;
        // pto: %y_flat__rv_v4_main_pview
        ;
        const int64_t v1043 = 16384;
        // pto: %y_flat__rv_v4_main_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1044 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__rv_v4_main_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1045 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__rv_v4_main_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1046 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1041 + (v1042 + v934 * v1043), v1044, v1045);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1046, v1037);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
        // pto: %711, %709
        ;
        float v1047 = (v11)[(int64_t) ((uint64_t) v1012 + (uint64_t) v37)];
        // pto: %112
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1048 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %112
        ;
        uint64_t v1049 = (uint64_t) v33;
        TASSIGN(v1048, v1049);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
        TMULS(v1048, v941, v1047);
        // pto: %714, %712
        ;
        float v1050 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v37)];
        // pto: %113
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1051 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %113
        ;
        uint64_t v1052 = (uint64_t) v34;
        TASSIGN(v1051, v1052);
        TMULS(v1051, v960, v1050);
        // pto: %114
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1053 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %114
        ;
        uint64_t v1054 = (uint64_t) v33;
        TASSIGN(v1053, v1054);
        pipe_barrier(PIPE_V);
        TADD(v1053, v1048, v1051);
        // pto: %720, %718
        ;
        float v1055 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v66)];
        // pto: %115
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1056 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %115
        ;
        uint64_t v1057 = (uint64_t) v34;
        TASSIGN(v1056, v1057);
        pipe_barrier(PIPE_V);
        TMULS(v1056, v976, v1055);
        // pto: %116
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1058 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %116
        ;
        uint64_t v1059 = (uint64_t) v33;
        TASSIGN(v1058, v1059);
        pipe_barrier(PIPE_V);
        TADD(v1058, v1053, v1056);
        // pto: %726, %724
        ;
        float v1060 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v67)];
        // pto: %117
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1061 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %117
        ;
        uint64_t v1062 = (uint64_t) v34;
        TASSIGN(v1061, v1062);
        pipe_barrier(PIPE_V);
        TMULS(v1061, v992, v1060);
        // pto: %118
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1063 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %118
        ;
        uint64_t v1064 = (uint64_t) v33;
        TASSIGN(v1063, v1064);
        pipe_barrier(PIPE_V);
        TADD(v1063, v1058, v1061);
        // pto: %732, %730
        ;
        float v1065 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v68)];
        // pto: %119
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1066 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %119
        ;
        uint64_t v1067 = (uint64_t) v34;
        TASSIGN(v1066, v1067);
        pipe_barrier(PIPE_V);
        TMULS(v1066, v1008, v1065);
        // pto: %120
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1068 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %120
        ;
        uint64_t v1069 = (uint64_t) v33;
        TASSIGN(v1068, v1069);
        pipe_barrier(PIPE_V);
        TADD(v1068, v1063, v1066);
        // pto: %121
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1070 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %121
        ;
        uint64_t v1071 = (uint64_t) v33;
        TASSIGN(v1070, v1071);
        pipe_barrier(PIPE_V);
        RoundMode v1072 = RoundMode::CAST_RINT;
        SaturationMode v1073 = SaturationMode::ON;
        TCVT(v1070, v1068, v1072, v1073);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1070.SetValidShape(v37, v42);
        // pto: %738
        ;
        __gm__ bfloat16_t* v1074 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %738
        ;
        const int64_t v1075 = 4096;
        // pto: %738
        ;
        const int64_t v1076 = 16384;
        // pto: %738
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1077 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %738
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1078 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %738
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1079 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1074 + (v1075 + v934 * v1076), v1077, v1078);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1079, v1070);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        // pto: %741, %739
        ;
        float v1080 = (v11)[(int64_t) ((uint64_t) v1012 + (uint64_t) v47)];
        // pto: %123
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1081 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %123
        ;
        uint64_t v1082 = (uint64_t) v33;
        TASSIGN(v1081, v1082);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        TMULS(v1081, v941, v1080);
        // pto: %744, %742
        ;
        float v1083 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v47)];
        // pto: %124
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1084 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %124
        ;
        uint64_t v1085 = (uint64_t) v34;
        TASSIGN(v1084, v1085);
        TMULS(v1084, v960, v1083);
        // pto: %125
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1086 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %125
        ;
        uint64_t v1087 = (uint64_t) v33;
        TASSIGN(v1086, v1087);
        pipe_barrier(PIPE_V);
        TADD(v1086, v1081, v1084);
        // pto: %750, %748
        ;
        float v1088 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v69)];
        // pto: %126
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1089 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %126
        ;
        uint64_t v1090 = (uint64_t) v34;
        TASSIGN(v1089, v1090);
        pipe_barrier(PIPE_V);
        TMULS(v1089, v976, v1088);
        // pto: %127
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1091 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %127
        ;
        uint64_t v1092 = (uint64_t) v33;
        TASSIGN(v1091, v1092);
        pipe_barrier(PIPE_V);
        TADD(v1091, v1086, v1089);
        // pto: %756, %754
        ;
        float v1093 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v70)];
        // pto: %128
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1094 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %128
        ;
        uint64_t v1095 = (uint64_t) v34;
        TASSIGN(v1094, v1095);
        pipe_barrier(PIPE_V);
        TMULS(v1094, v992, v1093);
        // pto: %129
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1096 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %129
        ;
        uint64_t v1097 = (uint64_t) v33;
        TASSIGN(v1096, v1097);
        pipe_barrier(PIPE_V);
        TADD(v1096, v1091, v1094);
        // pto: %762, %760
        ;
        float v1098 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v71)];
        // pto: %130
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1099 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %130
        ;
        uint64_t v1100 = (uint64_t) v34;
        TASSIGN(v1099, v1100);
        pipe_barrier(PIPE_V);
        TMULS(v1099, v1008, v1098);
        // pto: %131
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1101 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %131
        ;
        uint64_t v1102 = (uint64_t) v33;
        TASSIGN(v1101, v1102);
        pipe_barrier(PIPE_V);
        TADD(v1101, v1096, v1099);
        // pto: %132
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1103 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %132
        ;
        uint64_t v1104 = (uint64_t) v33;
        TASSIGN(v1103, v1104);
        pipe_barrier(PIPE_V);
        RoundMode v1105 = RoundMode::CAST_RINT;
        SaturationMode v1106 = SaturationMode::ON;
        TCVT(v1103, v1101, v1105, v1106);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1103.SetValidShape(v37, v42);
        // pto: %768
        ;
        __gm__ bfloat16_t* v1107 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %768
        ;
        const int64_t v1108 = 8192;
        // pto: %768
        ;
        const int64_t v1109 = 16384;
        // pto: %768
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1110 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %768
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1111 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %768
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1112 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1107 + (v1108 + v934 * v1109), v1110, v1111);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1112, v1103);
        // pto: %771, %769
        ;
        float v1113 = (v11)[(int64_t) ((uint64_t) v1012 + (uint64_t) v64)];
        // pto: %134
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1114 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %134
        ;
        uint64_t v1115 = (uint64_t) v24;
        TASSIGN(v1114, v1115);
        TMULS(v1114, v941, v1113);
        // pto: %774, %772
        ;
        float v1116 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v64)];
        // pto: %135
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1117 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %135
        ;
        uint64_t v1118 = (uint64_t) v32;
        TASSIGN(v1117, v1118);
        TMULS(v1117, v960, v1116);
        // pto: %136
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1119 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %136
        ;
        uint64_t v1120 = (uint64_t) v24;
        TASSIGN(v1119, v1120);
        pipe_barrier(PIPE_V);
        TADD(v1119, v1114, v1117);
        // pto: %780, %778
        ;
        float v1121 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v56)];
        // pto: %137
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1122 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %137
        ;
        uint64_t v1123 = (uint64_t) v32;
        TASSIGN(v1122, v1123);
        pipe_barrier(PIPE_V);
        TMULS(v1122, v976, v1121);
        // pto: %138
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1124 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %138
        ;
        uint64_t v1125 = (uint64_t) v24;
        TASSIGN(v1124, v1125);
        pipe_barrier(PIPE_V);
        TADD(v1124, v1119, v1122);
        // pto: %786, %784
        ;
        float v1126 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v72)];
        // pto: %139
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1127 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %139
        ;
        uint64_t v1128 = (uint64_t) v32;
        TASSIGN(v1127, v1128);
        pipe_barrier(PIPE_V);
        TMULS(v1127, v992, v1126);
        // pto: %140
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1129 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %140
        ;
        uint64_t v1130 = (uint64_t) v24;
        TASSIGN(v1129, v1130);
        pipe_barrier(PIPE_V);
        TADD(v1129, v1124, v1127);
        // pto: %792, %790
        ;
        float v1131 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v50)];
        // pto: %141
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1132 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %141
        ;
        uint64_t v1133 = (uint64_t) v32;
        TASSIGN(v1132, v1133);
        pipe_barrier(PIPE_V);
        TMULS(v1132, v1008, v1131);
        // pto: %142
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1134 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %142
        ;
        uint64_t v1135 = (uint64_t) v24;
        TASSIGN(v1134, v1135);
        pipe_barrier(PIPE_V);
        TADD(v1134, v1129, v1132);
        // pto: %143
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1136 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %143
        ;
        uint64_t v1137 = (uint64_t) v24;
        TASSIGN(v1136, v1137);
        pipe_barrier(PIPE_V);
        RoundMode v1138 = RoundMode::CAST_RINT;
        SaturationMode v1139 = SaturationMode::ON;
        TCVT(v1136, v1134, v1138, v1139);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1136.SetValidShape(v37, v42);
        // pto: %798
        ;
        __gm__ bfloat16_t* v1140 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %798
        ;
        const int64_t v1141 = 12288;
        // pto: %798
        ;
        const int64_t v1142 = 16384;
        // pto: %798
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1143 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %798
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1144 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %798
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1145 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1140 + (v1141 + v934 * v1142), v1143, v1144);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v1145, v1136);
      };
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  pipe_barrier(PIPE_ALL);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}