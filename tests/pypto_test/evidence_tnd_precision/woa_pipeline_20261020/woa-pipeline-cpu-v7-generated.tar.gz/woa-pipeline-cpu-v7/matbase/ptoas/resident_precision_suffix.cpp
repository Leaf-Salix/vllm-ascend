#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void cube(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ bfloat16_t* v6, __gm__ int8_t* v7, __gm__ float* v8, __gm__ bfloat16_t* v9, __gm__ bfloat16_t* v10, __gm__ float* v11, __gm__ float* v12, __gm__ bfloat16_t* v13, __gm__ float* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int32_t v22 = 1;
  // pto: %c0_i64
  const int64_t v23 = 0;
  // pto: %c65536_i64
  const int64_t v24 = 65536;
  // pto: %c32768_i64
  const int64_t v25 = 32768;
  // pto: %c131072_i64
  const int64_t v26 = 131072;
  // pto: %c196608_i64
  const int64_t v27 = 196608;
  // pto: %c32768_index
  const int64_t v28 = 32768;
  // pto: %c1_index
  const int64_t v29 = 1;
  // pto: %c8_index
  const int64_t v30 = 8;
  const int64_t v31 = 64;
  // pto: %c256_index
  const int64_t v32 = 256;
  // pto: %c16_index
  const int64_t v33 = 16;
  // pto: %c4194304_index
  const int64_t v34 = 4194304;
  // pto: %c65536_index
  const int64_t v35 = 65536;
  const int64_t v36 = 128;
  // pto: %c512_index
  const int64_t v37 = 512;
  // pto: %c32_index
  const int64_t v38 = 32;
  // pto: %c33554432_index
  const int64_t v39 = 33554432;
  // pto: %c262144_index
  const int64_t v40 = 262144;
  // pto: %c4096_index
  const int64_t v41 = 4096;
  // pto: %c8192_index
  const int64_t v42 = 8192;
  // pto: %c4_index
  const int64_t v43 = 4;
  // pto: %c55296_index
  const int64_t v44 = 55296;
  // pto: %c0_index
  const int64_t v45 = 0;
  // pto: %c15_index
  const int64_t v46 = 15;
  // pto: %c192_index
  const int64_t v47 = 192;
  // pto: %c24_index
  const int64_t v48 = 24;
  // pto: %c7_index
  const int64_t v49 = 7;
  // pto: %c2_index
  const int64_t v50 = 2;
  // pto: %c3_index
  const int64_t v51 = 3;
  // pto: %c5_index
  const int64_t v52 = 5;
  // pto: %c6_index
  const int64_t v53 = 6;
  // pto: %c240_index
  const int64_t v54 = 240;
  // pto: %c1024_index
  const int64_t v55 = 1024;
  // pto: %c241_index
  const int64_t v56 = 241;
  // pto: %c9216_index
  const int64_t v57 = 9216;
  // pto: %c72_index
  const int64_t v58 = 72;
  // pto: %c27648_index
  const int64_t v59 = 27648;
  // pto: %c63_index
  const int64_t v60 = 63;
  // pto: %c36864_index
  const int64_t v61 = 36864;
  // pto: %heads__ssa_v0_view
  const int64_t v62 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v63 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %heads__ssa_v0_view
  int64_t v65 = (int64_t) v17;
  // pto: %heads__ssa_v0_view
  int64_t v66 = v65 * v28;
  // pto: %heads__ssa_v0_view
  int64_t v67 = v64 * v66;
  // pto: %heads__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v68 = pto::Shape<1, 1, 1, -1, -1>(v62, v63, v64, v65, v28);
  // pto: %heads__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v69 = pto::Stride<-1, -1, -1, -1, -1>(v63 * v67, v67, v66, v28, v29);
  // pto: %heads__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v70 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v68, v69);
  // pto: %wo_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v71 = pto::Shape<-1, -1, -1, -1, -1>(v30, v31, v32, v33, v33);
  // pto: %wo_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v34, v35, v32, v33, v29);
  // pto: %wo_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v73 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v2, v71, v72);
  // pto: %wo_b__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v74 = pto::Shape<-1, -1, -1, -1, -1>(v29, v36, v37, v33, v38);
  // pto: %wo_b__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v75 = pto::Stride<-1, -1, -1, -1, -1>(v39, v40, v37, v38, v29);
  // pto: %wo_b__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v76 = GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v3, v74, v75);
  // pto: %quantized__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v78 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v79 = 1;
  // pto: %quantized__ssa_v0_view
  int64_t v80 = (int64_t) v17;
  // pto: %quantized__ssa_v0_view
  int64_t v81 = v80 * v42;
  // pto: %quantized__ssa_v0_view
  int64_t v82 = v79 * v81;
  // pto: %quantized__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v83 = pto::Shape<1, 1, 1, -1, -1>(v77, v78, v79, v80, v42);
  // pto: %quantized__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v84 = pto::Stride<-1, -1, -1, -1, -1>(v78 * v82, v82, v81, v42, v29);
  // pto: %quantized__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v85 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v83, v84);
  // pto: %accum__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v87 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v88 = 1;
  // pto: %accum__ssa_v0_view
  int64_t v89 = (int64_t) v18;
  // pto: %accum__ssa_v0_view
  int64_t v90 = v89 * v42;
  // pto: %accum__ssa_v0_view
  int64_t v91 = v88 * v90;
  // pto: %accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v92 = pto::Shape<1, 1, 1, -1, -1>(v86, v87, v88, v89, v42);
  // pto: %accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v93 = pto::Stride<-1, -1, -1, -1, -1>(v87 * v91, v91, v90, v42, v29);
  // pto: %accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v94 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v92, v93);
  // pto: %integer_accum__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v96 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v97 = 1;
  // pto: %integer_accum__ssa_v0_view
  int64_t v98 = (int64_t) v19;
  // pto: %integer_accum__ssa_v0_view
  int64_t v99 = v98 * v41;
  // pto: %integer_accum__ssa_v0_view
  int64_t v100 = v97 * v99;
  // pto: %integer_accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v101 = pto::Shape<1, 1, 1, -1, -1>(v95, v96, v97, v98, v41);
  // pto: %integer_accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v102 = pto::Stride<-1, -1, -1, -1, -1>(v96 * v100, v100, v99, v41, v29);
  // pto: %integer_accum__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v103 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v101, v102);
  // pto: %signals__ssa_v0_view
  const int64_t v104 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v105 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v106 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v107 = 1;
  // pto: %signals__ssa_v0_view
  int64_t v108 = v44 * v29;
  // pto: %signals__ssa_v0_view
  int64_t v109 = v107 * v108;
  // pto: %signals__ssa_v0_view
  int64_t v110 = v106 * v109;
  // pto: %signals__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v111 = pto::Shape<1, 1, 1, 1, -1>(v104, v105, v106, v107, v44);
  // pto: %signals__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v112 = pto::Stride<-1, -1, -1, -1, -1>(v105 * v110, v110, v109, v108, v29);
  // pto: %signals__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v113 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v111, v112);
  // pto: %seed_fast_acc__phi_v7
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v114 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
  // pto: %seed_fast_acc__phi_v7
  uint64_t v115 = (uint64_t) v23;
  TASSIGN(v114, v115);
  // pto: %217
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v116 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
  // pto: %217
  uint64_t v117 = (uint64_t) v23;
  TASSIGN(v116, v117);
  // pto: %255
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v118 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
  // pto: %255
  uint64_t v119 = (uint64_t) v23;
  TASSIGN(v118, v119);
  // pto: %seed_narrow_acc__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
  // pto: %seed_narrow_acc__phi_v7
  uint64_t v121 = (uint64_t) v23;
  TASSIGN(v120, v121);
  // pto: %v4_wide_acc__phi_v7
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v122 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
  // pto: %v4_wide_acc__phi_v7
  uint64_t v123 = (uint64_t) v23;
  TASSIGN(v122, v123);
  // pto: %v4_narrow_acc__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
  // pto: %v4_narrow_acc__phi_v7
  uint64_t v125 = (uint64_t) v23;
  TASSIGN(v124, v125);
  // pto: %worker__ssa_v0
  int64_t v126 = (int64_t) v20;
  // pto: %57
  int64_t v127 = (int64_t) ((uint64_t) v126 * (uint64_t) v36);
  // pto: %58
  int64_t v128 = v127 < v45 ? v45 : v127;
  // pto: %signals__ssa_v0_pview
  __gm__ int32_t* v129 = PTOAS__GLOBAL_TENSOR_DATA(v113);
  // pto: %signals__ssa_v0_pview
  const int64_t v130 = 0;
  // pto: %signals__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 1> v131 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  pto::Stride<1, 1, 1, 1, 1> v132 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v133 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v129 + (v130 + v128), v131, v132);
  __gm__ int32_t* v134 = PTOAS__GLOBAL_TENSOR_DATA(v133);
  PTOAS__DCCI_SINGLE_CACHE_LINE(v134);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
  // pto: %t__tile
  int32_t v135 = (v16)[v127];
  // pto: %60
  int32_t v136 = (int32_t) ((uint32_t) v135 + (uint32_t) v22);
  pipe_barrier(PIPE_ALL);
  pto::comm::NotifyOp v137 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v133, v136, v137);
  // pto: %62, %63
  int64_t v138 = (int64_t) ((uint64_t) v17 + (uint64_t) v46) / v33;
  // pto: %64
  if (v17 >= v47) {
    for (int64_t v139 = v126; v139 < v31; v139 += v48) {
      // pto: %65
      ;
      int64_t v140 = v139 / v30;
      // pto: %66
      ;
      int64_t v141 = v139 % v30;
      // pto: %67, %68, %69
      ;
      int64_t v142 = v141 < v45 ? (int64_t) ((uint64_t) v141 + (uint64_t) v30) : v141;
      // pto: %70
      ;
      int64_t v143 = (int64_t) ((uint64_t) v142 * (uint64_t) v36);
      // pto: %71, %72
      ;
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v144 = v45; v144 < ((int64_t) ((uint64_t) v138 + (uint64_t) v49) / v30); v144 += v29) {
        // pto: %73
        ;
        int64_t v145 = (int64_t) ((uint64_t) v144 * (uint64_t) v30);
        // pto: %flat_offset, %75, %76, %74
        ;
        int32_t v146 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v144 * (uint64_t) v31) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
        // pto: %77
        ;
        int64_t v147 = (int64_t) v146;
        // pto: %78
        ;
        int64_t v148 = v147 < v45 ? v45 : v147;
        // pto: %79
        ;
        int64_t v149 = (int64_t) ((uint64_t) v145 + (uint64_t) v29);
        // pto: %80
        ;
        // pto: %seed_same_start__phi_v3
        ;
        int64_t v150;
        if (v149 < v138) {
          // pto: %83, %84, %85, %86, %81
          ;
          int32_t v151 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v149 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %87
          ;
          int64_t v152 = (int64_t) v151;
          // pto: %88
          ;
          int64_t v153 = v152 < v45 ? v45 : v152;
          // pto: %89, %seed_same_start__phi_v2
          ;
          v150 = v153 != v148 ? v45 : v29;
        } else {
          v150 = v29;
        };
        // pto: %90
        ;
        int64_t v154 = (int64_t) ((uint64_t) v145 + (uint64_t) v50);
        // pto: %91
        ;
        // pto: %seed_same_start__phi_v6
        ;
        int64_t v155;
        if (v154 < v138) {
          // pto: %94, %95, %96, %97, %92
          ;
          int32_t v156 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v154 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %98
          ;
          int64_t v157 = (int64_t) v156;
          // pto: %99
          ;
          int64_t v158 = v157 < v45 ? v45 : v157;
          // pto: %100, %seed_same_start__phi_v5
          ;
          int64_t v159 = v158 != v148 ? v45 : v150;
          v155 = v159;
        } else {
          v155 = v150;
        };
        // pto: %101
        ;
        int64_t v160 = (int64_t) ((uint64_t) v145 + (uint64_t) v51);
        // pto: %102
        ;
        // pto: %seed_same_start__phi_v9
        ;
        int64_t v161;
        if (v160 < v138) {
          // pto: %105, %106, %107, %108, %103
          ;
          int32_t v162 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v160 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %109
          ;
          int64_t v163 = (int64_t) v162;
          // pto: %110
          ;
          int64_t v164 = v163 < v45 ? v45 : v163;
          // pto: %111, %seed_same_start__phi_v8
          ;
          int64_t v165 = v164 != v148 ? v45 : v155;
          v161 = v165;
        } else {
          v161 = v155;
        };
        // pto: %112
        ;
        int64_t v166 = (int64_t) ((uint64_t) v145 + (uint64_t) v43);
        // pto: %113
        ;
        // pto: %seed_same_start__phi_v12
        ;
        int64_t v167;
        if (v166 < v138) {
          // pto: %116, %117, %118, %119, %114
          ;
          int32_t v168 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v166 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %120
          ;
          int64_t v169 = (int64_t) v168;
          // pto: %121
          ;
          int64_t v170 = v169 < v45 ? v45 : v169;
          // pto: %122, %seed_same_start__phi_v11
          ;
          int64_t v171 = v170 != v148 ? v45 : v161;
          v167 = v171;
        } else {
          v167 = v161;
        };
        // pto: %123
        ;
        int64_t v172 = (int64_t) ((uint64_t) v145 + (uint64_t) v52);
        // pto: %124
        ;
        // pto: %seed_same_start__phi_v15
        ;
        int64_t v173;
        if (v172 < v138) {
          // pto: %127, %128, %129, %130, %125
          ;
          int32_t v174 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v172 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %131
          ;
          int64_t v175 = (int64_t) v174;
          // pto: %132
          ;
          int64_t v176 = v175 < v45 ? v45 : v175;
          // pto: %133, %seed_same_start__phi_v14
          ;
          int64_t v177 = v176 != v148 ? v45 : v167;
          v173 = v177;
        } else {
          v173 = v167;
        };
        // pto: %134
        ;
        int64_t v178 = (int64_t) ((uint64_t) v145 + (uint64_t) v53);
        // pto: %135
        ;
        // pto: %seed_same_start__phi_v18
        ;
        int64_t v179;
        if (v178 < v138) {
          // pto: %138, %139, %140, %141, %136
          ;
          int32_t v180 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v178 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %142
          ;
          int64_t v181 = (int64_t) v180;
          // pto: %143
          ;
          int64_t v182 = v181 < v45 ? v45 : v181;
          // pto: %144, %seed_same_start__phi_v17
          ;
          int64_t v183 = v182 != v148 ? v45 : v173;
          v179 = v183;
        } else {
          v179 = v173;
        };
        // pto: %145
        ;
        int64_t v184 = (int64_t) ((uint64_t) v145 + (uint64_t) v49);
        // pto: %146
        ;
        // pto: %seed_same_start__phi_v21
        ;
        int64_t v185;
        if (v184 < v138) {
          // pto: %149, %150, %151, %152, %147
          ;
          int32_t v186 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v184 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %153
          ;
          int64_t v187 = (int64_t) v186;
          // pto: %154
          ;
          int64_t v188 = v187 < v45 ? v45 : v187;
          // pto: %155, %seed_same_start__phi_v20
          ;
          int64_t v189 = v188 != v148 ? v45 : v179;
          v185 = v189;
        } else {
          v185 = v179;
        };
        // pto: %156, %seed_same_start__phi_v25
        ;
        int64_t v190 = v148 > v54 ? v45 : v185;
        // pto: %157
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        if (v190 == v29) {
          int64_t v191 = (int64_t) ((uint64_t) v144 * (uint64_t) v36);
          // pto: %159
          ;
          int64_t v192 = (int64_t) ((uint64_t) v17 - (uint64_t) v191);
          // pto: %160
          ;
          int64_t v193 = v192 < v36 ? v192 : v36;
          // pto: %161
          ;
          int64_t v194 = (int64_t) ((uint64_t) v148 * (uint64_t) v33);
          // pto: %seed_fast_seed_x__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v195 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v32);
          // pto: %seed_fast_seed_x__tile
          ;
          uint64_t v196 = (uint64_t) v23;
          TASSIGN(v195, v196);
          // pto: %162
          ;
          int64_t v197 = v191 < v45 ? v45 : v191;
          // pto: %163
          ;
          int64_t v198 = (int64_t) ((uint64_t) v140 * (uint64_t) v41);
          // pto: %164
          ;
          int64_t v199 = (int64_t) ((uint64_t) v198 + (uint64_t) v194);
          // pto: %165
          ;
          int64_t v200 = v199 < v45 ? v45 : v199;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v201 = 0;
          // pto: %heads__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v202 = PTOAS__GLOBAL_TENSOR_DATA(v70);
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v203 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v204 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v205 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          int64_t v206 = v193 * v28;
          // pto: %heads__ssa_v0_pview
          ;
          int64_t v207 = v205 * v206;
          // pto: %heads__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, -1, 256> v208 = pto::Shape<1, 1, 1, -1, 256>(v203, v204, v205, v193, v32);
          // pto: %heads__ssa_v0_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v209 = pto::Stride<-1, -1, -1, -1, -1>(v204 * v207, v207, v206, v28, v29);
          // pto: %heads__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v210 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v202 + (v201 + v197 * v28 + v200 * v29), v208, v209);
          TLOAD(v195, v210);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %seed_fast_seed_w__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
          // pto: %seed_fast_seed_w__tile
          ;
          uint64_t v212 = (uint64_t) v24;
          TASSIGN(v211, v212);
          // pto: %166
          ;
          int64_t v213 = v140 < v45 ? v45 : v140;
          // pto: %167
          ;
          int64_t v214 = v143 / v33;
          // pto: %168
          ;
          int64_t v215 = v214 < v45 ? v45 : v214;
          // pto: %169
          ;
          int64_t v216 = v194 / v33;
          // pto: %170
          ;
          int64_t v217 = v216 < v45 ? v45 : v216;
          // pto: %wo_a__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v218 = PTOAS__GLOBAL_TENSOR_DATA(v73);
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v219 = 0;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v220 = 4194304;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v221 = 65536;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v222 = 256;
          // pto: %wo_a__ssa_v0_pview
          ;
          pto::Shape<1, 8, 16, 16, 16> v223 = pto::Shape<1, 8, 16, 16, 16>();
          // pto: %wo_a__ssa_v0_pview
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v224 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %wo_a__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v225 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v218 + ((v219 + v213 * v220) + v215 * v221 + v217 * v222), v223, v224);
          TLOAD(v211, v225);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %seed_fast_acc__tile_l0_init_storage
          ;
          Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v226 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
          // pto: %seed_fast_acc__tile_l0_init_storage
          ;
          uint64_t v227 = (uint64_t) v23;
          TASSIGN(v226, v227);
          v226.SetValidShape(v193, v36);
          // pto: %seed_fast_acc__tile_l0_a
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v228 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
          // pto: %seed_fast_acc__tile_l0_a
          ;
          uint64_t v229 = (uint64_t) v23;
          TASSIGN(v228, v229);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          uint16_t v230 = static_cast<uint16_t>(v45);
          uint16_t v231 = static_cast<uint16_t>(v45);
          TEXTRACT(v228, v195, v230, v231);
          // pto: %seed_fast_acc__tile_l0_b
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v232 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
          // pto: %seed_fast_acc__tile_l0_b
          ;
          uint64_t v233 = (uint64_t) v23;
          TASSIGN(v232, v233);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          uint16_t v234 = static_cast<uint16_t>(v45);
          uint16_t v235 = static_cast<uint16_t>(v45);
          TEXTRACT(v232, v211, v234, v235);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          // pto: %0
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v236 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
          // pto: %0
          ;
          uint64_t v237 = (uint64_t) v25;
          TASSIGN(v236, v237);
          uint16_t v238 = static_cast<uint16_t>(v45);
          uint16_t v239 = static_cast<uint16_t>(v36);
          TEXTRACT(v236, v195, v238, v239);
          // pto: %1
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v240 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
          // pto: %1
          ;
          uint64_t v241 = (uint64_t) v25;
          TASSIGN(v240, v241);
          uint16_t v242 = static_cast<uint16_t>(v36);
          uint16_t v243 = static_cast<uint16_t>(v45);
          TEXTRACT(v240, v211, v242, v243);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          TMATMUL(v226, v228, v232);
          pipe_barrier(PIPE_M);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
          TMATMUL_ACC(v226, v226, v236, v240);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
          for (int64_t v244 = v29; v244 < v46; v244 += v50) {
            // pto: %171
            ;
            int64_t v245 = (int64_t) ((uint64_t) v244 * (uint64_t) v33);
            // pto: %172, %173
            ;
            int64_t v246 = (int64_t) ((uint64_t) v148 + (uint64_t) v245) % v32;
            // pto: %174, %175, %176
            ;
            int64_t v247 = v246 < v45 ? (int64_t) ((uint64_t) v246 + (uint64_t) v32) : v246;
            // pto: %179, %178, %180
            ;
            int64_t v248 = (int64_t) ((uint64_t) v148 + (uint64_t) ((int64_t) (uint64_t) v245 + (uint64_t) v33)) % v32;
            // pto: %181, %182, %183
            ;
            int64_t v249 = v248 < v45 ? (int64_t) ((uint64_t) v248 + (uint64_t) v32) : v248;
            // pto: %184
            ;
            // pto: %185
            ;
            int64_t v250 = v193 < v36 ? v193 : v36;
            v114.SetValidShape(v250, v36);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
            if (v247 <= v54) {
              // pto: %186
              ;
              int64_t v251 = (int64_t) ((uint64_t) v247 * (uint64_t) v33);
              // pto: %seed_fast_packet_x__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v252 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v32);
              // pto: %seed_fast_packet_x__tile
              ;
              uint64_t v253 = (uint64_t) v23;
              TASSIGN(v252, v253);
              // pto: %189
              ;
              int64_t v254 = (int64_t) ((uint64_t) v198 + (uint64_t) v251);
              // pto: %190
              ;
              int64_t v255 = v254 < v45 ? v45 : v254;
              // pto: %191
              ;
              const int64_t v256 = 0;
              // pto: %191
              ;
              __gm__ bfloat16_t* v257 = PTOAS__GLOBAL_TENSOR_DATA(v70);
              // pto: %191
              ;
              const int64_t v258 = 1;
              // pto: %191
              ;
              const int64_t v259 = 1;
              // pto: %191
              ;
              const int64_t v260 = 1;
              // pto: %191
              ;
              int64_t v261 = v193 * v28;
              // pto: %191
              ;
              int64_t v262 = v260 * v261;
              // pto: %191
              ;
              pto::Shape<1, 1, 1, -1, 256> v263 = pto::Shape<1, 1, 1, -1, 256>(v258, v259, v260, v193, v32);
              // pto: %191
              ;
              pto::Stride<-1, -1, -1, -1, -1> v264 = pto::Stride<-1, -1, -1, -1, -1>(v259 * v262, v262, v261, v28, v29);
              // pto: %191
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v265 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v257 + (v256 + v197 * v28 + v255 * v29), v263, v264);
              TLOAD(v252, v265);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
              // pto: %seed_fast_packet_w__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v266 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
              // pto: %seed_fast_packet_w__tile
              ;
              uint64_t v267 = (uint64_t) v24;
              TASSIGN(v266, v267);
              // pto: %195
              ;
              int64_t v268 = v251 / v33;
              // pto: %196
              ;
              int64_t v269 = v268 < v45 ? v45 : v268;
              // pto: %197
              ;
              __gm__ bfloat16_t* v270 = PTOAS__GLOBAL_TENSOR_DATA(v73);
              // pto: %197
              ;
              const int64_t v271 = 0;
              // pto: %197
              ;
              const int64_t v272 = 4194304;
              // pto: %197
              ;
              const int64_t v273 = 65536;
              // pto: %197
              ;
              const int64_t v274 = 256;
              // pto: %197
              ;
              pto::Shape<1, 8, 16, 16, 16> v275 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %197
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v276 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %197
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v277 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v270 + ((v271 + v213 * v272) + v215 * v273 + v269 * v274), v275, v276);
              TLOAD(v266, v277);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
              // pto: %seed_fast_acc__iter_v1_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v278 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
              // pto: %seed_fast_acc__iter_v1_l0_a
              ;
              uint64_t v279 = (uint64_t) v23;
              TASSIGN(v278, v279);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
              uint16_t v280 = static_cast<uint16_t>(v45);
              uint16_t v281 = static_cast<uint16_t>(v45);
              TEXTRACT(v278, v252, v280, v281);
              // pto: %seed_fast_acc__iter_v1_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v282 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %seed_fast_acc__iter_v1_l0_b
              ;
              uint64_t v283 = (uint64_t) v23;
              TASSIGN(v282, v283);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
              uint16_t v284 = static_cast<uint16_t>(v45);
              uint16_t v285 = static_cast<uint16_t>(v45);
              TEXTRACT(v282, v266, v284, v285);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
              // pto: %3
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v286 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
              // pto: %3
              ;
              uint64_t v287 = (uint64_t) v25;
              TASSIGN(v286, v287);
              uint16_t v288 = static_cast<uint16_t>(v45);
              uint16_t v289 = static_cast<uint16_t>(v36);
              TEXTRACT(v286, v252, v288, v289);
              // pto: %4
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v290 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %4
              ;
              uint64_t v291 = (uint64_t) v25;
              TASSIGN(v290, v291);
              uint16_t v292 = static_cast<uint16_t>(v36);
              uint16_t v293 = static_cast<uint16_t>(v45);
              TEXTRACT(v290, v266, v292, v293);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v226, v226, v278, v282);
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
              TMATMUL_ACC(v226, v226, v286, v290);
            } else {
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
              for (int64_t v294 = v45; v294 < v33; v294 += v29) {
                // pto: %198, %199
                ;
                int64_t v295 = (int64_t) ((uint64_t) v247 + (uint64_t) v294) % v32;
                // pto: %200, %201, %202
                ;
                int64_t v296 = v295 < v45 ? (int64_t) ((uint64_t) v295 + (uint64_t) v32) : v295;
                // pto: %203
                ;
                int64_t v297 = (int64_t) ((uint64_t) v296 * (uint64_t) v33);
                // pto: %seed_fast_wrap_x__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v33);
                // pto: %seed_fast_wrap_x__tile
                ;
                uint64_t v299 = (uint64_t) v23;
                TASSIGN(v298, v299);
                // pto: %206
                ;
                int64_t v300 = (int64_t) ((uint64_t) v198 + (uint64_t) v297);
                // pto: %207
                ;
                int64_t v301 = v300 < v45 ? v45 : v300;
                // pto: %208
                ;
                const int64_t v302 = 0;
                // pto: %208
                ;
                __gm__ bfloat16_t* v303 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                // pto: %208
                ;
                const int64_t v304 = 1;
                // pto: %208
                ;
                const int64_t v305 = 1;
                // pto: %208
                ;
                const int64_t v306 = 1;
                // pto: %208
                ;
                int64_t v307 = v193 * v28;
                // pto: %208
                ;
                int64_t v308 = v306 * v307;
                // pto: %208
                ;
                pto::Shape<1, 1, 1, -1, 16> v309 = pto::Shape<1, 1, 1, -1, 16>(v304, v305, v306, v193, v33);
                // pto: %208
                ;
                pto::Stride<-1, -1, -1, -1, -1> v310 = pto::Stride<-1, -1, -1, -1, -1>(v305 * v308, v308, v307, v28, v29);
                // pto: %208
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v311 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v303 + (v302 + v197 * v28 + v301 * v29), v309, v310);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                TLOAD(v298, v311);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
                // pto: %seed_fast_wrap_w__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v312 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %seed_fast_wrap_w__tile
                ;
                uint64_t v313 = (uint64_t) v24;
                TASSIGN(v312, v313);
                // pto: %212
                ;
                int64_t v314 = v297 / v33;
                // pto: %213
                ;
                int64_t v315 = v314 < v45 ? v45 : v314;
                // pto: %214
                ;
                __gm__ bfloat16_t* v316 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                // pto: %214
                ;
                const int64_t v317 = 0;
                // pto: %214
                ;
                const int64_t v318 = 4194304;
                // pto: %214
                ;
                const int64_t v319 = 65536;
                // pto: %214
                ;
                const int64_t v320 = 256;
                // pto: %214
                ;
                pto::Shape<1, 8, 1, 16, 16> v321 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %214
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v322 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %214
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v323 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v316 + ((v317 + v213 * v318) + v215 * v319 + v315 * v320), v321, v322);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
                TLOAD(v312, v323);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
                // pto: %lhs_slice_0_textract
                ;
                Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v324 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v33);
                // pto: %lhs_slice_0_textract
                ;
                uint64_t v325 = (uint64_t) v23;
                TASSIGN(v324, v325);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
                uint16_t v326 = static_cast<uint16_t>(v45);
                uint16_t v327 = static_cast<uint16_t>(v45);
                TEXTRACT(v324, v298, v326, v327);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                // pto: %rhs_slice_0_textract
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v328 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %rhs_slice_0_textract
                ;
                uint64_t v329 = (uint64_t) v23;
                TASSIGN(v328, v329);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
                uint16_t v330 = static_cast<uint16_t>(v45);
                uint16_t v331 = static_cast<uint16_t>(v45);
                TEXTRACT(v328, v312, v330, v331);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v226, v226, v324, v328);
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
              };
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            };
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            // pto: %215
            ;
            v116.SetValidShape(v250, v36);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
            if (v249 <= v54) {
              // pto: %218
              ;
              int64_t v332 = (int64_t) ((uint64_t) v249 * (uint64_t) v33);
              // pto: %6
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v333 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v32);
              // pto: %6
              ;
              uint64_t v334 = (uint64_t) v26;
              TASSIGN(v333, v334);
              // pto: %221
              ;
              int64_t v335 = (int64_t) ((uint64_t) v198 + (uint64_t) v332);
              // pto: %222
              ;
              int64_t v336 = v335 < v45 ? v45 : v335;
              // pto: %223
              ;
              const int64_t v337 = 0;
              // pto: %223
              ;
              __gm__ bfloat16_t* v338 = PTOAS__GLOBAL_TENSOR_DATA(v70);
              // pto: %223
              ;
              const int64_t v339 = 1;
              // pto: %223
              ;
              const int64_t v340 = 1;
              // pto: %223
              ;
              const int64_t v341 = 1;
              // pto: %223
              ;
              int64_t v342 = v193 * v28;
              // pto: %223
              ;
              int64_t v343 = v341 * v342;
              // pto: %223
              ;
              pto::Shape<1, 1, 1, -1, 256> v344 = pto::Shape<1, 1, 1, -1, 256>(v339, v340, v341, v193, v32);
              // pto: %223
              ;
              pto::Stride<-1, -1, -1, -1, -1> v345 = pto::Stride<-1, -1, -1, -1, -1>(v340 * v343, v343, v342, v28, v29);
              // pto: %223
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v346 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v338 + (v337 + v197 * v28 + v336 * v29), v344, v345);
              TLOAD(v333, v346);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
              // pto: %7
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v347 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
              // pto: %7
              ;
              uint64_t v348 = (uint64_t) v27;
              TASSIGN(v347, v348);
              // pto: %227
              ;
              int64_t v349 = v332 / v33;
              // pto: %228
              ;
              int64_t v350 = v349 < v45 ? v45 : v349;
              // pto: %229
              ;
              __gm__ bfloat16_t* v351 = PTOAS__GLOBAL_TENSOR_DATA(v73);
              // pto: %229
              ;
              const int64_t v352 = 0;
              // pto: %229
              ;
              const int64_t v353 = 4194304;
              // pto: %229
              ;
              const int64_t v354 = 65536;
              // pto: %229
              ;
              const int64_t v355 = 256;
              // pto: %229
              ;
              pto::Shape<1, 8, 16, 16, 16> v356 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %229
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v357 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %229
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v358 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v351 + ((v352 + v213 * v353) + v215 * v354 + v350 * v355), v356, v357);
              TLOAD(v347, v358);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
              // pto: %8
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v359 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
              // pto: %8
              ;
              uint64_t v360 = (uint64_t) v23;
              TASSIGN(v359, v360);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
              uint16_t v361 = static_cast<uint16_t>(v45);
              uint16_t v362 = static_cast<uint16_t>(v45);
              TEXTRACT(v359, v333, v361, v362);
              // pto: %9
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v363 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %9
              ;
              uint64_t v364 = (uint64_t) v23;
              TASSIGN(v363, v364);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
              uint16_t v365 = static_cast<uint16_t>(v45);
              uint16_t v366 = static_cast<uint16_t>(v45);
              TEXTRACT(v363, v347, v365, v366);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
              // pto: %10
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v367 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
              // pto: %10
              ;
              uint64_t v368 = (uint64_t) v25;
              TASSIGN(v367, v368);
              uint16_t v369 = static_cast<uint16_t>(v45);
              uint16_t v370 = static_cast<uint16_t>(v36);
              TEXTRACT(v367, v333, v369, v370);
              // pto: %11
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v371 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %11
              ;
              uint64_t v372 = (uint64_t) v25;
              TASSIGN(v371, v372);
              uint16_t v373 = static_cast<uint16_t>(v36);
              uint16_t v374 = static_cast<uint16_t>(v45);
              TEXTRACT(v371, v347, v373, v374);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v114, v114, v359, v363);
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
              TMATMUL_ACC(v114, v114, v367, v371);
            } else {
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
              for (int64_t v375 = v45; v375 < v33; v375 += v29) {
                // pto: %231, %232
                ;
                int64_t v376 = (int64_t) ((uint64_t) v249 + (uint64_t) v375) % v32;
                // pto: %233, %234, %235
                ;
                int64_t v377 = v376 < v45 ? (int64_t) ((uint64_t) v376 + (uint64_t) v32) : v376;
                // pto: %236
                ;
                int64_t v378 = (int64_t) ((uint64_t) v377 * (uint64_t) v33);
                // pto: %14
                ;
                Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v379 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v33);
                // pto: %14
                ;
                uint64_t v380 = (uint64_t) v26;
                TASSIGN(v379, v380);
                // pto: %239
                ;
                int64_t v381 = (int64_t) ((uint64_t) v198 + (uint64_t) v378);
                // pto: %240
                ;
                int64_t v382 = v381 < v45 ? v45 : v381;
                // pto: %241
                ;
                const int64_t v383 = 0;
                // pto: %241
                ;
                __gm__ bfloat16_t* v384 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                // pto: %241
                ;
                const int64_t v385 = 1;
                // pto: %241
                ;
                const int64_t v386 = 1;
                // pto: %241
                ;
                const int64_t v387 = 1;
                // pto: %241
                ;
                int64_t v388 = v193 * v28;
                // pto: %241
                ;
                int64_t v389 = v387 * v388;
                // pto: %241
                ;
                pto::Shape<1, 1, 1, -1, 16> v390 = pto::Shape<1, 1, 1, -1, 16>(v385, v386, v387, v193, v33);
                // pto: %241
                ;
                pto::Stride<-1, -1, -1, -1, -1> v391 = pto::Stride<-1, -1, -1, -1, -1>(v386 * v389, v389, v388, v28, v29);
                // pto: %241
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v392 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v384 + (v383 + v197 * v28 + v382 * v29), v390, v391);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
                TLOAD(v379, v392);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                // pto: %15
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v393 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %15
                ;
                uint64_t v394 = (uint64_t) v27;
                TASSIGN(v393, v394);
                // pto: %245
                ;
                int64_t v395 = v378 / v33;
                // pto: %246
                ;
                int64_t v396 = v395 < v45 ? v45 : v395;
                // pto: %247
                ;
                __gm__ bfloat16_t* v397 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                // pto: %247
                ;
                const int64_t v398 = 0;
                // pto: %247
                ;
                const int64_t v399 = 4194304;
                // pto: %247
                ;
                const int64_t v400 = 65536;
                // pto: %247
                ;
                const int64_t v401 = 256;
                // pto: %247
                ;
                pto::Shape<1, 8, 1, 16, 16> v402 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %247
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v403 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %247
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v404 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v397 + ((v398 + v213 * v399) + v215 * v400 + v396 * v401), v402, v403);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
                TLOAD(v393, v404);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                // pto: %16
                ;
                Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v405 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v33);
                // pto: %16
                ;
                uint64_t v406 = (uint64_t) v23;
                TASSIGN(v405, v406);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
                uint16_t v407 = static_cast<uint16_t>(v45);
                uint16_t v408 = static_cast<uint16_t>(v45);
                TEXTRACT(v405, v379, v407, v408);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
                // pto: %17
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v409 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %17
                ;
                uint64_t v410 = (uint64_t) v23;
                TASSIGN(v409, v410);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                uint16_t v411 = static_cast<uint16_t>(v45);
                uint16_t v412 = static_cast<uint16_t>(v45);
                TEXTRACT(v409, v393, v411, v412);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v114, v114, v405, v409);
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
              };
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
            };
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
          };
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %248, %249
          ;
          int64_t v413 = (int64_t) ((uint64_t) v148 + (uint64_t) v54) % v32;
          // pto: %250, %251, %252
          ;
          int64_t v414 = v413 < v45 ? (int64_t) ((uint64_t) v413 + (uint64_t) v32) : v413;
          // pto: %253
          ;
          // pto: %254
          ;
          int64_t v415 = v193 < v36 ? v193 : v36;
          v118.SetValidShape(v415, v36);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
          if (v414 <= v54) {
            // pto: %256
            ;
            int64_t v416 = (int64_t) ((uint64_t) v414 * (uint64_t) v33);
            // pto: %19
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v417 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v32);
            // pto: %19
            ;
            uint64_t v418 = (uint64_t) v23;
            TASSIGN(v417, v418);
            // pto: %259
            ;
            int64_t v419 = (int64_t) ((uint64_t) v198 + (uint64_t) v416);
            // pto: %260
            ;
            int64_t v420 = v419 < v45 ? v45 : v419;
            // pto: %261
            ;
            const int64_t v421 = 0;
            // pto: %261
            ;
            __gm__ bfloat16_t* v422 = PTOAS__GLOBAL_TENSOR_DATA(v70);
            // pto: %261
            ;
            const int64_t v423 = 1;
            // pto: %261
            ;
            const int64_t v424 = 1;
            // pto: %261
            ;
            const int64_t v425 = 1;
            // pto: %261
            ;
            int64_t v426 = v193 * v28;
            // pto: %261
            ;
            int64_t v427 = v425 * v426;
            // pto: %261
            ;
            pto::Shape<1, 1, 1, -1, 256> v428 = pto::Shape<1, 1, 1, -1, 256>(v423, v424, v425, v193, v32);
            // pto: %261
            ;
            pto::Stride<-1, -1, -1, -1, -1> v429 = pto::Stride<-1, -1, -1, -1, -1>(v424 * v427, v427, v426, v28, v29);
            // pto: %261
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v430 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v422 + (v421 + v197 * v28 + v420 * v29), v428, v429);
            TLOAD(v417, v430);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %20
            ;
            Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v431 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
            // pto: %20
            ;
            uint64_t v432 = (uint64_t) v24;
            TASSIGN(v431, v432);
            // pto: %265
            ;
            int64_t v433 = v416 / v33;
            // pto: %266
            ;
            int64_t v434 = v433 < v45 ? v45 : v433;
            // pto: %267
            ;
            __gm__ bfloat16_t* v435 = PTOAS__GLOBAL_TENSOR_DATA(v73);
            // pto: %267
            ;
            const int64_t v436 = 0;
            // pto: %267
            ;
            const int64_t v437 = 4194304;
            // pto: %267
            ;
            const int64_t v438 = 65536;
            // pto: %267
            ;
            const int64_t v439 = 256;
            // pto: %267
            ;
            pto::Shape<1, 8, 16, 16, 16> v440 = pto::Shape<1, 8, 16, 16, 16>();
            // pto: %267
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v441 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %267
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v442 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v435 + ((v436 + v213 * v437) + v215 * v438 + v434 * v439), v440, v441);
            TLOAD(v431, v442);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %21
            ;
            Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v443 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
            // pto: %21
            ;
            uint64_t v444 = (uint64_t) v23;
            TASSIGN(v443, v444);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            uint16_t v445 = static_cast<uint16_t>(v45);
            uint16_t v446 = static_cast<uint16_t>(v45);
            TEXTRACT(v443, v417, v445, v446);
            // pto: %22
            ;
            Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v447 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
            // pto: %22
            ;
            uint64_t v448 = (uint64_t) v23;
            TASSIGN(v447, v448);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            uint16_t v449 = static_cast<uint16_t>(v45);
            uint16_t v450 = static_cast<uint16_t>(v45);
            TEXTRACT(v447, v431, v449, v450);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            // pto: %23
            ;
            Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v451 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
            // pto: %23
            ;
            uint64_t v452 = (uint64_t) v25;
            TASSIGN(v451, v452);
            uint16_t v453 = static_cast<uint16_t>(v45);
            uint16_t v454 = static_cast<uint16_t>(v36);
            TEXTRACT(v451, v417, v453, v454);
            // pto: %24
            ;
            Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v455 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
            // pto: %24
            ;
            uint64_t v456 = (uint64_t) v25;
            TASSIGN(v455, v456);
            uint16_t v457 = static_cast<uint16_t>(v36);
            uint16_t v458 = static_cast<uint16_t>(v45);
            TEXTRACT(v455, v431, v457, v458);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v226, v226, v443, v447);
            pipe_barrier(PIPE_M);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
            TMATMUL_ACC(v226, v226, v451, v455);
          } else {
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
            for (int64_t v459 = v45; v459 < v33; v459 += v29) {
              // pto: %269, %270
              ;
              int64_t v460 = (int64_t) ((uint64_t) v414 + (uint64_t) v459) % v32;
              // pto: %271, %272, %273
              ;
              int64_t v461 = v460 < v45 ? (int64_t) ((uint64_t) v460 + (uint64_t) v32) : v460;
              // pto: %274
              ;
              int64_t v462 = (int64_t) ((uint64_t) v461 * (uint64_t) v33);
              // pto: %27
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v463 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v33);
              // pto: %27
              ;
              uint64_t v464 = (uint64_t) v23;
              TASSIGN(v463, v464);
              // pto: %277
              ;
              int64_t v465 = (int64_t) ((uint64_t) v198 + (uint64_t) v462);
              // pto: %278
              ;
              int64_t v466 = v465 < v45 ? v45 : v465;
              // pto: %279
              ;
              const int64_t v467 = 0;
              // pto: %279
              ;
              __gm__ bfloat16_t* v468 = PTOAS__GLOBAL_TENSOR_DATA(v70);
              // pto: %279
              ;
              const int64_t v469 = 1;
              // pto: %279
              ;
              const int64_t v470 = 1;
              // pto: %279
              ;
              const int64_t v471 = 1;
              // pto: %279
              ;
              int64_t v472 = v193 * v28;
              // pto: %279
              ;
              int64_t v473 = v471 * v472;
              // pto: %279
              ;
              pto::Shape<1, 1, 1, -1, 16> v474 = pto::Shape<1, 1, 1, -1, 16>(v469, v470, v471, v193, v33);
              // pto: %279
              ;
              pto::Stride<-1, -1, -1, -1, -1> v475 = pto::Stride<-1, -1, -1, -1, -1>(v470 * v473, v473, v472, v28, v29);
              // pto: %279
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v476 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v468 + (v467 + v197 * v28 + v466 * v29), v474, v475);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              TLOAD(v463, v476);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              // pto: %28
              ;
              Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v477 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
              // pto: %28
              ;
              uint64_t v478 = (uint64_t) v24;
              TASSIGN(v477, v478);
              // pto: %283
              ;
              int64_t v479 = v462 / v33;
              // pto: %284
              ;
              int64_t v480 = v479 < v45 ? v45 : v479;
              // pto: %285
              ;
              __gm__ bfloat16_t* v481 = PTOAS__GLOBAL_TENSOR_DATA(v73);
              // pto: %285
              ;
              const int64_t v482 = 0;
              // pto: %285
              ;
              const int64_t v483 = 4194304;
              // pto: %285
              ;
              const int64_t v484 = 65536;
              // pto: %285
              ;
              const int64_t v485 = 256;
              // pto: %285
              ;
              pto::Shape<1, 8, 1, 16, 16> v486 = pto::Shape<1, 8, 1, 16, 16>();
              // pto: %285
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v487 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %285
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v488 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v481 + ((v482 + v213 * v483) + v215 * v484 + v480 * v485), v486, v487);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              TLOAD(v477, v488);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              // pto: %29
              ;
              Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v489 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v33);
              // pto: %29
              ;
              uint64_t v490 = (uint64_t) v23;
              TASSIGN(v489, v490);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
              uint16_t v491 = static_cast<uint16_t>(v45);
              uint16_t v492 = static_cast<uint16_t>(v45);
              TEXTRACT(v489, v463, v491, v492);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              // pto: %30
              ;
              Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v493 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
              // pto: %30
              ;
              uint64_t v494 = (uint64_t) v23;
              TASSIGN(v493, v494);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              uint16_t v495 = static_cast<uint16_t>(v45);
              uint16_t v496 = static_cast<uint16_t>(v45);
              TEXTRACT(v493, v477, v495, v496);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v226, v226, v489, v493);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
            };
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          };
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
          // pto: %seed_fast_acc__rv_v2
          ;
          Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v497 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v193, v36);
          // pto: %seed_fast_acc__rv_v2
          ;
          uint64_t v498 = (uint64_t) v23;
          TASSIGN(v497, v498);
          // pto: %287, %288
          ;
          int64_t v499 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v55) + (uint64_t) v143);
          // pto: %289
          ;
          int64_t v500 = v499 < v45 ? v45 : v499;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v501 = 0;
          // pto: %accum__ssa_v0_pview
          ;
          __gm__ float* v502 = PTOAS__GLOBAL_TENSOR_DATA(v94);
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v503 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v504 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v505 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          int64_t v506 = v193 * v42;
          // pto: %accum__ssa_v0_pview
          ;
          int64_t v507 = v505 * v506;
          // pto: %accum__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, -1, 128> v508 = pto::Shape<1, 1, 1, -1, 128>(v503, v504, v505, v193, v36);
          // pto: %accum__ssa_v0_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v509 = pto::Stride<-1, -1, -1, -1, -1>(v504 * v507, v507, v506, v42, v29);
          // pto: %accum__ssa_v0_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v510 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v502 + (v501 + v197 * v42 + v500 * v29), v508, v509);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
          TSTORE(v510, v497);
        } else {
          for (int64_t v511 = v45; v511 < v30; v511 += v29) {
            // pto: %290
            ;
            int64_t v512 = (int64_t) ((uint64_t) v145 + (uint64_t) v511);
            // pto: %291
            ;
            if (v512 < v138) {
              // pto: %292
              ;
              int64_t v513 = (int64_t) ((uint64_t) v512 * (uint64_t) v33);
              // pto: %293
              ;
              int64_t v514 = (int64_t) ((uint64_t) v17 - (uint64_t) v513);
              // pto: %294
              ;
              int64_t v515 = v514 < v33 ? v514 : v33;
              // pto: %296, %297, %298, %299, %295
              ;
              int32_t v516 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v512 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
              // pto: %300
              ;
              int64_t v517 = (int64_t) v516;
              // pto: %301
              ;
              int64_t v518 = v517 < v45 ? v45 : v517;
              // pto: %seed_narrow_acc__tile
              ;
              Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v519 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
              // pto: %seed_narrow_acc__tile
              ;
              uint64_t v520 = (uint64_t) v23;
              TASSIGN(v519, v520);
              wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              for (int64_t v521 = v45; v521 < v33; v521 += v29) {
                // pto: %302
                ;
                int64_t v522 = (int64_t) ((uint64_t) v521 * (uint64_t) v33);
                // pto: %303, %304
                ;
                int64_t v523 = (int64_t) ((uint64_t) v518 + (uint64_t) v522) % v32;
                // pto: %305, %306, %307
                ;
                int64_t v524 = v523 < v45 ? (int64_t) ((uint64_t) v523 + (uint64_t) v32) : v523;
                // pto: %308
                ;
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                if (v524 <= v54) {
                  // pto: %309
                  ;
                  int64_t v525 = (int64_t) ((uint64_t) v524 * (uint64_t) v33);
                  // pto: %seed_narrow_packet_x__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v526 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v515, v32);
                  // pto: %seed_narrow_packet_x__tile
                  ;
                  uint64_t v527 = (uint64_t) v24;
                  TASSIGN(v526, v527);
                  // pto: %310
                  ;
                  int64_t v528 = v513 < v45 ? v45 : v513;
                  // pto: %311, %312
                  ;
                  int64_t v529 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v41) + (uint64_t) v525);
                  // pto: %313
                  ;
                  int64_t v530 = v529 < v45 ? v45 : v529;
                  // pto: %314
                  ;
                  const int64_t v531 = 0;
                  // pto: %314
                  ;
                  __gm__ bfloat16_t* v532 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                  // pto: %314
                  ;
                  const int64_t v533 = 1;
                  // pto: %314
                  ;
                  const int64_t v534 = 1;
                  // pto: %314
                  ;
                  const int64_t v535 = 1;
                  // pto: %314
                  ;
                  int64_t v536 = v515 * v28;
                  // pto: %314
                  ;
                  int64_t v537 = v535 * v536;
                  // pto: %314
                  ;
                  pto::Shape<1, 1, 1, -1, 256> v538 = pto::Shape<1, 1, 1, -1, 256>(v533, v534, v535, v515, v32);
                  // pto: %314
                  ;
                  pto::Stride<-1, -1, -1, -1, -1> v539 = pto::Stride<-1, -1, -1, -1, -1>(v534 * v537, v537, v536, v28, v29);
                  // pto: %314
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v540 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v532 + (v531 + v528 * v28 + v530 * v29), v538, v539);
                  TLOAD(v526, v540);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  // pto: %seed_narrow_packet_w__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v541 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
                  // pto: %seed_narrow_packet_w__tile
                  ;
                  uint64_t v542 = (uint64_t) v23;
                  TASSIGN(v541, v542);
                  // pto: %315
                  ;
                  int64_t v543 = v140 < v45 ? v45 : v140;
                  // pto: %316
                  ;
                  int64_t v544 = v143 / v33;
                  // pto: %317
                  ;
                  int64_t v545 = v544 < v45 ? v45 : v544;
                  // pto: %318
                  ;
                  int64_t v546 = v525 / v33;
                  // pto: %319
                  ;
                  int64_t v547 = v546 < v45 ? v45 : v546;
                  // pto: %320
                  ;
                  __gm__ bfloat16_t* v548 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                  // pto: %320
                  ;
                  const int64_t v549 = 0;
                  // pto: %320
                  ;
                  const int64_t v550 = 4194304;
                  // pto: %320
                  ;
                  const int64_t v551 = 65536;
                  // pto: %320
                  ;
                  const int64_t v552 = 256;
                  // pto: %320
                  ;
                  pto::Shape<1, 8, 16, 16, 16> v553 = pto::Shape<1, 8, 16, 16, 16>();
                  // pto: %320
                  ;
                  pto::Stride<4194304, 65536, 256, 16, 1> v554 = pto::Stride<4194304, 65536, 256, 16, 1>();
                  // pto: %320
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v555 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v548 + ((v549 + v543 * v550) + v545 * v551 + v547 * v552), v553, v554);
                  TLOAD(v541, v555);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  // pto: %seed_narrow_acc__iter_v1_l0_a
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v556 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v515, v36);
                  // pto: %seed_narrow_acc__iter_v1_l0_a
                  ;
                  uint64_t v557 = (uint64_t) v23;
                  TASSIGN(v556, v557);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  uint16_t v558 = static_cast<uint16_t>(v45);
                  uint16_t v559 = static_cast<uint16_t>(v45);
                  TEXTRACT(v556, v526, v558, v559);
                  // pto: %seed_narrow_acc__iter_v1_l0_b
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v560 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %seed_narrow_acc__iter_v1_l0_b
                  ;
                  uint64_t v561 = (uint64_t) v23;
                  TASSIGN(v560, v561);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  uint16_t v562 = static_cast<uint16_t>(v45);
                  uint16_t v563 = static_cast<uint16_t>(v45);
                  TEXTRACT(v560, v541, v562, v563);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  // pto: %32
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v564 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v515, v36);
                  // pto: %32
                  ;
                  uint64_t v565 = (uint64_t) v25;
                  TASSIGN(v564, v565);
                  uint16_t v566 = static_cast<uint16_t>(v45);
                  uint16_t v567 = static_cast<uint16_t>(v36);
                  TEXTRACT(v564, v526, v566, v567);
                  // pto: %33
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v568 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %33
                  ;
                  uint64_t v569 = (uint64_t) v25;
                  TASSIGN(v568, v569);
                  uint16_t v570 = static_cast<uint16_t>(v36);
                  uint16_t v571 = static_cast<uint16_t>(v45);
                  TEXTRACT(v568, v541, v570, v571);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  // pto: %321
                  ;
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  if (v521 == v45) {
                    pipe_barrier(PIPE_M);
                    TMATMUL(v519, v556, v560);
                  } else {
                    pipe_barrier(PIPE_M);
                    TMATMUL_ACC(v519, v519, v556, v560);
                  };
                  pipe_barrier(PIPE_M);
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  TMATMUL_ACC(v519, v519, v564, v568);
                } else {
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  for (int64_t v572 = v45; v572 < v33; v572 += v29) {
                    // pto: %322, %323
                    ;
                    int64_t v573 = (int64_t) ((uint64_t) v524 + (uint64_t) v572) % v32;
                    // pto: %324, %325, %326
                    ;
                    int64_t v574 = v573 < v45 ? (int64_t) ((uint64_t) v573 + (uint64_t) v32) : v573;
                    // pto: %327
                    ;
                    int64_t v575 = (int64_t) ((uint64_t) v574 * (uint64_t) v33);
                    // pto: %seed_narrow_wrap_x__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v576 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v515, v33);
                    // pto: %seed_narrow_wrap_x__tile
                    ;
                    uint64_t v577 = (uint64_t) v24;
                    TASSIGN(v576, v577);
                    // pto: %328
                    ;
                    int64_t v578 = v513 < v45 ? v45 : v513;
                    // pto: %329, %330
                    ;
                    int64_t v579 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v41) + (uint64_t) v575);
                    // pto: %331
                    ;
                    int64_t v580 = v579 < v45 ? v45 : v579;
                    // pto: %332
                    ;
                    const int64_t v581 = 0;
                    // pto: %332
                    ;
                    __gm__ bfloat16_t* v582 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                    // pto: %332
                    ;
                    const int64_t v583 = 1;
                    // pto: %332
                    ;
                    const int64_t v584 = 1;
                    // pto: %332
                    ;
                    const int64_t v585 = 1;
                    // pto: %332
                    ;
                    int64_t v586 = v515 * v28;
                    // pto: %332
                    ;
                    int64_t v587 = v585 * v586;
                    // pto: %332
                    ;
                    pto::Shape<1, 1, 1, -1, 16> v588 = pto::Shape<1, 1, 1, -1, 16>(v583, v584, v585, v515, v33);
                    // pto: %332
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v589 = pto::Stride<-1, -1, -1, -1, -1>(v584 * v587, v587, v586, v28, v29);
                    // pto: %332
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v590 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v582 + (v581 + v578 * v28 + v580 * v29), v588, v589);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    TLOAD(v576, v590);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    // pto: %seed_narrow_wrap_w__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v591 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %seed_narrow_wrap_w__tile
                    ;
                    uint64_t v592 = (uint64_t) v23;
                    TASSIGN(v591, v592);
                    // pto: %333
                    ;
                    int64_t v593 = v140 < v45 ? v45 : v140;
                    // pto: %334
                    ;
                    int64_t v594 = v143 / v33;
                    // pto: %335
                    ;
                    int64_t v595 = v594 < v45 ? v45 : v594;
                    // pto: %336
                    ;
                    int64_t v596 = v575 / v33;
                    // pto: %337
                    ;
                    int64_t v597 = v596 < v45 ? v45 : v596;
                    // pto: %338
                    ;
                    __gm__ bfloat16_t* v598 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                    // pto: %338
                    ;
                    const int64_t v599 = 0;
                    // pto: %338
                    ;
                    const int64_t v600 = 4194304;
                    // pto: %338
                    ;
                    const int64_t v601 = 65536;
                    // pto: %338
                    ;
                    const int64_t v602 = 256;
                    // pto: %338
                    ;
                    pto::Shape<1, 8, 1, 16, 16> v603 = pto::Shape<1, 8, 1, 16, 16>();
                    // pto: %338
                    ;
                    pto::Stride<4194304, 65536, 256, 16, 1> v604 = pto::Stride<4194304, 65536, 256, 16, 1>();
                    // pto: %338
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v605 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v598 + ((v599 + v593 * v600) + v595 * v601 + v597 * v602), v603, v604);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                    TLOAD(v591, v605);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    // pto: %35
                    ;
                    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v606 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v515, v33);
                    // pto: %35
                    ;
                    uint64_t v607 = (uint64_t) v23;
                    TASSIGN(v606, v607);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                    uint16_t v608 = static_cast<uint16_t>(v45);
                    uint16_t v609 = static_cast<uint16_t>(v45);
                    TEXTRACT(v606, v576, v608, v609);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    // pto: %36
                    ;
                    Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v610 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %36
                    ;
                    uint64_t v611 = (uint64_t) v23;
                    TASSIGN(v610, v611);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    uint16_t v612 = static_cast<uint16_t>(v45);
                    uint16_t v613 = static_cast<uint16_t>(v45);
                    TEXTRACT(v610, v591, v612, v613);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    // pto: %340, %341
                    ;
                    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    if ((int64_t) ((uint64_t) v522 + (uint64_t) v572) == v45) {
                      pipe_barrier(PIPE_M);
                      TMATMUL(v519, v606, v610);
                    } else {
                      pipe_barrier(PIPE_M);
                      TMATMUL_ACC(v519, v519, v606, v610);
                    };
                    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  };
                  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
              // pto: %342
              ;
              int64_t v614 = v513 < v45 ? v45 : v513;
              // pto: %343, %344
              ;
              int64_t v615 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v55) + (uint64_t) v143);
              // pto: %345
              ;
              int64_t v616 = v615 < v45 ? v45 : v615;
              // pto: %346
              ;
              __gm__ float* v617 = PTOAS__GLOBAL_TENSOR_DATA(v94);
              // pto: %346
              ;
              const int64_t v618 = 0;
              // pto: %346
              ;
              const int64_t v619 = 8192;
              // pto: %346
              ;
              pto::Shape<1, 1, 1, 16, 128> v620 = pto::Shape<1, 1, 1, 16, 128>();
              // pto: %346
              ;
              pto::Stride<131072, 131072, 131072, 8192, 1> v621 = pto::Stride<131072, 131072, 131072, 8192, 1>();
              // pto: %346
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v622 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v617 + (v618 + v614 * v619 + v616), v620, v621);
              wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
              pipe_barrier(PIPE_FIX);
              TSTORE(v622, v519);
              set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
            };
          };
        };
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    };
  } else {
    for (int64_t v623 = v126; v623 < v31; v623 += v48) {
      // pto: %348
      ;
      int64_t v624 = v623 / v30;
      // pto: %349
      ;
      int64_t v625 = v623 % v30;
      // pto: %350, %351, %352
      ;
      int64_t v626 = v625 < v45 ? (int64_t) ((uint64_t) v625 + (uint64_t) v30) : v625;
      // pto: %353
      ;
      int64_t v627 = (int64_t) ((uint64_t) v626 * (uint64_t) v36);
      // pto: %354, %355
      ;
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v628 = v45; v628 < ((int64_t) ((uint64_t) v138 + (uint64_t) v49) / v30); v628 += v29) {
        // pto: %356
        ;
        int64_t v629 = (int64_t) ((uint64_t) v628 * (uint64_t) v30);
        // pto: %359, %360, %361, %357
        ;
        int32_t v630 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v628 * (uint64_t) v31) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
        // pto: %362
        ;
        int64_t v631 = (int64_t) v630;
        // pto: %363
        ;
        int64_t v632 = v631 < v45 ? v45 : v631;
        // pto: %364
        ;
        int64_t v633 = (int64_t) ((uint64_t) v629 + (uint64_t) v29);
        // pto: %365
        ;
        // pto: %v4_same_start__phi_v3
        ;
        int64_t v634;
        if (v633 < v138) {
          // pto: %368, %369, %370, %371, %366
          ;
          int32_t v635 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v633 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %372
          ;
          int64_t v636 = (int64_t) v635;
          // pto: %373
          ;
          int64_t v637 = v636 < v45 ? v45 : v636;
          // pto: %374, %v4_same_start__phi_v2
          ;
          v634 = v637 != v632 ? v45 : v29;
        } else {
          v634 = v29;
        };
        // pto: %375
        ;
        int64_t v638 = (int64_t) ((uint64_t) v629 + (uint64_t) v50);
        // pto: %376
        ;
        // pto: %v4_same_start__phi_v6
        ;
        int64_t v639;
        if (v638 < v138) {
          // pto: %379, %380, %381, %382, %377
          ;
          int32_t v640 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v638 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %383
          ;
          int64_t v641 = (int64_t) v640;
          // pto: %384
          ;
          int64_t v642 = v641 < v45 ? v45 : v641;
          // pto: %385, %v4_same_start__phi_v5
          ;
          int64_t v643 = v642 != v632 ? v45 : v634;
          v639 = v643;
        } else {
          v639 = v634;
        };
        // pto: %386
        ;
        int64_t v644 = (int64_t) ((uint64_t) v629 + (uint64_t) v51);
        // pto: %387
        ;
        // pto: %v4_same_start__phi_v9
        ;
        int64_t v645;
        if (v644 < v138) {
          // pto: %390, %391, %392, %393, %388
          ;
          int32_t v646 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v644 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %394
          ;
          int64_t v647 = (int64_t) v646;
          // pto: %395
          ;
          int64_t v648 = v647 < v45 ? v45 : v647;
          // pto: %396, %v4_same_start__phi_v8
          ;
          int64_t v649 = v648 != v632 ? v45 : v639;
          v645 = v649;
        } else {
          v645 = v639;
        };
        // pto: %397
        ;
        int64_t v650 = (int64_t) ((uint64_t) v629 + (uint64_t) v43);
        // pto: %398
        ;
        // pto: %v4_same_start__phi_v12
        ;
        int64_t v651;
        if (v650 < v138) {
          // pto: %401, %402, %403, %404, %399
          ;
          int32_t v652 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v650 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %405
          ;
          int64_t v653 = (int64_t) v652;
          // pto: %406
          ;
          int64_t v654 = v653 < v45 ? v45 : v653;
          // pto: %407, %v4_same_start__phi_v11
          ;
          int64_t v655 = v654 != v632 ? v45 : v645;
          v651 = v655;
        } else {
          v651 = v645;
        };
        // pto: %408
        ;
        int64_t v656 = (int64_t) ((uint64_t) v629 + (uint64_t) v52);
        // pto: %409
        ;
        // pto: %v4_same_start__phi_v15
        ;
        int64_t v657;
        if (v656 < v138) {
          // pto: %412, %413, %414, %415, %410
          ;
          int32_t v658 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v656 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %416
          ;
          int64_t v659 = (int64_t) v658;
          // pto: %417
          ;
          int64_t v660 = v659 < v45 ? v45 : v659;
          // pto: %418, %v4_same_start__phi_v14
          ;
          int64_t v661 = v660 != v632 ? v45 : v651;
          v657 = v661;
        } else {
          v657 = v651;
        };
        // pto: %419
        ;
        int64_t v662 = (int64_t) ((uint64_t) v629 + (uint64_t) v53);
        // pto: %420
        ;
        // pto: %v4_same_start__phi_v18
        ;
        int64_t v663;
        if (v662 < v138) {
          // pto: %423, %424, %425, %426, %421
          ;
          int32_t v664 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v662 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %427
          ;
          int64_t v665 = (int64_t) v664;
          // pto: %428
          ;
          int64_t v666 = v665 < v45 ? v45 : v665;
          // pto: %429, %v4_same_start__phi_v17
          ;
          int64_t v667 = v666 != v632 ? v45 : v657;
          v663 = v667;
        } else {
          v663 = v657;
        };
        // pto: %430
        ;
        int64_t v668 = (int64_t) ((uint64_t) v629 + (uint64_t) v49);
        // pto: %431
        ;
        // pto: %v4_same_start__phi_v21
        ;
        int64_t v669;
        if (v668 < v138) {
          // pto: %434, %435, %436, %437, %432
          ;
          int32_t v670 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v668 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %438
          ;
          int64_t v671 = (int64_t) v670;
          // pto: %439
          ;
          int64_t v672 = v671 < v45 ? v45 : v671;
          // pto: %440, %v4_same_start__phi_v20
          ;
          int64_t v673 = v672 != v632 ? v45 : v663;
          v669 = v673;
        } else {
          v669 = v663;
        };
        // pto: %441, %v4_same_start__phi_v23
        ;
        int64_t v674 = v17 <= v33 ? v45 : v669;
        // pto: %442
        ;
        int64_t v675 = v632 % v33;
        // pto: %443, %444, %445
        ;
        int64_t v676 = v675 < v45 ? (int64_t) ((uint64_t) v675 + (uint64_t) v33) : v675;
        // pto: %446, %v4_same_start__phi_v25
        ;
        int64_t v677 = v676 != v45 ? v45 : v674;
        // pto: %447
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        if (v677 == v29) {
          int64_t v678 = (int64_t) ((uint64_t) v628 * (uint64_t) v36);
          // pto: %449
          ;
          int64_t v679 = (int64_t) ((uint64_t) v17 - (uint64_t) v678);
          // pto: %450
          ;
          int64_t v680 = v679 < v36 ? v679 : v36;
          // pto: %451
          ;
          int64_t v681 = v632 % v32;
          // pto: %452, %453, %454
          ;
          int64_t v682 = v681 < v45 ? (int64_t) ((uint64_t) v681 + (uint64_t) v32) : v681;
          // pto: %455
          ;
          int64_t v683 = (int64_t) ((uint64_t) v682 * (uint64_t) v33);
          // pto: %v4_wide_seed_x__ssa_v0
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v684 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v680, v33);
          // pto: %v4_wide_seed_x__ssa_v0
          ;
          uint64_t v685 = (uint64_t) v23;
          TASSIGN(v684, v685);
          // pto: %456
          ;
          int64_t v686 = v678 < v45 ? v45 : v678;
          // pto: %457
          ;
          int64_t v687 = (int64_t) ((uint64_t) v624 * (uint64_t) v41);
          // pto: %458
          ;
          int64_t v688 = (int64_t) ((uint64_t) v687 + (uint64_t) v683);
          // pto: %459
          ;
          int64_t v689 = v688 < v45 ? v45 : v688;
          // pto: %460
          ;
          const int64_t v690 = 0;
          // pto: %460
          ;
          __gm__ bfloat16_t* v691 = PTOAS__GLOBAL_TENSOR_DATA(v70);
          // pto: %460
          ;
          const int64_t v692 = 1;
          // pto: %460
          ;
          const int64_t v693 = 1;
          // pto: %460
          ;
          const int64_t v694 = 1;
          // pto: %460
          ;
          int64_t v695 = v680 * v28;
          // pto: %460
          ;
          int64_t v696 = v694 * v695;
          // pto: %460
          ;
          pto::Shape<1, 1, 1, -1, 16> v697 = pto::Shape<1, 1, 1, -1, 16>(v692, v693, v694, v680, v33);
          // pto: %460
          ;
          pto::Stride<-1, -1, -1, -1, -1> v698 = pto::Stride<-1, -1, -1, -1, -1>(v693 * v696, v696, v695, v28, v29);
          // pto: %460
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v699 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v691 + (v690 + v686 * v28 + v689 * v29), v697, v698);
          TLOAD(v684, v699);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %t__tmp_v18
          ;
          Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v700 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
          // pto: %t__tmp_v18
          ;
          uint64_t v701 = (uint64_t) v24;
          TASSIGN(v700, v701);
          // pto: %461
          ;
          int64_t v702 = v624 < v45 ? v45 : v624;
          // pto: %462
          ;
          int64_t v703 = v627 / v33;
          // pto: %463
          ;
          int64_t v704 = v703 < v45 ? v45 : v703;
          // pto: %464
          ;
          int64_t v705 = v683 / v33;
          // pto: %465
          ;
          int64_t v706 = v705 < v45 ? v45 : v705;
          // pto: %466
          ;
          __gm__ bfloat16_t* v707 = PTOAS__GLOBAL_TENSOR_DATA(v73);
          // pto: %466
          ;
          const int64_t v708 = 0;
          // pto: %466
          ;
          const int64_t v709 = 4194304;
          // pto: %466
          ;
          const int64_t v710 = 65536;
          // pto: %466
          ;
          const int64_t v711 = 256;
          // pto: %466
          ;
          pto::Shape<1, 8, 1, 16, 16> v712 = pto::Shape<1, 8, 1, 16, 16>();
          // pto: %466
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v713 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %466
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v714 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v707 + ((v708 + v702 * v709) + v704 * v710 + v706 * v711), v712, v713);
          TLOAD(v700, v714);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %v4_wide_seed_w__ssa_v0
          ;
          Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v715 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
          // pto: %v4_wide_seed_w__ssa_v0
          ;
          uint64_t v716 = (uint64_t) v24;
          TASSIGN(v715, v716);
          // pto: %v4_wide_seed_x__ssa_v0_Left
          ;
          Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v717 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v680, v33);
          // pto: %v4_wide_seed_x__ssa_v0_Left
          ;
          uint64_t v718 = (uint64_t) v23;
          TASSIGN(v717, v718);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          TMOV(v717, v684);
          // pto: %v4_wide_seed_w__ssa_v0_Right
          ;
          Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v719 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
          // pto: %v4_wide_seed_w__ssa_v0_Right
          ;
          uint64_t v720 = (uint64_t) v23;
          TASSIGN(v719, v720);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          TMOV(v719, v715);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %v4_wide_acc__ssa_v0
          ;
          Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v721 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v680, v36);
          // pto: %v4_wide_acc__ssa_v0
          ;
          uint64_t v722 = (uint64_t) v23;
          TASSIGN(v721, v722);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          TMATMUL(v721, v717, v719);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          for (int64_t v723 = v45; v723 < v46; v723 += v29) {
            // pto: %468, %467, %469, %470
            ;
            int64_t v724 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v632 + (uint64_t) ((int64_t) (uint64_t) v723 * (uint64_t) v33)) + (uint64_t) v29) % v32;
            // pto: %471, %472, %473
            ;
            int64_t v725 = v724 < v45 ? (int64_t) ((uint64_t) v724 + (uint64_t) v32) : v724;
            // pto: %474
            ;
            v122.SetValidShape(v680, v36);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            if (v725 <= v54) {
              // pto: %475
              ;
              int64_t v726 = (int64_t) ((uint64_t) v725 * (uint64_t) v33);
              // pto: %v4_wide_packet_x__ssa_v0
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v727 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v680, v32);
              // pto: %v4_wide_packet_x__ssa_v0
              ;
              uint64_t v728 = (uint64_t) v23;
              TASSIGN(v727, v728);
              // pto: %478
              ;
              int64_t v729 = (int64_t) ((uint64_t) v687 + (uint64_t) v726);
              // pto: %479
              ;
              int64_t v730 = v729 < v45 ? v45 : v729;
              // pto: %480
              ;
              const int64_t v731 = 0;
              // pto: %480
              ;
              __gm__ bfloat16_t* v732 = PTOAS__GLOBAL_TENSOR_DATA(v70);
              // pto: %480
              ;
              const int64_t v733 = 1;
              // pto: %480
              ;
              const int64_t v734 = 1;
              // pto: %480
              ;
              const int64_t v735 = 1;
              // pto: %480
              ;
              int64_t v736 = v680 * v28;
              // pto: %480
              ;
              int64_t v737 = v735 * v736;
              // pto: %480
              ;
              pto::Shape<1, 1, 1, -1, 256> v738 = pto::Shape<1, 1, 1, -1, 256>(v733, v734, v735, v680, v32);
              // pto: %480
              ;
              pto::Stride<-1, -1, -1, -1, -1> v739 = pto::Stride<-1, -1, -1, -1, -1>(v734 * v737, v737, v736, v28, v29);
              // pto: %480
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v740 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v732 + (v731 + v686 * v28 + v730 * v29), v738, v739);
              TLOAD(v727, v740);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              // pto: %t__tmp_v19
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v741 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
              // pto: %t__tmp_v19
              ;
              uint64_t v742 = (uint64_t) v24;
              TASSIGN(v741, v742);
              // pto: %484
              ;
              int64_t v743 = v726 / v33;
              // pto: %485
              ;
              int64_t v744 = v743 < v45 ? v45 : v743;
              // pto: %486
              ;
              __gm__ bfloat16_t* v745 = PTOAS__GLOBAL_TENSOR_DATA(v73);
              // pto: %486
              ;
              const int64_t v746 = 0;
              // pto: %486
              ;
              const int64_t v747 = 4194304;
              // pto: %486
              ;
              const int64_t v748 = 65536;
              // pto: %486
              ;
              const int64_t v749 = 256;
              // pto: %486
              ;
              pto::Shape<1, 8, 16, 16, 16> v750 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %486
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v751 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %486
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v752 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v745 + ((v746 + v702 * v747) + v704 * v748 + v744 * v749), v750, v751);
              TLOAD(v741, v752);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              // pto: %v4_wide_packet_w__ssa_v0
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v753 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
              // pto: %v4_wide_packet_w__ssa_v0
              ;
              uint64_t v754 = (uint64_t) v24;
              TASSIGN(v753, v754);
              // pto: %v4_wide_acc__ssa_v3_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v755 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v680, v36);
              // pto: %v4_wide_acc__ssa_v3_l0_a
              ;
              uint64_t v756 = (uint64_t) v23;
              TASSIGN(v755, v756);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              uint16_t v757 = static_cast<uint16_t>(v45);
              uint16_t v758 = static_cast<uint16_t>(v45);
              TEXTRACT(v755, v727, v757, v758);
              // pto: %v4_wide_acc__ssa_v3_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v759 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %v4_wide_acc__ssa_v3_l0_b
              ;
              uint64_t v760 = (uint64_t) v23;
              TASSIGN(v759, v760);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              uint16_t v761 = static_cast<uint16_t>(v45);
              uint16_t v762 = static_cast<uint16_t>(v45);
              TEXTRACT(v759, v753, v761, v762);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              // pto: %37
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v763 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v680, v36);
              // pto: %37
              ;
              uint64_t v764 = (uint64_t) v25;
              TASSIGN(v763, v764);
              uint16_t v765 = static_cast<uint16_t>(v45);
              uint16_t v766 = static_cast<uint16_t>(v36);
              TEXTRACT(v763, v727, v765, v766);
              // pto: %38
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v767 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %38
              ;
              uint64_t v768 = (uint64_t) v25;
              TASSIGN(v767, v768);
              uint16_t v769 = static_cast<uint16_t>(v36);
              uint16_t v770 = static_cast<uint16_t>(v45);
              TEXTRACT(v767, v753, v769, v770);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v721, v721, v755, v759);
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              TMATMUL_ACC(v721, v721, v763, v767);
            } else {
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              for (int64_t v771 = v45; v771 < v33; v771 += v29) {
                // pto: %487, %488
                ;
                int64_t v772 = (int64_t) ((uint64_t) v725 + (uint64_t) v771) % v32;
                // pto: %489, %490, %491
                ;
                int64_t v773 = v772 < v45 ? (int64_t) ((uint64_t) v772 + (uint64_t) v32) : v772;
                // pto: %492
                ;
                int64_t v774 = (int64_t) ((uint64_t) v773 * (uint64_t) v33);
                // pto: %v4_wide_wrap_x__ssa_v0
                ;
                Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v775 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v680, v33);
                // pto: %v4_wide_wrap_x__ssa_v0
                ;
                uint64_t v776 = (uint64_t) v23;
                TASSIGN(v775, v776);
                // pto: %495
                ;
                int64_t v777 = (int64_t) ((uint64_t) v687 + (uint64_t) v774);
                // pto: %496
                ;
                int64_t v778 = v777 < v45 ? v45 : v777;
                // pto: %497
                ;
                const int64_t v779 = 0;
                // pto: %497
                ;
                __gm__ bfloat16_t* v780 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                // pto: %497
                ;
                const int64_t v781 = 1;
                // pto: %497
                ;
                const int64_t v782 = 1;
                // pto: %497
                ;
                const int64_t v783 = 1;
                // pto: %497
                ;
                int64_t v784 = v680 * v28;
                // pto: %497
                ;
                int64_t v785 = v783 * v784;
                // pto: %497
                ;
                pto::Shape<1, 1, 1, -1, 16> v786 = pto::Shape<1, 1, 1, -1, 16>(v781, v782, v783, v680, v33);
                // pto: %497
                ;
                pto::Stride<-1, -1, -1, -1, -1> v787 = pto::Stride<-1, -1, -1, -1, -1>(v782 * v785, v785, v784, v28, v29);
                // pto: %497
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v788 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v780 + (v779 + v686 * v28 + v778 * v29), v786, v787);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                TLOAD(v775, v788);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                // pto: %t__tmp_v20
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v789 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %t__tmp_v20
                ;
                uint64_t v790 = (uint64_t) v24;
                TASSIGN(v789, v790);
                // pto: %501
                ;
                int64_t v791 = v774 / v33;
                // pto: %502
                ;
                int64_t v792 = v791 < v45 ? v45 : v791;
                // pto: %503
                ;
                __gm__ bfloat16_t* v793 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                // pto: %503
                ;
                const int64_t v794 = 0;
                // pto: %503
                ;
                const int64_t v795 = 4194304;
                // pto: %503
                ;
                const int64_t v796 = 65536;
                // pto: %503
                ;
                const int64_t v797 = 256;
                // pto: %503
                ;
                pto::Shape<1, 8, 1, 16, 16> v798 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %503
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v799 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %503
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v800 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v793 + ((v794 + v702 * v795) + v704 * v796 + v792 * v797), v798, v799);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                TLOAD(v789, v800);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                // pto: %v4_wide_wrap_w__ssa_v0
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v801 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %v4_wide_wrap_w__ssa_v0
                ;
                uint64_t v802 = (uint64_t) v24;
                TASSIGN(v801, v802);
                // pto: %v4_wide_wrap_x__ssa_v0_Left
                ;
                Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v803 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v680, v33);
                // pto: %v4_wide_wrap_x__ssa_v0_Left
                ;
                uint64_t v804 = (uint64_t) v23;
                TASSIGN(v803, v804);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                TMOV(v803, v775);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                // pto: %v4_wide_wrap_w__ssa_v0_Right
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v805 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %v4_wide_wrap_w__ssa_v0_Right
                ;
                uint64_t v806 = (uint64_t) v23;
                TASSIGN(v805, v806);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                TMOV(v805, v801);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v721, v721, v803, v805);
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            };
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          for (int64_t v807 = v56; v807 < v32; v807 += v29) {
            // pto: %504, %505
            ;
            int64_t v808 = (int64_t) ((uint64_t) v632 + (uint64_t) v807) % v32;
            // pto: %506, %507, %508
            ;
            int64_t v809 = v808 < v45 ? (int64_t) ((uint64_t) v808 + (uint64_t) v32) : v808;
            // pto: %509
            ;
            int64_t v810 = (int64_t) ((uint64_t) v809 * (uint64_t) v33);
            // pto: %v4_wide_tail_x__ssa_v0
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v811 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v680, v33);
            // pto: %v4_wide_tail_x__ssa_v0
            ;
            uint64_t v812 = (uint64_t) v23;
            TASSIGN(v811, v812);
            // pto: %512
            ;
            int64_t v813 = (int64_t) ((uint64_t) v687 + (uint64_t) v810);
            // pto: %513
            ;
            int64_t v814 = v813 < v45 ? v45 : v813;
            // pto: %514
            ;
            const int64_t v815 = 0;
            // pto: %514
            ;
            __gm__ bfloat16_t* v816 = PTOAS__GLOBAL_TENSOR_DATA(v70);
            // pto: %514
            ;
            const int64_t v817 = 1;
            // pto: %514
            ;
            const int64_t v818 = 1;
            // pto: %514
            ;
            const int64_t v819 = 1;
            // pto: %514
            ;
            int64_t v820 = v680 * v28;
            // pto: %514
            ;
            int64_t v821 = v819 * v820;
            // pto: %514
            ;
            pto::Shape<1, 1, 1, -1, 16> v822 = pto::Shape<1, 1, 1, -1, 16>(v817, v818, v819, v680, v33);
            // pto: %514
            ;
            pto::Stride<-1, -1, -1, -1, -1> v823 = pto::Stride<-1, -1, -1, -1, -1>(v818 * v821, v821, v820, v28, v29);
            // pto: %514
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v824 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v816 + (v815 + v686 * v28 + v814 * v29), v822, v823);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            TLOAD(v811, v824);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %t__tmp_v21
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v825 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
            // pto: %t__tmp_v21
            ;
            uint64_t v826 = (uint64_t) v24;
            TASSIGN(v825, v826);
            // pto: %518
            ;
            int64_t v827 = v810 / v33;
            // pto: %519
            ;
            int64_t v828 = v827 < v45 ? v45 : v827;
            // pto: %520
            ;
            __gm__ bfloat16_t* v829 = PTOAS__GLOBAL_TENSOR_DATA(v73);
            // pto: %520
            ;
            const int64_t v830 = 0;
            // pto: %520
            ;
            const int64_t v831 = 4194304;
            // pto: %520
            ;
            const int64_t v832 = 65536;
            // pto: %520
            ;
            const int64_t v833 = 256;
            // pto: %520
            ;
            pto::Shape<1, 8, 1, 16, 16> v834 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %520
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v835 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %520
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v836 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v829 + ((v830 + v702 * v831) + v704 * v832 + v828 * v833), v834, v835);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            TLOAD(v825, v836);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %v4_wide_tail_w__ssa_v0
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v837 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
            // pto: %v4_wide_tail_w__ssa_v0
            ;
            uint64_t v838 = (uint64_t) v24;
            TASSIGN(v837, v838);
            // pto: %v4_wide_tail_x__ssa_v0_Left
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v839 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v680, v33);
            // pto: %v4_wide_tail_x__ssa_v0_Left
            ;
            uint64_t v840 = (uint64_t) v23;
            TASSIGN(v839, v840);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            TMOV(v839, v811);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            // pto: %v4_wide_tail_w__ssa_v0_Right
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v841 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
            // pto: %v4_wide_tail_w__ssa_v0_Right
            ;
            uint64_t v842 = (uint64_t) v23;
            TASSIGN(v841, v842);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            TMOV(v841, v837);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v721, v721, v839, v841);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
          // pto: %522, %523
          ;
          int64_t v843 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v624 * (uint64_t) v55) + (uint64_t) v627);
          // pto: %524
          ;
          int64_t v844 = v843 < v45 ? v45 : v843;
          // pto: %525
          ;
          const int64_t v845 = 0;
          // pto: %525
          ;
          __gm__ float* v846 = PTOAS__GLOBAL_TENSOR_DATA(v94);
          // pto: %525
          ;
          const int64_t v847 = 1;
          // pto: %525
          ;
          const int64_t v848 = 1;
          // pto: %525
          ;
          const int64_t v849 = 1;
          // pto: %525
          ;
          int64_t v850 = v680 * v42;
          // pto: %525
          ;
          int64_t v851 = v849 * v850;
          // pto: %525
          ;
          pto::Shape<1, 1, 1, -1, 128> v852 = pto::Shape<1, 1, 1, -1, 128>(v847, v848, v849, v680, v36);
          // pto: %525
          ;
          pto::Stride<-1, -1, -1, -1, -1> v853 = pto::Stride<-1, -1, -1, -1, -1>(v848 * v851, v851, v850, v42, v29);
          // pto: %525
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v854 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v846 + (v845 + v686 * v42 + v844 * v29), v852, v853);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
          TSTORE(v854, v721);
        } else {
          for (int64_t v855 = v45; v855 < v30; v855 += v29) {
            // pto: %526
            ;
            int64_t v856 = (int64_t) ((uint64_t) v629 + (uint64_t) v855);
            // pto: %527
            ;
            if (v856 < v138) {
              // pto: %528
              ;
              int64_t v857 = (int64_t) ((uint64_t) v856 * (uint64_t) v33);
              // pto: %529
              ;
              int64_t v858 = (int64_t) ((uint64_t) v17 - (uint64_t) v857);
              // pto: %530
              ;
              int64_t v859 = v858 < v33 ? v858 : v33;
              // pto: %532, %533, %534, %535, %531
              ;
              int32_t v860 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v856 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
              // pto: %536
              ;
              int64_t v861 = (int64_t) v860;
              // pto: %537
              ;
              int64_t v862 = v861 < v45 ? v45 : v861;
              // pto: %v4_narrow_acc__tile
              ;
              Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v863 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
              // pto: %v4_narrow_acc__tile
              ;
              uint64_t v864 = (uint64_t) v23;
              TASSIGN(v863, v864);
              wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              for (int64_t v865 = v45; v865 < v33; v865 += v29) {
                // pto: %538
                ;
                int64_t v866 = (int64_t) ((uint64_t) v865 * (uint64_t) v33);
                // pto: %539, %540
                ;
                int64_t v867 = (int64_t) ((uint64_t) v862 + (uint64_t) v866) % v32;
                // pto: %541, %542, %543
                ;
                int64_t v868 = v867 < v45 ? (int64_t) ((uint64_t) v867 + (uint64_t) v32) : v867;
                // pto: %544
                ;
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                if (v868 <= v54) {
                  // pto: %545
                  ;
                  int64_t v869 = (int64_t) ((uint64_t) v868 * (uint64_t) v33);
                  // pto: %v4_narrow_packet_x__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v870 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v859, v32);
                  // pto: %v4_narrow_packet_x__tile
                  ;
                  uint64_t v871 = (uint64_t) v24;
                  TASSIGN(v870, v871);
                  // pto: %546
                  ;
                  int64_t v872 = v857 < v45 ? v45 : v857;
                  // pto: %547, %548
                  ;
                  int64_t v873 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v624 * (uint64_t) v41) + (uint64_t) v869);
                  // pto: %549
                  ;
                  int64_t v874 = v873 < v45 ? v45 : v873;
                  // pto: %550
                  ;
                  const int64_t v875 = 0;
                  // pto: %550
                  ;
                  __gm__ bfloat16_t* v876 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                  // pto: %550
                  ;
                  const int64_t v877 = 1;
                  // pto: %550
                  ;
                  const int64_t v878 = 1;
                  // pto: %550
                  ;
                  const int64_t v879 = 1;
                  // pto: %550
                  ;
                  int64_t v880 = v859 * v28;
                  // pto: %550
                  ;
                  int64_t v881 = v879 * v880;
                  // pto: %550
                  ;
                  pto::Shape<1, 1, 1, -1, 256> v882 = pto::Shape<1, 1, 1, -1, 256>(v877, v878, v879, v859, v32);
                  // pto: %550
                  ;
                  pto::Stride<-1, -1, -1, -1, -1> v883 = pto::Stride<-1, -1, -1, -1, -1>(v878 * v881, v881, v880, v28, v29);
                  // pto: %550
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v884 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v876 + (v875 + v872 * v28 + v874 * v29), v882, v883);
                  TLOAD(v870, v884);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  // pto: %v4_narrow_packet_w__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v885 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
                  // pto: %v4_narrow_packet_w__tile
                  ;
                  uint64_t v886 = (uint64_t) v23;
                  TASSIGN(v885, v886);
                  // pto: %551
                  ;
                  int64_t v887 = v624 < v45 ? v45 : v624;
                  // pto: %552
                  ;
                  int64_t v888 = v627 / v33;
                  // pto: %553
                  ;
                  int64_t v889 = v888 < v45 ? v45 : v888;
                  // pto: %554
                  ;
                  int64_t v890 = v869 / v33;
                  // pto: %555
                  ;
                  int64_t v891 = v890 < v45 ? v45 : v890;
                  // pto: %556
                  ;
                  __gm__ bfloat16_t* v892 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                  // pto: %556
                  ;
                  const int64_t v893 = 0;
                  // pto: %556
                  ;
                  const int64_t v894 = 4194304;
                  // pto: %556
                  ;
                  const int64_t v895 = 65536;
                  // pto: %556
                  ;
                  const int64_t v896 = 256;
                  // pto: %556
                  ;
                  pto::Shape<1, 8, 16, 16, 16> v897 = pto::Shape<1, 8, 16, 16, 16>();
                  // pto: %556
                  ;
                  pto::Stride<4194304, 65536, 256, 16, 1> v898 = pto::Stride<4194304, 65536, 256, 16, 1>();
                  // pto: %556
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v899 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v892 + ((v893 + v887 * v894) + v889 * v895 + v891 * v896), v897, v898);
                  TLOAD(v885, v899);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  // pto: %v4_narrow_acc__iter_v1_l0_a
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v900 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v859, v36);
                  // pto: %v4_narrow_acc__iter_v1_l0_a
                  ;
                  uint64_t v901 = (uint64_t) v23;
                  TASSIGN(v900, v901);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  uint16_t v902 = static_cast<uint16_t>(v45);
                  uint16_t v903 = static_cast<uint16_t>(v45);
                  TEXTRACT(v900, v870, v902, v903);
                  // pto: %v4_narrow_acc__iter_v1_l0_b
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v904 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %v4_narrow_acc__iter_v1_l0_b
                  ;
                  uint64_t v905 = (uint64_t) v23;
                  TASSIGN(v904, v905);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  uint16_t v906 = static_cast<uint16_t>(v45);
                  uint16_t v907 = static_cast<uint16_t>(v45);
                  TEXTRACT(v904, v885, v906, v907);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  // pto: %40
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v908 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v859, v36);
                  // pto: %40
                  ;
                  uint64_t v909 = (uint64_t) v25;
                  TASSIGN(v908, v909);
                  uint16_t v910 = static_cast<uint16_t>(v45);
                  uint16_t v911 = static_cast<uint16_t>(v36);
                  TEXTRACT(v908, v870, v910, v911);
                  // pto: %41
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v912 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %41
                  ;
                  uint64_t v913 = (uint64_t) v25;
                  TASSIGN(v912, v913);
                  uint16_t v914 = static_cast<uint16_t>(v36);
                  uint16_t v915 = static_cast<uint16_t>(v45);
                  TEXTRACT(v912, v885, v914, v915);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  // pto: %557
                  ;
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  if (v865 == v45) {
                    pipe_barrier(PIPE_M);
                    TMATMUL(v863, v900, v904);
                  } else {
                    pipe_barrier(PIPE_M);
                    TMATMUL_ACC(v863, v863, v900, v904);
                  };
                  pipe_barrier(PIPE_M);
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  TMATMUL_ACC(v863, v863, v908, v912);
                } else {
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  for (int64_t v916 = v45; v916 < v33; v916 += v29) {
                    // pto: %558, %559
                    ;
                    int64_t v917 = (int64_t) ((uint64_t) v868 + (uint64_t) v916) % v32;
                    // pto: %560, %561, %562
                    ;
                    int64_t v918 = v917 < v45 ? (int64_t) ((uint64_t) v917 + (uint64_t) v32) : v917;
                    // pto: %563
                    ;
                    int64_t v919 = (int64_t) ((uint64_t) v918 * (uint64_t) v33);
                    // pto: %v4_narrow_wrap_x__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v920 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v859, v33);
                    // pto: %v4_narrow_wrap_x__tile
                    ;
                    uint64_t v921 = (uint64_t) v24;
                    TASSIGN(v920, v921);
                    // pto: %564
                    ;
                    int64_t v922 = v857 < v45 ? v45 : v857;
                    // pto: %565, %566
                    ;
                    int64_t v923 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v624 * (uint64_t) v41) + (uint64_t) v919);
                    // pto: %567
                    ;
                    int64_t v924 = v923 < v45 ? v45 : v923;
                    // pto: %568
                    ;
                    const int64_t v925 = 0;
                    // pto: %568
                    ;
                    __gm__ bfloat16_t* v926 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                    // pto: %568
                    ;
                    const int64_t v927 = 1;
                    // pto: %568
                    ;
                    const int64_t v928 = 1;
                    // pto: %568
                    ;
                    const int64_t v929 = 1;
                    // pto: %568
                    ;
                    int64_t v930 = v859 * v28;
                    // pto: %568
                    ;
                    int64_t v931 = v929 * v930;
                    // pto: %568
                    ;
                    pto::Shape<1, 1, 1, -1, 16> v932 = pto::Shape<1, 1, 1, -1, 16>(v927, v928, v929, v859, v33);
                    // pto: %568
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v933 = pto::Stride<-1, -1, -1, -1, -1>(v928 * v931, v931, v930, v28, v29);
                    // pto: %568
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v934 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v926 + (v925 + v922 * v28 + v924 * v29), v932, v933);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    TLOAD(v920, v934);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    // pto: %v4_narrow_wrap_w__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v935 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %v4_narrow_wrap_w__tile
                    ;
                    uint64_t v936 = (uint64_t) v23;
                    TASSIGN(v935, v936);
                    // pto: %569
                    ;
                    int64_t v937 = v624 < v45 ? v45 : v624;
                    // pto: %570
                    ;
                    int64_t v938 = v627 / v33;
                    // pto: %571
                    ;
                    int64_t v939 = v938 < v45 ? v45 : v938;
                    // pto: %572
                    ;
                    int64_t v940 = v919 / v33;
                    // pto: %573
                    ;
                    int64_t v941 = v940 < v45 ? v45 : v940;
                    // pto: %574
                    ;
                    __gm__ bfloat16_t* v942 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                    // pto: %574
                    ;
                    const int64_t v943 = 0;
                    // pto: %574
                    ;
                    const int64_t v944 = 4194304;
                    // pto: %574
                    ;
                    const int64_t v945 = 65536;
                    // pto: %574
                    ;
                    const int64_t v946 = 256;
                    // pto: %574
                    ;
                    pto::Shape<1, 8, 1, 16, 16> v947 = pto::Shape<1, 8, 1, 16, 16>();
                    // pto: %574
                    ;
                    pto::Stride<4194304, 65536, 256, 16, 1> v948 = pto::Stride<4194304, 65536, 256, 16, 1>();
                    // pto: %574
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v949 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v942 + ((v943 + v937 * v944) + v939 * v945 + v941 * v946), v947, v948);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                    TLOAD(v935, v949);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    // pto: %43
                    ;
                    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v950 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v859, v33);
                    // pto: %43
                    ;
                    uint64_t v951 = (uint64_t) v23;
                    TASSIGN(v950, v951);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                    uint16_t v952 = static_cast<uint16_t>(v45);
                    uint16_t v953 = static_cast<uint16_t>(v45);
                    TEXTRACT(v950, v920, v952, v953);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    // pto: %44
                    ;
                    Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v954 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %44
                    ;
                    uint64_t v955 = (uint64_t) v23;
                    TASSIGN(v954, v955);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    uint16_t v956 = static_cast<uint16_t>(v45);
                    uint16_t v957 = static_cast<uint16_t>(v45);
                    TEXTRACT(v954, v935, v956, v957);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    // pto: %576, %577
                    ;
                    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    if ((int64_t) ((uint64_t) v866 + (uint64_t) v916) == v45) {
                      pipe_barrier(PIPE_M);
                      TMATMUL(v863, v950, v954);
                    } else {
                      pipe_barrier(PIPE_M);
                      TMATMUL_ACC(v863, v863, v950, v954);
                    };
                    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  };
                  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
              // pto: %578
              ;
              int64_t v958 = v857 < v45 ? v45 : v857;
              // pto: %579, %580
              ;
              int64_t v959 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v624 * (uint64_t) v55) + (uint64_t) v627);
              // pto: %581
              ;
              int64_t v960 = v959 < v45 ? v45 : v959;
              // pto: %582
              ;
              __gm__ float* v961 = PTOAS__GLOBAL_TENSOR_DATA(v94);
              // pto: %582
              ;
              const int64_t v962 = 0;
              // pto: %582
              ;
              const int64_t v963 = 8192;
              // pto: %582
              ;
              pto::Shape<1, 1, 1, 16, 128> v964 = pto::Shape<1, 1, 1, 16, 128>();
              // pto: %582
              ;
              pto::Stride<131072, 131072, 131072, 8192, 1> v965 = pto::Stride<131072, 131072, 131072, 8192, 1>();
              // pto: %582
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v966 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v961 + (v962 + v958 * v963 + v960), v964, v965);
              wait_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
              pipe_barrier(PIPE_FIX);
              TSTORE(v966, v863);
              set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
            };
          };
        };
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    };
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %584
  int64_t v967 = (int64_t) ((uint64_t) v127 + (uint64_t) v57);
  // pto: %585
  int64_t v968 = v967 < v45 ? v45 : v967;
  // pto: %signals__ssa_v1_signal_pview
  __gm__ int32_t* v969 = PTOAS__GLOBAL_TENSOR_DATA(v113);
  // pto: %signals__ssa_v1_signal_pview
  const int64_t v970 = 0;
  // pto: %signals__ssa_v1_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v971 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v972 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v973 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v969 + (v970 + v968), v971, v972);
  pto::comm::NotifyOp v974 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v973, v136, v974);
  for (int64_t v975 = v48; v975 < v58; v975 += v29) {
    // pto: %586, %587
    ;
    int64_t v976 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v975 * (uint64_t) v36) + (uint64_t) v59);
    // pto: %588
    ;
    int64_t v977 = v976 < v45 ? v45 : v976;
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v978 = PTOAS__GLOBAL_TENSOR_DATA(v113);
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    const int64_t v979 = 0;
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v980 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v981 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v982 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v978 + (v979 + v977), v980, v981);
    pto::comm::WaitCmp v983 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v982, v136, v983);
  }
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %589
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
  if (v17 <= v33) {
    // pto: %590
    ;
    for (int64_t v984 = v126; v984 < ((int64_t) ((uint64_t) v138 * (uint64_t) v38)); v984 += v48) {
      // pto: %591, %592
      ;
      int64_t v985 = (int64_t) ((uint64_t) (v984 / v38) * (uint64_t) v33);
      // pto: %593
      ;
      int64_t v986 = v984 % v38;
      // pto: %594, %595, %596
      ;
      int64_t v987 = v986 < v45 ? (int64_t) ((uint64_t) v986 + (uint64_t) v38) : v986;
      // pto: %597
      ;
      int64_t v988 = (int64_t) ((uint64_t) v987 * (uint64_t) v36);
      // pto: %598
      ;
      int64_t v989 = (int64_t) ((uint64_t) v17 - (uint64_t) v985);
      // pto: %599
      ;
      int64_t v990 = v989 < v33 ? v989 : v33;
      // pto: %b_acc__tile
      ;
      Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v991 = Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
      // pto: %b_acc__tile
      ;
      uint64_t v992 = (uint64_t) v23;
      TASSIGN(v991, v992);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      for (int64_t v993 = v45; v993 < v33; v993 += v29) {
        // pto: %600
        ;
        int64_t v994 = (int64_t) ((uint64_t) v993 * (uint64_t) v37);
        // pto: %b_input__tile
        ;
        Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v995 = Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v990, v37);
        // pto: %b_input__tile
        ;
        uint64_t v996 = (uint64_t) v24;
        TASSIGN(v995, v996);
        // pto: %601
        ;
        int64_t v997 = v985 < v45 ? v45 : v985;
        // pto: %602
        ;
        int64_t v998 = v994 < v45 ? v45 : v994;
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v999 = 0;
        // pto: %quantized__ssa_v0_pview
        ;
        __gm__ int8_t* v1000 = PTOAS__GLOBAL_TENSOR_DATA(v85);
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v1001 = 1;
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v1002 = 1;
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v1003 = 1;
        // pto: %quantized__ssa_v0_pview
        ;
        int64_t v1004 = v990 * v42;
        // pto: %quantized__ssa_v0_pview
        ;
        int64_t v1005 = v1003 * v1004;
        // pto: %quantized__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 512> v1006 = pto::Shape<1, 1, 1, -1, 512>(v1001, v1002, v1003, v990, v37);
        // pto: %quantized__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1007 = pto::Stride<-1, -1, -1, -1, -1>(v1002 * v1005, v1005, v1004, v42, v29);
        // pto: %quantized__ssa_v0_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1008 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1000 + (v999 + v997 * v42 + v998 * v29), v1006, v1007);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        TLOAD(v995, v1008);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %b_weight__tile
        ;
        Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1009 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v37, v36);
        // pto: %b_weight__tile
        ;
        uint64_t v1010 = (uint64_t) v23;
        TASSIGN(v1009, v1010);
        // pto: %603
        ;
        int64_t v1011 = v988 / v38;
        // pto: %604
        ;
        int64_t v1012 = v1011 < v45 ? v45 : v1011;
        // pto: %605
        ;
        int64_t v1013 = v994 / v33;
        // pto: %606
        ;
        int64_t v1014 = v1013 < v45 ? v45 : v1013;
        // pto: %wo_b__ssa_v0_pview
        ;
        __gm__ int8_t* v1015 = PTOAS__GLOBAL_TENSOR_DATA(v76);
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v1016 = 0;
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v1017 = 262144;
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v1018 = 512;
        // pto: %wo_b__ssa_v0_pview
        ;
        pto::Shape<1, 4, 32, 16, 32> v1019 = pto::Shape<1, 4, 32, 16, 32>();
        // pto: %wo_b__ssa_v0_pview
        ;
        pto::Stride<33554432, 262144, 512, 32, 1> v1020 = pto::Stride<33554432, 262144, 512, 32, 1>();
        // pto: %wo_b__ssa_v0_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v1021 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v1015 + (v1016 + v1012 * v1017 + v1014 * v1018), v1019, v1020);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v1009, v1021);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %b_acc__tile_l0_a
        ;
        Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1022 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v990, v32);
        // pto: %b_acc__tile_l0_a
        ;
        uint64_t v1023 = (uint64_t) v23;
        TASSIGN(v1022, v1023);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        uint16_t v1024 = static_cast<uint16_t>(v45);
        uint16_t v1025 = static_cast<uint16_t>(v45);
        TEXTRACT(v1022, v995, v1024, v1025);
        // pto: %b_acc__tile_l0_b
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1026 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
        // pto: %b_acc__tile_l0_b
        ;
        uint64_t v1027 = (uint64_t) v23;
        TASSIGN(v1026, v1027);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v1028 = static_cast<uint16_t>(v45);
        uint16_t v1029 = static_cast<uint16_t>(v45);
        TEXTRACT(v1026, v1009, v1028, v1029);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %45
        ;
        Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1030 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v990, v32);
        // pto: %45
        ;
        uint64_t v1031 = (uint64_t) v25;
        TASSIGN(v1030, v1031);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v1032 = static_cast<uint16_t>(v45);
        uint16_t v1033 = static_cast<uint16_t>(v32);
        TEXTRACT(v1030, v995, v1032, v1033);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        // pto: %46
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1034 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
        // pto: %46
        ;
        uint64_t v1035 = (uint64_t) v25;
        TASSIGN(v1034, v1035);
        uint16_t v1036 = static_cast<uint16_t>(v32);
        uint16_t v1037 = static_cast<uint16_t>(v45);
        TEXTRACT(v1034, v1009, v1036, v1037);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %607
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        if (v993 == v45) {
          pipe_barrier(PIPE_M);
          TMATMUL(v991, v1022, v1026);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v991, v991, v1022, v1026);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v991, v991, v1030, v1034);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
      // pto: %608
      ;
      int64_t v1038 = v985 < v45 ? v45 : v985;
      // pto: %609
      ;
      int64_t v1039 = v988 < v45 ? v45 : v988;
      // pto: %integer_accum__ssa_v0_pview
      ;
      __gm__ int32_t* v1040 = PTOAS__GLOBAL_TENSOR_DATA(v103);
      // pto: %integer_accum__ssa_v0_pview
      ;
      const int64_t v1041 = 0;
      // pto: %integer_accum__ssa_v0_pview
      ;
      const int64_t v1042 = 4096;
      // pto: %integer_accum__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 128> v1043 = pto::Shape<1, 1, 1, 16, 128>();
      // pto: %integer_accum__ssa_v0_pview
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v1044 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %integer_accum__ssa_v0_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v1045 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v1040 + (v1041 + v1038 * v1042 + v1039), v1043, v1044);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
      pipe_barrier(PIPE_FIX);
      TSTORE(v1045, v991);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
    };
  } else {
    // pto: %610, %611, %612
    ;
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    for (int64_t v1046 = v126; v1046 < ((int64_t) ((uint64_t) ((int64_t) ((uint64_t) v17 + (uint64_t) v60) / v31) * (uint64_t) v38)); v1046 += v48) {
      // pto: %613, %614
      ;
      int64_t v1047 = (int64_t) ((uint64_t) (v1046 / v38) * (uint64_t) v31);
      // pto: %615
      ;
      int64_t v1048 = v1046 % v38;
      // pto: %616, %617, %618
      ;
      int64_t v1049 = v1048 < v45 ? (int64_t) ((uint64_t) v1048 + (uint64_t) v38) : v1048;
      // pto: %619
      ;
      int64_t v1050 = (int64_t) ((uint64_t) v1049 * (uint64_t) v36);
      // pto: %620
      ;
      int64_t v1051 = (int64_t) ((uint64_t) v17 - (uint64_t) v1047);
      // pto: %621
      ;
      int64_t v1052 = v1051 < v31 ? v1051 : v31;
      // pto: %wide_first_input__tile
      ;
      Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1053 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v1052, v37);
      // pto: %wide_first_input__tile
      ;
      uint64_t v1054 = (uint64_t) v24;
      TASSIGN(v1053, v1054);
      // pto: %622
      ;
      int64_t v1055 = v1047 < v45 ? v45 : v1047;
      // pto: %623
      ;
      const int64_t v1056 = 0;
      // pto: %623
      ;
      __gm__ int8_t* v1057 = PTOAS__GLOBAL_TENSOR_DATA(v85);
      // pto: %623
      ;
      const int64_t v1058 = 1;
      // pto: %623
      ;
      const int64_t v1059 = 1;
      // pto: %623
      ;
      const int64_t v1060 = 1;
      // pto: %623
      ;
      int64_t v1061 = v1052 * v42;
      // pto: %623
      ;
      int64_t v1062 = v1060 * v1061;
      // pto: %623
      ;
      pto::Shape<1, 1, 1, -1, 512> v1063 = pto::Shape<1, 1, 1, -1, 512>(v1058, v1059, v1060, v1052, v37);
      // pto: %623
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1064 = pto::Stride<-1, -1, -1, -1, -1>(v1059 * v1062, v1062, v1061, v42, v29);
      // pto: %623
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1065 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1057 + (v1056 + v1055 * v42 + v45 * v29), v1063, v1064);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v1053, v1065);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %wide_first_weight__tile
      ;
      Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1066 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v37, v36);
      // pto: %wide_first_weight__tile
      ;
      uint64_t v1067 = (uint64_t) v23;
      TASSIGN(v1066, v1067);
      // pto: %624
      ;
      int64_t v1068 = v1050 / v38;
      // pto: %625
      ;
      int64_t v1069 = v1068 < v45 ? v45 : v1068;
      // pto: %626
      ;
      __gm__ int8_t* v1070 = PTOAS__GLOBAL_TENSOR_DATA(v76);
      // pto: %626
      ;
      const int64_t v1071 = 0;
      // pto: %626
      ;
      const int64_t v1072 = 262144;
      // pto: %626
      ;
      pto::Shape<1, 4, 32, 16, 32> v1073 = pto::Shape<1, 4, 32, 16, 32>();
      // pto: %626
      ;
      pto::Stride<33554432, 262144, 512, 32, 1> v1074 = pto::Stride<33554432, 262144, 512, 32, 1>();
      // pto: %626
      ;
      GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v1075 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v1070 + (v1071 + v1069 * v1072), v1073, v1074);
      TLOAD(v1066, v1075);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %wide_b_acc__tile_l0_init_storage
      ;
      Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v1076 = Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v31, v36);
      // pto: %wide_b_acc__tile_l0_init_storage
      ;
      uint64_t v1077 = (uint64_t) v23;
      TASSIGN(v1076, v1077);
      v1076.SetValidShape(v1052, v36);
      // pto: %wide_b_acc__tile_l0_a
      ;
      Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1078 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v1052, v32);
      // pto: %wide_b_acc__tile_l0_a
      ;
      uint64_t v1079 = (uint64_t) v23;
      TASSIGN(v1078, v1079);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      uint16_t v1080 = static_cast<uint16_t>(v45);
      uint16_t v1081 = static_cast<uint16_t>(v45);
      TEXTRACT(v1078, v1053, v1080, v1081);
      // pto: %wide_b_acc__tile_l0_b
      ;
      Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1082 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
      // pto: %wide_b_acc__tile_l0_b
      ;
      uint64_t v1083 = (uint64_t) v23;
      TASSIGN(v1082, v1083);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      uint16_t v1084 = static_cast<uint16_t>(v45);
      uint16_t v1085 = static_cast<uint16_t>(v45);
      TEXTRACT(v1082, v1066, v1084, v1085);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %48
      ;
      Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1086 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v1052, v32);
      // pto: %48
      ;
      uint64_t v1087 = (uint64_t) v25;
      TASSIGN(v1086, v1087);
      uint16_t v1088 = static_cast<uint16_t>(v45);
      uint16_t v1089 = static_cast<uint16_t>(v32);
      TEXTRACT(v1086, v1053, v1088, v1089);
      // pto: %49
      ;
      Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1090 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
      // pto: %49
      ;
      uint64_t v1091 = (uint64_t) v25;
      TASSIGN(v1090, v1091);
      uint16_t v1092 = static_cast<uint16_t>(v32);
      uint16_t v1093 = static_cast<uint16_t>(v45);
      TEXTRACT(v1090, v1066, v1092, v1093);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
      TMATMUL(v1076, v1078, v1082);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v1076, v1076, v1086, v1090);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      for (int64_t v1094 = v29; v1094 < v33; v1094 += v29) {
        // pto: %627
        ;
        int64_t v1095 = (int64_t) ((uint64_t) v1094 * (uint64_t) v37);
        // pto: %wide_b_input__tile
        ;
        Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1096 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v1052, v37);
        // pto: %wide_b_input__tile
        ;
        uint64_t v1097 = (uint64_t) v24;
        TASSIGN(v1096, v1097);
        // pto: %629
        ;
        int64_t v1098 = v1095 < v45 ? v45 : v1095;
        // pto: %630
        ;
        const int64_t v1099 = 0;
        // pto: %630
        ;
        __gm__ int8_t* v1100 = PTOAS__GLOBAL_TENSOR_DATA(v85);
        // pto: %630
        ;
        const int64_t v1101 = 1;
        // pto: %630
        ;
        const int64_t v1102 = 1;
        // pto: %630
        ;
        const int64_t v1103 = 1;
        // pto: %630
        ;
        int64_t v1104 = v1052 * v42;
        // pto: %630
        ;
        int64_t v1105 = v1103 * v1104;
        // pto: %630
        ;
        pto::Shape<1, 1, 1, -1, 512> v1106 = pto::Shape<1, 1, 1, -1, 512>(v1101, v1102, v1103, v1052, v37);
        // pto: %630
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1107 = pto::Stride<-1, -1, -1, -1, -1>(v1102 * v1105, v1105, v1104, v42, v29);
        // pto: %630
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1108 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1100 + (v1099 + v1055 * v42 + v1098 * v29), v1106, v1107);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v1096, v1108);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %wide_b_weight__tile
        ;
        Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1109 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v37, v36);
        // pto: %wide_b_weight__tile
        ;
        uint64_t v1110 = (uint64_t) v23;
        TASSIGN(v1109, v1110);
        // pto: %633
        ;
        int64_t v1111 = v1095 / v33;
        // pto: %634
        ;
        int64_t v1112 = v1111 < v45 ? v45 : v1111;
        // pto: %635
        ;
        __gm__ int8_t* v1113 = PTOAS__GLOBAL_TENSOR_DATA(v76);
        // pto: %635
        ;
        const int64_t v1114 = 0;
        // pto: %635
        ;
        const int64_t v1115 = 262144;
        // pto: %635
        ;
        const int64_t v1116 = 512;
        // pto: %635
        ;
        pto::Shape<1, 4, 32, 16, 32> v1117 = pto::Shape<1, 4, 32, 16, 32>();
        // pto: %635
        ;
        pto::Stride<33554432, 262144, 512, 32, 1> v1118 = pto::Stride<33554432, 262144, 512, 32, 1>();
        // pto: %635
        ;
        GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v1119 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v1113 + (v1114 + v1069 * v1115 + v1112 * v1116), v1117, v1118);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        TLOAD(v1109, v1119);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %51
        ;
        Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1120 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v1052, v32);
        // pto: %51
        ;
        uint64_t v1121 = (uint64_t) v23;
        TASSIGN(v1120, v1121);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v1122 = static_cast<uint16_t>(v45);
        uint16_t v1123 = static_cast<uint16_t>(v45);
        TEXTRACT(v1120, v1096, v1122, v1123);
        // pto: %52
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1124 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
        // pto: %52
        ;
        uint64_t v1125 = (uint64_t) v23;
        TASSIGN(v1124, v1125);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v1126 = static_cast<uint16_t>(v45);
        uint16_t v1127 = static_cast<uint16_t>(v45);
        TEXTRACT(v1124, v1109, v1126, v1127);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %53
        ;
        Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1128 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v1052, v32);
        // pto: %53
        ;
        uint64_t v1129 = (uint64_t) v25;
        TASSIGN(v1128, v1129);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1130 = static_cast<uint16_t>(v45);
        uint16_t v1131 = static_cast<uint16_t>(v32);
        TEXTRACT(v1128, v1096, v1130, v1131);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        // pto: %54
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1132 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
        // pto: %54
        ;
        uint64_t v1133 = (uint64_t) v25;
        TASSIGN(v1132, v1133);
        uint16_t v1134 = static_cast<uint16_t>(v32);
        uint16_t v1135 = static_cast<uint16_t>(v45);
        TEXTRACT(v1132, v1109, v1134, v1135);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v1076, v1076, v1120, v1124);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v1076, v1076, v1128, v1132);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
      // pto: %637
      ;
      int64_t v1136 = v1050 < v45 ? v45 : v1050;
      // pto: %638
      ;
      const int64_t v1137 = 0;
      // pto: %638
      ;
      __gm__ int32_t* v1138 = PTOAS__GLOBAL_TENSOR_DATA(v103);
      // pto: %638
      ;
      const int64_t v1139 = 1;
      // pto: %638
      ;
      const int64_t v1140 = 1;
      // pto: %638
      ;
      const int64_t v1141 = 1;
      // pto: %638
      ;
      int64_t v1142 = v1052 * v41;
      // pto: %638
      ;
      int64_t v1143 = v1141 * v1142;
      // pto: %638
      ;
      pto::Shape<1, 1, 1, -1, 128> v1144 = pto::Shape<1, 1, 1, -1, 128>(v1139, v1140, v1141, v1052, v36);
      // pto: %638
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1145 = pto::Stride<-1, -1, -1, -1, -1>(v1140 * v1143, v1143, v1142, v41, v29);
      // pto: %638
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1146 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1138 + (v1137 + v1055 * v41 + v1136 * v29), v1144, v1145);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
      TSTORE(v1146, v1076);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
    };
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %640
  int64_t v1147 = (int64_t) ((uint64_t) v127 + (uint64_t) v61);
  // pto: %641
  int64_t v1148 = v1147 < v45 ? v45 : v1147;
  // pto: %signals_v2__ssa_v0_signal_pview
  __gm__ int32_t* v1149 = PTOAS__GLOBAL_TENSOR_DATA(v113);
  // pto: %signals_v2__ssa_v0_signal_pview
  const int64_t v1150 = 0;
  // pto: %signals_v2__ssa_v0_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v1151 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals_v2__ssa_v0_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v1152 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals_v2__ssa_v0_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v1153 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v1149 + (v1150 + v1148), v1151, v1152);
  pto::comm::NotifyOp v1154 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v1153, v136, v1154);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void vector(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ bfloat16_t* v6, __gm__ int8_t* v7, __gm__ float* v8, __gm__ bfloat16_t* v9, __gm__ bfloat16_t* v10, __gm__ float* v11, __gm__ float* v12, __gm__ bfloat16_t* v13, __gm__ float* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21, int32_t v22) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int32_t v23 = 1;
  // pto: %c0_i64
  const int64_t v24 = 0;
  // pto: %c32768_i64
  const int64_t v25 = 32768;
  // pto: %c65536_i64
  const int64_t v26 = 65536;
  // pto: %c65568_i64
  const int64_t v27 = 65568;
  // pto: %c32_i64
  const int64_t v28 = 32;
  // pto: %c64_i64
  const int64_t v29 = 64;
  // pto: %c49152_i64
  const int64_t v30 = 49152;
  // pto: %c67584_i64
  const int64_t v31 = 67584;
  // pto: %c16384_i64
  const int64_t v32 = 16384;
  // pto: %c81920_i64
  const int64_t v33 = 81920;
  // pto: %c98304_i64
  const int64_t v34 = 98304;
  // pto: %c114688_i64
  const int64_t v35 = 114688;
  // pto: %c122880_i64
  const int64_t v36 = 122880;
  // pto: %c1_index
  const int64_t v37 = 1;
  // pto: %c8_index
  const int64_t v38 = 8;
  // pto: %c16_index
  const int64_t v39 = 16;
  // pto: %c128_index
  const int64_t v40 = 128;
  // pto: %c512_index
  const int64_t v41 = 512;
  // pto: %c4096_index
  const int64_t v42 = 4096;
  // pto: %c8192_index
  const int64_t v43 = 8192;
  // pto: %c16384_index
  const int64_t v44 = 16384;
  // pto: %c4_index
  const int64_t v45 = 4;
  // pto: %c55296_index
  const int64_t v46 = 55296;
  // pto: %c2_index
  const int64_t v47 = 2;
  // pto: %c24_index
  const int64_t v48 = 24;
  // pto: %c0_index
  const int64_t v49 = 0;
  // pto: %c15_index
  const int64_t v50 = 15;
  // pto: %c9216_index
  const int64_t v51 = 9216;
  // pto: %c48_index
  const int64_t v52 = 48;
  // pto: %c1024_index
  const int64_t v53 = 1024;
  // pto: %c18432_index
  const int64_t v54 = 18432;
  // pto: %c72_index
  const int64_t v55 = 72;
  // pto: %c7_index
  const int64_t v56 = 7;
  // pto: %cst_41
  const float v57 = 0.00787401571f;
  // pto: %cst_42
  const float v58 = 0.0f;
  // pto: %cst_43
  const float v59 = 1.0f;
  // pto: %cst_44
  const float v60 = 127.0f;
  // pto: %c27648_index
  const int64_t v61 = 27648;
  // pto: %c36864_index
  const int64_t v62 = 36864;
  // pto: %c46080_index
  const int64_t v63 = 46080;
  // pto: %c3_index
  const int64_t v64 = 3;
  // pto: %c12_index
  const int64_t v65 = 12;
  // pto: %c5_index
  const int64_t v66 = 5;
  // pto: %c9_index
  const int64_t v67 = 9;
  // pto: %c13_index
  const int64_t v68 = 13;
  // pto: %c6_index
  const int64_t v69 = 6;
  // pto: %c10_index
  const int64_t v70 = 10;
  // pto: %c14_index
  const int64_t v71 = 14;
  // pto: %c11_index
  const int64_t v72 = 11;
  // pto: %c12288_index
  const int64_t v73 = 12288;
  // pto: %cn1_index
  const int64_t v74 = -1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v78 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v79 = v42 * v37;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v80 = v78 * v79;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v81 = v77 * v80;
  // pto: %wo_b_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v82 = pto::Shape<1, 1, 1, 1, -1>(v75, v76, v77, v78, v42);
  // pto: %wo_b_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v83 = pto::Stride<-1, -1, -1, -1, -1>(v76 * v81, v81, v80, v79, v37);
  // pto: %wo_b_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v84 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v82, v83);
  // pto: %projected__ssa_v0_view
  const int64_t v85 = 1;
  // pto: %projected__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %projected__ssa_v0_view
  const int64_t v87 = 1;
  // pto: %projected__ssa_v0_view
  int64_t v88 = (int64_t) v17;
  // pto: %projected__ssa_v0_view
  int64_t v89 = v88 * v43;
  // pto: %projected__ssa_v0_view
  int64_t v90 = v87 * v89;
  // pto: %projected__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v91 = pto::Shape<1, 1, 1, -1, -1>(v85, v86, v87, v88, v43);
  // pto: %projected__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v92 = pto::Stride<-1, -1, -1, -1, -1>(v86 * v90, v90, v89, v43, v37);
  // pto: %projected__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v93 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v91, v92);
  // pto: %quantized__ssa_v0_view
  const int64_t v94 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v96 = 1;
  // pto: %quantized__ssa_v0_view
  int64_t v97 = (int64_t) v17;
  // pto: %quantized__ssa_v0_view
  int64_t v98 = v97 * v43;
  // pto: %quantized__ssa_v0_view
  int64_t v99 = v96 * v98;
  // pto: %quantized__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v100 = pto::Shape<1, 1, 1, -1, -1>(v94, v95, v96, v97, v43);
  // pto: %quantized__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v101 = pto::Stride<-1, -1, -1, -1, -1>(v95 * v99, v99, v98, v43, v37);
  // pto: %quantized__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v102 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v100, v101);
  // pto: %token_scale__ssa_v0_view
  const int64_t v103 = 1;
  // pto: %token_scale__ssa_v0_view
  const int64_t v104 = 1;
  // pto: %token_scale__ssa_v0_view
  const int64_t v105 = 1;
  // pto: %token_scale__ssa_v0_view
  int64_t v106 = (int64_t) v17;
  // pto: %token_scale__ssa_v0_view
  int64_t v107 = v106 * v37;
  // pto: %token_scale__ssa_v0_view
  int64_t v108 = v105 * v107;
  // pto: %token_scale__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v109 = pto::Shape<1, 1, 1, -1, -1>(v103, v104, v105, v106, v37);
  // pto: %token_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v110 = pto::Stride<-1, -1, -1, -1, -1>(v104 * v108, v108, v107, v37, (int64_t) v17);
  // pto: %token_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v111 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v8, v109, v110);
  // pto: %attended__ssa_v0_view
  const int64_t v112 = 1;
  // pto: %attended__ssa_v0_view
  const int64_t v113 = 1;
  // pto: %attended__ssa_v0_view
  const int64_t v114 = 1;
  // pto: %attended__ssa_v0_view
  int64_t v115 = (int64_t) v17;
  // pto: %attended__ssa_v0_view
  int64_t v116 = v115 * v42;
  // pto: %attended__ssa_v0_view
  int64_t v117 = v114 * v116;
  // pto: %attended__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v118 = pto::Shape<1, 1, 1, -1, -1>(v112, v113, v114, v115, v42);
  // pto: %attended__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v119 = pto::Stride<-1, -1, -1, -1, -1>(v113 * v117, v117, v116, v42, v37);
  // pto: %attended__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v120 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v118, v119);
  // pto: %residual__ssa_v0_view
  const int64_t v121 = 1;
  // pto: %residual__ssa_v0_view
  const int64_t v122 = 1;
  // pto: %residual__ssa_v0_view
  const int64_t v123 = 1;
  // pto: %residual__ssa_v0_view
  int64_t v124 = (int64_t) v17;
  // pto: %residual__ssa_v0_view
  int64_t v125 = v124 * v44;
  // pto: %residual__ssa_v0_view
  int64_t v126 = v123 * v125;
  // pto: %residual__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v127 = pto::Shape<1, 1, 1, -1, -1>(v121, v122, v123, v124, v44);
  // pto: %residual__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v128 = pto::Stride<-1, -1, -1, -1, -1>(v122 * v126, v126, v125, v44, v37);
  // pto: %residual__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v129 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v10, v127, v128);
  // pto: %output__ssa_v0_view
  const int64_t v130 = 1;
  // pto: %output__ssa_v0_view
  const int64_t v131 = 1;
  // pto: %output__ssa_v0_view
  const int64_t v132 = 1;
  // pto: %output__ssa_v0_view
  int64_t v133 = (int64_t) v17;
  // pto: %output__ssa_v0_view
  int64_t v134 = v133 * v44;
  // pto: %output__ssa_v0_view
  int64_t v135 = v132 * v134;
  // pto: %output__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v136 = pto::Shape<1, 1, 1, -1, -1>(v130, v131, v132, v133, v44);
  // pto: %output__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v137 = pto::Stride<-1, -1, -1, -1, -1>(v131 * v135, v135, v134, v44, v37);
  // pto: %output__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v138 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v136, v137);
  // pto: %accum__ssa_v0_view
  const int64_t v139 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v140 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v141 = 1;
  // pto: %accum__ssa_v0_view
  int64_t v142 = (int64_t) v18;
  // pto: %accum__ssa_v0_view
  int64_t v143 = v142 * v43;
  // pto: %accum__ssa_v0_view
  int64_t v144 = v141 * v143;
  // pto: %accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v145 = pto::Shape<1, 1, 1, -1, -1>(v139, v140, v141, v142, v43);
  // pto: %accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v146 = pto::Stride<-1, -1, -1, -1, -1>(v140 * v144, v144, v143, v43, v37);
  // pto: %accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v147 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v145, v146);
  // pto: %integer_accum__ssa_v0_view
  const int64_t v148 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v149 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v150 = 1;
  // pto: %integer_accum__ssa_v0_view
  int64_t v151 = (int64_t) v19;
  // pto: %integer_accum__ssa_v0_view
  int64_t v152 = v151 * v42;
  // pto: %integer_accum__ssa_v0_view
  int64_t v153 = v150 * v152;
  // pto: %integer_accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v154 = pto::Shape<1, 1, 1, -1, -1>(v148, v149, v150, v151, v42);
  // pto: %integer_accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v155 = pto::Stride<-1, -1, -1, -1, -1>(v149 * v153, v153, v152, v42, v37);
  // pto: %integer_accum__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v156 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v154, v155);
  // pto: %signals__ssa_v0_view
  const int64_t v157 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v158 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v159 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v160 = 1;
  // pto: %signals__ssa_v0_view
  int64_t v161 = v46 * v37;
  // pto: %signals__ssa_v0_view
  int64_t v162 = v160 * v161;
  // pto: %signals__ssa_v0_view
  int64_t v163 = v159 * v162;
  // pto: %signals__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v164 = pto::Shape<1, 1, 1, 1, -1>(v157, v158, v159, v160, v46);
  // pto: %signals__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v165 = pto::Stride<-1, -1, -1, -1, -1>(v158 * v163, v163, v162, v161, v37);
  // pto: %signals__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v166 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v164, v165);
  // pto: %t__tmp_v0, %145, %146, %t__tmp_v1
  int64_t v167 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v20) * (uint64_t) v47) + (uint64_t) ((int64_t) v22));
  // pto: %147, %148
  int64_t v168 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v167 + (uint64_t) v48) * (uint64_t) v40);
  // pto: %149
  int64_t v169 = v168 < v49 ? v49 : v168;
  // pto: %signals__ssa_v0_pview
  __gm__ int32_t* v170 = PTOAS__GLOBAL_TENSOR_DATA(v166);
  // pto: %signals__ssa_v0_pview
  const int64_t v171 = 0;
  // pto: %signals__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 1> v172 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  pto::Stride<1, 1, 1, 1, 1> v173 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v174 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v170 + (v171 + v169), v172, v173);
  __gm__ int32_t* v175 = PTOAS__GLOBAL_TENSOR_DATA(v174);
  PTOAS__DCCI_SINGLE_CACHE_LINE(v175);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  // pto: %150
  int32_t v176 = (v16)[v168];
  // pto: %152
  int32_t v177 = (int32_t) ((uint32_t) v176 + (uint32_t) v23);
  pipe_barrier(PIPE_ALL);
  pto::comm::NotifyOp v178 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v174, v177, v178);
  // pto: %154, %155, %156
  int64_t v179 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v17 + (uint64_t) v50) / v39) * (uint64_t) v38);
  // pto: %157
  if (v167 < v179) {
    for (int64_t v180 = v49; v180 < v38; v180 += v37) {
      // pto: %158
      ;
      int64_t v181 = v167 % v38;
      // pto: %159, %160, %161
      ;
      int64_t v182 = v181 < v49 ? (int64_t) ((uint64_t) v181 + (uint64_t) v38) : v181;
      // pto: %162, %163, %164
      ;
      int64_t v183 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v182 * (uint64_t) v38) + (uint64_t) v180) % v48;
      // pto: %165, %166, %167
      ;
      int64_t v184 = v183 < v49 ? (int64_t) ((uint64_t) v183 + (uint64_t) v48) : v183;
      // pto: %168, %169
      ;
      int64_t v185 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v184 * (uint64_t) v40) + (uint64_t) v51);
      // pto: %170
      ;
      int64_t v186 = v185 < v49 ? v49 : v185;
      // pto: %signals__ssa_v1_signal_pview
      ;
      __gm__ int32_t* v187 = PTOAS__GLOBAL_TENSOR_DATA(v166);
      // pto: %signals__ssa_v1_signal_pview
      ;
      const int64_t v188 = 0;
      // pto: %signals__ssa_v1_signal_pview
      ;
      pto::Shape<1, 1, 1, 1, 1> v189 = pto::Shape<1, 1, 1, 1, 1>();
      // pto: %signals__ssa_v1_signal_pview
      ;
      pto::Stride<1, 1, 1, 1, 1> v190 = pto::Stride<1, 1, 1, 1, 1>();
      // pto: %signals__ssa_v1_signal_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v191 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v187 + (v188 + v186), v189, v190);
      pto::comm::WaitCmp v192 = pto::comm::WaitCmp::GE;
      pto::comm::TWAIT(v191, v177, v192);
    };
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
  }
  for (int64_t v193 = v167; v193 < v179; v193 += v52) {
    // pto: %172, %173
    ;
    int64_t v194 = (int64_t) ((uint64_t) (v193 / v38) * (uint64_t) v39);
    // pto: %174
    ;
    int64_t v195 = v193 % v38;
    // pto: %175, %176, %177
    ;
    int64_t v196 = v195 < v49 ? (int64_t) ((uint64_t) v195 + (uint64_t) v38) : v195;
    // pto: %178
    ;
    int64_t v197 = (int64_t) ((uint64_t) v196 * (uint64_t) v53);
    // pto: %179
    ;
    int64_t v198 = (int64_t) ((uint64_t) v17 - (uint64_t) v194);
    // pto: %180
    ;
    int64_t v199 = v198 < v39 ? v198 : v39;
    // pto: %oa_value__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v200 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v199, v53);
    // pto: %oa_value__ssa_v0
    ;
    uint64_t v201 = (uint64_t) v24;
    TASSIGN(v200, v201);
    // pto: %181
    ;
    int64_t v202 = v194 < v49 ? v49 : v194;
    // pto: %182
    ;
    int64_t v203 = v197 < v49 ? v49 : v197;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v204 = 0;
    // pto: %accum__ssa_v0_pview
    ;
    __gm__ float* v205 = PTOAS__GLOBAL_TENSOR_DATA(v147);
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v206 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v207 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v208 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    int64_t v209 = v199 * v43;
    // pto: %accum__ssa_v0_pview
    ;
    int64_t v210 = v208 * v209;
    // pto: %accum__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1024> v211 = pto::Shape<1, 1, 1, -1, 1024>(v206, v207, v208, v199, v53);
    // pto: %accum__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v212 = pto::Stride<-1, -1, -1, -1, -1>(v207 * v210, v210, v209, v43, v37);
    // pto: %accum__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v213 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v205 + (v204 + v202 * v43 + v203 * v37), v211, v212);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v200, v213);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %t__tmp_v3
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v214 = Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v199, v53);
    // pto: %t__tmp_v3
    ;
    uint64_t v215 = (uint64_t) v24;
    TASSIGN(v214, v215);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v216 = RoundMode::CAST_RINT;
    SaturationMode v217 = SaturationMode::ON;
    TCVT(v214, v200, v216, v217);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v218 = 0;
    // pto: %projected__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v219 = PTOAS__GLOBAL_TENSOR_DATA(v93);
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v220 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v221 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v222 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    int64_t v223 = v199 * v43;
    // pto: %projected__ssa_v0_pview
    ;
    int64_t v224 = v222 * v223;
    // pto: %projected__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1024> v225 = pto::Shape<1, 1, 1, -1, 1024>(v220, v221, v222, v199, v53);
    // pto: %projected__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v226 = pto::Stride<-1, -1, -1, -1, -1>(v221 * v224, v224, v223, v43, v37);
    // pto: %projected__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v227 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v219 + (v218 + v202 * v43 + v203 * v37), v225, v226);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v227, v214);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %186
  int64_t v228 = (int64_t) ((uint64_t) v168 + (uint64_t) v54);
  // pto: %187
  int64_t v229 = v228 < v49 ? v49 : v228;
  // pto: %188
  __gm__ int32_t* v230 = PTOAS__GLOBAL_TENSOR_DATA(v166);
  // pto: %188
  const int64_t v231 = 0;
  // pto: %188
  pto::Shape<1, 1, 1, 1, 1> v232 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %188
  pto::Stride<1, 1, 1, 1, 1> v233 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %188
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v234 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v230 + (v231 + v229), v232, v233);
  pto::comm::NotifyOp v235 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v234, v177, v235);
  for (int64_t v236 = v48; v236 < v55; v236 += v37) {
    // pto: %189, %190
    ;
    int64_t v237 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v236 * (uint64_t) v40) + (uint64_t) v54);
    // pto: %191
    ;
    int64_t v238 = v237 < v49 ? v49 : v237;
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v239 = PTOAS__GLOBAL_TENSOR_DATA(v166);
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    const int64_t v240 = 0;
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v241 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v242 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v243 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v239 + (v240 + v238), v241, v242);
    pto::comm::WaitCmp v244 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v243, v177, v244);
  }
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %192, %193
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  for (int64_t v245 = v167; v245 < ((int64_t) ((uint64_t) v17 + (uint64_t) v56) / v38); v245 += v52) {
    // pto: %195
    ;
    int64_t v246 = (int64_t) ((uint64_t) v245 * (uint64_t) v38);
    // pto: %196
    ;
    int64_t v247 = (int64_t) ((uint64_t) v17 - (uint64_t) v246);
    // pto: %197
    ;
    int64_t v248 = v247 < v38 ? v247 : v38;
    // pto: %first_quant__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v249 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
    // pto: %first_quant__ssa_v0
    ;
    uint64_t v250 = (uint64_t) v25;
    TASSIGN(v249, v250);
    // pto: %198
    ;
    int64_t v251 = v246 < v49 ? v49 : v246;
    // pto: %199
    ;
    const int64_t v252 = 0;
    // pto: %199
    ;
    __gm__ bfloat16_t* v253 = PTOAS__GLOBAL_TENSOR_DATA(v93);
    // pto: %199
    ;
    const int64_t v254 = 1;
    // pto: %199
    ;
    const int64_t v255 = 1;
    // pto: %199
    ;
    const int64_t v256 = 1;
    // pto: %199
    ;
    int64_t v257 = v248 * v43;
    // pto: %199
    ;
    int64_t v258 = v256 * v257;
    // pto: %199
    ;
    pto::Shape<1, 1, 1, -1, 1024> v259 = pto::Shape<1, 1, 1, -1, 1024>(v254, v255, v256, v248, v53);
    // pto: %199
    ;
    pto::Stride<-1, -1, -1, -1, -1> v260 = pto::Stride<-1, -1, -1, -1, -1>(v255 * v258, v258, v257, v43, v37);
    // pto: %199
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v261 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v253 + (v252 + v251 * v43 + v49 * v37), v259, v260);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v249, v261);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %t__tmp_v4
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v262 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
    // pto: %t__tmp_v4
    ;
    uint64_t v263 = (uint64_t) v24;
    TASSIGN(v262, v263);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    pipe_barrier(PIPE_V);
    RoundMode v264 = RoundMode::CAST_ROUND;
    SaturationMode v265 = SaturationMode::ON;
    TCVT(v262, v249, v264, v265);
    // pto: %first_abs__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v266 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
    // pto: %first_abs__ssa_v0
    ;
    uint64_t v267 = (uint64_t) v24;
    TASSIGN(v266, v267);
    pipe_barrier(PIPE_V);
    TABS(v266, v262);
    // pto: %t__tmp_v5
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v268 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v53);
    // pto: %t__tmp_v5
    ;
    uint64_t v269 = (uint64_t) v25;
    TASSIGN(v268, v269);
    // pto: %amax__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v270 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v37);
    // pto: %amax__ssa_v0
    ;
    uint64_t v271 = (uint64_t) v26;
    TASSIGN(v270, v271);
    pipe_barrier(PIPE_V);
    TROWMAX(v270, v266, v268);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    for (int64_t v272 = v37; v272 < v38; v272 += v37) {
      // pto: %q_bf16__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v273 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
      // pto: %q_bf16__ssa_v0
      ;
      uint64_t v274 = (uint64_t) v25;
      TASSIGN(v273, v274);
      // pto: %201
      ;
      int64_t v275 = (int64_t) ((uint64_t) v272 * (uint64_t) v53);
      // pto: %202
      ;
      int64_t v276 = v275 < v49 ? v49 : v275;
      // pto: %203
      ;
      const int64_t v277 = 0;
      // pto: %203
      ;
      __gm__ bfloat16_t* v278 = PTOAS__GLOBAL_TENSOR_DATA(v93);
      // pto: %203
      ;
      const int64_t v279 = 1;
      // pto: %203
      ;
      const int64_t v280 = 1;
      // pto: %203
      ;
      const int64_t v281 = 1;
      // pto: %203
      ;
      int64_t v282 = v248 * v43;
      // pto: %203
      ;
      int64_t v283 = v281 * v282;
      // pto: %203
      ;
      pto::Shape<1, 1, 1, -1, 1024> v284 = pto::Shape<1, 1, 1, -1, 1024>(v279, v280, v281, v248, v53);
      // pto: %203
      ;
      pto::Stride<-1, -1, -1, -1, -1> v285 = pto::Stride<-1, -1, -1, -1, -1>(v280 * v283, v283, v282, v43, v37);
      // pto: %203
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v286 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v278 + (v277 + v251 * v43 + v276 * v37), v284, v285);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      TLOAD(v273, v286);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %q_fp32__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v287 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
      // pto: %q_fp32__ssa_v0
      ;
      uint64_t v288 = (uint64_t) v24;
      TASSIGN(v287, v288);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      pipe_barrier(PIPE_V);
      RoundMode v289 = RoundMode::CAST_ROUND;
      SaturationMode v290 = SaturationMode::ON;
      TCVT(v287, v273, v289, v290);
      // pto: %t__tmp_v6
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v291 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
      // pto: %t__tmp_v6
      ;
      uint64_t v292 = (uint64_t) v24;
      TASSIGN(v291, v292);
      pipe_barrier(PIPE_V);
      TABS(v291, v287);
      // pto: %t__tmp_v7
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v293 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v53);
      // pto: %t__tmp_v7
      ;
      uint64_t v294 = (uint64_t) v25;
      TASSIGN(v293, v294);
      // pto: %t__tmp_v8
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v295 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v37);
      // pto: %t__tmp_v8
      ;
      uint64_t v296 = (uint64_t) v27;
      TASSIGN(v295, v296);
      pipe_barrier(PIPE_V);
      TROWMAX(v295, v291, v293);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      // pto: %amax__rm_a0_tmp_v0
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v297 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
      // pto: %amax__rm_a0_tmp_v0
      ;
      uint64_t v298 = (uint64_t) v26;
      TASSIGN(v297, v298);
      // pto: %amax__rm_a1_tmp_v1
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v299 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
      // pto: %amax__rm_a1_tmp_v1
      ;
      uint64_t v300 = (uint64_t) v27;
      TASSIGN(v299, v300);
      // pto: %amax__row_major_tmp_v2
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v301 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
      // pto: %amax__row_major_tmp_v2
      ;
      uint64_t v302 = (uint64_t) v24;
      TASSIGN(v301, v302);
      pipe_barrier(PIPE_V);
      TMAX(v301, v297, v299);
      // pto: %amax__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v303 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v37);
      // pto: %amax__ssa_v3
      ;
      uint64_t v304 = (uint64_t) v24;
      TASSIGN(v303, v304);
      // pto: %amax__ssa_v3_mv
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v305 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v37);
      // pto: %amax__ssa_v3_mv
      ;
      uint64_t v306 = (uint64_t) v26;
      TASSIGN(v305, v306);
      pipe_barrier(PIPE_V);
      TMOV(v305, v303);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    // pto: %dequant__rm_a0_tmp_v3
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v307 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
    // pto: %dequant__rm_a0_tmp_v3
    ;
    uint64_t v308 = (uint64_t) v26;
    TASSIGN(v307, v308);
    // pto: %dequant__row_major_tmp_v4
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
    // pto: %dequant__row_major_tmp_v4
    ;
    uint64_t v310 = (uint64_t) v24;
    TASSIGN(v309, v310);
    pipe_barrier(PIPE_V);
    TMULS(v309, v307, v57);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %dequant__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v311 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v37);
    // pto: %dequant__ssa_v0
    ;
    uint64_t v312 = (uint64_t) v24;
    TASSIGN(v311, v312);
    // pto: %denominator__rm_a0_tmp_v5
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
    // pto: %denominator__rm_a0_tmp_v5
    ;
    uint64_t v314 = (uint64_t) v26;
    TASSIGN(v313, v314);
    // pto: %denominator__row_major_tmp_v6
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
    // pto: %denominator__row_major_tmp_v6
    ;
    uint64_t v316 = (uint64_t) v28;
    TASSIGN(v315, v316);
    TADDS(v315, v313, v58);
    set_flag(PIPE_V, PIPE_S, EVENT_ID0);
    // pto: %denominator__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v317 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v37);
    // pto: %denominator__ssa_v0
    ;
    uint64_t v318 = (uint64_t) v28;
    TASSIGN(v317, v318);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
    for (int64_t v319 = v49; v319 < v248; v319 += v37) {
      // pto: %magnitude__ssa_v0
      ;
      float v320 = v317.GetValue(v319);
      // pto: %204
      ;
      bool v321 = v320 != v320 || v58 != v58;
      // pto: %204
      ;
      if ((v320 == v320 && v58 == v58) && v320 == v58) {
        v317.SetValue(v319, v59);
      };
    };
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
    // pto: %t__rm_a0_tmp_v7
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v322 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
    // pto: %t__rm_a0_tmp_v7
    ;
    uint64_t v323 = (uint64_t) v26;
    TASSIGN(v322, v323);
    // pto: %t__row_major_tmp_v8
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v324 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
    // pto: %t__row_major_tmp_v8
    ;
    uint64_t v325 = (uint64_t) v29;
    TASSIGN(v324, v325);
    TMULS(v324, v322, v58);
    // pto: %t__tmp_v9
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v326 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v37);
    // pto: %t__tmp_v9
    ;
    uint64_t v327 = (uint64_t) v29;
    TASSIGN(v326, v327);
    // pto: %t__rm_a0_tmp_v9
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v328 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
    // pto: %t__rm_a0_tmp_v9
    ;
    uint64_t v329 = (uint64_t) v29;
    TASSIGN(v328, v329);
    // pto: %t__row_major_tmp_v10
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v330 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
    // pto: %t__row_major_tmp_v10
    ;
    uint64_t v331 = (uint64_t) v29;
    TASSIGN(v330, v331);
    pipe_barrier(PIPE_V);
    TADDS(v330, v328, v60);
    // pto: %t__tmp_v10
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v332 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v37);
    // pto: %t__tmp_v10
    ;
    uint64_t v333 = (uint64_t) v29;
    TASSIGN(v332, v333);
    // pto: %multiplier__rm_a0_tmp_v11
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v334 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
    // pto: %multiplier__rm_a0_tmp_v11
    ;
    uint64_t v335 = (uint64_t) v29;
    TASSIGN(v334, v335);
    // pto: %multiplier__rm_a1_tmp_v12
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v336 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
    // pto: %multiplier__rm_a1_tmp_v12
    ;
    uint64_t v337 = (uint64_t) v28;
    TASSIGN(v336, v337);
    // pto: %multiplier__row_major_tmp_v13
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v338 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v248);
    // pto: %multiplier__row_major_tmp_v13
    ;
    uint64_t v339 = (uint64_t) v30;
    TASSIGN(v338, v339);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    TDIV(v338, v334, v336);
    // pto: %multiplier__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v340 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v37);
    // pto: %multiplier__ssa_v0
    ;
    uint64_t v341 = (uint64_t) v30;
    TASSIGN(v340, v341);
    v311.SetValidShape(v248, v37);
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v342 = (int64_t) v17;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v343 = 0;
    // pto: %token_scale__ssa_v0_pview
    ;
    __gm__ float* v344 = PTOAS__GLOBAL_TENSOR_DATA(v111);
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v345 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v346 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v347 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v348 = v248 * v37;
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v349 = v347 * v348;
    // pto: %token_scale__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1> v350 = pto::Shape<1, 1, 1, -1, 1>(v345, v346, v347, v248, v37);
    // pto: %token_scale__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v351 = pto::Stride<-1, -1, -1, -1, -1>(v346 * v349, v349, v348, v37, v342);
    // pto: %token_scale__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v352 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v344 + (v343 + v251 * v37 + v49 * v342), v350, v351);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    TSTORE(v352, v311);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    for (int64_t v353 = v49; v353 < v38; v353 += v37) {
      // pto: %209
      ;
      int64_t v354 = (int64_t) ((uint64_t) v353 * (uint64_t) v53);
      // pto: %quant_bf16__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v355 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
      // pto: %quant_bf16__ssa_v0
      ;
      uint64_t v356 = (uint64_t) v25;
      TASSIGN(v355, v356);
      // pto: %211
      ;
      int64_t v357 = v354 < v49 ? v49 : v354;
      // pto: %212
      ;
      const int64_t v358 = 0;
      // pto: %212
      ;
      __gm__ bfloat16_t* v359 = PTOAS__GLOBAL_TENSOR_DATA(v93);
      // pto: %212
      ;
      const int64_t v360 = 1;
      // pto: %212
      ;
      const int64_t v361 = 1;
      // pto: %212
      ;
      const int64_t v362 = 1;
      // pto: %212
      ;
      int64_t v363 = v248 * v43;
      // pto: %212
      ;
      int64_t v364 = v362 * v363;
      // pto: %212
      ;
      pto::Shape<1, 1, 1, -1, 1024> v365 = pto::Shape<1, 1, 1, -1, 1024>(v360, v361, v362, v248, v53);
      // pto: %212
      ;
      pto::Stride<-1, -1, -1, -1, -1> v366 = pto::Stride<-1, -1, -1, -1, -1>(v361 * v364, v364, v363, v43, v37);
      // pto: %212
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v367 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v359 + (v358 + v251 * v43 + v357 * v37), v365, v366);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      TLOAD(v355, v367);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %t__tmp_v12
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v368 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
      // pto: %t__tmp_v12
      ;
      uint64_t v369 = (uint64_t) v24;
      TASSIGN(v368, v369);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      RoundMode v370 = RoundMode::CAST_ROUND;
      SaturationMode v371 = SaturationMode::ON;
      TCVT(v368, v355, v370, v371);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      // pto: %quant_scaled__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v372 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
      // pto: %quant_scaled__ssa_v0
      ;
      uint64_t v373 = (uint64_t) v24;
      TASSIGN(v372, v373);
      pipe_barrier(PIPE_V);
      TROWEXPANDMUL(v372, v368, v340);
      // pto: %integer__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v374 = Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
      // pto: %integer__ssa_v0
      ;
      uint64_t v375 = (uint64_t) v24;
      TASSIGN(v374, v375);
      pipe_barrier(PIPE_V);
      RoundMode v376 = RoundMode::CAST_RINT;
      SaturationMode v377 = SaturationMode::ON;
      TCVT(v374, v372, v376, v377);
      // pto: %half__ssa_v0
      ;
      Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v378 = Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
      // pto: %half__ssa_v0
      ;
      uint64_t v379 = (uint64_t) v24;
      TASSIGN(v378, v379);
      pipe_barrier(PIPE_V);
      RoundMode v380 = RoundMode::CAST_ROUND;
      SaturationMode v381 = SaturationMode::ON;
      TCVT(v378, v374, v380, v381);
      // pto: %result__ssa_v0
      ;
      Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v382 = Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v248, v53);
      // pto: %result__ssa_v0
      ;
      uint64_t v383 = (uint64_t) v24;
      TASSIGN(v382, v383);
      pipe_barrier(PIPE_V);
      RoundMode v384 = RoundMode::CAST_TRUNC;
      SaturationMode v385 = SaturationMode::ON;
      TCVT(v382, v378, v384, v385);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      v382.SetValidShape(v248, v53);
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v386 = 0;
      // pto: %quantized__ssa_v0_pview
      ;
      __gm__ int8_t* v387 = PTOAS__GLOBAL_TENSOR_DATA(v102);
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v388 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v389 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v390 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      int64_t v391 = v248 * v43;
      // pto: %quantized__ssa_v0_pview
      ;
      int64_t v392 = v390 * v391;
      // pto: %quantized__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 1024> v393 = pto::Shape<1, 1, 1, -1, 1024>(v388, v389, v390, v248, v53);
      // pto: %quantized__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v394 = pto::Stride<-1, -1, -1, -1, -1>(v389 * v392, v392, v391, v43, v37);
      // pto: %quantized__ssa_v0_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v395 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v387 + (v386 + v251 * v43 + v357 * v37), v393, v394);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      TSTORE(v395, v382);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %216
  int64_t v396 = (int64_t) ((uint64_t) v168 + (uint64_t) v61);
  // pto: %217
  int64_t v397 = v396 < v49 ? v49 : v396;
  // pto: %signals_v2__ssa_v0_signal_pview
  __gm__ int32_t* v398 = PTOAS__GLOBAL_TENSOR_DATA(v166);
  // pto: %signals_v2__ssa_v0_signal_pview
  const int64_t v399 = 0;
  // pto: %signals_v2__ssa_v0_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v400 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals_v2__ssa_v0_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v401 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals_v2__ssa_v0_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v402 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v398 + (v399 + v397), v400, v401);
  pto::comm::NotifyOp v403 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v402, v177, v403);
  for (int64_t v404 = v49; v404 < v48; v404 += v37) {
    // pto: %218, %219
    ;
    int64_t v405 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v404 * (uint64_t) v40) + (uint64_t) v62);
    // pto: %220
    ;
    int64_t v406 = v405 < v49 ? v49 : v405;
    // pto: %signals_v3__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v407 = PTOAS__GLOBAL_TENSOR_DATA(v166);
    // pto: %signals_v3__ssa_v0_signal_pview
    ;
    const int64_t v408 = 0;
    // pto: %signals_v3__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v409 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v3__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v410 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v3__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v411 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v407 + (v408 + v406), v409, v410);
    pto::comm::WaitCmp v412 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v411, v177, v412);
  }
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  for (int64_t v413 = v167; v413 < v179; v413 += v52) {
    // pto: %223, %224
    ;
    int64_t v414 = (int64_t) ((uint64_t) (v413 / v38) * (uint64_t) v39);
    // pto: %225
    ;
    int64_t v415 = v413 % v38;
    // pto: %226, %227, %228
    ;
    int64_t v416 = v415 < v49 ? (int64_t) ((uint64_t) v415 + (uint64_t) v38) : v415;
    // pto: %229
    ;
    int64_t v417 = (int64_t) ((uint64_t) v416 * (uint64_t) v41);
    // pto: %230
    ;
    int64_t v418 = (int64_t) ((uint64_t) v17 - (uint64_t) v414);
    // pto: %231
    ;
    int64_t v419 = v418 < v39 ? v418 : v39;
    // pto: %ob_integer__ssa_v0
    ;
    Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v420 = Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v419, v41);
    // pto: %ob_integer__ssa_v0
    ;
    uint64_t v421 = (uint64_t) v24;
    TASSIGN(v420, v421);
    // pto: %232
    ;
    int64_t v422 = v414 < v49 ? v49 : v414;
    // pto: %233
    ;
    int64_t v423 = v417 < v49 ? v49 : v417;
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v424 = 0;
    // pto: %integer_accum__ssa_v0_pview
    ;
    __gm__ int32_t* v425 = PTOAS__GLOBAL_TENSOR_DATA(v156);
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v426 = 1;
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v427 = 1;
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v428 = 1;
    // pto: %integer_accum__ssa_v0_pview
    ;
    int64_t v429 = v419 * v42;
    // pto: %integer_accum__ssa_v0_pview
    ;
    int64_t v430 = v428 * v429;
    // pto: %integer_accum__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v431 = pto::Shape<1, 1, 1, -1, 512>(v426, v427, v428, v419, v41);
    // pto: %integer_accum__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v432 = pto::Stride<-1, -1, -1, -1, -1>(v427 * v430, v430, v429, v42, v37);
    // pto: %integer_accum__ssa_v0_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v433 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v425 + (v424 + v422 * v42 + v423 * v37), v431, v432);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    TLOAD(v420, v433);
    // pto: %t__tmp_v14
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v434 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v41);
    // pto: %t__tmp_v14
    ;
    uint64_t v435 = (uint64_t) v26;
    TASSIGN(v434, v435);
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    __gm__ float* v436 = PTOAS__GLOBAL_TENSOR_DATA(v84);
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    const int64_t v437 = 0;
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 512> v438 = pto::Shape<1, 1, 1, 1, 512>();
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    pto::Stride<512, 512, 512, 512, 1> v439 = pto::Stride<512, 512, 512, 512, 1>();
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v440 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v436 + (v437 + v423), v438, v439);
    TLOAD(v434, v440);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    // pto: %channel__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v441 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v41);
    // pto: %channel__ssa_v0
    ;
    uint64_t v442 = (uint64_t) v26;
    TASSIGN(v441, v442);
    // pto: %scale__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v443 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v419, v37);
    // pto: %scale__ssa_v0
    ;
    uint64_t v444 = (uint64_t) v31;
    TASSIGN(v443, v444);
    // pto: %236
    ;
    int64_t v445 = (int64_t) v17;
    // pto: %236
    ;
    const int64_t v446 = 0;
    // pto: %236
    ;
    __gm__ float* v447 = PTOAS__GLOBAL_TENSOR_DATA(v111);
    // pto: %236
    ;
    const int64_t v448 = 1;
    // pto: %236
    ;
    const int64_t v449 = 1;
    // pto: %236
    ;
    const int64_t v450 = 1;
    // pto: %236
    ;
    int64_t v451 = v419 * v37;
    // pto: %236
    ;
    int64_t v452 = v450 * v451;
    // pto: %236
    ;
    pto::Shape<1, 1, 1, -1, 1> v453 = pto::Shape<1, 1, 1, -1, 1>(v448, v449, v450, v419, v37);
    // pto: %236
    ;
    pto::Stride<-1, -1, -1, -1, -1> v454 = pto::Stride<-1, -1, -1, -1, -1>(v449 * v452, v452, v451, v37, v445);
    // pto: %236
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v455 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v447 + (v446 + v422 * v37 + v49 * v445), v453, v454);
    TLOAD(v443, v455);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    // pto: %coefficient_one__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v456 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v39, v41);
    // pto: %coefficient_one__ssa_v0
    ;
    uint64_t v457 = (uint64_t) v25;
    TASSIGN(v456, v457);
    pipe_barrier(PIPE_V);
    TEXPANDS(v456, v59);
    // pto: %coefficient_channel__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v458 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v39, v41);
    // pto: %coefficient_channel__ssa_v0
    ;
    uint64_t v459 = (uint64_t) v25;
    TASSIGN(v458, v459);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    TCOLEXPANDMUL(v458, v456, v441);
    // pto: %coefficient__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v460 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v39, v41);
    // pto: %coefficient__ssa_v0
    ;
    uint64_t v461 = (uint64_t) v25;
    TASSIGN(v460, v461);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    TROWEXPANDMUL(v460, v458, v443);
    // pto: %t__tmp_v15
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v462 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v419, v41);
    // pto: %t__tmp_v15
    ;
    uint64_t v463 = (uint64_t) v24;
    TASSIGN(v462, v463);
    RoundMode v464 = RoundMode::CAST_ROUND;
    SaturationMode v465 = SaturationMode::ON;
    TCVT(v462, v420, v464, v465);
    // pto: %ob_scaled__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v466 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v419, v41);
    // pto: %ob_scaled__ssa_v0
    ;
    uint64_t v467 = (uint64_t) v24;
    TASSIGN(v466, v467);
    pipe_barrier(PIPE_V);
    TMUL(v466, v462, v460);
    // pto: %t__tmp_v16
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v468 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v419, v41);
    // pto: %t__tmp_v16
    ;
    uint64_t v469 = (uint64_t) v24;
    TASSIGN(v468, v469);
    pipe_barrier(PIPE_V);
    RoundMode v470 = RoundMode::CAST_RINT;
    SaturationMode v471 = SaturationMode::ON;
    TCVT(v468, v466, v470, v471);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v472 = 0;
    // pto: %attended__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v473 = PTOAS__GLOBAL_TENSOR_DATA(v120);
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v474 = 1;
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v475 = 1;
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v476 = 1;
    // pto: %attended__ssa_v0_pview
    ;
    int64_t v477 = v419 * v42;
    // pto: %attended__ssa_v0_pview
    ;
    int64_t v478 = v476 * v477;
    // pto: %attended__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v479 = pto::Shape<1, 1, 1, -1, 512>(v474, v475, v476, v419, v41);
    // pto: %attended__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v480 = pto::Stride<-1, -1, -1, -1, -1>(v475 * v478, v478, v477, v42, v37);
    // pto: %attended__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v481 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v473 + (v472 + v422 * v42 + v423 * v37), v479, v480);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    TSTORE(v481, v468);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %240
  int64_t v482 = (int64_t) ((uint64_t) v168 + (uint64_t) v63);
  // pto: %241
  int64_t v483 = v482 < v49 ? v49 : v482;
  // pto: %signals_v4__ssa_v0_signal_pview
  __gm__ int32_t* v484 = PTOAS__GLOBAL_TENSOR_DATA(v166);
  // pto: %signals_v4__ssa_v0_signal_pview
  const int64_t v485 = 0;
  // pto: %signals_v4__ssa_v0_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v486 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals_v4__ssa_v0_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v487 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals_v4__ssa_v0_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v488 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v484 + (v485 + v483), v486, v487);
  pto::comm::NotifyOp v489 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v488, v177, v489);
  for (int64_t v490 = v48; v490 < v55; v490 += v37) {
    // pto: %242, %243
    ;
    int64_t v491 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v490 * (uint64_t) v40) + (uint64_t) v63);
    // pto: %244
    ;
    int64_t v492 = v491 < v49 ? v49 : v491;
    // pto: %signals_v5__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v493 = PTOAS__GLOBAL_TENSOR_DATA(v166);
    // pto: %signals_v5__ssa_v0_signal_pview
    ;
    const int64_t v494 = 0;
    // pto: %signals_v5__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v495 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v5__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v496 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v5__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v497 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v493 + (v494 + v492), v495, v496);
    pto::comm::WaitCmp v498 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v497, v177, v498);
  }
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %245, %246
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  for (int64_t v499 = v167; v499 < ((int64_t) ((uint64_t) v17 + (uint64_t) v64) / v45); v499 += v52) {
    // pto: %247
    ;
    int64_t v500 = (int64_t) ((uint64_t) v499 * (uint64_t) v45);
    // pto: %248
    ;
    int64_t v501 = (int64_t) ((uint64_t) v500 + (uint64_t) v45);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    for (int64_t v502 = v500; v502 < v501; v502 += v47) {
      // pto: %249
      ;
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      if (v502 < v17) {
        // pto: %250
        ;
        int64_t v503 = (int64_t) ((uint64_t) v502 * (uint64_t) v45);
        // pto: %post_scalar__tile
        ;
        float v504 = (v11)[v503];
        // pto: %252
        ;
        int64_t v505 = (int64_t) ((uint64_t) v502 * (uint64_t) v39);
        // pto: %comb_scalar_0__tile
        ;
        float v506 = (v12)[v505];
        // pto: %255, %comb_scalar_1__tile
        ;
        float v507 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v45)];
        // pto: %257, %comb_scalar_2__tile
        ;
        float v508 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v38)];
        // pto: %259, %comb_scalar_3__tile
        ;
        float v509 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v65)];
        // pto: %262, %260
        ;
        float v510 = (v11)[(int64_t) ((uint64_t) v503 + (uint64_t) v37)];
        // pto: %265, %263
        ;
        float v511 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v37)];
        // pto: %268, %266
        ;
        float v512 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v66)];
        // pto: %271, %269
        ;
        float v513 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v67)];
        // pto: %274, %272
        ;
        float v514 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v68)];
        // pto: %277, %275
        ;
        float v515 = (v11)[(int64_t) ((uint64_t) v503 + (uint64_t) v47)];
        // pto: %280, %278
        ;
        float v516 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v47)];
        // pto: %283, %281
        ;
        float v517 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v69)];
        // pto: %286, %284
        ;
        float v518 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v70)];
        // pto: %289, %287
        ;
        float v519 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v71)];
        // pto: %292, %290
        ;
        float v520 = (v11)[(int64_t) ((uint64_t) v503 + (uint64_t) v64)];
        // pto: %295, %293
        ;
        float v521 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v64)];
        // pto: %298, %296
        ;
        float v522 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v56)];
        // pto: %301, %299
        ;
        float v523 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v72)];
        // pto: %304, %302
        ;
        float v524 = (v12)[(int64_t) ((uint64_t) v505 + (uint64_t) v50)];
        // pto: %x_block__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v525 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %x_block__tile
        ;
        uint64_t v526 = (uint64_t) v32;
        TASSIGN(v525, v526);
        // pto: %305
        ;
        int64_t v527 = v502 < v49 ? v49 : v502;
        // pto: %x__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v528 = PTOAS__GLOBAL_TENSOR_DATA(v120);
        // pto: %x__ssa_v0_pview
        ;
        const int64_t v529 = 0;
        // pto: %x__ssa_v0_pview
        ;
        const int64_t v530 = 4096;
        // pto: %x__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v531 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %x__ssa_v0_pview
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v532 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %x__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v533 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v528 + (v529 + v527 * v530), v531, v532);
        TLOAD(v525, v533);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        // pto: %306
        ;
        int64_t v534 = (int64_t) ((uint64_t) v17 - (uint64_t) v502);
        // pto: %307
        ;
        int64_t v535 = v534 < v49 ? v49 : v534;
        // pto: %308
        ;
        int64_t v536 = v535 < v37 ? v535 : v37;
        // pto: %t__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v537 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %t__tile
        ;
        uint64_t v538 = (uint64_t) v25;
        TASSIGN(v537, v538);
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v539 = 0;
        // pto: %residual_flat__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v540 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v541 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v542 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v543 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        int64_t v544 = v536 * v44;
        // pto: %residual_flat__ssa_v0_pview
        ;
        int64_t v545 = v543 * v544;
        // pto: %residual_flat__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 4096> v546 = pto::Shape<1, 1, 1, -1, 4096>(v541, v542, v543, v536, v42);
        // pto: %residual_flat__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v547 = pto::Stride<-1, -1, -1, -1, -1>(v542 * v545, v545, v544, v44, v37);
        // pto: %residual_flat__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v548 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v540 + (v539 + v527 * v44 + v49 * v37), v546, v547);
        TLOAD(v537, v548);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        // pto: %0
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v549 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %0
        ;
        uint64_t v550 = (uint64_t) v30;
        TASSIGN(v549, v550);
        // pto: %320
        ;
        const int64_t v551 = 0;
        // pto: %320
        ;
        __gm__ bfloat16_t* v552 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %320
        ;
        const int64_t v553 = 1;
        // pto: %320
        ;
        const int64_t v554 = 1;
        // pto: %320
        ;
        const int64_t v555 = 1;
        // pto: %320
        ;
        int64_t v556 = v536 * v44;
        // pto: %320
        ;
        int64_t v557 = v555 * v556;
        // pto: %320
        ;
        pto::Shape<1, 1, 1, -1, 4096> v558 = pto::Shape<1, 1, 1, -1, 4096>(v553, v554, v555, v536, v42);
        // pto: %320
        ;
        pto::Stride<-1, -1, -1, -1, -1> v559 = pto::Stride<-1, -1, -1, -1, -1>(v554 * v557, v557, v556, v44, v37);
        // pto: %320
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v560 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v552 + (v551 + v527 * v44 + v42 * v37), v558, v559);
        TLOAD(v549, v560);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %1
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v561 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %1
        ;
        uint64_t v562 = (uint64_t) v26;
        TASSIGN(v561, v562);
        // pto: %328
        ;
        const int64_t v563 = 0;
        // pto: %328
        ;
        __gm__ bfloat16_t* v564 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %328
        ;
        const int64_t v565 = 1;
        // pto: %328
        ;
        const int64_t v566 = 1;
        // pto: %328
        ;
        const int64_t v567 = 1;
        // pto: %328
        ;
        int64_t v568 = v536 * v44;
        // pto: %328
        ;
        int64_t v569 = v567 * v568;
        // pto: %328
        ;
        pto::Shape<1, 1, 1, -1, 4096> v570 = pto::Shape<1, 1, 1, -1, 4096>(v565, v566, v567, v536, v42);
        // pto: %328
        ;
        pto::Stride<-1, -1, -1, -1, -1> v571 = pto::Stride<-1, -1, -1, -1, -1>(v566 * v569, v569, v568, v44, v37);
        // pto: %328
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v572 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v564 + (v563 + v527 * v44 + v43 * v37), v570, v571);
        TLOAD(v561, v572);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %2
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v573 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %2
        ;
        uint64_t v574 = (uint64_t) v33;
        TASSIGN(v573, v574);
        // pto: %336
        ;
        const int64_t v575 = 0;
        // pto: %336
        ;
        __gm__ bfloat16_t* v576 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %336
        ;
        const int64_t v577 = 1;
        // pto: %336
        ;
        const int64_t v578 = 1;
        // pto: %336
        ;
        const int64_t v579 = 1;
        // pto: %336
        ;
        int64_t v580 = v536 * v44;
        // pto: %336
        ;
        int64_t v581 = v579 * v580;
        // pto: %336
        ;
        pto::Shape<1, 1, 1, -1, 4096> v582 = pto::Shape<1, 1, 1, -1, 4096>(v577, v578, v579, v536, v42);
        // pto: %336
        ;
        pto::Stride<-1, -1, -1, -1, -1> v583 = pto::Stride<-1, -1, -1, -1, -1>(v578 * v581, v581, v580, v44, v37);
        // pto: %336
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v584 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v576 + (v575 + v527 * v44 + v73 * v37), v582, v583);
        TLOAD(v573, v584);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %x_f32__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v585 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %x_f32__tile
        ;
        uint64_t v586 = (uint64_t) v24;
        TASSIGN(v585, v586);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        RoundMode v587 = RoundMode::CAST_ROUND;
        SaturationMode v588 = SaturationMode::ON;
        TCVT(v585, v525, v587, v588);
        // pto: %res_0__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v589 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %res_0__tile
        ;
        uint64_t v590 = (uint64_t) v32;
        TASSIGN(v589, v590);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        RoundMode v591 = RoundMode::CAST_ROUND;
        SaturationMode v592 = SaturationMode::ON;
        TCVT(v589, v537, v591, v592);
        // pto: %res_1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v593 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %res_1__tile
        ;
        uint64_t v594 = (uint64_t) v25;
        TASSIGN(v593, v594);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v595 = RoundMode::CAST_ROUND;
        SaturationMode v596 = SaturationMode::ON;
        TCVT(v593, v549, v595, v596);
        // pto: %res_2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v597 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %res_2__tile
        ;
        uint64_t v598 = (uint64_t) v30;
        TASSIGN(v597, v598);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        RoundMode v599 = RoundMode::CAST_ROUND;
        SaturationMode v600 = SaturationMode::ON;
        TCVT(v597, v561, v599, v600);
        // pto: %res_3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v601 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %res_3__tile
        ;
        uint64_t v602 = (uint64_t) v26;
        TASSIGN(v601, v602);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v603 = RoundMode::CAST_ROUND;
        SaturationMode v604 = SaturationMode::ON;
        TCVT(v601, v573, v603, v604);
        // pto: %single_y__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v605 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_y__tile
        ;
        uint64_t v606 = (uint64_t) v33;
        TASSIGN(v605, v606);
        pipe_barrier(PIPE_V);
        TMULS(v605, v585, v504);
        // pto: %single_weighted_0__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v607 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %single_weighted_0__tile
        ;
        uint64_t v608 = (uint64_t) v34;
        TASSIGN(v607, v608);
        TMULS(v607, v589, v506);
        // pto: %single_y_v1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v609 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_y_v1__tile
        ;
        uint64_t v610 = (uint64_t) v33;
        TASSIGN(v609, v610);
        pipe_barrier(PIPE_V);
        TADD(v609, v605, v607);
        // pto: %single_weighted_1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v611 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %single_weighted_1__tile
        ;
        uint64_t v612 = (uint64_t) v34;
        TASSIGN(v611, v612);
        pipe_barrier(PIPE_V);
        TMULS(v611, v593, v507);
        // pto: %single_y_v2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v613 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_y_v2__tile
        ;
        uint64_t v614 = (uint64_t) v33;
        TASSIGN(v613, v614);
        pipe_barrier(PIPE_V);
        TADD(v613, v609, v611);
        // pto: %single_weighted_2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v615 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %single_weighted_2__tile
        ;
        uint64_t v616 = (uint64_t) v34;
        TASSIGN(v615, v616);
        pipe_barrier(PIPE_V);
        TMULS(v615, v597, v508);
        // pto: %single_y_v3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v617 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_y_v3__tile
        ;
        uint64_t v618 = (uint64_t) v33;
        TASSIGN(v617, v618);
        pipe_barrier(PIPE_V);
        TADD(v617, v613, v615);
        // pto: %single_weighted_3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v619 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %single_weighted_3__tile
        ;
        uint64_t v620 = (uint64_t) v34;
        TASSIGN(v619, v620);
        pipe_barrier(PIPE_V);
        TMULS(v619, v601, v509);
        // pto: %single_y_v4__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v621 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_y_v4__tile
        ;
        uint64_t v622 = (uint64_t) v33;
        TASSIGN(v621, v622);
        pipe_barrier(PIPE_V);
        TADD(v621, v617, v619);
        // pto: %single_result__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v623 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_result__tile
        ;
        uint64_t v624 = (uint64_t) v35;
        TASSIGN(v623, v624);
        pipe_barrier(PIPE_V);
        RoundMode v625 = RoundMode::CAST_RINT;
        SaturationMode v626 = SaturationMode::ON;
        TCVT(v623, v621, v625, v626);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        v623.SetValidShape(v37, v42);
        // pto: %4
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v627 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %4
        ;
        uint64_t v628 = (uint64_t) v33;
        TASSIGN(v627, v628);
        pipe_barrier(PIPE_V);
        TMULS(v627, v585, v510);
        // pto: %5
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v629 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %5
        ;
        uint64_t v630 = (uint64_t) v34;
        TASSIGN(v629, v630);
        TMULS(v629, v589, v511);
        // pto: %6
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v631 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %6
        ;
        uint64_t v632 = (uint64_t) v33;
        TASSIGN(v631, v632);
        pipe_barrier(PIPE_V);
        TADD(v631, v627, v629);
        // pto: %7
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v633 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %7
        ;
        uint64_t v634 = (uint64_t) v34;
        TASSIGN(v633, v634);
        pipe_barrier(PIPE_V);
        TMULS(v633, v593, v512);
        // pto: %8
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v635 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %8
        ;
        uint64_t v636 = (uint64_t) v33;
        TASSIGN(v635, v636);
        pipe_barrier(PIPE_V);
        TADD(v635, v631, v633);
        // pto: %9
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v637 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %9
        ;
        uint64_t v638 = (uint64_t) v34;
        TASSIGN(v637, v638);
        pipe_barrier(PIPE_V);
        TMULS(v637, v597, v513);
        // pto: %10
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v639 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %10
        ;
        uint64_t v640 = (uint64_t) v33;
        TASSIGN(v639, v640);
        pipe_barrier(PIPE_V);
        TADD(v639, v635, v637);
        // pto: %11
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v641 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %11
        ;
        uint64_t v642 = (uint64_t) v34;
        TASSIGN(v641, v642);
        pipe_barrier(PIPE_V);
        TMULS(v641, v601, v514);
        // pto: %12
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v643 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %12
        ;
        uint64_t v644 = (uint64_t) v33;
        TASSIGN(v643, v644);
        pipe_barrier(PIPE_V);
        TADD(v643, v639, v641);
        // pto: %13
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v645 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %13
        ;
        uint64_t v646 = (uint64_t) v36;
        TASSIGN(v645, v646);
        pipe_barrier(PIPE_V);
        RoundMode v647 = RoundMode::CAST_RINT;
        SaturationMode v648 = SaturationMode::ON;
        TCVT(v645, v643, v647, v648);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        v645.SetValidShape(v37, v42);
        // pto: %15
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v649 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %15
        ;
        uint64_t v650 = (uint64_t) v33;
        TASSIGN(v649, v650);
        pipe_barrier(PIPE_V);
        TMULS(v649, v585, v515);
        // pto: %16
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v651 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %16
        ;
        uint64_t v652 = (uint64_t) v34;
        TASSIGN(v651, v652);
        TMULS(v651, v589, v516);
        // pto: %17
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v653 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %17
        ;
        uint64_t v654 = (uint64_t) v33;
        TASSIGN(v653, v654);
        pipe_barrier(PIPE_V);
        TADD(v653, v649, v651);
        // pto: %18
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v655 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %18
        ;
        uint64_t v656 = (uint64_t) v34;
        TASSIGN(v655, v656);
        pipe_barrier(PIPE_V);
        TMULS(v655, v593, v517);
        // pto: %19
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v657 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %19
        ;
        uint64_t v658 = (uint64_t) v33;
        TASSIGN(v657, v658);
        pipe_barrier(PIPE_V);
        TADD(v657, v653, v655);
        // pto: %20
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v659 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %20
        ;
        uint64_t v660 = (uint64_t) v34;
        TASSIGN(v659, v660);
        pipe_barrier(PIPE_V);
        TMULS(v659, v597, v518);
        // pto: %21
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v661 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %21
        ;
        uint64_t v662 = (uint64_t) v33;
        TASSIGN(v661, v662);
        pipe_barrier(PIPE_V);
        TADD(v661, v657, v659);
        // pto: %22
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v663 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %22
        ;
        uint64_t v664 = (uint64_t) v34;
        TASSIGN(v663, v664);
        pipe_barrier(PIPE_V);
        TMULS(v663, v601, v519);
        // pto: %23
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v665 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %23
        ;
        uint64_t v666 = (uint64_t) v33;
        TASSIGN(v665, v666);
        pipe_barrier(PIPE_V);
        TADD(v665, v661, v663);
        // pto: %24
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v667 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %24
        ;
        uint64_t v668 = (uint64_t) v33;
        TASSIGN(v667, v668);
        pipe_barrier(PIPE_V);
        RoundMode v669 = RoundMode::CAST_RINT;
        SaturationMode v670 = SaturationMode::ON;
        TCVT(v667, v665, v669, v670);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        v667.SetValidShape(v37, v42);
        // pto: %26
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v671 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %26
        ;
        uint64_t v672 = (uint64_t) v24;
        TASSIGN(v671, v672);
        TMULS(v671, v585, v520);
        // pto: %27
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v673 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %27
        ;
        uint64_t v674 = (uint64_t) v32;
        TASSIGN(v673, v674);
        TMULS(v673, v589, v521);
        // pto: %28
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v675 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %28
        ;
        uint64_t v676 = (uint64_t) v24;
        TASSIGN(v675, v676);
        pipe_barrier(PIPE_V);
        TADD(v675, v671, v673);
        // pto: %29
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v677 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %29
        ;
        uint64_t v678 = (uint64_t) v32;
        TASSIGN(v677, v678);
        pipe_barrier(PIPE_V);
        TMULS(v677, v593, v522);
        // pto: %30
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v679 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %30
        ;
        uint64_t v680 = (uint64_t) v24;
        TASSIGN(v679, v680);
        pipe_barrier(PIPE_V);
        TADD(v679, v675, v677);
        // pto: %31
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v681 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %31
        ;
        uint64_t v682 = (uint64_t) v32;
        TASSIGN(v681, v682);
        pipe_barrier(PIPE_V);
        TMULS(v681, v597, v523);
        // pto: %32
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v683 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %32
        ;
        uint64_t v684 = (uint64_t) v24;
        TASSIGN(v683, v684);
        pipe_barrier(PIPE_V);
        TADD(v683, v679, v681);
        // pto: %33
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v685 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v536, v42);
        // pto: %33
        ;
        uint64_t v686 = (uint64_t) v32;
        TASSIGN(v685, v686);
        pipe_barrier(PIPE_V);
        TMULS(v685, v601, v524);
        // pto: %34
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v687 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %34
        ;
        uint64_t v688 = (uint64_t) v24;
        TASSIGN(v687, v688);
        pipe_barrier(PIPE_V);
        TADD(v687, v683, v685);
        // pto: %35
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v689 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %35
        ;
        uint64_t v690 = (uint64_t) v24;
        TASSIGN(v689, v690);
        pipe_barrier(PIPE_V);
        RoundMode v691 = RoundMode::CAST_RINT;
        SaturationMode v692 = SaturationMode::ON;
        TCVT(v689, v687, v691, v692);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        v689.SetValidShape(v37, v42);
        // pto: %y_flat__iter_v3_pview
        ;
        __gm__ bfloat16_t* v693 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %y_flat__iter_v3_pview
        ;
        const int64_t v694 = 0;
        // pto: %y_flat__iter_v3_pview
        ;
        const int64_t v695 = 16384;
        // pto: %y_flat__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v696 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__iter_v3_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v697 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v698 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v693 + (v694 + v527 * v695), v696, v697);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        TSTORE(v698, v623);
        // pto: %y_flat__tile_pview
        ;
        __gm__ bfloat16_t* v699 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %y_flat__tile_pview
        ;
        const int64_t v700 = 4096;
        // pto: %y_flat__tile_pview
        ;
        const int64_t v701 = 16384;
        // pto: %y_flat__tile_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v702 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__tile_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v703 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__tile_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v704 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v699 + (v700 + v527 * v701), v702, v703);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        TSTORE(v704, v645);
        // pto: %402
        ;
        __gm__ bfloat16_t* v705 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %402
        ;
        const int64_t v706 = 8192;
        // pto: %402
        ;
        const int64_t v707 = 16384;
        // pto: %402
        ;
        pto::Shape<1, 1, 1, 1, 4096> v708 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %402
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v709 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %402
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v710 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v705 + (v706 + v527 * v707), v708, v709);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        TSTORE(v710, v667);
        // pto: %405
        ;
        __gm__ bfloat16_t* v711 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %405
        ;
        const int64_t v712 = 12288;
        // pto: %405
        ;
        const int64_t v713 = 16384;
        // pto: %405
        ;
        pto::Shape<1, 1, 1, 1, 4096> v714 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %405
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v715 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %405
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v716 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v711 + (v712 + v527 * v713), v714, v715);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        TSTORE(v716, v689);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      // pto: %406
      ;
      int64_t v717 = (int64_t) ((uint64_t) v502 + (uint64_t) v37);
      // pto: %407
      ;
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      if (v717 < v17) {
        // pto: %410
        ;
        int64_t v718 = (int64_t) ((uint64_t) v717 * (uint64_t) v45);
        // pto: %408
        ;
        float v719 = (v11)[v718];
        // pto: %414
        ;
        int64_t v720 = (int64_t) ((uint64_t) v717 * (uint64_t) v39);
        // pto: %412
        ;
        float v721 = (v12)[v720];
        // pto: %419, %416
        ;
        float v722 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v45)];
        // pto: %423, %420
        ;
        float v723 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v38)];
        // pto: %427, %424
        ;
        float v724 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v65)];
        // pto: %431, %428
        ;
        float v725 = (v11)[(int64_t) ((uint64_t) v718 + (uint64_t) v37)];
        // pto: %435, %432
        ;
        float v726 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v37)];
        // pto: %439, %436
        ;
        float v727 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v66)];
        // pto: %443, %440
        ;
        float v728 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v67)];
        // pto: %447, %444
        ;
        float v729 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v68)];
        // pto: %451, %448
        ;
        float v730 = (v11)[(int64_t) ((uint64_t) v718 + (uint64_t) v47)];
        // pto: %455, %452
        ;
        float v731 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v47)];
        // pto: %459, %456
        ;
        float v732 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v69)];
        // pto: %463, %460
        ;
        float v733 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v70)];
        // pto: %467, %464
        ;
        float v734 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v71)];
        // pto: %471, %468
        ;
        float v735 = (v11)[(int64_t) ((uint64_t) v718 + (uint64_t) v64)];
        // pto: %475, %472
        ;
        float v736 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v64)];
        // pto: %479, %476
        ;
        float v737 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v56)];
        // pto: %483, %480
        ;
        float v738 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v72)];
        // pto: %487, %484
        ;
        float v739 = (v12)[(int64_t) ((uint64_t) v720 + (uint64_t) v50)];
        // pto: %37
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v740 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %37
        ;
        uint64_t v741 = (uint64_t) v32;
        TASSIGN(v740, v741);
        // pto: %489
        ;
        int64_t v742 = v717 < v49 ? v49 : v717;
        // pto: %490
        ;
        __gm__ bfloat16_t* v743 = PTOAS__GLOBAL_TENSOR_DATA(v120);
        // pto: %490
        ;
        const int64_t v744 = 0;
        // pto: %490
        ;
        const int64_t v745 = 4096;
        // pto: %490
        ;
        pto::Shape<1, 1, 1, 1, 4096> v746 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %490
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v747 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %490
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v748 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v743 + (v744 + v742 * v745), v746, v747);
        TLOAD(v740, v748);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %491, %492
        ;
        int64_t v749 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v17 - (uint64_t) v502) + (uint64_t) v74);
        // pto: %493
        ;
        int64_t v750 = v749 < v49 ? v49 : v749;
        // pto: %494
        ;
        int64_t v751 = v750 < v37 ? v750 : v37;
        // pto: %38
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v752 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %38
        ;
        uint64_t v753 = (uint64_t) v25;
        TASSIGN(v752, v753);
        // pto: %501
        ;
        const int64_t v754 = 0;
        // pto: %501
        ;
        __gm__ bfloat16_t* v755 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %501
        ;
        const int64_t v756 = 1;
        // pto: %501
        ;
        const int64_t v757 = 1;
        // pto: %501
        ;
        const int64_t v758 = 1;
        // pto: %501
        ;
        int64_t v759 = v751 * v44;
        // pto: %501
        ;
        int64_t v760 = v758 * v759;
        // pto: %501
        ;
        pto::Shape<1, 1, 1, -1, 4096> v761 = pto::Shape<1, 1, 1, -1, 4096>(v756, v757, v758, v751, v42);
        // pto: %501
        ;
        pto::Stride<-1, -1, -1, -1, -1> v762 = pto::Stride<-1, -1, -1, -1, -1>(v757 * v760, v760, v759, v44, v37);
        // pto: %501
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v763 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v755 + (v754 + v742 * v44 + v49 * v37), v761, v762);
        TLOAD(v752, v763);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %39
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v764 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %39
        ;
        uint64_t v765 = (uint64_t) v30;
        TASSIGN(v764, v765);
        // pto: %512
        ;
        const int64_t v766 = 0;
        // pto: %512
        ;
        __gm__ bfloat16_t* v767 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %512
        ;
        const int64_t v768 = 1;
        // pto: %512
        ;
        const int64_t v769 = 1;
        // pto: %512
        ;
        const int64_t v770 = 1;
        // pto: %512
        ;
        int64_t v771 = v751 * v44;
        // pto: %512
        ;
        int64_t v772 = v770 * v771;
        // pto: %512
        ;
        pto::Shape<1, 1, 1, -1, 4096> v773 = pto::Shape<1, 1, 1, -1, 4096>(v768, v769, v770, v751, v42);
        // pto: %512
        ;
        pto::Stride<-1, -1, -1, -1, -1> v774 = pto::Stride<-1, -1, -1, -1, -1>(v769 * v772, v772, v771, v44, v37);
        // pto: %512
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v775 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v767 + (v766 + v742 * v44 + v42 * v37), v773, v774);
        TLOAD(v764, v775);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %40
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v776 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %40
        ;
        uint64_t v777 = (uint64_t) v26;
        TASSIGN(v776, v777);
        // pto: %523
        ;
        const int64_t v778 = 0;
        // pto: %523
        ;
        __gm__ bfloat16_t* v779 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %523
        ;
        const int64_t v780 = 1;
        // pto: %523
        ;
        const int64_t v781 = 1;
        // pto: %523
        ;
        const int64_t v782 = 1;
        // pto: %523
        ;
        int64_t v783 = v751 * v44;
        // pto: %523
        ;
        int64_t v784 = v782 * v783;
        // pto: %523
        ;
        pto::Shape<1, 1, 1, -1, 4096> v785 = pto::Shape<1, 1, 1, -1, 4096>(v780, v781, v782, v751, v42);
        // pto: %523
        ;
        pto::Stride<-1, -1, -1, -1, -1> v786 = pto::Stride<-1, -1, -1, -1, -1>(v781 * v784, v784, v783, v44, v37);
        // pto: %523
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v787 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v779 + (v778 + v742 * v44 + v43 * v37), v785, v786);
        TLOAD(v776, v787);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        // pto: %41
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v788 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %41
        ;
        uint64_t v789 = (uint64_t) v33;
        TASSIGN(v788, v789);
        // pto: %534
        ;
        const int64_t v790 = 0;
        // pto: %534
        ;
        __gm__ bfloat16_t* v791 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %534
        ;
        const int64_t v792 = 1;
        // pto: %534
        ;
        const int64_t v793 = 1;
        // pto: %534
        ;
        const int64_t v794 = 1;
        // pto: %534
        ;
        int64_t v795 = v751 * v44;
        // pto: %534
        ;
        int64_t v796 = v794 * v795;
        // pto: %534
        ;
        pto::Shape<1, 1, 1, -1, 4096> v797 = pto::Shape<1, 1, 1, -1, 4096>(v792, v793, v794, v751, v42);
        // pto: %534
        ;
        pto::Stride<-1, -1, -1, -1, -1> v798 = pto::Stride<-1, -1, -1, -1, -1>(v793 * v796, v796, v795, v44, v37);
        // pto: %534
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v799 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v791 + (v790 + v742 * v44 + v73 * v37), v797, v798);
        TLOAD(v788, v799);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        // pto: %42
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v800 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %42
        ;
        uint64_t v801 = (uint64_t) v24;
        TASSIGN(v800, v801);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v802 = RoundMode::CAST_ROUND;
        SaturationMode v803 = SaturationMode::ON;
        TCVT(v800, v740, v802, v803);
        // pto: %43
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v804 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %43
        ;
        uint64_t v805 = (uint64_t) v32;
        TASSIGN(v804, v805);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        RoundMode v806 = RoundMode::CAST_ROUND;
        SaturationMode v807 = SaturationMode::ON;
        TCVT(v804, v752, v806, v807);
        // pto: %44
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v808 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %44
        ;
        uint64_t v809 = (uint64_t) v25;
        TASSIGN(v808, v809);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v810 = RoundMode::CAST_ROUND;
        SaturationMode v811 = SaturationMode::ON;
        TCVT(v808, v764, v810, v811);
        // pto: %45
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v812 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %45
        ;
        uint64_t v813 = (uint64_t) v30;
        TASSIGN(v812, v813);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        RoundMode v814 = RoundMode::CAST_ROUND;
        SaturationMode v815 = SaturationMode::ON;
        TCVT(v812, v776, v814, v815);
        // pto: %46
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v816 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %46
        ;
        uint64_t v817 = (uint64_t) v26;
        TASSIGN(v816, v817);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        RoundMode v818 = RoundMode::CAST_ROUND;
        SaturationMode v819 = SaturationMode::ON;
        TCVT(v816, v788, v818, v819);
        // pto: %47
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v820 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %47
        ;
        uint64_t v821 = (uint64_t) v33;
        TASSIGN(v820, v821);
        pipe_barrier(PIPE_V);
        TMULS(v820, v800, v719);
        // pto: %48
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v822 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %48
        ;
        uint64_t v823 = (uint64_t) v34;
        TASSIGN(v822, v823);
        TMULS(v822, v804, v721);
        // pto: %49
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v824 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %49
        ;
        uint64_t v825 = (uint64_t) v33;
        TASSIGN(v824, v825);
        pipe_barrier(PIPE_V);
        TADD(v824, v820, v822);
        // pto: %50
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v826 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %50
        ;
        uint64_t v827 = (uint64_t) v34;
        TASSIGN(v826, v827);
        pipe_barrier(PIPE_V);
        TMULS(v826, v808, v722);
        // pto: %51
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v828 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %51
        ;
        uint64_t v829 = (uint64_t) v33;
        TASSIGN(v828, v829);
        pipe_barrier(PIPE_V);
        TADD(v828, v824, v826);
        // pto: %52
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v830 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %52
        ;
        uint64_t v831 = (uint64_t) v34;
        TASSIGN(v830, v831);
        pipe_barrier(PIPE_V);
        TMULS(v830, v812, v723);
        // pto: %53
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v832 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %53
        ;
        uint64_t v833 = (uint64_t) v33;
        TASSIGN(v832, v833);
        pipe_barrier(PIPE_V);
        TADD(v832, v828, v830);
        // pto: %54
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v834 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %54
        ;
        uint64_t v835 = (uint64_t) v34;
        TASSIGN(v834, v835);
        pipe_barrier(PIPE_V);
        TMULS(v834, v816, v724);
        // pto: %55
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v836 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %55
        ;
        uint64_t v837 = (uint64_t) v33;
        TASSIGN(v836, v837);
        pipe_barrier(PIPE_V);
        TADD(v836, v832, v834);
        // pto: %56
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v838 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %56
        ;
        uint64_t v839 = (uint64_t) v35;
        TASSIGN(v838, v839);
        pipe_barrier(PIPE_V);
        RoundMode v840 = RoundMode::CAST_RINT;
        SaturationMode v841 = SaturationMode::ON;
        TCVT(v838, v836, v840, v841);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v838.SetValidShape(v37, v42);
        // pto: %58
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v842 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %58
        ;
        uint64_t v843 = (uint64_t) v33;
        TASSIGN(v842, v843);
        pipe_barrier(PIPE_V);
        TMULS(v842, v800, v725);
        // pto: %59
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v844 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %59
        ;
        uint64_t v845 = (uint64_t) v34;
        TASSIGN(v844, v845);
        TMULS(v844, v804, v726);
        // pto: %60
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v846 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %60
        ;
        uint64_t v847 = (uint64_t) v33;
        TASSIGN(v846, v847);
        pipe_barrier(PIPE_V);
        TADD(v846, v842, v844);
        // pto: %61
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v848 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %61
        ;
        uint64_t v849 = (uint64_t) v34;
        TASSIGN(v848, v849);
        pipe_barrier(PIPE_V);
        TMULS(v848, v808, v727);
        // pto: %62
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v850 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %62
        ;
        uint64_t v851 = (uint64_t) v33;
        TASSIGN(v850, v851);
        pipe_barrier(PIPE_V);
        TADD(v850, v846, v848);
        // pto: %63
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v852 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %63
        ;
        uint64_t v853 = (uint64_t) v34;
        TASSIGN(v852, v853);
        pipe_barrier(PIPE_V);
        TMULS(v852, v812, v728);
        // pto: %64
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v854 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %64
        ;
        uint64_t v855 = (uint64_t) v33;
        TASSIGN(v854, v855);
        pipe_barrier(PIPE_V);
        TADD(v854, v850, v852);
        // pto: %65
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v856 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %65
        ;
        uint64_t v857 = (uint64_t) v34;
        TASSIGN(v856, v857);
        pipe_barrier(PIPE_V);
        TMULS(v856, v816, v729);
        // pto: %66
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v858 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %66
        ;
        uint64_t v859 = (uint64_t) v33;
        TASSIGN(v858, v859);
        pipe_barrier(PIPE_V);
        TADD(v858, v854, v856);
        // pto: %67
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v860 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %67
        ;
        uint64_t v861 = (uint64_t) v36;
        TASSIGN(v860, v861);
        pipe_barrier(PIPE_V);
        RoundMode v862 = RoundMode::CAST_RINT;
        SaturationMode v863 = SaturationMode::ON;
        TCVT(v860, v858, v862, v863);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        v860.SetValidShape(v37, v42);
        // pto: %69
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v864 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %69
        ;
        uint64_t v865 = (uint64_t) v33;
        TASSIGN(v864, v865);
        pipe_barrier(PIPE_V);
        TMULS(v864, v800, v730);
        // pto: %70
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v866 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %70
        ;
        uint64_t v867 = (uint64_t) v34;
        TASSIGN(v866, v867);
        TMULS(v866, v804, v731);
        // pto: %71
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v868 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %71
        ;
        uint64_t v869 = (uint64_t) v33;
        TASSIGN(v868, v869);
        pipe_barrier(PIPE_V);
        TADD(v868, v864, v866);
        // pto: %72
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v870 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %72
        ;
        uint64_t v871 = (uint64_t) v34;
        TASSIGN(v870, v871);
        pipe_barrier(PIPE_V);
        TMULS(v870, v808, v732);
        // pto: %73
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v872 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %73
        ;
        uint64_t v873 = (uint64_t) v33;
        TASSIGN(v872, v873);
        pipe_barrier(PIPE_V);
        TADD(v872, v868, v870);
        // pto: %74
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v874 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %74
        ;
        uint64_t v875 = (uint64_t) v34;
        TASSIGN(v874, v875);
        pipe_barrier(PIPE_V);
        TMULS(v874, v812, v733);
        // pto: %75
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v876 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %75
        ;
        uint64_t v877 = (uint64_t) v33;
        TASSIGN(v876, v877);
        pipe_barrier(PIPE_V);
        TADD(v876, v872, v874);
        // pto: %76
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v878 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %76
        ;
        uint64_t v879 = (uint64_t) v34;
        TASSIGN(v878, v879);
        pipe_barrier(PIPE_V);
        TMULS(v878, v816, v734);
        // pto: %77
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v880 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %77
        ;
        uint64_t v881 = (uint64_t) v33;
        TASSIGN(v880, v881);
        pipe_barrier(PIPE_V);
        TADD(v880, v876, v878);
        // pto: %78
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v882 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %78
        ;
        uint64_t v883 = (uint64_t) v33;
        TASSIGN(v882, v883);
        pipe_barrier(PIPE_V);
        RoundMode v884 = RoundMode::CAST_RINT;
        SaturationMode v885 = SaturationMode::ON;
        TCVT(v882, v880, v884, v885);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        v882.SetValidShape(v37, v42);
        // pto: %80
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v886 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %80
        ;
        uint64_t v887 = (uint64_t) v24;
        TASSIGN(v886, v887);
        TMULS(v886, v800, v735);
        // pto: %81
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v888 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %81
        ;
        uint64_t v889 = (uint64_t) v32;
        TASSIGN(v888, v889);
        TMULS(v888, v804, v736);
        // pto: %82
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v890 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %82
        ;
        uint64_t v891 = (uint64_t) v24;
        TASSIGN(v890, v891);
        pipe_barrier(PIPE_V);
        TADD(v890, v886, v888);
        // pto: %83
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v892 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %83
        ;
        uint64_t v893 = (uint64_t) v32;
        TASSIGN(v892, v893);
        pipe_barrier(PIPE_V);
        TMULS(v892, v808, v737);
        // pto: %84
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v894 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %84
        ;
        uint64_t v895 = (uint64_t) v24;
        TASSIGN(v894, v895);
        pipe_barrier(PIPE_V);
        TADD(v894, v890, v892);
        // pto: %85
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v896 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %85
        ;
        uint64_t v897 = (uint64_t) v32;
        TASSIGN(v896, v897);
        pipe_barrier(PIPE_V);
        TMULS(v896, v812, v738);
        // pto: %86
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v898 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %86
        ;
        uint64_t v899 = (uint64_t) v24;
        TASSIGN(v898, v899);
        pipe_barrier(PIPE_V);
        TADD(v898, v894, v896);
        // pto: %87
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v900 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v751, v42);
        // pto: %87
        ;
        uint64_t v901 = (uint64_t) v32;
        TASSIGN(v900, v901);
        pipe_barrier(PIPE_V);
        TMULS(v900, v816, v739);
        // pto: %88
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v902 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %88
        ;
        uint64_t v903 = (uint64_t) v24;
        TASSIGN(v902, v903);
        pipe_barrier(PIPE_V);
        TADD(v902, v898, v900);
        // pto: %89
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v904 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %89
        ;
        uint64_t v905 = (uint64_t) v24;
        TASSIGN(v904, v905);
        pipe_barrier(PIPE_V);
        RoundMode v906 = RoundMode::CAST_RINT;
        SaturationMode v907 = SaturationMode::ON;
        TCVT(v904, v902, v906, v907);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        v904.SetValidShape(v37, v42);
        // pto: %y_flat__phi_v9_pview
        ;
        __gm__ bfloat16_t* v908 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %y_flat__phi_v9_pview
        ;
        const int64_t v909 = 0;
        // pto: %y_flat__phi_v9_pview
        ;
        const int64_t v910 = 16384;
        // pto: %y_flat__phi_v9_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v911 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__phi_v9_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v912 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__phi_v9_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v913 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v908 + (v909 + v742 * v910), v911, v912);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v913, v838);
        // pto: %621
        ;
        __gm__ bfloat16_t* v914 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %621
        ;
        const int64_t v915 = 4096;
        // pto: %621
        ;
        const int64_t v916 = 16384;
        // pto: %621
        ;
        pto::Shape<1, 1, 1, 1, 4096> v917 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %621
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v918 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %621
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v919 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v914 + (v915 + v742 * v916), v917, v918);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v919, v860);
        // pto: %625
        ;
        __gm__ bfloat16_t* v920 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %625
        ;
        const int64_t v921 = 8192;
        // pto: %625
        ;
        const int64_t v922 = 16384;
        // pto: %625
        ;
        pto::Shape<1, 1, 1, 1, 4096> v923 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %625
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v924 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %625
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v925 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v920 + (v921 + v742 * v922), v923, v924);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        TSTORE(v925, v882);
        // pto: %629
        ;
        __gm__ bfloat16_t* v926 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %629
        ;
        const int64_t v927 = 12288;
        // pto: %629
        ;
        const int64_t v928 = 16384;
        // pto: %629
        ;
        pto::Shape<1, 1, 1, 1, 4096> v929 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %629
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v930 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %629
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v931 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v926 + (v927 + v742 * v928), v929, v930);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        TSTORE(v931, v904);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    // pto: %630, %631, %632
    ;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    if ((int64_t) ((uint64_t) ((int64_t) (uint64_t) v500 - (uint64_t) v501) + (uint64_t) v45) == v37) {
      // pto: %633
      ;
      if (v501 < v17) {
        // pto: %91
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v932 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %91
        ;
        uint64_t v933 = (uint64_t) v32;
        TASSIGN(v932, v933);
        // pto: %634
        ;
        int64_t v934 = v501 < v49 ? v49 : v501;
        // pto: %635
        ;
        __gm__ bfloat16_t* v935 = PTOAS__GLOBAL_TENSOR_DATA(v120);
        // pto: %635
        ;
        const int64_t v936 = 0;
        // pto: %635
        ;
        const int64_t v937 = 4096;
        // pto: %635
        ;
        pto::Shape<1, 1, 1, 1, 4096> v938 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %635
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v939 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %635
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v940 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v935 + (v936 + v934 * v937), v938, v939);
        TLOAD(v932, v940);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %92
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v941 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %92
        ;
        uint64_t v942 = (uint64_t) v24;
        TASSIGN(v941, v942);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v943 = RoundMode::CAST_ROUND;
        SaturationMode v944 = SaturationMode::ON;
        TCVT(v941, v932, v943, v944);
        // pto: %636
        ;
        int64_t v945 = (int64_t) ((uint64_t) v17 - (uint64_t) v501);
        // pto: %637
        ;
        int64_t v946 = v945 < v49 ? v49 : v945;
        // pto: %638
        ;
        int64_t v947 = v946 < v37 ? v946 : v37;
        // pto: %93
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v948 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %93
        ;
        uint64_t v949 = (uint64_t) v25;
        TASSIGN(v948, v949);
        // pto: %643
        ;
        const int64_t v950 = 0;
        // pto: %643
        ;
        __gm__ bfloat16_t* v951 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %643
        ;
        const int64_t v952 = 1;
        // pto: %643
        ;
        const int64_t v953 = 1;
        // pto: %643
        ;
        const int64_t v954 = 1;
        // pto: %643
        ;
        int64_t v955 = v947 * v44;
        // pto: %643
        ;
        int64_t v956 = v954 * v955;
        // pto: %643
        ;
        pto::Shape<1, 1, 1, -1, 4096> v957 = pto::Shape<1, 1, 1, -1, 4096>(v952, v953, v954, v947, v42);
        // pto: %643
        ;
        pto::Stride<-1, -1, -1, -1, -1> v958 = pto::Stride<-1, -1, -1, -1, -1>(v953 * v956, v956, v955, v44, v37);
        // pto: %643
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v959 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v951 + (v950 + v934 * v44 + v49 * v37), v957, v958);
        TLOAD(v948, v959);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %94
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v960 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %94
        ;
        uint64_t v961 = (uint64_t) v32;
        TASSIGN(v960, v961);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v962 = RoundMode::CAST_ROUND;
        SaturationMode v963 = SaturationMode::ON;
        TCVT(v960, v948, v962, v963);
        // pto: %95
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v964 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %95
        ;
        uint64_t v965 = (uint64_t) v30;
        TASSIGN(v964, v965);
        // pto: %654
        ;
        const int64_t v966 = 0;
        // pto: %654
        ;
        __gm__ bfloat16_t* v967 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %654
        ;
        const int64_t v968 = 1;
        // pto: %654
        ;
        const int64_t v969 = 1;
        // pto: %654
        ;
        const int64_t v970 = 1;
        // pto: %654
        ;
        int64_t v971 = v947 * v44;
        // pto: %654
        ;
        int64_t v972 = v970 * v971;
        // pto: %654
        ;
        pto::Shape<1, 1, 1, -1, 4096> v973 = pto::Shape<1, 1, 1, -1, 4096>(v968, v969, v970, v947, v42);
        // pto: %654
        ;
        pto::Stride<-1, -1, -1, -1, -1> v974 = pto::Stride<-1, -1, -1, -1, -1>(v969 * v972, v972, v971, v44, v37);
        // pto: %654
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v975 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v967 + (v966 + v934 * v44 + v42 * v37), v973, v974);
        TLOAD(v964, v975);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %96
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v976 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %96
        ;
        uint64_t v977 = (uint64_t) v25;
        TASSIGN(v976, v977);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v978 = RoundMode::CAST_ROUND;
        SaturationMode v979 = SaturationMode::ON;
        TCVT(v976, v964, v978, v979);
        // pto: %97
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v980 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %97
        ;
        uint64_t v981 = (uint64_t) v26;
        TASSIGN(v980, v981);
        // pto: %665
        ;
        const int64_t v982 = 0;
        // pto: %665
        ;
        __gm__ bfloat16_t* v983 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %665
        ;
        const int64_t v984 = 1;
        // pto: %665
        ;
        const int64_t v985 = 1;
        // pto: %665
        ;
        const int64_t v986 = 1;
        // pto: %665
        ;
        int64_t v987 = v947 * v44;
        // pto: %665
        ;
        int64_t v988 = v986 * v987;
        // pto: %665
        ;
        pto::Shape<1, 1, 1, -1, 4096> v989 = pto::Shape<1, 1, 1, -1, 4096>(v984, v985, v986, v947, v42);
        // pto: %665
        ;
        pto::Stride<-1, -1, -1, -1, -1> v990 = pto::Stride<-1, -1, -1, -1, -1>(v985 * v988, v988, v987, v44, v37);
        // pto: %665
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v991 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v983 + (v982 + v934 * v44 + v43 * v37), v989, v990);
        TLOAD(v980, v991);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %98
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v992 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %98
        ;
        uint64_t v993 = (uint64_t) v30;
        TASSIGN(v992, v993);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v994 = RoundMode::CAST_ROUND;
        SaturationMode v995 = SaturationMode::ON;
        TCVT(v992, v980, v994, v995);
        // pto: %99
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v996 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %99
        ;
        uint64_t v997 = (uint64_t) v33;
        TASSIGN(v996, v997);
        // pto: %676
        ;
        const int64_t v998 = 0;
        // pto: %676
        ;
        __gm__ bfloat16_t* v999 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %676
        ;
        const int64_t v1000 = 1;
        // pto: %676
        ;
        const int64_t v1001 = 1;
        // pto: %676
        ;
        const int64_t v1002 = 1;
        // pto: %676
        ;
        int64_t v1003 = v947 * v44;
        // pto: %676
        ;
        int64_t v1004 = v1002 * v1003;
        // pto: %676
        ;
        pto::Shape<1, 1, 1, -1, 4096> v1005 = pto::Shape<1, 1, 1, -1, 4096>(v1000, v1001, v1002, v947, v42);
        // pto: %676
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1006 = pto::Stride<-1, -1, -1, -1, -1>(v1001 * v1004, v1004, v1003, v44, v37);
        // pto: %676
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1007 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v999 + (v998 + v934 * v44 + v73 * v37), v1005, v1006);
        TLOAD(v996, v1007);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %100
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1008 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %100
        ;
        uint64_t v1009 = (uint64_t) v26;
        TASSIGN(v1008, v1009);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v1010 = RoundMode::CAST_ROUND;
        SaturationMode v1011 = SaturationMode::ON;
        TCVT(v1008, v996, v1010, v1011);
        // pto: %681
        ;
        int64_t v1012 = (int64_t) ((uint64_t) v501 * (uint64_t) v45);
        // pto: %680
        ;
        float v1013 = (v11)[v1012];
        // pto: %101
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1014 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %101
        ;
        uint64_t v1015 = (uint64_t) v33;
        TASSIGN(v1014, v1015);
        pipe_barrier(PIPE_V);
        TMULS(v1014, v941, v1013);
        // pto: %684
        ;
        int64_t v1016 = (int64_t) ((uint64_t) v501 * (uint64_t) v39);
        // pto: %683
        ;
        float v1017 = (v12)[v1016];
        // pto: %102
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1018 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %102
        ;
        uint64_t v1019 = (uint64_t) v34;
        TASSIGN(v1018, v1019);
        TMULS(v1018, v960, v1017);
        // pto: %103
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1020 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %103
        ;
        uint64_t v1021 = (uint64_t) v33;
        TASSIGN(v1020, v1021);
        pipe_barrier(PIPE_V);
        TADD(v1020, v1014, v1018);
        // pto: %691, %689
        ;
        float v1022 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v45)];
        // pto: %104
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1023 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %104
        ;
        uint64_t v1024 = (uint64_t) v34;
        TASSIGN(v1023, v1024);
        pipe_barrier(PIPE_V);
        TMULS(v1023, v976, v1022);
        // pto: %105
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1025 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %105
        ;
        uint64_t v1026 = (uint64_t) v33;
        TASSIGN(v1025, v1026);
        pipe_barrier(PIPE_V);
        TADD(v1025, v1020, v1023);
        // pto: %697, %695
        ;
        float v1027 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v38)];
        // pto: %106
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1028 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %106
        ;
        uint64_t v1029 = (uint64_t) v34;
        TASSIGN(v1028, v1029);
        pipe_barrier(PIPE_V);
        TMULS(v1028, v992, v1027);
        // pto: %107
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1030 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %107
        ;
        uint64_t v1031 = (uint64_t) v33;
        TASSIGN(v1030, v1031);
        pipe_barrier(PIPE_V);
        TADD(v1030, v1025, v1028);
        // pto: %703, %701
        ;
        float v1032 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v65)];
        // pto: %108
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1033 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %108
        ;
        uint64_t v1034 = (uint64_t) v34;
        TASSIGN(v1033, v1034);
        pipe_barrier(PIPE_V);
        TMULS(v1033, v1008, v1032);
        // pto: %109
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1035 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %109
        ;
        uint64_t v1036 = (uint64_t) v33;
        TASSIGN(v1035, v1036);
        pipe_barrier(PIPE_V);
        TADD(v1035, v1030, v1033);
        // pto: %110
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1037 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %110
        ;
        uint64_t v1038 = (uint64_t) v33;
        TASSIGN(v1037, v1038);
        pipe_barrier(PIPE_V);
        RoundMode v1039 = RoundMode::CAST_RINT;
        SaturationMode v1040 = SaturationMode::ON;
        TCVT(v1037, v1035, v1039, v1040);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1037.SetValidShape(v37, v42);
        // pto: %y_flat__rv_v4_main_pview
        ;
        __gm__ bfloat16_t* v1041 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %y_flat__rv_v4_main_pview
        ;
        const int64_t v1042 = 0;
        // pto: %y_flat__rv_v4_main_pview
        ;
        const int64_t v1043 = 16384;
        // pto: %y_flat__rv_v4_main_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1044 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__rv_v4_main_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1045 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__rv_v4_main_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1046 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1041 + (v1042 + v934 * v1043), v1044, v1045);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1046, v1037);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
        // pto: %711, %709
        ;
        float v1047 = (v11)[(int64_t) ((uint64_t) v1012 + (uint64_t) v37)];
        // pto: %112
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1048 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %112
        ;
        uint64_t v1049 = (uint64_t) v33;
        TASSIGN(v1048, v1049);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
        TMULS(v1048, v941, v1047);
        // pto: %714, %712
        ;
        float v1050 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v37)];
        // pto: %113
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1051 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %113
        ;
        uint64_t v1052 = (uint64_t) v34;
        TASSIGN(v1051, v1052);
        TMULS(v1051, v960, v1050);
        // pto: %114
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1053 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %114
        ;
        uint64_t v1054 = (uint64_t) v33;
        TASSIGN(v1053, v1054);
        pipe_barrier(PIPE_V);
        TADD(v1053, v1048, v1051);
        // pto: %720, %718
        ;
        float v1055 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v66)];
        // pto: %115
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1056 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %115
        ;
        uint64_t v1057 = (uint64_t) v34;
        TASSIGN(v1056, v1057);
        pipe_barrier(PIPE_V);
        TMULS(v1056, v976, v1055);
        // pto: %116
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1058 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %116
        ;
        uint64_t v1059 = (uint64_t) v33;
        TASSIGN(v1058, v1059);
        pipe_barrier(PIPE_V);
        TADD(v1058, v1053, v1056);
        // pto: %726, %724
        ;
        float v1060 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v67)];
        // pto: %117
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1061 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %117
        ;
        uint64_t v1062 = (uint64_t) v34;
        TASSIGN(v1061, v1062);
        pipe_barrier(PIPE_V);
        TMULS(v1061, v992, v1060);
        // pto: %118
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1063 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %118
        ;
        uint64_t v1064 = (uint64_t) v33;
        TASSIGN(v1063, v1064);
        pipe_barrier(PIPE_V);
        TADD(v1063, v1058, v1061);
        // pto: %732, %730
        ;
        float v1065 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v68)];
        // pto: %119
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1066 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %119
        ;
        uint64_t v1067 = (uint64_t) v34;
        TASSIGN(v1066, v1067);
        pipe_barrier(PIPE_V);
        TMULS(v1066, v1008, v1065);
        // pto: %120
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1068 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %120
        ;
        uint64_t v1069 = (uint64_t) v33;
        TASSIGN(v1068, v1069);
        pipe_barrier(PIPE_V);
        TADD(v1068, v1063, v1066);
        // pto: %121
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1070 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %121
        ;
        uint64_t v1071 = (uint64_t) v33;
        TASSIGN(v1070, v1071);
        pipe_barrier(PIPE_V);
        RoundMode v1072 = RoundMode::CAST_RINT;
        SaturationMode v1073 = SaturationMode::ON;
        TCVT(v1070, v1068, v1072, v1073);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1070.SetValidShape(v37, v42);
        // pto: %738
        ;
        __gm__ bfloat16_t* v1074 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %738
        ;
        const int64_t v1075 = 4096;
        // pto: %738
        ;
        const int64_t v1076 = 16384;
        // pto: %738
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1077 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %738
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1078 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %738
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1079 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1074 + (v1075 + v934 * v1076), v1077, v1078);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1079, v1070);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        // pto: %741, %739
        ;
        float v1080 = (v11)[(int64_t) ((uint64_t) v1012 + (uint64_t) v47)];
        // pto: %123
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1081 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %123
        ;
        uint64_t v1082 = (uint64_t) v33;
        TASSIGN(v1081, v1082);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        TMULS(v1081, v941, v1080);
        // pto: %744, %742
        ;
        float v1083 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v47)];
        // pto: %124
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1084 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %124
        ;
        uint64_t v1085 = (uint64_t) v34;
        TASSIGN(v1084, v1085);
        TMULS(v1084, v960, v1083);
        // pto: %125
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1086 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %125
        ;
        uint64_t v1087 = (uint64_t) v33;
        TASSIGN(v1086, v1087);
        pipe_barrier(PIPE_V);
        TADD(v1086, v1081, v1084);
        // pto: %750, %748
        ;
        float v1088 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v69)];
        // pto: %126
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1089 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %126
        ;
        uint64_t v1090 = (uint64_t) v34;
        TASSIGN(v1089, v1090);
        pipe_barrier(PIPE_V);
        TMULS(v1089, v976, v1088);
        // pto: %127
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1091 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %127
        ;
        uint64_t v1092 = (uint64_t) v33;
        TASSIGN(v1091, v1092);
        pipe_barrier(PIPE_V);
        TADD(v1091, v1086, v1089);
        // pto: %756, %754
        ;
        float v1093 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v70)];
        // pto: %128
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1094 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %128
        ;
        uint64_t v1095 = (uint64_t) v34;
        TASSIGN(v1094, v1095);
        pipe_barrier(PIPE_V);
        TMULS(v1094, v992, v1093);
        // pto: %129
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1096 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %129
        ;
        uint64_t v1097 = (uint64_t) v33;
        TASSIGN(v1096, v1097);
        pipe_barrier(PIPE_V);
        TADD(v1096, v1091, v1094);
        // pto: %762, %760
        ;
        float v1098 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v71)];
        // pto: %130
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1099 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %130
        ;
        uint64_t v1100 = (uint64_t) v34;
        TASSIGN(v1099, v1100);
        pipe_barrier(PIPE_V);
        TMULS(v1099, v1008, v1098);
        // pto: %131
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1101 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %131
        ;
        uint64_t v1102 = (uint64_t) v33;
        TASSIGN(v1101, v1102);
        pipe_barrier(PIPE_V);
        TADD(v1101, v1096, v1099);
        // pto: %132
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1103 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %132
        ;
        uint64_t v1104 = (uint64_t) v33;
        TASSIGN(v1103, v1104);
        pipe_barrier(PIPE_V);
        RoundMode v1105 = RoundMode::CAST_RINT;
        SaturationMode v1106 = SaturationMode::ON;
        TCVT(v1103, v1101, v1105, v1106);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1103.SetValidShape(v37, v42);
        // pto: %768
        ;
        __gm__ bfloat16_t* v1107 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %768
        ;
        const int64_t v1108 = 8192;
        // pto: %768
        ;
        const int64_t v1109 = 16384;
        // pto: %768
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1110 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %768
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1111 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %768
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1112 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1107 + (v1108 + v934 * v1109), v1110, v1111);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1112, v1103);
        // pto: %771, %769
        ;
        float v1113 = (v11)[(int64_t) ((uint64_t) v1012 + (uint64_t) v64)];
        // pto: %134
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1114 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %134
        ;
        uint64_t v1115 = (uint64_t) v24;
        TASSIGN(v1114, v1115);
        TMULS(v1114, v941, v1113);
        // pto: %774, %772
        ;
        float v1116 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v64)];
        // pto: %135
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1117 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %135
        ;
        uint64_t v1118 = (uint64_t) v32;
        TASSIGN(v1117, v1118);
        TMULS(v1117, v960, v1116);
        // pto: %136
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1119 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %136
        ;
        uint64_t v1120 = (uint64_t) v24;
        TASSIGN(v1119, v1120);
        pipe_barrier(PIPE_V);
        TADD(v1119, v1114, v1117);
        // pto: %780, %778
        ;
        float v1121 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v56)];
        // pto: %137
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1122 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %137
        ;
        uint64_t v1123 = (uint64_t) v32;
        TASSIGN(v1122, v1123);
        pipe_barrier(PIPE_V);
        TMULS(v1122, v976, v1121);
        // pto: %138
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1124 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %138
        ;
        uint64_t v1125 = (uint64_t) v24;
        TASSIGN(v1124, v1125);
        pipe_barrier(PIPE_V);
        TADD(v1124, v1119, v1122);
        // pto: %786, %784
        ;
        float v1126 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v72)];
        // pto: %139
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1127 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %139
        ;
        uint64_t v1128 = (uint64_t) v32;
        TASSIGN(v1127, v1128);
        pipe_barrier(PIPE_V);
        TMULS(v1127, v992, v1126);
        // pto: %140
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1129 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %140
        ;
        uint64_t v1130 = (uint64_t) v24;
        TASSIGN(v1129, v1130);
        pipe_barrier(PIPE_V);
        TADD(v1129, v1124, v1127);
        // pto: %792, %790
        ;
        float v1131 = (v12)[(int64_t) ((uint64_t) v1016 + (uint64_t) v50)];
        // pto: %141
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1132 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v947, v42);
        // pto: %141
        ;
        uint64_t v1133 = (uint64_t) v32;
        TASSIGN(v1132, v1133);
        pipe_barrier(PIPE_V);
        TMULS(v1132, v1008, v1131);
        // pto: %142
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1134 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %142
        ;
        uint64_t v1135 = (uint64_t) v24;
        TASSIGN(v1134, v1135);
        pipe_barrier(PIPE_V);
        TADD(v1134, v1129, v1132);
        // pto: %143
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1136 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %143
        ;
        uint64_t v1137 = (uint64_t) v24;
        TASSIGN(v1136, v1137);
        pipe_barrier(PIPE_V);
        RoundMode v1138 = RoundMode::CAST_RINT;
        SaturationMode v1139 = SaturationMode::ON;
        TCVT(v1136, v1134, v1138, v1139);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1136.SetValidShape(v37, v42);
        // pto: %798
        ;
        __gm__ bfloat16_t* v1140 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %798
        ;
        const int64_t v1141 = 12288;
        // pto: %798
        ;
        const int64_t v1142 = 16384;
        // pto: %798
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1143 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %798
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1144 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %798
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1145 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1140 + (v1141 + v934 * v1142), v1143, v1144);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v1145, v1136);
      };
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  pipe_barrier(PIPE_ALL);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}