#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void cube(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ bfloat16_t* v6, __gm__ int8_t* v7, __gm__ float* v8, __gm__ bfloat16_t* v9, __gm__ bfloat16_t* v10, __gm__ float* v11, __gm__ float* v12, __gm__ bfloat16_t* v13, __gm__ float* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int32_t v22 = 1;
  // pto: %c0_i64
  const int64_t v23 = 0;
  // pto: %c65536_i64
  const int64_t v24 = 65536;
  // pto: %c4096_i64
  const int64_t v25 = 4096;
  // pto: %c32768_i64
  const int64_t v26 = 32768;
  // pto: %c16384_i64
  const int64_t v27 = 16384;
  // pto: %c32768_index
  const int64_t v28 = 32768;
  // pto: %c1_index
  const int64_t v29 = 1;
  // pto: %c8_index
  const int64_t v30 = 8;
  const int64_t v31 = 64;
  const int64_t v32 = 256;
  // pto: %c16_index
  const int64_t v33 = 16;
  // pto: %c4194304_index
  const int64_t v34 = 4194304;
  // pto: %c65536_index
  const int64_t v35 = 65536;
  const int64_t v36 = 128;
  // pto: %c512_index
  const int64_t v37 = 512;
  // pto: %c32_index
  const int64_t v38 = 32;
  // pto: %c33554432_index
  const int64_t v39 = 33554432;
  // pto: %c262144_index
  const int64_t v40 = 262144;
  // pto: %c4096_index
  const int64_t v41 = 4096;
  // pto: %c8192_index
  const int64_t v42 = 8192;
  // pto: %c4_index
  const int64_t v43 = 4;
  // pto: %c55296_index
  const int64_t v44 = 55296;
  // pto: %c0_index
  const int64_t v45 = 0;
  // pto: %c15_index
  const int64_t v46 = 15;
  // pto: %c192_index
  const int64_t v47 = 192;
  // pto: %c24_index
  const int64_t v48 = 24;
  // pto: %c2_index
  const int64_t v49 = 2;
  // pto: %c3_index
  const int64_t v50 = 3;
  // pto: %c5_index
  const int64_t v51 = 5;
  // pto: %c6_index
  const int64_t v52 = 6;
  // pto: %c7_index
  const int64_t v53 = 7;
  // pto: %c9_index
  const int64_t v54 = 9;
  // pto: %c10_index
  const int64_t v55 = 10;
  // pto: %c11_index
  const int64_t v56 = 11;
  // pto: %c12_index
  const int64_t v57 = 12;
  // pto: %c13_index
  const int64_t v58 = 13;
  // pto: %c14_index
  const int64_t v59 = 14;
  // pto: %c240_index
  const int64_t v60 = 240;
  // pto: %c1024_index
  const int64_t v61 = 1024;
  // pto: %c241_index
  const int64_t v62 = 241;
  // pto: %c9216_index
  const int64_t v63 = 9216;
  // pto: %c72_index
  const int64_t v64 = 72;
  // pto: %c27648_index
  const int64_t v65 = 27648;
  // pto: %c63_index
  const int64_t v66 = 63;
  // pto: %c36864_index
  const int64_t v67 = 36864;
  // pto: %heads__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v69 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v70 = 1;
  // pto: %heads__ssa_v0_view
  int64_t v71 = (int64_t) v17;
  // pto: %heads__ssa_v0_view
  int64_t v72 = v71 * v28;
  // pto: %heads__ssa_v0_view
  int64_t v73 = v70 * v72;
  // pto: %heads__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v74 = pto::Shape<1, 1, 1, -1, -1>(v68, v69, v70, v71, v28);
  // pto: %heads__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v75 = pto::Stride<-1, -1, -1, -1, -1>(v69 * v73, v73, v72, v28, v29);
  // pto: %heads__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v76 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v74, v75);
  // pto: %wo_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v77 = pto::Shape<-1, -1, -1, -1, -1>(v30, v31, v32, v33, v33);
  // pto: %wo_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v78 = pto::Stride<-1, -1, -1, -1, -1>(v34, v35, v32, v33, v29);
  // pto: %wo_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v79 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v2, v77, v78);
  // pto: %wo_b__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v80 = pto::Shape<-1, -1, -1, -1, -1>(v29, v36, v37, v33, v38);
  // pto: %wo_b__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v81 = pto::Stride<-1, -1, -1, -1, -1>(v39, v40, v37, v38, v29);
  // pto: %wo_b__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v82 = GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v3, v80, v81);
  // pto: %quantized__ssa_v0_view
  const int64_t v83 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v84 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v85 = 1;
  // pto: %quantized__ssa_v0_view
  int64_t v86 = (int64_t) v17;
  // pto: %quantized__ssa_v0_view
  int64_t v87 = v86 * v42;
  // pto: %quantized__ssa_v0_view
  int64_t v88 = v85 * v87;
  // pto: %quantized__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v89 = pto::Shape<1, 1, 1, -1, -1>(v83, v84, v85, v86, v42);
  // pto: %quantized__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v90 = pto::Stride<-1, -1, -1, -1, -1>(v84 * v88, v88, v87, v42, v29);
  // pto: %quantized__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v91 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v89, v90);
  // pto: %accum__ssa_v0_view
  const int64_t v92 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v93 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v94 = 1;
  // pto: %accum__ssa_v0_view
  int64_t v95 = (int64_t) v18;
  // pto: %accum__ssa_v0_view
  int64_t v96 = v95 * v42;
  // pto: %accum__ssa_v0_view
  int64_t v97 = v94 * v96;
  // pto: %accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v98 = pto::Shape<1, 1, 1, -1, -1>(v92, v93, v94, v95, v42);
  // pto: %accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v99 = pto::Stride<-1, -1, -1, -1, -1>(v93 * v97, v97, v96, v42, v29);
  // pto: %accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v100 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v98, v99);
  // pto: %integer_accum__ssa_v0_view
  const int64_t v101 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v102 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v103 = 1;
  // pto: %integer_accum__ssa_v0_view
  int64_t v104 = (int64_t) v19;
  // pto: %integer_accum__ssa_v0_view
  int64_t v105 = v104 * v41;
  // pto: %integer_accum__ssa_v0_view
  int64_t v106 = v103 * v105;
  // pto: %integer_accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v107 = pto::Shape<1, 1, 1, -1, -1>(v101, v102, v103, v104, v41);
  // pto: %integer_accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v108 = pto::Stride<-1, -1, -1, -1, -1>(v102 * v106, v106, v105, v41, v29);
  // pto: %integer_accum__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v109 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v107, v108);
  // pto: %signals__ssa_v0_view
  const int64_t v110 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v111 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v112 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v113 = 1;
  // pto: %signals__ssa_v0_view
  int64_t v114 = v44 * v29;
  // pto: %signals__ssa_v0_view
  int64_t v115 = v113 * v114;
  // pto: %signals__ssa_v0_view
  int64_t v116 = v112 * v115;
  // pto: %signals__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v117 = pto::Shape<1, 1, 1, 1, -1>(v110, v111, v112, v113, v44);
  // pto: %signals__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v118 = pto::Stride<-1, -1, -1, -1, -1>(v111 * v116, v116, v115, v114, v29);
  // pto: %signals__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v119 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v117, v118);
  // pto: %seed_narrow_acc__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
  // pto: %seed_narrow_acc__phi_v7
  uint64_t v121 = (uint64_t) v23;
  TASSIGN(v120, v121);
  // pto: %v4_wide_acc__phi_v7
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v122 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
  // pto: %v4_wide_acc__phi_v7
  uint64_t v123 = (uint64_t) v23;
  TASSIGN(v122, v123);
  // pto: %v4_narrow_acc__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
  // pto: %v4_narrow_acc__phi_v7
  uint64_t v125 = (uint64_t) v23;
  TASSIGN(v124, v125);
  // pto: %worker__ssa_v0
  int64_t v126 = (int64_t) v20;
  // pto: %33
  int64_t v127 = (int64_t) ((uint64_t) v126 * (uint64_t) v36);
  // pto: %34
  int64_t v128 = v127 < v45 ? v45 : v127;
  // pto: %signals__ssa_v0_pview
  __gm__ int32_t* v129 = PTOAS__GLOBAL_TENSOR_DATA(v119);
  // pto: %signals__ssa_v0_pview
  const int64_t v130 = 0;
  // pto: %signals__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 1> v131 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  pto::Stride<1, 1, 1, 1, 1> v132 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v133 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v129 + (v130 + v128), v131, v132);
  __gm__ int32_t* v134 = PTOAS__GLOBAL_TENSOR_DATA(v133);
  PTOAS__DCCI_SINGLE_CACHE_LINE(v134);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
  // pto: %t__tile
  int32_t v135 = (v16)[v127];
  // pto: %36
  int32_t v136 = (int32_t) ((uint32_t) v135 + (uint32_t) v22);
  pipe_barrier(PIPE_ALL);
  pto::comm::NotifyOp v137 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v133, v136, v137);
  // pto: %38, %39
  int64_t v138 = (int64_t) ((uint64_t) v17 + (uint64_t) v46) / v33;
  // pto: %40
  if (v17 >= v47) {
    for (int64_t v139 = v126; v139 < v31; v139 += v48) {
      // pto: %41
      ;
      int64_t v140 = v139 / v30;
      // pto: %42
      ;
      int64_t v141 = v139 % v30;
      // pto: %43, %44, %45
      ;
      int64_t v142 = v141 < v45 ? (int64_t) ((uint64_t) v141 + (uint64_t) v30) : v141;
      // pto: %46
      ;
      int64_t v143 = (int64_t) ((uint64_t) v142 * (uint64_t) v36);
      // pto: %47, %48
      ;
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v144 = v45; v144 < ((int64_t) ((uint64_t) v138 + (uint64_t) v46) / v33); v144 += v29) {
        // pto: %49
        ;
        int64_t v145 = (int64_t) ((uint64_t) v144 * (uint64_t) v33);
        // pto: %flat_offset, %51, %52, %50
        ;
        int32_t v146 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v144 * (uint64_t) v36) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
        // pto: %53
        ;
        int64_t v147 = (int64_t) v146;
        // pto: %54
        ;
        int64_t v148 = v147 < v45 ? v45 : v147;
        // pto: %55
        ;
        int64_t v149 = (int64_t) ((uint64_t) v145 + (uint64_t) v29);
        // pto: %56
        ;
        // pto: %seed_same_start__phi_v3
        ;
        int64_t v150;
        if (v149 < v138) {
          // pto: %59, %60, %61, %62, %57
          ;
          int32_t v151 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v149 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %63
          ;
          int64_t v152 = (int64_t) v151;
          // pto: %64
          ;
          int64_t v153 = v152 < v45 ? v45 : v152;
          // pto: %65, %seed_same_start__phi_v2
          ;
          v150 = v153 != v148 ? v45 : v29;
        } else {
          v150 = v29;
        };
        // pto: %66
        ;
        int64_t v154 = (int64_t) ((uint64_t) v145 + (uint64_t) v49);
        // pto: %67
        ;
        // pto: %seed_same_start__phi_v6
        ;
        int64_t v155;
        if (v154 < v138) {
          // pto: %70, %71, %72, %73, %68
          ;
          int32_t v156 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v154 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %74
          ;
          int64_t v157 = (int64_t) v156;
          // pto: %75
          ;
          int64_t v158 = v157 < v45 ? v45 : v157;
          // pto: %76, %seed_same_start__phi_v5
          ;
          int64_t v159 = v158 != v148 ? v45 : v150;
          v155 = v159;
        } else {
          v155 = v150;
        };
        // pto: %77
        ;
        int64_t v160 = (int64_t) ((uint64_t) v145 + (uint64_t) v50);
        // pto: %78
        ;
        // pto: %seed_same_start__phi_v9
        ;
        int64_t v161;
        if (v160 < v138) {
          // pto: %81, %82, %83, %84, %79
          ;
          int32_t v162 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v160 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %85
          ;
          int64_t v163 = (int64_t) v162;
          // pto: %86
          ;
          int64_t v164 = v163 < v45 ? v45 : v163;
          // pto: %87, %seed_same_start__phi_v8
          ;
          int64_t v165 = v164 != v148 ? v45 : v155;
          v161 = v165;
        } else {
          v161 = v155;
        };
        // pto: %88
        ;
        int64_t v166 = (int64_t) ((uint64_t) v145 + (uint64_t) v43);
        // pto: %89
        ;
        // pto: %seed_same_start__phi_v12
        ;
        int64_t v167;
        if (v166 < v138) {
          // pto: %92, %93, %94, %95, %90
          ;
          int32_t v168 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v166 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %96
          ;
          int64_t v169 = (int64_t) v168;
          // pto: %97
          ;
          int64_t v170 = v169 < v45 ? v45 : v169;
          // pto: %98, %seed_same_start__phi_v11
          ;
          int64_t v171 = v170 != v148 ? v45 : v161;
          v167 = v171;
        } else {
          v167 = v161;
        };
        // pto: %99
        ;
        int64_t v172 = (int64_t) ((uint64_t) v145 + (uint64_t) v51);
        // pto: %100
        ;
        // pto: %seed_same_start__phi_v15
        ;
        int64_t v173;
        if (v172 < v138) {
          // pto: %103, %104, %105, %106, %101
          ;
          int32_t v174 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v172 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %107
          ;
          int64_t v175 = (int64_t) v174;
          // pto: %108
          ;
          int64_t v176 = v175 < v45 ? v45 : v175;
          // pto: %109, %seed_same_start__phi_v14
          ;
          int64_t v177 = v176 != v148 ? v45 : v167;
          v173 = v177;
        } else {
          v173 = v167;
        };
        // pto: %110
        ;
        int64_t v178 = (int64_t) ((uint64_t) v145 + (uint64_t) v52);
        // pto: %111
        ;
        // pto: %seed_same_start__phi_v18
        ;
        int64_t v179;
        if (v178 < v138) {
          // pto: %114, %115, %116, %117, %112
          ;
          int32_t v180 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v178 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %118
          ;
          int64_t v181 = (int64_t) v180;
          // pto: %119
          ;
          int64_t v182 = v181 < v45 ? v45 : v181;
          // pto: %120, %seed_same_start__phi_v17
          ;
          int64_t v183 = v182 != v148 ? v45 : v173;
          v179 = v183;
        } else {
          v179 = v173;
        };
        // pto: %121
        ;
        int64_t v184 = (int64_t) ((uint64_t) v145 + (uint64_t) v53);
        // pto: %122
        ;
        // pto: %seed_same_start__phi_v21
        ;
        int64_t v185;
        if (v184 < v138) {
          // pto: %125, %126, %127, %128, %123
          ;
          int32_t v186 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v184 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %129
          ;
          int64_t v187 = (int64_t) v186;
          // pto: %130
          ;
          int64_t v188 = v187 < v45 ? v45 : v187;
          // pto: %131, %seed_same_start__phi_v20
          ;
          int64_t v189 = v188 != v148 ? v45 : v179;
          v185 = v189;
        } else {
          v185 = v179;
        };
        // pto: %132
        ;
        int64_t v190 = (int64_t) ((uint64_t) v145 + (uint64_t) v30);
        // pto: %133
        ;
        // pto: %seed_same_start__phi_v24
        ;
        int64_t v191;
        if (v190 < v138) {
          // pto: %136, %137, %138, %139, %134
          ;
          int32_t v192 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v190 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %140
          ;
          int64_t v193 = (int64_t) v192;
          // pto: %141
          ;
          int64_t v194 = v193 < v45 ? v45 : v193;
          // pto: %142, %seed_same_start__phi_v23
          ;
          int64_t v195 = v194 != v148 ? v45 : v185;
          v191 = v195;
        } else {
          v191 = v185;
        };
        // pto: %143
        ;
        int64_t v196 = (int64_t) ((uint64_t) v145 + (uint64_t) v54);
        // pto: %144
        ;
        // pto: %seed_same_start__phi_v27
        ;
        int64_t v197;
        if (v196 < v138) {
          // pto: %147, %148, %149, %150, %145
          ;
          int32_t v198 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v196 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %151
          ;
          int64_t v199 = (int64_t) v198;
          // pto: %152
          ;
          int64_t v200 = v199 < v45 ? v45 : v199;
          // pto: %153, %seed_same_start__phi_v26
          ;
          int64_t v201 = v200 != v148 ? v45 : v191;
          v197 = v201;
        } else {
          v197 = v191;
        };
        // pto: %154
        ;
        int64_t v202 = (int64_t) ((uint64_t) v145 + (uint64_t) v55);
        // pto: %155
        ;
        // pto: %seed_same_start__phi_v30
        ;
        int64_t v203;
        if (v202 < v138) {
          // pto: %158, %159, %160, %161, %156
          ;
          int32_t v204 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v202 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %162
          ;
          int64_t v205 = (int64_t) v204;
          // pto: %163
          ;
          int64_t v206 = v205 < v45 ? v45 : v205;
          // pto: %164, %seed_same_start__phi_v29
          ;
          int64_t v207 = v206 != v148 ? v45 : v197;
          v203 = v207;
        } else {
          v203 = v197;
        };
        // pto: %165
        ;
        int64_t v208 = (int64_t) ((uint64_t) v145 + (uint64_t) v56);
        // pto: %166
        ;
        // pto: %seed_same_start__phi_v33
        ;
        int64_t v209;
        if (v208 < v138) {
          // pto: %169, %170, %171, %172, %167
          ;
          int32_t v210 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v208 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %173
          ;
          int64_t v211 = (int64_t) v210;
          // pto: %174
          ;
          int64_t v212 = v211 < v45 ? v45 : v211;
          // pto: %175, %seed_same_start__phi_v32
          ;
          int64_t v213 = v212 != v148 ? v45 : v203;
          v209 = v213;
        } else {
          v209 = v203;
        };
        // pto: %176
        ;
        int64_t v214 = (int64_t) ((uint64_t) v145 + (uint64_t) v57);
        // pto: %177
        ;
        // pto: %seed_same_start__phi_v36
        ;
        int64_t v215;
        if (v214 < v138) {
          // pto: %180, %181, %182, %183, %178
          ;
          int32_t v216 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v214 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %184
          ;
          int64_t v217 = (int64_t) v216;
          // pto: %185
          ;
          int64_t v218 = v217 < v45 ? v45 : v217;
          // pto: %186, %seed_same_start__phi_v35
          ;
          int64_t v219 = v218 != v148 ? v45 : v209;
          v215 = v219;
        } else {
          v215 = v209;
        };
        // pto: %187
        ;
        int64_t v220 = (int64_t) ((uint64_t) v145 + (uint64_t) v58);
        // pto: %188
        ;
        // pto: %seed_same_start__phi_v39
        ;
        int64_t v221;
        if (v220 < v138) {
          // pto: %191, %192, %193, %194, %189
          ;
          int32_t v222 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v220 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %195
          ;
          int64_t v223 = (int64_t) v222;
          // pto: %196
          ;
          int64_t v224 = v223 < v45 ? v45 : v223;
          // pto: %197, %seed_same_start__phi_v38
          ;
          int64_t v225 = v224 != v148 ? v45 : v215;
          v221 = v225;
        } else {
          v221 = v215;
        };
        // pto: %198
        ;
        int64_t v226 = (int64_t) ((uint64_t) v145 + (uint64_t) v59);
        // pto: %199
        ;
        // pto: %seed_same_start__phi_v42
        ;
        int64_t v227;
        if (v226 < v138) {
          // pto: %202, %203, %204, %205, %200
          ;
          int32_t v228 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v226 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %206
          ;
          int64_t v229 = (int64_t) v228;
          // pto: %207
          ;
          int64_t v230 = v229 < v45 ? v45 : v229;
          // pto: %208, %seed_same_start__phi_v41
          ;
          int64_t v231 = v230 != v148 ? v45 : v221;
          v227 = v231;
        } else {
          v227 = v221;
        };
        // pto: %209
        ;
        int64_t v232 = (int64_t) ((uint64_t) v145 + (uint64_t) v46);
        // pto: %210
        ;
        // pto: %seed_same_start__phi_v45
        ;
        int64_t v233;
        if (v232 < v138) {
          // pto: %213, %214, %215, %216, %211
          ;
          int32_t v234 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v232 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %217
          ;
          int64_t v235 = (int64_t) v234;
          // pto: %218
          ;
          int64_t v236 = v235 < v45 ? v45 : v235;
          // pto: %219, %seed_same_start__phi_v44
          ;
          int64_t v237 = v236 != v148 ? v45 : v227;
          v233 = v237;
        } else {
          v233 = v227;
        };
        // pto: %220, %seed_same_start__phi_v49
        ;
        int64_t v238 = v148 > v60 ? v45 : v233;
        // pto: %221
        ;
        int64_t v239 = v148 % v33;
        // pto: %222, %223, %224
        ;
        int64_t v240 = v239 < v45 ? (int64_t) ((uint64_t) v239 + (uint64_t) v33) : v239;
        // pto: %225, %seed_same_start__phi_v51
        ;
        int64_t v241 = v240 != v45 ? v45 : v238;
        // pto: %226
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        if (v241 == v29) {
          int64_t v242 = (int64_t) ((uint64_t) v144 * (uint64_t) v32);
          // pto: %228
          ;
          int64_t v243 = (int64_t) ((uint64_t) v17 - (uint64_t) v242);
          // pto: %229
          ;
          int64_t v244 = v243 < v32 ? v243 : v32;
          // pto: %230
          ;
          int64_t v245 = (int64_t) ((uint64_t) v148 * (uint64_t) v33);
          // pto: %seed_small_x__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v246 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v244, v36);
          // pto: %seed_small_x__tile
          ;
          uint64_t v247 = (uint64_t) v23;
          TASSIGN(v246, v247);
          // pto: %231
          ;
          int64_t v248 = v242 < v45 ? v45 : v242;
          // pto: %232
          ;
          int64_t v249 = (int64_t) ((uint64_t) v140 * (uint64_t) v41);
          // pto: %233
          ;
          int64_t v250 = (int64_t) ((uint64_t) v249 + (uint64_t) v245);
          // pto: %234
          ;
          int64_t v251 = v250 < v45 ? v45 : v250;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v252 = 0;
          // pto: %heads__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v253 = PTOAS__GLOBAL_TENSOR_DATA(v76);
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v254 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v255 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v256 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          int64_t v257 = v244 * v28;
          // pto: %heads__ssa_v0_pview
          ;
          int64_t v258 = v256 * v257;
          // pto: %heads__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, -1, 128> v259 = pto::Shape<1, 1, 1, -1, 128>(v254, v255, v256, v244, v36);
          // pto: %heads__ssa_v0_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v260 = pto::Stride<-1, -1, -1, -1, -1>(v255 * v258, v258, v257, v28, v29);
          // pto: %heads__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v261 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v253 + (v252 + v248 * v28 + v251 * v29), v259, v260);
          TLOAD(v246, v261);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %seed_small_w__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v262 = Tile<TileType::Mat, bfloat16_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
          // pto: %seed_small_w__tile
          ;
          uint64_t v263 = (uint64_t) v24;
          TASSIGN(v262, v263);
          // pto: %235
          ;
          int64_t v264 = v140 < v45 ? v45 : v140;
          // pto: %236
          ;
          int64_t v265 = v143 / v33;
          // pto: %237
          ;
          int64_t v266 = v265 < v45 ? v45 : v265;
          // pto: %238
          ;
          int64_t v267 = v245 / v33;
          // pto: %239
          ;
          int64_t v268 = v267 < v45 ? v45 : v267;
          // pto: %wo_a__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v269 = PTOAS__GLOBAL_TENSOR_DATA(v79);
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v270 = 0;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v271 = 4194304;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v272 = 65536;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v273 = 256;
          // pto: %wo_a__ssa_v0_pview
          ;
          pto::Shape<1, 8, 8, 16, 16> v274 = pto::Shape<1, 8, 8, 16, 16>();
          // pto: %wo_a__ssa_v0_pview
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v275 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %wo_a__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 8, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v276 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 8, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v269 + ((v270 + v264 * v271) + v266 * v272 + v268 * v273), v274, v275);
          TLOAD(v262, v276);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %lhs_slice_0_textract
          ;
          Tile<TileType::Left, bfloat16_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v277 = Tile<TileType::Left, bfloat16_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v244, v36);
          // pto: %lhs_slice_0_textract
          ;
          uint64_t v278 = (uint64_t) v23;
          TASSIGN(v277, v278);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          uint16_t v279 = static_cast<uint16_t>(v45);
          uint16_t v280 = static_cast<uint16_t>(v45);
          TEXTRACT(v277, v246, v279, v280);
          // pto: %rhs_slice_0_textract
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v281 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
          // pto: %rhs_slice_0_textract
          ;
          uint64_t v282 = (uint64_t) v23;
          TASSIGN(v281, v282);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          uint16_t v283 = static_cast<uint16_t>(v45);
          uint16_t v284 = static_cast<uint16_t>(v45);
          TEXTRACT(v281, v262, v283, v284);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %seed_fast_acc__tile
          ;
          Tile<TileType::Acc, float, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v285 = Tile<TileType::Acc, float, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v244, v36);
          // pto: %seed_fast_acc__tile
          ;
          uint64_t v286 = (uint64_t) v23;
          TASSIGN(v285, v286);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          TMATMUL(v285, v277, v281);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
          for (int64_t v287 = v29; v287 < v38; v287 += v29) {
            // pto: %241, %240, %242
            ;
            int64_t v288 = (int64_t) ((uint64_t) v148 + (uint64_t) ((int64_t) (uint64_t) v287 * (uint64_t) v30)) % v32;
            // pto: %243, %244, %245
            ;
            int64_t v289 = v288 < v45 ? (int64_t) ((uint64_t) v288 + (uint64_t) v32) : v288;
            // pto: %246
            ;
            int64_t v290 = (int64_t) ((uint64_t) v289 * (uint64_t) v33);
            // pto: %seed_small_packet_x__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v291 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v244, v36);
            // pto: %seed_small_packet_x__tile
            ;
            uint64_t v292 = (uint64_t) v23;
            TASSIGN(v291, v292);
            // pto: %249
            ;
            int64_t v293 = (int64_t) ((uint64_t) v249 + (uint64_t) v290);
            // pto: %250
            ;
            int64_t v294 = v293 < v45 ? v45 : v293;
            // pto: %251
            ;
            const int64_t v295 = 0;
            // pto: %251
            ;
            __gm__ bfloat16_t* v296 = PTOAS__GLOBAL_TENSOR_DATA(v76);
            // pto: %251
            ;
            const int64_t v297 = 1;
            // pto: %251
            ;
            const int64_t v298 = 1;
            // pto: %251
            ;
            const int64_t v299 = 1;
            // pto: %251
            ;
            int64_t v300 = v244 * v28;
            // pto: %251
            ;
            int64_t v301 = v299 * v300;
            // pto: %251
            ;
            pto::Shape<1, 1, 1, -1, 128> v302 = pto::Shape<1, 1, 1, -1, 128>(v297, v298, v299, v244, v36);
            // pto: %251
            ;
            pto::Stride<-1, -1, -1, -1, -1> v303 = pto::Stride<-1, -1, -1, -1, -1>(v298 * v301, v301, v300, v28, v29);
            // pto: %251
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v304 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v296 + (v295 + v248 * v28 + v294 * v29), v302, v303);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            TLOAD(v291, v304);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
            // pto: %seed_small_packet_w__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v305 = Tile<TileType::Mat, bfloat16_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
            // pto: %seed_small_packet_w__tile
            ;
            uint64_t v306 = (uint64_t) v24;
            TASSIGN(v305, v306);
            // pto: %255
            ;
            int64_t v307 = v290 / v33;
            // pto: %256
            ;
            int64_t v308 = v307 < v45 ? v45 : v307;
            // pto: %257
            ;
            __gm__ bfloat16_t* v309 = PTOAS__GLOBAL_TENSOR_DATA(v79);
            // pto: %257
            ;
            const int64_t v310 = 0;
            // pto: %257
            ;
            const int64_t v311 = 4194304;
            // pto: %257
            ;
            const int64_t v312 = 65536;
            // pto: %257
            ;
            const int64_t v313 = 256;
            // pto: %257
            ;
            pto::Shape<1, 8, 8, 16, 16> v314 = pto::Shape<1, 8, 8, 16, 16>();
            // pto: %257
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v315 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %257
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 8, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v316 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 8, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v309 + ((v310 + v264 * v311) + v266 * v312 + v308 * v313), v314, v315);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            TLOAD(v305, v316);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
            // pto: %0
            ;
            Tile<TileType::Left, bfloat16_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v317 = Tile<TileType::Left, bfloat16_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v244, v36);
            // pto: %0
            ;
            uint64_t v318 = (uint64_t) v23;
            TASSIGN(v317, v318);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
            uint16_t v319 = static_cast<uint16_t>(v45);
            uint16_t v320 = static_cast<uint16_t>(v45);
            TEXTRACT(v317, v291, v319, v320);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            // pto: %1
            ;
            Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v321 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
            // pto: %1
            ;
            uint64_t v322 = (uint64_t) v23;
            TASSIGN(v321, v322);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
            uint16_t v323 = static_cast<uint16_t>(v45);
            uint16_t v324 = static_cast<uint16_t>(v45);
            TEXTRACT(v321, v305, v323, v324);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
            TMATMUL_ACC(v285, v285, v317, v321);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          };
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
          // pto: %259, %260
          ;
          int64_t v325 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v61) + (uint64_t) v143);
          // pto: %261
          ;
          int64_t v326 = v325 < v45 ? v45 : v325;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v327 = 0;
          // pto: %accum__ssa_v0_pview
          ;
          __gm__ float* v328 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v329 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v330 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v331 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          int64_t v332 = v244 * v42;
          // pto: %accum__ssa_v0_pview
          ;
          int64_t v333 = v331 * v332;
          // pto: %accum__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, -1, 128> v334 = pto::Shape<1, 1, 1, -1, 128>(v329, v330, v331, v244, v36);
          // pto: %accum__ssa_v0_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v335 = pto::Stride<-1, -1, -1, -1, -1>(v330 * v333, v333, v332, v42, v29);
          // pto: %accum__ssa_v0_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v336 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v328 + (v327 + v248 * v42 + v326 * v29), v334, v335);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
          TSTORE(v336, v285);
        } else {
          for (int64_t v337 = v45; v337 < v33; v337 += v29) {
            // pto: %262
            ;
            int64_t v338 = (int64_t) ((uint64_t) v145 + (uint64_t) v337);
            // pto: %263
            ;
            if (v338 < v138) {
              // pto: %264
              ;
              int64_t v339 = (int64_t) ((uint64_t) v338 * (uint64_t) v33);
              // pto: %265
              ;
              int64_t v340 = (int64_t) ((uint64_t) v17 - (uint64_t) v339);
              // pto: %266
              ;
              int64_t v341 = v340 < v33 ? v340 : v33;
              // pto: %268, %269, %270, %271, %267
              ;
              int32_t v342 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v338 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
              // pto: %272
              ;
              int64_t v343 = (int64_t) v342;
              // pto: %273
              ;
              int64_t v344 = v343 < v45 ? v45 : v343;
              // pto: %seed_narrow_acc__tile
              ;
              Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v345 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
              // pto: %seed_narrow_acc__tile
              ;
              uint64_t v346 = (uint64_t) v23;
              TASSIGN(v345, v346);
              wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
              for (int64_t v347 = v45; v347 < v33; v347 += v29) {
                // pto: %274
                ;
                int64_t v348 = (int64_t) ((uint64_t) v347 * (uint64_t) v33);
                // pto: %275, %276
                ;
                int64_t v349 = (int64_t) ((uint64_t) v344 + (uint64_t) v348) % v32;
                // pto: %277, %278, %279
                ;
                int64_t v350 = v349 < v45 ? (int64_t) ((uint64_t) v349 + (uint64_t) v32) : v349;
                // pto: %280
                ;
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
                if (v350 <= v60) {
                  // pto: %281
                  ;
                  int64_t v351 = (int64_t) ((uint64_t) v350 * (uint64_t) v33);
                  // pto: %seed_narrow_packet_x__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v352 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v341, v32);
                  // pto: %seed_narrow_packet_x__tile
                  ;
                  uint64_t v353 = (uint64_t) v24;
                  TASSIGN(v352, v353);
                  // pto: %282
                  ;
                  int64_t v354 = v339 < v45 ? v45 : v339;
                  // pto: %283, %284
                  ;
                  int64_t v355 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v41) + (uint64_t) v351);
                  // pto: %285
                  ;
                  int64_t v356 = v355 < v45 ? v45 : v355;
                  // pto: %286
                  ;
                  const int64_t v357 = 0;
                  // pto: %286
                  ;
                  __gm__ bfloat16_t* v358 = PTOAS__GLOBAL_TENSOR_DATA(v76);
                  // pto: %286
                  ;
                  const int64_t v359 = 1;
                  // pto: %286
                  ;
                  const int64_t v360 = 1;
                  // pto: %286
                  ;
                  const int64_t v361 = 1;
                  // pto: %286
                  ;
                  int64_t v362 = v341 * v28;
                  // pto: %286
                  ;
                  int64_t v363 = v361 * v362;
                  // pto: %286
                  ;
                  pto::Shape<1, 1, 1, -1, 256> v364 = pto::Shape<1, 1, 1, -1, 256>(v359, v360, v361, v341, v32);
                  // pto: %286
                  ;
                  pto::Stride<-1, -1, -1, -1, -1> v365 = pto::Stride<-1, -1, -1, -1, -1>(v360 * v363, v363, v362, v28, v29);
                  // pto: %286
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v366 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v358 + (v357 + v354 * v28 + v356 * v29), v364, v365);
                  TLOAD(v352, v366);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
                  // pto: %seed_narrow_packet_w__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v367 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
                  // pto: %seed_narrow_packet_w__tile
                  ;
                  uint64_t v368 = (uint64_t) v23;
                  TASSIGN(v367, v368);
                  // pto: %287
                  ;
                  int64_t v369 = v140 < v45 ? v45 : v140;
                  // pto: %288
                  ;
                  int64_t v370 = v143 / v33;
                  // pto: %289
                  ;
                  int64_t v371 = v370 < v45 ? v45 : v370;
                  // pto: %290
                  ;
                  int64_t v372 = v351 / v33;
                  // pto: %291
                  ;
                  int64_t v373 = v372 < v45 ? v45 : v372;
                  // pto: %292
                  ;
                  __gm__ bfloat16_t* v374 = PTOAS__GLOBAL_TENSOR_DATA(v79);
                  // pto: %292
                  ;
                  const int64_t v375 = 0;
                  // pto: %292
                  ;
                  const int64_t v376 = 4194304;
                  // pto: %292
                  ;
                  const int64_t v377 = 65536;
                  // pto: %292
                  ;
                  const int64_t v378 = 256;
                  // pto: %292
                  ;
                  pto::Shape<1, 8, 16, 16, 16> v379 = pto::Shape<1, 8, 16, 16, 16>();
                  // pto: %292
                  ;
                  pto::Stride<4194304, 65536, 256, 16, 1> v380 = pto::Stride<4194304, 65536, 256, 16, 1>();
                  // pto: %292
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v381 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v374 + ((v375 + v369 * v376) + v371 * v377 + v373 * v378), v379, v380);
                  TLOAD(v367, v381);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
                  // pto: %seed_narrow_acc__iter_v1_l0_a
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v382 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v341, v36);
                  // pto: %seed_narrow_acc__iter_v1_l0_a
                  ;
                  uint64_t v383 = (uint64_t) v23;
                  TASSIGN(v382, v383);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
                  uint16_t v384 = static_cast<uint16_t>(v45);
                  uint16_t v385 = static_cast<uint16_t>(v45);
                  TEXTRACT(v382, v352, v384, v385);
                  // pto: %seed_narrow_acc__iter_v1_l0_b
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v386 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %seed_narrow_acc__iter_v1_l0_b
                  ;
                  uint64_t v387 = (uint64_t) v23;
                  TASSIGN(v386, v387);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
                  uint16_t v388 = static_cast<uint16_t>(v45);
                  uint16_t v389 = static_cast<uint16_t>(v45);
                  TEXTRACT(v386, v367, v388, v389);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
                  // pto: %2
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v390 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v341, v36);
                  // pto: %2
                  ;
                  uint64_t v391 = (uint64_t) v25;
                  TASSIGN(v390, v391);
                  uint16_t v392 = static_cast<uint16_t>(v45);
                  uint16_t v393 = static_cast<uint16_t>(v36);
                  TEXTRACT(v390, v352, v392, v393);
                  // pto: %3
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v394 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %3
                  ;
                  uint64_t v395 = (uint64_t) v26;
                  TASSIGN(v394, v395);
                  uint16_t v396 = static_cast<uint16_t>(v36);
                  uint16_t v397 = static_cast<uint16_t>(v45);
                  TEXTRACT(v394, v367, v396, v397);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
                  // pto: %293
                  ;
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
                  if (v347 == v45) {
                    pipe_barrier(PIPE_M);
                    TMATMUL(v345, v382, v386);
                  } else {
                    pipe_barrier(PIPE_M);
                    TMATMUL_ACC(v345, v345, v382, v386);
                  };
                  pipe_barrier(PIPE_M);
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
                  TMATMUL_ACC(v345, v345, v390, v394);
                } else {
                  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
                  for (int64_t v398 = v45; v398 < v33; v398 += v29) {
                    // pto: %294, %295
                    ;
                    int64_t v399 = (int64_t) ((uint64_t) v350 + (uint64_t) v398) % v32;
                    // pto: %296, %297, %298
                    ;
                    int64_t v400 = v399 < v45 ? (int64_t) ((uint64_t) v399 + (uint64_t) v32) : v399;
                    // pto: %299
                    ;
                    int64_t v401 = (int64_t) ((uint64_t) v400 * (uint64_t) v33);
                    // pto: %seed_narrow_wrap_x__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v402 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v341, v33);
                    // pto: %seed_narrow_wrap_x__tile
                    ;
                    uint64_t v403 = (uint64_t) v24;
                    TASSIGN(v402, v403);
                    // pto: %300
                    ;
                    int64_t v404 = v339 < v45 ? v45 : v339;
                    // pto: %301, %302
                    ;
                    int64_t v405 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v41) + (uint64_t) v401);
                    // pto: %303
                    ;
                    int64_t v406 = v405 < v45 ? v45 : v405;
                    // pto: %304
                    ;
                    const int64_t v407 = 0;
                    // pto: %304
                    ;
                    __gm__ bfloat16_t* v408 = PTOAS__GLOBAL_TENSOR_DATA(v76);
                    // pto: %304
                    ;
                    const int64_t v409 = 1;
                    // pto: %304
                    ;
                    const int64_t v410 = 1;
                    // pto: %304
                    ;
                    const int64_t v411 = 1;
                    // pto: %304
                    ;
                    int64_t v412 = v341 * v28;
                    // pto: %304
                    ;
                    int64_t v413 = v411 * v412;
                    // pto: %304
                    ;
                    pto::Shape<1, 1, 1, -1, 16> v414 = pto::Shape<1, 1, 1, -1, 16>(v409, v410, v411, v341, v33);
                    // pto: %304
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v415 = pto::Stride<-1, -1, -1, -1, -1>(v410 * v413, v413, v412, v28, v29);
                    // pto: %304
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v416 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v408 + (v407 + v404 * v28 + v406 * v29), v414, v415);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
                    TLOAD(v402, v416);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
                    // pto: %seed_narrow_wrap_w__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v417 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %seed_narrow_wrap_w__tile
                    ;
                    uint64_t v418 = (uint64_t) v23;
                    TASSIGN(v417, v418);
                    // pto: %305
                    ;
                    int64_t v419 = v140 < v45 ? v45 : v140;
                    // pto: %306
                    ;
                    int64_t v420 = v143 / v33;
                    // pto: %307
                    ;
                    int64_t v421 = v420 < v45 ? v45 : v420;
                    // pto: %308
                    ;
                    int64_t v422 = v401 / v33;
                    // pto: %309
                    ;
                    int64_t v423 = v422 < v45 ? v45 : v422;
                    // pto: %310
                    ;
                    __gm__ bfloat16_t* v424 = PTOAS__GLOBAL_TENSOR_DATA(v79);
                    // pto: %310
                    ;
                    const int64_t v425 = 0;
                    // pto: %310
                    ;
                    const int64_t v426 = 4194304;
                    // pto: %310
                    ;
                    const int64_t v427 = 65536;
                    // pto: %310
                    ;
                    const int64_t v428 = 256;
                    // pto: %310
                    ;
                    pto::Shape<1, 8, 1, 16, 16> v429 = pto::Shape<1, 8, 1, 16, 16>();
                    // pto: %310
                    ;
                    pto::Stride<4194304, 65536, 256, 16, 1> v430 = pto::Stride<4194304, 65536, 256, 16, 1>();
                    // pto: %310
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v431 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v424 + ((v425 + v419 * v426) + v421 * v427 + v423 * v428), v429, v430);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
                    TLOAD(v417, v431);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
                    // pto: %5
                    ;
                    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v432 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v341, v33);
                    // pto: %5
                    ;
                    uint64_t v433 = (uint64_t) v23;
                    TASSIGN(v432, v433);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
                    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
                    uint16_t v434 = static_cast<uint16_t>(v45);
                    uint16_t v435 = static_cast<uint16_t>(v45);
                    TEXTRACT(v432, v402, v434, v435);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
                    // pto: %6
                    ;
                    Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v436 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %6
                    ;
                    uint64_t v437 = (uint64_t) v23;
                    TASSIGN(v436, v437);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
                    uint16_t v438 = static_cast<uint16_t>(v45);
                    uint16_t v439 = static_cast<uint16_t>(v45);
                    TEXTRACT(v436, v417, v438, v439);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
                    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
                    // pto: %312, %313
                    ;
                    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
                    if ((int64_t) ((uint64_t) v348 + (uint64_t) v398) == v45) {
                      pipe_barrier(PIPE_M);
                      TMATMUL(v345, v432, v436);
                    } else {
                      pipe_barrier(PIPE_M);
                      TMATMUL_ACC(v345, v345, v432, v436);
                    };
                    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
                  };
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
                  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
              };
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
              set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
              // pto: %314
              ;
              int64_t v440 = v339 < v45 ? v45 : v339;
              // pto: %315, %316
              ;
              int64_t v441 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v61) + (uint64_t) v143);
              // pto: %317
              ;
              int64_t v442 = v441 < v45 ? v45 : v441;
              // pto: %318
              ;
              __gm__ float* v443 = PTOAS__GLOBAL_TENSOR_DATA(v100);
              // pto: %318
              ;
              const int64_t v444 = 0;
              // pto: %318
              ;
              const int64_t v445 = 8192;
              // pto: %318
              ;
              pto::Shape<1, 1, 1, 16, 128> v446 = pto::Shape<1, 1, 1, 16, 128>();
              // pto: %318
              ;
              pto::Stride<131072, 131072, 131072, 8192, 1> v447 = pto::Stride<131072, 131072, 131072, 8192, 1>();
              // pto: %318
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v448 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v443 + (v444 + v440 * v445 + v442), v446, v447);
              wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
              pipe_barrier(PIPE_FIX);
              TSTORE(v448, v345);
              set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
            };
          };
        };
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    };
  } else {
    for (int64_t v449 = v126; v449 < v31; v449 += v48) {
      // pto: %320
      ;
      int64_t v450 = v449 / v30;
      // pto: %321
      ;
      int64_t v451 = v449 % v30;
      // pto: %322, %323, %324
      ;
      int64_t v452 = v451 < v45 ? (int64_t) ((uint64_t) v451 + (uint64_t) v30) : v451;
      // pto: %325
      ;
      int64_t v453 = (int64_t) ((uint64_t) v452 * (uint64_t) v36);
      // pto: %326, %327
      ;
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      for (int64_t v454 = v45; v454 < ((int64_t) ((uint64_t) v138 + (uint64_t) v53) / v30); v454 += v29) {
        // pto: %328
        ;
        int64_t v455 = (int64_t) ((uint64_t) v454 * (uint64_t) v30);
        // pto: %331, %332, %333, %329
        ;
        int32_t v456 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v454 * (uint64_t) v31) + (uint64_t) v450) * (uint64_t) v30) + (uint64_t) v452)];
        // pto: %334
        ;
        int64_t v457 = (int64_t) v456;
        // pto: %335
        ;
        int64_t v458 = v457 < v45 ? v45 : v457;
        // pto: %336
        ;
        int64_t v459 = (int64_t) ((uint64_t) v455 + (uint64_t) v29);
        // pto: %337
        ;
        // pto: %v4_same_start__phi_v3
        ;
        int64_t v460;
        if (v459 < v138) {
          // pto: %340, %341, %342, %343, %338
          ;
          int32_t v461 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v459 * (uint64_t) v30) + (uint64_t) v450) * (uint64_t) v30) + (uint64_t) v452)];
          // pto: %344
          ;
          int64_t v462 = (int64_t) v461;
          // pto: %345
          ;
          int64_t v463 = v462 < v45 ? v45 : v462;
          // pto: %346, %v4_same_start__phi_v2
          ;
          v460 = v463 != v458 ? v45 : v29;
        } else {
          v460 = v29;
        };
        // pto: %347
        ;
        int64_t v464 = (int64_t) ((uint64_t) v455 + (uint64_t) v49);
        // pto: %348
        ;
        // pto: %v4_same_start__phi_v6
        ;
        int64_t v465;
        if (v464 < v138) {
          // pto: %351, %352, %353, %354, %349
          ;
          int32_t v466 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v464 * (uint64_t) v30) + (uint64_t) v450) * (uint64_t) v30) + (uint64_t) v452)];
          // pto: %355
          ;
          int64_t v467 = (int64_t) v466;
          // pto: %356
          ;
          int64_t v468 = v467 < v45 ? v45 : v467;
          // pto: %357, %v4_same_start__phi_v5
          ;
          int64_t v469 = v468 != v458 ? v45 : v460;
          v465 = v469;
        } else {
          v465 = v460;
        };
        // pto: %358
        ;
        int64_t v470 = (int64_t) ((uint64_t) v455 + (uint64_t) v50);
        // pto: %359
        ;
        // pto: %v4_same_start__phi_v9
        ;
        int64_t v471;
        if (v470 < v138) {
          // pto: %362, %363, %364, %365, %360
          ;
          int32_t v472 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v470 * (uint64_t) v30) + (uint64_t) v450) * (uint64_t) v30) + (uint64_t) v452)];
          // pto: %366
          ;
          int64_t v473 = (int64_t) v472;
          // pto: %367
          ;
          int64_t v474 = v473 < v45 ? v45 : v473;
          // pto: %368, %v4_same_start__phi_v8
          ;
          int64_t v475 = v474 != v458 ? v45 : v465;
          v471 = v475;
        } else {
          v471 = v465;
        };
        // pto: %369
        ;
        int64_t v476 = (int64_t) ((uint64_t) v455 + (uint64_t) v43);
        // pto: %370
        ;
        // pto: %v4_same_start__phi_v12
        ;
        int64_t v477;
        if (v476 < v138) {
          // pto: %373, %374, %375, %376, %371
          ;
          int32_t v478 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v476 * (uint64_t) v30) + (uint64_t) v450) * (uint64_t) v30) + (uint64_t) v452)];
          // pto: %377
          ;
          int64_t v479 = (int64_t) v478;
          // pto: %378
          ;
          int64_t v480 = v479 < v45 ? v45 : v479;
          // pto: %379, %v4_same_start__phi_v11
          ;
          int64_t v481 = v480 != v458 ? v45 : v471;
          v477 = v481;
        } else {
          v477 = v471;
        };
        // pto: %380
        ;
        int64_t v482 = (int64_t) ((uint64_t) v455 + (uint64_t) v51);
        // pto: %381
        ;
        // pto: %v4_same_start__phi_v15
        ;
        int64_t v483;
        if (v482 < v138) {
          // pto: %384, %385, %386, %387, %382
          ;
          int32_t v484 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v482 * (uint64_t) v30) + (uint64_t) v450) * (uint64_t) v30) + (uint64_t) v452)];
          // pto: %388
          ;
          int64_t v485 = (int64_t) v484;
          // pto: %389
          ;
          int64_t v486 = v485 < v45 ? v45 : v485;
          // pto: %390, %v4_same_start__phi_v14
          ;
          int64_t v487 = v486 != v458 ? v45 : v477;
          v483 = v487;
        } else {
          v483 = v477;
        };
        // pto: %391
        ;
        int64_t v488 = (int64_t) ((uint64_t) v455 + (uint64_t) v52);
        // pto: %392
        ;
        // pto: %v4_same_start__phi_v18
        ;
        int64_t v489;
        if (v488 < v138) {
          // pto: %395, %396, %397, %398, %393
          ;
          int32_t v490 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v488 * (uint64_t) v30) + (uint64_t) v450) * (uint64_t) v30) + (uint64_t) v452)];
          // pto: %399
          ;
          int64_t v491 = (int64_t) v490;
          // pto: %400
          ;
          int64_t v492 = v491 < v45 ? v45 : v491;
          // pto: %401, %v4_same_start__phi_v17
          ;
          int64_t v493 = v492 != v458 ? v45 : v483;
          v489 = v493;
        } else {
          v489 = v483;
        };
        // pto: %402
        ;
        int64_t v494 = (int64_t) ((uint64_t) v455 + (uint64_t) v53);
        // pto: %403
        ;
        // pto: %v4_same_start__phi_v21
        ;
        int64_t v495;
        if (v494 < v138) {
          // pto: %406, %407, %408, %409, %404
          ;
          int32_t v496 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v494 * (uint64_t) v30) + (uint64_t) v450) * (uint64_t) v30) + (uint64_t) v452)];
          // pto: %410
          ;
          int64_t v497 = (int64_t) v496;
          // pto: %411
          ;
          int64_t v498 = v497 < v45 ? v45 : v497;
          // pto: %412, %v4_same_start__phi_v20
          ;
          int64_t v499 = v498 != v458 ? v45 : v489;
          v495 = v499;
        } else {
          v495 = v489;
        };
        // pto: %413, %v4_same_start__phi_v23
        ;
        int64_t v500 = v17 <= v33 ? v45 : v495;
        // pto: %414
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        if (v500 == v29) {
          int64_t v501 = (int64_t) ((uint64_t) v454 * (uint64_t) v36);
          // pto: %416
          ;
          int64_t v502 = (int64_t) ((uint64_t) v17 - (uint64_t) v501);
          // pto: %417
          ;
          int64_t v503 = v502 < v36 ? v502 : v36;
          // pto: %418
          ;
          int64_t v504 = v458 % v32;
          // pto: %419, %420, %421
          ;
          int64_t v505 = v504 < v45 ? (int64_t) ((uint64_t) v504 + (uint64_t) v32) : v504;
          // pto: %422
          ;
          int64_t v506 = (int64_t) ((uint64_t) v505 * (uint64_t) v33);
          // pto: %v4_wide_seed_x__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v507 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v503, v33);
          // pto: %v4_wide_seed_x__tile
          ;
          uint64_t v508 = (uint64_t) v23;
          TASSIGN(v507, v508);
          // pto: %423
          ;
          int64_t v509 = v501 < v45 ? v45 : v501;
          // pto: %424
          ;
          int64_t v510 = (int64_t) ((uint64_t) v450 * (uint64_t) v41);
          // pto: %425
          ;
          int64_t v511 = (int64_t) ((uint64_t) v510 + (uint64_t) v506);
          // pto: %426
          ;
          int64_t v512 = v511 < v45 ? v45 : v511;
          // pto: %427
          ;
          const int64_t v513 = 0;
          // pto: %427
          ;
          __gm__ bfloat16_t* v514 = PTOAS__GLOBAL_TENSOR_DATA(v76);
          // pto: %427
          ;
          const int64_t v515 = 1;
          // pto: %427
          ;
          const int64_t v516 = 1;
          // pto: %427
          ;
          const int64_t v517 = 1;
          // pto: %427
          ;
          int64_t v518 = v503 * v28;
          // pto: %427
          ;
          int64_t v519 = v517 * v518;
          // pto: %427
          ;
          pto::Shape<1, 1, 1, -1, 16> v520 = pto::Shape<1, 1, 1, -1, 16>(v515, v516, v517, v503, v33);
          // pto: %427
          ;
          pto::Stride<-1, -1, -1, -1, -1> v521 = pto::Stride<-1, -1, -1, -1, -1>(v516 * v519, v519, v518, v28, v29);
          // pto: %427
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v522 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v514 + (v513 + v509 * v28 + v512 * v29), v520, v521);
          TLOAD(v507, v522);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %v4_wide_seed_w__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v523 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
          // pto: %v4_wide_seed_w__tile
          ;
          uint64_t v524 = (uint64_t) v24;
          TASSIGN(v523, v524);
          // pto: %428
          ;
          int64_t v525 = v450 < v45 ? v45 : v450;
          // pto: %429
          ;
          int64_t v526 = v453 / v33;
          // pto: %430
          ;
          int64_t v527 = v526 < v45 ? v45 : v526;
          // pto: %431
          ;
          int64_t v528 = v506 / v33;
          // pto: %432
          ;
          int64_t v529 = v528 < v45 ? v45 : v528;
          // pto: %433
          ;
          __gm__ bfloat16_t* v530 = PTOAS__GLOBAL_TENSOR_DATA(v79);
          // pto: %433
          ;
          const int64_t v531 = 0;
          // pto: %433
          ;
          const int64_t v532 = 4194304;
          // pto: %433
          ;
          const int64_t v533 = 65536;
          // pto: %433
          ;
          const int64_t v534 = 256;
          // pto: %433
          ;
          pto::Shape<1, 8, 1, 16, 16> v535 = pto::Shape<1, 8, 1, 16, 16>();
          // pto: %433
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v536 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %433
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v537 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v530 + ((v531 + v525 * v532) + v527 * v533 + v529 * v534), v535, v536);
          TLOAD(v523, v537);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %7
          ;
          Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v538 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v503, v33);
          // pto: %7
          ;
          uint64_t v539 = (uint64_t) v23;
          TASSIGN(v538, v539);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          uint16_t v540 = static_cast<uint16_t>(v45);
          uint16_t v541 = static_cast<uint16_t>(v45);
          TEXTRACT(v538, v507, v540, v541);
          // pto: %8
          ;
          Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v542 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
          // pto: %8
          ;
          uint64_t v543 = (uint64_t) v23;
          TASSIGN(v542, v543);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          uint16_t v544 = static_cast<uint16_t>(v45);
          uint16_t v545 = static_cast<uint16_t>(v45);
          TEXTRACT(v542, v523, v544, v545);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
          // pto: %v4_wide_acc__tile
          ;
          Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v546 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v503, v36);
          // pto: %v4_wide_acc__tile
          ;
          uint64_t v547 = (uint64_t) v23;
          TASSIGN(v546, v547);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
          TMATMUL(v546, v538, v542);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
          for (int64_t v548 = v45; v548 < v46; v548 += v29) {
            // pto: %435, %434, %436, %437
            ;
            int64_t v549 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v458 + (uint64_t) ((int64_t) (uint64_t) v548 * (uint64_t) v33)) + (uint64_t) v29) % v32;
            // pto: %438, %439, %440
            ;
            int64_t v550 = v549 < v45 ? (int64_t) ((uint64_t) v549 + (uint64_t) v32) : v549;
            // pto: %441
            ;
            // pto: %442
            ;
            int64_t v551 = v503 < v36 ? v503 : v36;
            v122.SetValidShape(v551, v36);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
            if (v550 <= v60) {
              // pto: %443
              ;
              int64_t v552 = (int64_t) ((uint64_t) v550 * (uint64_t) v33);
              // pto: %v4_wide_packet_x__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v553 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v503, v32);
              // pto: %v4_wide_packet_x__tile
              ;
              uint64_t v554 = (uint64_t) v23;
              TASSIGN(v553, v554);
              // pto: %446
              ;
              int64_t v555 = (int64_t) ((uint64_t) v510 + (uint64_t) v552);
              // pto: %447
              ;
              int64_t v556 = v555 < v45 ? v45 : v555;
              // pto: %448
              ;
              const int64_t v557 = 0;
              // pto: %448
              ;
              __gm__ bfloat16_t* v558 = PTOAS__GLOBAL_TENSOR_DATA(v76);
              // pto: %448
              ;
              const int64_t v559 = 1;
              // pto: %448
              ;
              const int64_t v560 = 1;
              // pto: %448
              ;
              const int64_t v561 = 1;
              // pto: %448
              ;
              int64_t v562 = v503 * v28;
              // pto: %448
              ;
              int64_t v563 = v561 * v562;
              // pto: %448
              ;
              pto::Shape<1, 1, 1, -1, 256> v564 = pto::Shape<1, 1, 1, -1, 256>(v559, v560, v561, v503, v32);
              // pto: %448
              ;
              pto::Stride<-1, -1, -1, -1, -1> v565 = pto::Stride<-1, -1, -1, -1, -1>(v560 * v563, v563, v562, v28, v29);
              // pto: %448
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v566 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v558 + (v557 + v509 * v28 + v556 * v29), v564, v565);
              TLOAD(v553, v566);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              // pto: %v4_wide_packet_w__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v567 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
              // pto: %v4_wide_packet_w__tile
              ;
              uint64_t v568 = (uint64_t) v24;
              TASSIGN(v567, v568);
              // pto: %452
              ;
              int64_t v569 = v552 / v33;
              // pto: %453
              ;
              int64_t v570 = v569 < v45 ? v45 : v569;
              // pto: %454
              ;
              __gm__ bfloat16_t* v571 = PTOAS__GLOBAL_TENSOR_DATA(v79);
              // pto: %454
              ;
              const int64_t v572 = 0;
              // pto: %454
              ;
              const int64_t v573 = 4194304;
              // pto: %454
              ;
              const int64_t v574 = 65536;
              // pto: %454
              ;
              const int64_t v575 = 256;
              // pto: %454
              ;
              pto::Shape<1, 8, 16, 16, 16> v576 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %454
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v577 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %454
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v578 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v571 + ((v572 + v525 * v573) + v527 * v574 + v570 * v575), v576, v577);
              TLOAD(v567, v578);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              // pto: %v4_wide_acc__iter_v1_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v579 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v503, v36);
              // pto: %v4_wide_acc__iter_v1_l0_a
              ;
              uint64_t v580 = (uint64_t) v23;
              TASSIGN(v579, v580);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              uint16_t v581 = static_cast<uint16_t>(v45);
              uint16_t v582 = static_cast<uint16_t>(v45);
              TEXTRACT(v579, v553, v581, v582);
              // pto: %v4_wide_acc__iter_v1_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v583 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %v4_wide_acc__iter_v1_l0_b
              ;
              uint64_t v584 = (uint64_t) v23;
              TASSIGN(v583, v584);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              uint16_t v585 = static_cast<uint16_t>(v45);
              uint16_t v586 = static_cast<uint16_t>(v45);
              TEXTRACT(v583, v567, v585, v586);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
              // pto: %9
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v587 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v503, v36);
              // pto: %9
              ;
              uint64_t v588 = (uint64_t) v26;
              TASSIGN(v587, v588);
              uint16_t v589 = static_cast<uint16_t>(v45);
              uint16_t v590 = static_cast<uint16_t>(v36);
              TEXTRACT(v587, v553, v589, v590);
              // pto: %10
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v591 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %10
              ;
              uint64_t v592 = (uint64_t) v26;
              TASSIGN(v591, v592);
              uint16_t v593 = static_cast<uint16_t>(v36);
              uint16_t v594 = static_cast<uint16_t>(v45);
              TEXTRACT(v591, v567, v593, v594);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v546, v546, v579, v583);
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
              TMATMUL_ACC(v546, v546, v587, v591);
            } else {
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
              for (int64_t v595 = v45; v595 < v33; v595 += v29) {
                // pto: %455, %456
                ;
                int64_t v596 = (int64_t) ((uint64_t) v550 + (uint64_t) v595) % v32;
                // pto: %457, %458, %459
                ;
                int64_t v597 = v596 < v45 ? (int64_t) ((uint64_t) v596 + (uint64_t) v32) : v596;
                // pto: %460
                ;
                int64_t v598 = (int64_t) ((uint64_t) v597 * (uint64_t) v33);
                // pto: %v4_wide_wrap_x__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v599 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v503, v33);
                // pto: %v4_wide_wrap_x__tile
                ;
                uint64_t v600 = (uint64_t) v23;
                TASSIGN(v599, v600);
                // pto: %463
                ;
                int64_t v601 = (int64_t) ((uint64_t) v510 + (uint64_t) v598);
                // pto: %464
                ;
                int64_t v602 = v601 < v45 ? v45 : v601;
                // pto: %465
                ;
                const int64_t v603 = 0;
                // pto: %465
                ;
                __gm__ bfloat16_t* v604 = PTOAS__GLOBAL_TENSOR_DATA(v76);
                // pto: %465
                ;
                const int64_t v605 = 1;
                // pto: %465
                ;
                const int64_t v606 = 1;
                // pto: %465
                ;
                const int64_t v607 = 1;
                // pto: %465
                ;
                int64_t v608 = v503 * v28;
                // pto: %465
                ;
                int64_t v609 = v607 * v608;
                // pto: %465
                ;
                pto::Shape<1, 1, 1, -1, 16> v610 = pto::Shape<1, 1, 1, -1, 16>(v605, v606, v607, v503, v33);
                // pto: %465
                ;
                pto::Stride<-1, -1, -1, -1, -1> v611 = pto::Stride<-1, -1, -1, -1, -1>(v606 * v609, v609, v608, v28, v29);
                // pto: %465
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v612 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v604 + (v603 + v509 * v28 + v602 * v29), v610, v611);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
                TLOAD(v599, v612);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                // pto: %v4_wide_wrap_w__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v613 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %v4_wide_wrap_w__tile
                ;
                uint64_t v614 = (uint64_t) v24;
                TASSIGN(v613, v614);
                // pto: %469
                ;
                int64_t v615 = v598 / v33;
                // pto: %470
                ;
                int64_t v616 = v615 < v45 ? v45 : v615;
                // pto: %471
                ;
                __gm__ bfloat16_t* v617 = PTOAS__GLOBAL_TENSOR_DATA(v79);
                // pto: %471
                ;
                const int64_t v618 = 0;
                // pto: %471
                ;
                const int64_t v619 = 4194304;
                // pto: %471
                ;
                const int64_t v620 = 65536;
                // pto: %471
                ;
                const int64_t v621 = 256;
                // pto: %471
                ;
                pto::Shape<1, 8, 1, 16, 16> v622 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %471
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v623 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %471
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v624 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v617 + ((v618 + v525 * v619) + v527 * v620 + v616 * v621), v622, v623);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                TLOAD(v613, v624);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                // pto: %12
                ;
                Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v625 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v503, v33);
                // pto: %12
                ;
                uint64_t v626 = (uint64_t) v23;
                TASSIGN(v625, v626);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
                uint16_t v627 = static_cast<uint16_t>(v45);
                uint16_t v628 = static_cast<uint16_t>(v45);
                TEXTRACT(v625, v599, v627, v628);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
                // pto: %13
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v629 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %13
                ;
                uint64_t v630 = (uint64_t) v23;
                TASSIGN(v629, v630);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                uint16_t v631 = static_cast<uint16_t>(v45);
                uint16_t v632 = static_cast<uint16_t>(v45);
                TEXTRACT(v629, v613, v631, v632);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v546, v546, v625, v629);
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            };
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
          for (int64_t v633 = v62; v633 < v32; v633 += v29) {
            // pto: %472, %473
            ;
            int64_t v634 = (int64_t) ((uint64_t) v458 + (uint64_t) v633) % v32;
            // pto: %474, %475, %476
            ;
            int64_t v635 = v634 < v45 ? (int64_t) ((uint64_t) v634 + (uint64_t) v32) : v634;
            // pto: %477
            ;
            int64_t v636 = (int64_t) ((uint64_t) v635 * (uint64_t) v33);
            // pto: %v4_wide_tail_x__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v637 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v503, v33);
            // pto: %v4_wide_tail_x__tile
            ;
            uint64_t v638 = (uint64_t) v23;
            TASSIGN(v637, v638);
            // pto: %480
            ;
            int64_t v639 = (int64_t) ((uint64_t) v510 + (uint64_t) v636);
            // pto: %481
            ;
            int64_t v640 = v639 < v45 ? v45 : v639;
            // pto: %482
            ;
            const int64_t v641 = 0;
            // pto: %482
            ;
            __gm__ bfloat16_t* v642 = PTOAS__GLOBAL_TENSOR_DATA(v76);
            // pto: %482
            ;
            const int64_t v643 = 1;
            // pto: %482
            ;
            const int64_t v644 = 1;
            // pto: %482
            ;
            const int64_t v645 = 1;
            // pto: %482
            ;
            int64_t v646 = v503 * v28;
            // pto: %482
            ;
            int64_t v647 = v645 * v646;
            // pto: %482
            ;
            pto::Shape<1, 1, 1, -1, 16> v648 = pto::Shape<1, 1, 1, -1, 16>(v643, v644, v645, v503, v33);
            // pto: %482
            ;
            pto::Stride<-1, -1, -1, -1, -1> v649 = pto::Stride<-1, -1, -1, -1, -1>(v644 * v647, v647, v646, v28, v29);
            // pto: %482
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v650 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v642 + (v641 + v509 * v28 + v640 * v29), v648, v649);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
            TLOAD(v637, v650);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %v4_wide_tail_w__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v651 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
            // pto: %v4_wide_tail_w__tile
            ;
            uint64_t v652 = (uint64_t) v24;
            TASSIGN(v651, v652);
            // pto: %486
            ;
            int64_t v653 = v636 / v33;
            // pto: %487
            ;
            int64_t v654 = v653 < v45 ? v45 : v653;
            // pto: %488
            ;
            __gm__ bfloat16_t* v655 = PTOAS__GLOBAL_TENSOR_DATA(v79);
            // pto: %488
            ;
            const int64_t v656 = 0;
            // pto: %488
            ;
            const int64_t v657 = 4194304;
            // pto: %488
            ;
            const int64_t v658 = 65536;
            // pto: %488
            ;
            const int64_t v659 = 256;
            // pto: %488
            ;
            pto::Shape<1, 8, 1, 16, 16> v660 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %488
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v661 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %488
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v662 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v655 + ((v656 + v525 * v657) + v527 * v658 + v654 * v659), v660, v661);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            TLOAD(v651, v662);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %14
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v663 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v503, v33);
            // pto: %14
            ;
            uint64_t v664 = (uint64_t) v23;
            TASSIGN(v663, v664);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
            uint16_t v665 = static_cast<uint16_t>(v45);
            uint16_t v666 = static_cast<uint16_t>(v45);
            TEXTRACT(v663, v637, v665, v666);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
            // pto: %15
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v667 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
            // pto: %15
            ;
            uint64_t v668 = (uint64_t) v23;
            TASSIGN(v667, v668);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            uint16_t v669 = static_cast<uint16_t>(v45);
            uint16_t v670 = static_cast<uint16_t>(v45);
            TEXTRACT(v667, v651, v669, v670);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v546, v546, v663, v667);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
          // pto: %490, %491
          ;
          int64_t v671 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v450 * (uint64_t) v61) + (uint64_t) v453);
          // pto: %492
          ;
          int64_t v672 = v671 < v45 ? v45 : v671;
          // pto: %493
          ;
          const int64_t v673 = 0;
          // pto: %493
          ;
          __gm__ float* v674 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %493
          ;
          const int64_t v675 = 1;
          // pto: %493
          ;
          const int64_t v676 = 1;
          // pto: %493
          ;
          const int64_t v677 = 1;
          // pto: %493
          ;
          int64_t v678 = v503 * v42;
          // pto: %493
          ;
          int64_t v679 = v677 * v678;
          // pto: %493
          ;
          pto::Shape<1, 1, 1, -1, 128> v680 = pto::Shape<1, 1, 1, -1, 128>(v675, v676, v677, v503, v36);
          // pto: %493
          ;
          pto::Stride<-1, -1, -1, -1, -1> v681 = pto::Stride<-1, -1, -1, -1, -1>(v676 * v679, v679, v678, v42, v29);
          // pto: %493
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v682 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v674 + (v673 + v509 * v42 + v672 * v29), v680, v681);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
          TSTORE(v682, v546);
        } else {
          for (int64_t v683 = v45; v683 < v30; v683 += v29) {
            // pto: %494
            ;
            int64_t v684 = (int64_t) ((uint64_t) v455 + (uint64_t) v683);
            // pto: %495
            ;
            if (v684 < v138) {
              // pto: %496
              ;
              int64_t v685 = (int64_t) ((uint64_t) v684 * (uint64_t) v33);
              // pto: %497
              ;
              int64_t v686 = (int64_t) ((uint64_t) v17 - (uint64_t) v685);
              // pto: %498
              ;
              int64_t v687 = v686 < v33 ? v686 : v33;
              // pto: %500, %501, %502, %503, %499
              ;
              int32_t v688 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v684 * (uint64_t) v30) + (uint64_t) v450) * (uint64_t) v30) + (uint64_t) v452)];
              // pto: %504
              ;
              int64_t v689 = (int64_t) v688;
              // pto: %505
              ;
              int64_t v690 = v689 < v45 ? v45 : v689;
              // pto: %v4_narrow_acc__tile
              ;
              Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v691 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
              // pto: %v4_narrow_acc__tile
              ;
              uint64_t v692 = (uint64_t) v23;
              TASSIGN(v691, v692);
              wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
              for (int64_t v693 = v45; v693 < v33; v693 += v29) {
                // pto: %506
                ;
                int64_t v694 = (int64_t) ((uint64_t) v693 * (uint64_t) v33);
                // pto: %507, %508
                ;
                int64_t v695 = (int64_t) ((uint64_t) v690 + (uint64_t) v694) % v32;
                // pto: %509, %510, %511
                ;
                int64_t v696 = v695 < v45 ? (int64_t) ((uint64_t) v695 + (uint64_t) v32) : v695;
                // pto: %512
                ;
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
                if (v696 <= v60) {
                  // pto: %513
                  ;
                  int64_t v697 = (int64_t) ((uint64_t) v696 * (uint64_t) v33);
                  // pto: %v4_narrow_packet_x__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v698 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v687, v32);
                  // pto: %v4_narrow_packet_x__tile
                  ;
                  uint64_t v699 = (uint64_t) v24;
                  TASSIGN(v698, v699);
                  // pto: %514
                  ;
                  int64_t v700 = v685 < v45 ? v45 : v685;
                  // pto: %515, %516
                  ;
                  int64_t v701 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v450 * (uint64_t) v41) + (uint64_t) v697);
                  // pto: %517
                  ;
                  int64_t v702 = v701 < v45 ? v45 : v701;
                  // pto: %518
                  ;
                  const int64_t v703 = 0;
                  // pto: %518
                  ;
                  __gm__ bfloat16_t* v704 = PTOAS__GLOBAL_TENSOR_DATA(v76);
                  // pto: %518
                  ;
                  const int64_t v705 = 1;
                  // pto: %518
                  ;
                  const int64_t v706 = 1;
                  // pto: %518
                  ;
                  const int64_t v707 = 1;
                  // pto: %518
                  ;
                  int64_t v708 = v687 * v28;
                  // pto: %518
                  ;
                  int64_t v709 = v707 * v708;
                  // pto: %518
                  ;
                  pto::Shape<1, 1, 1, -1, 256> v710 = pto::Shape<1, 1, 1, -1, 256>(v705, v706, v707, v687, v32);
                  // pto: %518
                  ;
                  pto::Stride<-1, -1, -1, -1, -1> v711 = pto::Stride<-1, -1, -1, -1, -1>(v706 * v709, v709, v708, v28, v29);
                  // pto: %518
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v712 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v704 + (v703 + v700 * v28 + v702 * v29), v710, v711);
                  TLOAD(v698, v712);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  // pto: %v4_narrow_packet_w__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v713 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
                  // pto: %v4_narrow_packet_w__tile
                  ;
                  uint64_t v714 = (uint64_t) v23;
                  TASSIGN(v713, v714);
                  // pto: %519
                  ;
                  int64_t v715 = v450 < v45 ? v45 : v450;
                  // pto: %520
                  ;
                  int64_t v716 = v453 / v33;
                  // pto: %521
                  ;
                  int64_t v717 = v716 < v45 ? v45 : v716;
                  // pto: %522
                  ;
                  int64_t v718 = v697 / v33;
                  // pto: %523
                  ;
                  int64_t v719 = v718 < v45 ? v45 : v718;
                  // pto: %524
                  ;
                  __gm__ bfloat16_t* v720 = PTOAS__GLOBAL_TENSOR_DATA(v79);
                  // pto: %524
                  ;
                  const int64_t v721 = 0;
                  // pto: %524
                  ;
                  const int64_t v722 = 4194304;
                  // pto: %524
                  ;
                  const int64_t v723 = 65536;
                  // pto: %524
                  ;
                  const int64_t v724 = 256;
                  // pto: %524
                  ;
                  pto::Shape<1, 8, 16, 16, 16> v725 = pto::Shape<1, 8, 16, 16, 16>();
                  // pto: %524
                  ;
                  pto::Stride<4194304, 65536, 256, 16, 1> v726 = pto::Stride<4194304, 65536, 256, 16, 1>();
                  // pto: %524
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v727 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v720 + ((v721 + v715 * v722) + v717 * v723 + v719 * v724), v725, v726);
                  TLOAD(v713, v727);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  // pto: %v4_narrow_acc__iter_v1_l0_a
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v728 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v687, v36);
                  // pto: %v4_narrow_acc__iter_v1_l0_a
                  ;
                  uint64_t v729 = (uint64_t) v23;
                  TASSIGN(v728, v729);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  uint16_t v730 = static_cast<uint16_t>(v45);
                  uint16_t v731 = static_cast<uint16_t>(v45);
                  TEXTRACT(v728, v698, v730, v731);
                  // pto: %v4_narrow_acc__iter_v1_l0_b
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v732 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %v4_narrow_acc__iter_v1_l0_b
                  ;
                  uint64_t v733 = (uint64_t) v23;
                  TASSIGN(v732, v733);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  uint16_t v734 = static_cast<uint16_t>(v45);
                  uint16_t v735 = static_cast<uint16_t>(v45);
                  TEXTRACT(v732, v713, v734, v735);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  // pto: %16
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v736 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v687, v36);
                  // pto: %16
                  ;
                  uint64_t v737 = (uint64_t) v25;
                  TASSIGN(v736, v737);
                  uint16_t v738 = static_cast<uint16_t>(v45);
                  uint16_t v739 = static_cast<uint16_t>(v36);
                  TEXTRACT(v736, v698, v738, v739);
                  // pto: %17
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v740 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %17
                  ;
                  uint64_t v741 = (uint64_t) v26;
                  TASSIGN(v740, v741);
                  uint16_t v742 = static_cast<uint16_t>(v36);
                  uint16_t v743 = static_cast<uint16_t>(v45);
                  TEXTRACT(v740, v713, v742, v743);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  // pto: %525
                  ;
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  if (v693 == v45) {
                    pipe_barrier(PIPE_M);
                    TMATMUL(v691, v728, v732);
                  } else {
                    pipe_barrier(PIPE_M);
                    TMATMUL_ACC(v691, v691, v728, v732);
                  };
                  pipe_barrier(PIPE_M);
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  TMATMUL_ACC(v691, v691, v736, v740);
                } else {
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                  for (int64_t v744 = v45; v744 < v33; v744 += v29) {
                    // pto: %526, %527
                    ;
                    int64_t v745 = (int64_t) ((uint64_t) v696 + (uint64_t) v744) % v32;
                    // pto: %528, %529, %530
                    ;
                    int64_t v746 = v745 < v45 ? (int64_t) ((uint64_t) v745 + (uint64_t) v32) : v745;
                    // pto: %531
                    ;
                    int64_t v747 = (int64_t) ((uint64_t) v746 * (uint64_t) v33);
                    // pto: %v4_narrow_wrap_x__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v748 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v687, v33);
                    // pto: %v4_narrow_wrap_x__tile
                    ;
                    uint64_t v749 = (uint64_t) v24;
                    TASSIGN(v748, v749);
                    // pto: %532
                    ;
                    int64_t v750 = v685 < v45 ? v45 : v685;
                    // pto: %533, %534
                    ;
                    int64_t v751 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v450 * (uint64_t) v41) + (uint64_t) v747);
                    // pto: %535
                    ;
                    int64_t v752 = v751 < v45 ? v45 : v751;
                    // pto: %536
                    ;
                    const int64_t v753 = 0;
                    // pto: %536
                    ;
                    __gm__ bfloat16_t* v754 = PTOAS__GLOBAL_TENSOR_DATA(v76);
                    // pto: %536
                    ;
                    const int64_t v755 = 1;
                    // pto: %536
                    ;
                    const int64_t v756 = 1;
                    // pto: %536
                    ;
                    const int64_t v757 = 1;
                    // pto: %536
                    ;
                    int64_t v758 = v687 * v28;
                    // pto: %536
                    ;
                    int64_t v759 = v757 * v758;
                    // pto: %536
                    ;
                    pto::Shape<1, 1, 1, -1, 16> v760 = pto::Shape<1, 1, 1, -1, 16>(v755, v756, v757, v687, v33);
                    // pto: %536
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v761 = pto::Stride<-1, -1, -1, -1, -1>(v756 * v759, v759, v758, v28, v29);
                    // pto: %536
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v762 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v754 + (v753 + v750 * v28 + v752 * v29), v760, v761);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
                    TLOAD(v748, v762);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    // pto: %v4_narrow_wrap_w__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v763 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %v4_narrow_wrap_w__tile
                    ;
                    uint64_t v764 = (uint64_t) v23;
                    TASSIGN(v763, v764);
                    // pto: %537
                    ;
                    int64_t v765 = v450 < v45 ? v45 : v450;
                    // pto: %538
                    ;
                    int64_t v766 = v453 / v33;
                    // pto: %539
                    ;
                    int64_t v767 = v766 < v45 ? v45 : v766;
                    // pto: %540
                    ;
                    int64_t v768 = v747 / v33;
                    // pto: %541
                    ;
                    int64_t v769 = v768 < v45 ? v45 : v768;
                    // pto: %542
                    ;
                    __gm__ bfloat16_t* v770 = PTOAS__GLOBAL_TENSOR_DATA(v79);
                    // pto: %542
                    ;
                    const int64_t v771 = 0;
                    // pto: %542
                    ;
                    const int64_t v772 = 4194304;
                    // pto: %542
                    ;
                    const int64_t v773 = 65536;
                    // pto: %542
                    ;
                    const int64_t v774 = 256;
                    // pto: %542
                    ;
                    pto::Shape<1, 8, 1, 16, 16> v775 = pto::Shape<1, 8, 1, 16, 16>();
                    // pto: %542
                    ;
                    pto::Stride<4194304, 65536, 256, 16, 1> v776 = pto::Stride<4194304, 65536, 256, 16, 1>();
                    // pto: %542
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v777 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v770 + ((v771 + v765 * v772) + v767 * v773 + v769 * v774), v775, v776);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    TLOAD(v763, v777);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    // pto: %19
                    ;
                    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v778 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v687, v33);
                    // pto: %19
                    ;
                    uint64_t v779 = (uint64_t) v23;
                    TASSIGN(v778, v779);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                    uint16_t v780 = static_cast<uint16_t>(v45);
                    uint16_t v781 = static_cast<uint16_t>(v45);
                    TEXTRACT(v778, v748, v780, v781);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
                    // pto: %20
                    ;
                    Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v782 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %20
                    ;
                    uint64_t v783 = (uint64_t) v23;
                    TASSIGN(v782, v783);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    uint16_t v784 = static_cast<uint16_t>(v45);
                    uint16_t v785 = static_cast<uint16_t>(v45);
                    TEXTRACT(v782, v763, v784, v785);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    // pto: %544, %545
                    ;
                    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    if ((int64_t) ((uint64_t) v694 + (uint64_t) v744) == v45) {
                      pipe_barrier(PIPE_M);
                      TMATMUL(v691, v778, v782);
                    } else {
                      pipe_barrier(PIPE_M);
                      TMATMUL_ACC(v691, v691, v778, v782);
                    };
                    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                  };
                  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
              set_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
              // pto: %546
              ;
              int64_t v786 = v685 < v45 ? v45 : v685;
              // pto: %547, %548
              ;
              int64_t v787 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v450 * (uint64_t) v61) + (uint64_t) v453);
              // pto: %549
              ;
              int64_t v788 = v787 < v45 ? v45 : v787;
              // pto: %550
              ;
              __gm__ float* v789 = PTOAS__GLOBAL_TENSOR_DATA(v100);
              // pto: %550
              ;
              const int64_t v790 = 0;
              // pto: %550
              ;
              const int64_t v791 = 8192;
              // pto: %550
              ;
              pto::Shape<1, 1, 1, 16, 128> v792 = pto::Shape<1, 1, 1, 16, 128>();
              // pto: %550
              ;
              pto::Stride<131072, 131072, 131072, 8192, 1> v793 = pto::Stride<131072, 131072, 131072, 8192, 1>();
              // pto: %550
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v794 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v789 + (v790 + v786 * v791 + v788), v792, v793);
              wait_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
              pipe_barrier(PIPE_FIX);
              TSTORE(v794, v691);
              set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
            };
          };
        };
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      };
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
    };
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %552
  int64_t v795 = (int64_t) ((uint64_t) v127 + (uint64_t) v63);
  // pto: %553
  int64_t v796 = v795 < v45 ? v45 : v795;
  // pto: %signals__ssa_v1_signal_pview
  __gm__ int32_t* v797 = PTOAS__GLOBAL_TENSOR_DATA(v119);
  // pto: %signals__ssa_v1_signal_pview
  const int64_t v798 = 0;
  // pto: %signals__ssa_v1_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v799 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v800 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v801 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v797 + (v798 + v796), v799, v800);
  pto::comm::NotifyOp v802 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v801, v136, v802);
  for (int64_t v803 = v48; v803 < v64; v803 += v29) {
    // pto: %554, %555
    ;
    int64_t v804 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v803 * (uint64_t) v36) + (uint64_t) v65);
    // pto: %556
    ;
    int64_t v805 = v804 < v45 ? v45 : v804;
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v806 = PTOAS__GLOBAL_TENSOR_DATA(v119);
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    const int64_t v807 = 0;
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v808 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v809 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v810 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v806 + (v807 + v805), v808, v809);
    pto::comm::WaitCmp v811 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v810, v136, v811);
  }
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %557
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
  if (v17 <= v33) {
    // pto: %558
    ;
    for (int64_t v812 = v126; v812 < ((int64_t) ((uint64_t) v138 * (uint64_t) v38)); v812 += v48) {
      // pto: %559, %560
      ;
      int64_t v813 = (int64_t) ((uint64_t) (v812 / v38) * (uint64_t) v33);
      // pto: %561
      ;
      int64_t v814 = v812 % v38;
      // pto: %562, %563, %564
      ;
      int64_t v815 = v814 < v45 ? (int64_t) ((uint64_t) v814 + (uint64_t) v38) : v814;
      // pto: %565
      ;
      int64_t v816 = (int64_t) ((uint64_t) v815 * (uint64_t) v36);
      // pto: %566
      ;
      int64_t v817 = (int64_t) ((uint64_t) v17 - (uint64_t) v813);
      // pto: %567
      ;
      int64_t v818 = v817 < v33 ? v817 : v33;
      // pto: %b_acc__tile
      ;
      Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v819 = Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
      // pto: %b_acc__tile
      ;
      uint64_t v820 = (uint64_t) v23;
      TASSIGN(v819, v820);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      for (int64_t v821 = v45; v821 < v33; v821 += v29) {
        // pto: %568
        ;
        int64_t v822 = (int64_t) ((uint64_t) v821 * (uint64_t) v37);
        // pto: %b_input__tile
        ;
        Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v823 = Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v818, v37);
        // pto: %b_input__tile
        ;
        uint64_t v824 = (uint64_t) v24;
        TASSIGN(v823, v824);
        // pto: %569
        ;
        int64_t v825 = v813 < v45 ? v45 : v813;
        // pto: %570
        ;
        int64_t v826 = v822 < v45 ? v45 : v822;
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v827 = 0;
        // pto: %quantized__ssa_v0_pview
        ;
        __gm__ int8_t* v828 = PTOAS__GLOBAL_TENSOR_DATA(v91);
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v829 = 1;
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v830 = 1;
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v831 = 1;
        // pto: %quantized__ssa_v0_pview
        ;
        int64_t v832 = v818 * v42;
        // pto: %quantized__ssa_v0_pview
        ;
        int64_t v833 = v831 * v832;
        // pto: %quantized__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 512> v834 = pto::Shape<1, 1, 1, -1, 512>(v829, v830, v831, v818, v37);
        // pto: %quantized__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v835 = pto::Stride<-1, -1, -1, -1, -1>(v830 * v833, v833, v832, v42, v29);
        // pto: %quantized__ssa_v0_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v836 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v828 + (v827 + v825 * v42 + v826 * v29), v834, v835);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        TLOAD(v823, v836);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %b_weight__tile
        ;
        Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v837 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v37, v36);
        // pto: %b_weight__tile
        ;
        uint64_t v838 = (uint64_t) v23;
        TASSIGN(v837, v838);
        // pto: %571
        ;
        int64_t v839 = v816 / v38;
        // pto: %572
        ;
        int64_t v840 = v839 < v45 ? v45 : v839;
        // pto: %573
        ;
        int64_t v841 = v822 / v33;
        // pto: %574
        ;
        int64_t v842 = v841 < v45 ? v45 : v841;
        // pto: %wo_b__ssa_v0_pview
        ;
        __gm__ int8_t* v843 = PTOAS__GLOBAL_TENSOR_DATA(v82);
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v844 = 0;
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v845 = 262144;
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v846 = 512;
        // pto: %wo_b__ssa_v0_pview
        ;
        pto::Shape<1, 4, 32, 16, 32> v847 = pto::Shape<1, 4, 32, 16, 32>();
        // pto: %wo_b__ssa_v0_pview
        ;
        pto::Stride<33554432, 262144, 512, 32, 1> v848 = pto::Stride<33554432, 262144, 512, 32, 1>();
        // pto: %wo_b__ssa_v0_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v849 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v843 + (v844 + v840 * v845 + v842 * v846), v847, v848);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v837, v849);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %b_acc__tile_l0_a
        ;
        Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v850 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v818, v32);
        // pto: %b_acc__tile_l0_a
        ;
        uint64_t v851 = (uint64_t) v23;
        TASSIGN(v850, v851);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        uint16_t v852 = static_cast<uint16_t>(v45);
        uint16_t v853 = static_cast<uint16_t>(v45);
        TEXTRACT(v850, v823, v852, v853);
        // pto: %b_acc__tile_l0_b
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v854 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
        // pto: %b_acc__tile_l0_b
        ;
        uint64_t v855 = (uint64_t) v23;
        TASSIGN(v854, v855);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v856 = static_cast<uint16_t>(v45);
        uint16_t v857 = static_cast<uint16_t>(v45);
        TEXTRACT(v854, v837, v856, v857);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %21
        ;
        Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v858 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v818, v32);
        // pto: %21
        ;
        uint64_t v859 = (uint64_t) v25;
        TASSIGN(v858, v859);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v860 = static_cast<uint16_t>(v45);
        uint16_t v861 = static_cast<uint16_t>(v32);
        TEXTRACT(v858, v823, v860, v861);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        // pto: %22
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v862 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
        // pto: %22
        ;
        uint64_t v863 = (uint64_t) v26;
        TASSIGN(v862, v863);
        uint16_t v864 = static_cast<uint16_t>(v32);
        uint16_t v865 = static_cast<uint16_t>(v45);
        TEXTRACT(v862, v837, v864, v865);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %575
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        if (v821 == v45) {
          pipe_barrier(PIPE_M);
          TMATMUL(v819, v850, v854);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v819, v819, v850, v854);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v819, v819, v858, v862);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
      // pto: %576
      ;
      int64_t v866 = v813 < v45 ? v45 : v813;
      // pto: %577
      ;
      int64_t v867 = v816 < v45 ? v45 : v816;
      // pto: %integer_accum__ssa_v0_pview
      ;
      __gm__ int32_t* v868 = PTOAS__GLOBAL_TENSOR_DATA(v109);
      // pto: %integer_accum__ssa_v0_pview
      ;
      const int64_t v869 = 0;
      // pto: %integer_accum__ssa_v0_pview
      ;
      const int64_t v870 = 4096;
      // pto: %integer_accum__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 128> v871 = pto::Shape<1, 1, 1, 16, 128>();
      // pto: %integer_accum__ssa_v0_pview
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v872 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %integer_accum__ssa_v0_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v873 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v868 + (v869 + v866 * v870 + v867), v871, v872);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
      pipe_barrier(PIPE_FIX);
      TSTORE(v873, v819);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
    };
  } else {
    // pto: %578, %579, %580
    ;
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    for (int64_t v874 = v126; v874 < ((int64_t) ((uint64_t) ((int64_t) ((uint64_t) v17 + (uint64_t) v66) / v31) * (uint64_t) v38)); v874 += v48) {
      // pto: %581, %582
      ;
      int64_t v875 = (int64_t) ((uint64_t) (v874 / v38) * (uint64_t) v31);
      // pto: %583
      ;
      int64_t v876 = v874 % v38;
      // pto: %584, %585, %586
      ;
      int64_t v877 = v876 < v45 ? (int64_t) ((uint64_t) v876 + (uint64_t) v38) : v876;
      // pto: %587
      ;
      int64_t v878 = (int64_t) ((uint64_t) v877 * (uint64_t) v36);
      // pto: %588
      ;
      int64_t v879 = (int64_t) ((uint64_t) v17 - (uint64_t) v875);
      // pto: %589
      ;
      int64_t v880 = v879 < v31 ? v879 : v31;
      // pto: %wide_first_input__tile
      ;
      Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v881 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v880, v37);
      // pto: %wide_first_input__tile
      ;
      uint64_t v882 = (uint64_t) v24;
      TASSIGN(v881, v882);
      // pto: %590
      ;
      int64_t v883 = v875 < v45 ? v45 : v875;
      // pto: %591
      ;
      const int64_t v884 = 0;
      // pto: %591
      ;
      __gm__ int8_t* v885 = PTOAS__GLOBAL_TENSOR_DATA(v91);
      // pto: %591
      ;
      const int64_t v886 = 1;
      // pto: %591
      ;
      const int64_t v887 = 1;
      // pto: %591
      ;
      const int64_t v888 = 1;
      // pto: %591
      ;
      int64_t v889 = v880 * v42;
      // pto: %591
      ;
      int64_t v890 = v888 * v889;
      // pto: %591
      ;
      pto::Shape<1, 1, 1, -1, 512> v891 = pto::Shape<1, 1, 1, -1, 512>(v886, v887, v888, v880, v37);
      // pto: %591
      ;
      pto::Stride<-1, -1, -1, -1, -1> v892 = pto::Stride<-1, -1, -1, -1, -1>(v887 * v890, v890, v889, v42, v29);
      // pto: %591
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v893 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v885 + (v884 + v883 * v42 + v45 * v29), v891, v892);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v881, v893);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %wide_first_weight__tile
      ;
      Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v894 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v37, v36);
      // pto: %wide_first_weight__tile
      ;
      uint64_t v895 = (uint64_t) v23;
      TASSIGN(v894, v895);
      // pto: %592
      ;
      int64_t v896 = v878 / v38;
      // pto: %593
      ;
      int64_t v897 = v896 < v45 ? v45 : v896;
      // pto: %594
      ;
      __gm__ int8_t* v898 = PTOAS__GLOBAL_TENSOR_DATA(v82);
      // pto: %594
      ;
      const int64_t v899 = 0;
      // pto: %594
      ;
      const int64_t v900 = 262144;
      // pto: %594
      ;
      pto::Shape<1, 4, 32, 16, 32> v901 = pto::Shape<1, 4, 32, 16, 32>();
      // pto: %594
      ;
      pto::Stride<33554432, 262144, 512, 32, 1> v902 = pto::Stride<33554432, 262144, 512, 32, 1>();
      // pto: %594
      ;
      GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v903 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v898 + (v899 + v897 * v900), v901, v902);
      TLOAD(v894, v903);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %wide_b_acc__tile_l0_init_storage
      ;
      Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v904 = Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v31, v36);
      // pto: %wide_b_acc__tile_l0_init_storage
      ;
      uint64_t v905 = (uint64_t) v23;
      TASSIGN(v904, v905);
      v904.SetValidShape(v880, v36);
      // pto: %wide_b_acc__tile_l0_a
      ;
      Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v906 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v880, v32);
      // pto: %wide_b_acc__tile_l0_a
      ;
      uint64_t v907 = (uint64_t) v23;
      TASSIGN(v906, v907);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      uint16_t v908 = static_cast<uint16_t>(v45);
      uint16_t v909 = static_cast<uint16_t>(v45);
      TEXTRACT(v906, v881, v908, v909);
      // pto: %wide_b_acc__tile_l0_b
      ;
      Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v910 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
      // pto: %wide_b_acc__tile_l0_b
      ;
      uint64_t v911 = (uint64_t) v23;
      TASSIGN(v910, v911);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      uint16_t v912 = static_cast<uint16_t>(v45);
      uint16_t v913 = static_cast<uint16_t>(v45);
      TEXTRACT(v910, v894, v912, v913);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %24
      ;
      Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v914 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v880, v32);
      // pto: %24
      ;
      uint64_t v915 = (uint64_t) v27;
      TASSIGN(v914, v915);
      uint16_t v916 = static_cast<uint16_t>(v45);
      uint16_t v917 = static_cast<uint16_t>(v32);
      TEXTRACT(v914, v881, v916, v917);
      // pto: %25
      ;
      Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v918 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
      // pto: %25
      ;
      uint64_t v919 = (uint64_t) v26;
      TASSIGN(v918, v919);
      uint16_t v920 = static_cast<uint16_t>(v32);
      uint16_t v921 = static_cast<uint16_t>(v45);
      TEXTRACT(v918, v894, v920, v921);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
      TMATMUL(v904, v906, v910);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v904, v904, v914, v918);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      for (int64_t v922 = v29; v922 < v33; v922 += v29) {
        // pto: %595
        ;
        int64_t v923 = (int64_t) ((uint64_t) v922 * (uint64_t) v37);
        // pto: %wide_b_input__tile
        ;
        Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v924 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v880, v37);
        // pto: %wide_b_input__tile
        ;
        uint64_t v925 = (uint64_t) v24;
        TASSIGN(v924, v925);
        // pto: %597
        ;
        int64_t v926 = v923 < v45 ? v45 : v923;
        // pto: %598
        ;
        const int64_t v927 = 0;
        // pto: %598
        ;
        __gm__ int8_t* v928 = PTOAS__GLOBAL_TENSOR_DATA(v91);
        // pto: %598
        ;
        const int64_t v929 = 1;
        // pto: %598
        ;
        const int64_t v930 = 1;
        // pto: %598
        ;
        const int64_t v931 = 1;
        // pto: %598
        ;
        int64_t v932 = v880 * v42;
        // pto: %598
        ;
        int64_t v933 = v931 * v932;
        // pto: %598
        ;
        pto::Shape<1, 1, 1, -1, 512> v934 = pto::Shape<1, 1, 1, -1, 512>(v929, v930, v931, v880, v37);
        // pto: %598
        ;
        pto::Stride<-1, -1, -1, -1, -1> v935 = pto::Stride<-1, -1, -1, -1, -1>(v930 * v933, v933, v932, v42, v29);
        // pto: %598
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v936 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v928 + (v927 + v883 * v42 + v926 * v29), v934, v935);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v924, v936);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %wide_b_weight__tile
        ;
        Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v937 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v37, v36);
        // pto: %wide_b_weight__tile
        ;
        uint64_t v938 = (uint64_t) v23;
        TASSIGN(v937, v938);
        // pto: %601
        ;
        int64_t v939 = v923 / v33;
        // pto: %602
        ;
        int64_t v940 = v939 < v45 ? v45 : v939;
        // pto: %603
        ;
        __gm__ int8_t* v941 = PTOAS__GLOBAL_TENSOR_DATA(v82);
        // pto: %603
        ;
        const int64_t v942 = 0;
        // pto: %603
        ;
        const int64_t v943 = 262144;
        // pto: %603
        ;
        const int64_t v944 = 512;
        // pto: %603
        ;
        pto::Shape<1, 4, 32, 16, 32> v945 = pto::Shape<1, 4, 32, 16, 32>();
        // pto: %603
        ;
        pto::Stride<33554432, 262144, 512, 32, 1> v946 = pto::Stride<33554432, 262144, 512, 32, 1>();
        // pto: %603
        ;
        GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v947 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v941 + (v942 + v897 * v943 + v940 * v944), v945, v946);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        TLOAD(v937, v947);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %27
        ;
        Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v948 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v880, v32);
        // pto: %27
        ;
        uint64_t v949 = (uint64_t) v23;
        TASSIGN(v948, v949);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v950 = static_cast<uint16_t>(v45);
        uint16_t v951 = static_cast<uint16_t>(v45);
        TEXTRACT(v948, v924, v950, v951);
        // pto: %28
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v952 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
        // pto: %28
        ;
        uint64_t v953 = (uint64_t) v23;
        TASSIGN(v952, v953);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v954 = static_cast<uint16_t>(v45);
        uint16_t v955 = static_cast<uint16_t>(v45);
        TEXTRACT(v952, v937, v954, v955);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %29
        ;
        Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v956 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v880, v32);
        // pto: %29
        ;
        uint64_t v957 = (uint64_t) v27;
        TASSIGN(v956, v957);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v958 = static_cast<uint16_t>(v45);
        uint16_t v959 = static_cast<uint16_t>(v32);
        TEXTRACT(v956, v924, v958, v959);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        // pto: %30
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v960 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
        // pto: %30
        ;
        uint64_t v961 = (uint64_t) v26;
        TASSIGN(v960, v961);
        uint16_t v962 = static_cast<uint16_t>(v32);
        uint16_t v963 = static_cast<uint16_t>(v45);
        TEXTRACT(v960, v937, v962, v963);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v904, v904, v948, v952);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v904, v904, v956, v960);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
      // pto: %605
      ;
      int64_t v964 = v878 < v45 ? v45 : v878;
      // pto: %606
      ;
      const int64_t v965 = 0;
      // pto: %606
      ;
      __gm__ int32_t* v966 = PTOAS__GLOBAL_TENSOR_DATA(v109);
      // pto: %606
      ;
      const int64_t v967 = 1;
      // pto: %606
      ;
      const int64_t v968 = 1;
      // pto: %606
      ;
      const int64_t v969 = 1;
      // pto: %606
      ;
      int64_t v970 = v880 * v41;
      // pto: %606
      ;
      int64_t v971 = v969 * v970;
      // pto: %606
      ;
      pto::Shape<1, 1, 1, -1, 128> v972 = pto::Shape<1, 1, 1, -1, 128>(v967, v968, v969, v880, v36);
      // pto: %606
      ;
      pto::Stride<-1, -1, -1, -1, -1> v973 = pto::Stride<-1, -1, -1, -1, -1>(v968 * v971, v971, v970, v41, v29);
      // pto: %606
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v974 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v966 + (v965 + v883 * v41 + v964 * v29), v972, v973);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
      TSTORE(v974, v904);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
    };
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %608
  int64_t v975 = (int64_t) ((uint64_t) v127 + (uint64_t) v67);
  // pto: %609
  int64_t v976 = v975 < v45 ? v45 : v975;
  // pto: %signals_v2__ssa_v0_signal_pview
  __gm__ int32_t* v977 = PTOAS__GLOBAL_TENSOR_DATA(v119);
  // pto: %signals_v2__ssa_v0_signal_pview
  const int64_t v978 = 0;
  // pto: %signals_v2__ssa_v0_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v979 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals_v2__ssa_v0_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v980 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals_v2__ssa_v0_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v981 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v977 + (v978 + v976), v979, v980);
  pto::comm::NotifyOp v982 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v981, v136, v982);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void vector(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ bfloat16_t* v6, __gm__ int8_t* v7, __gm__ float* v8, __gm__ bfloat16_t* v9, __gm__ bfloat16_t* v10, __gm__ float* v11, __gm__ float* v12, __gm__ bfloat16_t* v13, __gm__ float* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21, int32_t v22) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int32_t v23 = 1;
  // pto: %c0_i64
  const int64_t v24 = 0;
  // pto: %c32768_i64
  const int64_t v25 = 32768;
  // pto: %c65536_i64
  const int64_t v26 = 65536;
  // pto: %c65568_i64
  const int64_t v27 = 65568;
  // pto: %c32_i64
  const int64_t v28 = 32;
  // pto: %c64_i64
  const int64_t v29 = 64;
  // pto: %c49152_i64
  const int64_t v30 = 49152;
  // pto: %c67584_i64
  const int64_t v31 = 67584;
  // pto: %c16384_i64
  const int64_t v32 = 16384;
  // pto: %c81920_i64
  const int64_t v33 = 81920;
  // pto: %c98304_i64
  const int64_t v34 = 98304;
  // pto: %c114688_i64
  const int64_t v35 = 114688;
  // pto: %c122880_i64
  const int64_t v36 = 122880;
  // pto: %c1_index
  const int64_t v37 = 1;
  // pto: %c8_index
  const int64_t v38 = 8;
  // pto: %c16_index
  const int64_t v39 = 16;
  // pto: %c128_index
  const int64_t v40 = 128;
  // pto: %c512_index
  const int64_t v41 = 512;
  // pto: %c4096_index
  const int64_t v42 = 4096;
  // pto: %c8192_index
  const int64_t v43 = 8192;
  // pto: %c16384_index
  const int64_t v44 = 16384;
  // pto: %c4_index
  const int64_t v45 = 4;
  // pto: %c55296_index
  const int64_t v46 = 55296;
  // pto: %c2_index
  const int64_t v47 = 2;
  // pto: %c24_index
  const int64_t v48 = 24;
  // pto: %c0_index
  const int64_t v49 = 0;
  // pto: %c15_index
  const int64_t v50 = 15;
  // pto: %c9216_index
  const int64_t v51 = 9216;
  // pto: %c48_index
  const int64_t v52 = 48;
  // pto: %c1024_index
  const int64_t v53 = 1024;
  // pto: %c18432_index
  const int64_t v54 = 18432;
  // pto: %c7_index
  const int64_t v55 = 7;
  // pto: %c21504_index
  const int64_t v56 = 21504;
  // pto: %cst_41
  const float v57 = 0.00787401571f;
  // pto: %cst_42
  const float v58 = 0.0f;
  // pto: %cst_43
  const float v59 = 1.0f;
  // pto: %cst_44
  const float v60 = 127.0f;
  // pto: %c27648_index
  const int64_t v61 = 27648;
  // pto: %c36864_index
  const int64_t v62 = 36864;
  // pto: %c46080_index
  const int64_t v63 = 46080;
  // pto: %c72_index
  const int64_t v64 = 72;
  // pto: %c3_index
  const int64_t v65 = 3;
  // pto: %c12_index
  const int64_t v66 = 12;
  // pto: %c5_index
  const int64_t v67 = 5;
  // pto: %c9_index
  const int64_t v68 = 9;
  // pto: %c13_index
  const int64_t v69 = 13;
  // pto: %c6_index
  const int64_t v70 = 6;
  // pto: %c10_index
  const int64_t v71 = 10;
  // pto: %c14_index
  const int64_t v72 = 14;
  // pto: %c11_index
  const int64_t v73 = 11;
  // pto: %c12288_index
  const int64_t v74 = 12288;
  // pto: %cn1_index
  const int64_t v75 = -1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v78 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v79 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v80 = v42 * v37;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v81 = v79 * v80;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v82 = v78 * v81;
  // pto: %wo_b_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v83 = pto::Shape<1, 1, 1, 1, -1>(v76, v77, v78, v79, v42);
  // pto: %wo_b_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v84 = pto::Stride<-1, -1, -1, -1, -1>(v77 * v82, v82, v81, v80, v37);
  // pto: %wo_b_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v85 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v83, v84);
  // pto: %projected__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %projected__ssa_v0_view
  const int64_t v87 = 1;
  // pto: %projected__ssa_v0_view
  const int64_t v88 = 1;
  // pto: %projected__ssa_v0_view
  int64_t v89 = (int64_t) v17;
  // pto: %projected__ssa_v0_view
  int64_t v90 = v89 * v43;
  // pto: %projected__ssa_v0_view
  int64_t v91 = v88 * v90;
  // pto: %projected__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v92 = pto::Shape<1, 1, 1, -1, -1>(v86, v87, v88, v89, v43);
  // pto: %projected__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v93 = pto::Stride<-1, -1, -1, -1, -1>(v87 * v91, v91, v90, v43, v37);
  // pto: %projected__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v94 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v92, v93);
  // pto: %quantized__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v96 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v97 = 1;
  // pto: %quantized__ssa_v0_view
  int64_t v98 = (int64_t) v17;
  // pto: %quantized__ssa_v0_view
  int64_t v99 = v98 * v43;
  // pto: %quantized__ssa_v0_view
  int64_t v100 = v97 * v99;
  // pto: %quantized__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v101 = pto::Shape<1, 1, 1, -1, -1>(v95, v96, v97, v98, v43);
  // pto: %quantized__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v102 = pto::Stride<-1, -1, -1, -1, -1>(v96 * v100, v100, v99, v43, v37);
  // pto: %quantized__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v103 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v101, v102);
  // pto: %token_scale__ssa_v0_view
  const int64_t v104 = 1;
  // pto: %token_scale__ssa_v0_view
  const int64_t v105 = 1;
  // pto: %token_scale__ssa_v0_view
  const int64_t v106 = 1;
  // pto: %token_scale__ssa_v0_view
  int64_t v107 = (int64_t) v17;
  // pto: %token_scale__ssa_v0_view
  int64_t v108 = v107 * v37;
  // pto: %token_scale__ssa_v0_view
  int64_t v109 = v106 * v108;
  // pto: %token_scale__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v110 = pto::Shape<1, 1, 1, -1, -1>(v104, v105, v106, v107, v37);
  // pto: %token_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v111 = pto::Stride<-1, -1, -1, -1, -1>(v105 * v109, v109, v108, v37, (int64_t) v17);
  // pto: %token_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v112 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v8, v110, v111);
  // pto: %attended__ssa_v0_view
  const int64_t v113 = 1;
  // pto: %attended__ssa_v0_view
  const int64_t v114 = 1;
  // pto: %attended__ssa_v0_view
  const int64_t v115 = 1;
  // pto: %attended__ssa_v0_view
  int64_t v116 = (int64_t) v17;
  // pto: %attended__ssa_v0_view
  int64_t v117 = v116 * v42;
  // pto: %attended__ssa_v0_view
  int64_t v118 = v115 * v117;
  // pto: %attended__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v119 = pto::Shape<1, 1, 1, -1, -1>(v113, v114, v115, v116, v42);
  // pto: %attended__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v120 = pto::Stride<-1, -1, -1, -1, -1>(v114 * v118, v118, v117, v42, v37);
  // pto: %attended__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v121 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v119, v120);
  // pto: %residual__ssa_v0_view
  const int64_t v122 = 1;
  // pto: %residual__ssa_v0_view
  const int64_t v123 = 1;
  // pto: %residual__ssa_v0_view
  const int64_t v124 = 1;
  // pto: %residual__ssa_v0_view
  int64_t v125 = (int64_t) v17;
  // pto: %residual__ssa_v0_view
  int64_t v126 = v125 * v44;
  // pto: %residual__ssa_v0_view
  int64_t v127 = v124 * v126;
  // pto: %residual__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v128 = pto::Shape<1, 1, 1, -1, -1>(v122, v123, v124, v125, v44);
  // pto: %residual__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v129 = pto::Stride<-1, -1, -1, -1, -1>(v123 * v127, v127, v126, v44, v37);
  // pto: %residual__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v130 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v10, v128, v129);
  // pto: %output__ssa_v0_view
  const int64_t v131 = 1;
  // pto: %output__ssa_v0_view
  const int64_t v132 = 1;
  // pto: %output__ssa_v0_view
  const int64_t v133 = 1;
  // pto: %output__ssa_v0_view
  int64_t v134 = (int64_t) v17;
  // pto: %output__ssa_v0_view
  int64_t v135 = v134 * v44;
  // pto: %output__ssa_v0_view
  int64_t v136 = v133 * v135;
  // pto: %output__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v137 = pto::Shape<1, 1, 1, -1, -1>(v131, v132, v133, v134, v44);
  // pto: %output__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v138 = pto::Stride<-1, -1, -1, -1, -1>(v132 * v136, v136, v135, v44, v37);
  // pto: %output__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v139 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v137, v138);
  // pto: %accum__ssa_v0_view
  const int64_t v140 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v141 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v142 = 1;
  // pto: %accum__ssa_v0_view
  int64_t v143 = (int64_t) v18;
  // pto: %accum__ssa_v0_view
  int64_t v144 = v143 * v43;
  // pto: %accum__ssa_v0_view
  int64_t v145 = v142 * v144;
  // pto: %accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v146 = pto::Shape<1, 1, 1, -1, -1>(v140, v141, v142, v143, v43);
  // pto: %accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v147 = pto::Stride<-1, -1, -1, -1, -1>(v141 * v145, v145, v144, v43, v37);
  // pto: %accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v148 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v146, v147);
  // pto: %integer_accum__ssa_v0_view
  const int64_t v149 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v150 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v151 = 1;
  // pto: %integer_accum__ssa_v0_view
  int64_t v152 = (int64_t) v19;
  // pto: %integer_accum__ssa_v0_view
  int64_t v153 = v152 * v42;
  // pto: %integer_accum__ssa_v0_view
  int64_t v154 = v151 * v153;
  // pto: %integer_accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v155 = pto::Shape<1, 1, 1, -1, -1>(v149, v150, v151, v152, v42);
  // pto: %integer_accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v156 = pto::Stride<-1, -1, -1, -1, -1>(v150 * v154, v154, v153, v42, v37);
  // pto: %integer_accum__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v157 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v155, v156);
  // pto: %signals__ssa_v0_view
  const int64_t v158 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v159 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v160 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v161 = 1;
  // pto: %signals__ssa_v0_view
  int64_t v162 = v46 * v37;
  // pto: %signals__ssa_v0_view
  int64_t v163 = v161 * v162;
  // pto: %signals__ssa_v0_view
  int64_t v164 = v160 * v163;
  // pto: %signals__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v165 = pto::Shape<1, 1, 1, 1, -1>(v158, v159, v160, v161, v46);
  // pto: %signals__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v166 = pto::Stride<-1, -1, -1, -1, -1>(v159 * v164, v164, v163, v162, v37);
  // pto: %signals__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v167 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v165, v166);
  // pto: %t__tmp_v0, %145, %146, %t__tmp_v1
  int64_t v168 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v20) * (uint64_t) v47) + (uint64_t) ((int64_t) v22));
  // pto: %147, %148
  int64_t v169 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v168 + (uint64_t) v48) * (uint64_t) v40);
  // pto: %149
  int64_t v170 = v169 < v49 ? v49 : v169;
  // pto: %signals__ssa_v0_pview
  __gm__ int32_t* v171 = PTOAS__GLOBAL_TENSOR_DATA(v167);
  // pto: %signals__ssa_v0_pview
  const int64_t v172 = 0;
  // pto: %signals__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 1> v173 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  pto::Stride<1, 1, 1, 1, 1> v174 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v175 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v171 + (v172 + v170), v173, v174);
  __gm__ int32_t* v176 = PTOAS__GLOBAL_TENSOR_DATA(v175);
  PTOAS__DCCI_SINGLE_CACHE_LINE(v176);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  // pto: %150
  int32_t v177 = (v16)[v169];
  // pto: %152
  int32_t v178 = (int32_t) ((uint32_t) v177 + (uint32_t) v23);
  pipe_barrier(PIPE_ALL);
  pto::comm::NotifyOp v179 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v175, v178, v179);
  // pto: %154, %155, %156
  int64_t v180 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v17 + (uint64_t) v50) / v39) * (uint64_t) v38);
  // pto: %157
  if (v168 < v180) {
    for (int64_t v181 = v49; v181 < v38; v181 += v37) {
      // pto: %158
      ;
      int64_t v182 = v168 % v38;
      // pto: %159, %160, %161
      ;
      int64_t v183 = v182 < v49 ? (int64_t) ((uint64_t) v182 + (uint64_t) v38) : v182;
      // pto: %162, %163, %164
      ;
      int64_t v184 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v183 * (uint64_t) v38) + (uint64_t) v181) % v48;
      // pto: %165, %166, %167
      ;
      int64_t v185 = v184 < v49 ? (int64_t) ((uint64_t) v184 + (uint64_t) v48) : v184;
      // pto: %168, %169
      ;
      int64_t v186 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v185 * (uint64_t) v40) + (uint64_t) v51);
      // pto: %170
      ;
      int64_t v187 = v186 < v49 ? v49 : v186;
      // pto: %signals__ssa_v1_signal_pview
      ;
      __gm__ int32_t* v188 = PTOAS__GLOBAL_TENSOR_DATA(v167);
      // pto: %signals__ssa_v1_signal_pview
      ;
      const int64_t v189 = 0;
      // pto: %signals__ssa_v1_signal_pview
      ;
      pto::Shape<1, 1, 1, 1, 1> v190 = pto::Shape<1, 1, 1, 1, 1>();
      // pto: %signals__ssa_v1_signal_pview
      ;
      pto::Stride<1, 1, 1, 1, 1> v191 = pto::Stride<1, 1, 1, 1, 1>();
      // pto: %signals__ssa_v1_signal_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v192 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v188 + (v189 + v187), v190, v191);
      pto::comm::WaitCmp v193 = pto::comm::WaitCmp::GE;
      pto::comm::TWAIT(v192, v178, v193);
    };
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
  }
  for (int64_t v194 = v168; v194 < v180; v194 += v52) {
    // pto: %172, %173
    ;
    int64_t v195 = (int64_t) ((uint64_t) (v194 / v38) * (uint64_t) v39);
    // pto: %174
    ;
    int64_t v196 = v194 % v38;
    // pto: %175, %176, %177
    ;
    int64_t v197 = v196 < v49 ? (int64_t) ((uint64_t) v196 + (uint64_t) v38) : v196;
    // pto: %178
    ;
    int64_t v198 = (int64_t) ((uint64_t) v197 * (uint64_t) v53);
    // pto: %179
    ;
    int64_t v199 = (int64_t) ((uint64_t) v17 - (uint64_t) v195);
    // pto: %180
    ;
    int64_t v200 = v199 < v39 ? v199 : v39;
    // pto: %oa_value__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v201 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v200, v53);
    // pto: %oa_value__ssa_v0
    ;
    uint64_t v202 = (uint64_t) v24;
    TASSIGN(v201, v202);
    // pto: %181
    ;
    int64_t v203 = v195 < v49 ? v49 : v195;
    // pto: %182
    ;
    int64_t v204 = v198 < v49 ? v49 : v198;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v205 = 0;
    // pto: %accum__ssa_v0_pview
    ;
    __gm__ float* v206 = PTOAS__GLOBAL_TENSOR_DATA(v148);
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v207 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v208 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v209 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    int64_t v210 = v200 * v43;
    // pto: %accum__ssa_v0_pview
    ;
    int64_t v211 = v209 * v210;
    // pto: %accum__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1024> v212 = pto::Shape<1, 1, 1, -1, 1024>(v207, v208, v209, v200, v53);
    // pto: %accum__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v213 = pto::Stride<-1, -1, -1, -1, -1>(v208 * v211, v211, v210, v43, v37);
    // pto: %accum__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v214 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v206 + (v205 + v203 * v43 + v204 * v37), v212, v213);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v201, v214);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %t__tmp_v3
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v200, v53);
    // pto: %t__tmp_v3
    ;
    uint64_t v216 = (uint64_t) v24;
    TASSIGN(v215, v216);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v217 = RoundMode::CAST_RINT;
    SaturationMode v218 = SaturationMode::ON;
    TCVT(v215, v201, v217, v218);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v219 = 0;
    // pto: %projected__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v220 = PTOAS__GLOBAL_TENSOR_DATA(v94);
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v221 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v222 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v223 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    int64_t v224 = v200 * v43;
    // pto: %projected__ssa_v0_pview
    ;
    int64_t v225 = v223 * v224;
    // pto: %projected__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1024> v226 = pto::Shape<1, 1, 1, -1, 1024>(v221, v222, v223, v200, v53);
    // pto: %projected__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v227 = pto::Stride<-1, -1, -1, -1, -1>(v222 * v225, v225, v224, v43, v37);
    // pto: %projected__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v228 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v220 + (v219 + v203 * v43 + v204 * v37), v226, v227);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v228, v215);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %186
  int64_t v229 = (int64_t) ((uint64_t) v169 + (uint64_t) v54);
  // pto: %187
  int64_t v230 = v229 < v49 ? v49 : v229;
  // pto: %188
  __gm__ int32_t* v231 = PTOAS__GLOBAL_TENSOR_DATA(v167);
  // pto: %188
  const int64_t v232 = 0;
  // pto: %188
  pto::Shape<1, 1, 1, 1, 1> v233 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %188
  pto::Stride<1, 1, 1, 1, 1> v234 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %188
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v235 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v231 + (v232 + v230), v233, v234);
  pto::comm::NotifyOp v236 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v235, v178, v236);
  // pto: %189, %190
  int64_t v237 = (int64_t) ((uint64_t) v17 + (uint64_t) v55) / v38;
  // pto: %191
  if (v168 < v237) {
    for (int64_t v238 = v49; v238 < v38; v238 += v37) {
      // pto: %192, %193, %194, %195
      ;
      int64_t v239 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) (v168 / v47) * (uint64_t) v38) + (uint64_t) v238) % v52;
      // pto: %196, %197, %198
      ;
      int64_t v240 = v239 < v49 ? (int64_t) ((uint64_t) v239 + (uint64_t) v52) : v239;
      // pto: %199, %200
      ;
      int64_t v241 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v240 * (uint64_t) v40) + (uint64_t) v56);
      // pto: %201
      ;
      int64_t v242 = v241 < v49 ? v49 : v241;
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      __gm__ int32_t* v243 = PTOAS__GLOBAL_TENSOR_DATA(v167);
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      const int64_t v244 = 0;
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      pto::Shape<1, 1, 1, 1, 1> v245 = pto::Shape<1, 1, 1, 1, 1>();
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      pto::Stride<1, 1, 1, 1, 1> v246 = pto::Stride<1, 1, 1, 1, 1>();
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v247 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v243 + (v244 + v242), v245, v246);
      pto::comm::WaitCmp v248 = pto::comm::WaitCmp::GE;
      pto::comm::TWAIT(v247, v178, v248);
    };
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  for (int64_t v249 = v168; v249 < v237; v249 += v52) {
    // pto: %203
    ;
    int64_t v250 = (int64_t) ((uint64_t) v249 * (uint64_t) v38);
    // pto: %204
    ;
    int64_t v251 = (int64_t) ((uint64_t) v17 - (uint64_t) v250);
    // pto: %205
    ;
    int64_t v252 = v251 < v38 ? v251 : v38;
    // pto: %first_quant__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v253 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
    // pto: %first_quant__ssa_v0
    ;
    uint64_t v254 = (uint64_t) v25;
    TASSIGN(v253, v254);
    // pto: %206
    ;
    int64_t v255 = v250 < v49 ? v49 : v250;
    // pto: %207
    ;
    const int64_t v256 = 0;
    // pto: %207
    ;
    __gm__ bfloat16_t* v257 = PTOAS__GLOBAL_TENSOR_DATA(v94);
    // pto: %207
    ;
    const int64_t v258 = 1;
    // pto: %207
    ;
    const int64_t v259 = 1;
    // pto: %207
    ;
    const int64_t v260 = 1;
    // pto: %207
    ;
    int64_t v261 = v252 * v43;
    // pto: %207
    ;
    int64_t v262 = v260 * v261;
    // pto: %207
    ;
    pto::Shape<1, 1, 1, -1, 1024> v263 = pto::Shape<1, 1, 1, -1, 1024>(v258, v259, v260, v252, v53);
    // pto: %207
    ;
    pto::Stride<-1, -1, -1, -1, -1> v264 = pto::Stride<-1, -1, -1, -1, -1>(v259 * v262, v262, v261, v43, v37);
    // pto: %207
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v265 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v257 + (v256 + v255 * v43 + v49 * v37), v263, v264);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v253, v265);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %t__tmp_v4
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v266 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
    // pto: %t__tmp_v4
    ;
    uint64_t v267 = (uint64_t) v24;
    TASSIGN(v266, v267);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    pipe_barrier(PIPE_V);
    RoundMode v268 = RoundMode::CAST_ROUND;
    SaturationMode v269 = SaturationMode::ON;
    TCVT(v266, v253, v268, v269);
    // pto: %first_abs__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v270 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
    // pto: %first_abs__ssa_v0
    ;
    uint64_t v271 = (uint64_t) v24;
    TASSIGN(v270, v271);
    pipe_barrier(PIPE_V);
    TABS(v270, v266);
    // pto: %t__tmp_v5
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v272 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v53);
    // pto: %t__tmp_v5
    ;
    uint64_t v273 = (uint64_t) v25;
    TASSIGN(v272, v273);
    // pto: %amax__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v274 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v37);
    // pto: %amax__ssa_v0
    ;
    uint64_t v275 = (uint64_t) v26;
    TASSIGN(v274, v275);
    pipe_barrier(PIPE_V);
    TROWMAX(v274, v270, v272);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    for (int64_t v276 = v37; v276 < v38; v276 += v37) {
      // pto: %q_bf16__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v277 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
      // pto: %q_bf16__ssa_v0
      ;
      uint64_t v278 = (uint64_t) v25;
      TASSIGN(v277, v278);
      // pto: %209
      ;
      int64_t v279 = (int64_t) ((uint64_t) v276 * (uint64_t) v53);
      // pto: %210
      ;
      int64_t v280 = v279 < v49 ? v49 : v279;
      // pto: %211
      ;
      const int64_t v281 = 0;
      // pto: %211
      ;
      __gm__ bfloat16_t* v282 = PTOAS__GLOBAL_TENSOR_DATA(v94);
      // pto: %211
      ;
      const int64_t v283 = 1;
      // pto: %211
      ;
      const int64_t v284 = 1;
      // pto: %211
      ;
      const int64_t v285 = 1;
      // pto: %211
      ;
      int64_t v286 = v252 * v43;
      // pto: %211
      ;
      int64_t v287 = v285 * v286;
      // pto: %211
      ;
      pto::Shape<1, 1, 1, -1, 1024> v288 = pto::Shape<1, 1, 1, -1, 1024>(v283, v284, v285, v252, v53);
      // pto: %211
      ;
      pto::Stride<-1, -1, -1, -1, -1> v289 = pto::Stride<-1, -1, -1, -1, -1>(v284 * v287, v287, v286, v43, v37);
      // pto: %211
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v290 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v282 + (v281 + v255 * v43 + v280 * v37), v288, v289);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      TLOAD(v277, v290);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %q_fp32__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v291 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
      // pto: %q_fp32__ssa_v0
      ;
      uint64_t v292 = (uint64_t) v24;
      TASSIGN(v291, v292);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      pipe_barrier(PIPE_V);
      RoundMode v293 = RoundMode::CAST_ROUND;
      SaturationMode v294 = SaturationMode::ON;
      TCVT(v291, v277, v293, v294);
      // pto: %t__tmp_v6
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v295 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
      // pto: %t__tmp_v6
      ;
      uint64_t v296 = (uint64_t) v24;
      TASSIGN(v295, v296);
      pipe_barrier(PIPE_V);
      TABS(v295, v291);
      // pto: %t__tmp_v7
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v297 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v53);
      // pto: %t__tmp_v7
      ;
      uint64_t v298 = (uint64_t) v25;
      TASSIGN(v297, v298);
      // pto: %t__tmp_v8
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v299 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v37);
      // pto: %t__tmp_v8
      ;
      uint64_t v300 = (uint64_t) v27;
      TASSIGN(v299, v300);
      pipe_barrier(PIPE_V);
      TROWMAX(v299, v295, v297);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      // pto: %amax__rm_a0_tmp_v0
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v301 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
      // pto: %amax__rm_a0_tmp_v0
      ;
      uint64_t v302 = (uint64_t) v26;
      TASSIGN(v301, v302);
      // pto: %amax__rm_a1_tmp_v1
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v303 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
      // pto: %amax__rm_a1_tmp_v1
      ;
      uint64_t v304 = (uint64_t) v27;
      TASSIGN(v303, v304);
      // pto: %amax__row_major_tmp_v2
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v305 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
      // pto: %amax__row_major_tmp_v2
      ;
      uint64_t v306 = (uint64_t) v24;
      TASSIGN(v305, v306);
      pipe_barrier(PIPE_V);
      TMAX(v305, v301, v303);
      // pto: %amax__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v307 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v37);
      // pto: %amax__ssa_v3
      ;
      uint64_t v308 = (uint64_t) v24;
      TASSIGN(v307, v308);
      // pto: %amax__ssa_v3_mv
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v37);
      // pto: %amax__ssa_v3_mv
      ;
      uint64_t v310 = (uint64_t) v26;
      TASSIGN(v309, v310);
      pipe_barrier(PIPE_V);
      TMOV(v309, v307);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    // pto: %dequant__rm_a0_tmp_v3
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v311 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
    // pto: %dequant__rm_a0_tmp_v3
    ;
    uint64_t v312 = (uint64_t) v26;
    TASSIGN(v311, v312);
    // pto: %dequant__row_major_tmp_v4
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
    // pto: %dequant__row_major_tmp_v4
    ;
    uint64_t v314 = (uint64_t) v24;
    TASSIGN(v313, v314);
    pipe_barrier(PIPE_V);
    TMULS(v313, v311, v57);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %dequant__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v37);
    // pto: %dequant__ssa_v0
    ;
    uint64_t v316 = (uint64_t) v24;
    TASSIGN(v315, v316);
    // pto: %denominator__rm_a0_tmp_v5
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v317 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
    // pto: %denominator__rm_a0_tmp_v5
    ;
    uint64_t v318 = (uint64_t) v26;
    TASSIGN(v317, v318);
    // pto: %denominator__row_major_tmp_v6
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v319 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
    // pto: %denominator__row_major_tmp_v6
    ;
    uint64_t v320 = (uint64_t) v28;
    TASSIGN(v319, v320);
    TADDS(v319, v317, v58);
    set_flag(PIPE_V, PIPE_S, EVENT_ID0);
    // pto: %denominator__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v321 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v37);
    // pto: %denominator__ssa_v0
    ;
    uint64_t v322 = (uint64_t) v28;
    TASSIGN(v321, v322);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
    for (int64_t v323 = v49; v323 < v252; v323 += v37) {
      // pto: %magnitude__ssa_v0
      ;
      float v324 = v321.GetValue(v323);
      // pto: %212
      ;
      bool v325 = v324 != v324 || v58 != v58;
      // pto: %212
      ;
      if ((v324 == v324 && v58 == v58) && v324 == v58) {
        v321.SetValue(v323, v59);
      };
    };
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
    // pto: %t__rm_a0_tmp_v7
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v326 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
    // pto: %t__rm_a0_tmp_v7
    ;
    uint64_t v327 = (uint64_t) v26;
    TASSIGN(v326, v327);
    // pto: %t__row_major_tmp_v8
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v328 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
    // pto: %t__row_major_tmp_v8
    ;
    uint64_t v329 = (uint64_t) v29;
    TASSIGN(v328, v329);
    TMULS(v328, v326, v58);
    // pto: %t__tmp_v9
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v330 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v37);
    // pto: %t__tmp_v9
    ;
    uint64_t v331 = (uint64_t) v29;
    TASSIGN(v330, v331);
    // pto: %t__rm_a0_tmp_v9
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v332 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
    // pto: %t__rm_a0_tmp_v9
    ;
    uint64_t v333 = (uint64_t) v29;
    TASSIGN(v332, v333);
    // pto: %t__row_major_tmp_v10
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v334 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
    // pto: %t__row_major_tmp_v10
    ;
    uint64_t v335 = (uint64_t) v29;
    TASSIGN(v334, v335);
    pipe_barrier(PIPE_V);
    TADDS(v334, v332, v60);
    // pto: %t__tmp_v10
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v336 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v37);
    // pto: %t__tmp_v10
    ;
    uint64_t v337 = (uint64_t) v29;
    TASSIGN(v336, v337);
    // pto: %multiplier__rm_a0_tmp_v11
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v338 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
    // pto: %multiplier__rm_a0_tmp_v11
    ;
    uint64_t v339 = (uint64_t) v29;
    TASSIGN(v338, v339);
    // pto: %multiplier__rm_a1_tmp_v12
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v340 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
    // pto: %multiplier__rm_a1_tmp_v12
    ;
    uint64_t v341 = (uint64_t) v28;
    TASSIGN(v340, v341);
    // pto: %multiplier__row_major_tmp_v13
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v342 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
    // pto: %multiplier__row_major_tmp_v13
    ;
    uint64_t v343 = (uint64_t) v30;
    TASSIGN(v342, v343);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    TDIV(v342, v338, v340);
    // pto: %multiplier__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v344 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v37);
    // pto: %multiplier__ssa_v0
    ;
    uint64_t v345 = (uint64_t) v30;
    TASSIGN(v344, v345);
    v315.SetValidShape(v252, v37);
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v346 = (int64_t) v17;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v347 = 0;
    // pto: %token_scale__ssa_v0_pview
    ;
    __gm__ float* v348 = PTOAS__GLOBAL_TENSOR_DATA(v112);
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v349 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v350 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v351 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v352 = v252 * v37;
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v353 = v351 * v352;
    // pto: %token_scale__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1> v354 = pto::Shape<1, 1, 1, -1, 1>(v349, v350, v351, v252, v37);
    // pto: %token_scale__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v355 = pto::Stride<-1, -1, -1, -1, -1>(v350 * v353, v353, v352, v37, v346);
    // pto: %token_scale__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v356 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v348 + (v347 + v255 * v37 + v49 * v346), v354, v355);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    TSTORE(v356, v315);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    for (int64_t v357 = v49; v357 < v38; v357 += v37) {
      // pto: %217
      ;
      int64_t v358 = (int64_t) ((uint64_t) v357 * (uint64_t) v53);
      // pto: %quant_bf16__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v359 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
      // pto: %quant_bf16__ssa_v0
      ;
      uint64_t v360 = (uint64_t) v25;
      TASSIGN(v359, v360);
      // pto: %219
      ;
      int64_t v361 = v358 < v49 ? v49 : v358;
      // pto: %220
      ;
      const int64_t v362 = 0;
      // pto: %220
      ;
      __gm__ bfloat16_t* v363 = PTOAS__GLOBAL_TENSOR_DATA(v94);
      // pto: %220
      ;
      const int64_t v364 = 1;
      // pto: %220
      ;
      const int64_t v365 = 1;
      // pto: %220
      ;
      const int64_t v366 = 1;
      // pto: %220
      ;
      int64_t v367 = v252 * v43;
      // pto: %220
      ;
      int64_t v368 = v366 * v367;
      // pto: %220
      ;
      pto::Shape<1, 1, 1, -1, 1024> v369 = pto::Shape<1, 1, 1, -1, 1024>(v364, v365, v366, v252, v53);
      // pto: %220
      ;
      pto::Stride<-1, -1, -1, -1, -1> v370 = pto::Stride<-1, -1, -1, -1, -1>(v365 * v368, v368, v367, v43, v37);
      // pto: %220
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v371 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v363 + (v362 + v255 * v43 + v361 * v37), v369, v370);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      TLOAD(v359, v371);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %t__tmp_v12
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v372 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
      // pto: %t__tmp_v12
      ;
      uint64_t v373 = (uint64_t) v24;
      TASSIGN(v372, v373);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      RoundMode v374 = RoundMode::CAST_ROUND;
      SaturationMode v375 = SaturationMode::ON;
      TCVT(v372, v359, v374, v375);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      // pto: %quant_scaled__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v376 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
      // pto: %quant_scaled__ssa_v0
      ;
      uint64_t v377 = (uint64_t) v24;
      TASSIGN(v376, v377);
      pipe_barrier(PIPE_V);
      TROWEXPANDMUL(v376, v372, v344);
      // pto: %integer__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v378 = Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
      // pto: %integer__ssa_v0
      ;
      uint64_t v379 = (uint64_t) v24;
      TASSIGN(v378, v379);
      pipe_barrier(PIPE_V);
      RoundMode v380 = RoundMode::CAST_RINT;
      SaturationMode v381 = SaturationMode::ON;
      TCVT(v378, v376, v380, v381);
      // pto: %half__ssa_v0
      ;
      Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v382 = Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
      // pto: %half__ssa_v0
      ;
      uint64_t v383 = (uint64_t) v24;
      TASSIGN(v382, v383);
      pipe_barrier(PIPE_V);
      RoundMode v384 = RoundMode::CAST_ROUND;
      SaturationMode v385 = SaturationMode::ON;
      TCVT(v382, v378, v384, v385);
      // pto: %result__ssa_v0
      ;
      Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v386 = Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
      // pto: %result__ssa_v0
      ;
      uint64_t v387 = (uint64_t) v24;
      TASSIGN(v386, v387);
      pipe_barrier(PIPE_V);
      RoundMode v388 = RoundMode::CAST_TRUNC;
      SaturationMode v389 = SaturationMode::ON;
      TCVT(v386, v382, v388, v389);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      v386.SetValidShape(v252, v53);
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v390 = 0;
      // pto: %quantized__ssa_v0_pview
      ;
      __gm__ int8_t* v391 = PTOAS__GLOBAL_TENSOR_DATA(v103);
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v392 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v393 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v394 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      int64_t v395 = v252 * v43;
      // pto: %quantized__ssa_v0_pview
      ;
      int64_t v396 = v394 * v395;
      // pto: %quantized__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 1024> v397 = pto::Shape<1, 1, 1, -1, 1024>(v392, v393, v394, v252, v53);
      // pto: %quantized__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v398 = pto::Stride<-1, -1, -1, -1, -1>(v393 * v396, v396, v395, v43, v37);
      // pto: %quantized__ssa_v0_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v399 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v391 + (v390 + v255 * v43 + v361 * v37), v397, v398);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      TSTORE(v399, v386);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %224
  int64_t v400 = (int64_t) ((uint64_t) v169 + (uint64_t) v61);
  // pto: %225
  int64_t v401 = v400 < v49 ? v49 : v400;
  // pto: %226
  __gm__ int32_t* v402 = PTOAS__GLOBAL_TENSOR_DATA(v167);
  // pto: %226
  const int64_t v403 = 0;
  // pto: %226
  pto::Shape<1, 1, 1, 1, 1> v404 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %226
  pto::Stride<1, 1, 1, 1, 1> v405 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %226
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v406 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v402 + (v403 + v401), v404, v405);
  pto::comm::NotifyOp v407 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v406, v178, v407);
  for (int64_t v408 = v49; v408 < v48; v408 += v37) {
    // pto: %227, %228
    ;
    int64_t v409 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v408 * (uint64_t) v40) + (uint64_t) v62);
    // pto: %229
    ;
    int64_t v410 = v409 < v49 ? v49 : v409;
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v411 = PTOAS__GLOBAL_TENSOR_DATA(v167);
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    const int64_t v412 = 0;
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v413 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v414 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v415 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v411 + (v412 + v410), v413, v414);
    pto::comm::WaitCmp v416 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v415, v178, v416);
  }
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  for (int64_t v417 = v168; v417 < v180; v417 += v52) {
    // pto: %232, %233
    ;
    int64_t v418 = (int64_t) ((uint64_t) (v417 / v38) * (uint64_t) v39);
    // pto: %234
    ;
    int64_t v419 = v417 % v38;
    // pto: %235, %236, %237
    ;
    int64_t v420 = v419 < v49 ? (int64_t) ((uint64_t) v419 + (uint64_t) v38) : v419;
    // pto: %238
    ;
    int64_t v421 = (int64_t) ((uint64_t) v420 * (uint64_t) v41);
    // pto: %239
    ;
    int64_t v422 = (int64_t) ((uint64_t) v17 - (uint64_t) v418);
    // pto: %240
    ;
    int64_t v423 = v422 < v39 ? v422 : v39;
    // pto: %ob_integer__ssa_v0
    ;
    Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v424 = Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v423, v41);
    // pto: %ob_integer__ssa_v0
    ;
    uint64_t v425 = (uint64_t) v24;
    TASSIGN(v424, v425);
    // pto: %241
    ;
    int64_t v426 = v418 < v49 ? v49 : v418;
    // pto: %242
    ;
    int64_t v427 = v421 < v49 ? v49 : v421;
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v428 = 0;
    // pto: %integer_accum__ssa_v0_pview
    ;
    __gm__ int32_t* v429 = PTOAS__GLOBAL_TENSOR_DATA(v157);
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v430 = 1;
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v431 = 1;
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v432 = 1;
    // pto: %integer_accum__ssa_v0_pview
    ;
    int64_t v433 = v423 * v42;
    // pto: %integer_accum__ssa_v0_pview
    ;
    int64_t v434 = v432 * v433;
    // pto: %integer_accum__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v435 = pto::Shape<1, 1, 1, -1, 512>(v430, v431, v432, v423, v41);
    // pto: %integer_accum__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v436 = pto::Stride<-1, -1, -1, -1, -1>(v431 * v434, v434, v433, v42, v37);
    // pto: %integer_accum__ssa_v0_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v437 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v429 + (v428 + v426 * v42 + v427 * v37), v435, v436);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    TLOAD(v424, v437);
    // pto: %t__tmp_v14
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v438 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v41);
    // pto: %t__tmp_v14
    ;
    uint64_t v439 = (uint64_t) v26;
    TASSIGN(v438, v439);
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    __gm__ float* v440 = PTOAS__GLOBAL_TENSOR_DATA(v85);
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    const int64_t v441 = 0;
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 512> v442 = pto::Shape<1, 1, 1, 1, 512>();
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    pto::Stride<512, 512, 512, 512, 1> v443 = pto::Stride<512, 512, 512, 512, 1>();
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v444 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v440 + (v441 + v427), v442, v443);
    TLOAD(v438, v444);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    // pto: %channel__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v445 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v41);
    // pto: %channel__ssa_v0
    ;
    uint64_t v446 = (uint64_t) v26;
    TASSIGN(v445, v446);
    // pto: %scale__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v447 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v423, v37);
    // pto: %scale__ssa_v0
    ;
    uint64_t v448 = (uint64_t) v31;
    TASSIGN(v447, v448);
    // pto: %245
    ;
    int64_t v449 = (int64_t) v17;
    // pto: %245
    ;
    const int64_t v450 = 0;
    // pto: %245
    ;
    __gm__ float* v451 = PTOAS__GLOBAL_TENSOR_DATA(v112);
    // pto: %245
    ;
    const int64_t v452 = 1;
    // pto: %245
    ;
    const int64_t v453 = 1;
    // pto: %245
    ;
    const int64_t v454 = 1;
    // pto: %245
    ;
    int64_t v455 = v423 * v37;
    // pto: %245
    ;
    int64_t v456 = v454 * v455;
    // pto: %245
    ;
    pto::Shape<1, 1, 1, -1, 1> v457 = pto::Shape<1, 1, 1, -1, 1>(v452, v453, v454, v423, v37);
    // pto: %245
    ;
    pto::Stride<-1, -1, -1, -1, -1> v458 = pto::Stride<-1, -1, -1, -1, -1>(v453 * v456, v456, v455, v37, v449);
    // pto: %245
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v459 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v451 + (v450 + v426 * v37 + v49 * v449), v457, v458);
    TLOAD(v447, v459);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    // pto: %coefficient_one__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v460 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v39, v41);
    // pto: %coefficient_one__ssa_v0
    ;
    uint64_t v461 = (uint64_t) v25;
    TASSIGN(v460, v461);
    pipe_barrier(PIPE_V);
    TEXPANDS(v460, v59);
    // pto: %coefficient_channel__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v462 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v39, v41);
    // pto: %coefficient_channel__ssa_v0
    ;
    uint64_t v463 = (uint64_t) v25;
    TASSIGN(v462, v463);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    TCOLEXPANDMUL(v462, v460, v445);
    // pto: %coefficient__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v464 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v39, v41);
    // pto: %coefficient__ssa_v0
    ;
    uint64_t v465 = (uint64_t) v25;
    TASSIGN(v464, v465);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    TROWEXPANDMUL(v464, v462, v447);
    // pto: %t__tmp_v15
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v466 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v423, v41);
    // pto: %t__tmp_v15
    ;
    uint64_t v467 = (uint64_t) v24;
    TASSIGN(v466, v467);
    RoundMode v468 = RoundMode::CAST_ROUND;
    SaturationMode v469 = SaturationMode::ON;
    TCVT(v466, v424, v468, v469);
    // pto: %ob_scaled__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v470 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v423, v41);
    // pto: %ob_scaled__ssa_v0
    ;
    uint64_t v471 = (uint64_t) v24;
    TASSIGN(v470, v471);
    pipe_barrier(PIPE_V);
    TMUL(v470, v466, v464);
    // pto: %t__tmp_v16
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v472 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v423, v41);
    // pto: %t__tmp_v16
    ;
    uint64_t v473 = (uint64_t) v24;
    TASSIGN(v472, v473);
    pipe_barrier(PIPE_V);
    RoundMode v474 = RoundMode::CAST_RINT;
    SaturationMode v475 = SaturationMode::ON;
    TCVT(v472, v470, v474, v475);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v476 = 0;
    // pto: %attended__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v477 = PTOAS__GLOBAL_TENSOR_DATA(v121);
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v478 = 1;
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v479 = 1;
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v480 = 1;
    // pto: %attended__ssa_v0_pview
    ;
    int64_t v481 = v423 * v42;
    // pto: %attended__ssa_v0_pview
    ;
    int64_t v482 = v480 * v481;
    // pto: %attended__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v483 = pto::Shape<1, 1, 1, -1, 512>(v478, v479, v480, v423, v41);
    // pto: %attended__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v484 = pto::Stride<-1, -1, -1, -1, -1>(v479 * v482, v482, v481, v42, v37);
    // pto: %attended__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v485 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v477 + (v476 + v426 * v42 + v427 * v37), v483, v484);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    TSTORE(v485, v472);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %249
  int64_t v486 = (int64_t) ((uint64_t) v169 + (uint64_t) v63);
  // pto: %250
  int64_t v487 = v486 < v49 ? v49 : v486;
  // pto: %signals_v3__ssa_v0_signal_pview
  __gm__ int32_t* v488 = PTOAS__GLOBAL_TENSOR_DATA(v167);
  // pto: %signals_v3__ssa_v0_signal_pview
  const int64_t v489 = 0;
  // pto: %signals_v3__ssa_v0_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v490 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals_v3__ssa_v0_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v491 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals_v3__ssa_v0_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v492 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v488 + (v489 + v487), v490, v491);
  pto::comm::NotifyOp v493 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v492, v178, v493);
  for (int64_t v494 = v48; v494 < v64; v494 += v37) {
    // pto: %251, %252
    ;
    int64_t v495 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v494 * (uint64_t) v40) + (uint64_t) v63);
    // pto: %253
    ;
    int64_t v496 = v495 < v49 ? v49 : v495;
    // pto: %signals_v4__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v497 = PTOAS__GLOBAL_TENSOR_DATA(v167);
    // pto: %signals_v4__ssa_v0_signal_pview
    ;
    const int64_t v498 = 0;
    // pto: %signals_v4__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v499 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v4__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v500 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v4__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v501 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v497 + (v498 + v496), v499, v500);
    pto::comm::WaitCmp v502 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v501, v178, v502);
  }
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %254, %255
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  for (int64_t v503 = v168; v503 < ((int64_t) ((uint64_t) v17 + (uint64_t) v65) / v45); v503 += v52) {
    // pto: %256
    ;
    int64_t v504 = (int64_t) ((uint64_t) v503 * (uint64_t) v45);
    // pto: %257
    ;
    int64_t v505 = (int64_t) ((uint64_t) v504 + (uint64_t) v45);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    for (int64_t v506 = v504; v506 < v505; v506 += v47) {
      // pto: %258
      ;
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      if (v506 < v17) {
        // pto: %259
        ;
        int64_t v507 = (int64_t) ((uint64_t) v506 * (uint64_t) v45);
        // pto: %post_scalar__tile
        ;
        float v508 = (v11)[v507];
        // pto: %261
        ;
        int64_t v509 = (int64_t) ((uint64_t) v506 * (uint64_t) v39);
        // pto: %comb_scalar_0__tile
        ;
        float v510 = (v12)[v509];
        // pto: %264, %comb_scalar_1__tile
        ;
        float v511 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v45)];
        // pto: %266, %comb_scalar_2__tile
        ;
        float v512 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v38)];
        // pto: %268, %comb_scalar_3__tile
        ;
        float v513 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v66)];
        // pto: %271, %269
        ;
        float v514 = (v11)[(int64_t) ((uint64_t) v507 + (uint64_t) v37)];
        // pto: %274, %272
        ;
        float v515 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v37)];
        // pto: %277, %275
        ;
        float v516 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v67)];
        // pto: %280, %278
        ;
        float v517 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v68)];
        // pto: %283, %281
        ;
        float v518 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v69)];
        // pto: %286, %284
        ;
        float v519 = (v11)[(int64_t) ((uint64_t) v507 + (uint64_t) v47)];
        // pto: %289, %287
        ;
        float v520 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v47)];
        // pto: %292, %290
        ;
        float v521 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v70)];
        // pto: %295, %293
        ;
        float v522 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v71)];
        // pto: %298, %296
        ;
        float v523 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v72)];
        // pto: %301, %299
        ;
        float v524 = (v11)[(int64_t) ((uint64_t) v507 + (uint64_t) v65)];
        // pto: %304, %302
        ;
        float v525 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v65)];
        // pto: %307, %305
        ;
        float v526 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v55)];
        // pto: %310, %308
        ;
        float v527 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v73)];
        // pto: %313, %311
        ;
        float v528 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v50)];
        // pto: %x_block__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v529 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %x_block__tile
        ;
        uint64_t v530 = (uint64_t) v32;
        TASSIGN(v529, v530);
        // pto: %314
        ;
        int64_t v531 = v506 < v49 ? v49 : v506;
        // pto: %x__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v532 = PTOAS__GLOBAL_TENSOR_DATA(v121);
        // pto: %x__ssa_v0_pview
        ;
        const int64_t v533 = 0;
        // pto: %x__ssa_v0_pview
        ;
        const int64_t v534 = 4096;
        // pto: %x__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v535 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %x__ssa_v0_pview
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v536 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %x__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v537 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v532 + (v533 + v531 * v534), v535, v536);
        TLOAD(v529, v537);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        // pto: %315
        ;
        int64_t v538 = (int64_t) ((uint64_t) v17 - (uint64_t) v506);
        // pto: %316
        ;
        int64_t v539 = v538 < v49 ? v49 : v538;
        // pto: %317
        ;
        int64_t v540 = v539 < v37 ? v539 : v37;
        // pto: %t__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v541 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %t__tile
        ;
        uint64_t v542 = (uint64_t) v25;
        TASSIGN(v541, v542);
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v543 = 0;
        // pto: %residual_flat__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v544 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v545 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v546 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v547 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        int64_t v548 = v540 * v44;
        // pto: %residual_flat__ssa_v0_pview
        ;
        int64_t v549 = v547 * v548;
        // pto: %residual_flat__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 4096> v550 = pto::Shape<1, 1, 1, -1, 4096>(v545, v546, v547, v540, v42);
        // pto: %residual_flat__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v551 = pto::Stride<-1, -1, -1, -1, -1>(v546 * v549, v549, v548, v44, v37);
        // pto: %residual_flat__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v552 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v544 + (v543 + v531 * v44 + v49 * v37), v550, v551);
        TLOAD(v541, v552);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        // pto: %0
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v553 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %0
        ;
        uint64_t v554 = (uint64_t) v30;
        TASSIGN(v553, v554);
        // pto: %329
        ;
        const int64_t v555 = 0;
        // pto: %329
        ;
        __gm__ bfloat16_t* v556 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %329
        ;
        const int64_t v557 = 1;
        // pto: %329
        ;
        const int64_t v558 = 1;
        // pto: %329
        ;
        const int64_t v559 = 1;
        // pto: %329
        ;
        int64_t v560 = v540 * v44;
        // pto: %329
        ;
        int64_t v561 = v559 * v560;
        // pto: %329
        ;
        pto::Shape<1, 1, 1, -1, 4096> v562 = pto::Shape<1, 1, 1, -1, 4096>(v557, v558, v559, v540, v42);
        // pto: %329
        ;
        pto::Stride<-1, -1, -1, -1, -1> v563 = pto::Stride<-1, -1, -1, -1, -1>(v558 * v561, v561, v560, v44, v37);
        // pto: %329
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v564 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v556 + (v555 + v531 * v44 + v42 * v37), v562, v563);
        TLOAD(v553, v564);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %1
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v565 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %1
        ;
        uint64_t v566 = (uint64_t) v26;
        TASSIGN(v565, v566);
        // pto: %337
        ;
        const int64_t v567 = 0;
        // pto: %337
        ;
        __gm__ bfloat16_t* v568 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %337
        ;
        const int64_t v569 = 1;
        // pto: %337
        ;
        const int64_t v570 = 1;
        // pto: %337
        ;
        const int64_t v571 = 1;
        // pto: %337
        ;
        int64_t v572 = v540 * v44;
        // pto: %337
        ;
        int64_t v573 = v571 * v572;
        // pto: %337
        ;
        pto::Shape<1, 1, 1, -1, 4096> v574 = pto::Shape<1, 1, 1, -1, 4096>(v569, v570, v571, v540, v42);
        // pto: %337
        ;
        pto::Stride<-1, -1, -1, -1, -1> v575 = pto::Stride<-1, -1, -1, -1, -1>(v570 * v573, v573, v572, v44, v37);
        // pto: %337
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v576 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v568 + (v567 + v531 * v44 + v43 * v37), v574, v575);
        TLOAD(v565, v576);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %2
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v577 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %2
        ;
        uint64_t v578 = (uint64_t) v33;
        TASSIGN(v577, v578);
        // pto: %345
        ;
        const int64_t v579 = 0;
        // pto: %345
        ;
        __gm__ bfloat16_t* v580 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %345
        ;
        const int64_t v581 = 1;
        // pto: %345
        ;
        const int64_t v582 = 1;
        // pto: %345
        ;
        const int64_t v583 = 1;
        // pto: %345
        ;
        int64_t v584 = v540 * v44;
        // pto: %345
        ;
        int64_t v585 = v583 * v584;
        // pto: %345
        ;
        pto::Shape<1, 1, 1, -1, 4096> v586 = pto::Shape<1, 1, 1, -1, 4096>(v581, v582, v583, v540, v42);
        // pto: %345
        ;
        pto::Stride<-1, -1, -1, -1, -1> v587 = pto::Stride<-1, -1, -1, -1, -1>(v582 * v585, v585, v584, v44, v37);
        // pto: %345
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v588 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v580 + (v579 + v531 * v44 + v74 * v37), v586, v587);
        TLOAD(v577, v588);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %x_f32__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v589 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %x_f32__tile
        ;
        uint64_t v590 = (uint64_t) v24;
        TASSIGN(v589, v590);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        RoundMode v591 = RoundMode::CAST_ROUND;
        SaturationMode v592 = SaturationMode::ON;
        TCVT(v589, v529, v591, v592);
        // pto: %res_0__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v593 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %res_0__tile
        ;
        uint64_t v594 = (uint64_t) v32;
        TASSIGN(v593, v594);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        RoundMode v595 = RoundMode::CAST_ROUND;
        SaturationMode v596 = SaturationMode::ON;
        TCVT(v593, v541, v595, v596);
        // pto: %res_1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v597 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %res_1__tile
        ;
        uint64_t v598 = (uint64_t) v25;
        TASSIGN(v597, v598);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v599 = RoundMode::CAST_ROUND;
        SaturationMode v600 = SaturationMode::ON;
        TCVT(v597, v553, v599, v600);
        // pto: %res_2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v601 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %res_2__tile
        ;
        uint64_t v602 = (uint64_t) v30;
        TASSIGN(v601, v602);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        RoundMode v603 = RoundMode::CAST_ROUND;
        SaturationMode v604 = SaturationMode::ON;
        TCVT(v601, v565, v603, v604);
        // pto: %res_3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v605 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %res_3__tile
        ;
        uint64_t v606 = (uint64_t) v26;
        TASSIGN(v605, v606);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v607 = RoundMode::CAST_ROUND;
        SaturationMode v608 = SaturationMode::ON;
        TCVT(v605, v577, v607, v608);
        // pto: %single_y__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v609 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_y__tile
        ;
        uint64_t v610 = (uint64_t) v33;
        TASSIGN(v609, v610);
        pipe_barrier(PIPE_V);
        TMULS(v609, v589, v508);
        // pto: %single_weighted_0__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v611 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %single_weighted_0__tile
        ;
        uint64_t v612 = (uint64_t) v34;
        TASSIGN(v611, v612);
        TMULS(v611, v593, v510);
        // pto: %single_y_v1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v613 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_y_v1__tile
        ;
        uint64_t v614 = (uint64_t) v33;
        TASSIGN(v613, v614);
        pipe_barrier(PIPE_V);
        TADD(v613, v609, v611);
        // pto: %single_weighted_1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v615 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %single_weighted_1__tile
        ;
        uint64_t v616 = (uint64_t) v34;
        TASSIGN(v615, v616);
        pipe_barrier(PIPE_V);
        TMULS(v615, v597, v511);
        // pto: %single_y_v2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v617 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_y_v2__tile
        ;
        uint64_t v618 = (uint64_t) v33;
        TASSIGN(v617, v618);
        pipe_barrier(PIPE_V);
        TADD(v617, v613, v615);
        // pto: %single_weighted_2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v619 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %single_weighted_2__tile
        ;
        uint64_t v620 = (uint64_t) v34;
        TASSIGN(v619, v620);
        pipe_barrier(PIPE_V);
        TMULS(v619, v601, v512);
        // pto: %single_y_v3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v621 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_y_v3__tile
        ;
        uint64_t v622 = (uint64_t) v33;
        TASSIGN(v621, v622);
        pipe_barrier(PIPE_V);
        TADD(v621, v617, v619);
        // pto: %single_weighted_3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v623 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %single_weighted_3__tile
        ;
        uint64_t v624 = (uint64_t) v34;
        TASSIGN(v623, v624);
        pipe_barrier(PIPE_V);
        TMULS(v623, v605, v513);
        // pto: %single_y_v4__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v625 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_y_v4__tile
        ;
        uint64_t v626 = (uint64_t) v33;
        TASSIGN(v625, v626);
        pipe_barrier(PIPE_V);
        TADD(v625, v621, v623);
        // pto: %single_result__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v627 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_result__tile
        ;
        uint64_t v628 = (uint64_t) v35;
        TASSIGN(v627, v628);
        pipe_barrier(PIPE_V);
        RoundMode v629 = RoundMode::CAST_RINT;
        SaturationMode v630 = SaturationMode::ON;
        TCVT(v627, v625, v629, v630);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        v627.SetValidShape(v37, v42);
        // pto: %4
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v631 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %4
        ;
        uint64_t v632 = (uint64_t) v33;
        TASSIGN(v631, v632);
        pipe_barrier(PIPE_V);
        TMULS(v631, v589, v514);
        // pto: %5
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v633 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %5
        ;
        uint64_t v634 = (uint64_t) v34;
        TASSIGN(v633, v634);
        TMULS(v633, v593, v515);
        // pto: %6
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v635 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %6
        ;
        uint64_t v636 = (uint64_t) v33;
        TASSIGN(v635, v636);
        pipe_barrier(PIPE_V);
        TADD(v635, v631, v633);
        // pto: %7
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v637 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %7
        ;
        uint64_t v638 = (uint64_t) v34;
        TASSIGN(v637, v638);
        pipe_barrier(PIPE_V);
        TMULS(v637, v597, v516);
        // pto: %8
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v639 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %8
        ;
        uint64_t v640 = (uint64_t) v33;
        TASSIGN(v639, v640);
        pipe_barrier(PIPE_V);
        TADD(v639, v635, v637);
        // pto: %9
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v641 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %9
        ;
        uint64_t v642 = (uint64_t) v34;
        TASSIGN(v641, v642);
        pipe_barrier(PIPE_V);
        TMULS(v641, v601, v517);
        // pto: %10
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v643 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %10
        ;
        uint64_t v644 = (uint64_t) v33;
        TASSIGN(v643, v644);
        pipe_barrier(PIPE_V);
        TADD(v643, v639, v641);
        // pto: %11
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v645 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %11
        ;
        uint64_t v646 = (uint64_t) v34;
        TASSIGN(v645, v646);
        pipe_barrier(PIPE_V);
        TMULS(v645, v605, v518);
        // pto: %12
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v647 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %12
        ;
        uint64_t v648 = (uint64_t) v33;
        TASSIGN(v647, v648);
        pipe_barrier(PIPE_V);
        TADD(v647, v643, v645);
        // pto: %13
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v649 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %13
        ;
        uint64_t v650 = (uint64_t) v36;
        TASSIGN(v649, v650);
        pipe_barrier(PIPE_V);
        RoundMode v651 = RoundMode::CAST_RINT;
        SaturationMode v652 = SaturationMode::ON;
        TCVT(v649, v647, v651, v652);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        v649.SetValidShape(v37, v42);
        // pto: %15
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v653 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %15
        ;
        uint64_t v654 = (uint64_t) v33;
        TASSIGN(v653, v654);
        pipe_barrier(PIPE_V);
        TMULS(v653, v589, v519);
        // pto: %16
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v655 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %16
        ;
        uint64_t v656 = (uint64_t) v34;
        TASSIGN(v655, v656);
        TMULS(v655, v593, v520);
        // pto: %17
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v657 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %17
        ;
        uint64_t v658 = (uint64_t) v33;
        TASSIGN(v657, v658);
        pipe_barrier(PIPE_V);
        TADD(v657, v653, v655);
        // pto: %18
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v659 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %18
        ;
        uint64_t v660 = (uint64_t) v34;
        TASSIGN(v659, v660);
        pipe_barrier(PIPE_V);
        TMULS(v659, v597, v521);
        // pto: %19
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v661 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %19
        ;
        uint64_t v662 = (uint64_t) v33;
        TASSIGN(v661, v662);
        pipe_barrier(PIPE_V);
        TADD(v661, v657, v659);
        // pto: %20
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v663 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %20
        ;
        uint64_t v664 = (uint64_t) v34;
        TASSIGN(v663, v664);
        pipe_barrier(PIPE_V);
        TMULS(v663, v601, v522);
        // pto: %21
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v665 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %21
        ;
        uint64_t v666 = (uint64_t) v33;
        TASSIGN(v665, v666);
        pipe_barrier(PIPE_V);
        TADD(v665, v661, v663);
        // pto: %22
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v667 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %22
        ;
        uint64_t v668 = (uint64_t) v34;
        TASSIGN(v667, v668);
        pipe_barrier(PIPE_V);
        TMULS(v667, v605, v523);
        // pto: %23
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v669 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %23
        ;
        uint64_t v670 = (uint64_t) v33;
        TASSIGN(v669, v670);
        pipe_barrier(PIPE_V);
        TADD(v669, v665, v667);
        // pto: %24
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v671 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %24
        ;
        uint64_t v672 = (uint64_t) v33;
        TASSIGN(v671, v672);
        pipe_barrier(PIPE_V);
        RoundMode v673 = RoundMode::CAST_RINT;
        SaturationMode v674 = SaturationMode::ON;
        TCVT(v671, v669, v673, v674);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        v671.SetValidShape(v37, v42);
        // pto: %26
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v675 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %26
        ;
        uint64_t v676 = (uint64_t) v24;
        TASSIGN(v675, v676);
        TMULS(v675, v589, v524);
        // pto: %27
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v677 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %27
        ;
        uint64_t v678 = (uint64_t) v32;
        TASSIGN(v677, v678);
        TMULS(v677, v593, v525);
        // pto: %28
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v679 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %28
        ;
        uint64_t v680 = (uint64_t) v24;
        TASSIGN(v679, v680);
        pipe_barrier(PIPE_V);
        TADD(v679, v675, v677);
        // pto: %29
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v681 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %29
        ;
        uint64_t v682 = (uint64_t) v32;
        TASSIGN(v681, v682);
        pipe_barrier(PIPE_V);
        TMULS(v681, v597, v526);
        // pto: %30
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v683 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %30
        ;
        uint64_t v684 = (uint64_t) v24;
        TASSIGN(v683, v684);
        pipe_barrier(PIPE_V);
        TADD(v683, v679, v681);
        // pto: %31
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v685 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %31
        ;
        uint64_t v686 = (uint64_t) v32;
        TASSIGN(v685, v686);
        pipe_barrier(PIPE_V);
        TMULS(v685, v601, v527);
        // pto: %32
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v687 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %32
        ;
        uint64_t v688 = (uint64_t) v24;
        TASSIGN(v687, v688);
        pipe_barrier(PIPE_V);
        TADD(v687, v683, v685);
        // pto: %33
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v689 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %33
        ;
        uint64_t v690 = (uint64_t) v32;
        TASSIGN(v689, v690);
        pipe_barrier(PIPE_V);
        TMULS(v689, v605, v528);
        // pto: %34
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v691 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %34
        ;
        uint64_t v692 = (uint64_t) v24;
        TASSIGN(v691, v692);
        pipe_barrier(PIPE_V);
        TADD(v691, v687, v689);
        // pto: %35
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v693 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %35
        ;
        uint64_t v694 = (uint64_t) v24;
        TASSIGN(v693, v694);
        pipe_barrier(PIPE_V);
        RoundMode v695 = RoundMode::CAST_RINT;
        SaturationMode v696 = SaturationMode::ON;
        TCVT(v693, v691, v695, v696);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        v693.SetValidShape(v37, v42);
        // pto: %y_flat__iter_v3_pview
        ;
        __gm__ bfloat16_t* v697 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %y_flat__iter_v3_pview
        ;
        const int64_t v698 = 0;
        // pto: %y_flat__iter_v3_pview
        ;
        const int64_t v699 = 16384;
        // pto: %y_flat__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v700 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__iter_v3_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v701 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v702 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v697 + (v698 + v531 * v699), v700, v701);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        TSTORE(v702, v627);
        // pto: %y_flat__tile_pview
        ;
        __gm__ bfloat16_t* v703 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %y_flat__tile_pview
        ;
        const int64_t v704 = 4096;
        // pto: %y_flat__tile_pview
        ;
        const int64_t v705 = 16384;
        // pto: %y_flat__tile_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v706 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__tile_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v707 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__tile_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v708 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v703 + (v704 + v531 * v705), v706, v707);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        TSTORE(v708, v649);
        // pto: %411
        ;
        __gm__ bfloat16_t* v709 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %411
        ;
        const int64_t v710 = 8192;
        // pto: %411
        ;
        const int64_t v711 = 16384;
        // pto: %411
        ;
        pto::Shape<1, 1, 1, 1, 4096> v712 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %411
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v713 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %411
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v714 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v709 + (v710 + v531 * v711), v712, v713);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        TSTORE(v714, v671);
        // pto: %414
        ;
        __gm__ bfloat16_t* v715 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %414
        ;
        const int64_t v716 = 12288;
        // pto: %414
        ;
        const int64_t v717 = 16384;
        // pto: %414
        ;
        pto::Shape<1, 1, 1, 1, 4096> v718 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %414
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v719 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %414
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v720 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v715 + (v716 + v531 * v717), v718, v719);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        TSTORE(v720, v693);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      // pto: %415
      ;
      int64_t v721 = (int64_t) ((uint64_t) v506 + (uint64_t) v37);
      // pto: %416
      ;
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      if (v721 < v17) {
        // pto: %419
        ;
        int64_t v722 = (int64_t) ((uint64_t) v721 * (uint64_t) v45);
        // pto: %417
        ;
        float v723 = (v11)[v722];
        // pto: %423
        ;
        int64_t v724 = (int64_t) ((uint64_t) v721 * (uint64_t) v39);
        // pto: %421
        ;
        float v725 = (v12)[v724];
        // pto: %428, %425
        ;
        float v726 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v45)];
        // pto: %432, %429
        ;
        float v727 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v38)];
        // pto: %436, %433
        ;
        float v728 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v66)];
        // pto: %440, %437
        ;
        float v729 = (v11)[(int64_t) ((uint64_t) v722 + (uint64_t) v37)];
        // pto: %444, %441
        ;
        float v730 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v37)];
        // pto: %448, %445
        ;
        float v731 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v67)];
        // pto: %452, %449
        ;
        float v732 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v68)];
        // pto: %456, %453
        ;
        float v733 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v69)];
        // pto: %460, %457
        ;
        float v734 = (v11)[(int64_t) ((uint64_t) v722 + (uint64_t) v47)];
        // pto: %464, %461
        ;
        float v735 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v47)];
        // pto: %468, %465
        ;
        float v736 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v70)];
        // pto: %472, %469
        ;
        float v737 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v71)];
        // pto: %476, %473
        ;
        float v738 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v72)];
        // pto: %480, %477
        ;
        float v739 = (v11)[(int64_t) ((uint64_t) v722 + (uint64_t) v65)];
        // pto: %484, %481
        ;
        float v740 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v65)];
        // pto: %488, %485
        ;
        float v741 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v55)];
        // pto: %492, %489
        ;
        float v742 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v73)];
        // pto: %496, %493
        ;
        float v743 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v50)];
        // pto: %37
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v744 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %37
        ;
        uint64_t v745 = (uint64_t) v32;
        TASSIGN(v744, v745);
        // pto: %498
        ;
        int64_t v746 = v721 < v49 ? v49 : v721;
        // pto: %499
        ;
        __gm__ bfloat16_t* v747 = PTOAS__GLOBAL_TENSOR_DATA(v121);
        // pto: %499
        ;
        const int64_t v748 = 0;
        // pto: %499
        ;
        const int64_t v749 = 4096;
        // pto: %499
        ;
        pto::Shape<1, 1, 1, 1, 4096> v750 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %499
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v751 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %499
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v752 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v747 + (v748 + v746 * v749), v750, v751);
        TLOAD(v744, v752);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %500, %501
        ;
        int64_t v753 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v17 - (uint64_t) v506) + (uint64_t) v75);
        // pto: %502
        ;
        int64_t v754 = v753 < v49 ? v49 : v753;
        // pto: %503
        ;
        int64_t v755 = v754 < v37 ? v754 : v37;
        // pto: %38
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v756 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %38
        ;
        uint64_t v757 = (uint64_t) v25;
        TASSIGN(v756, v757);
        // pto: %510
        ;
        const int64_t v758 = 0;
        // pto: %510
        ;
        __gm__ bfloat16_t* v759 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %510
        ;
        const int64_t v760 = 1;
        // pto: %510
        ;
        const int64_t v761 = 1;
        // pto: %510
        ;
        const int64_t v762 = 1;
        // pto: %510
        ;
        int64_t v763 = v755 * v44;
        // pto: %510
        ;
        int64_t v764 = v762 * v763;
        // pto: %510
        ;
        pto::Shape<1, 1, 1, -1, 4096> v765 = pto::Shape<1, 1, 1, -1, 4096>(v760, v761, v762, v755, v42);
        // pto: %510
        ;
        pto::Stride<-1, -1, -1, -1, -1> v766 = pto::Stride<-1, -1, -1, -1, -1>(v761 * v764, v764, v763, v44, v37);
        // pto: %510
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v767 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v759 + (v758 + v746 * v44 + v49 * v37), v765, v766);
        TLOAD(v756, v767);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %39
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v768 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %39
        ;
        uint64_t v769 = (uint64_t) v30;
        TASSIGN(v768, v769);
        // pto: %521
        ;
        const int64_t v770 = 0;
        // pto: %521
        ;
        __gm__ bfloat16_t* v771 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %521
        ;
        const int64_t v772 = 1;
        // pto: %521
        ;
        const int64_t v773 = 1;
        // pto: %521
        ;
        const int64_t v774 = 1;
        // pto: %521
        ;
        int64_t v775 = v755 * v44;
        // pto: %521
        ;
        int64_t v776 = v774 * v775;
        // pto: %521
        ;
        pto::Shape<1, 1, 1, -1, 4096> v777 = pto::Shape<1, 1, 1, -1, 4096>(v772, v773, v774, v755, v42);
        // pto: %521
        ;
        pto::Stride<-1, -1, -1, -1, -1> v778 = pto::Stride<-1, -1, -1, -1, -1>(v773 * v776, v776, v775, v44, v37);
        // pto: %521
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v779 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v771 + (v770 + v746 * v44 + v42 * v37), v777, v778);
        TLOAD(v768, v779);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %40
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v780 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %40
        ;
        uint64_t v781 = (uint64_t) v26;
        TASSIGN(v780, v781);
        // pto: %532
        ;
        const int64_t v782 = 0;
        // pto: %532
        ;
        __gm__ bfloat16_t* v783 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %532
        ;
        const int64_t v784 = 1;
        // pto: %532
        ;
        const int64_t v785 = 1;
        // pto: %532
        ;
        const int64_t v786 = 1;
        // pto: %532
        ;
        int64_t v787 = v755 * v44;
        // pto: %532
        ;
        int64_t v788 = v786 * v787;
        // pto: %532
        ;
        pto::Shape<1, 1, 1, -1, 4096> v789 = pto::Shape<1, 1, 1, -1, 4096>(v784, v785, v786, v755, v42);
        // pto: %532
        ;
        pto::Stride<-1, -1, -1, -1, -1> v790 = pto::Stride<-1, -1, -1, -1, -1>(v785 * v788, v788, v787, v44, v37);
        // pto: %532
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v791 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v783 + (v782 + v746 * v44 + v43 * v37), v789, v790);
        TLOAD(v780, v791);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        // pto: %41
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v792 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %41
        ;
        uint64_t v793 = (uint64_t) v33;
        TASSIGN(v792, v793);
        // pto: %543
        ;
        const int64_t v794 = 0;
        // pto: %543
        ;
        __gm__ bfloat16_t* v795 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %543
        ;
        const int64_t v796 = 1;
        // pto: %543
        ;
        const int64_t v797 = 1;
        // pto: %543
        ;
        const int64_t v798 = 1;
        // pto: %543
        ;
        int64_t v799 = v755 * v44;
        // pto: %543
        ;
        int64_t v800 = v798 * v799;
        // pto: %543
        ;
        pto::Shape<1, 1, 1, -1, 4096> v801 = pto::Shape<1, 1, 1, -1, 4096>(v796, v797, v798, v755, v42);
        // pto: %543
        ;
        pto::Stride<-1, -1, -1, -1, -1> v802 = pto::Stride<-1, -1, -1, -1, -1>(v797 * v800, v800, v799, v44, v37);
        // pto: %543
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v803 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v795 + (v794 + v746 * v44 + v74 * v37), v801, v802);
        TLOAD(v792, v803);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        // pto: %42
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v804 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %42
        ;
        uint64_t v805 = (uint64_t) v24;
        TASSIGN(v804, v805);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v806 = RoundMode::CAST_ROUND;
        SaturationMode v807 = SaturationMode::ON;
        TCVT(v804, v744, v806, v807);
        // pto: %43
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v808 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %43
        ;
        uint64_t v809 = (uint64_t) v32;
        TASSIGN(v808, v809);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        RoundMode v810 = RoundMode::CAST_ROUND;
        SaturationMode v811 = SaturationMode::ON;
        TCVT(v808, v756, v810, v811);
        // pto: %44
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v812 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %44
        ;
        uint64_t v813 = (uint64_t) v25;
        TASSIGN(v812, v813);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v814 = RoundMode::CAST_ROUND;
        SaturationMode v815 = SaturationMode::ON;
        TCVT(v812, v768, v814, v815);
        // pto: %45
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v816 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %45
        ;
        uint64_t v817 = (uint64_t) v30;
        TASSIGN(v816, v817);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        RoundMode v818 = RoundMode::CAST_ROUND;
        SaturationMode v819 = SaturationMode::ON;
        TCVT(v816, v780, v818, v819);
        // pto: %46
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v820 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %46
        ;
        uint64_t v821 = (uint64_t) v26;
        TASSIGN(v820, v821);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        RoundMode v822 = RoundMode::CAST_ROUND;
        SaturationMode v823 = SaturationMode::ON;
        TCVT(v820, v792, v822, v823);
        // pto: %47
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v824 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %47
        ;
        uint64_t v825 = (uint64_t) v33;
        TASSIGN(v824, v825);
        pipe_barrier(PIPE_V);
        TMULS(v824, v804, v723);
        // pto: %48
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v826 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %48
        ;
        uint64_t v827 = (uint64_t) v34;
        TASSIGN(v826, v827);
        TMULS(v826, v808, v725);
        // pto: %49
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v828 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %49
        ;
        uint64_t v829 = (uint64_t) v33;
        TASSIGN(v828, v829);
        pipe_barrier(PIPE_V);
        TADD(v828, v824, v826);
        // pto: %50
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v830 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %50
        ;
        uint64_t v831 = (uint64_t) v34;
        TASSIGN(v830, v831);
        pipe_barrier(PIPE_V);
        TMULS(v830, v812, v726);
        // pto: %51
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v832 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %51
        ;
        uint64_t v833 = (uint64_t) v33;
        TASSIGN(v832, v833);
        pipe_barrier(PIPE_V);
        TADD(v832, v828, v830);
        // pto: %52
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v834 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %52
        ;
        uint64_t v835 = (uint64_t) v34;
        TASSIGN(v834, v835);
        pipe_barrier(PIPE_V);
        TMULS(v834, v816, v727);
        // pto: %53
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v836 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %53
        ;
        uint64_t v837 = (uint64_t) v33;
        TASSIGN(v836, v837);
        pipe_barrier(PIPE_V);
        TADD(v836, v832, v834);
        // pto: %54
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v838 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %54
        ;
        uint64_t v839 = (uint64_t) v34;
        TASSIGN(v838, v839);
        pipe_barrier(PIPE_V);
        TMULS(v838, v820, v728);
        // pto: %55
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v840 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %55
        ;
        uint64_t v841 = (uint64_t) v33;
        TASSIGN(v840, v841);
        pipe_barrier(PIPE_V);
        TADD(v840, v836, v838);
        // pto: %56
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v842 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %56
        ;
        uint64_t v843 = (uint64_t) v35;
        TASSIGN(v842, v843);
        pipe_barrier(PIPE_V);
        RoundMode v844 = RoundMode::CAST_RINT;
        SaturationMode v845 = SaturationMode::ON;
        TCVT(v842, v840, v844, v845);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v842.SetValidShape(v37, v42);
        // pto: %58
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v846 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %58
        ;
        uint64_t v847 = (uint64_t) v33;
        TASSIGN(v846, v847);
        pipe_barrier(PIPE_V);
        TMULS(v846, v804, v729);
        // pto: %59
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v848 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %59
        ;
        uint64_t v849 = (uint64_t) v34;
        TASSIGN(v848, v849);
        TMULS(v848, v808, v730);
        // pto: %60
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v850 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %60
        ;
        uint64_t v851 = (uint64_t) v33;
        TASSIGN(v850, v851);
        pipe_barrier(PIPE_V);
        TADD(v850, v846, v848);
        // pto: %61
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v852 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %61
        ;
        uint64_t v853 = (uint64_t) v34;
        TASSIGN(v852, v853);
        pipe_barrier(PIPE_V);
        TMULS(v852, v812, v731);
        // pto: %62
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v854 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %62
        ;
        uint64_t v855 = (uint64_t) v33;
        TASSIGN(v854, v855);
        pipe_barrier(PIPE_V);
        TADD(v854, v850, v852);
        // pto: %63
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v856 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %63
        ;
        uint64_t v857 = (uint64_t) v34;
        TASSIGN(v856, v857);
        pipe_barrier(PIPE_V);
        TMULS(v856, v816, v732);
        // pto: %64
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v858 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %64
        ;
        uint64_t v859 = (uint64_t) v33;
        TASSIGN(v858, v859);
        pipe_barrier(PIPE_V);
        TADD(v858, v854, v856);
        // pto: %65
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v860 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %65
        ;
        uint64_t v861 = (uint64_t) v34;
        TASSIGN(v860, v861);
        pipe_barrier(PIPE_V);
        TMULS(v860, v820, v733);
        // pto: %66
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v862 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %66
        ;
        uint64_t v863 = (uint64_t) v33;
        TASSIGN(v862, v863);
        pipe_barrier(PIPE_V);
        TADD(v862, v858, v860);
        // pto: %67
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v864 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %67
        ;
        uint64_t v865 = (uint64_t) v36;
        TASSIGN(v864, v865);
        pipe_barrier(PIPE_V);
        RoundMode v866 = RoundMode::CAST_RINT;
        SaturationMode v867 = SaturationMode::ON;
        TCVT(v864, v862, v866, v867);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        v864.SetValidShape(v37, v42);
        // pto: %69
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v868 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %69
        ;
        uint64_t v869 = (uint64_t) v33;
        TASSIGN(v868, v869);
        pipe_barrier(PIPE_V);
        TMULS(v868, v804, v734);
        // pto: %70
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v870 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %70
        ;
        uint64_t v871 = (uint64_t) v34;
        TASSIGN(v870, v871);
        TMULS(v870, v808, v735);
        // pto: %71
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v872 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %71
        ;
        uint64_t v873 = (uint64_t) v33;
        TASSIGN(v872, v873);
        pipe_barrier(PIPE_V);
        TADD(v872, v868, v870);
        // pto: %72
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v874 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %72
        ;
        uint64_t v875 = (uint64_t) v34;
        TASSIGN(v874, v875);
        pipe_barrier(PIPE_V);
        TMULS(v874, v812, v736);
        // pto: %73
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v876 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %73
        ;
        uint64_t v877 = (uint64_t) v33;
        TASSIGN(v876, v877);
        pipe_barrier(PIPE_V);
        TADD(v876, v872, v874);
        // pto: %74
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v878 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %74
        ;
        uint64_t v879 = (uint64_t) v34;
        TASSIGN(v878, v879);
        pipe_barrier(PIPE_V);
        TMULS(v878, v816, v737);
        // pto: %75
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v880 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %75
        ;
        uint64_t v881 = (uint64_t) v33;
        TASSIGN(v880, v881);
        pipe_barrier(PIPE_V);
        TADD(v880, v876, v878);
        // pto: %76
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v882 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %76
        ;
        uint64_t v883 = (uint64_t) v34;
        TASSIGN(v882, v883);
        pipe_barrier(PIPE_V);
        TMULS(v882, v820, v738);
        // pto: %77
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v884 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %77
        ;
        uint64_t v885 = (uint64_t) v33;
        TASSIGN(v884, v885);
        pipe_barrier(PIPE_V);
        TADD(v884, v880, v882);
        // pto: %78
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v886 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %78
        ;
        uint64_t v887 = (uint64_t) v33;
        TASSIGN(v886, v887);
        pipe_barrier(PIPE_V);
        RoundMode v888 = RoundMode::CAST_RINT;
        SaturationMode v889 = SaturationMode::ON;
        TCVT(v886, v884, v888, v889);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        v886.SetValidShape(v37, v42);
        // pto: %80
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v890 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %80
        ;
        uint64_t v891 = (uint64_t) v24;
        TASSIGN(v890, v891);
        TMULS(v890, v804, v739);
        // pto: %81
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v892 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %81
        ;
        uint64_t v893 = (uint64_t) v32;
        TASSIGN(v892, v893);
        TMULS(v892, v808, v740);
        // pto: %82
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v894 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %82
        ;
        uint64_t v895 = (uint64_t) v24;
        TASSIGN(v894, v895);
        pipe_barrier(PIPE_V);
        TADD(v894, v890, v892);
        // pto: %83
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v896 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %83
        ;
        uint64_t v897 = (uint64_t) v32;
        TASSIGN(v896, v897);
        pipe_barrier(PIPE_V);
        TMULS(v896, v812, v741);
        // pto: %84
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v898 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %84
        ;
        uint64_t v899 = (uint64_t) v24;
        TASSIGN(v898, v899);
        pipe_barrier(PIPE_V);
        TADD(v898, v894, v896);
        // pto: %85
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v900 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %85
        ;
        uint64_t v901 = (uint64_t) v32;
        TASSIGN(v900, v901);
        pipe_barrier(PIPE_V);
        TMULS(v900, v816, v742);
        // pto: %86
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v902 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %86
        ;
        uint64_t v903 = (uint64_t) v24;
        TASSIGN(v902, v903);
        pipe_barrier(PIPE_V);
        TADD(v902, v898, v900);
        // pto: %87
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v904 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %87
        ;
        uint64_t v905 = (uint64_t) v32;
        TASSIGN(v904, v905);
        pipe_barrier(PIPE_V);
        TMULS(v904, v820, v743);
        // pto: %88
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v906 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %88
        ;
        uint64_t v907 = (uint64_t) v24;
        TASSIGN(v906, v907);
        pipe_barrier(PIPE_V);
        TADD(v906, v902, v904);
        // pto: %89
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v908 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %89
        ;
        uint64_t v909 = (uint64_t) v24;
        TASSIGN(v908, v909);
        pipe_barrier(PIPE_V);
        RoundMode v910 = RoundMode::CAST_RINT;
        SaturationMode v911 = SaturationMode::ON;
        TCVT(v908, v906, v910, v911);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        v908.SetValidShape(v37, v42);
        // pto: %y_flat__phi_v9_pview
        ;
        __gm__ bfloat16_t* v912 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %y_flat__phi_v9_pview
        ;
        const int64_t v913 = 0;
        // pto: %y_flat__phi_v9_pview
        ;
        const int64_t v914 = 16384;
        // pto: %y_flat__phi_v9_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v915 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__phi_v9_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v916 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__phi_v9_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v917 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v912 + (v913 + v746 * v914), v915, v916);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v917, v842);
        // pto: %630
        ;
        __gm__ bfloat16_t* v918 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %630
        ;
        const int64_t v919 = 4096;
        // pto: %630
        ;
        const int64_t v920 = 16384;
        // pto: %630
        ;
        pto::Shape<1, 1, 1, 1, 4096> v921 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %630
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v922 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %630
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v923 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v918 + (v919 + v746 * v920), v921, v922);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v923, v864);
        // pto: %634
        ;
        __gm__ bfloat16_t* v924 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %634
        ;
        const int64_t v925 = 8192;
        // pto: %634
        ;
        const int64_t v926 = 16384;
        // pto: %634
        ;
        pto::Shape<1, 1, 1, 1, 4096> v927 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %634
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v928 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %634
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v929 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v924 + (v925 + v746 * v926), v927, v928);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        TSTORE(v929, v886);
        // pto: %638
        ;
        __gm__ bfloat16_t* v930 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %638
        ;
        const int64_t v931 = 12288;
        // pto: %638
        ;
        const int64_t v932 = 16384;
        // pto: %638
        ;
        pto::Shape<1, 1, 1, 1, 4096> v933 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %638
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v934 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %638
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v935 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v930 + (v931 + v746 * v932), v933, v934);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        TSTORE(v935, v908);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    // pto: %639, %640, %641
    ;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    if ((int64_t) ((uint64_t) ((int64_t) (uint64_t) v504 - (uint64_t) v505) + (uint64_t) v45) == v37) {
      // pto: %642
      ;
      if (v505 < v17) {
        // pto: %91
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v936 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %91
        ;
        uint64_t v937 = (uint64_t) v32;
        TASSIGN(v936, v937);
        // pto: %643
        ;
        int64_t v938 = v505 < v49 ? v49 : v505;
        // pto: %644
        ;
        __gm__ bfloat16_t* v939 = PTOAS__GLOBAL_TENSOR_DATA(v121);
        // pto: %644
        ;
        const int64_t v940 = 0;
        // pto: %644
        ;
        const int64_t v941 = 4096;
        // pto: %644
        ;
        pto::Shape<1, 1, 1, 1, 4096> v942 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %644
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v943 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %644
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v944 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v939 + (v940 + v938 * v941), v942, v943);
        TLOAD(v936, v944);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %92
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v945 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %92
        ;
        uint64_t v946 = (uint64_t) v24;
        TASSIGN(v945, v946);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v947 = RoundMode::CAST_ROUND;
        SaturationMode v948 = SaturationMode::ON;
        TCVT(v945, v936, v947, v948);
        // pto: %645
        ;
        int64_t v949 = (int64_t) ((uint64_t) v17 - (uint64_t) v505);
        // pto: %646
        ;
        int64_t v950 = v949 < v49 ? v49 : v949;
        // pto: %647
        ;
        int64_t v951 = v950 < v37 ? v950 : v37;
        // pto: %93
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v952 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %93
        ;
        uint64_t v953 = (uint64_t) v25;
        TASSIGN(v952, v953);
        // pto: %652
        ;
        const int64_t v954 = 0;
        // pto: %652
        ;
        __gm__ bfloat16_t* v955 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %652
        ;
        const int64_t v956 = 1;
        // pto: %652
        ;
        const int64_t v957 = 1;
        // pto: %652
        ;
        const int64_t v958 = 1;
        // pto: %652
        ;
        int64_t v959 = v951 * v44;
        // pto: %652
        ;
        int64_t v960 = v958 * v959;
        // pto: %652
        ;
        pto::Shape<1, 1, 1, -1, 4096> v961 = pto::Shape<1, 1, 1, -1, 4096>(v956, v957, v958, v951, v42);
        // pto: %652
        ;
        pto::Stride<-1, -1, -1, -1, -1> v962 = pto::Stride<-1, -1, -1, -1, -1>(v957 * v960, v960, v959, v44, v37);
        // pto: %652
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v963 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v955 + (v954 + v938 * v44 + v49 * v37), v961, v962);
        TLOAD(v952, v963);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %94
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v964 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %94
        ;
        uint64_t v965 = (uint64_t) v32;
        TASSIGN(v964, v965);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v966 = RoundMode::CAST_ROUND;
        SaturationMode v967 = SaturationMode::ON;
        TCVT(v964, v952, v966, v967);
        // pto: %95
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v968 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %95
        ;
        uint64_t v969 = (uint64_t) v30;
        TASSIGN(v968, v969);
        // pto: %663
        ;
        const int64_t v970 = 0;
        // pto: %663
        ;
        __gm__ bfloat16_t* v971 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %663
        ;
        const int64_t v972 = 1;
        // pto: %663
        ;
        const int64_t v973 = 1;
        // pto: %663
        ;
        const int64_t v974 = 1;
        // pto: %663
        ;
        int64_t v975 = v951 * v44;
        // pto: %663
        ;
        int64_t v976 = v974 * v975;
        // pto: %663
        ;
        pto::Shape<1, 1, 1, -1, 4096> v977 = pto::Shape<1, 1, 1, -1, 4096>(v972, v973, v974, v951, v42);
        // pto: %663
        ;
        pto::Stride<-1, -1, -1, -1, -1> v978 = pto::Stride<-1, -1, -1, -1, -1>(v973 * v976, v976, v975, v44, v37);
        // pto: %663
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v979 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v971 + (v970 + v938 * v44 + v42 * v37), v977, v978);
        TLOAD(v968, v979);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %96
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v980 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %96
        ;
        uint64_t v981 = (uint64_t) v25;
        TASSIGN(v980, v981);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v982 = RoundMode::CAST_ROUND;
        SaturationMode v983 = SaturationMode::ON;
        TCVT(v980, v968, v982, v983);
        // pto: %97
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v984 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %97
        ;
        uint64_t v985 = (uint64_t) v26;
        TASSIGN(v984, v985);
        // pto: %674
        ;
        const int64_t v986 = 0;
        // pto: %674
        ;
        __gm__ bfloat16_t* v987 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %674
        ;
        const int64_t v988 = 1;
        // pto: %674
        ;
        const int64_t v989 = 1;
        // pto: %674
        ;
        const int64_t v990 = 1;
        // pto: %674
        ;
        int64_t v991 = v951 * v44;
        // pto: %674
        ;
        int64_t v992 = v990 * v991;
        // pto: %674
        ;
        pto::Shape<1, 1, 1, -1, 4096> v993 = pto::Shape<1, 1, 1, -1, 4096>(v988, v989, v990, v951, v42);
        // pto: %674
        ;
        pto::Stride<-1, -1, -1, -1, -1> v994 = pto::Stride<-1, -1, -1, -1, -1>(v989 * v992, v992, v991, v44, v37);
        // pto: %674
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v995 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v987 + (v986 + v938 * v44 + v43 * v37), v993, v994);
        TLOAD(v984, v995);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %98
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v996 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %98
        ;
        uint64_t v997 = (uint64_t) v30;
        TASSIGN(v996, v997);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v998 = RoundMode::CAST_ROUND;
        SaturationMode v999 = SaturationMode::ON;
        TCVT(v996, v984, v998, v999);
        // pto: %99
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1000 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %99
        ;
        uint64_t v1001 = (uint64_t) v33;
        TASSIGN(v1000, v1001);
        // pto: %685
        ;
        const int64_t v1002 = 0;
        // pto: %685
        ;
        __gm__ bfloat16_t* v1003 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %685
        ;
        const int64_t v1004 = 1;
        // pto: %685
        ;
        const int64_t v1005 = 1;
        // pto: %685
        ;
        const int64_t v1006 = 1;
        // pto: %685
        ;
        int64_t v1007 = v951 * v44;
        // pto: %685
        ;
        int64_t v1008 = v1006 * v1007;
        // pto: %685
        ;
        pto::Shape<1, 1, 1, -1, 4096> v1009 = pto::Shape<1, 1, 1, -1, 4096>(v1004, v1005, v1006, v951, v42);
        // pto: %685
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1010 = pto::Stride<-1, -1, -1, -1, -1>(v1005 * v1008, v1008, v1007, v44, v37);
        // pto: %685
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1011 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1003 + (v1002 + v938 * v44 + v74 * v37), v1009, v1010);
        TLOAD(v1000, v1011);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %100
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1012 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %100
        ;
        uint64_t v1013 = (uint64_t) v26;
        TASSIGN(v1012, v1013);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v1014 = RoundMode::CAST_ROUND;
        SaturationMode v1015 = SaturationMode::ON;
        TCVT(v1012, v1000, v1014, v1015);
        // pto: %690
        ;
        int64_t v1016 = (int64_t) ((uint64_t) v505 * (uint64_t) v45);
        // pto: %689
        ;
        float v1017 = (v11)[v1016];
        // pto: %101
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1018 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %101
        ;
        uint64_t v1019 = (uint64_t) v33;
        TASSIGN(v1018, v1019);
        pipe_barrier(PIPE_V);
        TMULS(v1018, v945, v1017);
        // pto: %693
        ;
        int64_t v1020 = (int64_t) ((uint64_t) v505 * (uint64_t) v39);
        // pto: %692
        ;
        float v1021 = (v12)[v1020];
        // pto: %102
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1022 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %102
        ;
        uint64_t v1023 = (uint64_t) v34;
        TASSIGN(v1022, v1023);
        TMULS(v1022, v964, v1021);
        // pto: %103
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1024 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %103
        ;
        uint64_t v1025 = (uint64_t) v33;
        TASSIGN(v1024, v1025);
        pipe_barrier(PIPE_V);
        TADD(v1024, v1018, v1022);
        // pto: %700, %698
        ;
        float v1026 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v45)];
        // pto: %104
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1027 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %104
        ;
        uint64_t v1028 = (uint64_t) v34;
        TASSIGN(v1027, v1028);
        pipe_barrier(PIPE_V);
        TMULS(v1027, v980, v1026);
        // pto: %105
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1029 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %105
        ;
        uint64_t v1030 = (uint64_t) v33;
        TASSIGN(v1029, v1030);
        pipe_barrier(PIPE_V);
        TADD(v1029, v1024, v1027);
        // pto: %706, %704
        ;
        float v1031 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v38)];
        // pto: %106
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1032 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %106
        ;
        uint64_t v1033 = (uint64_t) v34;
        TASSIGN(v1032, v1033);
        pipe_barrier(PIPE_V);
        TMULS(v1032, v996, v1031);
        // pto: %107
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1034 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %107
        ;
        uint64_t v1035 = (uint64_t) v33;
        TASSIGN(v1034, v1035);
        pipe_barrier(PIPE_V);
        TADD(v1034, v1029, v1032);
        // pto: %712, %710
        ;
        float v1036 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v66)];
        // pto: %108
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1037 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %108
        ;
        uint64_t v1038 = (uint64_t) v34;
        TASSIGN(v1037, v1038);
        pipe_barrier(PIPE_V);
        TMULS(v1037, v1012, v1036);
        // pto: %109
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1039 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %109
        ;
        uint64_t v1040 = (uint64_t) v33;
        TASSIGN(v1039, v1040);
        pipe_barrier(PIPE_V);
        TADD(v1039, v1034, v1037);
        // pto: %110
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1041 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %110
        ;
        uint64_t v1042 = (uint64_t) v33;
        TASSIGN(v1041, v1042);
        pipe_barrier(PIPE_V);
        RoundMode v1043 = RoundMode::CAST_RINT;
        SaturationMode v1044 = SaturationMode::ON;
        TCVT(v1041, v1039, v1043, v1044);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1041.SetValidShape(v37, v42);
        // pto: %y_flat__rv_v4_main_pview
        ;
        __gm__ bfloat16_t* v1045 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %y_flat__rv_v4_main_pview
        ;
        const int64_t v1046 = 0;
        // pto: %y_flat__rv_v4_main_pview
        ;
        const int64_t v1047 = 16384;
        // pto: %y_flat__rv_v4_main_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1048 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__rv_v4_main_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1049 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__rv_v4_main_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1050 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1045 + (v1046 + v938 * v1047), v1048, v1049);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1050, v1041);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
        // pto: %720, %718
        ;
        float v1051 = (v11)[(int64_t) ((uint64_t) v1016 + (uint64_t) v37)];
        // pto: %112
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1052 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %112
        ;
        uint64_t v1053 = (uint64_t) v33;
        TASSIGN(v1052, v1053);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
        TMULS(v1052, v945, v1051);
        // pto: %723, %721
        ;
        float v1054 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v37)];
        // pto: %113
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1055 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %113
        ;
        uint64_t v1056 = (uint64_t) v34;
        TASSIGN(v1055, v1056);
        TMULS(v1055, v964, v1054);
        // pto: %114
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1057 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %114
        ;
        uint64_t v1058 = (uint64_t) v33;
        TASSIGN(v1057, v1058);
        pipe_barrier(PIPE_V);
        TADD(v1057, v1052, v1055);
        // pto: %729, %727
        ;
        float v1059 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v67)];
        // pto: %115
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1060 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %115
        ;
        uint64_t v1061 = (uint64_t) v34;
        TASSIGN(v1060, v1061);
        pipe_barrier(PIPE_V);
        TMULS(v1060, v980, v1059);
        // pto: %116
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1062 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %116
        ;
        uint64_t v1063 = (uint64_t) v33;
        TASSIGN(v1062, v1063);
        pipe_barrier(PIPE_V);
        TADD(v1062, v1057, v1060);
        // pto: %735, %733
        ;
        float v1064 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v68)];
        // pto: %117
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1065 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %117
        ;
        uint64_t v1066 = (uint64_t) v34;
        TASSIGN(v1065, v1066);
        pipe_barrier(PIPE_V);
        TMULS(v1065, v996, v1064);
        // pto: %118
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1067 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %118
        ;
        uint64_t v1068 = (uint64_t) v33;
        TASSIGN(v1067, v1068);
        pipe_barrier(PIPE_V);
        TADD(v1067, v1062, v1065);
        // pto: %741, %739
        ;
        float v1069 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v69)];
        // pto: %119
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1070 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %119
        ;
        uint64_t v1071 = (uint64_t) v34;
        TASSIGN(v1070, v1071);
        pipe_barrier(PIPE_V);
        TMULS(v1070, v1012, v1069);
        // pto: %120
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1072 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %120
        ;
        uint64_t v1073 = (uint64_t) v33;
        TASSIGN(v1072, v1073);
        pipe_barrier(PIPE_V);
        TADD(v1072, v1067, v1070);
        // pto: %121
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1074 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %121
        ;
        uint64_t v1075 = (uint64_t) v33;
        TASSIGN(v1074, v1075);
        pipe_barrier(PIPE_V);
        RoundMode v1076 = RoundMode::CAST_RINT;
        SaturationMode v1077 = SaturationMode::ON;
        TCVT(v1074, v1072, v1076, v1077);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1074.SetValidShape(v37, v42);
        // pto: %747
        ;
        __gm__ bfloat16_t* v1078 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %747
        ;
        const int64_t v1079 = 4096;
        // pto: %747
        ;
        const int64_t v1080 = 16384;
        // pto: %747
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1081 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %747
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1082 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %747
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1083 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1078 + (v1079 + v938 * v1080), v1081, v1082);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1083, v1074);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        // pto: %750, %748
        ;
        float v1084 = (v11)[(int64_t) ((uint64_t) v1016 + (uint64_t) v47)];
        // pto: %123
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1085 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %123
        ;
        uint64_t v1086 = (uint64_t) v33;
        TASSIGN(v1085, v1086);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        TMULS(v1085, v945, v1084);
        // pto: %753, %751
        ;
        float v1087 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v47)];
        // pto: %124
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1088 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %124
        ;
        uint64_t v1089 = (uint64_t) v34;
        TASSIGN(v1088, v1089);
        TMULS(v1088, v964, v1087);
        // pto: %125
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1090 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %125
        ;
        uint64_t v1091 = (uint64_t) v33;
        TASSIGN(v1090, v1091);
        pipe_barrier(PIPE_V);
        TADD(v1090, v1085, v1088);
        // pto: %759, %757
        ;
        float v1092 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v70)];
        // pto: %126
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1093 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %126
        ;
        uint64_t v1094 = (uint64_t) v34;
        TASSIGN(v1093, v1094);
        pipe_barrier(PIPE_V);
        TMULS(v1093, v980, v1092);
        // pto: %127
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1095 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %127
        ;
        uint64_t v1096 = (uint64_t) v33;
        TASSIGN(v1095, v1096);
        pipe_barrier(PIPE_V);
        TADD(v1095, v1090, v1093);
        // pto: %765, %763
        ;
        float v1097 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v71)];
        // pto: %128
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1098 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %128
        ;
        uint64_t v1099 = (uint64_t) v34;
        TASSIGN(v1098, v1099);
        pipe_barrier(PIPE_V);
        TMULS(v1098, v996, v1097);
        // pto: %129
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1100 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %129
        ;
        uint64_t v1101 = (uint64_t) v33;
        TASSIGN(v1100, v1101);
        pipe_barrier(PIPE_V);
        TADD(v1100, v1095, v1098);
        // pto: %771, %769
        ;
        float v1102 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v72)];
        // pto: %130
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1103 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %130
        ;
        uint64_t v1104 = (uint64_t) v34;
        TASSIGN(v1103, v1104);
        pipe_barrier(PIPE_V);
        TMULS(v1103, v1012, v1102);
        // pto: %131
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1105 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %131
        ;
        uint64_t v1106 = (uint64_t) v33;
        TASSIGN(v1105, v1106);
        pipe_barrier(PIPE_V);
        TADD(v1105, v1100, v1103);
        // pto: %132
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1107 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %132
        ;
        uint64_t v1108 = (uint64_t) v33;
        TASSIGN(v1107, v1108);
        pipe_barrier(PIPE_V);
        RoundMode v1109 = RoundMode::CAST_RINT;
        SaturationMode v1110 = SaturationMode::ON;
        TCVT(v1107, v1105, v1109, v1110);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1107.SetValidShape(v37, v42);
        // pto: %777
        ;
        __gm__ bfloat16_t* v1111 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %777
        ;
        const int64_t v1112 = 8192;
        // pto: %777
        ;
        const int64_t v1113 = 16384;
        // pto: %777
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1114 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %777
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1115 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %777
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1116 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1111 + (v1112 + v938 * v1113), v1114, v1115);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1116, v1107);
        // pto: %780, %778
        ;
        float v1117 = (v11)[(int64_t) ((uint64_t) v1016 + (uint64_t) v65)];
        // pto: %134
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1118 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %134
        ;
        uint64_t v1119 = (uint64_t) v24;
        TASSIGN(v1118, v1119);
        TMULS(v1118, v945, v1117);
        // pto: %783, %781
        ;
        float v1120 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v65)];
        // pto: %135
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1121 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %135
        ;
        uint64_t v1122 = (uint64_t) v32;
        TASSIGN(v1121, v1122);
        TMULS(v1121, v964, v1120);
        // pto: %136
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1123 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %136
        ;
        uint64_t v1124 = (uint64_t) v24;
        TASSIGN(v1123, v1124);
        pipe_barrier(PIPE_V);
        TADD(v1123, v1118, v1121);
        // pto: %789, %787
        ;
        float v1125 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v55)];
        // pto: %137
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1126 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %137
        ;
        uint64_t v1127 = (uint64_t) v32;
        TASSIGN(v1126, v1127);
        pipe_barrier(PIPE_V);
        TMULS(v1126, v980, v1125);
        // pto: %138
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1128 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %138
        ;
        uint64_t v1129 = (uint64_t) v24;
        TASSIGN(v1128, v1129);
        pipe_barrier(PIPE_V);
        TADD(v1128, v1123, v1126);
        // pto: %795, %793
        ;
        float v1130 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v73)];
        // pto: %139
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1131 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %139
        ;
        uint64_t v1132 = (uint64_t) v32;
        TASSIGN(v1131, v1132);
        pipe_barrier(PIPE_V);
        TMULS(v1131, v996, v1130);
        // pto: %140
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1133 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %140
        ;
        uint64_t v1134 = (uint64_t) v24;
        TASSIGN(v1133, v1134);
        pipe_barrier(PIPE_V);
        TADD(v1133, v1128, v1131);
        // pto: %801, %799
        ;
        float v1135 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v50)];
        // pto: %141
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1136 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %141
        ;
        uint64_t v1137 = (uint64_t) v32;
        TASSIGN(v1136, v1137);
        pipe_barrier(PIPE_V);
        TMULS(v1136, v1012, v1135);
        // pto: %142
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1138 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %142
        ;
        uint64_t v1139 = (uint64_t) v24;
        TASSIGN(v1138, v1139);
        pipe_barrier(PIPE_V);
        TADD(v1138, v1133, v1136);
        // pto: %143
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1140 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %143
        ;
        uint64_t v1141 = (uint64_t) v24;
        TASSIGN(v1140, v1141);
        pipe_barrier(PIPE_V);
        RoundMode v1142 = RoundMode::CAST_RINT;
        SaturationMode v1143 = SaturationMode::ON;
        TCVT(v1140, v1138, v1142, v1143);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1140.SetValidShape(v37, v42);
        // pto: %807
        ;
        __gm__ bfloat16_t* v1144 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %807
        ;
        const int64_t v1145 = 12288;
        // pto: %807
        ;
        const int64_t v1146 = 16384;
        // pto: %807
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1147 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %807
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1148 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %807
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1149 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1144 + (v1145 + v938 * v1146), v1147, v1148);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v1149, v1140);
      };
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  pipe_barrier(PIPE_ALL);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}