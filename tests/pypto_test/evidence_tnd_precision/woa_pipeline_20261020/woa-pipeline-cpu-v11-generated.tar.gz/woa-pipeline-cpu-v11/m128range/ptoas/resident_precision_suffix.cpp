#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void cube(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ bfloat16_t* v6, __gm__ int8_t* v7, __gm__ float* v8, __gm__ bfloat16_t* v9, __gm__ bfloat16_t* v10, __gm__ float* v11, __gm__ float* v12, __gm__ bfloat16_t* v13, __gm__ float* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int32_t v22 = 1;
  // pto: %c0_i64
  const int64_t v23 = 0;
  // pto: %c65536_i64
  const int64_t v24 = 65536;
  // pto: %c32768_i64
  const int64_t v25 = 32768;
  // pto: %c32768_index
  const int64_t v26 = 32768;
  // pto: %c1_index
  const int64_t v27 = 1;
  // pto: %c8_index
  const int64_t v28 = 8;
  const int64_t v29 = 64;
  // pto: %c256_index
  const int64_t v30 = 256;
  // pto: %c16_index
  const int64_t v31 = 16;
  // pto: %c4194304_index
  const int64_t v32 = 4194304;
  // pto: %c65536_index
  const int64_t v33 = 65536;
  const int64_t v34 = 128;
  // pto: %c512_index
  const int64_t v35 = 512;
  // pto: %c32_index
  const int64_t v36 = 32;
  // pto: %c33554432_index
  const int64_t v37 = 33554432;
  // pto: %c262144_index
  const int64_t v38 = 262144;
  // pto: %c4096_index
  const int64_t v39 = 4096;
  // pto: %c8192_index
  const int64_t v40 = 8192;
  // pto: %c4_index
  const int64_t v41 = 4;
  // pto: %c55296_index
  const int64_t v42 = 55296;
  // pto: %c0_index
  const int64_t v43 = 0;
  // pto: %c15_index
  const int64_t v44 = 15;
  // pto: %c192_index
  const int64_t v45 = 192;
  // pto: %c24_index
  const int64_t v46 = 24;
  // pto: %c7_index
  const int64_t v47 = 7;
  // pto: %c2_index
  const int64_t v48 = 2;
  // pto: %c3_index
  const int64_t v49 = 3;
  // pto: %c5_index
  const int64_t v50 = 5;
  // pto: %c6_index
  const int64_t v51 = 6;
  // pto: %c240_index
  const int64_t v52 = 240;
  // pto: %c1024_index
  const int64_t v53 = 1024;
  // pto: %c241_index
  const int64_t v54 = 241;
  // pto: %c9216_index
  const int64_t v55 = 9216;
  // pto: %c72_index
  const int64_t v56 = 72;
  // pto: %c27648_index
  const int64_t v57 = 27648;
  // pto: %c63_index
  const int64_t v58 = 63;
  // pto: %c36864_index
  const int64_t v59 = 36864;
  // pto: %heads__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v61 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v62 = 1;
  // pto: %heads__ssa_v0_view
  int64_t v63 = (int64_t) v17;
  // pto: %heads__ssa_v0_view
  int64_t v64 = v63 * v26;
  // pto: %heads__ssa_v0_view
  int64_t v65 = v62 * v64;
  // pto: %heads__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v66 = pto::Shape<1, 1, 1, -1, -1>(v60, v61, v62, v63, v26);
  // pto: %heads__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v67 = pto::Stride<-1, -1, -1, -1, -1>(v61 * v65, v65, v64, v26, v27);
  // pto: %heads__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v68 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v66, v67);
  // pto: %wo_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v69 = pto::Shape<-1, -1, -1, -1, -1>(v28, v29, v30, v31, v31);
  // pto: %wo_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v70 = pto::Stride<-1, -1, -1, -1, -1>(v32, v33, v30, v31, v27);
  // pto: %wo_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v71 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v2, v69, v70);
  // pto: %wo_b__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v72 = pto::Shape<-1, -1, -1, -1, -1>(v27, v34, v35, v31, v36);
  // pto: %wo_b__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v73 = pto::Stride<-1, -1, -1, -1, -1>(v37, v38, v35, v36, v27);
  // pto: %wo_b__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v74 = GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v3, v72, v73);
  // pto: %quantized__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %quantized__ssa_v0_view
  int64_t v78 = (int64_t) v17;
  // pto: %quantized__ssa_v0_view
  int64_t v79 = v78 * v40;
  // pto: %quantized__ssa_v0_view
  int64_t v80 = v77 * v79;
  // pto: %quantized__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v81 = pto::Shape<1, 1, 1, -1, -1>(v75, v76, v77, v78, v40);
  // pto: %quantized__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v82 = pto::Stride<-1, -1, -1, -1, -1>(v76 * v80, v80, v79, v40, v27);
  // pto: %quantized__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v83 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v81, v82);
  // pto: %accum__ssa_v0_view
  const int64_t v84 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v85 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %accum__ssa_v0_view
  int64_t v87 = (int64_t) v18;
  // pto: %accum__ssa_v0_view
  int64_t v88 = v87 * v40;
  // pto: %accum__ssa_v0_view
  int64_t v89 = v86 * v88;
  // pto: %accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v90 = pto::Shape<1, 1, 1, -1, -1>(v84, v85, v86, v87, v40);
  // pto: %accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v91 = pto::Stride<-1, -1, -1, -1, -1>(v85 * v89, v89, v88, v40, v27);
  // pto: %accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v92 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v90, v91);
  // pto: %integer_accum__ssa_v0_view
  const int64_t v93 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v94 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %integer_accum__ssa_v0_view
  int64_t v96 = (int64_t) v19;
  // pto: %integer_accum__ssa_v0_view
  int64_t v97 = v96 * v39;
  // pto: %integer_accum__ssa_v0_view
  int64_t v98 = v95 * v97;
  // pto: %integer_accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v99 = pto::Shape<1, 1, 1, -1, -1>(v93, v94, v95, v96, v39);
  // pto: %integer_accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v100 = pto::Stride<-1, -1, -1, -1, -1>(v94 * v98, v98, v97, v39, v27);
  // pto: %integer_accum__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v101 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v99, v100);
  // pto: %signals__ssa_v0_view
  const int64_t v102 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v103 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v104 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v105 = 1;
  // pto: %signals__ssa_v0_view
  int64_t v106 = v42 * v27;
  // pto: %signals__ssa_v0_view
  int64_t v107 = v105 * v106;
  // pto: %signals__ssa_v0_view
  int64_t v108 = v104 * v107;
  // pto: %signals__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v109 = pto::Shape<1, 1, 1, 1, -1>(v102, v103, v104, v105, v42);
  // pto: %signals__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v110 = pto::Stride<-1, -1, -1, -1, -1>(v103 * v108, v108, v107, v106, v27);
  // pto: %signals__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v111 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v109, v110);
  // pto: %seed_narrow_acc__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v112 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v31, v34);
  // pto: %seed_narrow_acc__phi_v7
  uint64_t v113 = (uint64_t) v23;
  TASSIGN(v112, v113);
  // pto: %v4_wide_acc__phi_v7
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v114 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v34, v34);
  // pto: %v4_wide_acc__phi_v7
  uint64_t v115 = (uint64_t) v23;
  TASSIGN(v114, v115);
  // pto: %v4_narrow_acc__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v31, v34);
  // pto: %v4_narrow_acc__phi_v7
  uint64_t v117 = (uint64_t) v23;
  TASSIGN(v116, v117);
  // pto: %worker__ssa_v0
  int64_t v118 = (int64_t) v20;
  // pto: %33
  int64_t v119 = (int64_t) ((uint64_t) v118 * (uint64_t) v34);
  // pto: %34
  int64_t v120 = v119 < v43 ? v43 : v119;
  // pto: %signals__ssa_v0_pview
  __gm__ int32_t* v121 = PTOAS__GLOBAL_TENSOR_DATA(v111);
  // pto: %signals__ssa_v0_pview
  const int64_t v122 = 0;
  // pto: %signals__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 1> v123 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  pto::Stride<1, 1, 1, 1, 1> v124 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v125 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v121 + (v122 + v120), v123, v124);
  __gm__ int32_t* v126 = PTOAS__GLOBAL_TENSOR_DATA(v125);
  PTOAS__DCCI_SINGLE_CACHE_LINE(v126);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
  // pto: %t__tile
  int32_t v127 = (v16)[v119];
  // pto: %36
  int32_t v128 = (int32_t) ((uint32_t) v127 + (uint32_t) v22);
  pipe_barrier(PIPE_ALL);
  pto::comm::NotifyOp v129 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v125, v128, v129);
  // pto: %38, %39
  int64_t v130 = (int64_t) ((uint64_t) v17 + (uint64_t) v44) / v31;
  // pto: %40
  if (v17 >= v45) {
    for (int64_t v131 = v118; v131 < v29; v131 += v46) {
      // pto: %41
      ;
      int64_t v132 = v131 / v28;
      // pto: %42
      ;
      int64_t v133 = v131 % v28;
      // pto: %43, %44, %45
      ;
      int64_t v134 = v133 < v43 ? (int64_t) ((uint64_t) v133 + (uint64_t) v28) : v133;
      // pto: %46
      ;
      int64_t v135 = (int64_t) ((uint64_t) v134 * (uint64_t) v34);
      // pto: %47, %48
      ;
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v136 = v43; v136 < ((int64_t) ((uint64_t) v130 + (uint64_t) v47) / v28); v136 += v27) {
        // pto: %49
        ;
        int64_t v137 = (int64_t) ((uint64_t) v136 * (uint64_t) v28);
        // pto: %flat_offset, %51, %52, %50
        ;
        int32_t v138 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v136 * (uint64_t) v29) + (uint64_t) v132) * (uint64_t) v28) + (uint64_t) v134)];
        // pto: %53
        ;
        int64_t v139 = (int64_t) v138;
        // pto: %54
        ;
        int64_t v140 = v139 < v43 ? v43 : v139;
        // pto: %55
        ;
        int64_t v141 = (int64_t) ((uint64_t) v137 + (uint64_t) v27);
        // pto: %56
        ;
        // pto: %seed_same_start__phi_v3
        ;
        int64_t v142;
        if (v141 < v130) {
          // pto: %59, %60, %61, %62, %57
          ;
          int32_t v143 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v141 * (uint64_t) v28) + (uint64_t) v132) * (uint64_t) v28) + (uint64_t) v134)];
          // pto: %63
          ;
          int64_t v144 = (int64_t) v143;
          // pto: %64
          ;
          int64_t v145 = v144 < v43 ? v43 : v144;
          // pto: %65, %seed_same_start__phi_v2
          ;
          v142 = v145 != v140 ? v43 : v27;
        } else {
          v142 = v27;
        };
        // pto: %66
        ;
        int64_t v146 = (int64_t) ((uint64_t) v137 + (uint64_t) v48);
        // pto: %67
        ;
        // pto: %seed_same_start__phi_v6
        ;
        int64_t v147;
        if (v146 < v130) {
          // pto: %70, %71, %72, %73, %68
          ;
          int32_t v148 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v146 * (uint64_t) v28) + (uint64_t) v132) * (uint64_t) v28) + (uint64_t) v134)];
          // pto: %74
          ;
          int64_t v149 = (int64_t) v148;
          // pto: %75
          ;
          int64_t v150 = v149 < v43 ? v43 : v149;
          // pto: %76, %seed_same_start__phi_v5
          ;
          int64_t v151 = v150 != v140 ? v43 : v142;
          v147 = v151;
        } else {
          v147 = v142;
        };
        // pto: %77
        ;
        int64_t v152 = (int64_t) ((uint64_t) v137 + (uint64_t) v49);
        // pto: %78
        ;
        // pto: %seed_same_start__phi_v9
        ;
        int64_t v153;
        if (v152 < v130) {
          // pto: %81, %82, %83, %84, %79
          ;
          int32_t v154 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v152 * (uint64_t) v28) + (uint64_t) v132) * (uint64_t) v28) + (uint64_t) v134)];
          // pto: %85
          ;
          int64_t v155 = (int64_t) v154;
          // pto: %86
          ;
          int64_t v156 = v155 < v43 ? v43 : v155;
          // pto: %87, %seed_same_start__phi_v8
          ;
          int64_t v157 = v156 != v140 ? v43 : v147;
          v153 = v157;
        } else {
          v153 = v147;
        };
        // pto: %88
        ;
        int64_t v158 = (int64_t) ((uint64_t) v137 + (uint64_t) v41);
        // pto: %89
        ;
        // pto: %seed_same_start__phi_v12
        ;
        int64_t v159;
        if (v158 < v130) {
          // pto: %92, %93, %94, %95, %90
          ;
          int32_t v160 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v158 * (uint64_t) v28) + (uint64_t) v132) * (uint64_t) v28) + (uint64_t) v134)];
          // pto: %96
          ;
          int64_t v161 = (int64_t) v160;
          // pto: %97
          ;
          int64_t v162 = v161 < v43 ? v43 : v161;
          // pto: %98, %seed_same_start__phi_v11
          ;
          int64_t v163 = v162 != v140 ? v43 : v153;
          v159 = v163;
        } else {
          v159 = v153;
        };
        // pto: %99
        ;
        int64_t v164 = (int64_t) ((uint64_t) v137 + (uint64_t) v50);
        // pto: %100
        ;
        // pto: %seed_same_start__phi_v15
        ;
        int64_t v165;
        if (v164 < v130) {
          // pto: %103, %104, %105, %106, %101
          ;
          int32_t v166 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v164 * (uint64_t) v28) + (uint64_t) v132) * (uint64_t) v28) + (uint64_t) v134)];
          // pto: %107
          ;
          int64_t v167 = (int64_t) v166;
          // pto: %108
          ;
          int64_t v168 = v167 < v43 ? v43 : v167;
          // pto: %109, %seed_same_start__phi_v14
          ;
          int64_t v169 = v168 != v140 ? v43 : v159;
          v165 = v169;
        } else {
          v165 = v159;
        };
        // pto: %110
        ;
        int64_t v170 = (int64_t) ((uint64_t) v137 + (uint64_t) v51);
        // pto: %111
        ;
        // pto: %seed_same_start__phi_v18
        ;
        int64_t v171;
        if (v170 < v130) {
          // pto: %114, %115, %116, %117, %112
          ;
          int32_t v172 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v170 * (uint64_t) v28) + (uint64_t) v132) * (uint64_t) v28) + (uint64_t) v134)];
          // pto: %118
          ;
          int64_t v173 = (int64_t) v172;
          // pto: %119
          ;
          int64_t v174 = v173 < v43 ? v43 : v173;
          // pto: %120, %seed_same_start__phi_v17
          ;
          int64_t v175 = v174 != v140 ? v43 : v165;
          v171 = v175;
        } else {
          v171 = v165;
        };
        // pto: %121
        ;
        int64_t v176 = (int64_t) ((uint64_t) v137 + (uint64_t) v47);
        // pto: %122
        ;
        // pto: %seed_same_start__phi_v21
        ;
        int64_t v177;
        if (v176 < v130) {
          // pto: %125, %126, %127, %128, %123
          ;
          int32_t v178 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v176 * (uint64_t) v28) + (uint64_t) v132) * (uint64_t) v28) + (uint64_t) v134)];
          // pto: %129
          ;
          int64_t v179 = (int64_t) v178;
          // pto: %130
          ;
          int64_t v180 = v179 < v43 ? v43 : v179;
          // pto: %131, %seed_same_start__phi_v20
          ;
          int64_t v181 = v180 != v140 ? v43 : v171;
          v177 = v181;
        } else {
          v177 = v171;
        };
        // pto: %132, %seed_same_start__phi_v25
        ;
        int64_t v182 = v140 > v52 ? v43 : v177;
        // pto: %133
        ;
        int64_t v183 = v140 % v31;
        // pto: %134, %135, %136
        ;
        int64_t v184 = v183 < v43 ? (int64_t) ((uint64_t) v183 + (uint64_t) v31) : v183;
        // pto: %137, %seed_same_start__phi_v27
        ;
        int64_t v185 = v184 != v43 ? v43 : v182;
        // pto: %138
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        if (v185 == v27) {
          int64_t v186 = (int64_t) ((uint64_t) v136 * (uint64_t) v34);
          // pto: %140
          ;
          int64_t v187 = (int64_t) ((uint64_t) v17 - (uint64_t) v186);
          // pto: %141
          ;
          int64_t v188 = v187 < v34 ? v187 : v34;
          // pto: %142
          ;
          int64_t v189 = (int64_t) ((uint64_t) v140 * (uint64_t) v31);
          // pto: %seed_small_x__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v190 = Tile<TileType::Mat, bfloat16_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v188, v34);
          // pto: %seed_small_x__tile
          ;
          uint64_t v191 = (uint64_t) v23;
          TASSIGN(v190, v191);
          // pto: %143
          ;
          int64_t v192 = v186 < v43 ? v43 : v186;
          // pto: %144
          ;
          int64_t v193 = (int64_t) ((uint64_t) v132 * (uint64_t) v39);
          // pto: %145
          ;
          int64_t v194 = (int64_t) ((uint64_t) v193 + (uint64_t) v189);
          // pto: %146
          ;
          int64_t v195 = v194 < v43 ? v43 : v194;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v196 = 0;
          // pto: %heads__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v197 = PTOAS__GLOBAL_TENSOR_DATA(v68);
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v198 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v199 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v200 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          int64_t v201 = v188 * v26;
          // pto: %heads__ssa_v0_pview
          ;
          int64_t v202 = v200 * v201;
          // pto: %heads__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, -1, 128> v203 = pto::Shape<1, 1, 1, -1, 128>(v198, v199, v200, v188, v34);
          // pto: %heads__ssa_v0_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v204 = pto::Stride<-1, -1, -1, -1, -1>(v199 * v202, v202, v201, v26, v27);
          // pto: %heads__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v205 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v197 + (v196 + v192 * v26 + v195 * v27), v203, v204);
          TLOAD(v190, v205);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %seed_small_w__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v206 = Tile<TileType::Mat, bfloat16_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v34, v34);
          // pto: %seed_small_w__tile
          ;
          uint64_t v207 = (uint64_t) v24;
          TASSIGN(v206, v207);
          // pto: %147
          ;
          int64_t v208 = v132 < v43 ? v43 : v132;
          // pto: %148
          ;
          int64_t v209 = v135 / v31;
          // pto: %149
          ;
          int64_t v210 = v209 < v43 ? v43 : v209;
          // pto: %150
          ;
          int64_t v211 = v189 / v31;
          // pto: %151
          ;
          int64_t v212 = v211 < v43 ? v43 : v211;
          // pto: %wo_a__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v213 = PTOAS__GLOBAL_TENSOR_DATA(v71);
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v214 = 0;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v215 = 4194304;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v216 = 65536;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v217 = 256;
          // pto: %wo_a__ssa_v0_pview
          ;
          pto::Shape<1, 8, 8, 16, 16> v218 = pto::Shape<1, 8, 8, 16, 16>();
          // pto: %wo_a__ssa_v0_pview
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v219 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %wo_a__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 8, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v220 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 8, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v213 + ((v214 + v208 * v215) + v210 * v216 + v212 * v217), v218, v219);
          TLOAD(v206, v220);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %lhs_slice_0_textract
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v221 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v188, v34);
          // pto: %lhs_slice_0_textract
          ;
          uint64_t v222 = (uint64_t) v23;
          TASSIGN(v221, v222);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          uint16_t v223 = static_cast<uint16_t>(v43);
          uint16_t v224 = static_cast<uint16_t>(v43);
          TEXTRACT(v221, v190, v223, v224);
          // pto: %rhs_slice_0_textract
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v225 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v34, v34);
          // pto: %rhs_slice_0_textract
          ;
          uint64_t v226 = (uint64_t) v23;
          TASSIGN(v225, v226);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          uint16_t v227 = static_cast<uint16_t>(v43);
          uint16_t v228 = static_cast<uint16_t>(v43);
          TEXTRACT(v225, v206, v227, v228);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %seed_fast_acc__tile
          ;
          Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v229 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v188, v34);
          // pto: %seed_fast_acc__tile
          ;
          uint64_t v230 = (uint64_t) v23;
          TASSIGN(v229, v230);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          TMATMUL(v229, v221, v225);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
          for (int64_t v231 = v27; v231 < v36; v231 += v27) {
            // pto: %153, %152, %154
            ;
            int64_t v232 = (int64_t) ((uint64_t) v140 + (uint64_t) ((int64_t) (uint64_t) v231 * (uint64_t) v28)) % v30;
            // pto: %155, %156, %157
            ;
            int64_t v233 = v232 < v43 ? (int64_t) ((uint64_t) v232 + (uint64_t) v30) : v232;
            // pto: %158
            ;
            int64_t v234 = (int64_t) ((uint64_t) v233 * (uint64_t) v31);
            // pto: %seed_small_packet_x__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v235 = Tile<TileType::Mat, bfloat16_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v188, v34);
            // pto: %seed_small_packet_x__tile
            ;
            uint64_t v236 = (uint64_t) v23;
            TASSIGN(v235, v236);
            // pto: %161
            ;
            int64_t v237 = (int64_t) ((uint64_t) v193 + (uint64_t) v234);
            // pto: %162
            ;
            int64_t v238 = v237 < v43 ? v43 : v237;
            // pto: %163
            ;
            const int64_t v239 = 0;
            // pto: %163
            ;
            __gm__ bfloat16_t* v240 = PTOAS__GLOBAL_TENSOR_DATA(v68);
            // pto: %163
            ;
            const int64_t v241 = 1;
            // pto: %163
            ;
            const int64_t v242 = 1;
            // pto: %163
            ;
            const int64_t v243 = 1;
            // pto: %163
            ;
            int64_t v244 = v188 * v26;
            // pto: %163
            ;
            int64_t v245 = v243 * v244;
            // pto: %163
            ;
            pto::Shape<1, 1, 1, -1, 128> v246 = pto::Shape<1, 1, 1, -1, 128>(v241, v242, v243, v188, v34);
            // pto: %163
            ;
            pto::Stride<-1, -1, -1, -1, -1> v247 = pto::Stride<-1, -1, -1, -1, -1>(v242 * v245, v245, v244, v26, v27);
            // pto: %163
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v248 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v240 + (v239 + v192 * v26 + v238 * v27), v246, v247);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            TLOAD(v235, v248);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
            // pto: %seed_small_packet_w__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v249 = Tile<TileType::Mat, bfloat16_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v34, v34);
            // pto: %seed_small_packet_w__tile
            ;
            uint64_t v250 = (uint64_t) v24;
            TASSIGN(v249, v250);
            // pto: %167
            ;
            int64_t v251 = v234 / v31;
            // pto: %168
            ;
            int64_t v252 = v251 < v43 ? v43 : v251;
            // pto: %169
            ;
            __gm__ bfloat16_t* v253 = PTOAS__GLOBAL_TENSOR_DATA(v71);
            // pto: %169
            ;
            const int64_t v254 = 0;
            // pto: %169
            ;
            const int64_t v255 = 4194304;
            // pto: %169
            ;
            const int64_t v256 = 65536;
            // pto: %169
            ;
            const int64_t v257 = 256;
            // pto: %169
            ;
            pto::Shape<1, 8, 8, 16, 16> v258 = pto::Shape<1, 8, 8, 16, 16>();
            // pto: %169
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v259 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %169
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 8, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v260 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 8, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v253 + ((v254 + v208 * v255) + v210 * v256 + v252 * v257), v258, v259);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            TLOAD(v249, v260);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
            // pto: %0
            ;
            Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v261 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v188, v34);
            // pto: %0
            ;
            uint64_t v262 = (uint64_t) v23;
            TASSIGN(v261, v262);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
            uint16_t v263 = static_cast<uint16_t>(v43);
            uint16_t v264 = static_cast<uint16_t>(v43);
            TEXTRACT(v261, v235, v263, v264);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            // pto: %1
            ;
            Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v265 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v34, v34);
            // pto: %1
            ;
            uint64_t v266 = (uint64_t) v23;
            TASSIGN(v265, v266);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
            uint16_t v267 = static_cast<uint16_t>(v43);
            uint16_t v268 = static_cast<uint16_t>(v43);
            TEXTRACT(v265, v249, v267, v268);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
            TMATMUL_ACC(v229, v229, v261, v265);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          };
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
          // pto: %171, %172
          ;
          int64_t v269 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v132 * (uint64_t) v53) + (uint64_t) v135);
          // pto: %173
          ;
          int64_t v270 = v269 < v43 ? v43 : v269;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v271 = 0;
          // pto: %accum__ssa_v0_pview
          ;
          __gm__ float* v272 = PTOAS__GLOBAL_TENSOR_DATA(v92);
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v273 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v274 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v275 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          int64_t v276 = v188 * v40;
          // pto: %accum__ssa_v0_pview
          ;
          int64_t v277 = v275 * v276;
          // pto: %accum__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, -1, 128> v278 = pto::Shape<1, 1, 1, -1, 128>(v273, v274, v275, v188, v34);
          // pto: %accum__ssa_v0_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v279 = pto::Stride<-1, -1, -1, -1, -1>(v274 * v277, v277, v276, v40, v27);
          // pto: %accum__ssa_v0_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v280 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v272 + (v271 + v192 * v40 + v270 * v27), v278, v279);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
          TSTORE(v280, v229);
        } else {
          for (int64_t v281 = v43; v281 < v28; v281 += v27) {
            // pto: %174
            ;
            int64_t v282 = (int64_t) ((uint64_t) v137 + (uint64_t) v281);
            // pto: %175
            ;
            if (v282 < v130) {
              // pto: %176
              ;
              int64_t v283 = (int64_t) ((uint64_t) v282 * (uint64_t) v31);
              // pto: %177
              ;
              int64_t v284 = (int64_t) ((uint64_t) v17 - (uint64_t) v283);
              // pto: %178
              ;
              int64_t v285 = v284 < v31 ? v284 : v31;
              // pto: %180, %181, %182, %183, %179
              ;
              int32_t v286 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v282 * (uint64_t) v28) + (uint64_t) v132) * (uint64_t) v28) + (uint64_t) v134)];
              // pto: %184
              ;
              int64_t v287 = (int64_t) v286;
              // pto: %185
              ;
              int64_t v288 = v287 < v43 ? v43 : v287;
              // pto: %seed_narrow_acc__tile
              ;
              Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v289 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v31, v34);
              // pto: %seed_narrow_acc__tile
              ;
              uint64_t v290 = (uint64_t) v23;
              TASSIGN(v289, v290);
              wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
              for (int64_t v291 = v43; v291 < v31; v291 += v27) {
                // pto: %186
                ;
                int64_t v292 = (int64_t) ((uint64_t) v291 * (uint64_t) v31);
                // pto: %187, %188
                ;
                int64_t v293 = (int64_t) ((uint64_t) v288 + (uint64_t) v292) % v30;
                // pto: %189, %190, %191
                ;
                int64_t v294 = v293 < v43 ? (int64_t) ((uint64_t) v293 + (uint64_t) v30) : v293;
                // pto: %192
                ;
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
                if (v294 <= v52) {
                  // pto: %193
                  ;
                  int64_t v295 = (int64_t) ((uint64_t) v294 * (uint64_t) v31);
                  // pto: %seed_narrow_packet_x__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v296 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v285, v30);
                  // pto: %seed_narrow_packet_x__tile
                  ;
                  uint64_t v297 = (uint64_t) v24;
                  TASSIGN(v296, v297);
                  // pto: %194
                  ;
                  int64_t v298 = v283 < v43 ? v43 : v283;
                  // pto: %195, %196
                  ;
                  int64_t v299 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v132 * (uint64_t) v39) + (uint64_t) v295);
                  // pto: %197
                  ;
                  int64_t v300 = v299 < v43 ? v43 : v299;
                  // pto: %198
                  ;
                  const int64_t v301 = 0;
                  // pto: %198
                  ;
                  __gm__ bfloat16_t* v302 = PTOAS__GLOBAL_TENSOR_DATA(v68);
                  // pto: %198
                  ;
                  const int64_t v303 = 1;
                  // pto: %198
                  ;
                  const int64_t v304 = 1;
                  // pto: %198
                  ;
                  const int64_t v305 = 1;
                  // pto: %198
                  ;
                  int64_t v306 = v285 * v26;
                  // pto: %198
                  ;
                  int64_t v307 = v305 * v306;
                  // pto: %198
                  ;
                  pto::Shape<1, 1, 1, -1, 256> v308 = pto::Shape<1, 1, 1, -1, 256>(v303, v304, v305, v285, v30);
                  // pto: %198
                  ;
                  pto::Stride<-1, -1, -1, -1, -1> v309 = pto::Stride<-1, -1, -1, -1, -1>(v304 * v307, v307, v306, v26, v27);
                  // pto: %198
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v310 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v302 + (v301 + v298 * v26 + v300 * v27), v308, v309);
                  TLOAD(v296, v310);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
                  // pto: %seed_narrow_packet_w__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v311 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v30, v34);
                  // pto: %seed_narrow_packet_w__tile
                  ;
                  uint64_t v312 = (uint64_t) v23;
                  TASSIGN(v311, v312);
                  // pto: %199
                  ;
                  int64_t v313 = v132 < v43 ? v43 : v132;
                  // pto: %200
                  ;
                  int64_t v314 = v135 / v31;
                  // pto: %201
                  ;
                  int64_t v315 = v314 < v43 ? v43 : v314;
                  // pto: %202
                  ;
                  int64_t v316 = v295 / v31;
                  // pto: %203
                  ;
                  int64_t v317 = v316 < v43 ? v43 : v316;
                  // pto: %204
                  ;
                  __gm__ bfloat16_t* v318 = PTOAS__GLOBAL_TENSOR_DATA(v71);
                  // pto: %204
                  ;
                  const int64_t v319 = 0;
                  // pto: %204
                  ;
                  const int64_t v320 = 4194304;
                  // pto: %204
                  ;
                  const int64_t v321 = 65536;
                  // pto: %204
                  ;
                  const int64_t v322 = 256;
                  // pto: %204
                  ;
                  pto::Shape<1, 8, 16, 16, 16> v323 = pto::Shape<1, 8, 16, 16, 16>();
                  // pto: %204
                  ;
                  pto::Stride<4194304, 65536, 256, 16, 1> v324 = pto::Stride<4194304, 65536, 256, 16, 1>();
                  // pto: %204
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v325 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v318 + ((v319 + v313 * v320) + v315 * v321 + v317 * v322), v323, v324);
                  TLOAD(v311, v325);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
                  // pto: %seed_narrow_acc__iter_v1_l0_a
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v326 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v285, v34);
                  // pto: %seed_narrow_acc__iter_v1_l0_a
                  ;
                  uint64_t v327 = (uint64_t) v23;
                  TASSIGN(v326, v327);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
                  uint16_t v328 = static_cast<uint16_t>(v43);
                  uint16_t v329 = static_cast<uint16_t>(v43);
                  TEXTRACT(v326, v296, v328, v329);
                  // pto: %seed_narrow_acc__iter_v1_l0_b
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v330 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v34, v34);
                  // pto: %seed_narrow_acc__iter_v1_l0_b
                  ;
                  uint64_t v331 = (uint64_t) v23;
                  TASSIGN(v330, v331);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
                  uint16_t v332 = static_cast<uint16_t>(v43);
                  uint16_t v333 = static_cast<uint16_t>(v43);
                  TEXTRACT(v330, v311, v332, v333);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
                  // pto: %2
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v334 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v285, v34);
                  // pto: %2
                  ;
                  uint64_t v335 = (uint64_t) v25;
                  TASSIGN(v334, v335);
                  uint16_t v336 = static_cast<uint16_t>(v43);
                  uint16_t v337 = static_cast<uint16_t>(v34);
                  TEXTRACT(v334, v296, v336, v337);
                  // pto: %3
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v338 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v34, v34);
                  // pto: %3
                  ;
                  uint64_t v339 = (uint64_t) v25;
                  TASSIGN(v338, v339);
                  uint16_t v340 = static_cast<uint16_t>(v34);
                  uint16_t v341 = static_cast<uint16_t>(v43);
                  TEXTRACT(v338, v311, v340, v341);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
                  // pto: %205
                  ;
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
                  if (v291 == v43) {
                    pipe_barrier(PIPE_M);
                    TMATMUL(v289, v326, v330);
                  } else {
                    pipe_barrier(PIPE_M);
                    TMATMUL_ACC(v289, v289, v326, v330);
                  };
                  pipe_barrier(PIPE_M);
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
                  TMATMUL_ACC(v289, v289, v334, v338);
                } else {
                  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
                  for (int64_t v342 = v43; v342 < v31; v342 += v27) {
                    // pto: %206, %207
                    ;
                    int64_t v343 = (int64_t) ((uint64_t) v294 + (uint64_t) v342) % v30;
                    // pto: %208, %209, %210
                    ;
                    int64_t v344 = v343 < v43 ? (int64_t) ((uint64_t) v343 + (uint64_t) v30) : v343;
                    // pto: %211
                    ;
                    int64_t v345 = (int64_t) ((uint64_t) v344 * (uint64_t) v31);
                    // pto: %seed_narrow_wrap_x__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v346 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v285, v31);
                    // pto: %seed_narrow_wrap_x__tile
                    ;
                    uint64_t v347 = (uint64_t) v24;
                    TASSIGN(v346, v347);
                    // pto: %212
                    ;
                    int64_t v348 = v283 < v43 ? v43 : v283;
                    // pto: %213, %214
                    ;
                    int64_t v349 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v132 * (uint64_t) v39) + (uint64_t) v345);
                    // pto: %215
                    ;
                    int64_t v350 = v349 < v43 ? v43 : v349;
                    // pto: %216
                    ;
                    const int64_t v351 = 0;
                    // pto: %216
                    ;
                    __gm__ bfloat16_t* v352 = PTOAS__GLOBAL_TENSOR_DATA(v68);
                    // pto: %216
                    ;
                    const int64_t v353 = 1;
                    // pto: %216
                    ;
                    const int64_t v354 = 1;
                    // pto: %216
                    ;
                    const int64_t v355 = 1;
                    // pto: %216
                    ;
                    int64_t v356 = v285 * v26;
                    // pto: %216
                    ;
                    int64_t v357 = v355 * v356;
                    // pto: %216
                    ;
                    pto::Shape<1, 1, 1, -1, 16> v358 = pto::Shape<1, 1, 1, -1, 16>(v353, v354, v355, v285, v31);
                    // pto: %216
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v359 = pto::Stride<-1, -1, -1, -1, -1>(v354 * v357, v357, v356, v26, v27);
                    // pto: %216
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v360 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v352 + (v351 + v348 * v26 + v350 * v27), v358, v359);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
                    TLOAD(v346, v360);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
                    // pto: %seed_narrow_wrap_w__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v361 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v31, v34);
                    // pto: %seed_narrow_wrap_w__tile
                    ;
                    uint64_t v362 = (uint64_t) v23;
                    TASSIGN(v361, v362);
                    // pto: %217
                    ;
                    int64_t v363 = v132 < v43 ? v43 : v132;
                    // pto: %218
                    ;
                    int64_t v364 = v135 / v31;
                    // pto: %219
                    ;
                    int64_t v365 = v364 < v43 ? v43 : v364;
                    // pto: %220
                    ;
                    int64_t v366 = v345 / v31;
                    // pto: %221
                    ;
                    int64_t v367 = v366 < v43 ? v43 : v366;
                    // pto: %222
                    ;
                    __gm__ bfloat16_t* v368 = PTOAS__GLOBAL_TENSOR_DATA(v71);
                    // pto: %222
                    ;
                    const int64_t v369 = 0;
                    // pto: %222
                    ;
                    const int64_t v370 = 4194304;
                    // pto: %222
                    ;
                    const int64_t v371 = 65536;
                    // pto: %222
                    ;
                    const int64_t v372 = 256;
                    // pto: %222
                    ;
                    pto::Shape<1, 8, 1, 16, 16> v373 = pto::Shape<1, 8, 1, 16, 16>();
                    // pto: %222
                    ;
                    pto::Stride<4194304, 65536, 256, 16, 1> v374 = pto::Stride<4194304, 65536, 256, 16, 1>();
                    // pto: %222
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v375 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v368 + ((v369 + v363 * v370) + v365 * v371 + v367 * v372), v373, v374);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
                    TLOAD(v361, v375);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
                    // pto: %5
                    ;
                    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v376 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v285, v31);
                    // pto: %5
                    ;
                    uint64_t v377 = (uint64_t) v23;
                    TASSIGN(v376, v377);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
                    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
                    uint16_t v378 = static_cast<uint16_t>(v43);
                    uint16_t v379 = static_cast<uint16_t>(v43);
                    TEXTRACT(v376, v346, v378, v379);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
                    // pto: %6
                    ;
                    Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v380 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v31, v34);
                    // pto: %6
                    ;
                    uint64_t v381 = (uint64_t) v23;
                    TASSIGN(v380, v381);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
                    uint16_t v382 = static_cast<uint16_t>(v43);
                    uint16_t v383 = static_cast<uint16_t>(v43);
                    TEXTRACT(v380, v361, v382, v383);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
                    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
                    // pto: %224, %225
                    ;
                    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
                    if ((int64_t) ((uint64_t) v292 + (uint64_t) v342) == v43) {
                      pipe_barrier(PIPE_M);
                      TMATMUL(v289, v376, v380);
                    } else {
                      pipe_barrier(PIPE_M);
                      TMATMUL_ACC(v289, v289, v376, v380);
                    };
                    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
                  };
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
                  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
              };
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
              set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
              // pto: %226
              ;
              int64_t v384 = v283 < v43 ? v43 : v283;
              // pto: %227, %228
              ;
              int64_t v385 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v132 * (uint64_t) v53) + (uint64_t) v135);
              // pto: %229
              ;
              int64_t v386 = v385 < v43 ? v43 : v385;
              // pto: %230
              ;
              __gm__ float* v387 = PTOAS__GLOBAL_TENSOR_DATA(v92);
              // pto: %230
              ;
              const int64_t v388 = 0;
              // pto: %230
              ;
              const int64_t v389 = 8192;
              // pto: %230
              ;
              pto::Shape<1, 1, 1, 16, 128> v390 = pto::Shape<1, 1, 1, 16, 128>();
              // pto: %230
              ;
              pto::Stride<131072, 131072, 131072, 8192, 1> v391 = pto::Stride<131072, 131072, 131072, 8192, 1>();
              // pto: %230
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v392 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v387 + (v388 + v384 * v389 + v386), v390, v391);
              wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
              pipe_barrier(PIPE_FIX);
              TSTORE(v392, v289);
              set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
            };
          };
        };
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    };
  } else {
    for (int64_t v393 = v118; v393 < v29; v393 += v46) {
      // pto: %232
      ;
      int64_t v394 = v393 / v28;
      // pto: %233
      ;
      int64_t v395 = v393 % v28;
      // pto: %234, %235, %236
      ;
      int64_t v396 = v395 < v43 ? (int64_t) ((uint64_t) v395 + (uint64_t) v28) : v395;
      // pto: %237
      ;
      int64_t v397 = (int64_t) ((uint64_t) v396 * (uint64_t) v34);
      // pto: %238, %239
      ;
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      for (int64_t v398 = v43; v398 < ((int64_t) ((uint64_t) v130 + (uint64_t) v47) / v28); v398 += v27) {
        // pto: %240
        ;
        int64_t v399 = (int64_t) ((uint64_t) v398 * (uint64_t) v28);
        // pto: %243, %244, %245, %241
        ;
        int32_t v400 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v398 * (uint64_t) v29) + (uint64_t) v394) * (uint64_t) v28) + (uint64_t) v396)];
        // pto: %246
        ;
        int64_t v401 = (int64_t) v400;
        // pto: %247
        ;
        int64_t v402 = v401 < v43 ? v43 : v401;
        // pto: %248
        ;
        int64_t v403 = (int64_t) ((uint64_t) v399 + (uint64_t) v27);
        // pto: %249
        ;
        // pto: %v4_same_start__phi_v3
        ;
        int64_t v404;
        if (v403 < v130) {
          // pto: %252, %253, %254, %255, %250
          ;
          int32_t v405 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v403 * (uint64_t) v28) + (uint64_t) v394) * (uint64_t) v28) + (uint64_t) v396)];
          // pto: %256
          ;
          int64_t v406 = (int64_t) v405;
          // pto: %257
          ;
          int64_t v407 = v406 < v43 ? v43 : v406;
          // pto: %258, %v4_same_start__phi_v2
          ;
          v404 = v407 != v402 ? v43 : v27;
        } else {
          v404 = v27;
        };
        // pto: %259
        ;
        int64_t v408 = (int64_t) ((uint64_t) v399 + (uint64_t) v48);
        // pto: %260
        ;
        // pto: %v4_same_start__phi_v6
        ;
        int64_t v409;
        if (v408 < v130) {
          // pto: %263, %264, %265, %266, %261
          ;
          int32_t v410 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v408 * (uint64_t) v28) + (uint64_t) v394) * (uint64_t) v28) + (uint64_t) v396)];
          // pto: %267
          ;
          int64_t v411 = (int64_t) v410;
          // pto: %268
          ;
          int64_t v412 = v411 < v43 ? v43 : v411;
          // pto: %269, %v4_same_start__phi_v5
          ;
          int64_t v413 = v412 != v402 ? v43 : v404;
          v409 = v413;
        } else {
          v409 = v404;
        };
        // pto: %270
        ;
        int64_t v414 = (int64_t) ((uint64_t) v399 + (uint64_t) v49);
        // pto: %271
        ;
        // pto: %v4_same_start__phi_v9
        ;
        int64_t v415;
        if (v414 < v130) {
          // pto: %274, %275, %276, %277, %272
          ;
          int32_t v416 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v414 * (uint64_t) v28) + (uint64_t) v394) * (uint64_t) v28) + (uint64_t) v396)];
          // pto: %278
          ;
          int64_t v417 = (int64_t) v416;
          // pto: %279
          ;
          int64_t v418 = v417 < v43 ? v43 : v417;
          // pto: %280, %v4_same_start__phi_v8
          ;
          int64_t v419 = v418 != v402 ? v43 : v409;
          v415 = v419;
        } else {
          v415 = v409;
        };
        // pto: %281
        ;
        int64_t v420 = (int64_t) ((uint64_t) v399 + (uint64_t) v41);
        // pto: %282
        ;
        // pto: %v4_same_start__phi_v12
        ;
        int64_t v421;
        if (v420 < v130) {
          // pto: %285, %286, %287, %288, %283
          ;
          int32_t v422 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v420 * (uint64_t) v28) + (uint64_t) v394) * (uint64_t) v28) + (uint64_t) v396)];
          // pto: %289
          ;
          int64_t v423 = (int64_t) v422;
          // pto: %290
          ;
          int64_t v424 = v423 < v43 ? v43 : v423;
          // pto: %291, %v4_same_start__phi_v11
          ;
          int64_t v425 = v424 != v402 ? v43 : v415;
          v421 = v425;
        } else {
          v421 = v415;
        };
        // pto: %292
        ;
        int64_t v426 = (int64_t) ((uint64_t) v399 + (uint64_t) v50);
        // pto: %293
        ;
        // pto: %v4_same_start__phi_v15
        ;
        int64_t v427;
        if (v426 < v130) {
          // pto: %296, %297, %298, %299, %294
          ;
          int32_t v428 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v426 * (uint64_t) v28) + (uint64_t) v394) * (uint64_t) v28) + (uint64_t) v396)];
          // pto: %300
          ;
          int64_t v429 = (int64_t) v428;
          // pto: %301
          ;
          int64_t v430 = v429 < v43 ? v43 : v429;
          // pto: %302, %v4_same_start__phi_v14
          ;
          int64_t v431 = v430 != v402 ? v43 : v421;
          v427 = v431;
        } else {
          v427 = v421;
        };
        // pto: %303
        ;
        int64_t v432 = (int64_t) ((uint64_t) v399 + (uint64_t) v51);
        // pto: %304
        ;
        // pto: %v4_same_start__phi_v18
        ;
        int64_t v433;
        if (v432 < v130) {
          // pto: %307, %308, %309, %310, %305
          ;
          int32_t v434 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v432 * (uint64_t) v28) + (uint64_t) v394) * (uint64_t) v28) + (uint64_t) v396)];
          // pto: %311
          ;
          int64_t v435 = (int64_t) v434;
          // pto: %312
          ;
          int64_t v436 = v435 < v43 ? v43 : v435;
          // pto: %313, %v4_same_start__phi_v17
          ;
          int64_t v437 = v436 != v402 ? v43 : v427;
          v433 = v437;
        } else {
          v433 = v427;
        };
        // pto: %314
        ;
        int64_t v438 = (int64_t) ((uint64_t) v399 + (uint64_t) v47);
        // pto: %315
        ;
        // pto: %v4_same_start__phi_v21
        ;
        int64_t v439;
        if (v438 < v130) {
          // pto: %318, %319, %320, %321, %316
          ;
          int32_t v440 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v438 * (uint64_t) v28) + (uint64_t) v394) * (uint64_t) v28) + (uint64_t) v396)];
          // pto: %322
          ;
          int64_t v441 = (int64_t) v440;
          // pto: %323
          ;
          int64_t v442 = v441 < v43 ? v43 : v441;
          // pto: %324, %v4_same_start__phi_v20
          ;
          int64_t v443 = v442 != v402 ? v43 : v433;
          v439 = v443;
        } else {
          v439 = v433;
        };
        // pto: %325, %v4_same_start__phi_v23
        ;
        int64_t v444 = v17 <= v31 ? v43 : v439;
        // pto: %326
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        if (v444 == v27) {
          int64_t v445 = (int64_t) ((uint64_t) v398 * (uint64_t) v34);
          // pto: %328
          ;
          int64_t v446 = (int64_t) ((uint64_t) v17 - (uint64_t) v445);
          // pto: %329
          ;
          int64_t v447 = v446 < v34 ? v446 : v34;
          // pto: %330
          ;
          int64_t v448 = v402 % v30;
          // pto: %331, %332, %333
          ;
          int64_t v449 = v448 < v43 ? (int64_t) ((uint64_t) v448 + (uint64_t) v30) : v448;
          // pto: %334
          ;
          int64_t v450 = (int64_t) ((uint64_t) v449 * (uint64_t) v31);
          // pto: %v4_wide_seed_x__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v451 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v447, v31);
          // pto: %v4_wide_seed_x__tile
          ;
          uint64_t v452 = (uint64_t) v23;
          TASSIGN(v451, v452);
          // pto: %335
          ;
          int64_t v453 = v445 < v43 ? v43 : v445;
          // pto: %336
          ;
          int64_t v454 = (int64_t) ((uint64_t) v394 * (uint64_t) v39);
          // pto: %337
          ;
          int64_t v455 = (int64_t) ((uint64_t) v454 + (uint64_t) v450);
          // pto: %338
          ;
          int64_t v456 = v455 < v43 ? v43 : v455;
          // pto: %339
          ;
          const int64_t v457 = 0;
          // pto: %339
          ;
          __gm__ bfloat16_t* v458 = PTOAS__GLOBAL_TENSOR_DATA(v68);
          // pto: %339
          ;
          const int64_t v459 = 1;
          // pto: %339
          ;
          const int64_t v460 = 1;
          // pto: %339
          ;
          const int64_t v461 = 1;
          // pto: %339
          ;
          int64_t v462 = v447 * v26;
          // pto: %339
          ;
          int64_t v463 = v461 * v462;
          // pto: %339
          ;
          pto::Shape<1, 1, 1, -1, 16> v464 = pto::Shape<1, 1, 1, -1, 16>(v459, v460, v461, v447, v31);
          // pto: %339
          ;
          pto::Stride<-1, -1, -1, -1, -1> v465 = pto::Stride<-1, -1, -1, -1, -1>(v460 * v463, v463, v462, v26, v27);
          // pto: %339
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v466 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v458 + (v457 + v453 * v26 + v456 * v27), v464, v465);
          TLOAD(v451, v466);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %v4_wide_seed_w__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v467 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v31, v34);
          // pto: %v4_wide_seed_w__tile
          ;
          uint64_t v468 = (uint64_t) v24;
          TASSIGN(v467, v468);
          // pto: %340
          ;
          int64_t v469 = v394 < v43 ? v43 : v394;
          // pto: %341
          ;
          int64_t v470 = v397 / v31;
          // pto: %342
          ;
          int64_t v471 = v470 < v43 ? v43 : v470;
          // pto: %343
          ;
          int64_t v472 = v450 / v31;
          // pto: %344
          ;
          int64_t v473 = v472 < v43 ? v43 : v472;
          // pto: %345
          ;
          __gm__ bfloat16_t* v474 = PTOAS__GLOBAL_TENSOR_DATA(v71);
          // pto: %345
          ;
          const int64_t v475 = 0;
          // pto: %345
          ;
          const int64_t v476 = 4194304;
          // pto: %345
          ;
          const int64_t v477 = 65536;
          // pto: %345
          ;
          const int64_t v478 = 256;
          // pto: %345
          ;
          pto::Shape<1, 8, 1, 16, 16> v479 = pto::Shape<1, 8, 1, 16, 16>();
          // pto: %345
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v480 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %345
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v481 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v474 + ((v475 + v469 * v476) + v471 * v477 + v473 * v478), v479, v480);
          TLOAD(v467, v481);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %7
          ;
          Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v482 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v447, v31);
          // pto: %7
          ;
          uint64_t v483 = (uint64_t) v23;
          TASSIGN(v482, v483);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          uint16_t v484 = static_cast<uint16_t>(v43);
          uint16_t v485 = static_cast<uint16_t>(v43);
          TEXTRACT(v482, v451, v484, v485);
          // pto: %8
          ;
          Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v486 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v31, v34);
          // pto: %8
          ;
          uint64_t v487 = (uint64_t) v23;
          TASSIGN(v486, v487);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          uint16_t v488 = static_cast<uint16_t>(v43);
          uint16_t v489 = static_cast<uint16_t>(v43);
          TEXTRACT(v486, v467, v488, v489);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
          // pto: %v4_wide_acc__tile
          ;
          Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v490 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v447, v34);
          // pto: %v4_wide_acc__tile
          ;
          uint64_t v491 = (uint64_t) v23;
          TASSIGN(v490, v491);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
          TMATMUL(v490, v482, v486);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
          for (int64_t v492 = v43; v492 < v44; v492 += v27) {
            // pto: %347, %346, %348, %349
            ;
            int64_t v493 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v402 + (uint64_t) ((int64_t) (uint64_t) v492 * (uint64_t) v31)) + (uint64_t) v27) % v30;
            // pto: %350, %351, %352
            ;
            int64_t v494 = v493 < v43 ? (int64_t) ((uint64_t) v493 + (uint64_t) v30) : v493;
            // pto: %353
            ;
            // pto: %354
            ;
            int64_t v495 = v447 < v34 ? v447 : v34;
            v114.SetValidShape(v495, v34);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
            if (v494 <= v52) {
              // pto: %355
              ;
              int64_t v496 = (int64_t) ((uint64_t) v494 * (uint64_t) v31);
              // pto: %v4_wide_packet_x__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v497 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v447, v30);
              // pto: %v4_wide_packet_x__tile
              ;
              uint64_t v498 = (uint64_t) v23;
              TASSIGN(v497, v498);
              // pto: %358
              ;
              int64_t v499 = (int64_t) ((uint64_t) v454 + (uint64_t) v496);
              // pto: %359
              ;
              int64_t v500 = v499 < v43 ? v43 : v499;
              // pto: %360
              ;
              const int64_t v501 = 0;
              // pto: %360
              ;
              __gm__ bfloat16_t* v502 = PTOAS__GLOBAL_TENSOR_DATA(v68);
              // pto: %360
              ;
              const int64_t v503 = 1;
              // pto: %360
              ;
              const int64_t v504 = 1;
              // pto: %360
              ;
              const int64_t v505 = 1;
              // pto: %360
              ;
              int64_t v506 = v447 * v26;
              // pto: %360
              ;
              int64_t v507 = v505 * v506;
              // pto: %360
              ;
              pto::Shape<1, 1, 1, -1, 256> v508 = pto::Shape<1, 1, 1, -1, 256>(v503, v504, v505, v447, v30);
              // pto: %360
              ;
              pto::Stride<-1, -1, -1, -1, -1> v509 = pto::Stride<-1, -1, -1, -1, -1>(v504 * v507, v507, v506, v26, v27);
              // pto: %360
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v510 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v502 + (v501 + v453 * v26 + v500 * v27), v508, v509);
              TLOAD(v497, v510);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              // pto: %v4_wide_packet_w__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v511 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v30, v34);
              // pto: %v4_wide_packet_w__tile
              ;
              uint64_t v512 = (uint64_t) v24;
              TASSIGN(v511, v512);
              // pto: %364
              ;
              int64_t v513 = v496 / v31;
              // pto: %365
              ;
              int64_t v514 = v513 < v43 ? v43 : v513;
              // pto: %366
              ;
              __gm__ bfloat16_t* v515 = PTOAS__GLOBAL_TENSOR_DATA(v71);
              // pto: %366
              ;
              const int64_t v516 = 0;
              // pto: %366
              ;
              const int64_t v517 = 4194304;
              // pto: %366
              ;
              const int64_t v518 = 65536;
              // pto: %366
              ;
              const int64_t v519 = 256;
              // pto: %366
              ;
              pto::Shape<1, 8, 16, 16, 16> v520 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %366
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v521 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %366
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v522 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v515 + ((v516 + v469 * v517) + v471 * v518 + v514 * v519), v520, v521);
              TLOAD(v511, v522);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              // pto: %v4_wide_acc__iter_v1_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v523 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v447, v34);
              // pto: %v4_wide_acc__iter_v1_l0_a
              ;
              uint64_t v524 = (uint64_t) v23;
              TASSIGN(v523, v524);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              uint16_t v525 = static_cast<uint16_t>(v43);
              uint16_t v526 = static_cast<uint16_t>(v43);
              TEXTRACT(v523, v497, v525, v526);
              // pto: %v4_wide_acc__iter_v1_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v527 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v34, v34);
              // pto: %v4_wide_acc__iter_v1_l0_b
              ;
              uint64_t v528 = (uint64_t) v23;
              TASSIGN(v527, v528);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              uint16_t v529 = static_cast<uint16_t>(v43);
              uint16_t v530 = static_cast<uint16_t>(v43);
              TEXTRACT(v527, v511, v529, v530);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
              // pto: %9
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v531 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v447, v34);
              // pto: %9
              ;
              uint64_t v532 = (uint64_t) v25;
              TASSIGN(v531, v532);
              uint16_t v533 = static_cast<uint16_t>(v43);
              uint16_t v534 = static_cast<uint16_t>(v34);
              TEXTRACT(v531, v497, v533, v534);
              // pto: %10
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v535 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v34, v34);
              // pto: %10
              ;
              uint64_t v536 = (uint64_t) v25;
              TASSIGN(v535, v536);
              uint16_t v537 = static_cast<uint16_t>(v34);
              uint16_t v538 = static_cast<uint16_t>(v43);
              TEXTRACT(v535, v511, v537, v538);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v490, v490, v523, v527);
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
              TMATMUL_ACC(v490, v490, v531, v535);
            } else {
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
              for (int64_t v539 = v43; v539 < v31; v539 += v27) {
                // pto: %367, %368
                ;
                int64_t v540 = (int64_t) ((uint64_t) v494 + (uint64_t) v539) % v30;
                // pto: %369, %370, %371
                ;
                int64_t v541 = v540 < v43 ? (int64_t) ((uint64_t) v540 + (uint64_t) v30) : v540;
                // pto: %372
                ;
                int64_t v542 = (int64_t) ((uint64_t) v541 * (uint64_t) v31);
                // pto: %v4_wide_wrap_x__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v543 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v447, v31);
                // pto: %v4_wide_wrap_x__tile
                ;
                uint64_t v544 = (uint64_t) v23;
                TASSIGN(v543, v544);
                // pto: %375
                ;
                int64_t v545 = (int64_t) ((uint64_t) v454 + (uint64_t) v542);
                // pto: %376
                ;
                int64_t v546 = v545 < v43 ? v43 : v545;
                // pto: %377
                ;
                const int64_t v547 = 0;
                // pto: %377
                ;
                __gm__ bfloat16_t* v548 = PTOAS__GLOBAL_TENSOR_DATA(v68);
                // pto: %377
                ;
                const int64_t v549 = 1;
                // pto: %377
                ;
                const int64_t v550 = 1;
                // pto: %377
                ;
                const int64_t v551 = 1;
                // pto: %377
                ;
                int64_t v552 = v447 * v26;
                // pto: %377
                ;
                int64_t v553 = v551 * v552;
                // pto: %377
                ;
                pto::Shape<1, 1, 1, -1, 16> v554 = pto::Shape<1, 1, 1, -1, 16>(v549, v550, v551, v447, v31);
                // pto: %377
                ;
                pto::Stride<-1, -1, -1, -1, -1> v555 = pto::Stride<-1, -1, -1, -1, -1>(v550 * v553, v553, v552, v26, v27);
                // pto: %377
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v556 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v548 + (v547 + v453 * v26 + v546 * v27), v554, v555);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
                TLOAD(v543, v556);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                // pto: %v4_wide_wrap_w__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v557 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v31, v34);
                // pto: %v4_wide_wrap_w__tile
                ;
                uint64_t v558 = (uint64_t) v24;
                TASSIGN(v557, v558);
                // pto: %381
                ;
                int64_t v559 = v542 / v31;
                // pto: %382
                ;
                int64_t v560 = v559 < v43 ? v43 : v559;
                // pto: %383
                ;
                __gm__ bfloat16_t* v561 = PTOAS__GLOBAL_TENSOR_DATA(v71);
                // pto: %383
                ;
                const int64_t v562 = 0;
                // pto: %383
                ;
                const int64_t v563 = 4194304;
                // pto: %383
                ;
                const int64_t v564 = 65536;
                // pto: %383
                ;
                const int64_t v565 = 256;
                // pto: %383
                ;
                pto::Shape<1, 8, 1, 16, 16> v566 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %383
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v567 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %383
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v568 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v561 + ((v562 + v469 * v563) + v471 * v564 + v560 * v565), v566, v567);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                TLOAD(v557, v568);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                // pto: %12
                ;
                Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v569 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v447, v31);
                // pto: %12
                ;
                uint64_t v570 = (uint64_t) v23;
                TASSIGN(v569, v570);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
                uint16_t v571 = static_cast<uint16_t>(v43);
                uint16_t v572 = static_cast<uint16_t>(v43);
                TEXTRACT(v569, v543, v571, v572);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
                // pto: %13
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v573 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v31, v34);
                // pto: %13
                ;
                uint64_t v574 = (uint64_t) v23;
                TASSIGN(v573, v574);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                uint16_t v575 = static_cast<uint16_t>(v43);
                uint16_t v576 = static_cast<uint16_t>(v43);
                TEXTRACT(v573, v557, v575, v576);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v490, v490, v569, v573);
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            };
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
          for (int64_t v577 = v54; v577 < v30; v577 += v27) {
            // pto: %384, %385
            ;
            int64_t v578 = (int64_t) ((uint64_t) v402 + (uint64_t) v577) % v30;
            // pto: %386, %387, %388
            ;
            int64_t v579 = v578 < v43 ? (int64_t) ((uint64_t) v578 + (uint64_t) v30) : v578;
            // pto: %389
            ;
            int64_t v580 = (int64_t) ((uint64_t) v579 * (uint64_t) v31);
            // pto: %v4_wide_tail_x__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v581 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v447, v31);
            // pto: %v4_wide_tail_x__tile
            ;
            uint64_t v582 = (uint64_t) v23;
            TASSIGN(v581, v582);
            // pto: %392
            ;
            int64_t v583 = (int64_t) ((uint64_t) v454 + (uint64_t) v580);
            // pto: %393
            ;
            int64_t v584 = v583 < v43 ? v43 : v583;
            // pto: %394
            ;
            const int64_t v585 = 0;
            // pto: %394
            ;
            __gm__ bfloat16_t* v586 = PTOAS__GLOBAL_TENSOR_DATA(v68);
            // pto: %394
            ;
            const int64_t v587 = 1;
            // pto: %394
            ;
            const int64_t v588 = 1;
            // pto: %394
            ;
            const int64_t v589 = 1;
            // pto: %394
            ;
            int64_t v590 = v447 * v26;
            // pto: %394
            ;
            int64_t v591 = v589 * v590;
            // pto: %394
            ;
            pto::Shape<1, 1, 1, -1, 16> v592 = pto::Shape<1, 1, 1, -1, 16>(v587, v588, v589, v447, v31);
            // pto: %394
            ;
            pto::Stride<-1, -1, -1, -1, -1> v593 = pto::Stride<-1, -1, -1, -1, -1>(v588 * v591, v591, v590, v26, v27);
            // pto: %394
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v594 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v586 + (v585 + v453 * v26 + v584 * v27), v592, v593);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
            TLOAD(v581, v594);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %v4_wide_tail_w__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v595 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v31, v34);
            // pto: %v4_wide_tail_w__tile
            ;
            uint64_t v596 = (uint64_t) v24;
            TASSIGN(v595, v596);
            // pto: %398
            ;
            int64_t v597 = v580 / v31;
            // pto: %399
            ;
            int64_t v598 = v597 < v43 ? v43 : v597;
            // pto: %400
            ;
            __gm__ bfloat16_t* v599 = PTOAS__GLOBAL_TENSOR_DATA(v71);
            // pto: %400
            ;
            const int64_t v600 = 0;
            // pto: %400
            ;
            const int64_t v601 = 4194304;
            // pto: %400
            ;
            const int64_t v602 = 65536;
            // pto: %400
            ;
            const int64_t v603 = 256;
            // pto: %400
            ;
            pto::Shape<1, 8, 1, 16, 16> v604 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %400
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v605 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %400
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v606 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v599 + ((v600 + v469 * v601) + v471 * v602 + v598 * v603), v604, v605);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            TLOAD(v595, v606);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %14
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v607 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v447, v31);
            // pto: %14
            ;
            uint64_t v608 = (uint64_t) v23;
            TASSIGN(v607, v608);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
            uint16_t v609 = static_cast<uint16_t>(v43);
            uint16_t v610 = static_cast<uint16_t>(v43);
            TEXTRACT(v607, v581, v609, v610);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
            // pto: %15
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v611 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v31, v34);
            // pto: %15
            ;
            uint64_t v612 = (uint64_t) v23;
            TASSIGN(v611, v612);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            uint16_t v613 = static_cast<uint16_t>(v43);
            uint16_t v614 = static_cast<uint16_t>(v43);
            TEXTRACT(v611, v595, v613, v614);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v490, v490, v607, v611);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
          // pto: %402, %403
          ;
          int64_t v615 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v394 * (uint64_t) v53) + (uint64_t) v397);
          // pto: %404
          ;
          int64_t v616 = v615 < v43 ? v43 : v615;
          // pto: %405
          ;
          const int64_t v617 = 0;
          // pto: %405
          ;
          __gm__ float* v618 = PTOAS__GLOBAL_TENSOR_DATA(v92);
          // pto: %405
          ;
          const int64_t v619 = 1;
          // pto: %405
          ;
          const int64_t v620 = 1;
          // pto: %405
          ;
          const int64_t v621 = 1;
          // pto: %405
          ;
          int64_t v622 = v447 * v40;
          // pto: %405
          ;
          int64_t v623 = v621 * v622;
          // pto: %405
          ;
          pto::Shape<1, 1, 1, -1, 128> v624 = pto::Shape<1, 1, 1, -1, 128>(v619, v620, v621, v447, v34);
          // pto: %405
          ;
          pto::Stride<-1, -1, -1, -1, -1> v625 = pto::Stride<-1, -1, -1, -1, -1>(v620 * v623, v623, v622, v40, v27);
          // pto: %405
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v626 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v618 + (v617 + v453 * v40 + v616 * v27), v624, v625);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
          TSTORE(v626, v490);
        } else {
          for (int64_t v627 = v43; v627 < v28; v627 += v27) {
            // pto: %406
            ;
            int64_t v628 = (int64_t) ((uint64_t) v399 + (uint64_t) v627);
            // pto: %407
            ;
            if (v628 < v130) {
              // pto: %408
              ;
              int64_t v629 = (int64_t) ((uint64_t) v628 * (uint64_t) v31);
              // pto: %409
              ;
              int64_t v630 = (int64_t) ((uint64_t) v17 - (uint64_t) v629);
              // pto: %410
              ;
              int64_t v631 = v630 < v31 ? v630 : v31;
              // pto: %412, %413, %414, %415, %411
              ;
              int32_t v632 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v628 * (uint64_t) v28) + (uint64_t) v394) * (uint64_t) v28) + (uint64_t) v396)];
              // pto: %416
              ;
              int64_t v633 = (int64_t) v632;
              // pto: %417
              ;
              int64_t v634 = v633 < v43 ? v43 : v633;
              // pto: %v4_narrow_acc__tile
              ;
              Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v635 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v31, v34);
              // pto: %v4_narrow_acc__tile
              ;
              uint64_t v636 = (uint64_t) v23;
              TASSIGN(v635, v636);
              wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
              for (int64_t v637 = v43; v637 < v31; v637 += v27) {
                // pto: %418
                ;
                int64_t v638 = (int64_t) ((uint64_t) v637 * (uint64_t) v31);
                // pto: %419, %420
                ;
                int64_t v639 = (int64_t) ((uint64_t) v634 + (uint64_t) v638) % v30;
                // pto: %421, %422, %423
                ;
                int64_t v640 = v639 < v43 ? (int64_t) ((uint64_t) v639 + (uint64_t) v30) : v639;
                // pto: %424
                ;
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
                if (v640 <= v52) {
                  // pto: %425
                  ;
                  int64_t v641 = (int64_t) ((uint64_t) v640 * (uint64_t) v31);
                  // pto: %v4_narrow_packet_x__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v642 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v631, v30);
                  // pto: %v4_narrow_packet_x__tile
                  ;
                  uint64_t v643 = (uint64_t) v24;
                  TASSIGN(v642, v643);
                  // pto: %426
                  ;
                  int64_t v644 = v629 < v43 ? v43 : v629;
                  // pto: %427, %428
                  ;
                  int64_t v645 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v394 * (uint64_t) v39) + (uint64_t) v641);
                  // pto: %429
                  ;
                  int64_t v646 = v645 < v43 ? v43 : v645;
                  // pto: %430
                  ;
                  const int64_t v647 = 0;
                  // pto: %430
                  ;
                  __gm__ bfloat16_t* v648 = PTOAS__GLOBAL_TENSOR_DATA(v68);
                  // pto: %430
                  ;
                  const int64_t v649 = 1;
                  // pto: %430
                  ;
                  const int64_t v650 = 1;
                  // pto: %430
                  ;
                  const int64_t v651 = 1;
                  // pto: %430
                  ;
                  int64_t v652 = v631 * v26;
                  // pto: %430
                  ;
                  int64_t v653 = v651 * v652;
                  // pto: %430
                  ;
                  pto::Shape<1, 1, 1, -1, 256> v654 = pto::Shape<1, 1, 1, -1, 256>(v649, v650, v651, v631, v30);
                  // pto: %430
                  ;
                  pto::Stride<-1, -1, -1, -1, -1> v655 = pto::Stride<-1, -1, -1, -1, -1>(v650 * v653, v653, v652, v26, v27);
                  // pto: %430
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v656 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v648 + (v647 + v644 * v26 + v646 * v27), v654, v655);
                  TLOAD(v642, v656);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  // pto: %v4_narrow_packet_w__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v657 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v30, v34);
                  // pto: %v4_narrow_packet_w__tile
                  ;
                  uint64_t v658 = (uint64_t) v23;
                  TASSIGN(v657, v658);
                  // pto: %431
                  ;
                  int64_t v659 = v394 < v43 ? v43 : v394;
                  // pto: %432
                  ;
                  int64_t v660 = v397 / v31;
                  // pto: %433
                  ;
                  int64_t v661 = v660 < v43 ? v43 : v660;
                  // pto: %434
                  ;
                  int64_t v662 = v641 / v31;
                  // pto: %435
                  ;
                  int64_t v663 = v662 < v43 ? v43 : v662;
                  // pto: %436
                  ;
                  __gm__ bfloat16_t* v664 = PTOAS__GLOBAL_TENSOR_DATA(v71);
                  // pto: %436
                  ;
                  const int64_t v665 = 0;
                  // pto: %436
                  ;
                  const int64_t v666 = 4194304;
                  // pto: %436
                  ;
                  const int64_t v667 = 65536;
                  // pto: %436
                  ;
                  const int64_t v668 = 256;
                  // pto: %436
                  ;
                  pto::Shape<1, 8, 16, 16, 16> v669 = pto::Shape<1, 8, 16, 16, 16>();
                  // pto: %436
                  ;
                  pto::Stride<4194304, 65536, 256, 16, 1> v670 = pto::Stride<4194304, 65536, 256, 16, 1>();
                  // pto: %436
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v671 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v664 + ((v665 + v659 * v666) + v661 * v667 + v663 * v668), v669, v670);
                  TLOAD(v657, v671);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  // pto: %v4_narrow_acc__iter_v1_l0_a
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v672 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v631, v34);
                  // pto: %v4_narrow_acc__iter_v1_l0_a
                  ;
                  uint64_t v673 = (uint64_t) v23;
                  TASSIGN(v672, v673);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  uint16_t v674 = static_cast<uint16_t>(v43);
                  uint16_t v675 = static_cast<uint16_t>(v43);
                  TEXTRACT(v672, v642, v674, v675);
                  // pto: %v4_narrow_acc__iter_v1_l0_b
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v676 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v34, v34);
                  // pto: %v4_narrow_acc__iter_v1_l0_b
                  ;
                  uint64_t v677 = (uint64_t) v23;
                  TASSIGN(v676, v677);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  uint16_t v678 = static_cast<uint16_t>(v43);
                  uint16_t v679 = static_cast<uint16_t>(v43);
                  TEXTRACT(v676, v657, v678, v679);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  // pto: %16
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v680 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v631, v34);
                  // pto: %16
                  ;
                  uint64_t v681 = (uint64_t) v25;
                  TASSIGN(v680, v681);
                  uint16_t v682 = static_cast<uint16_t>(v43);
                  uint16_t v683 = static_cast<uint16_t>(v34);
                  TEXTRACT(v680, v642, v682, v683);
                  // pto: %17
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v684 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v34, v34);
                  // pto: %17
                  ;
                  uint64_t v685 = (uint64_t) v25;
                  TASSIGN(v684, v685);
                  uint16_t v686 = static_cast<uint16_t>(v34);
                  uint16_t v687 = static_cast<uint16_t>(v43);
                  TEXTRACT(v684, v657, v686, v687);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  // pto: %437
                  ;
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  if (v637 == v43) {
                    pipe_barrier(PIPE_M);
                    TMATMUL(v635, v672, v676);
                  } else {
                    pipe_barrier(PIPE_M);
                    TMATMUL_ACC(v635, v635, v672, v676);
                  };
                  pipe_barrier(PIPE_M);
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  TMATMUL_ACC(v635, v635, v680, v684);
                } else {
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                  for (int64_t v688 = v43; v688 < v31; v688 += v27) {
                    // pto: %438, %439
                    ;
                    int64_t v689 = (int64_t) ((uint64_t) v640 + (uint64_t) v688) % v30;
                    // pto: %440, %441, %442
                    ;
                    int64_t v690 = v689 < v43 ? (int64_t) ((uint64_t) v689 + (uint64_t) v30) : v689;
                    // pto: %443
                    ;
                    int64_t v691 = (int64_t) ((uint64_t) v690 * (uint64_t) v31);
                    // pto: %v4_narrow_wrap_x__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v692 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v631, v31);
                    // pto: %v4_narrow_wrap_x__tile
                    ;
                    uint64_t v693 = (uint64_t) v24;
                    TASSIGN(v692, v693);
                    // pto: %444
                    ;
                    int64_t v694 = v629 < v43 ? v43 : v629;
                    // pto: %445, %446
                    ;
                    int64_t v695 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v394 * (uint64_t) v39) + (uint64_t) v691);
                    // pto: %447
                    ;
                    int64_t v696 = v695 < v43 ? v43 : v695;
                    // pto: %448
                    ;
                    const int64_t v697 = 0;
                    // pto: %448
                    ;
                    __gm__ bfloat16_t* v698 = PTOAS__GLOBAL_TENSOR_DATA(v68);
                    // pto: %448
                    ;
                    const int64_t v699 = 1;
                    // pto: %448
                    ;
                    const int64_t v700 = 1;
                    // pto: %448
                    ;
                    const int64_t v701 = 1;
                    // pto: %448
                    ;
                    int64_t v702 = v631 * v26;
                    // pto: %448
                    ;
                    int64_t v703 = v701 * v702;
                    // pto: %448
                    ;
                    pto::Shape<1, 1, 1, -1, 16> v704 = pto::Shape<1, 1, 1, -1, 16>(v699, v700, v701, v631, v31);
                    // pto: %448
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v705 = pto::Stride<-1, -1, -1, -1, -1>(v700 * v703, v703, v702, v26, v27);
                    // pto: %448
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v706 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v698 + (v697 + v694 * v26 + v696 * v27), v704, v705);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
                    TLOAD(v692, v706);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    // pto: %v4_narrow_wrap_w__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v707 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v31, v34);
                    // pto: %v4_narrow_wrap_w__tile
                    ;
                    uint64_t v708 = (uint64_t) v23;
                    TASSIGN(v707, v708);
                    // pto: %449
                    ;
                    int64_t v709 = v394 < v43 ? v43 : v394;
                    // pto: %450
                    ;
                    int64_t v710 = v397 / v31;
                    // pto: %451
                    ;
                    int64_t v711 = v710 < v43 ? v43 : v710;
                    // pto: %452
                    ;
                    int64_t v712 = v691 / v31;
                    // pto: %453
                    ;
                    int64_t v713 = v712 < v43 ? v43 : v712;
                    // pto: %454
                    ;
                    __gm__ bfloat16_t* v714 = PTOAS__GLOBAL_TENSOR_DATA(v71);
                    // pto: %454
                    ;
                    const int64_t v715 = 0;
                    // pto: %454
                    ;
                    const int64_t v716 = 4194304;
                    // pto: %454
                    ;
                    const int64_t v717 = 65536;
                    // pto: %454
                    ;
                    const int64_t v718 = 256;
                    // pto: %454
                    ;
                    pto::Shape<1, 8, 1, 16, 16> v719 = pto::Shape<1, 8, 1, 16, 16>();
                    // pto: %454
                    ;
                    pto::Stride<4194304, 65536, 256, 16, 1> v720 = pto::Stride<4194304, 65536, 256, 16, 1>();
                    // pto: %454
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v721 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v714 + ((v715 + v709 * v716) + v711 * v717 + v713 * v718), v719, v720);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    TLOAD(v707, v721);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    // pto: %19
                    ;
                    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v722 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v631, v31);
                    // pto: %19
                    ;
                    uint64_t v723 = (uint64_t) v23;
                    TASSIGN(v722, v723);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                    uint16_t v724 = static_cast<uint16_t>(v43);
                    uint16_t v725 = static_cast<uint16_t>(v43);
                    TEXTRACT(v722, v692, v724, v725);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
                    // pto: %20
                    ;
                    Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v726 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v31, v34);
                    // pto: %20
                    ;
                    uint64_t v727 = (uint64_t) v23;
                    TASSIGN(v726, v727);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    uint16_t v728 = static_cast<uint16_t>(v43);
                    uint16_t v729 = static_cast<uint16_t>(v43);
                    TEXTRACT(v726, v707, v728, v729);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    // pto: %456, %457
                    ;
                    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    if ((int64_t) ((uint64_t) v638 + (uint64_t) v688) == v43) {
                      pipe_barrier(PIPE_M);
                      TMATMUL(v635, v722, v726);
                    } else {
                      pipe_barrier(PIPE_M);
                      TMATMUL_ACC(v635, v635, v722, v726);
                    };
                    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                  };
                  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
              set_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
              // pto: %458
              ;
              int64_t v730 = v629 < v43 ? v43 : v629;
              // pto: %459, %460
              ;
              int64_t v731 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v394 * (uint64_t) v53) + (uint64_t) v397);
              // pto: %461
              ;
              int64_t v732 = v731 < v43 ? v43 : v731;
              // pto: %462
              ;
              __gm__ float* v733 = PTOAS__GLOBAL_TENSOR_DATA(v92);
              // pto: %462
              ;
              const int64_t v734 = 0;
              // pto: %462
              ;
              const int64_t v735 = 8192;
              // pto: %462
              ;
              pto::Shape<1, 1, 1, 16, 128> v736 = pto::Shape<1, 1, 1, 16, 128>();
              // pto: %462
              ;
              pto::Stride<131072, 131072, 131072, 8192, 1> v737 = pto::Stride<131072, 131072, 131072, 8192, 1>();
              // pto: %462
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v738 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v733 + (v734 + v730 * v735 + v732), v736, v737);
              wait_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
              pipe_barrier(PIPE_FIX);
              TSTORE(v738, v635);
              set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
            };
          };
        };
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      };
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
    };
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %464
  int64_t v739 = (int64_t) ((uint64_t) v119 + (uint64_t) v55);
  // pto: %465
  int64_t v740 = v739 < v43 ? v43 : v739;
  // pto: %signals__ssa_v1_signal_pview
  __gm__ int32_t* v741 = PTOAS__GLOBAL_TENSOR_DATA(v111);
  // pto: %signals__ssa_v1_signal_pview
  const int64_t v742 = 0;
  // pto: %signals__ssa_v1_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v743 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v744 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v745 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v741 + (v742 + v740), v743, v744);
  pto::comm::NotifyOp v746 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v745, v128, v746);
  for (int64_t v747 = v46; v747 < v56; v747 += v27) {
    // pto: %466, %467
    ;
    int64_t v748 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v747 * (uint64_t) v34) + (uint64_t) v57);
    // pto: %468
    ;
    int64_t v749 = v748 < v43 ? v43 : v748;
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v750 = PTOAS__GLOBAL_TENSOR_DATA(v111);
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    const int64_t v751 = 0;
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v752 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v753 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v754 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v750 + (v751 + v749), v752, v753);
    pto::comm::WaitCmp v755 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v754, v128, v755);
  }
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %469
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
  if (v17 <= v31) {
    // pto: %470
    ;
    for (int64_t v756 = v118; v756 < ((int64_t) ((uint64_t) v130 * (uint64_t) v36)); v756 += v46) {
      // pto: %471, %472
      ;
      int64_t v757 = (int64_t) ((uint64_t) (v756 / v36) * (uint64_t) v31);
      // pto: %473
      ;
      int64_t v758 = v756 % v36;
      // pto: %474, %475, %476
      ;
      int64_t v759 = v758 < v43 ? (int64_t) ((uint64_t) v758 + (uint64_t) v36) : v758;
      // pto: %477
      ;
      int64_t v760 = (int64_t) ((uint64_t) v759 * (uint64_t) v34);
      // pto: %478
      ;
      int64_t v761 = (int64_t) ((uint64_t) v17 - (uint64_t) v757);
      // pto: %479
      ;
      int64_t v762 = v761 < v31 ? v761 : v31;
      // pto: %b_acc__tile
      ;
      Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v763 = Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v31, v34);
      // pto: %b_acc__tile
      ;
      uint64_t v764 = (uint64_t) v23;
      TASSIGN(v763, v764);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      for (int64_t v765 = v43; v765 < v31; v765 += v27) {
        // pto: %480
        ;
        int64_t v766 = (int64_t) ((uint64_t) v765 * (uint64_t) v35);
        // pto: %b_input__tile
        ;
        Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v767 = Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v762, v35);
        // pto: %b_input__tile
        ;
        uint64_t v768 = (uint64_t) v24;
        TASSIGN(v767, v768);
        // pto: %481
        ;
        int64_t v769 = v757 < v43 ? v43 : v757;
        // pto: %482
        ;
        int64_t v770 = v766 < v43 ? v43 : v766;
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v771 = 0;
        // pto: %quantized__ssa_v0_pview
        ;
        __gm__ int8_t* v772 = PTOAS__GLOBAL_TENSOR_DATA(v83);
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v773 = 1;
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v774 = 1;
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v775 = 1;
        // pto: %quantized__ssa_v0_pview
        ;
        int64_t v776 = v762 * v40;
        // pto: %quantized__ssa_v0_pview
        ;
        int64_t v777 = v775 * v776;
        // pto: %quantized__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 512> v778 = pto::Shape<1, 1, 1, -1, 512>(v773, v774, v775, v762, v35);
        // pto: %quantized__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v779 = pto::Stride<-1, -1, -1, -1, -1>(v774 * v777, v777, v776, v40, v27);
        // pto: %quantized__ssa_v0_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v780 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v772 + (v771 + v769 * v40 + v770 * v27), v778, v779);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        TLOAD(v767, v780);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %b_weight__tile
        ;
        Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v781 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v35, v34);
        // pto: %b_weight__tile
        ;
        uint64_t v782 = (uint64_t) v23;
        TASSIGN(v781, v782);
        // pto: %483
        ;
        int64_t v783 = v760 / v36;
        // pto: %484
        ;
        int64_t v784 = v783 < v43 ? v43 : v783;
        // pto: %485
        ;
        int64_t v785 = v766 / v31;
        // pto: %486
        ;
        int64_t v786 = v785 < v43 ? v43 : v785;
        // pto: %wo_b__ssa_v0_pview
        ;
        __gm__ int8_t* v787 = PTOAS__GLOBAL_TENSOR_DATA(v74);
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v788 = 0;
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v789 = 262144;
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v790 = 512;
        // pto: %wo_b__ssa_v0_pview
        ;
        pto::Shape<1, 4, 32, 16, 32> v791 = pto::Shape<1, 4, 32, 16, 32>();
        // pto: %wo_b__ssa_v0_pview
        ;
        pto::Stride<33554432, 262144, 512, 32, 1> v792 = pto::Stride<33554432, 262144, 512, 32, 1>();
        // pto: %wo_b__ssa_v0_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v793 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v787 + (v788 + v784 * v789 + v786 * v790), v791, v792);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v781, v793);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %b_acc__tile_l0_a
        ;
        Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v794 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v762, v30);
        // pto: %b_acc__tile_l0_a
        ;
        uint64_t v795 = (uint64_t) v23;
        TASSIGN(v794, v795);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        uint16_t v796 = static_cast<uint16_t>(v43);
        uint16_t v797 = static_cast<uint16_t>(v43);
        TEXTRACT(v794, v767, v796, v797);
        // pto: %b_acc__tile_l0_b
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v798 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v34);
        // pto: %b_acc__tile_l0_b
        ;
        uint64_t v799 = (uint64_t) v23;
        TASSIGN(v798, v799);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v800 = static_cast<uint16_t>(v43);
        uint16_t v801 = static_cast<uint16_t>(v43);
        TEXTRACT(v798, v781, v800, v801);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %21
        ;
        Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v802 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v762, v30);
        // pto: %21
        ;
        uint64_t v803 = (uint64_t) v25;
        TASSIGN(v802, v803);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v804 = static_cast<uint16_t>(v43);
        uint16_t v805 = static_cast<uint16_t>(v30);
        TEXTRACT(v802, v767, v804, v805);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        // pto: %22
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v806 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v34);
        // pto: %22
        ;
        uint64_t v807 = (uint64_t) v25;
        TASSIGN(v806, v807);
        uint16_t v808 = static_cast<uint16_t>(v30);
        uint16_t v809 = static_cast<uint16_t>(v43);
        TEXTRACT(v806, v781, v808, v809);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %487
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        if (v765 == v43) {
          pipe_barrier(PIPE_M);
          TMATMUL(v763, v794, v798);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v763, v763, v794, v798);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v763, v763, v802, v806);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
      // pto: %488
      ;
      int64_t v810 = v757 < v43 ? v43 : v757;
      // pto: %489
      ;
      int64_t v811 = v760 < v43 ? v43 : v760;
      // pto: %integer_accum__ssa_v0_pview
      ;
      __gm__ int32_t* v812 = PTOAS__GLOBAL_TENSOR_DATA(v101);
      // pto: %integer_accum__ssa_v0_pview
      ;
      const int64_t v813 = 0;
      // pto: %integer_accum__ssa_v0_pview
      ;
      const int64_t v814 = 4096;
      // pto: %integer_accum__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 128> v815 = pto::Shape<1, 1, 1, 16, 128>();
      // pto: %integer_accum__ssa_v0_pview
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v816 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %integer_accum__ssa_v0_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v817 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v812 + (v813 + v810 * v814 + v811), v815, v816);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
      pipe_barrier(PIPE_FIX);
      TSTORE(v817, v763);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
    };
  } else {
    // pto: %490, %491, %492
    ;
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    for (int64_t v818 = v118; v818 < ((int64_t) ((uint64_t) ((int64_t) ((uint64_t) v17 + (uint64_t) v58) / v29) * (uint64_t) v36)); v818 += v46) {
      // pto: %493, %494
      ;
      int64_t v819 = (int64_t) ((uint64_t) (v818 / v36) * (uint64_t) v29);
      // pto: %495
      ;
      int64_t v820 = v818 % v36;
      // pto: %496, %497, %498
      ;
      int64_t v821 = v820 < v43 ? (int64_t) ((uint64_t) v820 + (uint64_t) v36) : v820;
      // pto: %499
      ;
      int64_t v822 = (int64_t) ((uint64_t) v821 * (uint64_t) v34);
      // pto: %500
      ;
      int64_t v823 = (int64_t) ((uint64_t) v17 - (uint64_t) v819);
      // pto: %501
      ;
      int64_t v824 = v823 < v29 ? v823 : v29;
      // pto: %wide_first_input__tile
      ;
      Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v825 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v824, v35);
      // pto: %wide_first_input__tile
      ;
      uint64_t v826 = (uint64_t) v24;
      TASSIGN(v825, v826);
      // pto: %502
      ;
      int64_t v827 = v819 < v43 ? v43 : v819;
      // pto: %503
      ;
      const int64_t v828 = 0;
      // pto: %503
      ;
      __gm__ int8_t* v829 = PTOAS__GLOBAL_TENSOR_DATA(v83);
      // pto: %503
      ;
      const int64_t v830 = 1;
      // pto: %503
      ;
      const int64_t v831 = 1;
      // pto: %503
      ;
      const int64_t v832 = 1;
      // pto: %503
      ;
      int64_t v833 = v824 * v40;
      // pto: %503
      ;
      int64_t v834 = v832 * v833;
      // pto: %503
      ;
      pto::Shape<1, 1, 1, -1, 512> v835 = pto::Shape<1, 1, 1, -1, 512>(v830, v831, v832, v824, v35);
      // pto: %503
      ;
      pto::Stride<-1, -1, -1, -1, -1> v836 = pto::Stride<-1, -1, -1, -1, -1>(v831 * v834, v834, v833, v40, v27);
      // pto: %503
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v837 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v829 + (v828 + v827 * v40 + v43 * v27), v835, v836);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v825, v837);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %wide_first_weight__tile
      ;
      Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v838 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v35, v34);
      // pto: %wide_first_weight__tile
      ;
      uint64_t v839 = (uint64_t) v23;
      TASSIGN(v838, v839);
      // pto: %504
      ;
      int64_t v840 = v822 / v36;
      // pto: %505
      ;
      int64_t v841 = v840 < v43 ? v43 : v840;
      // pto: %506
      ;
      __gm__ int8_t* v842 = PTOAS__GLOBAL_TENSOR_DATA(v74);
      // pto: %506
      ;
      const int64_t v843 = 0;
      // pto: %506
      ;
      const int64_t v844 = 262144;
      // pto: %506
      ;
      pto::Shape<1, 4, 32, 16, 32> v845 = pto::Shape<1, 4, 32, 16, 32>();
      // pto: %506
      ;
      pto::Stride<33554432, 262144, 512, 32, 1> v846 = pto::Stride<33554432, 262144, 512, 32, 1>();
      // pto: %506
      ;
      GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v847 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v842 + (v843 + v841 * v844), v845, v846);
      TLOAD(v838, v847);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %wide_b_acc__tile_l0_init_storage
      ;
      Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v848 = Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v29, v34);
      // pto: %wide_b_acc__tile_l0_init_storage
      ;
      uint64_t v849 = (uint64_t) v23;
      TASSIGN(v848, v849);
      v848.SetValidShape(v824, v34);
      // pto: %wide_b_acc__tile_l0_a
      ;
      Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v850 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v824, v30);
      // pto: %wide_b_acc__tile_l0_a
      ;
      uint64_t v851 = (uint64_t) v23;
      TASSIGN(v850, v851);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      uint16_t v852 = static_cast<uint16_t>(v43);
      uint16_t v853 = static_cast<uint16_t>(v43);
      TEXTRACT(v850, v825, v852, v853);
      // pto: %wide_b_acc__tile_l0_b
      ;
      Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v854 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v34);
      // pto: %wide_b_acc__tile_l0_b
      ;
      uint64_t v855 = (uint64_t) v23;
      TASSIGN(v854, v855);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      uint16_t v856 = static_cast<uint16_t>(v43);
      uint16_t v857 = static_cast<uint16_t>(v43);
      TEXTRACT(v854, v838, v856, v857);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %24
      ;
      Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v858 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v824, v30);
      // pto: %24
      ;
      uint64_t v859 = (uint64_t) v25;
      TASSIGN(v858, v859);
      uint16_t v860 = static_cast<uint16_t>(v43);
      uint16_t v861 = static_cast<uint16_t>(v30);
      TEXTRACT(v858, v825, v860, v861);
      // pto: %25
      ;
      Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v862 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v34);
      // pto: %25
      ;
      uint64_t v863 = (uint64_t) v25;
      TASSIGN(v862, v863);
      uint16_t v864 = static_cast<uint16_t>(v30);
      uint16_t v865 = static_cast<uint16_t>(v43);
      TEXTRACT(v862, v838, v864, v865);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
      TMATMUL(v848, v850, v854);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v848, v848, v858, v862);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      for (int64_t v866 = v27; v866 < v31; v866 += v27) {
        // pto: %507
        ;
        int64_t v867 = (int64_t) ((uint64_t) v866 * (uint64_t) v35);
        // pto: %wide_b_input__tile
        ;
        Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v868 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v824, v35);
        // pto: %wide_b_input__tile
        ;
        uint64_t v869 = (uint64_t) v24;
        TASSIGN(v868, v869);
        // pto: %509
        ;
        int64_t v870 = v867 < v43 ? v43 : v867;
        // pto: %510
        ;
        const int64_t v871 = 0;
        // pto: %510
        ;
        __gm__ int8_t* v872 = PTOAS__GLOBAL_TENSOR_DATA(v83);
        // pto: %510
        ;
        const int64_t v873 = 1;
        // pto: %510
        ;
        const int64_t v874 = 1;
        // pto: %510
        ;
        const int64_t v875 = 1;
        // pto: %510
        ;
        int64_t v876 = v824 * v40;
        // pto: %510
        ;
        int64_t v877 = v875 * v876;
        // pto: %510
        ;
        pto::Shape<1, 1, 1, -1, 512> v878 = pto::Shape<1, 1, 1, -1, 512>(v873, v874, v875, v824, v35);
        // pto: %510
        ;
        pto::Stride<-1, -1, -1, -1, -1> v879 = pto::Stride<-1, -1, -1, -1, -1>(v874 * v877, v877, v876, v40, v27);
        // pto: %510
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v880 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v872 + (v871 + v827 * v40 + v870 * v27), v878, v879);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v868, v880);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %wide_b_weight__tile
        ;
        Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v881 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v35, v34);
        // pto: %wide_b_weight__tile
        ;
        uint64_t v882 = (uint64_t) v23;
        TASSIGN(v881, v882);
        // pto: %513
        ;
        int64_t v883 = v867 / v31;
        // pto: %514
        ;
        int64_t v884 = v883 < v43 ? v43 : v883;
        // pto: %515
        ;
        __gm__ int8_t* v885 = PTOAS__GLOBAL_TENSOR_DATA(v74);
        // pto: %515
        ;
        const int64_t v886 = 0;
        // pto: %515
        ;
        const int64_t v887 = 262144;
        // pto: %515
        ;
        const int64_t v888 = 512;
        // pto: %515
        ;
        pto::Shape<1, 4, 32, 16, 32> v889 = pto::Shape<1, 4, 32, 16, 32>();
        // pto: %515
        ;
        pto::Stride<33554432, 262144, 512, 32, 1> v890 = pto::Stride<33554432, 262144, 512, 32, 1>();
        // pto: %515
        ;
        GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v891 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v885 + (v886 + v841 * v887 + v884 * v888), v889, v890);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        TLOAD(v881, v891);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %27
        ;
        Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v892 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v824, v30);
        // pto: %27
        ;
        uint64_t v893 = (uint64_t) v23;
        TASSIGN(v892, v893);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v894 = static_cast<uint16_t>(v43);
        uint16_t v895 = static_cast<uint16_t>(v43);
        TEXTRACT(v892, v868, v894, v895);
        // pto: %28
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v896 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v34);
        // pto: %28
        ;
        uint64_t v897 = (uint64_t) v23;
        TASSIGN(v896, v897);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v898 = static_cast<uint16_t>(v43);
        uint16_t v899 = static_cast<uint16_t>(v43);
        TEXTRACT(v896, v881, v898, v899);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %29
        ;
        Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v900 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v824, v30);
        // pto: %29
        ;
        uint64_t v901 = (uint64_t) v25;
        TASSIGN(v900, v901);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v902 = static_cast<uint16_t>(v43);
        uint16_t v903 = static_cast<uint16_t>(v30);
        TEXTRACT(v900, v868, v902, v903);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        // pto: %30
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v904 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v34);
        // pto: %30
        ;
        uint64_t v905 = (uint64_t) v25;
        TASSIGN(v904, v905);
        uint16_t v906 = static_cast<uint16_t>(v30);
        uint16_t v907 = static_cast<uint16_t>(v43);
        TEXTRACT(v904, v881, v906, v907);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v848, v848, v892, v896);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v848, v848, v900, v904);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
      // pto: %517
      ;
      int64_t v908 = v822 < v43 ? v43 : v822;
      // pto: %518
      ;
      const int64_t v909 = 0;
      // pto: %518
      ;
      __gm__ int32_t* v910 = PTOAS__GLOBAL_TENSOR_DATA(v101);
      // pto: %518
      ;
      const int64_t v911 = 1;
      // pto: %518
      ;
      const int64_t v912 = 1;
      // pto: %518
      ;
      const int64_t v913 = 1;
      // pto: %518
      ;
      int64_t v914 = v824 * v39;
      // pto: %518
      ;
      int64_t v915 = v913 * v914;
      // pto: %518
      ;
      pto::Shape<1, 1, 1, -1, 128> v916 = pto::Shape<1, 1, 1, -1, 128>(v911, v912, v913, v824, v34);
      // pto: %518
      ;
      pto::Stride<-1, -1, -1, -1, -1> v917 = pto::Stride<-1, -1, -1, -1, -1>(v912 * v915, v915, v914, v39, v27);
      // pto: %518
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v918 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v910 + (v909 + v827 * v39 + v908 * v27), v916, v917);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
      TSTORE(v918, v848);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
    };
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %520
  int64_t v919 = (int64_t) ((uint64_t) v119 + (uint64_t) v59);
  // pto: %521
  int64_t v920 = v919 < v43 ? v43 : v919;
  // pto: %signals_v2__ssa_v0_signal_pview
  __gm__ int32_t* v921 = PTOAS__GLOBAL_TENSOR_DATA(v111);
  // pto: %signals_v2__ssa_v0_signal_pview
  const int64_t v922 = 0;
  // pto: %signals_v2__ssa_v0_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v923 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals_v2__ssa_v0_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v924 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals_v2__ssa_v0_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v925 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v921 + (v922 + v920), v923, v924);
  pto::comm::NotifyOp v926 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v925, v128, v926);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void vector(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ bfloat16_t* v6, __gm__ int8_t* v7, __gm__ float* v8, __gm__ bfloat16_t* v9, __gm__ bfloat16_t* v10, __gm__ float* v11, __gm__ float* v12, __gm__ bfloat16_t* v13, __gm__ float* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21, int32_t v22) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int32_t v23 = 1;
  // pto: %c0_i64
  const int64_t v24 = 0;
  // pto: %c32768_i64
  const int64_t v25 = 32768;
  // pto: %c65536_i64
  const int64_t v26 = 65536;
  // pto: %c65568_i64
  const int64_t v27 = 65568;
  // pto: %c32_i64
  const int64_t v28 = 32;
  // pto: %c64_i64
  const int64_t v29 = 64;
  // pto: %c49152_i64
  const int64_t v30 = 49152;
  // pto: %c67584_i64
  const int64_t v31 = 67584;
  // pto: %c16384_i64
  const int64_t v32 = 16384;
  // pto: %c81920_i64
  const int64_t v33 = 81920;
  // pto: %c98304_i64
  const int64_t v34 = 98304;
  // pto: %c114688_i64
  const int64_t v35 = 114688;
  // pto: %c122880_i64
  const int64_t v36 = 122880;
  // pto: %c1_index
  const int64_t v37 = 1;
  // pto: %c8_index
  const int64_t v38 = 8;
  // pto: %c16_index
  const int64_t v39 = 16;
  // pto: %c128_index
  const int64_t v40 = 128;
  // pto: %c512_index
  const int64_t v41 = 512;
  // pto: %c4096_index
  const int64_t v42 = 4096;
  // pto: %c8192_index
  const int64_t v43 = 8192;
  // pto: %c16384_index
  const int64_t v44 = 16384;
  // pto: %c4_index
  const int64_t v45 = 4;
  // pto: %c55296_index
  const int64_t v46 = 55296;
  // pto: %c2_index
  const int64_t v47 = 2;
  // pto: %c24_index
  const int64_t v48 = 24;
  // pto: %c0_index
  const int64_t v49 = 0;
  // pto: %c15_index
  const int64_t v50 = 15;
  // pto: %c9216_index
  const int64_t v51 = 9216;
  // pto: %c48_index
  const int64_t v52 = 48;
  // pto: %c1024_index
  const int64_t v53 = 1024;
  // pto: %c18432_index
  const int64_t v54 = 18432;
  // pto: %c7_index
  const int64_t v55 = 7;
  // pto: %c21504_index
  const int64_t v56 = 21504;
  // pto: %cst_41
  const float v57 = 0.00787401571f;
  // pto: %cst_42
  const float v58 = 0.0f;
  // pto: %cst_43
  const float v59 = 1.0f;
  // pto: %cst_44
  const float v60 = 127.0f;
  // pto: %c27648_index
  const int64_t v61 = 27648;
  // pto: %c36864_index
  const int64_t v62 = 36864;
  // pto: %c46080_index
  const int64_t v63 = 46080;
  // pto: %c72_index
  const int64_t v64 = 72;
  // pto: %c3_index
  const int64_t v65 = 3;
  // pto: %c12_index
  const int64_t v66 = 12;
  // pto: %c5_index
  const int64_t v67 = 5;
  // pto: %c9_index
  const int64_t v68 = 9;
  // pto: %c13_index
  const int64_t v69 = 13;
  // pto: %c6_index
  const int64_t v70 = 6;
  // pto: %c10_index
  const int64_t v71 = 10;
  // pto: %c14_index
  const int64_t v72 = 14;
  // pto: %c11_index
  const int64_t v73 = 11;
  // pto: %c12288_index
  const int64_t v74 = 12288;
  // pto: %cn1_index
  const int64_t v75 = -1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v78 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v79 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v80 = v42 * v37;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v81 = v79 * v80;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v82 = v78 * v81;
  // pto: %wo_b_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v83 = pto::Shape<1, 1, 1, 1, -1>(v76, v77, v78, v79, v42);
  // pto: %wo_b_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v84 = pto::Stride<-1, -1, -1, -1, -1>(v77 * v82, v82, v81, v80, v37);
  // pto: %wo_b_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v85 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v83, v84);
  // pto: %projected__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %projected__ssa_v0_view
  const int64_t v87 = 1;
  // pto: %projected__ssa_v0_view
  const int64_t v88 = 1;
  // pto: %projected__ssa_v0_view
  int64_t v89 = (int64_t) v17;
  // pto: %projected__ssa_v0_view
  int64_t v90 = v89 * v43;
  // pto: %projected__ssa_v0_view
  int64_t v91 = v88 * v90;
  // pto: %projected__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v92 = pto::Shape<1, 1, 1, -1, -1>(v86, v87, v88, v89, v43);
  // pto: %projected__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v93 = pto::Stride<-1, -1, -1, -1, -1>(v87 * v91, v91, v90, v43, v37);
  // pto: %projected__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v94 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v92, v93);
  // pto: %quantized__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v96 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v97 = 1;
  // pto: %quantized__ssa_v0_view
  int64_t v98 = (int64_t) v17;
  // pto: %quantized__ssa_v0_view
  int64_t v99 = v98 * v43;
  // pto: %quantized__ssa_v0_view
  int64_t v100 = v97 * v99;
  // pto: %quantized__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v101 = pto::Shape<1, 1, 1, -1, -1>(v95, v96, v97, v98, v43);
  // pto: %quantized__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v102 = pto::Stride<-1, -1, -1, -1, -1>(v96 * v100, v100, v99, v43, v37);
  // pto: %quantized__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v103 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v101, v102);
  // pto: %token_scale__ssa_v0_view
  const int64_t v104 = 1;
  // pto: %token_scale__ssa_v0_view
  const int64_t v105 = 1;
  // pto: %token_scale__ssa_v0_view
  const int64_t v106 = 1;
  // pto: %token_scale__ssa_v0_view
  int64_t v107 = (int64_t) v17;
  // pto: %token_scale__ssa_v0_view
  int64_t v108 = v107 * v37;
  // pto: %token_scale__ssa_v0_view
  int64_t v109 = v106 * v108;
  // pto: %token_scale__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v110 = pto::Shape<1, 1, 1, -1, -1>(v104, v105, v106, v107, v37);
  // pto: %token_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v111 = pto::Stride<-1, -1, -1, -1, -1>(v105 * v109, v109, v108, v37, (int64_t) v17);
  // pto: %token_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v112 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v8, v110, v111);
  // pto: %attended__ssa_v0_view
  const int64_t v113 = 1;
  // pto: %attended__ssa_v0_view
  const int64_t v114 = 1;
  // pto: %attended__ssa_v0_view
  const int64_t v115 = 1;
  // pto: %attended__ssa_v0_view
  int64_t v116 = (int64_t) v17;
  // pto: %attended__ssa_v0_view
  int64_t v117 = v116 * v42;
  // pto: %attended__ssa_v0_view
  int64_t v118 = v115 * v117;
  // pto: %attended__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v119 = pto::Shape<1, 1, 1, -1, -1>(v113, v114, v115, v116, v42);
  // pto: %attended__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v120 = pto::Stride<-1, -1, -1, -1, -1>(v114 * v118, v118, v117, v42, v37);
  // pto: %attended__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v121 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v119, v120);
  // pto: %residual__ssa_v0_view
  const int64_t v122 = 1;
  // pto: %residual__ssa_v0_view
  const int64_t v123 = 1;
  // pto: %residual__ssa_v0_view
  const int64_t v124 = 1;
  // pto: %residual__ssa_v0_view
  int64_t v125 = (int64_t) v17;
  // pto: %residual__ssa_v0_view
  int64_t v126 = v125 * v44;
  // pto: %residual__ssa_v0_view
  int64_t v127 = v124 * v126;
  // pto: %residual__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v128 = pto::Shape<1, 1, 1, -1, -1>(v122, v123, v124, v125, v44);
  // pto: %residual__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v129 = pto::Stride<-1, -1, -1, -1, -1>(v123 * v127, v127, v126, v44, v37);
  // pto: %residual__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v130 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v10, v128, v129);
  // pto: %output__ssa_v0_view
  const int64_t v131 = 1;
  // pto: %output__ssa_v0_view
  const int64_t v132 = 1;
  // pto: %output__ssa_v0_view
  const int64_t v133 = 1;
  // pto: %output__ssa_v0_view
  int64_t v134 = (int64_t) v17;
  // pto: %output__ssa_v0_view
  int64_t v135 = v134 * v44;
  // pto: %output__ssa_v0_view
  int64_t v136 = v133 * v135;
  // pto: %output__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v137 = pto::Shape<1, 1, 1, -1, -1>(v131, v132, v133, v134, v44);
  // pto: %output__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v138 = pto::Stride<-1, -1, -1, -1, -1>(v132 * v136, v136, v135, v44, v37);
  // pto: %output__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v139 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v137, v138);
  // pto: %accum__ssa_v0_view
  const int64_t v140 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v141 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v142 = 1;
  // pto: %accum__ssa_v0_view
  int64_t v143 = (int64_t) v18;
  // pto: %accum__ssa_v0_view
  int64_t v144 = v143 * v43;
  // pto: %accum__ssa_v0_view
  int64_t v145 = v142 * v144;
  // pto: %accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v146 = pto::Shape<1, 1, 1, -1, -1>(v140, v141, v142, v143, v43);
  // pto: %accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v147 = pto::Stride<-1, -1, -1, -1, -1>(v141 * v145, v145, v144, v43, v37);
  // pto: %accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v148 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v146, v147);
  // pto: %integer_accum__ssa_v0_view
  const int64_t v149 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v150 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v151 = 1;
  // pto: %integer_accum__ssa_v0_view
  int64_t v152 = (int64_t) v19;
  // pto: %integer_accum__ssa_v0_view
  int64_t v153 = v152 * v42;
  // pto: %integer_accum__ssa_v0_view
  int64_t v154 = v151 * v153;
  // pto: %integer_accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v155 = pto::Shape<1, 1, 1, -1, -1>(v149, v150, v151, v152, v42);
  // pto: %integer_accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v156 = pto::Stride<-1, -1, -1, -1, -1>(v150 * v154, v154, v153, v42, v37);
  // pto: %integer_accum__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v157 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v155, v156);
  // pto: %signals__ssa_v0_view
  const int64_t v158 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v159 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v160 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v161 = 1;
  // pto: %signals__ssa_v0_view
  int64_t v162 = v46 * v37;
  // pto: %signals__ssa_v0_view
  int64_t v163 = v161 * v162;
  // pto: %signals__ssa_v0_view
  int64_t v164 = v160 * v163;
  // pto: %signals__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v165 = pto::Shape<1, 1, 1, 1, -1>(v158, v159, v160, v161, v46);
  // pto: %signals__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v166 = pto::Stride<-1, -1, -1, -1, -1>(v159 * v164, v164, v163, v162, v37);
  // pto: %signals__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v167 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v165, v166);
  // pto: %t__tmp_v0, %145, %146, %t__tmp_v1
  int64_t v168 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v20) * (uint64_t) v47) + (uint64_t) ((int64_t) v22));
  // pto: %147, %148
  int64_t v169 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v168 + (uint64_t) v48) * (uint64_t) v40);
  // pto: %149
  int64_t v170 = v169 < v49 ? v49 : v169;
  // pto: %signals__ssa_v0_pview
  __gm__ int32_t* v171 = PTOAS__GLOBAL_TENSOR_DATA(v167);
  // pto: %signals__ssa_v0_pview
  const int64_t v172 = 0;
  // pto: %signals__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 1> v173 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  pto::Stride<1, 1, 1, 1, 1> v174 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v175 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v171 + (v172 + v170), v173, v174);
  __gm__ int32_t* v176 = PTOAS__GLOBAL_TENSOR_DATA(v175);
  PTOAS__DCCI_SINGLE_CACHE_LINE(v176);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  // pto: %150
  int32_t v177 = (v16)[v169];
  // pto: %152
  int32_t v178 = (int32_t) ((uint32_t) v177 + (uint32_t) v23);
  pipe_barrier(PIPE_ALL);
  pto::comm::NotifyOp v179 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v175, v178, v179);
  // pto: %154, %155, %156
  int64_t v180 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v17 + (uint64_t) v50) / v39) * (uint64_t) v38);
  // pto: %157
  if (v168 < v180) {
    for (int64_t v181 = v49; v181 < v38; v181 += v37) {
      // pto: %158
      ;
      int64_t v182 = v168 % v38;
      // pto: %159, %160, %161
      ;
      int64_t v183 = v182 < v49 ? (int64_t) ((uint64_t) v182 + (uint64_t) v38) : v182;
      // pto: %162, %163, %164
      ;
      int64_t v184 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v183 * (uint64_t) v38) + (uint64_t) v181) % v48;
      // pto: %165, %166, %167
      ;
      int64_t v185 = v184 < v49 ? (int64_t) ((uint64_t) v184 + (uint64_t) v48) : v184;
      // pto: %168, %169
      ;
      int64_t v186 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v185 * (uint64_t) v40) + (uint64_t) v51);
      // pto: %170
      ;
      int64_t v187 = v186 < v49 ? v49 : v186;
      // pto: %signals__ssa_v1_signal_pview
      ;
      __gm__ int32_t* v188 = PTOAS__GLOBAL_TENSOR_DATA(v167);
      // pto: %signals__ssa_v1_signal_pview
      ;
      const int64_t v189 = 0;
      // pto: %signals__ssa_v1_signal_pview
      ;
      pto::Shape<1, 1, 1, 1, 1> v190 = pto::Shape<1, 1, 1, 1, 1>();
      // pto: %signals__ssa_v1_signal_pview
      ;
      pto::Stride<1, 1, 1, 1, 1> v191 = pto::Stride<1, 1, 1, 1, 1>();
      // pto: %signals__ssa_v1_signal_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v192 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v188 + (v189 + v187), v190, v191);
      pto::comm::WaitCmp v193 = pto::comm::WaitCmp::GE;
      pto::comm::TWAIT(v192, v178, v193);
    };
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
  }
  for (int64_t v194 = v168; v194 < v180; v194 += v52) {
    // pto: %172, %173
    ;
    int64_t v195 = (int64_t) ((uint64_t) (v194 / v38) * (uint64_t) v39);
    // pto: %174
    ;
    int64_t v196 = v194 % v38;
    // pto: %175, %176, %177
    ;
    int64_t v197 = v196 < v49 ? (int64_t) ((uint64_t) v196 + (uint64_t) v38) : v196;
    // pto: %178
    ;
    int64_t v198 = (int64_t) ((uint64_t) v197 * (uint64_t) v53);
    // pto: %179
    ;
    int64_t v199 = (int64_t) ((uint64_t) v17 - (uint64_t) v195);
    // pto: %180
    ;
    int64_t v200 = v199 < v39 ? v199 : v39;
    // pto: %oa_value__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v201 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v200, v53);
    // pto: %oa_value__ssa_v0
    ;
    uint64_t v202 = (uint64_t) v24;
    TASSIGN(v201, v202);
    // pto: %181
    ;
    int64_t v203 = v195 < v49 ? v49 : v195;
    // pto: %182
    ;
    int64_t v204 = v198 < v49 ? v49 : v198;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v205 = 0;
    // pto: %accum__ssa_v0_pview
    ;
    __gm__ float* v206 = PTOAS__GLOBAL_TENSOR_DATA(v148);
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v207 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v208 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v209 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    int64_t v210 = v200 * v43;
    // pto: %accum__ssa_v0_pview
    ;
    int64_t v211 = v209 * v210;
    // pto: %accum__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1024> v212 = pto::Shape<1, 1, 1, -1, 1024>(v207, v208, v209, v200, v53);
    // pto: %accum__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v213 = pto::Stride<-1, -1, -1, -1, -1>(v208 * v211, v211, v210, v43, v37);
    // pto: %accum__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v214 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v206 + (v205 + v203 * v43 + v204 * v37), v212, v213);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v201, v214);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %t__tmp_v3
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v200, v53);
    // pto: %t__tmp_v3
    ;
    uint64_t v216 = (uint64_t) v24;
    TASSIGN(v215, v216);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v217 = RoundMode::CAST_RINT;
    SaturationMode v218 = SaturationMode::ON;
    TCVT(v215, v201, v217, v218);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v219 = 0;
    // pto: %projected__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v220 = PTOAS__GLOBAL_TENSOR_DATA(v94);
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v221 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v222 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v223 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    int64_t v224 = v200 * v43;
    // pto: %projected__ssa_v0_pview
    ;
    int64_t v225 = v223 * v224;
    // pto: %projected__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1024> v226 = pto::Shape<1, 1, 1, -1, 1024>(v221, v222, v223, v200, v53);
    // pto: %projected__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v227 = pto::Stride<-1, -1, -1, -1, -1>(v222 * v225, v225, v224, v43, v37);
    // pto: %projected__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v228 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v220 + (v219 + v203 * v43 + v204 * v37), v226, v227);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v228, v215);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %186
  int64_t v229 = (int64_t) ((uint64_t) v169 + (uint64_t) v54);
  // pto: %187
  int64_t v230 = v229 < v49 ? v49 : v229;
  // pto: %188
  __gm__ int32_t* v231 = PTOAS__GLOBAL_TENSOR_DATA(v167);
  // pto: %188
  const int64_t v232 = 0;
  // pto: %188
  pto::Shape<1, 1, 1, 1, 1> v233 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %188
  pto::Stride<1, 1, 1, 1, 1> v234 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %188
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v235 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v231 + (v232 + v230), v233, v234);
  pto::comm::NotifyOp v236 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v235, v178, v236);
  // pto: %189, %190
  int64_t v237 = (int64_t) ((uint64_t) v17 + (uint64_t) v55) / v38;
  // pto: %191
  if (v168 < v237) {
    for (int64_t v238 = v49; v238 < v38; v238 += v37) {
      // pto: %192, %193, %194, %195
      ;
      int64_t v239 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) (v168 / v47) * (uint64_t) v38) + (uint64_t) v238) % v52;
      // pto: %196, %197, %198
      ;
      int64_t v240 = v239 < v49 ? (int64_t) ((uint64_t) v239 + (uint64_t) v52) : v239;
      // pto: %199, %200
      ;
      int64_t v241 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v240 * (uint64_t) v40) + (uint64_t) v56);
      // pto: %201
      ;
      int64_t v242 = v241 < v49 ? v49 : v241;
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      __gm__ int32_t* v243 = PTOAS__GLOBAL_TENSOR_DATA(v167);
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      const int64_t v244 = 0;
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      pto::Shape<1, 1, 1, 1, 1> v245 = pto::Shape<1, 1, 1, 1, 1>();
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      pto::Stride<1, 1, 1, 1, 1> v246 = pto::Stride<1, 1, 1, 1, 1>();
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v247 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v243 + (v244 + v242), v245, v246);
      pto::comm::WaitCmp v248 = pto::comm::WaitCmp::GE;
      pto::comm::TWAIT(v247, v178, v248);
    };
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  for (int64_t v249 = v168; v249 < v237; v249 += v52) {
    // pto: %203
    ;
    int64_t v250 = (int64_t) ((uint64_t) v249 * (uint64_t) v38);
    // pto: %204
    ;
    int64_t v251 = (int64_t) ((uint64_t) v17 - (uint64_t) v250);
    // pto: %205
    ;
    int64_t v252 = v251 < v38 ? v251 : v38;
    // pto: %first_quant__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v253 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
    // pto: %first_quant__ssa_v0
    ;
    uint64_t v254 = (uint64_t) v25;
    TASSIGN(v253, v254);
    // pto: %206
    ;
    int64_t v255 = v250 < v49 ? v49 : v250;
    // pto: %207
    ;
    const int64_t v256 = 0;
    // pto: %207
    ;
    __gm__ bfloat16_t* v257 = PTOAS__GLOBAL_TENSOR_DATA(v94);
    // pto: %207
    ;
    const int64_t v258 = 1;
    // pto: %207
    ;
    const int64_t v259 = 1;
    // pto: %207
    ;
    const int64_t v260 = 1;
    // pto: %207
    ;
    int64_t v261 = v252 * v43;
    // pto: %207
    ;
    int64_t v262 = v260 * v261;
    // pto: %207
    ;
    pto::Shape<1, 1, 1, -1, 1024> v263 = pto::Shape<1, 1, 1, -1, 1024>(v258, v259, v260, v252, v53);
    // pto: %207
    ;
    pto::Stride<-1, -1, -1, -1, -1> v264 = pto::Stride<-1, -1, -1, -1, -1>(v259 * v262, v262, v261, v43, v37);
    // pto: %207
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v265 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v257 + (v256 + v255 * v43 + v49 * v37), v263, v264);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v253, v265);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %t__tmp_v4
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v266 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
    // pto: %t__tmp_v4
    ;
    uint64_t v267 = (uint64_t) v24;
    TASSIGN(v266, v267);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    pipe_barrier(PIPE_V);
    RoundMode v268 = RoundMode::CAST_ROUND;
    SaturationMode v269 = SaturationMode::ON;
    TCVT(v266, v253, v268, v269);
    // pto: %first_abs__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v270 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
    // pto: %first_abs__ssa_v0
    ;
    uint64_t v271 = (uint64_t) v24;
    TASSIGN(v270, v271);
    pipe_barrier(PIPE_V);
    TABS(v270, v266);
    // pto: %t__tmp_v5
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v272 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v53);
    // pto: %t__tmp_v5
    ;
    uint64_t v273 = (uint64_t) v25;
    TASSIGN(v272, v273);
    // pto: %amax__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v274 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v37);
    // pto: %amax__ssa_v0
    ;
    uint64_t v275 = (uint64_t) v26;
    TASSIGN(v274, v275);
    pipe_barrier(PIPE_V);
    TROWMAX(v274, v270, v272);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    for (int64_t v276 = v37; v276 < v38; v276 += v37) {
      // pto: %q_bf16__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v277 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
      // pto: %q_bf16__ssa_v0
      ;
      uint64_t v278 = (uint64_t) v25;
      TASSIGN(v277, v278);
      // pto: %209
      ;
      int64_t v279 = (int64_t) ((uint64_t) v276 * (uint64_t) v53);
      // pto: %210
      ;
      int64_t v280 = v279 < v49 ? v49 : v279;
      // pto: %211
      ;
      const int64_t v281 = 0;
      // pto: %211
      ;
      __gm__ bfloat16_t* v282 = PTOAS__GLOBAL_TENSOR_DATA(v94);
      // pto: %211
      ;
      const int64_t v283 = 1;
      // pto: %211
      ;
      const int64_t v284 = 1;
      // pto: %211
      ;
      const int64_t v285 = 1;
      // pto: %211
      ;
      int64_t v286 = v252 * v43;
      // pto: %211
      ;
      int64_t v287 = v285 * v286;
      // pto: %211
      ;
      pto::Shape<1, 1, 1, -1, 1024> v288 = pto::Shape<1, 1, 1, -1, 1024>(v283, v284, v285, v252, v53);
      // pto: %211
      ;
      pto::Stride<-1, -1, -1, -1, -1> v289 = pto::Stride<-1, -1, -1, -1, -1>(v284 * v287, v287, v286, v43, v37);
      // pto: %211
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v290 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v282 + (v281 + v255 * v43 + v280 * v37), v288, v289);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      TLOAD(v277, v290);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %q_fp32__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v291 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
      // pto: %q_fp32__ssa_v0
      ;
      uint64_t v292 = (uint64_t) v24;
      TASSIGN(v291, v292);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      pipe_barrier(PIPE_V);
      RoundMode v293 = RoundMode::CAST_ROUND;
      SaturationMode v294 = SaturationMode::ON;
      TCVT(v291, v277, v293, v294);
      // pto: %t__tmp_v6
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v295 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
      // pto: %t__tmp_v6
      ;
      uint64_t v296 = (uint64_t) v24;
      TASSIGN(v295, v296);
      pipe_barrier(PIPE_V);
      TABS(v295, v291);
      // pto: %t__tmp_v7
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v297 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v53);
      // pto: %t__tmp_v7
      ;
      uint64_t v298 = (uint64_t) v25;
      TASSIGN(v297, v298);
      // pto: %t__tmp_v8
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v299 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v37);
      // pto: %t__tmp_v8
      ;
      uint64_t v300 = (uint64_t) v27;
      TASSIGN(v299, v300);
      pipe_barrier(PIPE_V);
      TROWMAX(v299, v295, v297);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      // pto: %amax__rm_a0_tmp_v0
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v301 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
      // pto: %amax__rm_a0_tmp_v0
      ;
      uint64_t v302 = (uint64_t) v26;
      TASSIGN(v301, v302);
      // pto: %amax__rm_a1_tmp_v1
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v303 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
      // pto: %amax__rm_a1_tmp_v1
      ;
      uint64_t v304 = (uint64_t) v27;
      TASSIGN(v303, v304);
      // pto: %amax__row_major_tmp_v2
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v305 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
      // pto: %amax__row_major_tmp_v2
      ;
      uint64_t v306 = (uint64_t) v24;
      TASSIGN(v305, v306);
      pipe_barrier(PIPE_V);
      TMAX(v305, v301, v303);
      // pto: %amax__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v307 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v37);
      // pto: %amax__ssa_v3
      ;
      uint64_t v308 = (uint64_t) v24;
      TASSIGN(v307, v308);
      // pto: %amax__ssa_v3_mv
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v37);
      // pto: %amax__ssa_v3_mv
      ;
      uint64_t v310 = (uint64_t) v26;
      TASSIGN(v309, v310);
      pipe_barrier(PIPE_V);
      TMOV(v309, v307);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    // pto: %dequant__rm_a0_tmp_v3
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v311 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
    // pto: %dequant__rm_a0_tmp_v3
    ;
    uint64_t v312 = (uint64_t) v26;
    TASSIGN(v311, v312);
    // pto: %dequant__row_major_tmp_v4
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
    // pto: %dequant__row_major_tmp_v4
    ;
    uint64_t v314 = (uint64_t) v24;
    TASSIGN(v313, v314);
    pipe_barrier(PIPE_V);
    TMULS(v313, v311, v57);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %dequant__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v37);
    // pto: %dequant__ssa_v0
    ;
    uint64_t v316 = (uint64_t) v24;
    TASSIGN(v315, v316);
    // pto: %denominator__rm_a0_tmp_v5
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v317 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
    // pto: %denominator__rm_a0_tmp_v5
    ;
    uint64_t v318 = (uint64_t) v26;
    TASSIGN(v317, v318);
    // pto: %denominator__row_major_tmp_v6
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v319 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
    // pto: %denominator__row_major_tmp_v6
    ;
    uint64_t v320 = (uint64_t) v28;
    TASSIGN(v319, v320);
    TADDS(v319, v317, v58);
    set_flag(PIPE_V, PIPE_S, EVENT_ID0);
    // pto: %denominator__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v321 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v37);
    // pto: %denominator__ssa_v0
    ;
    uint64_t v322 = (uint64_t) v28;
    TASSIGN(v321, v322);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
    for (int64_t v323 = v49; v323 < v252; v323 += v37) {
      // pto: %magnitude__ssa_v0
      ;
      float v324 = v321.GetValue(v323);
      // pto: %212
      ;
      bool v325 = v324 != v324 || v58 != v58;
      // pto: %212
      ;
      if ((v324 == v324 && v58 == v58) && v324 == v58) {
        v321.SetValue(v323, v59);
      };
    };
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
    // pto: %t__rm_a0_tmp_v7
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v326 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
    // pto: %t__rm_a0_tmp_v7
    ;
    uint64_t v327 = (uint64_t) v26;
    TASSIGN(v326, v327);
    // pto: %t__row_major_tmp_v8
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v328 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
    // pto: %t__row_major_tmp_v8
    ;
    uint64_t v329 = (uint64_t) v29;
    TASSIGN(v328, v329);
    TMULS(v328, v326, v58);
    // pto: %t__tmp_v9
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v330 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v37);
    // pto: %t__tmp_v9
    ;
    uint64_t v331 = (uint64_t) v29;
    TASSIGN(v330, v331);
    // pto: %t__rm_a0_tmp_v9
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v332 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
    // pto: %t__rm_a0_tmp_v9
    ;
    uint64_t v333 = (uint64_t) v29;
    TASSIGN(v332, v333);
    // pto: %t__row_major_tmp_v10
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v334 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
    // pto: %t__row_major_tmp_v10
    ;
    uint64_t v335 = (uint64_t) v29;
    TASSIGN(v334, v335);
    pipe_barrier(PIPE_V);
    TADDS(v334, v332, v60);
    // pto: %t__tmp_v10
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v336 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v37);
    // pto: %t__tmp_v10
    ;
    uint64_t v337 = (uint64_t) v29;
    TASSIGN(v336, v337);
    // pto: %multiplier__rm_a0_tmp_v11
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v338 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
    // pto: %multiplier__rm_a0_tmp_v11
    ;
    uint64_t v339 = (uint64_t) v29;
    TASSIGN(v338, v339);
    // pto: %multiplier__rm_a1_tmp_v12
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v340 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
    // pto: %multiplier__rm_a1_tmp_v12
    ;
    uint64_t v341 = (uint64_t) v28;
    TASSIGN(v340, v341);
    // pto: %multiplier__row_major_tmp_v13
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v342 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v252);
    // pto: %multiplier__row_major_tmp_v13
    ;
    uint64_t v343 = (uint64_t) v30;
    TASSIGN(v342, v343);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    TDIV(v342, v338, v340);
    // pto: %multiplier__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v344 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v37);
    // pto: %multiplier__ssa_v0
    ;
    uint64_t v345 = (uint64_t) v30;
    TASSIGN(v344, v345);
    v315.SetValidShape(v252, v37);
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v346 = (int64_t) v17;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v347 = 0;
    // pto: %token_scale__ssa_v0_pview
    ;
    __gm__ float* v348 = PTOAS__GLOBAL_TENSOR_DATA(v112);
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v349 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v350 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v351 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v352 = v252 * v37;
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v353 = v351 * v352;
    // pto: %token_scale__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1> v354 = pto::Shape<1, 1, 1, -1, 1>(v349, v350, v351, v252, v37);
    // pto: %token_scale__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v355 = pto::Stride<-1, -1, -1, -1, -1>(v350 * v353, v353, v352, v37, v346);
    // pto: %token_scale__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v356 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v348 + (v347 + v255 * v37 + v49 * v346), v354, v355);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    TSTORE(v356, v315);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    for (int64_t v357 = v49; v357 < v38; v357 += v37) {
      // pto: %217
      ;
      int64_t v358 = (int64_t) ((uint64_t) v357 * (uint64_t) v53);
      // pto: %quant_bf16__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v359 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
      // pto: %quant_bf16__ssa_v0
      ;
      uint64_t v360 = (uint64_t) v25;
      TASSIGN(v359, v360);
      // pto: %219
      ;
      int64_t v361 = v358 < v49 ? v49 : v358;
      // pto: %220
      ;
      const int64_t v362 = 0;
      // pto: %220
      ;
      __gm__ bfloat16_t* v363 = PTOAS__GLOBAL_TENSOR_DATA(v94);
      // pto: %220
      ;
      const int64_t v364 = 1;
      // pto: %220
      ;
      const int64_t v365 = 1;
      // pto: %220
      ;
      const int64_t v366 = 1;
      // pto: %220
      ;
      int64_t v367 = v252 * v43;
      // pto: %220
      ;
      int64_t v368 = v366 * v367;
      // pto: %220
      ;
      pto::Shape<1, 1, 1, -1, 1024> v369 = pto::Shape<1, 1, 1, -1, 1024>(v364, v365, v366, v252, v53);
      // pto: %220
      ;
      pto::Stride<-1, -1, -1, -1, -1> v370 = pto::Stride<-1, -1, -1, -1, -1>(v365 * v368, v368, v367, v43, v37);
      // pto: %220
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v371 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v363 + (v362 + v255 * v43 + v361 * v37), v369, v370);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      TLOAD(v359, v371);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %t__tmp_v12
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v372 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
      // pto: %t__tmp_v12
      ;
      uint64_t v373 = (uint64_t) v24;
      TASSIGN(v372, v373);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      RoundMode v374 = RoundMode::CAST_ROUND;
      SaturationMode v375 = SaturationMode::ON;
      TCVT(v372, v359, v374, v375);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      // pto: %quant_scaled__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v376 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
      // pto: %quant_scaled__ssa_v0
      ;
      uint64_t v377 = (uint64_t) v24;
      TASSIGN(v376, v377);
      pipe_barrier(PIPE_V);
      TROWEXPANDMUL(v376, v372, v344);
      // pto: %integer__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v378 = Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
      // pto: %integer__ssa_v0
      ;
      uint64_t v379 = (uint64_t) v24;
      TASSIGN(v378, v379);
      pipe_barrier(PIPE_V);
      RoundMode v380 = RoundMode::CAST_RINT;
      SaturationMode v381 = SaturationMode::ON;
      TCVT(v378, v376, v380, v381);
      // pto: %half__ssa_v0
      ;
      Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v382 = Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
      // pto: %half__ssa_v0
      ;
      uint64_t v383 = (uint64_t) v24;
      TASSIGN(v382, v383);
      pipe_barrier(PIPE_V);
      RoundMode v384 = RoundMode::CAST_ROUND;
      SaturationMode v385 = SaturationMode::ON;
      TCVT(v382, v378, v384, v385);
      // pto: %result__ssa_v0
      ;
      Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v386 = Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v252, v53);
      // pto: %result__ssa_v0
      ;
      uint64_t v387 = (uint64_t) v24;
      TASSIGN(v386, v387);
      pipe_barrier(PIPE_V);
      RoundMode v388 = RoundMode::CAST_TRUNC;
      SaturationMode v389 = SaturationMode::ON;
      TCVT(v386, v382, v388, v389);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      v386.SetValidShape(v252, v53);
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v390 = 0;
      // pto: %quantized__ssa_v0_pview
      ;
      __gm__ int8_t* v391 = PTOAS__GLOBAL_TENSOR_DATA(v103);
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v392 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v393 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v394 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      int64_t v395 = v252 * v43;
      // pto: %quantized__ssa_v0_pview
      ;
      int64_t v396 = v394 * v395;
      // pto: %quantized__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 1024> v397 = pto::Shape<1, 1, 1, -1, 1024>(v392, v393, v394, v252, v53);
      // pto: %quantized__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v398 = pto::Stride<-1, -1, -1, -1, -1>(v393 * v396, v396, v395, v43, v37);
      // pto: %quantized__ssa_v0_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v399 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v391 + (v390 + v255 * v43 + v361 * v37), v397, v398);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      TSTORE(v399, v386);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %224
  int64_t v400 = (int64_t) ((uint64_t) v169 + (uint64_t) v61);
  // pto: %225
  int64_t v401 = v400 < v49 ? v49 : v400;
  // pto: %226
  __gm__ int32_t* v402 = PTOAS__GLOBAL_TENSOR_DATA(v167);
  // pto: %226
  const int64_t v403 = 0;
  // pto: %226
  pto::Shape<1, 1, 1, 1, 1> v404 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %226
  pto::Stride<1, 1, 1, 1, 1> v405 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %226
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v406 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v402 + (v403 + v401), v404, v405);
  pto::comm::NotifyOp v407 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v406, v178, v407);
  for (int64_t v408 = v49; v408 < v48; v408 += v37) {
    // pto: %227, %228
    ;
    int64_t v409 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v408 * (uint64_t) v40) + (uint64_t) v62);
    // pto: %229
    ;
    int64_t v410 = v409 < v49 ? v49 : v409;
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v411 = PTOAS__GLOBAL_TENSOR_DATA(v167);
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    const int64_t v412 = 0;
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v413 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v414 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v415 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v411 + (v412 + v410), v413, v414);
    pto::comm::WaitCmp v416 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v415, v178, v416);
  }
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  for (int64_t v417 = v168; v417 < v180; v417 += v52) {
    // pto: %232, %233
    ;
    int64_t v418 = (int64_t) ((uint64_t) (v417 / v38) * (uint64_t) v39);
    // pto: %234
    ;
    int64_t v419 = v417 % v38;
    // pto: %235, %236, %237
    ;
    int64_t v420 = v419 < v49 ? (int64_t) ((uint64_t) v419 + (uint64_t) v38) : v419;
    // pto: %238
    ;
    int64_t v421 = (int64_t) ((uint64_t) v420 * (uint64_t) v41);
    // pto: %239
    ;
    int64_t v422 = (int64_t) ((uint64_t) v17 - (uint64_t) v418);
    // pto: %240
    ;
    int64_t v423 = v422 < v39 ? v422 : v39;
    // pto: %ob_integer__ssa_v0
    ;
    Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v424 = Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v423, v41);
    // pto: %ob_integer__ssa_v0
    ;
    uint64_t v425 = (uint64_t) v24;
    TASSIGN(v424, v425);
    // pto: %241
    ;
    int64_t v426 = v418 < v49 ? v49 : v418;
    // pto: %242
    ;
    int64_t v427 = v421 < v49 ? v49 : v421;
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v428 = 0;
    // pto: %integer_accum__ssa_v0_pview
    ;
    __gm__ int32_t* v429 = PTOAS__GLOBAL_TENSOR_DATA(v157);
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v430 = 1;
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v431 = 1;
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v432 = 1;
    // pto: %integer_accum__ssa_v0_pview
    ;
    int64_t v433 = v423 * v42;
    // pto: %integer_accum__ssa_v0_pview
    ;
    int64_t v434 = v432 * v433;
    // pto: %integer_accum__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v435 = pto::Shape<1, 1, 1, -1, 512>(v430, v431, v432, v423, v41);
    // pto: %integer_accum__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v436 = pto::Stride<-1, -1, -1, -1, -1>(v431 * v434, v434, v433, v42, v37);
    // pto: %integer_accum__ssa_v0_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v437 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v429 + (v428 + v426 * v42 + v427 * v37), v435, v436);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    TLOAD(v424, v437);
    // pto: %t__tmp_v14
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v438 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v41);
    // pto: %t__tmp_v14
    ;
    uint64_t v439 = (uint64_t) v26;
    TASSIGN(v438, v439);
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    __gm__ float* v440 = PTOAS__GLOBAL_TENSOR_DATA(v85);
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    const int64_t v441 = 0;
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 512> v442 = pto::Shape<1, 1, 1, 1, 512>();
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    pto::Stride<512, 512, 512, 512, 1> v443 = pto::Stride<512, 512, 512, 512, 1>();
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v444 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v440 + (v441 + v427), v442, v443);
    TLOAD(v438, v444);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    // pto: %channel__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v445 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v41);
    // pto: %channel__ssa_v0
    ;
    uint64_t v446 = (uint64_t) v26;
    TASSIGN(v445, v446);
    // pto: %scale__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v447 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v423, v37);
    // pto: %scale__ssa_v0
    ;
    uint64_t v448 = (uint64_t) v31;
    TASSIGN(v447, v448);
    // pto: %245
    ;
    int64_t v449 = (int64_t) v17;
    // pto: %245
    ;
    const int64_t v450 = 0;
    // pto: %245
    ;
    __gm__ float* v451 = PTOAS__GLOBAL_TENSOR_DATA(v112);
    // pto: %245
    ;
    const int64_t v452 = 1;
    // pto: %245
    ;
    const int64_t v453 = 1;
    // pto: %245
    ;
    const int64_t v454 = 1;
    // pto: %245
    ;
    int64_t v455 = v423 * v37;
    // pto: %245
    ;
    int64_t v456 = v454 * v455;
    // pto: %245
    ;
    pto::Shape<1, 1, 1, -1, 1> v457 = pto::Shape<1, 1, 1, -1, 1>(v452, v453, v454, v423, v37);
    // pto: %245
    ;
    pto::Stride<-1, -1, -1, -1, -1> v458 = pto::Stride<-1, -1, -1, -1, -1>(v453 * v456, v456, v455, v37, v449);
    // pto: %245
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v459 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v451 + (v450 + v426 * v37 + v49 * v449), v457, v458);
    TLOAD(v447, v459);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    // pto: %coefficient_one__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v460 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v39, v41);
    // pto: %coefficient_one__ssa_v0
    ;
    uint64_t v461 = (uint64_t) v25;
    TASSIGN(v460, v461);
    pipe_barrier(PIPE_V);
    TEXPANDS(v460, v59);
    // pto: %coefficient_channel__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v462 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v39, v41);
    // pto: %coefficient_channel__ssa_v0
    ;
    uint64_t v463 = (uint64_t) v25;
    TASSIGN(v462, v463);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    TCOLEXPANDMUL(v462, v460, v445);
    // pto: %coefficient__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v464 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v39, v41);
    // pto: %coefficient__ssa_v0
    ;
    uint64_t v465 = (uint64_t) v25;
    TASSIGN(v464, v465);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    TROWEXPANDMUL(v464, v462, v447);
    // pto: %t__tmp_v15
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v466 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v423, v41);
    // pto: %t__tmp_v15
    ;
    uint64_t v467 = (uint64_t) v24;
    TASSIGN(v466, v467);
    RoundMode v468 = RoundMode::CAST_ROUND;
    SaturationMode v469 = SaturationMode::ON;
    TCVT(v466, v424, v468, v469);
    // pto: %ob_scaled__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v470 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v423, v41);
    // pto: %ob_scaled__ssa_v0
    ;
    uint64_t v471 = (uint64_t) v24;
    TASSIGN(v470, v471);
    pipe_barrier(PIPE_V);
    TMUL(v470, v466, v464);
    // pto: %t__tmp_v16
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v472 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v423, v41);
    // pto: %t__tmp_v16
    ;
    uint64_t v473 = (uint64_t) v24;
    TASSIGN(v472, v473);
    pipe_barrier(PIPE_V);
    RoundMode v474 = RoundMode::CAST_RINT;
    SaturationMode v475 = SaturationMode::ON;
    TCVT(v472, v470, v474, v475);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v476 = 0;
    // pto: %attended__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v477 = PTOAS__GLOBAL_TENSOR_DATA(v121);
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v478 = 1;
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v479 = 1;
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v480 = 1;
    // pto: %attended__ssa_v0_pview
    ;
    int64_t v481 = v423 * v42;
    // pto: %attended__ssa_v0_pview
    ;
    int64_t v482 = v480 * v481;
    // pto: %attended__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v483 = pto::Shape<1, 1, 1, -1, 512>(v478, v479, v480, v423, v41);
    // pto: %attended__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v484 = pto::Stride<-1, -1, -1, -1, -1>(v479 * v482, v482, v481, v42, v37);
    // pto: %attended__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v485 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v477 + (v476 + v426 * v42 + v427 * v37), v483, v484);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    TSTORE(v485, v472);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %249
  int64_t v486 = (int64_t) ((uint64_t) v169 + (uint64_t) v63);
  // pto: %250
  int64_t v487 = v486 < v49 ? v49 : v486;
  // pto: %signals_v3__ssa_v0_signal_pview
  __gm__ int32_t* v488 = PTOAS__GLOBAL_TENSOR_DATA(v167);
  // pto: %signals_v3__ssa_v0_signal_pview
  const int64_t v489 = 0;
  // pto: %signals_v3__ssa_v0_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v490 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals_v3__ssa_v0_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v491 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals_v3__ssa_v0_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v492 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v488 + (v489 + v487), v490, v491);
  pto::comm::NotifyOp v493 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v492, v178, v493);
  for (int64_t v494 = v48; v494 < v64; v494 += v37) {
    // pto: %251, %252
    ;
    int64_t v495 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v494 * (uint64_t) v40) + (uint64_t) v63);
    // pto: %253
    ;
    int64_t v496 = v495 < v49 ? v49 : v495;
    // pto: %signals_v4__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v497 = PTOAS__GLOBAL_TENSOR_DATA(v167);
    // pto: %signals_v4__ssa_v0_signal_pview
    ;
    const int64_t v498 = 0;
    // pto: %signals_v4__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v499 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v4__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v500 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v4__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v501 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v497 + (v498 + v496), v499, v500);
    pto::comm::WaitCmp v502 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v501, v178, v502);
  }
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %254, %255
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  for (int64_t v503 = v168; v503 < ((int64_t) ((uint64_t) v17 + (uint64_t) v65) / v45); v503 += v52) {
    // pto: %256
    ;
    int64_t v504 = (int64_t) ((uint64_t) v503 * (uint64_t) v45);
    // pto: %257
    ;
    int64_t v505 = (int64_t) ((uint64_t) v504 + (uint64_t) v45);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    for (int64_t v506 = v504; v506 < v505; v506 += v47) {
      // pto: %258
      ;
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      if (v506 < v17) {
        // pto: %259
        ;
        int64_t v507 = (int64_t) ((uint64_t) v506 * (uint64_t) v45);
        // pto: %post_scalar__tile
        ;
        float v508 = (v11)[v507];
        // pto: %261
        ;
        int64_t v509 = (int64_t) ((uint64_t) v506 * (uint64_t) v39);
        // pto: %comb_scalar_0__tile
        ;
        float v510 = (v12)[v509];
        // pto: %264, %comb_scalar_1__tile
        ;
        float v511 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v45)];
        // pto: %266, %comb_scalar_2__tile
        ;
        float v512 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v38)];
        // pto: %268, %comb_scalar_3__tile
        ;
        float v513 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v66)];
        // pto: %271, %269
        ;
        float v514 = (v11)[(int64_t) ((uint64_t) v507 + (uint64_t) v37)];
        // pto: %274, %272
        ;
        float v515 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v37)];
        // pto: %277, %275
        ;
        float v516 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v67)];
        // pto: %280, %278
        ;
        float v517 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v68)];
        // pto: %283, %281
        ;
        float v518 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v69)];
        // pto: %286, %284
        ;
        float v519 = (v11)[(int64_t) ((uint64_t) v507 + (uint64_t) v47)];
        // pto: %289, %287
        ;
        float v520 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v47)];
        // pto: %292, %290
        ;
        float v521 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v70)];
        // pto: %295, %293
        ;
        float v522 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v71)];
        // pto: %298, %296
        ;
        float v523 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v72)];
        // pto: %301, %299
        ;
        float v524 = (v11)[(int64_t) ((uint64_t) v507 + (uint64_t) v65)];
        // pto: %304, %302
        ;
        float v525 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v65)];
        // pto: %307, %305
        ;
        float v526 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v55)];
        // pto: %310, %308
        ;
        float v527 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v73)];
        // pto: %313, %311
        ;
        float v528 = (v12)[(int64_t) ((uint64_t) v509 + (uint64_t) v50)];
        // pto: %x_block__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v529 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %x_block__tile
        ;
        uint64_t v530 = (uint64_t) v32;
        TASSIGN(v529, v530);
        // pto: %314
        ;
        int64_t v531 = v506 < v49 ? v49 : v506;
        // pto: %x__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v532 = PTOAS__GLOBAL_TENSOR_DATA(v121);
        // pto: %x__ssa_v0_pview
        ;
        const int64_t v533 = 0;
        // pto: %x__ssa_v0_pview
        ;
        const int64_t v534 = 4096;
        // pto: %x__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v535 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %x__ssa_v0_pview
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v536 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %x__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v537 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v532 + (v533 + v531 * v534), v535, v536);
        TLOAD(v529, v537);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        // pto: %315
        ;
        int64_t v538 = (int64_t) ((uint64_t) v17 - (uint64_t) v506);
        // pto: %316
        ;
        int64_t v539 = v538 < v49 ? v49 : v538;
        // pto: %317
        ;
        int64_t v540 = v539 < v37 ? v539 : v37;
        // pto: %t__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v541 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %t__tile
        ;
        uint64_t v542 = (uint64_t) v25;
        TASSIGN(v541, v542);
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v543 = 0;
        // pto: %residual_flat__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v544 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v545 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v546 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v547 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        int64_t v548 = v540 * v44;
        // pto: %residual_flat__ssa_v0_pview
        ;
        int64_t v549 = v547 * v548;
        // pto: %residual_flat__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 4096> v550 = pto::Shape<1, 1, 1, -1, 4096>(v545, v546, v547, v540, v42);
        // pto: %residual_flat__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v551 = pto::Stride<-1, -1, -1, -1, -1>(v546 * v549, v549, v548, v44, v37);
        // pto: %residual_flat__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v552 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v544 + (v543 + v531 * v44 + v49 * v37), v550, v551);
        TLOAD(v541, v552);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        // pto: %0
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v553 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %0
        ;
        uint64_t v554 = (uint64_t) v30;
        TASSIGN(v553, v554);
        // pto: %329
        ;
        const int64_t v555 = 0;
        // pto: %329
        ;
        __gm__ bfloat16_t* v556 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %329
        ;
        const int64_t v557 = 1;
        // pto: %329
        ;
        const int64_t v558 = 1;
        // pto: %329
        ;
        const int64_t v559 = 1;
        // pto: %329
        ;
        int64_t v560 = v540 * v44;
        // pto: %329
        ;
        int64_t v561 = v559 * v560;
        // pto: %329
        ;
        pto::Shape<1, 1, 1, -1, 4096> v562 = pto::Shape<1, 1, 1, -1, 4096>(v557, v558, v559, v540, v42);
        // pto: %329
        ;
        pto::Stride<-1, -1, -1, -1, -1> v563 = pto::Stride<-1, -1, -1, -1, -1>(v558 * v561, v561, v560, v44, v37);
        // pto: %329
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v564 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v556 + (v555 + v531 * v44 + v42 * v37), v562, v563);
        TLOAD(v553, v564);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %1
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v565 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %1
        ;
        uint64_t v566 = (uint64_t) v26;
        TASSIGN(v565, v566);
        // pto: %337
        ;
        const int64_t v567 = 0;
        // pto: %337
        ;
        __gm__ bfloat16_t* v568 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %337
        ;
        const int64_t v569 = 1;
        // pto: %337
        ;
        const int64_t v570 = 1;
        // pto: %337
        ;
        const int64_t v571 = 1;
        // pto: %337
        ;
        int64_t v572 = v540 * v44;
        // pto: %337
        ;
        int64_t v573 = v571 * v572;
        // pto: %337
        ;
        pto::Shape<1, 1, 1, -1, 4096> v574 = pto::Shape<1, 1, 1, -1, 4096>(v569, v570, v571, v540, v42);
        // pto: %337
        ;
        pto::Stride<-1, -1, -1, -1, -1> v575 = pto::Stride<-1, -1, -1, -1, -1>(v570 * v573, v573, v572, v44, v37);
        // pto: %337
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v576 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v568 + (v567 + v531 * v44 + v43 * v37), v574, v575);
        TLOAD(v565, v576);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %2
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v577 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %2
        ;
        uint64_t v578 = (uint64_t) v33;
        TASSIGN(v577, v578);
        // pto: %345
        ;
        const int64_t v579 = 0;
        // pto: %345
        ;
        __gm__ bfloat16_t* v580 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %345
        ;
        const int64_t v581 = 1;
        // pto: %345
        ;
        const int64_t v582 = 1;
        // pto: %345
        ;
        const int64_t v583 = 1;
        // pto: %345
        ;
        int64_t v584 = v540 * v44;
        // pto: %345
        ;
        int64_t v585 = v583 * v584;
        // pto: %345
        ;
        pto::Shape<1, 1, 1, -1, 4096> v586 = pto::Shape<1, 1, 1, -1, 4096>(v581, v582, v583, v540, v42);
        // pto: %345
        ;
        pto::Stride<-1, -1, -1, -1, -1> v587 = pto::Stride<-1, -1, -1, -1, -1>(v582 * v585, v585, v584, v44, v37);
        // pto: %345
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v588 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v580 + (v579 + v531 * v44 + v74 * v37), v586, v587);
        TLOAD(v577, v588);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %x_f32__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v589 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %x_f32__tile
        ;
        uint64_t v590 = (uint64_t) v24;
        TASSIGN(v589, v590);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        RoundMode v591 = RoundMode::CAST_ROUND;
        SaturationMode v592 = SaturationMode::ON;
        TCVT(v589, v529, v591, v592);
        // pto: %res_0__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v593 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %res_0__tile
        ;
        uint64_t v594 = (uint64_t) v32;
        TASSIGN(v593, v594);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        RoundMode v595 = RoundMode::CAST_ROUND;
        SaturationMode v596 = SaturationMode::ON;
        TCVT(v593, v541, v595, v596);
        // pto: %res_1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v597 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %res_1__tile
        ;
        uint64_t v598 = (uint64_t) v25;
        TASSIGN(v597, v598);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v599 = RoundMode::CAST_ROUND;
        SaturationMode v600 = SaturationMode::ON;
        TCVT(v597, v553, v599, v600);
        // pto: %res_2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v601 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %res_2__tile
        ;
        uint64_t v602 = (uint64_t) v30;
        TASSIGN(v601, v602);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        RoundMode v603 = RoundMode::CAST_ROUND;
        SaturationMode v604 = SaturationMode::ON;
        TCVT(v601, v565, v603, v604);
        // pto: %res_3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v605 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %res_3__tile
        ;
        uint64_t v606 = (uint64_t) v26;
        TASSIGN(v605, v606);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v607 = RoundMode::CAST_ROUND;
        SaturationMode v608 = SaturationMode::ON;
        TCVT(v605, v577, v607, v608);
        // pto: %single_y__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v609 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_y__tile
        ;
        uint64_t v610 = (uint64_t) v33;
        TASSIGN(v609, v610);
        pipe_barrier(PIPE_V);
        TMULS(v609, v589, v508);
        // pto: %single_weighted_0__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v611 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %single_weighted_0__tile
        ;
        uint64_t v612 = (uint64_t) v34;
        TASSIGN(v611, v612);
        TMULS(v611, v593, v510);
        // pto: %single_y_v1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v613 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_y_v1__tile
        ;
        uint64_t v614 = (uint64_t) v33;
        TASSIGN(v613, v614);
        pipe_barrier(PIPE_V);
        TADD(v613, v609, v611);
        // pto: %single_weighted_1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v615 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %single_weighted_1__tile
        ;
        uint64_t v616 = (uint64_t) v34;
        TASSIGN(v615, v616);
        pipe_barrier(PIPE_V);
        TMULS(v615, v597, v511);
        // pto: %single_y_v2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v617 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_y_v2__tile
        ;
        uint64_t v618 = (uint64_t) v33;
        TASSIGN(v617, v618);
        pipe_barrier(PIPE_V);
        TADD(v617, v613, v615);
        // pto: %single_weighted_2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v619 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %single_weighted_2__tile
        ;
        uint64_t v620 = (uint64_t) v34;
        TASSIGN(v619, v620);
        pipe_barrier(PIPE_V);
        TMULS(v619, v601, v512);
        // pto: %single_y_v3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v621 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_y_v3__tile
        ;
        uint64_t v622 = (uint64_t) v33;
        TASSIGN(v621, v622);
        pipe_barrier(PIPE_V);
        TADD(v621, v617, v619);
        // pto: %single_weighted_3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v623 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %single_weighted_3__tile
        ;
        uint64_t v624 = (uint64_t) v34;
        TASSIGN(v623, v624);
        pipe_barrier(PIPE_V);
        TMULS(v623, v605, v513);
        // pto: %single_y_v4__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v625 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_y_v4__tile
        ;
        uint64_t v626 = (uint64_t) v33;
        TASSIGN(v625, v626);
        pipe_barrier(PIPE_V);
        TADD(v625, v621, v623);
        // pto: %single_result__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v627 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %single_result__tile
        ;
        uint64_t v628 = (uint64_t) v35;
        TASSIGN(v627, v628);
        pipe_barrier(PIPE_V);
        RoundMode v629 = RoundMode::CAST_RINT;
        SaturationMode v630 = SaturationMode::ON;
        TCVT(v627, v625, v629, v630);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        v627.SetValidShape(v37, v42);
        // pto: %4
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v631 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %4
        ;
        uint64_t v632 = (uint64_t) v33;
        TASSIGN(v631, v632);
        pipe_barrier(PIPE_V);
        TMULS(v631, v589, v514);
        // pto: %5
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v633 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %5
        ;
        uint64_t v634 = (uint64_t) v34;
        TASSIGN(v633, v634);
        TMULS(v633, v593, v515);
        // pto: %6
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v635 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %6
        ;
        uint64_t v636 = (uint64_t) v33;
        TASSIGN(v635, v636);
        pipe_barrier(PIPE_V);
        TADD(v635, v631, v633);
        // pto: %7
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v637 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %7
        ;
        uint64_t v638 = (uint64_t) v34;
        TASSIGN(v637, v638);
        pipe_barrier(PIPE_V);
        TMULS(v637, v597, v516);
        // pto: %8
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v639 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %8
        ;
        uint64_t v640 = (uint64_t) v33;
        TASSIGN(v639, v640);
        pipe_barrier(PIPE_V);
        TADD(v639, v635, v637);
        // pto: %9
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v641 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %9
        ;
        uint64_t v642 = (uint64_t) v34;
        TASSIGN(v641, v642);
        pipe_barrier(PIPE_V);
        TMULS(v641, v601, v517);
        // pto: %10
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v643 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %10
        ;
        uint64_t v644 = (uint64_t) v33;
        TASSIGN(v643, v644);
        pipe_barrier(PIPE_V);
        TADD(v643, v639, v641);
        // pto: %11
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v645 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %11
        ;
        uint64_t v646 = (uint64_t) v34;
        TASSIGN(v645, v646);
        pipe_barrier(PIPE_V);
        TMULS(v645, v605, v518);
        // pto: %12
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v647 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %12
        ;
        uint64_t v648 = (uint64_t) v33;
        TASSIGN(v647, v648);
        pipe_barrier(PIPE_V);
        TADD(v647, v643, v645);
        // pto: %13
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v649 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %13
        ;
        uint64_t v650 = (uint64_t) v36;
        TASSIGN(v649, v650);
        pipe_barrier(PIPE_V);
        RoundMode v651 = RoundMode::CAST_RINT;
        SaturationMode v652 = SaturationMode::ON;
        TCVT(v649, v647, v651, v652);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        v649.SetValidShape(v37, v42);
        // pto: %15
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v653 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %15
        ;
        uint64_t v654 = (uint64_t) v33;
        TASSIGN(v653, v654);
        pipe_barrier(PIPE_V);
        TMULS(v653, v589, v519);
        // pto: %16
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v655 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %16
        ;
        uint64_t v656 = (uint64_t) v34;
        TASSIGN(v655, v656);
        TMULS(v655, v593, v520);
        // pto: %17
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v657 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %17
        ;
        uint64_t v658 = (uint64_t) v33;
        TASSIGN(v657, v658);
        pipe_barrier(PIPE_V);
        TADD(v657, v653, v655);
        // pto: %18
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v659 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %18
        ;
        uint64_t v660 = (uint64_t) v34;
        TASSIGN(v659, v660);
        pipe_barrier(PIPE_V);
        TMULS(v659, v597, v521);
        // pto: %19
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v661 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %19
        ;
        uint64_t v662 = (uint64_t) v33;
        TASSIGN(v661, v662);
        pipe_barrier(PIPE_V);
        TADD(v661, v657, v659);
        // pto: %20
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v663 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %20
        ;
        uint64_t v664 = (uint64_t) v34;
        TASSIGN(v663, v664);
        pipe_barrier(PIPE_V);
        TMULS(v663, v601, v522);
        // pto: %21
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v665 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %21
        ;
        uint64_t v666 = (uint64_t) v33;
        TASSIGN(v665, v666);
        pipe_barrier(PIPE_V);
        TADD(v665, v661, v663);
        // pto: %22
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v667 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %22
        ;
        uint64_t v668 = (uint64_t) v34;
        TASSIGN(v667, v668);
        pipe_barrier(PIPE_V);
        TMULS(v667, v605, v523);
        // pto: %23
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v669 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %23
        ;
        uint64_t v670 = (uint64_t) v33;
        TASSIGN(v669, v670);
        pipe_barrier(PIPE_V);
        TADD(v669, v665, v667);
        // pto: %24
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v671 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %24
        ;
        uint64_t v672 = (uint64_t) v33;
        TASSIGN(v671, v672);
        pipe_barrier(PIPE_V);
        RoundMode v673 = RoundMode::CAST_RINT;
        SaturationMode v674 = SaturationMode::ON;
        TCVT(v671, v669, v673, v674);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        v671.SetValidShape(v37, v42);
        // pto: %26
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v675 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %26
        ;
        uint64_t v676 = (uint64_t) v24;
        TASSIGN(v675, v676);
        TMULS(v675, v589, v524);
        // pto: %27
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v677 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %27
        ;
        uint64_t v678 = (uint64_t) v32;
        TASSIGN(v677, v678);
        TMULS(v677, v593, v525);
        // pto: %28
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v679 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %28
        ;
        uint64_t v680 = (uint64_t) v24;
        TASSIGN(v679, v680);
        pipe_barrier(PIPE_V);
        TADD(v679, v675, v677);
        // pto: %29
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v681 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %29
        ;
        uint64_t v682 = (uint64_t) v32;
        TASSIGN(v681, v682);
        pipe_barrier(PIPE_V);
        TMULS(v681, v597, v526);
        // pto: %30
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v683 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %30
        ;
        uint64_t v684 = (uint64_t) v24;
        TASSIGN(v683, v684);
        pipe_barrier(PIPE_V);
        TADD(v683, v679, v681);
        // pto: %31
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v685 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %31
        ;
        uint64_t v686 = (uint64_t) v32;
        TASSIGN(v685, v686);
        pipe_barrier(PIPE_V);
        TMULS(v685, v601, v527);
        // pto: %32
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v687 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %32
        ;
        uint64_t v688 = (uint64_t) v24;
        TASSIGN(v687, v688);
        pipe_barrier(PIPE_V);
        TADD(v687, v683, v685);
        // pto: %33
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v689 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v540, v42);
        // pto: %33
        ;
        uint64_t v690 = (uint64_t) v32;
        TASSIGN(v689, v690);
        pipe_barrier(PIPE_V);
        TMULS(v689, v605, v528);
        // pto: %34
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v691 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %34
        ;
        uint64_t v692 = (uint64_t) v24;
        TASSIGN(v691, v692);
        pipe_barrier(PIPE_V);
        TADD(v691, v687, v689);
        // pto: %35
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v693 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %35
        ;
        uint64_t v694 = (uint64_t) v24;
        TASSIGN(v693, v694);
        pipe_barrier(PIPE_V);
        RoundMode v695 = RoundMode::CAST_RINT;
        SaturationMode v696 = SaturationMode::ON;
        TCVT(v693, v691, v695, v696);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        v693.SetValidShape(v37, v42);
        // pto: %y_flat__iter_v3_pview
        ;
        __gm__ bfloat16_t* v697 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %y_flat__iter_v3_pview
        ;
        const int64_t v698 = 0;
        // pto: %y_flat__iter_v3_pview
        ;
        const int64_t v699 = 16384;
        // pto: %y_flat__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v700 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__iter_v3_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v701 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v702 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v697 + (v698 + v531 * v699), v700, v701);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        TSTORE(v702, v627);
        // pto: %y_flat__tile_pview
        ;
        __gm__ bfloat16_t* v703 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %y_flat__tile_pview
        ;
        const int64_t v704 = 4096;
        // pto: %y_flat__tile_pview
        ;
        const int64_t v705 = 16384;
        // pto: %y_flat__tile_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v706 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__tile_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v707 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__tile_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v708 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v703 + (v704 + v531 * v705), v706, v707);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        TSTORE(v708, v649);
        // pto: %411
        ;
        __gm__ bfloat16_t* v709 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %411
        ;
        const int64_t v710 = 8192;
        // pto: %411
        ;
        const int64_t v711 = 16384;
        // pto: %411
        ;
        pto::Shape<1, 1, 1, 1, 4096> v712 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %411
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v713 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %411
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v714 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v709 + (v710 + v531 * v711), v712, v713);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        TSTORE(v714, v671);
        // pto: %414
        ;
        __gm__ bfloat16_t* v715 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %414
        ;
        const int64_t v716 = 12288;
        // pto: %414
        ;
        const int64_t v717 = 16384;
        // pto: %414
        ;
        pto::Shape<1, 1, 1, 1, 4096> v718 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %414
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v719 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %414
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v720 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v715 + (v716 + v531 * v717), v718, v719);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        TSTORE(v720, v693);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      // pto: %415
      ;
      int64_t v721 = (int64_t) ((uint64_t) v506 + (uint64_t) v37);
      // pto: %416
      ;
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      if (v721 < v17) {
        // pto: %419
        ;
        int64_t v722 = (int64_t) ((uint64_t) v721 * (uint64_t) v45);
        // pto: %417
        ;
        float v723 = (v11)[v722];
        // pto: %423
        ;
        int64_t v724 = (int64_t) ((uint64_t) v721 * (uint64_t) v39);
        // pto: %421
        ;
        float v725 = (v12)[v724];
        // pto: %428, %425
        ;
        float v726 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v45)];
        // pto: %432, %429
        ;
        float v727 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v38)];
        // pto: %436, %433
        ;
        float v728 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v66)];
        // pto: %440, %437
        ;
        float v729 = (v11)[(int64_t) ((uint64_t) v722 + (uint64_t) v37)];
        // pto: %444, %441
        ;
        float v730 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v37)];
        // pto: %448, %445
        ;
        float v731 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v67)];
        // pto: %452, %449
        ;
        float v732 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v68)];
        // pto: %456, %453
        ;
        float v733 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v69)];
        // pto: %460, %457
        ;
        float v734 = (v11)[(int64_t) ((uint64_t) v722 + (uint64_t) v47)];
        // pto: %464, %461
        ;
        float v735 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v47)];
        // pto: %468, %465
        ;
        float v736 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v70)];
        // pto: %472, %469
        ;
        float v737 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v71)];
        // pto: %476, %473
        ;
        float v738 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v72)];
        // pto: %480, %477
        ;
        float v739 = (v11)[(int64_t) ((uint64_t) v722 + (uint64_t) v65)];
        // pto: %484, %481
        ;
        float v740 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v65)];
        // pto: %488, %485
        ;
        float v741 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v55)];
        // pto: %492, %489
        ;
        float v742 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v73)];
        // pto: %496, %493
        ;
        float v743 = (v12)[(int64_t) ((uint64_t) v724 + (uint64_t) v50)];
        // pto: %37
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v744 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %37
        ;
        uint64_t v745 = (uint64_t) v32;
        TASSIGN(v744, v745);
        // pto: %498
        ;
        int64_t v746 = v721 < v49 ? v49 : v721;
        // pto: %499
        ;
        __gm__ bfloat16_t* v747 = PTOAS__GLOBAL_TENSOR_DATA(v121);
        // pto: %499
        ;
        const int64_t v748 = 0;
        // pto: %499
        ;
        const int64_t v749 = 4096;
        // pto: %499
        ;
        pto::Shape<1, 1, 1, 1, 4096> v750 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %499
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v751 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %499
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v752 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v747 + (v748 + v746 * v749), v750, v751);
        TLOAD(v744, v752);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %500, %501
        ;
        int64_t v753 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v17 - (uint64_t) v506) + (uint64_t) v75);
        // pto: %502
        ;
        int64_t v754 = v753 < v49 ? v49 : v753;
        // pto: %503
        ;
        int64_t v755 = v754 < v37 ? v754 : v37;
        // pto: %38
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v756 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %38
        ;
        uint64_t v757 = (uint64_t) v25;
        TASSIGN(v756, v757);
        // pto: %510
        ;
        const int64_t v758 = 0;
        // pto: %510
        ;
        __gm__ bfloat16_t* v759 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %510
        ;
        const int64_t v760 = 1;
        // pto: %510
        ;
        const int64_t v761 = 1;
        // pto: %510
        ;
        const int64_t v762 = 1;
        // pto: %510
        ;
        int64_t v763 = v755 * v44;
        // pto: %510
        ;
        int64_t v764 = v762 * v763;
        // pto: %510
        ;
        pto::Shape<1, 1, 1, -1, 4096> v765 = pto::Shape<1, 1, 1, -1, 4096>(v760, v761, v762, v755, v42);
        // pto: %510
        ;
        pto::Stride<-1, -1, -1, -1, -1> v766 = pto::Stride<-1, -1, -1, -1, -1>(v761 * v764, v764, v763, v44, v37);
        // pto: %510
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v767 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v759 + (v758 + v746 * v44 + v49 * v37), v765, v766);
        TLOAD(v756, v767);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %39
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v768 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %39
        ;
        uint64_t v769 = (uint64_t) v30;
        TASSIGN(v768, v769);
        // pto: %521
        ;
        const int64_t v770 = 0;
        // pto: %521
        ;
        __gm__ bfloat16_t* v771 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %521
        ;
        const int64_t v772 = 1;
        // pto: %521
        ;
        const int64_t v773 = 1;
        // pto: %521
        ;
        const int64_t v774 = 1;
        // pto: %521
        ;
        int64_t v775 = v755 * v44;
        // pto: %521
        ;
        int64_t v776 = v774 * v775;
        // pto: %521
        ;
        pto::Shape<1, 1, 1, -1, 4096> v777 = pto::Shape<1, 1, 1, -1, 4096>(v772, v773, v774, v755, v42);
        // pto: %521
        ;
        pto::Stride<-1, -1, -1, -1, -1> v778 = pto::Stride<-1, -1, -1, -1, -1>(v773 * v776, v776, v775, v44, v37);
        // pto: %521
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v779 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v771 + (v770 + v746 * v44 + v42 * v37), v777, v778);
        TLOAD(v768, v779);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %40
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v780 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %40
        ;
        uint64_t v781 = (uint64_t) v26;
        TASSIGN(v780, v781);
        // pto: %532
        ;
        const int64_t v782 = 0;
        // pto: %532
        ;
        __gm__ bfloat16_t* v783 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %532
        ;
        const int64_t v784 = 1;
        // pto: %532
        ;
        const int64_t v785 = 1;
        // pto: %532
        ;
        const int64_t v786 = 1;
        // pto: %532
        ;
        int64_t v787 = v755 * v44;
        // pto: %532
        ;
        int64_t v788 = v786 * v787;
        // pto: %532
        ;
        pto::Shape<1, 1, 1, -1, 4096> v789 = pto::Shape<1, 1, 1, -1, 4096>(v784, v785, v786, v755, v42);
        // pto: %532
        ;
        pto::Stride<-1, -1, -1, -1, -1> v790 = pto::Stride<-1, -1, -1, -1, -1>(v785 * v788, v788, v787, v44, v37);
        // pto: %532
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v791 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v783 + (v782 + v746 * v44 + v43 * v37), v789, v790);
        TLOAD(v780, v791);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        // pto: %41
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v792 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %41
        ;
        uint64_t v793 = (uint64_t) v33;
        TASSIGN(v792, v793);
        // pto: %543
        ;
        const int64_t v794 = 0;
        // pto: %543
        ;
        __gm__ bfloat16_t* v795 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %543
        ;
        const int64_t v796 = 1;
        // pto: %543
        ;
        const int64_t v797 = 1;
        // pto: %543
        ;
        const int64_t v798 = 1;
        // pto: %543
        ;
        int64_t v799 = v755 * v44;
        // pto: %543
        ;
        int64_t v800 = v798 * v799;
        // pto: %543
        ;
        pto::Shape<1, 1, 1, -1, 4096> v801 = pto::Shape<1, 1, 1, -1, 4096>(v796, v797, v798, v755, v42);
        // pto: %543
        ;
        pto::Stride<-1, -1, -1, -1, -1> v802 = pto::Stride<-1, -1, -1, -1, -1>(v797 * v800, v800, v799, v44, v37);
        // pto: %543
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v803 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v795 + (v794 + v746 * v44 + v74 * v37), v801, v802);
        TLOAD(v792, v803);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        // pto: %42
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v804 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %42
        ;
        uint64_t v805 = (uint64_t) v24;
        TASSIGN(v804, v805);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v806 = RoundMode::CAST_ROUND;
        SaturationMode v807 = SaturationMode::ON;
        TCVT(v804, v744, v806, v807);
        // pto: %43
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v808 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %43
        ;
        uint64_t v809 = (uint64_t) v32;
        TASSIGN(v808, v809);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        RoundMode v810 = RoundMode::CAST_ROUND;
        SaturationMode v811 = SaturationMode::ON;
        TCVT(v808, v756, v810, v811);
        // pto: %44
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v812 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %44
        ;
        uint64_t v813 = (uint64_t) v25;
        TASSIGN(v812, v813);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v814 = RoundMode::CAST_ROUND;
        SaturationMode v815 = SaturationMode::ON;
        TCVT(v812, v768, v814, v815);
        // pto: %45
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v816 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %45
        ;
        uint64_t v817 = (uint64_t) v30;
        TASSIGN(v816, v817);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        RoundMode v818 = RoundMode::CAST_ROUND;
        SaturationMode v819 = SaturationMode::ON;
        TCVT(v816, v780, v818, v819);
        // pto: %46
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v820 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %46
        ;
        uint64_t v821 = (uint64_t) v26;
        TASSIGN(v820, v821);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        RoundMode v822 = RoundMode::CAST_ROUND;
        SaturationMode v823 = SaturationMode::ON;
        TCVT(v820, v792, v822, v823);
        // pto: %47
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v824 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %47
        ;
        uint64_t v825 = (uint64_t) v33;
        TASSIGN(v824, v825);
        pipe_barrier(PIPE_V);
        TMULS(v824, v804, v723);
        // pto: %48
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v826 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %48
        ;
        uint64_t v827 = (uint64_t) v34;
        TASSIGN(v826, v827);
        TMULS(v826, v808, v725);
        // pto: %49
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v828 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %49
        ;
        uint64_t v829 = (uint64_t) v33;
        TASSIGN(v828, v829);
        pipe_barrier(PIPE_V);
        TADD(v828, v824, v826);
        // pto: %50
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v830 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %50
        ;
        uint64_t v831 = (uint64_t) v34;
        TASSIGN(v830, v831);
        pipe_barrier(PIPE_V);
        TMULS(v830, v812, v726);
        // pto: %51
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v832 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %51
        ;
        uint64_t v833 = (uint64_t) v33;
        TASSIGN(v832, v833);
        pipe_barrier(PIPE_V);
        TADD(v832, v828, v830);
        // pto: %52
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v834 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %52
        ;
        uint64_t v835 = (uint64_t) v34;
        TASSIGN(v834, v835);
        pipe_barrier(PIPE_V);
        TMULS(v834, v816, v727);
        // pto: %53
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v836 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %53
        ;
        uint64_t v837 = (uint64_t) v33;
        TASSIGN(v836, v837);
        pipe_barrier(PIPE_V);
        TADD(v836, v832, v834);
        // pto: %54
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v838 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %54
        ;
        uint64_t v839 = (uint64_t) v34;
        TASSIGN(v838, v839);
        pipe_barrier(PIPE_V);
        TMULS(v838, v820, v728);
        // pto: %55
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v840 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %55
        ;
        uint64_t v841 = (uint64_t) v33;
        TASSIGN(v840, v841);
        pipe_barrier(PIPE_V);
        TADD(v840, v836, v838);
        // pto: %56
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v842 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %56
        ;
        uint64_t v843 = (uint64_t) v35;
        TASSIGN(v842, v843);
        pipe_barrier(PIPE_V);
        RoundMode v844 = RoundMode::CAST_RINT;
        SaturationMode v845 = SaturationMode::ON;
        TCVT(v842, v840, v844, v845);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v842.SetValidShape(v37, v42);
        // pto: %58
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v846 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %58
        ;
        uint64_t v847 = (uint64_t) v33;
        TASSIGN(v846, v847);
        pipe_barrier(PIPE_V);
        TMULS(v846, v804, v729);
        // pto: %59
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v848 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %59
        ;
        uint64_t v849 = (uint64_t) v34;
        TASSIGN(v848, v849);
        TMULS(v848, v808, v730);
        // pto: %60
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v850 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %60
        ;
        uint64_t v851 = (uint64_t) v33;
        TASSIGN(v850, v851);
        pipe_barrier(PIPE_V);
        TADD(v850, v846, v848);
        // pto: %61
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v852 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %61
        ;
        uint64_t v853 = (uint64_t) v34;
        TASSIGN(v852, v853);
        pipe_barrier(PIPE_V);
        TMULS(v852, v812, v731);
        // pto: %62
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v854 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %62
        ;
        uint64_t v855 = (uint64_t) v33;
        TASSIGN(v854, v855);
        pipe_barrier(PIPE_V);
        TADD(v854, v850, v852);
        // pto: %63
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v856 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %63
        ;
        uint64_t v857 = (uint64_t) v34;
        TASSIGN(v856, v857);
        pipe_barrier(PIPE_V);
        TMULS(v856, v816, v732);
        // pto: %64
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v858 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %64
        ;
        uint64_t v859 = (uint64_t) v33;
        TASSIGN(v858, v859);
        pipe_barrier(PIPE_V);
        TADD(v858, v854, v856);
        // pto: %65
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v860 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %65
        ;
        uint64_t v861 = (uint64_t) v34;
        TASSIGN(v860, v861);
        pipe_barrier(PIPE_V);
        TMULS(v860, v820, v733);
        // pto: %66
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v862 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %66
        ;
        uint64_t v863 = (uint64_t) v33;
        TASSIGN(v862, v863);
        pipe_barrier(PIPE_V);
        TADD(v862, v858, v860);
        // pto: %67
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v864 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %67
        ;
        uint64_t v865 = (uint64_t) v36;
        TASSIGN(v864, v865);
        pipe_barrier(PIPE_V);
        RoundMode v866 = RoundMode::CAST_RINT;
        SaturationMode v867 = SaturationMode::ON;
        TCVT(v864, v862, v866, v867);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        v864.SetValidShape(v37, v42);
        // pto: %69
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v868 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %69
        ;
        uint64_t v869 = (uint64_t) v33;
        TASSIGN(v868, v869);
        pipe_barrier(PIPE_V);
        TMULS(v868, v804, v734);
        // pto: %70
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v870 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %70
        ;
        uint64_t v871 = (uint64_t) v34;
        TASSIGN(v870, v871);
        TMULS(v870, v808, v735);
        // pto: %71
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v872 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %71
        ;
        uint64_t v873 = (uint64_t) v33;
        TASSIGN(v872, v873);
        pipe_barrier(PIPE_V);
        TADD(v872, v868, v870);
        // pto: %72
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v874 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %72
        ;
        uint64_t v875 = (uint64_t) v34;
        TASSIGN(v874, v875);
        pipe_barrier(PIPE_V);
        TMULS(v874, v812, v736);
        // pto: %73
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v876 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %73
        ;
        uint64_t v877 = (uint64_t) v33;
        TASSIGN(v876, v877);
        pipe_barrier(PIPE_V);
        TADD(v876, v872, v874);
        // pto: %74
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v878 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %74
        ;
        uint64_t v879 = (uint64_t) v34;
        TASSIGN(v878, v879);
        pipe_barrier(PIPE_V);
        TMULS(v878, v816, v737);
        // pto: %75
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v880 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %75
        ;
        uint64_t v881 = (uint64_t) v33;
        TASSIGN(v880, v881);
        pipe_barrier(PIPE_V);
        TADD(v880, v876, v878);
        // pto: %76
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v882 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %76
        ;
        uint64_t v883 = (uint64_t) v34;
        TASSIGN(v882, v883);
        pipe_barrier(PIPE_V);
        TMULS(v882, v820, v738);
        // pto: %77
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v884 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %77
        ;
        uint64_t v885 = (uint64_t) v33;
        TASSIGN(v884, v885);
        pipe_barrier(PIPE_V);
        TADD(v884, v880, v882);
        // pto: %78
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v886 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %78
        ;
        uint64_t v887 = (uint64_t) v33;
        TASSIGN(v886, v887);
        pipe_barrier(PIPE_V);
        RoundMode v888 = RoundMode::CAST_RINT;
        SaturationMode v889 = SaturationMode::ON;
        TCVT(v886, v884, v888, v889);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        v886.SetValidShape(v37, v42);
        // pto: %80
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v890 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %80
        ;
        uint64_t v891 = (uint64_t) v24;
        TASSIGN(v890, v891);
        TMULS(v890, v804, v739);
        // pto: %81
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v892 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %81
        ;
        uint64_t v893 = (uint64_t) v32;
        TASSIGN(v892, v893);
        TMULS(v892, v808, v740);
        // pto: %82
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v894 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %82
        ;
        uint64_t v895 = (uint64_t) v24;
        TASSIGN(v894, v895);
        pipe_barrier(PIPE_V);
        TADD(v894, v890, v892);
        // pto: %83
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v896 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %83
        ;
        uint64_t v897 = (uint64_t) v32;
        TASSIGN(v896, v897);
        pipe_barrier(PIPE_V);
        TMULS(v896, v812, v741);
        // pto: %84
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v898 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %84
        ;
        uint64_t v899 = (uint64_t) v24;
        TASSIGN(v898, v899);
        pipe_barrier(PIPE_V);
        TADD(v898, v894, v896);
        // pto: %85
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v900 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %85
        ;
        uint64_t v901 = (uint64_t) v32;
        TASSIGN(v900, v901);
        pipe_barrier(PIPE_V);
        TMULS(v900, v816, v742);
        // pto: %86
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v902 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %86
        ;
        uint64_t v903 = (uint64_t) v24;
        TASSIGN(v902, v903);
        pipe_barrier(PIPE_V);
        TADD(v902, v898, v900);
        // pto: %87
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v904 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v755, v42);
        // pto: %87
        ;
        uint64_t v905 = (uint64_t) v32;
        TASSIGN(v904, v905);
        pipe_barrier(PIPE_V);
        TMULS(v904, v820, v743);
        // pto: %88
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v906 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %88
        ;
        uint64_t v907 = (uint64_t) v24;
        TASSIGN(v906, v907);
        pipe_barrier(PIPE_V);
        TADD(v906, v902, v904);
        // pto: %89
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v908 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %89
        ;
        uint64_t v909 = (uint64_t) v24;
        TASSIGN(v908, v909);
        pipe_barrier(PIPE_V);
        RoundMode v910 = RoundMode::CAST_RINT;
        SaturationMode v911 = SaturationMode::ON;
        TCVT(v908, v906, v910, v911);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        v908.SetValidShape(v37, v42);
        // pto: %y_flat__phi_v9_pview
        ;
        __gm__ bfloat16_t* v912 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %y_flat__phi_v9_pview
        ;
        const int64_t v913 = 0;
        // pto: %y_flat__phi_v9_pview
        ;
        const int64_t v914 = 16384;
        // pto: %y_flat__phi_v9_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v915 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__phi_v9_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v916 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__phi_v9_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v917 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v912 + (v913 + v746 * v914), v915, v916);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v917, v842);
        // pto: %630
        ;
        __gm__ bfloat16_t* v918 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %630
        ;
        const int64_t v919 = 4096;
        // pto: %630
        ;
        const int64_t v920 = 16384;
        // pto: %630
        ;
        pto::Shape<1, 1, 1, 1, 4096> v921 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %630
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v922 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %630
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v923 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v918 + (v919 + v746 * v920), v921, v922);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v923, v864);
        // pto: %634
        ;
        __gm__ bfloat16_t* v924 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %634
        ;
        const int64_t v925 = 8192;
        // pto: %634
        ;
        const int64_t v926 = 16384;
        // pto: %634
        ;
        pto::Shape<1, 1, 1, 1, 4096> v927 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %634
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v928 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %634
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v929 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v924 + (v925 + v746 * v926), v927, v928);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        TSTORE(v929, v886);
        // pto: %638
        ;
        __gm__ bfloat16_t* v930 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %638
        ;
        const int64_t v931 = 12288;
        // pto: %638
        ;
        const int64_t v932 = 16384;
        // pto: %638
        ;
        pto::Shape<1, 1, 1, 1, 4096> v933 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %638
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v934 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %638
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v935 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v930 + (v931 + v746 * v932), v933, v934);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        TSTORE(v935, v908);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    // pto: %639, %640, %641
    ;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    if ((int64_t) ((uint64_t) ((int64_t) (uint64_t) v504 - (uint64_t) v505) + (uint64_t) v45) == v37) {
      // pto: %642
      ;
      if (v505 < v17) {
        // pto: %91
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v936 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %91
        ;
        uint64_t v937 = (uint64_t) v32;
        TASSIGN(v936, v937);
        // pto: %643
        ;
        int64_t v938 = v505 < v49 ? v49 : v505;
        // pto: %644
        ;
        __gm__ bfloat16_t* v939 = PTOAS__GLOBAL_TENSOR_DATA(v121);
        // pto: %644
        ;
        const int64_t v940 = 0;
        // pto: %644
        ;
        const int64_t v941 = 4096;
        // pto: %644
        ;
        pto::Shape<1, 1, 1, 1, 4096> v942 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %644
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v943 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %644
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v944 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v939 + (v940 + v938 * v941), v942, v943);
        TLOAD(v936, v944);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %92
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v945 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %92
        ;
        uint64_t v946 = (uint64_t) v24;
        TASSIGN(v945, v946);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v947 = RoundMode::CAST_ROUND;
        SaturationMode v948 = SaturationMode::ON;
        TCVT(v945, v936, v947, v948);
        // pto: %645
        ;
        int64_t v949 = (int64_t) ((uint64_t) v17 - (uint64_t) v505);
        // pto: %646
        ;
        int64_t v950 = v949 < v49 ? v49 : v949;
        // pto: %647
        ;
        int64_t v951 = v950 < v37 ? v950 : v37;
        // pto: %93
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v952 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %93
        ;
        uint64_t v953 = (uint64_t) v25;
        TASSIGN(v952, v953);
        // pto: %652
        ;
        const int64_t v954 = 0;
        // pto: %652
        ;
        __gm__ bfloat16_t* v955 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %652
        ;
        const int64_t v956 = 1;
        // pto: %652
        ;
        const int64_t v957 = 1;
        // pto: %652
        ;
        const int64_t v958 = 1;
        // pto: %652
        ;
        int64_t v959 = v951 * v44;
        // pto: %652
        ;
        int64_t v960 = v958 * v959;
        // pto: %652
        ;
        pto::Shape<1, 1, 1, -1, 4096> v961 = pto::Shape<1, 1, 1, -1, 4096>(v956, v957, v958, v951, v42);
        // pto: %652
        ;
        pto::Stride<-1, -1, -1, -1, -1> v962 = pto::Stride<-1, -1, -1, -1, -1>(v957 * v960, v960, v959, v44, v37);
        // pto: %652
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v963 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v955 + (v954 + v938 * v44 + v49 * v37), v961, v962);
        TLOAD(v952, v963);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %94
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v964 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %94
        ;
        uint64_t v965 = (uint64_t) v32;
        TASSIGN(v964, v965);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v966 = RoundMode::CAST_ROUND;
        SaturationMode v967 = SaturationMode::ON;
        TCVT(v964, v952, v966, v967);
        // pto: %95
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v968 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %95
        ;
        uint64_t v969 = (uint64_t) v30;
        TASSIGN(v968, v969);
        // pto: %663
        ;
        const int64_t v970 = 0;
        // pto: %663
        ;
        __gm__ bfloat16_t* v971 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %663
        ;
        const int64_t v972 = 1;
        // pto: %663
        ;
        const int64_t v973 = 1;
        // pto: %663
        ;
        const int64_t v974 = 1;
        // pto: %663
        ;
        int64_t v975 = v951 * v44;
        // pto: %663
        ;
        int64_t v976 = v974 * v975;
        // pto: %663
        ;
        pto::Shape<1, 1, 1, -1, 4096> v977 = pto::Shape<1, 1, 1, -1, 4096>(v972, v973, v974, v951, v42);
        // pto: %663
        ;
        pto::Stride<-1, -1, -1, -1, -1> v978 = pto::Stride<-1, -1, -1, -1, -1>(v973 * v976, v976, v975, v44, v37);
        // pto: %663
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v979 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v971 + (v970 + v938 * v44 + v42 * v37), v977, v978);
        TLOAD(v968, v979);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %96
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v980 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %96
        ;
        uint64_t v981 = (uint64_t) v25;
        TASSIGN(v980, v981);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v982 = RoundMode::CAST_ROUND;
        SaturationMode v983 = SaturationMode::ON;
        TCVT(v980, v968, v982, v983);
        // pto: %97
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v984 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %97
        ;
        uint64_t v985 = (uint64_t) v26;
        TASSIGN(v984, v985);
        // pto: %674
        ;
        const int64_t v986 = 0;
        // pto: %674
        ;
        __gm__ bfloat16_t* v987 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %674
        ;
        const int64_t v988 = 1;
        // pto: %674
        ;
        const int64_t v989 = 1;
        // pto: %674
        ;
        const int64_t v990 = 1;
        // pto: %674
        ;
        int64_t v991 = v951 * v44;
        // pto: %674
        ;
        int64_t v992 = v990 * v991;
        // pto: %674
        ;
        pto::Shape<1, 1, 1, -1, 4096> v993 = pto::Shape<1, 1, 1, -1, 4096>(v988, v989, v990, v951, v42);
        // pto: %674
        ;
        pto::Stride<-1, -1, -1, -1, -1> v994 = pto::Stride<-1, -1, -1, -1, -1>(v989 * v992, v992, v991, v44, v37);
        // pto: %674
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v995 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v987 + (v986 + v938 * v44 + v43 * v37), v993, v994);
        TLOAD(v984, v995);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %98
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v996 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %98
        ;
        uint64_t v997 = (uint64_t) v30;
        TASSIGN(v996, v997);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v998 = RoundMode::CAST_ROUND;
        SaturationMode v999 = SaturationMode::ON;
        TCVT(v996, v984, v998, v999);
        // pto: %99
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1000 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %99
        ;
        uint64_t v1001 = (uint64_t) v33;
        TASSIGN(v1000, v1001);
        // pto: %685
        ;
        const int64_t v1002 = 0;
        // pto: %685
        ;
        __gm__ bfloat16_t* v1003 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %685
        ;
        const int64_t v1004 = 1;
        // pto: %685
        ;
        const int64_t v1005 = 1;
        // pto: %685
        ;
        const int64_t v1006 = 1;
        // pto: %685
        ;
        int64_t v1007 = v951 * v44;
        // pto: %685
        ;
        int64_t v1008 = v1006 * v1007;
        // pto: %685
        ;
        pto::Shape<1, 1, 1, -1, 4096> v1009 = pto::Shape<1, 1, 1, -1, 4096>(v1004, v1005, v1006, v951, v42);
        // pto: %685
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1010 = pto::Stride<-1, -1, -1, -1, -1>(v1005 * v1008, v1008, v1007, v44, v37);
        // pto: %685
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1011 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1003 + (v1002 + v938 * v44 + v74 * v37), v1009, v1010);
        TLOAD(v1000, v1011);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %100
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1012 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %100
        ;
        uint64_t v1013 = (uint64_t) v26;
        TASSIGN(v1012, v1013);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v1014 = RoundMode::CAST_ROUND;
        SaturationMode v1015 = SaturationMode::ON;
        TCVT(v1012, v1000, v1014, v1015);
        // pto: %690
        ;
        int64_t v1016 = (int64_t) ((uint64_t) v505 * (uint64_t) v45);
        // pto: %689
        ;
        float v1017 = (v11)[v1016];
        // pto: %101
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1018 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %101
        ;
        uint64_t v1019 = (uint64_t) v33;
        TASSIGN(v1018, v1019);
        pipe_barrier(PIPE_V);
        TMULS(v1018, v945, v1017);
        // pto: %693
        ;
        int64_t v1020 = (int64_t) ((uint64_t) v505 * (uint64_t) v39);
        // pto: %692
        ;
        float v1021 = (v12)[v1020];
        // pto: %102
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1022 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %102
        ;
        uint64_t v1023 = (uint64_t) v34;
        TASSIGN(v1022, v1023);
        TMULS(v1022, v964, v1021);
        // pto: %103
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1024 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %103
        ;
        uint64_t v1025 = (uint64_t) v33;
        TASSIGN(v1024, v1025);
        pipe_barrier(PIPE_V);
        TADD(v1024, v1018, v1022);
        // pto: %700, %698
        ;
        float v1026 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v45)];
        // pto: %104
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1027 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %104
        ;
        uint64_t v1028 = (uint64_t) v34;
        TASSIGN(v1027, v1028);
        pipe_barrier(PIPE_V);
        TMULS(v1027, v980, v1026);
        // pto: %105
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1029 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %105
        ;
        uint64_t v1030 = (uint64_t) v33;
        TASSIGN(v1029, v1030);
        pipe_barrier(PIPE_V);
        TADD(v1029, v1024, v1027);
        // pto: %706, %704
        ;
        float v1031 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v38)];
        // pto: %106
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1032 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %106
        ;
        uint64_t v1033 = (uint64_t) v34;
        TASSIGN(v1032, v1033);
        pipe_barrier(PIPE_V);
        TMULS(v1032, v996, v1031);
        // pto: %107
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1034 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %107
        ;
        uint64_t v1035 = (uint64_t) v33;
        TASSIGN(v1034, v1035);
        pipe_barrier(PIPE_V);
        TADD(v1034, v1029, v1032);
        // pto: %712, %710
        ;
        float v1036 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v66)];
        // pto: %108
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1037 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %108
        ;
        uint64_t v1038 = (uint64_t) v34;
        TASSIGN(v1037, v1038);
        pipe_barrier(PIPE_V);
        TMULS(v1037, v1012, v1036);
        // pto: %109
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1039 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %109
        ;
        uint64_t v1040 = (uint64_t) v33;
        TASSIGN(v1039, v1040);
        pipe_barrier(PIPE_V);
        TADD(v1039, v1034, v1037);
        // pto: %110
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1041 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %110
        ;
        uint64_t v1042 = (uint64_t) v33;
        TASSIGN(v1041, v1042);
        pipe_barrier(PIPE_V);
        RoundMode v1043 = RoundMode::CAST_RINT;
        SaturationMode v1044 = SaturationMode::ON;
        TCVT(v1041, v1039, v1043, v1044);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1041.SetValidShape(v37, v42);
        // pto: %y_flat__rv_v4_main_pview
        ;
        __gm__ bfloat16_t* v1045 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %y_flat__rv_v4_main_pview
        ;
        const int64_t v1046 = 0;
        // pto: %y_flat__rv_v4_main_pview
        ;
        const int64_t v1047 = 16384;
        // pto: %y_flat__rv_v4_main_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1048 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__rv_v4_main_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1049 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__rv_v4_main_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1050 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1045 + (v1046 + v938 * v1047), v1048, v1049);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1050, v1041);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
        // pto: %720, %718
        ;
        float v1051 = (v11)[(int64_t) ((uint64_t) v1016 + (uint64_t) v37)];
        // pto: %112
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1052 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %112
        ;
        uint64_t v1053 = (uint64_t) v33;
        TASSIGN(v1052, v1053);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
        TMULS(v1052, v945, v1051);
        // pto: %723, %721
        ;
        float v1054 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v37)];
        // pto: %113
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1055 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %113
        ;
        uint64_t v1056 = (uint64_t) v34;
        TASSIGN(v1055, v1056);
        TMULS(v1055, v964, v1054);
        // pto: %114
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1057 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %114
        ;
        uint64_t v1058 = (uint64_t) v33;
        TASSIGN(v1057, v1058);
        pipe_barrier(PIPE_V);
        TADD(v1057, v1052, v1055);
        // pto: %729, %727
        ;
        float v1059 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v67)];
        // pto: %115
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1060 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %115
        ;
        uint64_t v1061 = (uint64_t) v34;
        TASSIGN(v1060, v1061);
        pipe_barrier(PIPE_V);
        TMULS(v1060, v980, v1059);
        // pto: %116
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1062 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %116
        ;
        uint64_t v1063 = (uint64_t) v33;
        TASSIGN(v1062, v1063);
        pipe_barrier(PIPE_V);
        TADD(v1062, v1057, v1060);
        // pto: %735, %733
        ;
        float v1064 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v68)];
        // pto: %117
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1065 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %117
        ;
        uint64_t v1066 = (uint64_t) v34;
        TASSIGN(v1065, v1066);
        pipe_barrier(PIPE_V);
        TMULS(v1065, v996, v1064);
        // pto: %118
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1067 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %118
        ;
        uint64_t v1068 = (uint64_t) v33;
        TASSIGN(v1067, v1068);
        pipe_barrier(PIPE_V);
        TADD(v1067, v1062, v1065);
        // pto: %741, %739
        ;
        float v1069 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v69)];
        // pto: %119
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1070 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %119
        ;
        uint64_t v1071 = (uint64_t) v34;
        TASSIGN(v1070, v1071);
        pipe_barrier(PIPE_V);
        TMULS(v1070, v1012, v1069);
        // pto: %120
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1072 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %120
        ;
        uint64_t v1073 = (uint64_t) v33;
        TASSIGN(v1072, v1073);
        pipe_barrier(PIPE_V);
        TADD(v1072, v1067, v1070);
        // pto: %121
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1074 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %121
        ;
        uint64_t v1075 = (uint64_t) v33;
        TASSIGN(v1074, v1075);
        pipe_barrier(PIPE_V);
        RoundMode v1076 = RoundMode::CAST_RINT;
        SaturationMode v1077 = SaturationMode::ON;
        TCVT(v1074, v1072, v1076, v1077);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1074.SetValidShape(v37, v42);
        // pto: %747
        ;
        __gm__ bfloat16_t* v1078 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %747
        ;
        const int64_t v1079 = 4096;
        // pto: %747
        ;
        const int64_t v1080 = 16384;
        // pto: %747
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1081 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %747
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1082 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %747
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1083 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1078 + (v1079 + v938 * v1080), v1081, v1082);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1083, v1074);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        // pto: %750, %748
        ;
        float v1084 = (v11)[(int64_t) ((uint64_t) v1016 + (uint64_t) v47)];
        // pto: %123
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1085 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %123
        ;
        uint64_t v1086 = (uint64_t) v33;
        TASSIGN(v1085, v1086);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        TMULS(v1085, v945, v1084);
        // pto: %753, %751
        ;
        float v1087 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v47)];
        // pto: %124
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1088 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %124
        ;
        uint64_t v1089 = (uint64_t) v34;
        TASSIGN(v1088, v1089);
        TMULS(v1088, v964, v1087);
        // pto: %125
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1090 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %125
        ;
        uint64_t v1091 = (uint64_t) v33;
        TASSIGN(v1090, v1091);
        pipe_barrier(PIPE_V);
        TADD(v1090, v1085, v1088);
        // pto: %759, %757
        ;
        float v1092 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v70)];
        // pto: %126
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1093 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %126
        ;
        uint64_t v1094 = (uint64_t) v34;
        TASSIGN(v1093, v1094);
        pipe_barrier(PIPE_V);
        TMULS(v1093, v980, v1092);
        // pto: %127
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1095 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %127
        ;
        uint64_t v1096 = (uint64_t) v33;
        TASSIGN(v1095, v1096);
        pipe_barrier(PIPE_V);
        TADD(v1095, v1090, v1093);
        // pto: %765, %763
        ;
        float v1097 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v71)];
        // pto: %128
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1098 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %128
        ;
        uint64_t v1099 = (uint64_t) v34;
        TASSIGN(v1098, v1099);
        pipe_barrier(PIPE_V);
        TMULS(v1098, v996, v1097);
        // pto: %129
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1100 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %129
        ;
        uint64_t v1101 = (uint64_t) v33;
        TASSIGN(v1100, v1101);
        pipe_barrier(PIPE_V);
        TADD(v1100, v1095, v1098);
        // pto: %771, %769
        ;
        float v1102 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v72)];
        // pto: %130
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1103 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %130
        ;
        uint64_t v1104 = (uint64_t) v34;
        TASSIGN(v1103, v1104);
        pipe_barrier(PIPE_V);
        TMULS(v1103, v1012, v1102);
        // pto: %131
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1105 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %131
        ;
        uint64_t v1106 = (uint64_t) v33;
        TASSIGN(v1105, v1106);
        pipe_barrier(PIPE_V);
        TADD(v1105, v1100, v1103);
        // pto: %132
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1107 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %132
        ;
        uint64_t v1108 = (uint64_t) v33;
        TASSIGN(v1107, v1108);
        pipe_barrier(PIPE_V);
        RoundMode v1109 = RoundMode::CAST_RINT;
        SaturationMode v1110 = SaturationMode::ON;
        TCVT(v1107, v1105, v1109, v1110);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1107.SetValidShape(v37, v42);
        // pto: %777
        ;
        __gm__ bfloat16_t* v1111 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %777
        ;
        const int64_t v1112 = 8192;
        // pto: %777
        ;
        const int64_t v1113 = 16384;
        // pto: %777
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1114 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %777
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1115 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %777
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1116 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1111 + (v1112 + v938 * v1113), v1114, v1115);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1116, v1107);
        // pto: %780, %778
        ;
        float v1117 = (v11)[(int64_t) ((uint64_t) v1016 + (uint64_t) v65)];
        // pto: %134
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1118 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %134
        ;
        uint64_t v1119 = (uint64_t) v24;
        TASSIGN(v1118, v1119);
        TMULS(v1118, v945, v1117);
        // pto: %783, %781
        ;
        float v1120 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v65)];
        // pto: %135
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1121 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %135
        ;
        uint64_t v1122 = (uint64_t) v32;
        TASSIGN(v1121, v1122);
        TMULS(v1121, v964, v1120);
        // pto: %136
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1123 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %136
        ;
        uint64_t v1124 = (uint64_t) v24;
        TASSIGN(v1123, v1124);
        pipe_barrier(PIPE_V);
        TADD(v1123, v1118, v1121);
        // pto: %789, %787
        ;
        float v1125 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v55)];
        // pto: %137
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1126 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %137
        ;
        uint64_t v1127 = (uint64_t) v32;
        TASSIGN(v1126, v1127);
        pipe_barrier(PIPE_V);
        TMULS(v1126, v980, v1125);
        // pto: %138
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1128 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %138
        ;
        uint64_t v1129 = (uint64_t) v24;
        TASSIGN(v1128, v1129);
        pipe_barrier(PIPE_V);
        TADD(v1128, v1123, v1126);
        // pto: %795, %793
        ;
        float v1130 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v73)];
        // pto: %139
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1131 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %139
        ;
        uint64_t v1132 = (uint64_t) v32;
        TASSIGN(v1131, v1132);
        pipe_barrier(PIPE_V);
        TMULS(v1131, v996, v1130);
        // pto: %140
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1133 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %140
        ;
        uint64_t v1134 = (uint64_t) v24;
        TASSIGN(v1133, v1134);
        pipe_barrier(PIPE_V);
        TADD(v1133, v1128, v1131);
        // pto: %801, %799
        ;
        float v1135 = (v12)[(int64_t) ((uint64_t) v1020 + (uint64_t) v50)];
        // pto: %141
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1136 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v951, v42);
        // pto: %141
        ;
        uint64_t v1137 = (uint64_t) v32;
        TASSIGN(v1136, v1137);
        pipe_barrier(PIPE_V);
        TMULS(v1136, v1012, v1135);
        // pto: %142
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1138 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %142
        ;
        uint64_t v1139 = (uint64_t) v24;
        TASSIGN(v1138, v1139);
        pipe_barrier(PIPE_V);
        TADD(v1138, v1133, v1136);
        // pto: %143
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1140 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
        // pto: %143
        ;
        uint64_t v1141 = (uint64_t) v24;
        TASSIGN(v1140, v1141);
        pipe_barrier(PIPE_V);
        RoundMode v1142 = RoundMode::CAST_RINT;
        SaturationMode v1143 = SaturationMode::ON;
        TCVT(v1140, v1138, v1142, v1143);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1140.SetValidShape(v37, v42);
        // pto: %807
        ;
        __gm__ bfloat16_t* v1144 = PTOAS__GLOBAL_TENSOR_DATA(v139);
        // pto: %807
        ;
        const int64_t v1145 = 12288;
        // pto: %807
        ;
        const int64_t v1146 = 16384;
        // pto: %807
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1147 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %807
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1148 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %807
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1149 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1144 + (v1145 + v938 * v1146), v1147, v1148);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v1149, v1140);
      };
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  pipe_barrier(PIPE_ALL);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}