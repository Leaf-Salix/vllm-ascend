"""穷举M256及M128分区、标定起点、固定K128序列；非设备资格。"""
from pathlib import Path
import json
import runpy

root = Path(__file__).resolve().parent
repo = root.parents[2] / 'vllm-ascend-nalinaly-tnd-20261008-codex'
data = runpy.run_path(str(repo/'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision/oproj_order_data.py'))
records = []
for t in range(192, 257):
    tiles = (t + 15) // 16
    starts = data['OPROJ_TILE_STARTS'][data['OPROJ_TOKEN_MODES'][t-1]]
    covered = []
    counts = {'parent_fast':0,'new_fast':0,'new_fallback':0}
    for logical in range(64):
        g,n = divmod(logical,8)
        for rb in range(0,tiles,8):
            selected = [starts[r][g][n] for r in range(rb,min(rb+8,tiles))]
            counts['parent_fast'] += int(len(set(selected))==1 and 0<=selected[0]<=240 and selected[0]%16==0)
        for rb in range(0,tiles,16):
            selected = [starts[r][g][n] for r in range(rb,min(rb+16,tiles))]
            fast = len(set(selected))==1 and 0<=selected[0]<=240 and selected[0]%16==0
            counts['new_fast' if fast else 'new_fallback'] += 1
            for row in range(rb*16,min((rb+16)*16,t)):
                covered.append((logical,row))
            if fast:
                first = selected[0]
                sequence = [((first+p*8)%256)*16 for p in range(32)]
                old = [((first+p*16)%256)*16+k*128 for p in range(16) for k in range(2)]
                assert sequence == old
    assert len(covered)==t*64 and len(set(covered))==t*64
    assert t+127>=256
    records.append({'T':t,**counts})
(root/'M256_PROOF.json').write_text(json.dumps({'pass':True,'scope':'finite CPU source/layout eligibility and K sequence only','records':records},indent=2)+'\n')
print([r for r in records if r['T'] in (240,256)])
