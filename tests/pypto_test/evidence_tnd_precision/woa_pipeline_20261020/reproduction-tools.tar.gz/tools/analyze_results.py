"""离线复核本轮逐位门禁、成对延迟与候选SHA。"""
from pathlib import Path
import hashlib
import json
import re
import statistics

root = Path(__file__).resolve().parent
runs = json.loads((root / 'RUNS.json').read_text())
rows = []
for path in sorted(root.glob('woa-ab-*.json')):
    result = json.loads(path.read_text())
    assert result['pass'] and result['complete'] and result['actual_acl_graph'] and result['guards'] and result['readonly']
    comparisons = [item for group in result['comparisons'].values() for item in group.values()]
    assert len(comparisons) == 160 and all(item['bit_equal'] and item['different_elements'] == 0 for item in comparisons)
    assert result['final_generation'] == {'parent': 1204, 'new': 1204}
    timings = result['timings']
    assert timings['windows'] == 12 and timings['replays'] == 100 and not timings['outliers_removed']
    samples, summaries = timings['samples'], timings['summary']
    for arm in ('frozen', 'resident', 'new'):
        assert len(samples[arm]) == 12
        assert statistics.median(samples[arm]) == summaries[arm]['median']
    candidate = result['candidate_proof']
    source = root / ('candidate-' + re.fullmatch(r'woa-ab-(.+)-t[0-9]+-v[0-9]+', path.stem)[1] + '.py')
    assert hashlib.sha256(source.read_bytes()).hexdigest() == candidate['candidate_sha256']
    med = {arm: summaries[arm]['median'] for arm in ('frozen', 'resident', 'new')}
    rows.append({'case': path.stem, 'tokens': result['tokens'], 'parent': result['comparison_parent'], 'median_us': med, 'change_percent': (med['new'] / med['resident'] - 1) * 100, 'vs_frozen_percent': (med['new'] / med['frozen'] - 1) * 100, 'improved_windows': sum(a < b for a, b in zip(samples['new'], samples['resident'])), 'better_than_frozen_windows': sum(a < b for a, b in zip(samples['new'], samples['frozen'])), 'bit_comparisons': len(comparisons), 'probe_seconds': result['finished_unix'] - result['started_unix']})
(root / 'AB_VALIDATION.json').write_text(json.dumps({'pass': True, 'scope': 'frozen PTO suffix gold; not a new Native wholemodel qualification', 'rows': rows}, indent=2) + '\n')
for row in rows:
    print(row['case'], *(round(row['median_us'][k], 3) for k in ('frozen', 'resident', 'new')), round(row['change_percent'], 2), row['improved_windows'], 'probe_seconds', round(row['probe_seconds'], 1))
