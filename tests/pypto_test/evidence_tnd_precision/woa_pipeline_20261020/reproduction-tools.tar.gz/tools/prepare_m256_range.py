"""M256容量修正的成对控制：两臂均K128单缓冲，只差行面板高度。"""
import ast
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
for name, source_name, parent in [('m128range', 'k128owner2', 'k128owner2'), ('m256range', 'm256owner2', 'm128range')]:
    source = (root / ('candidate-' + source_name + '.py')).read_text()
    assert source.count('pl.pipeline(1, 32, stage=2)') == 1
    candidate = source.replace('pl.pipeline(1, 32, stage=2)', 'pl.range(1, 32)')
    ast.parse(candidate)
    path = root / ('candidate-' + name + '.py');path.write_text(candidate)
    path.with_suffix('.json').write_text(json.dumps({'parent':parent,'parent_sha256':hashlib.sha256((root / ('candidate-' + parent + '.py')).read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'change':('K128 highT range control; no row size change' if name=='m128range' else 'only combine two M128 to M256 panels with same K128 range; verify all 16 starts, original narrow fallback; vector and WO-B identical'),'scope':'CPU full qualification before NPU; original baseline preserved','formal_baseline':'48c58ce7c467dfce63d5cb5c41afd225488d6012'},indent=2)+'\n')
probe = (root/'ab_probe_m256.py').read_text().replace("choices=('m256owner2',)","choices=('m256range',)").replace("choices=('k128owner2',)","choices=('m128range',)").replace("args.variant=='m256owner2'", "args.variant=='m256range'").replace("args.parent=='k128owner2'", "args.parent=='m128range'")
(root/'ab_probe_m256range.py').write_text(probe)
(root/'run-m256range.sh').write_text((root/'run-m256.sh').read_text().replace('ab_probe_m256.py','ab_probe_m256range.py'))
(root/'check_candidates_v11.py').write_text((root/'check_candidates_v10.py').read_text().replace("('m256owner2',)","('m128range','m256range')").replace('cpu-v10','cpu-v11'))
(root/'check-candidates-v11.sh').write_text((root/'check-candidates-v10.sh').read_text().replace('v10','v11'))
print('paired control prepared')
