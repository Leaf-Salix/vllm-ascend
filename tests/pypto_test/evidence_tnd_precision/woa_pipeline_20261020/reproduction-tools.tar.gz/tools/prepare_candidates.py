"""只改WO-A搬运/流水，冻结phase1及Native算术链。"""
from pathlib import Path
import ast
import hashlib
import json
import textwrap

root = Path(__file__).resolve().parent
parent = (root/'parent-phase1.py').read_text()
parent_hash = hashlib.sha256(parent.encode()).hexdigest()
assert parent_hash == 'f22d7d8dd6ef2a48f640b88511c6c32c672ade0b116fa922f18c6a6a23237fe6'
start = parent.index('                    for v4_wide_packet in pl.range(15):')
end = parent.index('                    for v4_wide_tail in pl.range(241, 256):', start)
replacement = textwrap.indent(textwrap.dedent('''\
v4_pre_base = (v4_wide_first_block + 1) % 256
v4_pre_count = 15
if v4_pre_base % 16 != 0:
    v4_pre_count = pl.min(15, pl.max(0, (240 - v4_pre_base) // 16 + 1))
for v4_pre_packet in pl.range(v4_pre_count):
    v4_pre_k = (v4_pre_base + v4_pre_packet * 16) % 256 * 16
    v4_pre_x = pl.slice(heads, [128, 256], [v4_wide_row, v4_group * 4096 + v4_pre_k], valid_shape=[v4_wide_valid, 256])
    v4_pre_w = wo_a[v4_group:v4_group + 1, v4_pre_k:v4_pre_k + 256, v4_col:v4_col + 128]
    v4_wide_acc = pl.matmul_acc(v4_wide_acc, v4_pre_x, v4_pre_w, init_cond=False)
v4_wrap_base = 240 + v4_pre_base % 16
for v4_wrap_piece in pl.range(pl.min(16, (15 - v4_pre_count) * 16)):
    v4_wrap_k = (v4_wrap_base + v4_wrap_piece) % 256 * 16
    v4_wrap_x = pl.slice(heads, [128, 16], [v4_wide_row, v4_group * 4096 + v4_wrap_k], valid_shape=[v4_wide_valid, 16])
    v4_wrap_w = wo_a[v4_group:v4_group + 1, v4_wrap_k:v4_wrap_k + 16, v4_col:v4_col + 128]
    v4_wide_acc = pl.matmul_acc(v4_wide_acc, v4_wrap_x, v4_wrap_w, init_cond=False)
for v4_post_packet in pl.range(pl.max(0, 14 - v4_pre_count)):
    v4_post_k = (v4_pre_base % 16 + v4_post_packet * 16) * 16
    v4_post_x = pl.slice(heads, [128, 256], [v4_wide_row, v4_group * 4096 + v4_post_k], valid_shape=[v4_wide_valid, 256])
    v4_post_w = wo_a[v4_group:v4_group + 1, v4_post_k:v4_post_k + 256, v4_col:v4_col + 128]
    v4_wide_acc = pl.matmul_acc(v4_wide_acc, v4_post_x, v4_post_w, init_cond=False)
'''), ' '*20)
split = parent[:start] + replacement + parent[end:]
pipelined = split.replace('for v4_pre_packet in pl.range(v4_pre_count):', 'for v4_pre_packet in pl.pipeline(v4_pre_count, stage=2):').replace('for v4_post_packet in pl.range(pl.max(0, 14 - v4_pre_count)):', 'for v4_post_packet in pl.pipeline(pl.max(0, 14 - v4_pre_count), stage=2):')
# Only aligned Native K256 starts enter K128 transport; other fast paths remain byte-identical.
start = parent.index('                    seed_fast_seed_k = seed_first_start * 16')
end = parent.index('                    pl.assemble(accum, seed_fast_acc', start)
original = parent[start:end]
transport = textwrap.indent(textwrap.dedent('''\
seed_small_k = seed_first_start * 16
seed_small_x = pl.slice(heads, [128, 128], [seed_fast_row, seed_group * 4096 + seed_small_k], valid_shape=[seed_fast_valid, 128])
seed_small_w = wo_a[seed_group:seed_group + 1, seed_small_k:seed_small_k + 128, seed_col:seed_col + 128]
seed_fast_acc = pl.matmul(seed_small_x, seed_small_w, out_dtype=pl.FP32)
for seed_small_packet in pl.pipeline(1, 32, stage=2):
    seed_small_kb = (seed_first_start + seed_small_packet * 8) % 256
    seed_small_packet_k = seed_small_kb * 16
    seed_small_packet_x = pl.slice(heads, [128, 128], [seed_fast_row, seed_group * 4096 + seed_small_packet_k], valid_shape=[seed_fast_valid, 128])
    seed_small_packet_w = wo_a[seed_group:seed_group + 1, seed_small_packet_k:seed_small_packet_k + 128, seed_col:seed_col + 128]
    seed_fast_acc = pl.matmul_acc(seed_fast_acc, seed_small_packet_x, seed_small_packet_w, init_cond=False)
'''), ' '*24)
assembly_end=parent.index('\n',end)+1
assembly=parent[end:assembly_end]
k128 = parent[:start] + '                    if seed_first_start % 16 == 0:\n' + transport + textwrap.indent(assembly,' '*4) + '                    else:\n' + textwrap.indent(original+assembly, ' '*4) + parent[assembly_end:]
variants = {'split': (split, 'phase1', 'v4 branch hoist only; exact original K packet widths/order'), 'pipeline': (pipelined, 'split', 'only two contiguous v4 range loops to pipeline stage2'), 'k128': (k128, 'phase1', 'only aligned seed_fast K256 transfer to K128 pipeline; generated MMA order must be verified')}
for name, (source, ancestor, description) in variants.items():
    ast.parse(source)
    path = root/f'candidate-{name}.py';path.write_text(source)
    proof = {'candidate_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'parent': ancestor, 'parent_sha256': parent_hash if ancestor=='phase1' else hashlib.sha256(split.encode()).hexdigest(), 'formal_baseline':'48c58ce7c467dfce63d5cb5c41afd225488d6012', 'change':description, 'scope':'independent diagnostic, not installed or device qualified'}
    (root/f'candidate-{name}.json').write_text(json.dumps(proof,indent=2)+'\n')
# Prove packet-level width/start sequence, including the original K16 wrap and tail.
for s in range(256):
    old=[]
    for p in range(15):
        k=(s+1+p*16)%256
        old.extend([(k,16)] if k<=240 else [((k+i)%256,1) for i in range(16)])
    base=(s+1)%256;before=15 if base%16==0 else min(15,max(0,(240-base)//16+1));new=[((base+p*16)%256,16) for p in range(before)]
    if before<15:
        wrap=240+base%16
        assert wrap>240
        new += [((wrap+i)%256,1) for i in range(16)]
        new += [(base%16+p*16,16) for p in range(14-before)]
    assert old==new,(s,old,new)
    trace=[s]+[k for b,n in new for k in [(b+i)%256 for i in range(n)]]+[(s+i)%256 for i in range(241,256)]
    assert trace==[(s+i)%256 for i in range(256)]
# K256 lowers to two ordered K128 MMAs in the prior generated program; only aligned starts use new transport.
for s in range(0,241,16):
    old=[((s+p*16+half*8)%256,8) for p in range(16) for half in range(2)]
    new=[((s+p*8)%256,8) for p in range(32)]
    assert old==new
(root/'TRACE_PROOF.json').write_text(json.dumps({'v4_split_all_256_starts_exact_packet_widths_order':True,'seed_k128_aligned_starts_same_lowered_k128_sequence':True,'seed_unaligned_original_branch_retained':True,'wo_b_and_vector_unchanged':True},indent=2)+'\n')
print('PASS: 3 candidates parsed, K-trace proofs')
