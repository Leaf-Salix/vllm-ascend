"""只合并高T WO-A行面板，保留K128有序累加及低T/窄回退数学。"""
import ast
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
parent = root / 'candidate-k128owner2.py'
source = parent.read_text()
a = source.index('    if rows >= 192:')
b = source.index('    else:\n        for logical in pl.range(worker, 64, 24):', a)
chunk = source[a:b]
chunk = chunk.replace('(row_tiles + 7) // 8', '(row_tiles + 15) // 16').replace('seed_panel * 8', 'seed_panel * 16')
anchor = '                if rows <= 16:\n'
checks = ''.join(f'                if seed_first_rb + {i} < row_tiles:\n                    if pl.max(pl.read(start, [seed_first_rb + {i}, seed_group, seed_block]), 0) != seed_first_start:\n                        seed_same_start = 0\n' for i in range(8,16))
assert chunk.count(anchor) == 1
chunk = chunk.replace(anchor, checks + anchor)
chunk = chunk.replace('pl.min(128, rows - seed_fast_row)', 'pl.min(256, rows - seed_fast_row)').replace('pl.slice(heads, [128, 128]', 'pl.slice(heads, [256, 128]').replace('pl.range(8):\n                        seed_narrow_rb', 'pl.range(16):\n                        seed_narrow_rb')
out = source[:a] + chunk + source[b:]
ast.parse(out)
assert out[out.index('    else:\n        for logical'): ] == source[source.index('    else:\n        for logical'): ]
name = 'm256owner2'
p = root / ('candidate-' + name + '.py');p.write_text(out)
p.with_suffix('.json').write_text(json.dumps({'parent':'k128owner2','parent_sha256':hashlib.sha256(parent.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'change':'WO-A highT combine two M128 panels to M256, check all sixteen calibrated row starts; K128 ordered chain unchanged; narrow fallback all sixteen rows; original vector/WO-B','scope':'CPU generated-code qualification required before NPU; no delivered route','formal_baseline':'48c58ce7c467dfce63d5cb5c41afd225488d6012'},indent=2)+'\n')
probe = (root/'ab_probe_v3.py').read_text().replace("choices=('tailboth','tailowner2','k128owner2')", "choices=('m256owner2',)").replace("choices=('tailpreload','owner2')", "choices=('k128owner2',)")
start = probe.index("assert (args.variant=='k128owner2'")
end = probe.index("sdk=Path(",start)
probe = probe[:start]+"assert args.variant=='m256owner2' and 192<=args.tokens<=256\nassert args.parent=='k128owner2'\n"+probe[end:]
(root/'ab_probe_m256.py').write_text(probe)
(root/'run-m256.sh').write_text((root/'run-v3.sh').read_text().replace('ab_probe_v3.py','ab_probe_m256.py'))
(root/'check_candidates_v10.py').write_text((root/'check_candidates_v9.py').read_text().replace("('tailboth','tailowner2','k128owner2')", "('m256owner2',)").replace('cpu-v9','cpu-v10'))
(root/'check-candidates-v10.sh').write_text((root/'check-candidates-v9.sh').read_text().replace('v9','v10'))
print('prepared independent M256 candidate')
