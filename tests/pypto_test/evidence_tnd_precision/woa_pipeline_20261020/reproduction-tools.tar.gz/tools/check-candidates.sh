#!/usr/bin/env bash
set -euo pipefail
sdk=/data/pyptouser/yejia/csa-spmd-sdk-20261020
export PYTHONNOUSERSITE=1 TORCH_DEVICE_BACKEND_AUTOLOAD=0 ASCEND_RT_VISIBLE_DEVICES=""
source /data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/vector-mte2-20261019-codex/full-csa-live-staging-v2/env.sh
export ASCEND_RT_VISIBLE_DEVICES="" TORCH_DEVICE_BACKEND_AUTOLOAD=0
unset PYTHONPATH
set +u
source /data/pyptouser/yejia/vllm-cann92-main/env/Ascend/cann-9.2.0-beta.2/set_env.sh
set -u
export ASCEND_HOME_PATH=/data/pyptouser/yejia/vllm-cann92-main/env/Ascend/cann-9.2.0-beta.2
export PATH="$sdk/sources/pypto/.venv/bin:/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/env/bin:$PATH"
export PYTHONPATH="$sdk/sources/pypto/python:$sdk/sources/simpler/python:$sdk/sources/simpler:$sdk/sources/simpler/.venv/lib/python3.12/site-packages${PYTHONPATH:+:$PYTHONPATH}"
cd "$sdk/sources/pypto"
source .claude/skills/testing/load-env.sh
export CCACHE_DIR="$PWD/.ccache"
ccache -s
export PTOAS_ROOT="$sdk/toolchain-wheel"
export PATH="$PTOAS_ROOT/bin:$PATH"
export PYPTO_PROG_BUILD_DIR="$sdk/wheel-compile-build" PYPTO_CACHE_DIR="$sdk/wheel-compile-cache"
timeout 600s python "$sdk/woa-pipeline-20261020/check_candidates.py" > "$sdk/logs/woa-pipeline-cpu-v4.log" 2>&1
