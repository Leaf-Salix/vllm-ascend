"""常驻后缀对冻结PTO数学的FULL graph逐位与交替性能；非整层/整模型结论。"""
import argparse
import hashlib
import importlib
import importlib.util
import json
import os
from pathlib import Path
import runpy
import statistics
import sys
import time
import traceback

parser=argparse.ArgumentParser()
parser.add_argument('--tokens',type=int,required=True)
parser.add_argument('--out',type=Path,required=True)
parser.add_argument('--variant',choices=('tailboth','tailowner2','k128owner2'),required=True)
parser.add_argument('--parent',choices=('tailpreload','owner2'),required=True)
args=parser.parse_args()
assert (args.variant=='k128owner2' and 192<=args.tokens<=256) or (args.variant!='k128owner2' and 16<args.tokens<192)
assert args.parent==('tailpreload' if args.variant=='tailboth' else 'owner2')
sdk=Path('/data/pyptouser/yejia/csa-spmd-sdk-20261020')
sys.argv=[str(sdk/'sdk-preflight.py')]
runpy.run_path(sys.argv[0],run_name='__main__')
import torch
import torch_npu
import pypto.torch
from vllm.engine.arg_utils import EngineArgs
from vllm.platforms import current_platform
from dsv4_csa_native_case import native_session
from dsv4_csa_single_layer import make_layer

args.out.mkdir(exist_ok=False)
report={'pass':False,'complete':False,'tokens':args.tokens,'scope':'WO-A one-factor transfer/pipeline candidate versus explicit parent and frozen PTO; not Native whole CSA','source_baseline':'48c58ce7c467dfce63d5cb5c41afd225488d6012','layout_scope':'token-row suffix only; no request metadata, not a full TND admission test','started_unix':time.time()}
def save():
 (args.out/'result.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
def sha(t):
 c=t.detach().cpu().contiguous();return hashlib.sha256(c.view(torch.uint8).numpy().tobytes()).hexdigest()
def bit_equal(a,b):
 return a.shape==b.shape and a.dtype==b.dtype and torch.equal(a.contiguous().view(torch.uint8),b.contiguous().view(torch.uint8))
current_platform.pre_register_and_update()
torch.npu.set_device(0)
torch.npu.config.allow_internal_format=True
torch.use_deterministic_algorithms(True)
torch_npu.npu.set_deterministic_level(1)
torch.set_num_threads(4)
from vllm_ascend.utils import enable_custom_op
assert enable_custom_op()
import vllm_ascend.ops.pypto as namespace
source_root=Path(os.environ['SOURCE_ROOT'])
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.o_proj import o_proj_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.hc_post import hc_post_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.oproj_order_data import OPROJ_TILE_STARTS,OPROJ_TOKEN_MODES
experiment=sdk/'woa-pipeline-20261020'
parent_file=experiment/('parent-phase1.py' if args.parent=='phase1' else 'candidate-'+args.parent+'.py')
parent_proof=json.loads(parent_file.with_suffix('.json').read_text())
phase1_proof=json.loads((experiment/'parent-phase1.json').read_text())
assert hashlib.sha256((experiment/'parent-phase1.py').read_bytes()).hexdigest()==phase1_proof['candidate_sha256']
assert phase1_proof['candidate_sha256']=='f22d7d8dd6ef2a48f640b88511c6c32c672ade0b116fa922f18c6a6a23237fe6'
spec=importlib.util.spec_from_file_location('private_resident_suffix_device',parent_file)
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
proof=json.loads((sdk/'RESIDENT_SUFFIX_SOURCE_PROOF.json').read_text())
assert hashlib.sha256(parent_file.read_bytes()).hexdigest()==parent_proof['candidate_sha256']
assert phase1_proof['parent_sha256']==proof['candidate_sha256']
lineage=[];cursor=args.parent
while cursor!='phase1':
 item_path=experiment/('candidate-'+cursor+'.py')
 item=json.loads(item_path.with_suffix('.json').read_text())
 assert hashlib.sha256(item_path.read_bytes()).hexdigest()==item['candidate_sha256']
 ancestor=item['parent'];ancestor_path=experiment/('parent-phase1.py' if ancestor=='phase1' else 'candidate-'+ancestor+'.py')
 assert hashlib.sha256(ancestor_path.read_bytes()).hexdigest()==item['parent_sha256']
 lineage.append({'name':cursor,**item});assert len(lineage)<8
 cursor=ancestor
report['comparison_parent_lineage']=lineage
report['comparison_parent_proof']=parent_proof
report['comparison_parent']=args.parent
assert all(hashlib.sha256((source_root/n).read_bytes()).hexdigest()==h for n,h in proof['sources'].items())
assert proof['candidate_sha256']=='a31a78f89e1ed71c007de2b692434cc0a0f1bc35626b22188418b3e715edd022'
actual_modules={}
for name,relative in (
 ('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.o_proj','vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision/o_proj.py'),
 ('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.hc_post','vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision/hc_post.py')):
 imported=importlib.import_module(name)
 actual=Path(imported.__file__).resolve()
 assert actual==(source_root/relative).resolve(),(name,str(actual))
 assert hashlib.sha256(actual.read_bytes()).hexdigest()==proof['sources'][relative]
 actual_modules[name]={'path':str(actual),'sha256':proof['sources'][relative]}
report['baseline_actual_modules']=actual_modules
report['harness_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
report['PTOAS_ROOT']=os.environ['PTOAS_ROOT']
assert Path(report['PTOAS_ROOT']).resolve()==sdk/'toolchain-wheel'
report['sdk_preflight']=json.loads((sdk/'results/pypto-import-preflight.json').read_text())
report['source_proof']=proof
checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
tokens=args.tokens
config=EngineArgs(model=str(checkpoint),tokenizer_mode='deepseek_v4',trust_remote_code=True,
 tensor_parallel_size=1,dtype='bfloat16',quantization='ascend',hf_overrides={'sliding_window':128},
 max_model_len=16384,max_num_seqs=40,max_num_batched_tokens=256,enable_prefix_caching=False,
 enforce_eager=False,block_size=32,speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},
 compilation_config={'cudagraph_mode':'FULL_DECODE_ONLY','cudagraph_capture_sizes':[tokens],'cache_dir':str(args.out/'vllm-cache')},
 additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,'fuse_norm_quant':True,'align_decode_capture_sizes':False},
 'enable_cpu_binding':False,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False}).create_engine_config()
save()
try:
 with native_session(config,0),torch.inference_mode():
  layer,details=make_layer(config,checkpoint,torch.device('npu:0'),4)
  report['weight_details']=details
  wo_a=layer.self_attn.wo_a.weight.detach();wo_b=layer.self_attn.wo_b.weight.detach()
  channel=layer.self_attn.wo_b.weight_scale.detach().reshape(-1).float().contiguous()
  assert wo_a.shape==(8,4096,1024) and wo_a.dtype==torch.bfloat16 and torch_npu.get_npu_format(wo_a)==29
  assert wo_b.shape==(8192,4096) and wo_b.dtype==torch.int8 and torch_npu.get_npu_format(wo_b)==29
  assert torch.count_nonzero(layer.self_attn.wo_b.weight_offset).cpu()==0
  start=torch.tensor(OPROJ_TILE_STARTS[OPROJ_TOKEN_MODES[tokens-1]],device='npu',dtype=torch.int32)
  assert start.shape==(16,8,8)
  torch.manual_seed(4190+tokens);torch.npu.manual_seed(4190+tokens)
  guarded=[]
  def buffer(shape,dtype,fill=-91):
   owner=torch.full((shape[0]+32,*shape[1:]),fill,dtype=dtype,device='npu')
   value=owner[16:16+shape[0]]
   guarded.append((owner,shape[0],fill));return value
  heads=buffer((tokens,32768),torch.bfloat16);heads.normal_(0,0.03)
  residual=buffer((tokens,4,4096),torch.bfloat16);residual.normal_(0,0.1)
  post=buffer((tokens,4),torch.float32);post.uniform_(0,1)
  comb=buffer((tokens,16),torch.float32);comb.uniform_(0,0.25)
  original_heads=heads.clone()
  bundles={}
  for side in ('frozen','resident','new'):
   bundles[side]={
    'projected':buffer((tokens,8192),torch.bfloat16),
    'quantized':buffer((tokens,8192),torch.int8),
    'token_scale':buffer((tokens,1),torch.float32),
    'attended':buffer((tokens,4096),torch.bfloat16),
    'output':buffer((tokens,4,4096),torch.bfloat16)}
  accum=buffer((tokens+127,8192),torch.float32)
  integer=buffer((tokens+63,4096),torch.int32)
  signal_owner=torch.full((module.WORDS+256,),-91,device='npu',dtype=torch.int32)
  signals=signal_owner[128:-128];signals.zero_()
  residual_flat=residual.view(tokens,16384)
  out_flat=bundles['resident']['output'].view(tokens,16384)
  for a,b in ((residual,residual_flat),(bundles['resident']['output'],out_flat)):
   assert a.is_contiguous() and b.is_contiguous() and a.data_ptr()==b.data_ptr() and a.storage_offset()==b.storage_offset()
  assert len({v.data_ptr() for v in (heads,residual,post,comb,accum,integer,signals,*bundles['resident'].values())})==12
  new_accum=buffer((tokens+127,8192),torch.float32)
  new_integer=buffer((tokens+63,4096),torch.int32)
  new_signal_owner=torch.full((module.WORDS+256,),-91,device='npu',dtype=torch.int32)
  new_signals=new_signal_owner[128:-128];new_signals.zero_()
  new_flat=bundles['new']['output'].view(tokens,16384)
  assert new_flat.is_contiguous() and new_flat.data_ptr()==bundles['new']['output'].data_ptr() and new_flat.storage_offset()==bundles['new']['output'].storage_offset()
  assert len({v.data_ptr() for v in (accum,integer,signals,new_accum,new_integer,new_signals,*bundles['resident'].values(),*bundles['new'].values())})==16
  candidate_file=experiment/('candidate-'+args.variant+'.py')
  candidate_proof=json.loads((experiment/('candidate-'+args.variant+'.json')).read_text())
  assert candidate_proof['parent_sha256']==parent_proof['candidate_sha256']
  assert candidate_proof['parent']==args.parent
  assert hashlib.sha256(candidate_file.read_bytes()).hexdigest()==candidate_proof['candidate_sha256']
  report['candidate_proof']=candidate_proof
  spec=importlib.util.spec_from_file_location('single_factor_candidate',candidate_file)
  new_module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=new_module;spec.loader.exec_module(new_module)
  assert all(getattr(new_module,k)==getattr(module,k) for k in ('WORDS','CORES','STRIDE'))
  readonly={n:sha(v) for n,v in {'wo_a':wo_a,'wo_b':wo_b,'channel':channel,'start':start,'residual':residual,'post':post,'comb':comb}.items()}
  report['readonly_sha256']=readonly
  report['input_A_sha256']={'heads':sha(heads),'residual':sha(residual),'post':sha(post),'comb':sha(comb)}
  pypto.torch.init()
  base=pypto.torch.register(o_proj_test,'resident_suffix_test::frozen_oproj')
  hc=pypto.torch.register(hc_post_test,'resident_suffix_test::frozen_post')
  candidate=pypto.torch.register(module.resident_suffix,'resident_suffix_test::candidate')
  new_op=pypto.torch.register(new_module.resident_suffix,'resident_suffix_test::new_candidate')
  def launch(side):
   b=bundles[side]
   if side=='frozen':
    base(heads,wo_a,wo_b,channel,start,b['projected'],b['quantized'],b['token_scale'],b['attended'])
    hc(b['attended'],residual,post,comb,b['output'])
   elif side=='resident':
    candidate(heads,wo_a,wo_b,channel,start,b['projected'],b['quantized'],b['token_scale'],b['attended'],residual_flat,post,comb,out_flat,accum,integer,signals)
   else:
    new_op(heads,wo_a,wo_b,channel,start,b['projected'],b['quantized'],b['token_scale'],b['attended'],residual_flat,post,comb,new_flat,new_accum,new_integer,new_signals)
  def guards():
   for owner,rows,fill in guarded:
    assert torch.all(owner[:16].cpu()==fill) and torch.all(owner[16+rows:].cpu()==fill),'guard modified'
   for owner in (signal_owner,new_signal_owner):assert torch.all(owner[:128].cpu()==-91) and torch.all(owner[-128:].cpu()==-91)
  def generation(side='resident'):
   words=(new_signals if side=='new' else signals).cpu().reshape(6,72,128);g=int(words[0,0,0]);assert g>0
   assert torch.count_nonzero(words[:,:,1:])==0
   used=torch.zeros((6,72),dtype=torch.bool);used[0,:]=True;used[1,:24]=True;used[2,24:]=True;used[3,24:]=True;used[4,:24]=True;used[5,24:]=True
   assert torch.all(words[:,:,0][used]==g) and torch.count_nonzero(words[:,:,0][~used])==0
   return g
  def poison(side):
   for key,v in bundles[side].items():
    if v.is_floating_point():v.fill_(float('nan'))
    elif side=='frozen':v.copy_(torch.bitwise_not(bundles['resident'][key]))
    else:v.copy_(torch.bitwise_not(bundles['frozen'][key]))
  def compare(label):
   result={}
   for side in ('resident','new'):
    for key,a in bundles[side].items():
     x=a.cpu();y=bundles['frozen'][key].cpu()
     if x.is_floating_point():assert torch.isfinite(x).all() and torch.isfinite(y).all()
     equal=bit_equal(x,y);diff=x.float()-y.float()
     result[side+'.'+key]={'bit_equal':equal,'different_elements':int((x!=y).sum()),'max_abs':float(diff.abs().max()),'first':(x!=y).nonzero()[:4].tolist()}
   report.setdefault('comparisons',{})[label]=result;save();guards()
   assert generation()==generation('new'),'generation drift'
   if not all(v['bit_equal'] for v in result.values()):
    torch.save({side:{k:v.cpu() for k,v in b.items()} for side,b in bundles.items()},args.out/'first-difference.pt')
    raise RuntimeError('first suffix difference: '+label)
  for side in bundles:launch(side)
  torch.npu.synchronize();compare('eager_warmup')
  graphs={};stream=torch.npu.Stream();stream.wait_stream(torch.npu.current_stream())
  with torch.npu.stream(stream):
   for side in bundles:
    graph=torch.npu.NPUGraph()
    with torch.npu.graph(graph,stream=stream):launch(side)
    graphs[side]=graph
   torch.npu.synchronize()
   before=generation()
   for side in bundles:poison(side);graphs[side].replay()
   torch.npu.synchronize();assert generation()==before+1;compare('FULL_A')
   baseline_a={k:v.cpu() for k,v in bundles['frozen'].items()}
   heads.add_(0.03125)
   for side in bundles:poison(side);graphs[side].replay()
   torch.npu.synchronize();compare('FULL_B')
   assert not bit_equal(baseline_a['output'],bundles['frozen']['output'].cpu()),'stale input'
   heads.copy_(original_heads)
   for side in bundles:poison(side);graphs[side].replay()
   torch.npu.synchronize();compare('FULL_A_restore')
   assert all(bit_equal(v,bundles['resident'][k].cpu()) for k,v in baseline_a.items())
   samples={s:[] for s in bundles}
   for window in range(12):
    order=list(bundles);shift=window%len(order);order=order[shift:]+order[:shift]
    if window%2:order.reverse()
    before=generation();before_new=generation('new')
    for side in order:
     start_event,end_event=torch.npu.Event(enable_timing=True),torch.npu.Event(enable_timing=True)
     start_event.record()
     for _ in range(100):graphs[side].replay()
     end_event.record();end_event.synchronize()
     samples[side].append(start_event.elapsed_time(end_event)*1000/100)
    assert generation()==before+100 and generation('new')==before_new+100
    compare('window_'+str(window))
  assert readonly=={n:sha(v) for n,v in {'wo_a':wo_a,'wo_b':wo_b,'channel':channel,'start':start,'residual':residual,'post':post,'comb':comb}.items()}
  assert sha(heads)==sha(original_heads)
  report['timings']={'unit':'us/O-proj+HC-post FULL graph replay','windows':12,'replays':100,'outliers_removed':False,'samples':samples,'summary':{s:{'min':min(v),'median':statistics.median(v),'mean':statistics.mean(v),'max':max(v)} for s,v in samples.items()}}
  report['actual_acl_graph']=True;report['guards']=True;report['readonly']=True;report['final_generation']={'parent':generation(),'new':generation('new')};report['pass']=report['complete']=True;save()
except BaseException:
 report['error']=traceback.format_exc();save();raise
finally:
 report['finished_unix']=time.time();save()
