"""单独测T126 WO-A末尾15次K16的heads驻留；先显式Tile控制，再只改驻留。"""
from pathlib import Path
import ast
import copy
import hashlib
import json
import textwrap

root=Path(__file__).resolve().parent
parent=(root/'parent-phase1.py').read_text()
a=parent.index('                    v4_wide_row =')
b=parent.index('\n                else:\n',a)+1
body=ast.parse(textwrap.dedent(parent[a:b])).body
class ExplicitTile(ast.NodeTransformer):
    def visit_Call(self,node):
        node=self.generic_visit(node)
        if ast.unparse(node.func)=='pl.slice' and isinstance(node.args[0],ast.Name) and node.args[0].id=='heads':
            node.func=ast.parse('pl.load',mode='eval').body
            node.args=[node.args[0],node.args[2],node.args[1]]
            node.keywords.append(ast.keyword(arg='target_memory',value=ast.parse('pl.MemorySpace.Mat',mode='eval').body))
        if ast.unparse(node.func)=='pl.assemble':
            assert ast.unparse(node.args[1])=='v4_wide_acc'
            node.func=ast.parse('pl.store',mode='eval').body
            node.args=[node.args[1],node.args[2],node.args[0]]
        return node
    def visit_Subscript(self,node):
        if not isinstance(node.value,ast.Name) or node.value.id!='wo_a':return self.generic_visit(node)
        axes=node.slice.elts;g,k,c=[ax.lower for ax in axes]
        width=k_width=ast.literal_eval(axes[1].upper.right)
        assert width in (16,256) and ast.literal_eval(axes[2].upper.right)==128
        text=f'pl.reshape(pl.load(wo_a, [{ast.unparse(g)}, {ast.unparse(k)}, {ast.unparse(c)}], [1, {width}, 128], target_memory=pl.MemorySpace.Mat), [{width}, 128])'
        return ast.copy_location(ast.parse(text,mode='eval').body,node)
body=[ExplicitTile().visit(copy.deepcopy(node)) for node in body]
module=ast.fix_missing_locations(ast.Module(body=body,type_ignores=[]))
block=textwrap.indent(ast.unparse(module)+'\n',' '*20)
matbase=parent[:a]+block+parent[b:]
guard='                if rows <= 16:\n                    v4_same_start = 0\n'
assert matbase.count(guard)==1
matbase=matbase.replace(guard,guard+'                if v4_first_start % 16 != 0:\n                    v4_same_start = 0\n')
tree=ast.parse(textwrap.dedent(block));tail=next(n for n in tree.body if isinstance(n,ast.For) and ast.unparse(n.target)=='v4_wide_tail')
preload=ast.parse('''v4_tail_base = (v4_wide_first_block + 240) % 256 * 16
v4_tail_heads = pl.load(heads, [v4_wide_row, v4_group * 4096 + v4_tail_base], [128, 256], valid_shape=[v4_wide_valid, 256], target_memory=pl.MemorySpace.Mat)
''').body
index=tree.body.index(tail);tree.body[index:index]=preload
assign=next(n for n in tail.body if isinstance(n,ast.Assign) and ast.unparse(n.targets[0])=='v4_wide_tail_x')
assign.value=ast.parse('pl.tile.slice(v4_tail_heads, [128, 16], [0, (v4_wide_tail - 240) * 16], valid_shape=[v4_wide_valid, 16])',mode='eval').body
newblock=textwrap.indent(ast.unparse(ast.fix_missing_locations(tree))+'\n',' '*20)
tailpre=parent[:a]+newblock+parent[b:];tailpre=tailpre.replace(guard,guard+'                if v4_first_start % 16 != 0:\n                    v4_same_start = 0\n')
variants={'matbase':(matbase,'phase1','v4 fastpath explicit Mat tiles; same ordered MMA sizes and GM store; aligned guard'), 'tailpreload':(tailpre,'matbase','only retain final K256 heads tile in L1 and slice15 K16 views; same weight loads and all MMA widths/order')}
for name,(source,ancestor,description) in variants.items():
    ast.parse(source);path=root/f'candidate-{name}.py';path.write_text(source)
    base=parent if ancestor=='phase1' else matbase
    path.with_suffix('.json').write_text(json.dumps({'parent':ancestor,'parent_sha256':hashlib.sha256(base.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(source.encode()).hexdigest(),'change':description,'scope':'independent 16<T<192 aligned diagnostic; not installed','formal_baseline':'48c58ce7c467dfce63d5cb5c41afd225488d6012'},indent=2)+'\n')
# Tile window proof for each possible eligible seed and valid row count.
for s in range(0,256,16):
    base=(s+240)%256
    assert base<=240
    for i in range(241,256):
        offset=(i-240)*16
        assert 0<=offset and offset+16<=256
        assert [base*16+offset+k for k in range(16)]==[((s+i)%256)*16+k for k in range(16)]
print('PASS: explicit Mat and tail residency syntax/physical windows')
