"""PMU任务失败仍保留原始设备计数；独立验证，不修改task结果。"""
import csv
import io
import json
import statistics
import tarfile
from pathlib import Path

root = Path(__file__).resolve().parent
expected = json.loads((root / 'PMU_DEVICE_VALIDATION.json').read_text())
assert expected['task_exit'] == 1
with tarfile.open(root / 'woa-pmu-k128narrow-t240-v1-counters.tar.gz') as archive:
    result = json.load(archive.extractfile('woa-pmu-k128narrow-t240-v1/result.json'))
    assert not result['pass'] and not result['complete']
    assert "NameError: name 'samples' is not defined" in result['error']
    checks = [v for group in result['comparisons'].values() for v in group.values()]
    assert len(checks) == 70 and all(v['bit_equal'] for v in checks)
    members = [m for m in archive.getmembers() if m.name.endswith('kernel_details.csv')]
    assert len(members) == 9
    for arm in ('resident', 'new'):
        rows = []
        files = sorted((m for m in members if '/' + arm + '-pmu-r' in m.name), key=lambda m: m.name)
        assert len(files) == 3
        for member in files:
            csv_rows = list(csv.DictReader(io.StringIO(archive.extractfile(member).read().decode())))
            selected = [r for r in csv_rows if r['Name'] == 'aicore_kernel_mode_0']
            assert len(selected) == 1
            rows.append({k: float(selected[0][k]) for k in expected['arms'][arm]['median']})
        assert rows == expected['arms'][arm]['samples']
        assert {key: statistics.median(r[key] for r in rows) for key in rows[0]} == expected['arms'][arm]['median']
print('9 counter CSVs present; 6 MIX device rows match saved medians; task remains failed')
