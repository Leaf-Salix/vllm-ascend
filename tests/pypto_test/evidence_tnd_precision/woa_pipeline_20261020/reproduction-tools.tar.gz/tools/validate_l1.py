"""离线复核原始L1结构及跨度；不改变被测结果。"""
import json
import tarfile
from pathlib import Path

root = Path(__file__).resolve().parent
result = json.loads((root / 'woa-dfx-k128narrow-t240-v3.json').read_text())
checks = []
with tarfile.open(root / 'woa-dfx-k128narrow-t240-v3-evidence.tar.gz') as archive:
    members = {m.name: m for m in archive.getmembers()}
    for entry in result['DFX']['records']:
        number = entry['window']
        middle = '' if number == 0 else f'window_{number}/'
        path = 'woa-dfx-k128narrow-t240-v3/dfx/' + middle + 'chip_swimlane_records.json'
        record = json.load(archive.extractfile(members[path]))
        meta, tasks = record['metadata'], record['aicore_tasks']
        assert record['chip_swimlane_level'] == 1
        assert meta['clock_freq_hz'] == 50_000_000 and meta['num_cores'] == 72
        assert meta['core_types'] == ['aic'] * 24 + ['aiv'] * 48
        assert meta['dropped_run_boundaries'] == 0
        assert len(meta['run_boundaries']) == (2 if entry['side'] == 'frozen' else 1)
        assert all(len(row) == 6 and 0 <= row[0] < 72 and row[4] >= row[3] for row in tasks)
        assert len(tasks) == (522 if entry['side'] == 'frozen' else 72)
        for key, rows in [('total', tasks), ('AIC', [r for r in tasks if r[0] < 24]), ('AIV', [r for r in tasks if r[0] >= 24])]:
            metric = entry['total'] if key == 'total' else entry['roles'][key]
            assert len(rows) == metric['records']
            span = (max(r[4] for r in rows) - min(r[3] for r in rows)) / 50
            assert abs(span - metric['span_us']) < 1e-8
        checks.append({'window': number, 'side': entry['side'], 'rows': len(tasks), 'roots': len(meta['run_boundaries']), 'span_us': entry['total']['span_us']})
assert len(checks) == 9
assert result['pass'] and result['complete'] and result['guards'] and result['readonly']
assert result['final_generation'] == {'parent': 7, 'new': 7}
(root / 'L1_DEVICE_VALIDATION.json').write_text(json.dumps({'pass': True, 'scope': 'L1 schema and span verification; not formal performance or pure wait decomposition', 'windows': checks}, indent=2) + '\n')
print('9 raw windows independently verified')
