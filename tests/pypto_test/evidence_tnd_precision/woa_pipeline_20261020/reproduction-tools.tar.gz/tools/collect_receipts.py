"""归档本轮自有任务最终状态、日志及CPU编译回执。"""
import io
import json
from pathlib import Path
import subprocess
import tarfile

sdk = Path('/data/pyptouser/yejia/csa-spmd-sdk-20261020')
root = sdk / 'woa-pipeline-20261020'
runs = json.loads((root / 'RUNS.json').read_text())
archive_path = sdk / 'woa-pipeline-run-receipts-v1.tar.gz'
statuses = {}
with tarfile.open(archive_path, 'w:gz') as archive:
    def blob(name, value):
        encoded = value.encode()
        info = tarfile.TarInfo(name)
        info.size = len(encoded)
        archive.addfile(info, io.BytesIO(encoded))
    for case, item in runs['runs'].items():
        status = subprocess.run(['task-submit', '--status', item['task']], capture_output=True, text=True, timeout=30)
        assert status.returncode == 0
        expected = f"completed (exit={item['exit_code']})"
        assert expected in status.stdout, (case, status.stdout, expected)
        statuses[case] = {'task': item['task'], 'status': status.stdout.strip()}
        blob(case + '/task-status.txt', status.stdout + status.stderr)
        log = subprocess.run(['task-submit', '--log', item['task']], capture_output=True, text=True, timeout=30)
        blob(case + '/task.log', log.stdout + log.stderr)
        for path in (sdk / 'results' / case / 'result.json', sdk / 'results' / (case + '-run.log')):
            if path.is_file():
                archive.add(path, arcname=case + '/' + path.name)
    for n in range(1, 10):
        case = f'woa-pipeline-cpu-v{n}'
        for path in (sdk / 'results' / case / 'result.json', sdk / 'logs' / (case + '.log')):
            if path.is_file():
                archive.add(path, arcname='cpu/' + case + '/' + path.name)
    blob('FINAL_STATUSES.json', json.dumps(statuses, indent=2) + '\n')
print(archive_path)
print('all tasks ended:', len(statuses))
