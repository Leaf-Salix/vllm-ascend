"""归档原样实验材料；不将候选安装到正式代码。"""
from pathlib import Path
import hashlib
import json
import shutil
import tarfile

root = Path(__file__).resolve().parent
repo = root.parents[2] / 'vllm-ascend-nalinaly-tnd-20261008-codex'
dest = repo / 'tests/pypto_test/evidence_tnd_precision/woa_pipeline_20261020'
dest.mkdir(parents=True, exist_ok=True)
report = repo / 'tests/pypto_test/DSV4_FLASH_CSA_TND_WOA_PIPELINE_OWNER_AB_20261020.md'
report.write_bytes((root / 'REPORT_DRAFT.md').read_bytes())
raw = sorted(root.glob('*.json'))
with tarfile.open(dest / 'raw-results.tar.gz', 'w:gz') as archive:
    for path in raw:
        archive.add(path, arcname=path.name)
(dest / 'RAW_SHA256.json').write_text(json.dumps({p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in raw}, indent=2) + '\n')
with tarfile.open(dest / 'reproduction-tools.tar.gz', 'w:gz') as archive:
    for path in sorted([*root.glob('*.py'), *root.glob('*.sh')]):
        archive.add(path, arcname='tools/' + path.name)
    for directory in sorted(root.glob('cpu-v*-source')):
        for path in sorted(directory.iterdir()):
            if path.is_file():
                archive.add(path, arcname='historical/' + directory.name + '/' + path.name)
    for name in ('resident-suffix-candidate.py', 'RESIDENT_SUFFIX_SOURCE_PROOF.json', 'SDK_SOURCES.json', 'sdk-preflight.py'):
        archive.add(root.parent / name, arcname='reference/' + name)
    for path in sorted((root.parent / 'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_spmd').glob('*.py')):
        archive.add(path, arcname='nalinaly-reference/' + path.name)
for path in sorted(root.glob('*.tar.gz')):
    shutil.copy2(path, dest / path.name)
with tarfile.open(dest / 'independent-reviews.tar.gz', 'w:gz') as archive:
    for path in sorted(root.glob('*REVIEW.md')):
        archive.add(path, arcname=path.name)
for name in ('CHECKLIST.md', 'CHECK_HISTORY.md', 'REPRODUCTION.md'):
    shutil.copy2(root / name, dest / name)
(dest / 'README.md').write_text('''# WO-A搬运、流水及owner增量对拍证据

正式精度源48c58ce7c与旧后缀a31a78f8保留。候选只在独立实验文件中；没有切换默认路由。
结论见[报告](../../DSV4_FLASH_CSA_TND_WOA_PIPELINE_OWNER_AB_20261020.md)。

## 文件

| 文件 | 内容 |
| --- | --- |
| raw-results.tar.gz / RAW_SHA256.json | 12项AB原始JSON、DFX、proof、RUNS任务清单、离线复核结果；保留被测字节 |
| reproduction-tools.tar.gz | 各候选及父版、历史probe、CPU检查、运行/统计脚本、失败源码快照和固定nalinaly参考 |
| woa-pipeline-run-receipts-v1.tar.gz | 追加M256前15项任务最终状态、CPU v1..v9回执快照；3项失败保留 |
| woa-pipeline-cpu-v5-generated.tar.gz | nopipe/K128实际PTO、C++、编译报告 |
| woa-pipeline-cpu-v7-generated.tar.gz | 显式Mat控制/heads-tail实际生成物 |
| woa-pipeline-cpu-v9-generated.tar.gz | tail权重驻留及两项owner组合实际生成物 |
| woa-pipeline-cpu-v11-generated.tar.gz | M128/M256同K128单缓冲配对控制生成物 |
| woa-pipeline-run-receipts-v2.tar.gz | 追加M256任务后的16项最终状态、CPU v1..v11；v1为先前15项快照 |
| woa-dfx-k128narrow-t240-v3-evidence.tar.gz | 9个L1原始窗口及结果/log |
| woa-pmu-k128narrow-t240-v1-counters.tar.gz | PMU失败任务的原始result/log与9份CSV；设备计数独立核验，不改为PASS |
| independent-reviews.tar.gz | 设计、源/生成物、owner依赖、最终结果独立审查 |
| REPRODUCTION.md | 环境身份、CPU资格、版本脚本选择、设备门禁、离线复核 |
| CHECK_HISTORY.md | 编译、观测脚本及离线分析错误的修正历史 |
| SHA256.json | 本目录所有发布文件SHA，不包含自身 |

## 范围限制

真实L4权重，合成后缀输入；金值是冻结PTO数学。本轮不是新的Native整层或整模型验收。
12项正式AB五边界160项逐位检查均通过，仍没有候选稳定快于冻结后缀；不进入8K/128K。
PMU/L1可重叠，不能相加或相减成为计算、搬运、纯等待的唯一分解。
SDK原环境和正式基准均保留，不把局部实验收益误记为已交付整层收益。
''')
manifest = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dest.iterdir()) if p.is_file() and p.name != 'SHA256.json'}
(dest / 'SHA256.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(report)
print(dest)
