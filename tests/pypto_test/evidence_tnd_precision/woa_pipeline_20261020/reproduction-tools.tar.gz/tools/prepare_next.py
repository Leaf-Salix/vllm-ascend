"""准备独立的下一因素及增量组合；上卡仍须前序硬件门禁。"""
from pathlib import Path
import ast,hashlib,json
r=Path(__file__).resolve().parent
phase=(r/'parent-phase1.py').read_text();owner=(r/'candidate-owner2.py').read_text()
old='    signals = wait_group(signals, 2, 24, 72, generation)\n    quant_rows = (rows + 7) // 8'
a=owner.index('    quant_rows = (rows + 7) // 8');b=owner.index('    for block in pl.range(worker, quant_rows, 48):',a);replacement=owner[a:b].rstrip('\n')
assert phase.replace(old,replacement)==owner
head=(r/'candidate-tailpreload.py').read_text()
needle='                    for v4_wide_tail in pl.range(241, 256):'
# Explicit Tile AST unparse in prepare_tail preserves this spelling.
assert head.count(needle)==1
pre='                    v4_tail_weights = pl.reshape(pl.load(wo_a, [v4_group, v4_tail_base, v4_col], [1, 256, 128], target_memory=pl.MemorySpace.Mat), [256, 128])\n'
both=head.replace(needle,pre+needle)
oldw='                        v4_wide_tail_w = pl.reshape(pl.load(wo_a, [v4_group, v4_wide_tail_k, v4_col], [1, 16, 128], target_memory=pl.MemorySpace.Mat), [16, 128])'
neww='                        v4_wide_tail_w = pl.tile.slice(v4_tail_weights, [16, 128], [(v4_wide_tail - 240) * 16, 0])'
assert both.count(oldw)==1;both=both.replace(oldw,neww)
variants={'tailboth':(both,'tailpreload','only retain tail K256 weights in L1 as well; same15 K16 MMAs'), 'tailowner2':(head.replace(old,replacement),'owner2','incremental add verified explicit-Mat heads-tail residency implementation; all output math unchanged'), 'k128owner2':((r/'candidate-k128narrow.py').read_text().replace(old,replacement),'owner2','incremental add verified K128 transport; original owner2 wait and math unchanged')}
for n,(src,parent,change) in variants.items():
 ast.parse(src);assert (old not in src) if n!='tailboth' else True
 p=r/f'candidate-{n}.py';p.write_text(src);parentfile=r/f'candidate-{parent}.py'
 p.with_suffix('.json').write_text(json.dumps({'parent':parent,'parent_sha256':hashlib.sha256(parentfile.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(src.encode()).hexdigest(),'change':change,'scope':'independent candidate; require predecessor hardware pass before submitting; not installed','formal_baseline':'48c58ce7c467dfce63d5cb5c41afd225488d6012'},indent=2)+'\n')
print('PASS next candidates syntax and composition')
