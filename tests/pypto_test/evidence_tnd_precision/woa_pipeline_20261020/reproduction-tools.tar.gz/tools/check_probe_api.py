import runpy,sys,inspect,json
from pathlib import Path
sdk=Path('/data/pyptouser/yejia/csa-spmd-sdk-20261020')
sys.argv=[str(sdk/'sdk-preflight.py')];runpy.run_path(sys.argv[0],run_name='__main__')
import pypto.torch,torch_npu
sig=inspect.signature(pypto.torch.init)
sig.bind(enable_chip_swimlane=1,enable_dep_gen=False,output_dir=sdk/'results/probe-api-dummy')
assert not torch_npu.npu.is_initialized()
print(json.dumps({'api':str(sig),'pass':True,'device_execution':False}))

import ast
p=sdk/'woa-pipeline-20261020/ab_probe_dfx.py'
calls=[n for n in ast.walk(ast.parse(p.read_text())) if isinstance(n,ast.Call) and ast.unparse(n.func)=='pypto.torch.init']
assert len(calls)==1 and {k.arg for k in calls[0].keywords}=={'enable_chip_swimlane','enable_dep_gen','output_dir'}
assert not calls[0].args
print('single configured DFX init PASS')
