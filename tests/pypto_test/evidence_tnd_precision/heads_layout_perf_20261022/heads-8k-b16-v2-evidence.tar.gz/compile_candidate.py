"""Full root and orchestration compile, without NPU initialization."""
import json
import hashlib
import os
from pathlib import Path
import sys
import traceback
import torch
import torch_npu
import pypto.torch
from pypto.runtime import RunConfig
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program
from pypto.runtime.kernel_compiler import KernelCompiler
from source_identity import source_identity
from load_candidate import entry_for

HERE = Path(__file__).resolve().parent
arm = sys.argv[1]
assert arm in ('direct','packed') and os.environ['ASCEND_RT_VISIBLE_DEVICES'] == ''
assert os.environ['CMAKE_BUILD_PARALLEL_LEVEL'] == '4'
assert not torch.npu.is_initialized()
record = {'arm':arm,'pass':False,'source':source_identity(),'device_execution':False,
          'candidate_source_sha256':hashlib.sha256((HERE/'SOURCE.json').read_bytes()).hexdigest()}
try:
    entry = entry_for(arm)
    registered = pypto.torch.register(entry,'heads_'+arm+'_cpu::attention')
    assert len(registered._schema.arguments) == 64
    out = HERE/('compiled-'+arm)
    out.mkdir(exist_ok=False)
    entry.compile(config=RunConfig(platform='a2a3',save_kernels=True,save_kernels_dir=str(out)))
    program = entry.specialize()
    abi = kernel_abi_for_program(program,platform='a2a3',runtime='tensormap_and_ringbuffer')
    _compile_impl(program,output_dir=str(HERE/('kernel-'+arm)),platform='a2a3',_kernel_abi=abi)
    cpp = list((out/'orchestration').glob('*.cpp'))
    assert len(cpp) == 1
    KernelCompiler().compile_orchestration('tensormap_and_ringbuffer',str(cpp[0]))
    assert not torch.npu.is_initialized()
    artifacts={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest()
               for p in out.rglob('*') if p.is_file() and p.suffix in ('.cpp','.py','.json','.so')}
    record.update({'pass':True,'schema':str(registered._schema),'orchestration':str(cpp[0]),
                   'npu_initialized':False,'artifacts':artifacts})
except BaseException:
    record['error'] = traceback.format_exc()
finally:
    (HERE/('compile-'+arm+'-receipt.json')).write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record,indent=2),flush=True)
if not record['pass']: raise SystemExit(1)
